"""Independent changed/reused physical-report audit, zero new PF/model."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
import psutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/vcsa_development/common_control_selected_physical_audit'
PRIOR=ROOT/'outputs/vcsa_development/state_control_selected_replay'
CONTROL=ROOT/'outputs/vcsa_development/common_information_control_pilot'
DATA=ROOT/'outputs/vcsa_development/training_interface'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (OUT/'independent_audit.json').exists()
pid=int((OUT/'owner.claim').read_text())
if psutil.pid_exists(pid):assert not any('replay_vcsa_common_control_changed_actions.py' in arg for arg in psutil.Process(pid).cmdline())
manifest=read(OUT/'manifest.json')
for name,entry in manifest.items():assert sha(OUT/name)==entry['sha256'] and (OUT/name).stat().st_size==entry['bytes']
protocol=read(OUT/'protocol.json');assert sha(ROOT/'work/replay_vcsa_common_control_changed_actions.py')==protocol['source_sha256']
for folder,key in [(PRIOR,'prior_physical_manifest_sha256'),(CONTROL,'control_manifest_sha256'),(DATA,'data_manifest_sha256')]:
    assert sha(folder/'manifest.json')==protocol[key]
    for name,entry in read(folder/'manifest.json').items():assert sha(folder/name)==entry['sha256']
for path,digest in protocol['frozen_sources'].items():assert sha(ROOT/path.replace('\\','/'))==digest
choices={r['id']:r for r in read(CONTROL/'final_rows.json')}
labels={r['local_observation_id']:r for r in read(DATA/'rows.json')}
old={r['id']:r for file in (PRIOR/'worlds').glob('*.json') for r in read(file)['records']}
records=read(OUT/'Actual_All_Action_Replay_Records.json')
assert len(records)==len({r['id'] for r in records})==48 and {r['id'] for r in records}==set(choices)
fresh=0;reused=0
for record in records:
    row=labels[record['id']]
    assert (record['scenario_id'],record['split'],record['zone'])==(row['scenario_id'],row['split'],row['zone'])
    assert record['scenario_sha256']==row['scenario_sha256']
    if record['reused_prior_exact_report']:
        assert {k:v for k,v in record.items() if k not in {'reused_prior_exact_report','prior_report_manifest_sha256'}}==old[record['id']]
        assert record['prior_report_manifest_sha256']==sha(PRIOR/'manifest.json')
    if not row['training_eligible']:
        assert record['retained_invalid_input'] and record['hard_abstained'];continue
    action=choices[record['id']]['action']
    assert record['action']=={'add_shunts_q_mvar':{str(action['bus']):float(action['q_mvar'])}}
    candidate=next(c for c in row['candidate_labels'] if (c['bus'],c['q_mvar'])==(action['bus'],action['q_mvar']))
    after=record['independent_replay_metrics'];original=record['original_verification']['after']
    assert all(abs(after[k]-original[k])<=1e-10 and abs(after[k]-candidate['after_metrics'][k])<=1e-10 for k in after)
    assert len(record['replayed_bus_voltages'])==118
    assert abs(min(record['replayed_bus_voltages'].values())-after['vmin'])<=1e-10
    assert abs(max(record['replayed_bus_voltages'].values())-after['vmax'])<=1e-10
    assert sum(v<.95 for v in record['replayed_bus_voltages'].values())==after['uv_count']
    assert record['normal_guard_admissible']==bool(candidate['guard_admissibility_target'])
    if record['reused_prior_exact_report']:reused+=1
    else:fresh+=1
summary=read(OUT/'summary.json');assert summary['passed'] and fresh==summary['freshly_verified_actions']==3 and reused==summary['reused_exact_action_reports']==44
costs=summary['new_costs'];assert {k:v['attempts'] for k,v in costs.items()}==protocol['new_phases']
assert sum(v['attempts'] for v in costs.values())==9 and all(v['exceptions']==0 and v['returns']==v['attempts'] for v in costs.values())
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'passed':True,'scientific_manifest_members':len(manifest),
    'exact_view_identities':48,'fresh_physical_action_reports':3,'reused_exact_physical_action_reports':44,
    'new_actual_PF_attempts':9,'new_PF_exceptions':0,'continuous_per_bus_selected_state_checks':47,
    'prior_actual_PF_study_cost':139,'new_audit_PF_model_calls':0,'source_manifest_sha256':sha(OUT/'manifest.json'),
    'scope':'All47 selected one-state control actions covered by exact independent physics; one invalid retained. No LLM/full-DSE/operational-optimum claim',
    'source_sha256':sha(Path(__file__))}
(OUT/'independent_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
