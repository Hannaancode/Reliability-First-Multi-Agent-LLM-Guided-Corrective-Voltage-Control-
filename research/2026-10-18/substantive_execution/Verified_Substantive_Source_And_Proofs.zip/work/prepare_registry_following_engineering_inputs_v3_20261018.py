"""Use the ACTUAL selected paid current NET, never substitute a field-only replay."""
import copy,hashlib,json,os,time
from pathlib import Path
import numpy as np,pandapower as pp
from full_receding_paid_campaign_20261015 import R,B as OLD,read,put,sha,pin,METHODS
from equal_operation_benchmark_v2 import decode_capsule
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible
from frozen_physics_loader import load_stack
from lazy_paid_lineage_receipts_v1_20261018 import ArchivedLineage
from bounded_paid_lookahead_physics_20261014 import load_after
import paid_receding_referenced_commit_v2_20261018 as transport
import paid_receding_commit_and_history_v1 as original_state
B=R/'outputs/registry_following_engineering_input_preparation_v3_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();p=read(OLD/'Protocol.json');pin(p)
    put(B/'Protocol.json',{'role':'CORRECT_ACTUAL_SELECTED_CURRENT_NET_ENGINEERING_INPUTS_NOT_REPLAY_STATE_SUBSTITUTION',
        'source_sha256':sha(Path(__file__)),'bound_seconds':300,
        'selection':'First originally declared unfinished branch; latest observed actual commit after last complete source checkpoint. Fixed ascending eligible actionSHA order, no reward selection.',
        'source_case_rule':'Actual selected paid successor NET from its exact source cache record. Independent replay may bind all118fields yet differs in hidden native case arrays; it cannot substitute the selected state.',
        'global_coverage_and_reader_and_owner_pending':True,'science_calls_allowed':0})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    forbidden=[]
    def fail(*a,**k):forbidden.append(True);raise AssertionError('No science in input preparation')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,fail)
    result=read(OLD/'actual/Result.json');scope=read(R/'outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json')
    assert scope['status']=='PASS_ALL_RECORDED_COMMITTED_TRANSITIONS_AND_CLOSED_ENDPOINTS_SCOPED_ONLY' and scope['all_recorded_commits_checked']==26
    closed={(x['world'],x['mode']) for x in result['branches']};entry,method=next((e,m) for e in p['endpoints'] for m in METHODS if (e['world'],m) not in closed)
    journal=OLD/'actual/scientific.jsonl';assert sha(journal)==scope['journal_SHA256']
    with journal.open('rb') as f:
        f.seek(max(0,journal.stat().st_size-4*1024**2));f.readline();matches=[]
        while raw:=f.readline():
            end=f.tell();e=json.loads(raw)
            if e['event']=='actual_receding_first_commit' and (e['data']['world'],e['data']['method'])==(entry['world'],method):
                matches.append({'event':e,'reference':{'offset':end-len(raw),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}})
    selected=max(matches,key=lambda x:x['reference']['offset']);record=selected['event']['data']['record']
    request=result['checkpoint_requests'][-1];saved=original_state.restore(R/request['checkpoint'],request['receipt'])
    assert saved['cursor']['world']==entry['world'] and saved['cursor']['committed_transitions']==record['following_cursor']['committed_transitions'][:-1]
    before=copy.deepcopy(saved['cursor']);before['commit_mode']=transport.MODE;transport.validate(saved['net'],before)
    oldkey=point_key(saved['net'],before)+'|'+action_key(record['candidate']);archive=ArchivedLineage();paid=archive.archived_receipt(oldkey)
    assert paid['receipt_id']==record['paid_receipt_id'] and paid['verdict']['accepted']
    after=load_after(paid['after_reference'],None)['net']
    with (OLD/'actual/capsules.bin').open('rb') as f:replay=decode_capsule(f,record['replay_receipt']['after'])['net']
    assert transport.fields(after)==transport.fields(replay)
    cursor=copy.deepcopy(record['following_cursor']);old_mode=cursor['commit_mode'];cursor['commit_mode']=transport.MODE;transport.validate(after,cursor)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    domain=build_current_domain(after,cursor,runner=runner,zones=zones);cursor=domain['expanded_cursor_for_separately_fixed_future_protocol']
    point=point_key(after,cursor);replay_point=point_key(replay,cursor)
    differences={}
    for name in ['bus','branch','gen']:
        a=after['_ppc'][name];b=replay['_ppc'][name]
        differences[name]={'shape_equal':a.shape==b.shape,'exact_equal':np.array_equal(a,b),'different_entries':int(np.count_nonzero(a!=b)),'max_absolute_delta':float(np.max(abs(a-b)))}
    eligible=[r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if resource_eligible(r,cursor)]
    missing=[r for r in sorted(eligible,key=action_key) if point+'|'+action_key(r) not in archive.index];assert len(missing)>=2
    details={'status':'PASS_EXACT_ACTUAL_SELECTED_CURRENT_NET_AND_SOURCE_RESOURCE_CURSOR_INPUTS',
        'source_entry':entry,'method':method,'source_before_checkpoint':request,'source_commit_reference':selected['reference'],'source_commit_record':record,
        'selected_paid_old_input_key':oldkey,'selected_paid_after_reference':paid['after_reference'],
        'current_point_key':point,'replay_capsule_point_key_not_a_substitute':replay_point,
        'selected_vs_replay_full_case_differences':differences,'all118_fields_equal':True,
        'source_NET_role':'ACTUAL_SELECTED_PAID_SUCCESSOR','source_old_MODE':old_mode,'current_resource_cursor':cursor,'current_metrics':runner.rescue.grid_metrics(after),
        'candidate_following_rows':missing[:2],'candidate_following_keys':[point+'|'+action_key(r) for r in missing[:2]],
        'current_menu_rows':len(domain['all_declared_original9Q_ordinary_and_owned_joint_identities']),'eligible_rows':len(eligible),'inspected_lineage_absent_eligible_rows':len(missing),
        'global_unexecuted_status':'UNKNOWN_PENDING_RELEVANT_CONTRACT_COVERAGE','new_seed_if_separate_owner_justified':20261018,
        'old_missing26th_state_or_RNG_inferred':False,'old_original_absolute_bound_not_extended':True,
        'original_journal_sha256':scope['journal_SHA256'],'lineage_anchors':archive.anchors,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started}
    assert not forbidden and time.perf_counter()-started<300
    put(B/'Prepared_Inputs.json',details);put(B/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()},'new_science':0})
    print(json.dumps({'actual_selected_engineering_inputs':'PASS','world':entry['world'],'selected_state_equals_replay_point':point==replay_point,'known_lineage_absent':len(missing),'science':0}))
if __name__=='__main__':main()
