"""Post-terminal complete/partial native baseline assembly, not a superiority test.

Prepared during remaining-case execution. Refuses live/unaudited inputs and never
calls a model, nonlinear PF, derivative, factorization, optimizer or training.
"""
import hashlib,json
from pathlib import Path
from datetime import datetime,timezone
from coordinate_native_inverter_linear_reference_20261020 import process
R=Path(__file__).resolve().parents[1];O=R/'outputs/public13_native_cohort_assembly_20261021'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False)
def main():
    handoff=R/'outputs/public13_missing_only_handoff_20261021';assert (handoff/'Completion.json').exists(),'Sole primary/reader coordinator has not closed'
    for rel,source in [('outputs/public13_missing_only_execution_20261021','run_public13_missing_only_continuation_20261021.py'),('outputs/public13_missing_only_independent_20261021','audit_public13_missing_only_continuation_20261021.py'),('outputs/public13_missing_only_handoff_20261021','coordinate_public13_missing_only_20261021.py')]:
        claim=read(R/rel/'owner.claim');live=process(claim['actual_pid']);assert not live or source not in (live.get('CommandLine') or ''),'Do not inspect before actual owners end'
    for rel in ['outputs/public13_missing_only_coordination_20261021','outputs/public13_missing_only_reader_coordination_20261021']:
        end=read(R/rel/'End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
    prefix=read(R/'outputs/public13_first_partial_validation_v2_20261021/Independent_Audit.json');new=read(R/'outputs/public13_missing_only_independent_20261021/Independent_Audit.json');seed0=read(R/'outputs/stable_ddpg_native_episode_20261020/Result.json');seed0audit=read(R/'outputs/stable_ddpg_native_episode_20261020/independent_audit/Independent_Audit.json')
    assert prefix['status']=='PASS_FIRST_INDEPENDENT_PRESERVED_PARTIAL_PREFIX_NATIVE_SOURCE_PROJECTION_POLICY_PHYSICS_AND_COST_VALIDATION' and new['status']=='PASS_INDEPENDENT_MISSING_ONLY_SOURCE_STATE_CONTINUOUS_POLICY_PHYSICS_AND_COST_AUDIT'
    assert seed0audit['status']=='PASS_ALL3_NATIVE100HORIZON_SUFFIXES_EVERY_RAW_POLICY_ACTION_CONTINUOUS_PHYSICS_CHECKPOINT_COST_AND_FULL_FIELDS'
    assert prefix['full_fields_max_delta']<=1e-10 and new['full_fields_max_delta']<=1e-10 and seed0audit['all_numeric_replay_field_delta']<=1e-10
    rows={};methods=['safe-ddpg','linear','ddpg']
    for endpoint in seed0['endpoints']:
        a=endpoint['algorithm'];vm=endpoint['all_bus_vm_pu'];rows[(0,a)]={'case':0,'method':a,'status':'COMPLETE_NATIVE_EPISODE','all13_vm':vm,'actions':endpoint['completed_original_steps'],'native3done':endpoint['native_controlled_done'],'source':'original_case0_verified_paid_suffix'}
    for stage,data in [('verified_failed_prefix',prefix),('verified_missing_only_continuation',new)]:
        for case in data['cases']:
            key=(case['seed'],case.get('algorithm'))
            if key[1] is None:continue
            if key in rows:
                # The one UNKNOWN zero-step placeholder for162linear may be
                # replaced only by the separately declared genuinely new row.
                assert key==(162,'linear') and rows[key]['status']!='COMPLETE_NATIVE_EPISODE' and not rows[key].get('all13_vm')
            endpoint=case.get('endpoint')
            rows[key]={'case':key[0],'method':key[1],'status':case['status'],'all13_vm':endpoint['all13_vm_after'] if endpoint else None,'actions':case['completed_steps'],'native3done':endpoint['native_done'] if endpoint else None,'source':stage}
    complete=all((s,a) in rows and rows[(s,a)]['status']=='COMPLETE_NATIVE_EPISODE' for s in range(500) for a in methods)
    matrix=[];summaries={}
    for s in range(500):
        for a in methods:
            row=rows.get((s,a),{'case':s,'method':a,'status':'UNENTERED_UNKNOWN','all13_vm':None,'actions':None,'native3done':None,'source':None})
            if row['status']=='COMPLETE_NATIVE_EPISODE':
                v=row['all13_vm'];assert len(v)==13
                row.update(UV=sum(x<.95 for x in v),OV=sum(x>1.05 for x in v),full13band=all(.95<=x<=1.05 for x in v),vmin=min(v),vmax=max(v))
            else:row.update(UV=None,OV=None,full13band=None,vmin=None,vmax=None)
            matrix.append(row)
    for a in methods:
        group=[v for v in matrix if v['method']==a];known=[v for v in group if v['status']=='COMPLETE_NATIVE_EPISODE'];unknown=500-len(known)
        summaries[a]={'registered_denominator':500,'complete':len(known),'unknown':unknown,'full13_band_restored_on_complete':sum(v['full13band'] for v in known),'sum_UV_on_complete':sum(v['UV'] for v in known),'sum_OV_on_complete':sum(v['OV'] for v in known),'source3done_on_complete':sum(v['native3done'] for v in known),'actions_on_complete':sum(v['actions'] for v in known),'full500_band_restoration_fraction':sum(v['full13band'] for v in known)/500 if unknown==0 else None,'missing_evidence_success_fraction_bounds_NOT_CI':[sum(v['full13band'] for v in known)/500,(sum(v['full13band'] for v in known)+unknown)/500]}
    O.mkdir(exist_ok=False)
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_SOURCE_NATIVE_ALL500_THREE_METHOD_INPUT_CASE_COHORT' if complete else 'TERMINAL_PARTIAL_SOURCE_NATIVE_CASE_COHORT_NO_FULL500_SCORE','registered_physical_cases':500,'registered_method_case_pairs':1500,'methods':summaries,'rows':matrix,'primary_metric':'All13bus voltage band0.95..1.05; source3controlledbus strict done separately. No added guard or altered policy in native row.','no_HierGrid_or_numerical_score_in_this_stage':True,'scope':'External baseline only; whole original-paper/new-controller comparison and LLM contribution still pending. Native local-state policies and global-information controllers are distinct information classes. Full-source native versus common-safety wrappers must be labeled separately.','original_primary_final_bytes':'UNRECOVERED; prefix behavior independently exact, continuation carry independently reconstructed and explicitly labeled. Original final preservation certificate never invented.','case_boundary':'Case0 is reused from an earlier separately loaded verified native episode. Cases1..162prefix begin another source-checkpoint load; the remaining stage carries the independently replayed state. This is not a claim of a single uninterrupted original author500caseprocess/RNG/parameter lifecycle.','statistical_limits':'Public source-generated cases are development/replication evidence, not unused confirmation or a universal all-grids superiority proof. Partial availability bounds are missing-evidence bounds, not statistical confidence intervals.','cost_ledger_paths':['outputs/stable_ddpg_native_episode_20261020/Result.json','outputs/stable_ddpg_native_episode_20261020/independent_audit/Independent_Audit.json','outputs/public13_remaining_published_cohort_20261021/Failure.json','outputs/public13_first_partial_validation_v2_20261021/Independent_Audit.json','outputs/public13_missing_only_execution_20261021/Result.json','outputs/public13_missing_only_independent_20261021/Independent_Audit.json'],'costs':'Keep separate actual setup/preparation/original failed science/repair/first independent replay/new science/new independent replay ledgers; do not sum overlapping retained-prior dictionaries or call reuse free. No deployment-efficiency claim.','new_analysis_model_PF_optimizer_calls':0,'all6finalgoals':'OPEN'}
    put(O/'Native_Cohort_Results.json',result);put(O/'Source_Receipts.json',{'input_sha256':{str(p.relative_to(R)).replace('\\','/'):sha(p) for p in [R/'outputs/public13_first_partial_validation_v2_20261021/Independent_Audit.json',R/'outputs/public13_missing_only_independent_20261021/Independent_Audit.json',R/'outputs/stable_ddpg_native_episode_20261020/Result.json',Path(__file__)]}})
    print(json.dumps({'status':result['status'],'methods':summaries}))
if __name__=='__main__':main()
