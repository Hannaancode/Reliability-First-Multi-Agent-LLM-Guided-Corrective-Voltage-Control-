"""Read existing device metadata and pinned source only; no simulator/model execution."""
from pathlib import Path
import ast, datetime, hashlib, json, os, pickle, time

R=Path(__file__).resolve().parents[1];O=R/'outputs/external118_device_contract_clarification_v3_20261028'
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def put(name,obj):
    with (O/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())

def main():
    O.mkdir(exist_ok=False);start=time.monotonic()
    bindings_path='outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json'
    old_path='outputs/published_voltage_common118_design_20261022/Source_Contract_And_Execution_Decision.json'
    author='outputs/published_voltage_source_intake_20261022/RWTH-IAEW__voltage-control-env/source/src/voltage_control_env/env_utils.py'
    put('Protocol.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixed_seconds':120,
      'purpose':'Resolve internal contradiction between eight sgen rows and claim of no staticPV devices; inspect all4 existing roots and exact author selector/capacity constructor without running it.',
      'bindings_sha256':sha(bindings_path),'old_note_sha256':sha(old_path),'author_source_sha256':sha(author),
      'new_PF_model_training_allocation_calls_allowed':0,
      'fields':['index','name','bus','p_mw','q_mvar','sn_mva','type','in_service','controllable','min_p_mw','max_p_mw','min_q_mvar','max_q_mvar'],
      'no_device_creation_or_capability_imputation':True})
    put('owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    import pandapower as pp
    def forbidden(*args,**kwargs):raise AssertionError('No PF or optimisation permitted in metadata inspection')
    for name in ('runpp','rundcpp','runopp','rundcopp','runpp_3ph'):
        if hasattr(pp,name):setattr(pp,name,forbidden)
    rows=[]
    bindings=json.loads((R/bindings_path).read_text('utf-8-sig'));assert len(bindings)==4
    for binding in bindings:
        assert time.monotonic()-start<120
        relative=binding['solved_payload'];assert sha(relative)==binding['payload_sha256']
        with (R/relative).open('rb') as f:payload=pickle.load(f)
        assert set(payload)=={'net','python_rng','numpy_rng'}
        net=payload['net']
        frame=net['sgen'];cols=[c for c in ['name','bus','p_mw','q_mvar','sn_mva','type','in_service','controllable','min_p_mw','max_p_mw','min_q_mvar','max_q_mvar'] if c in frame.columns]
        records=json.loads(frame[cols].reset_index().to_json(orient='records'))
        rows.append({'case_id':binding['case_id'],'source':relative,'source_sha256':binding['payload_sha256'],
          'sgen_count':len(frame),'columns_present':list(frame.columns),'records':records,
          'type_labels':frame['type'].fillna('<missing>').astype(str).value_counts().to_dict() if 'type' in frame else {},
          'literal_PV_type_count':int((frame['type'].astype(str)=='PV').sum()) if 'type' in frame else None,
          'missing_native_capability_fields':[k for k in ['min_p_mw','max_p_mw','min_q_mvar','max_q_mvar'] if k not in frame],
          'source_bytes_unchanged':sha(relative)==binding['payload_sha256']})
    text=(R/author).read_text('utf-8-sig');tree=ast.parse(text)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScenarioManager')
    evidence=[]
    for name in ('__init__','_init_pv_converter'):
        n=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
        segment=ast.get_source_segment(text,n);evidence.append({'function':'ScenarioManager.'+name,'line':n.lineno,'end_line':n.end_lineno,'sha256':hashlib.sha256(segment.encode()).hexdigest()})
    # Read-only interpretation: author default takes all sgen indices; constructor derives capacity from dataset maximum P.
    assert 'self.ctrl_sgen_indices = list(range(len(net.sgen)))' in text
    assert "self.dataset.get_item(idx)['sgen']['max_p_mw']" in text
    assert "self.net.sgen['sn_mva'] = s_max" in text
    result={'status':'ALL4_DEVICE_METADATA_AND_AUTHOR_CONTRACT_READ_COMPLETE','roots':rows,'author':{'path':author,'sha256':sha(author),'functions':evidence},
      'correction':'The earlier note labels eight rows staticPV while also claiming no staticPV devices. The actual sgen rows and exact type labels below resolve what is present. A PV name/type label alone is not a certified controllable inverter capability.',
      'author_default':'ScenarioManager uses all sgen indices when no truthy explicit list is supplied; it does not select only literal type==PV rows here.',
      'capacity_contract':'The author constructor sets sn_mva using maximum dataset active-power profiles times its oversizing factor. A federation snapshot alone does not supply the original profile/capability contract.',
      'remaining_admission':'Original positive shunt increments versus continuous inverter P/Q, source-equivalent time profiles, credible capability bounds, actual compatible checkpoint/training, same information/protection/costs and complete episode preservation remain unresolved. No published method is counted beaten or physically inadmissible solely from this corrected note.',
      'prior_note_preserved':old_path,'new_PF_model_optimizer_training_GPU_calls':0,'author_code_imported_or_executed':False,
      'workflow_seconds':time.monotonic()-start}
    put('Device_And_Contract_Clarification.json',result)
    put('Closed_Manifest.json',{'members':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'status':result['status'],'roots':[{'case_id':x['case_id'],'sgen_count':x['sgen_count'],'type_labels':x['type_labels'],'missing_capability_fields':x['missing_native_capability_fields']} for x in rows],'new_science':0}))

if __name__=='__main__':main()
