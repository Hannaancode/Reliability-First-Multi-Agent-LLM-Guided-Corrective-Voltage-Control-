"""Freeze ALL3 remaining pre-existing policy queries, then zero-PF preflight.

No experiment is started from a component absence alone. Actual source claims,
two real cold state handoffs, original verifier inputs and independent reader
claim are checked before the first scientific kernel can be launched.
"""
import copy,importlib.metadata,json,time,traceback
from datetime import datetime,timezone,timedelta
from pathlib import Path
import pandapower as pp
from public118_slsqp_native_20261018 import R,read,put,sha
from third_point_remaining_three_core_20261019 import B,I,PHASES,helpers,certificate
from certify_third_point_remaining_three_20261019 import certify,INPUT
from audit_third_point_remaining_three_20261019 import certificate as reader_certificate
from prepare_exact_two_paid_query_engineering_20261018 import local_closure
from frozen_physics_loader import load_stack,AUDIT
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from strict_saved_native_input_match_v2_20261018 import require_same
from candidate_process_evidence_utils import frozen_checks

def main():
    B.mkdir(exist_ok=False);begun=time.perf_counter()
    try:
        core=certificate();reader_proof=reader_certificate();coverage=certify();rows=[{k:v[k] for k in ('row','point_action_key','role')} for v in coverage['exact_rows']]
        _,runner,_=load_stack();state=helpers(__file__)['input_state']();verify,actuate,native=build_verifier(runner.rescue,state['cursor'])
        calls=[];previous=pp.runpp
        def labelled_stub(net,**kwargs):
            assert len(calls)<3;require_same(net,actuate(copy.deepcopy(state['net']),action(rows[len(calls)]['row'])))
            calls.append(kwargs);raise RuntimeError('LABELLED_SOFTWARE_ONLY_NO_NATIVE_KERNEL')
        pp.runpp=labelled_stub
        try:
            initial=copy.deepcopy(state['net'])
            for item in rows:
                v=verify(state['net'],action(item['row']));assert v['reason']=='pf_failed' and v['after'] is None;require_same(state['net'],initial)
        finally:pp.runpp=previous
        solver={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True};assert calls==[solver]*3
        source=R/'work/run_third_point_remaining_three_20261019.py';reader=R/'work/audit_third_point_remaining_three_20261019.py';scope=R/'work/certify_third_point_remaining_three_20261019.py'
        put(B/'Source_Transformation_Proof.json',{'worker_reservations':core,'independent_reader':reader_proof,'new_scientific_calls':0})
        put(B/'Independent_Coverage_Reader_Lock.json',{'reader_source':str(scope.relative_to(R)),'reader_sha256':sha(scope)})
        files=local_closure([source,reader,scope,Path(__file__)])
        files += [Path(x['file']) for x in AUDIT]
        files += [R/v for v in coverage['evidence_sha256']]
        files += [INPUT,I/'Exact_Current_Input.zlib',B/'Source_Transformation_Proof.json',B/'Attempt_Coverage_Certificate.json',B/'Independent_Coverage_Reader_Lock.json']
        files=sorted(set(files));old=read(INPUT)
        protocol={'status':'FROZEN_ALL3_REMAINING_ORIGINAL_K4_QUERY_ACQUISITION','created_utc':datetime.now(timezone.utc).isoformat(),
            'absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=1800)).isoformat(),'fixed_whole_preflight_science_reader_bound_seconds':1800,
            'phases':list(PHASES),'exact_query_count':3,'maximum_PF_attempts':6,'maximum_storage_bytes':256*1024**2,'seed':20261018,
            'solver_kwargs':solver,'field_tolerance':1e-10,'point':old['point'],'parent_handle':old['parent'],'exact_new_query_rows':rows,
            'input_preparation_sha256':sha(INPUT),'input_state_sha256':sha(I/'Exact_Current_Input.zlib'),
            'attempt_coverage_certificate':{'path':str((B/'Attempt_Coverage_Certificate.json').relative_to(R)),'sha256':sha(B/'Attempt_Coverage_Certificate.json')},
            'independent_coverage_reader_lock':{'path':str((B/'Independent_Coverage_Reader_Lock.json').relative_to(R)),'sha256':sha(B/'Independent_Coverage_Reader_Lock.json')},
            'source_input_sha256':{str(v.relative_to(R)):sha(v) for v in files},'runtime_versions':{n:importlib.metadata.version(n) for n in ('numpy','scipy','pandas','pandapower')},
            'independent_reader_source':str(reader.relative_to(R)),'independent_reader_sha256':sha(reader),
            'selection':'ALL3remaining originalK4 ranks2,3,4 from pre-outcome menu; same source current18UV, no new Q/width/threshold/budget tuning. Prior rank1 was already measured18to15 and remains paid. The stopped cold owner never passedACK or entered a scientific body; these3 exact identities were never reserved or attempted. No old owner is restarted. Acquire each primary once, each converged return one explicitly charged replay.',
            'stop':'No retry, old-owner restart, old-budget extension, automatic replacement identity or actual commit. Stop at new absolute bound; partial/unexecuted identities stayUNKNOWN. No physics at the already-zero state.',
            'fixed_gate':'Complete acquisition/evidence requires ALL3actual primaries and3chargedreplays, all6returns,0exceptions, exact complete coldNET/cursor/registry/history/RNG/cost/source/deadline restores, unchanged saved-native verifier and all118replay fields<=1e-10, source/input/hash/cost/frozen independent audit. Query rejection is a valid measured outcome, not an engineering gate failure.',
            'scope_limits':'Observed hypothetical paid AFTER at17UV, not actual committed deployment restart, fresh LLM or whole-policy performance. No all4world/DSE/zero-all/unused-confirmation/LLM advantage from this acquisition. All old costs/sources/failures and frozen original assets remain preserved.',
            'original_resources':'Original remaining15of25deviceops, cap450 no refund, owned stock, rawcommonANDzone, original9Q, verifier/score, normalupper1.05+1e-8 unchanged; query-only, no operations are falsely counted as committed.'}
        put(B/'Protocol.json',protocol);put(B/'Independent_Reader_Lock.json',{'reader_sha256':sha(reader),'source':str(reader.relative_to(R)),'protocol_sha256':sha(B/'Protocol.json'),'no_new_science':True})
        h=helpers(__file__);fixtures={}
        for phase in PHASES:
            mode='fixture_'+phase;fixtures[mode]=h['launch'](source,mode,B/mode,protocol);assert fixtures[mode]==0
            assert read(B/mode/'Result.json')['scientific_calls']==0
        fixtures['reader_identity']=h['launch'](reader,'identity-fixture',B/'fixture_reader',protocol);assert fixtures['reader_identity']==0
        assert read(B/'fixture_reader/Result.json')['new_scientific_calls']==0
        put(B/'Frozen_Prelaunch.json',frozen_checks())
        put(B/'Readiness.json',{'status':'PASS_FIXED_THREE_QUERY_PRELAUNCH_ZERO_SCIENCE','fixture_exit_codes':fixtures,'exact_native_stub_inputs':3,
            'actual_claimed_cold_process_handoffs':2,'actual_reader_claim_checked':True,'source_transformation_proof':sha(B/'Source_Transformation_Proof.json'),
            'pinned_source_input_files':len(files),'all9frozen_checks_pass':True,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-begun})
        print(json.dumps({'three_query_prelaunch':'PASS','scientific_calls':0,'actual_cold_handoffs':2,'reader_claim':'PASS'}))
    except BaseException:
        put(B/'Preparation_Failure.json',{'traceback':traceback.format_exc(),'new_science_launched':False,'old_sources_not_edited':True});raise
if __name__=='__main__':main()
