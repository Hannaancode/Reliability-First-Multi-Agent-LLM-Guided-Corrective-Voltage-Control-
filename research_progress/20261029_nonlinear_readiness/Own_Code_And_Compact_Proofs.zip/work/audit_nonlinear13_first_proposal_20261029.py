"""First independent saved numerical-output reader; no optimizer/PF/model."""
from pathlib import Path
from datetime import datetime,timezone
import os,json,time,hashlib,base64,pickle
from collections import Counter
import numpy as np
R=Path(__file__).resolve().parents[1];P=R/'outputs/nonlinear13_first_proposal_preparation_20261029';S=R/'outputs/nonlinear13_first_proposal_execution_20261029';O=R/'outputs/nonlinear13_first_proposal_independent_20261029'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    start=time.monotonic();O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    while not (O/'Launcher_ACK.json').exists():
        if time.monotonic()-start>60:raise TimeoutError('No reader owner ACK')
        time.sleep(.1)
    ack=json.loads((O/'Launcher_ACK.json').read_text(encoding='utf-8'))
    assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    assert Path(__file__).name in ack['actual_command']
    p=json.loads((P/'Protocol.json').read_text(encoding='utf-8'))
    for rel,h in p['sources_and_gates'].items():assert sha(R/rel)==h,rel
    ended=json.loads((R/'outputs/nonlinear13_first_proposal_coordination_20261029/End_ACK.json').read_text());assert ended['actual_owned_chain_ended'] and ended['exit_code']==0
    for v in json.loads((S/'Closed_Manifest.json').read_text())['files']:assert sha(S/v['path'])==v['sha256']
    primary=json.loads((S/'Result.json').read_text());packref=p['input_pack'];assert sha(R/packref['path'])==packref['sha256']
    pack=np.load(R/packref['path'],allow_pickle=False);Y=pack['Y'];V0=pack['V_current'];pq=np.flatnonzero(pack['ppc_bus'][:,1]==1)
    lookup=pack['lookup'];control=pack['control'];q=pack['current_q'];vm0=pack['current_vm'];normal=(vm0>=.95)&(vm0<=1.05);base=float(pack['baseMVA'])
    b=pack['ppc_bus'];g=pack['ppc_gen'];injection=-(b[:,2]+1j*b[:,3])
    for row in g:
        if row[7]>0:injection[int(row[0])]+=row[1]+1j*row[2]
    injection/=base;cost={'independent_saved_algebra_evaluations':0,'independent_saved_jacobian_reconstructions':0}
    def calc(name,x,stage,t1):
        cost['independent_saved_algebra_evaluations']+=1
        V=V0.copy();V[pq]=x[12:24]*np.exp(1j*x[:12]);vm=np.abs(V)[lookup]
        if name in ['objective','objective_gradient']:
            if name=='objective':return x[30] if stage==1 else np.sum(x[27:30])
            out=np.zeros(31);out[30]=1 if stage==1 else 0
            if stage==2:out[27:30]=1
            return out
        if 'inequalit' in name:
            if name=='inequality_jacobian':
                cost['independent_saved_jacobian_reconstructions']+=1;D=np.zeros((13,31))
                for native,internal in enumerate(lookup):
                    w=np.flatnonzero(pq==internal)
                    if len(w):D[native,12+int(w[0])]=1
                a=-D.copy();a[:,30]=1;c=D.copy();c[:,30]=1
                e=np.zeros((3,31));e[:,24:27]=-np.eye(3);e[:,27:30]=np.eye(3);f=e.copy();f[:,24:27]=np.eye(3)
                out=np.vstack([a,c,-D[normal],D[normal],e,f])
                if t1 is not None:z=np.zeros((1,31));z[0,30]=-1;out=np.vstack([out,z])
                return out
            out=np.r_[1.05+x[30]-vm,vm-.95+x[30],1.05-vm[normal],vm[normal]-.95,x[27:30]-q-x[24:27],x[27:30]+q+x[24:27]]
            return np.r_[out,t1+1e-10-x[30]] if t1 is not None else out
        if name=='equality_jacobian':
            cost['independent_saved_jacobian_reconstructions']+=1;I=Y@V;diagV=np.diag(V);unit=V.copy();unit[pq]=np.exp(1j*x[:12]);ref=np.setdiff1d(np.arange(13),pq);unit[ref]=V[ref]/np.abs(V[ref])
            da=1j*diagV@np.conj(np.diag(I)-Y@diagV)
            dm=diagV@np.conj(Y@np.diag(unit))+np.diag(np.conj(I))@np.diag(unit)
            out=np.zeros((24,31));out[:12,:12]=da[np.ix_(pq,pq)].real;out[12:,:12]=da[np.ix_(pq,pq)].imag
            out[:12,12:24]=dm[np.ix_(pq,pq)].real;out[12:,12:24]=dm[np.ix_(pq,pq)].imag
            for j,k in enumerate(control):out[12+int(np.flatnonzero(pq==k)[0]),24+j]=-1/base
            return out
        target=injection.copy();target[control]+=1j*x[24:27]/base;err=V*np.conj(Y@V)-target
        return np.r_[err[pq].real,err[pq].imag]
    attempts={};returns=0;previous='0'*64;stage_t={};worst=0.;events=[];raw_solver=[]
    for line in (S/'calculations.jsonl').read_text(encoding='utf-8').splitlines():
        if time.monotonic()-start>p['reader_seconds']-5:raise TimeoutError('Original reader bound')
        row=json.loads(line);e=row['event'];assert e['previous']==previous and e['seq']==len(events)
        assert hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==row['sha256'];previous=row['sha256'];events.append(e)
        if e['kind']=='optimizer_attempt':stage_t[e['stage']]=e['first_stage_t']
        if e['kind']=='calculation_attempt':assert e['identity'] not in attempts;attempts[e['identity']]=e
        if e['kind']=='calculation_return':
            a=attempts[e['identity']];actual=np.asarray(e['result']);expected=np.asarray(calc(a['name'],np.asarray(a['x']),a['stage'],stage_t[a['stage']]))
            assert actual.shape==expected.shape and np.allclose(actual,expected,rtol=0,atol=1e-9),(a['name'],float(np.max(np.abs(actual-expected))))
            worst=max(worst,float(np.max(np.abs(actual-expected),initial=0.)));returns+=1
        if e['kind']=='optimizer_lossless_raw_return':
            decoded={}
            for key in ['x_bytes','multipliers_bytes']:
                info=e[key];raw=base64.b64decode(info['bytes_base64']);a=np.frombuffer(raw,dtype=np.dtype(info['dtype'])).reshape(info['shape']);assert a.tobytes()==raw;decoded[key]=a
            raw_solver.append(dict(event=e,decoded=decoded))
    assert previous==primary['journal_last_sha256'] and len(events)==primary['journal_events'] and (S/'calculations.jsonl').stat().st_size==primary['journal_bytes']
    kinds=Counter(e['kind'] for e in events)
    ended_calculations={e['identity'] for e in events if e['kind'] in ['calculation_return','calculation_failure']}
    pending=sorted(set(attempts)-ended_calculations)
    event_to_cost={'objective':'objective_evaluations','objective_gradient':'analytic_objective_gradient_evaluations',
      'equality':'nonlinear_equation_evaluations','returned_equality':'nonlinear_equation_evaluations',
      'inequalities':'constraint_evaluations','returned_inequalities':'constraint_evaluations',
      'equality_jacobian':'analytic_equation_jacobian_evaluations','inequality_jacobian':'analytic_constraint_jacobian_evaluations'}
    upper=Counter();lower=Counter()
    for identity,a in attempts.items():
        key=event_to_cost[a['name']];upper[key]+=1
        if identity in ended_calculations:lower[key]+=1
    upper['native_action_conversions']=kinds['representable_action_attempt']
    lower['native_action_conversions']=kinds['representable_action_return']+kinds['representable_action_failure']
    for key in set(upper)|set(primary['kernel_costs']):
        assert lower[key]<=primary['kernel_costs'].get(key,0)<=upper[key],(key,lower[key],primary['kernel_costs'].get(key),upper[key])
    cost_accounting=dict(event_counts=dict(kinds),kernel_actual=primary['kernel_costs'],kernel_confirmed_lower=dict(lower),kernel_entered_upper=dict(upper),
      unpaired_calculation_attempts=pending,unpaired_native_attempt_count=kinds['native_solver_call_attempt']-kinds['native_solver_call_end'],
      unpaired_optimizer_attempt_count=kinds['optimizer_attempt']-kinds['optimizer_lossless_raw_return']-kinds['optimizer_exception'],
      unpaired_status='UNKNOWN_NOT_FREE_NOT_RETRIED',native_internal_factor_solve_counts='UNKNOWN_INSIDE_PINNED_LIBRARY',workflow_seconds=primary['workflow_seconds'])
    proposal=json.loads((S/'Proposal_Result.json').read_text()) if (S/'Proposal_Result.json').exists() else None
    if proposal:
        assert proposal['costs']['optimizer_attempts']==sum(e['kind']=='optimizer_attempt' for e in events)
        assert proposal['costs']['optimizer_returns']==len(raw_solver)
        assert proposal['costs']['native_slsqp_calls']==sum(e['kind']=='native_solver_call_attempt' for e in events)
        if proposal['status']=='ADMITTED_UNMEASURED_PROPOSAL':
            assert len(raw_solver)==2 and all(e['event']['success'] for e in raw_solver)
            assert [r['stage'] for r in proposal['stages']]==[1,2] and stage_t[1] is None
            def independently_feasible(x,t1):
                assert x.shape==(31,) and np.isfinite(x).all()
                assert np.all(x[12:24]>=0) and np.all(np.abs(x[24:27])<=float(np.float32(.3))) and np.all(x[27:]>=0)
                eq=calc('returned_equality',x,1 if t1 is None else 2,t1)
                iq=calc('returned_inequalities',x,1 if t1 is None else 2,t1)
                assert np.max(np.abs(eq))<=p['recipe']['absolute_equality_acceptance'] and np.min(iq)>=-p['recipe']['absolute_inequality_acceptance']
            first_t=float(raw_solver[0]['decoded']['x_bytes'][30])
            assert stage_t[2]==first_t and not pending
            assert cost_accounting['unpaired_native_attempt_count']==cost_accounting['unpaired_optimizer_attempt_count']==0
            for r in proposal['stages']:
                raw=raw_solver[r['stage']-1]['decoded']['x_bytes'];assert np.array_equal(raw,r['x']) and r['checks']['pass']
                assert r['status']==raw_solver[r['stage']-1]['event']['status']==0
                independently_feasible(raw,None if r['stage']==1 else first_t)
                native_ends=[e for e in events if e['kind']=='native_solver_call_end' and e['stage']==r['stage']]
                assert native_ends and native_ends[-1]['state']['mode']==0 and native_ends[-1]['state']['iter']==r['nit']
            u=np.asarray(proposal['u'],dtype=np.float32);x=np.asarray(proposal['applied_x']);assert np.isfinite(u).all() and np.all(np.abs(u)<=np.float32(.3))
            assert np.array_equal(q-u,proposal['next_q']) and np.array_equal(x[24:27],q-u-q)
            raw2=raw_solver[1]['decoded']['x_bytes'];assert np.array_equal(u,(-raw2[24:27]).astype(np.float32))
            assert np.array_equal(x[:24],raw2[:24]) and x[30]==raw2[30] and np.array_equal(x[27:30],np.abs(q-u))
            independently_feasible(x,first_t)
            v=V0.copy();v[pq]=x[12:24]*np.exp(1j*x[:12]);assert np.allclose(np.abs(v)[lookup],proposal['proposed_vm'],rtol=0,atol=1e-12)
    cursor=pickle.loads((S/'Complete_Pre_Proposal_Cursor.pkl').read_bytes());assert cursor['seed']==0 and cursor['step']==1 and cursor['remaining_horizon']==100 and cursor['history']==[]
    assert cursor['current_input']['pack']==p['input_pack'] and cursor['current_input']['root']==p['input_root']
    assert cursor['protocol_sha256']==sha(P/'Protocol.json')
    out=dict(status='PASS_FIRST_SAVED_NUMERICAL_PROPOSAL_AND_COST_EVIDENCE',at_utc=datetime.now(timezone.utc).isoformat(),primary_status=primary['status'],
      proposal_status=None if proposal is None else proposal['status'],new_PF_optimizer_model_calls=0,actual_control_commits=0,
      calculation_returns_verified=returns,optimizer_returns_preserved=len(raw_solver),max_algebra_difference=worst,independent_costs=cost,
      primary_cost_accounting=cost_accounting,
      workflow_seconds=time.monotonic()-start,scope='Saved numerical proposal only. Actual physical response, receding controller and all500 performance UNKNOWN.')
    put(O/'Independent_Audit.json',out);put(O/'Closed_Manifest.json',dict(files=[dict(path=f.name,bytes=f.stat().st_size,sha256=sha(f)) for f in O.iterdir() if f.is_file()]))
    print(json.dumps(out))
if __name__=='__main__':main()
