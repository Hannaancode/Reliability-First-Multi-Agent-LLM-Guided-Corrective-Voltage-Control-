"""Prospective one-context continuation; unchanged worker/equation reader.

The context is the first missing dependency of the closed, unchanged policy.
No nonlinear PF, model, optimizer, or commit is authorized by this program.
"""
import argparse,ast,hashlib,importlib.metadata,json,os,pickle,time,zlib
from datetime import datetime,timezone,timedelta
from pathlib import Path
import first_missing_paid_numeric_context_20261018 as original
from second_required_numeric_context_20261019 import claim_writer as prior_writer
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from fixed_three_query_core_20261019 import helpers
from prepare_exact_two_paid_query_engineering_20261018 import local_closure
from prospective_query_custody_v3_20261019 import bind,atomic_new
B=R/'outputs/fourth_required_numeric_context_v2_20261019'
SCREEN=R/'outputs/resumed16_with_fixed_followup_receipts_v2_20261019'
PREVIOUS=['first_missing_paid_numeric_context_20261018','next_required_numeric_context_20261019','second_required_numeric_context_20261019','third_required_numeric_context_20261019']

def read_exact_launcher_ack(path,maximum_seconds=60):
    begun=time.perf_counter();errors={}
    while True:
        try:return read(path),errors
        except (PermissionError,json.JSONDecodeError,UnicodeDecodeError) as error:
            errors[type(error).__name__]=errors.get(type(error).__name__,0)+1
            if time.perf_counter()-begun>=maximum_seconds:raise
            time.sleep(.025)

def claim_writer(entrypoint):
    def write(path,value):
        if Path(path).name=='owner.claim':
            value={**value,'actual_parent_pid':os.getppid(),'source_sha256':sha(entrypoint),'protocol_sha256':sha(B/'Protocol.json')}
        (atomic_new if Path(path).name=='owner.claim' else put)(path,value)
        if Path(path).name=='owner.claim':
            begun=time.perf_counter()
            while not (Path(path).parent/'Launcher_ACK.json').exists():assert time.perf_counter()-begun<60;time.sleep(.1)
            ack,errors=read_exact_launcher_ack(Path(path).parent/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_PID_parent_command']
            if errors:put(Path(path).parent/'ACK_Transient_Read_Recovery.json',{'errors':errors,'same_exact_ACK_PID_source':True,'no_new_scientific_calls':0,'no_acl_or_permission_change':True})
    return write

def prepare():
    from dynamic_actual_mask_guidance_v1 import current_inputs,identity
    B.mkdir(exist_ok=False);started=time.perf_counter()
    assert read(R/'outputs/prospective_query_custody_v3_20261019/Results.json')['status']=='PASS_FOUR_REAL_ZERO_SCIENCE_CUSTODY_CASES'
    leg=read(SCREEN/'Leg_1.json');assert leg['status']=='UNKNOWN_MissingPaidNumericalContext'
    ref=leg['frontier_input'];encoded=(SCREEN/ref['path']).read_bytes();assert hashlib.sha256(encoded).hexdigest()==ref['encoded_sha256']
    raw=zlib.decompress(encoded);assert hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];state=pickle.loads(raw)
    ident=identity(current_inputs(state['net']));assert ident==leg['missing_identity']=='bfeba1e3ad7a5e4b1df6dab46d4bc45c86d8c8526920f50f370f32c64b326802'
    assert read(SCREEN/'Results.json')['new_model_PF_optimizer_derivative_forecast_solve_calls']==0
    for rel,h in read(SCREEN/'Closed_Manifest.json')['members'].items():assert sha(SCREEN/rel)==h
    refs=read(R/'outputs/full_paid_numeric_reuse_separate_roles_v2_20261018/All_Existing_Contexts.json');excluded={v['identity'] for v in refs}
    paths=[]
    for name in PREVIOUS:
        root=R/'outputs'/name;proof=read(root/'independent_audit/Independent_Audit.json');assert proof['status'].startswith('PASS_SINGLE_EXACT_');excluded.add(proof['identity'])
        paths += [root/'actual/Journal.jsonl',root/'actual/Closed_Manifest.json',root/'independent_audit/Independent_Audit.json']
    assert ident not in excluded
    catalog=read(R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json')
    original_paths=[R/v['path'] for v in catalog if any('derivative_attempt' in k for k in v['events'])];assert len(original_paths)==3
    coverage=[]
    for path in original_paths+[R/'outputs'/n/'actual/Journal.jsonl' for n in PREVIOUS]:
        h=hashlib.sha256();tail=b'';hits=0;needle=ident.encode()
        with path.open('rb') as f:
            while block:=f.read(1024**2):
                h.update(block);joined=tail+block;hits+=joined.count(needle);tail=joined[-(len(needle)-1):]
        assert hits==0
        coverage.append({'path':str(path.relative_to(R)),'sha256':h.hexdigest(),'identity_mentions':hits})
    put(B/'Attempt_Coverage.json',{'status':'PASS_NEW_REQUIRED_CONTEXT_IN_CLOSED_NUMERIC_DEPENDENCY_ROLE','identity':ident,'excluded_complete_contexts':sorted(excluded),'searched_attempt_journals':coverage,'limits':'Not a universal historical mathematical-operation claim. PF-internal Newton derivatives are prior paid PF work, not this public compile role.','scientific_calls':0,'workflow_seconds':time.perf_counter()-started})
    files=local_closure([Path(__file__),R/'work/audit_fourth_required_numeric_context_v2_20261019.py'])
    files += paths+[SCREEN/'Results.json',SCREEN/'Leg_1.json',SCREEN/ref['path'],SCREEN/'Closed_Manifest.json',B/'Attempt_Coverage.json',R/'outputs/prospective_query_custody_v3_20261019/Results.json']
    pins={str(v.relative_to(R)):sha(v) for v in sorted(set(files))};reader=R/'work/audit_fourth_required_numeric_context_v2_20261019.py'
    put(B/'Protocol.json',{'status':'FROZEN_BEFORE_ONE_REQUIRED_CONTEXT','identity':ident,'input_frontier':str((SCREEN/ref['path']).relative_to(R)),'raw_sha256':ref['raw_sha256'],
        'absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=900)).isoformat(),'bound_seconds':120,'reader_bound_seconds':120,
        'allowed':'ONE unchanged current-mask compile:1dSbus_dV/1LUfactor/1solve118RHS, then one forecast per ALL original native9Q ordinary+owned rows within remaining operation allowance. Zero PF/model/optimizer/controller commit.',
        'selection':'First missing dependency of closed fixed-policy all17receipt screen, not outcome-selected action or retuning. Old source owners/budgets remain ended.',
        'pins':pins,'source_input_sha256':pins,'runtime_versions':{n:importlib.metadata.version(n) for n in ('numpy','scipy','pandas','pandapower')},
        'reader_source':str(reader.relative_to(R)),'reader_sha256':sha(reader),'source_certificate':'Original worker and independent equation reader FunctionDef AST unchanged; only output namespace and atomic actual-source owner service rebound.',
        'limitations':'Ordering evidence only, not nonlinear trajectory or LLM superiority. No retry, additional context, budget extension or automatic PF/model launch.'})
    print(json.dumps({'prepared':ident,'science':0}))

def worker():
    from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
    guard=LockedSourceSnapshot(B/'Protocol.json')
    try:
        n=next(n for n in ast.parse(Path(original.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='worker')
        env=original.__dict__.copy();env.update(B=B,__file__=__file__,put=claim_writer(__file__))
        exec(compile(ast.Module(body=[n],type_ignores=[]),str(original.__file__),'exec'),env);env['worker']()
    finally:guard.close()

def fixture():
    out=B/'fixture';out.mkdir(exist_ok=False);claim_writer(__file__)(out/'owner.claim',{'actual_pid':os.getpid()});put(out/'Result.json',{'status':'PASS_ACTUAL_SOURCE_ATOMIC_CUSTODY_ZERO_SCIENCE','scientific_calls':0});manifest(out)

def environment():
    env=helpers(__file__);env['B']=B;return bind(env,__file__)

def preflight():
    p=read(B/'Protocol.json');env=environment();code=env['launch'](Path(__file__),'identity-fixture',B/'fixture',p);assert code==0
    put(B/'Readiness.json',{'status':'PASS_ACTUAL_SOURCE_ATOMIC_CUSTODY_ZERO_SCIENCE','fixture_exit':code,'scientific_calls':0})

def coordinator():
    assert read(B/'Readiness.json')['status']=='PASS_ACTUAL_SOURCE_ATOMIC_CUSTODY_ZERO_SCIENCE'
    p=read(B/'Protocol.json');env=environment();codes={}
    try:
        codes['actual']=env['launch'](Path(__file__),'worker',B/'actual',p)
        if codes['actual']==0:codes['independent_audit']=env['launch'](R/p['reader_source'],'reader',B/'independent_audit',p)
    finally:put(B/'Completion.json',{'exit_codes':codes,'no_science_retry':True,'new_PF_model_calls':0})
    print(json.dumps({'exit_codes':codes}))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for flag in ['prepare','preflight','worker','identity-fixture','coordinator']:p.add_argument('--'+flag,action='store_true')
    a=p.parse_args()
    if a.prepare:prepare()
    elif a.preflight:preflight()
    elif a.worker:worker()
    elif a.identity_fixture:fixture()
    else:coordinator()
