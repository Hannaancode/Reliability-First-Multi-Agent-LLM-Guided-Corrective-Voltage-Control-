"""Separate source-bound unentered generations after independently diagnosed zero-forward loader failure."""
import json,hashlib,ast,zipfile
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import frozen_checks
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'outputs/original_lora_native13_transfer_preparation_20261020';OUT=ROOT/'outputs/original_lora_native13_transfer_preparation_v2_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def clone(old,new,changes):
    s=(ROOT/'work'/old).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in s,(old,a);s=s.replace(a,b)
    ast.parse(s)
    with (ROOT/'work'/new).open('x',encoding='utf-8') as f:f.write(s)
def main():
    audit=json.loads((ROOT/'outputs/original_lora_native13_transfer_execution_20261020/independent_audit/Independent_Audit.json').read_text(encoding='utf-8'));assert not audit['science_complete'] and audit['actual_remote_costs']['pretrained_forward_attempts']==audit['actual_remote_costs']['generation_attempts']==0
    end=json.loads((ROOT/'outputs/original_lora_native13_transfer_coordination_20261020/End_ACK.json').read_text(encoding='utf-8'));assert end['actual_owned_chain_ended']
    state=json.loads((ROOT/'outputs/original_lora_native13_transfer_execution_20261020/status.json').read_text(encoding='utf-8'));assert state['runtime_released'] and state['all_actual_closed_artifacts_preserved'] and state['scientific_process_ended']
    causal=ROOT/'outputs/original_lora_native13_loader_order_repair_20261020/Independent_Causal_Software_Proof.json';proof=json.loads(causal.read_text(encoding='utf-8'));assert proof['status'].startswith('PASS_') and proof['fixed_false_gate_final_trainable_tensors']==0
    OUT.mkdir(exist_ok=False)
    clone('run_original_lora_native13_colab_20261020.py','run_original_lora_native13_colab_v2_20261020.py',[("original_lora_native13_transfer_preparation_20261020","original_lora_native13_transfer_preparation_v2_20261020"),("original_lora_native13_transfer_execution_20261020","original_lora_native13_transfer_execution_v2_20261020"),('native13_lora_setup_remote_20261020.py','native13_lora_setup_remote_v2_20261020.py'),('native13_lora_guardian_20261020.py','native13_lora_guardian_v2_20261020.py')])
    clone('run_native13_lora_transfer_remote_20261020.py','run_native13_lora_transfer_remote_v2_20261020.py',[('from candidate_process_pretrained_loader import','from candidate_process_pretrained_loader_native13_v2_20261020 import')])
    clone('native13_lora_environment_check_20261020.py','native13_lora_environment_check_v2_20261020.py',[("private model instantiation", "private model instantiation (v2 unentered owner)")])
    clone('native13_lora_setup_remote_20261020.py','native13_lora_setup_remote_v2_20261020.py',[('native13_lora_environment_check_20261020.py','native13_lora_environment_check_v2_20261020.py')])
    clone('native13_lora_guardian_20261020.py','native13_lora_guardian_v2_20261020.py',[('run_native13_lora_transfer_remote_20261020.py','run_native13_lora_transfer_remote_v2_20261020.py')])
    clone('audit_original_lora_native13_outputs_20261020.py','audit_original_lora_native13_outputs_v2_20261020.py',[("original_lora_native13_transfer_preparation_20261020","original_lora_native13_transfer_preparation_v2_20261020"),("original_lora_native13_transfer_execution_20261020","original_lora_native13_transfer_execution_v2_20261020")])
    p=json.loads((OLD/'Production_Protocol.json').read_text(encoding='utf-8'));p['preinference_loader_repair']={'original_complete_preserved_partial_audit':str((ROOT/'outputs/original_lora_native13_transfer_execution_20261020/independent_audit/Independent_Audit.json').relative_to(ROOT)).replace('\\','/'),'actual_cause':'PEFTrestore resets activeadapter trainability; final source-controlled set_body_trainability must follow restored gate. No oldscientificattempt exists torepeat.','proof_sha256':sha(causal),'all_input_prompt_token_decoder_privateweight_publicbase_seed_PI_schema_settings_unchanged':True,'new_output_claim_source_and_bound':'Distinct v2 unentered6generations;one original-profile assignment only, no fallback/retry. Prior load/setup/allocation costs retained separately.'}
    put(OUT/'Production_Protocol.json',p)
    for n in ['All3_Messages_And_Token_IDs.json','Input_Anchors.json']:
        with (OUT/n).open('xb') as f:f.write((OLD/n).read_bytes())
        assert sha(OUT/n)==sha(OLD/n)
    with (OUT/'Direct_Human_Authority.json').open('xb') as f:f.write((OLD/'Direct_Human_Authority.json').read_bytes())
    sources=['run_original_lora_native13_colab_v2_20261020.py','run_native13_lora_transfer_remote_v2_20261020.py','native13_lora_environment_check_v2_20261020.py','native13_lora_setup_remote_v2_20261020.py','native13_lora_guardian_v2_20261020.py','candidate_process_pretrained_loader_native13_v2_20261020.py','public_size_u61_preservation.py','public_size_local_preservation_v2.py','google_account_profile.py','audit_original_lora_native13_outputs_v2_20261020.py','prepare_original_lora_native13_transfer_gate_20261020.py','coordinate_single_source_bound_owner_20261020.py']
    for n in sources:ast.parse((ROOT/'work'/n).read_text(encoding='utf-8'))
    host=(ROOT/'work'/sources[0]).read_text(encoding='utf-8');assert host.count('client.assign(')==1 and "arm='public_0_5B'" in host
    bundle={}
    excluded={sources[0],'public_size_local_preservation_v2.py','google_account_profile.py','audit_original_lora_native13_outputs_v2_20261020.py','prepare_original_lora_native13_transfer_gate_20261020.py','coordinate_single_source_bound_owner_20261020.py'}
    for n in sources:
        if n not in excluded:bundle['work/'+n]=ROOT/'work'/n
    for n in ['frozen_gpu_requirements.txt','frozen_dependency_closure.txt','uv_bootstrap_version.txt']:bundle['work/'+n]=ROOT/'work'/n
    for n,h in p['private_adapter_tokenizer_unchanged'].items():
        f=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'/n;assert sha(f)==h;bundle['work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/'+n]=f
    bundle['prep/protocol.json']=OUT/'Production_Protocol.json';bundle['prep/All3_Messages_And_Token_IDs.json']=OUT/'All3_Messages_And_Token_IDs.json';m={n:{'bytes':f.stat().st_size,'sha256':sha(f)} for n,f in bundle.items()};archive=OUT/'Native13_Private_LoRA_Inputs_Only.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,f in bundle.items():z.write(f,n)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json',json.dumps(m,indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(m)+1
        for n,e in m.items():raw=z.read(n);assert len(raw)==e['bytes'] and hashlib.sha256(raw).hexdigest()==e['sha256']
    payload={'archive':archive.relative_to(ROOT).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(m)+1,'human_authority_source':(OUT/'Direct_Human_Authority.json').relative_to(ROOT).as_posix(),'human_authority_sha256':sha(OUT/'Direct_Human_Authority.json'),'private_adapter_tokenizer_authorized':True,'credentials_network_bank_privateTRAINlabels_uploaded':False};put(OUT/'Cloud_Payload_Manifest.json',payload)
    put(OUT/'Launch_Readiness_Audit.json',{'passed':True,'at_utc':datetime.now(timezone.utc).isoformat(),'source_hashes':{(ROOT/'work'/n).relative_to(ROOT).as_posix():sha(ROOT/'work'/n) for n in sources},'payload_sha256':payload['sha256'],'frozen_original_checks':frozen_checks(),'prior_all_actor_ended_release_and_zero_forward_proved':True,'same_all3_inputs_and_actual_token_IDs':True,'same_full384decoder_no_output_driven_change':True,'final_trainability_checked_on_actual_model_before_any_generation':True,'same_actual_PEFT_CPU_state_transition_proof':proof,'single_original_profile_oneassign_no_fallback':True,'8hashedACK_packages_planned_not_completed':True,'old_partial_all_costs_retained':True})
    put(OUT/'Host_Coordination_Protocol.json',{'single_owner':{'source':'work/'+sources[0],'sha256':sha(ROOT/'work'/sources[0]),'python':'work/colab_access_env/Scripts/python.exe','output':'outputs/original_lora_native13_transfer_execution_v2_20261020','coordination':'outputs/original_lora_native13_transfer_coordination_v2_20261020','bound_seconds':3900},'require_ended_claims':['outputs/original_lora_native13_transfer_execution_20261020/owner.claim'],'old_scientific_source_name':'run_original_lora_native13_colab_20261020.py','independent_reader':'work/audit_original_lora_native13_outputs_v2_20261020.py','reader_gate':'Onlyafteractualownerandchildended,allactualcompleteorpartialartifactspreserved,exactruntime released. No oldowners/readers restarted.'})
    print(json.dumps({'v2_inputs_only_bytes':payload['bytes'],'sha256':payload['sha256'],'all6_generations_unentered':True,'new_GPU_model_PF_calls_by_preparation':0,'same_prompts_decoder_seed_weights_native_contract':True,'old_failure_audit':'PASS_PARTIAL_UNKNOWN'}))
if __name__=='__main__':main()
