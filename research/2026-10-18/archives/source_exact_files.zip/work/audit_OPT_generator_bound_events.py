"""Separate all-source genQ occupancy/constitutive reader; zero new solves."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter,defaultdict
import json,math,time
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';S=P/'OPT_generator_bound_event_inventory'
OUT=P/'OPT_generator_bound_event_external_audit';assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
proto=read(S/'Protocol.json');summary=read(S/'Summary.json');actual=read(S/'Actual_Generator_Bound_Records.json')
assert read(S/'status.json')['stage']=='complete_readonly_occupancy_inventory'
assert len(actual)==len({r['transition_id'] for r in actual})==216
assert sha(ROOT/'work/inventory_OPT_generator_bound_events.py')==proto['source_sha256']
sources={}
for name,h in proto['source_branch_hashes'].items():assert sha(ROOT/name)==h;sources[h]=read(ROOT/name)
def frame(f):return {i:dict(zip(f['columns'],r)) for i,r in zip(f['index'],f['values'])}
tol=proto['tolerance_mvar'];classes=Counter();changes=Counter();worlds=set();families=set();events=0;pairs=0;checks=0
groups=defaultdict(list);interior_vm_checks=0;interior_vm_failures=[];max_vm_error=0.;duplicate_buses=[];reference_overlap=[]
q_const_p_checks=0;p_changes=[]
for r in actual:
    p=r['source_provenance'][0];src=sources[p['source_record_sha256']];n=p['prefix']
    b=src['observations'][n]['input_observation']['physical_tables'];a=src['observations'][n+1]['input_observation']['physical_tables']
    bg=frame(b['gen']);br=frame(b['res_gen']);ar=frame(a['res_gen']);busafter=frame(a['res_bus'])
    assert len(r['generator_measurements'])==len(bg)==53
    if len({g['bus'] for g in bg.values()})!=53:duplicate_buses.append(r['transition_id'])
    refs={g['bus'] for g in frame(b['ext_grid']).values() if g['in_service'] is True}
    if refs&{g['bus'] for g in bg.values()}:reference_overlap.append(r['transition_id'])
    changed=False
    for m in r['generator_measurements']:
        gen=m['native_gen_id'];g=bg[gen]
        for field,value in [('native_bus',g['bus']),('min_q_mvar',g['min_q_mvar']),('max_q_mvar',g['max_q_mvar']),
            ('before_q_mvar',br[gen]['q_mvar']),('after_q_mvar',ar[gen]['q_mvar']),
            ('before_vm_pu',br[gen]['vm_pu']),('after_vm_pu',ar[gen]['vm_pu']),('voltage_setpoint_pu',g['vm_pu'])]:
            assert m[field]==value;checks+=1
        observed=[]
        for side,res in [('before',br[gen]),('after',ar[gen])]:
            q=res['q_mvar'];lo=g['min_q_mvar'];hi=g['max_q_mvar']
            assert all(type(v) in (int,float) and math.isfinite(v) for v in (q,lo,hi))
            nearlo=abs(q-lo)<=tol;nearhi=abs(q-hi)<=tol
            label='both_ambiguous' if nearlo and nearhi else 'near_min' if nearlo else 'near_max' if nearhi else 'outside_low' if q<lo-tol else 'outside_high' if q>hi+tol else 'interior'
            assert label==m[side+'_nominal_occupancy'];observed.append(label);classes[(side,label)]+=1
        assert g['in_service'] is True and g['reactive_capability_curve'] is False
        assert m['fixed_bound_event_eligible'] and m['solver_internal_mode'] is None
        difference=observed[0]!=observed[1]
        assert m['measured_nominal_occupancy_changed']==difference
        if difference:changed=True;changes[tuple(observed)]+=1
        if observed[1]=='interior':
            error=abs(ar[gen]['vm_pu']-g['vm_pu']);max_vm_error=max(max_vm_error,error);interior_vm_checks+=1
            if error>1e-10:interior_vm_failures.append({'transition_id':r['transition_id'],'gen':gen,'absolute_vm_error':error})
        assert abs(ar[gen]['vm_pu']-busafter[g['bus']]['vm_pu'])<=1e-10
        q_const_p_checks+=1
        if abs(ar[gen]['p_mw']-br[gen]['p_mw'])>1e-10:p_changes.append((r['transition_id'],gen))
        pairs+=1
    assert changed==r['has_eligible_occupancy_event']
    if changed:events+=1;worlds.add(p['world_sha256']);families.add(p['family'])
    groups[(p['world_sha256'],r['before_sha256'])].append(r)
contrasts=0;contrast_families=set()
for key,v in groups.items():
    if len(v)<2:continue
    labels={tuple((m['native_gen_id'],m['after_nominal_occupancy']) for m in r['generator_measurements']) for r in v}
    if len(labels)>1:contrasts+=1;contrast_families.add(v[0]['source_provenance'][0]['family'])
assert events==summary['transitions_with_eligible_changes']==186
assert pairs==summary['actual_generator_before_after_records']==11448
assert changes==Counter({('near_max','near_min'):122,('near_max','interior'):141,('interior','near_min'):100})
assert {str(k):v for k,v in classes.items()}==summary['class_counts']
assert worlds==set(summary['event_worlds']) and families==set(summary['event_families'])
assert contrasts==summary['informative_distinct_after_contrasts']==15 and contrast_families==set(summary['informative_contrast_families'])
m=proto['minimum_design_support'];g={'event_transitions':events>=m['nontrivial_transition_events'],
    'event_worlds':len(worlds)>=m['OPT_worlds_with_events'],'event_families':len(families)>=m['families_with_events'],
    'distinct_after_contrasts':contrasts>=m['exact_same_before_distinct_measured_after_occupancy_groups'],
    'contrast_families':len(contrast_families)>=m['families_with_distinct_after_groups']}
assert g==summary['minimum_design_support_gates'] and all(g.values())
result={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_source_label_support_checks_passed':True,
    'actual_source_scalar_checks':checks,'gen_before_after_pairs':pairs,'event_transitions':events,
    'changed_gen_pairs':sum(changes.values()),'event_OPT_worlds':len(worlds),'same_before_distinct_after_groups':contrasts,
    'support_gates_independently_checked':g,'interior_next_vm_setpoint_checks':interior_vm_checks,
    'maximum_interior_vm_setpoint_error_pu':max_vm_error,'interior_vm_setpoint_failures':interior_vm_failures,
    'all_after_resgen_vm_resbus_vm_agree_1e10':True,'generator_const_P_checks':q_const_p_checks,'generator_P_change_records':p_changes,
    'duplicate_gen_bus_transition_ids':duplicate_buses,'gen_reference_bus_overlap_transition_ids':reference_overlap,
    'empirical_Qbound_and_interior_voltage_constraints_consistent':not interior_vm_failures,
    'unrecorded_solver_internal_bus_modes_still_UNKNOWN':True,
    'new_model_optimizer_PF_controller_cloud_calls':0,'held_targets_read':0,'reader_seconds':time.perf_counter()-started,
    'no_causal_LLM_or_grid_superiority_claim':True}
write(OUT/'Independent_Observed_Bound_and_Constitutive_Audit.json',result)
seal(OUT,{'Independent_Observed_Bound_and_Constitutive_Audit.json':OUT/'Independent_Observed_Bound_and_Constitutive_Audit.json',
    'original_inventory_protocol.json':S/'Protocol.json','original_inventory_summary.json':S/'Summary.json','source/reader.py':Path(__file__)},
    'Verified_Generator_Bound_Constitutive_Audit.zip')
print(json.dumps(result,indent=2))
