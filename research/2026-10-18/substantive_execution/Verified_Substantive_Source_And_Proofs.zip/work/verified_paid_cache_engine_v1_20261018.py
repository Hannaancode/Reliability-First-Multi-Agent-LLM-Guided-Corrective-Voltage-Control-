"""Per-use verified old receipts bound into source-identical decision logic.

Read-only source lineage: an absent identity blocks. A prospective new-query
reservation owner is intentionally not supplied by this module.
"""
import ast,copy,gzip,hashlib,json,os,time
from pathlib import Path
from collections.abc import Mapping
import receding_paid_decision_engine_durable_v2 as original_engine
import receding_paid_admitted_referenced_runtime_v1_20261018 as admitted
import receding_paid_referenced_runtime_v2_20261018 as referenced
from lazy_paid_lineage_receipts_v1_20261018 import ArchivedLineage,UnknownLineageIdentity
from certify_archived_receipt_on_use_v1_20261018 import certify,read_line
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from shared_original_serving_action_domain_v1 import build_current_domain
R=Path(__file__).resolve().parents[1]
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(Path(p).read_bytes())
def read(p):return json.loads(Path(p).read_text('utf-8-sig'))
def durable(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

class KnownLineageCache(Mapping):
    def __init__(self,archive):self.archive=archive
    def __contains__(self,key):self.archive.classification(key);return True
    def __getitem__(self,key):return self.archive.archived_receipt(key)
    def __iter__(self):return iter(self.archive.index)
    def __len__(self):return len(self.archive.index)
    def __deepcopy__(self,memo):return KnownLineageCache(self.archive)

class VerifiedPaidUseRegistry:
    def __init__(self,path,*,runner,zones,restore_anchor=None):
        self.path=Path(path).resolve();assert self.path.is_relative_to(R)
        self.runner=runner;self.zones=zones;self.archive=ArchivedLineage();self.cache=KnownLineageCache(self.archive)
        base=R/'outputs/primary_input_reference_index_20261018';raw=(base/'All_Primary_Input_References.json.gz').read_bytes()
        assert digest(raw)==read(base/'Results.json')['index_sha256'];self.primary=json.loads(gzip.decompress(raw))
        self.pins={'frontier':self.archive.anchors,'primary_input_index_sha256':digest(raw),
            'registry_source_sha256':sha(__file__),'peruse_checker_sha256':sha(R/'work/certify_archived_receipt_on_use_v1_20261018.py'),
            'native_reader_sha256':sha(R/'work/audit_full_receding_linear_composed_v4_20261018.py')}
        # Reuse the existing independently checked warm closure, never claim
        # that the later incomplete full-policy reader passed.
        paths=['outputs/operation_aware_lookahead_input_cache_20261014/audit_trace_v2/Independent_Compatible_Paid_Input_Audit.json',
            'outputs/receding_durable_engine_independent_audit_20261015/Independent_Warm_Engine_Audit.json',
            'outputs/bounded_paid_lookahead_physics_20261014/verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json']
        a,b,c=[read(R/p) for p in paths]
        assert a['status'].startswith('PASS_ALL_SOURCE_RECEIPTS_') and a['checked_cache_entries']==22653
        assert b['status'].startswith('PASS_INDEPENDENT_ALL8_') and b['paid_cache_entries']==22721 and b['newly_indexed_old_query_ids']==68
        assert c['status']=='PASS_COMPLETE_BOUNDED_SCREEN_SOURCE_PHYSICS_REPLAY_COST_AND_FROZEN_EVIDENCE'
        self.pins['warm_independent_certificates']={p:sha(R/p) for p in paths}
        self.previous='0'*64;self.prefix=hashlib.sha256();self.rows=0;self.actual_CPU_seconds=0.;self.validated={}
        if restore_anchor is None:
            self.path.mkdir(exist_ok=False);(self.path/'acks').mkdir();durable(self.path/'Source_Anchors.json',self.pins)
            self.stream=(self.path/'verified_uses.jsonl').open('xb')
        else:
            assert read(self.path/'Source_Anchors.json')==self.pins==restore_anchor['source_anchors']
            ledger=self.path/'verified_uses.jsonl';assert ledger.stat().st_size==restore_anchor['bytes'],'Stale/torn live-use cursor; no rollback'
            with ledger.open('rb') as f:
                for line in f:
                    e=json.loads(line);assert e['previous']==self.previous
                    d=e['data'];key=d['key'];self.archive.classification(key)
                    assert self._record_hash(key)==d['archived_record_sha256']
                    if d['ack'] is not None:
                        ack=self.path/d['ack']['path'];assert sha(ack)==d['ack']['sha256'];self._validate_ack(key,read(ack))
                        self.validated[key]=d['ack']
                    self.actual_CPU_seconds+=d['actual_verification_CPU_seconds'];self.previous=digest(line[:-1]);self.prefix.update(line);self.rows+=1
            assert self.previous==restore_anchor['last_event_sha256'] and self.prefix.hexdigest()==restore_anchor['sha256'] and self.rows==restore_anchor['records']
            assert self.actual_CPU_seconds==restore_anchor['actual_verification_CPU_seconds']
            self.stream=ledger.open('ab')
    def _record_hash(self,key):return digest(canonical(self.archive.archived_receipt(key)))
    def _validate_ack(self,key,ack):
        e=self.primary[key];ref=e['record_reference'];event=read_line(self.archive.journal,{'offset':ref['journal_offset'],'bytes':ref['journal_bytes'],'sha256':ref['journal_line_sha256']})
        assert ack['status']=='PASS_EXACT_CAUSAL_ARCHIVED_RECEIPT_SAVED_NATIVE_VERIFIER' and ack['point_action_key']==key
        assert ack['source_protocol_sha256']==e['source_protocol_sha256'] and ack['source_journal_sha256']==e['source_journal_sha256']
        assert ack['source_intent_line_sha256']==e['intent_reference']['sha256'] and ack['source_record_line_sha256']==ref['journal_line_sha256']
        assert ack['checked_record_sha256']==digest(canonical(event['data']['record']))
        assert ack['native_source_bound_reader_sha256']==self.pins['native_reader_sha256'] and ack['new_model_PF_derivative_forecast_factor_solve_calls']==0
    def import_existing_ack(self,path):
        # Existing CPU verification stays paid; source/point/hash predicates
        # are checked again. The fixture or new owner must pin its origin.
        ack=read(path);key=ack['point_action_key'];self._validate_ack(key,ack)
        target=self.path/'acks'/(digest(key.encode())+'.json');durable(target,ack)
        self.validated[key]={'path':str(target.relative_to(self.path)),'sha256':sha(target)}
    def lookup(self,node,row,key):
        started=time.perf_counter();assert key==point_key(node['net'],node['cursor'])+'|'+action_key(row)
        self.archive.classification(key)
        domain=build_current_domain(node['net'],node['cursor'],runner=self.runner,zones=self.zones)
        assert row in domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
        record=self.archive.archived_receipt(key);ackref=None
        if key in self.primary:
            if key not in self.validated:
                target=self.path/'acks'/(digest(key.encode())+'.json')
                certify(node['net'],node['cursor'],row,self.primary[key],runner=self.runner,zones=self.zones,ack_path=target)
                self.validated[key]={'path':str(target.relative_to(self.path)),'sha256':sha(target)}
            ackref=self.validated[key];path=self.path/ackref['path'];assert sha(path)==ackref['sha256'];self._validate_ack(key,read(path))
        else:assert self.archive.index[key]['classification']=='WARM_PAID_RECEIPT_RETAIN_OLD_COSTS'
        seconds=time.perf_counter()-started
        data={'key':key,'archived_record_sha256':digest(canonical(record)),'ack':ackref,'actual_verification_CPU_seconds':seconds,
            'warm_certificate_anchors_sha256':digest(canonical(self.pins['warm_independent_certificates'])) if ackref is None else None}
        raw=canonical({'previous':self.previous,'data':data})+b'\n';self.stream.write(raw);self.stream.flush();os.fsync(self.stream.fileno())
        self.previous=digest(raw[:-1]);self.prefix.update(raw);self.rows+=1;self.actual_CPU_seconds+=seconds
        # Namespace prevents collisions with fresh owner's NEW_RECEDING IDs;
        # source receipt identity and original paid cost remain explicit.
        record['source_original_receipt_id']=record['receipt_id'];record['receipt_id']='ARCHIVED_'+digest(key.encode())
        record['verified_use_reference']={'path':str((self.path/'verified_uses.jsonl').relative_to(R)),
            'prefix_bytes':self.stream.tell(),'event_sha256':self.previous,'source_anchors_sha256':digest(canonical(self.pins)),
            'actual_verification_CPU_seconds':seconds}
        return record
    def anchor(self):
        return {'path':str(self.path.relative_to(R)),'bytes':self.stream.tell(),'sha256':self.prefix.hexdigest(),'last_event_sha256':self.previous,
            'records':self.rows,'source_anchors':self.pins,'actual_verification_CPU_seconds':self.actual_CPU_seconds}
    def close(self):self.stream.close()

text=Path(original_engine.__file__).read_text('utf-8')
before='record = copy.deepcopy(cache[key])';after='record = self.certified_cached_record(node, row, key)'
assert text.count(before)==1
changed=text.replace(before,after);assert changed.replace(after,before)==text
node=next(n for n in ast.parse(changed).body if isinstance(n,ast.ClassDef) and n.name=='PaidDecisionEngine')
env=original_engine.__dict__.copy();exec(compile(ast.Module(body=[node],type_ignores=[]),str(Path(__file__)),'exec'),env)
SourceEngine=env[node.name]
# Admission method is copied as an AST into the derived class, retaining its
# original super() semantics before the exact source-derived engine begins.
tree=ast.parse('''class VerifiedPaidDecisionEngine(SourceEngine):
    def __init__(self,*,use_registry,**kwargs):
        super().__init__(**kwargs)
        self.use_registry=use_registry
    def certified_cached_record(self,node,row,key):
        self.evidence.admit()
        record=self.use_registry.lookup(node,row,key)
        seconds=record['verified_use_reference']['actual_verification_CPU_seconds']
        self.evidence.costs.setdefault('archived_receipt_verification_CPU_seconds',0.)
        self.evidence.costs['archived_receipt_verification_CPU_seconds']+=seconds
        self.evidence.event('archived_receipt_verified_before_policy_use',{'key':key,'receipt_id':record['receipt_id'],'reference':record['verified_use_reference']})
        return record
''')
admission=next(n for n in ast.parse(Path(admitted.__file__).read_text('utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='AdmittedPaidDecisionEngine')
tree.body[0].body.append(next(n for n in admission.body if isinstance(n,ast.FunctionDef) and n.name=='decision'))
env={'SourceEngine':SourceEngine,'Path':Path,'time':time,'admit_input':admitted.admit_input};exec(compile(tree,str(Path(__file__)),'exec'),env)
VerifiedPaidDecisionEngine=env['VerifiedPaidDecisionEngine']
def runtime_class(use_registry):
    node=next(n for n in ast.parse(referenced.changed).body if isinstance(n,ast.ClassDef) and n.name=='PaidRecedingRuntime')
    env=referenced.PaidRecedingRuntime.__init__.__globals__.copy()
    env['PaidDecisionEngine']=lambda **kw:VerifiedPaidDecisionEngine(use_registry=use_registry,**kw)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(referenced.SOURCE),'exec'),env)
    return env['PaidRecedingRuntime']
SOURCE_CERTIFICATE={'engine_source_sha256':sha(original_engine.__file__),'inverse_source_transform_exact':True,'before':before,'after':after,
    'controller_class_AST_unchanged':True,'policy_menu_queries_verifier_action_Q_guard_score_equations_unchanged':True,
    'receipt_namespace_changed_for_collision_prevention':True,'missing_identity_means_UNKNOWN_BLOCK_NOT_PF':True,
    'science_owner_or_new_query_reservation_supplied':False}
