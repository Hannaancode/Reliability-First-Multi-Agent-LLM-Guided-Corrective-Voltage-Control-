"""Independent saved-source and exact-decimal arithmetic reader; no model calls."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
import ast,hashlib,json,time
R=Path(__file__).resolve().parents[1]; O=R/'outputs/common118_external_bellman_contract_20261029'
def main():
    start=time.perf_counter(); dest=O/'Independent_Audit.json'; assert not dest.exists()
    p=json.loads((O/'Source_Contract_Proof.json').read_text()); src={}
    for k,s in p['sources'].items():
        f=R/s['path']; assert hashlib.sha256(f.read_bytes()).hexdigest()==s['sha256'];src[k]=f.read_text()
    pin=json.loads(src['upstream_pin']); assert pin['commit']=='98e9ee97302ee2eb53f3210acdea7ebe00eaefef'
    a=ast.parse(src['author_dqn']);c=next(x for x in a.body if isinstance(x,ast.ClassDef) and x.name=='DQNUniqueActions')
    assert ast.unparse(c.bases[0])=='DQN' and not any(getattr(x,'name',None)=='setup_model' for x in c.body)
    replay=[x for x in ast.walk(c) if isinstance(x,ast.Call) and ast.unparse(x.func)=='self.replay_buffer.add']; assert len(replay)==1
    assert [ast.unparse(x) for x in replay[0].args]==['obs','action','rew','new_obs','float(done)']
    assert 'np.isin(action_arr, action_list)' in src['author_dqn']
    t=ast.parse(src['author_train']); patch=[x for x in ast.walk(t) if isinstance(x,ast.Call) and ast.unparse(x.func)=='patch']
    assert len(patch)==1 and ast.literal_eval(patch[0].args[0])=='stable_baselines.deepq.build_graph.build_act'
    g=ast.parse(src['upstream_graph']); ex=ast.parse((O/'Extracted_Upstream_Formula.txt').read_text())
    for node in ex.body:
        assert any(ast.dump(node)==ast.dump(n) for n in ast.walk(g)), 'Extracted expression absent from pinned source'
    assert hashlib.sha256(ast.dump(ex).encode()).hexdigest()==p['operator_ast_sha256']
    assert 'q_tp1_best_using_online_net = tf.argmax(double_q_values, axis=1)' in ast.unparse(ex)
    assert 'q_tp1_best_masked = (1.0 - done_mask_ph) * q_tp1_best' in ast.unparse(ex)
    for row in p['checks']:
        values=row['online'] if row['double_q'] else row['target']
        allidx=max(range(len(values)),key=lambda i:values[i]); legalidx=max([i for i,x in enumerate(row['legal']) if x],key=lambda i:values[i])
        def value(i): return Decimal(str(row['reward']))+Decimal(str(row['gamma']))*(1-row['done'])*Decimal(str(row['target'][i]))
        assert value(allidx)==Decimal(str(row['source_formula'])) and value(legalidx)==Decimal(str(row['history_aware_formula']))
    out=dict(status='PASS_PINNED_SOURCE_INHERITANCE_REPLAY_OPERATOR_AND_EXACT_DECIMAL_CHECKS',at_utc=datetime.now(timezone.utc).isoformat(),checks=len(p['checks']),
      maximum_numeric_difference=0,source_proof_sha256=hashlib.sha256((O/'Source_Contract_Proof.json').read_bytes()).hexdigest(),
      limitations=p['execution_scope']+' '+p['native_performance_effect'],new_model_PF_optimizer_calls=0,workflow_seconds=time.perf_counter()-start)
    dest.write_text(json.dumps(out,indent=2),encoding='utf-8'); print(json.dumps(out))
if __name__=='__main__':main()
