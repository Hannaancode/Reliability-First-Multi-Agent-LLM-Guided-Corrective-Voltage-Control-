"""Pin compatible archived source semantics without installing or executing it."""
import ast,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'outputs/published_graph118_environment_source_20261022/compatible_archived'
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def main():
    p=O/'voltage_control_env.py';b=p.read_bytes();expected='75c01edf1eacdb32f4f1ce09da7a977c82f5d0ea'
    if blob(b)!=expected:
        assert b.endswith(b'\n') and blob(b[:-1])==expected
        (O/'Transport_Extra_Newline_Copy.txt').write_bytes(b);b=b[:-1];p.write_bytes(b)
    assert len(b)==133578 and blob(b)==expected
    tree=ast.parse(b.decode('utf-8'));classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
    base=classes['DiscreteVoltageControlEnvBase'];env=classes['DiscreteVoltageControlEnv'];methods={n.name:n for n in base.body if isinstance(n,ast.FunctionDef)}
    constants={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['MIN_V','MAX_V','LOW_V','HIGH_V']:
            constants[n.targets[0].id]=ast.literal_eval(n.value)
    cap=[n for n in ast.walk(env) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr=='_action_cap' for t in n.targets)]
    assert len(cap)==1 and ast.unparse(cap[0].value)=='2 * self.num_gens + 2 * self.num_shunts'
    proof=dict(status='COMPATIBLE_ARCHIVED_ENVIRONMENT_SOURCE_PIN_AND_STOP_RULES_RECOVERED_NO_EXECUTION',
        repository='blthayer/gym-powerworld',archived_master_commit='d776a67939ef5b239a2148b9949b25a50a25d350',git_blob=expected,source_bytes=len(b),source_sha256=hashlib.sha256(b).hexdigest(),
        historical_paper_exact_dependency_revision='UNRECOVERED; installer was not version-pinned. This explicitly pinned compatible source can ground a named backend adaptation, not a claim of exact historical PowerWorld runtime.',
        action_cap_expression=ast.unparse(cap[0].value),action_cap_uses_units_not_only_distinct_regulator_buses=True,
        environment_stopping='Stop at action_count >= action_cap, all source-band voltages, failed power flow; robust voltage-range rejection applies only in truncate_voltages mode, or configured no-op. Author GraphAgent comparison additionally ends on no-op and does not compare its modified rewards.',
        truncate_mode='Author experiment sets truncate_voltages=False, selecting _solve_and_observe_default. MIN_V/MAX_V rejection is conditional and must not be imposed on this experiment.',source_voltage_constants=constants,normal_band_success='Unrounded bus_obs_data between low_v and high_v inclusively; actor observation is explicitly float32.',
        init_gen_bins='Author experiment overrides to five values from0.95to1.05; environment constructor wider default must not replace them.',
        control_update='Full backend must refresh generator reference observations and binary-bank status from each solved state while preserving original GraphAgent action history/distance caches/initial episode graph.',
        old_first_query_port='Already source-AST-bound and independently checked on four roots; no full episode was claimed. This intake does not rerun those physics calls.',
        next_gate='Source-faithful transition/cursor/cold/persistent/ownership/relevant-attempt-history/first-replay protocol before full policy. Native and common-actuator or common-guard adaptations must be named separately.',
        source_method_AST_hashes={name:hashlib.sha256(ast.dump(methods[name],include_attributes=False).encode()).hexdigest() for name in ['step','_check_done','all_v_in_range','_solve_and_observe_default','_solve_and_observe_truncate']},
        new_PF_model_optimizer_training_install_calls=0)
    with (O/'Compatible_Source_Semantics.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
    print(json.dumps(dict(compatible_environment='PINNED_SOURCE_ONLY',native_action_cap=proof['action_cap_expression'],robust_voltage_constants=constants,new_scientific_calls=0)))
if __name__=='__main__':main()
