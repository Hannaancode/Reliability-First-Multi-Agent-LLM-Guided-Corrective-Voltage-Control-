"""Exact derivatives of the prepared native13 algebra, no solver or PF call.

The bus layout is bound by NonlinearNative13. Voltage magnitudes have a
nonnegative domain. At zero magnitude the inequality derivative is the
right-domain derivative; the AC equality is smooth in the polar variables.
"""
import numpy as np

def equality_jacobian(model,x):
    model._charge('analytic_equation_jacobian_evaluations')
    theta, magnitude, dq, aq, t=model.split(x)
    V=model.voltage(x);DV=np.zeros((13,24),dtype=complex)
    DV[model.pq,np.arange(12)]=1j*V[model.pq]
    DV[model.pq,12+np.arange(12)]=np.exp(1j*theta)
    I=model.Y@V
    DS=DV*np.conj(I)[:,None]+V[:,None]*np.conj(model.Y@DV)
    jac=np.zeros((24,31));jac[:12,:24]=DS[model.pq].real;jac[12:,:24]=DS[model.pq].imag
    inverse={int(bus):i for i,bus in enumerate(model.pq)}
    for j,bus in enumerate(model.control):jac[12+inverse[int(bus)],24+j]=-1/model.baseMVA
    if not np.isfinite(jac).all():raise ValueError('Nonfinite analytic AC Jacobian')
    return jac

def inequality_jacobian(model,x,first_stage_t=None):
    model._charge('analytic_constraint_jacobian_evaluations')
    _,magnitude,_,_,_=model.split(x)
    if np.any(magnitude<0):raise ValueError('Magnitude outside nonnegative variable domain')
    vmjac=np.zeros((13,31));inverse={int(bus):i for i,bus in enumerate(model.pq)}
    for native_bus,internal_bus in enumerate(model.lookup):
        if int(internal_bus) in inverse:vmjac[native_bus,12+inverse[int(internal_bus)]]=1.
    top=-vmjac.copy();top[:,30]=1.;bottom=vmjac.copy();bottom[:,30]=1.
    a=np.zeros((3,31));a[:,24:27]=-np.eye(3);a[:,27:30]=np.eye(3)
    b=a.copy();b[:,24:27]=np.eye(3)
    rows=[top,bottom,-vmjac[model.normal],vmjac[model.normal],a,b]
    if first_stage_t is not None:
        if not np.isfinite(first_stage_t) or first_stage_t<0:raise ValueError('Invalid first-stage t')
        extra=np.zeros((1,31));extra[0,30]=-1.;rows.append(extra)
    return np.concatenate(rows)

def objective_gradient(model,x,stage):
    model._charge('analytic_objective_gradient_evaluations');model.split(x)
    g=np.zeros(31)
    if stage==1:g[30]=1.
    elif stage==2:g[27:30]=1.
    else:raise ValueError('Only frozen stages1 and2 are supported')
    return g
