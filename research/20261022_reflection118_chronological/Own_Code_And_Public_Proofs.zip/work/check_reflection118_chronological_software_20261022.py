"""Labelled mock tests of original policy plumbing; zero scientific calls."""
import copy, json, re, sys
from pathlib import Path
from reflection118_chronological_core_20261022 import *


def main():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp, numpy as np
    from frozen_physics_loader import load_stack, AUDIT
    p=R/'outputs/reflection118_chronological_preparation_20261022'
    p.mkdir(exist_ok=True)
    assert not (p/'Labelled_Software_Checks.json').exists()
    v2,runner,reflection=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    row=bindings[0];root=pickle.loads((R/row['solved_payload']).read_bytes())['net']
    base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    scenario=read(R/row['registration']['recipe']);zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    calls=[];generations=[];feedback_seen=[];warm=None
    def forbidden(*a,**k):raise BaseException('No real PF in labelled software mocks')
    pp.runpp=forbidden
    original_verify=runner.rescue.verify_action
    def mock_verify(net,action):
        b=runner.rescue.grid_metrics(net);a=dict(b);a.update(uv_count=max(0,b['uv_count']-1),deficit_sum=b['deficit_sum']*.9,vmin=b['vmin']+.001)
        return {'accepted':bool(action),'reason':'LABELLED_MOCK_ACCEPTED' if action else 'LABELLED_MOCK_NONE',
            'before':b,'after':a,'converged':True}
    runner.rescue.verify_action=mock_verify
    original_query=reflection.get_llm_action_required_two_best_v2
    def observed_query(**kw):
        feedback_seen.append(copy.deepcopy(kw['feedback_state']))
        return original_query(**kw)
    reflection.get_llm_action_required_two_best_v2=observed_query
    def generate(messages):
        generations.append(copy.deepcopy(messages));text=messages[-1]['content']
        bus=re.search(r'CANDIDATE_BUSES_YOU_MAY_USE: \[(\d+)',text).group(1)
        return json.dumps({'bus':bus,'q_mvar':50})
    def pf(net,**kw):
        calls.append(kw)
        if len(calls)==1:restore_exact(net,root)
        else:net.res_bus['vm_pu']=1.0;net.converged=True
    def stop(cp):
        nonlocal warm
        warm=cp;raise FirstCommitBoundary()
    try:controller(v2,runner,reflection,scenario,base,zones,generate,pf,'reflection_v2',stop)
    except FirstCommitBoundary:pass
    assert warm and len(warm['result']['executed_actions'])==1
    assert len(generations)==4 and [re.search(r'\nzone: (\w+)',m[-1]['content']).group(1) for m in generations]==sorted(zones)
    memories=[m[-1]['content'].split('VERIFIER_FEEDBACK_MEMORY:\n')[1].split('\n\nCOMPACT_VERIFIER_REFLECTION')[0] for m in generations]
    assert [len(f['accepted_recent']) for f in feedback_seen]==[0,1,2,3]
    assert memories[0]==memories[1]=='None'
    assert warm['feedback_state'] and warm['result']['logs'] and warm['failed_actions']==[]
    checkpoints=[];calls.clear();generations.clear()
    # Original source may complete at UV0. The trace checkpoint is reproducible
    # from actual source locals even though the mock only tests plumbing.
    result,cold=controller(v2,runner,reflection,scenario,base,zones,generate,pf,'reflection_v2',lambda cp:checkpoints.append(cp))
    assert result['final_metrics']['uv_count']==0 and len(checkpoints)==1
    # RNG isn't used by these mocks; all current/history/source values match.
    checkpoint_equal(warm,cold)
    assert len(result['logs'])>=4 and len(result['executed_actions'])==1
    runner.rescue.verify_action=original_verify
    reflection.get_llm_action_required_two_best_v2=original_query
    put(p/'Labelled_Software_Checks.json',{'status':'PASS_ORIGINAL_CHRONOLOGICAL_POLICY_PLUMBING_LABELLED_MOCKS',
        'checks':['all_original_function_ASTs_unchanged','all_four_zones_source_order','MG2_query_receives_updated_MG1_feedback_state',
        'original_candidate_filter_can_hide_other_zone_feedback_from_prompt',
        'guided_refinement_retains_original_source','first_checkpoint_after_original_history_append',
        'complete_failed_feedback_history_in_checkpoint','warm_cold_source_state_equal','terminal_source_UV0_loop_stop'],
        'real_PF_model_calls':0,'mock_outcome_is_not_physics_or_performance':True})
    print(json.dumps(read(p/'Labelled_Software_Checks.json')))


if __name__=='__main__':main()
