"""Independent source/identity/scope/selection/cost readout, no new model/PF."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,math
import psutil
from vcsa_action_selection_audit import audit_action
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/vcsa_development/common_information_control_pilot'
AUDIT=ROOT/'outputs/vcsa_development/common_information_control_completion_audit'
assert not AUDIT.exists()
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pid=int((OUT/'owner.claim').read_text())
if psutil.pid_exists(pid):assert not any('run_vcsa_common_information_control_pilot.py' in arg for arg in psutil.Process(pid).cmdline())
assert read(OUT/'status.json')['stage']=='completed'
manifest=read(OUT/'manifest.json')
for name,entry in manifest.items():assert (OUT/name).stat().st_size==entry['bytes'] and sha(OUT/name)==entry['sha256']
protocol=read(OUT/'protocol.json')
for path,digest in protocol['source_hashes'].items():assert sha(ROOT/path)==digest
DATA=ROOT/'outputs/vcsa_development/common_information_contract'
for name,digest in protocol['data_hashes'].items():assert sha(DATA/name)==digest
labels={r['local_observation_id']:r for r in read(ROOT/'outputs/vcsa_development/full_pilot_preparation/rows.json')}
inputs={r['local_observation_id']:r for r in read(DATA/'input_only_rows.json')}
train=sorted(identity for identity,row in inputs.items() if row['split']=='train' and row['model_input'] is not None)
steps=read(OUT/'Actual_Training_Step_Identities.json')
ledger=[json.loads(line) for line in (OUT/'completed_step_ledger.jsonl').read_text().splitlines()]
assert steps==ledger and len(steps)==155 and [r['step'] for r in steps]==list(range(1,156))
for epoch in range(1,6):assert [r['id'] for r in steps if r['epoch']==epoch]==train
calls=read(OUT/'Actual_Forward_Call_Identities.json')
assert len(calls)==296 and [r['call'] for r in calls]==list(range(1,297))
assert Counter(r['phase'] for r in calls)=={'untrained_evaluation':47,'optimizer_forward':155,'final_evaluation':47,'checkpoint_replay':47}
records=0;predictions=0;split_statistics={}
final=None
for tag in ['untrained','final']:
    saved=read(OUT/(tag+'_rows.json'));assert len(saved)==len({r['id'] for r in saved})==48 and {r['id'] for r in saved}==set(labels)
    for record in saved:
        row=labels[record['id']];records+=1
        assert row['scenario_id']==record['scenario_id'] and row['split']==record['split']
        audit_action(row,record)
        if not row['training_eligible']:continue
        chosen=next(r for r in row['candidate_labels'] if (r['bus'],r['q_mvar'])==(record['action']['bus'],record['action']['q_mvar']))
        assert bool(chosen['guard_admissibility_target'])==record['admissible_in_existing_table']
        assert chosen['after_metrics']==record['label_after_metrics']
        assert ((record['action']['bus_position'],record['action']['q_index'])==(row['positive_action_target']['bus_position'],row['positive_action_target']['q_index']))==record['preferred_match']
        candidates=record['candidate_predictions']
        assert len(candidates)==len({(r['bus'],r['q_mvar']) for r in candidates})==len(row['candidate_labels'])
        assert {(r['bus'],r['q_mvar']) for r in candidates}=={(r['bus'],r['q_mvar']) for r in row['candidate_labels']}
        for candidate in candidates:
            predictions+=1
            assert all(math.isfinite(v) for v in candidate['normalized_progress'])
            assert 0<=candidate['PF_failure_probability']<=1 and 0<=candidate['guard_admissibility_probability']<=1
    split_statistics[tag]={}
    for split in ['train','validation']:
        subset=[r for r in saved if r['split']==split and 'action' in r]
        split_statistics[tag][split]={'finite_views':len(subset),'preferred_matches':sum(r['preferred_match'] for r in subset),
            'admissible_in_existing_tables':sum(r['admissible_in_existing_table'] for r in subset),
            'mean_residualUV_in_existing_tables':sum(r['label_after_metrics']['uv_count'] for r in subset)/len(subset),
            'strictUV_zero_normal_upper_in_existing_tables':sum(r['label_after_metrics']['uv_count']==0 and r['label_after_metrics']['vmax']<=1.05+1e-8 for r in subset)}
    if tag=='final':final={r['id']:r for r in saved}
assert predictions==6066
reloaded=read(OUT/'Actual_Checkpoint_Reload_Rows.json');assert len(reloaded)==len({r['id'] for r in reloaded})==48
for record in reloaded:
    if 'action' not in record:assert record['hard_abstained'];continue
    assert record['action']==final[record['id']]['action'] and record['maximum_logit_error']<=5e-6
summary=read(OUT/'summary.json');counts=summary['counts']
assert summary['completed'] and summary['split_results']==split_statistics
assert counts['non_LLM_forward_attempts']==counts['non_LLM_forward_returns']==296 and counts['optimizer_steps']==155
assert counts['forward_exceptions']==counts['pretrained_calls']==counts['generations']==counts['PF_calls']==0
assert counts['typed_record_inputs']==sum(r['typed_records'] for r in calls)
expected_bytes=0
for call in calls:
    source=inputs[call['id']]['model_input']['full_observed_prompt_state']['records']
    assert call['typed_records']==len(source) and not call['exception']
    if call['phase']=='optimizer_forward':assert call['id'] in train
    expected_bytes+=sum(len(json.dumps(r['path'],ensure_ascii=False,separators=(',',':')).encode())+len(r.get('value_utf8',[])) for r in source)
assert expected_bytes==counts['byte_encoder_input_bytes']
assert summary['final_checkpoint_sha256']==sha(OUT/'control_epoch_05.pt') and summary['fixed_checkpoint_epoch']==5
assert summary['actual_new_parameters']==418448 and summary['elapsed_seconds']<=protocol['max_wall_seconds']
assert sha(ROOT/'outputs/vcsa_development/state_only_pilot/manifest.json')==protocol['old_completed_control_manifest_sha256']
assert sha(ROOT/'outputs/vcsa_development/framework_preparation/framework_smoke_hf_inputs.zip')==protocol['old_pending_smoke_archive_sha256']
old={r['id']:r for r in read(ROOT/'outputs/vcsa_development/state_only_pilot/final_rows.json')}
paired=[]
for identity,record in final.items():
    if 'action' not in record:continue
    prior=old[identity]
    paired.append({'id':identity,'split':record['split'],'same_action':record['action']==prior['action'],
        'common_info_minus_old_UV':record['label_after_metrics']['uv_count']-prior['label_after_metrics']['uv_count'],
        'common_info_admissible':record['admissible_in_existing_table'],
        'old_control_admissible':prior['measured_label_guard_admissible'],
        'source_physical_tables_only':True})
AUDIT.mkdir()
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'passed':True,'scientific_manifest_members':len(manifest),
    'records_audited':records,'candidate_prediction_records_audited':predictions,'training_step_identities':155,
    'forward_identities':296,'exact_final_checkpoint_actions':47,'source_manifest_sha256':sha(OUT/'manifest.json'),
    'counts':counts,'split_statistics':split_statistics,'new_model_PF_optimizer_calls_in_audit':0,
    'old_control_and_pending_private_payload_hashes_preserved':True,
    'scope':'Same-information/capacity-matched no-LLM initial-state development control; table outcomes, no newly executed physical trajectories or superiority claim',
    'source_sha256':sha(Path(__file__))}
(AUDIT/'Independent_Completion_Audit.json').write_text(json.dumps(report,indent=2))
(AUDIT/'Paired_Old_And_Common_Information_Control_Table.json').write_text(json.dumps(paired,indent=2))
validation=[r for r in paired if r['split']=='validation']
comparison={'views':16,'UV_wins':sum(r['common_info_minus_old_UV']<0 for r in validation),
    'UV_ties':sum(r['common_info_minus_old_UV']==0 for r in validation),'UV_losses':sum(r['common_info_minus_old_UV']>0 for r in validation),
    'mean_UV_delta':sum(r['common_info_minus_old_UV'] for r in validation)/16,
    'not_independent_worlds_or_confirmation':True,'no_control_selection_or_retune':True}
(AUDIT/'Descriptive_Validation_Comparison.json').write_text(json.dumps(comparison,indent=2))
(AUDIT/'manifest.json').write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in AUDIT.iterdir()},indent=2))
print(json.dumps({'independent_audit':report,'old_control_comparison':comparison}))
