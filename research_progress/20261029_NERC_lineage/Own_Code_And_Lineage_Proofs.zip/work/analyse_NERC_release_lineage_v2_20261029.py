"""New saved-data grouping analysis; reuse prior archive inventory, no inference."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter,defaultdict
import hashlib,json,re,time,zipfile
R=Path(__file__).resolve().parents[1];O=R/'outputs/nerc_release_lineage_v2_20261029'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def put(name,x):(O/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8')
def main():
    assert not O.exists();O.mkdir();start=time.perf_counter()
    invpath=R/'outputs/powergridqa_archive_inventory.json';inv=json.loads(invpath.read_text('cp1252'))
    a=next(a for a in inv['archives'] if a['path'].endswith('PowerGridQA-main.zip'))
    nm=next(m for m in a['members'] if m['name'].endswith('/Nerc questions.jsonl'));rm=next(m for m in a['members'] if m['name'].endswith('/references.json'))
    nerc=Path('C:/Users/HOME/Downloads/RAG_Based_Integration_NERC (3).ipynb');nb=json.loads(nerc.read_text('utf-8'));source=''.join(nb['cells'][1]['source'])
    assert 're.search(r"(LL\\d{8})", question)' in source
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'FIXED_BEFORE_NEW_GROUPING_COUNTS','input_member':nm['name'],'expected_member_sha256':nm['sha256'],'reference_member':rm['name'],'expected_reference_sha256':rm['sha256'],
      'inventory_path':invpath.relative_to(R).as_posix(),'inventory_sha256':sha(invpath.read_bytes()),'inventory_encoding':'cp1252; original default-Windows write retained','prior_archive_identity':a['sha256'],'whole_archive_rehash_or_CRC_rerun':False,
      'source_notebook_sha256':sha(nerc.read_bytes()),'source_cell':2,'source_cell_sha256':sha(source.encode()),'rule':'First occurrence LL followed by exactly8decimal digits in question, as source regex; do not add boundary or drop rows silently.',
      'analyses':['allrowquestionidentifiercoverage','referenceMapmembership','exactquestionandQAduplicates','sameidentifiergroups','normalizedquestiontemplateswithidentifierremoved'],
      'not_claimed':['Recovered original evaluation membership','Recovered train/testsplit','Actual model leakage or metricreplication','Explanation of paper4696count without exactrelease'],'new_model_PF_training_calls':0,'source_sha256':sha(Path(__file__).read_bytes())}
    put('Protocol.json',protocol)
    with zipfile.ZipFile(a['path']) as z:raw=z.read(nm['name']);refsraw=z.read(rm['name'])
    assert sha(raw)==nm['sha256'] and sha(refsraw)==rm['sha256']
    protocol['analyses'].extend(['Retain every invalid nonblank line with raw SHA and parse error.','Separate syntactic candidate view: remove exactly one terminal comma only when the remainder parses as one QA object. Never overwrite source or count this as actual historical runtime ingestion.'])
    protocol['prior_failure']='Original strict decoder stopped at line309 heading before any grouping result; source/protocol/failure retained. New saved-only analysis classifies every line and preserves both strict and candidate-syntax views.'
    put('Protocol.json',protocol)
    records=[];invalid=[];repaired=[];nonblank=0
    for lineno,line in enumerate(raw.decode('utf-8-sig').splitlines(),1):
        if not line.strip():continue
        nonblank+=1
        try:row=json.loads(line)
        except json.JSONDecodeError as exc:
            item={'line':lineno,'raw_line_sha256':sha(line.encode()),'parse_error':str(exc),'classification':'non_record_text_or_unrecovered','candidate_record_sha256':None}
            if line.strip().endswith(','):
                try:
                    candidate=json.loads(line.strip()[:-1])
                    if isinstance(candidate,dict) and isinstance(candidate.get('question'),str) and isinstance(candidate.get('answer'),str):
                        item['classification']='single_terminal_comma_QA_candidate';item['candidate_record_sha256']=sha(enc(candidate));repaired.append((lineno,candidate))
                except json.JSONDecodeError:pass
            if re.fullmatch(r'LL[0-9]{8}.*',line.strip()):item['classification']='lesson_heading'
            invalid.append(item);continue
        assert isinstance(row,dict) and isinstance(row.get('question'),str) and isinstance(row.get('answer'),str);records.append((lineno,row))
    assert len(records)+len(invalid)==nonblank
    put('Invalid_Line_Preservation_LOCAL_ONLY.json',invalid)
    put('Candidate_Syntax_Repair_Views_LOCAL_ONLY.json',[{'line':i,'record':v,'record_sha256':sha(enc(v))} for i,v in repaired])
    refs=json.loads(refsraw.decode('utf-8-sig'));assert isinstance(refs,dict)
    def manual(s):
        # Independent character scan of the notebook's non-boundary first-match rule.
        for i in range(len(s)-9):
            if s[i:i+2]=='LL' and len(s[i+2:i+10])==8 and all(c.isdecimal() for c in s[i+2:i+10]):return s[i:i+10]
        return None
    identity=[];groups=defaultdict(list);questions=defaultdict(list);pairs=defaultdict(list);templates=defaultdict(list)
    for ordinal,(lineno,row) in enumerate(records):
        match=re.search(r'(LL\d{8})',row['question']);rid=match.group(1) if match else None;assert rid==manual(row['question'])
        q=sha(row['question'].encode());pair=sha(enc(row));allids=re.findall(r'LL\d{8}',row['question'])
        normal=re.sub(r'\s+',' ',re.sub(r'LL\d{8}','<LESSON_ID>',row['question'])).strip().casefold();tid=sha(normal.encode())
        x={'ordinal':ordinal,'line':lineno,'record_sha256':pair,'question_sha256':q,'lesson_id':rid,'all_question_ids':allids,'mapped_reference':rid in refs if rid else False,'template_sha256':tid};identity.append(x)
        groups[rid].append(ordinal);questions[q].append(ordinal);pairs[pair].append(ordinal);templates[tid].append(ordinal)
    put('All_Row_Identity_And_Source_Groups_LOCAL_ONLY.json',identity)
    idcounts=Counter(x['lesson_id'] for x in identity);valid=sum(x['lesson_id'] is not None for x in identity);mapped=sum(x['mapped_reference'] for x in identity)
    dupq=[v for v in questions.values() if len(v)>1];dupp=[v for v in pairs.values() if len(v)>1]
    cross=[]
    for k,ids in templates.items():
        lessons={identity[i]['lesson_id'] for i in ids if identity[i]['lesson_id'] is not None}
        if len(lessons)>1:cross.append({'template_sha256':k,'rows':len(ids),'distinct_lesson_ids':len(lessons)})
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_EXACT_RELEASE_IDENTIFIER_AND_DUPLICATE_GROUPING','source_members_unchanged':True,'whole_archive_rehash_or_CRC_rerun':False,
      'records':len(records),'notebook_rule_id_present':valid,'notebook_rule_id_missing':len(records)-valid,'rows_with_mapped_id':mapped,'distinct_first_ids':len([x for x in idcounts if x is not None]),'reference_map_entries':len(refs),
      'multiple_id_question_rows':sum(len(set(x['all_question_ids']))>1 for x in identity),'regex_manual_scan_allrows_agree':True,
      'duplicate_exact_question_groups':len(dupq),'duplicate_exact_question_excess_rows':sum(len(x)-1 for x in dupq),'duplicate_exact_QA_groups':len(dupp),'duplicate_exact_QA_excess_rows':sum(len(x)-1 for x in dupp),
      'cross_document_normalized_question_template_groups':len(cross),'cross_document_template_rows':sum(x['rows'] for x in cross),'cross_document_template_groups':cross,
      'per_id_row_counts':{str(k):v for k,v in sorted(idcounts.items(),key=lambda x:str(x[0]))},'unmapped_first_ids':sorted({x['lesson_id'] for x in identity if x['lesson_id'] and not x['mapped_reference']}),
      'reported_paper_counts':{'operational_subset':4696,'evaluated_retrieval_records':4396},'reported_evaluation_count_equals_notebook_ID_filter':valid==4396,
      'reported_evaluation_count_equals_release_rows':len(records)==4396,'reported_operational_minus_bound_release':4696-len(records),
      'identity_file_sha256':sha((O/'All_Row_Identity_And_Source_Groups_LOCAL_ONLY.json').read_bytes()),'input_member_sha256':sha(raw),'reference_member_sha256':sha(refsraw),'protocol_sha256':sha((O/'Protocol.json').read_bytes()),
      'workflow_seconds':time.perf_counter()-start,'new_model_retrieval_PF_training_calls':0,
      'limits':['The selected archive member is exactly the earlier inventoried byte sequence, not necessarily the later paper runtime release.','Identifier in a question is not authoritative document text or the historical evaluation manifest.','Duplicate/template grouping is a leakage risk map, not proof of overlap with unknown train/test manifests.','No records excluded, relabelled, regenerated or used for model tuning.','T13remainsPARTIAL until finalrelease/split/4396vs4696 identities are reconciled.']}
    result.update(nonblank_source_lines=nonblank,strict_valid_records=len(records),invalid_nonblank_lines=len(invalid),invalid_classes=dict(Counter(x['classification'] for x in invalid)),candidate_single_comma_QA_records=len(repaired),strict_plus_syntactic_candidate_records=len(records)+len(repaired),candidate_total_equals_reported4696=len(records)+len(repaired)==4696,
        candidate_record_first_identifiers=dict(Counter((re.search(r'(LL\d{8})',v['question']).group(1) if re.search(r'(LL\d{8})',v['question']) else 'UNKNOWN') for _,v in repaired)),
        mechanical_repair_scope='Candidate syntax repair only; original dataset and actual historical runtime remain unchanged. Count agreement is not proof this repaired release was used in the paper.',prior_failure_preserved='outputs/nerc_release_lineage_20261029/Failure.json')
    put('Release_Lineage_And_Grouping.json',result)
    print(json.dumps({k:result[k] for k in ['status','records','notebook_rule_id_present','notebook_rule_id_missing','rows_with_mapped_id','distinct_first_ids','duplicate_exact_question_excess_rows','cross_document_normalized_question_template_groups','reported_evaluation_count_equals_notebook_ID_filter','invalid_classes','candidate_single_comma_QA_records','strict_plus_syntactic_candidate_records']}))
if __name__=='__main__':main()
