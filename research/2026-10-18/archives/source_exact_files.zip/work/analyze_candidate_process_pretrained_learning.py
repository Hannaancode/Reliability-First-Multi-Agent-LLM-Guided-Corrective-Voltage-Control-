"""Single external learning/attribution gate reader; zero model or PF calls."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import collections,gzip,json,math,os,subprocess
import torch
from safetensors.torch import load_file
from candidate_process_evidence_utils import ROOT,read,write,sha,seal,frozen_checks
from candidate_process_diagnostics import recorded_priority_diagnostic
torch.set_num_threads(2)
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';PREP=BASE/'pretrained_learning_preparation'
EXEC=BASE/'pretrained_learning_execution';SCI=EXEC/'staged/study';OUT=BASE/'pretrained_learning_external_audit'
status=read(EXEC/'status.json');assert status['runtime_released'] and status['all_actual_artifacts_preserved'] and status['remote_exit_code']==0
pid=int((EXEC/'owner.claim').read_text())
r=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
assert not r.stdout.strip()
assert not OUT.exists();OUT.mkdir();write(OUT/'owner.claim',{'actual_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__))})
protocol=read(PREP/'protocol.json');assert read(SCI/'protocol.json')==protocol
for name,digest in read(PREP/'Program_Input_Manifest.json').items():assert sha(ROOT/name)==digest
assert read(EXEC/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
assert read(EXEC/'staged/remote_frozen_environment.json')==read(PREP/'Expected_Environment.json')
manifest=read(SCI/'Closed_Actual_Manifest.json')
for name,m in manifest.items():assert sha(SCI/name)==m['sha256'] and (SCI/name).stat().st_size==m['bytes']
summary=read(SCI/'summary.json');assert summary['completed'] and summary['total_optimizer_steps']==1870 and summary['total_pretrained_forwards']==3736
assert summary['forbidden_call_counts']=={'PF_attempts':0,'generation_attempts':0}
events=[json.loads(line) for line in (SCI/'events.jsonl').read_text().splitlines()]
assert all(a['elapsed_seconds']<=b['elapsed_seconds'] for a,b in zip(events,events[1:]))
assert not any(e['event'] in ['forward_exception','terminal_failure'] for e in events)
input_index=read(PREP/'Input_Index.json');target_index=read(PREP/'Target_Index.json');byid={r['observation_id']:r for r in input_index}
allids=sorted(byid);train=protocol['exact_optimization_order'];assert len(allids)==311 and len(train)==187
common=torch.load(PREP/'Common_Initial_Interface.pt',weights_only=True,map_location='cpu')
original=load_file(str(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/adapter_model.safetensors'))
with gzip.open(BASE/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz','rt') as f:labels={r['observation_id']:r for r in map(json.loads,f)}
vm={}
with gzip.open(BASE/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz','rt') as f:
    for row in map(json.loads,f):
        frame=row['model_input']['current_physical_observation']['physical_tables']['res_bus'];j=frame['columns'].index('vm_pu')
        vm[row['observation_id']]=dict(zip(frame['index'],[v[j] for v in frame['values']]))
normal=read(PREP/'Target_Normalization.json');results={};compute={};all_priority_rows=[]
for arm in protocol['arms']:
    folder=SCI/arm;arm_summary=read(folder/'summary.json');counts=arm_summary['counts']
    es=[e for e in events if e['arm']==arm];attempts=[e for e in es if e['event']=='forward_attempt'];returns=[e for e in es if e['event']=='forward_return']
    backwards=[e for e in es if e['event']=='backward_attempt'];back_returns=[e for e in es if e['event']=='backward_return']
    steps=[e for e in es if e['event']=='optimizer_return'];step_attempts=[e for e in es if e['event']=='optimizer_attempt']
    assert len(attempts)==len(returns)==counts['forward_attempts']==counts['forward_returns']==1868
    assert len(backwards)==len(back_returns)==len(steps)==len(step_attempts)==counts['optimizer_steps']==935
    assert counts['forward_exceptions']==counts['optimizer_exceptions']==0
    assert [e['call'] for e in attempts]==[e['call'] for e in returns]==list(range(1,1869))
    assert [(e['phase'],e['observation_id']) for e in attempts]==[(e['phase'],e['observation_id']) for e in returns]
    assert [e['observation_id'] for e in attempts if e['phase']=='training']==train*5
    for epoch in range(1,6):
        assert [e['observation_id'] for e in steps if e['epoch']==epoch]==train
        assert [e['observation_id'] for e in backwards if e['epoch']==epoch]==train
    for e in backwards:
        expected=187/(22*protocol['optimization_world_target_counts'][byid[e['observation_id']]['world_sha256']])
        assert e['world_weight']==expected and math.isfinite(e['loss'])
    assert counts['soft_embedding_positions']==1868*237
    assert counts['typed_record_inputs']==sum(byid[e['observation_id']]['typed_records'] for e in attempts)
    assert counts['value_utf8_input_bytes']==sum(byid[e['observation_id']]['value_utf8_bytes'] for e in attempts)
    checkpoint_events=[e for e in es if e['event']=='epoch_checkpoint_preserved'];assert [e['epoch'] for e in checkpoint_events]==list(range(1,6))
    for e in checkpoint_events:
        assert sha(SCI/e['checkpoint'])==e['sha256'] and e['actual_steps']==187*e['epoch']
        c=torch.load(SCI/e['checkpoint'],weights_only=True,map_location='cpu');assert set(c)=={'common','copied_adapter'}
        assert set(c['common'])==set(common) and set(c['copied_adapter'])==set(original)
        assert sum(t.numel() for t in c['common'].values())==289759 and sum(t.numel() for t in c['copied_adapter'].values())==8798208
    checkpoint=torch.load(folder/'Epoch5_Actual_Checkpoint.pt',weights_only=True,map_location='cpu')
    changed={n:not torch.equal(checkpoint['copied_adapter'][n],v) for n,v in original.items()}
    assert all(changed.values()) if arm=='copied_original_LoRA_body' else not any(changed.values())
    assert read(folder/'Actual_Copy_Tensor_Updates.json')==changed
    assert read(folder/'Frozen_Base_Before.json')==read(folder/'Frozen_Base_After.json')
    scores={phase:torch.load(folder/(phase+'_scores.pt'),weights_only=True,map_location='cpu') for phase in ['untrained','final_epoch5','fresh_model_checkpoint_reload']}
    for phase,predictions in scores.items():
        assert set(predictions)==set(allids) and [e['observation_id'] for e in attempts if e['phase']==phase]==allids
        assert all(p.shape==(118,9,7) and bool(torch.isfinite(p).all()) for p in predictions.values())
    assert all(torch.equal(scores['final_epoch5'][i],scores['fresh_model_checkpoint_reload'][i]) for i in allids)
    assert arm_summary['all311_fresh_scores_exact'] and arm_summary['actual_trainable_parameters']==(9087967 if arm=='copied_original_LoRA_body' else 289759)
    compute[arm]=arm_summary;results[arm]={}
    for phase in ['untrained','final_epoch5']:
        gain_worlds={};class_worlds={};priority_worlds={}
        for row in target_index:
            ident=row['observation_id'];key=(row['split'],row['world_sha256']);p=scores[phase][ident]
            target=torch.load(PREP/row['tensor_path'],weights_only=True,map_location='cpu');finite=target['regression_mask']
            gain_worlds.setdefault(key,[]).append(float(((p[...,3:]-target['regression'])[finite]**2).mean()))
            mask=target['classification_mask'];class_worlds.setdefault(key,[]).append(float(((torch.sigmoid(p[...,:3])-target['classification'])[mask]**2).mean()))
            allowed=torch.load(PREP/byid[ident]['tensor_path'],weights_only=True,map_location='cpu')['allowed_actions']
            diagnostic=recorded_priority_diagnostic(p,allowed,normal,labels[ident],vm[ident])
            priority_worlds.setdefault(key,[]).append(diagnostic)
            all_priority_rows.append({'arm':arm,'phase':phase,'observation_id':ident,'world_sha256':row['world_sha256'],'split':row['split'],'actual_diagnostic':diagnostic})
        phase_metrics={}
        for split in ['optimization','development_held']:
            means=[sum(v)/len(v) for (s,w),v in gain_worlds.items() if s==split]
            classified=[sum(v)/len(v) for (s,w),v in class_worlds.items() if s==split]
            metric={'equal_world_gain_MSE':sum(means)/len(means),'worlds_with_measured_gain_targets':len(means),
              'actual_target_states':sum(len(v) for (s,w),v in gain_worlds.items() if s==split),'masked_classification_Brier':sum(classified)/len(classified),'all_K':{}}
            for k in [1,4,8]:
                rates=[];denom=hits=unknown=known=0
                for (s,w),ds in priority_worlds.items():
                    if s!=split:continue
                    supported=[d['model_priority'][str(k)] for d in ds if d['known_admissible_oracle_exists']]
                    if supported:rates.append(sum(d['recorded_best_score_included'] for d in supported)/len(supported))
                    denom+=len(supported);hits+=sum(d['recorded_best_score_included'] for d in supported)
                    unknown+=sum(d['model_priority'][str(k)]['unmeasured_unknown'] for d in ds);known+=sum(d['model_priority'][str(k)]['known_measured'] for d in ds)
                metric['all_K'][str(k)]={'recorded_oracle_supported_states':denom,'recorded_best_included_states':hits,'equal_world_inclusion':sum(rates)/len(rates),
                   'unknown_unmeasured_candidates':unknown,'known_measured_candidates':known}
            phase_metrics[split]=metric
        results[arm][phase]=phase_metrics
head=results['frozen_original_body_heads']['final_epoch5']['development_held'];body=results['copied_original_LoRA_body']['final_epoch5']['development_held']
relative=1-body['equal_world_gain_MSE']/head['equal_world_gain_MSE']
internal=relative>=.10 and body['all_K']['4']['equal_world_inclusion']>head['all_K']['4']['equal_world_inclusion']
future=internal and body['equal_world_gain_MSE']<protocol['future_physical_study_gate']['MSE_strictly_below_best_control'] and body['all_K']['4']['equal_world_inclusion']>protocol['future_physical_study_gate']['equal_world_top4_strictly_above_best_control']
decision={'fixed_internal_body_gate_passed':internal,'fixed_future_physical_study_gate_passed':future,
 'actual_relative_MSE_reduction_against_frozen_heads':relative,'copied_held_MSE':body['equal_world_gain_MSE'],'frozen_held_MSE':head['equal_world_gain_MSE'],
 'copied_equal_world_top4':body['all_K']['4']['equal_world_inclusion'],'frozen_equal_world_top4':head['all_K']['4']['equal_world_inclusion'],
 'decision':'eligible for separately prospective attribution/physical plan; no automatic rollout' if future else 'STOP this intervention branch on this dataset; preserve actual evidence, no minor parameter changes/retraining',
 'no_LLM_DSE_superiority_novelty_unused_confirmation_or_causal_pretraining_claim':True}
write(OUT/'Prospective_Gate_Decision.json',decision);write(OUT/'Actual_All_Arms_Results.json',{'metrics':results,'actual_compute':compute,'summary':summary,
 'all_original_invalid_unlabelled_failed_unknown_denominators_retained':True,'data_is_historical_development':True})
write(OUT/'All_Actual_Priority_Diagnostics.json',all_priority_rows)
write(OUT/'Fresh_Frozen_Asset_Audit.json',frozen_checks())
write(OUT/'Independent_Actual_Learning_Audit.json',{'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'actual_optimizer_steps':1870,'actual_pretrained_forwards':3736,
 'all622_fresh_model_score_arrays_exact':True,'actual_ten_epoch_checkpoints_verified':True,'all_actual_source_input_environment_gradient_step_cost_identity_gates_passed':True,
 'exact_owned_runtime_release_verified':True,'actual_notebook_hash':status['notebook_hash'],'science_manifest_sha256':sha(SCI/'Closed_Actual_Manifest.json'),
 'old_original_assets_private_files_and_negative_studies_preserved':True,'zero_model_optimizer_PF_calls_in_reader':True,'validated_superiority_unachieved':True})
(OUT/'Results.md').write_text(f'''# Actual dense-process pretrained learning results\n\nBoth fixed arms completed935optimizersteps/1868pretrainedforwards each, with exact311-state fresh-model reproduction per arm. All10epochcheckpoints, source/input/environment/journal/cost/frozen-file and exact owned-release gates passed. No new PF or physical controller trajectory was run.\n\nHeld-development gain MSE: frozen heads {head['equal_world_gain_MSE']:.6f}, copied LoRA {body['equal_world_gain_MSE']:.6f}. Equal-world top4 recorded-best inclusion: {head['all_K']['4']['equal_world_inclusion']:.6f} versus {body['all_K']['4']['equal_world_inclusion']:.6f}. All K values, per-state outcomes and invalid/unknown denominators remain in the actual-results files. Internal-body gate passed={internal}; future physical-study gate passed={future}.\n\n{decision['decision']}. These are historical learning/development results, not LLM superiority over literal D-SE, causal pretraining, unused confirmation or a novelty claim.\n''')
files={'audit/'+p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'}
files['Closed_Actual_Science_Archive.zip']=EXEC/'preserved_remote_outputs.zip'
for name in ['status.json','remote_output_descriptor.json']:files['closed_execution/'+name]=EXEC/name
for name in ['protocol.json','Cloud_Payload_Manifest.json','Launch_Readiness_Audit.json','Launch_Readiness_Transfer_v2.json','Direct_Human_Authority_for_Exact_Payload.json']:
    files['preparation/'+name]=PREP/name
files['sources/'+Path(__file__).name]=Path(__file__)
files['Prospective_Research_Decision.md']=BASE/'Copied_Body_Learning_Pilot_Prospective_Decision.md'
archive=seal(OUT,files,'Actual_Dense_Process_Learning_Evidence.zip')
write(OUT/'status.json',{'stage':'complete_independent_pretrained_learning_audit','all_passed':True,'fixed_gate_decision':decision,'archive':archive,'finished_at_utc':datetime.now(timezone.utc).isoformat()})
print(json.dumps({'all_identity_and_checkpoint_gates_passed':True,'fixed_gate_decision':decision,'archive':archive},indent=2))
