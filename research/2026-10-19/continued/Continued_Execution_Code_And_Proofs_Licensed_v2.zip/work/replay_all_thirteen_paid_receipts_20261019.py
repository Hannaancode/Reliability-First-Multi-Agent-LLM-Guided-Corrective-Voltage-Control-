"""Same fixed policy with ALL thirteen available query receipts; no new science."""
import ast,copy,hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
import replay_fixed_nine_second_context_20261019 as previous
import replay_fixed_nine_preserved_receipts_v3_20261019 as nine
from replay_paid_suffix_new_receipts_v3_20261018 import Overlay
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from strict_saved_native_input_match_v2_20261018 import require_same
from equal_operation_benchmark_v2 import decode_capsule
from audit_full_receding_linear_composed_v4_20261018 import check_query
B=R/'outputs/all_thirteen_paid_receipts_policy_screen_20261019'
PREP=R/'outputs/all_thirteen_paid_receipts_policy_preparation_20261019'
WARM=R/'outputs/third_point_four_query_acquisition_20261019'
TAIL=R/'outputs/third_point_remaining_three_query_acquisition_20261019'

class Registry(nine.Registry):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.tail_locks=[];self.tail={}
        assert read(WARM/'Preserved_Prefix_State_Proof.json')['status']=='PASS_ACTUAL_WARM_PREFIX_NATIVE_PHYSICS_STATE_COSTS_ONLY'
        assert read(WARM/'partial_reader_preparation/Completion.json')['reader_exit']==0
        assert read(TAIL/'Completion.json')['exit_codes']=={'warm':0,'cold_1':0,'cold_2':0,'audit':0}
        assert read(TAIL/'audit/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
        for base,phases in [(WARM,('warm',)),(TAIL,('warm','cold_1','cold_2'))]:
            self.tail_locks.append(LockedSourceSnapshot(base/'Protocol.json'));protocol=read(base/'Protocol.json')
            for phase in phases:
                root=base/phase
                for rel,h in read(root/'Closed_Manifest.json')['members'].items():assert sha(root/rel)==h
                message=read(root/'Result.json')['receipt']['message'];key=protocol['point']+'|'+message['aid'];record=copy.deepcopy(message['record'])
                record['after_reference']={'kind':'external_capsule','base':str(base.relative_to(R)),'descriptor':{**record['after_reference']['descriptor'],'path':phase+'/capsules.bin'}}
                intents={};returns={};exceptions={}
                for raw in (root/'scientific.jsonl').read_bytes().splitlines():
                    e=json.loads(raw);d=e['data']
                    if e['event']=='PF_intent':intents[d['identity']]=d
                    elif e['event']=='PF_return':returns[d['PF_id']]=d
                    elif e['event']=='PF_exception':exceptions[d['PF_id']]=d
                assert key not in self.new_data and key not in self.more and key not in self.four and key not in self.archive.index and key not in self.tail
                self.tail[key]={'root':root,'base':base,'p':protocol,'message':message,'record':record,'intents':intents,'returns':returns,'exceptions':exceptions}
        assert len(self.tail)==4;self.cache=Overlay(self.cache,{k:v['record'] for k,v in self.tail.items()});self.tail_stream=(self.path/'new_third_point_four_receipt_uses.jsonl').open('xb')
    def lookup(self,node,row,key):
        if key not in self.tail:return super().lookup(node,row,key)
        begun=time.perf_counter();d=self.tail[key];assert key==point_key(node['net'],node['cursor'])+'|'+action_key(row) and row==d['message']['row']
        expected=build_verifier(self.runner.rescue,node['cursor'])[1](copy.deepcopy(node['net']),action(row));pid=d['message']['record']['actual_measured_receipt']['PF_id']
        with (d['root']/'capsules.bin').open('rb') as pack:
            require_same(expected,decode_capsule(pack,d['intents'][pid]['before'])['net']);check_query(node,row,d['message'],cache={},intents=d['intents'],returns=d['returns'],exceptions=d['exceptions'],pack=pack,p=d['p'],runner=self.runner)
        record=copy.deepcopy(d['record']);seconds=time.perf_counter()-begun
        event={'key':key,'source_protocol_sha256':sha(d['base']/'Protocol.json'),'source_closed_manifest_sha256':sha(d['root']/'Closed_Manifest.json'),'verification_workflow_seconds':seconds,'new_PF':0,'old_lifecycle_unknowns_retained':True}
        raw=json.dumps(event,sort_keys=True,separators=(',',':')).encode()+b'\n';self.tail_stream.write(raw);self.tail_stream.flush();os.fsync(self.tail_stream.fileno())
        record['source_original_receipt_id']=record['receipt_id'];record['receipt_id']='ARCHIVED_THIRD_POINT_'+hashlib.sha256(key.encode()).hexdigest();record['verified_use_reference']={'path':str((self.path/'new_third_point_four_receipt_uses.jsonl').relative_to(R)),'prefix_bytes':self.tail_stream.tell(),'event_sha256':hashlib.sha256(raw[:-1]).hexdigest(),'actual_verification_CPU_seconds':seconds,'clock_semantics':'Original field name; measured perfcounter workflow, not separately process CPU/intrinsic latency'};return record
    def close(self):
        self.tail_stream.close()
        for lock in self.tail_locks:lock.close()
        super().close()

def main():
    assert not B.exists() and not PREP.exists();text=Path(previous.__file__).read_text('utf-8');fn=copy.deepcopy(next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main'))
    extra=";files += [R/'outputs/third_point_four_query_acquisition_20261019/Protocol.json',R/'outputs/third_point_four_query_acquisition_20261019/Preserved_Prefix_State_Proof.json',R/'outputs/third_point_four_query_acquisition_20261019/partial_reader_preparation/Completion.json',R/'outputs/third_point_remaining_three_query_acquisition_20261019/Protocol.json',R/'outputs/third_point_remaining_three_query_acquisition_20261019/Completion.json',R/'outputs/third_point_remaining_three_query_acquisition_20261019/audit/Independent_Audit.json']"
    where=next(i for i,s in enumerate(fn.body) if isinstance(s,ast.Assign) and len(s.targets)==1 and isinstance(s.targets[0],ast.Name) and s.targets[0].id=='new')
    fn.body.insert(where+1,ast.AugAssign(target=ast.Name(id='new',ctx=ast.Store()),op=ast.Add(),value=ast.Constant(value=extra)))
    proxy=SimpleNamespace(**nine.__dict__);proxy.Registry=Registry;env=previous.__dict__.copy();env.update(B=B,PREP=PREP,nine=proxy,__file__=__file__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),__file__,'exec'),env);env['main']()
if __name__=='__main__':main()
