"""After original terminal partial: saved-root KCL proof and one never-entered independent replay."""
import hashlib,json,pickle,time,os,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/stable_ddpg_native_engineering_20261020';OUT=SRC/'preserved_root_independent_audit';PREP=ROOT/'outputs/stable_ddpg_preserved_root_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));costs={'admittance_builds':0,'independent_dense_branch_matrix_builds':0,'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'model_derivative_forecast_linear_solve_optimizer_GPU_calls':0}
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    try:
        import numpy as np
        import pandapower as pp
        from pandapower.pypower.makeYbus import makeYbus
        from pandapower.pypower.makeSbus import makeSbus
        from candidate_process_evidence_utils import frozen_checks
        assert sha(__file__)==p['single_owner']['sha256']
        for f,h in p['inputs'].items():assert sha(ROOT/f)==h
        failure=json.loads((SRC/'Failure.json').read_text(encoding='utf-8'));assert failure['costs']['PF_returns']==1 and failure['costs']['policy_agent_attempts']==0
        with (SRC/'PF0_after.pkl').open('rb') as f:saved=pickle.load(f)
        assert saved.converged;ppc=saved._ppc;bus=ppc['bus'];branch=ppc['branch'];assert len(bus)==13
        y,_,_=makeYbus(ppc['baseMVA'],bus,branch);costs['admittance_builds']+=1
        dense=np.zeros((len(bus),len(bus)),dtype=complex);status=branch[:,10].real;ys=status/(branch[:,2]+1j*branch[:,3]);bc=status*branch[:,4];tap=np.ones(len(branch),dtype=complex);nonzero=branch[:,8]!=0;tap[nonzero]=branch[nonzero,8];tap*=np.exp(1j*np.deg2rad(branch[:,9].real));f=branch[:,0].real.astype(int);t=branch[:,1].real.astype(int)
        np.add.at(dense,(f,f),(ys+1j*bc/2)/(tap*np.conj(tap)));np.add.at(dense,(f,t),-ys/np.conj(tap));np.add.at(dense,(t,f),-ys/tap);np.add.at(dense,(t,t),ys+1j*bc/2);dense[np.diag_indices(len(bus))]+=(bus[:,4]+1j*bus[:,5])/ppc['baseMVA'];costs['independent_dense_branch_matrix_builds']+=1
        matrix_delta=float(np.max(np.abs(dense-y.toarray())));assert matrix_delta<=1e-10
        v=bus[:,7]*np.exp(1j*np.deg2rad(bus[:,8]));s=makeSbus(ppc['baseMVA'],bus,ppc['gen']);residual=float(np.max(np.abs(v*np.conj(y@v)-s)));assert residual<=1e-7
        np.savez(OUT/'Verified_Admittance_And_State.npz',Y=dense,V=v,bus=bus,branch=branch,gen=ppc['gen'],baseMVA=ppc['baseMVA'])
        # Before the original callback failed, original PF had returned and full state/fields were saved.
        original=(ROOT/'work/run_stable_ddpg_native_engineering_20261020.py').read_text(encoding='utf-8')
        assert original.index('costs[\'PF_returns\']+=1')<original.index("with (OUT/f'PF{index}_after.pkl')")<original.index("assert y.shape==")
        with (SRC/'PF0_before.pkl').open('rb') as stream:net=pickle.load(stream)
        rng=np.random.RandomState(0);assert rng.choice([0,1])==0;expected=np.zeros(len(net.sgen));expected[0]=-.5*rng.uniform(1,7);expected[1]=-.8*rng.uniform(1,4);expected[2]=-.3*rng.uniform(1,5);assert np.array_equal(expected,net.sgen.p_mw.to_numpy())
        stored=np.load(SRC/'PF0_fields.npz');costs['PF_attempts']+=1;t0=time.monotonic()
        try:pp.runpp(net,algorithm='bfsw')
        except BaseException:costs['PF_exceptions']+=1;raise
        costs['PF_returns']+=1;assert net.converged;delta=0.
        for name in stored.files:
            actual=net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float);target=stored[name];assert actual.shape==target.shape and np.allclose(actual,target,rtol=0,atol=1e-9,equal_nan=True)
            finite=np.isfinite(actual)&np.isfinite(target)
            if finite.any():delta=max(delta,float(np.max(np.abs(actual[finite]-target[finite]))))
        vm=net.res_bus.vm_pu.to_numpy(copy=True);controlled=vm[[2,7,9]]
        put(OUT/'Frozen_After.json',frozen_checks());audit={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_PRESERVED_PARTIAL_ROOT_SOURCE_ORDER_RNG_ADMITTANCE_KCL_AND_ONE_INDEPENDENT_REPLAY','original_science_costs':failure['costs'],'costs':costs,'cached_author_solver_Ybus_empty':list(ppc['internal']['Ybus'].shape)==[0],'native_admittance_matrix_shape':list(dense.shape),'independent_admittance_delta':matrix_delta,'KCL_max_pu':residual,'all_numeric_field_replay_delta':delta,'all_bus_UV':int((vm<.95).sum()),'all_bus_OV':int((vm>1.05).sum()),'controlled_UV':int((controlled<.95).sum()),'controlled_OV':int((controlled>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'replay_seconds':time.monotonic()-t0,'workflow_seconds':time.monotonic()-start,'all3_primary_and_cold_policy_outputs':'UNEXECUTED_UNKNOWN','original_failure_source_stderr_preserved':True,'old_worker_not_restarted':True}
        assert time.monotonic()-start<300;put(OUT/'Independent_Partial_Audit.json',audit);put(OUT/'Closed_Manifest.json',{'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.iterdir() if f.is_file()]});print(json.dumps({'independent_partial_root':'PASS','UV':audit['all_bus_UV'],'OV':audit['all_bus_OV'],'one_new_independent_PF_return':1,'field_delta':delta,'remaining_policy_outputs':'UNEXECUTED'}))
    except BaseException as e:put(OUT/'Failure.json',{'failure':str(e),'traceback':traceback.format_exc(),'costs':costs});raise
if __name__=='__main__':main()
