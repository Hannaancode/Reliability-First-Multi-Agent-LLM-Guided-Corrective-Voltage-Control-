"""Post-hoc descriptive mechanism diagnosis from sealed records only.

No model construction/forward, training, solver, checkpoint choice or retuning.
Observed score/weight changes do not causally isolate an individual component.
"""
from pathlib import Path
from datetime import datetime, timezone
import ctypes, hashlib, json, math, os
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/vcsa_development'
SCI = BASE / 'pretrained_pilot_execution/staged/study'
OUT = BASE / 'pretrained_pilot_mechanism_diagnostic_20261008'
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), 'Do not duplicate this descriptive record diagnosis'
    verified = read(BASE / 'pretrained_pilot_cpu_continuation_20261008/Verified_Completion.json')
    assert verified['completed'] and verified['all_selected_physics_audit']['passed']
    for folder in [SCI, BASE / 'pretrained_pilot_analysis', BASE / 'training_interface']:
        for name, entry in read(folder / 'manifest.json').items():
            assert (folder / name).stat().st_size == entry['bytes'] and sha(folder / name) == entry['sha256']
    rows = {r['local_observation_id']: r for r in read(BASE / 'training_interface/rows.json')}
    policies = {}
    for variant in ['frozen_LM_heads', 'VCSA_full']:
        policies[variant] = {r['id']: r for r in read(SCI / variant / 'final_rows.json')}
    comparisons = {}
    for split in ['train', 'validation']:
        ids = [identity for identity, row in rows.items() if row['training_eligible'] and row['split'] == split]
        differences = []; unequal_actions = 0
        for identity in ids:
            a, b = [policies[variant][identity] for variant in ['VCSA_full', 'frozen_LM_heads']]
            unequal_actions += int((a['action']['bus'], a['action']['q_mvar']) != (b['action']['bus'], b['action']['q_mvar']))
            scores = [{(x['bus_position'], x['q_index']): x['score']
                       for x in record['joint_decode_evidence']['candidate_joint_log_scores']} for record in [a, b]]
            assert scores[0].keys() == scores[1].keys()
            differences.extend(abs(scores[0][key] - scores[1][key]) for key in scores[0])
        comparisons[split] = {'finite_views': len(ids), 'different_selected_actions': unequal_actions,
            'stored_candidate_score_pairs': len(differences), 'maximum_absolute_joint_score_difference': max(differences),
            'mean_absolute_joint_score_difference': sum(differences) / len(differences)}
    metrics = {}
    for variant, records in policies.items():
        metrics[variant] = {}
        for split in ['train', 'validation']:
            finite = [r for identity, r in records.items() if rows[identity]['training_eligible'] and rows[identity]['split'] == split]
            errors = {'PF_failure_probability': [], 'guard_admissibility_probability': []}
            for r in finite:
                labels = {(c['bus'], c['q_mvar']): c for c in rows[r['id']]['candidate_labels']}
                for prediction in r['candidate_predictions']:
                    label = labels[(prediction['bus'], prediction['q_mvar'])]
                    for key, target in [('PF_failure_probability', 'PF_failure_target'),
                                        ('guard_admissibility_probability', 'guard_admissibility_target')]:
                        probability = prediction[key]; assert math.isfinite(probability) and 0 <= probability <= 1
                        errors[key].append((probability - float(label[target])) ** 2)
            metrics[variant][split] = {'finite_views': len(finite),
                'preferred_matches': sum(r['preferred_match'] for r in finite),
                'admissible': sum(r['admissible_in_existing_table'] for r in finite),
                'mean_residual_UV': sum(r['label_after_metrics']['uv_count'] for r in finite) / len(finite),
                'mean_residual_deficit': sum(r['label_after_metrics']['deficit_sum'] for r in finite) / len(finite),
                'candidate_count': len(errors['PF_failure_probability']),
                'candidate_Brier': {key: sum(value) / len(value) for key, value in errors.items()}}
    # Read only new-module tensors from the already preserved trusted epochs.
    lib = Path('C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
    dll_guard = os.add_dll_directory(str(lib)); dll = ctypes.WinDLL(str(lib / 'msvcp140.dll'))
    import torch
    tensor_changes = {}
    for variant in ['frozen_LM_heads', 'VCSA_full']:
        old = torch.load(SCI / variant / 'new_weights_epoch_01.pt', map_location='cpu', weights_only=True)
        new = torch.load(SCI / variant / 'new_weights_epoch_05.pt', map_location='cpu', weights_only=True)
        assert old.keys() == new.keys() and all('vcsa_' in name for name in old)
        groups = {}
        for name in old:
            assert old[name].shape == new[name].shape and torch.isfinite(new[name]).all()
            group = next((key for key in ['vcsa_encoder', 'vcsa_router', 'vcsa_injectors', 'vcsa_heads'] if name.startswith(key)), 'internal_rank_updates')
            record = groups.setdefault(group, {'parameters': 0, 'tensor_count': 0, 'changed_tensors': 0, 'squared_update_sum': 0.})
            record['parameters'] += new[name].numel(); record['tensor_count'] += 1
            record['changed_tensors'] += int(not torch.equal(old[name], new[name]))
            record['squared_update_sum'] += float((new[name].double() - old[name].double()).square().sum())
        for record in groups.values():
            record['update_L2_between_epochs1_and5'] = math.sqrt(record.pop('squared_update_sum'))
        tensor_changes[variant] = groups
    loss = {}; retention = {}
    for variant in policies:
        summary = read(SCI / variant / 'summary.json'); history = summary['history']
        loss[variant] = {'first_epoch_mean': history[0]['mean_loss'], 'last_epoch_mean': history[-1]['mean_loss'],
            'relative_decrease': 1 - history[-1]['mean_loss'] / history[0]['mean_loss'],
            'actual_training_seconds': summary['costs']['training_seconds']}
        terms = [r['terms']['last_token_language_retention'] for r in read(SCI / variant / 'Actual_Training_Step_Identities.json')]
        retention[variant] = {'actual_training_step_terms': len(terms), 'min': min(terms), 'max': max(terms),
            'mean': sum(terms) / len(terms),
            'evaluation_retention_zero_semantics': 'Final diagnostic objective does not request a reference language distribution; recorded zero is not a measured language-invariance result'}
    OUT.mkdir(); (OUT / 'owner.claim').write_text(str(os.getpid()))
    report = {'analyzed_at_utc': datetime.now(timezone.utc).isoformat(), 'passed_record_integrity': True,
        'post_hoc_descriptive_diagnostic': True, 'source_sha256': sha(Path(__file__)),
        'scientific_manifest_sha256': sha(SCI / 'manifest.json'), 'actual_selected_action_and_score_comparisons': comparisons,
        'actual_final_metrics': metrics, 'actual_epoch1_to5_new_tensor_changes': tensor_changes,
        'actual_training_loss': loss, 'actual_training_retention_terms': retention,
        'new_model_forwards_optimizer_PF_calls': 0, 'weights_or_settings_changed': False,
        'causal_component_attribution_established': False,
        'decision': 'Stop the current VCSA performance branch under its predeclared no-incremental-value rule. No minor retuning, checkpoint selection, retry or closed-loop performance launch justified from these results alone.',
        'remaining_research': 'Separate outcome-independent scientific redesign may be researched. Any new experiment needs a justified hypothesis, strong controls, prospective manifest and unused confirmation for a superiority claim.'}
    (OUT / 'Mechanism_Diagnostic.json').write_text(json.dumps(report, indent=2, allow_nan=False))
    (OUT / 'manifest.json').write_text(json.dumps({'Mechanism_Diagnostic.json': {
        'bytes': (OUT / 'Mechanism_Diagnostic.json').stat().st_size, 'sha256': sha(OUT / 'Mechanism_Diagnostic.json')}}, indent=2))
    print(json.dumps({'selected_actions': comparisons, 'training_loss': loss,
                     'VCSA_internal_tensor_changes': tensor_changes['VCSA_full'], 'decision': report['decision']}, indent=2))


if __name__ == '__main__':
    main()
