"""Preserve pre-entry missing-requests failure; select established Colab launcher."""
import json,ast
from pathlib import Path
from candidate_process_evidence_utils import read,write,sha
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'outputs/native_joint_15_engineering_preparation_20261020';new=ROOT/'outputs/native_joint_15_engineering_preparation_v2_20261020';new.mkdir(exist_ok=False)
assert not (ROOT/'outputs/native_joint_15_engineering_execution_20261020').exists()
log=ROOT/'outputs/native_joint_15_engineering_coordination_20261020/Owner.log';assert "ModuleNotFoundError: No module named 'requests'" in log.read_text(encoding='utf-8')
for name in ['Production_Protocol.json','Cloud_Payload_Manifest.json','Direct_Human_Authority.json','Complete_Function_Scope_Import_Proof.json']:(new/name).write_bytes((old/name).read_bytes())
source=(ROOT/'work/run_native_joint_15_colab_20261020.py').read_text(encoding='utf-8').replace('native_joint_15_engineering_preparation_20261020','native_joint_15_engineering_preparation_v2_20261020').replace('native_joint_15_engineering_execution_20261020','native_joint_15_engineering_execution_v2_20261020')
(ROOT/'work/run_native_joint_15_colab_v2_20261020.py').write_text(source,encoding='utf-8');ast.parse(source)
reader=(ROOT/'work/audit_native_joint_15_engineering_20261020.py').read_text(encoding='utf-8').replace('native_joint_15_engineering_preparation_20261020','native_joint_15_engineering_preparation_v2_20261020').replace('native_joint_15_engineering_execution_20261020','native_joint_15_engineering_execution_v2_20261020').replace('native_joint_15_engineering_independent_20261020','native_joint_15_engineering_independent_v2_20261020').replace('native_joint_15_engineering_coordination_20261020','native_joint_15_engineering_coordination_v2_20261020')
(ROOT/'work/audit_native_joint_15_engineering_v2_20261020.py').write_text(reader,encoding='utf-8');ast.parse(reader)
ready=read(old/'Launch_Readiness_Audit.json');ready['source_hashes'].pop('work/run_native_joint_15_colab_20261020.py');ready['source_hashes'].pop('work/audit_native_joint_15_engineering_20261020.py')
for rel in ['work/run_native_joint_15_colab_v2_20261020.py','work/audit_native_joint_15_engineering_v2_20261020.py']:ready['source_hashes'][rel]=sha(ROOT/rel)
write(new/'Launch_Readiness_Audit.json',ready)
write(new/'Independent_Reader_Lock.json',{'reader_sha256':sha(ROOT/'work/audit_native_joint_15_engineering_v2_20261020.py'),'protocol_sha256':sha(new/'Production_Protocol.json'),'validator_sha256':sha(ROOT/'work/validate_native_joint_checkpoint_20261020.py'),'only_after_actual_owner_ended_release_and_closed_outputs':True,'zero_new_model_PF_optimizer_calls':True})
write(new/'Preentry_Launcher_Failure_Provenance.json',{'original_failure_log_sha256':sha(log),'before_actual_owner_claim':True,'old_GPU_allocation_model_PF_optimizer_network_calls':0,'original_source_and_failed_coordinator_preserved':True,'repair':'Select established work/colab_access_env launcher, fresh owner/output/coordinator/reader claims. Same immutable scientific protocol,22KBpayload/source/head/loss/settings remain unchanged.','new_cpu_import_check':'requests/colab_cli/googlecredentials passed in actualselectedlauncher','no_scientific_retry':True})
write(new/'Owner_Protocol.json',{'single_owner':{'source':'work/run_native_joint_15_colab_v2_20261020.py','sha256':sha(ROOT/'work/run_native_joint_15_colab_v2_20261020.py'),'python':'work/colab_access_env/Scripts/python.exe','output':'outputs/native_joint_15_engineering_execution_v2_20261020','coordination':'outputs/native_joint_15_engineering_coordination_v2_20261020','bound_seconds':4500}})
print('UNENTERED_OWNER_CORRECT_LAUNCHER_FROZEN')
