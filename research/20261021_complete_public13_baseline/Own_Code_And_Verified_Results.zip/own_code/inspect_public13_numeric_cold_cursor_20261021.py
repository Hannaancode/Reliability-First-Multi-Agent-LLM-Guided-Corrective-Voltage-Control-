"""Fresh-process cursor reconstruction for inspection only, never science resume."""
import json,pickle,hashlib,argparse
from pathlib import Path
import stable_ddpg_native_bridge_20261020 as b
from native_upgrade_support_engine_20261020 import signature
R=Path(__file__).resolve().parents[1]
def inspect(path):
    value=pickle.loads(Path(path).read_bytes());ref=value['current_NET'];raw=(R/ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256'];data=pickle.loads(raw);net=data['network'] if ref['kind']=='ENV' else data
    assert value['remaining_original_horizon']==101-value['next_step'] and value['absolute_deadline_monotonic']>0
    assert b.np.array_equal(net.res_bus.vm_pu.to_numpy(),value['current_vm']) and b.np.array_equal(net.sgen.q_mvar.to_numpy()[:3],value['current_Q'])
    assert len(value['python_rng'])==3 and len(value['numpy_rng'])==5 and value['torch_rng'].dtype==b.np.uint8
    return {'status':'PASS_FRESH_PROCESS_COMPLETE_NET_Q_VM_RNG_CURSOR_BINDING_FOR_INSPECTION','physical_signature':signature(net),'next_step':value['next_step'],'remaining_original_horizon':value['remaining_original_horizon'],'absolute_deadline_monotonic_UNCHANGED':value['absolute_deadline_monotonic'],'new_model_PF_converter_derivative_solver_optimizer_calls':0,'resuming_or_restarting_any_owner_authorized':False}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cursor',required=True);a=p.parse_args();print(json.dumps(inspect(R/a.cursor)))
