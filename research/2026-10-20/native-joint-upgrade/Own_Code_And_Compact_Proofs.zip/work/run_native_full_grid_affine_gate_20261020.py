"""ALL24 cached native terminal contexts, one derivative/LU/3RHS and fixed2LP per context; zero PF."""
import json,hashlib,pickle,os,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_full_grid_affine_preparation_20261020';OUT=ROOT/'outputs/native_full_grid_affine_gate_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from scipy.sparse import bmat,csc_matrix
    from scipy.sparse.linalg import splu
    from scipy.optimize import linprog
    from pandapower.pypower.dSbus_dV import dSbus_dV
    from native_full_grid_affine_core_20261020 import problem,second_problem
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));costs={k:0 for k in ['public_derivative_attempts','public_derivative_returns','LU_factorizations','RHS_solves','LP_attempts','LP_returns']};costs['PF_model_training_GPU_calls']=0;rows=[];put(OUT/'Frozen_Before.json',frozen_checks())
    for n,h in {**p['sources'],**p['inputs']}.items():assert sha(ROOT/n)==h
    graph=np.load(ROOT/p['graph']);y=csc_matrix(graph['Y']);events=(OUT/'events.jsonl').open('x',encoding='utf-8');previous='0'*64
    def event(kind,**v):
        nonlocal previous
        assert time.monotonic()-start<p['worker_seconds'];e={'kind':kind,'elapsed_seconds':time.monotonic()-start,'previous':previous,**v};h=hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest();events.write(json.dumps({'event':e,'sha256':h})+'\n');events.flush();os.fsync(events.fileno());previous=h
    try:
        for pos,context in enumerate(p['all24contexts']):
            d=OUT/f'context_{pos:02d}';d.mkdir();r={'seed':context['seed'],'algorithm':context['algorithm'],'status':'UNKNOWN'};rows.append(r)
            try:
                with (ROOT/context['paid_NET']).open('rb') as f:net=pickle.load(f)
                pp=net._ppc;assert np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and pp['baseMVA']==float(graph['baseMVA'])
                v=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));pq=np.flatnonzero(pp['bus'][:,1]==1);lookup=net._pd2ppc_lookups['bus'][net.bus.index.to_numpy()];assert len(pq)==12 and np.sum(pp['bus'][:,1]==3)==1 and not np.any(pp['bus'][:,1]==2);vm=net.res_bus.vm_pu.to_numpy(copy=True);q0=net.sgen.q_mvar.to_numpy(copy=True)[:3];assert np.allclose(vm,np.abs(v)[lookup],atol=1e-14,rtol=0) and np.array_equal(net.sgen.bus.to_numpy()[:3],[2,7,9])
                costs['public_derivative_attempts']+=1;event('derivative_attempt',context=pos);dm,da=dSbus_dV(y,v);costs['public_derivative_returns']+=1;event('derivative_return',context=pos);j=bmat([[da[pq,:][:,pq].real,dm[pq,:][:,pq].real],[da[pq,:][:,pq].imag,dm[pq,:][:,pq].imag]],format='csc');rhs=np.zeros((24,3));order={int(k):i for i,k in enumerate(pq)}
                for col,bus in enumerate(net.sgen.bus.to_numpy()[:3]):rhs[12+order[int(net._pd2ppc_lookups['bus'][bus])],col]=1/pp['baseMVA']
                lu=splu(j);costs['LU_factorizations']+=1;x=lu.solve(rhs);costs['RHS_solves']+=3;assert np.max(np.abs(j@x-rhs))<=1e-9;full=np.zeros((13,3));full[pq]=x[12:];s=full[lookup];c,a,bb,bounds=problem(vm,s,q0);np.savez(d/'Model_And_Problem.npz',Y=graph['Y'],V=v,J=j.toarray(),rhs=rhs,response=x,pq=pq,lookup=lookup,control_ppc=net._pd2ppc_lookups['bus'][net.sgen.bus.to_numpy()[:3]],baseMVA=pp['baseMVA'],vm=vm,q0=q0,S=s,c=c,A=a,b=bb)
                solutions=[]
                for stage in [1,2]:
                    if stage==2:c,a,bb,bounds=second_problem(c,a,bb,bounds,solutions[0].x[-1])
                    costs['LP_attempts']+=1;event('LP_attempt',context=pos,stage=stage);sol=linprog(c,A_ub=a,b_ub=bb,bounds=bounds,method='highs',options=p['LP_options']);costs['LP_returns']+=1;put(d/f'Stage{stage}_Return.json',{'success':bool(sol.success),'status':int(sol.status),'message':str(sol.message)});event('LP_return',context=pos,stage=stage,success=bool(sol.success));assert sol.success,'Fixed LP returned no optimum; preserve UNKNOWN, no solver/settings retry';solutions.append(sol);np.savez(d/f'Stage{stage}_Proof.npz',x=sol.x,c=c,A=a,b=bb,ineq_marginals=sol.ineqlin.marginals,lower_marginals=sol.lower.marginals,upper_marginals=sol.upper.marginals)
                sol=solutions[-1];u=np.clip(np.asarray(-sol.x[:3],dtype=np.float32),-.3,.3);qnext=q0-u;predicted=vm+s@(qnext-q0);net.sgen.loc[net.sgen.index[:3],'q_mvar']=qnext
                with (d/'UNEXECUTED_Candidate_NET.pkl').open('xb') as f:pickle.dump(net,f,protocol=5)
                np.save(d/'UNEXECUTED_Native_u_Mvar.npy',u);r.update(status='COMPLETE_AFFINE_ONLY',current_UV=int((vm<.95).sum()),current_OV=int((vm>1.05).sum()),current_max_band_violation=float(np.maximum(np.maximum(.95-vm,vm-1.05),0).max()),optimal_linear_minimax=float(solutions[0].x[-1]),predicted_native_float32_UV=int((predicted<.95).sum()),predicted_native_float32_OV=int((predicted>1.05).sum()),predicted_max_band_violation=float(np.maximum(np.maximum(.95-predicted,predicted-1.05),0).max()),predicted_vm=predicted.tolist(),current_q=q0.tolist(),proposed_native_u=u.tolist(),proposed_absolute_q=qnext.tolist(),actual_nonlinear_next_state='UNKNOWN_UNEXECUTED',information='CentralizedfullcurrentYbus/full13VM;notthesameinputasoriginalown1VMactorsandnotLLMbenefit')
                put(d/'Result.json',r)
            except BaseException as exc:r.update(failure_type=type(exc).__name__,failure=str(exc));put(d/'Failure.json',r)
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_DECLARED24_AFFINE_CONTROL_ANALYSIS' if all(r['status']=='COMPLETE_AFFINE_ONLY' for r in rows) else 'TERMINAL_PARTIAL_DECLARED24_AFFINE_ANALYSIS','all24contexts':rows,'costs':costs,'worker_seconds':time.monotonic()-start,'all_physical_candidates_and_LLM_training_permission':'UNEXECUTED_UNKNOWN_NO_AUTOMATIC_PHYSICS_OR_MODEL_LAUNCH','claim':'Affine minimax optimality isnot nonlinear feasibility or impossibility. All24contextsretained,notselectedonlyfailures.'};put(OUT/'Result.json',result);put(OUT/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(OUT/'Result.json'));events.close();put(OUT/'Closed_Manifest.json',{'files':[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()],'journal_last_sha256':previous});print(result['status'],costs)
    except BaseException as exc:put(OUT/'Failure.json',{'type':type(exc).__name__,'failure':str(exc),'rows':rows,'costs':costs});events.close();raise
if __name__=='__main__':main()
