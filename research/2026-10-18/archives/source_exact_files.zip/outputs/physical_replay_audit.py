"""Independent postprocessing of actual saved trajectories; never select controls.

Strict original voltage counts are preserved alongside separately labelled
1e-8 tolerance diagnostics. Neither diagnostic changes the running campaign.
"""
from pathlib import Path
import copy,hashlib,json,math,sys,time,warnings
import numpy as np
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack
from checkpoint_io import read_json_ready
warnings.filterwarnings('ignore')
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
TOL=1e-8
def clean(x):
    if isinstance(x,(float,np.floating)) and not math.isfinite(x):return {'nonfinite':str(x)}
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    if isinstance(x,np.integer):return int(x)
    return x
def save(path,x):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(clean(x),indent=2,allow_nan=False),encoding='utf-8');tmp.replace(path)
def limits(net,table,result,fields):
    rows=[];df=net[table];res=net[result]
    for i,r in df.iterrows():
        if not bool(r.get('in_service',True)):continue
        for field,lo,hi in fields:
            val=float(res.at[i,field]);low=float(r.get(lo,np.nan));high=float(r.get(hi,np.nan))
            if not np.isfinite(val) or (np.isfinite(low) and val<low-1e-6) or (np.isfinite(high) and val>high+1e-6):
                rows.append({'index':int(i),'field':field,'actual':val,'minimum':low,'maximum':high})
    return rows
def state_audit(net,original_shunts):
    buses=net.bus.index[net.bus.in_service.astype(bool)];vm=net.res_bus.vm_pu.reindex(buses)
    missing=[int(i) for i,v in vm.items() if not np.isfinite(v)]
    unserved=[]
    for i,r in net.load.iterrows():
        if not bool(r.in_service):continue
        p=float(r.p_mw)*float(r.scaling);q=float(r.q_mvar)*float(r.scaling)
        actualp=float(net.res_load.at[i,'p_mw']);actualq=float(net.res_load.at[i,'q_mvar'])
        if int(r.bus) in missing or not np.isfinite(actualp) or abs(actualp-p)>1e-6 or abs(actualq-q)>1e-6:
            unserved.append({'load':int(i),'bus':int(r.bus),'scheduled_p_mw':p,'scheduled_q_mvar':q,'served_p_mw':actualp,'served_q_mvar':actualq})
    thermal={}
    for t in ['line','trafo']:
        active=net[t].index[net[t].in_service.astype(bool)];loading=net['res_'+t].loading_percent.reindex(active)
        thermal[t]={'nonfinite_active_indices':[int(i) for i,v in loading.items() if not np.isfinite(v)],'above_100_percent':[int(i) for i,v in loading.items() if np.isfinite(v) and v>100+TOL],'above_declared_loading_limit':[int(i) for i,v in loading.items() if np.isfinite(v) and np.isfinite(float(net[t].at[i,'max_loading_percent'])) and v>float(net[t].at[i,'max_loading_percent'])+TOL],'maximum_percent':float(loading.max())}
    added=net.shunt.index.difference(original_shunts);nominal={};realized={};conversion_errors=[]
    for i in added:
        b=str(int(net.shunt.at[i,'bus']));nominal[b]=nominal.get(b,0.)+abs(float(net.shunt.at[i,'q_mvar']))
        realized[b]=realized.get(b,0.)-float(net.res_shunt.at[i,'q_mvar'])
        voltage=float(net.res_bus.at[int(b),'vm_pu']);ratio=float(net.bus.at[int(b),'vn_kv'])/float(net.shunt.at[i,'vn_kv'])
        expected=-float(net.shunt.at[i,'q_mvar'])*float(net.shunt.at[i,'step'])*(voltage*ratio)**2
        actual=-float(net.res_shunt.at[i,'q_mvar']);conversion_errors.append(abs(actual-expected))
    finite=vm[np.isfinite(vm)]
    return {'pf_converged':bool(net.converged),'active_bus_count':len(buses),'nonfinite_active_bus_ids':missing,'all_active_bus_voltages_finite':not missing,'unserved_or_mismatched_loads':unserved,'unserved_scheduled_p_mw':sum(x['scheduled_p_mw'] for x in unserved),'voltage':{'minimum':float(finite.min()),'maximum':float(finite.max()),'uv_strict':int((finite<.95).sum()),'ov_strict':int((finite>1.05).sum()),'uv_beyond_1e8_tolerance':int((finite<.95-TOL).sum()),'ov_beyond_1e8_tolerance':int((finite>1.05+TOL).sum()),'hard_ov_beyond_1e8_tolerance':int((finite>1.06+TOL).sum())},'thermal':thermal,'gen_q_limit_violations':limits(net,'gen','res_gen',[('q_mvar','min_q_mvar','max_q_mvar')]),'ext_grid_declared_limit_violations':limits(net,'ext_grid','res_ext_grid',[('p_mw','min_p_mw','max_p_mw'),('q_mvar','min_q_mvar','max_q_mvar')]),'ext_grid_actual':net.res_ext_grid.reset_index().to_dict(orient='records'),'incremental_shunt_nominal_mvar_by_bus':nominal,'incremental_shunt_realized_mvar_by_bus':realized,'incremental_shunt_nominal_mvar_total':sum(nominal.values()),'incremental_shunt_realized_mvar_total':sum(realized.values()),'incremental_shunt_realized_vs_admittance_formula_max_abs_error_mvar':max(conversion_errors,default=0),'incremental_shunt_cap_violations':[b for b,q in nominal.items() if q>450+TOL]}
def replay(scenario,branch,base,zones,v2,runner):
    if branch.get('status')=='exception':
        return {'status':'saved_branch_exception_not_replayed','exception_type':branch.get('exception_type')}
    if not branch.get('base_converged'):
        return {'status':'saved_initial_branch_failure_not_replayed','saved_stop_reason':branch.get('stop_reason')}
    net=copy.deepcopy(base);original_shunts=net.shunt.index.copy();v2.v0.apply_scenario_to_net(net,scenario,zones)
    conv,err=v2.v0.run_pf(net);states=[]
    if not conv:return {'status':'initial_pf_failed','error':err}
    states.append({'step':0,**state_audit(net,original_shunts)})
    actions=branch.get('executed_actions',[])
    action_space=[]
    for j,row in enumerate(actions,1):
        action=row['action'];runner.rescue.apply_action(net,action);conv,err=runner.base_runner.run_pf(net)
        values=[abs(float(q)) for q in action.get('add_shunts_q_mvar',{}).values()]
        action_space.append({'step':j,'single_shunt_action':len(values)==1,'within_actual_normalizer_25_mvar_grid_25_to_300':all(25<=q<=300 and abs(q/25-round(q/25))<1e-8 for q in values),'q_values_not_in_prompt_or_fallback_nine_value_list':[q for q in values if q not in runner.rescue.Q_SWEEP]})
        if not conv:return {'status':'trajectory_pf_failed','step':j,'error':err,'states':states}
        states.append({'step':j,'action':action,**state_audit(net,original_shunts)})
    metrics=runner.rescue.grid_metrics(net);saved=branch.get('final_metrics') or {};errors={}
    for k,v in metrics.items():
        if isinstance(saved.get(k),(int,float)) and np.isfinite(v):errors[k]=float(v)-saved[k]
    continuous=[abs(v) for k,v in errors.items() if k not in ['uv_count','ov_count']]
    return {'status':'replayed','executed_action_count':len(actions),'within_25_action_budget':len(actions)<=25,'action_space_audit':action_space,'terminal_original_metrics':metrics,'terminal_saved_metric_differences':errors,'continuous_metrics_match_1e10':all(x<1e-10 for x in continuous),'states':states}
def main():
    v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
    paths=sorted(Path('outputs/matched_campaign/cases').glob('*.json'));out=Path('outputs/physical_replay_audit');index=[]
    for p in paths:
        target=out/'cases'/p.name;record=read_json_ready(p);sf=ROOT/'bank/scenarios'/p.name
        identity={'saved_case_sha256':sha(p),'scenario_sha256':sha(sf),'audit_source_sha256':sha(__file__),'network_sha256':sha(ROOT/'pack/testbeds/federation_4mg_ieee118.json')}
        if target.exists() and json.loads(target.read_text())['identity']==identity:
            report=json.loads(target.read_text())
        else:
            start=time.perf_counter();report={'identity':identity,'scenario_id':p.stem,'platform':'local Windows CPU; recorded numerical core versions; discrete boundary roundoff separately retained','diagnostic_voltage_tolerance_pu':TOL,'branches':{k:replay(json.loads(sf.read_text()),b,base,zones,v2,runner) for k,b in record['branches'].items()},'elapsed_seconds':time.perf_counter()-start};save(target,report)
            print('PHYSICAL_AUDIT_SAVED',p.stem,flush=True)
        index.append({'scenario_id':p.stem,'branches':{k:{'status':b['status'],'continuous_metrics_match_1e10':b.get('continuous_metrics_match_1e10'),'terminal':b.get('states',[{}])[-1]} for k,b in report['branches'].items()}})
    save(out/'summary.json',{'audited_case_count':len(index),'case_count_available_at_start':len(paths),'cases':index})
    print('AUDIT_COMPLETE',len(index),flush=True)
if __name__=='__main__':main()
