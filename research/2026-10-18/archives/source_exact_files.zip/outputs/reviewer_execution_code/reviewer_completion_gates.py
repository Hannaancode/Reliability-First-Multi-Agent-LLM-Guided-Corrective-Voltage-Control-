"""Evidence-only completion gates shared by status writing and packaging."""
from pathlib import Path
import hashlib, json
from checkpoint_io import read_json_ready

def completion_gates(out=Path('outputs')):
    def read(name):
        p = out / name
        return read_json_ready(p) if p.exists() else {}
    main = read('main_campaign_detailed_audit.json')
    preservation = read('execution_preservation_verification.json')
    overlap = read('training_bank_physical_overlap.json')
    applied = read('effective_operating_point_overlap.json')
    trajectory = read('physical_trajectory_validity.json')
    ac_status = read('ac_reference_campaign_status.json')
    ac_compare = read('ac_reference_controller_comparison_summary.json')
    central = read('central_matched_summary.json')
    development = read('central_gpu_development_validation.json')
    central_physical = read('central_physical_replay/summary.json')
    protocol = read('central_experiment_protocol.json')
    bank_lock = read_json_ready(Path('work/e/bank/BANK_LOCK.json'))
    expected_ids = {Path(name).stem for name in bank_lock['scenario_file_sha256']}
    physical_rows = central_physical.get('cases', [])
    central_replays_valid = len(physical_rows) == 62 and {r.get('scenario_id') for r in physical_rows} == expected_ids and all(
        set(r.get('branches', {})) == {'HG-VF', 'CENTRAL-VF'} and all(
            (b.get('status') == 'replayed' and b.get('continuous_metrics_match_1e10') is True)
            or b.get('status') in {'saved_branch_exception_not_replayed', 'saved_initial_branch_failure_not_replayed'}
            for b in r['branches'].values()) for r in physical_rows)
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    def matches_source(key, filename):
        p = Path('work') / filename
        return p.exists() and protocol.get(key) == sha(p)
    gates = {
        'main_cases_and_rng_complete': main.get('checkpoint_checks', {}).get('cases') == 62 and main.get('checkpoint_checks', {}).get('rng_checkpoints') == 62,
        'frozen_assets_preserved': preservation.get('all_passed') is True,
        'archived_training_overlap_audited': overlap.get('locked_case_count') == 62,
        'applied_physical_inputs_audited': applied.get('locked_case_count') == 62 and applied.get('base_preserved') is True and applied.get('unknown_modifications_ignored_by_original_applicator') == [],
        'all_main_trajectory_replays_aggregated': trajectory.get('audited_case_count') == 62 and trajectory.get('trajectory_count') == 186 and trajectory.get('all_replay_input_and_source_hashes_match') is True and all(r.get('continuous_terminal_metrics_match_1e10') is True for r in trajectory.get('rows', [])),
        'ac_campaign_and_comparison_complete': ac_status.get('status') == 'complete' and ac_status.get('completed_count') == 62 and ac_compare.get('case_count') == 62,
        'central_gpu_development_passed_current_sources': development.get('passed') is True and development.get('central_source_sha256') == protocol.get('central_source_sha256') and development.get('runner_sha256') == protocol.get('runner_sha256') and matches_source('central_source_sha256', 'central_ablation.py') and matches_source('runner_sha256', 'run_central_experiment.py'),
        'central_full_bank_analysis_complete_current_source': central.get('case_count') == 62 and matches_source('analysis_source_sha256', 'analyze_central_campaign.py'),
        'central_all_case_and_rng_files_present': len(list((out / 'central_matched_campaign/cases').glob('*.json'))) == 62 and len(list((out / 'central_matched_campaign/rng').glob('*.pt'))) == 62,
        'central_all_case_physical_replays_complete': central_physical.get('audited_case_count') == 62 and central_replays_valid,
    }
    return {'all_required_experimental_evidence_complete': all(gates.values()), 'gates': gates,
            'open_gates': [name for name, passed in gates.items() if not passed]}
