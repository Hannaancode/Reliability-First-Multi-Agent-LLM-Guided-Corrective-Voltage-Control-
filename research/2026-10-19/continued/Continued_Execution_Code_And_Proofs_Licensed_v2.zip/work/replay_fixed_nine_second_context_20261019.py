"""Unchanged saved-policy analysis with one additional independently paid table.

All original receipts and adverse/UNKNOWN provenance retained. Zero new
physical/model/derivative/forecast/solve calls; no complete lifecycle claim.
"""
import ast,json
from pathlib import Path
import replay_fixed_nine_preserved_receipts_v3_20261019 as nine
import replay_fixed_receipts_with_next_context_20261019 as previous
from public118_slsqp_native_20261018 import R,read,sha
from fixed_three_query_core_20261019 import transform
B=R/'outputs/fixed_nine_second_context_policy_screen_20261019'
PREP=R/'outputs/fixed_nine_second_context_policy_preparation_20261019'
SECOND=R/'outputs/second_required_numeric_context_20261019'

def main():
    assert read(SECOND/'Completion.json')['exit_codes']=={'actual':0,'independent_audit':0}
    proof=read(SECOND/'independent_audit/Independent_Audit.json');assert proof['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
    assert read(SECOND/'Full_Native_Menu_ACK.json')['all_forecast_keys']==proof['forecasts']
    assert not B.exists() and not PREP.exists()
    text=Path(previous.__file__).read_text('utf-8');node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main');function='\n'.join(text.splitlines()[node.lineno-1:node.end_lineno])
    before="changed=transform(function,[(before,after)]);tree=ast.parse(changed)"
    after="""marker="    for ref in read(reuse/'All_Existing_Contexts.json'):"
        addition='''    newest=R/'outputs/second_required_numeric_context_20261019'
    newestproof=read(newest/'independent_audit/Independent_Audit.json')
    assert read(newest/'Completion.json')['exit_codes']=={'actual':0,'independent_audit':0}
    for relative,expected in read(newest/'actual/Closed_Manifest.json')['members'].items():assert sha(newest/'actual'/relative)==expected
    for key,value in read(newest/'actual/All_Current_Native_Forecasts.json').items():
        assert key not in forecasts;forecasts[key]=value['forecast']
    with np.load(newest/'actual'/(newestproof['identity']+'.npz'),allow_pickle=False) as z:newestcontext={k:z[k].copy() for k in z.files}
    assert identity(newestcontext)==newestproof['identity'] and newestproof['identity'] not in contexts
    contexts[newestproof['identity']]=newestcontext
    for ref in read(reuse/'All_Existing_Contexts.json'):'''
        assert after.count(marker)==1;after=after.replace(marker,addition)
        changed=transform(function,[(before,after)]);tree=ast.parse(changed)"""
    function=transform(function,[(before,after)])
    old="files=[Path(__file__),Path(original.__file__),R/'work/replay_paid_suffix_with_fixed_three_20261019.py',NUM/'Protocol.json',NUM/'Completion.json',NUM/'additive_menu_join_v2/Full_Native_Menu_ACK.json',NUM/'menu_join_repair_v2_preparation/Completion.json',NUM/'independent_audit/Independent_Audit.json',NUM/'actual/Closed_Manifest.json']"
    new=old+";files += [Path(nine.__file__),Path(previous.__file__),SECOND/'Protocol.json',SECOND/'Completion.json',SECOND/'independent_audit/Independent_Audit.json',SECOND/'actual/Closed_Manifest.json',SECOND/'Full_Native_Menu_ACK.json',nine.FOUR/'Protocol.json',nine.FOUR/'Completion.json',nine.FOUR/'audit/Independent_Audit.json',nine.FOUR/'custody_repair/Completion.json']"
    function=transform(function,[(old,new)]);ast.parse(function)
    env=previous.__dict__.copy();env.update(B=B,PREP=PREP,Registry=nine.Registry,nine=nine,SECOND=SECOND,previous=previous,__file__=__file__)
    exec(compile(function,__file__,'exec'),env);env['main']()
if __name__=='__main__':main()
