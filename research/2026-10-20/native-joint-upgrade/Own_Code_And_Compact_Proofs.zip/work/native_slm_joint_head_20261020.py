"""Native centralized coupled-action head. No free-text command, fallback or physics API."""
import torch
from torch import nn
class NativeJointHead(nn.Module):
    def __init__(self,width):
        super().__init__();self.width=width;self.linear=nn.Linear(width,3,dtype=torch.float32);nn.init.normal_(self.linear.weight,0,.001);nn.init.zeros_(self.linear.bias)
    def forward(self,hidden,last_q):
        if hidden.ndim!=2 or hidden.shape[1]!=self.width or last_q.shape!=(hidden.shape[0],3):raise ValueError('Exact native global-state/3actuator shape required')
        if not torch.isfinite(hidden).all() or not torch.isfinite(last_q).all():raise ValueError('Nonfinite state')
        u=torch.tanh(self.linear(hidden.float()))*torch.tensor(.3,dtype=torch.float32,device=hidden.device)
        if not torch.isfinite(u).all():raise ValueError('Nonfinite native command')
        return {'u_mvar':u,'next_q_mvar':last_q.float()-u}
