"""Prospective complete author cohort closure and no-old-physics-attempt gate."""
import ast,copy,hashlib,json,pickle,shutil,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/public13_full_cohort_preparation_20261021'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);began=time.monotonic()
    import candidate_process_runtime,sys
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np
    from run_public13_remaining_published_cohort_20261021 import regime,metrics
    roster=ROOT/'outputs/stable_ddpg_native500_input_roster_20261020';recipes=np.load(roster/'All500_Native_Physical_Input_Recipes.npz');base=pickle.loads((ROOT/'outputs/stable_ddpg_native_engineering_20261020/PF0_before.pkl').read_bytes());assert len(base.bus)==13 and len(base.sgen)==12
    # Includes primary and independent attempt inputs, failed attempts as well as
    # returns. Regime proof is for this exact source13 plant, not universal history.
    scopes=['stable_ddpg_native_engineering_20261020','stable_ddpg_native_remaining_engineering_v2_20261020','stable_ddpg_native_episode_20261020','native_action_upgrade_support_20261020','native_action_upgrade_support_independent_20261020','native_affine_physics_support_20261020','native_affine_physics_independent_20261020','native_full_grid_affine_gate_20261020','native_full_grid_affine_independent_20261020','native_fit_teacher_execution_20261020','native_fit_teacher_independent_20261020','native15_saved_command_physics_20261020','native15_saved_command_physics_independent_20261020']
    paid=set();scanned=[]
    for name in scopes:
        folder=ROOT/'outputs'/name;assert folder.is_dir()
        for path in sorted(folder.rglob('*before.pkl')):
            net=pickle.loads(path.read_bytes());assert len(net.bus)==13
            reg=regime(net);paid.add(reg);scanned.append({'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path),'regime':reg})
    assert scanned and regime(base) in paid
    regimes={}
    for seed in range(500):
        net=copy.deepcopy(base)
        for n,tab,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:net[tab][col]=recipes[n][seed].copy()
        regimes[str(seed)]=regime(net)
    assert len(set(regimes.values()))==500 and regimes['0'] in paid
    intersections=[s for s in range(1,500) if regimes[str(s)] in paid];assert not intersections,'Previously executed author-case regimes must be reused, never rerun'
    assert shutil.disk_usage(ROOT).free>10*1024**3
    sources=['work/run_public13_remaining_published_cohort_20261021.py','work/audit_public13_remaining_published_cohort_20261021.py','work/coordinate_public13_cohort_20261021.py','work/stable_ddpg_native_bridge_20261020.py','work/native_upgrade_support_engine_20261020.py','work/candidate_process_runtime.py','work/candidate_process_evidence_utils.py','work/coordinate_single_source_bound_owner_20261020.py','work/coordinate_native_inverter_linear_reference_20261020.py']
    author=ROOT/'outputs/stable_ddpg_author_intake_20261020/author_reference'
    sources +=[(author/n).relative_to(ROOT).as_posix() for n in ['safeDDPG.py','env_single_phase_13bus.py','pandapower models/pandapower models/case_13.mat']]
    for algorithm in ['safe-ddpg','linear','ddpg']:
        sources +=[(author/f'checkpoints/single-phase/13bus/{algorithm}/policy_net_checkpoint_a{i}.pth').relative_to(ROOT).as_posix() for i in range(3)]
    graph='outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz';recipe=(roster/'All500_Native_Physical_Input_Recipes.npz').relative_to(ROOT).as_posix();sources +=[graph,recipe,(roster/'All500_Ordered_Identities.json').relative_to(ROOT).as_posix(),(roster/'Independent_Input_Audit.json').relative_to(ROOT).as_posix()]
    seed0='outputs/stable_ddpg_native_episode_20261020/Result.json';assert json.loads((ROOT/seed0).read_text())['status'].startswith('COMPLETE_');sources.append(seed0)
    for n in sources:
        if n.endswith('.py'):ast.parse((ROOT/n).read_text(encoding='utf-8'))
    # Labelled counterfactual checks exercise input/action/endpoint invariants;
    # no model/PF/physics-converter/numerical solve is invoked in this preparation.
    assert regime(base)==regimes['0'];perturbed=copy.deepcopy(base);perturbed.sgen.at[0,'q_mvar']+=.01;assert regime(perturbed)==regime(base);perturbed.sgen.at[0,'p_mw']+=1e-6;assert regime(perturbed)!=regime(base)
    assert metrics(np.array([.949,1.051]))['full_band_restored'] is False and metrics(np.array([.95,1.05]))['full_band_restored'] is True
    p={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PROSPECTIVE_SOURCE_NATIVE_ALL500_EXTERNAL_BASELINE_COHORT_ONLY','science_seconds':1800,'reader_seconds':1800,'binary_preservation_cap_bytes':4*1024**3,'primary_coordination':'outputs/public13_remaining_published_coordination_20261021','algorithms':['safe-ddpg','linear','ddpg'],'remaining_author_seeds':list(range(1,500)),'all_author_seeds':list(range(500)),'recipes':recipe,'graph':graph,'remaining_regimes':{str(s):regimes[str(s)] for s in range(1,500)},'paid_prior_regimes':sorted(paid),'paid_history_scope':scopes,'prior_before_inputs_checked':len(scanned),'seed0_closed_evidence':seed0,'source_and_input_hashes':{n:sha(ROOT/n) for n in sources},
       'full_system_comparison_connection':'External baseline evidence stage. Our paper/native-port/new/hybrid rows remain UNKNOWN until their separately frozen matched policies run. Baseline completion does not close G3 or prove ours better.',
       'native_contract':'Exact author13 environment3controlledbus strict done and100step horizon, native action lastQ-clip(raw,-.3,.3); no added absoluteQcap/HierGridguard/return shaping. Record all13 bus voltages and native vs allbus success separately.',
       'information':'Published checkpoint policies consume three local scalar voltages, no claimed equal-information or LLM advantage versus centralized full-Y numerical methods.',
       'existing_seed0_not_repeated':True,'root_policy_PF_failure':'Retain all attempts/returns/failures; no failed PF repetition, fallback initializer or favorable-case omission. Unentered/partial are UNKNOWN, not negative.',
       'independent_reader':'One pinned reader after exact scientist chain ended/exit0/closed manifest. One charged fresh independent PF per new primary returned identity, all numeric fields1e-10, KCL<=1e-7, continuous policy and cold cursor replay; original failed PF not repeated.',
       'release_and_cost':'All9checkpoint loads/agent forwards/unique primaryPF/reuses/independent model+PF/preparation/converter/failure workflows separately paid; immutable values and nine original frozen checks before/after.',
       'no_training_outcome_retune_or_superiority_guarantee':True,'not_unused_confirmation':'Allcase/sourceinputs registered; seed0development. Full cohort remains external author test reproduction, not proof of absence of training overlap or unused universal confirmation.'}
    put(OUT/'Prior_Actual_Attempt_Regime_Closure.json',{'source_scopes':scopes,'all_before_inputs':scanned,'distinct_paid_regimes':len(paid),'new499_intersections':intersections,'all500_unique':True,'new_model_PF_converter_optimizer_derivative_solve_calls':0})
    put(OUT/'Protocol.json',p)
    for name,source,output,coord in [('Primary','work/run_public13_remaining_published_cohort_20261021.py','outputs/public13_remaining_published_cohort_20261021',p['primary_coordination']),('Reader','work/audit_public13_remaining_published_cohort_20261021.py','outputs/public13_published_cohort_independent_20261021','outputs/public13_published_reader_coordination_20261021')]:
        assert not (ROOT/output).exists() and not (ROOT/coord).exists();put(OUT/f'{name}_Owner_Protocol.json',{'single_owner':{'source':source,'sha256':sha(ROOT/source),'output':output,'coordination':coord,'python':'work/vcsa_module_env/Scripts/python.exe','bound_seconds':1900}})
    put(OUT/'Readiness.json',{'status':'PASS_SOURCE_NATIVE499_FRESH_REGIMES_SOURCE_READER_LOCK_PERSISTENCE_CONTRACT_SOFTWARE','old_paid_before_inputs':len(scanned),'unique_old_regimes':len(paid),'all499_new_regimes_disjoint':True,'registered_native_baseline_cases_including_reused0':500,'protocol_sha256':sha(OUT/'Protocol.json'),'new_model_PF_converter_optimizer_derivative_solve_calls':0,'workflow_seconds':time.monotonic()-began})
    print(json.dumps({'status':'PASS_PROSPECTIVE_NATIVE_BASELINE_COHORT','prior_before_inputs':len(scanned),'paid_regimes':len(paid),'remaining_cases':499,'all_cases':500}))
if __name__=='__main__':main()
