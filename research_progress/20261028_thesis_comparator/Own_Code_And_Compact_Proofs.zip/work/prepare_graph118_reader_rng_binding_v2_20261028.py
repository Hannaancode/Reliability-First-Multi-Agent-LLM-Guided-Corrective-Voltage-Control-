"""Additive initial-RNG binding repair; preserve every original audit check."""
import ast
from graph118_native_campaign_core_20261028 import *
Q=R/'outputs/graph118_reader_rng_binding_v2_preparation_20261028'
def main():
    from coordinate_native_inverter_linear_reference_20261020 import process
    for folder,source in [(E,'run_graph118_native_campaign_20261028.py'),(A,'audit_graph118_native_campaign_20261028.py'),(R/'outputs/graph118_native_campaign_handoff_20261028','coordinate_graph118_native_campaign_20261028.py')]:
        claim=read(folder/'owner.claim')
        for pid in [claim['actual_pid'],claim['parent_pid']]:
            current=process(pid);assert current is None or source not in current.get('CommandLine','')
    f=read(A/'Failure.json');assert f['first_replay_attempts']==f['first_replay_returns']==0
    assert f['message']=='CONTINUOUS_PRE_STATE.python_rng[1][1]:value'
    assert not (A/'Replay_Attempts.jsonl').exists()
    np,pp=setup()
    from published_graph118_episode_engine_v2_20261026 import NativeGraphEpisode
    from exact_graph_cursor_compare_20261023 import require_same
    Q.mkdir(exist_ok=False);source=R/'work/audit_graph118_native_campaign_20261028.py';text=source.read_text('utf-8')
    anchor="            for name in case['calls']:\n";assert text.count(anchor)==1
    insertion="""            # Old paid first-action cursors predate RNG preservation. Bind the
            # actual primary case-entry RNG, while requiring every other old
            # cursor field to match. All later full RNG checks stay unchanged.
            import random
            first_path=E/case['calls'][0]
            first_saved=decode(first_path.parent,read(first_path)['pre_state'])['episode']
            initial=episode.snapshot()
            for key in ['python_rng','numpy_rng']:initial[key]=copy.deepcopy(first_saved[key])
            require_same(initial,first_saved,'ORIGINAL_CURSOR_ALL_NON_RNG_FIELDS')
            random.setstate(first_saved['python_rng']);np.random.set_state(first_saved['numpy_rng'])
"""
    header="from graph118_native_campaign_core_20261028 import *\n"
    replacement=header+"A=R/'outputs/graph118_native_campaign_independent_rng_v2_20261028'\nrepair=read(R/'outputs/graph118_reader_rng_binding_v2_preparation_20261028/Protocol.json')\nassert sha(__file__)==repair['new_reader_sha256']\n"
    edited=text.replace(header,replacement,1).replace(anchor,insertion+anchor,1)
    # Removing only the declared binding and namespace recovers exact old source.
    assert edited.replace(replacement,header,1).replace(insertion,'',1)==text
    new=R/'work/audit_graph118_native_campaign_rng_v2_20261028.py';assert not new.exists();new.write_text(edited,encoding='utf-8')
    roots=read(OLD/'Saved_Transition_And_Cursor_Readiness.json')['rows'];primary=read(E/'Result.json');checks=[]
    for i,(meta,case) in enumerate(zip(roots,primary['cases'])):
        old=decode(OLD,meta['cursor']);assert 'python_rng' not in old and 'numpy_rng' not in old
        d=Q/f'case_{i:02d}';d.mkdir();obj=NativeGraphEpisode.restore(d,old)
        first=E/case['calls'][0];saved=decode(first.parent,read(first)['pre_state'])['episode'];current=obj.snapshot()
        for key in ['python_rng','numpy_rng']:current[key]=copy.deepcopy(saved[key])
        require_same(current,saved,'ALL_ACTUAL_CASE_ENTRY_NON_RNG_FIELDS')
        checks.append(dict(case_id=case['case_id'],old_cursor_has_no_RNG=True,all_non_RNG_fields_exact=True,actual_case_entry_RNG_preserved=True))
    put(Q/'Protocol.json',dict(status='PROSPECTIVE_MECHANICAL_INITIAL_RNG_BINDING_ONLY',old_reader_sha256=sha(source),new_reader_sha256=sha(new),
        original_failure_sha256=sha(A/'Failure.json'),first_replays_already_entered=0,all_old_assertions_retained=True,exact_source_recovery_after_removing_declared_insert=True,checks=checks,
        new_primary_PF_model_calls=0,first_independent_unentered_return_replays=primary['costs']['new_PF_returns'],
        bounds=dict(reader_scientific_seconds=7200,reader_process_seconds=7500),initial_RNG='Actual primary case-entry RNG, not invented historical RNG; independent cases have separate entry anchors. All subsequent full RNG comparisons retained.'))
    print(json.dumps(dict(status='PASS_EXACT_SOURCE_REPAIR_AND_ALL4_ENTRY_BINDINGS',old_replays=0,first_replays_pending=primary['costs']['new_PF_returns'])))
if __name__=='__main__':main()
