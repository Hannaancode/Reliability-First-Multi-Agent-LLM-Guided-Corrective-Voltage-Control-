"""Complete a control-only log update after the exclusive-write status failure."""
import json, subprocess
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import read,sha,write,seal
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'outputs/critical_research_reset_20261010';OUT=R/'public_size_production_launch_handoff'
assert not (OUT/'Local_Archive_Audit.json').exists()
checkpoint=read(OUT/'Verified_Launch_Checkpoint.json')
for record in checkpoint['actual_processes']:
    pid=record['ProcessId'];query=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"
    observed=subprocess.run(['powershell','-NoProfile','-Command',query],capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert observed.returncode==0 and observed.stdout.strip()==record['CommandLine']
write(OUT/'Control_Log_Failure.json',{'failure':'Exclusive new-artifact write helper cannot overwrite live latest_execution_status.json; headers/checkpoint were already written',
 'source_sha256':sha(ROOT/'work/record_public_size_launch_checkpoint_20261010.py'),'new_scientific_calls':0,'repair':'Atomic live-status update and completion of pending progress entry/seal; no old scientific operation repeated'})
now=datetime.now(timezone.utc).isoformat();latest=ROOT/'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json'
value=read(latest);value.update(updated_at_utc=now,activity='paired_public_size_actual_T4_owner_and_bound_audit_continuation',actual_GPU_owner_running=True,
 actual_public_size_launch_checkpoint=checkpoint,next_safe_work='Observe exact live owner and bound handoff; one independent reader after actual closed artifacts and exact release. No duplicate launch.',overall_research_goal='active_unachieved')
tmp=latest.with_name('latest_execution_status.public_size.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8');tmp.replace(latest)
entry={'event_id':'public_size_production_and_actual_T4_launch_20261010','method':'Fixed paired public Qwen2.5 0.5B/1.5B development diagnostic, identical prompts, one owned T4 and one bound audit continuation.',
 'result':'Production preparation and six tiny RANDOM CPU forwards passed. One actual T4 is allocated; actual owners were confirmed live. 62 generations and four engineering forwards are planned, not completed evidence. No1.5B benefit is claimed.',
 'improvements':'Before: metadata, tokenizer input checks and reader prototype. After: full frozen owner, per-response hashed preservation ACKs, raw logits and independent cold-load/output audit. Sixty reported failed solver labels stay known failures; all31 numerical control actions decoded from existing final scores, zero model reruns.',
 'limitations':'Only21 of31 selected states have saved measured candidate labels; nine are initially healthy. Missing/invalid outcomes remain; stronger numerical controls see full tables. Historical development, not unused confirmation. Uninstrumented prior preparation wall remains UNKNOWN/notfree. Not full DSE superiority or pure size causation.',
 'decision':'Continue exact owner/handoff only. No duplicate, scientific retry, profile fallback, setting sweep or automatic training/physical campaign. Overall goal remains active/unachieved.',
 'sources':['outputs/critical_research_reset_20261010/public_size_production_launch_handoff/Verified_Launch_Checkpoint.json','outputs/critical_research_reset_20261010/public_size_production_preparation_v4/protocol.json','outputs/critical_research_reset_20261010/public_size_production_preparation_v4/Launch_Readiness_Audit.json','outputs/critical_research_reset_20261010/public_size_production_software_readiness/Software_Readiness.json']}
write(OUT/'Progress_Entry.json',entry)
subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8','work/append_research_progress.py','--entry-json',str(OUT/'Progress_Entry.json')],cwd=ROOT,check=True)
files={p.name:p for p in OUT.iterdir() if p.is_file()}
prep=R/'public_size_production_preparation_v4'
for name in ['protocol.json','Launch_Readiness_Audit.json','Cloud_Payload_Manifest.json','Fixed_Label_Coverage.json','Fresh_Frozen_Preservation.json']:files['preparation/'+name]=prep/name
files['source/original_log_writer.py']=ROOT/'work/record_public_size_launch_checkpoint_20261010.py';files['source/completion.py']=Path(__file__)
print(json.dumps(seal(OUT,files,'Public_Size_Production_Launch_Handoff.zip')))
