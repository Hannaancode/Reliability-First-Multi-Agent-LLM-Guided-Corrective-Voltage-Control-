from pathlib import Path
import json,sys
sys.stdout.reconfigure(encoding='utf-8')
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack
v2,runner,ref=load_stack()
net=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'))
report={'pandapower':pp.__version__,'tables':{}}
for name in ['bus','load','gen','sgen','ext_grid','shunt','line','trafo','controller']:
 df=net[name];cols=[c for c in df.columns if any(s in c for s in ['min_','max_','controllable','vm_pu','p_mw','q_mvar','in_service','vn_kv','slack'])]
 report['tables'][name]={'rows':len(df),'columns':list(df.columns),'resource_fields':df[cols].reset_index().to_dict(orient='records')}
 print(name,'rows',len(df),'resource columns',cols)
 if name in ['gen','ext_grid','shunt']:print(df[cols].to_string())
Path('outputs/network_resource_audit.json').write_text(json.dumps(report,indent=2,default=str))
print('source PF functions retained; controller PF max_iteration=50')
