"""Write-once prospective exact identities; never infer newness from absence."""
import hashlib,json,os
from pathlib import Path
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from original_local_paid_branch_broker_v1 import resource_eligible
from shared_original_serving_action_domain_v1 import build_current_domain
R=Path(__file__).resolve().parents[1]
class UnclosedAttemptCoverage(RuntimeError):pass
class AlreadyAttemptedIdentity(RuntimeError):pass
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def durable(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
class Reservations:
    def __init__(self,path,*,protocol,coverage,known_attempt_keys,runner,zones,restore_anchor=None):
        self.path=Path(path).resolve();assert self.path.is_relative_to(R)
        if coverage.get('status')!='PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE':raise UnclosedAttemptCoverage('A catalog or absent lineage key is not new-query permission')
        self.software_only=coverage.get('mode')=='SOFTWARE_FIXTURE_NO_PF'
        self.execution_authorized=False
        if not self.software_only:
            pointer=protocol['attempt_coverage_certificate'];certificate=(R/pointer['path']).resolve();assert certificate.is_relative_to(R)
            raw=certificate.read_bytes();assert digest(raw)==pointer['sha256'] and json.loads(raw)==coverage
            lock=protocol['independent_coverage_reader_lock'];lockpath=(R/lock['path']).resolve();assert lockpath.is_relative_to(R)
            raw=lockpath.read_bytes();assert digest(raw)==lock['sha256'];locked=json.loads(raw)
            assert digest((R/locked['reader_source']).read_bytes())==locked['reader_sha256']==coverage['reader_source_sha256']
            self.execution_authorized=True
        self.p=protocol;self.coverage=coverage;self.runner=runner;self.zones=zones
        self.protocol_sha256=digest(canon(protocol));self.known=set(known_attempt_keys)
        rows=protocol['exact_new_query_rows'];self.allowed={r['point_action_key']:r for r in rows}
        assert len(rows)==len(self.allowed)==2
        assert set(self.allowed)==set(coverage['exact_candidate_keys']) and not set(self.allowed)&self.known
        assert coverage['input_preparation_sha256']==protocol['input_preparation_sha256']
        self.source={'protocol_sha256':self.protocol_sha256,'coverage_sha256':digest(canon(coverage))}
        self.previous='0'*64;self.prefix=hashlib.sha256();self.count=0;self.states={}
        if restore_anchor is None:
            self.path.mkdir(exist_ok=False);durable(self.path/'Source_Anchors.json',self.source);self.stream=(self.path/'events.jsonl').open('xb')
        else:
            assert json.loads((self.path/'Source_Anchors.json').read_text())==self.source==restore_anchor['source_anchors']
            ledger=self.path/'events.jsonl';assert ledger.stat().st_size==restore_anchor['bytes'],'Torn/stale reservation cursor; no rollback'
            with ledger.open('rb') as f:
                for raw in f:
                    e=json.loads(raw);assert e['previous']==self.previous;self._apply(e['event'],e['data']);self.previous=digest(raw[:-1]);self.prefix.update(raw);self.count+=1
            assert self.count==restore_anchor['records'] and self.prefix.hexdigest()==restore_anchor['sha256'] and self.previous==restore_anchor['last_event_sha256']
            self.stream=ledger.open('ab')
    def _apply(self,event,d):
        key=d['point_action_key'];assert key in self.allowed and key not in self.known
        if event=='reserved_exact_identity_before_physics':
            if key in self.states:raise AlreadyAttemptedIdentity(key)
            assert d['declared_row']==self.allowed[key]['row'] and d['declared_role']==self.allowed[key]['role'];self.states[key]={'reservation':d,'started':None,'closed':None}
        elif event=='native_PF_intent_bound_to_exact_reservation':
            if key not in self.states or self.states[key]['started'] is not None:raise AlreadyAttemptedIdentity(key)
            self.states[key]['started']=d
        elif event=='native_PF_return_or_exception_preserved':
            assert key in self.states and self.states[key]['started'] is not None and self.states[key]['closed'] is None
            self.states[key]['closed']=d
        else:raise ValueError('Unsupported reservation event')
    def event(self,name,data):
        self._apply(name,data);raw=canon({'event':name,'data':data,'previous':self.previous})+b'\n'
        self.stream.write(raw);self.stream.flush();os.fsync(self.stream.fileno());self.previous=digest(raw[:-1]);self.prefix.update(raw);self.count+=1
    def reserve(self,net,cursor,row,*,role):
        if not bool(net.converged) or not bool((net.res_bus.vm_pu<.95).any()):raise UnclosedAttemptCoverage('No new voltage query at an unconverged or legal zero-UV terminal state')
        key=point_key(net,cursor)+'|'+action_key(row)
        if key not in self.allowed or key in self.known or key in self.states:raise AlreadyAttemptedIdentity('Unknown/old/already reserved identity cannot enter physics')
        assert self.allowed[key]['row']==row and self.allowed[key]['role']==role
        domain=build_current_domain(net,cursor,runner=self.runner,zones=self.zones)
        assert row in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] and resource_eligible(row,cursor)
        self.event('reserved_exact_identity_before_physics',{'point_action_key':key,'declared_row':row,'declared_role':role,'source_anchors':self.source})
        return key
    def start(self,key,*,PF_id,solver_kwargs,software_fixture=False):
        if not self.execution_authorized and not (self.software_only and software_fixture):raise UnclosedAttemptCoverage('Software fixture cannot authorize native PF')
        assert solver_kwargs==self.p['solver_kwargs']
        self.event('native_PF_intent_bound_to_exact_reservation',{'point_action_key':key,'PF_id':PF_id,'solver_kwargs':solver_kwargs,'software_fixture_no_PF':bool(software_fixture)})
    def closed(self,key,receipt):
        assert receipt['PF_id']==self.states[key]['started']['PF_id']
        self.event('native_PF_return_or_exception_preserved',{'point_action_key':key,'receipt_sha256':digest(canon(receipt)),'PF_id':receipt['PF_id'],'outcome':receipt['outcome']})
    def anchor(self):return {'path':str(self.path.relative_to(R)),'bytes':self.stream.tell(),'sha256':self.prefix.hexdigest(),'records':self.count,'last_event_sha256':self.previous,'source_anchors':self.source}
    def close(self):self.stream.close()
