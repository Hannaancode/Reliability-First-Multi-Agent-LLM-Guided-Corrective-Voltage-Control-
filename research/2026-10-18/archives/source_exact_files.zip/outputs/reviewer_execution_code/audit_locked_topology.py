"""Fixed topology/supply audit of locked cases; never repair/regenerate them."""
import copy,json,sys
from pathlib import Path
import pandapower as pp
import pandapower.topology as top
from frozen_physics_loader import ROOT,load_stack
from physical_replay_audit import save
sys.stdout.reconfigure(encoding='utf-8')
v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json');rows=[]
for p in sorted((ROOT/'bank/scenarios').glob('*.json')):
    net=copy.deepcopy(base);v2.v0.apply_scenario_to_net(net,json.loads(p.read_text()),zones);unsupplied=sorted(int(b) for b in top.unsupplied_buses(net));loads=[{'load':int(i),'bus':int(r.bus),'p_mw':float(r.p_mw)*float(r.scaling),'q_mvar':float(r.q_mvar)*float(r.scaling)} for i,r in net.load.iterrows() if bool(r.in_service) and int(r.bus) in unsupplied]
    if unsupplied:
        rows.append({'scenario_id':p.stem,'buses_without_a_frozen_slack_supply_path':unsupplied,'scheduled_unsupplied_loads':loads,'scheduled_unsupplied_p_mw':sum(r['p_mw'] for r in loads),'isolated_resource_tables':{name:[{'index':int(i),'bus':int(r.bus),'p_mw':float(r.get('p_mw',0)),'q_mvar':float(r.get('q_mvar',0))} for i,r in net[name].iterrows() if int(r.bus) in unsupplied and bool(r.get('in_service',True))] for name in ['gen','sgen','storage','ext_grid']}})
report={'locked_case_count':62,'cases_without_full_frozen_slack_connectivity':len(rows),'method':'pandapower 3.4.0 topology.unsupplied_buses with original switch/branch/in-service statuses; network unchanged','scope':'Reactive shunts alone cannot reconnect a bus to the frozen slack supply path; all affected cases remain in the bank and failure ledger. No grid-forming/slack reassignment or load shedding introduced.','cases':rows};save('outputs/locked_topology_audit.json',report)
print(json.dumps(report,indent=2))
