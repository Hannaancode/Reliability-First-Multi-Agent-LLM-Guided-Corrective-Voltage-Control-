"""Conditional preserved-prefix reader ONLY; no scientific retry or launch.

Prepare may run while science is live. Run is forbidden until original full
scientist/coordinator/reader chains ended and a real terminal partial exists.
The complete reader's physical/query/verifier/cursor/cost AST prefix is retained,
apart from explicitly recorded terminal-completeness assumptions. Full gate is
ALWAYS UNKNOWN. No selected-prefix aggregate is substituted for all4 outcomes.
"""
import argparse, ast, copy, hashlib, json, os, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
B = R/'outputs/full_joint_suffix_benchmark_20261014'
PREP = B/'conditional_prefix_reader_preparation'
OUT = B/'partial_audit_v1'
OLD_SOURCE = R/'work/full_joint_suffix_benchmark_20261014.py'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def put(path, value):
    with path.open('x', encoding='utf8') as file:
        json.dump(value, file, indent=2, allow_nan=False); file.flush(); os.fsync(file.fileno())

def original_source_absent():
    cmd = "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -match 'full_joint_suffix_benchmark_20261014.py' } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    result = subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',cmd],
        capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0
    return not result.stdout.strip()

def derive():
    tree = ast.parse(OLD_SOURCE.read_text('utf8'))
    original = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit')
    derived = copy.deepcopy(original)
    body = next(n for n in derived.body if isinstance(n,ast.Try))
    old_body = next(n for n in original.body if isinstance(n,ast.Try))
    boundary = next(i for i,n in enumerate(body.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='worlds' for t in n.targets))
    prefix = body.body[:boundary]
    replacements = {
        "end['exit_code'] == 0": "end['exit_code'] != 0",
        "process(end['actual_pid']) is None and process(end['launcher_pid']) is None": "_original_source_absent()",
        "manifest['exit_code'] == 0": "manifest['exit_code'] == end['exit_code']",
        "results['exit_code'] == 0": "results['exit_code'] == end['exit_code']",
        "completed == [(world, method) for world in p['all_four_fixed_worlds'] for method in METHODS]":
            "completed == [(world, method) for world in p['all_four_fixed_worlds'] for method in METHODS][:len(completed)]",
        "commits_checked == checkpoints_checked == costs['continuous_replay_PF_attempts']":
            "0 <= checkpoints_checked <= commits_checked == costs['continuous_replay_PF_attempts']"}
    counts = {k:0 for k in replacements}
    class Change(ast.NodeTransformer):
        def __init__(self,mapping,count=None):self.mapping=mapping;self.count=count
        def visit_Assert(self,node):
            key = ast.unparse(node.test)
            if key in self.mapping:
                if self.count is not None:self.count[key]+=1
                node.test=ast.parse(self.mapping[key],mode='eval').body
            return self.generic_visit(node)
    mapped = [Change(replacements,counts).visit(n) for n in prefix]
    assert all(count==1 for count in counts.values()),counts
    inverse = {v:k for k,v in replacements.items()}
    restored = [Change(inverse).visit(copy.deepcopy(n)) for n in mapped]
    assert [ast.dump(n,include_attributes=False) for n in restored] == [ast.dump(n,include_attributes=False) for n in old_body.body[:boundary]]
    # Preserve the entire functional event-processing prefix, including all
    # recorded initial/source/action/score/cap/query/commit/cold/cost assertions.
    supplemental = ast.parse('''
full_order=[(world,method) for world in p['all_four_fixed_worlds'] for method in METHODS]
assert completed==full_order[:len(completed)]
assert len(results['branches'])<=len(completed)
put(out/'Independent_Preserved_Prefix_Audit.json',{
    'status':'PASS_RECORDED_CLOSED_QUERY_COMMIT_CHECKPOINT_AND_COST_PREFIX_ONLY',
    'full_all_four_fixed_gate':'UNKNOWN_TERMINAL_PARTIAL',
    'original_owner_exit_code':end['exit_code'],
    'verified_completed_prefix_branch_identities':completed,
    'declared_original_branch_identities':full_order,
    'missing_branch_identities_UNKNOWN':[x for x in full_order if x not in completed],
    'recorded_source_closed_branch_snapshots_descriptive_ONLY':results['branches'],
    'query_identities_checked':query_checked,
    'actual_commits_checked':commits_checked,
    'complete_checkpoints_checked':checkpoints_checked,
    'commits_missing_complete_checkpoint_UNKNOWN':commits_checked-checkpoints_checked,
    'actual_costs':costs,
    'last_declared_decision_identities':declared,
    'last_declared_decision_closed_receipts':len(returned),
    'last_decision_full_evidence_UNKNOWN':len(returned)!=len(declared) if declared is not None else True,
    'available_or_closed_prefix_NOT_SELECTED_FULL_PERFORMANCE':True,
    'new_model_PF_optimizer_forecast_derivative_solve_calls':0,
    'saved_result_callbacks_are_existing_evidence_NOT_new_physical_replay':True,
    'full_DSE_LLMattribution_novelty_or_confirmation':'NOT_TESTED',
    'fresh_nine_frozen':frozen_checks(),
    'audit_seconds_before_manifest':time.perf_counter()-begun})
put(out/'Partial_Gate_Status.json',{'all_four_fixed_primary_gate':'UNKNOWN',
    'terminal_partial_is_not_negative_or_passed_science':True,
    'old_source_claims_failures_costs_preserved':True,
    'scientific_retry_or_budget_extension':False})
put(out/'Result.json',{'exit_code':0,'status':'PRESERVED_PREFIX_AUDIT_ONLY',
    'full_all_four_gate':'UNKNOWN','no_new_scientific_calls':True})
code=0
''').body
    body.body = mapped+supplemental
    # New output/claim scope only. Never write into the original reader folder.
    first = next(n for n in derived.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='out' for t in n.targets))
    first.value = ast.parse("B/'partial_audit_v1'",mode='eval').body
    derived.name='conditional_preserved_prefix_audit'
    certificate = {'original_complete_reader_source_sha256':sha(OLD_SOURCE),
        'new_conditional_reader_source_sha256':sha(Path(__file__)),
        'entire_original_functional_event_processing_prefix_reverse_AST_exact':True,
        'only_functional_prefix_changes':replacements,'change_counts':counts,
        'all_original_source_input_action_equation_scope_score_cap_commit_replay_checkpoint_present_cost_checks_retained':True,
        'only_full_completeness_interpretation_relaxed':True,
        'partial_missing_or_unexecuted_never_negative_or_passed_performance':True,
        'no_prefix_wins_losses_or_selected_subset_performance_aggregate':True,
        'original_live_scientific_and_complete_reader_source_unchanged':True,
        'new_model_PF_forecast_solve_calls':0}
    return ast.fix_missing_locations(derived),certificate

def prepare():
    PREP.mkdir(exist_ok=False); derived,certificate=derive()
    compile(ast.Module(body=[derived],type_ignores=[]),'<conditional preserved prefix only>','exec')
    put(PREP/'Static_Prefix_Reader_Readiness.json',certificate)
    put(PREP/'Conditional_Analysis_Protocol.json',{
        'prepared_at_utc':datetime.now(timezone.utc).isoformat(),
        'status':'PREPARED_ONLY_NOT_STARTED',
        'source_sha256':sha(Path(__file__)),'original_source_sha256':sha(OLD_SOURCE),
        'activation':'Only AFTER actual fullscientist/launcher/coordinator/anyoriginalreader ENDED and Completion.science_exit!=0/reader_exitNone, exact closedpartialmanifest and passed actualcoldcheckpoint available.',
        'exclusive_reader':True,'new_output':str(OUT.relative_to(R)),
        'old_scientific_settings_source_budgets_and_failure_provenance_unchanged':True,
        'all_four_original_primary_gate':'ALWAYS_UNKNOWN_FOR_THIS_READER',
        'new_model_PF_optimizer_forecast_derivative_solve_jobs':0,
        'preservation_analysis_only_no_scientific_rerun_or_extension':True})
    print(json.dumps({'conditional_reader_prepared':True,'science_jobs_or_readers_started':0,'original_checks_reverse_AST_exact':True}))

def reader_claim(out):
    out.mkdir(exist_ok=False)
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),
        'protocol_sha256':sha(PREP/'Conditional_Analysis_Protocol.json'),'argv':sys.argv})
    start=time.perf_counter()
    while not (out/'Launcher_ACK.json').exists():
        assert time.perf_counter()-start<90;time.sleep(.1)
    ack=read(out/'Launcher_ACK.json')
    assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_PID_parent_command']

def reader():
    protocol=read(PREP/'Conditional_Analysis_Protocol.json'); assert sha(Path(__file__))==protocol['source_sha256']
    assert sha(OLD_SOURCE)==protocol['original_source_sha256']
    assert original_source_absent()
    completion=read(B/'Completion.json')
    assert completion['all_owned_chains_ended'] and completion['science_exit']!=0 and completion['reader_exit'] is None
    assert read(B/'cold/Result.json')['status']=='PASS_ACTUAL_COLD_COMPLETE_CONTROLLER_CHECKPOINT'
    import full_joint_suffix_benchmark_20261014 as original
    derived,certificate=derive()
    assert certificate==read(PREP/'Static_Prefix_Reader_Readiness.json')
    env=original.__dict__.copy();env.update(claim=reader_claim,_original_source_absent=original_source_absent)
    exec(compile(ast.Module(body=[derived],type_ignores=[]),'<source-preserved conditional prefix reader>','exec'),env)
    env['conditional_preserved_prefix_audit']()

def run():
    assert original_source_absent()
    completion=read(B/'Completion.json')
    assert completion['all_owned_chains_ended'] and completion['science_exit']!=0 and completion['reader_exit'] is None
    assert not OUT.exists()
    from equal_operation_benchmark_v2 import process
    with (B/'partial_reader_console.log').open('x',encoding='utf8') as log:
        child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--reader'],
            stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        start=time.perf_counter()
        while not (OUT/'owner.claim').exists():
            assert child.poll() is None and time.perf_counter()-start<90;time.sleep(.1)
        claim=read(OUT/'owner.claim');actual=process(claim['actual_pid'])
        assert actual and actual['ParentProcessId']==child.pid and Path(__file__).name in actual['CommandLine'] and '--reader' in actual['CommandLine']
        put(OUT/'Launcher_ACK.json',{'actual_pid':claim['actual_pid'],'actual_parent_pid':child.pid,'fresh_PID_parent_command':True})
        code=child.wait()
    put(B/'Partial_Reader_End_ACK.json',{'exit_code':code,'actual_pid':claim['actual_pid'],'launcher_pid':child.pid,
        'actual_reader_chains_ended':True,'original_science_rerun':False})
    print(json.dumps({'partial_reader_exit':code,'full_original_gate':'UNKNOWN','source':str(OUT)}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--reader',action='store_true');parser.add_argument('--run',action='store_true')
    args=parser.parse_args();assert sum(vars(args).values())==1
    if args.prepare:prepare()
    elif args.reader:reader()
    else:run()
