"""Fail-fast observer for a future inference protocol, not a logits repair.

Register on the actual causal-model forward output before generation processors.
The caller must persist the emitted event and bind the source/runtime/owner. No
weights, scores, tokens, precision, prompts or decisions are changed here.
"""
from dataclasses import dataclass,field
import math

class NumericalAdmissionFailure(RuntimeError):pass

@dataclass
class RawLogitObserver:
    emit:object
    calls:int=0
    failures:int=0
    shapes:list=field(default_factory=list)

    def __call__(self,module,args,output):
        logits=getattr(output,'logits',None)
        self.calls+=1
        if logits is None:
            self.failures+=1;self.emit({'kind':'raw_logit_failure','call':self.calls,'reason':'missing_named_logits'})
            raise NumericalAdmissionFailure('Missing raw logits; do not infer numerical validity from generated tokens.')
        # Tensor operations are imported only when the observer receives a real tensor.
        import torch
        shape=list(logits.shape);self.shapes.append(shape)
        finite=bool(torch.isfinite(logits).all().item())
        self.emit({'kind':'raw_logit_observation','call':self.calls,'shape':shape,'dtype':str(logits.dtype),
                   'all_finite':finite,'native_scores_modified':False})
        if not finite:
            self.failures+=1
            raise NumericalAdmissionFailure('Nonfinite raw logits. Preserve this attempt and stop; never replace or zero them.')
        return None

def check_saved_smoke_probe(record,expected_letter):
    """Check an unrelated declared probe; forbidden as a test-answer selector."""
    if expected_letter not in 'ABCD' or len(expected_letter)!=1:raise ValueError('invalid declared smoke target')
    failures=[]
    if record.get('raw_text','').strip()!=expected_letter:failures.append('unexpected_non_test_smoke_response')
    if record.get('raw_forward_calls',0)<1:failures.append('missing_raw_forward_observation')
    if record.get('all_raw_logits_finite') is not True:failures.append('nonfinite_or_unknown_raw_logits')
    if record.get('stopped_at_output_cap') is not False:failures.append('cap_termination_or_unknown')
    if record.get('cold_input_ids_equal') is not True:failures.append('cold_input_mismatch_or_unknown')
    if record.get('cold_output_token_ids_equal') is not True:failures.append('cold_output_mismatch_or_unknown')
    if record.get('cold_weight_identity_equal') is not True:failures.append('cold_weight_identity_mismatch_or_unknown')
    return {'pass':not failures,'failures':failures,'scope':'Predeclared synthetic engineering only; not test accuracy, model capability or scientific launch permission.'}

def adjudicate_existing_probe(raw_token_ids,warm_cold_equal,finite_evidence):
    """Classify already-saved probes without another model call or causal inference."""
    return {'warm_cold_equal':bool(warm_cold_equal),'degenerate_single_token_stream':len(raw_token_ids)>1 and len(set(raw_token_ids))==1,
            'raw_logits_finite':finite_evidence if isinstance(finite_evidence,bool) else 'UNKNOWN',
            'numerical_admission':bool(finite_evidence is True and len(set(raw_token_ids))>1),
            'causal_nan_or_overflow_diagnosis':'UNKNOWN_FROM_TOKENS_ALONE'}

def fixed_synthetic_probe_spec():
    return {'schema':'synthetic_only_admission_v1','probes':[{'id':'echo_B','prompt':'This is a formatting check. Reply with exactly the uppercase letter B and nothing else.','expected':'B'},
        {'id':'echo_C','prompt':'This is a formatting check. Reply with exactly the uppercase letter C and nothing else.','expected':'C'}],
        'max_new_tokens':8,'decoding':'greedy','reuse_benchmark_questions':False,'send_labels_or_circuit':False,
        'primary_action_on_failure':'Preserve actual source, input IDs, raw-logit finite records, token IDs and costs; stop assigned engineering owner without fallback or retries.',
        'limitations':['Smoke validity does not guarantee useful circuit knowledge.','Finite logits do not guarantee correct output.','Two echo probes are not a scientific benchmark.','This module alone has no actual loader, owner, GPU, preservation or launch readiness.']}
