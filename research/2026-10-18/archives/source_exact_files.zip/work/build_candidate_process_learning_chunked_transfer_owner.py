"""Control-only prelaunch transfer repair; exact scientific inputs unchanged."""
import ast
from pathlib import Path
from candidate_process_evidence_utils import ROOT,read,write,sha
PREP=ROOT/'outputs/llm_value_candidate_development_20261009/pretrained_learning_preparation'
old=ROOT/'work/run_candidate_process_pretrained_learning_colab.py';source=old.read_text()
oldblock=""" archive_raw=raw_file('content/hiergrid_execution/outputs/pilot_actual_outputs.zip')
 assert len(archive_raw)==descriptor['bytes'] and sha(archive_raw)==descriptor['sha256']
 archive=OUT/'preserved_remote_outputs.zip';preserve(archive,archive_raw)"""
newblock=""" archive=OUT/'preserved_remote_outputs.zip'
 chunks=[]
 for part in descriptor['parts']:
  local=OUT/'downloaded_archive_parts'/part['name']
  if not local.exists():preserve(local,raw_file('content/hiergrid_execution/outputs/pilot_output_parts/'+part['name']))
  assert local.stat().st_size==part['bytes'] and sha(local.read_bytes())==part['sha256']
  chunks.append(local)
 if not archive.exists():
  temporary=OUT/'preserved_remote_outputs.closed_transfer.tmp'
  with temporary.open('wb') as file:
   for part in chunks:
    with part.open('rb') as chunk:
     while raw:=chunk.read(1024*1024):file.write(raw)
   file.flush();os.fsync(file.fileno())
  assert temporary.stat().st_size==descriptor['bytes']
  digest=hashlib.file_digest(temporary.open('rb'),'sha256').hexdigest()
  assert digest==descriptor['sha256'];temporary.replace(archive)
 assert archive.stat().st_size==descriptor['bytes'] and hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()==descriptor['sha256']"""
assert source.count(oldblock)==1;source=source.replace(oldblock,newblock)
old_descriptor="""Path('outputs/pilot_output_descriptor.json').write_text(json.dumps({'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2))"""
new_descriptor="""part_root=Path('outputs/pilot_output_parts');part_root.mkdir()
parts=[]
with archive.open('rb') as file:
 while raw:=file.read(2*1024*1024):
  name='part_'+str(len(parts)).zfill(5)+'.bin';(part_root/name).write_bytes(raw)
  parts.append({'name':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with archive.open('rb') as file:archive_digest=hashlib.file_digest(file,'sha256').hexdigest()
Path('outputs/pilot_output_descriptor.json').write_text(json.dumps({'bytes':archive.stat().st_size,'sha256':archive_digest,'members':members,'parts':parts},indent=2))"""
assert source.count(old_descriptor)==1;source=source.replace(old_descriptor,new_descriptor)
marker="assert read(PREP/'Launch_Readiness_Audit.json')['passed']"
assert source.count(marker)==1
source=source.replace(marker,marker+"\n assert sha(Path(__file__).read_bytes())==read(PREP/'Launch_Readiness_Transfer_v2.json')['new_owner_source_sha256']")
ast.parse(source);tree=ast.parse(source)
launch=next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='launch' for x in n.targets));ast.parse(launch)
target=ROOT/'work/run_candidate_process_pretrained_learning_colab_chunked_v2.py'
with target.open('x') as file:file.write(source)
payload=read(PREP/'Cloud_Payload_Manifest.json')
write(PREP/'Launch_Readiness_Transfer_v2.json',{'passed':True,'reason':'Avoid a single base64 GET of allfive checkpoints from both arms; preserve actual2MiB chunks independently before release',
 'old_owner_source_sha256':sha(old),'new_owner_source_sha256':sha(target),'literal_launch_AST_parsed':True,
 'exact_private_bundle_unchanged':True,'exact_bytes':payload['bytes'],'exact_sha256':payload['sha256'],
 'scientific_sources_protocol_models_data_objective_and_counts_unchanged':True,'zero_new_model_optimizer_PF_cloud_calls':0})
print('SAME_SCIENCE_BUNDLE_SINGLE_OWNER_CHUNKED_PRESERVATION_READY')
