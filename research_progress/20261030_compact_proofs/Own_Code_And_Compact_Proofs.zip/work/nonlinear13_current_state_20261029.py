"""Current solved-state binding and complete decision-boundary cursor custody.

No solver, equation, derivative, pretrained-model or training calls. Original
initial binder/kernel sources remain untouched. Public production entry points
require an ACTUAL_SOLVED_RECEIPT cursor and the complete all500 initial certificate.
The --synthetic check exercises new cursor serialization only, not saved physics.
"""
import ast
import copy
import hashlib
import io
import json
import os
import pickle
import random
import sys
import time
from pathlib import Path

import numpy as np
from remaining85_certified_loader_20261029 import load_certified_case
from remaining85_source_binder_v2_20261029 import DataUnpickler, checked_bytes, physical_signature
from nonlinear13_validated_kernel_v2_20261029 import ValidatedNonlinearNative13

SCHEMA = 'NONLINEAR13_CURRENT_CURSOR_V1'
SOURCE_FILE = 'work/nonlinear13_current_state_20261029.py'
AUXILIARY_SOURCE = 'work/physics_env/Lib/site-packages/pandapower/auxiliary.py'
PQ_SOURCE = 'work/physics_env/Lib/site-packages/pandapower/build_bus.py'
ADMITTANCE_COLUMNS = list(range(13)) + list(range(21, 26))
INIT_OPTION_KEYS = {'init_vm_pu', 'init_va_degree', 'init_results'}
REQUIRED = {
    'schema', 'evidence_scope', 'seed', 'next_step', 'remaining_original_horizon',
    'stop_status', 'root_NET', 'current_NET', 'current_physical_signature',
    'current_Q', 'current_vm', 'history', 'paid_receipt', 'source_lock',
    'absolute_deadline_monotonic', 'original_deadline_monotonic', 'clock_domain',
    'owner_protocol_ref', 'rng_state', 'solver_state_ref', 'costs', 'cost_journal_ref',
    'historical_paid_index_ref', 'attempt_journal_ref', 'math_journal_ref',
    'physical_journal_ref', 'original_horizon', 'physical_kwargs',
}


def _need(condition, message):
    if not condition:
        raise ValueError(message)


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _verify_reference(root, ref):
    _need(isinstance(ref, dict) and {'path', 'sha256'} <= ref.keys(), 'Missing content-bound reference')
    p = (Path(root) / ref['path']).resolve()
    p.relative_to(Path(root).resolve())
    raw = p.read_bytes()
    if 'prefix_bytes' in ref:
        n = ref['prefix_bytes']
        _need(type(n) is int and 0 <= n <= len(raw), 'Invalid journal prefix bound')
        raw = raw[:n]
    _need(_sha(raw) == ref['sha256'], 'Reference changed: ' + ref['path'])
    return raw


def _network(root, ref):
    saved = DataUnpickler(io.BytesIO(_verify_reference(root, ref))).load()
    _need(ref.get('kind') in ('NET', 'ENV'), 'Unknown network container kind')
    return saved['network'] if ref['kind'] == 'ENV' else saved


def _validate_cursor(cursor, root_q, *, allow_synthetic=False):
    _need(REQUIRED <= cursor.keys(), 'Missing cursor fields: ' + ','.join(sorted(REQUIRED - cursor.keys())))
    _need(cursor['schema'] == SCHEMA, 'Unsupported cursor schema')
    _need(cursor['evidence_scope'] == 'ACTUAL_SOLVED_RECEIPT' or
          (allow_synthetic and cursor['evidence_scope'] == 'NEW_SYNTHETIC_CURSOR_ONLY'),
          'Synthetic/unverified cursor cannot enter production')
    _need(type(cursor['seed']) is int and 0 <= cursor['seed'] < 500, 'Unregistered seed')
    step = cursor['next_step']
    _need(type(step) is int and 1 <= step <= 101, 'Invalid source step cursor')
    _need(cursor['original_horizon'] == 100 and cursor['remaining_original_horizon'] == 101-step,
          'Horizon changed or renewed')
    deadline = cursor['absolute_deadline_monotonic']
    _need(np.isfinite(deadline) and deadline == cursor['original_deadline_monotonic'], 'Deadline changed or renewed')
    _need(isinstance(cursor['clock_domain'], str) and bool(cursor['clock_domain']), 'Missing host monotonic-clock identity')
    _need(cursor['stop_status'] in (None, 'ORIGINAL_GUARD_HOLD_STOP', 'ORIGINAL_HORIZON', 'BAND_COMPLETE', 'UNKNOWN'), 'Unknown stop status')
    _need(isinstance(cursor['costs'], dict) and bool(cursor['costs']) and
          all(isinstance(v, (int, float)) and not isinstance(v, bool) and np.isfinite(v) and v >= 0
              for v in cursor['costs'].values()), 'Missing or invalid accumulated costs')
    _need(isinstance(cursor['rng_state'], dict) and {'python', 'numpy', 'torch', 'cuda', 'solver'} <= cursor['rng_state'].keys(), 'Missing RNG custody fields')
    _need(cursor['solver_state_ref'] is None or isinstance(cursor['solver_state_ref'], dict), 'Invalid solver-state reference')
    _need(cursor['physical_kwargs'] == {'algorithm': 'bfsw', 'init': 'dc'}, 'Changed prospective physical initializer')
    hist = cursor['history']
    _need(isinstance(hist, list) and len(hist) == step-1, 'History/cursor discontinuity')
    q = np.asarray(root_q, dtype=float).copy()
    for i, d in enumerate(hist, 1):
        _need(d['step'] == i and type(d['accepted']) is bool, 'History order/admission invalid')
        _need(np.array_equal(d['before_Q'], q), 'History starts from a different committedQ')
        u = np.asarray(d['native_u'])
        _need(u.dtype == np.float32 and u.shape == (3,) and np.isfinite(u).all()
              and np.all(np.abs(u) <= np.float32(.3)), 'History contains a non-native action')
        candidate_q = q - u
        _need(np.array_equal(candidate_q, d['candidate_Q']), 'History action arithmetic changed')
        q = candidate_q if d['accepted'] else q
        _need(np.array_equal(q, d['committed_Q']), 'History committedQ changed')
        if not d['accepted']:
            _need(i == len(hist) and cursor['stop_status'] == 'ORIGINAL_GUARD_HOLD_STOP', 'Continued after first rejection')
        _need(isinstance(d['candidate_receipt_ref'], dict), 'History missing candidate receipt custody')
    _need(np.array_equal(q, cursor['current_Q']), 'CursorQ differs from complete committed action history')
    vm = np.asarray(cursor['current_vm'])
    _need(vm.shape == (13,) and np.isfinite(vm).all(), 'Invalid current all13VM')


def _verify_cursor_references(root, cursor):
    for name in ['owner_protocol_ref', 'cost_journal_ref', 'historical_paid_index_ref',
                 'attempt_journal_ref', 'math_journal_ref', 'physical_journal_ref']:
        _verify_reference(root, cursor[name])
    if cursor['solver_state_ref'] is not None:
        _verify_reference(root, cursor['solver_state_ref'])
    _need({SOURCE_FILE, AUXILIARY_SOURCE, PQ_SOURCE} <= cursor['source_lock'].keys(), 'Current-state/PQ grouping sources missing from source lock')
    for path, digest in cursor['source_lock'].items():
        _verify_reference(root, {'path': path, 'sha256': digest})
    for d in cursor['history']:
        _verify_reference(root, d['candidate_receipt_ref'])
    receipt = cursor['paid_receipt']
    actual_receipt = json.loads(_verify_reference(root, receipt['record_ref']))
    _need(all(actual_receipt.get(k) == receipt[k] for k in ['status', 'after', 'after_sha256', 'physical_signature', 'kwargs']),
          'Paid receipt fields are not bound to the preserved record')
    _need(receipt['status'] == 'RETURNED' and receipt['after'] == cursor['current_NET']['path']
          and receipt['after_sha256'] == cursor['current_NET']['sha256']
          and receipt['physical_signature'] == cursor['current_physical_signature'],
          'CurrentNET is not the declared returned paid receipt')
    # Initial roots retain their original paid initializer. Every subsequent
    # committed state must come from the prospective bfsw/dc physical contract.
    if cursor['next_step'] > 1 and any(d['accepted'] for d in cursor['history']):
        _need(receipt['kwargs'] == cursor['physical_kwargs'], 'Current receipt initializer mismatch')


def _source_order_PQ(root, net):
    """Exact source-order table aggregation; no equations/solver call.

    Preserve numpy vector product/grouping order from build_bus, using the
    original pure _sum_by_group body. Reject source element types not covered
    by this native13 role instead of silently dropping their injections.
    """
    for name in ['motor', 'storage', 'ward', 'xward', 'asymmetric_load', 'asymmetric_sgen', 'load_dc']:
        _need(len(net[name]) == 0, 'Unsupported PQ aggregation element: ' + name)
    b, p, q = np.array([], dtype=np.int64), np.array([]), np.array([])
    for name, sign in [('load', 1), ('sgen', -1)]:
        tab = net[name]
        if len(tab) == 0:
            continue
        active = np.asarray(net['_is_elements'][name]).astype(np.float64)
        scaling = tab['scaling'].values
        p = np.hstack([p, tab['p_mw'].values * active * scaling * sign])
        q = np.hstack([q, tab['q_mvar'].values * active * scaling * sign])
        b = np.hstack([b, tab['bus'].values])
    table = np.zeros((13, 2))
    if len(b):
        b = net['_pd2ppc_lookups']['bus'][b]
        parsed = ast.parse((Path(root)/AUXILIARY_SOURCE).read_text(encoding='utf-8'))
        fn = next(n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == '_sum_by_group')
        # Future annotations avoid importing optional typing/runtime packages;
        # the executed function body remains the pinned original AST.
        future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
        module = ast.fix_missing_locations(ast.Module(body=[future, fn], type_ignores=[]))
        namespace = {'np': np}
        exec(compile(module, AUXILIARY_SOURCE, 'exec'), namespace)
        grouped, vp, vq = namespace['_sum_by_group'](b, p, q)
        table[grouped, 0], table[grouped, 1] = vp, vq
    return table


def _bind_current(root, seed, current_ref, cursor):
    initial, cert = load_certified_case(root, seed)
    _need(cursor['root_NET'] == cert['root'] and cursor['current_NET'] == current_ref
          and cursor['seed'] == seed, 'Root/current/seed custody mismatch')
    _validate_cursor(cursor, initial.current_q)
    _verify_cursor_references(root, cursor)
    origin, net = _network(root, cert['root']), _network(root, current_ref)
    # All physical DataFrames are immutable except the three admitted Q cells;
    # result tables may change. This is broader than the old9-table signature.
    import pandas as pd
    names = {k for k, v in origin.items() if isinstance(v, pd.DataFrame) and not k.startswith('res_') and not k.startswith('_')}
    current_names = {k for k, v in net.items() if isinstance(v, pd.DataFrame) and not k.startswith('res_') and not k.startswith('_')}
    _need(names == current_names, 'Physical table set changed')
    for name in sorted(names):
        a, b = origin[name], net[name]
        if name == 'sgen':
            b = b.copy()
            _need(np.array_equal(b.index[:3], a.index[:3]), 'Native control row identity changed')
            b.loc[b.index[:3], 'q_mvar'] = a.iloc[:3]['q_mvar'].to_numpy()
        _need(a.equals(b), 'Noncontrolled physical table changed: ' + name)
    _need(physical_signature(net) == cursor['current_physical_signature'], 'Current physical signature mismatch')
    _need(net['converged'] and net['_ppc']['success'], 'Current receipt not marked converged')
    for key in ['load', 'sgen']:
        _need(np.array_equal(net['_is_elements'][key], origin['_is_elements'][key]), 'Source active-element mask changed: ' + key)
    opt, baseopt = net['_options'], origin['_options']
    _need(opt.keys() == baseopt.keys(), 'Physical solver option set changed')
    for key in opt:
        if key not in INIT_OPTION_KEYS:
            _need(np.array_equal(opt[key], baseopt[key]), 'Physical solver option changed: ' + key)
    if cursor['next_step'] > 1 and any(d['accepted'] for d in cursor['history']):
        _need(opt['init_va_degree'] == 'dc' and opt['init_results'] is False, 'New committed state has wrong initialization')
    pp, bp = net['_ppc'], origin['_ppc']
    bus, gen, branch = (np.asarray(pp[k]) for k in ['bus', 'gen', 'branch'])
    _need(bus.shape == initial.ppc_bus.shape and np.isfinite(bus).all(), 'Invalid currentPPC bus table')
    _need(gen.shape == initial.ppc_gen.shape and np.isfinite(gen).all(), 'Invalid currentPPC generator table')
    _need(np.array_equal(gen[:, [0, 7]], bp['gen'][:, [0, 7]]) and np.all(gen[:, 0] == 0), 'Non-slack generator/source role changed')
    _need(pp['baseMVA'] == bp['baseMVA'], 'baseMVA changed')
    static_bus = [0, 1, 2, 4, 5, 6, 9, 10, 11, 12, 13, 14, 15, 16, 17]
    _need(np.array_equal(bus[:, static_bus], bp['bus'][:, static_bus]), 'NoncontrolledPPC bus fields changed')
    _need(branch.shape == bp['branch'].shape and np.array_equal(branch[:, ADMITTANCE_COLUMNS], bp['branch'][:, ADMITTANCE_COLUMNS]), 'Static admittance fields changed')
    _need(all(np.array_equal(pp[k], bp[k]) for k in ['svc', 'ssc', 'vsc', 'tcsc', 'bus_dc', 'branch_dc']), 'Unsupported additional equipment changed')
    lookup = np.asarray(net['_pd2ppc_lookups']['bus'])[net['bus'].index.to_numpy()]
    control = np.asarray(net['_pd2ppc_lookups']['bus'])[net['sgen'].iloc[:3]['bus'].to_numpy()]
    _need(np.issubdtype(lookup.dtype, np.integer) and np.issubdtype(control.dtype, np.integer)
          and np.array_equal(lookup, initial.lookup) and np.array_equal(control, initial.control), 'Native maps changed')
    sgen = net['sgen'].iloc[:3]
    q = sgen['q_mvar'].to_numpy(dtype=float)
    vm = net['res_bus']['vm_pu'].to_numpy(dtype=float)
    _need(np.isfinite(q).all() and np.array_equal(q, cursor['current_Q']), 'NET/current cursorQ mismatch')
    _need(np.array_equal(vm, cursor['current_vm']) and np.array_equal(vm, bus[lookup, 7]), 'NET/PPC/current cursorVM mismatch')
    source_pq = _source_order_PQ(root, net)
    _need(np.array_equal(bus[:, [2, 3]], source_pq), 'Stale/mismatched currentPPC P/Q aggregation')
    _need(np.all(np.asarray(net['_is_elements']['sgen'])[:3]), 'A native control is inactive')
    V = bus[:, 7] * np.exp(1j * np.deg2rad(bus[:, 8]))
    kernel = ValidatedNonlinearNative13(initial.Y, V, bus, gen, pp['baseMVA'], lookup, control, vm, q,
                                      sgen['scaling'].to_numpy(dtype=float), sgen['in_service'].to_numpy(dtype=bool),
                                      opt['enforce_q_lims'], opt['distributed_slack'])
    _need(not kernel.costs and np.isfinite(kernel.injection0).all(), 'Unexpected evaluation or invalid injection context')
    return kernel, {'immutable_physical_tables_checked': sorted(names),
                    'current_PPC_PQ_source_order_aggregation_exact': True,
                    'scientific_evaluations': 0}


def pack_current_state(root, seed, current_NET_ref, cursor, output_path):
    """Write an exclusive full cursor, return (unevaluated kernel, reference).

    A content-bound returned receipt and exact source-order PPC P/Q aggregation
    are both required; a receipt alone cannot conceal stalePPC.
    """
    kernel, binding = _bind_current(root, seed, current_NET_ref, cursor)
    value = {'schema': SCHEMA, 'cursor': copy.deepcopy(cursor), 'binding': binding}
    raw = pickle.dumps(value, protocol=5)
    p = (Path(root) / output_path).resolve()
    p.relative_to(Path(root).resolve())
    with p.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return kernel, {'path': p.relative_to(Path(root).resolve()).as_posix(), 'sha256': _sha(raw), 'bytes': len(raw)}


def load_current_state(root, checkpoint_ref):
    value = DataUnpickler(io.BytesIO(_verify_reference(root, checkpoint_ref))).load()
    _need(value['schema'] == SCHEMA, 'Unknown packed cursor schema')
    c = value['cursor']
    kernel, binding = _bind_current(root, c['seed'], c['current_NET'], c)
    _need(binding == value['binding'], 'Cold current binding changed')
    return kernel, c


def synthetic_check(root):
    """A new labelled cursor fixture; never read an old physical root/model."""
    root = Path(root).resolve()
    out = root / 'outputs/nonlinear13_current_state_preparation_20261029/cold_v2'
    out.mkdir(exist_ok=False)
    stub = out / 'Synthetic_References.json'
    stub.write_text(json.dumps({'scope': 'NEW_SYNTHETIC_CURSOR_ONLY', 'not_a_physical_receipt': True}), encoding='utf-8')
    ref = {'path': stub.relative_to(root).as_posix(), 'sha256': _sha(stub.read_bytes())}
    q0 = np.zeros(3)
    u = np.array([-.125, .0625, -.03125], dtype=np.float32)
    q = q0-u
    netref = dict(ref, kind='NET')
    paid = {'status': 'RETURNED', 'after': ref['path'], 'after_sha256': ref['sha256'],
            'physical_signature': 'synthetic_not_a_physical_signature',
            'kwargs': {'algorithm': 'bfsw', 'init': 'dc'}}
    receipt_path = out/'Synthetic_Receipt.json'
    receipt_path.write_text(json.dumps(paid), encoding='utf-8')
    receipt_ref = {'path': receipt_path.relative_to(root).as_posix(), 'sha256': _sha(receipt_path.read_bytes())}
    paid['record_ref'] = receipt_ref
    c = dict(schema=SCHEMA, evidence_scope='NEW_SYNTHETIC_CURSOR_ONLY', seed=0, next_step=2,
             remaining_original_horizon=99, original_horizon=100, stop_status=None,
             root_NET=netref, current_NET=netref, current_physical_signature='synthetic_not_a_physical_signature',
             current_Q=q, current_vm=np.ones(13),
             history=[{'step': 1, 'accepted': True, 'before_Q': q0, 'native_u': u,
                       'candidate_Q': q, 'committed_Q': q, 'candidate_receipt_ref': receipt_ref}],
             paid_receipt=paid,
             source_lock={p: _sha((root/p).read_bytes()) for p in [SOURCE_FILE, AUXILIARY_SOURCE, PQ_SOURCE]},
             absolute_deadline_monotonic=1234567.0, original_deadline_monotonic=1234567.0,
             clock_domain='SYNTHETIC_FIXED_CLOCK_NOT_LIVE', owner_protocol_ref=ref,
             rng_state={'python': random.Random(71029).getstate(), 'numpy': np.random.RandomState(71029).get_state(),
                        'torch': None, 'cuda': None, 'solver': None}, solver_state_ref=None,
             costs={'PF_attempts': 0, 'nonlinear_equation_evaluations': 0, 'synthetic_decisions': 1},
             cost_journal_ref=ref, historical_paid_index_ref=ref, attempt_journal_ref=dict(ref, prefix_bytes=stub.stat().st_size),
             math_journal_ref=ref, physical_journal_ref=ref, physical_kwargs={'algorithm': 'bfsw', 'init': 'dc'})
    _validate_cursor(c, q0, allow_synthetic=True)
    _verify_cursor_references(root, c)
    raw = pickle.dumps(c, protocol=5)
    path = out/'Synthetic_Complete_Cursor.pkl'
    path.write_bytes(raw)
    cold = DataUnpickler(io.BytesIO(path.read_bytes())).load()
    _validate_cursor(cold, q0, allow_synthetic=True)
    def same(a, b):
        if isinstance(a, np.ndarray):
            return isinstance(b, np.ndarray) and a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes()
        if isinstance(a, dict):
            return isinstance(b, dict) and list(a) == list(b) and all(same(a[k], b[k]) for k in a)
        if isinstance(a, (list, tuple)):
            return type(a) is type(b) and len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
        return type(a) is type(b) and a == b
    _need(same(c, cold), 'Synthetic cursor field/array state changed')
    rejection = None
    try:
        _validate_cursor(cold, q0)
    except ValueError as exc:
        rejection = str(exc)
    _need(rejection == 'Synthetic/unverified cursor cannot enter production', 'Synthetic production gate failed')
    result = {'status': 'NEW_SYNTHETIC_FULL_CURSOR_COLD_CHECK_PASS_PREPARATION_ONLY',
              'source': {'path': SOURCE_FILE, 'sha256': _sha((root/SOURCE_FILE).read_bytes())},
              'synthetic_cursor': {'path': path.relative_to(root).as_posix(), 'sha256': _sha(raw), 'bytes': len(raw)},
              'complete_cursor_fields_array_bytes_dtypes_shapes_exact': True, 'synthetic_rejected_for_production': True,
              'pickle_reserialization_bytes_used_as_state_test': False,
              'required_cursor_fields': sorted(REQUIRED), 'old_fixture_or_saved_root_replays': 0,
              'equation_PF_derivative_optimizer_model_training_GPU_calls': 0,
              'remaining_gates': ['Independent review of current-state source-orderPPC aggregation and full receipt/history binding.',
                                  'Prospective worker integration/owner/source/cost/reader freeze before any scientific call.'],
              'API': ['pack_current_state(root,seed,current_NET_ref,cursor,output_path)', 'load_current_state(root,checkpoint_ref)']}
    (out/'Results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'status': result['status'], 'cursor_bytes': len(raw), 'scientific_calls': 0}))


if __name__ == '__main__':
    if sys.argv[1:] != ['--synthetic']:
        raise SystemExit('Only --synthetic preparation is exposed; no production launch')
    synthetic_check(Path(__file__).resolve().parents[1])
