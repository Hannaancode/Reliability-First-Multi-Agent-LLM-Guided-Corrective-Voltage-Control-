"""Positive actual ZIP source transport and unknown-member rejection; zero PF."""
import json,time
import pandapower as pp
from source_bound_receipt_ack_bundle_20261019 import P,import_members
from verified_paid_cache_engine_v2_20261018 import VerifiedPaidUseRegistry
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from frozen_physics_loader import load_stack
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/source_bound_ack_bundle_fixture_20261019'

def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();metadata=read(P/'All697_Closed_Receipt_ACKs.json');row=metadata['rows'][0]
    files=[P/'All697_Closed_Receipt_ACKs.json',P/'All697_Closed_Receipt_ACKs.zip',R/'work/source_bound_receipt_ack_bundle_20261019.py']
    put(B/'Protocol.json',{'source_input_sha256':{str(p.relative_to(R)):sha(p) for p in files},'runtime_versions':{},'source_sha256':sha(__file__),'new_scientific_calls':0})
    guard=LockedSourceSnapshot(B/'Protocol.json');calls=[]
    def forbidden(*a,**k):calls.append(True);raise AssertionError('ZIP transport fixture cannot invoke physics')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,forbidden)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');registry=VerifiedPaidUseRegistry(B/'registry',runner=runner,zones=meta.get('zones',meta))
    try:
        proof=import_members(registry,[row['member']]);assert proof['imported']==1 and proof['new_scientific_calls']==0
        imported=registry.path/registry.validated[row['point_action_key']]['path'];assert sha(imported)==row['sha256'] and read(imported)==read(R/row['source_path'])
        try:import_members(registry,['UNDECLARED_MEMBER.json'])
        except AssertionError:pass
        else:raise AssertionError('Unknown member must not be read/imported')
        assert not calls
        put(B/'Results.json',{'status':'PASS_REAL_IMMUTABLE_ZIP_ACK_TRANSPORT_UNCHANGED_IMPORT_AST_AND_UNKNOWN_MEMBER_REJECTION','source_sha256':sha(__file__),'proof':proof,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
           'limits':'Preservation/analysis software only. All original physical/source/verification costs remain paid and no controller or LLM performance conclusion follows.'})
    finally:registry.close();guard.close()
    manifest(B);print(json.dumps({'ZIP_ACK_transport':'PASS','newPF':0}))

if __name__=='__main__':main()
