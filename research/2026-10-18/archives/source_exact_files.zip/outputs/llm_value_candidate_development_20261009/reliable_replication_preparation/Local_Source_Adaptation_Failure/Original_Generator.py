"""New human-authorized, disclosed replication; unchanged scientific choices."""
from pathlib import Path
from datetime import datetime,timezone
import ast,difflib,json
from candidate_process_evidence_utils import ROOT,read,write,sha
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';OUT=BASE/'reliable_replication_preparation'
assert not OUT.exists();OUT.mkdir()
write(OUT/'Direct_Human_Continuation_Authorization.json',{
 'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'authority':'direct human message in this chat after the terminal partial report',
 'human_instruction':'sooo did we progress to wrds our goal or are we still hitting a wall now chekc gain te vailkabe cli for t4 see is u can check vailable time and continue i have give you full access so u dont need any permission from my side',
 'authorized_action':'fresh resource check and necessary robust preservation preparation followed by a separately identified replication of the interrupted unmeasured learning study',
 'old_attempt_remains_terminal_not_resumed_without_its_missing_checkpoint':True,
 'fresh_replication_repeats_initialization_and_observations_transparently_previous187_steps_and_all_partial_costs_retained':True,
 'old_automatic_no_new_replication_wait_superseded_by_this_direct_continuation_only':True,
 'unchanged_science_no_outcome_based_retuning':True,'not_authority_for_purchases_quota_evasion_or_profile_fallback_after_denial':True})
changes=[]
def adapt(old,new,replacements):
    before=(ROOT/'work'/old).read_text(encoding='utf-8');after=before
    for a,b,n in replacements:
        assert after.count(a)==n,(old,a,after.count(a),n);after=after.replace(a,b)
    ast.parse(after);p=ROOT/'work'/new;assert not p.exists();p.write_text(after,encoding='utf-8')
    changes.append({'old_source':old,'old_sha256':sha(ROOT/'work'/old),'new_source':new,'new_sha256':sha(p),
      'exact_replacements':replacements,'diff':list(difflib.unified_diff(before.splitlines(),after.splitlines()))})
publish="""    transfer_number=0;preservation_wait_seconds=0.
    def publish(files,phase):
        nonlocal transfer_number,preservation_wait_seconds
        bound();event('preservation_package_requested',phase=phase,package=transfer_number)
        identity={'study_id':protocol['reliable_replication']['study_id'],'protocol_sha256':sha(PREP/'protocol.json'),
          'program_manifest_sha256':sha(PREP/'Program_Input_Manifest.json'),'arm':active_arm,'phase':phase}
        package,descriptor=make_package(ROOT/'outputs/reliable_transfer_packages',transfer_number,files,OUT/'events.jsonl',identity)
        waited=wait_for_ack(package,descriptor,protocol['reliable_replication']['ack_bound_seconds'])
        preservation_wait_seconds+=waited;event('preservation_acknowledged',package=transfer_number,
          archive_sha256=descriptor['archive_sha256'],journal_prefix_sha256=descriptor['journal_prefix_sha256'],wait_seconds=waited)
        transfer_number+=1
    def save_complete_checkpoint(path,shared,model,optimizer,counts,history,losses):
        names=[['interface.'+n for n,p in shared.named_parameters()]]
        if active_arm=='copied_original_LoRA_body':names.append([n for n,p in model.named_parameters() if p.requires_grad])
        steps=counts['optimizer_steps'];cursor={'completed_optimizer_steps':steps,'next_epoch':steps//187+1,'next_epoch_offset':steps%187,
          'completed_epoch_history':history,'current_epoch_loss_prefix':losses,'actual_counts':dict(counts)}
        contract={'study_id':protocol['reliable_replication']['study_id'],'protocol_sha256':sha(PREP/'protocol.json'),
          'program_manifest_sha256':sha(PREP/'Program_Input_Manifest.json'),'arm':active_arm}
        checkpoint=full_checkpoint(shared.state_dict(),get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False),
          optimizer,names,cursor,contract)
        assert verify_complete_checkpoint(checkpoint,contract,steps)
        torch.save(checkpoint,path);del checkpoint
        return contract
"""
adapt('candidate_process_pretrained_learning_trainability_v3_remote.py','candidate_reliable_replication_remote.py',[
 ('from vcsa_memory_execution import MemoryExecution','from vcsa_memory_execution import MemoryExecution\nfrom candidate_complete_state_and_transfer_v2 import full_checkpoint,verify_complete_checkpoint,make_package,wait_for_ack',1),
 ('/pretrained_learning_trainability_preparation_v3','/reliable_replication_preparation',1),('/pretrained_learning_trainability_science_v3','/reliable_replication_science',1),
 ('    try:\n        for name,digest in read(PREP',publish+'    try:\n        for name,digest in read(PREP',1),
 ("evaluate(wrapper,rows,'untrained',inputs,counts,folder)","evaluate(wrapper,rows,'untrained',inputs,counts,folder)\n            initial_files={p.relative_to(OUT).as_posix():p for p in OUT.rglob('*') if p.is_file() and p.name not in {'owner.claim','events.jsonl','progress.json'}}\n            publish(initial_files,'untrained_and_initial_identity')",1),
 ("losses.append(float(loss.detach()))", "losses.append(float(loss.detach()))\n                    if counts['optimizer_steps']==25:\n                        first=folder/'First25_Full_Continuation_State.pt'\n                        save_complete_checkpoint(first,shared,model,optimizer,counts,history,losses)\n                        event('first_complete_checkpoint_preserved',checkpoint=first.relative_to(OUT).as_posix(),sha256=sha(first),actual_steps=25)\n                        publish({first.relative_to(OUT).as_posix():first},'first25_complete_state')",1),
 ("checkpoint={'common':shared.state_dict(),'copied_adapter':get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False)}\n                checkpoint_path=folder/f'Epoch{epoch}_Actual_Checkpoint.pt';tick=time.perf_counter();torch.save(checkpoint,checkpoint_path)",
  "checkpoint_path=folder/f'Epoch{epoch}_Actual_Checkpoint.pt';tick=time.perf_counter()\n                save_complete_checkpoint(checkpoint_path,shared,model,optimizer,counts,history,losses)",1),
 ("history.append({'epoch':epoch,'actual_steps':187,'state_loss_mean':sum(losses)/len(losses)})", "history.append({'epoch':epoch,'actual_steps':187,'state_loss_mean':sum(losses)/len(losses)})\n                publish({checkpoint_path.relative_to(OUT).as_posix():checkpoint_path},'epoch_complete_state')",1),
 ("final=evaluate(wrapper,rows,'final_epoch5',inputs,counts,folder)", "final=evaluate(wrapper,rows,'final_epoch5',inputs,counts,folder)\n            publish({(folder/'final_epoch5_scores.pt').relative_to(OUT).as_posix():folder/'final_epoch5_scores.pt'},'final_scores')",1),
 ('del optimizer,optimizer_groups,wrapper,shared,model,actual,original_copy,updated,checkpoint,score,loss,target;', 'del optimizer,optimizer_groups,wrapper,shared,model,actual,original_copy,updated,score,loss,target;',1),
 ("event('arm_complete',counts=counts);del fresh", "publish({p.relative_to(OUT).as_posix():p for p in folder.iterdir() if p.is_file()},'fresh_reload_and_closed_arm')\n            event('arm_complete',counts=counts);del fresh",1),
 ("'arms':all_counts,'forbidden_call_counts':forbidden", "'arms':all_counts,'actual_preservation_packages':transfer_number,'actual_remote_ack_wait_seconds':preservation_wait_seconds,'forbidden_call_counts':forbidden",1)])
adapt('candidate_process_learning_trainability_v3_environment_check.py','candidate_reliable_replication_environment_check.py',[
 ('/pretrained_learning_trainability_preparation_v3','/reliable_replication_preparation',1)])
adapt('analyze_candidate_process_learning_trainability_v3.py','analyze_candidate_reliable_replication.py',[
 ("'pretrained_learning_trainability_preparation_v3'","'reliable_replication_preparation'",1),
 ("'pretrained_learning_trainability_execution_v3'","'reliable_replication_execution'",1),
 ("'pretrained_learning_trainability_external_audit_v3'","'reliable_replication_external_audit'",1),
 ("'Launch_Readiness_Transfer_v3.json'","'Preservation_and_Full_State_Readiness.json'",1),
 ("assert set(c)=={'common','copied_adapter'}", "assert set(c)=={'common','copied_adapter','optimizer','optimizer_group_parameter_names','rng','cursor','contract'}\n        from candidate_complete_state_and_transfer_v2 import verify_complete_checkpoint\n        assert verify_complete_checkpoint(c,{'study_id':protocol['reliable_replication']['study_id'],'protocol_sha256':sha(PREP/'protocol.json'),'program_manifest_sha256':sha(PREP/'Program_Input_Manifest.json'),'arm':arm},187*e['epoch'])",1),
 ("protocol=read(PREP/'protocol.json');assert read(SCI/'protocol.json')==protocol", "protocol=read(PREP/'protocol.json');assert read(SCI/'protocol.json')==protocol\nassert status['all_preservation_requests_verified_and_acknowledged']\nacks=read(EXEC/'Preservation_Acknowledgement_Ledger.json');assert len(acks)==summary_count if False else True",1)])
# Add source/cost/ack checks at the point where actual science summary exists.
p=ROOT/'work/analyze_candidate_reliable_replication.py';source=p.read_text()
source=source.replace("acks=read(EXEC/'Preservation_Acknowledgement_Ledger.json');assert len(acks)==summary_count if False else True","acks=read(EXEC/'Preservation_Acknowledgement_Ledger.json')")
source=source.replace("assert summary['forbidden_call_counts']=={'PF_attempts':0,'generation_attempts':0}",
 "assert summary['forbidden_call_counts']=={'PF_attempts':0,'generation_attempts':0}\nassert len(acks)==summary['actual_preservation_packages']==18\nassert all(a['all_files_and_full_state_verified_locally'] for a in acks)\nassert protocol['reliable_replication']['old_partial_steps_and_costs_preserved_not_claimed_reused']")
ast.parse(source);p.write_text(source,encoding='utf-8');changes[-1]['new_sha256']=sha(p)
adapt('continue_candidate_process_learning_trainability_v3_audit.py','continue_candidate_reliable_replication_audit.py',[
 ("'pretrained_learning_trainability_audit_continuation_v3'","'reliable_replication_audit_continuation'",1),
 ("'pretrained_learning_trainability_execution_v3'","'reliable_replication_execution'",1),
 ('run_candidate_process_learning_trainability_v3_colab.py','run_candidate_reliable_replication_colab.py',1),
 ("'pretrained_learning_trainability_external_audit_v3'","'reliable_replication_external_audit'",2),
 ('analyze_candidate_process_learning_trainability_v3.py','analyze_candidate_reliable_replication.py',1)])
write(OUT/'Additive_Program_Adaptation.json',{'all_AST_parsed':True,'unchanged_science_and_frozen_originals':True,'changes':changes})
print('Prepared separate replication sources and direct human authority; no allocation or model calls.')
