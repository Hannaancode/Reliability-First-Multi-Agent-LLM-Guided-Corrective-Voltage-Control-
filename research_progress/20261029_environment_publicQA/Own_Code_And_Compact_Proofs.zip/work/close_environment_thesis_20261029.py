"""Close reviewed environment documentation and save exact research continuation.

No model, physics, optimizer or scientific reader is invoked here.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, html, json, os, re, zipfile
from docx import Document
from docx.text.paragraph import Paragraph
from docx.table import Table
from pypdf import PdfReader

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/thesis_environment_contracts_20261029'
B = R / 'outputs/thesis_dse_and_public_diagnosis_20261028'

def rd(p):
    return json.loads((R / p).read_text('utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def put(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', 'utf-8')

def media(p):
    with zipfile.ZipFile(p) as z:
        return Counter(hashlib.sha256(z.read(n)).hexdigest()
                       for n in z.namelist() if n.startswith('word/media/'))

def main():
    assert not (O / 'Final_Visual_And_Evidence_QA.json').exists()
    base = B / 'Hannaan_Thesis_DSE_And_Public_Diagnosis.docx'
    path = O / 'Hannaan_Thesis_Environment_Contracts.docx'
    pdf_path = O / 'Integrated_Thesis_QA.pdf'
    old, new = Document(base), Document(path)
    assert sha(base) == rd((B / 'Final_Visual_And_Evidence_QA.json').relative_to(R))['docx_sha256']
    rows = lambda doc: [[[c.text for c in row.cells] for row in t.rows] for t in doc.tables]
    old_tables, new_tables = rows(old), rows(new)
    assert len(old_tables) == 17 and len(new_tables) == 18
    assert all(t in new_tables for t in old_tables)
    assert media(base) == media(path) and sum(media(path).values()) == 22
    refs = lambda doc: [p.text for p in doc.paragraphs if re.match(r'^\[\d+\]', p.text)]
    assert refs(old) == refs(new) and len(refs(new)) == 35
    norm = lambda text: re.sub(r'\t\d+$', '', text)
    old_text = Counter(norm(p.text) for p in old.paragraphs)
    new_text = Counter(norm(p.text) for p in new.paragraphs)
    assert not (old_text - new_text), list((old_text - new_text).items())[:3]
    contract = rd('outputs/environment_contracts_20261029/Source_And_Arithmetic_Check.json')
    assert contract['status'] == 'PASS_SEPARATE_SOURCE_AND_ARITHMETIC_CHECK'
    assert len(contract['checks']) == 18 and contract['source_files'] == 21
    assert contract['matrix_sha256'] == sha(R / 'outputs/environment_contracts_20261029/Environment_Contracts.json')
    assert contract['new_model_PF_derivative_solve_training_GPU_calls'] == 0
    public = rd('outputs/veragrid_source_admission_20261029/Independent_Input_View_Audit.json')
    assert public['status'] == 'PASS_ALL150_EXACT_ORDER_TEXT_OPTIONS_AND_LABEL_FIELD_EXCLUSION'
    assert public['records'] == 150 and public['new_model_PF_OPF_training_calls'] == 0
    assert public['participant_sha256'] == sha(R / 'outputs/veragrid_source_admission_20261029/participant/Question_Views.json')
    pdf = PdfReader(pdf_path)
    pagination = rd((O / 'Pagination_Record.json').relative_to(R))
    assert len(pdf.pages) == pagination['pages'] == 121
    assert pagination['list_entries'] == len(pagination['map']) == 53
    compact = lambda text: re.sub(r'\s+', '', text).lower()
    for item in pagination['map']:
        assert compact(item['label']) in compact(pdf.pages[item['physical_page'] - 1].extract_text() or ''), item
    for p in [7, 60, 74, 95, 96, 97, 98, 99, 100]:
        assert (O / f'render/verified-{p:03}.png').exists()
    assert len(list((O / 'render').glob('verified-*.png'))) == 121
    now = datetime.now(timezone.utc).isoformat()
    review = {
        'status': 'PASS_CONTACT_SHEETS_AND_NINE_CHANGED_PAGES_VISUALLY_REVIEWED',
        'pdf_sha256': sha(pdf_path), 'contact_sheet_pages': list(range(1, 122)),
        'final_full_size_pages': [7, 60, 74, 95, 96, 97, 98, 99, 100],
        'observations': 'New table, subsections and chapter transitions are readable and unclipped; final two-line orphan removed. Existing content checked separately below.',
        'renderer': 'Hidden Word COM PDF export and bundled Poppler; soffice unavailable. Final verified-*.png images used.',
        'preserved_earlier_layout_records': ['Layout_Repair_Record.json', 'Final_Rendered_Page_Identity.json'],
        'scope': 'All-page overview and nine detailed changed pages, not a claim of renewed full-size review of every old page. Earlier 122-page identity record is superseded by this 121-page PDF.'
    }
    put(O / 'Visual_Review_Record.json', review)
    qa_rel = (O / 'Final_Visual_And_Evidence_QA.json').relative_to(R).as_posix()
    qa = {'at_utc': now, 'status': 'PASS_WORKING_DRAFT_LAYOUT_AND_LISTED_EVIDENCE_CHECKS',
          'pages': 121, 'tables': 18, 'figures': 22, 'references': 35, 'page_bound_index_entries': 53,
          'docx_sha256': sha(path), 'pdf_sha256': sha(pdf_path), 'original116_unchanged': True,
          'all_prior17_table_values_unchanged': True, 'all_prior_paragraphs_preserved_with_multiplicity_except_index_page_numbers': True,
          'all22_media_bytes_unchanged': True, 'all35_references_unchanged': True,
          'visual_review': review, 'environment_source_check': contract, 'new_scientific_calls': 0,
          'limitations': ['Working draft, not final university submission.', 'RAG historical figure/runtime binding remains unknown; supplied code is not proof of its execution.',
                         'Environment separation and public QA input admission establish no new performance or causal LLM superiority.', 'All six research goals remain OPEN.']}
    put(O / 'Final_Visual_And_Evidence_QA.json', qa)
    chunks = []
    for e in new.element.body:
        if e.tag.endswith('}p'):
            p = Paragraph(e, new)
            chunks.append(('## ' if p.style.name.startswith('Heading') else '') + p.text)
        elif e.tag.endswith('}tbl'):
            t = Table(e, new)
            values = [[c.text.replace('\n', ' / ') for c in row.cells] for row in t.rows]
            chunks.append('\n'.join(['| ' + ' | '.join(values[0]) + ' |', '| ' + ' | '.join(['---'] * len(values[0])) + ' |'] + ['| ' + ' | '.join(row) + ' |' for row in values[1:]]))
    (O / 'Thesis_Text_And_Tables.md').write_text('\n\n'.join(chunks) + '\n', 'utf-8')
    index = rd((B / 'Thesis_Evidence_Navigation.json').relative_to(R))
    index.update(at_utc=now, qa_record=qa_rel, current_docx=path.relative_to(R).as_posix(), pages=121)
    sources = ['outputs/environment_contracts_20261029/Environment_Contracts.json',
               'outputs/environment_contracts_20261029/Source_And_Arithmetic_Check.json']
    caption = next(p.text for p in new.paragraphs if p.style.name == 'Caption' and p.text.startswith('Table 7.11 '))
    index['tables'].append({'table': '7.11', 'caption': caption, 'status': 'VERIFIED_SAVED_SOURCE_CONTRACTS',
                            'records': [{'path': s, 'sha256': sha(R / s)} for s in sources],
                            'limitation': 'Distinct actions, information, solver, protection, stopping and scope; historical demonstration runtime binding remains unknown. No new scientific execution.'})
    put(O / 'Thesis_Evidence_Navigation.json', index)
    def link(p, label):
        return '<a href="' + html.escape(os.path.relpath(R / p, O).replace('\\', '/'), quote=True) + '">' + html.escape(label) + '</a>'
    parts = ['<!doctype html><meta charset="utf-8"><title>Thesis evidence index</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.5 system-ui}section{border-top:1px solid #ddd;padding:12px 0}</style><h1>Thesis evidence index</h1>',
             '<p>121 pages; 18 tables; 22 figures; 35 references. Working draft; all six research goals remain open.</p>',
             '<p>' + link(path.relative_to(R), 'Current Word draft') + '</p>']
    for table in sorted(index['tables'], key=lambda x: tuple(map(int, x['table'].split('.')))):
        parts.append('<section><h2>' + html.escape(table['caption']) + '</h2><p>' + html.escape(table['limitation']) + '</p><ul>')
        parts.extend('<li>' + link(v['path'], v['path']) + '</li>' for v in table['records'])
        parts.append('</ul></section>')
    parts.append(link('outputs/thesis_integrated_evidence_20261028/Evidence_Index.html', 'Original figure sources'))
    (O / 'Evidence_Index.html').write_text('\n'.join(parts), 'utf-8')
    tasks = rd('outputs/thesis_research_closure_20261028/Tasks.json')
    task = next(t for t in tasks['tasks'] if t['id'] == 'T19')
    assert task['status'] == 'OPEN'
    task.update(status='COMPLETE_SCOPED_DOCUMENTATION_REQUIREMENT_IN_REVIEWED_WORKING_THESIS', completed_utc=now,
                evidence=sources + [qa_rel], limitation='Environment differences documented in Chapters 5–7; unknown historical runtime bindings remain explicit. No new performance result.')
    tasks['completed_requirement_count'] = sum(t['status'].startswith('COMPLETE') for t in tasks['tasks'])
    assert tasks['completed_requirement_count'] == 14
    tasks['updated_utc'] = now
    put(R / 'outputs/thesis_research_closure_20261028/Tasks.json', tasks)
    resume = rd('outputs/research_resumption_20261028/Current_Resume.json')
    resume.update(at_utc=now, updated_at_utc=now, thesis_integration=qa_rel, thesis_evidence_index=(O / 'Evidence_Index.html').relative_to(R).as_posix(),
                  thesis_closed_requirements=14, environment_contracts=sources,
                  public_QA_admission='outputs/veragrid_source_admission_20261029/Independent_Input_View_Audit.json',
                  public_QA_next='outputs/veragrid_source_admission_20261029/Decision_And_Next_Steps.md',
                  new_work_publication_status='LOCAL_VERIFIED_PENDING_NEXT_LEASE_AND_BYTE_CHECKED_PUBLICATION')
    resume['next'] = [x for x in resume['next'] if not x.startswith('T19:')]
    resume['next'].insert(0, 'G2/G3 QA: inspect pinned native VeraGrid runner/circuit prompt; bind actual RAG model and train/test overlap; freeze full150 inference/controls/parser/cost/ownership protocol before any model launch. Verified input packaging alone is not launch readiness.')
    put(R / 'outputs/research_resumption_20261028/Current_Resume.json', resume)
    main_tasks = rd('outputs/research_tasks_20261014/Tasks.json')
    main_tasks.update(updated_at_utc=now, thesis_documentation_requirements_complete=14, latest_verified_thesis=qa_rel)
    g2 = next(t for t in main_tasks['tasks'] if t['checklist_id'] == 'G2')
    assert all(t['id'] != 'G2.5a' for t in g2['subtasks'])
    g2['subtasks'].append({'id': 'G2.5a', 'completed': True, 'description': 'Pin and independently validate all150 public VeraGrid QA input views with labels/admin fields excluded; input readiness only.',
                          'evidence': 'outputs/veragrid_source_admission_20261029/Independent_Input_View_Audit.json', 'verified_at_save': now})
    g2['public_QA_admission'] = resume['public_QA_admission']
    put(R / 'outputs/research_tasks_20261014/Tasks.json', main_tasks)
    msg = ('T19 complete: 21 saved files and 18 source/arithmetic checks separate six environment contracts. Reviewed thesis 121 pages, 18 tables, 22 figures, 35 references, 53 page-bound index entries; original116-page copy preserved. Thesis requirements 14/35 complete, 21 open/partial; all6 final research goals OPEN. Public VeraGrid QA all150 input views independently checked, source order and question/options preserved, labels/admin fields excluded; no model benchmark yet. New scientific/model/PF/training/GPU calls zero; no owned experiment or waiting timer. New code/proofs local pending authorized publication. Resume identifies exact next runner/context/model/control gates; no launch from packaging readiness.')
    header = '## Environment documentation and public QA input preparation verified — ' + now + '\n\n' + msg + '\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        p = R / rel
        p.write_text(header + p.read_text('utf-8-sig'), 'utf-8')
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n' + now + '\n' + msg + '\n')
    integration = rd((O / 'Integration_Record.json').relative_to(R))
    integration.update(status='COMPLETE_WORKING_DRAFT_VISUALLY_VERIFIED', pages=121, qa=qa_rel)
    put(O / 'Integration_Record.json', integration)
    print(json.dumps({'status': 'PASS', 'pages': 121, 'thesis_requirements_complete': 14, 'public_QA_inputs': 150, 'new_science': 0}))

if __name__ == '__main__':
    main()
