"""Independent saved-output/state/source reader; zero model/PF/optimizer calls."""
import json,hashlib,os,sys,subprocess,time
from pathlib import Path
from candidate_process_evidence_utils import read,sha,write,frozen_checks,seal
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_joint_15_engineering_preparation_v2_20261020';OWNER=ROOT/'outputs/native_joint_15_engineering_execution_v2_20261020';OUT=ROOT/'outputs/native_joint_15_engineering_independent_v2_20261020'
def main():
    began=time.perf_counter();assert not OUT.exists();OUT.mkdir();write(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    p=read(PREP/'Production_Protocol.json');lock=read(PREP/'Independent_Reader_Lock.json');assert lock['reader_sha256']==sha(Path(__file__)) and lock['protocol_sha256']==sha(PREP/'Production_Protocol.json')
    state=read(OWNER/'status.json');end=read(ROOT/'outputs/native_joint_15_engineering_coordination_v2_20261020/End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
    assert state['runtime_released'] and state['scientific_process_ended'] and state['all_actual_closed_artifacts_preserved'] and state['remote_exit_code']==0
    for rel,h in p['source_hashes'].items():assert sha(ROOT/rel)==h
    study=OWNER/'staged/study';descriptor=read(OWNER/'remote_closed_descriptor.json')
    for rel,v in descriptor['members'].items():assert (study/rel).stat().st_size==v['bytes'] and sha(study/rel)==v['sha256']
    previous='0'*64;rows=[]
    for line in (study/'events.jsonl').read_text(encoding='utf-8').splitlines():
        record=json.loads(line);event=record['event'];assert event['previous']==previous;previous=hashlib.sha256(json.dumps(event,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert previous==record['sha256'];rows.append(event)
    result=read(study/'Results.json');assert result['status'].startswith('COMPLETE_DISPOSABLE') and result['full_tokens']==3229 and result['warm_cold_native_action_and_loss_bit_exact'] and result['peak_allocated_bytes']<=12*1024**3
    costs=result['actual_costs'];expected={'model_load_attempts':2,'model_load_returns':2,'body_forward_attempts':4,'body_forward_returns':4,'backward_attempts':2,'backward_returns':2,'optimizer_attempts':2,'optimizer_returns':2,'PF_generation_controller_calls':0};assert costs==expected
    for kind,total in [('model_load_attempt',2),('model_load_return',2),('body_forward_attempt',4),('body_forward_return',4),('backward_attempt',2),('backward_return',2),('optimizer_attempt',2),('optimizer_return',2)]:assert sum(x['kind']==kind for x in rows)==total
    a=read(study/'Application_03.json');b=read(study/'Application_04.json');assert a['phase']=='warm_final_eval' and b['phase']=='cold_complete_restored_eval'
    for k in ['loss','u','Qnext','u_dtype','Qnext_dtype','body_tokens']:assert a[k]==b[k]
    assert a['u_dtype']=='torch.float32' and a['Qnext_dtype']=='torch.float64'
    gradients=read(study/'Actual_Gradient_Participation.json');assert [r['step'] for r in gradients]==[1,2]
    for row in gradients:
        assert len(row['gradients'])==394 and all(v['finite'] and v['present'] for v in row['gradients'].values())
    assert all(v['nonzero']>0 for v in gradients[-1]['gradients'].values())
    validated=[]
    for name,step in [('initial0_complete.pt',0),('step2_complete.pt',2)]:
        output=OUT/f'Independent_CPU_State_{step}.json';subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(ROOT/'work/validate_native_joint_checkpoint_20261020.py'),str(study/name),str(output),str(step)],check=True,timeout=180);validated.append(read(output))
    audit={'status':'PASS_INDEPENDENT_FULL_NATIVE_BODY_CONTEXT_GRADIENT_MEMORY_COMPLETE_STATE_COLD_ACTION_SOURCE_COST_READER','engineering_only_not_policy_learning_or_benchmark':True,'actual_costs':costs,'all24_new_native_input_states_remain_development':True,'full_tokens':3229,'peak_allocated_bytes':result['peak_allocated_bytes'],'all394_gradient_tensors_and_steps_verified':True,'complete_CPU_states':validated,'strict_cold_actions_and_loss_exact':True,'original_frozen_assets':frozen_checks(),'workflow_seconds':time.perf_counter()-began,'new_model_PF_optimizer_calls':0,'next_training_or_physics_permission':'NONE_AUTOMATIC;requires_new_prospective_matched_protocol_and_controls'}
    write(OUT/'Independent_Audit.json',audit);seal(OUT,{p.name:p for p in OUT.glob('*.json')},'Independent_Native15_Engineering_Audit.zip');print('NATIVE15_ENGINEERING_INDEPENDENT_PASS')
if __name__=='__main__':main()
