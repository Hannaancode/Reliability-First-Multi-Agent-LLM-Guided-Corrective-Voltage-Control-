"""Record completed documentation requirements without closing open research goals."""
from pathlib import Path
from datetime import datetime, timezone
import json
R=Path(__file__).resolve().parents[1]
def load(p):return json.loads((R/p).read_text('utf-8-sig'))
def save(p,v):(R/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
now=datetime.now(timezone.utc).isoformat()
base='outputs/thesis_integrated_evidence_20261028/'
qa=load(base+'Final_Visual_And_Evidence_QA.json')
assert qa['status']=='PASS_WORKING_DRAFT_LAYOUT_AND_LISTED_EVIDENCE_CHECKS'
tasks=load('outputs/thesis_research_closure_20261028/Tasks.json')
closed={'T03','T07','T08','T10','T16','T18','T23'}
for t in tasks['tasks']:
    if t['id'] in closed:
        t['status']='COMPLETE_DOCUMENTATION_REQUIREMENT_IN_REVIEWED_WORKING_THESIS'
        t['completed']=True;t['verified_at_utc']=now
        t['evidence']=list(dict.fromkeys(t.get('evidence',[])+[base+'Final_Visual_And_Evidence_QA.json',base+'Hannaan_Thesis_Integrated_Evidence.docx']))
        t['limitation']='This closes the specified evidence/documentation requirement; no open research goal or superiority claim is converted into success.'
    elif t['id']=='T24':
        t['status']='CANDIDATE_TABLE_INTEGRATED_COLLABORATOR_ALLOCATION_PARTLY_UNCONFIRMED'
        t['limitation']='Candidate statement and documented review/supervision retained; RAG and provisional contributor allocations still need confirmation.'
    elif t['id']=='T27':
        t['status']='ALL12_TABLES_22_FIGURES_NAVIGABLE_UNDERLYING_REPRODUCIBILITY_GAPS_OPEN'
        t['evidence']=[base+'Thesis_Evidence_Navigation.json',base+'Evidence_Index.html']
    elif t['id']=='T30':
        t['status']='ABSTRACT_UPDATED_TO_CURRENT_VERIFIED_RESULTS_FINAL_RESEARCH_STILL_OPEN'
        t['evidence']=[base+'Final_Visual_And_Evidence_QA.json']
    elif t['id']=='T33':
        t['status']='KNOWN_HEADING_LABEL_UNIT_LAYOUT_FIXES_COMPLETE_REFERENCE_REVIEW_OPEN'
        t['evidence']=[base+'Final_Visual_And_Evidence_QA.json',base+'Final_Layout_Repairs.json']
tasks['updated_utc']=now
tasks['completed_requirement_count']=sum(t.get('completed',False) for t in tasks['tasks'])
assert tasks['completed_requirement_count']==8
save('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
resume=load('outputs/research_resumption_20261028/Current_Resume.json')
resume.update(at_utc=now,thesis_integration=base+'Final_Visual_And_Evidence_QA.json',
              thesis_evidence_index=base+'Evidence_Index.html',thesis_closed_requirements=8)
resume['next']=[
 'Continue G3 external118 admission from saved GraphAgent full-episode software/terminal restore and device-contract records; no repeated fixtures or automatic GPU launch.',
 'Resolve externally published device/action/solver/information/horizon and preservation contracts before matched118 execution; keep native-track differences explicit.',
 'Continue remaining27thesis requirements: closest literature, source lineage and unresolved137/RAG contracts; no unsupported completion.',
 'Publish the reviewed thesis compact provenance and task update with fresh branch lease and exact-byte verification.'
]
resume['publication']={'head':'c8cefac13891f596e9cf9f6801e7b181d3397167','exact_downloaded_files':9,
 'receipt':'outputs/closed118_and_thesis_publication_20261028/Verified_GitHub_Receipt.json','raw_backup_complete':False,
 'later_local_pending':'Full109page integration and evidence index not included in this published snapshot.'}
resume['parallel_completed'].append('109-page working thesis integrated,47indexentries bound,22usedfigurebytes preserved,12tables/30references;all109contactreview/32changedfullsize and finalfixchecksPASS.8of35requirementsclosed;27remainopen/partial.')
save('outputs/research_resumption_20261028/Current_Resume.json',resume)
header=f'''## Thesis integration verified; original comparison closed — {now}

The109-page working thesis now includes all4verified original endpoints, adverse fixedgateFAIL, exact offlineHGSE/fullBOTH distinction, verifier scope, training-world limits, candidate roles and sixRQ evidence answers.47indexentries bound;22usedfigurebytes unchanged;12tables/30references;full visual QA saved.8of35documentation/evidence requirements complete,27open/partial; all6researchgoals remainOPEN. Read outputs/research_resumption_20261028/Current_Resume.json and outputs/thesis_integrated_evidence_20261028/Final_Visual_And_Evidence_QA.json. BothT4sreleased;noownedscience/GPU/timer. Continue justified G3external118 contract work and remainingthesis requirements, no retune/restart oridleGPU. GPUreset/hour estimates remainunverified. Lastpublishedc8cefac compactproofs; newer109pageintegration localpendingpublication.

'''
for p in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
    f=R/p;f.write_text(header+f.read_text('utf-8-sig'),encoding='utf-8')
with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
    f.write(f'\n{now} — Thesis documentation integration COMPLETE for current evidence. Before:105-page draft with two unknown severe-root endpoints. After:109-page reviewed copy with all4closed results and explicit failures/limits,12tables/22original figures/30references; numeric tables bound to auditedJSON,47pageentries validated. Added navigable12table/22figure evidence map; unrecovered137/RAG provenance staysUNKNOWN. Eight of35requirements complete;27open/partial;all6researchgoalsOPEN.0newmodel/PF/training/GPU. Original105pageDOCX preserved.\n')
print(json.dumps({'closed_checklist_requirements':8,'remaining_open_partial':27,'research_goals_closed':0,'resume_saved':True}))
