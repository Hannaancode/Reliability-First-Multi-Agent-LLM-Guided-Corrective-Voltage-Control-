"""Read-only independent identity/continuous-physics/cost audit; zero solves."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import psutil
ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/vcsa_development'
OUT = BASE / 'pretrained_selected_physical_replay_20261008'
ANALYSIS = BASE / 'pretrained_pilot_analysis'
DATA = BASE / 'training_interface'
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert not (OUT / 'independent_audit.json').exists()
    pid = int((OUT / 'owner.claim').read_text())
    if psutil.pid_exists(pid):
        assert not any('replay_vcsa_pretrained_selected_actions_20261008.py' in arg
                       for arg in psutil.Process(pid).cmdline())
    for name, entry in read(OUT / 'manifest.json').items():
        assert (OUT / name).stat().st_size == entry['bytes'] and sha(OUT / name) == entry['sha256']
    protocol = read(OUT / 'protocol.json')
    assert sha(ROOT / 'work/replay_vcsa_pretrained_selected_actions_20261008.py') == protocol['source_sha256']
    for name, digest in protocol['frozen_sources'].items():
        assert sha(ROOT / name.replace('\\', '/')) == digest
    for folder, key in [(ANALYSIS, 'analysis_manifest_sha256'), (DATA, 'data_manifest_sha256')]:
        assert sha(folder / 'manifest.json') == protocol[key]
        for name, entry in read(folder / 'manifest.json').items():
            assert (folder / name).stat().st_size == entry['bytes'] and sha(folder / name) == entry['sha256']
    choices = {(r['policy'], r['id']): r for r in read(ANALYSIS / 'Actual_Four_Policy_One_State_Table.json')
               if r['policy'] in ['frozen_LM_heads', 'VCSA_full']}
    rows = {r['local_observation_id']: r for r in read(DATA / 'rows.json')}
    records = read(OUT / 'Actual_All_Pretrained_Selection_Physics.json')
    assert len(records) == len({(r['policy'], r['id']) for r in records}) == len(choices) == 96
    prior_cache = {}; fresh = {}
    for file in OUT.glob('fresh_*.json'):
        r = read(file); key = (r['id'], r['scenario_sha256'], json.dumps(r['action'], sort_keys=True))
        assert key not in fresh; fresh[key] = r
    continuous = 0; failed = 0; reused = 0
    for record in records:
        choice = choices[(record['policy'], record['id'])]; row = rows[record['id']]
        assert (record['scenario_id'], record['scenario_sha256'], record['split'], record['zone']) == (
            row['scenario_id'], row['scenario_sha256'], row['split'], row['zone'])
        assert sha(ROOT / f"work/e/pack/scenarios/federation/{row['scenario_id']}.json") == row['scenario_sha256']
        assert record['passed']
        if not row['training_eligible']:
            assert record['invalid_retained'] and record['hard_abstained'] and choice['invalid_retained']
            continue
        action = choice['action']; proposal = {'add_shunts_q_mvar': {str(action['bus']): float(action['q_mvar'])}}
        assert record['action'] == proposal
        candidate = next(c for c in row['candidate_labels'] if (c['bus'], c['q_mvar']) == (action['bus'], action['q_mvar']))
        assert row['input']['allowed_bus_mask'][action['bus_position']] and row['input']['bus_ids'][action['bus_position']] == action['bus']
        proof = record['provenance']; stripped = {k: v for k, v in record.items() if k not in ['policy', 'provenance']}
        if proof['type'] == 'prior_exact_report':
            folder = ROOT / proof['folder']; key = folder.as_posix()
            if key not in prior_cache:
                assert sha(folder / 'manifest.json') == proof['manifest_sha256']
                for name, entry in read(folder / 'manifest.json').items():
                    assert sha(folder / name) == entry['sha256']
                if folder.name == 'state_control_selected_replay':
                    prior_cache[key] = {r['id']: r for p in (folder / 'worlds').glob('*.json') for r in read(p)['records']}
                else:
                    prior_cache[key] = {r['id']: r for r in read(folder / 'Actual_All_Action_Replay_Records.json')}
            assert stripped == prior_cache[key][record['id']]; reused += 1
        else:
            assert proof['type'] == 'new_unique_physics'
            assert stripped == fresh[(record['id'], record['scenario_sha256'], json.dumps(proposal, sort_keys=True))]
        after = record['independent_replay_metrics']; verified = record['original_verification'].get('after')
        assert (after is None) == (verified is None) == (candidate['after_metrics'] is None)
        assert bool(candidate['PF_failure_target']) == (after is None)
        if after is None:
            assert record['replayed_bus_voltages'] is None; failed += 1
        else:
            assert all(abs(float(after[k]) - float(verified[k])) <= 1e-10 and
                       abs(float(after[k]) - float(candidate['after_metrics'][k])) <= 1e-10 for k in after)
            voltages = record['replayed_bus_voltages']; assert len(voltages) == 118
            assert abs(min(voltages.values()) - after['vmin']) <= 1e-10
            assert abs(max(voltages.values()) - after['vmax']) <= 1e-10
            assert sum(v < .95 for v in voltages.values()) == after['uv_count']
            continuous += 1
        assert record['normal_guard_admissible'] == bool(candidate['guard_admissibility_target']) == choice['measured_guard_admissible']
        assert record['strict_UV_zero_and_normal_upper'] == bool(after is not None and after['uv_count'] == 0 and after['vmax'] <= 1.05 + 1e-8)
    summary = read(OUT / 'summary.json'); assert summary['passed']
    assert continuous + failed == 94 and len(fresh) == protocol['fresh_unique_actions']
    assert {k: c['attempts'] for k, c in summary['new_costs'].items()} == protocol['new_phases']
    assert all(c['returns'] + c['exceptions'] == c['attempts'] for c in summary['new_costs'].values())
    assert summary['actual_new_PF_attempts'] == sum(c['attempts'] for c in summary['new_costs'].values())
    for policy, counts in summary['counts_by_policy'].items():
        assert counts['admissible'] == sum(r['policy'] == policy and r.get('normal_guard_admissible', False) for r in records)
        assert counts['strict_UV_zero_normal_upper'] == sum(r['policy'] == policy and r.get('strict_UV_zero_and_normal_upper', False) for r in records)
    report = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'passed': True,
        'exact_selections_including_invalid': 96, 'continuous_selected_state_checks': continuous,
        'retained_selected_PF_failures': failed, 'prior_exact_report_selections': reused,
        'fresh_unique_physical_actions': len(fresh), 'new_actual_PF_attempts': summary['actual_new_PF_attempts'],
        'new_PF_exceptions': sum(c['exceptions'] for c in summary['new_costs'].values()),
        'prior_PF_costs_separate': protocol['prior_PF_costs_separate'],
        'new_audit_model_PF_calls': 0, 'source_sha256': sha(Path(__file__)),
        'scientific_manifest_sha256': sha(OUT / 'manifest.json'),
        'full_DSE_superiority': False, 'unused_confirmation': False, 'full_operating_limit_certification': False}
    with (OUT / 'independent_audit.json').open('x') as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
