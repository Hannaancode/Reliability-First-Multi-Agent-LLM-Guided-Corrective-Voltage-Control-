"""Full-bank standalone architecture comparison; no envelope substitution."""
from pathlib import Path
import json,hashlib,csv
import numpy as np
from analyze_family_pairs import family,SEED,REPLICATES
def analyze():
    root=Path('outputs');protocol=json.loads((root/'central_experiment_protocol.json').read_text());lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());expected={Path(n).stem:h for n,h in lock['scenario_file_sha256'].items()};paths=list((root/'central_matched_campaign/cases').glob('*.json'));assert {p.stem for p in paths}==set(expected),'Full central matched 62-case ledger required'
    rows=[];groups={};promptfits=[]
    for p in sorted(paths):
        d=json.loads(p.read_text());assert d['protocol']==protocol and d['scenario_sha256']==expected[p.stem]
        row={'scenario_id':p.stem,'family':family(p.stem),'valid_numerical_pair':d['paired_terminal_metrics_valid']}
        for name in ['HG-VF','CENTRAL-VF']:
            b=d['branches'][name];m=b.get('final_metrics') or {};row[name+'_exception']=b.get('exception_type');row[name+'_finite_uv_clear_success']=bool(d['paired_terminal_metrics_valid'] and m['uv_count']==0)
            if d['paired_terminal_metrics_valid']:
                for k in ['uv_count','deficit_sum','vmin','vmax']:row[name+'_'+k]=m[k]
                row[name+'_accepted_actions']=len(b['executed_actions']);row[name+'_nominal_support_mvar']=sum(abs(float(q)) for a in b['executed_actions'] for q in a['action']['add_shunts_q_mvar'].values())
            for k,v in d['costs'][name].items():row[name+'_'+k]=v
            if name=='CENTRAL-VF':
                for log in b.get('logs',[]):
                    fit=log.get('llm_info',{}).get('central_prompt')
                    if fit:promptfits.append(fit)
        rows.append(row);groups.setdefault(row['family'],[]).append(row)
    assert len(groups)==31 and all(len(rs)==2 for rs in groups.values())
    metrics=['uv_count','deficit_sum','accepted_actions','nominal_support_mvar','wall_seconds','pf_attempts','llm_calls','input_tokens','output_tokens'];valid={f:rs for f,rs in groups.items() if all(r['valid_numerical_pair'] for r in rs)};differences={};pvalue=None
    if valid:
        matrix=np.array([[np.mean([r['CENTRAL-VF_'+m]-r['HG-VF_'+m] for r in rs]) for m in metrics] for rs in valid.values()],float);rng=np.random.default_rng(SEED);samples=matrix[rng.integers(0,len(matrix),size=(REPLICATES,len(matrix)))].mean(axis=1);observed=matrix.mean(axis=0)
        for i,m in enumerate(metrics):differences[m]={'mean_CENTRAL_minus_ZONAL':float(observed[i]),'outage_family_percentile_bootstrap_95_percent_ci':np.quantile(samples[:,i],[.025,.975]).tolist()}
        null=(rng.choice([-1.,1.],size=(REPLICATES,len(matrix)))*matrix[:,0]).mean(axis=1);pvalue=float((1+np.count_nonzero(np.abs(null)>=abs(observed[0])-1e-12))/(REPLICATES+1))
    cols=list(dict.fromkeys(k for row in rows for k in row))
    with (root/'central_matched_paired_ledger.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
    report={'case_count':len(rows),'invalid_case_ids':[r['scenario_id'] for r in rows if not r['valid_numerical_pair']],'complete_valid_family_count':len(valid),'cluster_unit':'same outage line/zone across both load levels','bootstrap_replicates':REPLICATES,'seed':SEED,'primary_uv_cluster_sign_flip_pvalue':pvalue,'scope':'Paired standalone zonal HG-VF and central VF under the same frozen zonally trained adapter and matched call/output allowance. Input tokens differ and are measured. Cluster sign symmetry/exchangeability assumption; local bank only. Invalid cases retained and not zero-imputed. Physical replay and declared-resource audit required separately.','paired_differences':differences,'prompt_context_audit':{'recorded_primary_queries':len(promptfits),'maximum_input_tokens':max((p['input_tokens'] for p in promptfits),default=None),'feedback_memory_reductions':sum(p['memory_reduced'] for p in promptfits),'physical_observation_truncations':sum(p['physical_observation_truncated'] for p in promptfits),'generation_reserved':384,'context_limit':4096}}
    assert report['prompt_context_audit']['physical_observation_truncations']==0
    (root/'central_matched_summary.json').write_text(json.dumps(report,indent=2,allow_nan=False));return report
if __name__=='__main__':print(json.dumps(analyze(),indent=2))
