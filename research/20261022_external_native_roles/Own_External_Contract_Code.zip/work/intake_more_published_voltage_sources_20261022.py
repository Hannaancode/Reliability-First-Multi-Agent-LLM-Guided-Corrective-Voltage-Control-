"""Read-only pinned author source intake; no imported/executed author code."""
import hashlib,json,os,time,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
O=R/'outputs/published_voltage_source_intake_20261022'
REPOS=['blthayer/drl-powerworld','blthayer/gym-powerworld','RWTH-IAEW/RRL-voltage-control','RWTH-IAEW/voltage-control-env']


def put(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())


def main():
    O.mkdir(exist_ok=False);start=time.monotonic();cost=[];records=[];total=0;failure=None
    put(O/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'repositories':REPOS,'fixed_seconds':600,'total_source_bound_bytes':8*1024**2,'single_file_bound_bytes':262144,
        'paper_primary_sources':['https://arxiv.org/abs/2006.06728','https://github.com/RWTH-IAEW/RRL-voltage-control'],
        'new_science_or_GPU_training_calls':0,'execute_author_code':False,'no_account_or_paid_access':True})
    def get(url):
        assert time.monotonic()-start<600
        tick=time.perf_counter();rec={'url':url,'attempt':1}
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'HierGrid-source-evidence-intake','Accept':'application/vnd.github+json'})
            with urllib.request.urlopen(req,timeout=30) as response:
                rec['status']=response.status;raw=response.read(3*1024**2+1)
            assert len(raw)<=3*1024**2;rec['returned_bytes']=len(raw);return raw
        except urllib.error.HTTPError as e:rec['status']=e.code;raise
        finally:rec['seconds']=time.perf_counter()-tick;cost.append(rec)
    try:
        for repo in REPOS:
            d=O/repo.replace('/','__');d.mkdir()
            metadata=json.loads(get('https://api.github.com/repos/'+repo));branch=metadata['default_branch']
            commit=json.loads(get('https://api.github.com/repos/'+repo+'/commits/'+branch));head=commit['sha']
            tree=json.loads(get('https://api.github.com/repos/'+repo+'/git/trees/'+commit['commit']['tree']['sha']+'?recursive=1'))
            assert not tree['truncated'];put(d/'Pinned_Commit.json',commit);put(d/'Pinned_Tree.json',tree)
            selected=[];excluded=[]
            for item in tree['tree']:
                name=item['path'];path=Path(name)
                if item['type']!='blob':continue
                if path.suffix.lower() not in {'.py','.md','.rst','.yml','.yaml','.toml','.cfg','.ini','.txt'} and path.name not in {'LICENSE','LICENSE.txt'}:
                    excluded.append({'path':name,'reason':'Not selected source/config/license text; model/data support not inferred.'});continue
                size=item.get('size',0)
                if size>262144 or total+size>8*1024**2:
                    excluded.append({'path':name,'reason':'Prospective text byte bound'});continue
                assert not path.is_absolute() and '..' not in path.parts
                raw=get('https://raw.githubusercontent.com/'+repo+'/'+head+'/'+name)
                blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
                assert blob==item['sha'] and len(raw)==size
                out=d/'source'/path;out.parent.mkdir(parents=True,exist_ok=True)
                with out.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
                total+=len(raw);selected.append({'path':name,'bytes':len(raw),'git_blob':blob,'sha256':hashlib.sha256(raw).hexdigest()})
            rec={'repository':repo,'commit':head,'license':metadata.get('license'),'selected_files':selected,'excluded':excluded,
                'author_code_imported_or_run':False,'trained118policy_or_common_actuator_admission':'UNKNOWN_PENDING_SOURCE_CONTRACT_AUDIT'}
            put(d/'Source_Intake.json',rec);records.append(rec)
    except BaseException as e:
        import traceback
        failure={'type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc()};put(O/'Failure.json',failure)
    finally:
        put(O/'GET_Costs.json',cost)
        result={'status':'COMPLETE_PINNED_AUTHOR_SOURCE_INTAKE_ONLY' if failure is None else 'PARTIAL_SOURCE_INTAKE_UNAVAILABLE_ITEMS_UNKNOWN',
            'repositories_complete':len(records),'selected_files':sum(len(x['selected_files']) for x in records),
            'selected_bytes':total,'HTTP_attempts':len(cost),'new_PF_model_training_or_GPU_calls':0,
            'not_performance_or_transfer_readiness':True,'workflow_seconds':time.monotonic()-start}
        put(O/'Result.json',result)
        put(O/'Closed_Manifest.json',{'members':{p.relative_to(O).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in O.rglob('*') if p.is_file()}})
        print(json.dumps(result))


if __name__=='__main__':main()
