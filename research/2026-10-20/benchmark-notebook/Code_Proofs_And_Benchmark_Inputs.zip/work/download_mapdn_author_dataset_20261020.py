"""One bounded public author-data transfer; no allocation, execution or solver."""
import hashlib,json,os,time,urllib.request,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/mapdn_author_dataset_full_20261020'
BASE=ROOT/'outputs/benchmark_priority_20261020/MAPDN'
def now():return datetime.now(timezone.utc).isoformat()
def save(p,v):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(v,indent=2),encoding='utf-8');tmp.replace(p)
def main():
    OUT.mkdir(exist_ok=False);started=time.monotonic();bound=1800
    meta=json.loads((BASE/'Archive_Directory_Access.json').read_text(encoding='utf-8'))
    state={'at_utc':now(),'stage':'CLAIMED','actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixed_process_bound_seconds':bound,'received_bytes':0,'network_requests':0,'new_model_PF_optimizer_GPU_calls':0}
    with (OUT/'owner.claim').open('x',encoding='utf-8') as f:json.dump(state,f,indent=2)
    save(OUT/'Protocol.json',{'source_url':meta['source_url'],'expected_bytes':meta['archive_size'],'expected_author_sha256':meta['archive_lfs_sha256'],'fixed_bound_seconds':bound,'network_requests_max':1,'resume_or_retry':False,'scope':'Download complete pinned public data and validate hash/directory/all CRCs; do not extract or inspect time-series numerical values; no policy or physics execution.','all_entries_included':True})
    save(OUT/'status.json',state)
    try:
        req=urllib.request.Request(meta['source_url']+'?download=true&hiergrid_full_intake=20261020',headers={'User-Agent':'HierGrid-pinned-author-data','Accept-Encoding':'identity'})
        state.update(stage='TRANSFER',network_requests=1);save(OUT/'status.json',state);h=hashlib.sha256()
        with urllib.request.urlopen(req,timeout=45) as response,(OUT/'voltage_control_data.zip.partial').open('xb') as dest,(OUT/'Transfer_Journal.jsonl').open('x',encoding='utf-8') as journal:
            assert response.status==200,'Full object request did not return200; no fallback'
            while True:
                assert time.monotonic()-started<bound,'Fixed transfer bound'
                raw=response.read(8*1024*1024)
                if not raw:break
                dest.write(raw);h.update(raw);state['received_bytes']+=len(raw);assert state['received_bytes']<=meta['archive_size']
                journal.write(json.dumps({'end_offset':state['received_bytes'],'chunk_bytes':len(raw),'chunk_sha256':hashlib.sha256(raw).hexdigest()})+'\n');journal.flush()
                state['updated_utc']=now();state['elapsed_seconds']=time.monotonic()-started;save(OUT/'status.json',state)
            dest.flush();os.fsync(dest.fileno())
        assert state['received_bytes']==meta['archive_size'] and h.hexdigest()==meta['archive_lfs_sha256']
        partial=OUT/'voltage_control_data.zip.partial';archive=OUT/'voltage_control_data.zip';partial.replace(archive)
        state.update(stage='CRC_VALIDATION',sha256=h.hexdigest());save(OUT/'status.json',state)
        expected=json.loads((BASE/'All_Author_Archive_Entries.json').read_text(encoding='utf-8'))['entries']
        with zipfile.ZipFile(archive) as z:
            assert z.namelist()==[r['path'] for r in expected]
            for entry,e in zip(z.infolist(),expected):
                assert entry.file_size==e['uncompressed_bytes'] and entry.compress_size==e['compressed_bytes'] and f'{entry.CRC:08x}'==e['CRC32']
                with z.open(entry) as source:
                    while source.read(8*1024*1024):assert time.monotonic()-started<bound,'Fixed validation bound'
        state.update(stage='COMPLETE_SOURCE_INTEGRITY_PASS',all16_entry_CRCs_pass=True,finished_utc=now(),elapsed_seconds=time.monotonic()-started,time_series_values_parsed=False)
        save(OUT/'Result.json',state);save(OUT/'status.json',state)
        print(json.dumps({'status':state['stage'],'bytes':state['received_bytes'],'workflow_seconds':state['elapsed_seconds']}))
    except BaseException as exc:
        state.update(stage='TERMINAL_PARTIAL_OR_FAILED',failure_type=type(exc).__name__,failure=str(exc)[:250],finished_utc=now(),elapsed_seconds=time.monotonic()-started)
        save(OUT/'Failure.json',state);save(OUT/'status.json',state);raise
if __name__=='__main__':main()
