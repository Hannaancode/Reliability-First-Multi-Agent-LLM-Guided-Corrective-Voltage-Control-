"""Declared paired analysis: outage-family clusters keep both load levels.

Complete locked-bank ledger required. Invalid numerical pairs remain in the
denominator/failure ledger; UV differences use complete valid outage families.
One primary endpoint: HG-SE minus D-SE final UV count. Secondary metrics
are descriptive with cluster CIs; no uncorrected collection of superiority tests.
"""
import json,math,hashlib,re
from pathlib import Path
import numpy as np
from scipy.stats import binomtest
SEED=20260917
REPLICATES=10000
METRICS=['final_uv','final_deficit','accepted_actions','added_nominal_support_mvar','wall_seconds','pf_attempts','llm_calls','input_tokens','output_tokens']
def family(sid):
    m=re.fullmatch(r'rev_unseen_combined_load_1p[34]_line_(\d+)_(MG\d+)',sid);assert m
    return 'line_'+m.group(1)+'_'+m.group(2)
def summarize_case(d):
    row={'scenario_id':d['scenario_id'],'family':family(d['scenario_id']),'valid_numerical_pair':d['paired_terminal_metrics_valid'],'methods':{}}
    for name in ['D-SE','HG-SE']:
        if row['valid_numerical_pair']:
            portfolio=d['portfolios'][name];b=d['branches'][portfolio['selected_branch']];s=portfolio['summary'];cost=portfolio['charged_cost']
            row['methods'][name]={'final_uv':s['final_uv'],'final_deficit':s['final_deficit'],'accepted_actions':s['accepted_actions'],'added_nominal_support_mvar':sum(abs(float(q)) for a in b['executed_actions'] for q in a['action']['add_shunts_q_mvar'].values()),**{k:cost[k] for k in METRICS if k in cost},'finite_uv_clear_success':s['final_uv']==0}
        else:row['methods'][name]={'finite_uv_clear_success':False,'failure_or_invalid_state':True}
    return row
def analyze():
    root=Path('outputs');lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());expected={Path(n).stem:h for n,h in lock['scenario_file_sha256'].items()};paths=list((root/'matched_campaign/cases').glob('*.json'));assert {p.stem for p in paths}==set(expected),'Full 62-case ledger required before inference'
    protocol_sha=hashlib.sha256((root/'matched_campaign_protocol.json').read_bytes()).hexdigest();rows=[]
    for p in sorted(paths):
        d=json.loads(p.read_text());assert d['scenario_sha256']==expected[p.stem] and d['protocol_sha256']==protocol_sha
        rows.append(summarize_case(d))
    groups={}
    for row in rows:groups.setdefault(row['family'],[]).append(row)
    assert len(groups)==31 and all(len(rs)==2 for rs in groups.values())
    valid_groups={f:rs for f,rs in groups.items() if all(r['valid_numerical_pair'] for r in rs)};rng=np.random.default_rng(SEED)
    matrix=np.array([[np.mean([r['methods']['HG-SE'][m]-r['methods']['D-SE'][m] for r in rs]) for m in METRICS] for rs in valid_groups.values()],float)
    assert len(matrix)>0
    draws=rng.integers(0,len(matrix),size=(REPLICATES,len(matrix)));samples=matrix[draws].mean(axis=1);observed=matrix.mean(axis=0)
    signs=rng.choice([-1.,1.],size=(REPLICATES,len(matrix)));null=(signs*matrix[:,0]).mean(axis=1);p=(1+np.count_nonzero(np.abs(null)>=abs(observed[0])-1e-12))/(REPLICATES+1)
    differences={m:{'mean_paired_difference_HG_SE_minus_D_SE':float(observed[i]),'outage_cluster_percentile_bootstrap_95_percent_ci':np.quantile(samples[:,i],[.025,.975]).tolist(),'interpretation':'negative favors HG-SE for smaller-is-better metrics; nominal support is not realized reactive injection'} for i,m in enumerate(METRICS)}
    discordant_hg=sum(r['methods']['HG-SE']['finite_uv_clear_success'] and not r['methods']['D-SE']['finite_uv_clear_success'] for r in rows);discordant_d=sum(r['methods']['D-SE']['finite_uv_clear_success'] and not r['methods']['HG-SE']['finite_uv_clear_success'] for r in rows)
    n=discordant_hg+discordant_d
    report={'protocol_sha256':protocol_sha,'case_count':len(rows),'family_count':len(groups),'cluster_unit':'same outaged line and zone across the two locked load levels','seed':SEED,'resampling_replicates':REPLICATES,'valid_numerical_pairs':sum(r['valid_numerical_pair'] for r in rows),'complete_valid_family_count':len(valid_groups),'families_excluded_from_numeric_inference':sorted(set(groups)-set(valid_groups)),'invalid_or_failed_cases':[r['scenario_id'] for r in rows if not r['valid_numerical_pair']],'primary_endpoint':{'metric':'final_uv','two_sided_cluster_sign_flip_monte_carlo_pvalue':float(p),'scope':'within complete valid outage families only; cluster sign symmetry/exchangeability assumption, no missing-pair imputation or generalization to unseen systems'},'paired_differences':differences,'full_bank_finite_uv_clear_success':{m:sum(r['methods'][m]['finite_uv_clear_success'] for r in rows) for m in ['D-SE','HG-SE']},'scenario_level_exact_McNemar_descriptive':{'HG_only_success':discordant_hg,'D_only_success':discordant_d,'pvalue':float(binomtest(discordant_hg,n,.5).pvalue) if n else 1.,'scope':'descriptive only because load levels within the same outage family are dependent'},'physical_validity':'Full-bank finite UV clearance is not proof of all loads served, full voltage band, or declared slack/thermal feasibility. Independent trajectory audit remains required.','rows':rows}
    (root/'matched_campaign_family_analysis.json').write_text(json.dumps(report,indent=2,allow_nan=False));return report
if __name__=='__main__':
    report=analyze();print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
