# Candidate scientific contribution: VCSA for HierGrid

**Status:** prospective architecture and experiment design; no new weights trained yet.  
**Frozen baseline:** unchanged literal D-SE, frozen base/model/network/controller/settings, and locked 62-case bank.

## The contribution

The proposed contribution is **VCSA: Verifier-Conditioned State-Adaptive LoRA with a Physical Advantage Head**.

VCSA is a new model variant that changes the model internally in four coordinated places:

1. It injects a typed representation of the current bus state and candidate scope into selected transformer layers through a small graph/state cross-attention module.
2. It splits the LoRA update into rank groups and uses the current state embedding to gate those groups at inference time. This is a state-conditioned rank allocation, rather than the static importance allocation in AdaLoRA.
3. It adds a factorized action head for `bus -> Q` proposals and a physical process head that predicts the verifier-relevant progress of each candidate.
4. It trains the proposal and process heads from exact physical counterfactuals, with a conservative abstention gate that falls back to unchanged D-SE when support or confidence is insufficient.

The scientific claim would be that **state-conditioned internal adaptation plus process-level physical supervision lets a small language model produce admissible, novel candidates that improve a fixed deterministic portfolio**. That claim is deliberately falsifiable. The architecture itself is not being presented as proven novel until a final prior-art and implementation comparison is completed.

## Why this is a real model contribution

The current model has a prefix adapter that emits proposals, but it has no learned internal representation of physical progress and no learned mechanism that decides which internal adapter capacity is relevant to the current grid state. VCSA adds trainable parameters inside the model computation and gives them a supervised physical objective. It therefore tests a change to the model, rather than another prompt, Q order, budget, or post-hoc selector.

The components are individually grounded in prior work, but their combination targets a gap:

* LoRA provides the parameter-efficient update; DoRA and AdaLoRA show that the structure and allocation of low-rank updates affect adaptation quality.
* Prefix-tuning and AdapterFusion show that small learned modules can condition or compose a frozen language model without rewriting the base.
* GL-Fusion motivates cross-attention between graph structure and language representations, but it does not train a physical action/progress head for this grid-control problem.
* Decision Transformer and Trajectory Transformer show how state, action, and return can be represented as a sequence. VCSA instead uses a protected vector of physical progress quantities and an exact verifier.
* Process-reward work motivates dense intermediate labels; CQL/IQL motivate conservative handling of unsupported actions.
* DAgger motivates collecting labels on states induced by the learner, rather than only on expert states.

The new part is **state-conditioned rank routing supervised by a vector physical advantage signal, coupled to a factorized action head and an exact-verifier abstention boundary**. I found no directly matching power-system LLM method in the reviewed primary literature. This remains a candidate novelty statement, not a publication guarantee.

## Model architecture

Let `s_t` be the freshly observed grid state, `G_t` the typed bus/topology representation, `c_t` the exact admissible candidate set, and `h_t` the frozen transformer hidden states.

### State cross-attention

Encode each active bus, generator, load, outage/topology flag, voltage, and candidate-bound flag with a small trainable state encoder `E_psi(G_t)`. At two predeclared transformer blocks, fuse the state tokens with the language hidden states:

```text
z_t = h_t + alpha_t * W_o CrossAttention(h_t, E_psi(G_t))
alpha_t = sigmoid(w_alpha^T mean(E_psi(G_t)))
```

The gate is initialized so the new path is near-zero at the start of training. This makes the frozen base/current-LoRA control a meaningful initialization and allows a clean state-fusion ablation.

### State-adaptive low-rank update

Partition the adapter into `R` rank groups. A small router produces `g_t in [0,1]^R` from the state embedding, with a fixed sparsity/entropy regularizer and a fixed maximum active rank. The update is:

```text
DeltaW_t = sum_r g_t[r] * B_r A_r
```

Unlike AdaLoRA's training-time matrix importance allocation, the gate is state-dependent at inference and is trained against physical progress. The maximum rank, group count, and regularization coefficient are frozen before training; they are not selected by looking at confirmation results.

### Factorized action head

The action head predicts a bus distribution and a conditional Q distribution over the raw candidate scope. Invalid bus/Q pairs are masked before decoding. The generated JSON proposal is still passed through the existing exact common-and-zone membership contract. This head gives a direct gradient to the action choice instead of relying entirely on next-token likelihood.

### Physical process head

For each proposed candidate, a small head predicts:

```text
[delta_UV, delta_normal_upper, delta_deficit, PF_failure_probability,
 support_probability, incremental_full_cost]
```

These are auxiliary predictions for ranking and abstention. They never replace the exact replay verifier. The head is trained on the training-scenario counterfactual table and calibrated only on validation scenarios.

## Training objective

For a training state with preferred candidate `a+` and rejected candidate `a-`, use:

```text
L = L_lm
  + lambda_action * L_factorized_action
  + lambda_pref * L_pairwise_physical_preference
  + lambda_process * L_physical_progress
  + lambda_support * L_conservative_support
  + lambda_consistency * L_state_format_consistency
```

* `L_lm` retains the original language ability.
* `L_factorized_action` supervises bus and Q separately.
* `L_pairwise_physical_preference` is a DPO-style pairwise loss, with preference determined by the predeclared lexicographic physical objective: protected UV count, normal-upper violation, residual deficit, support, then full cost.
* `L_physical_progress` is dense process supervision after each candidate, not only a terminal label.
* `L_conservative_support` penalizes high confidence on unsupported or out-of-scope candidates.
* `L_state_format_consistency` requires the same action distribution under two semantically equivalent serialization orders, while preserving the exact bus IDs and candidate set. This tests whether the model uses state rather than accidental textual position.

All coefficients, rank groups, active layers, seeds, and stopping rules must be frozen in the training manifest before any confirmation inference.

## Data construction without leakage

Use only the recovered grouped training archive in `outputs/recovered_training_provenance_assets.json`. The current audit records 109/13/15 physical scenarios and 16,000/2,000/2,000 JSONL records, with zero exact physical overlap with the locked 62-case bank and zero exact overlap with the recovered historical scenarios. It also warns that the same outage/DER pattern is shared, so no cross-grid or unseen-outage claim is allowed.

For the 109 training scenarios only:

1. Reconstruct the recorded state and exact raw candidate set.
2. Evaluate DFF, DFF-ALT, and additional admissible candidates using the original physical replay.
3. Record every success, failure, unsafe action, unsupported action, and full cost.
4. Form preferred/rejected pairs and dense progress labels without using validation, test, Stage 3, or locked-bank outcomes.
5. Freeze the resulting pair manifest and hashes.

Validation scenarios are for calibration and diagnostics. The 15-scenario test split is used once for development reporting. A separate unused confirmation source is required before any superiority claim.

## Ablation matrix

The first architecture campaign should contain these fixed variants:

| Variant | New trainable component | Purpose |
|---|---|---|
| D-SE | none | Primary deterministic comparator |
| frozen base | none | LLM-off control |
| current LoRA | existing adapter only | Existing model reference |
| static VAC-SFT | action head + static adapter | Tests verified action traces |
| state-fusion | state cross-attention only | Tests physical state injection |
| VCSA-process | state fusion + process head | Tests dense physical supervision |
| VCSA-full | state fusion + adaptive rank + action/process heads + abstention | Full proposed method |
| VCSA-full + DAgger | full method plus training-only induced-state aggregation | Later distribution-shift test |

The DAgger extension is not run unless VCSA-full produces a nonzero rate of admissible novel candidates. Otherwise it would add complexity without testing a live hypothesis.

## Falsifiable success criteria

VCSA is useful only if all of the following hold on the frozen confirmation manifest:

1. It changes the selected action on a recorded nonzero fraction of states.
2. The changed actions are physically admissible and pass independent replay identity checks.
3. The primary protected endpoint improves against literal D-SE, or a predeclared equal-cost trade-off improves without safety loss.
4. Any gain remains after charging generation, repair, model-load, and physical-replay costs.
5. The result is reproduced by an independent evaluator using the same manifest and hashes.

Stop and retain a null result if VCSA produces no novel actions, only learns to imitate D-SE, increases cost without endpoint gain, or causes any safety regression. Do not change prompts, Q order, normal thresholds, seeds, or budget after observing the sign.

## Implementation order

1. Let the active Stage 3 campaign finish and preserve its exact artifacts.
2. Build a CPU-only schema and pair-manifest checker; do not train or call a GPU.
3. Implement state encoder, gated cross-attention, factorized action head, process head, and rank router behind a new namespace; do not edit the frozen model files.
4. Run shape, masking, adapter enable/disable, serialization-invariance, and zero-solver-during-generation tests.
5. Generate training-scenario physical labels and freeze the pair manifest.
6. Train static VAC-SFT and VCSA-full as separately hashed adapters on one authorized T4 allocation.
7. Audit validation/test physical replay and support calibration on CPU.
8. Freeze a confirmation manifest only if the novel-candidate gate passes; then run matched D-SE/base/current-LoRA/VCSA evaluation.

No step above assumes VCSA will beat D-SE. The contribution is the architecture and the evidence-led test of whether internal state-conditioned adaptation can create useful, physically valid actions.

## Primary references

[AdaLoRA](https://arxiv.org/abs/2303.10512), [DoRA](https://arxiv.org/abs/2402.09353), [AdapterFusion](https://arxiv.org/abs/2005.00247), [Prefix-Tuning](https://arxiv.org/abs/2101.00190), [Decision Transformer](https://arxiv.org/abs/2106.01345), [Trajectory Transformer](https://arxiv.org/abs/2106.02039), [GL-Fusion](https://arxiv.org/abs/2412.06849), [CQL](https://arxiv.org/abs/2006.04779), [IQL](https://arxiv.org/abs/2110.06169), [DAgger](https://arxiv.org/abs/1011.0686), [ReST](https://arxiv.org/abs/2308.08998), [STaR](https://arxiv.org/abs/2203.14465), [T1 tool-integrated verification](https://arxiv.org/abs/2504.04718), and [GridMind](https://arxiv.org/abs/2509.02494).
