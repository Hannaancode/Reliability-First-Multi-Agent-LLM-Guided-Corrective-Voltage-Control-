"""Persistent six-goal checklist, evidence-bound completions and resume links."""
import hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];B=R/'outputs/research_tasks_20261014';HAND=R/'outputs/substantive_research_progress_20261018'
def read(p):return json.loads(Path(p).read_text('utf-8-sig'))
def write(p,data):
    p.parent.mkdir(exist_ok=True,parents=True);tmp=p.with_suffix(p.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:json.dump(data,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def main():
    at=datetime.now(timezone.utc).isoformat();old=R/'RESEARCH_TASKS.md';archive=B/'Task_List_Before_Checklist_20261018.md'
    assert not archive.exists();prior=old.read_bytes();archive.write_bytes(prior)
    tasks=read(B/'Tasks.json');assert [t['priority'] for t in tasks['tasks']]==list(range(1,7))
    def step(identifier,text,evidence=None):
        if evidence:assert (R/evidence).is_file(),evidence
        return {'id':identifier,'completed':evidence is not None,'description':text,'evidence':evidence,'verified_at_save':at if evidence else None}
    records=[
      {'id':'G1','priority':1,'title':'Zero UV on every declared severe federation case using our LLM-assisted system, and beat the original deterministic DSE safely.',
       'completion_criteria':['Audit all141 federation recipes and declare the full severe-case roster before new outcomes; missing initial/results stay UNKNOWN.',
         'Complete matched protected trajectories for every declared severe case, zeroUV with no weakened safety/actions/operation/resource limits.',
         'Show a prespecified improvement over original DFF,DFF-ALT and unchanged DSE, reporting each branch and FULL BOTH-branch plus model/training/preparation/failure costs.',
         'Independent source/physical/continuous replay/full-state/cost evidence and unused authorized confirmation.'],
       'current_result':'Two distinct development worlds have observed zeroUV from archived trained-LLM prefixes plus numerical control. Line36:33to0UV,24/25operations,upper guardPASS. Its26th fullcheckpoint and branchclosure are missing; full4world and allsevere goals UNKNOWN.',
       'steps':[step('G1.1','Index all141 federation recipes; retain68historical results and73missing asUNKNOWN.','outputs/research_tasks_20261014/All141_Federation_Case_Status.json'),
         step('G1.2','Verify recorded zeroUV transitions on line35 within the preserved26commit audit.','outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json'),
         step('G1.3','Verify another world,line36:33residualUVto0; retain missing closure/checkpoint limits.','outputs/observed_unclosed_zero_state_audit_20261018/Results.json'),
         step('G1.4','Complete independent physical-component index of all60426 tracked prior PF inputs; both proposed actions have0component matches.','outputs/prior_physical_query_footprints_20261018/independent_audit/Independent_Audit.json'),
         step('G1.5','Close remaining prior-history scope and freeze the exact unexecuted-query/persistent warm-cold/ownership/reader protocol.'),
         step('G1.6','Execute the justified next new query test once, preserve every result/failure/cost, then assess its fixed gate.'),
         step('G1.7','Complete matched full protected hybrid/DFF/DFF-ALT/DSE and strong numerical trajectories on the entire declared severe roster.'),
         step('G1.8','Independently confirm zeroUV across that roster and the prespecified deterministic-comparison improvement.')]},
      {'id':'G2','priority':2,'title':'Test our actual model/system on a published physical dataset.',
       'completion_criteria':['Preserve dataset license/version/native constraints and disclose any necessary role/actuator adaptation.',
         'Use verified common initialization and frozen model/control interface; run every declared identity with independent physics/full costs.'],
       'current_result':'Three official PGLib118 variants are pinned and audited. All3new SLSQP final points failed fixed5e-6native feasibility; a model test has not been completed.',
       'steps':[step('G2.1','Pin and audit all3published full native case inputs/constraints.','outputs/public118_native_acopf_reference_20261015/Protocol.json'),
         step('G2.2','Complete and independently report all3fixed SLSQP trials, including all3failed feasibility gates.','outputs/public118_slsqp_native_20261018/independent_audit/Independent_Audit.json'),
         step('G2.3','Establish a faithful verified public initialization/evaluation contract without rescuing stopped trials by retuning.'),
         step('G2.4','Test our actual model/hybrid and equally informed controls on every preregistered public test identity.')]},
      {'id':'G3','priority':3,'title':'Benchmark against comparable published methods/models and establish whether ours is better.',
       'completion_criteria':['Select relevant reproducible primary-source methods and document fidelity and task differences.',
         'Match plant,information,actions,protection,budgets,splits and costs; report all wins/ties/losses/failures.',
         'Claim superiority only if frozen comparison and independent unused confirmation support it.'],
       'current_result':'Native classical public benchmark execution is recorded, including strict failures. No completed published-system comparison establishes our superiority.',
       'steps':[step('G3.1','Record the source-faithful all3native classical benchmark trial and independent outcomes.','outputs/public118_slsqp_native_20261018/independent_audit/Independent_Audit.json'),
         step('G3.2','Freeze comparable published-method reproduction/adaptation protocols and strong trained numerical controls.'),
         step('G3.3','Run matched benchmarks with all outcomes, total costs and independent physical replay.'),
         step('G3.4','Confirm any superiority claim on genuinely unused authorized cases.')]},
      {'id':'G4','priority':4,'title':'Compare higher-parameter adapted small language models fairly.',
       'completion_criteria':['Use the same serving role,data/context/split,training/final-checkpoint rules and evaluation identities; disclose architecture/FLOP/precision differences.',
         'Record complete outcomes and compute/training/failure costs. Partial/OOM stays partial and is never a successful larger-model result.'],
       'current_result':'Matched0.5B41.6667%/1.5B53.125%teacher action accuracy,100%schema both; numerical72.9167%,fixed gateFAIL.3Bpartial logical upper59.375%below numerical;7Bfirst-backwardOOM. Fixed interventions stopped.',
       'steps':[step('G4.1','Complete matched adapted0.5B/1.5Bcomparison and preserve its failed numerical gate.','outputs/matched_scale_20261011/verified_completion_handoff_20261012/Verified_Matched_Scale_Completion.json'),
         step('G4.2','Retain higher3Bpartial/7BOOM evidence and bounds without silently completing missing outputs.'),
         step('G4.3','If justified by a materially different mechanism, freeze and complete a fair higher-model comparison; do not repeat size-only failed imitation.')]},
      {'id':'G5','priority':5,'title':'Demonstrate genuine incremental LLM superiority.',
       'completion_criteria':['Fresh per-state LLM inference and matched complete physical outcomes.',
         'With/without-LLM ablations under identical information/actions/protection/budgets, plus strong numerical and architecture/pretraining controls.',
         'Prespecified improvement after full model/training/preparation/solver/failure costs and independent unused confirmation.'],
       'current_result':'Unachieved. Numerical improvements, schema accuracy, readiness and larger-model teacher gains do not isolate an LLM contribution.',
       'steps':[step('G5.1','Freeze an evidence-supported causal LLM contribution and complete ablation/attribution protocol.'),
         step('G5.2','Execute matched fresh-inference physical comparisons with full costs.'),
         step('G5.3','Independently validate the incremental contribution on unused authorized confirmation.')]},
      {'id':'G6','priority':6,'title':'Implement and validate cybersecurity after the control/attribution gates.',
       'completion_criteria':['Freeze a causal threat model and matched attack/defence baselines.',
         'Measure full protected physical outcomes, attack/defence costs and independent confirmation; retain all failures.'],
       'current_result':'Deferred. Earlier24trial96proposal QA is a development pilot, not full FDIA/security validation.',
       'steps':[step('G6.1','After control/attribution gates, define attacks,defences,causal access and security acceptance criteria.'),
         step('G6.2','Run matched attack/defence experiments and independently confirm physical security outcomes.')]}]
    for record,task in zip(records,tasks['tasks']):
        task['completed']=False;task['checklist_id']=record['id'];task['completion_criteria']=record['completion_criteria'];task['current_result']=record['current_result'];task['subtasks']=record['steps']
    tasks['at_utc']=at;tasks['master_checklist']='RESEARCH_TASKS.md';tasks['goal_completion_rule']='Check and strike through a top-level goal ONLY after all its evidence-bound acceptance criteria pass. An executed failed/partial experiment can be a completed reporting step, never a passed goal.'
    tasks['maintenance_rule']='At each continuation read RESEARCH_TASKS.md plus newest headers/exact resume. At each verified result update stable subtask IDs, status/current_result/evidence, reseacrh progress.txt and exact resume. Preserve earlier results/failures and never repeat completed or stopped experiments.'
    tasks['process_ownership_at_save']='Original60426-input producer and independent reader ended,Completion reader_exit_code0. Old waiting automation deleted. Separate zero-science fresh3418observedcomponent scope check may be live; verify its actualclaim/command.'
    write(B/'Tasks.json',tasks)
    lines=['# HierGrid — master research checklist','',f'Updated {at}. Human priority order is preserved. **0 of6 final goals verified complete.**','',
      'This is the current checklist. Older operational notes were preserved in [the archived task list](outputs/research_tasks_20261014/Task_List_Before_Checklist_20261018.md).','',
      'Ticked subtasks mean that the named work and report are complete; they do not turn a failed experiment into a successful method. A whole goal is ticked and crossed out only when its acceptance criteria pass.','']
    for r in records:lines.append(f"- [ ] **{r['id']}. {r['title']}**")
    lines += ['', '## Evidence and next actions','']
    for r in records:
        lines += [f"### {r['id']}. {r['title']}",'',r['current_result'],'']
        for s in r['steps']:
            text=s['description']
            if s['evidence']:text+=f" [Evidence]({s['evidence']})"
            lines.append(f"- [{'x' if s['completed'] else ' '}] `{s['id']}` {text}")
        lines += ['','Done only when: '+ ' '.join(r['completion_criteria']),'']
    lines += ['## Continuation and record keeping','',
      '- Read this checklist and the newest runbook/plan headers before continuing. Use stable IDs such as G1.5 so no task disappears between runs.',
      '- Update checkboxes only from actual closed evidence; record the method,result,improvement,limitation and evidence path in reseacrh progress.txt.',
      '- Preserve failed/partial/UNKNOWN results and stopped interventions. No outcome-driven retunes, scientific repeats, old-budget extensions, weakened controls or promised winning percentages.',
      '- Keep original frozen assets and literal DFF+DFF-ALT+unchanged DSE. Report both branches and FULL BOTH costs.',
      '- Use an estimated one-time result check only when a confirmed live result is the sole dependency and useful parallel work is finished. Remove it at terminal; do not revive old recurring timers.',
      '- Continue useful authorized work as gates pass. No premature tick on zero-all, public-model testing, published superiority, LLM attribution or security.',
      '', '[Detailed structured tasks](outputs/research_tasks_20261014/Tasks.json) · [Latest exact resume](outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json) · [Progress log](reseacrh%20progress.txt)','']
    old.write_text('\n'.join(lines),'utf-8')
    completion=read(R/'outputs/prior_physical_query_footprints_20261018/Completion.json');assert completion['reader_exit_code']==0
    idx=read(R/'outputs/prior_physical_query_footprints_20261018/independent_audit/Independent_Audit.json')
    state=read(HAND/'Exact_Next_Execution_State.json');state['at_utc']=at;state['master_checklist']='RESEARCH_TASKS.md';state['structured_task_list']='outputs/research_tasks_20261014/Tasks.json';state['task_list_maintenance']=tasks['maintenance_rule']
    state['current_task']={'status':'INDEX_AND_INDEPENDENT_READER_COMPLETE_PASS_NEXT_HISTORY_SCOPE_CHECK','result':idx,'new_scientific_calls':0,
        'next_source':'work/close_fresh_observed_shunt_scope_20261018.py','next_output':'outputs/fresh_observed_shunt_scope_20261018','ownership':'Verify fresh actualclaim/PID/command; do not start a duplicate.'}
    state['timers']='Completed physical-input waiting automation deleted after actualproducer/readerterminal. No recurring timer revived.';write(HAND/'Exact_Next_Execution_State.json',state)
    cont=read(HAND/'Physical_Input_Index_Continuation.json');cont['at_utc']=at;cont['status']='TERMINAL_COMPLETE_INDEPENDENT_PASS';cont['actual_progress_snapshot_not_completion']={'decoded_inputs':idx['decoded_inputs'],'unique_components':idx['unique_components'],'completed':True};cont['independent_result']=idx;cont['one_time_followup']['status']='DELETED_AFTER_TERMINAL';cont['master_checklist']='RESEARCH_TASKS.md';write(HAND/'Physical_Input_Index_Continuation.json',cont)
    note=f'\n{at} MASTER CHECKLIST UPDATED: RESEARCH_TASKS.md retains all6humanpriorities with stableIDs, evidence-backed checked subtasks and unchecked finalgoals. Oldtasklist archivedexactly. All60426trackedPFphysicalinputs independentlyPASS,0matches to bothproposedqueries; notglobalnewPFauthority. Waitingtimerdeleted afteractualcompletion; fresh3418observedshuntcomponent closure continuing0science. Fullgoalsremain0of6verifiedcomplete.\n'
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write(note)
    header=f'CURRENT MASTER CHECKLIST AND COMPLETED INPUT AUDIT {at}\n\nRead RESEARCH_TASKS.md and outputs/research_tasks_20261014/Tasks.json each continuation; preserve all6priorities and update evidence-backed checkboxes after results.0of6finalgoalscomplete.60426-input producer+independentreaderCOMPLETE/PASS,bothcandidatecomponentmatches0; broaderscope/execution gates remain. Oldwaitingautomationdeleted. Separate fresh3418observedcomponent check continues; verify actualowner beforeintervention. Exactresume outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json.\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_INDEX.md']:
        path=R/rel;path.write_text(header+path.read_text('utf-8-sig'),'utf-8')
    write(B/'Checklist_Update_20261018.json',{'at_utc':at,'master':'RESEARCH_TASKS.md','structured':'outputs/research_tasks_20261014/Tasks.json','prior_task_list_sha256':hashlib.sha256(prior).hexdigest(),
        'goals':6,'verified_complete_goals':0,'checked_subtasks':sum(s['completed'] for r in records for s in r['steps']),'all_task_IDs_retained':True,'waiting_timer_deleted':True})
    print(json.dumps({'master_checklist_saved':True,'goals':6,'completed_final_goals':0,'checked_subtasks':sum(s['completed'] for r in records for s in r['steps'])}))
if __name__=='__main__':main()
