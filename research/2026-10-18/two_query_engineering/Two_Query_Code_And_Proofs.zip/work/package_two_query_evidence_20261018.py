"""Seal complete local query evidence and screen a separate public code/proof pack."""
import hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from candidate_process_evidence_utils import seal,frozen_checks
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME,TEXT
B=R/'outputs/exact_two_paid_query_engineering_20261018'
SOURCES=['certify_exact_two_query_coverage_20261018.py','exact_two_paid_query_engineering_20261018.py','audit_exact_two_paid_query_engineering_20261018.py',
    'prepare_exact_two_paid_query_engineering_20261018.py','audit_exact_two_query_source_claim_v2_20261018.py','run_two_query_analysis_repair_20261018.py','record_two_query_checkpoint_20261018.py',
    'replay_paid_suffix_new_receipts_v3_20261018.py','package_two_query_evidence_20261018.py']
def main():
    audit=read(B/'audit_source_claim_v2/Independent_Audit.json');assert audit['status']=='PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING'
    output=B/'sealed_completion';output.mkdir(exist_ok=False)
    ledger={'at_utc':datetime.now(timezone.utc).isoformat(),'status':audit['status'],'actual_scientific_costs':audit['costs'],
        'preparation_zero_science_workflow_seconds':read(B/'Readiness.json')['workflow_seconds'],
        'phases':{m:{'owner':read(B/m/'owner.claim'),'launcher_ACK':read(B/m/'Launcher_ACK.json'),'End_ACK':read(B/(m+'_End_ACK.json')),
            'workflow_seconds':read(B/m/'Result.json')['workflow_seconds']} for m in ('warm','cold')},
        'reader':{'owner':read(B/'audit_source_claim_v2/owner.claim'),'End_ACK':read(B/'audit_source_claim_v2_End_ACK.json'),'workflow_seconds':audit['workflow_seconds']},
        'original_failed_analysis_launch':read(B/'reader_source_claim_repair_v2/Original_Coordinator_Failure.json'),
        'original_deadline_utc':read(B/'Protocol.json')['absolute_deadline_utc'],'no_original_budget_extended':True,
        'source_preparation_training_data_old_physics_costs':'Retained in pinned provenance; not free, not allocated uniform guessed costs. Workflow/phase timings nest preservation and are not blindly summed.',
        'new_LLM_GPU_optimizer_derivative_forecast_solve_actual_commit_calls':0,'all_final_goals_open':True}
    put(output/'Execution_Ledger.json',ledger);put(output/'Frozen_Completion.json',frozen_checks())
    (output/'Results.md').write_text('''# Fixed two-query result — 18 October 2026

G1.5 and G1.6 complete: independent query/cold-preservation engineering PASS.
Neither action is accepted; the current saved state remains at17UV.

| Fixed query | Measured UV | Vmmax | Original protected decision |
|---|---:|---:|---|
| Owned100MVAr, bus32 to42 | 17 to14 | 1.0554550647 | Reject: normal upper band |
| Owned25MVAr, bus0 to44 | 17 to18 | 1.0500403307 | Reject: UV increased; upper band also violated |

Exactly2newprimaryPF+2explicitlychargedindependentreplays,4returns,0exceptions.
Both replays match all118bus voltage/angle/P/Q fields with maximum delta0.0.
Actual PF time11.198982799993246seconds; preservation0.9258079999926849seconds is
recorded inside the workflow, not added twice. No LLM/GPU/optimizer/new derivative,
forecast or linear solve, and no actual commit.

The cold child restored the exact currentNET/cursor, complete query registry,
hash-chained history, RNG, costs, source/input anchors and original new absolute
deadline before querying the second fixed identity. This is query-only engineering
at an observed hypothetical paid AFTER, not an original deployment/controller
restart or recovery of a missing old checkpoint. All nine frozen checks pass.

Original reader launch failed because imported claim() used the worker __file__.
Both scientists had already ended. Original claims/source/stderr are retained.
A separate reader output fixes only source-claim binding/output path; its original
verifier, inputs, cost, replay and full-state checks remain exact. It made0newPF.

No new accepted UV reduction, whole-policy/DSE superiority, LLM causal advantage,
zero-all result or unused confirmation follows. All six final goals remain open.
Next: incorporate BOTH receipts into the same fixed causal decision analysis;
stop at the next missing identity without new physics or invented successor.
''','utf-8')
    files={str(p.relative_to(R)).replace('\\','/'):p for p in B.rglob('*') if p.is_file() and 'sealed_completion' not in p.parts and 'publication' not in p.parts}
    for name in SOURCES:files['work/'+name]=R/'work'/name
    for p in (R/'outputs/next_exact_paid_query_preparation_20261018').iterdir():
        if p.is_file():files[str(p.relative_to(R)).replace('\\','/')]=p
    for name in ('Execution_Ledger.json','Frozen_Completion.json','Results.md'):files['completion/'+name]=output/name
    local=seal(output,files,'Complete_Local_Two_Query_Evidence.zip')
    public=B/'publication';public.mkdir();selected={};excluded=[]
    for relative,h in read(B/'Protocol.json')['source_input_sha256'].items():
        p=R/relative
        if p.suffix=='.py':selected[relative]=p
    for name in SOURCES:selected['work/'+name]=R/'work'/name
    for root in (B,output):
        for p in root.rglob('*'):
            if not p.is_file() or any(n in p.parts for n in ('publication','progress_before_update')):continue
            relative=str(p.relative_to(R)).replace('\\','/')
            if p.suffix in {'.json','.md','.log'} or p.name=='owner.claim':selected[relative]=p
            else:excluded.append({'path':relative,'bytes':p.stat().st_size,'sha256':sha(p),'reason':'Binary raw NET/state/capsules remain local; exact hashes retained'})
    for relative in ['RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json','reseacrh progress.txt']:selected[relative]=R/relative
    withheld=[]
    for name,p in list(selected.items()):
        if SECRET_NAME.search(p.name) or any(pattern.search(p.read_text('utf-8')) for pattern in SECRET):withheld.append(name);del selected[name]
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in selected.items()}
    summary={'status':'PREPARED_PUBLIC_CODE_AND_PROOF_PACK_NOT_FULL_RAW_BACKUP','files':desc,'withheld_secret_screen':withheld,'local_binary_evidence':excluded,
        'local_complete_archive':local,'all6goalsopen':True,'new_SLM_superiority':False}
    put(public/'Manifest.json',summary)
    archive=public/'Two_Query_Code_And_Proofs.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in selected.items():z.write(p,n)
        z.write(public/'Manifest.json','Manifest.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(selected)+1
        for n,m in desc.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
    put(public/'Package_Audit.json',{'status':'PASS_CRC_ALL_HASH_SECRET_SCREEN','members':len(selected)+1,'bytes':archive.stat().st_size,'sha256':sha(archive),
        'withheld_secret_paths':withheld,'large_raw_NET_state_capsules_local_only':True})
    print(json.dumps({'local_archive':local,'public_pack_bytes':archive.stat().st_size,'public_members':len(selected)+1,'secrets_withheld':len(withheld)}))
if __name__=='__main__':main()
