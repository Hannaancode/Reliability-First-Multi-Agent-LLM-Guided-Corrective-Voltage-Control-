"""Source-bound paper-system trace and common-case benchmark registration.

This prepares comparison inputs, not policy outcomes. No model/PF/training call.
"""
import ast,collections,copy,csv,hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/full_system_comparison_20261021'
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def put(path,value):
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.flush();os.fsync(f.fileno())
def defs(rel,names):
    path=ROOT/rel;tree=ast.parse(path.read_text(encoding='utf-8'));rows=[]
    for name in names:
        node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        rows.append({'function':name,'line':node.lineno,'end_line':node.end_lineno,
                     'AST_sha256':hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()})
    return {'source':rel,'source_sha256':sha(path),'functions':rows}
def main():
    OUT.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    matched=read(ROOT/'outputs/matched_campaign_protocol.json')
    for p,h in matched['source_sha256'].items():assert sha(ROOT/p)==h,'Frozen original source changed'
    metadata=read(ROOT/'outputs/notebook_reference_review_20261020/Original_Adapter_Metadata_Reconciliation.json')
    assert metadata['final_trainer']['global_step']==2000 and metadata['final_trainer']['epoch']==2
    adapter=read(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/adapter_config.json')
    assert adapter['r']==adapter['lora_alpha']==16 and len(adapter['target_modules'])==7
    traces=[
      defs('work/e/audit/phase2g_multiagent_llm_runner.py',['load_llm','generate_response','extract_json']),
      defs('work/e/audit/phase2g_llm_guided_rescue_runner.py',['get_zone_candidate_buses','get_llm_action_required','llm_guided_refinement_candidates','fallback_physics_candidates','run_one_scenario_llm_guided']),
      defs('work/e/audit/phase2g_rescue_runner.py',['extract_zone_state_full','normalize_action','apply_action','verify_action','score_candidate']),
      defs('work/e/audit/run_reflection_v4_safety_envelope.py',['init_feedback_state','build_compact_feedback_text','normalize_compact_or_nested_action','run_one_scenario_two_best_v2','run_one_scenario_no_llm_fallback_first','choose_safety_envelope']),
    ]
    put(OUT/'Original_Paper_System_Source_Map.json',{
      'at_utc':at,'status':'SOURCE_BOUND_ORIGINAL_LORA_MULTIAGENT_VERIFIER_REFINEMENT_ROUTER_MEMORY_AND_PORTFOLIO_TRACE',
      'training_provenance':'Phase2A notebook cell37 compact messages;cell40 SFT recipe; saved original adapter/checkpoint2000 metadata. Not exact historical runtime reconstruction.',
      'model':{'family':'Qwen2.5-0.5B-Instruct','quantized_base_bits':4,'LoRA_rank_alpha_dropout':[16,16,0],
               'target_modules':adapter['target_modules'],'trainable_adapter_parameters':8798208,
               'saved_training_epochs_steps':[2,2000],'notebook_training_max_length':512,
               'notebook_ultra_data_max_tokens':461,'agents':'Four zones share one trained adapter; not four independently trained LLMs.'},
      'system_flow':['Current zone/global measurements and allowed candidates','Shared trained LoRA supplies JSON bus/Q proposal',
                     'Preserved normalizer and physical verifier test proposals','Q refinement around LLM-selected buses',
                     'Fallback only under original trigger','Source-priority router commits an accepted action',
                     'Causal accepted/rejected/weak-action memory and fixed25-step loop','Safety-envelope variant evaluates both complete branches and uses unchanged selector'],
      'variants':{'HG_VF':'Reflection-v2 verified LLM-guided branch','HG_SE':'DFF plus HG_VF with original selector; FULL BOTH costs',
                  'D_SE':'DFF plus DFF_ALT with identical selector; FULL BOTH costs'},
      'source_native_control':'Capacitive shunt additions,25..300Mvar grid, cumulative450Mvar/bus; not native public-PV inverter commands.',
      'native_safety_and_metrics':'Historical verifier hardOV1.06 and reported zeroUV are distinct from full-band0.95..1.05 compliance. Preserve native algorithm; report both metrics. Common-guard wrapper must be a named adaptation for ALL methods.',
      'not_silently_in_pipeline':['NERC-RAG QA notebook results','An unrecovered critic module not called by these entry points','Newly fitted ExtraTrees or kernel models'],
      'known_provenance_limits':['Historical exact base snapshot unrecovered','Exact historical collator loss mask not fully established','Paper25-case aggregate not relabelled as a public-grid result'],
      'traces':traces,'original_training_metadata_reference':'outputs/notebook_reference_review_20261020/Original_Adapter_Metadata_Reconciliation.json',
      'new_scientific_calls':0})
    # Full existing federation cohorts, never chosen from favorable outcomes.
    roster=read(ROOT/'outputs/all141_benchmark_roster_20261018/All141_Exact_Recipe_Roster.json')
    assert len(roster)==len({r['world'] for r in roster})==141
    cases=[];types=collections.Counter()
    for row in roster:
        path=ROOT/row['recipe_path'];assert sha(path)==row['recipe_sha256'];recipe=read(path)
        kind=recipe.get('scenario_type','UNSPECIFIED');types[kind]+=1
        cases.append({'cohort':'FED141_DEVELOPMENT','case_id':row['world'],'recipe':row['recipe_path'],
                      'recipe_sha256':row['recipe_sha256'],'input_stratum':kind,'data_role':'Historical/inspected development; never unused confirmation',
                      'shared_initial_physical_state_digest':'PENDING_exact_solved_root_and_initializer_binding',
                      'benchmark_outcomes':'NOT_JOINED_OR_EXECUTED_FOR_THIS_NEW_PROTOCOL'})
    lock=read(ROOT/'work/e/bank/BANK_LOCK.json');assert len(lock['scenario_file_sha256'])==62
    for name,h in sorted(lock['scenario_file_sha256'].items()):
        assert sha(ROOT/'work/e/bank/scenarios'/name)==h
        cases.append({'cohort':'SEALED62_HISTORICAL_DEVELOPMENT','case_id':Path(name).stem,
                      'recipe':('work/e/bank/scenarios/'+name),'recipe_sha256':h,
                      'input_stratum':'LOCKED_EXISTING_BANK','data_role':'Already inspected; original bank name is not current unused status',
                      'shared_initial_physical_state_digest':'PENDING_reuse_exact_existing_solved_root_not_rerun',
                      'benchmark_outcomes':'Old sealed results retained; require exact horizon/controller/source/cost match before reuse'})
    assert len(cases)==203 and len({c['case_id'] for c in cases})==203
    put(OUT/'All203_Existing_Federation_Input_Cases.json',cases)
    # Public engineering cases are explicitly separate from publication cohorts.
    put(OUT/'Public_Case_Tracks.json',{
      'PUBLIC322':{'author':'TPA/MAPDN','engineering_case':{'year':'2013','month':'1','day':'20','day_id':'385','idx':'185262'},
                   'initial_UV':108,'comparison_record':'TPA77UV;ourNUM0UV,0OV both; original full LLM system NOT evaluated',
                   'main_target':'All120author test rows retained in source order; full exact schedule closure required before launch',
                   'unused_confirmation':False,'conditioning_overlap':'40author2012rows overlap seasonal conditioning; no silent causal/unused claim'},
      'PUBLIC13':{'engineering_seeds':list(range(500,508)),'additional_fixed_development_roots':True,
                  'author_test_target':'All500source-seed recipes0..499,low/high source regimes; exact input-vector manifests before launch',
                  'original_HG_complete_system_result':'PENDING_NAMED_LEGAL_INVERTER_PORT',
                  'eight_is_case_count_not_UV_count':True},
      'PUBLIC56_OR_123':'Separate native source/action/topology/solver contracts; no merged cross-network rankings',
      'no_case_set_performance_selection':True,'full_case_counts_not_completed_benchmark_counts':True})
    arms=[
      {'id':'HG_PAPER_VF','owner':'OURS','role':'Original trained0.5B/full verified multiagent branch','unchanged_domain':'Federation shunt','public_native_inverter_status':'NOT_COMPATIBLE_UNCHANGED; explicit port required','result_status':'Native historical outcomes only; no new full public comparison'},
      {'id':'HG_PAPER_SE','owner':'OURS','role':'Original full two-branch safety-envelope system','unchanged_domain':'Federation shunt','public_native_inverter_status':'Explicit named port of BOTH branches and selector required','result_status':'Do not confuse with standalone proposer accuracy'},
      {'id':'HG_NEW_NUM','owner':'OURS_IMPLEMENTATION_ESTABLISHED_MATH','role':'Current-Jacobian LP numerical controller','unchanged_domain':'One public322 engineering point/native13 component/data study','result_status':'No complete paired full-system published benchmark; no LLM inside'},
      {'id':'HG_NEW_HYBRID','owner':'OURS_TARGET_VARIANT','role':'Paper architecture with separately justified new numerical component','result_status':'NOT_A_COMPLETE_FROZEN_PERFORMANCE_POLICY; source/protocol/inference/physical/economic gates required'},
      {'id':'D_SE','owner':'OURS_INTERNAL_CONTROL','role':'LiteralDFF+DFF_ALT+unchangedselector FULLBOTHcosts','unchanged_domain':'Federation shunt','result_status':'Original sealed results; source/horizon reuse gate'},
      {'id':'TPA','owner':'OTHER_AUTHORS','primary_source':'https://github.com/Canyizl/TPA-for-AVC','native_domain':'MAPDN322 signed inverter/temporal conditioning','artifact':'Official trained checkpoint available; one independently verified case','transfer_to_federation':'Requires explicitly trained/adapted method; no native pretrained-shunt claim'},
      {'id':'STABLE_DDPG','owner':'OTHER_AUTHORS','primary_source':'https://github.com/JieFeng-cse/Stable-DDPG-for-voltage-control','native_domain':'Public13/123 inverter cases','artifact':'Native13 pretrained artifacts/reproduction available','transfer_to_federation':'Needs declared adaptation/training; no random stand-in'},
      {'id':'DDPG','owner':'OTHER_AUTHORS_BASELINE_IMPLEMENTATION','primary_source':'https://github.com/JieFeng-cse/Stable-DDPG-for-voltage-control','native_domain':'Public13 native','artifact':'Native13 pretrained artifacts/reproduction available'},
      {'id':'LINEAR','owner':'OTHER_AUTHORS_BASELINE_IMPLEMENTATION','primary_source':'https://github.com/JieFeng-cse/Stable-DDPG-for-voltage-control','native_domain':'Public13 native','artifact':'Native13 artifacts/reproduction available'},
      {'id':'MAPPO_MADDPG_SUITE','owner':'OTHER_AUTHORS','primary_source':'https://github.com/Future-Power-Networks/MAPDN','native_domain':'Public33/141/322 inverter','artifact':'Code available; trained artifact not certified. Source-faithful frozen training gate before score'},
      {'id':'ONLINE_TOPO_ADAPTATION','owner':'OTHER_AUTHORS','primary_source':'https://github.com/JieFeng-cse/Online-Optimization-for-NN-Voltage-Control','native_domain':'13/56 unknown-topology1000step','artifact':'Checkpoint/input loading passed; solver/rollout/source contract pending'},
    ]
    put(OUT/'Controller_Identity_And_Readiness.json',arms)
    native_units=read(ROOT/'outputs/original_teacher_native_action_units_20261020/independent_audit/Independent_Audit.json')
    assert native_units['finite_label_support_statement_only'] and all(c['all_nonnull_actions_exceed_conservative_native_capacity'] for c in native_units['checks'])
    put(OUT/'Unchanged_Paper_To_Public_Actuator_Eligibility.json',{
      'status':'UNCHANGED_ACTUATOR_CONTRACT_MISMATCH_CONFIRMED_NOT_MODEL_PERFORMANCE_FAILURE',
      'original_teacher_min_nonnull_Mvar':25,'public_native_checks':native_units['checks'],
      'source_proof':'outputs/original_teacher_native_action_units_20261020/independent_audit/Independent_Audit.json',
      'rule':'Do not silently rescale old Mvar labels, install stronger devices, clip invalid outputs into successful actions or call a new head the unchanged paper model. Preserve original paper track; name every public port and provide identical legal controls to all policies.',
      'new_model_PF_optimizer_calls':0})
    protocol={
      'at_utc':at,'status':'FULL_SYSTEM_COMPARISON_REGISTERED_SOURCE_AND_CASE_GATES_ONLY_NOT_READY_TO_LAUNCH',
      'human_priority':'Finish fair publishable full-system comparison before expanding to subsequent tasks. Superiority is assessed, never predetermined.',
      'source_and_input_pins':{rel:sha(ROOT/rel) for rel in [
        'work/prepare_full_system_comparison_20261021.py','outputs/matched_campaign_protocol.json',
        'outputs/notebook_reference_review_20261020/Original_Adapter_Metadata_Reconciliation.json',
        'outputs/notebook_reference_review_20261020/local_reference_extracts/notebook_6_cell_037.txt',
        'outputs/notebook_reference_review_20261020/local_reference_extracts/notebook_6_cell_040.txt',
        'outputs/original_teacher_native_action_units_20261020/independent_audit/Independent_Audit.json',
        'outputs/full_system_comparison_20261021/All203_Existing_Federation_Input_Cases.json',
        'outputs/full_system_comparison_20261021/Controller_Identity_And_Readiness.json']},
      'case_families':{'FED141':'All141 existing recipes; input-defined load/contingency/combined strata retained','SEALED62':'Separate old inspected cohort; no regeneration or changed frozen control','PUBLIC322':'Complete source120schedule closure before performance; exact same roots across eligible arms','PUBLIC13':'Complete source500schedule closure;8additional engineering roots reported separately'},
      'native_vs_common':'Unchanged original paper system stays the native federation baseline. On native public inverter datasets use an explicitly named paper-system port; native external models stay source-faithful. Adapted external methods on federation need source-faithful training, not unrelated pretrained weights.',
      'paired_case_invariants':['Same full initial physical NET digest and solver initialization, never just the same seed/UV count','Same legal actuator capabilities, units/rates/stock and allowed buses','Same all-bus outcome scope, safety policy and commitment horizon in each common-role table','Same available causal observations/history; model-specific consumption disclosed, full-information numerical controls retained','Identical predefined case order and unexecuted/failed denominators; no favorable-case filtering'],
      'safety_reporting':'Report native-paper zeroUV and common full0.95..1.05band separately. Native1.06hard cutoff is not zeroOV. Any common1.05guard is an explicit identical wrapper/adaptation for every arm; never edit frozen original verifier.',
      'primary_endpoint':'Per-case full-band safe restoration; paired all-bus residualUV+OV counts and voltage-deficit magnitudes retained. No win based only on UV while creating OV.',
      'secondary_endpoints':['UV before/after and OV before/after','Worst voltage/deviation and cumulative violations along trajectory','PF convergence/exceptions and rejected queries','Actions/Q usage/trajectory length','Real inference/model loads/tokens/preparation/training/numerical/solver/independent replay/failure time and memory','Per-case costs plus whole BOTH-branch portfolio totals'],
      'statistics':'Predeclare contrasts before outcomes; paired case-level differences and95%cluster bootstrap intervals by scenario root/day, not bus or repeated timestep. Report each plant/stratum separately. Holm correction for any family of superiority tests; small engineering cohorts remain descriptive. Trainingseed variability must be reported for any newly trained comparator.',
      'LLM_attribution':'Original full system versus exact noLLM ablation and new hybrid versus new numerical component under equal information/resources; originalDSE is required, not a weakened single branch. Whole-system benefit is distinct from incremental LLM benefit.',
      'publication_release_gates':['Complete runnable frozen controller/port and independent partial-aware reader','Actual model loader/context/parser/cold preservation and exact assignments verified before ready owner','Case/source/initial-state/actuator/current-view contracts exact across methods','Persistent query reservation/checkpoints/fullcosts and fixed measured resource bounds','Independent continuous physical replay of every completed new trajectory; every failure/partial/unknown retained','All required comparisons complete; absent/ineligible artifact cells cannot count as beaten','Unused authorized confirmation before broad superiority/novelty claim; current inspected cohorts development only'],
      'existing_science_reuse':'Only exact case/source/horizon/role/initialization/cost matches may reuse completed evidence. Native one-step engineering cannot fill full25/100step rows. Never repeat old model/PF calls or restart old workers.',
      'fresh_science_status':'No scientist, GPU allocation, forward, optimizer, PF, forecast or linear solve launched by this registration.',
      'known_ready_gaps':['Original unmodified shunt controller is not a native inverter controller','New numerical controller is ours; new hybrid is not yet a complete benchmark-ready policy','Original25case paper-table exact cohort/source join still required for numerical replication','Some published baselines have no certified trained artifact','Yesterday frozen-feature allocation attempts terminal; no automatic retry/fallback'],
      'all6goals':'OPEN','guaranteed_superiority_or_acceptance':False}
    put(OUT/'Protocol.json',protocol)
    matrix=[]
    for c in cases:
        for method in ['HG_PAPER_VF','HG_PAPER_SE','HG_NEW_NUM','HG_NEW_HYBRID','D_SE','TPA_FED_ADAPTED','STABLE_DDPG_FED_ADAPTED','MAPPO_FED_ADAPTED']:
            matrix.append({'cohort':c['cohort'],'case_id':c['case_id'],'recipe_sha256':c['recipe_sha256'],'method':method,
                           'root_digest':'PENDING','outcome':'UNKNOWN_FOR_THIS_PROTOCOL','no_case_dropped':True})
    put(OUT/'Federation_Common_Case_Result_Matrix_Empty.json',matrix)
    put(OUT/'Preparation_Result.json',{'at_utc':at,'status':'SOURCE_TRACE_CASE_CLOSURE_AND_COMPARISON_CONTRACT_PREPARED_NO_SCIENCE',
      'federation_cases':203,'original_recipe_types':dict(types),'same_case_method_cells':len(matrix),
      'all_results_in_new_matrix_unknown':True,'new_scientific_calls':0,'matched_benchmark_completed':False})
    print(json.dumps({'source_trace':'SAVED','exact_existing_cases':203,'input_types':dict(types),'paired_method_case_slots':len(matrix),'new_science':0,'performance_ready':False}))
if __name__=='__main__':main()
