"""Append newly closed missing-only suffix attempts; independently check only added keys.

Saved-data processing only: all old entries remain verbatim; no controller, model,
power-flow, derivative, optimizer or converter is executed.
"""
from reflection118_remaining_cases_v2_core_20261023 import *
import traceback
BASE=R/'outputs/original_case_registry_20261028/build/Closed_Physical_Receipt_Registry.json'
BA=R/'outputs/original_case_registry_20261028/audit/Result.json'
NEW=R/'outputs/closed_missing_suffix_registry_20261028'
PREP=R/'outputs/closed_missing_suffix_registry_preparation_20261028'

def entries():
    for index in [1,3]:
        host=R/'outputs/original_missing_suffix_execution_20261028'/f'case_{index:02d}'
        status=read(host/'status.json')
        assert status['runtime_released'] and status['scientific_process_ended'] and status['all_actual_closed_artifacts_preserved']
        audit=read(R/'outputs/original_missing_suffix_independent_20261028'/f'case_{index:02d}'/'Independent_Audit.json')
        assert audit['status']=='PASS_ONE_COMPLETE_ORIGINAL_REFLECTION_CASE' and audit['complete']
        local=host/'local_controller';d=local/audit['case_id']/'reflection_v2'
        calls=read(d/'Call_Order.json')
        paths=[d/f'pf_{i:06d}.json' for i in range(len(calls['PF']))]
        paths+=sorted((local/'solver_input_identity').glob('identity_*/Receipt.json'))
        covered=set()
        for path in paths:
            row=read(path);covered.add((path.parent/row['before']['path']).resolve())
            yield dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),
                       before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=row['exception'])
        candidates=list(d.glob('pf_*_before.zlib'))+list((local/'solver_input_identity').glob('identity_*/Target_Before.zlib'))
        for path in sorted(candidates):
            if path.resolve() in covered:continue
            raw=path.read_bytes();decoded=zlib.decompress(raw)
            desc=dict(path=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),decoded_bytes=len(decoded),decoded_sha256=hashlib.sha256(decoded).hexdigest())
            yield dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),before=desc,
                       after=None,kwargs=None,exception='UNCLOSED_MISSING_SUFFIX_ATTEMPT_UNKNOWN')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['build','audit'],required=True);mode=ap.parse_args().mode
    p=read(PREP/'Protocol.json');assert sha(__file__)==p['source_sha256']
    O=NEW/mode;O.mkdir(parents=True,exist_ok=False);began=time.monotonic()
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),mode=mode,protocol_sha256=sha(PREP/'Protocol.json')))
    try:
        while not (O/'Launcher_ACK.json').exists():
            assert time.monotonic()-began<120,'No exact-source owner acknowledgement'
            time.sleep(.1)
        ack=read(O/'Launcher_ACK.json')
        assert ack['actual_pid']==os.getpid() and ack['parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
        for path,h in p['input_anchors'].items():assert sha(R/path)==h,path
        np,pp,v2,runner,reflection=setup()
        def forbidden(*a,**k):raise RuntimeError('SAVED_REGISTRY_NEW_SCIENCE_FORBIDDEN')
        pp.runpp=forbidden;runner.base_runner.generate_response=forbidden
        old=read(BASE);prior=read(BA)
        assert prior['index_sha256']==sha(BASE) and prior['total_rows']==len(old['rows'])==12262
        def bound():assert time.monotonic()-began<p['stage_seconds'],'Fixed bound; no extension'
        index=NEW/'build/Closed_Physical_Receipt_Registry.json'
        if mode=='build':
            from prior_physical_query_footprints_20261018 import component
            from run_reflection118_chronological_local_20261022 import necessary
            rows=list(old['rows']);seen={v['source'] for v in rows};added=0;failures=0;unclosed=0
            for row in entries():
                bound();assert row['source'] not in seen;seen.add(row['source'])
                net=saved_net(row['directory'],row['before'])
                row['resource_key']=component(net)[0]+':'+hashlib.sha256(canonical(necessary(net))).hexdigest()
                row['directory']=row['directory'].relative_to(R).as_posix();rows.append(row);added+=1
                failures+=row['exception'] is not None;unclosed+=row['after'] is None
            put(index,dict(rows=rows,record_count=len(rows),old_prefix_count=len(old['rows']),new_record_count=added,anchors=p['input_anchors']))
            result=dict(status='APPENDED_NEW_CLOSED_SUFFIX_ROWS_REQUIRES_INDEPENDENT_READER',old_rows=len(old['rows']),new_rows=added,
                        recorded_failed_or_unknown=failures,unclosed_input_records=unclosed,index_sha256=sha(index))
        else:
            end=read(NEW/'build/End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
            from build_and_audit_closed_dff_registry_20261023 import direct_key
            data=read(index)
            assert data['anchors']==p['input_anchors'] and data['rows'][:len(old['rows'])]==old['rows']
            expected=list(entries());fresh=data['rows'][len(old['rows']):]
            assert len(fresh)==len(expected)==data['new_record_count']
            for row,item in zip(fresh,expected):
                bound();item['directory']=item['directory'].relative_to(R).as_posix()
                assert {k:v for k,v in row.items() if k!='resource_key'}==item
                assert sha(R/row['source'])==row['source_sha256']
                assert direct_key(saved_net(R/row['directory'],row['before']))==row['resource_key']
            result=dict(status='PASS_ALL_NEW_SUFFIX_KEYS_AND_EXACT_PRIOR_PREFIX',index_sha256=sha(index),old_rows=len(old['rows']),
                        new_rows_checked=len(fresh),total_rows=len(data['rows']),recorded_failed_or_unknown=sum(x['exception'] is not None for x in fresh),
                        unclosed_input_records=sum(x['after'] is None for x in fresh))
        result.update(new_PF_model_derivative_optimizer_converter_calls=0,workflow_seconds=time.monotonic()-began,
                      scope='Append-only saved attempt lookup; not a physical outcome, global historical closure or scientific launch permission.')
        put(O/'Result.json',result)
        put(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))
        print(json.dumps(result))
    except BaseException as exc:
        put(O/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),new_science_permitted=0));raise

if __name__=='__main__':main()
