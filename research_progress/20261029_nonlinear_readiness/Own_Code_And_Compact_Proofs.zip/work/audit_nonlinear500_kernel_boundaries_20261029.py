"""Independent NEW synthetic admission/guard boundaries; zero physical solves.

Does not execute either prior source-residual or derivative fixture. Does not
call equality, derivatives, an optimizer, pandapower, or any saved grid input.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import warnings
import numpy as np
from remaining85_nonlinear_kernel_20261029 import NonlinearNative13, original_guard, NATIVE_CAP
from nonlinear13_validated_kernel_v2_20261029 import ValidatedNonlinearNative13

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/nonlinear500_kernel_independent_review_20261029'
SOURCES = [
    'work/remaining85_nonlinear_kernel_20261029.py',
    'work/nonlinear13_validated_kernel_v2_20261029.py',
    'work/nonlinear13_analytic_derivatives_20261029.py',
    'work/public13_matched_numeric_engine_20261021.py',
    'work/native_fit_teacher_math_20261020.py',
    'work/native_full_grid_affine_core_20261020.py',
    'work/physics_env/Lib/site-packages/pandapower/pypower/makeSbus.py',
    'work/physics_env/Lib/site-packages/pandapower/pypower/newtonpf.py',
    'work/physics_env/Lib/site-packages/pandapower/pf/run_bfswpf.py',
    'work/physics_env/Lib/site-packages/pandapower/pypower/makeYbus.py',
    'work/physics_env/Lib/site-packages/pandapower/pypower/idx_brch.py',
    'work/physics_env/Lib/site-packages/pandapower/build_bus.py',
    'work/audit_nonlinear500_kernel_boundaries_20261029.py',
]


def fixture(**changes):
    bus = np.zeros((13, 18), dtype=float)
    bus[:, 0] = np.arange(13)
    bus[:, 1] = 1
    bus[0, 1] = 3
    gen = np.zeros((1, 8), dtype=float)
    gen[0, [0, 1, 2, 7]] = [0, 1, .5, 1]
    args = dict(Y=np.eye(13, dtype=complex), V_current=np.ones(13, dtype=complex),
                ppc_bus=bus, ppc_gen=gen, baseMVA=10., lookup=np.arange(13),
                control=np.array([2, 7, 9]), current_vm=np.ones(13),
                current_q=np.array([.25, -.5, .125]), control_scaling=np.ones(3),
                control_in_service=np.ones(3, dtype=bool), enforce_q_lims=False,
                distributed_slack=False)
    args.update(changes)
    return args


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    before = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in SOURCES}
    protocol = {
        'label': 'NEW_SYNTHETIC_INPUT_ADMISSION_GUARD_AND_ACTION_BOUNDARIES_ONLY',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'source_hashes': before,
        'inputs': 'Fixed synthetic arrays constructed in this script; no saved physical state is loaded.',
        'cases': ['real_voltage_storage', 'fractional_control_rejection',
                  'active_generator_nan_rejection', 'generator_status_nan_rejection',
                  'proposal_constraints_do_not_replace_original_guard',
                  'native_float32_cap_and_overcap_rejection',
                  'mixed_sign_absolute_final_Q_objective'],
        'no_equality_derivative_optimizer_PF_model_calls': True,
    }
    with (OUT / 'Boundary_Protocol.json').open('x', encoding='utf-8') as f:
        json.dump(protocol, f, indent=2, allow_nan=False)
    rows = []
    costs = {'constructor_attempts': 0, 'voltage_algebra_calls': 0,
             'guard_calls': 0, 'constraint_evaluations': 0,
             'native_action_conversions': 0, 'objective_evaluations': 0}

    def construct(cls, **changes):
        costs['constructor_attempts'] += 1
        return cls(**fixture(**changes))

    old = construct(NonlinearNative13, V_current=np.ones(13))
    new = construct(ValidatedNonlinearNative13, V_current=np.ones(13))
    xo = old.initial_vector(); xo[0] = .37
    xn = new.initial_vector(); xn[0] = .37
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter('always')
        vo = old.voltage(xo)
    vn = new.voltage(xn); costs['voltage_algebra_calls'] += 2
    expected = np.exp(1j * .37)
    assert vo[1].imag == 0 and abs(vn[1] - expected) < 1e-15
    rows.append({'name': 'real_voltage_storage', 'old_silently_loses_imaginary_voltage': True,
                 'old_warning_types': [type(w.message).__name__ for w in captured],
                 'old_phase_imaginary_error': float(abs(vo[1].imag - expected.imag)),
                 'wrapper_dtype': str(vn.dtype), 'wrapper_phase_absolute_error': float(abs(vn[1] - expected)),
                 'pass': True})

    bad = np.array([2.9, 7.9, 9.9])
    old = construct(NonlinearNative13, control=bad)
    try:
        construct(ValidatedNonlinearNative13, control=bad)
    except ValueError as exc:
        reason = str(exc)
    else:
        raise AssertionError('Wrapper admitted fractional controls')
    assert old.control.tolist() == [2, 7, 9]
    rows.append({'name': 'fractional_control_rejection', 'old_admitted_as': old.control.tolist(),
                 'wrapper_rejection': reason, 'pass': True})

    for col, name in [(2, 'active_generator_nan_rejection'), (7, 'generator_status_nan_rejection')]:
        gen = fixture()['ppc_gen']; gen[0, col] = np.nan
        old = construct(NonlinearNative13, ppc_gen=gen)
        try:
            construct(ValidatedNonlinearNative13, ppc_gen=gen)
        except ValueError as exc:
            reason = str(exc)
        else:
            raise AssertionError('Wrapper admitted nonfinite generator data')
        rows.append({'name': name, 'old_constructor_admitted': True,
                     'old_injection_finite': bool(np.isfinite(old.injection0).all()),
                     'wrapper_rejection': reason, 'pass': True})

    # Pure constraint boundary, deliberately NOT an AC-feasible physical state.
    vm = np.ones(13); vm[1] = .94; vm[2] = 1.06
    m = construct(ValidatedNonlinearNative13, V_current=vm.astype(complex), current_vm=vm)
    x = m.initial_vector(); x[12] = 1.06; x[13] = 1.06; x[30] = .02
    g = m.inequalities(x); after = m.voltage(x).real
    guard = original_guard(vm, after)
    costs['constraint_evaluations'] += 1; costs['voltage_algebra_calls'] += 2; costs['guard_calls'] += 1
    assert g.min() >= 0 and not guard
    rows.append({'name': 'proposal_constraints_do_not_replace_original_guard',
                 'minimum_inequality': float(g.min()), 'original_guard': guard,
                 'before_UV_OV': [int((vm < .95).sum()), int((vm > 1.05).sum())],
                 'synthetic_after_UV_OV': [int((after < .95).sum()), int((after > 1.05).sum())],
                 'meaning': 'Expected contract limit: continuous proposal constraints omit strict-count monotonicity. The original guard must still run on the physical return.',
                 'AC_equality_not_evaluated_or_asserted': True, 'pass': True})

    m = construct(ValidatedNonlinearNative13)
    x = m.initial_vector(); x[24:27] = [NATIVE_CAP, -NATIVE_CAP, .1]
    u, q, applied = m.representable_native_action(x)
    assert u.dtype == np.float32 and np.array_equal(q, m.current_q - u)
    assert np.array_equal(applied[24:27], q - m.current_q)
    x[24] = np.nextafter(NATIVE_CAP, np.inf)
    try:
        m.representable_native_action(x)
    except ValueError as exc:
        reason = str(exc)
    else:
        raise AssertionError('Over-cap raw proposal admitted')
    costs['native_action_conversions'] += 2
    rows.append({'name': 'native_float32_cap_and_overcap_rejection', 'native_cap': NATIVE_CAP,
                 'u_dtype': str(u.dtype), 'next_q_dtype': str(q.dtype),
                 'overcap_rejection': reason,
                 'difference_from_old_affine_adapter': 'The old adapter clips solver output before float32 casting. The new kernel rejects raw deltaQ beyond the exact float32 cap; this stricter proposal-admission difference must be disclosed.',
                 'requires_post_conversion_equation_bounds_and_constraint_checks': True, 'pass': True})

    x = m.initial_vector(); x[24:27] = [.125, .0625, -.25]
    x[27:30] = [.375, .4375, .125]
    objective = m.objective(x, 2); costs['objective_evaluations'] += 1
    assert objective == .9375
    rows.append({'name': 'mixed_sign_absolute_final_Q_objective', 'stage2_value': objective,
                 'expected_value': .9375, 'pass': True})

    after_hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in SOURCES}
    assert before == after_hashes
    result = {'status': 'PASS_NEW_BOUNDARIES_WRAPPER_FIXES_THREE_ADMISSION_CLASSES',
              'at_utc': datetime.now(timezone.utc).isoformat(), 'cases': rows,
              'source_hashes': before, 'sources_unchanged_during_review': True,
              'new_software_costs': costs,
              'new_AC_equality_evaluations': 0, 'new_derivative_evaluations': 0,
              'new_PF_optimizer_model_training_GPU_calls': 0,
              'prior_fixtures_rerun': False, 'saved_physical_states_loaded': 0,
              'limits': 'Synthetic software boundaries only; no controller outcome, all500 binding, optimized feasibility or derivative numerical check is performed here.'}
    with (OUT / 'Boundary_Results.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
    print(json.dumps({'status': result['status'], 'cases': len(rows), 'new_software_costs': costs}))


if __name__ == '__main__':
    main()
