"""Source-order first proposal joined to exact old paid physics, if available.
No optimizer, PF, model or actual control commitment. No different candidate.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,io,copy
import numpy as np
from remaining85_source_binder_v2_20261029 import DataUnpickler,physical_signature
from nonlinear500_paid_lookup_v2_20261029 import lookup_exact
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear13_first_proposal_paid_join_20261029';S=R/'outputs/nonlinear13_first_proposal_execution_20261029'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False),encoding='utf-8')
def main():
    O.mkdir(exist_ok=False);p=json.loads((R/'outputs/nonlinear13_first_proposal_preparation_20261029/Protocol.json').read_text());a=json.loads((R/'outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json').read_text());assert a['status'].startswith('PASS')
    frozen=R/'outputs/nonlinear500_paid_registry_20261029/Frozen_Registry_Manifest.json'
    protocol=dict(at_utc=datetime.now(timezone.utc).isoformat(),population='Only source-order seed0 first frozen numerical proposal, fixed before paid-result lookup. No search/alternative.',
      proposal_sha256=sha(S/'Proposal_Result.json'),reader_sha256=sha(R/'outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json'),
      registry_manifest_sha256=sha(frozen),lookup_source_sha256=sha(R/'work/nonlinear500_paid_lookup_v2_20261029.py'),
      source_sha256=sha(__file__),input_root=p['input_root'],kwargs={'algorithm':'bfsw','init':'dc'},new_PF_optimizer_model_calls=0)
    put(O/'Protocol.json',protocol)
    proposal=json.loads((S/'Proposal_Result.json').read_text());assert proposal['status']=='ADMITTED_UNMEASURED_PROPOSAL'
    ref=p['input_root'];assert sha(R/ref['path'])==ref['sha256'];raw=DataUnpickler(io.BytesIO((R/ref['path']).read_bytes())).load();net=raw if ref['kind']=='NET' else raw['network']
    before=net['res_bus'].vm_pu.to_numpy(copy=True);q=net['sgen'].q_mvar.to_numpy()[:3].copy();u=np.asarray(proposal['u'],dtype=np.float32)
    candidate=copy.deepcopy(net);candidate['sgen'].loc[candidate['sgen'].index[:3],'q_mvar']=q-u
    signature=physical_signature(candidate);reused=lookup_exact(R,signature,protocol['kwargs'],protocol['registry_manifest_sha256']);put(O/'Exact_Lookup.json',reused)
    result=dict(at_utc=datetime.now(timezone.utc).isoformat(),status=reused['status'],physical_signature=signature,new_PF_optimizer_model_calls=0,actual_control_commits=0)
    if reused['status']=='VERIFIED_EXACT_PAID_REUSE':
        r=reused['reuse']['after'];saved=DataUnpickler(io.BytesIO((R/r['path']).read_bytes())).load();assert physical_signature(saved)==signature
        vm=saved['res_bus'].vm_pu.to_numpy();assert np.array_equal(saved['sgen'].q_mvar.to_numpy()[:3],q-u)
        normal=np.flatnonzero((before>=.95)&(before<=1.05))
        guard=bool(np.isfinite(vm).all() and all(.95-1e-8<=vm[i]<=1.05+1e-8 for i in normal) and sum(vm<.95)<=sum(before<.95) and sum(vm>1.05)<=sum(before>1.05))
        result.update(status='COMPLETE_EXACT_OLD_PHYSICS_JOIN_NOT_NEW_MEASUREMENT',before_vm=before.tolist(),after_vm=vm.tolist(),
          before_UV=int(sum(before<.95)),after_UV=int(sum(vm<.95)),after_OV=int(sum(vm>1.05)),original_guard=guard,
          max_nonlinear_prediction_error=float(np.max(np.abs(vm-np.asarray(proposal['proposed_vm'])))),returned_capsule=r,
          interpretation='First proposal matches independently verified paid input. This is a saved-result join, not a new trajectory or all500 performance. Full old solver/replay/preparation costs retained.')
    put(O/'Result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['before_vm','after_vm','returned_capsule']}))
if __name__=='__main__':main()
