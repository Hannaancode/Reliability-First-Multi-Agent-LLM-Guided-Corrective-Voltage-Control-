"""Additional descriptive disclosure/sensitivity analysis; no controller tuning."""
from pathlib import Path
from collections import Counter
import csv,hashlib,json,math
import numpy as np
from analyze_family_pairs import family,SEED,REPLICATES
from frozen_physics_loader import load_stack

root=Path('outputs');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());protocol=sha(root/'matched_campaign_protocol.json')
paths=sorted((root/'matched_campaign/cases').glob('*.json'));assert {p.name for p in paths}==set(lock['scenario_file_sha256'])
pilot=[];pilot_failed=[]
for p in Path('work/e/debug/results/lora').glob('rev_*.json'):
    d=json.loads(p.read_text())
    # Saved pilot case 14 is an error record, not a completed pilot case.
    if d.get('error') or d.get('status') in ['error','failed','exception'] or not d.get('dff_result') and not d.get('branches'):
        pilot_failed.append({'scenario_id':p.stem,'keys':list(d)})
    else:pilot.append(p.stem)
print('PILOT_SCHEMA_CLASSIFICATION',len(pilot),len(pilot_failed),flush=True)
# The original pilot records use a top-level DFF / base / LoRA result schema.
if len(pilot)!=13:
    pilot=[];pilot_failed=[]
    for p in Path('work/e/debug/results/lora').glob('rev_*.json'):
        d=json.loads(p.read_text());is_complete=any(isinstance(v,dict) and ('executed_actions' in v or 'final_metrics' in v) for v in d.values())
        if is_complete:pilot.append(p.stem)
        else:pilot_failed.append({'scenario_id':p.stem,'keys':list(d)})
assert len(pilot)==13,(pilot,pilot_failed)
v2,runner,ref=load_stack();rows=[];rngs={};selection=Counter();first_change=Counter();raw=Counter();cost_totals={m:Counter() for m in ['D-SE','HG-SE']};branch_totals={m:Counter() for m in ['DFF','DFF-ALT','HG-VF']};events=Counter();same_path=0;shared_pilot_families={family(sid) for sid in pilot}|{family(r['scenario_id']) for r in pilot_failed}
for p in paths:
    d=json.loads(p.read_text());assert d['scenario_sha256']==lock['scenario_file_sha256'][p.name] and d['protocol_sha256']==protocol
    rng=root/'matched_campaign/rng'/f"{d['index_1based']:03d}.pt";assert rng.is_file() and rng.stat().st_size>0;rngs[rng.name]=sha(rng)
    valid=d['paired_terminal_metrics_valid'];row={'scenario_id':p.stem,'family':family(p.stem),'pilot13_observed':p.stem in pilot,'shares_outage_family_with_pilot':family(p.stem) in shared_pilot_families,'valid_pair':valid}
    for method,b in d['branches'].items():
        c=d['costs'][method]
        for k,v in c.items():
            if k=='peak_gpu_memory_allocated_bytes':branch_totals[method]['maximum_peak_gpu_memory_allocated_bytes']=max(branch_totals[method]['maximum_peak_gpu_memory_allocated_bytes'],v)
            elif isinstance(v,(float,int)):branch_totals[method][k]+=v
        if valid:branch_totals[method]['uv_clear_cases']+=b['final_metrics']['uv_count']==0;branch_totals[method]['total_final_uv']+=b['final_metrics']['uv_count']
        for log in b.get('logs',[]):
            info=log.get('llm_info')
            if not info:continue
            events['primary_queries_logged']+=1;events['parse_failures_final_reply']+=not info.get('parse_valid',False);events['invalid_proposals_final_reply']+=not info.get('valid_action',False);events['repairs']+=bool(info.get('reprompted'))
            parsed=info.get('parsed')
            if isinstance(parsed,dict) and isinstance(parsed.get('q_mvar'),(int,float)):
                q=float(parsed['q_mvar']);raw['compact_q_reported']+=1;raw['raw_q_not_in_prompt_nine_value_list']+=q not in ref.ALLOWED_Q
    for method,other in [('D-SE','DFF-ALT'),('HG-SE','HG-VF')]:
        for k in ['pf_attempts','pf_returns','pf_exceptions','llm_calls','llm_exceptions','input_tokens','output_tokens','wall_seconds']:
            row[method+'_'+k]=d['costs']['DFF'][k]+d['costs'][other][k];cost_totals[method][k]+=row[method+'_'+k]
        if valid:
            portfolio=d['portfolios'][method];s=portfolio['summary'];b=d['branches'][portfolio['selected_branch']];row[method+'_uv']=s['final_uv'];row[method+'_deficit']=s['final_deficit'];row[method+'_actions']=s['accepted_actions'];row[method+'_support']=sum(abs(float(q)) for a in b['executed_actions'] for q in a['action']['add_shunts_q_mvar'].values());selection[method+':'+portfolio['selected_branch']]+=1
        else:row[method+'_status']='invalid numerical pair retained, outcome not imputed'
    if valid:
        row['base_uv']=d['branches']['DFF']['base_metrics']['uv_count'];a=d['branches']['DFF']['executed_actions'];b=d['branches']['DFF-ALT']['executed_actions'];same_path+= [x['action'] for x in a]==[x['action'] for x in b]
        dec=d['branches']['DFF-ALT'].get('dff_alt_decisions',[])
        if dec:
            first=dec[0];first_change[first['reason']]+=1
            if first.get('second_action'):
                x=first['first_action']['add_shunts_q_mvar'];y=first['second_action']['add_shunts_q_mvar'];changed_bus=set(x)!=set(y);changed_q=list(x.values())!=list(y.values());first_change['both_changed' if changed_bus and changed_q else 'bus_only_changed' if changed_bus else 'Q_only_changed']+=1
            assert all(x['reason']=='ordinary_dff' for x in dec[1:]),'ALT changed beyond first iteration'
        # Full terminal ordering comparison uses the actual frozen function.
        ds=d['portfolios']['D-SE']['summary'];hs=d['portfolios']['HG-SE']['summary'];x=ref.choose_safety_envelope(ds,hs);y=ref.choose_safety_envelope(hs,ds)
        row['full_selector_comparison']='HG-SE_preferred' if x=='reflection_v2' else 'D-SE_preferred' if y=='reflection_v2' else 'tie'
    rows.append(row)
assert len(rngs)==62 and {int(n[:3]) for n in rngs}==set(range(1,63))
valid=[r for r in rows if r['valid_pair']];delta=np.array([r['HG-SE_uv']-r['D-SE_uv'] for r in valid],float);rng=np.random.default_rng(SEED);samples=delta[rng.integers(0,len(delta),size=(REPLICATES,len(delta)))].mean(axis=1)
def group_summary(rs):
    available=[r for r in rs if r['valid_pair']]
    return {'all_cases':len(rs),'valid_pairs':len(available),'invalid_ids':[r['scenario_id'] for r in rs if not r['valid_pair']],'HG_lower_uv':sum(r['HG-SE_uv']<r['D-SE_uv'] for r in available),'D_lower_uv':sum(r['D-SE_uv']<r['HG-SE_uv'] for r in available),'equal_uv':sum(r['HG-SE_uv']==r['D-SE_uv'] for r in available),'mean_uv_delta_HG_minus_D':float(np.mean([r['HG-SE_uv']-r['D-SE_uv'] for r in available])) if available else None}
report={'status':'full_62_case_descriptive_and_sensitivity_audit','analysis_timing':'Additional disclosure analysis after full main results; not a new preregistered confirmatory analysis and no control/protocol changes. Original family-cluster analysis remains primary.','checkpoint_checks':{'cases':62,'rng_checkpoints':62,'all_case_protocol_and_scenario_hashes_match':True},'rng_sha256':rngs,'full_bank_costs_including_invalid_case_attempts':{k:dict(v) for k,v in cost_totals.items()},'branch_costs_and_valid_case_uv':{k:dict(v) for k,v in branch_totals.items()},'finite_valid_initially_undervoltage_cases':sum(r['base_uv']>0 for r in valid),'finite_valid_initially_healthy_cases':sum(r['base_uv']==0 for r in valid),'selection_counts_on_valid_pairs':dict(selection),'full_selector_comparison_counts':dict(Counter(r['full_selector_comparison'] for r in valid)),'first_alt_diversity_on_valid_pairs':dict(first_change),'identical_complete_DFF_ALT_action_paths_on_valid_pairs':same_path,'model_reply_diagnostics':{**events,**raw},'ordinary_paired_scenario_bootstrap_sensitivity':{'seed':SEED,'replicates':REPLICATES,'valid_pair_count':len(delta),'mean_HG_minus_D_uv':float(delta.mean()),'percentile_95_percent_ci':np.quantile(samples,[.025,.975]).tolist(),'interpretation':'Sensitivity only; treats correlated load points as separate units, so the outage-family clustered interval is preferred.'},'pilot_awareness':{'observed_pilot_ids':sorted(pilot),'additional_failed_or_invalid_pilot_records':pilot_failed,'tuning_history':'Pilot outcomes were previously observed. New DFF-ALT and source protocol were frozen before this new bank campaign and tested on historical cases only. The historical pre-handover prompt/development edit history is incomplete; do not claim the 13 pilot cases or their related families were untouched.','pilot13':group_summary([r for r in rows if r['pilot13_observed']]),'remaining49':group_summary([r for r in rows if not r['pilot13_observed']]),'families_without_pilot_cases':group_summary([r for r in rows if not r['shares_outage_family_with_pilot']]),'family_overlap_note':'The second load level of a pilot outage shares its family; remaining49 are not automatically independent of pilot awareness.'},'rows':rows}
(root/'main_campaign_detailed_audit.json').write_text(json.dumps(report,indent=2,allow_nan=False))
cols=list(dict.fromkeys(k for row in rows for k in row))
with (root/'main_campaign_detailed_ledger.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
print(json.dumps({k:v for k,v in report.items() if k not in ['rows','rng_sha256']},indent=2))
