"""Finite sole handoff; zero model/PF/science calls, no scientific owner restart."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,time,subprocess
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
OUT=BASE/'pretrained_learning_audit_continuation';EXEC=BASE/'pretrained_learning_execution'
assert not OUT.exists();OUT.mkdir()
(OUT/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()}))
def save(stage,**kw):
    p=OUT/'status.tmp';p.write_text(json.dumps({'stage':stage,'updated_at_utc':datetime.now(timezone.utc).isoformat(),**kw},indent=2));p.replace(OUT/'status.json')
def alive(pid):
    r=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    return 'run_candidate_process_pretrained_learning_colab_chunked_v2.py' in r.stdout
try:
    began=time.monotonic();pid=int((EXEC/'owner.claim').read_text())
    save('waiting_for_actual_single_GPU_owner_to_end',observed_scientific_owner_pid=pid)
    while alive(pid):
        assert time.monotonic()-began<9000,'Finite handoff bound; inspect same owner, never restart'
        time.sleep(30)
    state=json.loads((EXEC/'status.json').read_text())
    if not(state.get('runtime_released') and state.get('all_actual_artifacts_preserved') and state.get('remote_exit_code')==0):
        save('terminal_preserved_scientific_or_resource_failure_no_reader_rerun',actual_owner_status=state)
    else:
        assert not (BASE/'pretrained_learning_external_audit').exists()
        save('single_external_reader_running')
        with (OUT/'reader_stdout.log').open('x') as stdout,(OUT/'reader_stderr.log').open('x') as stderr:
            result=subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8','work/analyze_candidate_process_pretrained_learning.py'],cwd=ROOT,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        assert result.returncode==0,'Preserve actual failed reader; no rerun'
        audit=json.loads((BASE/'pretrained_learning_external_audit/Local_Archive_Audit.json').read_text());assert audit['CRC_and_every_member_hash_passed']
        save('complete_independent_pretrained_learning_evidence',archive=audit)
except BaseException as e:
    save('terminal_handoff_failure_preserved',exception=type(e).__name__,message=str(e));raise
