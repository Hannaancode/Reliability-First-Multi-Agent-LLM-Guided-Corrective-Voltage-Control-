"""One read-only public-library source capture on each exact owned assignment."""
import ast,base64,hashlib,json,logging,subprocess,time,uuid
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import quote
import requests
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/matched_scale_20261011';OUT=BASE/'actual_PEFT_forward_source'
assert not OUT.exists();OUT.mkdir();logging.disable(logging.CRITICAL);began=time.perf_counter();report={}
for arm,folder in [('public_0_5B','gcloud'),('public_1_5B','gcloud-hiergrid-sheenah')]:
    session=None;row={'public_library_source_only':True,'new_allocation_model_PF_optimizer_calls':0}
    try:
        state=json.loads((BASE/arm/'status.json').read_text());claim=json.loads((BASE/arm/'owner.claim').read_text());pid=claim['actual_pid'];parent=claim['actual_parent_pid']
        cmd=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}';if($p -and $p.ParentProcessId -eq {parent} -and $p.CommandLine -match 'run_matched_scale_colab.py --arm {arm}'){{'LIVE'}}"
        checked=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True,timeout=30)
        assert checked.stdout.strip()=='LIVE' and state['runtime_allocated'] and not state['runtime_released']
        cred=Credentials.from_authorized_user_file(str(Path(r'C:\Users\HOME\AppData\Roaming')/folder/'application_default_credentials.json'))
        transport=Request()
        def refresh(*a,**kw):kw.setdefault('timeout',25);return transport(*a,**kw)
        cred.refresh(refresh);session=AuthorizedSession(cred,refresh_timeout=30)
        response=session.get('https://www.googleapis.com/oauth2/v2/userinfo',timeout=(10,25));response.raise_for_status();assert response.json()['email']==state['account']
        client=Client(Prod(),session);assignment=client._get_assignment(uuid.UUID(state['notebook_hash']),variant=Variant.GPU,accelerator=Accelerator.T4)
        assert assignment.endpoint==state['endpoint'] and assignment.runtime_proxy_info is not None
        path='content/hiergrid_execution/env/lib/python3.12/site-packages/peft/tuners/tuners_utils.py'
        response=requests.get(assignment.runtime_proxy_info.url.rstrip('/')+'/api/contents/'+quote(path,safe='/'),params={'authuser':'0','colab-runtime-proxy-token':assignment.runtime_proxy_info.token,'content':'1','format':'base64'},timeout=(10,30))
        response.raise_for_status();v=response.json();raw=base64.b64decode(v['content']) if v.get('format')=='base64' else v['content'].encode()
        with (OUT/(arm+'_tuners_utils.py')).open('xb') as f:f.write(raw)
        tree=ast.parse(raw.decode());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='BaseTuner')
        forward=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='forward')
        assert len(forward.body)==1 and isinstance(forward.body[0],ast.Return)
        call=forward.body[0].value;assert isinstance(call,ast.Call) and ast.unparse(call.func)=='self.model.forward'
        row.update(passed=True,actual_owner_pid=pid,notebook=state['notebook_hash'],account=state['account'],bytes=len(raw),source_sha256=hashlib.sha256(raw).hexdigest(),
          actual_BaseTuner_forward=ast.unparse(forward),direct_forward_bypasses_inner_Module_call_hooks=True)
    except Exception as e:row.update(passed=False,failure_type=type(e).__name__)
    finally:
        if session:session.close()
    report[arm]=row
result={'at_utc':datetime.now(timezone.utc).isoformat(),'arms':report,'all_source_proofs_passed':all(r.get('passed') for r in report.values()),'seconds':time.perf_counter()-began,'new_model_PF_optimizer_allocation_calls':0,'no_scientific_artifact_collector_started':True}
(OUT/'Actual_Source_Proof.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
