from pathlib import Path
from datetime import datetime,timezone
import json,shutil,hashlib
R=Path(__file__).resolve().parents[1];O=R/'outputs/consolidated_research_checkpoint_20261029'
def read(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
def put(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    reviewpath='outputs/task_completion_criteria_review_20261029/Independent_Review.json'
    review=read(reviewpath);close=review['count_reconciliation']['new_checklist_completion_recommendations']
    assert set(close)=={'T09','T12','T22','T24','T27','T30'}
    thesis='outputs/thesis_citations_integrated_20261029'
    qa=read(thesis+'/Independent_Citation_Integration_Check.json');assert str(qa['status']).startswith('PASS')
    doc=thesis+'/Hannaan_Thesis_Citations_And_Current_Results.docx'
    paths=['outputs/research_resumption_20261028/Current_Resume.json','outputs/research_resumption_20261028/Next_Exact_Work_20261029.json','outputs/research_tasks_20261014/Tasks.json','outputs/thesis_research_closure_20261028/Tasks.json']
    for i,p in enumerate(paths):shutil.copy2(R/p,O/f'Previous_{i:02d}_{Path(p).name}')
    checks=read(paths[3]);byid={x['id']:x for x in review['reviews']}
    for item in checks['tasks']:
        if item['id'] in close:
            rr=byid[item['id']]
            item.update(completed=True,status='COMPLETE_SCOPED_REQUIREMENT_INDEPENDENTLY_REVIEWED',verified_at_utc=now,
              criterion_review=reviewpath,completion_reason=rr['reason'],remaining_limits=rr.get('remaining_limits',[]),
              limitation='This closes the exact scoped checklist requirement; underlying UNKNOWN historical records and absent causal/physical guarantees remain unchanged. Current DOCX pagination is delegated to the user.')
            ev=item.setdefault('evidence',[])
            for p in [reviewpath,doc,thesis+'/Independent_Citation_Integration_Check.json','outputs/thesis_current_comparison_20261029/Independent_Content_Fields_And_Index_Check.json']:
                if p not in ev:ev.append(p)
    count=sum(x['completed'] for x in checks['tasks']);assert count==27
    checks.update(completed_count=count,completed_requirement_count=count,updated_at_utc=now,updated_utc=now)
    put(R/paths[3],checks)
    master=read(paths[2]);tasks={x['checklist_id']:x for x in master['tasks']}
    def add(goal,sid,description,evidence):
        ss=tasks[goal].setdefault('subtasks',[]);assert not any(x['id']==sid for x in ss)
        ss.append(dict(id=sid,completed=True,description=description,evidence=evidence,verified_at_save=now))
    add('G3','G3.common118_bellman_source_20261029','Independently verify the author DQN behaviour-mask/unmasked Bellman-target source distinction. Source/software evidence only, no trained comparison.','outputs/common118_external_bellman_contract_20261029/Independent_Audit.json')
    add('G3','G3.common_tolerance_saved500_20261029','Apply the explicitly human-requested1e-8 allowance uniformly to all2000 saved controller-case rows; preserve historical strict scores. Numerical415/500 versus262/258/363, retrospective descriptive rule.','outputs/public13_voltage_magnitude_analysis_20261029/Independent_Arithmetic_Check.json')
    add('G1','G1.remaining85_source_diagnosis_20261029','Classify all85 remaining native guard failures from saved records; preserve all cases and prepare an unexecuted nonlinear AC constraint adapter. No new performance experiment.','outputs/remaining85_mechanism_review_20261029/Remaining85_Taxonomy.json')
    add('G4','G4.public_qa_complete_20261029','Complete all450 fixed public QA generations across0.5/1.5/3B with full failures/costs and independent evidence;1.5B operational failure retained.','outputs/public_qa_completion_20261029/Verified_Completion.json')
    tasks['G4'].update(bounded_comparison_request_complete=True,bounded_completion_evidence=reviewpath,
      status='BOUNDED_SCALE_COMPARISONS_COMPLETE_ADVERSE_RESULTS_RETAINED_CONDITIONAL_FOLLOWON_OPEN',
      next='G4.3 remains conditional and open. Do not repeat stopped scale studies. A materially different justified role needs prospective actual loader/precision/context/control/cost gates.')
    # Preserve the established conservative final-goal convention. A bounded comparison
    # completed with a failed gate is recorded separately, not counted as superiority.
    assert all(not x['completed'] for x in master['tasks'])
    master.update(updated_at_utc=now,thesis_documentation_requirements_complete=27,thesis_documentation_requirements_total=35,
      latest_verified_thesis=doc,latest_verified_resume='outputs/consolidated_research_checkpoint_20261029/Exact_Resume.json',
      current_owned_jobs=[],current_GPU_assignments=[],waiting_automations=[],all6_final_goals='OPEN',
      bounded_main_comparison_request_complete=['G4'],new_work_publication_status='LOCAL_PENDING_COMPACT_PUBLICATION')
    put(R/paths[2],master)
    resume=dict(at_utc=now,status='CONSOLIDATED27_CHECKLIST_CLOSURES_CITATIONS_AND85_FAILURE_MECHANISM',
      actual_goal_tool='ACTIVE; actual usage/lifecycle governs',all_six_final_goals='OPEN',
      bounded_main_request_complete=['G4 matched size comparison; adverse results retained; G4.3 conditional follow-on OPEN'],
      priority_order=['G3','G1','G2','G4','G5','G6'],owned_scientific_jobs=[],GPU_assignments=[],waiting_timer=None,
      thesis_requirements_complete=27,thesis_requirements_total=35,thesis_current=doc,
      thesis_content_qa=thesis+'/Independent_Citation_Integration_Check.json',thesis_evidence_index=thesis+'/Thesis_Evidence_Navigation.json',
      thesis_counts=dict(tables=23,figures=22,references=71),pagination='Explicitly delegated to user; no new PDF, page count or visual layout certification.',
      open_thesis_items=[x['id'] for x in checks['tasks'] if not x['completed']],
      common_tolerance=dict(rule='Same1e-8 p.u. allowance for all methods; retrospective user-requested engineering analysis, not new confirmation.',
        wholeband500=dict(our_numerical=415,safe_ddpg=262,linear=258,ddpg=363),remaining_ours=85,
        evidence='outputs/public13_voltage_magnitude_analysis_20261029/Independent_Arithmetic_Check.json',
        historical_strict_scores_preserved=True,LLM_superiority=False),
      next_physical_mechanism='outputs/remaining85_mechanism_review_20261029/Prospective_Launch_Gates.json',
      latest_diagnosis='All85 rejected candidates violate a previously normal bus despite affine predicted guard satisfaction.81UV/4OV. Prediction error dominates rounding; no new performance claim.',
      nonlinear_adapter='work/remaining85_nonlinear_kernel_20261029.py',nonlinear_readiness='ONE_UNSOLVED_ALGEBRA_FIXTURE_PASS; all500 exact source/options binding and independent solver/state/cost/reader gates pending. NO optimizer/PF/model launched.',
      current_LLM_readiness='No newly justified GPU study. Stopped interface/scale/precision failures stay stopped. Complete causal matched controls and role binding before further model work.',
      GPU_readonly_evidence='outputs/colab_eligibility_readonly_20261029/Results.json',GPU_limits='All3 profiles eligibleT4 with0assignments at08:27UTC; no free-hour/reset/lifetime guarantee or fallback after denial.',
      usage_observation='Ordinary usage allowed;72percent consumed/28percent remaining in account10080minute window at this turn check. Not a per-turn token or duration promise.',
      last_verified_GitHub='cf7aefb7ed5d6e1c070fffff0cddfe2d417a3f5b',verified_GitHub_receipt='outputs/RAG_metadata_publication_20261029/Verified_GitHub_Receipt.json',
      new_work_publication='PENDING_COMPACT_OWN_CODE_AND_PROOFS',
      next_ordered_actions=[
        'Finish saved-only all500 NET/PPC/options/scaling/source binding for the new nonlinear constraint adapter; independently review algebra and source contracts without repeating physics.',
        'Only after source/input/history/solver/ownership/persistent-state/cost/first-reader protocol is frozen may one prospective new optimizer/physical campaign proceed. No old restart, budget extension or outcome retuning.',
        'For causal LLM work, finish common118 full attempt/rejection history, actor/query distinction, reward/split/environment/strong-control role and actual loader gates before fresh learning. Idle GPUs alone do not justify launch.',
        'Resolve remaining thesisT01/T02/T04/T05/T11/T13/T21/T29 only from actual missing evidence or explicit administrative approval; do not invent closure to meet counts.'
      ],standing_constraints='Preserve frozen original model/network/controller/settings/locked62bank, all adverse/partial/UNKNOWN, literal DFF+DFFALT+unchanged DSE with full BOTH/model/training/preparation/failure costs. No guaranteed winner, scientific retries, favorable worlds, quota evasion, purchases or fallback after denial.')
    put(O/'Exact_Resume.json',resume)
    for p in paths[:2]:put(R/p,resume)
    header=f'## Consolidated evidence and token-saving checkpoint — {now}\n\n27/35 thesis requirements independently closed; six final research goals remain OPEN. Bounded G4 scale comparison completed with adverse results, conditional G4.3 remains OPEN. Current DOCX23tables/22figures/71references; all citation/content checks PASS, PDF/pagination delegated to user. Uniform user-requested1e-8 rule gives numerical415/500 versus SafeDDPG262/linear258/DDPG363; historical strict264/500 preserved. All85 remaining cases are actual guard rejections, not rounding. New nonlinear AC adapter has one unsolved algebra fixture PASS only; no new PF/optimizer/model or GPU campaign. No owned scientific jobs or timer. Exactresume: outputs/consolidated_research_checkpoint_20261029/Exact_Resume.json. New compact publication pending.\n\n'
    for name in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/name;p.write_text(header+p.read_text(encoding='utf-8-sig'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write('\n'+header+'Before:21/35 closed and39 references with a duplicate. After:27/35 scoped requirements closed and71 unique reconciled references, all57 paper references accounted for;11 tangential/unverified entries explicitly excluded or deferred. No claim that remaining historical or causal gaps are solved. Before:236 strict numerical failures. After:151 fall inside the common engineering allowance and85 remain genuine failures; raw values unchanged. The85-case diagnosis motivates a different nonlinear constraint model, not another threshold adjustment. All original/failed science and full costs retained.\n')
    put(O/'Save_Manifest.json',dict(at_utc=now,files=[dict(path=p,sha256=hashlib.sha256((R/p).read_bytes()).hexdigest()) for p in paths],requirement_count=27,new_primary_science=0))
    print(json.dumps(dict(saved=True,thesis_complete=27,final_goals_open=6,bounded_scale_comparison_complete=True,current_docx=doc)))
if __name__=='__main__':main()
