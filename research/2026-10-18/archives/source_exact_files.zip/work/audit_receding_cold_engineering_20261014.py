"""Complete-only source/checkpoint/query-history/stock audit, no new science."""
import copy,json,os,sys,time
from pathlib import Path
import pandapower as pp
from check_and_cold_receding_controller_20261014 import R,B,OLD,PAID,read,sha,put,pins
from paid_receding_commit_and_history_v1 import restore_complete,HISTORY_KEY,fields,fingerprint,validate
from joint_reallocation_opportunity_core_v1 import load_endpoint
from compile_lookahead_paid_input_cache_20261014 import point_key
from candidate_process_evidence_utils import frozen_checks
def main():
    p=pins();result=read(B/'actual/Result.json');assert result['exit_code']==0
    for name,h in read(B/'actual/Closed_Manifest.json')['members'].items():assert sha(B/'actual'/name)==h
    out=B/'audit';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'source_sha256':sha(Path(__file__))})
    def blocked(*a,**k):raise AssertionError('Cold-state reader forbids all physics/model execution')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,blocked)
    entries=read(OLD/'preparation/Protocol.json')['current_endpoints'];proofs=[]
    for i,e in enumerate(entries,1):
        assert time.perf_counter()-start<120
        request=read(B/'actual'/f'Cold_Request_{i}.json');cold=read(B/'cold'/str(i)/'Result.json');claim=read(B/'cold'/str(i)/'owner.claim')
        assert cold['exit_code']==0 and cold['status'].startswith('PASS_ACTUAL_COLD_') and claim['actual_pid']!=os.getpid()
        assert '--cold' in claim['argv'] and str(i) in claim['argv']
        state,history=restore_complete(R/request['checkpoint'],request['receipt']);validate(state['net'],state['cursor'])
        assert len(history)==2 and history[-1]['event']=='engineering_first_commit'
        branch=read(PAID/'actual'/f'Branch_{2*i}.json');selected=branch['plan']['selected']
        message=next(m for m in branch['query_messages'] if m['parent']==branch['root'] and m['aid']==selected['first'])
        assert history[0]['payload']['query_messages']==branch['query_messages']
        assert history[0]['payload']['menus']==branch['menus'] and history[0]['payload']['attributed_costs']==branch['attributed_costs']
        assert history[0]['payload']['source_branch_sha256']==sha(PAID/'actual'/f'Branch_{2*i}.json')
        transition=state['cursor']['committed_transitions'];assert len(transition)==1
        assert transition[0]['candidate']==message['row'] and transition[0]['paid_receipt_id']==message['record']['receipt_id']
        initial,initial_cursor,_=load_endpoint(e);debit=1 if message['row']['kind']=='ordinary' else 2
        assert state['cursor']['remaining_original_device_operation_slots']==initial_cursor['remaining_original_device_operation_slots']-debit
        assert point_key(state['net'],state['cursor'])==request['actual_point_key']==cold['physical_source_point_key']
        assert fields(state['net'])==request['fields'] and fingerprint(state['net'],state['cursor'])==request['receipt']['state_fingerprint']
        assert state['absolute_deadline_utc']==request['absolute_deadline_utc'] and state['next_phase']==request['next_phase']
        assert state['paid_query_registry'][HISTORY_KEY]==request['history_anchor'] and state['next_phase']['second_hypothesis_not_committed']
        assert len(state['paid_query_registry'])==2 and set(state['paid_query_registry'])=={HISTORY_KEY,message['record']['receipt_id']}
        # Full query records are in the independently hashed durable prefix,
        # not discarded just because the compact selected-registry has two keys.
        assert (R/request['history_anchor']['path']).stat().st_size>request['history_anchor']['bytes']
        assert cold['history_records']==2 and cold['new_scientific_calls']==0
        proofs.append({'world':e['world'],'actual_paid_first_commit_operations':debit,
            'complete_query_history_receipts':len(history[0]['payload']['query_messages']),
            'complete_controller_and_cold_prefix':'PASS','second_not_implicitly_committed':True})
    assert len(proofs)==4 and result['new_engineering_logical_first_commits']==4
    put(out/'Fresh_Frozen_Checks.json',frozen_checks());assert read(out/'Fresh_Frozen_Checks.json')['all_passed']
    put(out/'Independent_Receding_Cold_State_Audit.json',{'status':'PASS_ALL4_ACTUAL_FIRST_ONLY_COMMIT_NET_MASK_STOCK_CAP_COMPLETE_QUERY_HISTORY_COLD_STATE_AND_BOUNDS',
        'all4_proofs':proofs,'software_checks':len(result['software_checks']),
        'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'reader_workflow_seconds':time.perf_counter()-start,
        'scope':'Full-state persistence/control software integration only; no fresh performance episode, wholeDSE or LLM superiority.'})
    print(json.dumps({'independent_cold_state_audit':'PASS','actual_roots':4,'new_scientific_calls':0}))
if __name__=='__main__':main()
