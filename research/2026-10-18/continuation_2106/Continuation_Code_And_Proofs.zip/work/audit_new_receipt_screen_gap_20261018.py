"""Audit changed-evidence analysis integrity and exact next gap, no physics.

Does not certify a complete physical policy or repeat the historical reader.
"""
import hashlib,json,pickle,time,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from equal_operation_benchmark_v2 import process
from strict_saved_native_input_match_v2_20261018 import require_same
from exact_two_paid_query_engineering_20261018 import input_state
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
B=R/'outputs/unstarted_paid_suffix_new_receipts_v3_20261018'
P=R/'outputs/unstarted_paid_suffix_new_receipts_v3_preparation_20261018'
def main():
    out=P/'closed_gap_audit';out.mkdir(exist_ok=False);begun=time.perf_counter();c=read(B/'owner.claim');assert process(c['actual_pid']) is None and process(c['parent_pid']) is None
    p=read(P/'Protocol.json')
    for rel,h in p['source_input_sha256'].items():assert sha(R/rel)==h
    for rel,h in read(B/'Closed_Manifest.json')['members'].items():assert sha(B/rel)==h
    protocol=sha(B/'Protocol.json');previous='0'*64;closed=0;new_uses=[];menus=[]
    with (B/'scientific.jsonl').open('rb') as f:
        for raw in f:
            e=json.loads(raw);assert e['previous_sha256']==previous and e['protocol_sha256']==protocol;previous=hashlib.sha256(raw[:-1]).hexdigest()
            assert e['event'] not in ('PF_intent','PF_return','PF_exception')
            if e['event']=='every_query_receipt_closed_before_more_science':
                closed+=1;d=e['data'];assert d['aid']==action_key(d['row'])
                if d['record']['receipt_id'].startswith('ARCHIVED_NEW_TWO_'):new_uses.append(d)
            elif e['event']=='second_causal_context_and_forecasts':menus.append(e['data'])
    assert len(new_uses)==1 and len(menus)==2 and closed==1518
    source=read(R/'outputs/exact_two_paid_query_engineering_20261018/warm/Result.json')['receipt']['message']['record']
    used=new_uses[0]['record'];assert used['verdict']==source['verdict'] and used['original_score']==source['original_score'] and used['attributed_PF_calls']==source['attributed_PF_calls'] and used['attributed_solver_seconds']==source['attributed_solver_seconds']
    assert not source['verdict']['accepted'] and source['verdict']['reason']=='normal_upper_band_mediation'
    result=read(B/'Results.json');assert result['new_model_PF_optimizer_derivative_forecast_solve_calls']==0 and result['old_full_four_world_physical_gate']=='UNKNOWN'
    leg=result['legs'][0];assert leg['status']=='UNKNOWN_UnknownLineageIdentity';ref=leg['frontier_input'];encoded=(B/ref['path']).read_bytes();assert hashlib.sha256(encoded).hexdigest()==ref['encoded_sha256']
    raw=zlib.decompress(encoded);assert len(raw)==ref['raw_bytes'] and hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];current=pickle.loads(raw);initial=input_state()
    require_same(current['net'],initial['net']);assert current['cursor']==initial['cursor']
    remain=read(R/'outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json');assert current['key']==remain['all_remaining_ordered_identities'][0]['point_action_key']
    assert current['key']==point_key(current['net'],current['cursor'])+'|'+action_key(current['row']) and current['row']==remain['all_remaining_ordered_identities'][0]['row']
    assert menus[-1]['selected_ids']==[v['point_action_key'].rsplit('|',1)[1] for v in remain['all4_original_order']]
    put(out/'Verified_Closed_Gap.json',{'status':'PASS_CHANGED_EVIDENCE_SCREEN_INTEGRITY_BOTH_REJECTED_RECEIPTS_AVAILABLE_NEXT_EXACT_GAP_SAVED_FULL_GATE_UNKNOWN',
        'actual_owner_and_shim_ended':True,'closed_query_messages':closed,'new_receipt_causally_used':1,'new_receipts_available':2,'same_saved_native_current_UV':17,
        'next_exact_missing_key':current['key'],'original_K4_followups_still_missing':3,'fixed_policy_menu_before_new_physics_equal':True,
        'zero_new_model_PF_derivative_forecast_factor_solve_calls':0,'actual_screen_costs':result['actual_CPU_verification_preservation_costs'],'screen_workflow_seconds':result['workflow_seconds'],
        'no_new_commit_or_completed_decision':True,'not_a_full_independent_policy_performance_audit':True,'full_four_world_gate':'UNKNOWN','workflow_seconds':time.perf_counter()-begun})
    manifest(out);print(json.dumps({'saved_gap_audit':'PASS','closed_messages':closed,'remaining_exact_keys':3,'new_science':0}))
if __name__=='__main__':main()
