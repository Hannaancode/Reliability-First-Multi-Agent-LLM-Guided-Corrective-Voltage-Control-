"""Analyze preserved genuine replies only; zero new inference or numerical solves."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/llm_value_broader_development'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(OUT/'Broader_Screen_Completion_Audit.json')['all_gates_passed']
assert read(OUT/'Broader_Component_Completion_Audit.json')['all_gates_passed']
protocol=read(OUT/'clean_value_development_protocol.json')
folder=OUT/'gpu_staged/llm_value_broader_development/gpu_proposals/batches'
details=[];validity={};repeated=[]
for case in protocol['initial_screen_scenarios']:
 for policy in ['zonal_LoRA_prefix','zonal_base_prefix']:
  batches={b:read(folder/(case['scenario_id']+'__'+policy+'__B'+str(b)+'.json')) for b in [8,32,128]}
  raw=[tuple(p['llm_info'].get('raw') for p in batch['proposals']) for batch in batches.values()]
  repeated.append({'scenario_id':case['scenario_id'],'policy':policy,'identical_replies_across_three_budget_acquisitions':raw[0]==raw[1]==raw[2]})
  row=read(OUT/'cpu_screen_cases'/(case['scenario_id']+'__'+policy+'__B32.json'))
  for proposal,scope in zip(batches[32]['proposals'],row['raw_zone_scope_audit']):
   zone=proposal['zone'];assert scope['zone']==zone
   parsed=proposal['llm_info'].get('parsed');voltage_copy=False
   if isinstance(parsed,dict) and set(parsed)=={'bus','q_mvar'}:
    try:
     bus=str(int(parsed['bus']));q=float(parsed['q_mvar'])
     state=batches[32]['proposer_inputs'][zone]['zone_state']
     values={**state.get('lowest_voltage_buses',{}),**state.get('undervoltage_buses',{})}
     voltage_copy=bus in values and abs(q-float(values[bus]))<=1e-10
    except (TypeError,ValueError):pass
   item={'scenario_id':case['scenario_id'],'policy':policy,'zone':zone,'strict_raw_status':scope['strict_raw_status'],
         'accepted_into_prefix':scope['accepted_into_prefix'],'raw_parsed':parsed,
         'parsed_Q_matches_observed_bus_voltage_within1e10':voltage_copy}
   details.append(item)
  selected=[r for r in details if r['policy']==policy]
  validity[policy]={'primary_opportunities_B32':len(selected),'strict_raw_valid':sum(r['accepted_into_prefix'] for r in selected),
                   'observed_voltage_value_used_as_Q':sum(r['parsed_Q_matches_observed_bus_voltage_within1e10'] for r in selected)}
result={'analyzed_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),
        'scope':'Post-outcome mechanism analysis of all eight fixed historical cases; no new performance trials',
        'new_model_calls':0,'new_PF_calls':0,'B32_raw_validity_and_unit_copy_diagnostic':validity,
        'per_query':details,'budget_reply_repeat_diagnostic':repeated,
        'interpretation_limits':'Identical outputs or copied numeric units diagnose this interface, not model knowledge in general. Future acquisition may reuse a declared genuine batch across numerical budgets; old charged calls remain retained.'}
with (OUT/'Response_Mechanism_Analysis.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({'validity':validity,'identical_across_budgets':sum(x['identical_replies_across_three_budget_acquisitions'] for x in repeated),'denominator':len(repeated)},indent=2))
