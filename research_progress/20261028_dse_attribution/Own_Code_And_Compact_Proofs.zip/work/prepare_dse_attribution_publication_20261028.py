"""Compact own-source and evidence snapshot, excluding raw private assets."""
from pathlib import Path
import datetime,hashlib,json,shutil,zipfile
R=Path(__file__).resolve().parents[1]
O=R/'outputs/dse_attribution_thesis_publication_20261028'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists()
    qa=R/'outputs/thesis_dse_and_public_diagnosis_20261028/Final_Visual_And_Evidence_QA.json'
    assert json.loads(qa.read_text('utf-8'))['status'].startswith('PASS_')
    O.mkdir()
    mapping={
      'Comparison.json':'outputs/original118_saved_dse_reconciliation_20261028/Comparison.json',
      'Comparison.csv':'outputs/original118_saved_dse_reconciliation_20261028/Comparison.csv',
      'Comparison_And_Limits.md':'outputs/original118_saved_dse_reconciliation_20261028/Results_Corrected.md',
      'Thesis_Visual_And_Evidence_QA.json':qa.relative_to(R).as_posix(),
      'Thesis_Checklist.json':'outputs/thesis_research_closure_20261028/Tasks.json'}
    for target,source in mapping.items():shutil.copyfile(R/source,O/target)
    members=[
      'work/analyse_original118_raw_action_attribution_v2_20261028.py',
      'work/audit_original118_raw_attribution_20261028.py',
      'work/audit_saved_original_prompt_candidates_20261028.py',
      'work/read_saved_prompt_candidate_diagnosis_20261028.py',
      'work/check_saved_original_context_bounds_20261028.py',
      'work/integrate_thesis_attribution_and_comparators_20261028.py',
      'work/finish_attribution_thesis_layout_20261028.py',
      'work/paginate_attribution_thesis_20261028.ps1',
      'work/close_attribution_thesis_20261028.py',
      'work/reconcile_saved_dse_original118_20261028.py',
      'work/audit_saved_dse_original118_20261028.py',
      'work/close_saved_dse_reconciliation_20261028.py',
      'work/integrate_dse_and_failure_diagnosis_thesis_20261028.py',
      'work/paginate_dse_thesis_20261028.ps1',
      'work/close_dse_thesis_20261028.py',
      'work/prepare_dse_attribution_publication_20261028.py',
      'outputs/original118_raw_action_attribution_v2_20261028/Results.json',
      'outputs/original118_raw_action_attribution_v2_20261028/independent/Independent_Audit.json',
      'outputs/original_prompt_candidate_diagnosis_20261028/Results.json',
      'outputs/original_prompt_candidate_diagnosis_20261028/independent/Independent_Audit.json',
      'outputs/original_saved_context_bounds_20261028/Actual_Saved_Context_Bounds.json',
      'outputs/original_saved_context_bounds_20261028/Initial_Path_Inspection_Failure.json',
      'outputs/thesis_attribution_and_comparators_20261028/Final_Visual_And_Evidence_QA.json',
      'outputs/thesis_attribution_and_comparators_20261028/Initial_QA_Text_Heuristic_Failure.json',
      'outputs/thesis_attribution_and_comparators_20261028/Integration_Record.json',
      'outputs/thesis_attribution_and_comparators_20261028/Layout_Repair_Record.json',
      'outputs/original118_saved_dse_reconciliation_20261028/Verified_Completion.json',
      'outputs/original118_saved_dse_reconciliation_20261028/independent/Independent_Audit.json',
      'outputs/original118_saved_dse_reconciliation_20261028/Input_And_Source_Bindings.json',
      'outputs/original118_saved_dse_reconciliation_20261028/Documentation_Correction.json',
      'outputs/original118_saved_dse_reconciliation_20261028/Process_Inspection_Failure.json',
      'outputs/thesis_dse_and_public_diagnosis_20261028/Integration_Record.json',
      'outputs/thesis_dse_and_public_diagnosis_20261028/Thesis_Evidence_Navigation.json',
      'outputs/public13_saved_numeric_stagnation_20261022/Separate_Arithmetic_Crosscheck.json',
      'outputs/gpu_usage_policy_20261028/Recorded_Usage_And_Scheduling_Policy.json']
    index=[]
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip','x',zipfile.ZIP_DEFLATED) as z:
        for name in members:
            p=R/name;assert p.is_file(),name
            z.write(p,name);index.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip') as z:
        assert z.testzip() is None
        for m in index:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
    (O/'Artifact_Index.json').write_text(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':index,
      'raw_backup_complete':False,'excluded':['private weights and NETs','raw prompts/responses/RAG transcripts','third-party source','full thesis DOCX and PDF'],
      'new_scientific_calls':0,'all_six_goals':'OPEN'},indent=2)+'\n','utf-8')
    resume=json.loads((R/'outputs/research_resumption_20261028/Current_Resume.json').read_text('utf-8-sig'))
    compact={k:resume[k] for k in ['at_utc','all_six_final_goals','scientific_jobs','gpu_assignments','waiting_check','publication','thesis_integration','thesis_closed_requirements','next','raw_action_attribution','raw_prompt_example_diagnosis','actual_saved_context_bounds','saved_DSE_join']}
    (O/'Current_Progress.json').write_text(json.dumps(compact,indent=2)+'\n','utf-8')
    files=[]
    for p in sorted(O.iterdir()):
        if p.is_file():
            b=p.read_bytes();files.append({'local':p.relative_to(R).as_posix(),'path':'research_progress/20261028_dse_attribution/'+p.name,
              'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
    (O/'Publication_Map.json').write_text(json.dumps(files,indent=2)+'\n','utf-8')
    print(json.dumps({'files':len(files),'bytes':sum(x['bytes'] for x in files),'members':len(index)}))
if __name__=='__main__':main()
