# Benchmark-first execution order,20October2026

Priority is G3/G2 first, then G1, followed by G4/G5/G6. Stable goal/subtask IDs, checked evidence and every failed/partial/UNKNOWN result remain retained. The goal is a fair measured win, not a guaranteed favorable result.

The actual paper draft reports227initialUV to3finalUV across25cases,22fullyrestored. Later inspected severe-development extensions reached observed0residualUV in two worlds, with numerical control after archived trainedLLMprefixes. The line36zero-prefix missing closure/checkpoint limitations remain. There is no new matched all25paper-cohort aggregate superiority result and no incrementalLLM superiority claim.

## First published comparison lane: MAPDN

Official NeurIPS2021 environment; all3author network sizes33/141/322are registered. Pinned current code has a documented later PVassignment bugfix, so current-source reproduction must not be labelled byte-identical2021reproduction. Native action is signed continuous PVreactive power limited by inverter capacity; the READMEpositive-only notation is not a complete executable contract. This is different from our trained additive-shunt JSON role. Native limits and all failures must remain unchanged; a proposed HierGridAVC adapter is a separately named variant, not a silent model or plant change.

Author MAPPO,MATD3,MADDPG and numerical droop/OPF form the initial comparator families; no one is weakened or replaced by an untrained policy to create a win. No checkpoint files occur in the pinned code tree; authentic external artifacts have not been established. Full native training/test splits, budgets, final-checkpoint rules and dependencies need fixed source-backed protocols before training. The MATPOWER controls need their authentic runtime; availability must be verified, not assumed.

All16archive entries are inventoried before outcome access. All3staticnetworkobjects have been retrieved with47,013HTTPresponsebytes and checked against exact lengths, deflate and author-directory CRCs. No timeseries row/outcome was opened, pickle executed, environment stepped, PF solved or model called. Native network object/units/zone/actuator inspection is the next substantive task, followed by the original numerical integration and a model-serving action contract. The full3.76GBarchiveSHA has not been independently recomputed; range intakes are not a full archive validation.

## Second lane: PowerGym

Pin all4IEEE13/34/123/8500systems. Preserve OpenDSS multiphase voltage, nativecap/regulator/battery controls and the24-step horizon. Recover the actual published trained baseline/checkpoints or sourcefaithful training recipe. Random is a diagnostic, not the strongest learned baseline. Original HierGrid actions cannot simply be substituted for these different native devices.

## Existing public sources stay in the roster

PGLib,PGLearn andPFDelta remain registered with their earlier sourcechecks, all failures and role mismatches. Do not rerun stoppedSLSQPtrials, relax fixed residual/voltage gates or discard difficult states. Native PF/OPF prediction results are reported separately from voltage-control outcomes. Claim a comparison only after one common valid task is frozen.

## Campaign gates

For each eligible family: version/license/data split -> native input/equation and actuator contract -> actual model-serving and equally informed trained numerical/control integration -> preregistered complete evaluation -> independent physical replay/fullcosts -> unused confirmation. Maintain original DFF,DFFALT and unchangedDSE each/FULLBOTH costs on the original plant. Native reproductions and explicitly adapted common-task runs are separate result tables. Track all planned/attempted/completed/failed/unsupported identities; no favorableworld/seed/checkpoint/prompt/threshold sweep. No superiority is declared before the fixed comparison supports it.

No scientific job,GPU,model call,training or benchmark PF run is active from this source intake. No timer is needed when no independent job is waiting. Exact task state is Current_Resume.json and RESEARCH_TASKS.md.
