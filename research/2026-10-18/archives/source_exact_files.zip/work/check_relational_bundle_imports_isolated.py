"""Isolated upload-source imports, including prior function-scope dependency."""
import candidate_process_runtime
import importlib,json,os,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path.cwd();P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009/cuda_integration_preparation_v3'
payload=json.loads((P/'Cloud_Payload_Manifest.json').read_text())
with tempfile.TemporaryDirectory(prefix='hgimports_checked_') as tmp:
    root=Path(tmp)
    with zipfile.ZipFile(ROOT/payload['archive']) as z:
        sources=[n for n in z.namelist() if n.startswith('work/') and n.endswith('.py')]
        for n in sources:(root/n).parent.mkdir(parents=True,exist_ok=True);(root/n).write_bytes(z.read(n))
    sys.path=[str(root/'work')]+[v for v in sys.path if Path(v or '.').resolve()!=ROOT/'work']
    checked=[]
    try:
        for n in sources:
            name=Path(n).stem
            if name in {'relational_cuda_environment_check_v3','relational_cuda_guardian_v3'}:continue
            mod=importlib.import_module(name);assert Path(mod.__file__).is_relative_to(root);checked.append(name)
        assert Path(sys.modules['candidate_process_pretrained_loader'].__file__).is_relative_to(root)
        (P/'Actual_Isolated_Import_Closure_Proof.json').write_text(json.dumps({'passed':True,
          'only_bundle_work_sources_available':True,'function_scope_missing_loader_import_directly_checked':True,
          'actual_modules_imported_without_model_calls':checked,
          'environment_and_child_launcher_not_executed_in_CPU_import_check':True,
          'new_model_forward_optimizer_PF_cloud_calls':0},indent=2))
        print('ISOLATED_SOURCE_AND_FUNCTION_SCOPE_IMPORT_CLOSURE_PASSED_NO_MODEL_CALLS')
    finally:os.chdir(ROOT)
