"""All-nine ZIP-entry header intake, never evaluate policy or select by outcomes."""
import csv,hashlib,io,json,struct,urllib.request,zlib
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/benchmark_priority_20261020/MAPDN'
OUT=ROOT/'outputs/mapdn_native_contract_v2_20261020/timeseries_headers'
def get_range(url,start,end):
    req=urllib.request.Request(url+'?contract_header='+str(start),headers={'Range':f'bytes={start}-{end}','User-Agent':'HierGrid-source-contract','Accept-Encoding':'identity'})
    with urllib.request.urlopen(req,timeout=45) as response:
        assert response.status==206 and response.headers['Content-Range'].startswith(f'bytes {start}-{end}/')
        raw=response.read(end-start+2);assert len(raw)==end-start+1;return raw
def main():
    OUT.mkdir(exist_ok=False)
    entries=json.loads((BASE/'All_Author_Archive_Entries.json').read_text(encoding='utf-8'))['entries']
    url=json.loads((BASE/'Archive_Directory_Access.json').read_text(encoding='utf-8'))['source_url']
    targets=[e for e in entries if e['path'].endswith('.csv')];assert len(targets)==9
    protocol={'targets':targets,'scope':'CSV column header and first two timestamps only; values neither retained nor inspected. All9entries selected before access, no performance or favourable-case choice.','range_bound_per_entry':66560,'new_PF_model_optimizer_calls':0,'no_full_entry_CRC_validation':True}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    rows=[];total=0
    for e in targets:
        start=e['local_header_offset'];raw=get_range(url,start,start+66559);total+=len(raw)
        fields=struct.unpack('<IHHHHHIIIHH',raw[:30]);assert fields[0]==0x04034b50 and fields[3]==8
        name=raw[30:30+fields[-2]].decode();assert name==e['path']
        offset=30+fields[-2]+fields[-1]
        prefix=zlib.decompressobj(-15).decompress(raw[offset:],128*1024)
        lines=prefix.decode('utf-8').splitlines();assert len(lines)>=3
        header=next(csv.reader([lines[0]]));first=next(csv.reader([lines[1]]));second=next(csv.reader([lines[2]]))
        assert len(first)==len(second)==len(header)
        network=e['path'].split('/')[1];family=Path(e['path']).stem
        native=json.loads((OUT.parent/(network+'_native_input_tables.json')).read_text(encoding='utf-8'))
        expected=len(native['sgen' if family=='pv_active' else 'load'])
        assert len(header)-1==expected
        t1=datetime.fromisoformat(first[0]);t2=datetime.fromisoformat(second[0]);assert (t2-t1).total_seconds()==180
        row={'entry':e['path'],'returned_bytes':len(raw),'range_sha256':hashlib.sha256(raw).hexdigest(),'header':header,'value_columns':len(header)-1,'native_device_count':expected,'first_timestamp':first[0],'second_timestamp':second[0],'initial_sampling_interval_seconds':180,'numerical_row_values_retained_or_evaluated':False,'whole_entry_CRC_verified':False}
        rows.append(row)
        (OUT/(network+'__'+family+'.json')).write_text(json.dumps(row,indent=2),encoding='utf-8')
    (OUT/'Results.json').write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'status':'ALL9_HEADER_DEVICE_COUNTS_AND_INITIAL_TIMESTAMPS_PASS','files':rows,'response_bytes':total,'new_science_calls':0,'limitations':'First interval only, not all-row regularity or total coverage/CRC. Split calendar endpoints and full checksums remain pending; no policy result.'},indent=2),encoding='utf-8')
    print(json.dumps({'all9_header_columns_match_native_devices':True,'response_bytes':total,'timestamps':[r['first_timestamp'] for r in rows]}))
if __name__=='__main__':main()
