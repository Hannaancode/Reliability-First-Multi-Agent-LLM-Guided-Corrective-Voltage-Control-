# Completed numerical pilot: residual route stopped

Both fixed five-epoch controls completed and their final epoch5 checkpoints were
independently verified. Graph reduced OPT equal-world response MSE by1.1169%;
row attention by1.1163%, versus the unchanged AC forecast. Required reduction
was10%. Both failed. Stop this bounded residual method/dataset and its conditional
rank4 LM training route. Do not tune the formula, representation, rank, objective,
decoder, Q, LR, seed, schedule, checkpoint or case subset to rescue the result.

The graph/attention final MSEs were0.00001403048806/0.00001403056567;
AC was0.00001418896235. Both forecast46 upper crossings among216 measured
protected teacher successors, versus58 for AC. This descriptive reduction does
not establish a safe policy, held generalization or incremental LLM value.

Actual2160 task optimizer returns/3456 numerical forwards/432 exact final-fresh
coefficients/10 full model-AdamW-RNG-cursor checkpoints passed identity, worldweight,
source, optimization, cost and frozen checks. The separate terminal binding reader
also verified226 input manifest members, exact original target/index/initialization
hashes, all initial shared tensors and fixed schema buffers; all47/61 active
parameter tensors changed. No dormant-capacity or fake-training explanation is
supported. Nominal FLOP/conditioning/architecture differences remain disclosed.

Science took1130.18seconds before manifest generation. Graph/attention workflows
were446.16/640.32seconds; shared initial loading remains separately charged.
Prior6mocksteps/12forwards, static public schema embedding lookups and all old
physical collection/replay costs remain separate. Zero new contextual pretrained
forwards, PF, GPU allocations or private exports. This is a failed numerical
viability gate; the unexecuted pretrained variant has UNKNOWN performance.

The scientific supplement has1324 unique members/296236555bytes, SHA256
f24db4e93cddb9ef70776fc4c492f113b5eedff08667f65c72a7c4ab483eb511,
with CRC/every member hash verified. All owners ended. Original source, adverse
results, frozen assets and locked bank are unchanged. No scientific or reader restart.

## Next research question, no ready performance experiment

The pilot does not identify why the remaining error was difficult to learn. The
finite-Q AC control explicitly infers current Q-bound PQ status and does not
model future bound releases/switches. A source-based inventory can examine whether
large residual errors coincide with changes in OBSERVED generatorQ-bound occupancy.
This is a physical mechanism hypothesis, not a new ready learner or a causal claim.
Recorded gen/res_gen tables for actual committed prefixes may supply measurements;
they do not certify the solver's unrecorded internal PV/PQ active set.

Before proposing another intervention, audit all exact OPT source before/action/
after identities, current/after generatorQ and known limits, finite/unknown/ambiguous
labels, world/family coverage and same-before action contrasts. Keep unsupported
internal modes unknown. Use no held target design measurements, new PF, model
training or favorable-case selection. Reuse complete physical/source certificates
with their costs. If meaningful measured event/contrast coverage is absent, stop
that hypothesis before spending GPU. Do not manufacture missing candidate vectors,
success rewards or a mature active-set runner. A different method still requires
primary-source novelty review, a separate prospective protocol and strong controls.

The overall objective remains unachieved. Literal D-SE/full both branches/unchanged
selector is still primary. Fresh per-state inference, common protection/verifier,
full numerical/model costs, independent physical replay and genuinely unused
confirmation remain requirements; this failed pilot does not weaken them.
