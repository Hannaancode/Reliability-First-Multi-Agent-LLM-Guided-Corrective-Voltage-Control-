"""Four registered severe cases: original chronological HG-VF and DFF.

Real model requests use the single remote model owner. Initial roots and exact
old physics are reused. Unknown prior collisions stop before another solve.
This is the original native guard track, not an external-method score.
"""
import copy, gzip, hashlib, json, os, pickle, random, sys, time, traceback
from pathlib import Path
from reflection118_chronological_core_20261022 import *

P = R / 'outputs/reflection118_chronological_preparation_20261022'
O = R / 'outputs/r118chrono_20261022/local_controller'
ACTIVE = {}


def necessary(net):
    # These original tables are present in every covered NET. A different
    # active load schedule or outage vector is a necessary-input exclusion.
    from fractions import Fraction
    loads = {}
    for _, row in net.load.iterrows():
        b = int(row.bus)
        if not bool(row.in_service) or not bool(net.bus.at[b, 'in_service']): continue
        q = Fraction(float(row.scaling)); old = loads.get(b, (Fraction(0), Fraction(0)))
        loads[b] = old[0] + Fraction(float(row.p_mw)) * q, old[1] + Fraction(float(row.q_mvar)) * q
    return {'load': [[b, str(p), str(q)] for b, (p, q) in sorted(loads.items())],
            'line_service': [[int(i), bool(v)] for i, v in net.line.in_service.items()],
            'bus_service': [[int(i), bool(v)] for i, v in net.bus.in_service.items()]}


class History:
    def __init__(self):
        from prior_physical_query_footprints_20261018 import component, decode as old_decode
        self.component, self.old_decode = component, old_decode
        path = R / 'outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz'
        self.index = json.loads(gzip.decompress(path.read_bytes())); self.sources = {}; self.cache = {}
        # Additional closed scope indexes have a separate explicit schema.
        # Their source intents are included by the preparation's fixed list.
        self.extra = read(P / 'Additional_Prior_Attempt_References.json')
        self.snapshots = read(R/'outputs/original_role_remaining_native_history_scope_20261022/All_Saved_Snapshot_Components.json')

    def find(self, net, kwargs):
        if len(self.cache)>64:self.cache.clear()
        key, _ = self.component(net)
        from resolve_original_role_input_component_collisions_20261022 import load_component
        load_key = hashlib.sha256(canonical(load_component(net.bus, net.load))).hexdigest()
        for snap in self.snapshots:
            if snap.get('shunt_key') == key and snap.get('nominal_load_key') == load_key:
                raise BaseException('REMAINING_SAVED_SNAPSHOT_INPUT_MATCH_UNKNOWN_NO_RETRY: '+snap['path'])
        refs = self.index.get(key, [])
        for ref in self.extra.get(key, []):
            if ref['necessary_input'] == necessary(net):
                raise BaseException('ADDITIONAL_OLD_INPUT_COMPONENT_AND_LOAD_MATCH_UNKNOWN_NO_RETRY: ' + str(ref['identity']))
        matches = []; excluded = 0
        for ref in refs:
            journal = R / ref['journal']; k = (str(journal), ref['intent_line_sha256'])
            if k not in self.cache:
                self.cache[k] = self.old_decode(journal.parent, ref['before'])
            old = self.cache[k]
            if necessary(old) != necessary(net): excluded += 1; continue
            try: frames_equal(net, old)
            except (AssertionError, KeyError, ValueError) as e:
                raise BaseException('PRIOR_COMPONENT_AND_CURRENT_LOAD_COLLISION_UNKNOWN; no new PF: ' + str(ref)) from e
            if str(journal) not in self.sources:
                self.sources[str(journal)] = [json.loads(x) for x in journal.open('rb')]
            events = self.sources[str(journal)]
            identity = ref['id']; intents = [e['data'] for e in events if e.get('event') == 'PF_intent' and
                e.get('data', {}).get('id', e.get('data', {}).get('identity')) == identity]
            returns = [e['data'] for e in events if e.get('event') == 'PF_return' and
                e.get('data', {}).get('id', e.get('data', {}).get('identity')) == identity]
            if len(intents) != 1 or len(returns) != 1 or 'after' not in returns[0]:
                raise BaseException('OLD_MATCHED_CALL_FAILED_OR_UNRECOVERED_UNKNOWN_NO_RETRY: ' + str(ref))
            if intents[0].get('kwargs') != kwargs:
                raise BaseException('OLD_MATCHED_INPUT_DIFFERENT_OR_UNKNOWN_SOLVER_CONTRACT: ' + str(ref))
            after = self.old_decode(journal.parent, returns[0]['after']); frames_equal(net, after)
            matches.append((after, ref))
        if matches:
            import pandas as pd
            for after, _ in matches[1:]:
                pd.testing.assert_frame_equal(matches[0][0].res_bus, after.res_bus, check_exact=True)
            return matches[0][0], {'exact_old_return': matches[0][1], 'all_matched_returns': len(matches),
                'necessary_input_exclusions': excluded, 'old_cost_and_audit_scope_not_free': True}
        return None, {'indexed_component_references': len(refs), 'necessary_input_exclusions': excluded,
            'scope': 'All frozen retained native attempt lineages; untracked historical kernels not universally certified.'}


def main():
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import numpy as np, pandapower as pp
    from frozen_physics_loader import load_stack, AUDIT
    from public_size_u61_preservation import journal
    O.mkdir(exist_ok=False); start = time.monotonic(); p = read(P / 'Frozen_Engineering_Protocol.json')
    put(O / 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(__file__)})
    for name, h in p['local_source_hashes'].items(): assert sha(R / name) == h
    v2, runner, reflection = load_stack(); assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    put(O / 'Original_AST_Execution.json', AUDIT)
    base = pp.from_json(str(R / 'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones = read(R / 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    rows = read(R / 'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    native_pf = pp.runpp; history = History(); recent = {}; costs = {'new_PF_attempts': 0, 'new_PF_returns': 0,
        'new_PF_exceptions': 0, 'prior_initial_reuses': 0, 'prior_return_reuses': 0,
        'same_study_return_reuses': 0, 'controller_cold_PF_replays': 0, 'model_requests': 0,
        'controller_cold_generation_replays': 0, 'new_PF_seconds': 0.0, 'binary_capsule_bytes': 0}
    previous = '0' * 64; results = []; request = 0

    def event(kind, **data):
        nonlocal previous
        assert time.monotonic() - start < p['local_controller_seconds']
        obj = {'kind': kind, 'active': dict(ACTIVE), 'elapsed_seconds': time.monotonic() - start,
               'previous': previous, **data}; h = hashlib.sha256(canonical(obj)).hexdigest()
        journal(O / 'events.jsonl', {'event': obj, 'sha256': h}); previous = h

    def model(messages):
        nonlocal request
        number = request; request += 1
        req = {'number': number, 'active': dict(ACTIVE), 'messages': messages}
        costs['model_requests'] += 1; event('model_request', number=number, messages_sha256=hashlib.sha256(canonical(messages)).hexdigest())
        put(O / 'requests' / f'request_{number:05d}.json', req)
        answer = O / 'responses' / f'response_{number:05d}.json'; began = time.monotonic()
        while not answer.exists():
            assert not (O/'Remote_Ended.json').exists(),'Actual remote model owner ended; no request retry'
            assert time.monotonic() - began < 300 and time.monotonic() - start < p['local_controller_seconds']
            time.sleep(.2)
        response = read(answer); assert response['request'] == req and response['number'] == number
        event('model_return', number=number, response_sha256=sha(answer))
        return response['raw_text']

    try:
        for row in rows:
            scenario = read(R / row['registration']['recipe']); root = pickle.loads((R / row['solved_payload']).read_bytes())['net']
            for arm in ['reflection_v2', 'no_llm_fallback_first']:
                ACTIVE.clear(); ACTIVE.update(case_id=row['case_id'], arm=arm)
                d = O / row['case_id'] / arm; d.mkdir(parents=True)
                random.seed(p['seed']); np.random.seed(p['seed']); initial_rng = (random.getstate(), np.random.get_state())
                pf_rows = []; gen_rows = []; initial = True

                def primary_pf(net, **kw):
                    nonlocal initial
                    resource_key = history.component(net)[0] + ':' + hashlib.sha256(canonical(necessary(net))).hexdigest() + ':' + hashlib.sha256(canonical(kw)).hexdigest()
                    assert costs['binary_capsule_bytes']+4*1024**2 < p['local_binary_bound_bytes']
                    before = capsule(d / f'pf_{len(pf_rows):06d}_before.zlib', copy.deepcopy(net))
                    costs['binary_capsule_bytes']+=before['bytes'];assert before['bytes']<=2*1024**2
                    assert time.monotonic()-start<p['local_controller_seconds']
                    if initial:
                        assert kw == row['solver_kwargs']; restore_exact(net, root); initial = False
                        costs['prior_initial_reuses'] += 1; provenance = {'kind': 'PAID_INITIAL_REUSE', 'binding': row['payload_sha256']}
                    else:
                        saved = None; provenance = None
                        for old in recent.get(resource_key, []):
                            try: frames_equal(net, decode(old['directory'], old['before']))
                            except AssertionError: continue
                            saved = decode(old['directory'], old['after']); provenance = {'kind': 'SAME_STUDY_RETURN_REUSE', 'record': old['record']}; break
                        if saved is not None:
                            restore_exact(net, saved); costs['same_study_return_reuses'] += 1
                        else:
                            old, scope = history.find(net, kw)
                            if old is not None:
                                restore_exact(net, old); costs['prior_return_reuses'] += 1
                                provenance = {'kind': 'PAID_OLD_RETURN_REUSE', **scope}
                            else:
                                costs['new_PF_attempts'] += 1; event('new_PF_attempt', record=str((d / before['path']).relative_to(O)), kwargs=kw, coverage=scope)
                                tick = time.perf_counter()
                                try: native_pf(net, **kw)
                                except Exception as e:
                                    costs['new_PF_exceptions'] += 1
                                    failed = capsule(d / f'pf_{len(pf_rows):06d}_exception.zlib', copy.deepcopy(net))
                                    costs['binary_capsule_bytes']+=failed['bytes']
                                    event('new_PF_exception', before=before, after=failed, exception=repr(e), kwargs=kw)
                                    raise
                                finally: costs['new_PF_seconds'] += time.perf_counter() - tick
                                costs['new_PF_returns'] += 1
                                provenance = {'kind': 'NEW_PRIMARY_RETURN', 'scope': scope}
                    after = capsule(d / f'pf_{len(pf_rows):06d}_after.zlib', copy.deepcopy(net))
                    costs['binary_capsule_bytes']+=after['bytes'];assert after['bytes']<=2*1024**2
                    rec = {'before': before, 'after': after, 'kwargs': kw, 'provenance': provenance}
                    put(d / f'pf_{len(pf_rows):06d}.json', rec); pf_rows.append(rec)
                    recent.setdefault(resource_key, []).append({'before': before, 'after': after, 'directory': d,
                        'record': str((d / f'pf_{len(pf_rows)-1:06d}.json').relative_to(O))})
                    event('logical_PF_return', record=str((d / f'pf_{len(pf_rows)-1:06d}.json').relative_to(O)), provenance=provenance['kind'])

                def primary_model(messages):
                    text = model(messages); gen_rows.append({'messages': copy.deepcopy(messages), 'text': text, 'request': request-1}); return text

                # Stop only after actual first commitment is in original history.
                warm = None; completed_during_engineering = None
                def stop_at_first(checkpoint):
                    nonlocal warm
                    warm = checkpoint;costs['binary_capsule_bytes']+=capsule(d / 'First_Commit_Warm_State.zlib', checkpoint)['bytes']
                    raise FirstCommitBoundary()
                try:
                    completed_during_engineering, _ = controller(v2, runner, reflection, scenario, base, zones,
                        primary_model, primary_pf, arm, stop_at_first)
                except FirstCommitBoundary: pass
                boundary_pf = len(pf_rows); boundary_gen = len(gen_rows); pi = gi = 0; cold_checked = False
                random.setstate(initial_rng[0]); np.random.set_state(initial_rng[1])

                def continuing_pf(net, **kw):
                    nonlocal pi
                    if pi < boundary_pf:
                        rec = pf_rows[pi]; assert kw == rec['kwargs']; frames_equal(net, decode(d, rec['before']))
                        restore_exact(net, decode(d, rec['after'])); pi += 1; costs['controller_cold_PF_replays'] += 1
                    else:
                        assert cold_checked; primary_pf(net, **kw)

                def continuing_model(messages):
                    nonlocal gi
                    if gi < boundary_gen:
                        rec = gen_rows[gi]; assert messages == rec['messages']; gi += 1; costs['controller_cold_generation_replays'] += 1
                        return rec['text']
                    assert cold_checked; return primary_model(messages)

                def verify_cold(checkpoint):
                    nonlocal cold_checked
                    assert warm is not None and pi == boundary_pf and gi == boundary_gen
                    checkpoint_equal(warm, checkpoint); cold_checked = True
                    costs['binary_capsule_bytes']+=capsule(d / 'First_Commit_Cold_State.zlib', checkpoint)['bytes']
                    put(d / 'Cold_Continuation_Gate.json', {'status': 'PASS_FULL_ACTUAL_CONTROLLER_FEEDBACK_HISTORY_NET_RNG_FIRST_COMMIT',
                        'cached_primary_PF_calls': pi, 'cached_actual_model_calls': gi, 'new_PF_model_calls': 0})
                    event('first_commit_cold_gate_pass', PF_prefix=pi, model_prefix=gi)

                result, _ = controller(v2, runner, reflection, scenario, base, zones,
                    continuing_model, continuing_pf, arm, verify_cold if warm is not None else None)
                if warm is None:
                    assert pi == boundary_pf and gi == boundary_gen and result == completed_during_engineering
                    cold_checked = True
                    put(d / 'Cold_Continuation_Gate.json', {'status': 'PASS_ORIGINAL_NO_COMMIT_TERMINAL_COLD_REPLAY', 'new_PF_model_calls': 0})
                assert cold_checked
                put(d / 'Result.json', result); put(d / 'Call_Order.json', {'PF': pf_rows, 'generations': gen_rows})
                summary = reflection.summarize_result(result); summary['case_id'] = row['case_id']
                summary['strict_final_OV'] = result['final_metrics']['ov_count']; results.append(summary)
                event('complete_actual_original_branch', summary=summary)
                put(d / 'Closed_Manifest.json', {'members': {x.name: sha(x) for x in d.iterdir() if x.is_file()}})
        pairs = []
        for row in rows:
            l = next(x for x in results if x['case_id'] == row['case_id'] and x['method'] == 'reflection_v2')
            n = next(x for x in results if x['case_id'] == row['case_id'] and x['method'] == 'no_llm_fallback_first')
            pairs.append({'case_id': row['case_id'], 'source_selector_choice': reflection.choose_safety_envelope(n, l),
                          'both_branch_costs_required': True})
        put(O / 'Results.json', {'status': 'COMPLETE_FOUR_SOURCE_NATIVE_HGVF_DFF_BRANCH_PAIRS_REQUIRE_READER',
            'summaries': results, 'source_HGSE_choices': pairs, 'costs': costs,
            'native_guard': 'Original hard1.06 unchanged; strict0.95/1.05 outcomes separately retained.',
            'not_full_DSE_external_or_unused_confirmation': True, 'workflow_seconds': time.monotonic()-start})
    except BaseException as e:
        put(O / 'Failure.json', {'type': type(e).__name__, 'failure': str(e), 'traceback': traceback.format_exc(),
            'costs': costs, 'completed_branches': results, 'active': dict(ACTIVE), 'workflow_seconds': time.monotonic()-start})
        raise
    finally:
        put(O / 'Closed_Manifest.json', {'members': {x.relative_to(O).as_posix(): sha(x) for x in O.rglob('*') if x.is_file()}})
        put(O / 'Local_Controller_Ended.json', {'at_unix': time.time(), 'pid': os.getpid(), 'no_retry': True})


if __name__ == '__main__': main()
