"""Prospectively prepare only genuinely unentered registered case/method identities.

No model, converter, PF, optimizer or training is called by this preparation.
The independent prefix replay must close successfully before source admission.
"""
import ast,hashlib,json
from pathlib import Path
from datetime import datetime,timezone

R=Path(__file__).resolve().parents[1]
P=R/'outputs/public13_missing_only_preparation_20261021'
OLD=R/'outputs/public13_remaining_published_cohort_20261021'
OLDPREP=R/'outputs/public13_full_cohort_preparation_20261021'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)

def main():
    assert not P.exists();P.mkdir()
    old=json.loads((OLDPREP/'Protocol.json').read_text());failure=json.loads((OLD/'Failure.json').read_text())
    worlds={w['seed']:w for w in failure['worlds']}
    actual={(w['seed'],a['algorithm']):a for w in failure['worlds'] for a in w['algorithms']}
    missing=[{'seed':seed,'algorithm':algorithm} for seed in old['remaining_author_seeds'] for algorithm in old['algorithms'] if (seed,algorithm) not in actual or actual[(seed,algorithm)]['status']!='COMPLETE_NATIVE_EPISODE']
    assert len(missing)==1013 and missing[:2]==[{'seed':162,'algorithm':'linear'},{'seed':162,'algorithm':'ddpg'}]
    assert actual[(162,'linear')]['steps']==[] and (162,'ddpg') not in actual
    assert [w for w in range(1,500) if w not in worlds]==list(range(163,500))
    assert all(a['status']=='COMPLETE_NATIVE_EPISODE' for (s,_),a in actual.items() if s<162)
    # Confirm no saved successful or attempted policy forward belongs to a new pair.
    missing_set={(v['seed'],v['algorithm']) for v in missing};attempts=0
    for line in (OLD/'events.jsonl').read_text().splitlines():
        v=json.loads(line)['event']
        if v['kind'] in ['agent_forward_attempt','agent_forward_return']:
            assert (v['seed'],v['algorithm']) not in missing_set;attempts+=int(v['kind']=='agent_forward_attempt')
    assert attempts==7896
    put(P/'Exact_Unentered_Method_Case_Identities.json',{'method_cases':missing,'count':len(missing),'original_registered_cases':500,'case0_already_closed_not_repeated':True,'completed_old_pairs_excluded':484,'old_attempt_journal_forward_calls':attempts,'selection_rule':'All missing source-ordered identities in the prospectively registered500-case set. No voltage/outcome selection.'})
    source0=R/'work/run_public13_remaining_published_cohort_20261021.py'
    text=source0.read_text(encoding='utf-8');changes=[]
    def replace(a,b,label):
        nonlocal text
        assert text.count(a)==1,(label,text.count(a));text=text.replace(a,b);changes.append(label)
    replace("PREP=ROOT/'outputs/public13_full_cohort_preparation_20261021';OUT=ROOT/'outputs/public13_remaining_published_cohort_20261021'", "PREP=ROOT/'outputs/public13_missing_only_preparation_20261021';OUT=ROOT/'outputs/public13_missing_only_execution_20261021'\nOLD=ROOT/'outputs/public13_remaining_published_cohort_20261021'\nPREFIX=ROOT/'outputs/public13_first_partial_validation_v2_20261021'",'new prospective source and outputs')
    replace('>4*1024**3','>8*1024**3','new fixed preservation capacity for unentered identities')
    replace("'Fixed4GiB scientific binary preservation budget; no extension'","'Fixed8GiB new-identity preservation budget; no extension'",'explicit new bound, original unchanged')
    replace("p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));deadline=began+p['science_seconds'];ack", "p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));deadline=began+p['science_seconds'];prefix=json.loads((PREFIX/'Independent_Audit.json').read_text());assert prefix['status']=='PASS_FIRST_INDEPENDENT_PRESERVED_PARTIAL_PREFIX_NATIVE_SOURCE_PROJECTION_POLICY_PHYSICS_AND_COST_VALIDATION';prefix_end=json.loads((ROOT/'outputs/public13_first_partial_validation_v2_coordination_20261021/End_ACK.json').read_text());assert prefix_end['actual_owned_chain_ended'] and prefix_end['exit_code']==0\n    ack",'only after independent replay terminal PASS')
    replace("assert regime(net) not in p['paid_prior_regimes'],'Previously entered source input; never repeat science'", "assert regime(net) not in p['paid_prior_regimes'],'Previously entered source regime; no repeated science'",'retain prior physical scope rejection')
    # Exact attempted old identities are excluded before any new reservation.
    replace("if key in attempted:raise RuntimeError", "if (sig,json.dumps(kwargs,sort_keys=True)) in historical_attempts:raise RuntimeError('Old paid physical input not in exact successful cache; NEVER repeat')\n        if any(k[0]==sig for k in historical_attempts):raise RuntimeError('Old physical input with other initializer; UNKNOWN, no retry')\n        if key in attempted:raise RuntimeError",'all old PF attempt signatures blocked before new PF')
    replace("previous='0'*64;stream=", "old_result=json.loads((OLD/'Failure.json').read_text());historical_attempts={(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True)) for r in old_result['receipts']}\n    previous='0'*64;stream=",'old exact PF history retained')
    replace("models,loads,_=b.load_three(env,load_event);put(OUT/'Actual_Checkpoint_Loads.json',loads)", """models,loads,_=b.load_three(env,load_event);put(OUT/'Actual_Checkpoint_Loads.json',loads)
        from public13_complete_policy_state_contract_20261021 import snapshot,restore,source_transition,check_cursor
        carry=np.load(PREFIX/'Independent_Replayed_Final_Source_State.npz');restore(models,{k:carry[k] for k in carry.files})
        put(OUT/'Initial_Carry_Provenance.json',{'source':'Independent replay-derived native policy state, not recovered original final bytes','primary_actual_final_snapshot':'UNRECOVERED','prefix_state_sha256':sha(PREFIX/'Independent_Replayed_Final_Source_State.npz'),'old_primary_costs':old_result['costs'],'prefix_independent_costs':prefix['actual_independent_costs'],'all_prior_costs_additive_not_free':True})
        missing={(v['seed'],v['algorithm']) for v in p['exact_unentered_method_cases']}
        expected_pairs=[(v['seed'],v['algorithm']) for v in p['exact_unentered_method_cases']]
        entered_pairs=[]
        returned_old={r['index']:r for r in old_result['receipts'] if r['status']=='RETURNED'}
        def import_old_seed_cache(seed):
            for index,r in returned_old.items():
                if r['context']['seed']!=seed:continue
                net=pickle.loads((OLD/'physics'/f'PF{index:06d}_after.pkl').read_bytes());assert sha(OLD/'physics'/f'PF{index:06d}_after.pkl')==r['after_sha256']
                ref='OLD:'+str(index);receipts.append({**r,'index':ref,'origin':'ORIGINAL_PAID_PREFIX','old_index':index});cache[(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True))]={'index':ref,'net':net}
        import_old_seed_cache(162)
""",'validated reconstructed native carry and exact paid cache reuse')
    replace("immutable=parameters();np.savez(OUT/'All9_Immutable_Parameters_Before.npz',**immutable)", "initial_parameters=parameters();np.savez(OUT/'All9_Source_Parameters_Before.npz',**initial_parameters)", 'full source-mutable initial state preserved')
    replace("env.__dict__.clear();env.__dict__.update(copy.deepcopy(template));env.reset(seed)", """env.__dict__.clear();env.__dict__.update(copy.deepcopy(template))
                if seed==162:
                    old_world=next(w for w in old_result['worlds'] if w['seed']==162);old_root=OLD/'seed162/Root_Complete_ENV.pkl';assert sha(old_root)==old_world['root_ENV_sha256'];env.__dict__.clear();env.__dict__.update(pickle.loads(old_root.read_bytes()));current_receipt='OLD:'+str(old_world['root_receipt']);costs['paid_exact_cache_uses']+=1;event('paid_old_root_reuse',seed=seed,receipt=current_receipt)
                else:env.reset(seed)""",'reuse exact already-paid seed162 root without a reset or PF')
    replace("for algorithm in p['algorithms']:\n                branch=", "for algorithm in p['algorithms']:\n                if (seed,algorithm) not in missing:continue\n                assert (seed,algorithm) not in entered_pairs;entered_pairs.append((seed,algorithm))\n                branch=", 'exact missing-only branch admission')
    replace("'protocol_sha256':sha(PREP/'Protocol.json')};binary", "'protocol_sha256':sha(PREP/'Protocol.json'),'complete_model_state':snapshot(models),'attempted_inputs':dict(attempted),'historical_attempts':historical_attempts.copy(),'paid_receipts':copy.deepcopy(receipts),'preserved_binary_bytes':_PRESERVED_BINARY_BYTES};binary",'persistent complete policy receipt RNG cursor before every step')
    replace("assert loaded['remaining_source_horizon']==101-step", "check_cursor(loaded,models,deadline);assert loaded['remaining_source_horizon']==101-step", 'strict complete cold state check without extra inference')
    replace("with torch.no_grad():a=m.get_action(np.asarray([loaded['state'][i]]))", "before_policy={n:v.detach().cpu().clone() for n,v in m.state_dict().items()}\n                            with torch.no_grad():a=m.get_action(np.asarray([loaded['state'][i]]))\n                            source_transition(m,algorithm,before_policy)", 'exact native b/c normalization and unchanged other parameters each call')
    replace("raw=np.asarray(raw);action=", "binary(sd/'Policy_State_After_Forwards.pkl',snapshot(models));raw=np.asarray(raw);action=", 'actual after-call mutable model state preserved')
    replace("if done:break", "binary(sd/'Completed_Full_State.pkl',{'environment':copy.deepcopy(env.__dict__),'state':state.copy(),'last_Q':last.copy(),'history':copy.deepcopy(branch['steps']),'complete_model_state':snapshot(models),'paid_receipts':copy.deepcopy(receipts),'attempted_inputs':dict(attempted),'historical_attempts':historical_attempts.copy(),'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'absolute_deadline_monotonic':deadline,'costs':costs.copy(),'next_step':step+1,'remaining_source_horizon':100-step,'protocol_sha256':sha(PREP/'Protocol.json')})\n                        if done:break", 'post-step complete causal cold restoration state retained')
    replace("final_parameters=parameters();assert all(np.array_equal(v,final_parameters[n]) for n,v in immutable.items());np.savez(OUT/'All9_Immutable_Parameters_After.npz',**final_parameters)", "final_parameters=parameters();np.savez(OUT/'All9_Source_Parameters_After.npz',**final_parameters)\n        binary(OUT/'Final_Complete_State.pkl',{'models':snapshot(models),'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'costs':costs.copy(),'worlds':worlds,'receipts':receipts,'absolute_deadline_monotonic':deadline,'original_final_snapshot':'UNRECOVERED','source':'New actual continuation state; original carry reconstructed independently'})", 'actual final state saved, no false immutability assertion')
    replace("complete=not partial and len(worlds)==499 and all(w['root_status']=='RETURNED' and len(w['algorithms'])==3 and all(a['status']=='COMPLETE_NATIVE_EPISODE' for a in w['algorithms']) for w in worlds)", "complete=not partial and entered_pairs==expected_pairs and all(w['root_status']=='RETURNED' and all(a['status']=='COMPLETE_NATIVE_EPISODE' for a in w['algorithms']) for w in worlds)", 'complete requires all exact1013 never-run method-case pairs')
    replace("'COMPLETE_ALL499_REMAINING_AUTHOR_CASES_ALL3_NATIVE_POLICIES' if complete else 'TERMINAL_PARTIAL_REMAINING_AUTHOR_COHORT'", "'COMPLETE_ALL1013_PREDECLARED_UNENTERED_METHOD_CASE_PAIRS' if complete else 'TERMINAL_PARTIAL_NEW_MISSING_ONLY_COHORT'", 'honest exact partial cohort labels')
    replace("'unentered_seeds':p['remaining_author_seeds'][len(worlds):]", "'unentered_seeds':p['remaining_author_seeds'][len(worlds):],'exact_unexecuted_method_cases':[v for v in p['exact_unentered_method_cases'] if (v['seed'],v['algorithm']) not in {(w['seed'],a['algorithm']) for w in worlds for a in w['algorithms'] if a['status']=='COMPLETE_NATIVE_EPISODE'}],'original_failed_prefix_costs':old_result['costs'],'independent_prefix_replay_costs':prefix['actual_independent_costs'],'initial_carry_is_independently_reconstructed_not_actual_old_final':True", 'all missing outcomes and additive prior costs explicit')
    newsource=R/'work/run_public13_missing_only_continuation_20261021.py';ast.parse(text);newsource.write_text(text,encoding='utf-8')
    put(P/'Worker_Static_Contract_Changes.json',{'old_source_sha256':sha(source0),'new_source_sha256':sha(newsource),'changes':changes,'old_worker_unchanged':True,'native_author_environment_and_policy_ASTs_unchanged':True,'action_raw_dtype_clip_reward_stopping_horizon_original':True,'old_resource_bound_not_extended':True,'new_model_PF_calls':0})
    protocol={**old,'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PREPARED_ONLY_SEPARATELY_PROSPECTIVE_GENUINELY_UNENTERED_IDENTITIES','science_seconds':7200,'reader_seconds':7200,'binary_preservation_cap_bytes':8*1024**3,'primary_coordination':'outputs/public13_missing_only_coordination_20261021','algorithms':old['algorithms'],'remaining_author_seeds':list(range(162,500)),'exact_unentered_method_cases':missing,'carried_state_provenance':'Independent source/behavior replay-derived continuation state. Original final bytes remain unrecovered, never relabelled. Fresh new actual snapshots at every new step.','prospective_justification':'Complete all genuinely unentered identities in already registered external500-case native test, no voltage/outcome selection, no old policy/physics retry. Original1800sec study terminal. New7200sec fixed bound for1013unentered episodes and complete state preservation, based on measured1785sec/484completed+additional snapshots, not quality outcomes.','unchanged_native_task':'Author3localvoltage inputs, same9checkpoints/carry order/native100steps/float32clip0.3/source3busstrictdone/all13rawmetrics; no addedguard/actiongrid/improvedpolicy. Not a same-information HierGrid comparison.','old_result_unknowns':'Original final parameter bytes unrecovered; full500 and original complete preserve certificate unknown until explicitly qualified aggregate. New reconstructed carry independently checked but not actual recovered bytes.','source_and_input_hashes':dict(old['source_and_input_hashes'])}
    protocol['source_and_input_hashes'].update({newsource.relative_to(R).as_posix():sha(newsource),'work/public13_complete_policy_state_contract_20261021.py':sha(R/'work/public13_complete_policy_state_contract_20261021.py'),(P/'Exact_Unentered_Method_Case_Identities.json').relative_to(R).as_posix():sha(P/'Exact_Unentered_Method_Case_Identities.json')})
    put(P/'Protocol_Draft.json',protocol)
    print('MISSING_ONLY1013_PROTOCOL_AND_WORKER_PREPARED_NO_NEW_SCIENCE; FIRST_READER_AND_STATIC_GATES_REQUIRED')

if __name__=='__main__':main()
