"""Sole zero-science reader AFTER all real warm/cold/replay owners ended."""
import hashlib
import json
import math
import os
import pickle
import time
from datetime import datetime, timezone
from pathlib import Path

import pandapower as pp
from audit_spatial_allocation_inputs_v3_20261011 import signature
from candidate_process_evidence_utils import frozen_checks, seal
from frozen_physics_loader import load_stack, AUDIT
from native_continuation_preservation_v2 import canonical, extended_local_path
from native_postcommit_preservation import measured_bus_fields, check_commit
from paid_spatial_controller_checkpoint_v1 import process_alive, validate_chain
from paid_spatial_controller_checkpoint_v3 import read_checkpoint, validate_linkages
from trusted_causal_controller_snapshot import SOLVER_ROLES, cap_totals, write_bytes

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'outputs/critical_research_reset_20261010/spatial_controller_cold_engineering_20261012'
OUT = BASE/'independent_audit'
SHARED = extended_local_path(BASE/'query_state')
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def compare(a, b):
    assert a and set(a) == set(b)
    delta = max(abs(a[bus][key]-b[bus][key]) for bus in a for key in a[bus])
    assert all(set(a[bus]) == set(b[bus]) == {'vm_pu', 'va_degree', 'p_mw', 'q_mvar'} for bus in a)
    assert all(math.isfinite(x) for fields in (a,b) for values in fields.values() for x in values.values())
    assert delta <= 1e-10
    assert sorted(bus for bus in a if a[bus]['vm_pu'] < .95) == sorted(bus for bus in b if b[bus]['vm_pu'] < .95)
    return delta


def main():
    OUT.mkdir(exist_ok=False); began = time.perf_counter()
    write_bytes(OUT/'owner.claim', canonical({'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(),
        'command': __import__('sys').argv, 'source_sha256': sha(Path(__file__)), 'new_model_PF_calls': 0}))
    protocol = read(BASE/'preparation/Protocol.json'); ph = sha(BASE/'preparation/Protocol.json')
    qp = read(BASE/'Query_Protocol.json')
    ownership = read(BASE/'Science_Ownership_And_Walltime.json')
    assert ownership['all_actual_phase_owners_ended_exit0'] and len(ownership['phases']) == 3
    assert len({entry['actual_pid'] for entry in ownership['phases']}) == 3
    for entry in ownership['phases']:
        assert entry['exit_code'] == 0 and not process_alive(entry['actual_pid'])
        phase = entry['phase']; claim = read(BASE/phase/'owner.claim'); ack = read(BASE/phase/'Launcher_ACK.json')
        assert entry['actual_pid'] == claim['actual_pid'] == ack['actual_pid']
        assert ack['exact_PID_parent_command_verified'] and claim['protocol_sha256'] == ph
        assert '--phase '+phase in ack['fresh_CIM_identity']['CommandLine']
        closed = read(BASE/phase/'Closed_Manifest.json')
        assert closed['exit_code'] == 0
        for name, item in closed['members'].items():
            path = BASE/phase/name
            assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], name
    for name, digest in protocol['source_sha256'].items():
        assert sha(ROOT/name) == digest, name
    assert sha(ROOT/protocol['network_path']) == protocol['network_sha256']
    assert sha(ROOT/protocol['metadata_path']) == protocol['metadata_sha256']
    warm = read(BASE/'warm/Result.json'); cold = read(BASE/'cold/Result.json'); replay = read(BASE/'replay/Result.json')
    # Refuse every public solver in the mechanical reader, including an
    # accidental indirect call while loading original function definitions.
    attempted = []
    def refuse(*args, **kwargs):
        attempted.append(True); raise AssertionError('Mechanical reader cannot execute physics')
    originals = {name: getattr(pp,name) for name in ('runpp','runopp','rundcpp','runpp_3ph')}
    for name in originals: setattr(pp,name,refuse)
    try:
        _, runner, _ = load_stack(); assert all(row['all_function_asts_unchanged'] for row in AUDIT)
        zones = read(ROOT/protocol['metadata_path'])['zones']
        for phase in ('warm', 'replay'):
            original_input = pickle.loads((BASE/phase/'Before_Initial_Input.pkl').read_bytes())
            assert signature(original_input) == (protocol['canonical_input_signature'], protocol['canonical_input_tables'])
        saved, manifest = read_checkpoint(cold['anchor'], expected_protocol=qp, expected_protocol_sha256=ph,
            expected_controller_identity=cold['controller'], expected_directory=SHARED)
        links = validate_linkages(saved, SHARED); assert len(links) == 1
        assert cold['controller'] == warm['controller'] and saved['controller']['actual_commit_count'] == 1
        assert saved['controller']['remaining_slots'] == 24
        def capsule(handle):
            return pickle.loads((SHARED/saved['handles'][handle]['relative_path']/'trusted_local_state.pkl').read_bytes())
        initial = capsule(warm['root_parent'])['net']
        reports = {z: runner.rescue.extract_zone_state_full(initial,z,zones) for z in sorted(zones)}
        buses = runner.rescue.candidate_buses_from_state(initial,zones,reports,[])
        actions = [runner.rescue.make_action(b,q) for b in buses for q in runner.rescue.Q_SWEEP]
        ids = [runner.action_signature(a) for a in actions]
        assert ids == warm['root_menu'] and list(saved['menus'][warm['root_parent']]) == ids
        root_receipts = [saved['receipts'][(warm['root_parent'],i)] for i in ids]
        accepted = [r for r in root_receipts if r.accepted]
        selected = max(accepted,key=lambda r:r.native_score)
        assert selected.action == warm['selected_receipt']['action']
        assert saved['menus'][warm['root_parent']][selected.action] == warm['selected_action']
        raw_files = sorted((SHARED/'queries').glob('*/Receipt.json'))
        assert len(raw_files) == len(ids)+1 == saved['counters_before_checkpoint']['new_queries']
        raw_by_key = {}
        for path in raw_files:
            raw = read(path); parent, action_id = raw['parent'], raw['action_id']
            assert (parent,action_id) not in raw_by_key; raw_by_key[(parent,action_id)] = raw
            parent_net = capsule(parent)['net']; before = runner.rescue.grid_metrics(parent_net)
            assert canonical(before) == canonical(raw['verification']['before'])
            action = saved['menus'][parent][action_id]
            assert action == raw['action'] and runner.action_signature(action) == action_id
            if raw['solver_handles']:
                assert len(raw['solver_handles']) == 1
                trial = capsule(raw['solver_handles'][0])['net']; after = runner.rescue.grid_metrics(trial)
                assert canonical(after) == canonical(raw['verification']['after'])
                native = (after['vmax'] <= runner.rescue.HARD_OV and after['uv_count'] <= before['uv_count'] and
                    after['deficit_sum'] <= before['deficit_sum']+1e-9 and
                    (after['uv_count'] < before['uv_count'] or after['deficit_sum'] < before['deficit_sum']-1e-9 or
                     after['vmin'] > before['vmin']+1e-9))
                guarded = native and after['vmax'] <= 1.05+1e-8
                assert raw['verification']['accepted'] == guarded
            else:
                assert not raw['verification']['accepted'] and (raw['failed'] or raw['verification']['reason'] == 'q_cap_exceeded')
            if raw['verification']['accepted']:
                assert tuple(raw['original_score']) == tuple(runner.rescue.score_candidate({'action':action,'verif':raw['verification']}))
        actual = capsule(cold['following_parent'])['net']
        admission = check_commit(measured_bus_fields(capsule(selected.successor)['net']), measured_bus_fields(actual),
                                 runner.rescue.grid_metrics(initial), cap_totals(actual))
        assert admission == warm['commit_admission']
        current_reports = {z: runner.rescue.extract_zone_state_full(actual,z,zones) for z in sorted(zones)}
        current_buses = runner.rescue.candidate_buses_from_state(actual,zones,current_reports,[])
        current_actions = [runner.rescue.make_action(b,q) for b in current_buses for q in runner.rescue.Q_SWEEP]
        legal = [a for a in current_actions if all(runner.rescue.llm_q_abs_at_bus(actual,int(b))+abs(float(q)) <= 450
                                                  for b,q in a['add_shunts_q_mvar'].items())]
        assert legal[0] == cold['following_action'] and cold['RNG_exact']
        assert cold['following_parent'] == saved['controller']['current_handle']
        assert cold['warm_receipts_reused'] == saved['counters_before_checkpoint']['reused_receipts'] == len(ids)
        replay_fields = {}
        for name, handle in [('Replay_Initial',warm['root_parent']), ('Replay_Commit',cold['following_parent']),
                             ('Replay_Following',cold['following_receipt']['successor'])]:
            meta = read(BASE/'replay'/(name+'.json')); raw = BASE/'replay'/meta['payload']
            assert sha(raw) == meta['payload_sha256'] and raw.stat().st_size == meta['bytes']
            full = pickle.loads(raw.read_bytes())['net']
            replay_fields[name] = compare(measured_bus_fields(capsule(handle)['net']),measured_bus_fields(full))
            assert cap_totals(full) == cap_totals(capsule(handle)['net'])
        assert replay['following_verification']['accepted'] == cold['following_receipt']['accepted']
        assert replay['following_native_score'] == cold['following_receipt']['native_score']
        assert replay['charged_rebuild_PF_attempts'] == replay['charged_rebuild_PF_returns'] == 3
        costs = saved['counters_before_checkpoint']
        rows, _ = validate_chain(saved['journal_bytes'],ph)
        assert sum(r['event']=='PF_intent' for r in rows) == costs['pf_attempts']
        assert sum(r['event']=='PF_return' for r in rows) == costs['pf_returns']
        assert sum(r['event']=='PF_exception' for r in rows) == costs['pf_exceptions']
        status = {phase:read(BASE/phase/'status.json') for phase in ('warm','cold','replay')}
        direct = sum(status[p]['direct_costs']['attempts'] for p in status)
        returns = costs['pf_returns']+sum(status[p]['direct_costs']['returns'] for p in status)
        exceptions = costs['pf_exceptions']+sum(status[p]['direct_costs']['exceptions'] for p in status)
        pure_seconds = costs['pf_seconds']+sum(status[p]['direct_costs']['pure_solver_seconds'] for p in status)
        total = costs['pf_attempts']+direct
        assert total == returns+exceptions and direct == 5 and not attempted
        frozen = frozen_checks(); write_bytes(OUT/'Frozen_Original_Checks.json',canonical(frozen))
        audit = {'status':'PASS','saved_at_utc':datetime.now(timezone.utc).isoformat(),'actual_reader_pid':os.getpid(),
            'engineering_gate':'ACTUAL_FULL_COORDINATOR_COLD_PROCESS_AND_CONTINUOUS_REPLAY_PASS',
            'scenario_id':protocol['scenario_id'],'actual_scientific_phase_pids':[x['actual_pid'] for x in ownership['phases']],
            'all_phase_sources_inputs_runtime_claims_manifests_verified':True,'full_current_cursor_history_registry_RNG_restoration':True,
            'complete_first_original_native_menu':len(ids),'paid_cache_reuses_without_PF':len(ids),
            'current_only_new_following_identity':True,'selected_trial_actual_commit_admission':admission,
            'independent_continuous_replay_field_deltas':replay_fields,'charged_replay_PF':3,
            'actual_total_PF_attempts':total,'actual_total_PF_returns':returns,'actual_total_PF_exceptions':exceptions,
            'query_PF_attempts':costs['pf_attempts'],'direct_initial_commit_and_replay_PF_attempts':direct,
            'pure_solver_seconds':pure_seconds,'actual_query_cumulative_costs':costs,
            'full_scientific_phase_ownership_and_walltimes':ownership,
            'reader_interval_excluding_import_report_archive_seconds':time.perf_counter()-began,
            'reader_new_model_PF_optimizer_forecast_cloud_calls':0,'nine_original_frozen_checks_pass':frozen['all_passed'],
            'full_policy_performance_or_LLM_advantage':False,
            'limitations':['One fixed L2 development prefix and one actual commit, not 25-step/whole-policy/general restart certificate.',
                'One paid current following trial, not a future committed reward or superiority proof.',
                'Raw native/current OV counts remain separate near 1.05; no all-discrete-OV equality claim.',
                'Full import/setup/preservation/reader/archive/failure costs separately retained; no deployment efficiency claim.',
                'Historical development including L1/L2 is not unused confirmation. No learning or calibrated90percent success.']}
        write_bytes(OUT/'Independent_Actual_Cold_Controller_Audit.json',canonical(audit))
    finally:
        for name,original in originals.items(): setattr(pp,name,original)
    files = {p.relative_to(BASE).as_posix():p for p in BASE.rglob('*') if p.is_file() and 'independent_audit' not in p.parts and
             p.name not in ('owner_status.json','owner_status.tmp','audit_stdout.log','audit_stderr.log')}
    for p in OUT.iterdir():
        if p.is_file():files[p.relative_to(BASE).as_posix()]=p
    for name in protocol['source_sha256']: files['source/'+name]=ROOT/name
    archive=seal(OUT,files,'Actual_Cold_Controller_Engineering_Evidence.zip')
    print(json.dumps({'status':'PASS','actual_PF':total,'charged_replay_PF':3,'archive':archive}),flush=True)


if __name__=='__main__':main()
