"""Public entry point for the new certified initial-state loader; no science.

Use in a fresh prospective owner. It requires complete all500 binding, checks
the saved result/manifest and every bound source hash before loading one case.
The kernel context is returned unevaluated. This does not authorize a rollout.
"""
import hashlib
import json
from pathlib import Path

DEFAULT_CERTIFICATE = 'outputs/nonlinear500_source_binding_20261029/v2_validated_full_admittance'


def load_certified_case(root, seed, certificate_directory=DEFAULT_CERTIFICATE):
    root = Path(root).resolve()
    directory = (root / certificate_directory).resolve()
    directory.relative_to(root)
    if type(seed) is not int or seed < 0 or seed >= 500:
        raise ValueError('A registered integer seed0..499 is required')
    def read_checked(name, expected_hash):
        path = (directory / name).resolve()
        path.relative_to(directory)
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected_hash:
            raise ValueError('Closed binding evidence hash mismatch: ' + name)
        return json.loads(raw)
    closed = json.loads((directory / 'Closed_Manifest.json').read_text(encoding='utf-8'))
    locked = {r['path']: r['sha256'] for r in closed['files']}
    result = read_checked('Results.json', locked['Results.json'])
    freeze = read_checked('Source_Input_Freeze.json', locked['Source_Input_Freeze.json'])
    if result['status'] != 'COMPLETE_ALL500_SOURCE_BINDING_PASS' or result['statuses'] != {'BOUND_INPUT_ONLY': 500}:
        raise ValueError('The all500 binding is incomplete or contains unsupported/unknown cases')
    if [r['seed'] for r in result['rows']] != list(range(500)):
        raise ValueError('Registered population/source order changed')
    if result['bound_sources'] != freeze['sources']:
        raise ValueError('Source freeze/result mismatch')
    for relative, expected in freeze['sources'].items():
        path = (root / relative).resolve()
        path.relative_to(root)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Bound source changed: ' + relative)
    row = result['rows'][seed]
    pack = row['bound_pack']
    pack_relative = (root / pack['path']).resolve().relative_to(directory).as_posix()
    if locked[pack_relative] != pack['sha256']:
        raise ValueError('Bound input pack is not the closed manifest entry')
    from remaining85_source_binder_v2_20261029 import load_bound_kernel
    kernel = load_bound_kernel(root, pack)
    if kernel.costs:
        raise ValueError('Unexpected scientific evaluation while loading')
    return kernel, {'seed': seed, 'root': row['exact_root'], 'pack': pack,
                    'certificate': certificate_directory, 'scientific_evaluations': 0,
                    'scope': 'Certified initial context only; prospective solver/owner/state/reader gates remain.'}
