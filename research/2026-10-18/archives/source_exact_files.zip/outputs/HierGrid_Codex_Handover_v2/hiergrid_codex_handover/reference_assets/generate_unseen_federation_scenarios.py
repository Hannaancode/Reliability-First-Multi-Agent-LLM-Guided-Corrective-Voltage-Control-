"""Generate and lock the post-training IEEE-118 revision scenario bank.

This script adapts the exact Phase-1 combined-stress construction:
uniform load scaling + one inter-zone line outage + DER drop in the line's
``from_zone``.  Inclusion depends only on stressed base-case AC power-flow
convergence.  No controller is imported or evaluated here.

The default factors (1.30 and 1.40) are disjoint from the original combined
bank (1.25, 1.35 and 1.50).  A positive protocol attestation is required so a
bank cannot accidentally be labelled unseen before its provenance is fixed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import revision_config as cfg


np: Any
pd: Any
pp: Any


def load_dependencies() -> None:
    """Load scientific dependencies after CLI parsing so ``--help`` still works."""
    global np, pd, pp
    try:
        import numpy as numpy_module
        import pandas as pandas_module
        import pandapower as pandapower_module
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "Missing scientific dependency. In Colab run: "
            "pip install pandapower numpy pandas"
        ) from exc
    np, pd, pp = numpy_module, pandas_module, pandapower_module


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def write_json(path: Path, obj: Any) -> None:
    path.write_bytes(json_bytes(obj))


def factor_token(value: float) -> str:
    return format(float(value), ".2f").replace(".", "p")


def get_zone_from_bus_idx(bus_idx: int) -> str:
    """Exact balanced bus-range partition used by the Phase-1 builder."""
    bus_idx = int(bus_idx)
    if 0 <= bus_idx <= 29:
        return "MG1"
    if 30 <= bus_idx <= 59:
        return "MG2"
    if 60 <= bus_idx <= 89:
        return "MG3"
    if 90 <= bus_idx <= 117:
        return "MG4"
    return "UNKNOWN"


def validate_metadata_zones(metadata: Mapping[str, Any], bus_indices: Iterable[int]) -> None:
    zones = metadata.get("zones")
    if not isinstance(zones, Mapping):
        raise ValueError("Frozen metadata does not contain a 'zones' mapping.")

    from_metadata: Dict[int, str] = {}
    for zone, buses in zones.items():
        for bus in buses:
            bus_i = int(bus)
            if bus_i in from_metadata:
                raise ValueError(f"Bus {bus_i} appears in multiple metadata zones.")
            from_metadata[bus_i] = str(zone)

    expected = {int(bus): get_zone_from_bus_idx(int(bus)) for bus in bus_indices}
    mismatches = {
        bus: {"metadata": from_metadata.get(bus), "expected": zone}
        for bus, zone in expected.items()
        if from_metadata.get(bus) != zone
    }
    if mismatches:
        sample = dict(list(mismatches.items())[:10])
        raise ValueError(f"Frozen metadata does not match the Phase-1 balanced split: {sample}")


def compute_tie_lines_from_zone_split(net: Any) -> List[Dict[str, Any]]:
    """Exact tie-line rule from ``phase1_testbed_builders_colab.py``."""
    tie_lines: List[Dict[str, Any]] = []
    for line_idx, row in net.line.iterrows():
        from_bus = int(row["from_bus"])
        to_bus = int(row["to_bus"])
        from_zone = get_zone_from_bus_idx(from_bus)
        to_zone = get_zone_from_bus_idx(to_bus)
        if from_zone != to_zone:
            tie_lines.append(
                {
                    "line_idx": int(line_idx),
                    "from_bus": from_bus,
                    "to_bus": to_bus,
                    "from_zone": from_zone,
                    "to_zone": to_zone,
                    "name": (
                        str(row["name"])
                        if "name" in net.line.columns and pd.notna(row["name"])
                        else None
                    ),
                }
            )
    return tie_lines


def group_sgens_by_zone(net: Any) -> Dict[str, List[int]]:
    groups: Dict[str, List[int]] = {"MG1": [], "MG2": [], "MG3": [], "MG4": [], "UNKNOWN": []}
    if not hasattr(net, "sgen") or len(net.sgen) == 0:
        return groups
    for idx, row in net.sgen.iterrows():
        groups[get_zone_from_bus_idx(int(row["bus"]))].append(int(idx))
    return groups


def make_scenario(
    *,
    scenario_id: str,
    factor: float,
    tie_line: Mapping[str, Any],
    zone_der_ids: Sequence[int],
    generated_at_utc: str,
) -> Dict[str, Any]:
    affected_zone = str(tie_line["from_zone"])
    modifications: List[Dict[str, Any]] = [
        {"action": "scale_all_loads", "factor": float(factor)},
        {"action": "open_line", "line_idx": int(tie_line["line_idx"])},
    ]
    if zone_der_ids:
        modifications.append(
            {"action": "drop_sgen_indices", "sgen_indices": [int(x) for x in zone_der_ids]}
        )

    return {
        "scenario_id": scenario_id,
        "system": "federation_4mg_ieee118",
        "scenario_type": "combined_stress",
        "severity": "critical" if float(factor) >= 1.35 else "stress",
        "description": (
            f"Post-training combined stress: load scaled by {factor:.2f}, "
            f"tie-line {int(tie_line['line_idx'])} opened, and DERs in "
            f"{affected_zone} dropped if available."
        ),
        "modifications": modifications,
        "tags": ["revision_unseen", "combined", "load", "tie-line", "der_drop", affected_zone],
        "source_note": "Generated after LoRA training; inclusion uses stressed base AC-PF convergence only.",
        "created_at_utc": generated_at_utc,
        "revision_protocol": {
            "bank_label": cfg.UNSEEN_BANK_LABEL,
            "load_factor": float(factor),
            "tie_line": dict(tie_line),
            "affected_zone": affected_zone,
            "der_drop_indices": [int(x) for x in zone_der_ids],
        },
    }


def apply_scenario_to_net(base_net: Any, scenario: Mapping[str, Any]) -> Any:
    """Apply only the three Phase-1 actions used by this bank."""
    import copy

    net = copy.deepcopy(base_net)
    for modification in scenario.get("modifications", []):
        action = modification.get("action")
        if action == "scale_all_loads":
            factor = float(modification["factor"])
            if len(net.load) > 0:
                net.load["scaling"] = net.load["scaling"].astype(float) * factor
        elif action == "open_line":
            line_idx = int(modification["line_idx"])
            if line_idx not in net.line.index:
                raise ValueError(f"Line index {line_idx} not found in frozen network.")
            net.line.at[line_idx, "in_service"] = False
        elif action == "drop_sgen_indices":
            for index in [int(x) for x in modification["sgen_indices"]]:
                if index not in net.sgen.index:
                    raise ValueError(f"sgen index {index} not found in frozen network.")
                net.sgen.at[index, "p_mw"] = 0.0
                if "q_mvar" in net.sgen.columns:
                    net.sgen.at[index, "q_mvar"] = 0.0
        else:
            raise ValueError(f"Unexpected scenario action in revision bank: {action}")
    return net


def run_base_power_flow(net: Any) -> Dict[str, Any]:
    """Physical/base convergence filter; no controller performance is used."""
    try:
        pp.runpp(
            net,
            algorithm=cfg.PF_ALGORITHM,
            init=cfg.PF_INIT,
            calculate_voltage_angles=cfg.PF_CALCULATE_VOLTAGE_ANGLES,
            enforce_q_lims=cfg.PF_ENFORCE_Q_LIMITS,
            max_iteration=cfg.PF_MAX_ITERATIONS_SCENARIO_FILTER,
        )
        if not bool(net.converged):
            return {"converged": False, "error": "pandapower returned converged=False"}

        vm = net.res_bus["vm_pu"].astype(float)
        result: Dict[str, Any] = {
            "converged": True,
            "error": None,
            "vm_min_pu": float(vm.min()),
            "vm_mean_pu": float(vm.mean()),
            "vm_max_pu": float(vm.max()),
            "under_vmin_count": int((vm < cfg.V_MIN_PU).sum()),
            "over_vmax_count": int((vm > cfg.V_MAX_PU).sum()),
            "voltage_deficit_sum": float(np.clip(cfg.V_MIN_PU - vm.to_numpy(), 0.0, None).sum()),
        }
        if hasattr(net, "res_line") and len(net.res_line) and "loading_percent" in net.res_line:
            loading = net.res_line["loading_percent"].astype(float)
            result["line_loading_max_percent"] = float(loading.max())
            result["overloaded_lines_count"] = int((loading > 100.0).sum())
        else:
            result["line_loading_max_percent"] = None
            result["overloaded_lines_count"] = 0
        return result
    except Exception as exc:  # recorded; never silently dropped
        return {"converged": False, "error": repr(exc)}


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    fieldnames = sorted({key for row in rows for key in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def bank_fingerprint(rows: Sequence[Mapping[str, Any]], provenance: Mapping[str, Any]) -> str:
    payload = {
        "included": [
            {"scenario_id": row["scenario_id"], "scenario_sha256": row["scenario_sha256"]}
            for row in rows
            if row["included_in_locked_bank"]
        ],
        "provenance": provenance,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--network", type=Path, default=cfg.FROZEN_NETWORK_PATH)
    parser.add_argument("--metadata", type=Path, default=cfg.FROZEN_METADATA_PATH)
    parser.add_argument("--output-root", type=Path, default=cfg.UNSEEN_BANK_ROOT)
    parser.add_argument("--factors", nargs="+", type=float, default=list(cfg.UNSEEN_LOAD_FACTORS))
    parser.add_argument(
        "--confirm-post-training-untuned",
        action="store_true",
        help=(
            "Attest that this bank is generated after training and will not be used for "
            "training, augmentation, model selection, threshold tuning, or baseline tuning."
        ),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    load_dependencies()
    network_path = args.network.expanduser().resolve()
    metadata_path = args.metadata.expanduser().resolve()
    output_root = args.output_root.expanduser().resolve(strict=False)
    cfg.assert_output_is_not_frozen(output_root)

    if not args.confirm_post_training_untuned:
        raise SystemExit(
            "Refusing to label a bank unseen without --confirm-post-training-untuned."
        )
    if not network_path.is_file() or not metadata_path.is_file():
        raise FileNotFoundError(
            f"Frozen network/metadata missing: network={network_path}, metadata={metadata_path}"
        )
    if output_root.exists() and any(output_root.iterdir()):
        raise FileExistsError(
            f"Output bank is not empty and will not be overwritten: {output_root}. "
            "Use a new bank directory."
        )

    factors = tuple(float(x) for x in args.factors)
    overlap = sorted(set(factors) & set(cfg.HISTORICAL_COMBINED_LOAD_FACTORS))
    if overlap:
        raise ValueError(f"Requested factors overlap the historical combined bank: {overlap}")
    if len(set(factors)) != len(factors):
        raise ValueError("Duplicate load factors are not allowed.")

    random.seed(cfg.EXPERIMENT_SEED)
    np.random.seed(cfg.EXPERIMENT_SEED)
    generated_at = utc_now()

    all_candidates_dir = output_root / "all_candidates"
    scenarios_dir = output_root / "scenarios"
    reports_dir = output_root / "reports"
    for directory in (all_candidates_dir, scenarios_dir, reports_dir):
        directory.mkdir(parents=True, exist_ok=False)

    base_net = pp.from_json(str(network_path))
    with metadata_path.open("r", encoding="utf-8") as handle:
        metadata = json.load(handle)
    validate_metadata_zones(metadata, [int(x) for x in base_net.bus.index])

    tie_lines = compute_tie_lines_from_zone_split(base_net)
    if not tie_lines:
        raise RuntimeError("No inter-zone tie-lines found; refusing to create an empty bank.")
    sgen_groups = group_sgens_by_zone(base_net)

    rows: List[Dict[str, Any]] = []
    for factor in factors:
        for tie_line in tie_lines:
            affected_zone = str(tie_line["from_zone"])
            zone_der_ids = sgen_groups.get(affected_zone, [])
            scenario_id = (
                f"rev_unseen_combined_load_{factor_token(factor)}_"
                f"line_{int(tie_line['line_idx'])}_{affected_zone}"
            )
            scenario = make_scenario(
                scenario_id=scenario_id,
                factor=factor,
                tie_line=tie_line,
                zone_der_ids=zone_der_ids,
                generated_at_utc=generated_at,
            )

            candidate_path = all_candidates_dir / f"{scenario_id}.json"
            write_json(candidate_path, scenario)
            scenario_hash = sha256_file(candidate_path)

            try:
                stressed_net = apply_scenario_to_net(base_net, scenario)
                pf = run_base_power_flow(stressed_net)
            except Exception as exc:
                pf = {"converged": False, "error": repr(exc)}

            included = bool(pf.get("converged"))
            selected_path = scenarios_dir / candidate_path.name
            if included:
                selected_path.write_bytes(candidate_path.read_bytes())

            row: Dict[str, Any] = {
                "scenario_id": scenario_id,
                "load_factor": factor,
                "line_idx": int(tie_line["line_idx"]),
                "from_bus": int(tie_line["from_bus"]),
                "to_bus": int(tie_line["to_bus"]),
                "from_zone": affected_zone,
                "to_zone": str(tie_line["to_zone"]),
                "der_drop_count": len(zone_der_ids),
                "included_in_locked_bank": included,
                "filter_rule": "stressed_base_ac_pf_converged_only",
                "scenario_sha256": scenario_hash,
                "candidate_file": str(candidate_path.relative_to(output_root)),
                "selected_file": str(selected_path.relative_to(output_root)) if included else None,
            }
            row.update(pf)
            rows.append(row)

    included_count = sum(bool(row["included_in_locked_bank"]) for row in rows)
    excluded_count = len(rows) - included_count
    provenance = {
        "bank_label": cfg.UNSEEN_BANK_LABEL,
        "generated_at_utc": generated_at,
        "network_path": str(network_path),
        "network_sha256": sha256_file(network_path),
        "metadata_path": str(metadata_path),
        "metadata_sha256": sha256_file(metadata_path),
        "generator_path": str(Path(__file__).resolve()),
        "generator_sha256": sha256_file(Path(__file__).resolve()),
        "experiment_seed": cfg.EXPERIMENT_SEED,
        "load_factors": list(factors),
        "historical_combined_load_factors": list(cfg.HISTORICAL_COMBINED_LOAD_FACTORS),
        "tie_line_count": len(tie_lines),
        "candidate_count": len(rows),
        "included_converged_count": included_count,
        "excluded_nonconverged_count": excluded_count,
        "selection_rule": "Include every and only candidate whose stressed base AC power flow converges.",
        "controller_outputs_consulted": False,
        "attestation": (
            "Generated after LoRA training; not used for training, augmentation, model selection, "
            "threshold tuning, or deterministic-baseline tuning."
        ),
        "software": {
            "python": platform.python_version(),
            "pandapower": getattr(pp, "__version__", "unknown"),
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        "power_flow": {
            "algorithm": cfg.PF_ALGORITHM,
            "init": cfg.PF_INIT,
            "max_iteration": cfg.PF_MAX_ITERATIONS_SCENARIO_FILTER,
            "enforce_q_lims": cfg.PF_ENFORCE_Q_LIMITS,
            "calculate_voltage_angles": cfg.PF_CALCULATE_VOLTAGE_ANGLES,
        },
    }

    write_json(reports_dir / "scenario_manifest.json", {"provenance": provenance, "scenarios": rows})
    write_csv(reports_dir / "scenario_manifest.csv", rows)

    sanity_summary = {
        "candidate_count": len(rows),
        "converged_included_count": included_count,
        "nonconverged_excluded_count": excluded_count,
        "target_range": [cfg.TARGET_CONVERGED_SCENARIOS_MIN, cfg.TARGET_CONVERGED_SCENARIOS_MAX],
        "within_target_range": (
            cfg.TARGET_CONVERGED_SCENARIOS_MIN
            <= included_count
            <= cfg.TARGET_CONVERGED_SCENARIOS_MAX
        ),
        "counts_by_factor": {
            str(factor): {
                "candidate": sum(row["load_factor"] == factor for row in rows),
                "included": sum(
                    row["load_factor"] == factor and row["included_in_locked_bank"] for row in rows
                ),
            }
            for factor in factors
        },
        "failed_scenarios": [
            {"scenario_id": row["scenario_id"], "error": row.get("error")}
            for row in rows
            if not row["included_in_locked_bank"]
        ],
    }
    write_json(reports_dir / "sanity_report.json", sanity_summary)
    write_csv(reports_dir / "sanity_report.csv", rows)

    if not sanity_summary["within_target_range"]:
        write_json(
            reports_dir / "BANK_NOT_LOCKED.json",
            {
                "reason": "Converged scenario count is outside the predeclared 50-80 target.",
                "included_converged_count": included_count,
                "action": "Inspect the complete manifest; do not tune using controller outcomes.",
            },
        )
        print(json.dumps(sanity_summary, indent=2))
        return 2

    fingerprint = bank_fingerprint(rows, provenance)
    lock = {
        "status": "LOCKED",
        "bank_label": cfg.UNSEEN_BANK_LABEL,
        "locked_at_utc": utc_now(),
        "bank_fingerprint_sha256": fingerprint,
        "included_scenario_count": included_count,
        "excluded_scenario_count": excluded_count,
        "scenario_directory": str(scenarios_dir),
        "manifest": "reports/scenario_manifest.json",
        "sanity_report": "reports/sanity_report.json",
        "immutable_protocol": (
            "Do not train, augment, select models, tune thresholds, or tune any controller/baseline "
            "using this bank. Preserve excluded failures and all raw outputs."
        ),
    }
    write_json(output_root / "LOCKED_BANK.json", lock)

    print(json.dumps({"lock": lock, "sanity": sanity_summary}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
