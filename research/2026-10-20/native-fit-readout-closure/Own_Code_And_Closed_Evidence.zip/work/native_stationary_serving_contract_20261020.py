"""Exact current-only input, numeric-control feature and native-Q serving boundary.

No model, tokenizer, physics, optimizer or receipt oracle is invoked here.
"""
import copy,json,math
import numpy as np
from native_slm_causal_features_20261020 import check_keys

PREFIX='<|im_start|>system\nEncode the complete current native circuit and operating point for a bounded numeric action readout. Do not generate language.\n<|im_end|>\n<|im_start|>user\n'
SUFFIX='\n<|im_end|>\n<|im_start|>assistant\n'

def extract_joint_state(text):
    marker='<|im_start|>user\n';start=text.index(marker)+len(marker);end=text.index('\n<|im_end|>',start)
    return json.loads(text[start:end])

def stationary_state(joint):
    state=copy.deepcopy(joint);check_keys(state)
    if set(state)!={'network','current_measurements','control','operating_rule','past_receipts'}:raise ValueError('Exact causal joint input schema required')
    if 'remaining_operations' not in state['control']:raise ValueError('Original joint budget must be explicit before stationary projection')
    state.pop('past_receipts');state['control'].pop('remaining_operations')
    return state

def encode_current(state, certified_Y, certified_base_mva):
    check_keys(state)
    if set(state)!={'network','current_measurements','control','operating_rule'}:raise ValueError('Stationary current-only schema required')
    network=state['network'];measure=state['current_measurements'];control=state['control'];rule=state['operating_rule']
    if set(network)!={'base_mva','bus_ids','Ybus_pu_sparse_ij_real_imag'} or network['bus_ids']!=list(range(13)):raise ValueError('Native13 ordered network contract')
    if network['base_mva']!=certified_base_mva or not math.isfinite(certified_base_mva) or certified_base_mva<=0:raise ValueError('Native base MVA must match source')
    if set(measure)!={'Vm_pu','Va_degree','net_P_injection_mw','net_Q_injection_mvar'}:raise ValueError('All current measurements required')
    for key,values in measure.items():
        array=np.asarray(values,dtype=np.float64)
        if array.shape!=(13,) or not np.isfinite(array).all() or (key=='Vm_pu' and not (array>0).all()):raise ValueError('Complete finite native measurements required')
    keys={'actuator_bus_ids','current_Q_mvar','maximum_absolute_increment_mvar','absolute_Q_hardware_cap','transition','decision_scope'}
    if set(control)!=keys or control['actuator_bus_ids']!=[2,7,9] or control['decision_scope']!='joint_three_native_actuators':raise ValueError('Joint native actuator namespace required')
    if control['maximum_absolute_increment_mvar']!=float(np.float32(.3)) or control['absolute_Q_hardware_cap'] is not None or control['transition']!='Q_next=Q_current-u;u is signed float32 Mvar':raise ValueError('No invented Q cap, scale or transition')
    q=np.asarray(control['current_Q_mvar'],dtype=np.float64)
    if q.shape!=(3,) or not np.isfinite(q).all():raise ValueError('Complete native current Q required')
    if rule!={'whole_grid_voltage_band_pu':[.95,1.05],'protect_currently_normal_buses':True,'no_increase_UV_or_OV_counts':True}:raise ValueError('Original protection and band are fixed')
    Y=np.zeros((13,13),dtype=np.complex128);seen=set()
    for entry in network['Ybus_pu_sparse_ij_real_imag']:
        if not isinstance(entry,list) or len(entry)!=4:raise ValueError('Explicit sparse Y entries required')
        i,j,re,im=entry
        if type(i) is not int or type(j) is not int or not 0<=i<13 or not 0<=j<13 or (i,j) in seen:raise ValueError('Native Y index/duplicate mismatch')
        if not math.isfinite(re) or not math.isfinite(im):raise ValueError('Nonfinite admittance')
        seen.add((i,j));Y[i,j]=complex(re,im)
    if np.asarray(certified_Y).shape!=(13,13) or not np.array_equal(Y,certified_Y):raise ValueError('Current circuit differs from pinned certified source')
    values=[float(network['base_mva'])]+Y.real.reshape(-1).tolist()+Y.imag.reshape(-1).tolist()
    for key in ['Vm_pu','Va_degree','net_P_injection_mw','net_Q_injection_mvar']:values+=measure[key]
    values+=control['current_Q_mvar']+control['actuator_bus_ids']+[control['maximum_absolute_increment_mvar']]+rule['whole_grid_voltage_band_pu']
    features=np.asarray(values,dtype=np.float64)
    if features.shape!=(400,) or not np.isfinite(features).all():raise ValueError('Exact same-current400 feature contract')
    text=PREFIX+json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False)+SUFFIX
    return text,features

def native_transition(current_q, native_u):
    q=np.asarray(current_q);u=np.asarray(native_u)
    if q.dtype!=np.float64 or q.shape!=(3,) or not np.isfinite(q).all():raise ValueError('Original float64 native Q cursor required')
    if u.dtype!=np.float32 or u.shape!=(3,) or not np.isfinite(u).all() or not (np.abs(u)<=np.float32(.3)).all():raise ValueError('Already bounded signed float32 Mvar command required')
    return q-u

def native_guard(before_vm, after_vm):
    before=np.asarray(before_vm,dtype=np.float64);after=np.asarray(after_vm,dtype=np.float64)
    if before.shape!=(13,) or after.shape!=(13,) or not np.isfinite(before).all():raise ValueError('Complete native13 current/result vectors required')
    normal=(before>=.95)&(before<=1.05)
    return bool(np.isfinite(after).all() and (after[normal]>=.95-1e-8).all() and (after[normal]<=1.05+1e-8).all() and (after<.95).sum()<=(before<.95).sum() and (after>1.05).sum()<=(before>1.05).sum())
