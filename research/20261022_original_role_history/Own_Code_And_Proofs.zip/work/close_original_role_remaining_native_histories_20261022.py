"""ALL saved warm/cold/reference-replay snapshots and ALL204 named recipes.

Exact nominal-load and shunt components; no new PF, model or derivative.
Ledger references count observations, not fresh scientific executions.
"""
import collections, copy, hashlib, json, os, pickle, sys, time
from datetime import datetime, timezone
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_remaining_native_history_scope_20261022'
B = R / 'outputs/critical_research_reset_20261010'
GROUPS = [B / 'spatial_controller_cold_engineering_20261012', B / 'spatial_full_controller_engineering_20261012', B / 'spatial_DSE_reference_screen_20261012/replays']
Q = R / 'outputs/original_role_prior_input_scope_20261022'

def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def key(x): return hashlib.sha256(canonical(x)).hexdigest()
def write(folder, name, value):
    with (folder / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())

def runtime():
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    def forbidden(*a, **k): raise BaseException('No scientific call in saved-input scope closure')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, forbidden)
    return pp

def produce():
    O.mkdir(exist_ok=False); started = time.perf_counter(); pp = runtime()
    from native_continuation_preservation_v2 import extended_local_path
    from prior_physical_query_footprints_20261018 import component
    from resolve_original_role_input_component_collisions_20261022 import load_component, roots
    from frozen_physics_loader import load_stack, AUDIT
    targetloads = roots(); targets = read(Q / 'All45_Indexed_Scope_Query.json')
    desired = {(t['physical_component_sha256'], key(targetloads[t['root']])) for t in targets}
    snapshots = []
    for group in GROUPS:
        for p in sorted(extended_local_path(group).rglob('*.pkl')):
            plain = Path(str(p)[4:]) if str(p).startswith('\\\\?\\') else p
            snapshots.append(plain)
    journals = sorted(p for g in GROUPS for p in g.rglob('*.jsonl'))
    catalog = read(B / 'spatial_allocation_input_preparation_v2_20261011/Input_Closure.json')['catalog_rows']
    assert len(catalog) == 204
    write(O, 'Protocol.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
        'source_sha256': sha(Path(__file__)), 'fixed_producer_seconds': 600, 'fixed_reader_seconds': 600,
        'all45_target_source_sha256': sha(Q / 'All45_Indexed_Scope_Query.json'),
        'selection': 'ALL saved pickle snapshots from BOTH remaining native warm/cold engineering lineages and ALL reference replays; ALL204 named original recipes. No outcome selection.',
        'snapshot_pins': {str(p.relative_to(R)): sha(extended_local_path(p)) for p in snapshots},
        'journal_pins': {str(p.relative_to(R)): sha(p) for p in journals},
        'old_catalog_certificate_sha256': sha(B / 'spatial_allocation_input_audit_v3_20261011/Independent_Input_Audit.json'),
        'new_scientific_calls': 0, 'limits': 'Necessary physical inputs, any matching pair staysUNKNOWN. Ledger clone copies explicitly retained, not extra new PF calls. Not universal history closure or launch permission.'})
    write(O, 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(Path(__file__))})
    records = []; by_digest = {}; unknown = []
    for path in snapshots:
        assert time.perf_counter() - started < 600
        payload = extended_local_path(path).read_bytes(); digest = hashlib.sha256(payload).hexdigest()
        obj = pickle.loads(payload); net = obj['net'] if isinstance(obj, dict) and 'net' in obj else obj
        if not hasattr(net, 'bus') or not hasattr(net, 'shunt') or not hasattr(net, 'load'):
            records.append({'path': str(path.relative_to(R)), 'sha256': digest, 'status': 'NOT_A_NET_CONTAINER'}); continue
        skey, _ = component(net); lkey = key(load_component(net.bus, net.load))
        rec = {'path': str(path.relative_to(R)), 'sha256': digest, 'status': 'BOUND_SAVED_INPUT_COMPONENTS',
               'shunt_key': skey, 'nominal_load_key': lkey, 'target_pair_match': (skey, lkey) in desired}
        records.append(rec); by_digest[digest] = rec
    closure = []
    for path in journals:
        attempts = []; ends = []; unmapped = []
        for raw in path.open('rb'):
            e = json.loads(raw); e = e.get('row', e); name = e.get('event', ''); data = e.get('payload', e)
            tag = data.get('identity', data.get('name'))
            if name == 'PF_intent' or name.endswith('_PF_intent'): attempts.append(canonical(tag).decode())
            elif name == 'PF_return' or name.endswith('_PF_return') or name == 'PF_exception' or name.endswith('_PF_exception'):
                ends.append(canonical(tag).decode())
                a = data.get('anchors', data)
                digest = data.get('handle', a.get('payload_sha256'))
                if digest not in by_digest: unmapped.append({'event': name, 'identity': tag, 'missing_digest': digest})
        if collections.Counter(attempts) != collections.Counter(ends) or unmapped:
            unknown.append({'journal': str(path.relative_to(R)), 'attempts': len(attempts), 'ends': len(ends), 'unmapped': unmapped})
        closure.append({'journal': str(path.relative_to(R)), 'intent_references': len(attempts), 'closed_references': len(ends),
                        'all_closed_and_snapshot_bound': collections.Counter(attempts) == collections.Counter(ends) and not unmapped})
    _, runner, _ = load_stack(); assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    base = pp.from_json(str(R / 'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones = read(R / 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    v2, _, _ = load_stack(); recipe_rows = []
    for row in catalog:
        path = R / row['path']; assert sha(path) == row['sha256']
        scenario = read(path); net = v2.v0.apply_scenario_to_net(copy.deepcopy(base), scenario, zones)
        loads = key(load_component(net.bus, net.load))
        recipe_rows.append({'path': row['path'], 'scenario_sha256': row['sha256'], 'nominal_load_key': loads,
            'matching_target_roots_UNKNOWN': [root for root, values in targetloads.items() if key(values) == loads]})
    write(O, 'All_Saved_Snapshot_Components.json', records)
    write(O, 'All_Journal_Reference_Closures.json', closure)
    write(O, 'All204_Named_Recipe_Load_Inputs.json', recipe_rows)
    result = {'status': 'COMPLETE_NAMED_SNAPSHOT_AND_RECIPE_SCOPE' if not unknown else 'PARTIAL_REFERENCE_INPUTS_UNKNOWN',
        'snapshot_files': len(records), 'actual_NET_snapshots': len(by_digest),
        'target_pair_matches_UNKNOWN': sum(x.get('target_pair_match', False) for x in records),
        'unclosed_or_unbound_source_groups': unknown,
        'recipe_load_matches_UNKNOWN': sum(bool(x['matching_target_roots_UNKNOWN']) for x in recipe_rows),
        'named_recipes': 204, 'new_scientific_calls': 0, 'pure_network_decodes': 1, 'pure_scenario_applications': 204,
        'not_universal_history_closure_or_PF_authority': True, 'workflow_seconds': time.perf_counter() - started}
    write(O, 'Result.json', result)
    write(O, 'Closed_Manifest.json', {'members': {p.name: sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({k: result[k] for k in ['status', 'snapshot_files', 'target_pair_matches_UNKNOWN', 'recipe_load_matches_UNKNOWN', 'new_scientific_calls', 'workflow_seconds']}))

def audit():
    A = O / 'independent_audit'; A.mkdir(exist_ok=False); started = time.perf_counter(); pp = runtime()
    from native_continuation_preservation_v2 import extended_local_path
    from audit_original_role_prior_input_scope_20261022 import independent_key
    from resolve_original_role_input_component_collisions_20261022 import roots
    from audit_spatial_allocation_inputs_v2_20261011 import independent_apply
    from resolve_original_role_input_component_collisions_20261022 import load_component
    p = read(O / 'Protocol.json'); res = read(O / 'Result.json')
    assert sha(Path(__file__)) == p['source_sha256']
    assert all(sha(O / rel) == h for rel, h in read(O / 'Closed_Manifest.json')['members'].items())
    targetloads = roots(); targets = read(Q / 'All45_Indexed_Scope_Query.json')
    desired = {(x['physical_component_sha256'], key(targetloads[x['root']])) for x in targets}
    rows = read(O / 'All_Saved_Snapshot_Components.json')
    assert len(rows) == len(p['snapshot_pins'])
    for row in rows:
        assert time.perf_counter() - started < 600
        payload = extended_local_path(R / row['path']).read_bytes()
        assert hashlib.sha256(payload).hexdigest() == row['sha256'] == p['snapshot_pins'][row['path']]
        obj = pickle.loads(payload); net = obj['net'] if isinstance(obj, dict) and 'net' in obj else obj
        if row['status'] == 'NOT_A_NET_CONTAINER': assert not hasattr(net, 'bus'); continue
        skey, _ = independent_key(net); lkey = key(load_component(net.bus, net.load))
        assert skey == row['shunt_key'] and lkey == row['nominal_load_key']
        assert ((skey, lkey) in desired) == row['target_pair_match']
    # Separate source-independent application covers all204 recipes. The old
    # full-frame identity audit is reused; this new scope asks only load overlap.
    base = pp.from_json(str(R / 'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones = read(R / 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    recipes = read(O / 'All204_Named_Recipe_Load_Inputs.json'); assert len(recipes) == 204
    for r in recipes:
        path = R / r['path']; assert sha(path) == r['scenario_sha256']
        net = independent_apply(base, read(path).get('modifications', []), zones)
        k = key(load_component(net.bus, net.load))
        assert k == r['nominal_load_key']
        assert [name for name, values in targetloads.items() if key(values) == k] == r['matching_target_roots_UNKNOWN']
    assert all(sha(R / rel) == h for rel, h in p['journal_pins'].items())
    value = {'status': 'PASS_SAVED_COMPONENTS_AND204_INDEPENDENT_RECIPE_APPLICATIONS',
        'snapshot_files': len(rows), 'named_recipes': 204, 'target_snapshot_matches_UNKNOWN': res['target_pair_matches_UNKNOWN'],
        'recipe_load_matches_UNKNOWN': res['recipe_load_matches_UNKNOWN'],
        'source_journal_closure_complete': not res['unclosed_or_unbound_source_groups'],
        'unclosed_source_groups_remain_UNKNOWN': res['unclosed_or_unbound_source_groups'],
        'new_scientific_calls': 0, 'pure_network_decodes': 1, 'pure_scenario_applications': 204,
        'not_universal_history_closure_or_new_PF_authority': True, 'workflow_seconds': time.perf_counter() - started}
    write(A, 'Independent_Audit.json', value)
    write(A, 'Closed_Manifest.json', {'members': {'Independent_Audit.json': sha(A / 'Independent_Audit.json')}})
    print(json.dumps({k: value[k] for k in ['status', 'snapshot_files', 'named_recipes', 'source_journal_closure_complete', 'new_scientific_calls', 'workflow_seconds']}))

if __name__ == '__main__': audit() if '--reader' in sys.argv else produce()
