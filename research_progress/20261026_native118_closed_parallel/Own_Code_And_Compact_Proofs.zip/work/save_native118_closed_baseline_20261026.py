"""Record newly verified full native DFF endpoints and parallel preparation."""
from datetime import datetime,timezone
from reflection118_remaining_cases_v2_core_20261023 import *
from finalize_r118_dff_prelaunch_and_task_snapshot_20261023 import replace_json
O=R/'outputs/native118_complete_dff_and_parallel_20261026'

def main():
    require_partition_closed();O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    audit=read(PARTITION_AUDIT/'Independent_Audit.json');oldpath=R/'outputs/r118chrono_audit_20261022/Independent_Audit.json';old=read(oldpath)
    matched={x['scenario_id']:x for x in old['complete_branches']};rows=[]
    def q(result):return sum(sum(float(v) for v in a['action'].get('add_shunts_q_mvar',{}).values()) for a in result['executed_actions'])
    for row in audit['summaries']:
        case=row['case_id'];dff=read(PARTITION/case/'Result.json');llm=matched.get(case)
        pair=dict(case_id=case,initial_UV=row['base_uv'],DFF_final_UV=row['final_uv'],DFF_strict_OV=row['strict_final_OV'],DFF_actions=row['accepted_actions'],DFF_added_Q_Mvar=q(dff),DFF_Vmin=row['final_vmin'],DFF_deficit=row['final_deficit'],LLM_final_UV=None,LLM_strict_OV=None,comparison='UNKNOWN_UNEXECUTED_LLM_CASE')
        if llm:
            original=read(R/'outputs/r118chrono_20261022/local_controller'/case/'reflection_v2/Result.json')
            pair.update(LLM_final_UV=llm['final_uv'],LLM_strict_OV=llm['strict_OV'],LLM_actions=llm['accepted_actions'],LLM_added_Q_Mvar=q(original),LLM_Vmin=llm['final_vmin'],LLM_deficit=llm['final_deficit'],comparison='COMPLETE_ONE_DEVELOPMENT_PAIR_LLM_HAS_FOUR_FEWER_UV_AND_ONE_FEWER_STRICT_OV',equal_cost_superiority=False)
        rows.append(pair)
    result=dict(at_utc=now,status='ALL4_NATIVE_DFF_COMPLETE_INDEPENDENT_PASS_ONE_ORIGINAL_LLM_PAIR_AVAILABLE',rows=rows,independent_audit=audit,old_original_model_audit_sha256=sha(oldpath),all4_original_model_gate='UNKNOWN_THREE_REMAINING',full_DSE_external_unused_confirmation='NOT_ESTABLISHED',strict_band_restoration_cases=0,source_native_guard=1.06,reporting_band=[.95,1.05],first_replays_only_new_returns=True,failed_calls_never_replayed=True,old_model_training_preparation_and_prior_studies_costs_remain_separate_not_free=True)
    put(O/'Verified_Native_Comparison_State.json',result)
    text='# Original severe118 comparison: verified current evidence\n\nAll four original DFF trajectories and their independent physical/source/cost audit are complete. These are four fixed inspected development roots, not the entire federation dataset or unused confirmation.\n\n| Case | Initial UV | DFF UV / strict OV | Original Reflection-v4 UV / strict OV |\n|---|---:|---:|---:|\n'
    for x in rows:text+=f"| {x['case_id']} | {x['initial_UV']} | {x['DFF_final_UV']} / {x['DFF_strict_OV']} | "+(f"{x['LLM_final_UV']} / {x['LLM_strict_OV']}" if x['LLM_final_UV'] is not None else 'UNKNOWN; not executed')+' |\n'
    text+='\nThe completed first LLM case uses17 actions versus7 for DFF; added reactive power and total search/model/training/preparation/failure costs must remain explicit. It has better voltage outcomes on this one development case, but does not establish equal-cost, full-DSE, external-method or general LLM superiority. Neither endpoint restores the strict normal band. The remaining three cases are fixed in advance.\n\nNew DFF study:4859 physical attempts,4851 returns,8 exceptions;4851 first independent replays,maximum full-field difference0,maxKCL1.140347297480584e-8. Nine exact native-input derived receipts avoided repeated nonlinear solves, with18 input preparations and9 source result extractions charged separately. Original2034first-menu identities,612priorreturns and all old failures/costs remain retained.\n\nParallel preparation: new three-case original-model integration passed on all fixed roots with0newmodel/PF; new GraphAgent pending/cold/stop software passed20 labelled checks,0physics. GraphAgent uses different native actuators and136actions; no matched-resource performance follows.\n'
    (O/'Results.md').write_text(text,encoding='utf-8')
    tasks_path=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(tasks_path)
    for task in tasks['tasks']:
        if task['checklist_id']=='G3':
            task.update(status='ALL4_NATIVE_DFF_VERIFIED_REMAINING3_ORIGINAL_LLM_PREPARING',current_result='All4DFF residualUV11/15/18/7 withstrictOV3/2/2/4. One originalLLMcase7UV/2OV versusDFF11UV/3OV;17versus7actions, unequalactualcosts. All4LLM/fullDSE/external/confirmation stillopen.',next='Complete append-only closed registry and independent audit; freeze new source/payload/analysis bindings; launch fixed three own-profile cases once ready. Published GraphAgent full episodes still need history/owner/reader locks.')
            new=dict(id='G3.native_all4_dff_20261026',completed=True,description='All4originalDFFcomplete;4851firstnewreturnreplays exact,8exceptions preserved,continuous source/cost auditPASS.',evidence='outputs/r118_dff_partition_continuation_independent_20261023/Independent_Audit.json',verified_at_save=now)
            assert new['id'] not in {x['id'] for x in task['subtasks']};task['subtasks'].append(new)
        if task['checklist_id']=='G1':task.update(status='ALL4_DFF_NONZERO_REMAINING_ORIGINAL_LLM_PENDING',current_result='Full DFF residualUV11/15/18/7; firstoriginalLLM7UV. No all-casezero proof.')
    tasks.update(updated_at_utc=now,current_waiting_automations=[]);replace_json(tasks_path,tasks)
    path=R/'outputs/r118_native_comparison_continuation_20261023/Current_Resume.json';resume=read(path)
    resume.update(at_utc=now,status='ALL4_DFF_INDEPENDENT_COMPLETE_NEW_THREE_CASE_REGISTRY_IN_PROGRESS',current_owned_jobs=[],current_timers=[],current_GPU_assignments=0,closed_baseline_evidence=(O/'Verified_Native_Comparison_State.json').relative_to(R).as_posix(),live_counts_not_completion=False,next_estimated_check=None,
        next_tasks=['Continue sole already-started additive v2registry producer/reader, exec84248; do not duplicate.','After incremental registryPASS freeze work/finalize_reflection118_three_case_v2_gates_20261023.py --stage freeze and verifyexactsource/case/ownership/payload locks before fixed3originalcase GPU launch. Old v1finalizer is superseded.','Prepared new GraphAgent episode adapter has softwarePASS only; freeze relevant prior history/native query/ownership/independent reader/fullcost gate before physics.','Publish closedbaseline/parallel sources/proofs and save exactresume.'],next_stage_conditions='Only new additive v2original-case sources; all original functions/guard/prompts intact; no scientific replay/retraining/oldownerrestart. All6finalgoalsOPEN.')
    replace_json(path,resume)
    headline=f'## Verified all4 native DFF closed; three original LLM cases preparing — {now}\n\nAll4DFF residualUV11/15/18/7,strictOV3/2/2/4;4851newreturns independentlyexact,8exceptionsretained. Scientist/reader/coordinatorENDED. Timerhiergrid-exact-input-118-result-checkdeleted. Read outputs/r118_native_comparison_continuation_20261023/Current_Resume.json. New additivev2registry producer/reader exec84248 active; noGPUallocationyet. GraphAgent20labelledsoftwarechecksPASS,0physics. No repeatoldscience; all6goalsOPEN.\n\n'
    for p in [R/'outputs/Unattended_Execution_Runbook.md',R/'outputs/llm_value_development/Next_Phase_Plan.md',R/'RESEARCH_TASKS.md']:
        p.write_text(headline+p.read_text('utf-8'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+headline+text)
    print(json.dumps(dict(status=result['status'],rows=rows)))
if __name__=='__main__':main()
