"""Independent source-file -> saved public NET audit, no converter/PF/model calls."""
import json,os,pickle,re,time
from pathlib import Path
import numpy as np
from public118_import_contract_20261014 import B,R,INTAKE,pins,read,sha,put
def source_matrix(text,name):
    source='\n'.join(line.split('%')[0] for line in text.splitlines())
    body=re.search(r'mpc\.'+name+r'\s*=\s*\[(.*?)\]\s*;',source,re.S).group(1)
    return np.asarray([list(map(float,row.split())) for row in body.split(';') if row.strip()])
def main():
    pins();r=read(B/'actual/Result.json');assert r['exit_code']==0
    out=B/'audit';out.mkdir(exist_ok=False);started=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    for name,digest in read(B/'actual/Closed_Manifest.json')['members'].items():assert sha(B/'actual'/name)==digest
    for i,(source,record) in enumerate(zip(read(INTAKE/'Public_Data_Intake_Result.json')['records'],r['cases']),1):
        path=R/source['path'];assert sha(path)==source['sha256']==record['raw_sha256']
        text=path.read_text('utf-8-sig');saved=pickle.loads((B/'actual'/record['NET']).read_bytes());ppc=saved['ppc'];net=saved['net']
        for kind in ['bus','gen','branch','gencost']:
            expected=source_matrix(text,kind)
            if kind in ['bus','gen']:expected[:,0]-=1
            if kind=='branch':expected[:,:2]-=1
            assert np.array_equal(expected,ppc[kind]),kind
        assert float(re.search(r'mpc\.baseMVA\s*=\s*([0-9.eE+-]+)',text).group(1))==ppc['baseMVA']==net.sn_mva
        assert list(net.bus.index)==list(range(118)) and len(net._from_ppc_lookups['branch'])==186
        assert np.array_equal(net.bus.vn_kv.to_numpy(),ppc['bus'][:,9])
        assert np.array_equal(net.bus.max_vm_pu.to_numpy(),ppc['bus'][:,11]) and np.array_equal(net.bus.min_vm_pu.to_numpy(),ppc['bus'][:,12])
        actual=net.load.groupby('bus')[['p_mw','q_mvar']].sum().reindex(range(118),fill_value=0).to_numpy()
        assert np.allclose(actual,ppc['bus'][:,2:4],atol=1e-12,rtol=0)
        assert len(saved['original_zones_as_policy_adapter'])==4
        assert sorted(b for pool in saved['original_zones_as_policy_adapter'].values() for b in pool)==list(range(118))
        assert not net.converged and net.res_bus.empty
    assert len(r['cases'])==r['converter_attempts']==r['converter_returns']==3
    put(out/'Independent_Public118_Input_Audit.json',{'status':'PASS_ALL_THREE_PINNED_PUBLIC_RAW_MATRICES_BUS_MAPPING_LOADS_LIMITS_AND_FOUR_ZONE_PARTITION',
        'native_and_policy_tasks_separate':True,'new_converter_PF_model_derivative_solve_forecast_calls':0,
        'reader_workflow_seconds':time.perf_counter()-started,
        'limits':'Import/scope validation only. Initial convergence/voltages and real model outputs are NOT_MEASURED; PGLib ACOPF formulation has not been reproduced.'})
    print(json.dumps({'independent_public_input_audit':'PASS','new_converter_model_PF_calls':0}))
if __name__=='__main__':main()
