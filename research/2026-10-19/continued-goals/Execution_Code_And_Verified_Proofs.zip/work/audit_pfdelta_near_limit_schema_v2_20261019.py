"""Additive schema repair for12old UNKNOWN solved_net rows, unchanged equations.

The24 original nominal results are reused, never overwritten. All36 remain.
No zero-filled labels, changed thresholds, solver retries or selected outcomes.
"""
import json,os,time
from pathlib import Path
import numpy as np
import audit_pfdelta_fixed36_native_20261019 as old
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/pfdelta_fixed36_native_schema_v2_20261019'

def normalize(raw):
    assert set(raw)=={'solved_net','lambda'}
    net=raw['solved_net'];assert all(k in net for k in ['bus','branch','gen','baseMVA','per_unit'])
    # The source file itself stores solved fields alongside native parameters;
    # alias them without changing numbers, units, status, limits or labels.
    assert all(all(k in v for k in ['vm','va']) for v in net['bus'].values())
    assert all(all(k in v for k in ['pg','qg']) for v in net['gen'].values() if v['gen_status']==1)
    assert all(all(k in v for k in ['pf','qf','pt','qt']) for v in net['branch'].values() if v['br_status']==1)
    return {'network':net,'solution':{'termination_status':None,'solution':net}}

def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();prior=read(old.B/'Results.json');assert len(prior['rows'])==36
    for rel,h in read(old.B/'Closed_Manifest.json')['members'].items():assert sha(old.B/rel)==h
    assert read(old.B/'independent_polar_audit/Independent_Audit.json')['status'].startswith('PASS_ALL36_')
    missing=[v for v in prior['rows'] if v['native']['status']=='UNKNOWN_UNSUPPORTED_SCHEMA_OR_FIELDS'];assert len(missing)==12 and all(v['native']['error']=="'network'" for v in missing)
    put(B/'Protocol.json',{'status':'FROZEN_ADDITIVE_SCHEMA_REPAIR_NO_CHANGED_PHYSICS','source_sha256':sha(__file__),'original_source_sha256':sha(Path(old.__file__)),'prior_result_sha256':sha(old.B/'Results.json'),
       'missing12_files':[v['file'] for v in missing],'all36_retained':True,'reuse_original24_results':True,'fixed_tolerance':old.TOL,
       'repair':'Only explicit nested solved_net normalization for old12schema-UNKNOWN rows; unchanged original extraction and complex/polar equations. No inferred solver status.',
       'new_model_PF_OPF_optimizer_derivative_forecast_linear_solve_calls':0,'reader_source_sha256':sha(R/'work/check_pfdelta_near_limit_schema_v2_20261019.py')})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    rows=[]
    for record in prior['rows']:
        if record not in missing:rows.append({**record,'provenance':'REUSED_ORIGINAL_INDEPENDENTLY_CHECKED_NOMINAL_RESULT'});continue
        path=old.BASE/'selected36'/record['file'];assert sha(path)==record['sha256']
        try:native=old.evaluate(normalize(read(path)),old.complex_flows)
        except Exception as error:native={'status':'UNKNOWN_UNSUPPORTED_SCHEMA_OR_FIELDS','error_type':type(error).__name__,'error':str(error)}
        rows.append({**record,'native':native,'provenance':'ADDITIVE_SOLVED_NET_SCHEMA_NORMALIZATION_NO_SOURCE_VALUE_CHANGES'})
        put(B/'rows'/record['file'],rows[-1])
    result={'status':'COMPLETE_ALL36_WITH_EXPLICIT_NOMINAL_AND_NEAR_LIMIT_SOURCE_SCHEMAS','rows':rows,'original_unknowns_preserved':True,'all36_retained':True,
       'PF_equation_passes':sum(v['native'].get('PF_equations_pass',False) for v in rows),'checked_limit_passes':sum(v['native'].get('all_checked_operating_limits_pass',False) for v in rows),
       'unknown_rows':sum(v['native']['status'].startswith('UNKNOWN') for v in rows),'workflow_seconds':time.perf_counter()-started,'new_scientific_calls':0,
       'limitations':'Near-limit fields are saved CPF outputs, not new solver-convergence or optimality proof. All native failures retained; no model or corrective-controller evaluation.'}
    put(B/'Results.json',result);manifest(B);print(json.dumps({k:result[k] for k in ['status','PF_equation_passes','unknown_rows']}))

if __name__=='__main__':main()
