"""One bounded joint handoff, waits for both exact arm owners to end."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT);P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';OUT=P/'lm_handoff'
assert not OUT.exists();OUT.mkdir();(OUT/'owner.claim').write_text(json.dumps({'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()}));start=time.monotonic()
def save(stage,**kw):
    f=OUT/'status.tmp';f.write_text(json.dumps({'stage':stage,'updated_at_utc':datetime.now(timezone.utc).isoformat(),**kw},indent=2));f.replace(OUT/'status.json')
try:
    while time.monotonic()-start<12600:
        ready=True;observed={}
        for arm,leaf in [('internal_residual','lm_i'),('frozen_capacity_head','lm_f')]:
            E=P/leaf
            if not (E/'owner.claim').exists():ready=False;observed[arm]='owner_not_started';continue
            pid=int((E/'owner.claim').read_text());cmd=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; if ($p -and $p.CommandLine -match 'run_relational_learning_colab.py') {{ 'LIVE' }} else {{ 'ENDED' }}"
            r=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True,timeout=30);assert r.returncode==0
            observed[arm]={'pid':pid,'authoritative_state':r.stdout.strip()}
            if r.stdout.strip()=='LIVE':ready=False
            else:
                s=json.loads((E/'status.json').read_text());assert s.get('finished_at_utc') and s.get('runtime_released') and s.get('all_actual_artifacts_preserved') and s.get('remote_exit_code')==0,'Terminal partial: complete-only joint reader blocked'
        if not ready:save('waiting_exact_arm_owners',owners=observed);time.sleep(15);continue
        assert not (P/'lm_audit').exists();save('starting_single_joint_external_reader')
        lock=json.loads((P/'learning_preparation/External_Reader_Source_Lock.json').read_text())
        assert hashlib.sha256((ROOT/'work/audit_relational_learning_results.py').read_bytes()).hexdigest()==lock['work/audit_relational_learning_results.py']
        with (OUT/'audit_stdout.log').open('x') as stdout,(OUT/'audit_stderr.log').open('x') as stderr:
            r=subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8','work/audit_relational_learning_results.py'],stdout=stdout,stderr=stderr,timeout=900,creationflags=subprocess.CREATE_NO_WINDOW)
        assert r.returncode==0;save('complete_single_joint_audit');break
    else:raise TimeoutError('Bounded wait elapsed; no scientific rerun')
except BaseException as e:save('ended_partial_or_audit_failure',exception=type(e).__name__);raise
