"""Freeze and exercise a bounded two-query engineering contract BEFORE physics."""
import argparse,ast,copy,hashlib,importlib.metadata,json,os,pickle,random,subprocess,sys,time,zlib
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from exact_two_paid_query_engineering_20261018 import B,I,PYTHON,input_state,save_state,restore_state,known_keys
from certify_exact_two_query_coverage_20261018 import certify
from exact_new_query_reservations_v1_20261018 import Reservations,AlreadyAttemptedIdentity
from paid_receding_chunked_history_v2_20261018 import History,verify_history
from reopen_exact_chunked_history_v1_20261018 import reopen_latest_history
from frozen_physics_loader import load_stack,AUDIT
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from strict_saved_native_input_match_v2_20261018 import require_same
from candidate_process_evidence_utils import frozen_checks

def forbidden(*a,**k):raise AssertionError('PREFLIGHT_ZERO_PHYSICS')
def fixture_cold():
    for name in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,name,forbidden)
    p=read(B/'Protocol.json');state=restore_state(read(B/'preflight/Warm_ACK.json'));source=input_state();require_same(source['net'],state['net']);assert source['cursor']==state['cursor']
    assert state['absolute_deadline_utc']==p['absolute_deadline_utc'];random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
    assert pickle.dumps(random.getstate(),5)==pickle.dumps(state['python_rng'],5) and pickle.dumps(np.random.get_state(),5)==pickle.dumps(state['numpy_rng'],5)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    coverage=dict(read(B/'Attempt_Coverage_Certificate.json'),mode='SOFTWARE_FIXTURE_NO_PF')
    r=Reservations(B/'preflight/reservations',protocol=p,coverage=coverage,known_attempt_keys=known_keys(),runner=runner,zones=zones,restore_anchor=state['reservation_anchor'])
    old=p['exact_new_query_rows'][0]
    try:r.reserve(state['net'],state['cursor'],old['row'],role=old['role'])
    except AlreadyAttemptedIdentity:pass
    else:raise AssertionError('Cold duplicate must block')
    h=reopen_latest_history(state['history_anchor']);assert len(verify_history(state['history_anchor']))==1
    other=p['exact_new_query_rows'][1];key=r.reserve(state['net'],state['cursor'],other['row'],role=other['role']);r.start(key,PF_id='SOFTWARE_ONLY_2',solver_kwargs=p['solver_kwargs'],software_fixture=True)
    r.closed(key,{'PF_id':'SOFTWARE_ONLY_2','outcome':'SOFTWARE_NO_PF'});h.append('software_cold_boundary',{'key':key,'actual_PF':0})
    r.close();h.close();put(B/'preflight/Cold_Result.json',{'status':'PASS_REAL_COLD_ACTUAL_NET_CURSOR_RNG_RESERVATIONS_HISTORY_DUPLICATE_AND_NEXT_IDENTITY','scientific_calls':0})

def local_closure(files):
    seen=set();todo=list(files)
    while todo:
        path=Path(todo.pop()).resolve()
        if path in seen:continue
        seen.add(path)
        if path.suffix!='.py':continue
        for n in ast.walk(ast.parse(path.read_text('utf-8-sig'))):
            modules=[a.name for a in n.names] if isinstance(n,ast.Import) else [n.module] if isinstance(n,ast.ImportFrom) and n.module else []
            for module in modules:
                q=R/'work'/(module.split('.')[0]+'.py')
                if q.is_file() and q not in seen:todo.append(q)
    return sorted(seen)

def prepare():
    B.mkdir(exist_ok=False);begun=time.perf_counter();certify();coverage=read(B/'Attempt_Coverage_Certificate.json');data=read(I/'Exact_Candidate_Inputs.json');state=input_state()
    _,runner,_=load_stack();verify,actuate,native=build_verifier(runner.rescue,state['cursor']);assert native['reverse_AST_exact']
    # Use the exact native verifier call path, replacing only its kernel with
    # a failing labelled stub. No solver/forecast/model is executed.
    calls=[];real=pp.runpp
    def stub(net,**kwargs):
        require_same(net,actuate(copy.deepcopy(state['net']),action(data['exact_new_query_rows'][len(calls)]['row'])))
        calls.append(kwargs);raise RuntimeError('LABELLED_SOFTWARE_PF_STUB_NO_NATIVE_EXECUTION')
    pp.runpp=stub
    try:
        before=copy.deepcopy(state['net'])
        for item in data['exact_new_query_rows']:
            result=verify(state['net'],action(item['row']));assert result['reason']=='pf_failed' and result['after'] is None;require_same(state['net'],before)
    finally:pp.runpp=real
    kwargs={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True}
    assert calls==[kwargs,kwargs]
    source=R/'work/exact_two_paid_query_engineering_20261018.py';reader=R/'work/audit_exact_two_paid_query_engineering_20261018.py';csource=R/'work/certify_exact_two_query_coverage_20261018.py'
    put(B/'Independent_Coverage_Reader_Lock.json',{'reader_source':str(csource.relative_to(R)),'reader_sha256':sha(csource)})
    files=local_closure([source,reader,csource,Path(__file__)])
    files += [Path(x['file']) for x in AUDIT]
    files += [I/'Exact_Candidate_Inputs.json',I/'Exact_Current_Input.zlib',B/'Attempt_Coverage_Certificate.json',B/'Independent_Coverage_Reader_Lock.json']
    files += [R/x for x in coverage['evidence_sha256']]
    files=sorted(set(files))
    protocol={'status':'FROZEN_PROSPECTIVE_TWO_QUERY_ENGINEERING_NOT_A_POLICY_CAMPAIGN','created_utc':datetime.now(timezone.utc).isoformat(),
        'absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=1200)).isoformat(),'fixed_whole_setup_science_reader_bound_seconds':1200,
        'maximum_PF_attempts':4,'maximum_storage_bytes':256*1024**2,'seed':20261018,'solver_kwargs':kwargs,'field_tolerance':1e-10,
        'point':data['point'],'parent_handle':data['parent_handle'],'exact_new_query_rows':data['exact_new_query_rows'],
        'input_preparation_sha256':sha(I/'Exact_Candidate_Inputs.json'),'input_state_sha256':sha(I/'Exact_Current_Input.zlib'),
        'attempt_coverage_certificate':{'path':str((B/'Attempt_Coverage_Certificate.json').relative_to(R)),'sha256':sha(B/'Attempt_Coverage_Certificate.json')},
        'independent_coverage_reader_lock':{'path':str((B/'Independent_Coverage_Reader_Lock.json').relative_to(R)),'sha256':sha(B/'Independent_Coverage_Reader_Lock.json')},
        'source_input_sha256':{str(x.relative_to(R)):sha(x) for x in files},'runtime_versions':{n:importlib.metadata.version(n) for n in ('numpy','scipy','pandas','pandapower')},
        'independent_reader_source':str(reader.relative_to(R)),'independent_reader_sha256':sha(reader),'native_actuation_only_replacement_certificate':native,
        'science':'Exactly the fixed warm primary and other cold primary from the SAME saved17UVcurrent state. Each converged returned primary gets ONE charged identical-input independent replay; exceptions/nonconvergence get no retry. No other identity or action allowed.',
        'gate':'Engineering PASS requires both primaries and both explicitly charged replays retained, exact cold restoration of query-only current NET/cursor/registry/history/RNG/source/cost/original new deadline, all native verifier outcomes and all118 replay fields <=1e-10, independent audit and nine frozen gates. Acceptance or UV improvement is NOT required for an engineering PASS.',
        'stopping':'No actual commit, source current17UVstate remains unchanged. A failure/timeout gives PARTIAL/UNKNOWN and no restart/budget extension. No zeroUVterminal queries.',
        'limits':'Saved hypothetical paid AFTER input, not an old deployment restart or missing old checkpoint/RNG recovery; no fresh LLM, DSE comparison, whole-policy, novelty, speed or superiority claim. No effect on stopped prior interventions.'}
    put(B/'Protocol.json',protocol);put(B/'Independent_Reader_Lock.json',{'source':str(reader.relative_to(R)),'sha256':sha(reader),'protocol_sha256':sha(B/'Protocol.json'),'zero_new_scientific_calls':True})
    fixture=B/'preflight';fixture.mkdir();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    mock=dict(coverage,mode='SOFTWARE_FIXTURE_NO_PF');r=Reservations(fixture/'reservations',protocol=protocol,coverage=mock,known_attempt_keys=known_keys(),runner=runner,zones=zones)
    h=History(fixture/'history',source_anchor=sha(B/'Protocol.json'),input_anchor=protocol['input_state_sha256'],max_bytes=1024**2)
    item=data['exact_new_query_rows'][0];key=r.reserve(state['net'],state['cursor'],item['row'],role=item['role']);r.start(key,PF_id='SOFTWARE_ONLY_1',solver_kwargs=kwargs,software_fixture=True);r.closed(key,{'PF_id':'SOFTWARE_ONLY_1','outcome':'SOFTWARE_NO_PF'})
    h.append('software_warm_boundary',{'key':key,'actual_PF':0});random.seed(protocol['seed']);np.random.seed(protocol['seed'])
    fixturestate={'net':state['net'],'cursor':state['cursor'],'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'reservation_anchor':r.anchor(),'history_anchor':h.anchor(),'absolute_deadline_utc':protocol['absolute_deadline_utc']}
    r.close();h.close();put(fixture/'Warm_ACK.json',save_state(fixture/'Warm_State.zlib',fixturestate))
    with (fixture/'cold_console.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(PYTHON),'-X','utf8',str(Path(__file__)),'--cold-fixture'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);code=child.wait(timeout=120)
    assert code==0 and read(fixture/'Cold_Result.json')['scientific_calls']==0
    put(B/'Frozen_Prelaunch.json',frozen_checks())
    put(B/'Readiness.json',{'status':'PASS_FIXED_TWO_QUERY_PRELAUNCH_ZERO_SCIENCE','source_import_closure_files':len(files),'native_stub_input_paths':2,'actual_cold_fixture':read(fixture/'Cold_Result.json'),
        'source_native_verifier_reverse_AST':native,'independent_reader_source_frozen':True,'coverage_certificate_sha256':sha(B/'Attempt_Coverage_Certificate.json'),
        'fresh_ownership_required_before_each_actual_phase':True,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-begun})
    print(json.dumps({'two_query_protocol':'FROZEN','prelaunch':'PASS','new_science':0,'source_files':len(files)}))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--cold-fixture',action='store_true');args=a.parse_args()
    if args.cold_fixture:fixture_cold()
    else:prepare()
