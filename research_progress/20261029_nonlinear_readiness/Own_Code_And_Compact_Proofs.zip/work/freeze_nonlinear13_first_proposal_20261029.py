from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
import scipy.optimize._slsqp_py as sq
import scipy.optimize._slsqplib as native
import scipy.optimize._minimize as minimize
from nonlinear13_preserved_solver_v3_20261029 import RECIPE
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear13_first_proposal_preparation_20261029'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def main():
    O.mkdir(exist_ok=False)
    proofs=['outputs/nonlinear500_input_binding_independent_20261029/Independent_Audit.json','outputs/nonlinear500_kernel_independent_review_20261029/Independent_Review.json','outputs/nonlinear13_preserved_solver_review_20261029/v3_changed_paths/Independent_Review.json','outputs/nonlinear13_first_proposal_preparation_review_20261029/Review.json']
    for p in proofs:
        d=json.loads((R/p).read_text(encoding='utf-8'));assert d['status'].startswith('PASS'),(p,d['status'])
    sources=['work/run_nonlinear13_first_proposal_20261029.py','work/audit_nonlinear13_first_proposal_20261029.py','work/coordinate_nonlinear13_first_proposal_20261029.py','work/coordinate_single_source_bound_owner_20261020.py','work/coordinate_native_inverter_linear_reference_20261020.py','work/candidate_process_evidence_utils.py','work/nonlinear13_preserved_solver_v3_20261029.py','work/nonlinear13_analytic_derivatives_20261029.py','work/nonlinear13_validated_kernel_v2_20261029.py','work/remaining85_nonlinear_kernel_20261029.py','work/remaining85_certified_loader_20261029.py','work/remaining85_source_binder_v2_20261029.py']
    sources += [Path(m.__file__).relative_to(R).as_posix() for m in [sq,native,minimize]]
    binding='outputs/nonlinear500_source_binding_20261029/v2_validated_full_admittance';sources += [binding+'/'+n for n in ['Results.json','Source_Input_Freeze.json','Closed_Manifest.json']]
    cert=json.loads((R/binding/'Results.json').read_text());pack=cert['rows'][0]['bound_pack'];sources.append(pack['path'])
    protocol=dict(status='FROZEN_ONE_NEW_FIRST_ENTRY_NUMERICAL_PROPOSAL_ONLY',at_utc=datetime.now(timezone.utc).isoformat(),seed=0,rng_seed=20261029,
      source_order_selection='First registered native500 case, fixed before any new proposal outcome; not chosen from85 failed cases.',
      recipe=RECIPE,science_seconds=90,reader_seconds=90,journal_byte_cap=67108864,input_pack=pack,input_root=cert['rows'][0]['exact_root'],
      sources_and_gates={p:sha(R/p) for p in sources+proofs},
      purpose='Actual solver/input/cold/preservation engineering. No physical query, model call or commitment. Two fixed stages only, no retry or rescue.',
      retained_failures='Original kernel and solver v1/v2 defects/software failures remain retained. This is first real optimizer execution for new mechanism.',
      numerical_receipt_reuse='Any future identical source/input/recipe must reuse this actual first proposal, preserving all costs. Not a disposable outcome trial.',
      internal_factor_costs='NativeSLQPCcall counts, elapsedtimes, iterations and all application/derivative calls measured; internal factorization/linear solve counts UNKNOWN, not free.',
      performance='No all500score, physical restoration, feasibility, superiority or LLM benefit can be inferred.')
    put(O/'Protocol.json',protocol)
    for label,src,out,coord in [('Primary','work/run_nonlinear13_first_proposal_20261029.py','outputs/nonlinear13_first_proposal_execution_20261029','outputs/nonlinear13_first_proposal_coordination_20261029'),('Reader','work/audit_nonlinear13_first_proposal_20261029.py','outputs/nonlinear13_first_proposal_independent_20261029','outputs/nonlinear13_first_proposal_reader_coordination_20261029')]:
        assert not (R/out).exists() and not (R/coord).exists()
        put(O/(label+'_Owner_Protocol.json'),dict(single_owner=dict(source=src,sha256=sha(R/src),output=out,coordination=coord,python='work/physics_env/Scripts/python.exe',bound_seconds=120)))
    put(O/'Freeze.json',dict(protocol_sha256=sha(O/'Protocol.json'),status='READY_ONE_NEW_OWNER_AFTER_FRESH_EXACT_PROCESS_CHECK'))
    print('FROZEN_NO_SCIENCE_STARTED')
if __name__=='__main__':main()
