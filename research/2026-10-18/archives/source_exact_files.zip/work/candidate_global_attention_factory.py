"""Capacity fixed from shared-interface plus original adapter, never outcomes."""
from candidate_process_body_intervention import SharedCurrentProcessInterface,GlobalAttentionProcessControl
def make_control(semantic_types):
    control=GlobalAttentionProcessControl(SharedCurrentProcessInterface(semantic_types))
    control.actual_parameters=control.actual_total_parameters
    control.capacity_width=control.ff_width
    return control
