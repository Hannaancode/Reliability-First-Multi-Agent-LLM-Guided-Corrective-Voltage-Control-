"""Bounded frozen-environment restoration with existing ADC and safe cleanup."""
import json,logging,sys,uuid,time
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone
sys.stdout.reconfigure(encoding='utf-8');logging.disable(logging.CRITICAL)
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from colab_cli.runtime import ColabRuntime
from colab_cli.contents import ContentsClient
from google_account_profile import credential_path, verify_account
credentials=Credentials.from_authorized_user_file(str(credential_path()));credentials.refresh(Request())
session=AuthorizedSession(credentials);client=Client(Prod(),session);endpoint=None;runtime=None
notebook_hash=uuid.uuid4()
report={'stage':'preparing','started_at_utc':datetime.now(timezone.utc).isoformat(),'runtime_released':False,'runtime_assignment_confirmed':False,'notebook_hash':str(notebook_hash),'created_by_this_task':True}
def save():Path('outputs/colab_frozen_restore_status.json').write_text(json.dumps(report,indent=2))
try:
 save()
 report['verified_google_account']=verify_account(session)
 usage=client.get_consumption_user_info()
 report['paid_compute_units_balance']=usage.paid_compute_units_balance
 report['preexisting_assignment_count']=len(client.list_assignments())
 report['requested_hardware']='standard T4'
 save()
 assignment=client.assign(notebook_hash,variant=Variant.GPU,accelerator=Accelerator.T4);endpoint=assignment.endpoint
 report['stage']='runtime_assigned';report['runtime_assignment_confirmed']=True;save()
 runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-frozen-restoration')
 ready=False
 for attempt in range(3):
  try:
   outs=runtime.execute_code("print('HIERGRID_KERNEL_READY')",allow_stdin=False,timeout=45)
   ready=any('HIERGRID_KERNEL_READY' in x.get('text','') for x in outs)
   if ready:break
  except RuntimeError:
   runtime.stop();runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-frozen-restoration');time.sleep(3)
 assert ready,'Colab kernel readiness was not established'
 contents=ContentsClient(SimpleNamespace(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token))
 contents.upload('work/remote_execution_bundle.zip','content/hiergrid_execution_bundle.zip')
 print('FROZEN_BUNDLE_UPLOADED',flush=True)
 code="""
import os,sys,subprocess,zipfile,json
from pathlib import Path
root=Path('/content/hiergrid_execution');root.mkdir(exist_ok=True)
with zipfile.ZipFile('/content/hiergrid_execution_bundle.zip') as z:
 for n in z.namelist():
  assert (root/n).resolve().is_relative_to(root.resolve())
 z.extractall(root)
os.chdir(root);Path('outputs').mkdir(exist_ok=True)
log=open('outputs/environment_setup.log','w')
subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','--no-cache-dir','uv==0.8.22'],stdout=log,stderr=subprocess.STDOUT,check=True)
import shutil
uv=shutil.which('uv')
subprocess.run([uv,'python','install','3.12.14'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([uv,'venv','--python','3.12.14','env'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([uv,'pip','install','--python','env/bin/python','--extra-index-url','https://download.pytorch.org/whl/cu128','--index-strategy','unsafe-best-match','-r','work/frozen_gpu_requirements.txt'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([uv,'pip','install','--python','env/bin/python','--extra-index-url','https://download.pytorch.org/whl/cu128','--index-strategy','unsafe-best-match','-r','work/frozen_dependency_closure.txt'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([uv,'pip','install','--python','env/bin/python','--reinstall','--no-deps','--index','https://pypi.org/simple','torchao==0.17.0'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['env/bin/python','work/remote_environment_check.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['env/bin/python','-c',"import importlib.metadata as m,json;from pathlib import Path;pins=[l.split('==') for l in Path('work/frozen_dependency_closure.txt').read_text().splitlines()];diff={n:{'expected':v,'actual':m.version(n)} for n,v in pins if m.version(n)!=v};Path('outputs/exact_dependency_check.json').write_text(json.dumps({'checked_count':len(pins),'differences':diff}));assert not diff"],stdout=log,stderr=subprocess.STDOUT,check=True)
log.close();print('HIERGRID_RESTORATION_COMPLETED')
"""
 bootstrap_version=Path('work/uv_bootstrap_version.txt').read_text().strip()
 import re
 assert re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+',bootstrap_version)
 code=code.replace('uv==0.8.22','uv=='+bootstrap_version)
 report['bootstrap_uv_version']=bootstrap_version
 report['stage']='installing_and_loading_frozen_model';save()
 outputs=runtime.execute_code(code,allow_stdin=False,timeout=900)
 for out in outputs:
  if out.get('output_type')=='stream':
   for line in out.get('text','').splitlines():
    if line.startswith('HIERGRID_RESTORATION_COMPLETED'):report['stage']='frozen_model_loaded'
  elif out.get('output_type')=='error':report['kernel_error_type']=out.get('ename');print('REMOTE_SETUP_ERROR',out.get('ename'),flush=True)
 for name in ['environment_setup.log','remote_frozen_environment.json','exact_dependency_check.json']:
  try:contents.download('content/hiergrid_execution/outputs/'+name,'outputs/'+name)
  except Exception:pass
 print('RESTORATION_STAGE',report['stage'],flush=True)
except Exception as exc:
 report['stage']='allocation_failed' if endpoint is None else 'restoration_failed'
 report['failure_type']=type(exc).__name__
 response=getattr(exc,'response',None)
 if response is not None:report['failure_http_status']=response.status_code
 message=str(exc)
 for secret in [credentials.token,credentials.refresh_token,credentials.client_secret,assignment.runtime_proxy_info.token if endpoint else None]:
  if secret:message=message.replace(secret,'[REDACTED]')
 import re
 message=re.sub(r'https?://[^\s\)]+','[URL]',message)
 report['sanitized_failure_message']=message[:500]
 print('RESTORATION_FAILURE',type(exc).__name__,message[:500],flush=True)
 if 'contents' in locals():
  try:contents.download('content/hiergrid_execution/outputs/environment_setup.log','outputs/environment_setup.log')
  except Exception:pass
finally:
 if runtime is not None:
  try:runtime.stop()
  except Exception:pass
 if endpoint is not None and report['stage']!='frozen_model_loaded':
  try:client.unassign(endpoint);report['runtime_released']=True
  except Exception as exc:report['release_failure_type']=type(exc).__name__
 if endpoint is None:
  try:
   existing=client._get_assignment(notebook_hash,variant=Variant.GPU,accelerator=Accelerator.T4)
   if getattr(existing,'runtime_proxy_info',None) is not None:
    client.unassign(existing.endpoint);report['runtime_released']=True;report['post_failure_assignment_state']='assigned_then_released'
   else:report['post_failure_assignment_state']='not_assigned'
  except Exception as exc:report['post_failure_assignment_check_failure_type']=type(exc).__name__
 report['finished_at_utc']=datetime.now(timezone.utc).isoformat()
 session.close();save();print('RESTORE_PROBE_RUNTIME_RELEASED',report['runtime_released'],flush=True)
 if report['stage']!='frozen_model_loaded':sys.exit(1)
