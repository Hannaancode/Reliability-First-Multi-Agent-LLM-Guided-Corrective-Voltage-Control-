"""Proposed action-conditioned Vm transition boundary; no model or solver.

Targets and audit metadata never enter compile_current_action. These helpers
do not implement a predictor, certify a GPU runner, or authorize a rollout.
"""
import copy, math
from candidate_predictor_input_contract import validate_observation, Q_GRID

INPUT_FIELDS={'current_physical_observation','current_control_state','original_Q_grid','candidate_action'}
CONTROL_FIELDS={'added_abs_Q_MVAr_by_bus','original_per_bus_added_support_cap_MVAr'}
ACTION_FIELDS={'bus','q_abs_mvar'}

def compile_current_action(current):
    if set(current)!=INPUT_FIELDS:raise ValueError('Only exact current/action fields; no audit IDs, labels or AFTER')
    validate_observation(current['current_physical_observation'])
    support=current['current_control_state'];action=current['candidate_action']
    if set(support)!=CONTROL_FIELDS or set(action)!=ACTION_FIELDS:raise ValueError('Exact control/action schema')
    if support['original_per_bus_added_support_cap_MVAr']!=450.:raise ValueError('Original cap required')
    values=support['added_abs_Q_MVAr_by_bus']
    if len(values)!=118 or any(type(x) not in (int,float) or not math.isfinite(x) or not 0<=x<=450. for x in values):
        raise ValueError('118 finite current added-support measurements required')
    if current['original_Q_grid']!=list(Q_GRID):raise ValueError('Original Q grid required')
    b=action['bus'];q=action['q_abs_mvar']
    if type(b) is not int or not 0<=b<118 or type(q) not in (int,float) or q not in Q_GRID:
        raise ValueError('Native bus and original Q value required')
    pools=current['current_physical_observation']['raw_common_and_zone_pools']
    if not any(b in p for p in pools.values()):raise ValueError('Before-state raw common AND zone membership required')
    if values[b]+q>450.:raise ValueError('Original added-support cap exceeded')
    return copy.deepcopy(current)

def vm_vector(table):
    if set(table)!={'columns','index','values'}:raise ValueError('Exact table schema')
    if len(table['index'])!=118 or set(table['index'])!=set(range(118)) or len(table['values'])!=118:
        raise ValueError('118 unique native buses required')
    if len(table['columns'])!=len(set(table['columns'])) or 'vm_pu' not in table['columns']:
        raise ValueError('Unique columns and Vm required')
    col=table['columns'].index('vm_pu'); values={}
    for b,row in zip(table['index'],table['values']):
        if len(row)!=len(table['columns']) or type(row[col]) not in (int,float) or not math.isfinite(row[col]) or row[col]<=0:
            raise ValueError('Finite positive native voltage values required')
        values[b]=float(row[col])
    return [values[b] for b in range(118)]

def measured_training_target(current, measured_target, analytic_next_vm):
    """Separate loss-side operation, never a forward input or claimed forecast."""
    inp=compile_current_action(current)
    if set(measured_target)!={'next_res_bus'}:raise ValueError('Only actually measured next bus table')
    after=vm_vector(measured_target['next_res_bus'])
    before=vm_vector(inp['current_physical_observation']['physical_tables']['res_bus'])
    if len(analytic_next_vm)!=118 or any(type(x) not in (int,float) or not math.isfinite(x) for x in analytic_next_vm):
        raise ValueError('Separately measured analytic forecast required, never a successor label')
    return {'measured_delta_vm':[a-b for a,b in zip(after,before)],
            'measured_minus_analytic_vm':[a-f for a,f in zip(after,analytic_next_vm)],
            'actual_next_vm':after}

def forecast_from_residual(current_vm, analytic_delta_vm, q, scale, predicted_unit_residual):
    """Fixed proposal equation; nonfinite/nonpositive outputs fail explicitly.

    q=0 is only a mathematical zero-action fixture, not an added Q-grid action.
    No clipping, projection, guard certificate or real PF result is supplied.
    """
    if q not in (0.,*Q_GRID) or not math.isfinite(scale) or scale<=0:raise ValueError('Fixed scale/Q')
    arrays=(current_vm,analytic_delta_vm,predicted_unit_residual)
    if any(len(v)!=118 or any(type(x) not in (int,float) or not math.isfinite(x) for x in v) for v in arrays):
        raise ValueError('Finite118-bus vectors required')
    result=[v+d+(q/300.)*scale*r for v,d,r in zip(*arrays)]
    if any(not math.isfinite(v) or v<=0 for v in result):raise ValueError('Unphysical forecast; retain failure')
    return result
