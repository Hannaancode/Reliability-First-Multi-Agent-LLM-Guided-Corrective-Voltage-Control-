"""First owned saved-evidence acquisition reader; no optimization or PF replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import sys
import time
import traceback

R=Path(__file__).resolve().parents[1]
P=R/'outputs/nonlinear500_receding_acquisition_preparation_20261030'
S=R/'outputs/nonlinear500_receding_acquisition_execution_20261030'
C=R/'outputs/nonlinear500_receding_acquisition_coordination_20261030'
O=R/'outputs/nonlinear500_receding_acquisition_independent_20261030'


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def ref(p):
    p=Path(p); p.resolve().relative_to(R.resolve())
    return {'path':p.relative_to(R).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def frozen_original_gate(before,after,reported):
    return bool(before.get('all_passed') is True and after.get('all_passed') is True
        and len(before.get('checks',{}))==9 and before['checks']==after.get('checks')
        and all(v is True for v in before['checks'].values()) and reported is True)


def preserved_protocol_reference(actual,claim_ref,worker_ref):
    if claim_ref != worker_ref or set(worker_ref) != {'path','sha256'}:
        raise ValueError('Worker runtime protocol reference contract changed')
    if any(actual[k]!=worker_ref[k] for k in ('path','sha256')):
        raise ValueError('Preserved worker protocol hash/path changed')
    return dict(worker_ref)


def main():
    began=time.monotonic(); O.mkdir(exist_ok=False)
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),
        actual_argv=sys.argv,at_utc=datetime.now(timezone.utc).isoformat()))
    while not (O/'Launcher_ACK.json').exists():
        if time.monotonic()-began>60: raise TimeoutError('No reader owner ACK; no evidence work authorized')
        time.sleep(.1)
    ack=json.loads((O/'Launcher_ACK.json').read_text(encoding='utf-8'))
    if not (ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid()
            and ack['fresh_exact_source_PID_parent_command'] is True and Path(__file__).name in ack['actual_command']):
        raise ValueError('Wrong reader owner process/source/parent')
    p=json.loads((P/'Protocol.json').read_text(encoding='utf-8'))
    if p['reader_seconds']!=7200: raise ValueError('Changed fixed reader allowance')
    for path,expected in p['sources'].items():
        if sha(R/path)!=expected: raise ValueError('Frozen source changed: '+path)
    deadline=began+p['reader_seconds']
    end=json.loads((C/'End_ACK.json').read_text(encoding='utf-8'))
    if end['actual_owned_chain_ended'] is not True: raise ValueError('Primary owned chain has not ended')
    worker_result=json.loads((S/'Result.json').read_text(encoding='utf-8'))
    claim=json.loads((S/'owner.claim').read_text(encoding='utf-8'))
    runtime_ref=preserved_protocol_reference(ref(S/'Runtime_Protocol.json'),claim['protocol_ref'],worker_result['actual_protocol_ref'])
    runtime=json.loads((S/'Runtime_Protocol.json').read_text(encoding='utf-8'))
    if runtime['frozen_preparation_protocol']['sha256']!=sha(P/'Protocol.json'):
        raise ValueError('Runtime protocol is not derived from the frozen preparation')
    if runtime['absolute_deadline_monotonic']!=runtime['original_deadline_monotonic']:
        raise ValueError('Original primary deadline changed')
    output=None; failure=None
    try:
        before_ref, after_ref = ref(S/'Frozen_Before.json'), ref(S/'Frozen_After.json')
        for name, actual in (('frozen_before',before_ref),('frozen_after',after_ref)):
            if any(worker_result[name].get(k)!=actual[k] for k in ('path','sha256')):
                raise ValueError('Frozen-check reference changed: '+name)
        before=json.loads((S/'Frozen_Before.json').read_text(encoding='utf-8'))
        after=json.loads((S/'Frozen_After.json').read_text(encoding='utf-8'))
        frozen_pass=frozen_original_gate(before,after,worker_result['frozen_originals_preserved'])
        if worker_result['policy_result'] is None:
            output=dict(status='UNKNOWN_PRIMARY_DID_NOT_CLOSE_POLICY_ACCOUNTING',
                primary_result_ref=ref(S/'Result.json'),owner_end_ref=ref(C/'End_ACK.json'),
                complete_policy_claim_permitted=False,unverified_numerical_claims='Retain all primary files and global claims; no retry or guessed outcome',
                actual_new_optimizer_PF_model_calls=0,historical_calculation_journal_reads=0)
        else:
            from nonlinear13_acquisition_reader_20261030 import verify_acquisition
            expected=ref(S/'policy/Result.json')
            if worker_result['policy_result']!=expected:
                # Worker ref omits optional byte count; all identity fields must match.
                if any(worker_result['policy_result'].get(k)!=expected[k] for k in ('path','sha256')):
                    raise ValueError('Worker/policy result reference changed')
            refs=dict(protocol=runtime_ref,journal=ref(S/'policy/policy.jsonl'),result=expected,
                closed_manifest=ref(S/'policy/Closed_Manifest.json'),owner_ack=ref(S/'Bound_Owner_ACK.json'),
                owner_end=ref(C/'End_ACK.json'))
            output=verify_acquisition(R,refs,expected_protocol_ref=runtime_ref,
                absolute_deadline_monotonic=deadline,max_bytes=p['reader_byte_cap'])
        output.update(at_utc=datetime.now(timezone.utc).isoformat(),workflow_seconds=time.monotonic()-began,
            reader_source_sha256=sha(__file__),reader_original_deadline_monotonic=deadline,
            no_actual_optimizer_PF_model_calls=True, frozen_originals_preserved=frozen_pass,
            frozen_before_ref=before_ref,frozen_after_ref=after_ref,
            aggregate_full_policy_gate='UNKNOWN_ACQUISITION_IS_NOT_A_FULL_POLICY_STUDY')
        if not frozen_pass:
            output['saved_outcome_verification_status']=output['status']
            output['status']='UNKNOWN_FROZEN_ORIGINALS_GATE_NOT_PRESERVED'
            output['complete_policy_claim_permitted']=False
    except BaseException as exc:
        failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),
            reconstruction_costs='UNKNOWN_IF_EXCEPTION_PREVENTED_RETURN; not free, no automatic reader retry')
        put(O/'Failure.json',failure)
        output=dict(status='FAIL_OR_UNKNOWN_INDEPENDENT_ACQUISITION_EVIDENCE',failure_ref=ref(O/'Failure.json'),
            workflow_seconds=time.monotonic()-began,complete_policy_claim_permitted=False,
            actual_new_optimizer_PF_model_calls=0,historical_calculation_journal_reads=0)
    put(O/'Independent_Audit.json',output)
    files=[dict(path=f.relative_to(O).as_posix(),sha256=sha(f),bytes=f.stat().st_size) for f in O.iterdir() if f.is_file()]
    put(O/'Closed_Manifest.json',dict(files=files,no_automatic_retry=True))
    print(output['status'])
    if failure is not None: raise RuntimeError('Independent evidence validation failed; retained, no retry')


if __name__=='__main__': main()
