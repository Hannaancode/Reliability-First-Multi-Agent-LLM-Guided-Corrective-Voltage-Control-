
PHASE 2G ITER25 RESUME PACK

This pack contains:
- Phase 2G runner scripts
- Phase 2D dependency scripts
- corrected zone-agent LoRA adapter
- IEEE-118 federation grid and metadata
- federation scenario JSON files
- partial logs/results
- environment freeze

Important:
Use max_iterations=25 for the next clean run.
Do not use final_critic_model.
Do not use infinite iterations.
For final paper-grade results, rerun in clean chunks and merge chunk CSVs.
