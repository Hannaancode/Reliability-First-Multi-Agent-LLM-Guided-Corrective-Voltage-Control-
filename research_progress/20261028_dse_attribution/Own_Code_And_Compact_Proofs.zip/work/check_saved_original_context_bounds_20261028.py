"""Saved token length/order check; no tokenization, model or physics execution."""
from pathlib import Path
import json,re,hashlib
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];O=R/'outputs/original_saved_context_bounds_20261028'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def main():
 O.mkdir(exist_ok=False)
 (O/'Initial_Path_Inspection_Failure.json').write_text(json.dumps({'failure':'Read-only precursor used Result.parents[2] (local_controller) instead of parents[3] (actual host). Failed before opening any remote descriptor or producing a checked row.','new_model_PF_controller_calls':0,'completed_token_record_checks':0,'old_artifacts_unchanged':True},indent=2),encoding='utf-8')
 counts=[]
 for i in range(4):
  a=read(R/f'outputs/original118_raw_action_attribution_v2_20261028/case_{i:02d}_Attribution.json');f=R/a['summary']['result_path'];host=f.parents[3];hosts=[]
  if i in (1,3):hosts.append(R/f'outputs/reflection118_remaining_cases_v2_execution_20261023/case_{i:02d}')
  hosts.append(host);receipts=[]
  for h in hosts:
   m=read(h/'remote_closed_descriptor.json')['members']
   for n in sorted(n for n in m if re.fullmatch(r'response_\d{5}\.json',n)):
    fp=h/'staged/study'/n;assert hashlib.sha256(fp.read_bytes()).hexdigest()==m[n]['sha256'];receipts.append(read(fp))
  checks=a['response_checks'];assert len(receipts)==len(checks)
  for v,c in zip(receipts,checks):
   assert hashlib.sha256(v['raw_text'].encode()).hexdigest()==c['raw_sha256']
   assert len(v['input_token_ids'])+384<=4096
  counts.append({'case_id':a['summary']['case_id'],'controller_receipts':len(receipts),'max_actual_input_tokens':max(len(v['input_token_ids']) for v in receipts),'min_actual_input_tokens':min(len(v['input_token_ids']) for v in receipts),'all_response_order_hashes_match':True,'all_full_context_plus384_within4096':True})
 record={'status':'PASS_ALL459_PRESERVED_CONTROLLER_RECEIPTS_CONTEXT_BOUNDS','at_utc':datetime.now(timezone.utc).isoformat(),'cases':counts,'scope':'Actual saved token lengths and response order; no new tokenizer encoding or model call. Earlier pinned serving source rejects overlength and compares full token IDs at generation entry. This new check alone is not independent decoding of message content.','new_model_PF_calls':0,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (O/'Actual_Saved_Context_Bounds.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(counts))
if __name__=='__main__':main()
