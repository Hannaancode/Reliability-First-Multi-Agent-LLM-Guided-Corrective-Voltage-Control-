"""One fixed saved-data input-check microbenchmark, zero scientific calls."""
from datetime import datetime,timezone
from r118_dff_missing_continuation_core_20261023 import *
O=R/'outputs/exact_frame_byte_precheck_20261023'

def main():
    O.mkdir(exist_ok=False);began=time.monotonic();np,pp,v2,runner,reflection=setup()
    import pandas as pd
    from exact_frame_byte_precheck_20261023 import frames_equal as fast
    old=read(E/'Result.json');candidates=[name for name in old['call_records'] if read(E/name)['provenance']['kind']=='NEW_NATIVE_ATTEMPT']
    # Even fixed source positions; no selection by equality outcome or timing.
    picks=[candidates[int(i*(len(candidates)-1)/11)] for i in range(12)]
    put(O/'Protocol.json',dict(status='FROZEN_12_SAVED_PAID_INPUT_PAIRS_NO_NEW_PHYSICS',at_utc=datetime.now(timezone.utc).isoformat(),records=picks,
        original_source_sha256=sha(R/'work/reflection118_chronological_core_20261022.py'),new_source_sha256=sha(R/'work/exact_frame_byte_precheck_20261023.py'),
        fixed_gate='Same supported primitive frame serialization is a positive exact check; every unequal/unsupported encoding falls back to unchanged original check. Changed load/shunt/dtype/extra table/base MVA/frequency must all be rejected. No active worker source is changed.',
        microbenchmark='One timed invocation of each check per pair; Python/cache/I-O/source workflow timings are not deployment solver latency or statistical speed guarantees.',new_PF_model_conversion_derivative_optimizer_calls=0))
    original_seconds=0.;fast_seconds=0.;paths={};pairs=[]
    for name in picks:
        path=E/name;row=read(path);a=saved_net(path.parent,row['before']);b=saved_net(path.parent,row['after'])
        tick=time.perf_counter();frames_equal(a,b);oldsec=time.perf_counter()-tick
        tick=time.perf_counter();kind=fast(a,b);newsec=time.perf_counter()-tick
        original_seconds+=oldsec;fast_seconds+=newsec;paths[kind]=paths.get(kind,0)+1;pairs.append(dict(record=name,original_seconds=oldsec,new_seconds=newsec,path=kind))
    source=saved_net((E/picks[0]).parent,read(E/picks[0])['before']);negatives=[]
    variants=[]
    x=copy.deepcopy(source);x.load.at[x.load.index[0],'p_mw']+=1.;variants.append(('changed_load',x))
    x=copy.deepcopy(source);x.shunt.at[x.shunt.index[-1],'q_mvar']-=25.;variants.append(('changed_shunt',x))
    x=copy.deepcopy(source);x.shunt['step']=x.shunt.step.astype(float);variants.append(('changed_dtype',x))
    x=copy.deepcopy(source);x['new_input_frame']=pd.DataFrame({'x':[1.]});variants.append(('extra_input_table',x))
    x=copy.deepcopy(source);x.sn_mva=float(x.sn_mva)+1.;variants.append(('changed_baseMVA',x))
    x=copy.deepcopy(source);x.f_hz=float(x.f_hz)+1.;variants.append(('changed_frequency',x))
    for name,x in variants:
        try:fast(source,x)
        except (AssertionError,ValueError,KeyError):negatives.append(dict(name=name,rejected=True))
        else:raise AssertionError(name+' must not pass')
    put(O/'Results.json',dict(status='PASS_FIXED_SAVED_INPUT_FAST_PATH_AND_ALL6_MUTATION_REJECTIONS',pairs=pairs,paths=paths,original_check_seconds=original_seconds,new_check_seconds=fast_seconds,all_negatives=negatives,
        new_scientific_calls=0,active_worker_source_changed=False,not_a_controller_improvement_or_deployment_speed_claim=True,
        next='If worthwhile, integrate only in a separately frozen future owner after all current original actors end. Never live-edit or restart current science.',workflow_seconds=time.monotonic()-began))
    put(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))
    print(json.dumps(dict(status='PASS_SAVED_ONLY_PRECHECK',paths=paths,original_seconds=original_seconds,new_seconds=fast_seconds,new_scientific_calls=0)))

if __name__=='__main__':main()
