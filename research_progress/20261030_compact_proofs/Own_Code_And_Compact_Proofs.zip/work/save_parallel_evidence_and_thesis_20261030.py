"""Save verified parallel findings and current thesis; no scientific mutation."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,subprocess
R=Path(__file__).resolve().parents[1];O=R/'outputs/parallel_evidence_checkpoint_20261030'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def put(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
 O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
 master=R/'outputs/research_resumption_20261028/Current_Resume.json';shutil.copy2(master,O/'Previous_Current_Resume.json');r=read(master)
 ps="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\\.exe$' -and $_.CommandLine -match '(run|audit|coordinate)_nonlinear500_receding_acquisition_v3_20261030|coordinate_acquisition_source_bound_owner_20261030' } | Select-Object ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4"
 raw=subprocess.run(['pwsh','-NoProfile','-Command',ps],capture_output=True,text=True,check=True).stdout.strip();procs=json.loads(raw) if raw else [];procs=procs if isinstance(procs,list) else [procs]
 primary=read(R/'outputs/nonlinear500_receding_acquisition_v3_execution_20261030/owner.claim')
 live=any(p['ProcessId']==primary['actual_pid'] and p['ParentProcessId']==primary['parent_pid'] and 'run_nonlinear500_receding_acquisition_v3_20261030.py' in p['CommandLine'] for p in procs)
 doc=read(R/'outputs/thesis_component_attribution_update_20261030/Source_Change_Record.json')['updated_docx']
 assert hashlib.sha256((R/doc['path']).read_bytes()).hexdigest()==doc['sha256']
 independent='outputs/parallel_lineage_component_independent_20261030/Compact_Review.json'
 state=dict(at_utc=now,status='VERIFIED_PARALLEL_EVIDENCE_AND_CURRENT_THESIS_SAVED_NUMERICAL_OWNER_LIVE' if live else 'VERIFIED_PARALLEL_EVIDENCE_SAVED_OWNER_PHASE_CHANGE',
  goal='ACTIVE',primary_live=live,actual_processes=procs,actual_primary=primary,
  active_scientific_resume='outputs/nonlinear500_v3_live_checkpoint_20261030/Exact_Resume.json',exec_session_id=65202,
  current_thesis={**doc,'title':'Evaluating Language Model Assistance for Power System Knowledge and Voltage Control',
   'contents':'Recovered source grouping, all500 historical THEORY QA lineage and all4-root component execution ledger.',
   'references':71,'tables':24,'inline_figures':22,'PAGEREF_fields':58,'sections':3,
   'independent_content_review':'outputs/thesis_component_parent_review_20261030/Review.json',
   'visual_layout_review':'NOT_PERFORMED_NO_PDF_OR_SCREEN_BY_USER_DIRECTION','supervisor_title_approval':'PENDING'},
  verified_parallel_findings={
   'RAG500':{'questions':500,'distinct_printed_questions':500,'all500_have_exact_THEORY_question_reference_match':True,
    'THEORY_question_occurrences':575,'THEORY_exact_QA_occurrences':511,'unique_exact_QA_identity_cases':489,
    'duplicate_exact_QA_identity_cases':11,'questions_with_alternative_corpus_answers':46,'NERC_cross_corpus_exact_QA_cases':4,
    'runtime_index_training_split_and_99percent_accuracy':'UNKNOWN',
    'evidence':'outputs/rag500_source_membership_recovery_20261030/Content_Identity_Clarification.json'},
   'T05':{'cases':4,'commits':102,'HGVF':{'direct':[51,132,4],'guided':[13,38,1],'fallback':[9,30,3],'total':[73,200,8]},
    'DFF_alternative':[29,175,8],'tuple_schema':['commits','net_recorded_UV_reduction','net_strict_OV_change'],
    'each_branch_initial_OV':3,'each_branch_final_OV':11,'causal_benefit':'NOT_ESTABLISHED',
    'per_component_costs':'UNKNOWN','full_branch_and_interrupted_cost_refs_retained':True,
    'evidence':'outputs/original118_component_ledger_20261030/Results.json'},
   'independent_review':independent,
   'G4':'outputs/G4_next_comparison_gap_review_20261030/Gap_And_Admission_Note.json',
   'future_frontier_design':'outputs/native13_first_missing_frontier_design_20261030/Prospective_Design.json'},
  actual_new_numerical_result='LIVE_ACQUISITION_NOT_INDEPENDENTLY_CLOSED; no new full500 performance or LLM claim.',
  GPU_assignments=[],waiting_timer=None,thesis_requirements_complete=27,thesis_requirements_total=35,all_six_final_goals='OPEN',
  next_ordered_actions=r['next_ordered_actions'])
 put(O/'Exact_Resume.json',state);r.update(state);r['latest_exact_execution_state']=(O/'Exact_Resume.json').relative_to(R).as_posix();r['new_work_publication']='Compact publication being finalized; raw data/weights/full DOCX stay local.';put(master,r)
 p=R/'outputs/thesis_research_closure_20261028/Tasks.json';shutil.copy2(p,O/'Previous_Thesis_Tasks.json');t=read(p)
 evidence={
  'T05':['outputs/original118_component_ledger_20261030/Results.json',independent,'outputs/thesis_component_attribution_update_20261030/Source_Change_Record.json','outputs/thesis_component_parent_review_20261030/Review.json'],
  'T11':['outputs/rag500_source_membership_recovery_20261030/Aggregate_Findings.json',independent,'outputs/thesis_rag500_lineage_update_20261030/Source_Change_Record.json'],
  'T13':['outputs/rag500_source_membership_recovery_20261030/Content_Identity_Clarification.json',independent,'outputs/thesis_rag500_lineage_update_20261030/Source_Change_Record.json']}
 for row in t['tasks']:
  if row['id'] in evidence:
   for ref in evidence[row['id']]:
    assert (R/ref).is_file()
    if ref not in row['evidence']:row['evidence'].append(ref)
   row['latest_integrated_thesis']=doc['path'];row['completed']=False
   row['latest_verified_extension_20261030']=state['verified_parallel_findings']['T05' if row['id']=='T05' else 'RAG500']
 t['updated_at_utc']=now;assert sum(bool(x.get('completed')) for x in t['tasks'])==27;put(p,t)
 p=R/'outputs/research_tasks_20261014/Tasks.json';m=read(p);m.update(updated_at_utc=now,latest_exact_execution_state=r['latest_exact_execution_state'],current_GPU_assignments=[],thesis_documentation_requirements_complete=27)
 for row in m['tasks']:
  if row.get('checklist_id')=='G4':
   if row.get('current_active_study') is not None:row['historical_active_study_field_before_20261030']=row['current_active_study']
   row['current_active_study']=None;row['latest_admission_review']=state['verified_parallel_findings']['G4'];row['next']='No execution-ready new scale contract. Preserve stopped3B/7B/encoder/matched-scale evidence; separately fix new causal role and controls before any allocation.'
 put(p,m)
 text=('Verified parallel evidence and current thesis — '+now+'\nExact resume: '+r['latest_exact_execution_state']+'. Current DOCX: '+doc['path']+'. All500 historical RAG question/reference pairs match THEORY content (575question occurrences,511exactQA occurrences;4NERC overlaps); actual index/split/99percent accuracy stayUNKNOWN. All4-root/102commit source ledger independentlyPASS: HG-VF direct51commits/132netUV reduction/+4netOV; guided13/38/+1; fallback9/30/+3; total73/200/+8. SeparateDFF29/175/+8. Both branchesOV3to11; execution attribution is not causal marginal LLM gain. Full costs/adverse/unknown records retained. New thesis contains71references,24tables,22figures,58PAGEREF; no PDF/render. G4 review confirms3B/7B/encoder were already attempted and no new higher-scale contract is ready. Actual CPU acquisition ownership state: '+str(live)+', full outcomes await first independent reader.27/35items complete; all6finalgoalsOPEN.\n')
 with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+text)
 for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
  p=R/rel;p.write_text('## '+text.splitlines()[0]+'\n\n'+text.splitlines()[1]+'\n\n'+p.read_text(encoding='utf-8'),encoding='utf-8')
 print(json.dumps({'primary_live':live,'current_thesis':doc['path'],'checklist_complete':27,'new_full500_score':False}))
if __name__=='__main__':main()
