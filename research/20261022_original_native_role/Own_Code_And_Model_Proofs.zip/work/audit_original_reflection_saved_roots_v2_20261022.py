"""Sole zero-model reader of original native-role inference and costs."""
import ast
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'
E = R / 'outputs/original_reflection_saved_root_execution_v2_20261022'
O = R / 'outputs/original_reflection_saved_root_independent_v2_20261022'


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    O.mkdir(exist_ok=False)
    with (O / 'owner.claim').open('x', encoding='utf-8') as f:
        json.dump({'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(Path(__file__))}, f)
    p = read(P / 'Frozen_Engineering_Protocol.json')
    lock = read(P / 'Independent_Reader_Lock.json')
    assert lock['sha256'] == sha(Path(__file__))
    status = read(E / 'status.json')
    assert status['runtime_released'] and status['scientific_process_ended']
    assert status['remote_exit_code'] == 0 and status['all_actual_closed_artifacts_preserved']
    ack = read(R / 'outputs/original_reflection_saved_root_coordination_v2_20261022/End_ACK.json')
    assert ack['exit_code'] == 0 and ack['actual_owned_chain_ended']
    for name, h in read(P / 'Launch_Readiness_Audit.json')['source_hashes'].items():
        assert sha(R / name) == h, name
    closed = read(E / 'remote_closed_descriptor.json')
    assert closed['scientific_process_ended'] and closed['exit_code'] == 0 and not closed['hard_bound_enforced']
    S = E / 'staged/study'
    for name, record in closed['members'].items():
        f = S / name
        assert f.stat().st_size == record['bytes'] and sha(f) == record['sha256']
    worker_claim = read(S / 'owner.claim')
    assert worker_claim['source_sha256'] == sha(R / 'work/run_original_reflection_saved_roots_remote_v2_20261022.py')
    assert worker_claim['protocol_sha256'] == sha(P / 'Frozen_Engineering_Protocol.json')
    result = read(S / 'Results.json')
    assert result['status'] == 'COMPLETE_ORIGINAL_FEDERATION_FIRST_ZONE_TWO_ROOT_LORA_BASE_AND_COLD'
    import candidate_process_runtime
    import sys
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    from transformers import AutoTokenizer
    from original_reflection_serving_pure_20261022 import original_query, initial_messages
    tok = AutoTokenizer.from_pretrained(str(R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'), local_files_only=True, trust_remote_code=False)
    inputs = read(P / 'All2_Original_FIRST_ZONE_Inputs.json')
    assert len(inputs) == 2 and [x['root'] for x in inputs] == ['L1', 'L2']
    queries = []
    actual_gens = []
    for replica in ['primary', 'cold']:
        assert read(S / f'{replica}_Immutable_Values_Before.json') == read(S / f'{replica}_Immutable_Values_After.json')
        proof = read(S / f'{replica}_Memory_And_Source_Proof.json')
        assert proof['all_base_private_quantized_values_and_buffers_unchanged'] and proof['optimizer_and_trainable_parameters'] == 0
        assert proof['peak_allocated_bytes'] <= 12 * 1024 ** 3
        for arm in p['arms']:
            flags = read(S / f'{replica}_{arm}_Actual_Adapter_Enable_State.json')
            assert flags and all(v == (arm == 'base_disabled') for v in flags.values())
            for item in inputs:
                q = read(S / f'{replica}_{arm}_{item["root"]}_Query_Result.json')
                records = [read(S / f'{replica}_{arm}_{item["root"]}_Call_{i}.json') for i in range(1, q['actual_generation_calls'] + 1)]
                assert 1 <= len(records) <= 2
                consumed = []
                def supplied(model, tokenizer, messages):
                    rec = records[len(consumed)]
                    assert rec['messages'] == messages
                    encoded = tok.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
                    ids = encoded['input_ids'] if hasattr(encoded, 'keys') else encoded
                    assert ids == rec['input_token_ids'] and len(ids) + 384 <= 4096
                    if not consumed:
                        assert messages == initial_messages(item) == item['messages'] and ids == item['token_ids']
                    assert tok.decode(rec['output_token_ids'], skip_special_tokens=True).strip() == rec['raw_text']
                    assert len(rec['output_token_ids']) == rec['actual_forward_returns']
                    assert 0 < len(rec['output_token_ids']) <= 384
                    consumed.append(rec)
                    return rec['raw_text']
                action, info = original_query(item, supplied)
                assert len(consumed) == len(records)
                assert action == q['original_action'] and info == q['original_info']
                assert q['all_generation_token_ids'] == [x['output_token_ids'] for x in records]
                queries.append(q); actual_gens.extend(records)
    for arm in p['arms']:
        for item in inputs:
            primary = next(q for q in queries if (q['replica'], q['arm'], q['root']) == ('primary', arm, item['root']))
            cold = next(q for q in queries if (q['replica'], q['arm'], q['root']) == ('cold', arm, item['root']))
            assert primary['all_generation_token_ids'] == cold['all_generation_token_ids']
            assert primary['original_action'] == cold['original_action'] and primary['original_info'] == cold['original_info']
    chain = '0' * 64
    event_rows = []
    for line in (S / 'events.jsonl').read_bytes().splitlines():
        e = json.loads(line); row = e['event']
        assert row['previous'] == chain
        chain = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        assert chain == e['sha256']; event_rows.append(row)
    c = result['actual_costs']
    for kind, key in [('model_load_attempt', 'model_load_attempts'), ('model_load_return', 'model_load_returns'),
                      ('generation_attempt', 'generation_attempts'), ('generation_return', 'generation_returns'),
                      ('pretrained_forward_attempt', 'pretrained_forward_attempts'), ('pretrained_forward_return', 'pretrained_forward_returns')]:
        assert sum(e['kind'] == kind for e in event_rows) == c[key]
    assert c['generation_attempts'] == c['generation_returns'] == len(actual_gens)
    assert c['query_attempts'] == c['query_returns'] == len(queries) == 8
    assert c['model_load_attempts'] == c['model_load_returns'] == 2
    assert c['generated_token_count'] == sum(len(x['output_token_ids']) for x in actual_gens) == c['pretrained_forward_returns']
    assert c['PF_optimizer_backward_training_calls'] == 0
    table = []
    for q in queries:
        if q['replica'] != 'primary': continue
        table.append({'root': q['root'], 'arm': q['arm'], 'original_source_valid': q['original_info']['valid_action'],
                      'original_source_action': q['original_action'], 'reprompted': q['original_info']['reprompted'],
                      'actual_generation_calls': q['actual_generation_calls'],
                      'physically_verified': False, 'UV_after': 'UNKNOWN_NO_NEW_PHYSICAL_ACTION'})
    passed = all(r['original_source_valid'] for r in table if r['arm'] == 'lora')
    report = {'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS_INDEPENDENT_ORIGINAL_NATIVE_ROLE_MODEL_AND_COLD_SOURCE_COST_AUDIT',
        'fixed_interface_gate': 'PASS_LIMITED_NATIVE_ROLE_READINESS' if passed else 'FAIL_STOP_THIS_FIXED_INTERFACE_INTERVENTION',
        'root_scope': 'First2 actually entered fixed8development roots; original FIRST_ZONE only, not a performance sample or full203 closure',
        'original_query_AST_conditional_reprompt_and_parser_preserved': True,
        'primary_lora_and_disabled_base_table': table, 'actual_costs': c,
        'all_fresh_load_query_paths_token_sequences_exact': True,
        'new_reader_PF_model_optimizer_or_training_calls': 0,
        'no_physical_UV_or_LLM_superiority_claim': True,
        'historical_base_runtime_not_exactly_recovered': True,
        'reader_source_sha256': sha(Path(__file__)), 'protocol_sha256': sha(P / 'Frozen_Engineering_Protocol.json')}
    with (O / 'Independent_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(report, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())
    manifest = {'complete': True, 'members': {x.name: {'bytes': x.stat().st_size, 'sha256': sha(x)} for x in O.iterdir() if x.is_file()}}
    with (O / 'Closed_Manifest.json').open('x', encoding='utf-8') as f: json.dump(manifest, f, indent=2)
    print(json.dumps({'status': report['status'], 'gate': report['fixed_interface_gate'], 'table': table, 'costs': c}))


if __name__ == '__main__':
    main()
