# A faithful larger-model comparison and the remaining research gates

10 October 2026. The trained original0.5B adapter is preserved and has recorded strong command-format results. No equivalent trained1.5B upgrade has been executed. The stopped public1.5B screen is a different unadapted-model/contract experiment, not the answer to the matched scale question. This document reconciles that question with the paper and defines the next necessary checks; it does not claim novelty or authorize automatic training from readiness.

## Original training and serving are related but not identical tasks

The actual16,000 TRAIN inputs contain scenario_id, scenario_type, severity, zone and local_measurements. Measurements include per-bus voltages, loads, generator/DER/storage status, boundary voltages and tie-line flows. Labels use the original zone diagnosis/action/verification schema. These data have109 original training scenario groups, not16,000 independent operating worlds.

The final guided deployment source instead supplies local voltage summaries, global undervoltage bus values, candidate buses and past failed actions. It requires a proposal when global undervoltage remains, even when a local zone is normal. All1,548 locally normal TRAIN examples have null proposed_action. Among the239 current OPT observations,249 of956 zone contexts are locally normal while global undervoltage remains. These are correlated saved-state contexts, not249 independent scenarios or actual new LLM outcomes. The source difference and counts suggest a target/information alignment question. They do not establish a causal explanation, prove inability to generalize or justify retraining by themselves.

The TRAIN corpus is not predominantly null-action:12,118/16,000 targets have a proposed action;2,334 say NO_AUTOMATIC_ACTION and1,548 say NO_ACTION_NEEDED. The100-case offline evaluation's high null-action contribution must not be confused with this full training distribution. The balanced400-case evaluation is also retained, including64.25% effective exact-action matching.

Saved training arguments were read as pickle opcode literals without executing the pickle. They record batch4 with accumulation4, two epochs, learning rate0.0002, cosine scheduling,50 warmup steps,8-bit AdamW, weight decay0.01, clipping1, FP16 and seed42. Together with the saved2,000-step trainer states, they make the earlier work substantially more concrete. Maximum training sequence length, preprocessing/loss masking and original base snapshot identity are not recovered by those arguments. Neither weights nor optimizer settings reconstruct a missing original training script.

## Next cheap prerequisites

1. Use the preserved original tokenizer and already pinned local public1.5B tokenizer to count the COMPLETE original TRAIN chat sequences and compare canonical tokenization. Do not load model weights, export private data, crop labels or alter the template until it fits. Check the common4096-token serving context as a declared compatibility condition; it does not recover the unknown original training limit. Preserve failures and all rows. Validation/test outcome metrics stay untouched.
2. Bind the prospective serving contract to the actual original Phase2G prompt, action normalizer, JSON extraction and verifier/refiner interfaces. Distinguish the original full training schema from the compact deployment proposal. Markdown fence recovery already exists and is an engineering interface property, not a new LLM contribution.
3. Specify which question the comparison answers. Reusing the old local corpus can test a larger trained proposer under the original serving system, but does not repair or isolate the global/local task difference. A new global-conditioned target is a different method and requires supported labels, strong equally informed numerical controls and a separate prospective protocol. Do not simply change targets/prompts after a failed result.
4. Treat recovered original settings as evidence, not proof of an exactly replicated trainer. If preprocessing cannot be recovered, disclose that implementation difference and do not attribute the result solely to parameter count. Preserve the original0.5B baseline; do not retrain it or select another old checkpoint to obtain a favorable comparison.

The next concrete work is therefore tokenizer/context and source-contract readiness, followed by the justified scientific-method decision. No GPU allocation is warranted by this document alone.

## Conditions before a genuine model pilot

A new1.5B adapter must match its own architecture. The original0.5B matrices cannot be transplanted. Retain one prospective dataset/role/objective/seed/budget/final checkpoint; account for different trainable capacity, frozen backbone FLOPs, precision and framework. Validate actual gradients, memory, old-asset preservation, full optimizer/RNG/cursor checkpoints and incremental hashed preservation before the learning study. Previous1.5B inference memory/timing is not a training estimate.

Require a strong trained numerical proposer/acquisition control with the same causal information, supervision, world groups and decision budget. Retain stronger full-table/graph/physical controls. A language-pretraining interpretation additionally requires an architecture/pretraining control. The current source-audited task difference is not permission to omit these comparisons.

Command validity is a prerequisite, not the primary superiority result. Compare complete fresh protected recovery trajectories and full costs against literal DFF, DFF-ALT and their unchanged D-SE selector, paying for BOTH portfolio branches. Preserve the original verifier and report the common normal-band/protection assessment; any added guarded search is an additional control, not a renamed original comparator. Lower UV alone, template fidelity, a smaller verification budget, cached labels or a common guard do not establish an LLM advantage.

All inspected original training/validation/test, current OPT/held and locked-bank evidence is development. Genuinely unused authorized confirmation remains necessary. No99%winning guarantee or blanket100%failure test follows from model scale or this review.

## Current numerical screen status

The separate saved-feedback CPU replay is terminal partial within its fixed resource bound:423 complete policy/state cases, one partial and532 unexecuted, with all956 declared cases retained. Its external audit verified3,386 query traces and original scores with no unsafe/unqueried commitments. Both feedback support gates remain UNKNOWN after applying the unchanged thresholds to missing-evidence intervals. Original passed=false means a pass was not certified; it is not a measured failure on the incomplete campaign. No replay, budget extension, new physical solve or model launch follows.

Evidence is in original_desktop_pipeline_alignment, original_training_and_deployed_role_audit, paid_feedback_acquisition_audit and paid_feedback_partial_gate_interpretation. Those artifacts keep the paper's original work, subsequent experiments and still-unachieved full research goal distinct.
