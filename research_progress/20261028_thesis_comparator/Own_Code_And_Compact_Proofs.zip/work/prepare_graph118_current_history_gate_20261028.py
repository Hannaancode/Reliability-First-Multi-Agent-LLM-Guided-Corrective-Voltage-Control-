"""Prospective all-four next-source-query admission against newly closed history.

No physics, model, derivative or performance results. Old complete gate checks are
reused; this check covers the newly enlarged retained history and exact next input.
"""
import argparse, copy, gzip, hashlib, json, os, pickle, sys, time, traceback
from pathlib import Path
R=Path(__file__).resolve().parents[1]
from reflection118_chronological_core_20261022 import read,put,sha,capsule,decode,canonical,frames_equal
O=R/'outputs/graph118_current_history_admission_20261028'
P=R/'outputs/graph118_current_history_preparation_20261028'
REG=R/'outputs/closed_missing_suffix_registry_20261028/build/Closed_Physical_Receipt_Registry.json'
AUD=R/'outputs/closed_missing_suffix_registry_20261028/audit/Result.json'

def controls(net):
    return {t:[[int(i),int(x.bus),float(x.vm_pu)] for i,x in net[t].iterrows()
               if bool(x.in_service) and bool(net.bus.at[int(x.bus),'in_service'])] for t in ['gen','ext_grid']}

def independent_controls(net):
    result={}
    for table in ('gen','ext_grid'):
        result[table]=[]
        data=net[table]
        for i in data.index:
            b=int(data.loc[i,'bus'])
            if data.loc[i,'in_service'] and net.bus.loc[b,'in_service']:
                result[table].append([int(i),b,float(data.loc[i,'vm_pu'])])
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['build','audit'],required=True);mode=ap.parse_args().mode
    p=read(P/'Protocol.json');assert sha(__file__)==p['source_sha256']
    out=O/mode;out.mkdir(parents=True,exist_ok=False);began=time.monotonic()
    put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),mode=mode))
    try:
        while not (out/'Launcher_ACK.json').exists():assert time.monotonic()-began<120;time.sleep(.1)
        ack=read(out/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['fresh_exact_source_PID_parent_command']
        for path,h in p['source_and_small_record_hashes'].items():assert sha(R/path)==h,path
        import candidate_process_runtime
        sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
        import pandapower as pp
        def forbidden(*a,**k):raise RuntimeError('HISTORY_ADMISSION_FORBIDS_NEW_PHYSICS')
        pp.runpp=forbidden
        from prior_physical_query_footprints_20261018 import component,decode as prior_decode
        from run_reflection118_chronological_local_20261022 import necessary
        from r118_dff_missing_continuation_core_20261023 import saved_net
        from resolve_original_role_input_component_collisions_20261022 import load_component
        from published_graph118_episode_engine_v2_20261026 import NativeGraphEpisode
        reg=read(REG);audit=read(AUD);assert audit['index_sha256']==sha(REG) and len(reg['rows'])==14479
        old=R/'outputs/published_graph118_paid_transition_20261022'
        cursors=read(old/'Saved_Transition_And_Cursor_Readiness.json')['rows']
        tracked=R/'outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz'
        indexed=json.loads(gzip.decompress(tracked.read_bytes()))
        extra=read(R/'outputs/reflection118_chronological_preparation_20261022/Additional_Prior_Attempt_References.json')
        snapshots=read(R/'outputs/original_role_remaining_native_history_scope_20261022/All_Saved_Snapshot_Components.json')
        grouped={}
        for row in reg['rows']:grouped.setdefault(row['resource_key'],[]).append(row)
        rows=[]
        for i,meta in enumerate(cursors):
            assert time.monotonic()-began<p['stage_seconds']
            folder=out/f'case_{i:02d}';folder.mkdir()
            if mode=='build':
                episode=NativeGraphEpisode.restore(folder,decode(old,meta['cursor']))
                intent=episode.next_intent()
                assert intent['action']==meta['hypothetical_next_action_id'] and intent['decoded']==meta['hypothetical_next_action']
                target=capsule(out/f'target_{i:02d}.zlib',intent)
            else:
                built=read(O/'build/Result.json')['rows'][i];target=built['target'];intent=decode(O/'build',target)
                assert intent['action']==meta['hypothetical_next_action_id'] and intent['decoded']==meta['hypothetical_next_action']
            net=intent['before'];needed=necessary(net);shunt,_=component(net)
            key=shunt+':'+hashlib.sha256(canonical(needed)).hexdigest()
            control_fn=controls if mode=='build' else independent_controls
            target_controls=control_fn(net);exclusions=[];unresolved=[]
            for ref in grouped.get(key,[]):
                before=saved_net(R/ref['directory'],ref['before'])
                if control_fn(before)!=target_controls:reason='DIFFERENT_REQUESTED_ACTIVE_REGULATOR_CONSTRAINTS'
                else:reason='SAME_COARSE_INPUT_REQUIRES_EXACT_REUSE_OR_FURTHER_PROOF';unresolved.append(ref['source'])
                exclusions.append(dict(scope='new_closed_registry',source=ref['source'],source_sha256=ref['source_sha256'],decision=reason))
            for ref in indexed.get(shunt,[]):
                before=prior_decode((R/ref['journal']).parent,ref['before'])
                if necessary(before)!=needed:reason='DIFFERENT_ACTIVE_LOAD_OR_LINE_BUS_SERVICE'
                elif control_fn(before)!=target_controls:reason='DIFFERENT_REQUESTED_ACTIVE_REGULATOR_CONSTRAINTS'
                else:reason='TRACKED_COARSE_INPUT_UNRESOLVED';unresolved.append(ref)
                exclusions.append(dict(scope='historical_component_index',reference=ref,decision=reason))
            additional=[x for x in extra.get(shunt,[]) if x['necessary_input']==needed]
            loadkey=hashlib.sha256(canonical(load_component(net.bus,net.load))).hexdigest()
            sn=[x for x in snapshots if x.get('shunt_key')==shunt and x.get('nominal_load_key')==loadkey]
            unresolved.extend(additional);unresolved.extend(sn)
            row=dict(case_id=meta['case_id'],target=target,source_action=intent['action'],decoded=intent['decoded'],
                     original_prefix_action_count=1,source_native_cap=136,closed_registry_rows=14479,
                     relevant_closed_rows=len(grouped.get(key,[])),historical_component_references=len(indexed.get(shunt,[])),
                     witness_records=exclusions,additional_unresolved=len(additional),snapshot_unresolved=len(sn),
                     unresolved=unresolved,status='PASS_SCOPED_NEXT_INPUT_UNENTERED' if not unresolved else 'UNKNOWN_NO_NEW_CALL')
            if mode=='audit':assert row==built,'Independent field-by-field history decision differs'
            rows.append(row)
        result=dict(status=('PASS_ALL4_SCOPED_NEW_QUERY_HISTORY' if all(not x['unresolved'] for x in rows) else 'UNKNOWN_AT_LEAST_ONE_INPUT_COLLISION'),
                    rows=rows,new_PF_model_converter_calls=0,no_performance_or_launch_permission=True,
                    remaining='Full episode scientist and independent reader source lock, persistent costs/preservation/ownership and runtime integration are still required.',
                    scope='Named retained history only, not universal absence of all historical inputs. Distinct regulator requests are distinct input identities even if Qlimits later bind.')
        if mode=='audit':
            result['status']='PASS_INDEPENDENT_ALL4_HISTORY_DECISION_CHECK';result['builder_result_sha256']=sha(O/'build/Result.json')
        result['workflow_seconds']=time.monotonic()-began;put(out/'Result.json',result)
        put(out/'Closed_Manifest.json',dict(members={f.relative_to(out).as_posix():sha(f) for f in out.rglob('*') if f.is_file()}))
        print(json.dumps(dict(status=result['status'],case_statuses=[x['status'] for x in rows],new_science=0)))
    except BaseException as e:
        put(out/'Failure.json',dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc(),new_science_permitted=0));raise
if __name__=='__main__':main()
