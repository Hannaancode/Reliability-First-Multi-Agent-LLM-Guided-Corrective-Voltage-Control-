"""Durable opaque-byte component; not a scientific executor or resume permit.

No pickle is loaded here. A future actual controller must separately validate
its complete decoded state, scientific cursor, source/runtime and permissions.
All returned bytes must be handed to preserve(), including failed-call state.
Admission cannot by itself certify the entry time of a later solver callback.
"""
import copy
import ctypes
import json
import os
import re
import stat
import sys
import time
import zlib
from datetime import datetime, timezone
from pathlib import Path

from lossless_evidence_byte_codec_v1 import canonical, decode, digest, encode


class EvidenceStop(BaseException):
    """Operational stop must not be silently converted to a physical rejection."""


def local_root(path):
    root = Path(path).resolve()
    if os.name == 'nt' and not str(root).startswith('\\\\?\\'):
        root = Path('\\\\?\\' + str(root))
    return root


def verify_source_pins(protocol):
    pins = protocol.get('source_sha256')
    required = {'work/durable_opaque_evidence_store_v1.py', 'work/lossless_evidence_byte_codec_v1.py'}
    if not isinstance(pins, dict) or not required.issubset(pins):
        raise EvidenceStop('Explicit byte-store/codec source pins required')
    workspace = Path(__file__).resolve().parents[1]
    for name, expected in pins.items():
        path = (workspace / name).resolve()
        if not path.is_relative_to(workspace) or digest(path.read_bytes()) != expected:
            raise EvidenceStop('Source binding changed or escaped')


def process_alive(pid):
    if type(pid) is not int or pid <= 0:
        raise EvidenceStop('Invalid issuing PID')
    if os.name == 'nt':
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
        handle = kernel.OpenProcess(0x100000 | 0x1000, False, pid)
        if not handle:
            if ctypes.get_last_error() == 87:
                return False
            raise EvidenceStop('Issuing process state UNKNOWN')
        try:
            state = kernel.WaitForSingleObject(handle, 0)
        finally:
            kernel.CloseHandle(handle)
        if state not in (0, 258):
            raise EvidenceStop('Issuing process state UNKNOWN')
        return state == 258
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError as exc:
        raise EvidenceStop('Issuing process state UNKNOWN') from exc
    return True


def inventory(root, *, hashes=False):
    """Full extended-path inventory: unknown subtrees/links fail closed."""
    root = local_root(root); pending = [root]; files = {}
    while pending:
        with os.scandir(pending.pop()) as entries:
            for entry in entries:
                info = entry.stat(follow_symlinks=False)
                if entry.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
                    raise EvidenceStop('Link/reparse evidence coverage UNKNOWN')
                p = Path(entry.path)
                if stat.S_ISDIR(info.st_mode):
                    pending.append(p)
                elif stat.S_ISREG(info.st_mode):
                    item = {'bytes': info.st_size}
                    if hashes:
                        data = p.read_bytes()
                        if len(data) != info.st_size:
                            raise EvidenceStop('File changed during complete inventory')
                        item['sha256'] = digest(data)
                    files[p.relative_to(root).as_posix()] = item
                else:
                    raise EvidenceStop('Special evidence file coverage UNKNOWN')
    return files


class OpaqueStore:
    def __init__(self, root, protocol):
        self.root = local_root(root)
        self.protocol = json.loads(canonical(protocol)); self.protocol_sha256 = digest(canonical(protocol))
        verify_source_pins(self.protocol)
        self.deadline = datetime.fromisoformat(protocol['absolute_deadline_utc'])
        if self.deadline.tzinfo is None:
            raise ValueError('Absolute timezone-bound deadline required')
        for name in ('complete_tree_byte_bound', 'max_raw_bytes', 'max_encoded_bytes'):
            if type(protocol[name]) is not int or protocol[name] <= 0:
                raise ValueError('Prospectively fixed positive resource bounds required')
        self.root.mkdir(parents=True, exist_ok=False)
        self.pid = os.getpid(); self.closed = False; self.stopped = False
        self.sequence = 0; self.tail = self.protocol_sha256; self.receipts = {}; self.failures = []
        self.costs = {'file_write_attempts': 0, 'file_write_returns': 0, 'bytes_written': 0,
                      'write_seconds': 0., 'encode_seconds': 0., 'inventory_seconds': 0.,
                      'inventories': 0, 'preservation_attempts': 0, 'preservation_returns': 0,
                      'admission_checks': 0, 'raw_fallbacks': 0}
        self.started = time.perf_counter()
        self._write('Protocol.json', canonical(self.protocol))
        self._write('owner.claim', canonical({'actual_pid': self.pid, 'parent_pid': os.getppid(),
            'protocol_sha256': self.protocol_sha256, 'python_version': sys.version,
            'zlib_runtime': zlib.ZLIB_RUNTIME_VERSION, 'scientific_resume_permission': False}))
        self._write('receipts.jsonl', b'')

    def _owner(self):
        if self.closed or os.getpid() != self.pid:
            raise EvidenceStop('Closed or different issuing owner')

    def _write(self, name, data, *, append=False):
        begun = time.perf_counter(); self.costs['file_write_attempts'] += 1
        try:
            with (self.root / name).open('ab' if append else 'xb') as f:
                f.write(data); f.flush(); os.fsync(f.fileno())
            self.costs['file_write_returns'] += 1; self.costs['bytes_written'] += len(data)
        finally:
            self.costs['write_seconds'] += time.perf_counter() - begun

    def _emit(self, event, payload):
        row = {'sequence': self.sequence, 'previous_sha256': self.tail,
               'at_utc': datetime.now(timezone.utc).isoformat(), 'event': event, 'payload': payload}
        anchor = digest(canonical(row))
        self._write('receipts.jsonl', canonical({'row': row, 'sha256': anchor}) + b'\n', append=True)
        self.sequence += 1; self.tail = anchor

    def _inventory(self, hashes=False):
        begun = time.perf_counter()
        try:
            return inventory(self.root, hashes=hashes)
        finally:
            self.costs['inventories'] += 1
            self.costs['inventory_seconds'] += time.perf_counter() - begun

    def admit_after_io(self):
        """Caller must still check actual backend entry in its pinned integration."""
        self._owner(); self.costs['admission_checks'] += 1
        if self.stopped:
            raise EvidenceStop('Terminal store; no new science admission')
        try:
            files = self._inventory()
            total = sum(x['bytes'] for x in files.values())
            if total >= self.protocol['complete_tree_byte_bound']:
                raise EvidenceStop('Complete evidence byte bound reached')
            self._emit('admission_intent', {'logical_file_bytes_before_journal': total})
            # Recount actual tree after journal I/O; neither I/O latency nor
            # newly written journal bytes are silently excluded from admission.
            total = sum(x['bytes'] for x in self._inventory().values())
            if total >= self.protocol['complete_tree_byte_bound'] or datetime.now(timezone.utc) >= self.deadline:
                raise EvidenceStop('Post-I/O byte/deadline admission refused; no callback invoked')
            return {'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'logical_file_bytes': total,
                    'later_backend_entry_not_certified': True}
        except BaseException as exc:
            self.stopped = True; self.failures.append({'phase': 'admission', 'type': type(exc).__name__, 'message': str(exc)})
            try:
                self._emit('admission_refused', self.failures[-1])
            finally:
                raise EvidenceStop('Terminal post-I/O admission stop; no callback invoked') from exc

    def preserve(self, identity, raw, anchors):
        """Preserve ALREADY-returned bytes before another admission, even late.

Bounds/codec failure retains full raw fallback and terminal evidence. It does
not produce a successful compressed receipt or any scientific negative label.
"""
        self._owner()
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', identity) or type(raw) is not bytes:
            raise ValueError('Explicit safe receipt identity and complete bytes required')
        self.costs['preservation_attempts'] += 1
        folder = self.root / identity
        if folder.exists():
            self.stopped = True
            self.failures.append({'phase': 'identity', 'identity': identity, 'message': 'Duplicate receipt; no overwrite'})
            fallback = 'Conflicting_Receipt_' + str(self.costs['preservation_attempts']) + '.bin'
            self._write(fallback, raw)
            self.costs['raw_fallbacks'] += 1
            self._emit('conflicting_identity_raw_retained', dict(self.failures[-1], raw_sha256=digest(raw), artifact=fallback))
            raise EvidenceStop('Duplicate receipt identity; new raw bytes retained separately')
        folder.mkdir(exist_ok=False)
        try:
            self._emit('preservation_intent', {'identity': identity, 'raw_bytes': len(raw), 'raw_sha256': digest(raw)})
            begun = time.perf_counter()
            try:
                encoded, manifest = encode(raw, anchors=anchors,
                    max_raw_bytes=self.protocol['max_raw_bytes'], max_encoded_bytes=self.protocol['max_encoded_bytes'])
            finally:
                self.costs['encode_seconds'] += time.perf_counter() - begun
            self._write(identity + '/payload.zlib', encoded)
            manifest_bytes = canonical(manifest); self._write(identity + '/Manifest.json', manifest_bytes)
            receipt = {'identity': identity, 'raw_sha256': digest(raw),
                       'manifest_sha256': digest(manifest_bytes), 'anchors': copy.deepcopy(manifest['anchors'])}
            self._emit('receipt_closed', receipt)
            self.receipts[identity] = receipt; self.costs['preservation_returns'] += 1
            return copy.deepcopy(receipt)
        except BaseException as exc:
            self.stopped = True
            failure = {'phase': 'preservation', 'identity': identity, 'type': type(exc).__name__,
                       'message': str(exc), 'scientific_result': 'UNKNOWN'}
            self.failures.append(failure)
            # Full raw fallback is a distinct artifact, never overwrite/retry
            # the compressed path or request another scientific call.
            try:
                self._write(identity + '/Raw_Fallback_Unknown.bin', raw)
                self.costs['raw_fallbacks'] += 1
                self._emit('preservation_failed_raw_retained', dict(failure, raw_sha256=digest(raw), raw_bytes=len(raw)))
            finally:
                raise EvidenceStop('Preservation failed; retained artifacts require inspection, no science retry') from exc

    def close(self):
        self._owner()
        self._emit('phase_closed', {'stopped': self.stopped, 'failures': self.failures})
        closure = {'issuer_pid': self.pid, 'protocol_sha256': self.protocol_sha256,
                   'journal_tail_sha256': self.tail, 'journal_rows': self.sequence,
                   'receipts': self.receipts, 'failures': self.failures, 'stopped': self.stopped,
                   'cost_snapshot_before_final_write': copy.deepcopy(self.costs),
                   'final_write_and_inventory_costs_in_external_receipt': True,
                   'scientific_resume_permission': False}
        closure_bytes = canonical(closure); self._write('Closure.json', closure_bytes)
        files = self._inventory(hashes=True)
        self.closed = True
        return {'issuer_pid': self.pid, 'protocol_sha256': self.protocol_sha256,
                'closure_sha256': digest(closure_bytes), 'journal_tail_sha256': self.tail,
                'complete_file_inventory': files, 'final_component_costs': copy.deepcopy(self.costs),
                'whole_owned_component_seconds': time.perf_counter() - self.started,
                'scientific_resume_permission': False}


def restore_closed_bytes(root, external_receipt, *, expected_protocol_sha256):
    """Only independently trusted LOCAL owner receipt, after issuer ended."""
    if external_receipt['protocol_sha256'] != expected_protocol_sha256:
        raise EvidenceStop('External protocol anchor mismatch')
    if process_alive(external_receipt['issuer_pid']):
        raise EvidenceStop('Issuing owner still live; no cold handoff')
    root = local_root(root)
    if inventory(root, hashes=True) != external_receipt['complete_file_inventory']:
        raise EvidenceStop('Incomplete, changed or additional closed evidence')
    protocol_bytes = (root / 'Protocol.json').read_bytes()
    if digest(protocol_bytes) != expected_protocol_sha256:
        raise EvidenceStop('Protocol changed')
    protocol = json.loads(protocol_bytes)
    verify_source_pins(protocol)
    claim = json.loads((root / 'owner.claim').read_bytes())
    if claim['actual_pid'] != external_receipt['issuer_pid'] or claim['python_version'] != sys.version or claim['zlib_runtime'] != zlib.ZLIB_RUNTIME_VERSION:
        raise EvidenceStop('Changed issuing identity or cold runtime')
    closure_bytes = (root / 'Closure.json').read_bytes()
    if digest(closure_bytes) != external_receipt['closure_sha256']:
        raise EvidenceStop('Closure anchor mismatch')
    closure = json.loads(closure_bytes); previous = expected_protocol_sha256; rows = []
    journal = (root / 'receipts.jsonl').read_bytes()
    if not journal.endswith(b'\n'):
        raise EvidenceStop('Truncated journal')
    for sequence, line in enumerate(journal.splitlines()):
        item = json.loads(line); row = item['row']
        if row['sequence'] != sequence or row['previous_sha256'] != previous or digest(canonical(row)) != item['sha256']:
            raise EvidenceStop('Journal hash/cursor mismatch')
        previous = item['sha256']; rows.append(row)
    if (previous != external_receipt['journal_tail_sha256'] or previous != closure['journal_tail_sha256'] or
            len(rows) != closure['journal_rows'] or rows[-1]['event'] != 'phase_closed'):
        raise EvidenceStop('Incomplete closure/journal binding')
    if closure['stopped'] or closure['failures']:
        raise EvidenceStop('Terminal failed phase retained; no successful cold restoration')
    receipts = {r['payload']['identity']: r['payload'] for r in rows if r['event'] == 'receipt_closed'}
    if receipts != closure['receipts']:
        raise EvidenceStop('Closed receipt registry differs')
    restored = {}
    for identity, receipt in receipts.items():
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', identity):
            raise EvidenceStop('Unsafe receipt path')
        manifest = json.loads((root / identity / 'Manifest.json').read_bytes())
        if manifest['anchors'] != receipt['anchors']:
            raise EvidenceStop('Receipt context/source anchors changed')
        restored[identity] = decode((root / identity / 'payload.zlib').read_bytes(), manifest,
            expected_manifest_sha256=receipt['manifest_sha256'], expected_raw_sha256=receipt['raw_sha256'],
            max_raw_bytes=protocol['max_raw_bytes'], max_encoded_bytes=protocol['max_encoded_bytes'])
    return restored, closure
