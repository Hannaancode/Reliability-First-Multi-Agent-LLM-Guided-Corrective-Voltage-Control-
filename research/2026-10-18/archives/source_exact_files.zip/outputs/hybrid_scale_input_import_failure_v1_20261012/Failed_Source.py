"""Original-role causal prompts and public model pins; no forward/allocation/PF."""
import hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
import requests
from durable_opaque_evidence_store_v1 import local_root
from joint_reallocation_opportunity_core_v1 import load_endpoint
from frozen_physics_loader import load_stack,AUDIT
from candidate_process_evidence_utils import frozen_checks

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/hybrid_scale_screen_20261012';PREP=BASE/'preparation'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()
def put(p,d):
    with local_root(p).open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def model_meta(repo):
    r=requests.get('https://huggingface.co/api/models/'+repo,params={'blobs':'true'},timeout=(10,35));r.raise_for_status();d=r.json()
    commit=d['sha'];response=requests.get(f'https://huggingface.co/{repo}/resolve/{commit}/config.json',timeout=(10,35));response.raise_for_status()
    cfg=response.json();files={}
    for f in d['siblings']:
        name=f['rfilename']
        if name.endswith('.safetensors') or name in ('config.json','generation_config.json','model.safetensors.index.json','tokenizer.json','tokenizer_config.json','vocab.json','merges.txt','special_tokens_map.json','chat_template.jinja'):
            files[name]={'bytes':f.get('size'), 'lfs_sha256':f.get('lfs',{}).get('sha256'),'git_blob_id':f.get('blobId')}
    return {'repo':repo,'revision':commit,'config':cfg,'config_sha256':hashlib.sha256(response.content).hexdigest(),
        'files':files,'safetensors_parameter_metadata':d.get('safetensors'),'source_url':'https://huggingface.co/'+repo}
def main():
    local_root(BASE).mkdir(exist_ok=False);local_root(PREP).mkdir()
    begun=time.perf_counter();frozen=frozen_checks();assert frozen['all_passed'];put(PREP/'Fresh_Frozen_Before.json',frozen)
    old=ROOT/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
    assert read(old/'audit/Fixed_Gate_Decision.json')['decision']=='PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY'
    original=ROOT/'outputs/critical_research_reset_20261010/severe_joint_current_verified_handoff_20261012/Verified_Current_And_Operator_Checkpoint.json'
    cp=read(original);p=read(ROOT/'outputs/critical_research_reset_20261010/severe_joint_current_engineering_20261012/preparation/Protocol.json')
    metadata=read(ROOT/p['metadata']);zones=metadata['zones']
    _,runner,_=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    import pandapower as pp
    def blocked(*a,**k):raise RuntimeError('Preparation makes no new physical/model call')
    for n in ('runpp','rundcpp','runopp','rundcopp'):
        if hasattr(pp,n):setattr(pp,n,blocked)
    cases=[];pins={str(original.relative_to(ROOT)):sha(original),p['metadata']:sha(ROOT/p['metadata'])}
    for e in cp['current_endpoints']:
        net,cursor,_=load_endpoint(e);global_uv=runner.rescue.global_uv_buses(net)
        for zone in sorted(zones):
            state=runner.rescue.extract_zone_state_full(net,zone,zones)
            messages=runner.rescue.build_prompt_full(state,global_uv,[])
            cases.append({'case_id':hashlib.sha256((e['world']+'|'+zone).encode()).hexdigest(),
                'administrator_world':e['world'],'zone':zone,'messages':messages,
                'native_receivers':cursor['raw_current_receiver_scope'],
                'fresh_root_failure_memory':'EMPTY_BY_PROSPECTIVE_RESET; not a claim that historical private failed memory was empty',
                'original_positive_cap_history':cursor['positive_addition_lifetime_MVAr']})
        ep=ROOT/e['endpoint_record'];pins[str(ep.relative_to(ROOT))]=sha(ep)
    assert len(cases)==16 and len({x['case_id'] for x in cases})==16
    put(PREP/'Causal_Prompt_Cases.json',cases)
    # Three larger candidates are fixed by size, never by favourable output.
    models=[]
    for repo in ('Qwen/Qwen2.5-3B-Instruct','Qwen/Qwen2.5-7B-Instruct','Qwen/Qwen2.5-14B-Instruct'):
        models.append(model_meta(repo))
    expected=read(ROOT/'outputs/llm_value_candidate_development_20261009/pretrained_learning_trainability_preparation_v3/Expected_Environment.json')
    adapter=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1';cfg=read(adapter/'adapter_config.json')
    base=model_meta(cfg['base_model_name_or_path']);assert base['revision']==expected['base_revision_verified']
    assert base['files']['model.safetensors']['lfs_sha256']==expected['base_weight_sha256']
    put(PREP/'Public_Model_Metadata.json',models);put(PREP/'Original_Private_Base_Metadata.json',base)
    for name in ('adapter_config.json','adapter_model.safetensors','chat_template.jinja','tokenizer.json','tokenizer_config.json'):
        pins[str((adapter/name).relative_to(ROOT))]=sha(adapter/name)
    for a in AUDIT:pins[str(Path(a['file']).relative_to(ROOT))]=a['sha256']
    put(PREP/'Input_And_Role_Closure.json',{'state':'PASS_CAUSAL_ORIGINAL_ROLE_INPUTS_AND_PUBLIC_SOURCE_PINS_ONLY',
        'all16_current_prompts':True,'original_prompt_builder_AST_unchanged':True,'prompt_fields':'Only current zone and global UV observations; no model sees administrator world/labels/AFTER/saved opportunity receipts.',
        'model_role':'Original positive LOCAL proposal supplies a recipient seed to the separately evaluated joint numerical planner; it does not directly emit a signed joint action.',
        'comparability':'Private0.5B carries original adapted weights; public larger models have different training history/architecture/precision costs. Include the identical unadapted quantized0.5B base control. No parameter-count-only causal attribution or matched historical SFT claim.',
        'all_source_input_pins':pins,'source_AST':AUDIT,'raw_input_asset_network_export':False,
        'no_model_PF_optimizer_allocation_calls':True,'new_model_capacity_performance_and_policy_gates':'UNEXECUTED',
        'old_stopped_matched1p5B_and_public_interface_studies_unchanged':True,'preparation_seconds':time.perf_counter()-begun})
    print(json.dumps({'state':'CAUSAL16PROMPTS_AND_LARGER_PUBLIC_MODEL_PINS_PREPARED','larger_models':[m['repo'] for m in models],'no_forward_PF_allocation':True}))
if __name__=='__main__':main()
