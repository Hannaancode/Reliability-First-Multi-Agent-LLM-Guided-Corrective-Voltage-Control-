# Current-state sensitivity control

All311 exact existing state identities and 49471 analytic forecasts were preserved and externally checked. This required311 finite current-Jacobian linear-system solves,622 converter calls,118.99 seconds and zero new nonlinear PF/model/training calls. Native nonlinear convergence is unknown in every forecast. The Q-bound active set is inferred from current observed generator data and is not the original solver's internal active-set certificate.

Held-development equal-world measured-gain error: 1.479406. AllK=1/4/8 recorded-oracle inclusion, failed/unmeasured denominators and the completed numerical control's results are retained. A separately labelled posthoc optimization-mean baseline is also reported to prevent interpreting improvement against random initialization as learned superiority.

These are existing-label forecasts and diagnostics, not measured successor voltages, new protected episodes, independent confirmation or LLM value. Original literal D-SE and full both-branch costs remain the primary later physical comparator. No objective/parameter/Q/seed sweep or new learning campaign automatically follows.
