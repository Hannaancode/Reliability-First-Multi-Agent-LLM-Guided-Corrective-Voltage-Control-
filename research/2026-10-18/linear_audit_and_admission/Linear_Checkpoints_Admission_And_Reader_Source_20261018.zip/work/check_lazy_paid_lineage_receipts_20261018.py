"""Reference lookup/provenance boundaries; no physical certificate fabricated."""
import copy,hashlib,json,os,time
from pathlib import Path
import lazy_paid_lineage_receipts_v1_20261018 as source
from full_receding_paid_campaign_20261015 import put
R=Path(__file__).resolve().parents[1];B=R/'outputs/lazy_paid_lineage_receipts_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'LAZY_ARCHIVED_SOURCE_LOOKUP_SOFTWARE_NOT_SCIENTIFIC_REUSE','source_sha256':sha(Path(source.__file__)),'test_sha256':sha(Path(__file__)),
        'selection':'All60377 source keys classified; first source-order warm, returned and exception receipt for boundary semantics. No outcomes used as performance subset.',
        'bound_seconds':180,'new_scientific_calls':0})
    a=source.ArchivedLineage();checks={};counts={};examples={}
    for key,e in a.index.items():
        assert time.perf_counter()-started<180
        category=a.classification(key);counts[category]=counts.get(category,0)+1
        role='warm' if category=='WARM_PAID_RECEIPT_RETAIN_OLD_COSTS' else 'exception' if e.get('outcome')=='EXCEPTION_OPERATIONAL_REJECT_FEASIBILITY_UNKNOWN' else 'returned'
        examples.setdefault(role,key)
    for role,key in examples.items():
        r=a.archived_receipt(key);assert r['archived_paid_lineage_provenance']['key']==key
        if role=='warm':assert r['receipt_id']==a.warm['cache'][key]['receipt_id']
        else:
            assert 'actual_measured_receipt' not in r and 'source_existing_measured_receipt' in r
            assert r['attributed_PF_calls']==1 and r['attributed_solver_seconds']==r['source_existing_measured_receipt']['seconds']
            if r['after_reference'] is not None:assert r['after_reference']['kind']=='external_capsule'
        r['verdict']['software_mutation']=True;assert 'software_mutation' not in a.archived_receipt(key)['verdict']
        checks[role+'_source_exact_paid_costs_retained_fresh_copy']=True
    try:a.classification('NOT_IN_THIS_LINEAGE|UNKNOWN')
    except source.UnknownLineageIdentity:checks['absent_identity_is_UNKNOWN_not_unexecuted_permission']=True
    else:raise AssertionError('Absent source admitted')
    try:a.execution_cache(B/'not_a_real_independent_physical_certificate.json')
    except source.PhysicalCertificateRequired:checks['no_physical_certificate_no_execution_cache']=True
    else:raise AssertionError('Fake physical certificate accepted')
    key=examples['returned'];original=a.index[key];bad=copy.deepcopy(original);bad['journal_line_sha256']='0'*64;a.index[key]=bad
    try:a.archived_receipt(key)
    except AssertionError:checks['altered_reference_hash_rejected']=True
    else:raise AssertionError('Tampered source accepted')
    finally:a.index[key]=original
    a.index['fixture_blocked']={'classification':'PRIOR_ATTEMPT_NO_CLOSED_RECEIPT_BLOCK_REEXECUTION'}
    try:a.archived_receipt('fixture_blocked')
    except source.PriorAttemptBlocked:checks['old_unclosed_attempt_blocks_reexecution']=True
    else:raise AssertionError('Missing old return fabricated')
    del a.index['fixture_blocked']
    put(B/'Results.json',{'status':'PASS_ALL60377_CLASSIFICATIONS_AND_LAZY_SOURCE_BOUNDARY_CHECKS','all_keys':len(a.index),'classification_counts':counts,'checks':checks,
        'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Source reference/provenance/software only. No new physics owner, missing-identity permission or full physical cache certificate. Independent physical reader and new owner protocol remain required.'})
    print(json.dumps({'lazy_source_lookup':'PASS','keys':len(a.index),'checks':len(checks),'science':0}))
if __name__=='__main__':main()
