"""Current physical observation to the frozen relational compiler.

Software boundary only: this module does not solve physics, load a model,
predict safety, or authorize a rollout. Audit identities stay outside forward.
"""
import copy
import math
import time

from candidate_predictor_input_contract import Q_GRID, validate_observation
from candidate_predictor_operational_state import augmented_model_input
from relational_current_state_codec import digest, encode
from relational_neural_input_v2 import compile_current


FORWARD_FIELDS = frozenset((
    'field_ids', 'kind_ids', 'numeric', 'value_bytes', 'cell_token_ids',
    'token_table_ids', 'token_roles', 'token_bus_ends', 'token_coordinates',
    'token_edge_active', 'query_token_ids', 'allowed_actions', 'original_Q_grid'))


def compile_observation(observation, actual_support, conditioning):
    """Reuse OPT conditioning; reject unsupported fields instead of refitting."""
    started = time.perf_counter()
    before = digest(observation)
    validate_observation(observation)
    common = observation['literal_fallback_bus_pool']
    zonal = observation['raw_zonal_bus_pools']
    scoped = observation['raw_common_and_zone_pools']
    if set(zonal) != set(scoped) or set(zonal) != set(observation['zone_buses']):
        raise ValueError('Exact current zone identity required')
    for pool in [common, *zonal.values(), *scoped.values()]:
        if (len(pool) != len(set(pool)) or
                any(type(b) is not int or not 0 <= b < 118 for b in pool)):
            raise ValueError('Unique native current bus IDs required')
    for zone in zonal:
        if scoped[zone] != [b for b in common if b in zonal[zone]]:
            raise ValueError('Raw common AND zone scope correspondence required')
    current = augmented_model_input(observation, actual_support, 450.)
    compiled = compile_current(encode(current), conditioning)
    if set(compiled) != FORWARD_FIELDS:
        raise ValueError('Only the frozen thirteen current forward fields')
    pooled = {b for p in scoped.values() for b in p}
    expected = [[b in pooled and actual_support[b] + q <= 450.
                 for q in Q_GRID] for b in range(118)]
    if compiled['allowed_actions'] != expected:
        raise ValueError('Current raw scope and original support cap mismatch')
    if digest(observation) != before:
        raise ValueError('Input compiler mutated the current observation')
    audit = {
        'evidence_kind': 'input_compilation_only',
        'current_observation_sha256': before,
        'current_model_input_sha256': digest(current),
        'OPT_conditioning_sha256': digest(conditioning),
        'compiled_input_sha256': digest(compiled),
        'actual_added_support_MVAr_by_bus': list(actual_support),
        'zone_raw_bus_pools': copy.deepcopy(scoped),
        'allowed_action_count': sum(sum(v) for v in expected),
        'soft_positions': len(compiled['token_roles']) + 118,
        'compile_wall_seconds': time.perf_counter() - started,
        'model_calls': 0, 'PF_calls': 0,
        'no_learned_or_physical_performance_claim': True,
    }
    return compiled, audit


def capture_current(net, runner, zones, conditioning):
    """Read an already solved live network using the original observer/getter.

    The caller owns the actual network, solver ledger, model identity and
    prospective experiment. No saved-state support-role inference is used.
    """
    if not bool(net.converged):
        raise ValueError('An actually converged current physical state is required')
    if (tuple(runner.rescue.Q_SWEEP) != Q_GRID or
            runner.rescue.MAX_ABS_Q_PER_BUS != 450.):
        raise ValueError('Original Q grid and per-bus support cap required')
    from train_trajectory_measurement_nullable_v2 import observation

    started = time.perf_counter()
    current = observation(net, runner, zones)
    support = [runner.rescue.llm_q_abs_at_bus(net, b) for b in range(118)]
    if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in support):
        raise ValueError('Finite actual original-getter support required')
    compiled, audit = compile_observation(current, support, conditioning)
    if (digest(observation(net, runner, zones)) != audit['current_observation_sha256'] or
            support != [runner.rescue.llm_q_abs_at_bus(net, b) for b in range(118)]):
        raise ValueError('Current network changed while capturing model input')
    audit['capture_and_compile_wall_seconds'] = time.perf_counter() - started
    audit['support_source'] = 'actual original llm_q_abs_at_bus on current network'
    return compiled, audit
