"""Prospective bidirectional hybrid contract; original paper assets untouched.

Implements input, literal action, refinement, common protection and routing
semantics. A physical executor and anchored runtime are separate requirements.
"""
import ast
import hashlib
import json
import math
from pathlib import Path
import numpy as np

from paper_native13_causal_contract_v2_20261021 import physical_contract

R = Path(__file__).resolve().parents[1]
STEP_CAP = float(np.float32(.3))
FRACTIONS = tuple(v / 300 for v in (25, 50, 75, 100, 125, 150, 200, 250, 300))
NAME = 'NATIVE13_BIDIRECTIONAL_FULLBAND_ORIGINAL_ADAPTER_HYBRID_V1'


def metric(vm):
    v = np.asarray(vm, dtype=np.float64)
    if v.shape != (13,) or not np.isfinite(v).all():
        raise ValueError('Complete finite native13 voltages required')
    error = np.maximum(np.maximum(.95 - v, v - 1.05), 0.)
    return {'UV': int((v < .95).sum()), 'OV': int((v > 1.05).sum()),
            'full13band': bool((error == 0).all()),
            'maximum_band_violation': float(error.max()), 'sum_band_violation': float(error.sum())}


def loss(vm):
    m = metric(vm)
    return (m['UV'] + m['OV'], m['maximum_band_violation'], m['sum_band_violation'])


def unchanged_common_guard():
    path = R / 'work/public13_matched_numeric_engine_20261021.py'
    node = next(n for n in ast.parse(path.read_text(encoding='utf-8')).body
                if isinstance(n, ast.FunctionDef) and n.name == 'original_guard')
    namespace = {'np': np, 'metric': metric}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), str(path), 'exec'), namespace)
    return namespace['original_guard'], hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


def frame(contract, vm, q, round_index, receipt_history=()):
    metric(vm)
    values = np.asarray(q, dtype=float)
    if values.shape != (3,) or not np.isfinite(values).all() or type(round_index) is not int or not 0 <= round_index < 100:
        raise ValueError('Actual three-control Q and fixed native opportunity cursor required')
    past = []
    for row in receipt_history:
        if set(row) != {'round', 'zone', 'bus', 'actual_delta_Q_Mvar', 'accepted', 'reason', 'receipt_sha256'}:
            raise ValueError('Only anchored actual past request/verdict facts may enter feedback')
        if type(row['round']) is not int or not 0 <= row['round'] < round_index:
            raise ValueError('Current/future feedback is unavailable')
        if row['zone'] not in contract['allowed'] or row['bus'] not in contract['allowed'][row['zone']]:
            raise ValueError('Foreign feedback namespace')
        delta = row['actual_delta_Q_Mvar']
        if not isinstance(delta, (float, int)) or isinstance(delta, bool) or not math.isfinite(delta) or not 0 < abs(delta) <= STEP_CAP:
            raise ValueError('Illegal signed history increment')
        if type(row['accepted']) is not bool or not isinstance(row['reason'], str):
            raise ValueError('Explicit past verdict required')
        digest = row['receipt_sha256']
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Actual saved receipt anchor required; runtime must verify its bytes')
        past.append(dict(row))
    return {'current_VM': list(map(float, vm)), 'current_Q_Mvar': values.tolist(),
            'round': round_index, 'anchored_past_feedback': past}


def messages(contract, state, zone):
    if zone not in contract['zones']:
        raise ValueError('Unknown zone')
    allowed = contract['allowed'][zone]
    if metric(state['current_VM'])['full13band'] or not allowed:
        return None
    observation = {'zone': zone, 'round': state['round'],
                   'all13_current_VM_pu': dict(zip(map(str, contract['bus_ids']), state['current_VM'])),
                   'local_bus_ids': contract['zones'][zone],
                   'native_zone_controls': [{'bus': b,
                                             'current_Q_Mvar': state['current_Q_Mvar'][contract['actuator_buses'].index(b)],
                                             'minimum_delta_Q_Mvar': -STEP_CAP,
                                             'maximum_delta_Q_Mvar': STEP_CAP} for b in allowed],
                   'actual_past_verifier_feedback': [r for r in state['anchored_past_feedback'] if r['zone'] == zone]}
    return [{'role': 'system', 'content': 'You are a microgrid zone agent. Return only valid JSON. No prose.'},
            {'role': 'user', 'content':
             'This explicitly adapted native-inverter controller must restore ALL bus voltages to0.95..1.05pu. '
             'Both undervoltage and overvoltage count. Propose one literal SIGNED Mvar INCREMENT at one listed control bus. '
             'Positive q_mvar increases capacitive injection; negative q_mvar reduces injection or absorbs reactive power. '
             'The value is a per-round change, not an absolute Q target. Do not use federation25..300Mvar units. '
             'Use only the listed native limits. No clipping, unit rescaling, sign repair or invalid-output fill is performed. '
             'Return exactly {"bus":"BUS_ID","q_mvar":SIGNED_NUMERIC_INCREMENT}, or null to abstain. '
             'Every proposal must pass a paid common physical verifier; query/refinement/fallback costs are retained.\n'
             'CURRENT_OBSERVATION:\n' + json.dumps(observation, sort_keys=True, separators=(',', ':'), allow_nan=False)}]


def admit(raw, contract, state, zone):
    if zone not in contract['allowed']:
        raise ValueError('Unknown zone')
    try:
        value = json.loads(raw) if isinstance(raw, str) else raw
    except (ValueError, TypeError):
        return {'status': 'INVALID', 'reason': 'strict_complete_JSON_required'}
    if value is None:
        return {'status': 'ABSTAIN', 'strict_JSON': True}
    if not isinstance(value, dict) or set(value) != {'bus', 'q_mvar'}:
        return {'status': 'INVALID', 'reason': 'exact_compact_schema_required_no_partial_extraction'}
    bus = value['bus']
    if isinstance(bus, bool) or not isinstance(bus, (str, int)):
        return {'status': 'INVALID', 'reason': 'native_bus_identity_required'}
    try:
        bus = int(bus)
    except (ValueError, TypeError, OverflowError):
        return {'status': 'INVALID', 'reason': 'native_bus_identity_required'}
    if bus not in contract['allowed'][zone]:
        return {'status': 'INVALID', 'reason': 'foreign_or_uncontrolled_recipient'}
    amount = value['q_mvar']
    if isinstance(amount, bool) or not isinstance(amount, (float, int)) or not math.isfinite(amount) or not 0 < abs(amount) <= STEP_CAP:
        return {'status': 'INVALID', 'reason': 'literal_signed_native_increment_required_no_clip'}
    u = np.zeros(3, dtype=np.float32)
    u[contract['actuator_buses'].index(bus)] = -amount
    if not np.any(u):
        return {'status': 'INVALID', 'reason': 'float32_underflow'}
    return {'status': 'LEGAL_PROPOSAL_NOT_PHYSICALLY_VERIFIED', 'bus': bus,
            'literal_requested_delta_Q_Mvar': amount, 'native_u': u.tolist(),
            'actual_delta_Q_Mvar': float(np.sum(-u)),
            'candidate_Q_Mvar': (np.asarray(state['current_Q_Mvar']) - u.astype(float)).tolist()}


def guided_requests(proposals):
    """Same nine source magnitudes as capability fractions, at chosen bus/sign.

    These are separately paid numerical queries, never rewritten LLM outputs.
    """
    seen = set()
    rows = []
    for p in proposals:
        if p['status'] != 'LEGAL_PROPOSAL_NOT_PHYSICALLY_VERIFIED':
            continue
        sign = 1 if p['actual_delta_Q_Mvar'] > 0 else -1
        if (p['bus'], sign) in seen:
            continue
        seen.add((p['bus'], sign))
        for fraction in FRACTIONS:
            rows.append({'bus': p['bus'], 'q_mvar': sign * STEP_CAP * fraction,
                         'source': 'llm_guided_numerical_refinement'})
    return rows


def choose_verified(before_vm, candidates):
    """Receipt integrity is checked by the executor, not invented by this core."""
    common_guard, _ = unchanged_common_guard()
    ranks = {'llm_direct': 3, 'llm_guided_numerical_refinement': 2, 'numerical_fallback': 1}
    eligible = []
    for c in candidates:
        if c['source'] not in ranks or not c.get('paid_receipt_reference'):
            raise ValueError('Known source and actual paid receipt required')
        native_u = np.asarray(c['native_u'], dtype=np.float32)
        if native_u.shape != (3,) or not np.isfinite(native_u).all() or not (np.abs(native_u) <= np.float32(.3)).all():
            raise ValueError('A proposal exceeded common native control capability')
        if common_guard(np.asarray(before_vm), np.asarray(c['after_VM'])) and loss(c['after_VM']) < loss(before_vm):
            eligible.append(c)
    if not eligible:
        return None
    return max(eligible, key=lambda c: (ranks[c['source']],)
               + tuple(-x for x in loss(c['after_VM']))
               + (-float(np.abs(c['native_u']).sum()),))
