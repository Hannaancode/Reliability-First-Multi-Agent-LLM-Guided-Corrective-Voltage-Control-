"""Single finite control handoff; audit only after exact CPU owner ends."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,time,subprocess,psutil
from candidate_process_evidence_utils import ROOT,read,sha,write
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';S=P/'transition_CPU_pilot'
OUT=P/'transition_CPU_audit_handoff';assert not OUT.exists();OUT.mkdir()
write(OUT/'owner.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__)),'started_at_utc':datetime.now(timezone.utc).isoformat()})
claim=read(S/'owner.claim');pid=claim['pid'];process=psutil.Process(pid);birth=process.create_time()
assert any(Path(s).name=='run_action_transition_CPU_pilot.py' for s in process.cmdline())
assert sha(ROOT/'work/run_action_transition_CPU_pilot.py')==claim['source_sha256']
started=time.monotonic()
def status(stage,**extra):
    t=OUT/'status.tmp';t.write_text(json.dumps({'stage':stage,'handoff_pid':os.getpid(),'actual_science_owner_pid':pid,
        'updated_at_utc':datetime.now(timezone.utc).isoformat(),**extra},indent=2));t.replace(OUT/'status.json')
status('waiting_for_actual_CPU_owner_to_end')
while True:
    try:
        p=psutil.Process(pid)
        alive=p.create_time()==birth and p.status()!=psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:alive=False
    if not alive:break
    assert time.monotonic()-started<4500,'Finite handoff bound; no reader launch on uncertain owner'
    time.sleep(20)
actual=read(S/'status.json')
if actual['stage']!='complete_fixed_OPT_numerical_pilot_pending_independent_audit':
    status('terminal_owner_partial_preserved_no_complete_reader',actual_owner_terminal_status=actual);raise SystemExit(1)
assert (S/'Closed_Scientific_Manifest.json').exists()
assert not (P/'transition_CPU_pilot_external_audit').exists(),'Existing reader claim/output; never duplicate'
for p in psutil.process_iter(['pid','name','cmdline']):
    if p.info['name']=='python.exe' and any(Path(s).name=='analyze_action_transition_CPU_pilot.py' for s in (p.info['cmdline'] or [])):
        raise AssertionError('Existing actual reader worker')
proto=read(P/'transition_CPU_pilot_preparation/Prospective_CPU_Pilot_Protocol.json')
reader=ROOT/'work/analyze_action_transition_CPU_pilot.py'
assert sha(reader)==proto['source_sha256']['work/analyze_action_transition_CPU_pilot.py']
with (OUT/'reader_stdout.log').open('x',encoding='utf8') as stdout,(OUT/'reader_stderr.log').open('x',encoding='utf8') as stderr:
    child=subprocess.Popen([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(reader)],cwd=ROOT,
        stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    status('single_external_reader_started_after_owner_end',reader_launcher_pid=child.pid)
    code=child.wait(timeout=1200)
if code:
    status('terminal_external_reader_failure_preserved_no_repeat',reader_exit_code=code);raise SystemExit(code)
audit=read(P/'transition_CPU_pilot_external_audit/status.json')
assert audit['stage']=='complete_OPT_control_external_audit'
status('complete_single_external_audit_handoff',audit_status=audit,new_model_PF_controller_cloud_calls=0)
