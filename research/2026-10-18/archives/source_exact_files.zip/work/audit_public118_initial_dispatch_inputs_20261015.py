"""All-three published raw initial-dispatch audit; no physical or model calls."""
import hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from intake_public_118_testbeds_20261014 import matrix
R=Path(__file__).resolve().parents[1];B=R/'outputs/public118_initial_dispatch_input_audit_20261015'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    B.mkdir(exist_ok=False);start=time.perf_counter();intake=read(R/'outputs/public_testbed_intake_20261014/Public_Data_Intake_Result.json')
    put(B/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'selection':'ALL3 originally pinned official IEEE118 variants, no voltage/outcome filtering',
        'source_sha256':sha(Path(__file__)),'exact_raw_inputs':[{k:r[k] for k in ('path','sha256')} for r in intake['records']],
        'method':'Read original numeric bus/gen/branch matrices only; compute raw scheduled generation/load/voltage and bound consistency. Never solve, convert, edit or create an operating dispatch.',
        'all_initial_convergence_voltage_physical_performance_results':'NOT_MEASURED','new_model_PF_OPF_converter_forecast_solve_calls':0})
    rows=[]
    for r in intake['records']:
        path=R/r['path'];assert sha(path)==r['sha256'];text=path.read_text('utf-8-sig')
        bus=np.asarray(matrix(text,'bus'));gen=np.asarray(matrix(text,'gen'));branch=np.asarray(matrix(text,'branch'))
        online=gen[:,7]>0;live=gen[online];load=float(bus[:,2].sum());scheduled=float(live[:,1].sum())
        rows.append({'case':r['path'],'raw_sha256':r['sha256'],'all_online_generators':int(online.sum()),
            'raw_total_load_MW':load,'raw_online_scheduled_Pg_MW':scheduled,
            'raw_generation_minus_load_MW_before_unknown_losses_and_shunts':scheduled-load,
            'online_Pmin_sum_MW':float(live[:,9].sum()),'online_Pmax_sum_MW':float(live[:,8].sum()),
            'generators_raw_Pg_outside_own_bounds':int(((live[:,1]<live[:,9])|(live[:,1]>live[:,8])).sum()),
            'generators_raw_Qg_outside_own_bounds':int(((live[:,2]<live[:,4])|(live[:,2]>live[:,3])).sum()),
            'buses_raw_Vm_outside_native_bounds':int(((bus[:,7]<bus[:,12])|(bus[:,7]>bus[:,11])).sum()),
            'online_branches_with_positive_rateA':int(((branch[:,10]>0)&(branch[:,5]>0)).sum()),
            'nonzero_load_with_zero_total_scheduled_generation':load>0 and scheduled==0,
            'operating_dispatch_convergence_slack_output_voltage_thermal_and_control_results':'UNKNOWN_NOT_SOLVED',
            'not_a_physical_infeasibility_result':True})
    result={'status':'COMPLETE_ALL3_RAW_PUBLISHED_DISPATCH_INPUT_AUDIT','at_utc':datetime.now(timezone.utc).isoformat(),
        'all3':rows,'new_model_PF_OPF_converter_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-start,
        'decision':'Do not claim a published physical benchmark from imported initial guesses. Freeze and verify an identical physically valid dispatch/initialization with native generator/voltage/thermal bounds before controller/model comparisons; charge initialization costs and disclose task adaptation.',
        'native_ACOPF_and_discrete_shunt_recovery_are_different_tasks':True,'no_automatic_solver_or_model_launch':True}
    put(B/'Results.json',result);put(B/'Closed_Manifest.json',{'exit_code':0,'members':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()}})
    print(json.dumps({'all3_raw_dispatch_audited':True,'cases_zero_schedule_nonzero_load':sum(r['nonzero_load_with_zero_total_scheduled_generation'] for r in rows),'new_scientific_calls':0}))
if __name__=='__main__':main()
