"""Newstationarynative frozen representations, complete primary+cold features; no labels/generation/training."""
import os,json,time,hashlib,gc,traceback
from pathlib import Path
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUBLAS_WORKSPACE_CONFIG=':4096:8',HF_HUB_DISABLE_IMPLICIT_TOKEN='1')
ROOT=Path(__file__).resolve().parents[1]
from public_size_u61_preservation import atomic_json,journal,Publisher,file_hash
OUT=ROOT/'outputs/public_size_science';OUT.mkdir(exist_ok=False);p=json.loads((ROOT/'prep/protocol.json').read_text());arm=json.loads((ROOT/'prep/selected_arm.json').read_text())['arm'];items=json.loads((ROOT/'prep/Causal_Inputs_Only.json').read_text());env=json.loads((ROOT/'outputs/public_size_environment.json').read_text());start=time.monotonic();cost={'model_load_attempts':0,'model_load_returns':0,'body_forward_attempts':0,'body_forward_returns':0,'zero_path_body_returns':0,'generation_backward_optimizer_PF_calls':0};previous='0'*64;events=OUT/'events.jsonl';publisher=Publisher(OUT,ROOT/'outputs/public_size_transfer',wait_seconds=180)
atomic_json(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':file_hash(__file__),'protocol_sha256':file_hash(ROOT/'prep/protocol.json'),'arm':arm})
def event(kind,**data):
    global previous
    assert time.monotonic()-start<p['science_process_seconds'];row={'kind':kind,'seconds':time.monotonic()-start,'previous':previous,**data};h=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest();journal(events,{'event':row,'sha256':h});previous=h
def progress(stage):atomic_json(OUT/'progress.json',{'stage':stage,'actual_costs':cost,'updated_unix':time.time()})
try:
    import numpy as np,torch
    from transformers import AutoModelForCausalLM,BitsAndBytesConfig
    from peft import PeftModel
    from candidate_process_pretrained_loader import preservation_inventory,source_adapter_state,verify_copy_state,enabled_restored_gate
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4' and len(items)==241 and max(r['tokens'] for r in items)==2598
    for rel,h in p['source_hashes'].items():assert file_hash(ROOT/rel)==h
    assert file_hash(ROOT/'prep/Causal_Inputs_Only.json')==p['causal_inputs_sha256'];declaration=p['models'][arm];width=declaration['hidden_size'];order=sorted(items,key=lambda r:(-r['tokens'],r['id']));all_outputs={};private=arm=='private_0_5B'
    atomic_json(OUT/'Input_Context_Identity.json',{'arm':arm,'all241_complete_inputs':True,'max_tokens':2598,'no_future_label_teacher_or_history_budget_fields_in_body':True,'body_width':width,'frozen_representation_new_native_role':True,'source':declaration,'all_tokens':sum(r['tokens'] for r in items),'selected_longest_id':order[0]['id']});event('input_context_source_pass');publisher.publish('input_context_source_before_model')
    def load(replica):
        torch.manual_seed(20261020);torch.cuda.manual_seed_all(20261020);cost['model_load_attempts']+=1;event('model_load_attempt',replica=replica);t=time.perf_counter();model=AutoModelForCausalLM.from_pretrained(env['base_snapshot'],local_files_only=True,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'},dtype=torch.float16,attn_implementation='sdpa');assert model.is_loaded_in_4bit and model.config.hidden_size==width
        if private:
            for rel,h in declaration['private_files'].items():assert file_hash(ROOT/rel)==h
            adapter=ROOT/'prep/private_adapter';cfg,state=source_adapter_state(adapter);model=PeftModel.from_pretrained(model,str(adapter),adapter_name='candidate_process_copy',is_trainable=False,local_files_only=True,autocast_adapter_dtype=True);model.set_adapter('candidate_process_copy');verify_copy_state(model,state);enabled_restored_gate(model)
        for param in model.parameters():param.requires_grad_(False)
        model.eval();assert not any(v.requires_grad for v in model.parameters());cost['model_load_returns']+=1;event('model_load_return',replica=replica,seconds=time.perf_counter()-t);return model
    def application(model,item,replica,zero=False):
        assert item['tokens']==len(item['input_ids'])<=4096;ids=torch.tensor([item['input_ids']],device='cuda',dtype=torch.long);mask=torch.ones_like(ids);body=model.get_base_model().model if private else model.model;cost['body_forward_attempts']+=1;event('body_forward_attempt',replica=replica,id=item['id'],zero_path=zero,tokens=ids.numel(),input_ids_sha256=hashlib.sha256(ids.cpu().numpy().tobytes()).hexdigest(),attention_mask_ones=int(mask.sum()));t=time.perf_counter()
        with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):out=body(input_ids=ids,attention_mask=mask,use_cache=False,return_dict=True).last_hidden_state
        torch.cuda.synchronize();assert out.shape==(1,item['tokens'],width) and torch.isfinite(out).all();value=out[0,-1].float().cpu().numpy().copy();cost['body_forward_returns']+=1;cost['zero_path_body_returns']+=int(zero);event('body_forward_return',replica=replica,id=item['id'],zero_path=zero,seconds=time.perf_counter()-t,feature_sha256=hashlib.sha256(value.tobytes()).hexdigest());return value
    torch.cuda.reset_peak_memory_stats()
    for replica in ['primary','cold']:
        model=load(replica);before=preservation_inventory(model);atomic_json(OUT/f'{replica}_Immutable_Before.json',before);features=np.zeros((len(items),width),dtype=np.float32);published=[]
        for pos,item in enumerate(order):
            features[item['id']]=application(model,item,replica);published.append(item['id'])
            if replica=='cold':assert np.array_equal(features[item['id']],all_outputs['primary'][item['id']]),'Exactcoldfeaturemismatch; no retry'
            if pos==0 and private:
                with model.disable_adapter():zero=application(model,item,replica,zero=True)
                for param in model.parameters():param.requires_grad_(False)
                np.save(OUT/f'{replica}_Public_Base_Zero_Path.npy',zero);atomic_json(OUT/f'{replica}_Zero_Path_Identity.json',{'case_id':item['id'],'tokens':item['tokens'],'after_restore_all_parameters_frozen':not any(v.requires_grad for v in model.parameters())})
            if (pos+1)%25==0 or pos+1==len(order):
                block=OUT/f'{replica}_block_{pos//25:03d}.npz';np.savez(block,ids=np.asarray(published),features=features[published]);published=[];progress(f'{replica}_features_preserving');publisher.publish(f'{replica}_block_{pos//25:03d}')
        assert preservation_inventory(model)==before;atomic_json(OUT/f'{replica}_Immutable_After.json',before)
        if private:verify_copy_state(model,source_adapter_state(ROOT/'prep/private_adapter')[1])
        np.save(OUT/f'{replica}_All241_Features.npy',features);all_outputs[replica]=features;del model;gc.collect();torch.cuda.empty_cache()
    expected=482+(2 if private else 0);assert cost['body_forward_attempts']==cost['body_forward_returns']==expected and cost['model_load_returns']==2;peak=torch.cuda.max_memory_allocated();assert peak<=12*1024**3
    result={'status':'COMPLETE_ALL241_NATIVE_FROZEN_FEATURES_AND_FRESH_MODEL_COLD_EXACT','arm':arm,'actual_costs':cost,'primary_feature_rows':241,'hidden_size':width,'all241_primary_cold_features_bit_exact':True,'all_base_quantized_and_private_values_unchanged':True,'peak_allocated_bytes':peak,'peak_reserved_bytes':torch.cuda.max_memory_reserved(),'workflow_seconds':time.monotonic()-start,'no_fitted_readout_or_benchmark_yet':True,'same_original1929_FITmultiplicities_preserved_locally':True,'no_DEV_confirmation_inference':True};atomic_json(OUT/'Results.json',result);event('closed',results_sha256=file_hash(OUT/'Results.json'));progress('complete_preserving_final');publisher.publish('complete_frozen_feature_results')
except BaseException as e:atomic_json(OUT/'Failure.json',{'type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'actual_costs':cost,'workflow_seconds':time.monotonic()-start});progress('partial_failure_preserved');raise
