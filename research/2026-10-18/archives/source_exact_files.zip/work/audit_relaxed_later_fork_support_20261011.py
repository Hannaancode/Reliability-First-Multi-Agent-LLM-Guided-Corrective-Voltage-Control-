"""One closed-run exact-ID necessary-support audit; no science or controller execution."""
import argparse
import ast
import ctypes
import hashlib
import json
import math
import os
import sys
import time
import traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import frozen_checks, seal

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/critical_research_reset_20261010/later_fork_process_support_20261011'
PRODUCTION = ROOT / 'work/check_relaxed_later_fork_support_20261011.py'
READY = ROOT / 'work/relaxed_later_fork_reader_readiness_20261011.json'
UTILS = ROOT / 'work/candidate_process_evidence_utils.py'
A = ROOT / 'outputs/critical_research_reset_20261010/actual_query_and_continuation_receipt_inventory_v3'
D = ROOT / 'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3'
T = ROOT / 'outputs/llm_value_relational_adaptation_research_20261009/measured_OPT_transition_inventory'
C = ROOT / 'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2'
INPUTS = {'edges': A / 'All216_Actual_Action_Linked_Successor_Records.json',
          'prior_summary': A / 'summary.json',
          'prior_reader': ROOT / 'outputs/critical_research_reset_20261010/actual_query_receipt_inventory_independent_reader/Independent_Actual_Receipt_Check.json',
          'partition': C / 'protocol.json', 'raw_protocol': D / 'protocol.json',
          'transition_protocol': T / 'Protocol.json'}
SOURCES = {'literal': ROOT / 'work/e/audit/run_reflection_v4_safety_envelope.py',
           'ALT': ROOT / 'work/dff_alt.py',
           'observer': ROOT / 'work/train_trajectory_measurement_nullable_v2.py',
           'base_observer': ROOT / 'work/value_observe_original_DFF.py'}
NO_SUPPORT = 'NO_RETAINED_LATER_FORK_SUPPORT_STOP_EXISTING_DATA_TRAINING'
POSITIVE_UNKNOWN = 'UNKNOWN_NEEDS_FULL_PROCESS_AND_PROTECTED_CONTINUATIONS'
FROZEN_CHECK_NAMES = {'frozen_matched_protocol_sha256', 'frozen_controller_sources',
                      'all_62_scenario_files', 'locked_file_set', 'bank_manifest',
                      'bank_sanity_report', 'network', 'metadata', 'model_root_files'}


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    # Same exact stored physical-observation byte representation as the observer.
    # No tolerance, metric proximity, or process-field imputation participates.
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf8')).hexdigest()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def write(path, value):
    with path.open('x', encoding='utf8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())


def stamp(value):
    parsed = datetime.fromisoformat(value)
    assert parsed.tzinfo is not None
    return parsed


def number(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def compare(expected, actual, label='root'):
    if isinstance(expected, dict):
        assert isinstance(actual, dict), label
        for key, value in expected.items():
            assert key in actual, (label, key)
            compare(value, actual[key], label + '.' + key)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), label
        for index, (left, right) in enumerate(zip(expected, actual)):
            compare(left, right, label + '[' + str(index) + ']')
    else:
        assert type(expected) is type(actual) and expected == actual, (label, expected, actual)


def owner_ended(pid):
    assert type(pid) is int and pid > 0 and pid != os.getpid()
    if os.name != 'nt':
        try:
            os.kill(pid, 0)
            return False
        except ProcessLookupError:
            return True
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    kernel.OpenProcess.restype = ctypes.c_void_p
    handle = kernel.OpenProcess(0x1000, 0, pid)
    if not handle:
        assert ctypes.get_last_error() == 87, 'Actual producer end cannot be certified'
        return True
    try:
        code = ctypes.c_ulong()
        kernel.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
        kernel.GetExitCodeProcess.restype = ctypes.c_int
        assert kernel.GetExitCodeProcess(handle, ctypes.byref(code))
        return code.value != 259
    finally:
        kernel.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel.CloseHandle(handle)


def normalized_path(value):
    assert isinstance(value, str) and '\\' not in value
    relative = Path(value)
    assert not relative.is_absolute() and '..' not in relative.parts and relative.as_posix() == value
    path = ROOT / relative
    assert path.resolve().is_relative_to(ROOT.resolve())
    return path


def raw_action(action):
    assert isinstance(action, dict) and set(action) == {'add_shunts_q_mvar'}
    shunts = action['add_shunts_q_mvar']
    assert isinstance(shunts, dict) and len(shunts) == 1
    bus, reactive = next(iter(shunts.items()))
    assert isinstance(bus, str) and number(reactive)
    return [int(bus), float(reactive)]


def edge_key(row):
    action = row['action']
    assert isinstance(action, list) and len(action) == 2
    assert type(action[0]) is int and number(action[1])
    return (row['world_sha256'], row['branch'], row['before_observation_id'],
            (action[0], float(action[1])), row['after_observation_id'])


def static_contract():
    # Parse source text only; never import or invoke a frozen source function.
    observer = ast.parse(SOURCES['observer'].read_text(encoding='utf8'))
    functions = {node.name: node for node in observer.body if isinstance(node, ast.FunctionDef)}
    assert {'safe', 'digest', 'observation'} <= set(functions)
    observation_keys = set()
    for node in ast.walk(functions['observation']):
        if isinstance(node, ast.Dict):
            observation_keys.update(key.value for key in node.keys
                                    if isinstance(key, ast.Constant) and isinstance(key.value, str))
    assert {'schema_version', 'physical_tables', 'zone_buses', 'zone_reports',
            'global_metrics', 'literal_fallback_bus_pool', 'raw_zonal_bus_pools',
            'raw_common_and_zone_pools'} <= observation_keys
    assert not {'decision', 'failed_signatures_before', 'branch', 'scenario_sha256'} & observation_keys
    return {'observer_source_sha256': sha(SOURCES['observer']),
            'digest_function_AST_sha256': hashlib.sha256(ast.dump(functions['digest'], include_attributes=False).encode('utf8')).hexdigest(),
            'observation_function_AST_sha256': hashlib.sha256(ast.dump(functions['observation'], include_attributes=False).encode('utf8')).hexdigest(),
            'source_functions_imported_or_invoked': False,
            'exact_canonical_stored_physical_IDs_only': True,
            'tolerance_based_ID_merges': 0,
            'cap_memory_history_and_restorable_solver_identity': 'DELIBERATELY_RELAXED_UNRESOLVED'}


def run():
    started = time.perf_counter()
    prep = BASE / 'preparation'
    execution = BASE / 'execution'
    # These guards precede every data/outcome read and exclusive reader claim.
    status = read(execution / 'status.json')
    owner = read(execution / 'owner.claim')
    closed = read(execution / 'Closed_Manifest.json')
    assert status['state'] in {'ENDED_COMPLETE', 'ENDED_PARTIAL'} and status['manifest_closed'] is True
    assert status['actual_pid'] == owner['actual_pid'] and owner_ended(owner['actual_pid'])
    protocol = read(prep / 'Protocol.json')
    ready = read(READY)
    lock = read(prep / 'Reader_Source_Lock.json')
    own_hash = sha(Path(__file__))
    protocol_hash = sha(prep / 'Protocol.json')
    assert own_hash == ready['reader_source_sha256'] == lock['reader_source_sha256']
    assert sha(READY) == lock['reader_readiness_sha256']
    lock_time = lock.get('at_utc', lock.get('prepared_at_utc'))
    assert lock_time is not None
    timestamps = [protocol['at_utc'], ready['prepared_at_utc'], lock_time,
                  owner['at_utc'], closed['at_utc'], status['at_utc']]
    assert all(stamp(left) <= stamp(right) for left, right in zip(timestamps, timestamps[1:]))
    assert stamp(ready['prepared_at_utc']) < stamp(owner['at_utc'])
    assert stamp(lock_time) < stamp(owner['at_utc'])
    for path in (Path(__file__), READY, prep / 'Reader_Source_Lock.json'):
        assert datetime.fromtimestamp(path.stat().st_mtime, timezone.utc) < stamp(owner['at_utc'])
    production_hash = sha(PRODUCTION)
    assert production_hash == protocol['source_sha256'] == ready['production_source_sha256']
    assert production_hash == owner['source_sha256'] == closed['source_sha256']
    assert protocol_hash == ready['protocol_sha256'] == owner['protocol_sha256'] == closed['protocol_sha256']
    assert sha(UTILS) == ready['evidence_utils_sha256']
    assert protocol['bound_seconds'] == 120
    assert protocol['new_model_PF_optimizer_controller_forecast_solve_fit_tokenizer_cloud_calls'] == 0
    assert protocol['no_full_process_or_restorable_solver_claim'] is True
    assert protocol['no_automatic_allocation_learning_or_physics'] is True
    assert ready['reader_executions'] == 0 and ready['performance_outcomes_read_during_implementation'] is False
    assert ready['static_fatal_issues'] == []
    out = BASE / 'independent_audit'
    out.mkdir(exist_ok=False)
    write(out / 'reader.claim', {'actual_pid': os.getpid(), 'at_utc': now(),
                               'reader_source_sha256': own_hash,
                               'reader_readiness_sha256': sha(READY),
                               'closed_production_manifest_sha256': sha(execution / 'Closed_Manifest.json'),
                               'actual_production_owner_verified_ended': True,
                               'no_frozen_function_or_science_calls': True})
    cost = {'independent_OPT_raw_branch_read_returns': 0,
            'independent_exact_observation_ID_checks': 0,
            'independent_edge_occurrence_classifications': 0,
            'independent_physical_multiaction_group_classifications': 0,
            'frozen_check_invocations': 0, 'new_archive_seal_invocations': 0,
            'new_model_PF_optimizer_controller_forecast_solve_fit_tokenizer_cloud_calls': 0,
            'frozen_controller_function_invocations': 0, 'old_archive_rehashes': 0,
            'held_branch_read_returns': 0, 'all_analysis_and_IO_paid': True}
    report = {'all_passed': False, 'gate': 'UNKNOWN_NO_IMPUTATION'}
    failure = None
    raw_paths = {}
    try:
        names = {path.name for path in execution.iterdir() if path.is_file()}
        assert all(path.is_file() and not path.is_symlink() for path in execution.iterdir())
        assert set(closed['members']) == names - {'Closed_Manifest.json', 'status.json'}
        assert {'owner.claim', 'Actual_Costs.json'} <= set(closed['members'])
        assert set(closed['members']) <= {'owner.claim', 'Actual_Costs.json', 'Failure.json',
                                         'All_Actual_Edge_Decision_Occurrences.json',
                                         'All_Optimistic_Physical_Forks.json', 'Results.json'}
        for name, descriptor in closed['members'].items():
            assert Path(name).name == name and not (execution / name).is_symlink()
            assert (execution / name).stat().st_size == descriptor['bytes']
            assert sha(execution / name) == descriptor['sha256'], name
        partial = status['state'] == 'ENDED_PARTIAL' or 'Failure.json' in names
        assert closed['complete'] is (not partial)
        if not partial:
            assert {'All_Actual_Edge_Decision_Occurrences.json', 'All_Optimistic_Physical_Forks.json',
                    'Results.json'} <= names
        compare(protocol['input_sha256'], ready['latched_input_sha256'])
        compare(protocol['source_sha256_by_role'], ready['latched_source_sha256_by_role'])
        assert set(protocol['input_sha256']) == set(INPUTS)
        assert set(protocol['source_sha256_by_role']) == set(SOURCES)
        for role, path in INPUTS.items():
            assert sha(path) == protocol['input_sha256'][role], role
        for role, path in SOURCES.items():
            assert sha(path) == protocol['source_sha256_by_role'][role], role
        contract = static_contract()
        write(out / 'Independent_Static_Exact_ID_Contract.json', contract)
        partition = read(INPUTS['partition'])
        raw_protocol = read(INPUTS['raw_protocol'])
        transition_protocol = read(INPUTS['transition_protocol'])
        opt = set(partition['optimization_world_sha256'])
        held = set(partition['development_held_world_sha256'])
        assert len(partition['optimization_world_sha256']) == len(opt) == 23
        assert len(partition['development_held_world_sha256']) == len(held) == 8 and not opt & held
        worlds = raw_protocol['worlds']
        assert len(worlds) == 31 and len({row['sha256'] for row in worlds}) == 31
        assert {row['sha256'] for row in worlds} == opt | held
        assert len({row['scenario_id'] for row in worlds}) == 31
        assert sorted(opt) == protocol['optimization_world_sha256']
        assert sorted(held) == protocol['declared_held_world_sha256_NOT_READ']
        historical_source = {key.replace('\\', '/'): value for key, value in raw_protocol['frozen_source_sha256'].items()}
        observer_relative = SOURCES['observer'].relative_to(ROOT).as_posix()
        assert historical_source[observer_relative] == sha(SOURCES['observer'])
        latches = protocol['latched_OPT_branches']
        assert len(latches) == 46 and len({entry['path'] for entry in latches}) == 46
        latch_map = {(entry['world_sha256'], entry['branch']): entry for entry in latches}
        expected_pairs = {(world, branch) for world in opt for branch in ('DFF', 'DFF-ALT')}
        assert len(latch_map) == 46 and set(latch_map) == expected_pairs
        old_latches = {key.replace('\\', '/'): value for key, value in transition_protocol['source_branch_hashes'].items()}
        world_map = {row['sha256']: row for row in worlds}
        for key, entry in latch_map.items():
            world, branch = key
            expected_path = D / ('branches/' + world_map[world]['scenario_id'] + '__' + branch + '.json')
            assert normalized_path(entry['path']) == expected_path
            assert old_latches[entry['path']] == entry['sha256']
            raw_paths[entry['path']] = expected_path
        retained = [{'world_sha256': world, 'scenario_id': world_map[world]['scenario_id'],
                     'split': 'OPT' if world in opt else 'HELD_IDENTITY_ONLY',
                     'new_branch_outcomes_read': world in opt,
                     'declared_branch_identities': ['DFF', 'DFF-ALT']}
                    for world in sorted(opt | held)]
        write(out / 'All31_Original_World_Identity_Retention.json', retained)
        assert read(INPUTS['prior_reader'])['all_passed'] is True
        previous = read(INPUTS['prior_summary'])
        assert previous['unique_actual_committed_successor_edges'] == 216
        assert previous['before_states_with_multiple_actual_committed_actions'] == 23
        assert previous['raw_held_outcomes_not_newly_analysed'] is True
        assert previous['all31_worlds_original_invalid_and_missing_ledger_denominators_retained'] is True
        unknown = previous['recorded_query_receipts_without_measured_successor']
        assert unknown == 30312
        assert previous['unique_OPT_measured_state_action_receipts'] - previous['recorded_query_receipts_with_exact_committed_successor'] == unknown
        edges = read(INPUTS['edges'])
        assert len(edges) == 216 and len({edge['transition_id'] for edge in edges}) == 216
        original = {edge_key(edge): edge for edge in edges}
        assert len(original) == 216
        assert len({(edge['before_observation_id'], tuple(edge['action'])) for edge in edges}) == 216
        for edge in edges:
            assert edge['world_sha256'] in opt and edge['branch'] in {'DFF', 'DFF-ALT'}
            assert edge['full_saved_successor_observation_present'] is True
            assert edge['past_teacher_committed_edge_only'] is True
            assert edge['uncommitted_candidate_successor_or_terminal_return_inferred'] is False
        reconstructed = []
        seen_keys = set()
        branch_prefixes = []
        for entry in latches:
            assert time.perf_counter() - started < ready['reader_analysis_bound_seconds_before_frozen_checks_and_seal']
            path = raw_paths[entry['path']]
            assert sha(path) == entry['sha256']
            raw = read(path)
            cost['independent_OPT_raw_branch_read_returns'] += 1
            assert raw['scenario_sha256'] == entry['world_sha256'] and raw['branch'] == entry['branch']
            assert raw['protocol_sha256'] == protocol['input_sha256']['raw_protocol']
            assert raw['independent_all_field_replay_passed_1e10'] is True
            assert raw['base_network_preserved'] is True
            observations = raw['observations']
            assert isinstance(observations, list) and observations
            assert observations[0]['decision'] == 0 and type(observations[0]['decision']) is int
            assert observations[0]['committed_action'] is None
            for observation in observations:
                assert digest(observation['input_observation']) == observation['observation_sha256']
                assert observation['input_observation']['schema_version'] == 1
                cost['independent_exact_observation_ID_checks'] += 1
            prefix_decisions = [observation['decision'] for observation in observations]
            assert all(type(decision) is int for decision in prefix_decisions)
            assert prefix_decisions == list(range(len(observations))) and len(observations) <= 26
            for before, after in zip(observations, observations[1:]):
                before_decision, after_decision = before['decision'], after['decision']
                assert 0 <= before_decision < 25 and after_decision == before_decision + 1
                action = raw_action(after['committed_action'])
                key = (entry['world_sha256'], entry['branch'], before['observation_sha256'],
                       tuple(action), after['observation_sha256'])
                assert key in original and key not in seen_keys
                seen_keys.add(key)
                reconstructed.append({'world_sha256': key[0], 'branch': key[1],
                                      'before_observation_id': key[2], 'action': action,
                                      'after_observation_id': key[4], 'transition_id': original[key]['transition_id'],
                                      'actual_before_decision': before_decision,
                                      'actual_after_decision': after_decision,
                                      'original_selection_iteration': before_decision + 1,
                                      'recorded_remaining_iteration_slots': 25 - before_decision,
                                      'classification': 'INITIAL_ROOT_COMMITMENT' if before_decision == 0 else 'LATER_RECORDED_COMMITMENT',
                                      'full_process_identity': 'UNRESOLVED_NOT_NEEDED_FOR_RELAXED_ABSENCE_PROOF'})
                cost['independent_edge_occurrence_classifications'] += 1
            branch_prefixes.append({'world_sha256': entry['world_sha256'], 'branch': entry['branch'],
                                    'latched_path': entry['path'], 'exact_source_sha256': entry['sha256'],
                                    'observed_decisions': prefix_decisions,
                                    'commitment_occurrences': len(observations) - 1,
                                    'observed_consecutive_prefix_complete': True,
                                    'terminal_success_or_unmeasured_continuations_inferred': False})
        assert len(reconstructed) == 216 and seen_keys == set(original)
        assert len(branch_prefixes) == 46 and sum(row['commitment_occurrences'] for row in branch_prefixes) == 216
        by_id = defaultdict(list)
        for occurrence in reconstructed:
            by_id[occurrence['before_observation_id']].append(occurrence)
        physical_groups = []
        for observation_id, occurrences in sorted(by_id.items()):
            actions = {tuple(row['action']) for row in occurrences}
            if len(actions) > 1:
                physical_groups.append({'before_observation_id': observation_id,
                                        'distinct_actions': [list(action) for action in sorted(actions)],
                                        'occurrences': occurrences,
                                        'contains_later_occurrence': any(row['actual_before_decision'] > 0 for row in occurrences)})
        assert len(physical_groups) == 23
        cost['independent_physical_multiaction_group_classifications'] = len(physical_groups)
        later_groups = sum(group['contains_later_occurrence'] for group in physical_groups)
        initial_occurrences = sum(row['actual_before_decision'] == 0 for row in reconstructed)
        later_occurrences = sum(row['actual_before_decision'] > 0 for row in reconstructed)
        assert initial_occurrences + later_occurrences == 216
        assert len(physical_groups) - later_groups + later_groups == 23
        gate = NO_SUPPORT if later_groups == 0 else POSITIVE_UNKNOWN
        expected = {'all216edges_joined': True, 'all46OPTbranches_retained': True,
                    'all31world_identities_retained_held8unread': True,
                    'physical_multiaction_nodes': len(physical_groups),
                    'initial_only_multiaction_nodes': len(physical_groups) - later_groups,
                    'optimistic_later_multiaction_nodes': later_groups,
                    'initial_commitment_occurrences': initial_occurrences,
                    'later_commitment_occurrences': later_occurrences,
                    'fixed_gate': gate,
                    'absence_proof_scope': 'Any exact complete-process later fork withinthese216edges would also appear in the relaxed physical grouping. No conclusionaboutunmeasuredalternatives or otherdatasets.',
                    'full_process_protected_terminal_rewards_physical_or_LLM_benefit': 'UNMEASURED',
                    'unmeasured_query_receipt_successors_UNKNOWN': unknown,
                    'no_automatic_learning_or_physics': True}
        calls = read(execution / 'Actual_Costs.json')
        assert set(calls) == {'raw_OPT_branch_read_returns', 'new_edge_occurrence_classifications',
                             'new_model_PF_optimizer_controller_forecast_solve_fit_tokenizer_cloud_calls',
                             'old_archive_rehashes', 'workflow_seconds_before_manifest'}
        assert calls['new_model_PF_optimizer_controller_forecast_solve_fit_tokenizer_cloud_calls'] == 0
        assert calls['old_archive_rehashes'] == 0
        assert type(calls['raw_OPT_branch_read_returns']) is int and 0 <= calls['raw_OPT_branch_read_returns'] <= 46
        assert type(calls['new_edge_occurrence_classifications']) is int and calls['new_edge_occurrence_classifications'] in {0, 216}
        assert number(calls['workflow_seconds_before_manifest']) and calls['workflow_seconds_before_manifest'] >= 0
        if not partial:
            compare({'raw_OPT_branch_read_returns': 46, 'new_edge_occurrence_classifications': 216}, calls)
            assert calls['workflow_seconds_before_manifest'] < protocol['bound_seconds']
        for name, expected_rows in [('All_Actual_Edge_Decision_Occurrences.json', reconstructed),
                                    ('All_Optimistic_Physical_Forks.json', physical_groups)]:
            if name in names:
                compare(expected_rows, read(execution / name), name)
            else:
                assert partial
        if 'Results.json' in names:
            result = read(execution / 'Results.json')
            assert stamp(owner['at_utc']) <= stamp(result['at_utc']) <= stamp(closed['at_utc'])
            compare(expected, result)
        else:
            assert partial
        write(out / 'Independent_All216_Exact_Edge_Decision_Occurrences.json', reconstructed)
        write(out / 'Independent_All46_Observed_Consecutive_Prefixes.json', branch_prefixes)
        write(out / 'Independent_All_Exact_Physical_Multiaction_Groups.json', physical_groups)
        proof = {'premise_all216_saved_edges_reconstructed_from46_latched_OPT_raw_sources': True,
                 'premise_exact_physical_IDs_recomputed_without_tolerance_merges': True,
                 'premise_actual_before_after_indices_from_observed_consecutive_prefixes': True,
                 'optimistic_later_multiaction_nodes': later_groups,
                 'strict_process_equivalence_requirement': 'Exact complete process identity implies the same exact stored physical observation ID; every strict process group is a subset of its physical-ID group.',
                 'necessary_condition_argument': 'Any retained strict-process later fork with two distinct committed actions yields an exact physical-ID multiaction group containing a before-decision greater than zero. Its absence excludes such a strict-process fork in these retained edges.',
                 'necessary_absence_condition_certified': not partial and later_groups == 0,
                 'positive_relaxed_fork_is_full_process_certificate': False,
                 'proof_scope': 'The proposed paired-continuation coordinator supervision using these 216 exact retained guarded OPT edges in 23 worlds only.',
                 'all31_original_world_ids_retained': True, 'held8_branch_outcomes_read': False,
                 'unmeasured_receipt_successors': {'count': unknown, 'state': 'UNKNOWN'},
                 'full_process_caps_memory_history_solver_state': 'DELIBERATELY_RELAXED_UNRESOLVED',
                 'unmeasured_alternatives_protected_terminal_rewards': 'UNKNOWN',
                 'scientific_benefit_novelty_universal_failure_nonmyopic_or_learning_impossibility': 'NOT_CERTIFIED',
                 'no_negative_physical_or_LLM_result': True}
        write(out / 'Independent_Necessary_Condition_Proof.json', proof)
        report = {'all_passed': True,
                  'gate': 'UNKNOWN_OWNER_PARTIAL_NO_RETRY' if partial else gate,
                  'producer_complete_outcome_certified': not partial,
                  'producer_closed_member_count': len(closed['members']),
                  'independently_derived': expected,
                  'exact_physical_ID_necessary_condition_only': True,
                  'all31_world_ids_retained_OPT23_held8_unread': True,
                  'partial_failed_outputs_preserved': True,
                  'scientific_retry_or_automatic_training_authorized': False,
                  'scientific_benefit_novelty_universal_failure': 'NOT_CERTIFIED'}
        assert not any(module == 'torch' or module == 'transformers' or module.startswith('pandapower')
                       or module.startswith('sklearn') for module in sys.modules)
    except BaseException as error:
        failure = error
        report = {'all_passed': False, 'gate': 'INDEPENDENT_AUDIT_FAIL_NO_RETRY',
                  'error': repr(error), 'traceback': traceback.format_exc(),
                  'partial_failed_outputs_preserved': True, 'no_scientific_retry': True,
                  'scientific_benefit_novelty_universal_failure': 'NOT_CERTIFIED'}
    # One existing frozen-check call and one NEW archive only, even on audit failure.
    cost['frozen_check_invocations'] = 1
    try:
        fresh = frozen_checks()
        assert set(fresh['checks']) == FROZEN_CHECK_NAMES and len(fresh['checks']) == 9
        assert fresh['all_passed'] is True and all(fresh['checks'].values())
    except BaseException as error:
        if failure is None:
            failure = error
        fresh = {'all_passed': False, 'error': repr(error), 'traceback': traceback.format_exc(),
                 'single_invocation': True, 'new_model_or_PF_calls': 0}
        report.update({'all_passed': False, 'gate': 'INDEPENDENT_AUDIT_FAIL_NO_RETRY',
                       'frozen_check_error': repr(error), 'no_scientific_retry': True})
    write(out / 'Fresh_Frozen_Asset_Checks.json', fresh)
    write(out / 'Independent_Audit.json', report)
    cost['workflow_seconds_before_seal'] = time.perf_counter() - started
    cost['new_archive_seal_invocations'] = 1
    write(out / 'Actual_Reader_Costs.json', cost)
    files = {path.name: path for path in out.iterdir() if path.is_file()}
    files.update({'sources/reader.py': Path(__file__), 'sources/production.py': PRODUCTION,
                  'sources/reader_readiness.json': READY, 'sources/evidence_utils.py': UTILS})
    for role, path in SOURCES.items():
        files['sources/frozen_contract_' + role + '.py'] = path
    for directory, label in ((prep, 'preparation'), (execution, 'execution')):
        for path in directory.iterdir():
            if path.is_file():
                files[label + '/' + path.name] = path
    for role, path in INPUTS.items():
        files['locked_existing_inputs/' + role + '_' + path.name] = path
    for relative, path in raw_paths.items():
        files['latched_OPT_raw/' + path.name] = path
    try:
        archive = seal(out, files, 'Independent_Exact_Relaxed_Later_Fork_Support.zip')
        assert archive['CRC_and_every_member_hash_passed'] is True
    except BaseException as error:
        write(out / 'Archive_Seal_Failure_NO_RETRY.json', {'at_utc': now(), 'error': repr(error),
                                                        'traceback': traceback.format_exc(),
                                                        'single_seal_attempt': True,
                                                        'partial_archive_preserved': True})
        raise
    final_cost = {'at_utc': now(), 'workflow_seconds_including_frozen_checks_and_new_archive': time.perf_counter() - started,
                  'frozen_check_invocations': 1, 'new_archive_seal_invocations': 1,
                  'new_science_or_frozen_controller_function_calls': 0, 'old_archive_rehashes': 0,
                  'held_branch_read_returns': 0, 'all_analysis_and_IO_paid': True,
                  'final_cost_record_outside_archive_to_avoid_self_reference': True}
    write(out / 'Actual_Reader_Final_Workflow_Cost.json', final_cost)
    print(canonical({'audit': report, 'archive': archive, 'final_cost': final_cost}))
    if failure is not None:
        raise RuntimeError('Independent audit failed; evidence retained once, no retry') from failure


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-authorized', action='store_true')
    arguments = parser.parse_args()
    assert arguments.execute_authorized, 'Closed producer and prospective source/readiness lock required'
    run()
