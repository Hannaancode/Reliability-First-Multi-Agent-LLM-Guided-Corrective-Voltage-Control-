# Verified TRAIN trajectory package

The embedded original scientific archive is byte-for-byte preserved. Its original manifest used Windows backslashes in some source keys while the ZIP writer normalized entry names to forward slashes. This wrapper supplies the canonical member manifest and the bijective normalization certificate. Every original scientific member was verified for exact bytes/SHA256 and the archive passed CRC. No scientific content, label, case, method, cost or result changed; no simulation/model call was rerun.

Extract Original_Scientific_Archive.zip, then use Canonical_Scientific_Member_Manifest.json for its member identities. The embedded Supplement_Manifest.json is preserved historical metadata. Independent state/scope/selection/cost and nine frozen-asset checks are included. Original failed audit logs remain in the workspace.

This dataset passes the prospective target-support gate for method design only. It is historical TRAIN development data, not trained LLM performance, novelty, independent confirmation or established superiority.
