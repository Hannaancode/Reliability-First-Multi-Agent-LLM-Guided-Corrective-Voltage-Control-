"""Fixed saved-score OPT diagnosis. No inference, optimizer, physics or cloud."""
import candidate_process_runtime
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
import os
import time
import torch

from candidate_process_evidence_utils import ROOT, read, sha, write, seal
from native_decision_preference_objective import native_decision_order

P = ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
A = P/'lm_audit'
PREP = P/'learning_preparation'
OUT = P/'closed_learning_OPT_mechanism_diagnostic'
assert not OUT.exists()
assert read(A/'Independent_Actual_Learning_Audit.json')['all_passed']
assert not read(A/'Fixed_Prospective_Gate_Decision.json')['all_fixed_development_gates_passed']
inputs = [r for r in read(PREP/'Input_Index.json') if r['split']=='optimization']
targets = {r['observation_id']:r for r in read(PREP/'Target_Index.json') if r['split']=='optimization'}
assert len(inputs)==239 and len(targets)==187
OUT.mkdir()
write(OUT/'owner.claim', {'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
started = time.perf_counter()
torch.set_num_threads(2)
protocol = {
    'declared_at_utc':datetime.now(timezone.utc).isoformat(),
    'posthoc_descriptive_not_confirmatory_or_causal':True,
    'scope':'All187 measured OPT states; both fixed final epoch5 arms; no held-target diagnosis or outcome-selected subset',
    'full_239_OPT_input_and_52_unknown_denominators_retained':True,
    'fixed_analysis':'Known classifier confusion at original zero threshold; stored native best-versus-other margins; original decoder anchor rank/priority; per-epoch actual loss components; selected/anchor Q histograms',
    'no_alternate_threshold_decoder_checkpoint_model_or_performance_test':True,
    'no_new_inference_optimizer_PF_controller_cloud_calls':True,
    'recorded_gate_failure_stays_STOP':True,
    'source_sha256':sha(__file__),
    'fixed_decoder_sha256':sha(ROOT/'work/native_decision_preference_objective.py'),
    'original_learning_protocol_sha256':sha(PREP/'protocol.json'),
    'original_results_sha256':sha(A/'Actual_All_Arm_Results.json'),
    'target_ids':sorted(targets),
}
write(OUT/'Analysis_Protocol.json', protocol)
all_diags = read(A/'All622_Final_State_Diagnostics.json')
answers = {}
states = {}
for arm, folder in (('internal_residual','lm_i'), ('frozen_capacity_head','lm_f')):
    S = P/folder/'staged/study'
    manifest = read(S/'Closed_Actual_Manifest.json')
    stored = {}
    for f in sorted((S/'final').glob('p*.pt')):
        m = manifest[str(f.relative_to(S)).replace('\\','/')]
        assert f.stat().st_size==m['bytes'] and sha(f)==m['sha256']
        block = torch.load(f, weights_only=True)
        assert not set(stored).intersection(block)
        stored.update(block)
    assert len(stored)==311
    actual_by = {r['observation_id']:r for r in all_diags[arm]}
    rows = []
    for inp in inputs:
        ident = inp['observation_id']
        if ident not in targets:
            continue
        target = targets[ident]
        assert sha(PREP/target['target_file'])==target['sha256']
        assert sha(PREP/inp['input_file'])==inp['sha256']
        t = torch.load(PREP/target['target_file'], weights_only=True)
        x = torch.load(PREP/inp['input_file'], weights_only=False)['model_input']
        pred = stored[ident]['prediction']
        assert pred.shape==(118,9,3) and bool(torch.isfinite(pred).all())
        allowed = torch.tensor(x['allowed_actions'], dtype=torch.bool)
        order = native_decision_order(pred,allowed)
        old = actual_by[ident]['diagnostic']
        assert [list(v) for v in order[:4]]==old['topK']['4']['selected_actions']
        confusion = {}
        for channel,name in enumerate(('native_accepted','recorded_convergence')):
            mask = t['classification_mask'][...,channel]
            known = t['classification'][...,channel][mask].bool()
            guessed = pred[...,channel][mask]>=0
            confusion[name] = {
                'known':int(mask.sum()),'positive':int(known.sum()),'predicted_positive':int(guessed.sum()),
                'true_positive':int((known&guessed).sum()),'false_positive':int((~known&guessed).sum()),
                'true_negative':int((~known&~guessed).sum()),'false_negative':int((known&~guessed).sum()),
            }
        pair = t['preference_pairs']
        pair_stats = None
        if len(pair):
            anchors = {(int(b),int(q)) for b,q in pair[:,:2]}
            assert len(anchors)==1
            b,q = next(iter(anchors))
            margin = pred[pair[:,0],pair[:,1],2]-pred[pair[:,2],pair[:,3],2]
            anchor_flag = bool((pred[b,q,:2]>=0).all())
            flags = (pred[...,:2]>=0).all(-1)
            pair_stats = {
                'pairs':len(pair),'strictly_correct_rank_pairs':int((margin>0).sum()),
                'state_pair_satisfaction':float((margin>0).float().mean()),
                'anchor':[b,q],'anchor_predicted_both_classifiers_positive':anchor_flag,
                'anchor_fixed_decoder_rank':order.index((b,q)),
                'correct_rank_pairs_but_lower_classifier_priority':int(((margin>0)&(not anchor_flag)&flags[pair[:,2],pair[:,3]]).sum()),
            }
        rows.append({'observation_id':ident,'world_sha256':inp['world_sha256'],
                     'classifiers':confusion,'native_pair':pair_stats,'original_top4':old['topK']['4']})
    assert len(rows)==187
    events_file = S/'events.jsonl'
    assert sha(events_file)==manifest['events.jsonl']['sha256']
    events = [json.loads(line) for line in events_file.read_text(encoding='utf8').splitlines()]
    epochs = {}
    for epoch in range(1,6):
        ee = [e for e in events if e['event']=='optimizer_return' and e['epoch']==epoch]
        native = [e for e in ee if e['loss_terms']['native_supervision']]
        assert len(ee)==239 and len(native)==187
        epochs[str(epoch)] = {
            'all_current_grounding_mean':sum(e['loss_terms']['current_grounding'] for e in ee)/239,
            'native_classification_mean':sum(e['loss_terms']['classification'] for e in native)/187,
            'native_pairwise_mean':sum(e['loss_terms']['native_pairwise_rank'] for e in native)/187,
        }
    pp = [r['native_pair'] for r in rows if r['native_pair']]
    by_world = defaultdict(list)
    for r in rows:
        if r['native_pair']:
            by_world[r['world_sha256']].append(r['native_pair']['state_pair_satisfaction'])
    q_selected = Counter(q for r in rows for _,q in r['original_top4']['selected_actions'])
    q_anchors = Counter(v['anchor'][1] for v in pp)
    totals = {name:{key:sum(r['classifiers'][name][key] for r in rows)
                    for key in rows[0]['classifiers'][name]}
              for name in ('native_accepted','recorded_convergence')}
    answers[arm] = {
        'all_OPT_inputs':239,'measured_OPT_states':187,'unlabelled_OPT_inputs':52,
        'actual_epoch_losses':epochs,'classifier_confusion':totals,
        'native_pair_states':len(pp),'native_pairs':sum(v['pairs'] for v in pp),
        'strictly_correct_rank_pairs':sum(v['strictly_correct_rank_pairs'] for v in pp),
        'equal_world_state_pair_satisfaction':sum(sum(v)/len(v) for v in by_world.values())/len(by_world),
        'anchors_predicted_both_classifiers_positive':sum(v['anchor_predicted_both_classifiers_positive'] for v in pp),
        'correct_rank_but_lower_priority_pairs':sum(v['correct_rank_pairs_but_lower_classifier_priority'] for v in pp),
        'top4_selected_Q_index_histogram':dict(sorted(q_selected.items())),
        'native_anchor_Q_index_histogram':dict(sorted(q_anchors.items())),
        'fixed_top4_known_rejected':sum(r['original_top4']['known_rejected'] for r in rows),
        'fixed_top4_known_selected':sum(r['original_top4']['known_measured'] for r in rows),
    }
    states[arm] = rows
write(OUT/'All374_OPT_Saved_State_Diagnostics.json',states)
write(OUT/'Summary.json',{'completed_at_utc':datetime.now(timezone.utc).isoformat(),
    'posthoc_descriptive_not_causal':True,'actual_results':answers,
    'actual_new_inference_optimizer_PF_controller_cloud_calls':0,
    'no_held_diagnostic_or_alternate_policy_test':True,
    'all_fixed_performance_gates_and_STOP_decision_preserved':True,
    'reader_seconds':time.perf_counter()-started})
seal(OUT, {p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'} |
     {'source/diagnosis.py':ROOT/'work/diagnose_closed_relational_learning_OPT.py'}, 'OPT_Saved_Mechanism_Diagnostic.zip')
write(OUT/'status.json',{'stage':'complete_readonly_OPT_diagnosis','new_model_PF_calls':0})
print(json.dumps(answers,indent=2))
