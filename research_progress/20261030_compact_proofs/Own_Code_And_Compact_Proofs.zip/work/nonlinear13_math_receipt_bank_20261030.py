"""Preserved first-entry numerical proposals; no CLI or automatic campaign.

Uses the unchanged, real-tested v3 numerical recipe. A genuine frozen owner,
complete current-state cursor, exact input/source identity and durable global
claim are required. Known paid proposals are reused; failed/unreturned claims
are never silently retried. This module has no physical or model entry point.
"""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,os,time,traceback
import numpy as np
from nonlinear13_receding_policy_engine_20261029 import typed,canonical,read_ref,MECHANISM_SOURCES
from nonlinear13_current_state_v2_20261030 import load_current_state
from remaining85_certified_loader_20261029 import load_certified_case
from nonlinear13_preserved_solver_v3_20261029 import RECIPE,PersistentCalculationJournal,solve_once,safe_record

SOURCE='work/nonlinear13_math_receipt_bank_20261030.py'
SCHEMA='NONLINEAR13_MATH_RECEIPT_V1'
FIELDS=['Y','V_current','ppc_bus','ppc_gen','baseMVA','lookup','control','current_vm','current_q','control_scaling','control_in_service']
ADMISSION_FIELDS=['enforce_q_lims','distributed_slack']
PINNED_RUNTIME=['work/physics_env/Lib/site-packages/scipy/optimize/_slsqp_py.py',
 'work/physics_env/Lib/site-packages/scipy/optimize/_slsqplib.cp312-win_amd64.pyd',
 'work/physics_env/Lib/site-packages/scipy/optimize/_minimize.py']

def need(value,message):
 if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def identity_payload(model,sources):
 return {'state':{n:typed(getattr(model,n)) for n in FIELDS},'initial_vector':typed(model.initial_vector()),
   'recipe':RECIPE,'mechanism_sources':{p:sources[p] for p in MECHANISM_SOURCES}}
def context_key(model,sources):return sha(canonical(identity_payload(model,sources)))
def file_ref(root,path):
 p=Path(path).resolve();p.relative_to(Path(root).resolve());raw=p.read_bytes()
 return dict(path=p.relative_to(Path(root).resolve()).as_posix(),sha256=sha(raw),bytes=len(raw))
def write_json(root,path,value):
 raw=(json.dumps(safe_record(value),indent=2,allow_nan=False)+'\n').encode('utf-8')
 with Path(path).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 return file_ref(root,path)

def import_first_paid(root,protocol):
 refs=protocol['first_paid_math']
 p=json.loads(read_ref(root,refs['protocol']))
 proposal=json.loads(read_ref(root,refs['proposal']))
 audit=json.loads(read_ref(root,refs['independent_reader']))
 closed=json.loads(read_ref(root,refs['closed_manifest']))
 files={r['path']:r['sha256'] for r in closed['files']}
 need(files['Proposal_Result.json']==refs['proposal']['sha256'],'First proposal not closed')
 need(p['seed']==0 and p['recipe']==RECIPE,'First proposal role/recipe mismatch')
 need(proposal['status']=='ADMITTED_UNMEASURED_PROPOSAL' and
   audit['status']=='PASS_FIRST_SAVED_NUMERICAL_PROPOSAL_AND_COST_EVIDENCE','First proposal lacks exact independent admission')
 for path in MECHANISM_SOURCES+PINNED_RUNTIME:need(p['sources_and_gates'][path]==protocol['sources'][path],'Historical mechanism/runtime changed')
 model,binding=load_certified_case(root,0)
 need(binding['pack']==p['input_pack'] and binding['root']==p['input_root'],'Historical first current-state input mismatch')
 key=context_key(model,protocol['sources'])
 return {key:dict(context_key=key,proposal=proposal,proposal_ref=refs['proposal'],reader_ref=refs['independent_reader'],
   input_binding_verified=True,independent_verification='PASS',retained_prior_cost_references=refs)}

class NumericalReceiptBank:
 def __init__(self,root,output_directory,owner,known_paid=None):
  self.root=Path(root).resolve();self.owner=owner;self.sources=copy.deepcopy(owner.protocol['sources'])
  self.out=(self.root/output_directory).resolve();self.out.relative_to(self.root)
  need(owner.protocol['recipe']==RECIPE,'Numerical recipe changed')
  need(owner.protocol.get('new_math_mode')=='SOURCE_ORDER_RECEDING_FIXED_RECIPE','No prospective numerical owner admission')
  need(owner.protocol.get('new_PF_entry_enabled') is False,'Numerical adapter cannot authorize physical entry')
  need(owner.ack['actual_pid']==os.getpid() and owner.ack['actual_parent_pid']==os.getppid(),'Foreign owner')
  need(json.loads(read_ref(self.root,owner.protocol_ref))==owner.protocol,'Unbound owner protocol')
  for source in [SOURCE,*MECHANISM_SOURCES,*PINNED_RUNTIME,'work/nonlinear13_receding_policy_engine_20261029.py','work/nonlinear13_current_state_20261029.py','work/nonlinear13_current_state_v2_20261030.py']:
   need(source in self.sources,'Unpinned numerical dependency: '+source)
   read_ref(self.root,dict(path=source,sha256=self.sources[source]))
  owner.check();self.out.mkdir(exist_ok=False)
  self.claims=self.root/'outputs/nonlinear13_math_identity_claims_20261030';self.claims.mkdir(exist_ok=True)
  self.paid=import_first_paid(self.root,owner.protocol);self.entered=set();self.pending_success={}
  if known_paid is not None:
   need(set(known_paid)==set(self.paid),'Unadmitted additional historical math cache')
   for key,row in known_paid.items():need(row['proposal_ref']==self.paid[key]['proposal_ref'],'Caller historical proposal differs')
  need(bool(self.paid),'Mandatory historical firstproposal import missing')
  for key,row in self.paid.items():
   need(key==row['context_key'],'Paid proposal key mismatch')
   actual=json.loads(read_ref(self.root,row['proposal_ref']))
   audit=json.loads(read_ref(self.root,row['reader_ref']))
   need(actual==safe_record(row['proposal']) and actual['status']=='ADMITTED_UNMEASURED_PROPOSAL','Paid proposal not exact/admitted')
   need(str(audit['status']).startswith('PASS'),'Paid proposal lacks independent PASS')
   need(row.get('input_binding_verified') is True,'Paid source/input binding must be independently imported')

 def resolve(self,model,complete_preproposal_cursor_ref,seed,step):
  need(type(seed) is int and 0<=seed<500 and type(step) is int and 1<=step<=100,'Changed population/horizon')
  cursor_model,cursor=load_current_state(self.root,complete_preproposal_cursor_ref)
  self.owner.check(cursor)
  need(cursor['seed']==seed and cursor['next_step']==step,'Numerical cursor identity mismatch')
  payload=identity_payload(model,self.sources);key=sha(canonical(payload))
  need(identity_payload(cursor_model,self.sources)==payload,'Numerical model differs from preserved current cursor')
  need(not model.costs and not cursor_model.costs,'A previously evaluated model cannot enter as a fresh proposal')
  if key in self.paid:
   return dict(kind='PAID_MATH_REUSE',context_key=key,record=copy.deepcopy(self.paid[key]),new_optimizer_calls=0)
  if key in self.pending_success:
   return dict(kind='CURRENT_OWNER_MATH_REUSE_AUDIT_PENDING',context_key=key,
     record=copy.deepcopy(self.pending_success[key]),independent_verification='PENDING_FIRST_READER',new_optimizer_calls=0)
  need(not(seed==0 and step==1),'Original seed0step1 is mandatory paid reuse, never fresh execution')
  claim=self.claims/(key+'.json')
  need(key not in self.entered and not claim.exists(),'Prior attempted numerical identity: UNKNOWN, no retry')
  claim_data=dict(schema=SCHEMA,context_key=key,owner_protocol_ref=self.owner.protocol_ref,
    actual_pid=os.getpid(),parent_pid=os.getppid(),created_at_utc=datetime.now(timezone.utc).isoformat(),
    input_cursor=complete_preproposal_cursor_ref,status='RESERVED_BEFORE_ANY_NEW_NUMERICAL_CALL',
    scope='No automatic retry if setup/return/closure fails; source and outcome preserved')
  # The exclusive claim, rather than the non-atomic exists check, owns identity.
  claim_ref=write_json(self.root,claim,claim_data);self.entered.add(key)
  directory=self.out/key;directory.mkdir(exist_ok=False)
  binding=dict(all_required_current_state_checks_passed=True,seed=seed,step=step,context_key=key,
    complete_preproposal_cursor_ref=complete_preproposal_cursor_ref,owner_protocol_ref=self.owner.protocol_ref,
    proposal_identity_payload=payload,actual_current_NET=cursor['current_NET'],original_deadline_monotonic=self.owner.deadline)
  start=time.monotonic();journal=None;proposal=None;failure=None;proposal_ref=None
  packpath=directory/'Input_Model.npz'
  with packpath.open('xb') as f:
   np.savez(f,**{n:np.asarray(getattr(model,n)).copy() for n in FIELDS+ADMISSION_FIELDS});f.flush();os.fsync(f.fileno())
  input_ref=file_ref(self.root,packpath)
  journal_path=directory/'calculations.jsonl'
  cap=self.owner.protocol['per_proposal_journal_byte_cap']
  need(type(cap) is int and cap>0,'Invalid fixed numerical preservation cap')
  try:
   self.owner.check(cursor)
   journal=PersistentCalculationJournal(journal_path,self.owner.deadline,cap)
   proposal=solve_once(model,journal,binding)
   proposal_ref=write_json(self.root,directory/'Proposal.json',proposal)
  except BaseException as exc:
   failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
  finally:
   if journal is not None:journal.close()
  # Closure is mechanical preservation; it may occur after the absolute science
  # deadline, with no further equation/optimizer/PF/model entry.
  if not journal_path.exists():
   with journal_path.open('xb') as f:f.flush();os.fsync(f.fileno())
  raw=journal_path.read_bytes()
  committed_bytes=journal.bytes if journal is not None else 0
  if len(raw)!=committed_bytes and failure is None:
   failure=dict(type='JournalClosureError',message='Actual journal differs from acknowledged durable prefix; UNKNOWN, never retry')
  primary=dict(status='RETURNED_FIXED_NUMERICAL_RESULT' if failure is None else 'FAILED_OR_PARTIAL_NO_RETRY',
    context_key=key,workflow_seconds=time.monotonic()-start,journal_last_sha256=journal.previous if journal is not None else '0'*64,
    journal_events=journal.calls if journal is not None else 0,journal_bytes=len(raw),journal_committed_bytes=committed_bytes,
    kernel_costs=model.costs.copy(),failure=failure,physical_model_GPU_calls=0,
    cost_limits='Every entered native/library callback is journaled; unresolved internal factors/linear solves remain UNKNOWN, not free.')
  primary_ref=write_json(self.root,directory/'Primary.json',primary)
  receipt=dict(schema=SCHEMA,status=primary['status'],context_key=key,sources=self.sources,input_pack=input_ref,
    journal=file_ref(self.root,journal_path),primary=primary_ref,proposal=proposal_ref,source_input_binding=binding,
    attempt_claim=claim_ref,owner_protocol_ref=self.owner.protocol_ref)
  receipt_ref=write_json(self.root,directory/'Receipt.json',receipt)
  result=dict(kind='NEW_FIXED_NUMERICAL_RECEIPT',context_key=key,receipt_ref=receipt_ref,
    proposal=safe_record(proposal),status=primary['status'],failure=failure,
    candidate_admitted=bool(failure is None and proposal and proposal.get('status')=='ADMITTED_UNMEASURED_PROPOSAL'),
    independent_verification='PENDING_FIRST_READER',new_PF_permitted=False)
  # Failed or partial returns remain globally claimed. Only completed numerical
  # returns may be reused by this same immutable recipe/context in this owner.
  if result['candidate_admitted']:
   self.pending_success[key]=dict(context_key=key,proposal=safe_record(proposal),proposal_ref=proposal_ref,
    reader_ref=None,receipt_ref=receipt_ref,input_binding_verified=True,independent_verification='PENDING_FIRST_READER')
  return result

if __name__=='__main__':raise SystemExit('No experiment CLI; source-frozen owner integration and first reader required.')
