"""Close saved read-only evidence and update exact task state; no science."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib
R=Path(__file__).resolve().parents[1]
def read(p): return json.loads((R/p).read_text('utf-8-sig'))
def save(p,v): (R/p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256((R/p).read_bytes()).hexdigest()
now=datetime.now(timezone.utc).isoformat()
base='outputs/graph118_current_history_admission_20261028/'
a=read(base+'audit/Result.json'); b=read(base+'build/Result.json')
assert a['status']=='PASS_INDEPENDENT_ALL4_HISTORY_DECISION_CHECK'
assert a['builder_result_sha256']==sha(base+'build/Result.json')
for stage in ['build','audit']:
    end=read(base+stage+'/End_ACK.json'); assert end['exit_code']==0 and end['actual_owned_chain_ended']
completion=dict(at_utc=now,status='COMPLETE_SCOPED_NEXT_INPUT_HISTORY_ADMISSION_ALL4',
    builder_sha256=sha(base+'build/Result.json'),reader_sha256=sha(base+'audit/Result.json'),
    cases=[dict(case_id=r['case_id'],source_action=r['source_action'],status=r['status']) for r in a['rows']],
    new_PF_model_converter_training_calls=0,remaining=a['remaining'],scope=a['scope'])
p=R/(base+'Verified_Completion.json'); assert not p.exists(); save(p.relative_to(R),completion)
t=read('outputs/thesis_research_closure_20261028/Tasks.json')
review='outputs/closest_llm_control_review_20261028/Review_And_Admission.md'
for row in t['tasks']:
    if row['id'] in ['T25','T31']:
        row['status']='FOCUSED_FIVE_PRIMARY_SOURCE_REVIEW_SAVED_THESIS_INTEGRATION_OPEN'
        row['evidence']=list(dict.fromkeys(row.get('evidence',[])+[review]))
        row['limitation']='Not exhaustive; source availability and interface admission differ; no executed new method score.'
t['updated_utc']=now;save('outputs/thesis_research_closure_20261028/Tasks.json',t)
r=read('outputs/research_resumption_20261028/Current_Resume.json')
r.update(at_utc=now,graph_next_input_history=base+'Verified_Completion.json',closest_literature=review)
r['parallel_completed'].append('All4 next source-selected GraphAgent input identities passed enlarged-history independent check;0newphysics. Five closest LLM-control/QA primary records and four pinned repositories added; exact FLARE substrates absent, VeraGridQA candidate only.')
save('outputs/research_resumption_20261028/Current_Resume.json',r)
with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
    f.write(f'\n{now} — G3/G2/T25/T31: closed all4 source-selected next GraphAgent history inputs against14479closedrecords and retained tracked scope. Both read-only actors ended/PASS;0PF/model. This is admission only; full episode protocol/reader remains required. Added five versioned closest-method primary papers/four pinned repos. FLARE exact substrate/panels are not in pinned repo; VeraGrid150QA is a candidate new role, no model benchmark run or test labels inspected. Novelty limits documented. All6goalsOPEN;8/35requirementscomplete.\n')
print(json.dumps(dict(graph_history='COMPLETE_ALL4_SCOPED_PASS',new_science=0,focused_review_sources=5)))
