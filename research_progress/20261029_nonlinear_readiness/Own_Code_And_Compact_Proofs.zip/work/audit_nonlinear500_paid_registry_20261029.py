"""Bounded saved-JSON registry audit; never imports or runs the producer.

Hashes generated registry metadata and selected source/certificate JSON only.
Does not open binary capsules, deserialize NETs, rebuild history, or run science.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import ast
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
REG = ROOT / 'outputs/nonlinear500_paid_registry_20261029'
OUT = ROOT / 'outputs/nonlinear500_paid_registry_independent_20261029'
SOURCE = 'work/nonlinear500_paid_registry_20261029.py'
read_bindings = {}


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    read_bindings[path.relative_to(ROOT).as_posix()] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return json.loads(raw)


def key(signature, kwargs): return signature + '|' + json.dumps(kwargs, sort_keys=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    frozen = read(REG / 'Frozen_Registry_Manifest.json')
    documents = {}
    for name, binding in frozen.items():
        if name == 'builder_source':
            raw = (ROOT / binding['path']).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == binding['sha256']
            read_bindings[binding['path']] = {'sha256': binding['sha256'], 'bytes': len(raw)}
        else:
            documents[name] = read(REG / name)
            found = read_bindings[(REG / name).relative_to(ROOT).as_posix()]
            assert found == binding
    registry = documents['Paid_Physical_Registry.json']; entries = registry['entries']
    denied = registry['signature_deny_provenance']; result = documents['Result.json']
    bindings = documents['Source_Bindings.json']; roots = documents['Exact_All500_Roots.json']['roots']
    aliases = documents['Canonical_Namespace_Aliases.json']
    allowed = [{'algorithm': 'bfsw'}, {'algorithm': 'bfsw', 'init': 'dc'}]
    counts = Counter(); certificates = set()
    for k, entry in entries.items():
        sig, kwargs = entry['physical_signature'], entry['kwargs']
        assert re.fullmatch('[0-9a-f]{64}', sig) and kwargs in allowed and k == key(sig, kwargs)
        assert sig in denied and entry['block_new_PF'] is True and entry['provenance']
        counts[entry['status']] += 1
        if entry['reuse'] is None:
            assert entry['status'] == 'BLOCKED_ATTEMPTED_NO_COMPLETE_REUSE_CAPSULE'
        else:
            assert entry['status'] == 'REUSABLE_AUDITED_EXACT_KEY'
            for name in ['after', 'fields']:
                d = entry['reuse'][name]
                assert re.fullmatch('[0-9a-f]{64}', d['sha256']) and d['bytes'] > 0
                (ROOT / d['path']).resolve().relative_to(ROOT)
            cert = entry['reuse']['independent_certificate']; assert cert in bindings
            certificates.add(cert)
    for cert in sorted(certificates):
        doc = read(ROOT / cert)
        assert read_bindings[cert]['sha256'] == bindings[cert]['sha256']
        assert str(doc.get('status', '')).startswith('PASS')
    assert dict(counts) == result['status_counts'] and len(entries) == result['exact_initializer_keys'] == 11355
    assert len(denied) == result['physical_signature_deny_count'] == 11355

    original_path = 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json'
    original = read(ROOT / original_path)['roots']
    assert read_bindings[original_path]['sha256'] == bindings[original_path]['sha256']
    assert [r['seed'] for r in roots] == list(range(500))
    for current, old in zip(roots, original):
        assert all(current[k] == v for k, v in old.items())
        k = key(current['physical_signature'], {'algorithm': 'bfsw'})
        assert current['exact_paid_root_key'] == k and entries[k]['reuse'] is not None
        assert current['initialization_kwargs'] == {'algorithm': 'bfsw'}
        assert current['capsule_binding']['path'] == current['path']
        assert current['capsule_binding']['sha256'] == current['sha256']
        assert current['source'] == original_path and current['source_pointer'] == '/roots/' + str(current['seed'])

    blocked = {k: e for k, e in entries.items() if e['reuse'] is None}
    assert len(blocked) == 1
    blocked_key, block = next(iter(blocked.items()))
    assert blocked_key == result['gaps'][0]['key'] and result['gaps'][0]['id'] == 'NATIVE15_NO_AFTER_NET'
    assert any(p['status'] == 'RETURNED_AUDITED_WITHOUT_SAVED_AFTER_NET' for p in block['provenance'])
    assert block['physical_signature'] in denied and block['block_new_PF']

    root0 = roots[0]; entry0 = entries[root0['exact_paid_root_key']]
    assert entry0['reuse']['after']['sha256'] == root0['sha256']
    unclosed = [p for p in entry0['provenance'] if p.get('status') == 'ATTEMPTED_WITHOUT_PRIMARY_RETURN_EVENT'
                or p.get('original_status') == 'ATTEMPTED_WITHOUT_PRIMARY_RETURN_EVENT']
    assert unclosed and any('independent_recovery_certificate' in p or 'recovery' in p for p in unclosed)
    tiny_journal_path = ROOT / 'outputs/stable_ddpg_native_engineering_20261020/Journal.jsonl'
    tiny_raw = tiny_journal_path.read_bytes()
    assert len(tiny_raw) < 100000
    tiny_rows = [json.loads(line) for line in tiny_raw.splitlines()]
    tiny_kinds = Counter(v.get('event', v).get('kind') for v in tiny_rows)
    assert tiny_kinds['PF_attempt'] == 1 and tiny_kinds['PF_return'] == tiny_kinds['PF_exception'] == 0
    read_bindings[tiny_journal_path.relative_to(ROOT).as_posix()] = {'sha256': hashlib.sha256(tiny_raw).hexdigest(), 'bytes': len(tiny_raw)}
    for alias in aliases:
        k = key(alias['canonical_signature'], alias['kwargs'])
        assert k in entries and alias['kwargs'] in allowed
        assert alias['old_namespace_signature'] != alias['canonical_signature']
    assert all('|' in k for k in entries)

    fresh_path = 'outputs/public13_fresh_router_execution_20261022/Result.json'
    fresh = read(ROOT / fresh_path)
    assert read_bindings[fresh_path]['sha256'] == bindings[fresh_path]['sha256']
    assert fresh['status'] == 'TERMINAL_PARTIAL_FRESH128_ACTUAL_ROUTING'
    assert len(fresh['worlds']) == result['fresh128_entered_worlds'] == 55
    assert fresh['unentered_seeds'] == result['fresh128_unentered_seeds'] and len(fresh['unentered_seeds']) == 73
    fresh_receipts = fresh['receipts']; assert len(fresh_receipts) == 1179
    for receipt in fresh_receipts:
        k = key(receipt['physical_signature'], receipt['kwargs'])
        assert k in entries and receipt['status'] == 'RETURNED'
        assert any(p.get('source') == fresh_path and p.get('status') == receipt['status'] for p in entries[k]['provenance'])
    assert result['universal_history_complete'] is False and result['new_PF_authorized'] is False

    # Independent metadata decision table; does not claim capsule bytes verified.
    def disposition(sig, kwargs):
        e = entries.get(key(sig, kwargs))
        if e and e['reuse']: return 'METADATA_ELIGIBLE_PENDING_SELECTED_PAYLOAD_HASH'
        if sig in denied: return 'BLOCKED_KNOWN_SIGNATURE'
        return 'FINITE_SCOPE_MISS_NOT_AUTHORIZATION'
    checks = [
        {'name': 'exact_root_key', 'status': disposition(root0['physical_signature'], {'algorithm': 'bfsw'})},
        {'name': 'different_initializer', 'status': disposition(root0['physical_signature'], {'algorithm': 'bfsw', 'init': 'results'})},
        {'name': 'missing_after_NET', 'status': disposition(block['physical_signature'], block['kwargs'])},
        {'name': 'unseen_signature', 'status': disposition('0' * 64, {'algorithm': 'bfsw', 'init': 'dc'})},
    ]
    assert [x['status'] for x in checks] == ['METADATA_ELIGIBLE_PENDING_SELECTED_PAYLOAD_HASH', 'BLOCKED_KNOWN_SIGNATURE', 'BLOCKED_KNOWN_SIGNATURE', 'FINITE_SCOPE_MISS_NOT_AUTHORIZATION']
    source_tree = ast.parse((ROOT / SOURCE).read_text(encoding='utf-8'))
    lookup = next(n for n in source_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'lookup')
    lookup_text = ast.get_source_segment((ROOT / SOURCE).read_text(encoding='utf-8'), lookup)
    assert 'Canonical_Namespace_Aliases' not in lookup_text
    output = {'status': 'PASS_BOUNDED_METADATA_AND_ALL500_JOIN_CHECKS_LOOKUP_BINDING_GAP_REMAINS',
              'at_utc': datetime.now(timezone.utc).isoformat(), 'source_bindings': read_bindings,
              'generated_frozen_metadata_verified': True, 'exact_initializer_keys': len(entries),
              'status_counts': dict(counts), 'all500_original_root_fields_exact': True,
              'root_join_count': 500, 'complete_after_NET_not_claimed_for_blocked_key': blocked_key,
              'blocked_key_cannot_retry': True, 'seed0_unclosed_original_attempt_preserved': True,
              'seed0_independent_recovery_recorded_separately': True,
              'fresh128': {'entered': 55, 'unentered': 73, 'returned_PF_keys': 1179, 'status': fresh['status']},
              'aliases_with_explicit_kwargs': len(aliases), 'bare_signature_reuse_aliases': 0,
              'certificate_metadata_hashes_and_PASS_status_checked': len(certificates),
              'independent_metadata_disposition_checks': checks,
              'lookup_source_anchor': {'path': SOURCE, 'start_line': lookup.lineno, 'end_line': lookup.end_lineno},
              'lookup_integrity_gap': 'lookup validates the selected registry file digest, but loads Source_Bindings.json without checking its frozen digest before trusting a certificate digest. Current snapshot Source_Bindings was independently verified here; executable lookup must also enforce it or an external pinned reader must do so.',
              'universal_history_complete': False, 'new_PF_authorized': False,
              'producer_import_or_execution': False, 'binary_capsules_read_or_rehashed': 0,
              'NET_deserializations': 0, 'PF_optimizer_model_training_GPU_calls': 0,
              'limits': ['Finite named-source registry only; absence outside these sources is not established.',
                         'Payload hashes were checked as metadata; selected actual after-NET/field bytes must still be verified at authorized reuse.',
                         'Nine-table physical signature is not a complete initializer-dependent solver-state identity. Source/option/current-state gates remain necessary.',
                         'Prior closed-manifest and audit findings are reused with explicit provenance; no old independent reader, source scan or archive audit was rerun.',
                         'Returned queried candidates are reusable physics evidence even when their control commits were rejected; this is not controller success.',
                         'A registry key count is not a count of all paid invocations, nor proof of actor, optimizer or history state.']}
    with (OUT / 'Independent_Review.json').open('x', encoding='utf-8') as f: json.dump(output, f, indent=2, allow_nan=False)
    print(json.dumps({'status': output['status'], 'keys': len(entries), 'roots': len(roots), 'blocked_keys': len(blocked),
                      'aliases': len(aliases), 'binary_reads': 0, 'science_calls': 0}))


if __name__ == '__main__': main()
