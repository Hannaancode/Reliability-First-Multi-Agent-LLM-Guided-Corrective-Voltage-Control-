"""Public metadata and adapter-shape audit, no model loading or cloud allocation."""
import hashlib
import json
import struct
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'work'))
from candidate_process_evidence_utils import write,seal,sha
OUT=ROOT/'outputs/critical_research_reset_20261010/requested_1_5B_model_scale_preparation'
assert not OUT.exists();OUT.mkdir()
write(OUT/'Direct_Request_and_Metadata_Scope.json',{
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'direct_human_request':'Use1.5B or intermediate small model to see whether size makes a difference; continue critical review and progress log',
    'selected_new_candidate':'Qwen/Qwen2.5-1.5B-Instruct',
    'matched_public_family_reference':'Qwen/Qwen2.5-0.5B-Instruct',
    'original_private0_5B_model_and_adapter_preserved':True,
    'public_metadata_fetch_only_no_gpu_or_weights_or_model_calls':True,
    'no_general100percent_failure_or99percent_winning_guarantee':True,
})

def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'HierGrid-research-metadata/1.0'})
    with urllib.request.urlopen(req,timeout=45) as response:
        payload=response.read()
    return json.loads(payload),hashlib.sha256(payload).hexdigest()

configs={};sources=[]
for short,repo in [('public_0_5B','Qwen/Qwen2.5-0.5B-Instruct'),('public_1_5B','Qwen/Qwen2.5-1.5B-Instruct')]:
    meta,meta_sha=get('https://huggingface.co/api/models/'+repo)
    rev=meta['sha'];assert len(rev)==40
    url='https://huggingface.co/'+repo+'/resolve/'+rev+'/config.json'
    config,config_sha=get(url)
    assert config['model_type']=='qwen2' and config['architectures']==['Qwen2ForCausalLM']
    write(OUT/(short+'_config.json'),config)
    configs[short]=config
    sources.append({'repo':repo,'revision':rev,'config_url':url,'config_payload_sha256':config_sha,
                    'API_payload_sha256':meta_sha,'public_safetensors_parameters':meta.get('safetensors',{}).get('total'),
                    'model_card_url':'https://huggingface.co/'+repo})

adapter=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/adapter_model.safetensors'
with adapter.open('rb') as f:
    length=struct.unpack('<Q',f.read(8))[0]
    assert 0<length<2_000_000
    header=json.loads(f.read(length))
tensors={k:v for k,v in header.items() if k!='__metadata__'}
assert len(tensors)==336 and all(v['dtype']=='F32' for v in tensors.values())
small=configs['public_0_5B'];large=configs['public_1_5B']
rank=16
def matrices(config):
    h=config['hidden_size'];ff=config['intermediate_size']
    q=config['num_attention_heads']*(config.get('head_dim') or h//config['num_attention_heads'])
    kv=config['num_key_value_heads']*(config.get('head_dim') or h//config['num_attention_heads'])
    return {'q_proj':(h,q),'k_proj':(h,kv),'v_proj':(h,kv),'o_proj':(q,h),
            'gate_proj':(h,ff),'up_proj':(h,ff),'down_proj':(ff,h)}
small_shapes=matrices(small);large_shapes=matrices(large)
rows=[]
for name,item in sorted(tensors.items()):
    part=name.split('.')
    mod=next(m for m in small_shapes if m in part)
    kind='A' if 'lora_A' in part else 'B'
    expected_small=[rank,small_shapes[mod][0]] if kind=='A' else [small_shapes[mod][1],rank]
    expected_large=[rank,large_shapes[mod][0]] if kind=='A' else [large_shapes[mod][1],rank]
    assert item['shape']==expected_small
    rows.append({'tensor':name,'original_shape':item['shape'],'candidate_shape':expected_large,
                 'direct_copy_compatible':item['shape']==expected_large})
new_parameters=sum(rank*(a+b) for a,b in large_shapes.values())*large['num_hidden_layers']
old_parameters=sum(rank*(a+b) for a,b in small_shapes.values())*small['num_hidden_layers']
assert old_parameters==8798208
summary={
    'completed_at_utc':datetime.now(timezone.utc).isoformat(),'sources':sources,
    'family_comparison':{'0_5B':{k:small[k] for k in ('hidden_size','intermediate_size','num_hidden_layers','num_attention_heads','num_key_value_heads','max_position_embeddings')},
                         '1_5B':{k:large[k] for k in ('hidden_size','intermediate_size','num_hidden_layers','num_attention_heads','num_key_value_heads','max_position_embeddings')}},
    'all336_original_private_adapter_tensors_match_original0_5B_shapes':True,
    'original_tensors_directly_compatible_with1_5B':sum(r['direct_copy_compatible'] for r in rows),
    'original_private_adapter_must_not_be_loaded_with_ignore_mismatch_or_relabelled_as1_5B':True,
    'new_r16_same_seven_module_adapter_parameters_analytical_only':new_parameters,
    'new_F32_parameters_gradients_two_Adam_moments_bytes_analytical_only':new_parameters*4*4,
    'not_total_VRAM_model_load_or_training_memory':True,
    'published_context_limit_not_actual_T4_fit_or_lifetime':True,
    'no_clean_scale_claim_if_public1_5B_is_compared_only_to_private_finetuned0_5B':True,
    'public_matched0_5B_reference_needed_private_original_separate_reference':True,
    'actual_new_model_weights_loaded_forward_optimizer_PF_cloud_calls':0,
    'actual1_5B_performance_memory_training_time_UNKNOWN':True,
    'no_new_training_or_physical_protocol_from_metadata_alone':True,
    'public_small_model_classification_no_universal_SLM_cutoff':True,
    'original_adapter_file_sha256':sha(adapter),'source_sha256':sha(Path(__file__)),
}
write(OUT/'All336_Adapter_Shape_Comparison.json',rows)
write(OUT/'Actual_Public_Config_and_Private_Adapter_Compatibility.json',summary)
(OUT/'Model_Size_Review_and_Test_Disposition.md').write_text('''# Human-requested1.5B size comparison

Select Qwen2.5-1.5B-Instruct against public Qwen2.5-0.5B-Instruct to keep the model family consistent.1.5B is a small language model in ordinary usage, although SLM has no universal cutoff. Qwen3-0.6B would also change generation/architecture and barely increase size; it is not the chosen scale arm. Official cards: https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct and https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct . Each specific card lists32768context, despite broader family prose about128K. That does not fit the previously measured roughly93000–97000-token raw current serialization. A larger parameter count does not fix every information or context problem.

Public revisions/configs are pinned in the JSON certificate. Exact header reading proves the private336-tensor0.5B adapter belongs to the original dimensions; its learned matrices cannot simply become a1.5B adapter. Preserve it. A1.5B fine-tuning arm would need a new, separately identified adapter and justified target/data/controls. Comparing an unfine-tuned1.5B base only to the private0.5B adapter is not a clean scale experiment.

The next bounded size screen should compare the two public instruction models on IDENTICAL prospectively fixed causal inputs/context/action grammar and independent saved physical labels, with strong numerical controls retained. A separately reported original-private reference may answer practical system relevance, with its fine-tuning advantage disclosed. No change to original baseline settings/assets or outcome-selected case list is permitted. Fix a small outcome-independent all-world sample and inference budget before any model call; retain invalid/unlabelled/missing responses. Input sufficiency and measured real memory/load/cold-replay gates precede that screen. It is a development scale diagnostic, not a full learned policy campaign, novelty or D-SE superiority.

Metadata and shape checks are complete. No weights were loaded, no GPU allocated, and no inference/training/PF performed. A published model size or context limit is not evidence of actual T4 memory, speed or available hours. The prospective inference source/collector/result reader still must be implemented and frozen before launch. Continue review and early gates rather than treat metadata as performance.
''',encoding='utf-8')
files={p.name:p for p in OUT.iterdir() if p.is_file()};files['sources/auditor.py']=Path(__file__)
archive=seal(OUT,files,'Requested_1_5B_Metadata_and_Compatibility_Evidence.zip')
print(json.dumps({'candidate_revision':sources[1]['revision'],'shape_compatible_original_tensors':summary['original_tensors_directly_compatible_with1_5B'],
                  'new_r16_parameters':new_parameters,'no_model_or_GPU_calls':True,'archive':archive}))
