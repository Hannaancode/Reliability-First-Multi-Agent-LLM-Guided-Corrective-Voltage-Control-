"""External source/row/incidence/native-pair audit; never calls model/physics."""
import gzip,hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT,read,sha,write,frozen_checks,seal
from vcsa_common_information_codec import flatten
B=ROOT/'outputs/llm_value_candidate_development_20261009'
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
S=P/'actual_representation_and_OPT_support';OUT=P/'independent_support_evidence'
assert not OUT.exists();OUT.mkdir();write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
start=time.perf_counter();protocol=read(P/'Support_Audit_Prospective_Protocol.json')
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
def h(v):return hashlib.sha256(canon(v).encode()).hexdigest()
def rows(path):
    with gzip.open(path,'rt',encoding='utf8') as f:
        for line in f:yield json.loads(line)
for p,v in protocol['source_hashes'].items():assert sha(ROOT/p)==v,p
manifest=read(S/'Closed_Scientific_Manifest.json')
assert set(manifest)=={p.name for p in S.iterdir() if p.is_file() and p.name not in {'Closed_Scientific_Manifest.json','owner.claim','status.json'}}
for n,v in manifest.items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
source={r['observation_id']:r for r in rows(B/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz')}
support={r['observation_id']:r for r in rows(B/'current_added_support_observables/Current_Control_State_Observables.jsonl.gz')}
identities={};checked_rows=0;checked_cells=0;checked_incidence=0;maxslots=0
for saved in rows(S/'Actual_Relational_Current_Input_Records.jsonl.gz'):
    ident=saved['audit_identity']['observation_id'];assert ident not in identities
    r=source[ident];assert saved['audit_identity']=={k:r[k] for k in ('observation_id','world_sha256','split')}
    current=r['model_input'];current=json.loads(canon(current));s=support[ident]
    current['current_control_state']={'original_per_bus_added_support_cap_MVAr':s['original_cap_MVAr'],
                                    'added_abs_Q_MVAr_by_bus':s['current_added_support_MVAr_by_bus']}
    e=saved['model_input_codec'];assert h(current)==e['source_current_input_sha256']==s['augmented_model_input_sha256']
    # Compare directly to original table rows, without calling the new encoder
    # or decoder. Table IDs and end roles come from native original columns.
    tables=current['current_physical_observation']['physical_tables']
    assert e['table_schemas']==[{'table':n,'columns':f['columns'],'rows':len(f['index'])} for n,f in sorted(tables.items())]
    expected=[];relations=[]
    for name,f in sorted(tables.items()):
        for pos,(entity,values) in enumerate(zip(f['index'],f['values'])):
            expected.append({'table':name,'row_position':pos,'entity_id':entity,'values':values})
            native=name[4:] if name.startswith('res_') else name
            nf=tables[native];j=nf['index'].index(entity);mapping=dict(zip(nf['columns'],nf['values'][j]))
            if native=='bus':busids=[entity];roles=['bus']
            elif native in ('line','impedance'):roles=['from_bus','to_bus'];busids=[mapping[k] for k in roles]
            elif native=='trafo':roles=['hv_bus','lv_bus'];busids=[mapping[k] for k in roles]
            else:roles=['bus'];busids=[mapping['bus']]
            relations.append({'table':name,'row_position':pos,'entity_id':entity,'bus_ids':busids,'endpoint_roles':roles})
            checked_rows+=1;checked_cells+=len(values);checked_incidence+=len(busids)
    assert canon(e['physical_rows'])==canon(expected) and canon(e['physical_incidence'])==canon(relations)
    del current['current_physical_observation']['physical_tables']
    assert canon(e['side_records'])==canon(flatten(current))
    assert r['world_sha256'] not in canon(e) and ident not in canon(e)
    positions=len(e['table_schemas'])+len(expected)+len(e['side_records'])+118
    maxslots=max(maxslots,positions);identities[ident]={'codec_sha256':h(e),'positions':positions}
assert set(identities)==set(source)==set(support) and len(identities)==311
closedrows=read(S/'All311_Exact_Input_and_Slot_Checks.json')
for r in closedrows:assert r['codec_sha256']==identities[r['observation_id']]['codec_sha256'] and r['proposed_soft_positions']==identities[r['observation_id']]['positions']
target={r['observation_id']:r for r in rows(B/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz') if r['split']=='optimization'}
assert len(target)==187
lookups={};expected_pairs={};worlds={w['scenario_sha256']:w for w in protocol['worlds']}
quality=[];contrasts=[];candcount=0;nearcount=0
for ident,r in target.items():
    inp=source[ident]['model_input'];obs=inp['current_physical_observation'];cap=support[ident]['current_added_support_MVAr_by_bus']
    pool={b for p in obs['raw_common_and_zone_pools'].values() for b in p}
    lookup={};good=[];bad=[];candcount+=len(r['measured_candidates'])
    for c in r['measured_candidates']:
        t=c['target'];pair=(t['bus'],t['Q_index']);assert pair not in lookup
        assert t['bus'] in pool and t['q_mvar']==inp['original_Q_grid'][t['Q_index']]
        lookup[pair]=t
        if cap[t['bus']]+t['q_mvar']<=450.:
            (good if t['recorded_verifier']['accepted'] else bad).append(t)
    lookups[ident]=lookup;best=max((tuple(t['recorded_original_score']) for t in good),default=None)
    pairs=set()
    for t in good:
        v=tuple(t['recorded_original_score'])
        if v==best:continue
        different=[j for j in range(len(v)) if best[j]!=v[j]]
        j=different[0];assert best>v
        if j==4:continue
        if j in (2,3) and abs(best[j]-v[j])<=1e-10:nearcount+=1;continue
        pairs.add((t['bus'],t['Q_index']))
    expected_pairs[ident]=pairs
    info={'world':r['world_sha256'],'family':worlds[r['world_sha256']]['family']}
    if pairs:quality.append(info)
    if good and bad:contrasts.append(info)
seen={ident:set() for ident in target};paircount=0
for p in rows(S/'Measured_OPT_Native_Quality_Preference_Pairs.jsonl.gz'):
    ident=p['observation_id'];assert ident in target and p['world_sha256']==target[ident]['world_sha256']
    a,b=(lookups[ident][tuple(p[k])] for k in ('preferred_action','other_action'))
    assert a['recorded_verifier']['accepted'] and b['recorded_verifier']['accepted']
    assert tuple(a['recorded_original_score'])>tuple(b['recorded_original_score'])
    maximum=max(tuple(t['target']['recorded_original_score']) for t in target[ident]['measured_candidates'] if t['target']['recorded_verifier']['accepted'])
    assert tuple(a['recorded_original_score'])==maximum
    pair=tuple(p['other_action']);assert pair not in seen[ident];seen[ident].add(pair);paircount+=1
assert seen==expected_pairs
def cov(values):return {'states':len(values),'worlds':len({v['world'] for v in values}),'families':sorted({v['family'] for v in values})}
summary=read(S/'Actual_Support_and_Context_Results.json');assert summary['OPT_native_stable_quality_pairs']==paircount==11884
assert summary['quality_competition_coverage']==cov(quality) and summary['accepted_rejected_coverage']==cov(contrasts)
assert summary['OPT_measured_candidates']==candcount and summary['OPT_near_tie_pairs_not_used']==nearcount
assert maxslots==summary['proposed_slots_max'] and maxslots+384<=4096
minimum=protocol['minimum_design_support'];q,c=cov(quality),cov(contrasts)
assert summary['label_design_support_gate_passed']==(q['states']>=minimum['stable_physical_quality_competition_OPT_states'] and c['states']>=minimum['accepted_and_known_rejected_OPT_states'] and all(v['worlds']>=minimum['distinct_OPT_worlds_each'] and len(v['families'])>=minimum['families_each'] for v in (q,c)))
assert len(read(S/'Five_Labelled_Alteration_Checks.json'))==5
certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_checks_passed':True,
 'exact_inputs':311,'all_worlds':31,'OPT_target_states':187,'physical_rows_checked':checked_rows,
 'physical_cells_checked':checked_cells,'physical_bus_incidence_ends_checked':checked_incidence,
 'native_quality_pairs_checked':paircount,'all_candidate_scope_and_native_order_checks_passed':True,
 'OPT_only_label_support':True,'held_label_metrics_or_pairs_computed':0,
 'actual_context_slot_count_max':maxslots,'context_is_slot_accounting_not_genuine_model_memory_or_tokenizer_gate':True,
 'original_missing_invalid_unlabelled_denominators_retained':True,
 'neural_graph_grounding_and_adapter_benefit_unmeasured':True,
 'new_model_optimizer_PF_linear_solve_controller_cloud_calls':0,
 'auditor_wall_seconds':time.perf_counter()-start,
 'limitations':['Source gzip reader parses and skips held target records; no held candidate labels enter preference computations.',
                'Global candidate labels do not prove robustness of per-bus successor threshold memberships.',
                '11,884 comparisons share187 states/22 world groups, not11,884 independent samples.',
                'A reversible raw codec is not a lossless neural representation or proven novel method.']}
write(OUT/'Independent_Source_Relation_and_Native_Preference_Audit.json',certificate)
write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
files={'source/auditor.py':Path(__file__), 'source/codec.py':ROOT/'work/relational_current_state_codec.py',
       'source/preparation.py':ROOT/'work/prepare_relational_method_support_protocol.py',
       'source/measurement.py':ROOT/'work/measure_relational_method_support.py',
       'protocol.json':P/'Support_Audit_Prospective_Protocol.json',
       'Critical_Primary_Research_and_New_Hypothesis.md':P/'Critical_Primary_Research_and_New_Hypothesis.md'}
for n in manifest:files['measurement/'+n]=S/n
files['measurement/Closed_Scientific_Manifest.json']=S/'Closed_Scientific_Manifest.json'
files['Independent_Source_Relation_and_Native_Preference_Audit.json']=OUT/'Independent_Source_Relation_and_Native_Preference_Audit.json'
files['Fresh_Frozen_Preservation.json']=OUT/'Fresh_Frozen_Preservation.json'
archive=seal(OUT,files,'Relational_Current_Input_and_OPT_Preference_Readiness.zip')
write(OUT/'status.json',{'stage':'complete_external_support_audit','all_checks_passed':True,'new_science_calls':0})
print(json.dumps({'audit':certificate,'archive':archive},indent=2))
