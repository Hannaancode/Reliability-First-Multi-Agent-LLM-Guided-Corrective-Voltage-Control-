"""Future-only atomic claim/ACK and bounded process custody; no physics changes.

The Oct19 coordinator read a claim between open and JSON completion. New
launchers tolerate only that transient, retain their original child handle,
record its exit, and never restart a child. Existing sources stay untouched.
"""
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from equal_operation_benchmark_v2 import process

def atomic_new(path,value):
    path=Path(path);assert not path.exists();tmp=path.with_name(path.name+'.writing')
    with tmp.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    assert not path.exists();os.replace(tmp,path)

def bind(env,entrypoint):
    """Bind only a prospectively source-locked new owner, never an old worker."""
    base=env['B'];python=env['PYTHON'];admit=env['admit'];now=env['now']
    def claim(out,p):
        out.mkdir(exist_ok=False)
        atomic_new(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'source_sha256':sha(entrypoint),'protocol_sha256':sha(base/'Protocol.json')})
        begun=time.perf_counter()
        while not (out/'Launcher_ACK.json').exists():admit(p);assert time.perf_counter()-begun<60;time.sleep(.05)
        a=read(out/'Launcher_ACK.json');assert a['actual_pid']==os.getpid() and a['actual_parent_pid']==os.getppid() and a['fresh_exact_PID_parent_command']
    def launch(source,mode,out,p):
        admit(p);source=Path(source);parsing_transients=0;claim_data=None;code=None;begun=time.perf_counter()
        with (base/(out.name+'_console.log')).open('x',encoding='utf-8') as log:
            child=subprocess.Popen([str(python),'-X','utf8',str(source),'--'+mode],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            try:
                while claim_data is None:
                    admit(p);assert child.poll() is None and time.perf_counter()-begun<60
                    if (out/'owner.claim').exists():
                        try:claim_data=read(out/'owner.claim')
                        except (json.JSONDecodeError,UnicodeDecodeError):parsing_transients+=1
                    if claim_data is None:time.sleep(.025)
                real=process(claim_data['actual_pid'])
                assert real and real['ParentProcessId']==child.pid and source.name in real['CommandLine'] and '--'+mode in real['CommandLine']
                assert claim_data['source_sha256']==sha(source) and claim_data['protocol_sha256']==sha(base/'Protocol.json')
                atomic_new(out/'Launcher_ACK.json',{'actual_pid':claim_data['actual_pid'],'actual_parent_pid':child.pid,'actual_command':real['CommandLine'],'fresh_exact_PID_parent_command':True,'at_utc':now(),'retained_launcher_handle':True,'partial_claim_reads':parsing_transients})
                remaining=max(1,(datetime.fromisoformat(p['absolute_deadline_utc'])-datetime.now(timezone.utc)).total_seconds()+30)
                code=child.wait(timeout=remaining)
            except BaseException:
                # No replacement or restart. An unacknowledged software child
                # self-terminates at its original ACK/deadline bound.
                if child.poll() is None:
                    remaining=max(1,min(65,(datetime.fromisoformat(p['absolute_deadline_utc'])-datetime.now(timezone.utc)).total_seconds()+30))
                    try:code=child.wait(timeout=remaining)
                    except subprocess.TimeoutExpired:code='UNKNOWN_STILL_OWNED_NO_RELAUNCH'
                atomic_new(base/(out.name+'_Admission_Failure.json'),{'launcher_pid':child.pid,'actual_pid':claim_data.get('actual_pid') if claim_data else None,'exit_code':code,'no_restart_or_replacement':True,'partial_claim_reads':parsing_transients})
                raise
        assert process(claim_data['actual_pid']) is None and process(child.pid) is None
        atomic_new(base/(out.name+'_End_ACK.json'),{'actual_pid':claim_data['actual_pid'],'launcher_pid':child.pid,'exit_code':code,'closed_manifest_sha256':sha(out/'Closed_Manifest.json'),'actual_owned_chain_ended':True,'OS_launcher_exit_code_from_original_retained_handle':True,'partial_claim_reads':parsing_transients})
        return code
    return dict(env,claim=claim,launch=launch)
