"""Causal current-forecast ordering only; no physical labels, omission or solve."""
import math

KEYS={'kind','receiver','q','donor_index','donor_bus','universe_index','ordering_forecast'}
def forecast_admissible(row,before,cursor):
    if set(row)!=KEYS:raise ValueError('Ordering must not receive measured labels, receipts or other unbound fields')
    operations=2 if row['kind']=='equal_owned_reallocation' else 1
    if cursor['remaining_original_device_operation_slots']<operations:return False
    if cursor['positive_addition_lifetime_MVAr'].get(str(row['receiver']),0)+row['q']>450:return False
    forecast=row['ordering_forecast']
    if forecast['status']!='FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE':return False
    after=forecast['after']
    if not all(math.isfinite(float(v)) for v in after.values()):return False
    return (after['vmax']<=1.05+1e-8 and after['uv_count']<=before['uv_count'] and
        after['deficit_sum']<=before['deficit_sum']+1e-9 and
        (after['uv_count']<before['uv_count'] or after['deficit_sum']<before['deficit_sum']-1e-9 or after['vmin']>before['vmin']+1e-9))

def order_all_current_forecasts(rows,before,cursor):
    if len({r['universe_index'] for r in rows})!=len(rows):raise ValueError('Duplicate candidate identities')
    result=sorted(rows,key=lambda r:(not forecast_admissible(r,before,cursor),tuple(-x for x in r['ordering_forecast']['score']),r['universe_index']))
    assert len(result)==len(rows) and {r['universe_index'] for r in result}=={r['universe_index'] for r in rows}
    return result
