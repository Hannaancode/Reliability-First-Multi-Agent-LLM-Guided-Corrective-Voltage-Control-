"""Add reviewed caption scope and closed adverse QA evidence to a new thesis copy."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,copy
from docx import Document
from docx.shared import Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
R=Path(__file__).resolve().parents[1];B=R/'outputs/thesis_cohorts_references_20261029';O=R/'outputs/thesis_caption_QA_v2_20261029'
def rd(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists();base=B/'Hannaan_Thesis_Cohorts_And_References.docx'
    assert sha(base)==rd(B/'Final_Visual_And_Evidence_QA.json')['docx_sha256']
    cap=rd(R/'outputs/thesis_caption_scope_20261029/Caption_Clarifications.json');result=rd(R/'outputs/public_qa_completion_20261029/Verified_Completion.json')
    assert result['all_actors_ended'] and result['science_generations']==450
    assert [r['primary_correct'] for r in result['rows']]==[37,0,37]
    paper=(R/'outputs/full_system_comparison_20261021/Provided_Multiagent_Paper_Extracted.txt').read_text('utf-8-sig')
    assert '538 actions were executed' in paper and '270 actions were direct verified' in paper
    d=Document(base);changes=[]
    for x in cap['records']:
        pps=[p for p in d.paragraphs if p.text==x['original']];assert len(pps)==1,(x['kind'],x['number'])
        text=x['proposed'].replace('structure:23,368 theory,4,696','structure: 23,368 theory, 4,696').replace('23,368 theory,4,696','23,368 theory, 4,696').replace('denotesVM<0.95','denotes voltage below 0.95').replace('strictOV','strict OV')
        if x['kind']=='Figure' and x['number']=='7.2':
            text='\nFigure 7.2 Reported source of 538 accepted actions across 61 development scenarios. Reproduced from [3], Figure 4. The manuscript reports 270 direct verified LLM actions, 70 guided numerical refinements and 198 fallback refinements. These are action-origin counts, not a causal ablation; the later 137-case cohort is separate.'
        if x['kind']=='Table' and x['number']=='7.2':text=text.replace('figures reported in the RAG manuscript. Manuscript-reported answering figures.','figures reported in the RAG manuscript.')
        p=pps[0]
        if x['kind']=='Figure':
            for oldrun in list(p.runs):
                if not oldrun._r.xpath('.//w:drawing'): oldrun._r.getparent().remove(oldrun._r)
        else:p.clear()
        run=p.add_run(text);run.font.name='Times New Roman';run.font.size=Pt(11);run.font.color.rgb=RGBColor(0,0,0)
        p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.keep_together=True;p.paragraph_format.keep_with_next=(x['kind']=='Table')
        p.paragraph_format.space_after=Pt(6);p.paragraph_format.line_spacing=1
        changes.append({**x,'integrated':text,'status':'SOURCE_REVIEWED_INTEGRATED_AWAITING_RENDER'})
    assert len(changes)==29
    # The short front-matter labels remain short; their exact body-prefix matches survive.
    # One changed figure label needs a matching short list entry.
    oldlist='Figure 7.2 Reported source of accepted actions in the 61-scenario development cohort'
    for p in d.paragraphs:
        if p.text.startswith(oldlist) and '\t' in p.text:
            number=p.text.rsplit('\t',1)[1];p.text='Figure 7.2 Reported source of 538 accepted actions across 61 development scenarios\t'+number
    p=next(p for p in d.paragraphs if p.text.startswith('The current VeraGrid protocol fixes 150 questions'))
    oldcohort=p.text;p.text=p.text.replace('This section records the declared design and does not report a score from an incomplete run.','This section records the declared design; Section 7.18 reports the completed fixed run and its limitations.')
    anchor=next(p._p for p in d.paragraphs if p.text=='Chapter 8 Cybersecurity scope existing stress tests and evaluation design')
    added=[]
    def para(text,style='Normal'):
        p=d.add_paragraph(text,style);anchor.addprevious(p._p);p.paragraph_format.space_after=Pt(6);p.paragraph_format.widow_control=True
        for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(14 if style.startswith('Heading') else 12);run.font.color.rgb=RGBColor(0,0,0)
        if style.startswith('Heading'):p.paragraph_format.keep_with_next=True
        added.append(text);return p
    para('7.18 Fixed public question answering across three model sizes','Heading 2')
    para('The public VeraGrid transfer study completed one fixed attempt for each of 150 questions at each of three model sizes [34]. All questions concern the same public circuit. The public Qwen2.5 instruction models received identical circuit information, question order and rendered prompts, with greedy decoding and at most 256 new tokens. The run used FP16 eager inference on separate T4 devices. It loaded no private voltage-control adapter and used neither retrieval nor solver tools, so it does not reproduce the complete RAG pipeline or measure voltage restoration.')
    caption='Table 7.12 Completed public QA operational results. Each denominator is the same 150 questions about one circuit. Native-parser accuracy is the fixed primary measure; strict accuracy also requires a single uppercase answer letter. The 1.5B output collapse limits interpretation of model capability.'
    cp=para(caption,'Caption');cp.paragraph_format.keep_with_next=True;cp.paragraph_format.keep_together=True;cp.paragraph_format.line_spacing=1
    for run in cp.runs:run.font.size=Pt(11)
    t=d.add_table(rows=1,cols=5);t.style='Table Grid';anchor.addprevious(t._tbl)
    for c,v in zip(t.rows[0].cells,['Public model','Native correct','Strict correct','Strict valid','At token cap']):c.text=v
    for r in result['rows']:
        values=[r['model'].split('/')[-1].replace('Qwen2.5-',''),f"{r['primary_correct']}/150",f"{r['strict_correct']}/150",f"{r['strict_valid']}/150",f"{r['output_cap_hits']}/150"]
        for c,v in zip(t.add_row().cells,values):c.text=v
    for row in t.rows:
        for c in row.cells:
            for p in c.paragraphs:
                p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(3)
                for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(10)
    para('The 0.5B and 3B models each obtained 37 correct answers under the native parser, or 24.67%. The 3B model gave a valid single letter for every question and obtained 37 strict correct answers, compared with 12 for 0.5B. Its answer distribution was A: 16, B: 98, C: 29 and D: 7. Better output formatting therefore did not improve the fixed primary accuracy. This one-circuit result provides no evidence of general model-size superiority or superiority over another published controller.')
    para('The 1.5B arm returned 256 repetitions of the exclamation-mark token for every question, yielding zero correct answers. The same pattern was present in both earlier synthetic capacity probes. The engineering gate required matching warm and cold outputs, but did not test finite raw logits or useful non-test response behavior. It therefore allowed reproducible degenerate output to enter the benchmark. The saved record contains no logits or intermediate activations, so it cannot establish whether numerical overflow, precision, implementation or another cause produced the collapse. The score describes the executed system, not an intrinsic absence of model knowledge.')
    para('An independent saved-output reader verified source, input, journal, token decoding and scoring records without repeating inference. All 450 scientific and six engineering generations were retained with setup, transfer, release and workflow costs. The three runtimes were released; overlapping timings are not added. The fixed adverse result remains closed. Future work needs separately declared numerical and non-test behavior gates.')
    # Add one concise table-list label before the existing Chapter9 table label.
    indexanchor=next(p for p in d.paragraphs if p.text.startswith('Table 9.1 ') and '\t' in p.text)
    newp=copy.deepcopy(indexanchor._p);indexanchor._p.addprevious(newp)
    from docx.text.paragraph import Paragraph
    Paragraph(newp,d).text='Table 7.12 Completed public QA operational results\t1'
    assert len(d.inline_shapes)==22
    O.mkdir();out=O/'Hannaan_Thesis_Caption_And_QA_Update.docx';d.save(out)
    assert len(Document(out).inline_shapes)==22
    record={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'INTEGRATED_AWAITING_PAGINATION_AND_VISUAL_REVIEW','base':str(base.relative_to(R)),'base_sha256':sha(base),'output':str(out.relative_to(R)),
        'caption_changes':changes,'old_cohort_sentence':oldcohort,'new_section_paragraphs':added,'new_table':'7.12',
        'source_bindings':[{'path':str(p.relative_to(R)),'sha256':sha(p)} for p in [R/'outputs/thesis_caption_scope_20261029/Caption_Clarifications.json',R/'outputs/public_qa_completion_20261029/Verified_Completion.json',R/'outputs/full_system_comparison_20261021/Provided_Multiagent_Paper_Extracted.txt']],
        'new_science':0,'T32':'AWAITING_REVIEWED_INTEGRATION'}
    (O/'Integration_Record.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n','utf-8')
    ps=(R/'work/paginate_cohorts_references_thesis_20261029.ps1').read_text('utf-8-sig').replace('thesis_cohorts_references_20261029','thesis_caption_QA_v2_20261029').replace('Hannaan_Thesis_Cohorts_And_References.docx','Hannaan_Thesis_Caption_And_QA_Update.docx')
    (R/'work/paginate_caption_QA_thesis_v2_20261029.ps1').write_text(ps,'utf-8')
    print(json.dumps({'caption_changes':len(changes),'tables':len(d.tables),'new_science':0}))
if __name__=='__main__':main()
