"""Prepare a locked first independent reader for the unentered-identity campaign."""
import ast,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_missing_only_preparation_20261021'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)
def main():
    original=R/'work/audit_public13_first_partial_validation_v2_20261021.py';text=original.read_text(encoding='utf-8');changes=[]
    def replace(a,b,label):
        nonlocal text
        assert text.count(a)==1,(label,text.count(a));text=text.replace(a,b);changes.append(label)
    replace("PREP=ROOT/'outputs/public13_full_cohort_preparation_20261021';PRIMARY=ROOT/'outputs/public13_remaining_published_cohort_20261021';OUT=ROOT/'outputs/public13_first_partial_validation_v2_20261021'", "PREP=ROOT/'outputs/public13_missing_only_preparation_20261021';PRIMARY=ROOT/'outputs/public13_missing_only_execution_20261021';OUT=ROOT/'outputs/public13_missing_only_independent_20261021'\nOLD=ROOT/'outputs/public13_remaining_published_cohort_20261021'\nPREFIX=ROOT/'outputs/public13_first_partial_validation_v2_20261021'",'new separately registered scope and outputs')
    start=text.index("    p=json.loads((PREP/'Protocol.json').read_text());")
    stop=text.index('    import stable_ddpg_native_bridge_20261020 as b',start)
    text=text[:start]+"""    p=json.loads((PREP/'Protocol.json').read_text());deadline=began+p['reader_seconds']
    end=json.loads((ROOT/p['primary_coordination']/'End_ACK.json').read_text());assert end['actual_owned_chain_ended'] and end['exit_code']==0
    prefix=json.loads((PREFIX/'Independent_Audit.json').read_text());assert prefix['status']=='PASS_FIRST_INDEPENDENT_PRESERVED_PARTIAL_PREFIX_NATIVE_SOURCE_PROJECTION_POLICY_PHYSICS_AND_COST_VALIDATION'
    for n,h in p['source_and_input_hashes'].items():assert sha(ROOT/n)==h
    lock=json.loads((PREP/'Independent_Reader_Lock.json').read_text());assert sha(__file__)==lock['reader_sha256'] and sha(PREP/'Protocol.json')==lock['protocol_sha256']
    for f in json.loads((PRIMARY/'Closed_Manifest.json').read_text())['files']:assert (PRIMARY/f['path']).stat().st_size==f['bytes'] and sha(PRIMARY/f['path'])==f['sha256']
"""+text[stop:];changes.append('new closed source input identity reader lock and inherited first-audit PASS admission')
    replace("result=json.loads((PREPARATION/'Preserved_Result_View.json').read_text())", "result=json.loads((PRIMARY/'Result.json').read_text())",'actual new closed result')
    replace("json.loads((RECOVERY/'Original_Failed_Study_File_Manifest.json').read_text())['journal_last_sha256']", "json.loads((PRIMARY/'Closed_Manifest.json').read_text())['journal_last_sha256']",'new primary exact journal')
    replace("before=PRIMARY/'physics'/f'PF{index:06d}_before.pkl'", "if r.get('origin')=='ORIGINAL_PAID_PREFIX':\n                assert index=='OLD:'+str(r['old_index']);verified[index]=True;continue\n            before=PRIMARY/'physics'/f'PF{index:06d}_before.pkl'",'no second replay of old already-independent paid receipts')
    replace("params=np.load(PRIMARY/'All9_Immutable_Parameters_Before.npz');derived=np.load(RECOVERY/'Derived_Source_Projected_Parameters_NOT_Actual_Final.npz')", "params=np.load(PRIMARY/'All9_Source_Parameters_Before.npz');derived=np.load(PRIMARY/'All9_Source_Parameters_After.npz')\n        from public13_complete_policy_state_contract_20261021 import restore,snapshot,check_cursor\n        carry=np.load(PREFIX/'Independent_Replayed_Final_Source_State.npz');restore(models,{n:carry[n] for n in carry.files})",'new actual initial final bytes plus explicitly reconstructed old carry')
    replace("saved=pickle.loads((PRIMARY/'physics'/f\"PF{r['index']:06d}_after.pkl\").read_bytes())", "saved_path=OLD/'physics'/f\"PF{r['old_index']:06d}_after.pkl\" if r.get('origin')=='ORIGINAL_PAID_PREFIX' else PRIMARY/'physics'/f\"PF{r['index']:06d}_after.pkl\";assert sha(saved_path)==r['after_sha256'];saved=pickle.loads(saved_path.read_bytes())",'exact previous paid cache after-state access without another PF')
    replace("cursor=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());assert", "cursor=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());current_model_state=snapshot(models);assert set(current_model_state)==set(cursor['complete_model_state']) and all(np.array_equal(v,cursor['complete_model_state'][n]) for n,v in current_model_state.items());assert",'verify actual source-mutable cold snapshot at every step')
    replace("raw=np.asarray(raw);assert", "actual_forward_state=snapshot(models);saved_forward_state=pickle.loads((sd/'Policy_State_After_Forwards.pkl').read_bytes());assert set(actual_forward_state)==set(saved_forward_state) and all(np.array_equal(v,saved_forward_state[n]) for n,v in actual_forward_state.items());raw=np.asarray(raw);assert",'every actual after-inference tensor exact')
    replace("history.append(row);checked_steps+=1", "history.append(row);checked_steps+=1\n                    completed=pickle.loads((sd/'Completed_Full_State.pkl').read_bytes());assert completed['next_step']==pos+1 and completed['remaining_source_horizon']==100-pos and completed['history']==history and np.array_equal(completed['last_Q'],last) and np.array_equal(completed['state'],state) and signature(completed['environment']['network'])==signature(env.network) and all(np.array_equal(v,completed['complete_model_state'][n]) for n,v in actual_forward_state.items())",'every committed complete checkpoint state and history exact')
    replace("assert costs['PF_returns']==result['costs']['PF_returns']", "assert costs['PF_returns']==result['costs']['PF_returns']\n        actual_pairs=[(w['seed'],a['algorithm']) for w in result['worlds'] for a in w['algorithms']];expected_pairs=[(v['seed'],v['algorithm']) for v in p['exact_unentered_method_cases']];assert actual_pairs==expected_pairs[:len(actual_pairs)]\n        completed={(w['seed'],a['algorithm']) for w in result['worlds'] for a in w['algorithms'] if a['status']=='COMPLETE_NATIVE_EPISODE'};assert result['exact_unexecuted_method_cases']==[v for v in p['exact_unentered_method_cases'] if (v['seed'],v['algorithm']) not in completed]\n        final_packet=pickle.loads((PRIMARY/'Final_Complete_State.pkl').read_bytes());assert all(np.array_equal(v,final_packet['models'][n]) for n,v in snapshot(models).items())",'no skipped selected repeated or fabricated completed identity; full final bytes checked')
    replace("'original_primary_cursor_lacked_live_mutable_policy_state':True", "'original_primary_cursor_lacked_live_mutable_policy_state':True,'new_primary_all_actual_cursors_and_final_state_saved_and_verified':True",'new complete actual preservation distinguished from old missing snapshot')
    # Only the audit RESULT status changes; the admission equality above stays fixed.
    replace("'status':'PASS_FIRST_INDEPENDENT_PRESERVED_PARTIAL_PREFIX_NATIVE_SOURCE_PROJECTION_POLICY_PHYSICS_AND_COST_VALIDATION','scientific_status'", "'status':'PASS_INDEPENDENT_MISSING_ONLY_SOURCE_STATE_CONTINUOUS_POLICY_PHYSICS_AND_COST_AUDIT','scientific_status'",'new audit result exact limited scope')
    replace("'all499_complete':result['status'].startswith('COMPLETE_')", "'all1013_new_pairs_complete':result['status']=='COMPLETE_ALL1013_PREDECLARED_UNENTERED_METHOD_CASE_PAIRS'",'new scope completion')
    replace("'all_new_scientific_identity_PF_returns_independently_replayed':len(verified)", "'all_new_scientific_identity_PF_returns_independently_replayed':costs['PF_returns'],'old_already_replayed_receipts_reused':sum(r.get('origin')=='ORIGINAL_PAID_PREFIX' for r in receipts.values())",'only genuinely new independent physical work counted')
    replace("'original_primary_cold_policy_checkpoint_complete':False", "'original_primary_cold_policy_checkpoint_complete':False,'new_primary_complete_actual_cold_policy_state_verified':True,'all_unexecuted_method_cases_UNKNOWN':result['exact_unexecuted_method_cases'],'old_failed_primary_costs':result['original_failed_prefix_costs'],'old_independent_replay_costs':result['independent_prefix_replay_costs']",'all old costs missing pairs original limitations retained')
    # Check all strict physical/model/action/reward thresholds retain AST literals.
    ast.parse(text);target=R/'work/audit_public13_missing_only_continuation_20261021.py';target.write_text(text,encoding='utf-8')
    protected=[];new_nodes={ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text))}
    for n in ast.walk(ast.parse(original.read_text(encoding='utf-8'))):
        if isinstance(n,ast.Assert) and any(k in ast.unparse(n) for k in ['allclose','kcl','np.array_equal(raw','reward','native_done',"ppc['",'Source-external parameter change']):
            assert ast.dump(n,include_attributes=False) in new_nodes,ast.unparse(n);protected.append(ast.unparse(n))
    put(P/'Independent_Reader_Static_Proof.json',{'reader_sha256':sha(target),'changes':changes,'unchanged_strict_equation_action_output_checks':protected,'new_policy_PF_calls_in_preparation':0,'reader_makes_first_independent_replay_only_for_new_primary_returns':True,'never_replay_old_prefix_or_failed_unentered_IDs':True})
    print('NEW_MISSING_ONLY_READER_PREPARED_SOURCE_STATIC_GATES; NOT_EXECUTED')
if __name__=='__main__':main()
