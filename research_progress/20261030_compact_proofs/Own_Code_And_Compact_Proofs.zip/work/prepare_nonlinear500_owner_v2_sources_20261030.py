"""Additive source preparation only. Never imports or starts an experiment."""
from pathlib import Path
import ast
import hashlib
import json

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/nonlinear500_receding_acquisition_v2_source_preparation_20261030'
OLD = 'nonlinear500_receding_acquisition'
SUFFIXES = ('preparation', 'execution', 'coordination', 'independent', 'reader_coordination', 'handoff')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, value):
    with p.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2); f.write('\n')


def once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def main():
    O.mkdir(exist_ok=False)
    rows = []
    for prefix in ('run', 'audit', 'coordinate', 'freeze'):
        before = R / ('work/' + prefix + '_' + OLD + '_20261030.py')
        after = R / ('work/' + prefix + '_' + OLD + '_v2_20261030.py')
        text = before.read_text(encoding='utf-8')
        for suffix in SUFFIXES:
            text = text.replace(OLD + '_' + suffix + '_20261030', OLD + '_v2_' + suffix + '_20261030')
        for stem in ('run', 'audit', 'coordinate', 'freeze'):
            text = text.replace(stem + '_' + OLD + '_20261030', stem + '_' + OLD + '_v2_20261030')
        if prefix == 'run':
            text = once(text, ' O.mkdir(exist_ok=False)\n from nonlinear13_receding_policy_engine_v2_20261030 import clock_domain',
                " from nonlinear500_isolated_owner_runtime_20261030 import admit_isolated_runtime\n runtime_admission=admit_isolated_runtime(R,base)\n O.mkdir(exist_ok=False)\n from nonlinear13_receding_policy_engine_v2_20261030 import clock_domain")
            text = once(text, "'owner_started_monotonic':began,'frozen_preparation_protocol':ref(P/'Protocol.json')}",
                "'owner_started_monotonic':began,'frozen_preparation_protocol':ref(P/'Protocol.json'),\n  'isolated_owner_runtime_admission':runtime_admission}")
        elif prefix == 'audit':
            text = once(text, "    deadline=began+p['reader_seconds']",
                "    from nonlinear500_isolated_owner_runtime_20261030 import admit_isolated_runtime\n    runtime_admission=admit_isolated_runtime(R,p)\n    deadline=began+p['reader_seconds']")
            text = once(text, "reader_source_sha256=sha(__file__),reader_original_deadline_monotonic=deadline,",
                "reader_source_sha256=sha(__file__),reader_original_deadline_monotonic=deadline,\n            isolated_owner_runtime_admission=runtime_admission,")
        elif prefix == 'freeze':
            text = once(text, " ap=argparse.ArgumentParser();ap.add_argument('--readiness-index',required=True);a=ap.parse_args()",
                " ap=argparse.ArgumentParser()\n for flag in ('readiness-index','runtime-certificate','failure-diagnosis','previous-terminal-certificate'):\n  ap.add_argument('--'+flag,required=True)\n a=ap.parse_args()\n from nonlinear500_isolated_owner_runtime_20261030 import (validate_previous_setup,validate_runtime_spec,\n  DEPENDENCY_DIRECTORY,WHEEL_FILE,WHEEL_SHA256,SOURCE_FILE)\n previous=dict(failed_protocol=ref(R/'outputs/nonlinear500_receding_acquisition_preparation_20261030/Protocol.json'),\n  independent_failure_diagnosis=ref(R/a.failure_diagnosis),fresh_terminal_absence=ref(R/a.previous_terminal_certificate),\n  old_study_never_restarted=True,original_authenticated_chain_end='UNKNOWN_RETAINED_UNCHANGED')\n failed=validate_previous_setup(R,previous)\n runtime_certificate=json.loads((R/a.runtime_certificate).read_text(encoding='utf-8'))\n runtime=dict(directory=DEPENDENCY_DIRECTORY,package='psutil',version='7.2.2',\n  official_wheel=ref(R/WHEEL_FILE),actual_runtime_certificate=ref(R/a.runtime_certificate),\n  actual_runtime_admission_source=ref(R/'work/check_acquisition_actual_runtime_20261030.py'),\n  source_files=runtime_certificate['isolated_dependency_sources'])\n assert runtime['official_wheel']['sha256']==WHEEL_SHA256")
            text = once(text, " sources=dict(first['sources_and_gates'])", " sources=dict(failed['sources'])\n for path,digest in first['sources_and_gates'].items():assert sources[path]==digest,path")
            text = once(text, "  'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py']",
                "  'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py',\n  SOURCE_FILE,'work/check_acquisition_actual_runtime_20261030.py']\n paths.extend(runtime['source_files'])\n paths.extend(Path(row['file']).resolve().relative_to(R.resolve()).as_posix() for row in runtime_certificate['imports'].values())")
            text = once(text, " for path,digest in sources.items():assert sha(R/path)==digest,path",
                " for path,digest in sources.items():assert sha(R/path)==digest,path\n validate_runtime_spec(R,runtime,sources,expected_executable=R/'work/physics_env/Scripts/python.exe')")
            text = once(text, "   'work/coordinate_nonlinear500_receding_acquisition_v2_20261030.py','work/coordinate_acquisition_source_bound_owner_20261030.py'):",
                "   'work/coordinate_nonlinear500_receding_acquisition_v2_20261030.py','work/coordinate_acquisition_source_bound_owner_20261030.py',\n   'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py',SOURCE_FILE):")
            text = once(text, "campaign_id='nonlinear500_receding_acquisition_20261030'", "campaign_id='nonlinear500_receding_acquisition_v2_20261030'")
            text = once(text, "  sources=sources,independent_readiness=gates,readiness_index=ref(R/a.readiness_index),",
                "  sources=sources,independent_readiness=gates,readiness_index=ref(R/a.readiness_index),\n  previous_failed_setup=previous,isolated_owner_runtime=runtime,\n  prospective_difference='Distinct owner paths and isolated pinned psutil admission only; original failed study never restarted.',")
        ast.parse(text)
        with after.open('x', encoding='utf-8', newline='\n') as f:
            f.write(text)
        rows.append(dict(original=before.relative_to(R).as_posix(),original_sha256=sha(before),
                         additive=after.relative_to(R).as_posix(),additive_sha256=sha(after)))
    put(O / 'Source_Preparation.json', dict(status='ADDITIVE_SOURCES_PREPARED_NOT_FROZEN_NOT_LAUNCHED',
        rows=rows,scientific_calls=0,old_source_edits=0,old_owner_restarts=0,
        prospective_protocol_created=False,freeze_executed=False,
        next='Independent delta review, then parent-controlled fresh prospective freeze and separate launch decision.'))


if __name__ == '__main__':
    main()
