"""Strict official8 actor/class and native MAT input gate, no forward/PF/training."""
import ast,json,hashlib,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/online_topology_published_intake_20261020';OUT=SRC/'native_loader_independent_audit_v2'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();(OUT/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)}),encoding='utf-8');import candidate_process_runtime
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np,torch
    import torch.nn as nn
    import torch.nn.functional as F
    from scipy.io import loadmat
    assert not torch.cuda.is_available();meta=json.loads((SRC/'Independent_Byte_And_Source_Intake_Audit.json').read_text(encoding='utf-8'));assert meta['status'].startswith('PASS_')
    for r in meta['files']:assert sha(SRC/'author_reference'/r['path'])==r['sha256']
    source=(SRC/'author_reference/models/safeDDPG.py').read_text(encoding='utf-8');tree=ast.parse(source);node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SafePolicyNetwork_SetPoint');scope={'__name__':'pinned_author_policy_definition_only','np':np,'torch':torch,'nn':nn,'F':F};exec(compile(ast.Module(body=[node],type_ignores=[]),'pinned_author_policy_AST','exec'),scope);C=scope[node.name]
    # The official load_policy function's default hidden64 and names bind all8 actor files.
    rollout=ast.parse((SRC/'author_reference/utils/run_rollouts.py').read_text(encoding='utf-8'));loader=next(n for n in rollout.body if isinstance(n,ast.FunctionDef) and n.name=='load_policy');args={a.arg:ast.literal_eval(d) for a,d in zip(loader.args.args[-len(loader.args.defaults):],loader.args.defaults)};assert args['hidden_dim']==64 and args['obs_dim']==args['action_dim']==1
    results=[]
    for network,nagents in [('13bus',3),('56bus',5)]:
        for i in range(nagents):
            assert time.monotonic()-start<300;f=SRC/'author_reference/checkpoints/single-phase'/network/'NN_control'/f'original_topo_policy_net_checkpoint_a{i}.pth';state=torch.load(f,map_location='cpu',weights_only=True);model=C(None,1,1,64).cpu();model.load_state_dict(state,strict=True)
            assert set(state)==set(model.state_dict()) and all(torch.equal(t,model.state_dict()[n]) and bool(torch.isfinite(t).all()) for n,t in state.items());results.append({'network':network,'agent':i,'checkpoint_sha256':sha(f),'tensor_keys':sorted(state),'parameter_values':sum(t.numel() for t in state.values()),'strict_actual_class_load':True,'forward_calls':0})
    finite=[]
    def visit(v):
        count=0
        if isinstance(v,np.ndarray):
            if v.dtype.names:
                for n in v.dtype.names:count+=visit(v[n])
            elif v.dtype==object:
                for x in v.flat:count+=visit(x)
            elif np.issubdtype(v.dtype,np.number):assert np.isfinite(v).all();count+=v.size
        return count
    for rel in meta['native_network_files']:
        data=loadmat(SRC/'author_reference'/rel);count=sum(visit(v) for n,v in data.items() if not n.startswith('__'));assert count>0;finite.append({'path':rel,'numeric_values_checked':count,'finite':True,'native_solver_or_label_feasibility':'UNKNOWN_UNMEASURED'})
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL8_ORIGINAL_ACTOR64_CLASS_STRICT_WEIGHTS_AND_ALL5_MAT_FINITE_SOURCE_GATES_ONLY','actor_components':results,'native_inputs':finite,'unchanged_class_AST_sha256':hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest(),'global_training_evaluation_code_executed':False,'actual_CPU_checkpoint_deserializations':8,'random_CPU_policy_class_initializations':8,'actual_model_forward_backward_optimizer_PF_GPU_calls':0,'information_and_task':'Unknown-topologyonlineadaptationon13/56bus;source1000steps,notthesamestatic100stepStableDDPGtask. Sourcecheckpointsarebasepolicies,notcertifiedonlineperformance. Do not ranktheirunexecutedoutputs againstotherfeederheadlines.','remaining_gates':['Nativepathrelocation/sourcefunction/fullreset/action/timing/guard/fields/preservation protocol','Nativegurobi-dependenttopology-estimationlibrary/actuallicense/solvercost and taskcost boundaries;no purchase/substitution assumed','Prospectiveexactfirstidentity/history/ownership/independentreader beforeanyactualpolicy/physics','MatchedourLLMrole remains blocked by completed nativePI schema screen;do notretuneorfillinvalidcommands'],'workflow_seconds':time.monotonic()-start}
    (OUT/'Independent_Native_Loader_And_Input_Audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'strict_actor_components':len(results),'native_MAT_files':len(finite),'model_forward_PF_calls':0,'readiness':'SOURCE_AND_LOADER_ONLY_NOT_PERFORMANCE','workflow_seconds':result['workflow_seconds']}))
if __name__=='__main__':main()
