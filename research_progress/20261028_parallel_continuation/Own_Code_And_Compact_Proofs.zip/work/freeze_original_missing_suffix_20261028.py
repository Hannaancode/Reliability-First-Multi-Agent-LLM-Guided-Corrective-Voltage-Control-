"""Freeze two missing suffixes after actual saved-state and registry checks."""
import ast,zipfile
from original_missing_suffix_core_20261028 import *

def main():
    assert read(R/'outputs/missing_suffix_integration_20261028/Results.json')['status']=='PASS_ACTUAL_ORIGINAL_SOURCE_MISSING_SUFFIX_ADMISSION'
    registry=R/'outputs/original_case_registry_20261028/build/Closed_Physical_Receipt_Registry.json'
    audit=R/'outputs/original_case_registry_20261028/audit/Result.json'
    assert read(audit)['index_sha256']==sha(registry)
    for directory in ['outputs/original_case_registry_20261028/audit_coordination','outputs/pending_source_state_20261028/verify_coordination','outputs/missing_suffix_integration_coordination_20261028']:
        end=read(R/directory/'End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    TOP.mkdir(exist_ok=False)
    # Recover the exact existing remote payload source roster; no new remote policy.
    tree=ast.parse((R/'work/finalize_reflection118_three_case_v2_gates_20261023.py').read_text('utf-8'))
    remote=None
    for node in ast.walk(tree):
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='remote_names' for t in node.targets):remote=ast.literal_eval(node.value)
    assert remote
    newnames=['original_missing_suffix_core_20261028.py','original_case_missing_suffix_20261028.py','immutable_response_transport_20261028.py','run_original_missing_suffix_local_20261028.py','run_original_missing_suffix_colab_20261028.py','audit_original_missing_suffix_20261028.py','freeze_original_missing_suffix_20261028.py']
    for namespace in ['execution','independent','coordination','reader_coordination']:
        (R/f'outputs/original_missing_suffix_{namespace}_20261028').mkdir(exist_ok=False)
    rows=[]
    for i in [1,3]:
        old=R/'outputs/reflection118_remaining_cases_v2_preparation_20261023'/f'case_{i:02d}'
        host=R/'outputs/reflection118_remaining_cases_v2_execution_20261023'/f'case_{i:02d}'
        st=read(host/'status.json');assert st['runtime_released'] and st['scientific_process_ended'] and st['all_actual_closed_artifacts_preserved']
        prep=TOP/f'case_{i:02d}';prep.mkdir()
        p=read(old/'Frozen_Engineering_Protocol.json')
        for name,h in p['original_serving_sources'].items():assert sha(R/name)==h
        for name,h in p['local_source_hashes'].items():assert sha(R/name)==h
        pending=R/'outputs/pending_source_state_20261028/capture'/f'case_{i:02d}'
        frontier=read(pending/'Frontier.json')
        p.update(status='FROZEN_MISSING_SUFFIX_NEW_STUDY_OLD_PARTIAL_PRESERVED',question='Complete only the unentered suffix of this original fixed severe case, reconstructing its paid prefix exactly.',
            old_model_calls_for_this_case=frontier['paid_model_responses_consumed'],closed_paid_registry=registry.relative_to(R).as_posix(),
            prior_partial_output=host.relative_to(R).as_posix(),missing_first_original_request=frontier['frontier']['number'],
            selection='BOTH interrupted original cases1and3; completed0and2 reused, no selected winners.',
            no_old_budget_extension=True,no_repeated_prior_model_or_PF=True,old_failure_and_all_costs_retained=True,
            reader_scope='First replay only NEW returned PF, paid-prefix reconstruction then new chronological source replay; all failures/partials retained.',
            local_controller_seconds=7200,reader_seconds=7200)
        newpins={f'work/{n}':sha(R/'work'/n) for n in newnames}
        p['local_source_hashes'].update(newpins)
        for file in [registry,audit,R/'outputs/missing_suffix_integration_20261028/Results.json',pending/'Pending_Source_State.json',pending/'Pending_Source_State.zlib',R/'outputs/pending_source_state_20261028/verify'/f'case_{i:02d}'/'Cold_State_Check.json',R/'outputs/original118_matched_analysis_preparation_20261023/Protocol.json']:
            p['input_hashes'][file.relative_to(R).as_posix()]=sha(file)
        protocol=prep/'Frozen_Engineering_Protocol.json';put(protocol,p)
        authority=prep/'Direct_Human_Authority.json';put(authority,read(old/'Direct_Human_Authority.json'))
        payload={f'work/{n}':R/'work'/n for n in remote};payload.update({n:R/n for n in p['original_serving_sources']})
        adapter=R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
        for n,h in p['private_adapter_tokenizer_unchanged'].items():assert sha(adapter/n)==h;payload[(adapter/n).relative_to(R).as_posix()]=adapter/n
        payload['prep/protocol.json']=protocol
        manifest={n:dict(bytes=f.stat().st_size,sha256=sha(f)) for n,f in payload.items()}
        archive=prep/'Unchanged_Private_Adapter_And_Causal_Service.zip'
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
            for n,f in payload.items():z.write(f,n)
            z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json',json.dumps(manifest,indent=2))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            for n,m in manifest.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
        pm=prep/'Cloud_Payload_Manifest.json';put(pm,dict(archive=archive.relative_to(R).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive),human_authority_source=authority.relative_to(R).as_posix(),human_authority_sha256=sha(authority)))
        for kind,source,python,output,coord,bound in [('Primary','run_original_missing_suffix_colab_20261028.py','work/colab_access_env/Scripts/python.exe','execution','coordination',13500),('Reader','audit_original_missing_suffix_20261028.py','work/vcsa_module_env/Scripts/python.exe','independent','reader_coordination',7500)]:
            put(prep/(kind+'_Owner_Protocol.json'),dict(single_owner=dict(source='work/'+source,sha256=sha(R/'work'/source),python=python,output=f'outputs/original_missing_suffix_{output}_20261028/case_{i:02d}',coordination=f'outputs/original_missing_suffix_{coord}_20261028/case_{i:02d}',bound_seconds=bound,arguments=['--case-index',str(i)])))
        pins=p['local_source_hashes']|p['input_hashes']|{x.relative_to(R).as_posix():sha(x) for x in [protocol,authority,pm]}
        put(prep/'Launch_Readiness_Audit.json',dict(passed=True,source_hashes=pins,old_science_not_repeated=True))
        put(prep/'Final_Allocation_Readiness.json',dict(passed=True,actual_pending_state_and_registry_and_transport_verified=True,protocol_sha256=sha(protocol),fixed_profile=p['local_profile_label'],case_index=i))
        rows.append(dict(case_index=i,first_missing_request=p['missing_first_original_request'],profile=p['local_profile_label'],protocol_sha256=sha(protocol)))
    put(TOP/'Final_Two_Case_Readiness.json',dict(passed=True,cases=rows,new_model_PF_allocations=0,all6_final_goals='OPEN'))
    print(json.dumps(dict(status='TWO_MISSING_SUFFIXES_FROZEN_NO_ALLOCATION_YET',cases=rows)))

if __name__=='__main__':main()
