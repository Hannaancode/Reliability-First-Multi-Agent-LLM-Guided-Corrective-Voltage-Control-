"""Saved-field and altered-input fixtures; zero learned forwards or PF."""
from pathlib import Path
from datetime import datetime,timezone
import copy,gzip,json,os
from action_transition_contract import compile_current_action,vm_vector,measured_training_target,forecast_from_residual
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
OUT=P/'action_transition_contract_software_readiness'
assert not OUT.exists();OUT.mkdir()
with gzip.open(P/'measured_OPT_transition_inventory/Actual_OPT_Transition_Rows.jsonl.gz','rt',encoding='utf8') as f:
    rows=[json.loads(l) for l in f]
with gzip.open(P/'OPT_transition_AC_vector_measurement/Actual_Transition_Vector_Records.jsonl.gz','rt',encoding='utf8') as f:
    vectors={r['transition_id']:r for r in (json.loads(l) for l in f)}
checks=[]
def rejects(name,function):
    try:function()
    except ValueError:checks.append(name);return
    raise AssertionError(name+' accepted altered input')
for r in rows:
    v=vectors[r['transition_id']]; inp=compile_current_action(r['model_input'])
    assert inp==r['model_input'] and set(inp)=={'current_physical_observation','current_control_state','original_Q_grid','candidate_action'}
    target=measured_training_target(inp,r['measured_target'],v['analytic_next_vm'])
    assert target['measured_delta_vm']==v['measured_delta_vm']
    current=vm_vector(inp['current_physical_observation']['physical_tables']['res_bus'])
    assert forecast_from_residual(current,[0.]*118,0.,1.,[99.]*118)==current
    # An exact mock residual reproduces the saved successor; this is algebra,
    # explicitly not learned prediction accuracy.
    q=inp['candidate_action']['q_abs_mvar'];mock=[x*300./q for x in target['measured_minus_analytic_vm']]
    result=forecast_from_residual(current,v['analytic_delta_vm'],q,1.,mock)
    assert max(abs(a-b) for a,b in zip(result,target['actual_next_vm']))<=1e-14
checks.extend(['all216exact_current_action_inputs','all216target_forward_separation','all216zero_action_algebra',
               'all216mock_residual_reconstruction_not_learning'])
r=rows[0];i=r['model_input']
for key in ('scenario_id','world_sha256','after','label'):
    bad=copy.deepcopy(i);bad[key]=0
    rejects('reject_'+key,lambda bad=bad:compile_current_action(bad))
bad=copy.deepcopy(i);bad['candidate_action']['q_abs_mvar']=37.
rejects('reject_nonoriginal_Q',lambda:compile_current_action(bad))
bad=copy.deepcopy(i);bus=bad['candidate_action']['bus'];bad['current_control_state']['added_abs_Q_MVAr_by_bus'][bus]=450.
rejects('reject_overcap',lambda:compile_current_action(bad))
bad=copy.deepcopy(i);bad['current_physical_observation']['raw_common_and_zone_pools']={z:[] for z in bad['current_physical_observation']['raw_common_and_zone_pools']}
rejects('reject_missing_raw_AND_scope',lambda:compile_current_action(bad))
target=copy.deepcopy(r['measured_target']['next_res_bus']);target['index'][0]=target['index'][1]
rejects('reject_duplicate_target_bus',lambda:vm_vector(target))
rejects('reject_nonfinite_forecast',lambda:forecast_from_residual([1.]*118,[0.]*118,25.,1.,[float('nan')]*118))
result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'all_software_checks_passed':True,
        'checks':checks,'saved_OPT_inputs_checked':216,'label':'Software/saved-algebra fixtures ONLY',
        'actual_pretrained_random_model_forward_optimizer_PF_cloud_calls':0,
        'source_sha256':sha(ROOT/'work/action_transition_contract.py'),
        'no_LLM_policy_novelty_framework_gradient_or_generalization_claim':True}
write(OUT/'Software_Readiness.json',result)
seal(OUT,{'Software_Readiness.json':OUT/'Software_Readiness.json','source/contract.py':ROOT/'work/action_transition_contract.py',
          'source/checker.py':Path(__file__)},'Action_Transition_Contract_Software.zip')
print(json.dumps(result,indent=2))
