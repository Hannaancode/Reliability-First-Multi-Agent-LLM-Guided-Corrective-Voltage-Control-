"""Source/data-only assessment of attribution confounds, zero model/PF."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/vcsa_development/attribution_readiness'
assert not OUT.exists()
rows=json.loads((ROOT/'outputs/vcsa_development/training_interface/rows.json').read_text())
cfg_path=ROOT/'work/vcsa_public_base_cache/models--unsloth--qwen2.5-0.5b-instruct-unsloth-bnb-4bit/snapshots/10413c288cb9629acdf60b3e0229f3ba75efe413/config.json'
cfg=json.loads(cfg_path.read_text())
h,w,g,r,active,q,n,f=cfg['hidden_size'],64,4,4,2,9,118,7
assert h==896 and cfg['num_hidden_layers']==24 and cfg['num_attention_heads']==14 and cfg['num_key_value_heads']==2
encoder=f*w+w+n*w+4*w+w*w+2*w
heads=h*w+w+w*w+2*w*q+q+2*w*(q*6)+q*6+2*w+1
state_query=w*h+h
injectors=2*(h*w+2*w*w+w*h)
router=w*g+g
kv_width=(h//cfg['num_attention_heads'])*cfg['num_key_value_heads']
rank_paths=2*(g*r*(h+h)+g*r*(h+kv_width))
counts={'state_only':encoder+state_query+heads,'frozen_LM_heads':encoder+heads,
        'VCSA_full':encoder+heads+injectors+router+rank_paths}
state_keys={}
for row in rows:
    if not row['training_eligible']: continue
    message=json.loads(row['input']['messages'][1]['content'])
    keys=sorted(message['zone_state'])
    state_keys[row['local_observation_id']]=keys
assert len(state_keys)==47 and len({tuple(keys) for keys in state_keys.values()})==1
OUT.mkdir(parents=True)
report={'assessed_at_utc':datetime.now(timezone.utc).isoformat(),
        'kind':'Static source/config/data assessment; no new performance study',
        'module_parameter_counts_from_exact_shapes':counts,
        'parameter_count_limit':'Trainable new module tensors only; frozen base/adapter and inactive control paths excluded. No equal FLOP/memory claim.',
        'VCSA_to_state_only_new_parameter_ratio':counts['VCSA_full']/counts['state_only'],
        'VCSA_to_frozen_LM_heads_new_parameter_ratio':counts['VCSA_full']/counts['frozen_LM_heads'],
        'all_47_prompt_zone_fields':next(iter(state_keys.values())),
        'state_only_numeric_features':['vm_pu','UV_deficit','upper_excess','candidate_membership','load_bus_type','gen_bus_type','DER_bus_type'],
        'information_confound_examples':['tie_line_flows including P/Q/loading/service/endpoints','total_load_mw and total_load_mvar','generator actual P/Q/setpoint/service','DER/storage P/Q/service/capacity'],
        'state_only_has_static_graph':True,'LM_prompts_have_extra_observed_local_quantities':True,
        'frozen_LM_heads_vs_VCSA_share_prompt_and_graph':True,
        'VCSA_vs_frozen_heads_has_trainable_capacity_confound':True,
        'existing_3_arm_pilot_can_establish_clean_incremental_LLM_value':False,
        'pilot_role':'Necessary training/integration/mechanism screen only; retain original plan/results unchanged',
        'required_before_attribution_campaign':['Common information contract for learned and strong non-LLM controls','Predeclared capacity control and internal-path ablations','Matched trajectories versus literal D-SE with both branch costs','Unused independent confirmation source'],
        'no_new_control_or_hyperparameter_sweep_authorized_here':True,
        'PF_calls':0,'pretrained_calls':0,'training_steps':0,
        'input_sha256':{str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in [cfg_path,ROOT/'work/vcsa_modules_v2.py',ROOT/'outputs/vcsa_development/training_interface/rows.json']}}
(OUT/'summary.json').write_text(json.dumps(report,indent=2))
(OUT/'manifest.json').write_text(json.dumps({'summary.json':{'bytes':(OUT/'summary.json').stat().st_size,'sha256':hashlib.sha256((OUT/'summary.json').read_bytes()).hexdigest()}},indent=2))
print(json.dumps(report))
