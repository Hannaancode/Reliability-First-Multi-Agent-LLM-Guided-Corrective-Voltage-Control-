"""Close this verified research unit and retain exact next execution gates."""
import ast,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import seal,frozen_checks
R=Path(__file__).resolve().parents[1];B=R/'outputs/referenced_controller_research_handoff_20261018'
def read(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
def put(p,d):p.write_text(json.dumps(d,indent=2),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    now=datetime.now(timezone.utc).isoformat()
    frontier=read('outputs/paid_lineage_frontier_20261018/audit/Independent_Frontier_Audit.json')
    factory=read('outputs/referenced_controller_factory_cold_capacity_v2_20261018/Results.json')
    assert frontier['status'].startswith('PASS_ALL_LINEAGE') and factory['status']=='PASS'
    sources=[R/'work/receding_paid_referenced_runtime_v2_20261018.py',R/'work/paid_receding_referenced_commit_v2_20261018.py',R/'work/paid_receding_journal_reference_history_v2_20261018.py']
    closure=set();pending=list(sources)
    while pending:
        path=pending.pop().resolve()
        if path in closure:continue
        closure.add(path)
        for n in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig'))):
            names=[a.name for a in n.names] if isinstance(n,ast.Import) else [n.module] if isinstance(n,ast.ImportFrom) and n.module else []
            for name in names:
                other=R/'work'/Path(*name.split('.')).with_suffix('.py')
                if other.is_file() and other.resolve() not in closure:pending.append(other)
    put(B/'Prepared_Referenced_Runtime_Local_Source_Closure.json',{'status':'SOURCE_INVENTORY_ONLY_NOT_A_PERFORMANCE_LAUNCH_LOCK','sources':{str(p.relative_to(R)):sha(p) for p in sorted(closure)},'scientific_calls':0,'future_source_owner_reader_protocol_still_required':True})
    facts={'at_utc':now,'status':'VERIFIED_ALL26_COMMITTED_PREFIX_PLUS_REFERENCED_FACTORY_AND_LINEAGE_FRONTIER',
        'scoped_physics_checkpoint':str((B/'Verified_Research_Checkpoint.json').relative_to(R)),
        'verified_one_world_zero_UV':'17 residual UV to0 in both closed numerical suffixes;11vs14 added operations, within original25 budget. No LLM causal advantage or fullDSE victory.',
        'lineage_frontier_audit':frontier,'capacity_v2_saved_real_factory_checks':sum(factory['cold']['checks'].values()),
        'capacity_v2_future_query_guard':read('outputs/referenced_controller_factory_cold_capacity_v2_20261018/Future_Query_Rejection.json'),
        'source_closure_modules':len(closure),'new_scientific_calls_in_this_unit':0,
        'owned_science_GPU_collector_reader_jobs':[],
        'next_tasks_in_order':[
            'Bind full-native v2 source/encoding admission to actual prospective input bounds (118buses/9Q/<=25ownedrows, <=27,628queryrefs, <=1024bytes/ref, <=8MiB metadata). Saved real factory/cold passes do not alone certify every future input.',
            'Build the future reader and cache consumer around the verified60,377-key inspected lineage frontier. Every recorded receipt requires independent source/physical-result checks before use; old attempts never repeat; missing/out-of-lineage history stays UNKNOWN, not permission.',
            'Freeze a separately justified genuinely unexecuted measurement protocol, exact cases, both fixed policies/strong controls, complete/partial reader, source/input/ownership/preservation/cost/bounds BEFORE physics. Do not restart old owner/budget or infer missing26th complete checkpoint.',
            'Then bind actual original LOCAL model/family broker causal serving role with numerical-only and trained numerical ablations. No further size-only imitation retraining; fresh full protected trajectories and unused confirmation required before LLM value.',
            'Keep all141 source recipes and73 missing old outcomes explicit; primary>=60 initial-UV cases remain unsolved/unverified. Published benchmark/security tasks remain pending their scientific gates.'
        ],
        'all_four_full_policy_or_LLM_superiority_gate':'UNKNOWN_OR_UNACHIEVED','no_new_timer_or_idle_GPU':True}
    put(B/'Exact_Next_Execution_State.json',facts);put(B/'Final_Frozen_Checks.json',frozen_checks())
    marker='18OCT VERIFIED ONE-WORLD ZERO-UV PREFIX; SOURCE-FRONTIER AND REFERENCED COLD GATES PASS'
    note=f'{marker} {now}\n\nAll26 actual recorded commits scoped-audited; both recorded closed numeric suffixes on line35 go17UVto0 (11vs14 addedops), not fullDSE/LLM/all-severe superiority. FullfourworldgateUNKNOWN. Exact2,580-receipt35.23MB history becomes1.323MB references with cold exactness. v2full-native capacity binding now passes17 saved-real cold factory checks and rejects futurequeryreferences; actual future-input admission/complete-reader/source-owner protocol still required before physics. Verified lineage index60,377 keys=22,721warm+37,656newprimaryattempts; all15solverexceptions retained. It is source/identity closure for4inspected roots, not globally all141cases or independent physical certification of every unchosen candidate. Newphysics/model/optimizer/forecast/solve0; no ownedscience/GPU/reader jobs or timers. Exact next work outputs/referenced_controller_research_handoff_20261018/Exact_Next_Execution_State.json.\n\n'
    p=R/'reseacrh progress.txt';p.write_text(p.read_text(encoding='utf-8')+'\n'+note,encoding='utf-8')
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_INDEX.md']:
        p=R/rel;p.write_text(note+p.read_text(encoding='utf-8'),encoding='utf-8')
    for rel in ['outputs/critical_research_reset_20261010/Research_Resume_20261012.json','outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json']:
        p=R/rel;d=read(rel);d.update(latest_referenced_controller_checkpoint=str((B/'Verified_Research_Checkpoint.json').relative_to(R)),latest_exact_execution_state=str((B/'Exact_Next_Execution_State.json').relative_to(R)),next_tasks_in_order=facts['next_tasks_in_order'],owned_science_collector_reader_jobs=[],latest_completed_at_utc=now);put(p,d)
    plan=B/'Results_And_Next_Execution.md'
    plan.write_text(plan.read_text(encoding='utf-8')+'\n## Final follow-through\n\nThe v2 capacity component is now bound to a separate original-commit/runtime namespace and passed the17 actual saved-real cold factory checks plus the future-receipt rejection test. A recursive local-source inventory is saved. This still requires prospective actual-input admission and a frozen complete/partial performance reader/owner protocol. The complete inspected-lineage index and independent reader verified60,377 keys,37,656 new primary attempts and15 recorded solver exceptions. Index identity/source closure is not independent physical validation of every candidate; absent keys do not prove globally unexecuted work. Read Exact_Next_Execution_State.json.\n',encoding='utf-8')
    files={}
    for name in ['paid_receding_journal_reference_history_v2_20261018.py','paid_receding_referenced_commit_v2_20261018.py','receding_paid_referenced_runtime_v2_20261018.py','check_referenced_controller_factory_cold_capacity_v2_20261018.py','prepare_paid_lineage_frontier_20261018.py','audit_paid_lineage_frontier_20261018.py',Path(__file__).name]:files['work/'+name]=R/'work'/name
    for folder in ['referenced_controller_factory_cold_capacity_v2_20261018','paid_lineage_frontier_20261018']:
        for path in (R/'outputs'/folder).rglob('*'):
            if path.is_file() and path.suffix in ['.json','.log']:files[str(path.relative_to(R)).replace('\\','/')]=path
    for path in [B/'Exact_Next_Execution_State.json',B/'Prepared_Referenced_Runtime_Local_Source_Closure.json',B/'Final_Frozen_Checks.json',B/'Results_And_Next_Execution.md']:files[str(path.relative_to(R)).replace('\\','/')]=path
    archive=seal(B/'final_frontier_supplement' if False else B,files,'Referenced_Factory_And_Lineage_Frontier_Metadata_20261018.zip')
    print(json.dumps({'complete':True,'frontier_keys':frontier['keys'],'source_modules':len(closure),'archive':archive}))
if __name__=='__main__':main()
