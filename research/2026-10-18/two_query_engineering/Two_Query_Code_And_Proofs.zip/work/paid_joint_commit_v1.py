"""Paid, protected joint commits with complete operation/stock accounting.

This component supplies no solver, model, allocation or automatic resume.
The caller must supply an anchored actual paid result and a fixed protocol.
"""
import copy
import hashlib
import json
import os
import pickle
from datetime import datetime
from pathlib import Path

from audit_spatial_allocation_inputs_v3_20261011 import signature
from durable_opaque_evidence_store_v1 import local_root
from lossless_evidence_byte_codec_v1 import canonical, digest, encode, decode
from owned_bank_joint_reallocation_v1 import Q_GRID

MODE = 'ACTUAL_PAID_PROTECTED_ENGINEERING_BRANCH'


def fields(net):
    import math
    result = {str(int(b)): {k: float(net.res_bus.at[b, k])
              for k in ('vm_pu', 'va_degree', 'p_mw', 'q_mvar')}
              for b in net.res_bus.index}
    assert len(result) == 118 and all(math.isfinite(v) for row in result.values() for v in row.values())
    return result


def fingerprint(net, cursor):
    return digest(canonical({'input': signature(net)[0], 'fields': fields(net), 'cursor': cursor}))


def initialize(net, original):
    cursor = copy.deepcopy(original)
    cursor.update(commit_mode=MODE, committed_transitions=[], withdrawn_lifetime_MVAr={},
                  original_device_operation_budget=25)
    validate(net, cursor)
    return cursor


def validate(net, cursor):
    import math
    assert cursor['commit_mode'] == MODE and bool(net.converged)
    assert cursor['withdrawals_refund_positive_addition_cap'] is False
    assert cursor['original_device_operation_budget'] == 25
    scope = cursor['raw_current_receiver_scope']
    assert isinstance(scope, list) and len(scope) == len(set(scope))
    assert all(type(b) is int and b in net.bus.index for b in scope)
    positive = {}; withdrawn = {}; charged = 0; seen = set()
    for action in cursor['original_prefix_actions']:
        assert set(action) == {'add_shunts_q_mvar'} and len(action['add_shunts_q_mvar']) == 1
        bus, q = next(iter(action['add_shunts_q_mvar'].items())); q = float(q)
        assert q in Q_GRID
        positive[str(int(bus))] = positive.get(str(int(bus)), 0.) + q; charged += 1
    for transition in cursor['committed_transitions']:
        assert transition['actual_new_branch_commit'] is True
        assert transition['historical_query_was_not_relabelled_as_past_commit'] is True
        assert transition['commit_id'] not in seen; seen.add(transition['commit_id'])
        row = transition['candidate']; q = float(row['q']); bus = str(row['receiver'])
        assert q in Q_GRID and row['kind'] in ('ordinary', 'equal_owned_reallocation')
        debit = 1 if row['kind'] == 'ordinary' else 2
        assert debit == transition['device_operations_debited']; charged += debit
        positive[bus] = positive.get(bus, 0.) + q
        if debit == 2:
            donor = str(row['donor_bus']); withdrawn[donor] = withdrawn.get(donor, 0.) + q
    assert positive == cursor['positive_addition_lifetime_MVAr']
    assert withdrawn == cursor['withdrawn_lifetime_MVAr']
    assert all(math.isfinite(v) and 0 <= v <= 450 for v in positive.values())
    assert type(cursor['remaining_original_device_operation_slots']) is int
    assert cursor['remaining_original_device_operation_slots'] == 25 - charged >= 0
    rows = cursor['owned_bank_rows']; assert len({r['index'] for r in rows}) == len(rows)
    sums = {}
    for owned in rows:
        assert type(owned['index']) is int and owned['index'] in net.shunt.index
        actual = net.shunt.loc[owned['index']]; bus = str(int(actual.bus)); q = float(actual.q_mvar)
        assert int(owned['bus']) == int(actual.bus) and owned['q_mvar'] == q
        assert owned['name'] == str(actual['name']) and q <= 0
        assert float(actual.p_mw) == 0 and float(actual.step) == 1 and bool(actual.in_service)
        assert not bool(actual.get('step_dependency_table', False))
        sums[bus] = sums.get(bus, 0.) - q
    for bus in set(positive) | set(withdrawn) | set(sums):
        assert sums.get(bus, 0.) == positive.get(bus, 0.) - withdrawn.get(bus, 0.)
    return True


def commit_paid(before, after, cursor, row, receipt, *, commit_id, actuate, next_scope):
    validate(before, cursor)
    assert receipt['before_fingerprint'] == fingerprint(before, cursor)
    assert receipt['accepted'] is True and receipt['converged'] is True
    assert fields(after) == receipt['fields'] and bool(after.converged)
    assert max(x['vm_pu'] for x in receipt['fields'].values()) <= 1.05 + 1e-8
    assert receipt['receipt_id'] and commit_id and all(t['commit_id'] != commit_id for t in cursor['committed_transitions'])
    assert all(t['paid_receipt_id'] != receipt['receipt_id'] for t in cursor['committed_transitions'])
    assert row['receiver'] in cursor['raw_current_receiver_scope'] and row['q'] in Q_GRID
    debit = 1 if row['kind'] == 'ordinary' else 2
    assert cursor['remaining_original_device_operation_slots'] >= debit
    from joint_reallocation_opportunity_core_v1 import action
    expected = actuate(copy.deepcopy(before), action(row))
    assert signature(expected) == signature(after), 'All non-result input tables must match actual actuation'
    result = copy.deepcopy(cursor); bus = str(row['receiver']); q = float(row['q'])
    result['positive_addition_lifetime_MVAr'][bus] = result['positive_addition_lifetime_MVAr'].get(bus, 0.) + q
    result['remaining_original_device_operation_slots'] -= debit
    if debit == 2:
        donor = str(row['donor_bus'])
        result['withdrawn_lifetime_MVAr'][donor] = result['withdrawn_lifetime_MVAr'].get(donor, 0.) + q
        bank = next(r for r in result['owned_bank_rows'] if r['index'] == row['donor_index'])
        bank['q_mvar'] += q
    introduced = [int(i) for i in after.shunt.index if i not in before.shunt.index]
    assert len(introduced) == 1
    bank = after.shunt.loc[introduced[0]]
    result['owned_bank_rows'].append({'index': introduced[0], 'bus': int(bank.bus),
        'name': str(bank['name']), 'q_mvar': float(bank.q_mvar), 'origin': MODE})
    result['committed_transitions'].append({'commit_id': commit_id, 'candidate': copy.deepcopy(row),
        'paid_receipt_id': receipt['receipt_id'], 'device_operations_debited': debit,
        'actual_new_branch_commit': True, 'historical_query_was_not_relabelled_as_past_commit': True})
    result['raw_current_receiver_scope'] = copy.deepcopy(next_scope)
    validate(after, result)
    return result


def save(path, state, anchors):
    assert set(state) == {'net', 'cursor', 'paid_query_registry', 'python_rng', 'numpy_rng',
                          'costs', 'absolute_deadline_utc', 'protocol_sha256', 'next_phase'}
    validate(state['net'], state['cursor'])
    assert datetime.fromisoformat(state['absolute_deadline_utc']).tzinfo is not None
    assert set(anchors) == {'source', 'input', 'paid_receipt', 'predecessor'}
    assert all(t['paid_receipt_id'] in state['paid_query_registry'] for t in state['cursor']['committed_transitions'])
    raw = pickle.dumps(state, protocol=5)
    packet, manifest = encode(raw, anchors=anchors, max_raw_bytes=32*1024**2, max_encoded_bytes=16*1024**2)
    path = local_root(path); path.mkdir(parents=True, exist_ok=False)
    for name, data in [('State.zlib', packet), ('Manifest.json', canonical(manifest))]:
        with (path/name).open('xb') as file:
            file.write(data); file.flush(); os.fsync(file.fileno())
    return {'manifest_sha256': digest(canonical(manifest)), 'raw_sha256': digest(raw),
            'state_fingerprint': fingerprint(state['net'], state['cursor']), 'mode': MODE}


def restore(path, receipt):
    assert receipt['mode'] == MODE
    path = local_root(path); manifest = json.loads((path/'Manifest.json').read_bytes())
    raw = decode((path/'State.zlib').read_bytes(), manifest,
                 expected_manifest_sha256=receipt['manifest_sha256'], expected_raw_sha256=receipt['raw_sha256'],
                 max_raw_bytes=32*1024**2, max_encoded_bytes=16*1024**2)
    state = pickle.loads(raw); validate(state['net'], state['cursor'])
    assert fingerprint(state['net'], state['cursor']) == receipt['state_fingerprint']
    return state
