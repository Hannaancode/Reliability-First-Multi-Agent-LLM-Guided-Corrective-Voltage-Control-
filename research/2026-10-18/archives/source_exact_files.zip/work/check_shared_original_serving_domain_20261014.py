"""Actual-input source-domain closure; no model or power-flow calls."""
import copy, hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path
import pandapower as pp
from frozen_physics_loader import load_stack, AUDIT
from joint_reallocation_opportunity_core_v1 import load_endpoint, Q_GRID
from shared_original_serving_action_domain_v1 import build_current_domain, joint_eligible_original_local_proposal

R = Path(__file__).resolve().parents[1]
B = R/'outputs/shared_original_serving_domain_20261014'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def put(path, value):
    with path.open('x', encoding='utf8') as file:
        json.dump(value, file, indent=2); file.flush(); os.fsync(file.fileno())

def main():
    B.mkdir(exist_ok=False); _, runner, _ = load_stack(); assert all(r['all_function_asts_unchanged'] for r in AUDIT)
    def blocked(*args, **kwargs): raise AssertionError('No physical/model call in source-domain software closure')
    for name in ('runpp', 'runopp', 'rundcpp', 'rundcopp'): setattr(pp, name, blocked)
    original = read(R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012/preparation/Protocol.json')
    expected = read(R/'outputs/original_local_common_scope_20261014/Verified_Source_Domain_Difference.json')
    metadata = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = metadata.get('zones', metadata)
    checks = []; worlds = []
    for entry, target in zip(original['current_endpoints'], expected['worlds']):
        net, cursor, _ = load_endpoint(entry); before = copy.deepcopy(cursor)
        domain = build_current_domain(net, cursor, runner=runner, zones=zones)
        assert cursor == before
        assert domain['shared_raw_receivers_for_BOTH_controls'] == target['source_defined_fair_joint_union']
        rows = domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
        assert all(row['receiver'] in target['source_defined_fair_joint_union'] and row['q'] in Q_GRID for row in rows)
        assert len({(r['kind'], r['receiver'], r['q'], r['donor_index']) for r in rows}) == len(rows)
        for receiver in target['source_defined_fair_joint_union']:
            assert {r['q'] for r in rows if r['kind'] == 'ordinary' and r['receiver'] == receiver} == set(Q_GRID)
        checks.append(entry['world']+'|exact_shared_union_original9Q_and_no_cursor_mutation')
        for zone in sorted(zones):
            allowed = domain['original_LOCAL_allowed_per_zone'][zone]
            if not allowed: continue
            bus = allowed[0]
            # Original175 stays175. It cannot enter the NEWjoint9grid by a
            # silent normalization, candidate-set rewrite or sign flip.
            proposal = {'proposed_action': {'add_shunts_q_mvar': {str(bus): 175.}}}
            result = joint_eligible_original_local_proposal(proposal, zone=zone, domain=domain, runner=runner)
            assert result['original_action'] == {'add_shunts_q_mvar': {str(bus): 175.}}
            assert result['original_candidate_valid'] and not result['joint_eligible']
            checks.append(entry['world']+'|'+zone+'|original175_preserved_newjointgate_rejects')
        limited = copy.deepcopy(cursor); limited['remaining_original_device_operation_slots'] = 1
        one = build_current_domain(net, limited, runner=runner, zones=zones)
        assert all(r['kind'] == 'ordinary' for r in one['all_declared_original9Q_ordinary_and_owned_joint_identities'])
        limited['remaining_original_device_operation_slots'] = 0
        zero = build_current_domain(net, limited, runner=runner, zones=zones)
        assert zero['all_declared_original9Q_ordinary_and_owned_joint_identities'] == []
        checks.append(entry['world']+'|one_and_zero_operation_budget')
        worlds.append({'world': entry['world'], 'shared_receivers': domain['shared_raw_receivers_for_BOTH_controls'],
            'declared_future_ordinary': sum(r['kind'] == 'ordinary' for r in rows),
            'declared_future_owned_joint': sum(r['kind'] == 'equal_owned_reallocation' for r in rows),
            'all_actions_planned_NOT_measured': True, 'actual_cursor_unchanged': True})
    checkpoint = {'status': 'PASS_SOURCE_BOUND_SHARED_ORIGINAL_SERVING_DOMAIN_SOFTWARE', 'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'checks': checks, 'worlds': worlds, 'new_model_PF_optimizer_forecast_calls': 0,
        'source_sha256': {'work/shared_original_serving_action_domain_v1.py': sha(R/'work/shared_original_serving_action_domain_v1.py'),
            'work/check_shared_original_serving_domain_20261014.py': sha(Path(__file__)),
            'work/owned_bank_joint_reallocation_v1.py': sha(R/'work/owned_bank_joint_reallocation_v1.py'),
            'work/joint_reallocation_opportunity_core_v1.py': sha(R/'work/joint_reallocation_opportunity_core_v1.py')},
        'original_sources': {str(Path(a['file']).relative_to(R)): a['sha256'] for a in AUDIT},
        'running_full_suffix_source_protocol_scope_unchanged': True,
        'physical_query_execution_economics_model_performance_confirmation': 'NOT_READY_OR_NOT_MEASURED',
        'next_gate': 'Separately freeze source-defined equal-domain physics/model controls, compare actual prior executed identities, and fix complete source/input/cost/preservation/reader bounds before ANY future measurement.'}
    put(B/'Verified_Shared_Domain_Software_Checkpoint.json', checkpoint)
    entry = {'event_id': 'shared_original_LOCAL_numeric_action_domain_component_20261014',
        'method': 'Implement source-defined global/common plusALL4LOCAL union shared identically by future model/numeric controllers; explicit original parser versusNEWjoint9grid eligibility.',
        'result': '24 actual-input source/causal/domain/operation/175magnitude software checks PASS acrossALL4states. Complete domain identities enumerated withoutPF/model calls. Old parser, cursor and live full-suffix scientific scope unchanged.',
        'improvements': 'The unequal candidate-domain confound now has a concrete shared-control component. Original175 is preserved and explicitly rejected for newjoint9grid; one-slot/zero-slot cursors cannot invent joint operations.',
        'limitations': 'Only software/input evidence; enumerated actions areNOTexecuted physics. No physical improvement, model value, cost advantage, novelty or unusedconfirmation established.',
        'decision': 'Keep running science immutable and scheduled result check. Future shared-domain measurements need separate prospective identity inventory/source/fullcost/preservation controls before launch.',
        'sources': [str((B/'Verified_Shared_Domain_Software_Checkpoint.json').relative_to(R)), 'work/shared_original_serving_action_domain_v1.py', 'work/check_shared_original_serving_domain_20261014.py']}
    put(B/'Research_Progress_Entry.json', entry)
    done = subprocess.run([str(R/'work/physics_env/Scripts/python.exe'), '-X', 'utf8', str(R/'work/append_research_progress.py'),
        '--entry-json', str(B/'Research_Progress_Entry.json')], capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    assert done.returncode == 0, done.stderr
    path = R/'outputs/critical_research_reset_20261010/Research_Resume_20261012.json'; resume = read(path)
    resume['latest_shared_original_serving_action_domain'] = str((B/'Verified_Shared_Domain_Software_Checkpoint.json').relative_to(R))
    with path.open('w', encoding='utf8') as file: json.dump(resume, file, indent=2); file.flush(); os.fsync(file.fileno())
    print(json.dumps({'source_domain_checks': len(checks), 'all4source_domains_closed': True, 'new_scientific_calls': 0}))

if __name__ == '__main__': main()
