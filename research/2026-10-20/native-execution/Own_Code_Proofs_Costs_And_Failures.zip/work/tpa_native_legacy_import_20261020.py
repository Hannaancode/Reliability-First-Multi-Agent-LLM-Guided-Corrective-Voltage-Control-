"""One explicit legacy schema import; no balanced-PF or source-field edits."""
def import_native(pp,path):
    import copy
    from pandapower.convert_format import convert_format
    net=pp.from_pickle(path,convert=False)
    original={k:v.copy(deep=True) for k,v in net.items() if hasattr(v,'columns')}
    assert 'type' not in net.sgen.columns and 'current_source' not in net.sgen.columns
    # The modern converter otherwise indexes a missing legacy sgen.type column.
    # This flag is the public create_sgen default and is unused by balanced runpp.
    # It is NOT a certified short-circuit/fault-current model of these inverters.
    net.sgen['current_source']=True
    convert_format(net)
    differences=[]
    for name,old in original.items():
        if name in ['line_geodata','bus_geodata']:
            differences.append({'table':name,'kind':'standard_geodata_to_geo_renderer_schema_conversion_original_source_retained'});continue
        new=net[name]
        assert old.index.equals(new.index)
        for column in old.columns:
            if column not in new.columns:differences.append({'table':name,'column':column,'kind':'legacy_column_removed_by_standard_converter'})
            elif not old[column].equals(new[column]):
                import numpy as np
                a=old[column].to_numpy();b=new[column].to_numpy()
                try:same=np.array_equal(a,b,equal_nan=True)
                except TypeError:
                    import pandas as pd
                    same=all((pd.isna(x) and pd.isna(y)) or x==y for x,y in zip(a,b))
                assert same,'Native source values changed: '+name+'.'+column
        differences.extend({'table':name,'column':c,'kind':'standard_schema_column_added'} for c in new.columns if c not in old.columns)
    return net,{'explicit_sgen_current_source_default':True,'balanced_runpp_sgen_type_current_source_not_used_in_build_gen_bus_pd2ppc_source':True,'source_numeric_values_unchanged':True,'standard_converter_schema_changes':differences,'short_circuit_type_information':'UNKNOWN_NOT_CERTIFIED'}
