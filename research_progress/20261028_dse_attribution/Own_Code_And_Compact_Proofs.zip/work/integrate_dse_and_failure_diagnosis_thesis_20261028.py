"""New thesis copy: stronger saved control and unchanged adverse public diagnosis."""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import hashlib,json,zipfile
from docx import Document
from docx.shared import Pt,Mm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_dse_and_public_diagnosis_20261028'
BASE=R/'outputs/thesis_attribution_and_comparators_20261028/Hannaan_Thesis_Attribution_And_Comparators.docx'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists();d=Document(BASE);beforehash=sha(BASE)
    result=rd('outputs/original118_saved_dse_reconciliation_20261028/Comparison.json')
    proof=rd('outputs/original118_saved_dse_reconciliation_20261028/independent/Independent_Audit.json')
    assert proof['status'].startswith('PASS_ALL4_')
    diagnosis=rd('outputs/public13_saved_numeric_stagnation_20261022/All500_Arithmetic_Diagnosis.json')
    assert diagnosis['all_counts']['accepted_unchanged_Q']==14387
    anchor=next(p._p for p in d.paragraphs if p.text=='Chapter 8 Cybersecurity scope existing stress tests and evaluation design')
    def para(s,style='Normal'):
        p=d.add_paragraph(s,style);anchor.addprevious(p._p)
        p.paragraph_format.space_after=Pt(6)
        if style=='Normal':p.paragraph_format.widow_control=True
        for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(12 if style=='Normal' else 11 if style=='Caption' else 14)
        return p
    def table(caption,headers,rows,widths):
        cp=para(caption,'Caption');cp.paragraph_format.keep_with_next=True
        t=d.add_table(rows=1,cols=len(headers));t.autofit=False
        for col,w in zip(t.columns,widths):col.width=Mm(w)
        for j,s in enumerate(headers):t.rows[0].cells[j].text=s
        for row in rows:
            cells=t.add_row().cells
            for j,s in enumerate(row):cells[j].text=str(s)
        borders=OxmlElement('w:tblBorders')
        for name in ('top','left','bottom','right','insideH','insideV'):
            e=OxmlElement('w:'+name);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
        t._tbl.tblPr.append(borders)
        for i,row in enumerate(t.rows):
            pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
            if i==0:pr.append(OxmlElement('w:tblHeader'))
            for c,w in zip(row.cells,widths):
                c.width=Mm(w)
                for p in c.paragraphs:
                    p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(4)
                    for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(10.5);rr.bold=i==0
        anchor.addprevious(t._tbl)
        # Extend the existing manual list without touching earlier entries.
        previous=next(p for p in d.paragraphs if p.text.startswith('Table 7.8 ') and '\t' in p.text)
        if caption.startswith('Table 7.10'):previous=next(p for p in d.paragraphs if p.text.startswith('Table 7.9 ') and '\t' in p.text)
        e=deepcopy(previous._p);q=Paragraph(e,previous._parent);q.text=caption+'\t0';previous._p.addnext(e)
    para('7.14 Stronger saved numerical envelope on the four severe roots','Heading 2')
    para('A stronger numerical control was already executed before the latest original-model continuations. It runs DFF and DFF-ALT, then applies the unchanged safety-envelope selector. DFF-ALT changes only the first accepted action to the second-ranked distinct candidate; subsequent steps use DFF. The present analysis reuses those results rather than executing either branch again.')
    para('The four scenario hashes and seven shared source hashes agree with the recent comparison. Each earlier DFF result is exactly equal to its recent complete result object, including all metrics, counters, actions, logs and stopping reasons. The 29 DFF committed actions therefore provide a particularly strong check of the join. The old DFF-ALT certificate independently replayed initial and committed-state metrics, but does not contain the newer per-candidate full-field, cold-state or exact native solver-input evidence. This difference in audit depth remains explicit.')
    table('Table 7.9 Saved stronger numerical and original language-system endpoints',
      ['Root','DFF UV/OV','D-SE UV/OV','HG-VF UV/OV','HG-SE UV/OV'],
      [[x['case_id'].split('line_')[1].replace('_',' '),f"{x['DFF_UV']}/{x['DFF_OV']}",f"{x['numerical_DSE_UV']}/{x['numerical_DSE_OV']}",f"{x['HGVF_UV']}/{x['HGVF_OV']}",f"{x['HGSE_UV']}/{x['HGSE_OV']}"] for x in result['rows']]+[['Total','51/11','35/12','26/11','20/12']],[26,30,30,30,30])
    para('HG-VF leaves 26 undervoltage buses across the four endpoints, compared with 35 for numerical D-SE. It wins on UV in three cases and loses in one. The offline HG-SE selection leaves 20 UV, winning in three cases and tying in one. However, HG-VF has more strict overvoltage than D-SE in the line-36 case. HG-SE has more strict overvoltage in the line-36 and line-127 cases. No method achieves zero UV or full-band restoration on these four endpoints. The result supports a qualified development finding, not complete dominance.')
    para('Numerical D-SE pays for both DFF and DFF-ALT. The four historical pairs used 15,425 power-flow attempts, with 15,407 returns and 18 exceptions. Their independent committed-state replay is charged separately. HG-SE similarly pays for DFF and HG-VF, including model, search, preparation, training and failed-stage costs. The saved records do not establish equal total cost or deployment speed. The cases were repeatedly inspected during development, so this retrospective comparison does not establish a causal language-model benefit or unused confirmation.')
    para('7.15 Why the public 13-bus numerical result remains adverse','Heading 2')
    para('The 500-case numerical result in Section 7.10 remains 264 whole-band endpoints, compared with 363 for published DDPG. A saved trace diagnosis shows that the aggregate hides a sharp difference between initial operating regimes. The numerical method reaches the strict whole-band endpoint in 247 of 251 initially overvoltage-only cases, but in none of the 232 initially undervoltage-only cases. Seventeen cases were already within the band; retaining them is not a corrective achievement. Table 7.10 keeps the complete declared cohort.')
    table('Table 7.10 Fixed numerical controller diagnosis by initial public 13-bus condition',
      ['Initial condition','Cases','Whole-band endpoint','Strict failures'],
      [['UV only',232,0,232],['OV only',251,247,4],['Already within band',17,17,0],['All cases',500,264,236]],[45,24,43,34])
    para('Among the UV-only failures, 151 reached the 100-round limit with a maximum violation no larger than 1e-8 p.u. They remain failures under the unchanged strict 0.95–1.05 endpoint. The recorded policy produced 14,387 accepted decisions with an all-zero float32 action and exactly unchanged Q and all 13 voltage magnitudes. A separate arithmetic crosscheck found no nonzero action lost during float64 Q accumulation. Thus the observed stagnation is present in the saved action itself; it cannot be attributed to addition swallowing a nonzero action.')
    para('The executed guard allows unchanged violations and small tolerance around buses that were already normal. Consequently, accepting a zero action does not imply progress toward the strict terminal condition. Repeating that accepted state can consume the remaining horizon. This explains the recorded no-change behaviour, but does not prove that a different margin, solver objective or stopping rule would recover the endpoint. Earlier feasibility checks on four other adverse roots yielded no infeasibility certificate. The failed numerical intervention remains stopped, all costs and strict failures are retained, and no tolerance adjustment is used to improve the reported score.')
    O.mkdir();out=O/'Hannaan_Thesis_DSE_And_Public_Diagnosis.docx';d.save(out)
    def media(p):
        with zipfile.ZipFile(p) as z:return Counter(sha_bytes(z.read(n)) for n in z.namelist() if n.startswith('word/media/'))
    def sha_bytes(b):return hashlib.sha256(b).hexdigest()
    assert sha(BASE)==beforehash and media(BASE)==media(out) and len(d.tables)==17
    (O/'Integration_Record.json').write_text(json.dumps({'status':'CREATED_AWAITING_VISUAL_QA','base_sha256':beforehash,'base_unchanged':True,'new_sections':['7.14','7.15'],'tables':17,'new_science':0,'source_records':['outputs/original118_saved_dse_reconciliation_20261028/Verified_Completion.json','outputs/public13_saved_numeric_stagnation_20261022/All500_Arithmetic_Diagnosis.json','outputs/public13_saved_numeric_stagnation_20261022/Separate_Arithmetic_Crosscheck.json']},indent=2)+'\n','utf-8')
    print(json.dumps({'docx':str(out),'tables':17,'new_science':0}))
if __name__=='__main__':main()
