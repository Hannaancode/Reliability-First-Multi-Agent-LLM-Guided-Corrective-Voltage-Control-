"""Saved real controller/dependency factory, in a separate cold process, no science."""
import argparse,copy,hashlib,json,os,pickle,random,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
import numpy as np,pandapower as pp
import paid_receding_commit_and_history_v1 as old
import paid_receding_referenced_commit_v2_20261018 as transport
from paid_receding_journal_reference_history_v2_20261018 import ReceiptJournalIndex,ReferencedHistory,canon
import receding_paid_referenced_runtime_v2_20261018 as runtime
from frozen_physics_loader import load_stack
from compile_lookahead_paid_input_cache_20261014 import point_key

R=Path(__file__).resolve().parents[1]
B=R/'outputs/referenced_controller_factory_cold_capacity_v2_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def cold():
    started=time.perf_counter();p=read(B/'Protocol.json')
    for rel,h in p['source_sha256'].items():assert sha(R/rel)==h
    forbidden=[]
    def no_science(*a,**k):forbidden.append('attempt');raise AssertionError('No new model/PF/forecast/derivative/solve in software factory')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,no_science)
    np.linalg.solve=no_science
    runtime.PaidRecedingRuntime.__init__.__globals__['pp']=pp
    request=read(B/'Cold_Request.json')
    state,events=transport.restore_complete(R/request['checkpoint'],request['receipt'])
    assert datetime.now(timezone.utc)>datetime.fromisoformat(state['absolute_deadline_utc'])
    warm=read(R/request['warm_dependency_path'])
    result=runtime.reconstruct_saved_readonly_factory(state,warm_dependencies=warm,source_anchors=request['source_anchors'])
    dep=result['dependencies']
    original=old.restore(R/p['original_request']['checkpoint'],p['original_request']['receipt'])
    checks={
        'all118_saved_fields_exact':transport.fields(state['net'])==old.fields(original['net']),
        'operation_cap_stock_cursor_exact_except_explicit_MODE':{k:v for k,v in state['cursor'].items() if k!='commit_mode'}=={k:v for k,v in original['cursor'].items() if k!='commit_mode'},
        'all_saved_costs_exact':state['costs']==original['costs'],
        'python_RNG_exact':pickle.dumps(state['python_rng'])==pickle.dumps(original['python_rng']),
        'numpy_RNG_exact':pickle.dumps(state['numpy_rng'])==pickle.dumps(original['numpy_rng']),
        'source_input_event_PF_receipt_forecast_context_prefix_verified':dep['saved_prefix_only'] and dep['new_scientific_calls']==0,
        'paid_cache_contains_every_warm_receipt':all(dep['cache'][k]==v for k,v in warm['cache'].items()),
        'paid_forecasts_contain_every_warm_forecast':all(dep['paid_forecasts'][k]==v for k,v in warm['existing_numeric_forecasts'].items()),
        'actual_contexts_restored':bool(dep['contexts']),
        'full_saved_point_key_exact':point_key(state['net'],state['cursor'])==p['original_request']['expected_point_key'],
        'saved_protocol_not_relabelled_as_new_science':state['protocol_sha256']==original['protocol_sha256'],
        'old_absolute_deadline_preserved_and_expired':result['original_absolute_deadline_utc']==original['absolute_deadline_utc'],
        'factory_is_explicitly_readonly':result['execution_authorized_by_this_factory'] is False}
    bad=copy.deepcopy(request['source_anchors']);bad['runtime']='f'*64
    try:runtime.reconstruct_saved_readonly_factory(state,warm_dependencies=warm,source_anchors=bad)
    except AssertionError:checks['wrong_runtime_source_rejected_before_factory_use']=True
    else:raise AssertionError('Foreign source accepted')
    # Construct the actual runtime class and its actual paid engine with the
    # verified caches/contexts, but admission MUST stop at the expired bound.
    class ExpiredBound(RuntimeError):pass
    class ReadonlyEvidence:
        def __init__(self):self.admission_checks=0;self.event_calls=0
        def admit(self):
            self.admission_checks+=1
            if datetime.now(timezone.utc)>=datetime.fromisoformat(state['absolute_deadline_utc']):raise ExpiredBound('Original budget expired; no resume')
            raise AssertionError('Fixture unexpectedly admitted')
        def event(self,*a,**k):self.event_calls+=1;raise AssertionError('No scientific event permitted')
    evidence=ReadonlyEvidence();_,runner,_=load_stack()
    meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    instance=runtime.PaidRecedingRuntime(out=B/'never_scientific_output',protocol={'absolute_deadline_utc':state['absolute_deadline_utc']},
        evidence=evidence,history=None,runner=runner,zones=zones,cache=dep['cache'],
        blocked=warm['blocked_prior_incomplete_identities'],contexts=dep['contexts'],numeric_cost=copy.deepcopy(state['costs']['numeric']),
        paid_forecasts=dep['paid_forecasts'],warm_dependency_path=R/request['warm_dependency_path'],
        warm_context_refs=[],source_anchors=request['source_anchors'],cold_gate=no_science)
    checks['actual_runtime_and_paid_engine_constructed']=instance.engine.cache is dep['cache'] and instance.engine.contexts is dep['contexts']
    try:instance.run_branch(state['net'],state['cursor'],world='READONLY_FIXTURE',mode='immediate1_followup16')
    except ExpiredBound:checks['actual_controller_rejects_expired_bound_before_search_commit_or_event']=evidence.admission_checks==1 and evidence.event_calls==0
    else:raise AssertionError('Expired controller executed')
    checks['no_forbidden_scientific_callback_attempted']=not forbidden
    assert all(checks.values())
    put(B/'Cold_Result.json',{'status':'PASS_REAL_SAVED_CONTROLLER_FACTORY_COLD_READONLY',
        'checks':checks,'cache_entries':len(dep['cache']),'forecasts':len(dep['paid_forecasts']),
        'contexts':len(dep['contexts']),'closed_scientific_intents':len(dep['closed_intent_ids']),
        'history_records':len(events),'original_absolute_deadline_utc':state['absolute_deadline_utc'],
        'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Actual saved factory and admission boundary only; no following query, fresh physical trajectory, new runtime cold continuation or recovered old26th checkpoint.'})

def main():
    begun=time.perf_counter();B.mkdir(exist_ok=False)
    request=read(R/'outputs/full_receding_paid_campaign_20261015/actual_cold_request/Request.json')
    sources=[Path(__file__),R/'work/receding_paid_referenced_runtime_v2_20261018.py',R/'work/paid_receding_chunked_history_v2_20261018.py',R/'work/receding_paid_runtime_v2.py',R/'work/paid_joint_commit_v1.py']
    put(B/'Protocol.json',{'role':'FIXED_READONLY_COMPLETE_FACTORY_COLD_COMPONENT','science_calls_allowed':0,
        'original_request':request,'source_sha256':{str(x.relative_to(R)):sha(x) for x in sources},
        'runtime_source_certificate':runtime.SOURCE_CERTIFICATE,'parent_bound_seconds':600,'cold_bound_seconds':300,
        'changes':'Fixture MODE, next-phase label and chunked transport anchor only; original protocol, NET, cursor resources, RNG, costs, paid dependencies and expired absolute bound unchanged.',
        'not_a_restart_or_fresh_physical_campaign':True})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    state=old.restore(R/request['checkpoint'],request['receipt'])
    state['cursor']['commit_mode']=transport.MODE;state['next_phase']='READONLY_FACTORY_FIXTURE_NO_SCIENCE'
    dep=state['paid_query_registry'][runtime.DEPENDENCY_KEY]
    journal=R/dep['scientific_journal_path']
    index=ReceiptJournalIndex(journal,protocol_sha256=state['protocol_sha256'])
    with journal.open('rb') as stream:
        while stream.tell()<dep['scientific_journal_bytes']:
            offset=stream.tell();line=stream.readline();assert offset+len(line)<=dep['scientific_journal_bytes']
            event=json.loads(line)
            if event['event']=='every_query_receipt_closed_before_more_science':index.observe_closed_durable_query(offset,line)
    original_records=old.verify_history(state['paid_query_registry'][old.HISTORY_KEY])
    history=ReferencedHistory(B/'history',source_anchor=sha(R/'work/receding_paid_referenced_runtime_v2_20261018.py'),input_anchor=request['receipt']['raw_sha256'],max_bytes=128*1024**2,query_index=index)
    for event in original_records:history.append(event['event'],event['payload'])
    state['paid_query_registry'][transport.HISTORY_KEY]=history.anchor()
    bad=copy.deepcopy(state);bad['paid_query_registry'][runtime.DEPENDENCY_KEY]['scientific_journal_bytes']=0
    try:transport.save_complete(B/'MUST_NOT_EXIST_future_receipt',bad,{'source':'f'*64,'input':'f'*64,'paid_receipt':'f'*64,'predecessor':'f'*64})
    except ValueError:put(B/'Future_Query_Rejection.json',{'rejected_before_save':True,'new_science':0})
    else:raise AssertionError('Future query reference admitted')
    receipt=transport.save_complete(B/'checkpoint',state,{'source':sha(R/'work/receding_paid_referenced_runtime_v2_20261018.py'),'input':request['receipt']['raw_sha256'],'paid_receipt':request['receipt']['manifest_sha256'],'predecessor':request['receipt']['state_fingerprint']})
    history.close();dep=state['paid_query_registry'][runtime.DEPENDENCY_KEY]
    put(B/'Cold_Request.json',{'checkpoint':str((B/'checkpoint').relative_to(R)),'receipt':receipt,'source_anchors':request['source_anchors'],'warm_dependency_path':dep['warm_dependency_path']})
    with (B/'cold_console.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        code=child.wait(timeout=300)
    put(B/'Child_Exit.json',{'actual_child_pid':child.pid,'exit_code':code})
    assert code==0,'Retain cold_console.log; no automatic rerun'
    result=read(B/'Cold_Result.json');put(B/'Results.json',{'status':'PASS','cold':result,'workflow_seconds':time.perf_counter()-begun,'new_scientific_calls':0})
    put(B/'Closed_Manifest.json',{'members':{str(x.relative_to(B)):sha(x) for x in B.rglob('*') if x.is_file()},'new_scientific_calls':0})
    print(json.dumps({'saved_runtime_factory_cold':'PASS','checks':len(result['checks']),'new_scientific_calls':0}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cold',action='store_true');args=p.parse_args()
    cold() if args.cold else main()
