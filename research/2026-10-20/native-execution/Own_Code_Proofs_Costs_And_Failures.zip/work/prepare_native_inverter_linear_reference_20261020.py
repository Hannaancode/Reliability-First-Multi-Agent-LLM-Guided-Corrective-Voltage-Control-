"""Prospectively freeze source/input/ownership/costs and mock sign/cap fixtures."""
import hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_inverter_linear_reference_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    import numpy as np
    from scipy.optimize import linprog
    import scipy,pandapower
    from native_inverter_linear_reference_core_20261020 import problem
    checks=[]
    for slope,cap,expected in [(.4,1.,.25),(-.4,1.,-.25),(.4,.1,.1)]:
        c,a,b,bounds=problem([.9],[[slope]],[0.],[cap]);r=linprog(c,A_ub=a,b_ub=b,bounds=bounds,method='highs')
        assert r.success and abs(r.x[0]-expected)<1e-9;checks.append({'label':'MOCK_only_signed_Q_absolute_units_and_cap','slope':slope,'cap':cap,'expected_Q':expected,'actual_Q':float(r.x[0])})
    sources=['run_native_inverter_linear_reference_20261020.py','audit_native_inverter_linear_reference_20261020.py','coordinate_native_inverter_linear_reference_20261020.py','native_inverter_linear_reference_core_20261020.py','candidate_process_evidence_utils.py']
    tpa=ROOT/'outputs/tpa_native_second_identity_engineering_20261020'
    inputs=[tpa/'PF0_before.pkl',tpa/'PF1_before.pkl',tpa/'PF0_fields.npz',tpa/'PF1_fields.npz',tpa/'independent_audit/Independent_Audit.json',tpa/'Closed_Manifest.json',ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json']
    assert json.loads((tpa/'independent_audit/Independent_Audit.json').read_text(encoding='utf-8'))['status'].startswith('PASS_')
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'identity':{'year':2013,'month':1,'day':20,'day_id':385,'idx':185262},'purpose':'Native numerical reference engineering on previously audited second scheduled author root. Not all120 benchmark or an information-matched LLM superiority claim. First scheduled case remains partial UNKNOWN; not dropped or retried.','sources':{f:sha(ROOT/'work'/f) for f in sources},'inputs':{f.relative_to(ROOT).as_posix():sha(f) for f in inputs},'installed_versions':{'scipy':scipy.__version__,'pandapower':pandapower.__version__},'installed_dSbus_dV_source_sha256':sha(Path(pandapower.__file__).parent/'pypower/dSbus_dV.py'),'worker_bound_seconds':600,'reader_bound_seconds':300,'LP_options':{'time_limit':60.0,'maxiter':10000},'method':'One analytic current-Jacobian; one642x642LU;38signed injectionRHS solves; oneHiGHS LP. min mean|V_linear-1|+.1mean|Q|, exact native .8sqrt((1.2Pmax)^2-P^2) absolute caps and predicted V<=1.05. One final physical candidate, no iterative refinement/retune/sweep.','root_reuse':'Use saved solved root internal state fromPF1_before with onlyQ restored to exactPF0 inputs; verify allphysicaltables/rootfields/KCL. No rootPF repeat.','costs_planned_not_completed':{'public_derivative_calls':1,'LU_factorizations':1,'RHS_solves':38,'LP_attempts':1,'new_candidate_PF_max':1,'independent_candidate_replay_PF_max':1,'new_model_GPU_optimizer':0},'reuse_gate':'If final candidate exactly equals an already measured physical input, reuse saved fields and costs; never repeat primary physics.','reader':'Allsource/hashchains/cachedroot/units/caps, independently dense-complex derivative and linear residual, exactLPconstruction and primal-dual optimality, one allnumeric physical replay if new input, nine frozen assets. Zero derivative/factor/solve/LP/model calls in reader.','information_limit':'Centralized known model/state numerical reference has Ybus and fullcurrentVm. TPA has distributed current/history/seasonal embedding; no same-information superiority claim. No ourLLM run.','mock_fixture_checks':checks,'mock_fixture_LP_calls':3,'actual_model_PF_derivative_factor_solve_calls_by_preparation':0,'no_retry_or_budget_extension':True}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    print(json.dumps({'status':'FROZEN','software_mock_checks':3,'actual_science_calls':0,'sources':len(sources),'inputs':len(inputs)}))
if __name__=='__main__':main()
