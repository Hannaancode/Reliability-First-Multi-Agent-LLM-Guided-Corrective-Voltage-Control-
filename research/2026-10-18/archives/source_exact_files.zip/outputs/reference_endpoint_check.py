"""Fresh PF check of a declared continuous-reference endpoint/padding."""
import copy,math
from physical_replay_audit import state_audit
def check_endpoint(scenario,nominal,factor,base,zones,v2,runner):
    assert math.isfinite(factor) and factor>0
    assert all(math.isfinite(float(q)) and float(q)>=0 for q in nominal.values()),'Nonfinite raw optimizer support retained; do not project it into a finite endpoint'
    q={str(b):min(450.,float(q)*factor) for b,q in nominal.items()}
    assert all(math.isfinite(q) and 0<=q<=450 for q in q.values())
    net=copy.deepcopy(base);original=net.shunt.index.copy();v2.v0.apply_scenario_to_net(net,scenario,zones);runner.rescue.apply_action(net,{'add_shunts_q_mvar':q});conv,err=v2.v0.run_pf(net)
    audit=state_audit(net,original) if conv else None;metrics=runner.rescue.grid_metrics(net) if conv else None
    valid=bool(audit and audit['all_active_bus_voltages_finite'] and not audit['unserved_or_mismatched_loads'] and metrics['uv_count']==0 and audit['voltage']['ov_beyond_1e8_tolerance']==0 and not audit['incremental_shunt_cap_violations'] and sum(q.values())<=7500+1e-8)
    return {'factor':factor,'nominal_support_mvar':sum(q.values()),'support_mvar_by_bus':q,'power_flow_converged':conv,'error':err,'original_metrics':metrics,'audit':audit,'strict_uv_zero_and_upper_band_within_1e8':valid}
