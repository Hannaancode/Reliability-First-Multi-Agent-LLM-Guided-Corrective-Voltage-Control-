"""Physical-modification and saved training-record audit, never just filenames."""
from pathlib import Path
from collections import Counter
import json,hashlib,re
root=Path('work/e');out=Path('outputs')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(s,ignore_load=False):
    mods=[]
    for raw in s['modifications']:
        m=dict(raw)
        if ignore_load and m['action']=='scale_all_loads':continue
        for k,v in m.items():
            if isinstance(v,list):m[k]=sorted(v)
        mods.append(m)
    return json.dumps({'system':s['system'],'modifications':sorted(mods,key=lambda m:json.dumps(m,sort_keys=True))},sort_keys=True,separators=(',',':'))
historical={p.stem:json.loads(p.read_text()) for p in (root/'pack/scenarios/federation').glob('*.json')}
locked={p.stem:json.loads(p.read_text()) for p in (root/'bank/scenarios').glob('*.json')}
split=json.loads((root/'training_provenance/scenario_split_map.json').read_text())
assert len(set().union(*(set(v) for v in split.values())))==sum(len(v) for v in split.values())
train_records={};record_ids={};unparsed={};local_vectors={}
for label in ['train','val','test']:
    path=root/'training_provenance'/f'zone_agent_{label}.jsonl';counts=Counter();fail=0;rows=0;vectors={}
    for line in path.open(encoding='utf-8'):
        rows+=1;row=json.loads(line)
        users=[m.get('content','') for m in row['messages'] if m.get('role')=='user']
        try:
            observation=json.loads(users[0]);sid=observation['scenario_id'];counts[sid]+=1
            vm=observation.get('local_measurements',{}).get('bus_voltages',{})
            if vm:vectors.setdefault(sid,{})[observation.get('zone')]=vm
        except (ValueError,KeyError,IndexError,TypeError):fail+=1
    train_records[label]={'record_count':rows,'sha256':sha(path),'distinct_scenario_ids':len(counts),'ids_outside_split_map':sorted(set(counts)-set(split[label+'_ids'])),'unparsed_observation_rows':fail}
    record_ids[label]=sorted(counts);unparsed[label]=fail;local_vectors[label]=vectors
    assert not train_records[label]['ids_outside_split_map']
all_ids=set().union(*(set(ids) for ids in record_ids.values()))
missing=sorted(all_ids-set(historical));assert not missing
train_fingerprints={canonical(historical[sid]):sid for sid in record_ids['train']}
all_fingerprints={canonical(historical[sid]):sid for sid in all_ids}
all_saved_fingerprints={canonical(s):sid for sid,s in historical.items()}
training_families={canonical(historical[sid],True) for sid in record_ids['train']}
rows=[]
for sid,s in locked.items():
    key=canonical(s);family=canonical(s,True)
    rows.append({'scenario_id':sid,'locked_scenario_sha256':sha(root/'bank/scenarios'/f'{sid}.json'),'physical_modification_sha256':hashlib.sha256(key.encode()).hexdigest(),'same_physical_modifications_in_saved_train':train_fingerprints.get(key),'same_physical_modifications_in_any_saved_split':all_fingerprints.get(key),'same_physical_modifications_in_any_saved_historical_case':all_saved_fingerprints.get(key),'outage_DER_pattern_present_in_saved_train':family in training_families})
report={'status':'saved_training_inputs_and_historical_physical_scenarios_audited','scope':'Physical modifications compared against the same frozen system, not scenario names or timestamps. Grouped split inputs recovered from an actual Desktop experiment ZIP. The exact training invocation/data hash of the final ultra_v1 adapter is not encoded in the recovered model card/trainer state; these files establish archived-input provenance, not a cryptographically proven complete adapter training lineage.','historical_scenario_count':len(historical),'split_scenario_counts':{k:len(v) for k,v in split.items()},'split_map_sha256':sha(root/'training_provenance/scenario_split_map.json'),'records':train_records,'locked_case_count':len(rows),'exact_physical_overlap_with_saved_train':sum(r['same_physical_modifications_in_saved_train'] is not None for r in rows),'exact_physical_overlap_with_any_saved_split':sum(r['same_physical_modifications_in_any_saved_split'] is not None for r in rows),'exact_physical_overlap_with_all_saved_historical':sum(r['same_physical_modifications_in_any_saved_historical_case'] is not None for r in rows),'locked_cases_sharing_outage_DER_pattern_with_saved_train':sum(r['outage_DER_pattern_present_in_saved_train'] for r in rows),'interpretation':'Post-training held-out load operating points in the same network and contingency construction; do not claim unseen outage families, cross-grid transfer, or broad OOD generalization. Linguistic record count is not number of independent physical scenarios.','rows':rows}
(out/'training_bank_physical_overlap.json').write_text(json.dumps(report,indent=2))
(out/'training_bank_physical_overlap_summary.md').write_text('# Saved training inputs and locked-bank overlap\n\n'+report['scope']+'\n\n'+f"Saved splits contain {len(split['train_ids'])} training, {len(split['val_ids'])} validation, and {len(split['test_ids'])} test physical scenario IDs. JSONL record counts are "+', '.join(f"{k}: {v['record_count']}" for k,v in train_records.items())+f". Exact physical modification overlap is {report['exact_physical_overlap_with_saved_train']}/62 with saved training and {report['exact_physical_overlap_with_all_saved_historical']}/62 with all {len(historical)} recovered historical scenarios. {report['locked_cases_sharing_outage_DER_pattern_with_saved_train']}/62 share an outage/DER pattern with saved training.\n\n"+report['interpretation']+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
