"""Scientific figure from closed, fixed, all500 policy results. No new science."""
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json'
O = R / 'outputs/verified_benchmark_model_and_router_state_20261022'


def main():
    data = json.loads(P.read_text(encoding='utf-8'))
    assert data['status'].startswith('COMPLETE_SAME500')
    assert data['fixed_gate'].startswith('FAIL_')
    labels = ['Published\nSafe-DDPG', 'Published\nlinear', 'Published\nDDPG', 'Our\nnumerical']
    colors = ['#2563eb', '#64748b', '#059669', '#d97706']
    totals = [262, 258, 363, 264]
    strata = data['input_defined_strata_descriptive']
    panels = [('All registered cases', totals, 500),
              ('Initially UV only', [232, 232, 214, 0], 232),
              ('Initially OV only', [13, 9, 132, 247], 251)]
    assert strata['UV_only']['native_fullband']['ddpg'] == 214
    assert strata['OV_only']['our_fullband'] == 247
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'axes.spines.top': False, 'axes.spines.right': False})
    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.6), sharey=True)
    for ax, (title, values, n) in zip(axes, panels):
        ax.bar(range(4), [v / n for v in values], color=colors, width=.68, zorder=3)
        ax.set_xticks(range(4), labels, fontsize=9)
        ax.set_title(f'{title} (n={n})', fontsize=11, pad=12)
        ax.set_ylim(0, 1.18)
        ax.set_yticks([0, .25, .5, .75, 1.])
        ax.yaxis.set_major_formatter(PercentFormatter(1))
        ax.grid(axis='y', color='#e2e8f0', zorder=0)
        for x, value in enumerate(values):
            ax.text(x, value / n + .035, f'{value}/{n}', ha='center', va='bottom', fontsize=9)
    axes[0].set_ylabel('All 13 buses within voltage band at endpoint')
    fig.suptitle('Observed same-case controller comparison: complementary failure modes',
                 fontsize=14, y=.98)
    fig.text(.01, .025,
             'Strict 0.95 ≤ VM ≤ 1.05 score; all near-boundary failures retained. Three published policies are one publication family.\n'
             'Source actors use local VM; NUM uses global VM/current Y. No LLM or new router performance is plotted.',
             fontsize=9, color='#334155')
    fig.subplots_adjust(left=.065, right=.985, bottom=.235, top=.84, wspace=.2)
    fig.savefig(O / 'Verified_Public13_Comparison.png', dpi=180)
    fig.savefig(O / 'Verified_Public13_Comparison.svg')
    plt.close(fig)
    record = {'source': P.relative_to(R).as_posix(), 'source_sha256': hashlib.sha256(P.read_bytes()).hexdigest(),
              'fixed_gate': data['fixed_gate'], 'actual_policies_only': True,
              'posthoc496_route_not_plotted_as_measured': True,
              'files': {name: hashlib.sha256((O / name).read_bytes()).hexdigest() for name in
                        ['Verified_Public13_Comparison.png', 'Verified_Public13_Comparison.svg']}}
    (O / 'Figure_Source_And_Scope.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
