"""Same source-defined action domain for future LOCAL/model/numeric controls.

Input/causal software only. No solver, model call, scientific resume or launch.
The running common-domain suffix experiment is not modified by this module.
"""
import copy
import math
from joint_reallocation_opportunity_core_v1 import universe
from owned_bank_joint_reallocation_v1 import Q_GRID


def build_current_domain(net, cursor, *, runner, zones):
    assert bool(net.converged) and len(net.res_bus) == 118
    reports = {zone: runner.rescue.extract_zone_state_full(net, zone, zones) for zone in sorted(zones)}
    common = runner.rescue.candidate_buses_from_state(net, zones, reports, [])
    per_zone = {zone: runner.get_zone_candidate_buses(net, zone, zones, reports[zone]) for zone in sorted(zones)}
    shared = sorted(set(common).union(*(set(buses) for buses in per_zone.values())))
    assert all(type(bus) is int and bus in net.bus.index for bus in shared)
    expanded = copy.deepcopy(cursor); expanded['raw_current_receiver_scope'] = shared
    rows = universe(expanded)
    if expanded['remaining_original_device_operation_slots'] < 2:
        rows = [row for row in rows if row['kind'] == 'ordinary']
    if expanded['remaining_original_device_operation_slots'] < 1:
        rows = []
    return {'status': 'CURRENT_SOURCE_DEFINED_SHARED_DOMAIN_NOT_SCIENTIFIC_LAUNCH',
        'original_common_buses': common, 'original_LOCAL_allowed_per_zone': per_zone,
        'shared_raw_receivers_for_BOTH_controls': shared, 'zone_current_views': reports,
        'expanded_cursor_for_separately_fixed_future_protocol': expanded,
        'all_declared_original9Q_ordinary_and_owned_joint_identities': rows,
        'previously_paid_compatible_receipts_still_require_identity_inventory': True,
        'no_after_or_unqueried_labels_in_domain': True, 'no_physical_or_model_performance_claim': True}


def joint_eligible_original_local_proposal(parsed, *, zone, domain, runner):
    """Retain the exact original normalization AND report the new9grid gate.

    This does not invent a donor, actuate/verify anything, silently repair q,
    or grant a model extra action choices compared with its numeric control.
    """
    action = runner.rescue.normalize_action(parsed)
    valid, reason = runner.validate_action_against_candidates(action, domain['original_LOCAL_allowed_per_zone'][zone])
    if not valid:
        return {'original_action': action, 'original_candidate_valid': False, 'joint_eligible': False, 'reason': reason}
    bus, q = next(iter(action['add_shunts_q_mvar'].items())); bus = int(bus); q = float(q)
    if not math.isfinite(q) or q not in Q_GRID:
        return {'original_action': action, 'original_candidate_valid': True, 'joint_eligible': False, 'reason': 'NEW_JOINT9GRID_NOT_ELIGIBLE_ORIGINAL_PARSER_UNCHANGED'}
    cursor = domain['expanded_cursor_for_separately_fixed_future_protocol']
    if cursor['positive_addition_lifetime_MVAr'].get(str(bus), 0.)+q > 450:
        return {'original_action': action, 'original_candidate_valid': True, 'joint_eligible': False, 'reason': 'POSITIVE_LIFETIME_CAP_NO_WITHDRAWAL_REFUND'}
    if cursor['remaining_original_device_operation_slots'] < 2:
        return {'original_action': action, 'original_candidate_valid': True, 'joint_eligible': False, 'reason': 'INSUFFICIENT_TWO_DEVICE_OPERATIONS'}
    return {'original_action': action, 'original_candidate_valid': True, 'joint_eligible': True,
            'reason': 'PROPOSAL_ONLY_DONOR_PAID_PHYSICS_COMMIT_GATES_STILL_REQUIRED'}
