"""Prepare exact new source-order recipes and prospectively specify a router.

No policy forward, converter, PF, derivative or optimizer call occurs here.
Native reset executes against an explicitly labelled recipe-only PF collector;
its stale returned observations are discarded, never called solved outcomes.
"""
import copy
import hashlib
import json
import pickle
import types
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/public13_fresh_input_router_preparation_v2_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    with Path(p).open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, allow_nan=False)


def main():
    O.mkdir(exist_ok=False)
    import stable_ddpg_native_bridge_20261020 as bridge
    from run_public13_remaining_published_cohort_20261021 import regime
    np = bridge.np
    source = bridge.AUTHOR / 'env_single_phase_13bus.py'
    reset_requests = []

    class RecipeOnly:
        def runpp(self, net, **kwargs):
            assert kwargs == {'algorithm': 'bfsw'}
            reset_requests.append(kwargs.copy())
            # Deliberately do not return a new physical result. Only the source
            # physical parameter writes are used; stale observations discarded.

    native, definition = bridge.definitions(source, ['IEEE13bus'],
        {'np': np, 'LA': np.linalg, 'gym': types.SimpleNamespace(Env=object),
         'copy': copy, 'pp': RecipeOnly()})
    base_path = R / 'outputs/stable_ddpg_native_engineering_20261020/PF0_after.pkl'
    base = pickle.loads(base_path.read_bytes())
    assert len(base.bus) == 13 and len(base.sgen) == 12 and len(base.res_bus) == 13
    old_unsolved=pickle.loads((R/'outputs/stable_ddpg_native_engineering_20261020/PF0_before.pkl').read_bytes())
    assert regime(base)==regime(old_unsolved)
    for table in ['bus','line','trafo','sgen','load','ext_grid','gen','shunt','switch']:
        assert base[table].equals(old_unsolved[table])
    old_protocol = read(R / 'outputs/public13_full_cohort_preparation_20261021/Protocol.json')
    old_roots = read(R / 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json')['roots']
    old_regimes = set(old_protocol['paid_prior_regimes']) | {r['noncontrolled_regime'] for r in old_roots}
    # All subsequent native500 and NUM steps are source-audited to change only
    # the three controlled Q values. Thus their noncontrolled regimes are in
    # this already closed set. Both recent model studies made zero PF calls.
    control_audit = read(R / 'outputs/public13_matched_numeric_independent_20261021/Independent_Audit.json')
    assert control_audit['all500_complete'] and control_audit['status'].startswith('PASS_')
    fields = {k: [] for k in ['sgen_p', 'sgen_q', 'load_p', 'load_q']}
    identities = []
    for seed in range(1000, 1128):
        env = native['IEEE13bus'](copy.deepcopy(base), np.array([2, 7, 9]))
        ignored_stale_obs = env.reset(seed)
        net = env.network
        reg = regime(net)
        assert reg not in old_regimes
        assert reg not in {r['noncontrolled_regime'] for r in identities}
        assert np.array_equal(net.sgen.q_mvar.to_numpy()[:3], np.zeros(3))
        for name, table, col in [('sgen_p', 'sgen', 'p_mw'), ('sgen_q', 'sgen', 'q_mvar'),
                                 ('load_p', 'load', 'p_mw'), ('load_q', 'load', 'q_mvar')]:
            fields[name].append(net[table][col].to_numpy(copy=True))
        identities.append({'seed': seed, 'noncontrolled_regime': reg,
                            'initial_physics_status': 'UNEXECUTED_UNKNOWN_NO_VOLTAGE_OUTCOME_MEASURED'})
    assert len(reset_requests) == len(identities) == 128
    np.savez(O / 'All128_Source_Exact_Physical_Recipes.npz', **{k: np.asarray(v) for k, v in fields.items()})
    put(O / 'All128_Prospective_Identities.json', identities)
    protocol = {
        'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PROSPECTIVE_128_INPUTS_CLOSED_WORKER_READER_PRESERVATION_GATES_STILL_REQUIRED',
        'question': 'Can a fixed initial-violation router preserve native SafeDDPG UV restoration and NUM OV restoration on new same-source cases, beating every unchanged published policy and a same-input published-only router?',
        'seeds': list(range(1000, 1128)), 'cases': 128,
        'route_rule_frozen_before_new_outcomes': 'If initially all13VM in0.95..1.05, stop. If UV>0 and OV==0, choose SafeDDPG. Otherwise (OV-only or mixed), choose unchanged NUM. One backend chosen before the trajectory; no hindsight case/expert choice.',
        'published_only_router_control': 'Same global initial13VM and protection: SafeDDPG for UV-only; DDPG for OV-only or mixed; already compliant stops. Its Safe/DDPG model states are separate from all other arms.',
        'other_primary_controls': ['Unmodified native SafeDDPG', 'Unmodified native linear', 'Unmodified native DDPG', 'Unchanged NUM'],
        'source_NN_state': 'Each arm owns its source-exact model state initialized from the same canonical checkpoints at study start. Preserve b/c normalization on every call and actual skipped-episode state carry. Never copy standalone outcomes as an executed router.',
        'protection': 'Native source policies remain unmodified strong primary comparators. Both named input routers use the same source-bound NUM normal-bus protection and nonincreasing global UV/OV counts; rejected query paid, no commit or refund. NUM source remains unchanged.',
        'actuation': 'Same exact solved startingNET per seed, native three actuators/float32±0.3increment/100round cap, no invented absoluteQcap. Record raw13bus voltages and source3bus strict done separately.',
        'primary_endpoint': 'Full13band0.95<=VM<=1.05 on all128 registered cases, no epsilon rounding or omitted failures. Partial/unexecuted remainUNKNOWN, no complete-only result on a partial.',
        'primary_comparisons': ['router vs sourceSafeDDPG', 'router vs sourcelinear', 'router vs sourceDDPG', 'router vs same-inputpublished-onlyrouter'],
        'fixed_statistics': 'Paired case-root bootstrap10000 seed20261022, exact two-sided discordant-binomial tests, Holm family4. No checkpoint/case/seed/guard/Q/objective/horizon retunes.',
        'fixed_gate': 'All128 complete independent outcomes, router strictfullband fraction>=0.90 and positive paired95%lowerbound/Holmp<0.05 versus EACH of the four primary controls. No guarantee. Failed gate stops this exact routing intervention.',
        'budget_draft': {'science_seconds': 7200, 'first_reader_seconds': 7200, 'binary_cap_bytes': 8 * 1024 ** 3, 'not_a_resumption_or_extension_of_old500studies': True},
        'all_old_completed_science_reused_not_repeated': 'New exact noncontrolled regimes disjoint from closed73prior+500roots. Future query broker must bind all relevant old attempted identities and exact initializer-matched returns, and charge every logical query/reuse.',
        'full_costs': 'Each source/model/preparation/rootPF/query/derivative/LP/failed/unknown/preservation/independent replay cost retained. No free teacher, cold model, source training, selected trajectory or simulator future. No wall-workflow deployment-speed claim.',
        'independent_reader_required': 'After sole primary actualend/exit0/closedmanifest only. First replay ONLY new returned PF and actual new native NN calls; verify dense derivative/LP certificates without new solves, source action/reward/done/cold/continuous decisions/guard/model state/all fields1e-10/KCL1e-7/costs/frozen gates.',
        'missing_before_science': ['Complete actual worker and partial-aware independent reader', 'Native baseline and separate router model/env/cost/paid-registry/RNG/cursor/absolute-bound warm-cold preservation', 'Labelled source/no-query/protection/ownership and actual saved-state fixtures', 'Freeze source/input/reader locks and exact fresh PID/parent/command/assignment gates'],
        'not_an_LLM_method_or_novelty_claim': True,
        'original_numerical_and_private_LLM_failed_primary_gates_remain_failed': True,
        'saved496of500_is_posthoc_development_NOT_this_new_result': True,
        'all6finalgoals': 'OPEN',
        'source_binding': {'author_class': definition, 'base_NET_sha256': sha(base_path),
                           'recipes_sha256': sha(O / 'All128_Source_Exact_Physical_Recipes.npz'),
                           'old_regime_scope_protocol_sha256': sha(R / 'outputs/public13_full_cohort_preparation_20261021/Protocol.json'),
                           'old500_root_list_sha256': sha(R / 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json')},
        'new_model_PF_converter_derivative_LP_optimizer_calls_by_preparation': 0,
    }
    put(O / 'Prospective_Router_Protocol.json', protocol)
    put(O / 'No_Repeat_And_Source_Input_Readiness.json', {
        'status': 'PASS_EXACT_SOURCE_RESET_RECIPE_AND_SCOPED_OLD_REGIME_DISJOINTNESS_ZERO_SCIENCE',
        'cases': 128, 'old_closed_distinct_noncontrolled_regimes': len(old_regimes),
        'new_distinct_noncontrolled_regimes': len(identities), 'old_intersections': 0,
        'source_recipe_only_reset_requests_NOT_PF': len(reset_requests),
        'stale_observations_discarded_not_claimed_new_physics': True,
        'source_reset_PF_kwargs': {'algorithm': 'bfsw'},
        'scope_limit': 'Closed named source13history; not universal historical absence. New future studies must extend the registry.',
        'ready_scientific_launch': False})
    print(json.dumps({'new_recipe_ids': [1000, 1127], 'count': 128, 'old_intersections': 0,
                      'actual_new_model_PF_calls': 0, 'worker_reader_gates_still_missing': True}))


if __name__ == '__main__':
    main()
