"""Freeze ALL4 source-selected first graph queries and tracked history gates.

This reproduces an external policy/backend integration, not the stopped
generator-regime intervention. Native actuator differences remain explicit.
"""
import copy,gzip,hashlib,json,pickle,sys,zlib
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'work'))
import candidate_process_runtime
sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
from reflection118_chronological_core_20261022 import read,put,sha,capsule,canonical
from prior_physical_query_footprints_20261018 import component,decode
from run_reflection118_chronological_local_20261022 import necessary
from resolve_original_role_input_component_collisions_20261022 import load_component
P=R/'outputs/published_graph118_first_queries_preparation_20261022'
def controls(n):
    return {t:[[int(i),int(r.bus),float(r.vm_pu)] for i,r in n[t].iterrows() if bool(r.in_service) and bool(n.bus.at[int(r.bus),'in_service'])] for t in ['gen','ext_grid']}
def main():
    P.mkdir(exist_ok=False);roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    admission=read(R/'outputs/published_graph118_backend_20261022/Author_Policy_Backend_Admission.json');assert len(admission['rows'])==4
    indexfile=R/'outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz'
    index=json.loads(gzip.decompress(indexfile.read_bytes()))
    extra=read(R/'outputs/reflection118_chronological_preparation_20261022/Additional_Prior_Attempt_References.json')
    snapshots=read(R/'outputs/original_role_remaining_native_history_scope_20261022/All_Saved_Snapshot_Components.json')
    rows=[]
    for i,(r,a) in enumerate(zip(roots,admission['rows'])):
        assert r['case_id']==a['case_id'];path=R/r['solved_payload'];assert sha(path)==r['payload_sha256']
        n=pickle.loads(path.read_bytes())['net'];target=copy.deepcopy(n);act=a['first_decoded_source_action']
        assert act['kind']=='GENERATOR_BUS_VOLTAGE_SETPOINT' and act['bus']==75 and act['vm_pu']==1.05
        for device in act['devices']:target[device['table']].at[device['index'],'vm_pu']=act['vm_pu']
        assert controls(target)!=controls(n);key,_=component(target);needed=necessary(target);witnesses=[]
        for ref in index.get(key,[]):
            old=decode((R/ref['journal']).parent,ref['before'])
            if necessary(old)!=needed:reason='EXACT_ACTIVE_LOAD_OR_LINE_BUS_SERVICE_DIFFERS'
            elif controls(old)!=controls(target):reason='REQUESTED_ACTIVE_GENERATOR_OR_SLACK_VOLTAGE_CONSTRAINT_DIFFERS'
            else:raise AssertionError('Known input collision requires separate exact reuse proof; no new PF')
            witnesses.append({'reference':ref,'exclusion':reason})
        assert not [x for x in extra.get(key,[]) if x['necessary_input']==needed], 'Additional same-component/load input unresolved; no PF'
        loadkey=hashlib.sha256(canonical(load_component(target.bus,target.load))).hexdigest()
        assert not [x for x in snapshots if x.get('shunt_key')==key and x.get('nominal_load_key')==loadkey], 'Snapshot collision unresolved; no PF'
        # Every new native call in the just-closed original-controller study
        # retains the old generator reference. Its failed calls are included.
        current_before=list((R/'outputs/r118chrono_20261022/local_controller').glob('*/*/pf_*_before.zlib'))
        current_relevant=0
        for p in current_before:
            old=pickle.loads(zlib.decompress(p.read_bytes()))
            if component(old)[0]!=key:continue
            if necessary(old)!=needed:continue
            assert controls(old)!=controls(target),'Current-study input collision including failed/unentered records'
            current_relevant+=1
        cap=capsule(P/f'target_{i:02d}.zlib',{'net':target,'case_id':r['case_id'],'action':act})
        rows.append({'case_id':r['case_id'],'root_payload_sha256':r['payload_sha256'],'target':cap,
            'source_action':act,'tracked_same_shunt_component_refs':len(witnesses),'history_witnesses':witnesses,
            'all_closed_original_controller_before_capsules_checked':len(current_before),'same_component_load_current_study_exclusions':current_relevant,
            'additional_same_component_load_refs':0,'saved_snapshot_same_component_load_refs':0})
    sources=[R/'work/run_published_graph118_first_queries_20261022.py',R/'work/audit_published_graph118_first_queries_20261022.py']
    assert all(p.is_file() for p in sources)
    put(P/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'FROZEN_ALL4_SOURCE_ORDER_FIRST_GRAPH_QUERIES_BEFORE_OUTCOMES',
        'question':'Does the unchanged author graph first action transfer through the named generator/capacitor pandapower backend on every registered severe root? This is a bounded native-actuator integration experiment, not a full policy score or same-resource LLM comparison.',
        'targets':rows,'solver_kwargs':{'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True},
        'source_hashes':{p.relative_to(R).as_posix():sha(p) for p in sources+[Path(__file__),R/'work/published_graph118_backend_20261022.py']},
        'source_admission_sha256':sha(R/'outputs/published_graph118_backend_20261022/Author_Policy_Backend_Admission.json'),
        'bound_seconds':600,'reader_seconds':600,'binary_bytes':64*1024**2,
        'history_scope':'All60426-index and separately prepared additional-lineage component refs; saved738snapshots and all closed current-study primary/failed/unentered before capsules. Scope is tracked retained native inputs, not a universal untracked-history certificate. Different requested active regulator references are different nonlinear solver input identities, even if Qlimits later bind.',
        'unchanged_first_actions_only':True,'initial_PF_reuses':4,'new_primary_PF_calls_max':4,'first_independent_return_replays_max':4,
        'new_model_GPU_training_optimizer_calls':0,'actual_policy_commits':0,
        'no_selection_retune_retry_or_automatic_full_campaign':True,'native_actuation_not_equal_to_HierGrid_positive_shunt_role':True,
        'old_generator_regime_study':'STOPPED_UNTOUCHED; this is external published baseline integration only.'})
    for name,source,output,coord in [('Owner_Protocol.json',sources[0],'published_graph118_first_queries_execution_20261022','published_graph118_first_queries_coordination_20261022'),('Reader_Owner_Protocol.json',sources[1],'published_graph118_first_queries_independent_20261022','published_graph118_first_queries_reader_coordination_20261022')]:
        put(P/name,{'single_owner':{'source':source.relative_to(R).as_posix(),'sha256':sha(source),'python':'work/vcsa_module_env/Scripts/python.exe','output':'outputs/'+output,'coordination':'outputs/'+coord,'bound_seconds':700}})
    put(P/'Launch_Readiness.json',{'status':'PASS_ALL4_EXACT_NEW_TARGET_NATIVE_SOURCE_AND_TRACKED_HISTORY_GATES','source_action_selection':'ALL4ordered roots, actual source-selectedbus75GENtarget1.05, no outcome-selected bus/Q/root/guard.','targets':4,'new_scientific_calls':0,'full_comparison':'NOT_READY_FROM_THIS_ENGINEERING_GATE'})
    print(json.dumps({'graph_first_queries_prepared':4,'tracked_collision_gates':'PASS','new_PF_calls':0}))
if __name__=='__main__':main()
