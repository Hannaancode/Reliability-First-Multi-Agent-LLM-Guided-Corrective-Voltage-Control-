"""One charged replay per new returned FIT physics input; independent dense/dual/guard/cursor audit."""
import os,json,pickle,time,hashlib
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_fit_teacher_preparation_20261020';SRC=ROOT/'outputs/native_fit_teacher_execution_20261020';OUT=ROOT/'outputs/native_fit_teacher_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from native_fit_teacher_math_20261020 import verify
    from candidate_process_evidence_utils import frozen_checks
    from pandapower.pypower.makeSbus import makeSbus
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text());result=json.loads((SRC/'Result.json').read_text());manifest=json.loads((SRC/'Closed_Manifest.json').read_text());graph=np.load(ROOT/p['graph']);cost={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'failed_primary_not_repeated':0,'model_derivative_LU_LP_optimizer_GPU_calls':0};maximum=0.;fields=OUT/'replay_fields';fields.mkdir();checks=[]
    for rel,h in p['source_and_input_hashes'].items():assert sha(ROOT/rel)==h
    for f in manifest['files']:assert (SRC/f['path']).stat().st_size==f['bytes'] and sha(SRC/f['path'])==f['sha256']
    prev='0'*64;events=[]
    for line in (SRC/'events.jsonl').read_text(encoding='utf-8').splitlines():
        r=json.loads(line);assert r['event']['previous']==prev;prev=hashlib.sha256(json.dumps(r['event'],sort_keys=True,separators=(',',':')).encode()).hexdigest();assert prev==r['sha256'];events.append(r['event'])
    assert prev==manifest['journal_last_sha256'] and [w['seed'] for w in result['all_worlds']]+result['unentered_seeds']==p['FIT_seeds'];replayed={};seen=set()
    for receipt in result['receipts']:
        assert time.monotonic()-start<p['reader_seconds'];i=receipt['index'];path=SRC/'physics'/f'PF{i:05d}_before.pkl'
        with path.open('rb') as f:net=pickle.load(f)
        key=(signature(net),json.dumps(receipt['kwargs'],sort_keys=True));assert key[0]==receipt['physical_signature'] and key not in seen;seen.add(key)
        if receipt['status']!='RETURNED':cost['failed_primary_not_repeated']+=1;continue
        cost['PF_attempts']+=1;t=time.perf_counter()
        try:b.pp.runpp(net,**receipt['kwargs'])
        except BaseException:cost['PF_exceptions']+=1;put(OUT/'Failed_Independent_Replay.json',{'receipt':i,'costs':cost});raise
        cost['PF_returns']+=1;assert net.converged and signature(net)==key[0];saved=np.load(SRC/'physics'/f'PF{i:05d}_fields.npz');out={}
        for name in saved.files:
            actual=net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float);assert actual.shape==saved[name].shape and np.allclose(actual,saved[name],atol=1e-10,rtol=0,equal_nan=True);finite=np.isfinite(actual)&np.isfinite(saved[name]);maximum=max(maximum,float(np.max(np.abs(actual[finite]-saved[name][finite]))) if finite.any() else 0.);out[name]=actual
        np.savez(fields/f'PF{i:05d}.npz',**out);pp=net._ppc;v=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));s=makeSbus(pp['baseMVA'],pp['bus'],pp['gen']);res=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert res<=1e-7;replayed[i]=net;put(fields/f'PF{i:05d}.json',{'PF_return':True,'seconds':time.perf_counter()-t,'KCL_residual':res,'full_fields_match':True,'primary_signature':key[0]})
    for world in result['all_worlds']:
        if 'root_receipt' not in world:checks.append({'seed':world['seed'],'status':'UNKNOWN_PRIMARY_ROOT_NOT_RETURNED'});continue
        current=replayed[world['root_receipt']];past=[]
        for decision in world['steps']:
            d=ROOT/decision['directory']
            with (d/'Current_ENV.pkl').open('rb') as f:env=pickle.load(f)
            with (d/'Full_Cursor_RNG_Registry.pkl').open('rb') as f:cursor=pickle.load(f)
            assert cursor['seed']==world['seed'] and cursor['next_step']==decision['step'] and cursor['remaining_operations']==101-decision['step'] and cursor['history']==past and cursor['source_protocol_sha256']==sha(PREP/'Protocol.json')
            for n in ['bus','line','sgen','load','ext_grid','res_bus']:assert env['network'][n].equals(current[n])
            u,S=verify(d,current);assert np.array_equal(u,np.load(d/'Native_u.npy')) and np.array_equal(u,np.asarray(decision['raw_teacher_u'],dtype=np.float32));q=current.sgen.q_mvar.to_numpy()[:3]-u
            with (d/'Candidate_ENV_After.pkl').open('rb') as f:candidate=pickle.load(f)['network']
            assert np.array_equal(candidate.sgen.q_mvar.to_numpy()[:3],q)
            for n in ['bus','line','load','ext_grid','gen','shunt','switch']:assert current[n].equals(candidate[n])
            assert current.sgen.drop(columns=['q_mvar']).equals(candidate.sgen.drop(columns=['q_mvar'])) and np.array_equal(current.sgen.q_mvar.to_numpy()[3:],candidate.sgen.q_mvar.to_numpy()[3:])
            if decision['candidate_receipt'] is not None:actual=replayed[decision['candidate_receipt']];assert candidate.res_bus.equals(actual.res_bus)
            v0=current.res_bus.vm_pu.to_numpy();v1=candidate.res_bus.vm_pu.to_numpy();normal=(v0>=.95)&(v0<=1.05);ok=bool(np.isfinite(v1).all() and (v1[normal]>=.95-1e-8).all() and (v1[normal]<=1.05+1e-8).all() and (v1<.95).sum()<=(v0<.95).sum() and (v1>1.05).sum()<=(v0>1.05).sum());assert ok==decision['accepted'] and np.array_equal(np.asarray(decision['committed_teacher_u']),u if ok else np.zeros(3))
            if ok:current=candidate;past.append({'step':decision['step'],'all13_vm':v1.tolist(),'absolute_Q_Mvar':q.reshape(3,1).tolist()})
            else:assert decision is world['steps'][-1],'Rejectedquery must terminate, no outcome-drivenretry'
        if 'final_vm' in world:assert np.array_equal(current.res_bus.vm_pu.to_numpy(),np.asarray(world['final_vm']))
        checks.append({'seed':world['seed'],'status':'PASS_ALL_RETURNED_CONTINUOUS_SOURCE_NATIVE_LP_DENSE_CURSOR_HISTORY_PROTECTION','primary_terminal':world['status']})
    primary=result['actual_costs'];assert sum(e['kind']=='PF_attempt' for e in events)==primary['PF_attempts'] and sum(e['kind']=='PF_return' for e in events)==primary['PF_returns'] and primary['derivative_returns']==primary['LU_returns'] and primary['RHS_returns']==3*primary['LU_returns']
    audit={'status':'PASS_INDEPENDENT_ALL_AVAILABLE_NATIVE64_FIT_SOURCE_DENSE_DERIVATIVE_LP_OPTIMALITY_NATIVE_ACTION_GUARD_CONTINUOUS_PHYSICS_CURSOR_COST_AUDIT','primary_scientific_status':result['status'],'all_worlds':checks,'unentered_seeds':result['unentered_seeds'],'teacher_rows':result['teacher_rows'],'primary_costs':primary,'actual_reader_costs':cost,'maximum_full_field_delta':maximum,'DEV_confirmation_new_PF_calls':0,'original_frozen_checks':frozen_checks(),'no_automatic_GPU_training_or_superiority_claim':True,'workflow_seconds':time.monotonic()-start};put(OUT/'Independent_Audit.json',audit);put(OUT/'Closed_Manifest.json',{'files':{f.relative_to(OUT).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()}});print('INDEPENDENT_NATIVE_FIT_PREFIX_PASS',result['status'])
if __name__=='__main__':main()
