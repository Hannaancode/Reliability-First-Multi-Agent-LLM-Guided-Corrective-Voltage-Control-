"""Local hashes, frozen-asset checks and scientific ZIP sealing only."""
import hashlib,json,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)
def frozen_checks():
    lock=read(ROOT/'work/e/bank/BANK_LOCK.json');bank=read(ROOT/'work/e/bank/scenario_manifest.json')
    matched=read(ROOT/'outputs/matched_campaign_protocol.json');model=read(ROOT/'outputs/frozen_input_verification.json')
    checks={'frozen_matched_protocol_sha256':sha(ROOT/'outputs/matched_campaign_protocol.json')=='a2d18b90656d541b29ca35062503b2bc6156aee28e1f5a794b392e91b35a3aa7',
        'frozen_controller_sources':all(sha(ROOT/p)==h for p,h in matched['source_sha256'].items()),
        'all_62_scenario_files':len(lock['scenario_file_sha256'])==62 and all(sha(ROOT/'work/e/bank/scenarios'/n)==h for n,h in lock['scenario_file_sha256'].items()),
        'locked_file_set':set(lock['scenario_file_sha256'])=={p.name for p in (ROOT/'work/e/bank/scenarios').glob('*.json')},
        'bank_manifest':sha(ROOT/'work/e/bank/scenario_manifest.json')==lock['manifest_sha256'],
        'bank_sanity_report':sha(ROOT/'work/e/bank/sanity_report.json')==lock['sanity_report_sha256'],
        'network':sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json')==bank['frozen_asset_hashes']['federation_network_sha256'],
        'metadata':sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')==bank['frozen_asset_hashes']['federation_metadata_sha256'],
        'model_root_files':all(sha(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'/n)==h for n,h in model['model_files'].items())}
    assert all(checks.values())
    return {'audited_at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'all_passed':True,'new_model_or_PF_calls':0}
def seal(out,files,archive_name):
    assert len(files)==len(set(files)) and all('\\' not in name for name in files)
    descriptor={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
    write(out/'Supplement_Manifest.json',descriptor)
    path=out/archive_name
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n,p in files.items():z.write(p,n)
        z.write(out/'Supplement_Manifest.json','Supplement_Manifest.json')
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(files)+1 and z.testzip() is None
        for n,m in descriptor.items():b=z.read(n);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
    result={'unique_members':len(files)+1,'bytes':path.stat().st_size,'sha256':sha(path),
        'CRC_and_every_member_hash_passed':True,'local_only':True,'private_export':False}
    write(out/'Local_Archive_Audit.json',result);return result
