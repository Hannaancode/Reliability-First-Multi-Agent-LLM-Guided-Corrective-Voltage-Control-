"""Same verified commit functions, bound to a new full-suffix controller mode.

All v1 function ASTs are unchanged. No old source or old owner is modified.
This supplies no scientific launch, model, solver or automatic resume.
"""
import ast
import hashlib
from pathlib import Path
import paid_joint_commit_v1 as original

SOURCE = Path(original.__file__)
TREE = ast.parse(SOURCE.read_text('utf8'))
FUNCTIONS = [node for node in TREE.body if isinstance(node, ast.FunctionDef)]
MODE = 'ACTUAL_PAID_PROTECTED_FULL_CURRENT_STATE_SUFFIX'
environment = original.__dict__.copy()
environment['MODE'] = MODE
exec(compile(ast.Module(body=FUNCTIONS, type_ignores=[]), str(SOURCE), 'exec'), environment)
for definition in FUNCTIONS:
    globals()[definition.name] = environment[definition.name]
SOURCE_CERTIFICATE = {'original_source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'all_original_commit_validation_checkpoint_function_ASTs_unchanged': True,
    'only_change': 'Separately prospective full-current-state-suffix mode binding',
    'old_mode_and_source_unchanged': original.MODE != MODE, 'scientific_launch_supplied': False}
