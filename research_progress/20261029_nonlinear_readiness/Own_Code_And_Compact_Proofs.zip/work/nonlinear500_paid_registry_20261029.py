"""Saved-only, bounded native13 paid-physics registry. No scientific imports/calls.

Build: python work/nonlinear500_paid_registry_20261029.py
Read:  ... --root 0
       ... --signature HEX --kwargs '{"algorithm":"bfsw","init":"dc"}'
Lookup verifies the selected binary bytes, but never deserializes or executes them.
An absent key is NOT authorization to run physics. Historical costs remain paid.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/nonlinear500_paid_registry_20261029'
BASE = 'outputs/public13_matched_numeric_preparation_20261021'
OLD = 'outputs/public13_remaining_published_cohort_20261021'
MISS = 'outputs/public13_missing_only_execution_20261021'
MATCH = 'outputs/public13_matched_numeric_execution_20261021'
FRESH = 'outputs/public13_fresh_router_execution_20261022'
ENG = 'outputs/stable_ddpg_native_engineering_20261020'
REM = 'outputs/stable_ddpg_native_remaining_engineering_v2_20261020'
EP = 'outputs/stable_ddpg_native_episode_20261020'
UP = 'outputs/native_action_upgrade_support_20261020'
FIT = 'outputs/native_fit_teacher_execution_20261020'
AFF = 'outputs/native_affine_physics_support_20261020'
N15 = 'outputs/native15_saved_command_physics_20261020'
ROOT_AUDIT = ENG + '/preserved_root_independent_audit/Independent_Partial_Audit.json'
OLD_MANIFEST = 'outputs/public13_terminal_saved_prefix_v2_20261021/Original_Failed_Study_File_Manifest.json'
BINDINGS, DOCS, MANIFESTS, JOURNALS = {}, {}, {}, {}
AUDITS = set()
GAPS, WARNINGS, CHECKS = [], [], []


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def relpath(path):
    p = (R / path).resolve()
    p.relative_to(R)
    return p


def read(path):
    if path not in DOCS:
        p = relpath(path)
        raw = p.read_bytes()
        DOCS[path] = json.loads(raw)
        BINDINGS[path] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw),
                              verification='metadata_bytes_hashed_this_build')
    return DOCS[path]


def bind_source(path):
    p = relpath(path)
    BINDINGS[path] = dict(sha256=sha(p), bytes=p.stat().st_size,
                          verification='source_bytes_hashed_this_build_not_executed')


def check(condition, name):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)


def key(sig, kwargs):
    return sig + '|' + json.dumps(kwargs, sort_keys=True)


def manifest(directory, source=None):
    if directory not in MANIFESTS:
        source = source or directory + '/Closed_Manifest.json'
        d = read(source)
        rows = d['files']
        rows = rows if isinstance(rows, list) else [dict(path=k, **v) for k, v in rows.items()]
        MANIFESTS[directory] = (source, {v['path']: v for v in rows})
    return MANIFESTS[directory]


def descriptor(directory, path, expected=None):
    mf, rows = manifest(directory)
    relative = path.removeprefix(directory + '/')
    row = rows[relative]
    if expected is not None:
        check(row['sha256'] == expected, 'manifest_digest:' + path)
    p = relpath(path)
    check(p.is_file() and p.stat().st_size == row['bytes'], 'exists_size:' + path)
    return dict(path=path, sha256=row['sha256'], bytes=row['bytes'], manifest=mf,
                verification='closed_manifest_digest_and_current_size; hash_bytes_at_lookup')


def audit(path):
    if path in AUDITS:
        return path
    d = read(path)
    check(str(d.get('status', '')).startswith('PASS'), 'audit_PASS:' + path)
    parent = path.rsplit('/', 1)[0]
    if (R / parent / 'Closed_Manifest.json').exists():
        _, entries = manifest(parent)
        if path.rsplit('/', 1)[1] in entries:
            descriptor(parent, path, BINDINGS[path]['sha256'])
        else:
            WARNINGS.append('Audit certificate saved outside its directory closed manifest; frozen by current metadata digest: ' + path)
    else:
        WARNINGS.append('Audit certificate directory has no closed manifest; certificate frozen by current metadata digest and prior canonical-index provenance: ' + path)
    AUDITS.add(path)
    return path


def journal(directory, filename='events.jsonl'):
    path = directory + '/' + filename
    if path in JOURNALS:
        return JOURNALS[path]
    p = relpath(path)
    # Parse only saved event metadata. No old binary archive rehash/replay.
    attempts, terminal, counts = [], {}, Counter()
    with p.open(encoding='utf-8') as f:
        for line_no, line in enumerate(f, 1):
            row = json.loads(line)
            e = row.get('event', row)
            kind = e.get('kind', '')
            counts[kind] += 1
            ident = e.get('index', e.get('number', e.get('context')))
            if kind == 'PF_attempt':
                attempts.append(dict(line=line_no, event=e, event_sha256=row.get('sha256')))
            elif kind in ('PF_return', 'PF_exception'):
                terminal[str(ident)] = dict(line=line_no, event=e, event_sha256=row.get('sha256'))
    if directory in MANIFESTS or (R / directory / 'Closed_Manifest.json').exists():
        proof = descriptor(directory, path)
    else:
        # Only the tiny original failed seed0 journal lacks a primary manifest.
        bind_source(path)
        proof = dict(path=path, **BINDINGS[path])
    result = dict(path=path, binding=proof, attempts=attempts, terminal=terminal,
                  PF_kind_counts={k: v for k, v in counts.items() if k.startswith('PF_')})
    JOURNALS[path] = result
    return result


def add(registry, sig, kwargs, provenance, candidate=None):
    k = key(sig, kwargs)
    row = registry.setdefault(k, dict(physical_signature=sig, kwargs=kwargs,
                                     provenance=[], reuse=None, block_new_PF=True))
    row['provenance'].append(provenance)
    if candidate is not None and row['reuse'] is None:
        row['reuse'] = candidate
    return row


def closure_receipts(registry, directory, reader, width=5, additional=False):
    result_path = directory + '/Result.json'
    result = read(result_path)
    cert = audit(reader + '/Independent_Audit.json')
    descriptor(directory, result_path, BINDINGS[result_path]['sha256'])
    manifest(reader)
    independent = read(reader + '/Result.json') if (R / reader / 'Result.json').exists() else None
    if independent:
        descriptor(reader, reader + '/Result.json', BINDINGS[reader + '/Result.json']['sha256'])
        rr = {key(v['physical_signature'], v['kwargs']): (i, v)
              for i, v in enumerate(independent['receipts'])}
    j = journal(directory)
    attempts = {str(v['event']['index']): v for v in j['attempts']}
    rs = result['receipts']
    check(set(attempts) == {str(v['index']) for v in rs}, 'all_attempts_in_receipts:' + directory)
    for pos, v in enumerate(rs):
        sig, kwargs, idx = v['physical_signature'], v['kwargs'], v['index']
        a = attempts[str(idx)]
        check((a['event']['physical_signature'], a['event']['kwargs']) == (sig, kwargs),
              'attempt_exact_key:' + directory + '/' + str(idx))
        stem = directory + '/physics/PF' + f'{idx:0{width}d}'
        before = descriptor(directory, stem + '_before.pkl', v.get('before_sha256'))
        provenance = dict(source=result_path, pointer=f'/receipts/{pos}', status=v['status'],
                          scope=v.get('scope', v.get('context')), before=before,
                          attempt_journal_line=a['line'], attempt_event_sha256=a['event_sha256'],
                          terminal_journal=j['terminal'].get(str(idx)), independent_certificate=cert)
        # Keep terminal event provenance compact; the exact source line remains available.
        if provenance['terminal_journal']:
            t = provenance['terminal_journal']
            provenance['terminal_journal'] = {k: t[k] for k in ('line', 'event_sha256')}
        candidate = None
        if v['status'] == 'RETURNED':
            after = descriptor(directory, v.get('after', stem + '_after.pkl'), v.get('after_sha256'))
            fields = descriptor(directory, v.get('fields', stem + '_fields.npz'), v.get('fields_sha256'))
            if independent:
                ipos, iv = rr[key(sig, kwargs)]
                check(iv['status'] == 'RETURNED', 'independent_return:' + stem)
                check(iv.get('fields_sha256') == fields['sha256'], 'independent_fields_digest:' + stem)
                provenance['independent_attempt'] = dict(source=reader + '/Result.json',
                                                        pointer=f'/receipts/{ipos}', status=iv['status'])
            else:
                # FIT reader has independently replayed fields and an aggregate PASS audit.
                rep = descriptor(reader, reader + f'/replay_fields/PF{idx:05d}.npz')
                check(rep['sha256'] == fields['sha256'], 'FIT_independent_fields_digest:' + stem)
                provenance['independent_attempt'] = dict(fields=rep, status='RETURNED_AUDITED')
            candidate = dict(after=after, fields=fields, independent_certificate=cert,
                             source=result_path, pointer=f'/receipts/{pos}')
        add(registry, sig, kwargs, provenance, candidate)
    return dict(source=result_path, independent_certificate=cert, statuses=dict(Counter(v['status'] for v in rs)),
                journal_PF_counts=j['PF_kind_counts'], costs=result.get('costs', result.get('actual_costs')),
                source_status=result['status'], additional_non500_scope=additional)


def build():
    O.mkdir(exist_ok=True)
    registry, sources, aliases, exclusions = {}, [], [], []
    old = read(BASE + '/Historical_Paid_Physical_Index.json')
    rootsdoc = read(BASE + '/All500_Audited_Exact_Roots.json')
    protocol = read(BASE + '/Protocol.json')
    for p in (BASE + '/Historical_Paid_Physical_Index.json', BASE + '/All500_Audited_Exact_Roots.json'):
        check(BINDINGS[p]['sha256'] == protocol['source_and_input_hashes'][p], 'frozen_protocol_binding:' + p)
    for p in ['work/prepare_public13_matched_numeric_inputs_20261021.py',
              'work/native_upgrade_support_engine_20261020.py',
              'work/public13_matched_numeric_engine_20261021.py',
              'work/public13_fresh_router_engine_20261022.py']:
        bind_source(p)
    manifest(OLD, OLD_MANIFEST)
    olddoc = read(OLD + '/Failure.json')
    missdoc = read(MISS + '/Result.json')
    descriptor(OLD, OLD + '/Failure.json', BINDINGS[OLD + '/Failure.json']['sha256'])
    descriptor(MISS, MISS + '/Result.json', BINDINGS[MISS + '/Result.json']['sha256'])
    row_by_after = {}
    for directory, doc, fname in [(OLD, olddoc, 'Failure.json'), (MISS, missdoc, 'Result.json')]:
        for pos, v in enumerate(doc['receipts']):
            if v.get('origin') == 'ORIGINAL_PAID_PREFIX':
                continue  # a paid reuse reference, not an additional physical attempt
            stem = directory + f"/physics/PF{v['index']:06d}"
            row_by_after[stem + '_after.pkl'] = (directory + '/' + fname, pos, v, stem)
        j = journal(directory)
        actual = [v for v in doc['receipts'] if v.get('origin') != 'ORIGINAL_PAID_PREFIX']
        check(len(j['attempts']) == len(actual), 'old_primary_attempt_count:' + directory)
        sources.append(dict(source=directory + '/' + fname,
                            statuses=dict(Counter(v['status'] for v in actual)),
                            journal_PF_counts=j['PF_kind_counts'], costs=doc['costs']))
    epdoc = read(EP + '/Result.json')
    audit(ROOT_AUDIT)
    root_cert = ROOT_AUDIT
    canonical_by_after = {}
    for k, v in old['returned_exact_initializer_entries'].items():
        check(k == key(v['physical_signature'], v['kwargs']), 'old_key:' + k)
        directory = '/'.join(v['after'].split('/')[:2])
        cert = audit(v['independent_certificate'])
        after = descriptor(directory, v['after'], v['after_sha256'])
        fields = descriptor(directory, v['fields'], v['fields_sha256'])
        before = descriptor(directory, v['after'].replace('_after.pkl', '_before.pkl'))
        provenance = dict(source=BASE + '/Historical_Paid_Physical_Index.json',
                          mapping_key=k, status='RETURNED_INDEPENDENTLY_AUDITED', before=before,
                          independent_certificate=cert)
        if v['after'] in row_by_after:
            path, pos, raw, stem = row_by_after[v['after']]
            check((raw['physical_signature'], raw['kwargs'], raw['status']) ==
                  (v['physical_signature'], v['kwargs'], 'RETURNED'), 'base_receipt_join:' + stem)
            provenance.update(original_source=path, original_pointer=f'/receipts/{pos}',
                              original_status=raw['status'], scope=raw.get('context'))
        else:
            idx = int(Path(v['after']).stem.replace('PF', '').replace('_after', ''))
            if directory == EP:
                raw = epdoc['receipts'][idx]
                check(raw['kwargs'] == v['kwargs'], 'seed0_suffix_kwargs:' + str(idx))
                aliases.append(dict(canonical_signature=v['physical_signature'], kwargs=v['kwargs'],
                                    old_namespace_signature=raw['physical_input_sha256'],
                                    source=EP + '/Result.json', pointer=f'/receipts/{idx}',
                                    canonicalization_source=BASE + '/Historical_Paid_Physical_Index.json',
                                    before=before, after=after))
                provenance.update(original_source=EP + '/Result.json', original_pointer=f'/receipts/{idx}')
            elif directory == REM:
                if idx:
                    ipath = REM + f'/PF{idx}_Identity.json'
                    raw = read(ipath)
                    check(raw['kwargs'] == v['kwargs'], 'seed0_step1_kwargs:' + str(idx))
                    aliases.append(dict(canonical_signature=v['physical_signature'], kwargs=v['kwargs'],
                                        old_namespace_signature=raw['physical_input_sha256'], source=ipath,
                                        canonicalization_source=BASE + '/Historical_Paid_Physical_Index.json',
                                        before=before, after=after))
                else:
                    cert = root_cert
                    provenance.update(original_status='ATTEMPTED_WITHOUT_PRIMARY_RETURN_EVENT',
                                      recovery='Preserved exact root independently replayed; original failure retained',
                                      original_source=ENG + '/Failure.json', independent_certificate=cert)
                    read(ENG + '/Failure.json')
            else:
                raise AssertionError('unrecognized old canonical alias source: ' + directory)
        candidate = dict(after=after, fields=fields, independent_certificate=cert,
                         source=BASE + '/Historical_Paid_Physical_Index.json', mapping_key=k)
        add(registry, v['physical_signature'], v['kwargs'], provenance, candidate)
        canonical_by_after[v['after']] = k
    # Never reduce the signature deny set to only successful exact kwargs keys.
    denied = {sig: [BASE + '/Historical_Paid_Physical_Index.json#/all_relevant_attempted_signatures']
              for sig in old['all_relevant_attempted_signatures']}
    check(len(old['returned_exact_initializer_entries']) == 8679, 'original_8679_entries')
    # The original seed0 run ended immediately after its PF_attempt journal event.
    j0 = journal(ENG, 'Journal.jsonl')
    check(len(j0['attempts']) == 1 and not j0['terminal'], 'original_seed0_unclosed_event_preserved')
    a0 = j0['attempts'][0]
    root0 = rootsdoc['roots'][0]
    root0key = key(root0['physical_signature'], a0['event']['kwargs'])
    check(registry[root0key]['reuse']['after']['sha256'] == root0['sha256'], 'exact_original_seed0_root_alias')
    aliases.append(dict(canonical_signature=root0['physical_signature'], kwargs=a0['event']['kwargs'],
                        old_namespace_signature=a0['event']['physical_input_sha256'],
                        source=j0['path'], line=a0['line'], event_sha256=a0['event_sha256'],
                        status='ATTEMPTED_WITHOUT_PRIMARY_RETURN_EVENT',
                        independent_recovery_certificate=root_cert))
    registry[root0key]['provenance'].append(aliases[-1])
    for directory, width in [(REM, 1), (EP, 3)]:
        jj = journal(directory, 'Journal.jsonl')
        for a in jj['attempts']:
            e = a['event']; idx = e.get('index', e.get('number'))
            suffix = f'/physics/PF{idx:03d}_after.pkl' if directory == EP else f'/PF{idx}_after.pkl'
            k = canonical_by_after[directory + suffix]
            registry[k]['provenance'].append(dict(source=jj['path'], line=a['line'],
                                                  event_sha256=a['event_sha256'],
                                                  status='ATTEMPTED', original_namespace_signature=e.get('physical_input_sha256'),
                                                  terminal=jj['terminal'].get(str(idx), {}).get('event', {}).get('kind')))
    sources.append(closure_receipts(registry, MATCH, 'outputs/public13_matched_numeric_independent_20261021'))
    anchorpath = 'outputs/public13_fresh_router_execution_preparation_20261022/Historical_Physical_Attempt_Anchors.json'
    anchors = read(anchorpath)
    for a in anchors['anchors']:
        read(a['path'])
        check(BINDINGS[a['path']]['sha256'] == a['sha256'], 'fresh_history_anchor:' + a['path'])
    expected = set(old['all_relevant_attempted_signatures']) | {v['physical_signature'] for v in read(MATCH + '/Result.json')['receipts']}
    check(set(anchors['physical_signatures']) == expected, 'fresh9750_exact_union')
    sources.append(closure_receipts(registry, FRESH, 'outputs/public13_fresh_router_independent_20261022'))
    sources.append(closure_receipts(registry, UP, 'outputs/native_action_upgrade_support_independent_20261020', 4, True))
    sources.append(closure_receipts(registry, FIT, 'outputs/native_fit_teacher_independent_20261020', 5, True))
    # All affine queries are retained, including guard-rejected returned candidates.
    adoc = read(AFF + '/Result.json')
    ac = audit('outputs/native_affine_physics_independent_20261020/Independent_Audit.json')
    checks = {x['context']: x for x in read(ac)['checks']}
    aj = journal(AFF)
    amap = {a['event']['context']: a for a in aj['attempts']}
    check(len(amap) == len(adoc['all24contexts']) == 24, 'all24_affine_attempts')
    for pos, v in enumerate(adoc['all24contexts']):
        idx = v['context']; stem = AFF + f'/context_{idx:02d}'
        sig, kw = v['physical_signature'], v['kwargs']
        check((amap[idx]['event']['signature'], amap[idx]['event']['kwargs']) == (sig, kw), 'affine_attempt_key:' + str(idx))
        check(checks[idx]['status'] == 'PASS', 'affine_independent_context:' + str(idx))
        before = descriptor(AFF, stem + '/Candidate_Before.pkl')
        after = descriptor(AFF, stem + '/Candidate_After.pkl')
        fields = descriptor(AFF, stem + '/Fields.npz')
        add(registry, sig, kw, dict(source=AFF + '/Result.json', pointer=f'/all24contexts/{pos}',
                                  status=v['status'], guard_accepted=v['typed_proposal_accepted'],
                                  actual_commit=v['actual_commit'], before=before,
                                  independent_certificate=ac, attempt_journal_line=amap[idx]['line']),
            dict(after=after, fields=fields, independent_certificate=ac,
                 source=AFF + '/Result.json', pointer=f'/all24contexts/{pos}'))
    sources.append(dict(source=AFF + '/Result.json', statuses=dict(Counter(x['status'] for x in adoc['all24contexts'])),
                        costs=adoc['costs'], journal_PF_counts=aj['PF_kind_counts'], independent_certificate=ac,
                        retained_guard_rejections=sum(not x['typed_proposal_accepted'] for x in adoc['all24contexts'])))
    n15attempt = read(N15 + '/Attempt.json')
    n15result = read(N15 + '/Result.json')
    n15cert = audit('outputs/native15_saved_command_physics_independent_20261020/Result.json')
    n15key = key(n15attempt['signature'], n15attempt['kwargs'])
    add(registry, n15attempt['signature'], n15attempt['kwargs'],
        dict(source=N15 + '/Attempt.json', status='RETURNED_AUDITED_WITHOUT_SAVED_AFTER_NET',
             result=N15 + '/Result.json', guard_accepted=n15result['guard_accepted'],
             actual_commits=n15result['actual_commits'], independent_certificate=n15cert,
             before=descriptor(N15, N15 + '/Actual_Native_Query_Before.pkl'),
             fields=descriptor(N15, N15 + '/Actual_All_Fields.npz')))
    GAPS.append(dict(id='NATIVE15_NO_AFTER_NET', key=n15key, severity='KEY_LOCAL_BLOCK',
                     missing=['saved solved after-NET capsule and its digest'],
                     disposition='Block this attempted key and physical signature; do not reconstruct or re-run physics.'))
    sources.append(dict(source=N15 + '/Result.json', independent_certificate=n15cert,
                        statuses={'RETURNED_AUDITED_WITHOUT_SAVED_AFTER_NET': 1},
                        primary_PF_attempts=1, primary_PF_returns=1, rejected_commit_retained=True))
    for path, field in [('outputs/native_full_grid_affine_gate_20261020/Result.json', 'PF_model_training_GPU_calls'),
                        ('outputs/public13_radial_outer_unentered_v2_execution_20261022/Result.json', 'new_PF_model_derivative_LU_training_calls')]:
        d = read(path)
        check(d['costs'][field] == 0, 'zero_physics_exclusion:' + path)
        exclusions.append(dict(source=path, reason='No physical call; numerical solver attempts are not PF attempts', costs=d['costs']))
    roots = []
    check([x['seed'] for x in rootsdoc['roots']] == list(range(500)), 'exact500_root_order')
    for row in rootsdoc['roots']:
        k = key(row['physical_signature'], {'algorithm': 'bfsw'})
        check(k in registry and registry[k]['reuse'] is not None, 'audited_root_solver_key:' + str(row['seed']))
        p = relpath(row['path'])
        check(p.is_file(), 'exact_root_file_exists:' + str(row['seed']))
        if row['seed']:
            d = OLD if row['seed'] <= 162 else MISS
            cap = descriptor(d, row['path'], row['sha256'])
        else:
            check(sha(p) == row['sha256'], 'original_root_bytes_exact')
            cap = dict(path=row['path'], sha256=row['sha256'], bytes=p.stat().st_size,
                       independent_certificate=root_cert, verification='exact_original_root_bytes_hashed')
        roots.append(dict(**row, initialization_kwargs={'algorithm': 'bfsw'},
                          exact_paid_root_key=k, capsule_binding=cap,
                          source=BASE + '/All500_Audited_Exact_Roots.json', source_pointer=f"/roots/{row['seed']}",
                          authorization='Reuse exact full capsule; never regenerate reset/root'))
    for k, v in registry.items():
        denied.setdefault(v['physical_signature'], []).append(k)
        v['status'] = 'REUSABLE_AUDITED_EXACT_KEY' if v['reuse'] else 'BLOCKED_ATTEMPTED_NO_COMPLETE_REUSE_CAPSULE'
    # A signature present only in the old attempt set remains blocked even without kwargs.
    unresolved_signatures = sorted(set(denied) - {v['physical_signature'] for v in registry.values()})
    if unresolved_signatures:
        GAPS.append(dict(id='SIGNATURE_ONLY_ATTEMPTS', severity='SIGNATURE_LOCAL_BLOCK',
                         signatures=unresolved_signatures, missing=['solver kwargs', 'terminal result/capsule']))
    WARNINGS.extend([
        'This is a finite named-source native13 registry, not proof that no arbitrary historical study exists.',
        'Old preparation scanned 566 saved before files across 13 scopes, but retained only the all500-relevant signature union, not its per-file regime/canonicalization map. That old scan is source-bound, not repeated or upgraded into global completeness.',
        'Raw binary payloads were not broadly rehashed or deserialized. Metadata hashes, closed-manifest digests, current sizes, exact root bindings and independent audit status were checked; selected payload bytes are hash-checked by lookup.',
        'Physical signature hashes only the nine named input tables. Exact kwargs are mandatory; it is not a complete numerical-state fingerprint for init=results or arbitrary solver settings. Only saved bfsw / bfsw+init=dc keys are eligible.',
        'Fresh128 has 55 entered worlds and 73 unentered seeds. A STARTED controller step without PF_attempt is not an attempted physical query; no missing PF is invented.',
        'No actor history, mathematical proof, trained state, controller success or new-PF authorization is inferred from a paid physical-query registry.',
        'The original seed0 primary has an unclosed PF_attempt event; its preserved exact returned root was subsequently independently audited. Both facts are retained.',
    ])
    counts = Counter(v['status'] for v in registry.values())
    result = dict(status='FROZEN_SCOPED_PAID_REGISTRY_WITH_EXPLICIT_KEY_LOCAL_BLOCK',
                  exact500_roots=len(roots), exact_initializer_keys=len(registry),
                  physical_signature_deny_count=len(denied), status_counts=dict(counts),
                  old_index_keys=8679, matchedNUM_new_keys=1071, fresh128_new_keys=1179,
                  additional_closed_sources_included=[UP, FIT, AFF, N15],
                  signature_only_unresolved_count=len(unresolved_signatures),
                  original_seed0_unclosed_primary_attempts_preserved=1,
                  original_seed0_independent_recovery=True,
                  fresh128_entered_worlds=len(read(FRESH + '/Result.json')['worlds']),
                  fresh128_unentered_seeds=read(FRESH + '/Result.json')['unentered_seeds'],
                  gaps=GAPS, limitations=WARNINGS,
                  all500_initial_roots_ready_for_exact_reuse=True,
                  universal_history_complete=False, new_PF_authorized=False,
                  current_build_science_calls=0, binary_deserializations=0,
                  metadata_invariants_checked=len(CHECKS), source_groups=sources,
                  old_scanned_scope_names=old['prior_scope_names'], zero_PF_exclusions=exclusions)
    payload = dict(schema_version=1, namespace='native_upgrade_support_engine_20261020.signature',
                   signature_tables=['bus','line','trafo','sgen','gen','load','ext_grid','shunt','switch'],
                   key_encoding='physical_signature + | + json.dumps(kwargs, sort_keys=True)',
                   policy='Exact returned independently audited key -> verify bytes and reuse; any known physical signature without eligible exact key -> block; unknown signature -> scoped miss, never automatic PF.',
                   entries=registry, signature_deny_provenance=denied)
    outfiles = {'Paid_Physical_Registry.json': payload, 'Exact_All500_Roots.json': dict(roots=roots),
                'Source_Bindings.json': BINDINGS, 'Canonical_Namespace_Aliases.json': aliases,
                'Result.json': result,
                'Journal_Attempt_Coverage.json': {k: dict(binding=v['binding'],
                    PF_kind_counts=v['PF_kind_counts'], attempts=len(v['attempts']),
                    unclosed_attempt_event_ids=[a['event'].get('index', a['event'].get('number', a['event'].get('context')))
                        for a in v['attempts'] if str(a['event'].get('index', a['event'].get('number', a['event'].get('context')))) not in v['terminal']])
                    for k, v in JOURNALS.items()}}
    for name, obj in outfiles.items():
        (O / name).write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    frozen = {name: dict(sha256=sha(O / name), bytes=(O / name).stat().st_size) for name in outfiles}
    frozen['builder_source'] = dict(path='work/nonlinear500_paid_registry_20261029.py', sha256=sha(Path(__file__)))
    (O / 'Frozen_Registry_Manifest.json').write_text(json.dumps(frozen, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['status','exact500_roots','exact_initializer_keys','physical_signature_deny_count','status_counts','metadata_invariants_checked']}))


def lookup(args):
    frozen = json.loads((O / 'Frozen_Registry_Manifest.json').read_text())
    name = 'Exact_All500_Roots.json' if args.root is not None else 'Paid_Physical_Registry.json'
    check(sha(O / name) == frozen[name]['sha256'], 'frozen_registry_digest')
    data = json.loads((O / name).read_text())
    if args.root is not None:
        row = data['roots'][args.root]
        check(row['seed'] == args.root, 'root_identity')
        check(sha(relpath(row['path'])) == row['sha256'], 'selected_exact_root_payload')
        return dict(status='VERIFIED_EXACT_SAVED_ROOT', root=row, new_PF_permitted=False)
    kw = json.loads(args.kwargs)
    k = key(args.signature, kw)
    entry = data['entries'].get(k)
    if entry and entry['reuse']:
        for what in ('after', 'fields'):
            d = entry['reuse'][what]
            check(sha(relpath(d['path'])) == d['sha256'], 'selected_payload:' + what)
        cert = entry['reuse']['independent_certificate']
        bindings = json.loads((O / 'Source_Bindings.json').read_text())
        check(sha(relpath(cert)) == bindings[cert]['sha256'], 'selected_independent_certificate')
        return dict(status='VERIFIED_EXACT_PAID_REUSE', key=k, reuse=entry['reuse'], new_PF_permitted=False)
    if args.signature in data['signature_deny_provenance']:
        return dict(status='BLOCKED_PREVIOUSLY_ATTEMPTED_NO_ELIGIBLE_EXACT_KEY', key=k, entry=entry,
                    new_PF_permitted=False)
    return dict(status='MISS_IN_FINITE_SCOPED_REGISTRY', key=k,
                meaning='No absence beyond listed scopes is established; prospective authorization and input controls still required.',
                new_PF_permitted=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=int, choices=range(500))
    parser.add_argument('--signature')
    parser.add_argument('--kwargs', default='{"algorithm":"bfsw","init":"dc"}')
    args = parser.parse_args()
    if args.root is not None or args.signature:
        print(json.dumps(lookup(args), indent=2))
    else:
        build()
