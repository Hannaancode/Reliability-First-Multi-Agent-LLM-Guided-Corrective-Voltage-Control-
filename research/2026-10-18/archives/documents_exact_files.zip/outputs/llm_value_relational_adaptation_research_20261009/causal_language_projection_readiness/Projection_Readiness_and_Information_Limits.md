One fixed causal V/reactive-constraint projection was declared before tokenization. It preserves its selected numerical fields exactly through dictionary and sparse-zero encoding, without rounding. Current angles, line/load/transformer/impedance/active-power tables and other fields are explicitly outside the language view. It is not full-table losslessness, a proved sufficient statistic, Markov completeness or learned benefit.

The physical numerical prior still uses full current information. A prospective method must supply the identical decoded projection AND numerical prior to strong non-LLM residual controls, and retain stronger full-table/graph/physical controls. Those implementations and performance protocols do not follow from this software test. Generator-regime and other failed studies stay stopped.

{
  "completed_at_utc": "2026-10-10T02:34:31.352212+00:00",
  "actual_OPT_tokenizer_contexts": 239,
  "OPT_worlds": 23,
  "minimum_context_tokens": 4193,
  "maximum_context_tokens": 4517,
  "fits4096_with384reserve": 0,
  "overflow_views_retained": 239,
  "all_selected_fields_exactly_preserved": true,
  "all38501_exact_current_scope_and_Qcap_commands_checked_without_model": true,
  "labelled_fake_reply_rejections": [
    "bool_bus",
    "wrong_Q",
    "extra_field",
    "float_bus",
    "outside_bus"
  ],
  "full_table_information_preserved_in_language_view": false,
  "no_AFTER_receipts_targets_world_branch_IDs_in_forward": true,
  "no_new_performance_or_training_protocol": true,
  "actual_model_PF_optimizer_controller_derivative_linear_solve_cloud_calls": 0,
  "no_weights_loaded_or_genuine_generation": true,
  "actual_workflow_seconds_before_seal": 32.64973390009254,
  "unexecuted_measurement_source_settings_untouched": true
}

If any context overflows, retain it and reject this single representation under4096/384 rather than adjust a prompt until a desired outcome. Fit only permits further justified interface work; it does not authorize a model study or establish novelty, pretraining value, D-SE superiority or confirmation. No candidate AFTER receipts or labels are input. All commands here were software fixtures, not genuine model replies.
