"""Save exact running source/state and verified input/software contributions."""
import json,os,zipfile
from datetime import datetime,timezone
from reflection118_chronological_core_20261022 import R,read,put,sha
P=R/'outputs/reflection118_chronological_preparation_20261022'
O=R/'outputs/reflection118_chronological_handoff_20261022'


def mutable(path,v):
    with path.open('w',encoding='utf-8',newline='') as f:
        f.write(v) if isinstance(v,str) else json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False)
        f.flush();os.fsync(f.fileno())


def main():
    O.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    root=read(R/'outputs/registered_severe_federation_root_binding_20261022/independent_audit/Independent_Audit.json')
    assert root['status'].startswith('PASS_')
    E=R/'outputs/r118chrono_20261022';status=read(E/'status.json');claim=read(E/'owner.claim')
    coord=read(R/'outputs/r118chrono_handoff_20261022/owner.claim')
    plan={'at_utc':at,'status':'ORIGINAL_CHRONOLOGICAL_FOUR_REGISTERED_ROOT_STUDY_STARTED_NO_PERFORMANCE_RESULT_YET',
        'all6_final_goals':'OPEN','source_native_case_order':root['case_order'],'initial_UV':root['initial_UV'],
        'exact_input_registration':'4FED141roots recovered/199other registrations pending; old paid12October solved roots reused, historical137trajectory identity stillUNKNOWN.',
        'actual_primary_claim':claim,'actual_coordinator_claim':coord,'exec_session':55078,
        'host_status_at_checkpoint':{k:status.get(k) for k in ['stage','runtime_allocated','allocation_requests','runtime_released','science_started','updated_at_utc','notebook_hash']},
        'next':'Inspect actual local/controller and remote service statuses from this owner; do not duplicate, restart or modify live sources. Sole locked reader follows actual host end/release/preservation. Full/partial outcomes are assessed by actual independent audit, never counts.',
        'study':'outputs/r118chrono_20261022','sole_reader':'outputs/r118chrono_audit_20261022',
        'sole_handoff':'outputs/r118chrono_handoff_20261022','protocol':(P/'Frozen_Engineering_Protocol.json').relative_to(R).as_posix(),
        'science_bounds':'Localcontroller7200seconds/8GiB; remote9000seconds, setup1800, collector10200; first independent reader7200. All bounds fixed before outcome; no extension/retry.',
        'critical_source_finding':'Actual feedback state is updated after each zone, but original candidate filtering can hide other-zone receipts from later prompts. Preserved; not modified for this study.',
        'external118_comparison':'Authentic compatible external118controllers or separately named trained/common-actuator ports remain pending. Source-native13inverter/322bus actors are not valid unmodified118shunt benchmarks.',
        'remaining_priority_tasks':['G3.F118.6b actual original full25step trained controller and DFF/HGSE bothbranch costs','G3.F118.5 compatible published118methods/common-task ports','G3.F118.7 strong same-information/constant/base controls, full literalDSE, wider cohort and unused confirmation'],
        'no_guaranteed_win_or_new_improvement_result':True,'timers':[]}
    put(O/'Current_Resume.json',plan)
    entry=f'''{at}
Method: independently bound four registered severe FED141 initial NETs to exact recipes, source initial NR kwargs and old captured returns. Initial UV56/58/57/55; strictOV0/1/1/1 retained exactly. No root PF repeated. Current inputs recovered for4/203registrations; historical137trajectory identity remainsUNKNOWN. Native original Reflection-v4 chronological harness retains every function AST, conditional reprompt, causal feedback, failed actions, guided/fallback queries, native450cap/9Q/1.06guard/source score and unchanged final selector. It persists actual controller NET/history/RNG and compares warm/cold first commitment before further scientific calls. Nine labelled software checks passed with0realPF/modelcalls. Test failure assuming unfiltered cross-zone memory preserved and corrected; actual source filters different-zone candidate receipts. This is a source/software finding, not evidence of a learning improvement.
History: reused closed60426component index; built new necessary-load/outage lookup for9297additional old attempts and retained738snapshot load/shunt checks. Matching unresolved/failed old inputs stop before another solve. Read-only nested-dict key failure preserved; additive canonical-key repair0science, successfullookup213.296seconds; failed cost UNKNOWN/notfree. Independent input binding workflows5.038118+4.304800seconds paid. No archive re-audit or old science restart.
Execution: sole new original-account model-service study started, actual host{claim['actual_pid']}/parent{claim['parent_pid']}, coordinator{coord['actual_pid']}/parent{coord['parent_pid']}, exec55078. Host snapshot{status.get('stage')}; allocationrequests{status.get('allocation_requests')}, runtimeallocated{status.get('runtime_allocated')}, science_started{status.get('science_started')}. Planned all4rootsx2originalnativebranches25steps is NOT actual completion. One T4 for unchanged trained0.5BLoRA, CPUphysics, cold complete firstmodeltoken check, immutable weights, fullcost and firstNEWreturned-PF independent replay. No training, model upgrade or superiority result yet. No second GPU solely because idle.
Limits/next: source-native hard1.06 guard is preserved; strict0.95/1.05 outcomes separately reported. Original DFF-ALT/full literalDSE, newcontroller, compatible published118ports and equally informed/constant/base controls still required for complete fair benchmark. No model beats all claim. All6goalsOPEN. Resume outputs/reflection118_chronological_handoff_20261022/Current_Resume.json; no duplicate owners, live edits, old budget extension, retries or quota fallback. Update only from independent closed evidence.
'''
    put(O/'Verified_Input_And_Software_Results.json',{'root_binding':root,'software':read(P/'Labelled_Software_Checks.json'),
        'lookup':read(P/'Additional_Coverage_Readiness.json'),'launch_lock':read(P/'Input_Source_Lock.json')})
    (O/'Research_Progress_Entry.txt').write_text(entry,encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+entry+'\n');f.flush();os.fsync(f.fileno())
    tasks=read(R/'outputs/research_tasks_20261014/Tasks.json')
    g=next(t for t in tasks['tasks'] if t.get('checklist_id')=='G3')
    for sub in [
        {'id':'G3.F118.6b.inputs','completed':True,'description':'Independent exact recipe/source/return binding of4registered severe118paid roots56/58/57/55UV; no newPF,199other registrations unresolved.','evidence':'outputs/registered_severe_federation_root_binding_20261022/independent_audit/Independent_Audit.json'},
        {'id':'G3.F118.6b','completed':False,'description':'Actual four-zone/full25step native original trainedHG-VF andDFF/HG-SE study. Sole owner/reader started; original input/cold/software gates, outcomes pending.','evidence':(O/'Current_Resume.json').relative_to(R).as_posix()}]:
        old=next((s for s in g.get('subtasks',[]) if s.get('id')==sub['id']),None)
        if old:old.update(sub)
        else:g.setdefault('subtasks',[]).append(sub)
    tasks.update(updated_at_utc=at,latest_resume=(O/'Current_Resume.json').relative_to(R).as_posix());mutable(R/'outputs/research_tasks_20261014/Tasks.json',tasks)
    for rel in ['outputs/full_system_comparison_20261021/Current_Resume.json','outputs/federation_matched_benchmark_20261022/Current_Resume.json']:
        path=R/rel;d=read(path);d.update(updated_at_utc=at,current_owner=claim['actual_pid'],chronological_original_resume=(O/'Current_Resume.json').relative_to(R).as_posix(),all6goals='OPEN');mutable(path,d)
    header=f'''## Original full chronological118system study started — {at}

Read outputs/reflection118_chronological_handoff_20261022/Current_Resume.json. Independently recovered4registered severe roots56/58/57/55UV, old initialPF reused;199registrations/historical137rawjoin pending. Actual host{claim['actual_pid']}/parent{claim['parent_pid']}, sole coordinator{coord['actual_pid']}/parent{coord['parent_pid']}, exec55078. No performance result yet. One original-profile T4service plus localCPU original full25step/all4zone HG-VF andDFF, unchanged nativeverifier1.06/Q450/grid/score/selector; strictOV retained. Actual feedback state is updated but original candidate filter can hide other-zone facts; preserved.

Frozen source/protocol/actualownership/firstcommitcold/fullcost/firstNEWPFreader gates apply. Never duplicate/restart/live-edit/extend/retry. Planned8branches are not completion; partial comparisonUNKNOWN. Source-native study does not replace full literalDSE, compatible published118ports/strong controls/widercohort/unusedconfirmation. All6goalsOPEN. No old recurring monitor; estimated one-time check only if truly live result is sole dependency and no useful parallel work remains.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        path=R/rel;mutable(path,header+path.read_text('utf-8'))
    files=['work/reflection118_chronological_core_20261022.py','work/run_reflection118_chronological_local_20261022.py',
        'work/run_reflection118_model_service_remote_20261022.py','work/audit_reflection118_chronological_20261022.py',
        'work/run_reflection118_chronological_colab_20261022.py','work/coordinate_reflection118_chronological_20261022.py',
        'work/freeze_reflection118_chronological_20261022.py','work/check_reflection118_chronological_software_20261022.py',
        'work/bind_registered_severe_federation_roots_20261022.py','work/prepare_reflection118_additional_prior_coverage_v2_20261022.py',
        'work/close_reflection118_input_launch_lock_20261022.py','work/save_reflection118_chronological_handoff_20261022.py',
        'outputs/registered_severe_federation_root_binding_20261022/Result.json',
        'outputs/registered_severe_federation_root_binding_20261022/independent_audit/Independent_Audit.json',
        (P/'Labelled_Software_Checks.json').relative_to(R).as_posix(),(P/'Frozen_Engineering_Protocol.json').relative_to(R).as_posix(),
        (P/'Independent_Reader_Lock.json').relative_to(R).as_posix(),(P/'Additional_Coverage_Readiness.json').relative_to(R).as_posix()]
    pack=O/'Own_Code_And_Proofs.zip'
    with zipfile.ZipFile(pack,'x',zipfile.ZIP_DEFLATED) as z:
        for name in files:z.write(R/name,name)
    with zipfile.ZipFile(pack) as z:assert z.testzip() is None and len(z.namelist())==len(files)
    put(O/'Publication_Pack.json',{'path':pack.relative_to(R).as_posix(),'bytes':pack.stat().st_size,'sha256':sha(pack),
        'members':len(files),'private_NETs_weights_credentials_thirdparty_code_or_trainingbank':False,
        'compact_code_proofs_not_full_private_raw_backup':True})
    print(json.dumps({'saved':True,'resume':(O/'Current_Resume.json').relative_to(R).as_posix(),'publication_bytes':pack.stat().st_size,'all6_final_goals':'OPEN'}))


if __name__=='__main__':main()
