"""Add one source-bound component-attribution section/table; no science or rendering."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
from lxml import etree
from docx import Document

R = Path(__file__).resolve().parents[2]
O = Path(__file__).resolve().parent
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W, 'wp': 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'}

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def put(name, obj):
    with (O / name).open('x', encoding='utf-8') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write('\n')

def ref(p):
    return {'path': Path(p).relative_to(R).as_posix(), 'sha256': sha(p), 'bytes': Path(p).stat().st_size}

def text(e):
    return ''.join(e.xpath('.//w:t/text()', namespaces=NS))

def canon(e):
    return etree.tostring(e, method='c14n')

def el(tag, **attrs):
    return etree.Element('{' + W + '}' + tag, {'{' + W + '}' + k: str(v) for k, v in attrs.items()})

def paragraph(template, value):
    p = el('p')
    props = template.find('w:pPr', NS)
    if props is not None:
        p.append(deepcopy(props))
    r = el('r')
    p.append(r)
    t = el('t')
    t.text = value
    r.append(t)
    return p

source = R / 'outputs/thesis_rag500_lineage_update_20261030/Hannaan_Thesis_RAG500_Lineage_Updated_20261030.docx'
target = O / 'Hannaan_Thesis_Component_Attribution_Updated_20261030.docx'
expected_source_sha = 'e6df14c00cdd3c87f44d29f888b42a1f31b8f0a0f2263a97d9f0214a7fb1c75c'
assert sha(source) == expected_source_sha
evidence_paths = [
    'outputs/parallel_lineage_component_independent_20261030/Compact_Review.json',
    'outputs/original118_component_ledger_20261030/Results.json',
    'outputs/original118_component_ledger_20261030/Cost_Lineage.json',
    'outputs/original118_component_ledger_20261030/Offline_Selector_Ledger.json',
]
evidence = [ref(R / p) for p in evidence_paths]
review = read(R / evidence_paths[0])
ledger = read(R / evidence_paths[1])
costs = read(R / evidence_paths[2])
selector = read(R / evidence_paths[3])
c = review['component_ledger']
assert review['status'] == 'PASS_FIRST_INDEPENDENT_NEW_LINEAGE_COMPONENT_JOINS_AND_NARROW_PROSE_REVIEW'
assert review['thesis']['document']['sha256'] == expected_source_sha
triples = {
    'HGVF/direct_language_proposal_after_source_normalization': [51, 132, 4],
    'HGVF/guided_numerical_refinement': [13, 38, 1],
    'HGVF/deterministic_fallback': [9, 30, 3],
    'DFF/deterministic_fallback': [29, 175, 8],
}
fields = ['commits', 'UV_reduction', 'OV_net_change']
quantitative = {
    'all_four_component_triples_match_ledger_and_independent_review': all(
        [ledger['components'][k][f] for f in fields] == v == [c['components'][k][f] for f in fields]
        for k, v in triples.items()),
    'HG_VF_sum_is_73_200_plus8': [sum(v[i] for k, v in triples.items() if k.startswith('HGVF/')) for i in range(3)] == [73, 200, 8],
    'all102_recorded_commits': ledger['committed_events'] == c['events'] == sum(v[0] for v in triples.values()) == 102,
    'both_OV_endpoints_3_to_11': all(c['endpoints'][b]['initial_OV'] == 3 and c['endpoints'][b]['final_OV'] == 11 for b in ['HGVF', 'DFF']),
    'recorded_UV_endpoint_reductions_match': all(c['endpoints'][b]['initial_UV'] - c['endpoints'][b]['final_UV'] == delta for b, delta in [('HGVF', 200), ('DFF', 175)]),
    'direct_verifier_status_counts': ledger['direct_verifier_status_counts'] == c['direct_verifier_counts'] == {'accepted_committed': 51, 'electrical_rejected': 124, 'accepted_unselected': 17, 'pretest_rejected': 116},
    'selector_three_HG_VF_one_DFF_no_new_commits': c['selector'] == {'branch_counts': {'HGVF': 3, 'DFF': 1}, 'additional_control_events': 0, 'both_branches_paid': True} and len(selector['rows']) == 4 and all(x['new_committed_control_events'] == 0 and x['both_branch_costs_required'] for x in selector['rows']),
    'per_component_costs_explicitly_unknown_and_full_blocks_retained': len(costs['cases']) == 4 and all(x['per_commit_or_component_costs'].startswith('UNKNOWN_NOT_SEPARATELY_MEASURED') and x['full_source_blocks'] and x['DFF_shared_all4_costs'] and x['HGVF_source_costs'] for x in costs['cases']),
    'failed_original_development_gate_retained': c['original_development_gate'] == 'FAIL',
    'native_guard_1p06_distinct_from_strict_OV1p05': any('1.06' in x and '1.05' in x for x in c['limitations']),
}
assert all(quantitative.values()), quantitative

title = '7.24 Execution attribution across the four severe cases'
intro = ('A saved-output ledger now links the 102 recorded commitments across the four severe development roots to their executed origins. Table 7.17 separates the three HG-VF components from the alternative DFF branch. The UV and OV changes are sums of changes between consecutive saved states; they describe the observed trajectories and do not measure a component\'s causal contribution.')
list_title = 'Table 7.17 Recorded component origins and sequential violation changes'
caption = (list_title + '. Net UV reduction is the count before an action minus the count after it; net OV change uses the opposite sign. Positive OV change is adverse. The saved ledger and independent source join are identified in Appendix A.4.')
endpoint = ('The three HG-VF components account for 73 commitments and a net reduction of 200 UV counts. The separate DFF branch accounts for 29 commitments and a net reduction of 175. Both branches began with three strict OV violations and ended with 11. These adverse OV results remain visible: the native hard guard at 1.06 p.u. differs from the reported strict OV threshold of 1.05 p.u. The attribution does not change the original failed development gate.')
rejection = ('Saved direct-verifier records distinguish 51 committed acceptances from 17 accepted but unselected proposals, 124 electrical rejections and 116 pretest rejections. These status counts are not power-flow query counts. Guided and HG-VF fallback per-candidate rejection histories are incomplete in the saved logs. The DFF records retain candidate acceptance and rejection counts, but not each candidate\'s reason or violation changes.')
selection = ('HG-SE selects three HG-VF endpoints and one DFF endpoint after both branches have been computed; selection creates no additional control commitment. The cost ledger retains both branches, shared DFF work and interrupted prefixes, together with the remaining historical cost unknowns. Per-component and per-event costs were not separately measured, and overlapping timing fields are not added as deployment latency.')
limits = ('Same-state ablations without language, refinement, fallback or the verifier are unavailable. This ledger establishes execution attribution. It does not establish marginal causal language-model benefit, equal-resource superiority or performance on unused confirmation cases.')
appendix = ('The component extension is retained in original118_component_ledger_20261030. Results.json records the committed origins and signed violation changes; Cost_Lineage.json retains full source-specific branch and interrupted-prefix cost references without inventing per-component allocations. Offline_Selector_Ledger.json separates endpoint selection from control execution. Compact_Review.json in parallel_lineage_component_independent_20261030 records the first independent source and endpoint accounting. The accompanying source-change record binds these compact proofs by hash. Underlying event rows are retained locally and are not republished here.')
rows = [
    ['Component or alternative branch', 'Commits', 'Net UV reduction', 'Net OV change'],
    ['HG-VF direct proposal after source normalization', '51', '132', '+4'],
    ['HG-VF guided numerical refinement', '13', '38', '+1'],
    ['HG-VF deterministic fallback', '9', '30', '+3'],
    ['HG-VF total', '73', '200', '+8'],
    ['DFF alternative branch', '29', '175', '+8'],
]
with ZipFile(source) as z:
    infos = z.infolist()
    original = {i.filename: z.read(i.filename) for i in infos}
before = etree.fromstring(original['word/document.xml'])
tree = etree.fromstring(original['word/document.xml'])
body = tree.find('w:body', NS)
paras = body.findall('w:p', NS)
original_children = list(body)
original_xml = [canon(x) for x in original_children]
assert text(paras[81]).startswith('Table 7.16 ')
assert text(paras[656]).startswith('The updated practical target is restoration of all 500 cases')
assert text(paras[657]).startswith('Chapter 8 ')
assert text(paras[722]).startswith('The earlier r118_dff_missing_continuation study')
assert text(paras[723]).startswith('A.5 ')

bookmark_name = 'hg_component_table_7_17'
bookmark_id = str(max(int(x) for x in tree.xpath('//w:bookmarkStart/@w:id', namespaces=NS)) + 1)
assert not tree.xpath('//w:bookmarkStart[@w:name="' + bookmark_name + '"]', namespaces=NS)
listing = deepcopy(paras[81])
list_text_nodes = listing.xpath('./w:r/w:t', namespaces=NS)
assert len(list_text_nodes) == 1
list_text_nodes[0].text = list_title
field = listing.find('w:fldSimple', NS)
assert field is not None
field.set('{' + W + '}instr', 'PAGEREF ' + bookmark_name + ' \\h')
field.set('{' + W + '}dirty', 'true')
cap = paragraph(paras[653], caption)
cap.find('w:pPr', NS).append(el('keepNext'))
cap.insert(1, el('bookmarkStart', id=bookmark_id, name=bookmark_name))
cap.append(el('bookmarkEnd', id=bookmark_id))

table = el('tbl')
props = el('tblPr')
props.append(el('tblW', type='dxa', w=8304))
props.append(el('tblLayout', type='fixed'))
table.append(props)
widths = [4304, 1000, 1500, 1500]
grid = el('tblGrid')
for width in widths:
    grid.append(el('gridCol', w=width))
table.append(grid)
for i, values in enumerate(rows):
    row = el('tr')
    rowprops = el('trPr')
    rowprops.append(el('cantSplit'))
    if i == 0:
        rowprops.append(el('tblHeader'))
    row.append(rowprops)
    for j, value in enumerate(values):
        cell = el('tc')
        cellprops = el('tcPr')
        cellprops.append(el('tcW', type='dxa', w=widths[j]))
        cell.append(cellprops)
        p = el('p')
        pp = el('pPr')
        pp.append(el('spacing', after=60, before=60, line=240, lineRule='auto'))
        pp.append(el('jc', val='left' if j == 0 else 'center'))
        p.append(pp)
        run = el('r')
        rp = el('rPr')
        rp.append(el('sz', val=19))
        if i in [0, 4]:
            rp.append(el('b'))
        run.append(rp)
        t = el('t')
        t.text = value
        run.append(t)
        p.append(run)
        cell.append(p)
        row.append(cell)
    table.append(row)

section = [paragraph(paras[651], title), paragraph(paras[652], intro), cap, table,
           paragraph(paras[652], endpoint), paragraph(paras[652], rejection),
           paragraph(paras[652], selection), paragraph(paras[652], limits)]
app = paragraph(paras[722], appendix)
insertions = [(81, [listing]), (656, section), (722, [app])]
patches = [
    {'operation': 'insert_list_of_tables_entry', 'base_paragraph_index': 81, 'exact_anchor': text(paras[81]), 'after': list_title, 'new_PAGEREF_target': bookmark_name},
    {'operation': 'insert_section_and_table', 'base_paragraph_index': 656, 'exact_anchor': text(paras[656]), 'heading': title, 'paragraphs': [intro, caption, endpoint, rejection, selection, limits], 'table_rows': rows},
    {'operation': 'insert_appendix_evidence_paragraph', 'base_paragraph_index': 722, 'exact_anchor': text(paras[722]), 'after': appendix},
]
put('Prepared_Patches.json', {'base_docx': ref(source), 'evidence': evidence, 'patches': patches,
    'authorization': 'Parent explicitly requested one compact T05 component table in a new additive DOCX; no checklist closure or rendering.'})
expected_children = []
after_anchor = {original_children.index(paras[i]): nodes for i, nodes in insertions}
for i, old in enumerate(original_children):
    expected_children.append(original_xml[i])
    nodes = after_anchor.get(i, [])
    tail = old
    for new in nodes:
        tail.addnext(new)
        tail = new
        expected_children.append(canon(new))
raw = etree.tostring(tree, xml_declaration=True, encoding='UTF-8', standalone=True)
with ZipFile(target, 'x') as z:
    for info in infos:
        z.writestr(info, raw if info.filename == 'word/document.xml' else original[info.filename])
with ZipFile(target) as z:
    assert z.testzip() is None
    saved = {n: z.read(n) for n in z.namelist()}
after = etree.fromstring(saved['word/document.xml'])
saved_text = [text(x) for x in after.find('w:body', NS).findall('w:p', NS)]
checks = {
    'saved_body_matches_only_three_declared_insertion_locations': [canon(x) for x in after.find('w:body', NS)] == expected_children,
    'all_original_body_objects_unchanged': all(canon(x) == original_xml[i] for i, x in enumerate(original_children)),
    'only_document_body_part_changed': set(saved) == set(original) and [n for n in original if saved[n] != original[n]] == ['word/document.xml'],
}
new_table_xml = canon(table)
checks['all23_original_tables_retained_exactly_plus_one_authorized_table'] = [canon(x) for x in before.xpath('//w:tbl', namespaces=NS)] == [canon(x) for x in after.xpath('//w:tbl', namespaces=NS) if canon(x) != new_table_xml]
for name, xp in [('drawings', '//w:drawing'), ('sections', '//w:sectPr')]:
    checks[name + '_XML_unchanged'] = [canon(x) for x in before.xpath(xp, namespaces=NS)] == [canon(x) for x in after.xpath(xp, namespaces=NS)]
field_xp = '//w:fldSimple | //w:fldChar | //w:instrText | //w:bookmarkStart | //w:bookmarkEnd'
def is_new_field(e):
    return e.get('{' + W + '}id') == bookmark_id or bookmark_name in e.get('{' + W + '}instr', '')
checks['all57_original_PAGEREF_and_original_bookmark_objects_retained_exactly'] = [canon(x) for x in before.xpath(field_xp, namespaces=NS)] == [canon(x) for x in after.xpath(field_xp, namespaces=NS) if not is_new_field(x)]
bookmark_names = after.xpath('//w:bookmarkStart/@w:name', namespaces=NS)
pagerefs = [x for x in after.xpath('//w:fldSimple/@w:instr | //w:instrText/text()', namespaces=NS) if 'PAGEREF' in x]
checks['all_PAGEREF_targets_exist_and_bookmark_names_unique'] = len(bookmark_names) == len(set(bookmark_names)) and all(x.split()[1] in bookmark_names for x in pagerefs)
before_text = [text(x) for x in before.find('w:body', NS).findall('w:p', NS)]
oldrefs = [x for x in before_text if re.match(r'^\[\d+\]\s', x)]
newrefs = [x for x in saved_text if re.match(r'^\[\d+\]\s', x)]
checks['all71_references_unchanged_and_sequential'] = oldrefs == newrefs and [int(re.match(r'^\[(\d+)\]', x).group(1)) for x in newrefs] == list(range(1, 72))
counts = {'references': len(newrefs), 'tables': len(after.xpath('//w:tbl', namespaces=NS)), 'figures': len(after.xpath('//wp:inline', namespaces=NS)), 'PAGEREF_fields': len(pagerefs), 'sections': len(after.xpath('//w:sectPr', namespaces=NS))}
checks['expected_counts_with_authorized_table_and_list_entry'] = counts == {'references': 71, 'tables': 24, 'figures': 22, 'PAGEREF_fields': 58, 'sections': 3}
prior16 = read(R / 'outputs/thesis_evidence_updates_20261030/Evidence_Update_Record.json')['patches']
prior7 = read(R / 'outputs/thesis_rag500_lineage_update_20261030/Prepared_Patches.json')['patches']
checks['all_prior16_amendments_retained'] = len(prior16) == 16 and all((x['exact_before'] not in saved_text) if x['operation'] == 'delete_paragraph' else x['after'] in saved_text for x in prior16)
checks['all_seven_prior_RAG500_patches_retained'] = len(prior7) == 7 and all(x['after'] in saved_text for x in prior7)
checks['all_six_research_questions_retained'] = all(any(x.startswith('RQ' + str(i) + ':') for x in saved_text) for i in range(1, 7))
checks['saved_DOCX_opens_with_expected_new_table'] = len(Document(target).tables) == 24
checks['source_DOCX_unchanged'] = sha(source) == expected_source_sha
checks['all_evidence_bytes_unchanged_during_build'] = all(sha(R / x['path']) == x['sha256'] for x in evidence)
checks['new_table_width_fits_body_text_width_and_rows_cannot_split'] = sum(widths) == 8304 <= 11906 - 2160 - 1440 and len(table.xpath('./w:tr/w:trPr/w:cantSplit', namespaces=NS)) == 6
checks['new_prose_preserves_unknown_cost_causal_and_failed_gate_limits'] = all(v in ' '.join([endpoint, selection, limits]) for v in ['failed development gate', 'cost unknowns', 'not separately measured', 'Same-state ablations', 'does not establish marginal causal'])
assert all(checks.values()), checks
record = {
    'status': 'ADDITIVE_COMPONENT_EXECUTION_ATTRIBUTION_DOCX_COMPLETE', 'at_utc': datetime.now(timezone.utc).isoformat(),
    'base_docx': ref(source), 'updated_docx': ref(target), 'evidence': evidence, 'patches': patches,
    'chaptered_change_summary': {'front_matter': 'One Table7.17 list entry with a real caption bookmark and new PAGEREF; no invented page number.', 'Chapter7': 'New Section7.24 and five-data-row component/alternative table, adverse endpoints, rejection distinctions, offline-selection accounting and causal/cost limits.', 'AppendixA4': 'Exact compact source-ledger and independent-review locations.'},
    'counts': counts, 'prior16_and_prior7_changes_retained': True, 'all_original_body_content_and_other_ZIP_parts_retained': True,
    'T05_closed': False, 'other_task_closures_created': 0, 'master_tasks_resume_or_current_pointer_changed': False,
    'new_model_retrieval_training_PF_optimizer_calls': 0, 'raw_event_rows_added': False,
    'render_PDF_screen_or_UI_performed': False, 'page_references_recalculated': False,
}
put('Source_Change_Record.json', record)
put('Self_Review.json', {'status': 'PASS_POSTWRITE_SELF_REVIEW_CONTENT_AND_STRUCTURE_ONLY',
    'reviewer_role': 'Document author self-review, not independent review of this new DOCX.', 'updated_docx': ref(target),
    'checks': checks, 'quantitative_evidence_checks': quantitative, 'counts': counts,
    'no_visual_QA_claim': True, 'layout_and_cached_page_numbers': 'NOT_RENDERED_OR_RECALCULATED_BY_USER_INSTRUCTION',
    'scope': 'Recorded execution origins and sequential count changes only. No marginal causal LLM gain, complete component cost allocation, equal-resource superiority, whole-band restoration or task closure.'})
(O / 'Update_Note.txt').write_text('\n'.join([
    'ADDITIVE COMPONENT EXECUTION ATTRIBUTION UPDATE', '',
    'Built from and preserved the independently prose-reviewed RAG500 DOCX; all previous16 amendments and7 RAG500 changes remain.',
    'New Section7.24/Table7.17: HG-VF direct51/132/+4; guided13/38/+1; fallback9/30/+3; HG-VF total73/200/+8; separate DFF29/175/+8 (commitments/net UV reduction/net OV change). Both branches start with3 strict OV violations and end with11.',
    'Recorded verifier acceptance/rejection statuses remain distinct from commitments and paid power-flow queries. HG-SE selected3 HG-VF and1 DFF endpoint after both branches were paid; it creates0 control commitments.',
    'Full available branch/shared/interrupted-prefix cost references remain retained. Per-component costs and same-state counterfactuals are unknown; no marginal causal language-model gain, equal-cost superiority or checklist closure is asserted.',
    'One authorized table and List-of-Tables PAGEREF added:71 references,24 tables,22 figures,58 PAGEREF fields,3 sections. All23 original tables, all original fields/bookmarks, and every prior paragraph remain unchanged.',
    'Content/OOXML author self-review only; no rendering, PDF, screen/UI or page-number recalculation. Parent owns independent review and canonical current-DOCX/resume pointer.', ''
]), encoding='utf-8')
put('Closed_Manifest.json', {'scope': 'New additive component-attribution DOCX, exact source change and self-review only', 'files': [ref(p) for p in sorted(O.iterdir()) if p.is_file()]})
print(json.dumps({'status': record['status'], 'updated_docx': ref(target), 'structural_checks': len(checks), 'quantitative_checks': len(quantitative), 'counts': counts, 'T05_closed': False}))
