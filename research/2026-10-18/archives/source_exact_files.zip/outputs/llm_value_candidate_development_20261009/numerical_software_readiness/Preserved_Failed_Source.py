"""Explicit random-weight/software readiness; zero optimizer, LLM or PF calls."""
import candidate_process_runtime
import copy,json,time
from pathlib import Path
import torch
from candidate_process_numerical_predictor import TableGraphProcessControl,process_objective
from candidate_predictor_input_contract import InputContractError,model_input
from candidate_process_evidence_utils import read,sha,write
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
CACHE=BASE/'tensor_readiness_v2';OUT=BASE/'numerical_software_readiness'
assert not OUT.exists();OUT.mkdir();torch.set_num_threads(2);torch.manual_seed(20261009)
assert read(CACHE/'summary.json')['training_steps']==0
normal=read(BASE/'input_and_target_contract_nullable_v2/Input_Normalization.json')
index=read(CACHE/'Input_Index.json');tindex=read(CACHE/'Target_Index.json');ident=tindex[0]['observation_id']
x=torch.load(CACHE/'inputs'/f'{ident}.pt',weights_only=True);target=torch.load(CACHE/'targets'/f'{ident}.pt',weights_only=True)
model=TableGraphProcessControl(len(normal['typed_semantic_schema']));model.eval();checks={}
begin=time.perf_counter();prediction=model(x);forward_seconds=time.perf_counter()-begin
assert prediction.shape==(118,9,7);checks['actual_input_random_forward_shape_finite']=True
assert abs(model.actual_parameters-8798208)<8798208*.001;checks['capacity_fixed_before_outcomes']=True
alltext=model.text(x['value_bytes'],torch.device('cpu'));present=[i for i,s in enumerate(x['value_bytes']) if s]
sparse=torch.zeros_like(alltext)
if present:sparse=sparse.index_copy(0,torch.tensor(present),model.text([x['value_bytes'][i] for i in present],torch.device('cpu')))
assert torch.equal(alltext,sparse);checks['empty_sequence_skip_exact_original_ByteEncoder_equivalence']=True
loss,parts=process_objective(prediction,target);assert bool(torch.isfinite(loss))
altered=copy.deepcopy(target);altered['regression'][~target['regression_mask']]=99999.
altered['classification'][~target['classification_mask']]=99999.
other,_=process_objective(prediction,altered);assert torch.equal(loss,other)
checks['unknown_target_padding_does_not_affect_loss']=True
begin=time.perf_counter();loss.backward();backward_seconds=time.perf_counter()-begin
assert all(p.grad is not None and bool(torch.isfinite(p.grad).all()) for p in model.parameters())
checks['real_random_graph_all_gradient_paths_finite']=True
assert set(x)=={'field_ids','kind','numeric','coordinates','value_bytes','node_features','adjacency','zone_ids','allowed_actions'}
checks['forward_no_world_branch_or_outcome_keys']=True
probe=dict(x);probe['after_metrics']={}
try:model(probe)
except AssertionError:checks['future_label_injection_rejected']=True
else:raise AssertionError('Future field accepted')
torch.save(model.state_dict(),OUT/'Random_Fixture_Checkpoint.pt');again=TableGraphProcessControl(len(normal['typed_semantic_schema']))
again.load_state_dict(torch.load(OUT/'Random_Fixture_Checkpoint.pt',weights_only=True));again.eval()
with torch.no_grad():replay=again(x)
assert torch.equal(prediction.detach(),replay);checks['random_checkpoint_reload_exact_scores']=True
observed=x['allowed_actions'];assert not bool((target['classification_mask'].any(-1)&~observed).any())
assert not bool((target['regression_mask'].any(-1)&~observed).any());checks['known_cap_rejections_not_learned']=True
checks['missing_after_not_fabricated_as_negative_UVzero']=True
certificate={'explicit_random_software_checks':checks,'all_passed':all(checks.values()),
 'actual_random_numerical_forwards':2,'rejected_extra_field_before_forward':1,'actual_random_backward_calls':1,
 'optimizer_steps':0,'pretrained_calls':0,'PF_calls':0,'controller_calls':0,'cloud_calls':0,
 'random_forward_seconds':forward_seconds,'random_backward_seconds':backward_seconds,
 'model_parameters':model.actual_parameters,'capacity_width':model.capacity_width,'input_typed_records':len(x['field_ids']),
 'node_channels':13,'cache_manifest_sha256':sha(CACHE/'manifest.json'),
 'source_sha256':sha(Path(__file__)),'no_performance_or_training_evidence':True}
write(OUT/'Readiness.json',certificate)
write(OUT/'manifest.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()})
print(json.dumps(certificate,indent=2))
