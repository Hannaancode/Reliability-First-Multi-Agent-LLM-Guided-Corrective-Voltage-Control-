"""Save completed safe parallel gates, human priority order and one-time wait."""
import re,zipfile
from datetime import datetime,timezone
from r118_dff_partition_core_20261023 import *
from finalize_r118_dff_prelaunch_and_task_snapshot_20261023 import replace_json
from prepare_github_research_snapshot_20261018 import SECRET
O=R/'outputs/native118_parallel_gates_and_wait_20261023'

def main():
    O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    proofpaths=['outputs/reflection118_remaining_cases_preparation_20261023/closed_registry_independent/Independent_Audit.json','outputs/provider_observer_pause_20261023/Results.json','outputs/exact_frame_byte_precheck_20261023/Results.json','outputs/original118_matched_analysis_preparation_20261023/Protocol.json']
    proofs=[read(R/n) for n in proofpaths]
    assert proofs[0]['rows_checked']==3517 and proofs[0]['status'].startswith('PASS_')
    assert proofs[1]['paid_physics_calls_reused']==41 and proofs[1]['paid_model_responses_reused']==7 and proofs[1]['source_checkpoint_NET_feedback_failure_history_result_RNG_exact']
    assert len(proofs[2]['all_negatives'])==6 and all(x['rejected'] for x in proofs[2]['all_negatives'])
    order=['G3','G1','G2','G4','G5','G6']
    source=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(source)
    for t in tasks['tasks']:
        prior=t['priority'];t['priority']=order.index(t['checklist_id'])+1
        if prior!=t['priority']:t['priority_before_20261023_correction']=prior
        if t['checklist_id']=='G1':
            t['status']='MATCHED_ALL4_NATIVE_BASELINE_RUNNING_FULL_ROSTER_ZERO_UNKNOWN'
            t['current_result']='Two old observed zero-UV development paths retained with their provenance/closure limits. Entire severe roster not independently zero certified. Current original4root comparison uses56/58/57/55initialUV; all4baseline/nativeLLM/fullDSE contrasts pending.'
        if t['checklist_id']=='G2':
            t['status']='PUBLIC_NATIVE_BASELINES_COMPLETE_FULL_OUR_MODEL_ROLE_AND_FAIR_MATCH_OPEN'
            t['current_result']='Public13 three author policies500cases each complete; our numerical264normal-band cases versusDDPG363, failed gate retained. Public322one engineering point numerical108to0vsTPA108to77,notourLLM or aggregate superiority. Faithful paper-model public role and full matched evaluation remain open.'
        if t['checklist_id']=='G5':
            t['status']='CAUSAL_LLM_CONTRIBUTION_UNPROVEN_MATCHED_OUTCOMES_PENDING'
            t['current_result']='One original-trained native118case56to7UV/2strictOV audited; no completedall4matchedliteralDSE/external/unusedconfirmation proof. Failed scale/encoder/control gates remain stopped.'
        if t['checklist_id']=='G3':
            new=[dict(id='G3.native_partial612_20261023',completed=True,description='Independently preserve612new DFF physical returns and three source commitments; full case/cohort remainsUNKNOWN.',evidence='outputs/r118_dff_missing_continuation_independent_20261023/Independent_Audit.json'),dict(id='G3.exact_partition_identity_20261023',completed=True,description='Prove exact native ppci/options/kwargs identity for125+25versus150 and source result mapping with0new nonlinear solves; retain all preparation/reader failures and costs.',evidence='outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023/Independent_Audit.json'),dict(id='G3.closed_registry3517_20261023',completed=True,description='Complete old closed3517input registry and independent rational-key audit. Current live study still needs missing-only extension after closure; no autoallocation.',evidence=proofpaths[0]),dict(id='G3.provider_observer_gate_20261023',completed=True,description='Future observer binding reproduces exact original first commitment/feedback/failure/RNG using41paid physics/7paid model replies,0newscience; current live source unchanged.',evidence=proofpaths[1])]
            existing={s['id'] for s in t.get('subtasks',[])};t.setdefault('subtasks',[]).extend(x for x in new if x['id'] not in existing)
    tasks['tasks'].sort(key=lambda t:t['priority']);tasks['priority_order']=order;tasks['updated_at_utc']=now;tasks['current_waiting_automations']=['hiergrid-exact-input-118-result-check'];tasks['latest_verified_GitHub']='48e2815b2ca69b84e5066e7e192d3f4032e5d6d4'
    replace_json(source,tasks)
    resume_path=R/'outputs/r118_native_comparison_continuation_20261023/Current_Resume.json';resume=read(resume_path)
    resume.update(at_utc=now,priority_order=order,current_timers=['hiergrid-exact-input-118-result-check'],next_estimated_check='2026-10-23 13:30 Asia/Qatar; one-time, rearm only if exact actors remain live and no useful parallel task is ready; delete at actual terminal.',completed_safe_parallel_gates=proofpaths,
        next_stage_conditions='Do not run old --stage freeze or allocate GPUs now. After NEW partition scientist/reader/coordinator end, extend old3517index with this study actual/derived/failed/unclosed records and identity proofs. Integrate exact-input reuse and optional verified provider observation/positive byte precheck in separately frozen three-case owners, bind exact sources/output names BEFORE their first model call, and only then use three fixed own profiles. No current live source may be edited.',
        latest_verified_GitHub='48e2815b2ca69b84e5066e7e192d3f4032e5d6d4',latest_publication_receipt='outputs/native118_partition_identity_publication_20261023/Verified_GitHub_Receipt.json')
    replace_json(resume_path,resume);(O/'Current_Resume.json').write_bytes(resume_path.read_bytes())
    progress=[]
    for t in tasks['tasks']:
        main=[s for s in t.get('subtasks',[]) if re.fullmatch(r'G\d+\.\d+',s['id'])];n=sum(bool(s.get('completed')) for s in main)
        progress.append(dict(id=t['checklist_id'],priority=t['priority'],task=t['target'],completed_main_milestones=n,total_main_milestones=len(main),milestone_percent=round(100*n/len(main),1),final_goal_completed=False))
    put(O/'Task_Progress.json',dict(at_utc=now,basis='Existing equal-weight main checklist milestones only; final large trajectory/confirmation steps remain. Not cases solved, effort percent or winning confidence.',tasks=progress,all6_final_goals='OPEN'))
    put(O/'Safe_Parallel_Gates_And_Wait.json',dict(at_utc=now,completed_proofs={n:sha(R/n) for n in proofpaths},one_time_timer='hiergrid-exact-input-118-result-check',estimated_time='13:30Asia/Qatar23October2026',new_scientific_calls_in_parallel_gates=0,current_GPU_assignments=0,existing_3517_scope_does_not_include_live_new_partition_study=True,current_live_source_unchanged=True))
    header=f"## All ready parallel gates saved; one result check13:30Qatar — {now}\n\nRead outputs/r118_native_comparison_continuation_20261023/Current_Resume.json. Sole actual NEW partition scientist16988/parent15484/coordinator7284/parent25296 continue unchanged,exec8361; pinned reader follows actual end. One-time timer hiergrid-exact-input-118-result-check at13:30Qatar23Oct; rearm only while exact actors live/soledependency, delete at terminal,no recurringmonitor. Closed old3517registry independentPASS; actual original observer gate41paidPF/7paidmodel/fullstatePASS;12byte-pairs/6mutationsPASS; all4descriptive analysis locked before remaining3model outputs. These are completed software/saved-data gates,0newscience; do not rerun. New study still must finish; old3517index must be extended with NEW actual/derived/failed/unclosed receipts before separate3GPUoriginalcase gates/allocation. No currentGPU. PriorityG3benchmark,G1zeroUV,G2publicdata,G4scale,G5LLMcontribution,G6security. All6finalgoalsOPEN; no old restart/retune/liveedit/repeatedphysics. LatestverifiedGitHub48e2815b2ca69b84e5066e7e192d3f4032e5d6d4/all5bytesPASS.\n\n"
    for path in [R/'outputs/Unattended_Execution_Runbook.md',R/'outputs/llm_value_development/Next_Phase_Plan.md']:
        path.write_text(header+path.read_text(encoding='utf-8-sig'),encoding='utf-8')
    checklist=R/'RESEARCH_TASKS.md';intro='Current priority order: G3 fair benchmarks; G1 zero UV; G2 published datasets; G4 larger SLMs; G5 incremental LLM contribution; G6 security. All six final goals remain OPEN. Latest exact state: outputs/r118_native_comparison_continuation_20261023/Current_Resume.json. One-time result check13:30Qatar23October; current scientist and pinned reader continue under their fixed bounds. Main milestone percentages are25/75/50/67/0/0 in that priority order; these are not the share of cases solved or winning confidence.\n\n';checklist.write_text(intro+checklist.read_text(encoding='utf-8-sig'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write(f"\n[{now}] Safe parallel work COMPLETE: old closed3517input index+independent rational-key pass; future provider-observer pause preserves exact original source first commitment/feedback/failures/RNG with41paidPF+7paid replies/0newscience, and restores observation on exceptions; fixed12byte-equality pairs/6mutation negativesPASS. These are workflow checks, not control/deployment speed or LLM superiority. All4 native matched metrics/cost/2wins0loss+noextraOV development gate locked before remaining3model outputs; no statistical significance/unusedconfirmation claim from four inspected roots. Current NEW DFF study/source unchanged and running, noGPUsallocated. One-time result check13:30Qatar23October2026 (hiergrid-exact-input-118-result-check), rearmiftrulylive/soledependency, deleteatterminal. No other ready physical/model owner may overlap. All6goalsOPEN. LatestGitHub48e2815b2ca69b84e5066e7e192d3f4032e5d6d4/all5exactbytesPASS.\n")
    methods=['exact_frame_byte_precheck_20261023.py','check_exact_frame_byte_precheck_20261023.py','provider_observer_pause_20261023.py','check_provider_observer_pause_20261023.py','freeze_original118_matched_analysis_20261023.py','save_parallel_gates_and_wait_20261023.py']
    files={'own_source/'+n:R/'work'/n for n in methods};files.update({'proofs/'+Path(n).parent.name+'/'+Path(n).name:R/n for n in proofpaths})
    manifest=[];raws={}
    for name,path in files.items():
        text=path.read_text('utf-8');assert not any(p.search(text) for p in SECRET)
        raw=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','OWN_PROFILE_EMAIL_REDACTED',text).encode('utf-8');raws[name]=raw;manifest.append(dict(name=name,local=path.relative_to(R).as_posix(),local_sha256=sha(path),public_sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
    raws['Public_Source_Manifest.json']=json.dumps(manifest,indent=2).encode()
    archive=O/'Safe_Parallel_Gates_And_Analysis_Source.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for name,raw in raws.items():z.writestr(name,raw)
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None and all(z.read(n)==v for n,v in raws.items())
    put(O/'Artifact_Index.json',dict(at_utc=now,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),members=len(raws),CRC_and_all_member_bytes_checked=True,files=manifest,raw_physical_NETs_and_private_models_local_only=True))
    print(json.dumps(dict(saved=O.relative_to(R).as_posix(),zip_bytes=archive.stat().st_size,files=[dict(name=f.name,bytes=f.stat().st_size,sha256=sha(f)) for f in O.iterdir() if f.is_file()])))

if __name__=='__main__':main()
