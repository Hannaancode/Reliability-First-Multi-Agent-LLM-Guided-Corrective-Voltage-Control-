"""Operation-aware two-step paid search; no physics, model or commit on import.

The caller supplies actual completed native-verifier receipts and causal menus.
This GLOBAL numerical planner is not an original LOCAL language agent.
"""
from dataclasses import dataclass
import math

class MissingEvidence(Exception):pass

@dataclass(frozen=True)
class Receipt:
    parent:str
    action:str
    verifier_returned:bool
    accepted:bool|None
    operations:int
    successor:str|None
    metrics:dict|None
    native_score:tuple|None
    physical_feasibility_unknown:bool=False

def metrics_value(m):
    if not isinstance(m,dict):raise MissingEvidence('No observed metrics')
    for key in ['uv_count','deficit_sum','vmin','vmax']:
        if key not in m or isinstance(m[key],bool) or not isinstance(m[key],(int,float)) or not math.isfinite(m[key]):
            raise MissingEvidence('Missing/nonfinite observed metric')
    if type(m['uv_count']) is not int or m['uv_count']<0 or m['deficit_sum']<0 or m['vmin']<=0 or m['vmin']>m['vmax']:
        raise MissingEvidence('Invalid observed metric')
    return (-m['uv_count'],-m['deficit_sum'],m['vmin'])

def checked_query(parent,aid,slots,query):
    r=query(parent,aid)
    if not isinstance(r,Receipt) or r.parent!=parent or r.action!=aid:raise MissingEvidence('Receipt identity mismatch')
    if not r.verifier_returned or type(r.accepted) is not bool:raise MissingEvidence('Incomplete native verification')
    if type(r.operations) is not int or r.operations not in (1,2) or r.operations>slots:raise MissingEvidence('Invalid operation debit')
    if r.accepted:
        if r.physical_feasibility_unknown:raise MissingEvidence('Unknown physical outcome cannot be accepted')
        if not isinstance(r.successor,str) or not r.successor:raise MissingEvidence('No measured paid successor')
        metrics_value(r.metrics)
        if r.metrics['vmax']>1.05+1e-8:raise MissingEvidence('Upper-band violation')
        if not isinstance(r.native_score,tuple) or len(r.native_score)!=5 or any(not math.isfinite(float(v)) for v in r.native_score):
            raise MissingEvidence('No original native score')
    return r

def plan(root,root_metrics,remaining_operations,root_menu,second_menu,query,*,mode):
    """Fixed breadth4x4 versus immediate-first1x16, equal follow-up allowance16.

    First menus are identical and complete declared menus. The caller charges
    every receipt, including cached and failed queries. A returned native reject
    after recorded PF failure is an operational rejection with feasibility
    UNKNOWN, never a negative learning label or impossibility proof. A missing
    verifier return aborts. STOP after a safe first move is always a valid leaf.
    """
    metrics_value(root_metrics)
    if type(remaining_operations) is not int or not 0<=remaining_operations<=25:raise ValueError('Remaining original operation bound')
    if mode not in ('breadth4_followup4','immediate1_followup16'):raise ValueError('Fixed method required')
    limit=min(4,remaining_operations)
    if not limit or not root_metrics['uv_count']:
        return {'status':'legal_terminal','selected':None,'root_queries':0,'second_queries':0,'operations_limit':limit}
    ids=tuple(root_menu(root,limit))
    if len(set(ids))!=len(ids):raise MissingEvidence('Duplicate first menu')
    receipts=[checked_query(root,aid,limit,query) for aid in ids]
    accepted=[r for r in receipts if r.accepted]
    if not accepted:
        return {'status':'complete_declared_menu_no_safe_first','selected':None,'root_queries':len(ids),'second_queries':0,
                'operations_limit':limit,'physical_failure_rejections':sum(r.physical_feasibility_unknown for r in receipts)}
    # Stable ties retain native menu order. No after-label ranking enters menus.
    first=sorted(accepted,key=lambda r:r.native_score,reverse=True)
    width,perchild=(4,4) if mode=='breadth4_followup4' else (1,16)
    leaves=[];second_queries=0;unknown_rejects=sum(r.physical_feasibility_unknown for r in receipts)
    for r in first[:width]:
        leaf={'first':r.action,'second':None,'first_successor':r.successor,'endpoint':r.successor,
              'measured_leaf':r.metrics,'operations':r.operations}
        remaining=limit-r.operations
        if remaining and r.metrics['uv_count']:
            menu=tuple(second_menu(r.successor,remaining,perchild))
            if len(menu)>perchild or len(set(menu))!=len(menu):raise MissingEvidence('Invalid bounded second menu')
            received=[checked_query(r.successor,aid,remaining,query) for aid in menu]
            second_queries+=len(menu);unknown_rejects+=sum(s.physical_feasibility_unknown for s in received)
            for s in received:
                if s.accepted:
                    candidate={**leaf,'second':s.action,'endpoint':s.successor,'measured_leaf':s.metrics,'operations':r.operations+s.operations}
                    assert candidate['operations']<=limit
                    if metrics_value(candidate['measured_leaf'])+(-candidate['operations'],)>metrics_value(leaf['measured_leaf'])+(-leaf['operations'],):leaf=candidate
        leaves.append(leaf)
    assert second_queries<=16
    selected=max(leaves,key=lambda x:metrics_value(x['measured_leaf'])+(-x['operations'],))
    return {'status':'complete_declared_bounded_horizon','selected':selected,'leaves':leaves,
            'root_queries':len(ids),'second_queries':second_queries,'followup_query_allowance':16,
            'operations_limit':limit,'physical_failure_rejections':unknown_rejects,
            'not_an_actual_commit_or_LLM_or_whole_policy':True}
