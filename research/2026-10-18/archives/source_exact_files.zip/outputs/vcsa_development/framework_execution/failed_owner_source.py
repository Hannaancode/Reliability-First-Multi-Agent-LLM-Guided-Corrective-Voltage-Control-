"""One owned isolated-profile T4 integration run; incremental exact artifacts.

No fallback, replacement runtime, repeated scientific worker or inference due
to transfer failure. New payload-specific approval review applies at launch.
"""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import quote
import ast, base64, concurrent.futures, hashlib, json, logging, os, sys, time, uuid
import requests
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession, Request
from colab_cli.client import Client, Prod, Variant, Accelerator
from colab_cli.runtime import ColabRuntime
from google_account_profile import verify_account
ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT); logging.disable(logging.CRITICAL)
OUT = ROOT / 'outputs/vcsa_development/framework_execution'
PREP = ROOT / 'outputs/vcsa_development/framework_preparation'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
assert not OUT.exists(), 'Do not start duplicate integration owner'
OUT.mkdir(); (OUT / 'owner.claim').write_text(str(os.getpid()))
state = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'stage': 'preconditions', 'profile': 'isolated',
         'expected_account': 'sheenahammed@gmail.com', 'runtime_allocated': False, 'runtime_released': False,
         'allocation_requests': 0, 'scientific_campaign_started': False}
def save():
    state['updated_at_utc'] = datetime.now(timezone.utc).isoformat()
    temporary = OUT / 'status.tmp'; temporary.write_text(json.dumps(state, indent=2)); temporary.replace(OUT / 'status.json')
class BoundedSession(AuthorizedSession):
    def request(self, *a, **kw):
        kw.setdefault('timeout', (10, 30)); return super().request(*a, **kw)
session = runtime = client = assignment = endpoint = pool = None
safe_release = True; refreshed = 0
def fresh():
    global assignment, refreshed
    assignment = client._get_assignment(nbh, variant=Variant.GPU, accelerator=Accelerator.T4)
    assert getattr(assignment, 'runtime_proxy_info', None) is not None, 'Same exact assignment unavailable; preserve local partials'
    assert assignment.endpoint == endpoint
    refreshed = time.monotonic()
def content(method, path, payload=None):
    for attempt in range(3):
        if time.monotonic() - refreshed > 120:
            fresh()
        try:
            response = requests.request(method, assignment.runtime_proxy_info.url.rstrip('/') + '/api/contents/' + quote(path.strip('/'), safe='/'),
                params={'authuser': '0', 'colab-runtime-proxy-token': assignment.runtime_proxy_info.token, 'content': '1'},
                json=payload, timeout=(10, 30))
            if response.status_code == 404:
                raise FileNotFoundError('Owned artifact not yet present')
            response.raise_for_status(); return response.json()
        except (requests.exceptions.HTTPError, requests.exceptions.Timeout, requests.exceptions.ConnectionError):
            if attempt == 2: raise
            time.sleep(5); fresh()
def execute(code, timeout):
    ast.parse(code)
    output = runtime.execute_code(code, allow_stdin=False, timeout=timeout)
    assert not any(item.get('output_type') == 'error' for item in output), 'Owned remote stage failed'
    return output
def download(relative):
    item = content('GET', 'content/hiergrid_execution/outputs/' + relative)
    raw = base64.b64decode(item['content']) if item.get('format') == 'base64' else str(item['content']).encode()
    path = OUT / 'staged' / relative; path.parent.mkdir(parents=True, exist_ok=True)
    if path.suffix == '.json': json.loads(raw)
    if path.exists():
        assert path.read_bytes() == raw, 'Preserved artifact changed'; return
    temporary = path.parent / ('.transfer_' + uuid.uuid4().hex)
    temporary.write_bytes(raw); temporary.replace(path)
save()
try:
    payload = read(PREP / 'HF_Cloud_Payload_Manifest.json')
    archive = ROOT / payload['archive']; assert sha(archive) == payload['sha256']
    assert read(ROOT / 'outputs/vcsa_development/module_v2_fixture_checks/summary.json')['passed']
    assert read(ROOT / 'outputs/vcsa_development/training_interface/independent_audit.json')['passed']
    os.environ['HIERGRID_EXPECTED_GOOGLE_ACCOUNT'] = state['expected_account']
    credentials = Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud-hiergrid-sheenah\application_default_credentials.json')
    credentials.refresh(Request()); session = BoundedSession(credentials, refresh_timeout=30)
    assert verify_account(session) == state['expected_account']
    client = Client(Prod(), session)
    assert not client.list_assignments(), 'Selected profile has an existing assignment'
    response = session.get('https://colab.research.google.com/tun/m/ccu-info', params={'authuser':'0'}, headers={'X-Colab-Client-Agent':'colab-cli'})
    response.raise_for_status(); usage = json.loads(response.text.removeprefix(")]}'\n"))
    assert 'T4' in (usage.get('eligibleGpus') or []), 'No account fallback after selected-profile denial'
    nbh = uuid.uuid4(); state.update(stage='allocating_selected_T4', notebook_hash=str(nbh), allocation_requests=1); save()
    assignment = client.assign(nbh, variant=Variant.GPU, accelerator=Accelerator.T4)
    endpoint = assignment.endpoint; refreshed = time.monotonic()
    assert assignment.accelerator == Accelerator.T4
    state.update(runtime_allocated=True, endpoint=endpoint, stage='uploading_exact_reviewed_payload'); save()
    runtime = ColabRuntime(url=assignment.runtime_proxy_info.url, token=assignment.runtime_proxy_info.token, session_name='hiergrid-vcsa-framework')
    execute("print('VCSA_KERNEL_READY')", 60)
    raw = archive.read_bytes(); parts = []
    for index, offset in enumerate(range(0, len(raw), 2*1024*1024)):
        path = 'content/vcsa_smoke.part_' + str(index).zfill(3)
        content('PUT', path, {'name':path.rsplit('/',1)[-1], 'path':path, 'type':'file', 'format':'base64',
                             'content':base64.b64encode(raw[offset:offset+2*1024*1024]).decode(), 'chunk':1})
        parts.append('/'+path); state['parts_uploaded'] = len(parts); save()
    install = f"from pathlib import Path\nimport hashlib,json,zipfile\nraw=b''.join(Path(p).read_bytes() for p in {parts!r})\nassert hashlib.sha256(raw).hexdigest()=={payload['sha256']!r}\nPath('/content/hiergrid_execution_bundle.zip').write_bytes(raw)\nwith zipfile.ZipFile('/content/hiergrid_execution_bundle.zip') as z:\n assert z.testzip() is None\n for name,digest in json.loads(z.read('VCSA_INPUT_MANIFEST.json')).items():\n  assert hashlib.sha256(z.read(name)).hexdigest()==digest\nprint('VCSA_INPUTS_VERIFIED')\n"
    execute(install, 60)
    tree = ast.parse((ROOT / 'work/colab_environment_prepare.py').read_text())
    setup = next(n.value.value for n in ast.walk(tree) if isinstance(n, ast.Assign) and any(isinstance(t,ast.Name) and t.id=='code' for t in n.targets) and isinstance(n.value,ast.Constant))
    setup = setup.replace('uv==0.8.22', 'uv==' + (ROOT / 'work/uv_bootstrap_version.txt').read_text().strip())
    state['stage'] = 'restoring_exact_frozen_environment'; save(); execute(setup, 1800)
    for name in ['remote_frozen_environment.json', 'exact_dependency_check.json', 'environment_setup.log']: download(name)
    assert read(OUT / 'staged/exact_dependency_check.json') == {'checked_count':111, 'differences':{}}
    assert read(OUT / 'staged/remote_frozen_environment.json') == read(ROOT / 'outputs/remote_frozen_environment.json')
    launch = "import os,subprocess\nfrom pathlib import Path\nos.chdir('/content/hiergrid_execution')\nwith open('outputs/vcsa_smoke.log','w') as log:\n p=subprocess.Popen(['env/bin/python','work/run_vcsa_framework_smoke_hf_remote.py'],stdout=log,stderr=subprocess.STDOUT)\n Path('outputs/vcsa_smoke_pid.json').write_text(__import__('json').dumps({'pid':p.pid}))\n result=p.wait()\nPath('outputs/vcsa_smoke_exit.json').write_text(__import__('json').dumps({'exit_code':result}))\nprint('VCSA_SMOKE_EXIT',result)\n"
    safe_release = False; state['stage'] = 'two_real_gradient_step_framework_smoke'; save()
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=1); future = pool.submit(execute, launch, 600)
    seen = set(); began = time.monotonic()
    while time.monotonic() - began < 600:
        try:
            listing = content('GET', 'content/hiergrid_execution/outputs/vcsa_development/framework_smoke')
            for item in listing.get('content', []):
                name = item['name']
                if name in seen or name == 'owner.claim': continue
                download('vcsa_development/framework_smoke/' + name); seen.add(name)
            state['artifacts_preserved'] = len(seen); save()
        except FileNotFoundError: pass
        if future.done():
            future.result(); break
        time.sleep(10)
    assert future.done(), 'Bounded remote smoke deadline reached; preserve actual partials, no restart'
    download('vcsa_smoke_exit.json'); assert read(OUT / 'staged/vcsa_smoke_exit.json')['exit_code'] == 0
    listing = content('GET', 'content/hiergrid_execution/outputs/vcsa_development/framework_smoke')
    for item in listing.get('content', []):
        if item['name'] != 'owner.claim': download('vcsa_development/framework_smoke/' + item['name'])
    download('vcsa_smoke.log')
    staged = OUT / 'staged/vcsa_development/framework_smoke'
    for name, info in read(staged / 'manifest.json').items():
        assert sha(staged / name) == info['sha256'] and (staged / name).stat().st_size == info['bytes']
    assert read(staged / 'summary.json')['passed']
    safe_release = True; state['stage'] = 'all_real_framework_artifacts_preserved'; save()
except Exception as exc:
    state.update(stage='failed_preserve_partials', failure_type=type(exc).__name__)
    response = getattr(exc, 'response', None)
    if response is not None: state['failure_http_status'] = response.status_code
    # Recover exact failed outputs only if the same assignment is accessible.
    if endpoint:
        try:
            download('vcsa_smoke_exit.json')
            exit_data = read(OUT / 'staged/vcsa_smoke_exit.json')
            listing = content('GET', 'content/hiergrid_execution/outputs/vcsa_development/framework_smoke')
            for item in listing.get('content', []):
                if item['name'] != 'owner.claim': download('vcsa_development/framework_smoke/' + item['name'])
            download('vcsa_smoke.log'); safe_release = True
            state['remote_exit_and_failure_artifacts_preserved'] = exit_data
        except Exception as transfer: state['recovery_failure_type'] = type(transfer).__name__
    save(); raise
finally:
    if runtime:
        try: runtime.stop()
        except Exception: pass
    if endpoint and safe_release:
        try:
            client.unassign(endpoint)
            state['runtime_released'] = not any(a.endpoint == endpoint for a in client.list_assignments())
        except Exception as exc: state['release_failure_type'] = type(exc).__name__
    if session: session.close()
    if pool: pool.shutdown(wait=False)
    state['finished_at_utc'] = datetime.now(timezone.utc).isoformat(); save()
