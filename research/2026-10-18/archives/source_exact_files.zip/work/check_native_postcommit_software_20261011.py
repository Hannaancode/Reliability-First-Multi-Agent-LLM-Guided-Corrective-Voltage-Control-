"""One new labelled measured-field fixture suite; actual PF/model calls zero."""
import copy,hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
from native_postcommit_preservation import check_commit,PreservationStop
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/native_postcommit_software_20261011'
assert not OUT.exists(),'No duplicate or overwrite'
OUT.mkdir();start=time.perf_counter()
def write(name,value):
 with (OUT/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2);f.flush();os.fsync(f.fileno())
source=ROOT/'work/native_postcommit_preservation.py'
write('Protocol.json',{'declared_at_utc':datetime.now(timezone.utc).isoformat(),
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'scope':'LABELLED synthetic result fields only; no actual solver or physical trajectory',
 'cases':['valid_return','raw_OV_boundary_difference_retained','continuous_mismatch','UV_membership_boundary_mismatch','upper_protection','cap_exceeded','missing_bus','missing_field','nonfinite','no_strict_progress'],
 'new_model_PF_optimizer_controller_forecast_solver_calls':0})
trial={'0':{'vm_pu':.946,'va_degree':-.3,'p_mw':1.,'q_mvar':.2},'1':{'vm_pu':1.05,'va_degree':0.,'p_mw':-1.,'q_mvar':-.2}}
before={'uv_count':2,'deficit_sum':.04,'vmin':.92}
reports=[]
reports.append({'case':'valid_return','returned':check_commit(trial,copy.deepcopy(trial),before,{'0':25.})})
near=copy.deepcopy(trial);near['1']['vm_pu']=1.05+1e-12
boundary=check_commit(trial,near,before,{'0':25.})
assert boundary['trial_raw_OV_members']==[] and boundary['commit_raw_OV_members']==['1']
reports.append({'case':'raw_OV_boundary_difference_retained','returned':boundary})
def reject(name,expected,actual,old=before,caps=None):
 try:check_commit(expected,actual,old,{'0':25.} if caps is None else caps)
 except PreservationStop as exc:reports.append({'case':name,'rejected':True,'reason':str(exc)})
 else:raise AssertionError('Invalid fixture accepted:'+name)
bad=copy.deepcopy(trial);bad['0']['p_mw']+=1e-5;reject('continuous_mismatch',trial,bad)
a=copy.deepcopy(trial);b=copy.deepcopy(trial);a['0']['vm_pu']=.95-1e-12;b['0']['vm_pu']=.95+1e-12;reject('UV_membership_boundary_mismatch',a,b)
bad=copy.deepcopy(trial);bad['1']['vm_pu']=1.051;reject('upper_protection',bad,bad)
reject('cap_exceeded',trial,copy.deepcopy(trial),caps={'0':450.000001})
bad=copy.deepcopy(trial);del bad['1'];reject('missing_bus',trial,bad)
bad=copy.deepcopy(trial);del bad['0']['q_mvar'];reject('missing_field',trial,bad)
bad=copy.deepcopy(trial);bad['0']['p_mw']=float('nan');reject('nonfinite',trial,bad)
reject('no_strict_progress',trial,copy.deepcopy(trial),old={'uv_count':1,'deficit_sum':.004,'vmin':.946})
assert len(reports)==10
result={'all_passed':True,'labelled_fixtures':reports,'actual_native_loop_or_solver_integration':'NOT TESTED',
 'cold_real_native_continuation_equivalence':'UNTESTED','new_model_PF_optimizer_controller_forecast_solver_calls':0,
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'seconds':time.perf_counter()-start,
 'next_gate':'One separately prospective fresh-root actual engineering integration with strict owner/source/input/receipt/deadline/full-cost gates before an opportunity campaign.'}
write('Software_Readiness.json',result)
print(json.dumps({'all_passed':True,'labelled_fixtures':10,'new_scientific_calls':0,'seconds':result['seconds']}))
