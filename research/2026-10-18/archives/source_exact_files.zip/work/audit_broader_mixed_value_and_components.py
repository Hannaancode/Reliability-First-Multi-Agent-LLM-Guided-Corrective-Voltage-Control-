"""Read-only independent row/selection/cost audit; never calls a model or solver."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/llm_value_broader_development'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def verify_manifest(base, manifest):
    for name, item in manifest.items():
        path = base/name
        assert sha(path) == item['sha256'] and path.stat().st_size == item['bytes']

def original_score(test):
    before, after = test['verification']['before'], test['verification']['after']
    return (int(after['uv_count']==0), before['uv_count']-after['uv_count'],
            before['deficit_sum']-after['deficit_sum'], after['vmin']-before['vmin'],
            -sum(abs(float(q)) for q in test['action']['add_shunts_q_mvar'].values()))

def selection(row):
    accepted = [t for t in row['tested'] if t['verification']['accepted']]
    best = max(accepted, key=original_score) if accepted else None
    assert row['selected_action'] == (best['action'] if best else None)
    if best:
        after = best['verification']['after']
        assert all(abs(float(after[k])-float(row['executed_after_metrics'][k])) <= 1e-10 for k in after)
    else:
        assert row['executed_after_metrics'] == row['initial_metrics']

def sum_counts(items):
    return {k: sum(x[k] for x in items) for k in ['attempts','returns','exceptions']}

def write_new(path, value):
    with path.open('x') as f: json.dump(value, f, indent=2)

def audit_screen():
    destination = OUT/'Broader_Screen_Completion_Audit.json'
    assert not destination.exists()
    protocol = read(OUT/'clean_value_development_protocol.json')
    analysis = read(OUT/'clean_value_screen_analysis.json')
    summary = read(OUT/'cpu_screen_summary.json')
    owner = read(OUT/'gpu_missing_resume_status.json')
    assert owner['runtime_released'] and owner['actual_batches_preserved']==48
    verify_manifest(OUT/'gpu_staged', read(OUT/'GPU_Staged_Manifest.json'))
    verify_manifest(OUT/'cpu_controls', read(OUT/'CPU_Control_Manifest.json'))
    expected = {c['scenario_id']+'__'+p+'__B'+str(b) for c in protocol['initial_screen_scenarios']
                for p in protocol['first_screen_policies'] for b in protocol['candidate_evaluation_budget_grid']}
    assert set(analysis['input_row_sha256']) == expected and len(expected)==120
    rows = {}
    for key, digest in analysis['input_row_sha256'].items():
        path = OUT/'cpu_screen_cases'/(key+'.json')
        assert sha(path)==digest
        row = read(path); rows[key] = row
        case = next(c for c in protocol['initial_screen_scenarios'] if c['scenario_id']==row['scenario_id'])
        assert row['scenario_sha256']==case['sha256']==sha(ROOT/case['path'])
        assert row['true_state_preserved'] and len(row['tested'])==row['tested_candidate_count']<=row['budget']
        assert row['candidate_PF_counts']['attempts']<=row['budget'] and row['execution_PF_counts']['attempts']<=1
        selection(row)
        for counts in [row['candidate_PF_counts'],row['execution_PF_counts']]:
            assert counts['attempts']==counts['returns']+counts['exceptions']
        if row['policy'].startswith('zonal_'):
            batch = read(OUT/'gpu_staged/llm_value_broader_development/gpu_proposals/batches'/(key+'.json'))
            assert row['model_costs']==batch['costs'] and len(row['raw_zone_scope_audit'])==4
        else:
            control = OUT/'cpu_controls'/(key+'.json')
            assert row['preserved_control_reused_without_rerunning'] and row['preserved_source_row_sha256']==sha(control)
            old = read(control)
            assert all(row[n]==value for n,value in old.items())
    assert summary['actual_trials']==analysis['actual_trials']==120
    assert summary['preserved_control_rows_reused_without_rerun']==72
    gpu_summary = read(OUT/'gpu_staged/llm_value_broader_development/gpu_proposals/summary.json')
    assert summary['actual_GPU_calls']==analysis['actual_GPU_calls']==gpu_summary['actual_costs']['llm_calls']
    learned = [r for r in rows.values() if r['policy'].startswith('zonal_')]
    fresh_counts = [r[k] for r in learned for k in ['candidate_PF_counts','execution_PF_counts']]
    fresh_counts += [x['initial_PF_counts'] for x in summary['shared_initial_PF_costs']]
    assert sum_counts(fresh_counts)==summary['actual_local_PF_counts']
    previous = read(OUT/'cpu_controls/summary.json')['PF_budget']
    assert summary['preserved_control_original_actual_PF_counts']=={k:previous[k] for k in ['attempts','returns','exceptions']}
    assert summary['actual_local_PF_counts_all_executed_stages']=={
        k: previous[k]+summary['actual_local_PF_counts'][k] for k in ['attempts','returns','exceptions']}
    for name,digest in read(ROOT/'outputs/matched_campaign_protocol.json')['source_sha256'].items():
        assert sha(ROOT/name.replace('\\','/'))==digest
    primary = [c for c in analysis['comparisons'] if c['primary_development_comparison']]
    families = {}
    for row in primary:
        family = re.search(r'line_(\d+)_MG(\d+)', row['scenario_id'])
        assert family
        families.setdefault('line_'+family[1]+'_MG'+family[2],[]).append(row)
    assert len(primary)==8 and len(families)==4 and all(len(v)==2 for v in families.values())
    averages = {key: {n: sum(r[n] for r in pair)/2 for n in
                     ['residual_UV_learned_minus_control','deficit_learned_minus_control','Vmin_learned_minus_control']}
                for key,pair in families.items()}
    audit = {'audited_at_utc':datetime.now(timezone.utc).isoformat(),'auditor_sha256':sha(Path(__file__)),
             'all_gates_passed':True,'exact_row_identities':120,'preserved_controls_without_rerun':72,
             'actual_batches':48,'actual_primary_query_opportunities':192,'actual_generations':summary['actual_GPU_calls'],
             'actual_local_PF_counts_all_stages':summary['actual_local_PF_counts_all_executed_stages'],
             'all_selected_actions_match_original_score_and_executed_physics_1e10':True,
             'family_pair_descriptive_averages':averages,'primary_residual_UV_deltas':analysis['primary_residual_UV_deltas'],
             'new_model_or_PF_calls_by_auditor':0,'scope':'Eight historical points, four families; descriptive one-state development only'}
    write_new(destination,audit)
    paths = list((OUT/'cpu_screen_cases').glob('*.json'))
    paths += [OUT/n for n in ['cpu_screen_summary.json','cpu_screen_progress.json','clean_value_screen_analysis.json',
                              'genuine_clean_GPU_artifact_audit.json','Broader_Screen_Completion_Audit.json']]
    write_new(OUT/'Broader_Screen_Results_Manifest.json', {p.relative_to(OUT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths})
    print('BROADER_120_ROW_INDEPENDENT_AUDIT_PASSED',audit['primary_residual_UV_deltas'],flush=True)
    return audit

def audit_components():
    folder = OUT/'bus_Q_attribution'
    verify_manifest(folder, read(folder/'manifest.json'))
    protocol, summary = read(folder/'protocol.json'), read(folder/'summary.json')
    assert sha(ROOT/'work/run_broader_mixed_bus_Q_attribution.py')==protocol['driver_sha256']
    assert sha(OUT/'Broader_Bus_Q_Attribution_Design.md')==protocol['design_sha256']
    assert summary['actual_new_CPU_trials']==16 and summary['actual_new_model_calls']==0
    expected = {c['scenario_id']+'__'+p+'__bus_Q_component_B32' for c in protocol['scenarios'] for p in protocol['model_policies']}
    assert {r['trial_id'] for r in summary['rows']}==expected
    counts = [x['PF_counts'] for x in summary['shared_initial_PF_costs']]
    for reference in summary['rows']:
        row = read(folder/(reference['trial_id']+'.json'))
        selection(row)
        assert row['source_state_preserved'] and row['selected_action_execution_matches_verification_1e10']
        case = next(c for c in protocol['scenarios'] if c['scenario_id']==row['scenario_id'])
        assert row['scenario_sha256']==case['sha256']==sha(ROOT/case['path'])
        assert row['actual_candidate_PF_counts']['attempts']<=32 and len(row['tested'])<=32
        assert row['actual_execution_PF_counts']['attempts']<=1
        counts += [row['actual_candidate_PF_counts'],row['actual_execution_PF_counts']]
        original = read(OUT/'cpu_screen_cases'/(row['scenario_id']+'__'+row['proposal_source_policy']+'__B32.json'))
        lowest = read(OUT/'cpu_screen_cases'/(row['scenario_id']+'__lowest_voltage__B32.json'))
        assert row['UV_delta_vs_lowest_voltage']==row['executed_after_metrics']['uv_count']-lowest['executed_after_metrics']['uv_count']
        assert row['UV_delta_vs_original_raw_prefix']==row['executed_after_metrics']['uv_count']-original['executed_after_metrics']['uv_count']
    assert sum_counts(counts)==summary['actual_new_PF_counts'] and sum_counts(counts)['attempts']<=536
    audit = {'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_gates_passed':True,
             'exact_component_trials':16,'original_manifest_members_verified':len(read(folder/'manifest.json')),
             'actual_new_PF_counts':summary['actual_new_PF_counts'],'new_model_calls':0,
             'selected_action_identity_score_physics_and_reference_deltas_verified':True,
             'new_model_or_PF_calls_by_auditor':0,'scope':'Historical component attribution; no new inference or closed-loop superiority'}
    write_new(OUT/'Broader_Component_Completion_Audit.json',audit)
    print('BROADER_16_COMPONENT_INDEPENDENT_AUDIT_PASSED',audit['actual_new_PF_counts'],flush=True)
    return audit

if __name__=='__main__':
    import sys
    (audit_components if sys.argv[-1]=='components' else audit_screen)()
