"""Reconstruct the unchanged DFF only from verified paid native80 returns.

Stop at the first missing exact input/contract. This does not enter physics,
model inference, training, a new controller campaign or the old reader phase.
"""
import copy,json,pickle,random,sys,time
from pathlib import Path
from reflection118_chronological_core_20261022 import *
O=R/'outputs/r118_dff_paid_prefix_continuation_20261022'
class MissingPaidReturn(BaseException):pass
def main():
    O.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np,pandas as pd,pandapower as pp
    from frozen_physics_loader import load_stack,AUDIT
    def forbidden(*a,**k):raise BaseException('FORBIDDEN_NEW_PHYSICS_OR_MODEL')
    pp.runpp=forbidden
    proto=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json')
    for n,h in proto['original_serving_sources'].items():assert sha(R/n)==h
    v2,runner,reflection=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    old=R/'outputs/r118chrono_20261022/local_controller'
    oldaudit=read(R/'outputs/r118chrono_audit_20261022/Independent_Audit.json')
    assert oldaudit['all_causal_original_policy_outputs_exact']
    bridge=R/'outputs/r118_solver_contract_bridge_execution_20261022'
    bridgeaudit=R/'outputs/r118_solver_contract_bridge_independent_20261022/Independent_Audit.json'
    assert read(bridgeaudit)['status'].startswith('PASS_FIRST_NEW80')
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    row=roots[0];d=old/row['case_id'];cache=[]
    for arm in ['no_llm_fallback_first','reflection_v2']:
        for path in sorted((d/arm).glob('pf_*.json')):
            rec=read(path);cache.append(dict(directory=path.parent,rec=rec,source=path.relative_to(R).as_posix(),sha256=sha(path)))
    result=read(bridge/'Result.json');assert result['exception'] is None
    cache.append(dict(directory=bridge,rec=dict(before=result['before'],after=result['after'],kwargs=read(R/'outputs/r118_solver_contract_bridge_preparation_20261022/Protocol.json')['new_native_kwargs']),source=(bridge/'Result.json').relative_to(R).as_posix(),sha256=sha(bridge/'Result.json')))
    for c in cache:c['before']=decode(c['directory'],c['rec']['before']);c['after']=None
    scenario=read(R/row['registration']['recipe']);base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    runs=[]
    for run in ['warm','cold']:
        calls=[];boundary=None;missing=None;complete=None
        random.seed(proto['seed']);np.random.seed(proto['seed'])
        def saved_pf(net,**kw):
            nonlocal missing
            assert time.monotonic()-start<180
            matches=[]
            for c in cache:
                if kw!=c['rec']['kwargs'] or not net.shunt.equals(c['before'].shunt):continue
                try:frames_equal(net,c['before'])
                except (AssertionError,KeyError,ValueError):continue
                if c['after'] is None:c['after']=decode(c['directory'],c['rec']['after'])
                matches.append(c)
            if not matches:
                desc=capsule(O/(run+'_first_missing_native_input.zlib'),copy.deepcopy(net))
                missing=dict(physical_input=desc,solver_kwargs=kw,logical_call=len(calls),status='UNEXECUTED_BY_THIS_GATE_UNKNOWN_REQUIRES_HISTORY_AND_PROSPECTIVE_MEASUREMENT_GATES')
                raise MissingPaidReturn()
            for c in matches[1:]:pd.testing.assert_frame_equal(matches[0]['after'].res_bus,c['after'].res_bus,check_exact=True)
            restore_exact(net,matches[0]['after']);calls.append(dict(source=matches[0]['source'],source_sha256=matches[0]['sha256'],kwargs=kw,all_matching_paid_returns=len(matches)))
        def checkpoint(state):
            nonlocal boundary
            boundary=copy.deepcopy(state)
        try:complete,_=controller(v2,runner,reflection,scenario,base,zones,forbidden,saved_pf,'no_llm_fallback_first',checkpoint)
        except MissingPaidReturn:pass
        if boundary is not None:capsule(O/(run+'_actual_first_commit_state.zlib'),boundary)
        runs.append(dict(calls=calls,boundary=boundary,missing=missing,complete=complete))
    assert runs[0]['calls']==runs[1]['calls'] and runs[0]['complete']==runs[1]['complete']
    if runs[0]['boundary'] is not None:checkpoint_equal(runs[0]['boundary'],runs[1]['boundary'])
    else:assert runs[1]['boundary'] is None
    if runs[0]['missing'] is not None:
        a=decode(O,runs[0]['missing']['physical_input']);b=decode(O,runs[1]['missing']['physical_input']);frames_equal(a,b)
        assert runs[0]['missing']['solver_kwargs']==runs[1]['missing']['solver_kwargs']
    put(O/'Continuation_Readiness.json',dict(status='PASS_EXACT_PAID_DFF_PREFIX_WARM_COLD_NEXT_MISSING_UNKNOWN',
        cached_native_PF_calls_per_pass=len(runs[0]['calls']),paid_records=runs[0]['calls'],
        first_commit_checkpoint_present=runs[0]['boundary'] is not None,next_missing=runs[0]['missing'],complete_source_result=runs[0]['complete'],
        new_PF_model_derivative_optimizer_calls=0,original_DFF_AST_unchanged=True,
        original_failure_and_costs_preserved=True,not_a_completed_DFF_or_head_to_head_result=True,
        original_audit_sha256=sha(R/'outputs/r118chrono_audit_20261022/Independent_Audit.json'),bridge_audit_sha256=sha(bridgeaudit),
        source_sha256=sha(__file__),workflow_seconds=time.monotonic()-start))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(cached_native_calls=len(runs[0]['calls']),actual_first_commit=runs[0]['boundary'] is not None,next_missing=runs[0]['missing'] is not None,new_scientific_calls=0)))
if __name__=='__main__':main()
