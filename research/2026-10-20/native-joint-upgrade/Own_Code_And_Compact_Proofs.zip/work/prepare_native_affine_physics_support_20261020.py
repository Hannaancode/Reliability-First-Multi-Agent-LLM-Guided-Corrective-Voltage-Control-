"""Freeze ALL24 unexecuted candidate inputs/native query history/protection/reader before new physics."""
import json,hashlib,pickle,ast
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_affine_physics_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;affine=ROOT/'outputs/native_full_grid_affine_gate_20261020';r=json.loads((affine/'Result.json').read_text(encoding='utf-8'));a=json.loads((ROOT/'outputs/native_full_grid_affine_independent_20261020/Independent_Audit.json').read_text(encoding='utf-8'));assert r['status']=='COMPLETE_DECLARED24_AFFINE_CONTROL_ANALYSIS' and a['status'].startswith('PASS_')
    for rel in ['outputs/native_full_grid_affine_coordination_20261020/End_ACK.json','outputs/native_full_grid_affine_reader_coordination_20261020/End_ACK.json']:
        e=json.loads((ROOT/rel).read_text(encoding='utf-8'));assert e['actual_owned_chain_ended'] and e['exit_code']==0
    ap=json.loads((ROOT/'outputs/native_full_grid_affine_preparation_20261020/Protocol.json').read_text(encoding='utf-8'));support=ROOT/'outputs/native_action_upgrade_support_20261020';s=json.loads((support/'Result.json').read_text(encoding='utf-8'));history=[];inputs={}
    for x in s['receipts']:
        if x['status']!='RETURNED':continue
        before=support/'physics'/f"PF{x['index']:04d}_before.pkl";after=support/'physics'/f"PF{x['index']:04d}_after.pkl";fields=support/'physics'/f"PF{x['index']:04d}_fields.npz"
        with before.open('rb') as f:net=pickle.load(f)
        assert signature(net)==x['physical_signature'];history.append({'signature':x['physical_signature'],'kwargs':x['kwargs'],'before_NET':before.relative_to(ROOT).as_posix(),'after_NET':after.relative_to(ROOT).as_posix(),'fields':fields.relative_to(ROOT).as_posix(),'original_scientific_cost_reference':'outputs/native_action_upgrade_support_20261020/Result.json'})
        for f in [before,after,fields]:inputs[f.relative_to(ROOT).as_posix()]=sha(f)
    assert len(history)==114 and len({(x['signature'],json.dumps(x['kwargs'],sort_keys=True)) for x in history})==114;put(OUT/'Relevant_Paid_Inputs.json',{'status':'PASS_ALL114_ACTUAL_RETURNED_NATIVE_QUERIES_SOURCE_SIGNATURES_AND_ARG_BINDINGS','all114_returned_queries':history,'prior25_root0_inputs_not_revisited':'Allnew500..507activeP/Qrecipes aredisjointfromall500source0..499profilesandknownpriornative13signatures;physicalPfixedthroughall24newstates. Relevantactualproofin native_action_upgrade_preparation_20261020.'})
    contexts=[]
    for i,x in enumerate(ap['all24contexts']):
        netfile=affine/f'context_{i:02d}/UNEXECUTED_Candidate_NET.pkl';u=affine/f'context_{i:02d}/UNEXECUTED_Native_u_Mvar.npy';row={**x,'original_NET':x['paid_NET'],'candidate_NET':netfile.relative_to(ROOT).as_posix(),'native_u':u.relative_to(ROOT).as_posix()};contexts.append(row)
        with (ROOT/x['paid_NET']).open('rb') as f:before=pickle.load(f)
        with netfile.open('rb') as f:candidate=pickle.load(f)
        action=np.load(u);assert action.dtype==np.float32 and action.shape==(3,) and np.max(np.abs(action))<=np.float32(.3);assert np.array_equal(candidate.sgen.q_mvar.to_numpy()[:3],before.sgen.q_mvar.to_numpy()[:3]-action)
        for name in ['bus','line','trafo','load','gen','ext_grid','shunt','switch']:assert before[name].equals(candidate[name])
        assert before.sgen.drop(columns=['q_mvar']).equals(candidate.sgen.drop(columns=['q_mvar'])) and np.array_equal(before.sgen.q_mvar.to_numpy()[3:],candidate.sgen.q_mvar.to_numpy()[3:])
        for f in [netfile,u,ROOT/x['paid_NET']]:inputs[f.relative_to(ROOT).as_posix()]=sha(f)
    graph=ap['graph'];inputs[graph]=sha(ROOT/graph);inputs[(OUT/'Relevant_Paid_Inputs.json').relative_to(ROOT).as_posix()]=sha(OUT/'Relevant_Paid_Inputs.json');sources=['work/run_native_affine_physics_support_20261020.py','work/audit_native_affine_physics_support_20261020.py','work/native_upgrade_support_engine_20261020.py','work/stable_ddpg_native_bridge_20261020.py']
    for n in sources:ast.parse((ROOT/n).read_text(encoding='utf-8'))
    p={'at_utc':datetime.now(timezone.utc).isoformat(),'scientific_question':'OnALL24fixedpaidcontexts,doesoneplannednativeaffinecandidatephysicallyreducewhole-gridviolationswithoutcausingnewUV/OV? This checksnumericalopportunitybeforemodelupgrade,notLLM/matchedrolloutperformance.','all24contexts':contexts,'graph':graph,'sources':{n:sha(ROOT/n) for n in sources},'inputs':inputs,'worker_seconds':600,'actual_PF_kwargs':{'algorithm':'bfsw','init':'dc'},'maximum_primary_new_PF_attempts':24,'maximum_independent_new_PF_replays':24,'normal_band_guard':'ProtectallbeforeVMwithin[.95,1.05]usinglower.95-1e-8/upper1.05+1e-8;typedacceptalsorequiresstrictmeasuredUVandOVcountsnotincrease. Rejectpreservesoldstateconceptually,noactualcommit.','fixed_gate':'Completeall24knownidentitiesandsafeactualviolationcountimprovementinatleast2exactdevelopmentworlds=>limitednumericalphysicalsupportonly. Partial/unrecovered=>UNKNOWN. Retainall9alreadyrestoredcontextsandall15OVcontexts,nooutcomeselection.','no_scientific_retry':'OnePFperpreviouslyunexecutedexactinput+initializeridentity;old/currentstudyexactmatchesreusepaidoutputs/costs. DifferinginitializeronpaidphysicalinputUNKNOWN,noadditionalcall. Failedscientificcallsretainednotreplayed.','native_actuator':'Exactsourcefloat32 +/-0.3per-stepuandQnext=Qcurrent-u,unchanged3controlledsgens/buses2/7/9;noinventedabsolutestockcap.','scope':'CentralizedYbus/full13VM/additional1step,differentinformationandstoppingthanunmodifiedpublishedlocalcontrollers. No wholepolicy,originalDSE,LLM,noveltyorunusedconfirmationwin. Futurematchedcommon-goalcontrolvariants/fullcostsrequired.','training_GPU_calls':0,'frozen_original_checks':frozen_checks()};put(OUT/'Protocol.json',p)
    for mode,src,output,coord in [('primary',sources[0],'outputs/native_affine_physics_support_20261020','outputs/native_affine_physics_coordination_20261020'),('independent',sources[1],'outputs/native_affine_physics_independent_20261020','outputs/native_affine_physics_reader_coordination_20261020')]:put(OUT/(mode+'_Owner_Protocol.json'),{'single_owner':{'source':src,'sha256':sha(ROOT/src),'python':'work/vcsa_module_env/Scripts/python.exe','output':output,'coordination':coord,'bound_seconds':650},'require_ended_claims':[] if mode=='primary' else ['outputs/native_affine_physics_support_20261020/owner.claim'],'old_scientific_source_name':'run_native_affine_physics_support_20261020.py'})
    put(OUT/'Readiness.json',{'status':'PASS_ALL24_NATIVE_PI_CANDIDATE_INPUTS_FULL114_PAID_HISTORY_NORMAL_PROTECTION_OWNER_READER_SOURCE_LOCK','actual_PF_model_optimizer_GPU_calls':0,'all24_real_candidate_results':'UNKNOWN_UNEXECUTED','input_hashes':len(inputs),'same_all24_contexts_as_affine_protocol':True});print('ALL24_NATIVE_PHYSICAL_SUPPORT_PREPARATION_PASS_ZERO_NEW_PF')
if __name__=='__main__':main()
