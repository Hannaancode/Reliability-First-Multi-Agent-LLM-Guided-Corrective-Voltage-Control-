"""Independent full lineage attempt-key and receipt-reference audit; zero science."""
import gzip,hashlib,json,os,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/paid_lineage_frontier_20261018';OUT=B/'audit'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
def put(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);started=time.perf_counter()
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    lock=read(B/'Independent_Reader_Lock.json');assert lock['reader_sha256']==sha(Path(__file__))
    result=read(B/'Results.json');manifest=read(B/'Closed_Manifest.json');protocol=read(B/'Protocol.json')
    for rel,v in manifest['members'].items():assert sha(B/rel)==v['sha256'] if isinstance(v,dict) else sha(B/rel)==v
    indexfile=B/'All_Lineage_Attempt_Keys.json.gz';assert sha(indexfile)==result['frontier_sha256']
    with gzip.open(indexfile,'rt',encoding='utf-8') as f:index=json.load(f)
    warm_path=R/'outputs/receding_warm_dependency_closure_20261015/Paid_Warm_Dependencies.json';assert sha(warm_path)==protocol['warm_dependency_sha256']
    warm=read(warm_path);warmkeys=set(warm['cache']);blocked=set(warm['blocked_prior_incomplete_identities'])
    for k in warmkeys:assert index[k]=={'classification':'WARM_PAID_RECEIPT_RETAIN_OLD_COSTS','receipt_id':warm['cache'][k]['receipt_id'],'warm_key':k}
    for k in blocked:assert index[k]=={'classification':'PRIOR_INCOMPLETE_BLOCK_REEXECUTION'}
    old=R/'outputs/full_receding_paid_campaign_20261015';expected=read(old/'actual/Closed_Manifest.json')['members']['scientific.jsonl'];scientific_protocol=sha(old/'Protocol.json')
    intent_keys={};actual_attempts=set();closed_hashes={};seen_receipts={};position=0;previous='0'*64;filehash=hashlib.sha256();return_count=exception_count=0
    with (old/'actual/scientific.jsonl').open('rb') as f:
        while line:=f.readline():
            assert time.perf_counter()-started<300,'Fixed independent reader bound, no extension'
            event=json.loads(line);assert event['previous_sha256']==previous and event['protocol_sha256']==scientific_protocol
            previous=digest(line[:-1]);filehash.update(line);d=event['data'];name=event['event']
            if name=='PF_intent':
                pid=d['identity'];assert pid not in actual_attempts;actual_attempts.add(pid)
                if d['context']['phase']=='NEW_PRIMARY_QUERY':
                    c=d['context'];key=c['point']+'|'+c['action_key'];assert key not in warmkeys|blocked and pid not in intent_keys;intent_keys[pid]=key
            elif name in ['PF_return','PF_exception']:
                pid=d['PF_id'];assert pid in actual_attempts and pid not in closed_hashes
                closed_hashes[pid]=(digest(canonical(d)),name)
                if name=='PF_return':return_count+=1
                else:exception_count+=1
            elif name=='every_query_receipt_closed_before_more_science':
                message=d['record'];receipt=message.get('actual_measured_receipt')
                if receipt:
                    pid=receipt['PF_id'];key=intent_keys[pid];assert digest(canonical(receipt))==closed_hashes[pid][0]
                    entry=index[key];assert entry['PF_id']==pid and entry['receipt_id']==message['receipt_id']
                    assert entry['classification']=='RECORDED_CLOSED_RECEIPT_REQUIRES_INDEPENDENT_SOURCE_RESULT_CHECK'
                    assert entry['PF_close_data_sha256']==closed_hashes[pid][0]
                    assert entry['outcome']==('RETURNED' if closed_hashes[pid][1]=='PF_return' else 'EXCEPTION_OPERATIONAL_REJECT_FEASIBILITY_UNKNOWN')
                    if pid not in seen_receipts:
                        assert entry['journal_offset']==position and entry['journal_bytes']==len(line) and entry['journal_line_sha256']==digest(line)
                    seen_receipts[pid]=key
            position+=len(line)
    assert filehash.hexdigest()==expected['sha256']==protocol['journal_sha256'] and position==expected['bytes']
    missing=set(intent_keys)-set(seen_receipts)
    for pid in missing:assert index[intent_keys[pid]]=={'classification':'PRIOR_ATTEMPT_NO_CLOSED_RECEIPT_BLOCK_REEXECUTION','PF_id':pid}
    assert set(index)==warmkeys|blocked|set(intent_keys.values())
    assert len(intent_keys)==result['new_primary_attempts'] and len(seen_receipts)==result['new_primary_with_closed_receipts']
    assert len(actual_attempts)==result['all_actual_attempts_including_replay'] and exception_count==result['recorded_exceptions']
    report={'status':'PASS_ALL_LINEAGE_ATTEMPT_KEYS_AND_EXACT_SOURCE_RECEIPT_REFERENCES','keys':len(index),'warm_paid_keys':len(warmkeys),'old_blocked_keys':len(blocked),
        'new_primary_attempt_keys':len(intent_keys),'new_primary_closed_receipts':len(seen_receipts),'new_primary_missing_receipt_BLOCKED':len(missing),
        'all_attempts_including_replay':len(actual_attempts),'source_recorded_exceptions':exception_count,'reader_scientific_calls':0,
        'workflow_seconds':time.perf_counter()-started,'limitations':'Index identity/source closure only, NOT independent physical certification of every candidate or permission to execute an absent key. Not global history beyond this four-root lineage.'}
    put(OUT/'Independent_Frontier_Audit.json',report);put(OUT/'Closed_Manifest.json',{'members':{str(p.relative_to(OUT)):sha(p) for p in OUT.iterdir() if p.is_file()},'new_science':0})
    print(json.dumps(report))
if __name__=='__main__':main()
