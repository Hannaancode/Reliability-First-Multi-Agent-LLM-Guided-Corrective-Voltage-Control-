"""Finite local handoff. Wait for owned data job, then audit once; never train."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/llm_value_next_method_research_20261008'
DATA=BASE/'train_trajectory_collection_nullable_v2'
OUT=BASE/'train_trajectory_audit_continuation'
AUDIT=BASE/'train_trajectory_collection_nullable_v2_audit'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
now=lambda:datetime.now(timezone.utc).isoformat()
assert not OUT.exists(),'One finite handoff only; preserve ended claims'
OUT.mkdir()
with (OUT/'owner.claim').open('x') as f:f.write(str(os.getpid()))
status={'owner_pid':os.getpid(),'started_at_utc':now(),'stage':'waiting_for_actual_data_owner_end',
        'new_model_or_PF_calls':0,'scientific_controller_restarts':0}
def save():
    status['updated_at_utc']=now();tmp=OUT/'status.tmp';tmp.write_text(json.dumps(status,indent=2),encoding='utf-8');tmp.replace(OUT/'status.json')
save()
try:
    deadline=time.monotonic()+4*3600
    while True:
        state=read(DATA/'status.json');pid=int(state['owner_pid'])
        command=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"
        live=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,check=True,
                            creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
        if not live:break
        assert 'run_train_trajectory_collection_nullable_v2.py' in live,'Actual PID was reused; ownership needs attention'
        assert time.monotonic()<deadline,'Bounded follow-through deadline; preserve data owner and report'
        time.sleep(45)
    assert state['stage']=='collection_closed_pending_external_audit','Actual collection did not close successfully; no audit rerun'
    assert not AUDIT.exists(),'Existing/partial external audit must be preserved, not restarted'
    reader=ROOT/'work/audit_train_trajectory_collection_nullable_v2.py'
    ready=read(BASE/'trajectory_measurement_nullable_v2_preparation/External_Reader_Readiness.json')
    assert ready['passed'] and hashlib.sha256(reader.read_bytes()).hexdigest()==ready['reader_source_sha256']
    status.update(stage='running_single_closed_data_external_audit',data_owner_ended=True);save()
    with (OUT/'stdout.log').open('x',encoding='utf-8') as stdout,(OUT/'stderr.log').open('x',encoding='utf-8') as stderr:
        result=subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(reader)],
                              cwd=str(ROOT),stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0,'External reader failed; partial audit preserved, no scientific rerun'
    certificate=read(AUDIT/'Independent_Identity_State_Scope_Selection_Cost_Audit.json')
    archive=read(AUDIT/'Local_Archive_Audit.json')
    assert certificate['all_closed_member_hashes_and_mechanical_gates_passed'] and archive['CRC_and_every_member_hash_passed']
    assert read(AUDIT/'Fresh_Frozen_Preservation.json')['all_passed']
    status.update(stage='TRAIN_data_collection_and_external_local_seal_complete',finished_at_utc=now(),
                  target_feasibility_gate_passed=certificate['target_feasibility_gate_passed'],
                  target_feasibility_counts=certificate['target_feasibility_counts'],
                  archive_sha256=archive['sha256'],validated_LLM_superiority=False,
                  next_action='evidence_backed_method_design_only' if certificate['target_feasibility_gate_passed'] else 'episode_recovery_target_not_ready_no_model_training')
    save()
    latest=read(BASE/'latest_execution_status.json');latest.update(updated_at_utc=now(),current_activity='TRAIN_data_measurement_audited_local_package_sealed',
           followthrough=status,research_objective='unachieved',data_gate_decision=status['next_action'])
    (BASE/'latest_execution_status.json').write_text(json.dumps(latest,indent=2),encoding='utf-8')
except BaseException as exc:
    status.update(stage='followthrough_failed_preserve_all_outputs',failure_type=type(exc).__name__,failure=str(exc),finished_at_utc=now());save();raise
