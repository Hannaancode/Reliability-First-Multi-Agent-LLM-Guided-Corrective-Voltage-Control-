"""Explicit native absolute-Q LP assembly; no model, PF, loader or file I/O."""
import numpy as np

def problem(vm, sensitivity, root_q, caps):
    vm=np.asarray(vm,dtype=float);s=np.asarray(sensitivity,dtype=float)
    q0=np.asarray(root_q,dtype=float);caps=np.asarray(caps,dtype=float)
    n,m=s.shape
    assert vm.shape==(n,) and q0.shape==caps.shape==(m,)
    assert all(np.isfinite(x).all() for x in (vm,s,q0,caps)) and np.all(caps>0)
    base=vm-s@q0
    # x=(absolute signed inverter Q, absolute voltage deviations, absolute Q).
    c=np.r_[np.zeros(m),np.full(n,1/n),np.full(m,.1/m)]
    a=np.vstack([np.c_[s,-np.eye(n),np.zeros((n,m))],
                 np.c_[-s,-np.eye(n),np.zeros((n,m))],
                 np.c_[np.eye(m),np.zeros((m,n)),-np.eye(m)],
                 np.c_[-np.eye(m),np.zeros((m,n)),-np.eye(m)],
                 np.c_[s,np.zeros((n,n+m))]])
    b=np.r_[1-base,base-1,np.zeros(2*m),1.05-base]
    bounds=[(-float(q),float(q)) for q in caps]+[(0,None)]*(n+m)
    return c,a,b,bounds

def metric(vm,q):
    vm=np.asarray(vm);q=np.asarray(q)
    return {'UV':int((vm<.95).sum()),'OV':int((vm>1.05).sum()),
            'vmin':float(vm.min()),'vmax':float(vm.max()),
            'native_L1_plus_q_cost':float(np.mean(np.abs(vm-1))+.1*np.mean(np.abs(q)))}
