"""Distinct v3 changed-path audit, synthetic stubs only; no earlier suite rerun."""
from pathlib import Path
from datetime import datetime, timezone
from types import ModuleType
import base64
import hashlib
import json
import struct
import sys
import numpy as np
from audit_nonlinear13_preserved_solver_20261029 import Clock, SyntheticResult, ValidatedNonlinearNative13, load, journal_records

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/nonlinear13_preserved_solver_review_20261029/v3_changed_paths'
SOURCE = 'work/nonlinear13_preserved_solver_v3_20261029.py'
CASES = ['nonfinite_x_and_native_state', 'nonfinite_multipliers_only',
         'invalid_x_shape', 'normal_success_regression']


def recover(record):
    raw = base64.b64decode(record['bytes_base64'])
    array = np.frombuffer(raw, dtype=np.dtype(record['dtype'])).reshape(record['shape'])
    return array, raw


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    files = [SOURCE, 'work/audit_nonlinear13_preserved_solver_20261029.py',
             'work/audit_nonlinear13_preserved_solver_v3_20261029.py']
    hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in files}
    protocol = {'label': 'ONE_ADDITIVE_V3_CHANGED_PATH_MOCK_AUDIT',
                'at_utc': datetime.now(timezone.utc).isoformat(), 'source_hashes': hashes,
                'cases': CASES, 'max_mock_minimize_calls_per_case': 2,
                'deadline_mock': 100., 'journal_byte_cap': 1000000,
                'NaN_float64_payload_bits_hex': '7ff8000000000042',
                'real_optimizer_native_derivative_PF_model_calls': 0,
                'prior_suite_rerun': False}
    with (OUT / 'Protocol.json').open('x', encoding='utf-8') as f: json.dump(protocol, f, indent=2)
    scipy = ModuleType('scipy'); scipy.__version__ = '1.16.3'; scipy.__path__ = []
    optimize = ModuleType('scipy.optimize'); optimize.__path__ = []
    native = ModuleType('scipy.optimize._slsqp_py'); scipy.optimize = optimize; optimize._slsqp_py = native
    keys = ['scipy', 'scipy.optimize', 'scipy.optimize._slsqp_py']; prior = {k: sys.modules.get(k) for k in keys}
    sys.modules.update(dict(zip(keys, [scipy, optimize, native])))
    rows = []
    try:
        module = load(SOURCE, 'synthetic_v3_changed_path_runner')
        module.equality_jacobian = lambda m, x: (m.charge('synthetic_equality_jacobian') or np.zeros((24, 31)))
        module.inequality_jacobian = lambda m, x, t: (m.charge('synthetic_inequality_jacobian') or np.zeros((2, 31)))
        module.objective_gradient = lambda m, x, s: (m.charge('synthetic_objective_gradient') or np.zeros(31))
        payload_nan = np.array([0x7ff8000000000042], dtype=np.uint64).view(np.float64)[0]
        state_array = np.array([np.nan, np.inf, -np.inf], dtype=np.float32)
        for case in CASES:
            clock = Clock(); module.time = clock
            model = ValidatedNonlinearNative13('success', clock)
            returned_arrays = []; calls = []
            def base_native(state):
                state['mode'] = 1
                if case == 'nonfinite_x_and_native_state':
                    state['nested_after'] = {'array': state_array.copy(), 'scalar': float(payload_nan)}
            native.slsqp = base_native
            def fake_minimize(fun, x, **kw):
                calls.append(len(calls) + 1); assert len(calls) <= 2
                state = {'mode': 0, 'iter': len(calls)}
                if case == 'nonfinite_x_and_native_state': state['before_nonfinite'] = float('inf')
                native.slsqp(state)
                rx = x.copy(); rm = np.array([.1, -.2], dtype=np.float64)
                if case == 'nonfinite_x_and_native_state': rx[:3] = [payload_nan, np.inf, -np.inf]
                elif case == 'nonfinite_multipliers_only': rm = state_array.copy()
                elif case == 'invalid_x_shape': rx = rx[:30]
                else:
                    fun(x); kw['jac'](x)
                    for c in kw['constraints']: c['fun'](x); c['jac'](x)
                    kw['callback'](x)
                returned_arrays.append((rx.copy(), rm.copy()))
                return SyntheticResult(x=rx, multipliers=rm, success=True, status=0,
                                       message='SYNTHETIC_V3_RETURN_ONLY', nit=1, nfev=1, njev=1)
            optimize.minimize = fake_minimize
            path = OUT / (case + '.jsonl')
            journal = module.PersistentCalculationJournal(path, 100., 1000000)
            try:
                result = module.solve_once(model, journal, {'all_required_current_state_checks_passed': True, 'label': 'SYNTHETIC_ONLY'})
            finally: journal.close()
            events, last = journal_records(path)
            assert native.slsqp is base_native and last == journal.previous
            assert journal.bytes == path.stat().st_size and journal.bytes <= journal.byte_cap
            raw_events = [e for e in events if e['kind'] == 'optimizer_lossless_raw_return']
            assert len(raw_events) == len(returned_arrays)
            for event, (rx, rm) in zip(raw_events, returned_arrays):
                for key, expected in [('x_bytes', rx), ('multipliers_bytes', rm)]:
                    arr, raw = recover(event[key])
                    assert arr.dtype.str == expected.dtype.str and arr.shape == expected.shape
                    assert raw == expected.tobytes(order='C')
            if case != 'normal_success_regression':
                assert result['status'] == 'NONFINITE_OPTIMIZER_RETURN_NO_RETRY' and len(calls) == 1
                assert not model.costs, 'No callback, equation, derivative or conversion may follow invalid return'
                reject = [e for e in events if e['kind'] == 'nonfinite_or_invalid_optimizer_return_rejected']
                assert len(reject) == 1 and raw_events[0]['seq'] < reject[0]['seq']
                assert not any(e['kind'] == 'calculation_attempt' for e in events)
                assert result['costs']['optimizer_returns'] == 1
            else:
                assert result['status'] == 'ADMITTED_UNMEASURED_PROPOSAL' and calls == [1, 2]
                assert result['costs']['optimizer_attempts'] == result['costs']['optimizer_returns'] == 2
                assert result['costs']['native_slsqp_calls'] == 2 and result['costs']['major_iteration_callbacks'] == 2
                assert sum(e['kind'] == 'calculation_attempt' for e in events) == 18
            native_bytes_checked = False
            if case == 'nonfinite_x_and_native_state':
                attempt = next(e for e in events if e['kind'] == 'native_solver_call_attempt')
                end = next(e for e in events if e['kind'] == 'native_solver_call_end')
                before = attempt['state']['before_nonfinite']['__float64_bytes_le__']
                assert base64.b64decode(before) == struct.pack('<d', float('inf'))
                after = end['state']['nested_after']
                assert base64.b64decode(after['scalar']['__float64_bytes_le__']) == struct.pack('<d', float(payload_nan))
                _, raw = recover(after['array']['__numeric_array_bytes__'])
                assert raw == state_array.tobytes()
                native_bytes_checked = True
            rows.append({'case': case, 'status': result['status'], 'mock_optimizer_calls': len(calls),
                         'stage_order': calls, 'optimizer_payload_dtype_shape_and_bytes_exact': True,
                         'native_nonfinite_nested_bytes_checked': native_bytes_checked,
                         'native_wrapper_restored': True, 'hash_chain_valid': True,
                         'charged_bytes': journal.bytes, 'physical_bytes': path.stat().st_size,
                         'costs': result['costs'], 'synthetic_callback_costs': model.costs,
                         'journal_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    finally:
        for key, value in prior.items():
            if value is None: sys.modules.pop(key, None)
            else: sys.modules[key] = value
    assert hashes == {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in files}
    result = {'status': 'PASS_V3_LOSSLESS_NONFINITE_PRESERVATION_AND_ONE_NORMAL_REGRESSION',
              'at_utc': datetime.now(timezone.utc).isoformat(), 'source_hashes': hashes, 'cases': rows,
              'S5_resolved_for_pinned_numeric_optimizer_payload': True,
              'actual_optimizer_native_derivative_PF_model_training_GPU_calls': 0,
              'old_suite_rerun': False, 'saved_grid_state_reads': 0, 'producer_or_master_edits': False,
              'limitations': ['Synthetic stubs only; no installed SciPy ABI or numerical convergence claim.',
                             'Raw numeric arrays preserve dtype, shape and C-order bytes, including NaN payload and both infinities.',
                             'Object-array payloads are intentionally outside the supported numeric optimizer contract.',
                             'The prior deadline/resource-exhaustion UNKNOWN-attempt limits and physical-validation gates remain.']}
    with (OUT / 'Results.json').open('x', encoding='utf-8') as f: json.dump(result, f, indent=2, allow_nan=False)
    print(json.dumps({'status': result['status'], 'cases': len(rows), 'S5_resolved': True, 'actual_optimizer_PF_calls': 0}))


if __name__ == '__main__': main()
