"""One charged independent replay of every new returned candidate; saved failures not reattempted."""
import json,hashlib,pickle,time,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_affine_physics_preparation_20261020';SRC=ROOT/'outputs/native_affine_physics_support_20261020';OUT=ROOT/'outputs/native_affine_physics_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));r=json.loads((SRC/'Result.json').read_text(encoding='utf-8'));m=json.loads((SRC/'Closed_Manifest.json').read_text(encoding='utf-8'));costs={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'reused_old_outputs':0,'failed_primary_not_replayed':0,'model_derivative_LP_GPU_calls':0};checks=[];delta=0.
    for n,h in {**p['sources'],**p['inputs']}.items():assert sha(ROOT/n)==h
    for f in m['files']:assert sha(SRC/f['path'])==f['sha256'] and (SRC/f['path']).stat().st_size==f['bytes']
    prev='0'*64
    for line in (SRC/'events.jsonl').read_text(encoding='utf-8').splitlines():
        v=json.loads(line);e=v['event'];assert e['previous']==prev and hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest()==v['sha256'];prev=v['sha256']
    assert prev==m['journal_last_sha256']
    for i,row in enumerate(r['all24contexts']):
        assert time.monotonic()-start<600;assert row['seed']==p['all24contexts'][i]['seed'] and row['algorithm']==p['all24contexts'][i]['algorithm'];d=SRC/f'context_{i:02d}'
        if row['status'] not in ['RETURNED_NEW','RETURNED_REUSED']:costs['failed_primary_not_replayed']+=1;checks.append({'context':i,'status':'UNKNOWN_PRESERVED_NO_RETRY'});continue
        with (d/'Candidate_Before.pkl').open('rb') as f:net=pickle.load(f)
        with (ROOT/p['all24contexts'][i]['original_NET']).open('rb') as f:before=pickle.load(f)
        before_vm=before.res_bus.vm_pu.to_numpy();assert signature(net)==row['physical_signature'];assert all(before[n].equals(net[n]) for n in ['bus','line','trafo','load','gen','ext_grid','shunt','switch']) and before.sgen.drop(columns=['q_mvar']).equals(net.sgen.drop(columns=['q_mvar']))
        q0=before.sgen.q_mvar.to_numpy()[:3];u=np.load(ROOT/p['all24contexts'][i]['native_u']);assert u.dtype==np.float32 and np.max(np.abs(u))<=np.float32(.3) and np.array_equal(net.sgen.q_mvar.to_numpy()[:3],q0-u)
        if row['status']=='RETURNED_NEW':
            costs['PF_attempts']+=1
            try:b.pp.runpp(net,**row['kwargs'])
            except BaseException:costs['PF_exceptions']+=1;raise
            costs['PF_returns']+=1
        else:
            costs['reused_old_outputs']+=1
            with (ROOT/row['paid_reuse']['after_NET']).open('rb') as f:net=pickle.load(f)
        stored=np.load(d/'Fields.npz')
        for n in stored.files:
            actual=net[n].select_dtypes(include=[np.number]).to_numpy(dtype=float);expected=stored[n];assert actual.shape==expected.shape and np.allclose(actual,expected,atol=1e-10,rtol=0,equal_nan=True);finite=np.isfinite(actual)&np.isfinite(expected)
            if finite.any():delta=max(delta,float(np.max(np.abs(actual[finite]-expected[finite]))))
        vm=net.res_bus.vm_pu.to_numpy();uv=int((vm<.95).sum());ov=int((vm>1.05).sum());protected=(before_vm>=.95)&(before_vm<=1.05);guard=bool(np.all(vm[protected]>=.95-1e-8)&np.all(vm[protected]<=1.05+1e-8));accepted=guard and uv<=int((before_vm<.95).sum()) and ov<=int((before_vm>1.05).sum());assert uv==row['after_UV'] and ov==row['after_OV'] and accepted==row['typed_proposal_accepted'] and not row['actual_commit'];checks.append({'context':i,'status':'PASS','accepted':accepted,'UV':uv,'OV':ov})
    assert costs['PF_returns']==r['costs']['PF_returns'];result={'status':'PASS_INDEPENDENT_DECLARED24_NATIVE_IDENTITY_SOURCE_Q_PI_GUARD_COST_FULL_FIELDS_PHYSICAL_REPLAY','scientific_status':r['status'],'fixed_gate':r['fixed_gate'],'checks':checks,'primary_costs':r['costs'],'actual_reader_costs':costs,'maximum_full_field_delta':delta,'frozen_original_checks':frozen_checks(),'workflow_seconds':time.monotonic()-start,'no_LLM_or_matched_benchmark_or_global_feasibility_claim':True};put(OUT/'Independent_Audit.json',result);put(OUT/'Closed_Manifest.json',{'files':{f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.iterdir() if f.is_file()}});print('INDEPENDENT_ALL24_NATIVE_CANDIDATE_REPLAY_PASS',costs,r['fixed_gate'])
if __name__=='__main__':main()
