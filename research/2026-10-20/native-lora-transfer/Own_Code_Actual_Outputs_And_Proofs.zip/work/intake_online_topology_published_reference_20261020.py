"""Read-only author source/data/checkpoint intake, zero import/execution/inference/PF."""
import json,hashlib,urllib.request,time,os,ast
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/online_topology_published_intake_20261020'
def main():
    start=time.monotonic();p=json.loads((OUT/'Pinned_Author_Git_Tree.json').read_text(encoding='utf-8'));assert not p['truncated'];rows=[e for e in p['tree'] if e['type']=='blob' and Path(e['path']).suffix in ['.py','.md','.mat','.pth']];assert len(rows)==len({r['path'] for r in rows})
    with (OUT/'owner.claim').open('x',encoding='utf-8') as f:json.dump({'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'at_utc':datetime.now(timezone.utc).isoformat()},f)
    with (OUT/'Protocol.json').open('x',encoding='utf-8') as f:json.dump({'author_repo':p['repository'],'commit':p['commit'],'fixed_all_python_README_MAT_and_checkpoint_files':len(rows),'download_bytes':sum(r['size'] for r in rows),'resource_bound_seconds':300,'no_retry_or_import_or_scientific_calls':True,'historical_results_not_performance_evidence':True,'third_party_redistribution':'NoLICENSEfilefoundinthecompleteinspectedtree;preserve locallyonly,publish ownhashes/URLs/proofs.'},f,indent=2)
    records=[]
    for e in rows:
        assert time.monotonic()-start<300;url='https://raw.githubusercontent.com/'+p['repository']+'/'+p['commit']+'/'+e['path'];q=urllib.request.Request(url,headers={'User-Agent':'HierGrid-published-reference-intake'})
        with urllib.request.urlopen(q,timeout=min(30,300-(time.monotonic()-start))) as response:raw=response.read()
        assert len(raw)==e['size'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==e['sha'];target=OUT/'author_reference'/e['path'];target.parent.mkdir(parents=True,exist_ok=True)
        if target.suffix=='.py':ast.parse(raw.decode('utf-8-sig'))
        with target.open('xb') as f:f.write(raw)
        records.append({'path':e['path'],'bytes':len(raw),'git_blob':e['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'source_url':url})
    # Independent reread equations and all native feeder/checkpoint inventory; never unpickle.
    for r in records:
        raw=(OUT/'author_reference'/r['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['git_blob']
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL_PROSPECTIVE_OFFICIAL_SOURCE_NATIVE_DATA_CHECKPOINT_BYTE_AND_AST_INTAKE','commit':p['commit'],'files':records,'actual_download_bytes':sum(r['bytes'] for r in records),'checkpoint_components':sum(r['path'].endswith('.pth') for r in records),'actor_checkpoint_components':sum('policy_net_checkpoint' in r['path'] for r in records),'native_network_files':[r['path'] for r in records if r['path'].endswith('.mat')],'native_paper_scope':'AuthorREADMEdescribes13and56busunknown-topologyadaptation,acceptedPSCC2026; paperpublication independentlylinkableviaauthorarXiv2602.10355.','no_source_LICENSE_in_complete_inspected_tree':not any(Path(e['path']).name.lower().startswith('license') for e in p['tree']),'actual_author_code_imports_executions_weight_loads_model_PF_optimizer_GPU_calls':0,'workflow_seconds':time.monotonic()-start,'not_benchmark_or_ours_superiority':True,'next':'Independently certify actualselectedcheckpoint/class/nativeaction/observation/topology/information/solverlicense/sourceprotocolandpersistentcost gates beforeanyinference/physics;noautomatictrainingorcompatibilitysweep.'}
    with (OUT/'Independent_Byte_And_Source_Intake_Audit.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='files'}))
if __name__=='__main__':main()
