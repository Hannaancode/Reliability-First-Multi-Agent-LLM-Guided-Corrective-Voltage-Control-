"""Bounded T4/kernel test with existing ADC; no credentials are persisted."""
import json
import logging
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
logging.disable(logging.CRITICAL)
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession, Request
from colab_cli.client import Client, Prod, Variant, Accelerator
from colab_cli.runtime import ColabRuntime

root = Path(__file__).resolve().parents[1]
report_path = root / 'outputs/colab_execution_probe.json'
report = {'checked_at_utc':datetime.now(timezone.utc).isoformat(), 'client_use':'Isolated official Python client integration on Windows; native CLI platform support is not claimed', 'requested_accelerator':'T4', 'runtime_created':False, 'kernel_execution_verified':False, 'runtime_released':False}
started=time.monotonic()

class BoundedSession(AuthorizedSession):
    def request(self, *args, **kwargs):
        kwargs.setdefault('timeout',25)
        return super().request(*args, **kwargs)

credentials=Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud\application_default_credentials.json')
credentials.refresh(Request())
session=BoundedSession(credentials)
client=Client(Prod(),session)
endpoint=None
runtime=None
try:
    existing=client.list_assignments()
    report['preexisting_assignment_count']=len(existing)
    usage=client.get_consumption_user_info()
    report['paid_compute_units_balance']=usage.paid_compute_units_balance
    print('PREEXISTING_RUNTIME_COUNT',len(existing),flush=True)
    print('REQUESTING_ONE_STANDARD_T4_RUNTIME',flush=True)
    assignment=client.assign(uuid.uuid4(),variant=Variant.GPU,accelerator=Accelerator.T4)
    endpoint=assignment.endpoint
    report['runtime_created']=True
    print('T4_ASSIGNMENT_CREATED',flush=True)
    runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-access-check')
    nonce=uuid.uuid4().hex
    code=(
        "import json, platform, subprocess\n"
        "probe = {'nonce': '"+nonce+"', 'python': platform.python_version()}\n"
        "gpu = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader'], capture_output=True, text=True, timeout=15)\n"
        "probe['nvidia_smi_exit'] = gpu.returncode\n"
        "probe['gpu'] = gpu.stdout.strip()\n"
        "import torch\n"
        "probe['cuda_available'] = torch.cuda.is_available()\n"
        "probe['cuda_tensor_sum'] = torch.tensor([1.,2.,3.], device='cuda').sum().item() if probe['cuda_available'] else None\n"
        "print('HIERGRID_COLAB_PROBE ' + json.dumps(probe))\n"
    )
    outputs=runtime.execute_code(code,allow_stdin=False,timeout=45)
    for output in outputs:
        if output.get('output_type')=='stream':
            for line in output.get('text','').splitlines():
                if line.startswith('HIERGRID_COLAB_PROBE '):
                    result=json.loads(line[len('HIERGRID_COLAB_PROBE '):])
                    report['kernel_execution_verified']=result.get('nonce')==nonce
                    result.pop('nonce',None)
                    report['remote_probe']=result
                    print('REMOTE_EXECUTION_RESULT',json.dumps(result),flush=True)
        elif output.get('output_type')=='error':
            report['kernel_error_type']=output.get('ename')
    print('KERNEL_EXECUTION_VERIFIED',report['kernel_execution_verified'],flush=True)
except Exception as exc:
    report['failure_type']=type(exc).__name__
    response=getattr(exc,'response',None)
    if response is not None:report['failure_http_status']=response.status_code
    print('PROBE_FAILURE_TYPE',report['failure_type'],flush=True)
    if 'failure_http_status' in report:print('PROBE_FAILURE_HTTP_STATUS',report['failure_http_status'],flush=True)
finally:
    if runtime is not None:
        try:runtime.stop()
        except Exception:pass
    if endpoint is not None:
        try:
            client.unassign(endpoint)
            report['runtime_released']=True
            print('AGENT_CREATED_RUNTIME_RELEASED',flush=True)
        except Exception as exc:
            report['release_failure_type']=type(exc).__name__
            print('RELEASE_FAILURE_TYPE',type(exc).__name__,flush=True)
    report['elapsed_seconds']=round(time.monotonic()-started,2)
    report_path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    session.close()
    print('SANITIZED_PROBE_REPORT',report_path,flush=True)
