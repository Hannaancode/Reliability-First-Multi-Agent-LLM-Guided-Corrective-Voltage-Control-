"""Independent current exact identities + closed scope indexes, zero science."""
import copy,gzip,hashlib,json
from pathlib import Path
from fixed_three_query_core_20261019 import B,I,helpers,known_keys
from public118_slsqp_native_20261018 import R,read,put,sha
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from frozen_physics_loader import load_stack
from equal_operation_benchmark_v2 import decode_capsule
INPUT=R/'outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json'
def certify():
    data=read(INPUT);state=helpers(__file__)['input_state']();_,runner,_=load_stack();assert runner.rescue.grid_metrics(state['net'])['uv_count']==17 and point_key(state['net'],state['cursor'])==data['point']
    _,actuate,native=build_verifier(runner.rescue,state['cursor']);assert native['reverse_AST_exact']
    base=R/'outputs/prior_physical_query_footprints_20261018';a=read(base/'independent_audit/Independent_Audit.json');assert a['decoded_inputs']==60426 and a['status'].startswith('PASS_ALL60426_')
    indexpath=base/'actual/Physical_Component_Input_References.json.gz';expected=read(base/'actual/Closed_Manifest.json')['members'][indexpath.name];expected=expected['sha256'] if isinstance(expected,dict) else expected
    assert sha(indexpath)==expected;index=json.loads(gzip.decompress(indexpath.read_bytes()))
    static=R/'outputs/fresh_static_component_index_20261018';s=read(static/'Results.json');assert s['observations']==3418 and s['unique_components']==280 and sha(static/'All_Static_Component_References.json.gz')==s['index_sha256']
    older_static=json.loads(gzip.decompress((static/'All_Static_Component_References.json.gz').read_bytes()))
    two=R/'outputs/exact_two_paid_query_engineering_20261018';assert read(two/'audit_source_claim_v2/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING'
    recent=[]
    for phase in ('warm','cold'):
        with (two/phase/'capsules.bin').open('rb') as pack:
            for raw in (two/phase/'scientific.jsonl').read_bytes().splitlines():
                e=json.loads(raw)
                if e['event']=='PF_intent':
                    net=decode_capsule(pack,e['data']['before'])['net'];h,_=component(net);assert independent_component(net)==h;recent.append(h)
    assert len(recent)==4;known=known_keys();targets=[]
    for v in data['all_remaining_ordered_identities']:
        key=data['point']+'|'+action_key(v['row']);assert key==v['point_action_key'] and key not in known
        native_net=actuate(copy.deepcopy(state['net']),action(v['row']));h,values=component(native_net);assert independent_component(native_net)==h==v['physical_component_sha256'] and values==v['perbus_rational_component']
        assert not index.get(h) and not older_static.get(h) and h not in recent
        targets.append({'row':v['row'],'point_action_key':key,'role':'ORIGINAL_K4_RANK_'+str(v['fixed_rank']),'tracked_component_matches':0,'static_component_matches':0,'recent4_input_component_matches':0,'component_sha256':h})
    assert len(targets)==3
    files=[INPUT,base/'independent_audit/Independent_Audit.json',base/'actual/Closed_Manifest.json',static/'Results.json',static/'All_Static_Component_References.json.gz',
        two/'audit_source_claim_v2/Independent_Audit.json',two/'Protocol.json',I/'Exact_Current_Input.zlib']
    result={'status':'PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE','exact_candidate_keys':[v['point_action_key'] for v in targets],
        'input_preparation_sha256':sha(INPUT),'reader_source_sha256':sha(__file__),'exact_rows':targets,'native_verifier_certificate':native,
        'evidence_sha256':{str(x.relative_to(R)):sha(x) for x in files},'scope':'60426tracked nativeBEFORE inputs;3418staticAFTER observed tables;all4newprior query/replay BEFOREs. Broader unlogged histories/full staticBEFORE reconstruction not claimed. A scoped certificate alone is not execution authority.',
        'selection':'ALL3remaining originalK4 ranks2/3/4 selected before prior new physics, including all unsafe/adverse results. No outcome-driven Q/prompt/seed/budget/width selection.',
        'new_scientific_calls':0}
    put(B/'Attempt_Coverage_Certificate.json',result);return result
if __name__=='__main__':print(json.dumps({'coverage':certify()['status'],'science':0}))
