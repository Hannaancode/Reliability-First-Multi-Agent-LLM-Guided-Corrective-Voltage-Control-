"""Freeze an additive zero-science reader; retain the failed original unchanged."""
import ast,hashlib,json,os
from pathlib import Path
R=Path(__file__).resolve().parents[1]
P=R/'outputs/receding_linear_composed_reader_preparation_20261018'
OLD=R/'work/audit_full_receding_preserved_frame_v3_20261015.py'
NEW=R/'work/audit_full_receding_linear_composed_v4_20261018.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    P.mkdir(exist_ok=False)
    original=OLD.read_text('utf-8');changed=original;edits=[]
    def edit(before,after,count=1):
        nonlocal changed
        assert changed.count(before)==count,(before,changed.count(before))
        changed=changed.replace(before,after);edits.append({'before':before,'after':after,'count':count})
    edit("from receding_paid_runtime_v2 import restore_dependency_prefix", "from receding_paid_runtime_v2 import restore_dependency_prefix\nfrom exact_input_pair_equality_v1_20261018 import same_inputs\nfrom paid_receding_commit_and_history_v1 import restore as restore_raw")
    edit('def main():\n', '''PREPARATION=R/'outputs/receding_linear_composed_reader_preparation_20261018'
def verified_checkpoint_certificate(result):
    lock=read(PREPARATION/'Independent_Reader_Lock.json')
    assert lock['reader_sha256']==sha(Path(__file__))
    for relative,expected in lock['pinned_files'].items():assert sha(R/relative)==expected,relative
    proof=read(R/lock['checkpoint_certificate'])
    assert proof['status']=='PASS_ALL25_SAVED_COMPLETE_STATE_AND_DEPENDENCY_PREFIXES_LINEAR'
    assert proof['new_model_PF_derivative_forecast_factor_solve_calls']==0
    assert [entry['request'] for entry in proof['checkpoints']]==result['checkpoint_requests']
    assert proof['scientific_journal_sha256']==read(B/'actual/Closed_Manifest.json')['members']['scientific.jsonl']['sha256']
    return proof

def main():
''')
    edit("out=B/'audit_preserved_frame_v3';out.mkdir(exist_ok=False);started=time.perf_counter()", "checkpoint_certificate=verified_checkpoint_certificate(result)\n    out=B/'audit_linear_composed_v4_20261018';out.mkdir(exist_ok=False);started=time.perf_counter()")
    edit("time.perf_counter()-started<p['reader_bound_seconds']", "time.perf_counter()-started<read(PREPARATION/'Protocol.json')['analysis_bound_seconds']")
    edit("prior.signature(expected)==prior.signature(input_net)", "same_inputs(expected,input_net)")
    edit("prior.signature(net)==prior.signature(input_net)", "same_inputs(net,input_net)")
    edit("prior.signature(expected)==prior.signature(decode_capsule(pack,intents[m['PF_id']]['before'])['net'])", "same_inputs(expected,decode_capsule(pack,intents[m['PF_id']]['before'])['net'])")
    edit("state,_=restore_complete(R/result['checkpoint_requests'][-1]['checkpoint'],result['checkpoint_requests'][-1]['receipt'])", "state=restore_raw(R/result['checkpoint_requests'][-1]['checkpoint'],result['checkpoint_requests'][-1]['receipt'])")
    begin=original.index("    for checkpoint_index,request in enumerate(result['checkpoint_requests']):")
    end=original.index("    complete=result['exit_code']==0",begin)
    edit(original[begin:end],'''    for checkpoint_index,request in enumerate(result['checkpoint_requests']):
        admit();proof=checkpoint_certificate['checkpoints'][checkpoint_index]
        assert proof['request']==request and proof['all_cursor_caps_stock_NET_mask_RNG_cost_prefixes_verified']
        assert proof['manifest_sha256']==request['receipt']['manifest_sha256'] and proof['raw_sha256']==request['receipt']['raw_sha256']
        # All original raw state, history, dependency, point, cursor, mask, RNG,
        # source and cost assertions are independently covered by this pinned
        # ALL25 prefix certificate, not repeated scans of the same growing log.
''')
    edit("'original_runtime_checkpoint_frame_failure_not_repaired_or_resumed':True,", "'original_runtime_checkpoint_frame_failure_not_repaired_or_resumed':True,\n        'composed_all25_checkpoint_certificate_sha256':sha(R/'outputs/receding_checkpoints_linear_audit_20261018/Independent_Checkpoint_Audit.json'),")
    edit("returns[d['PF_id']]=d", "returns[d['PF_id']]=d\n                if len(returns)%2000==0:put(out/f'Capsule_Progress_{len(returns)}.json',{'checked_returns':len(returns),'workflow_seconds':time.perf_counter()-started,'new_science':0})")
    edit("query_checked+=count;decision_checked+=1", "query_checked+=count;decision_checked+=1\n                    put(out/f'Decision_Progress_{decision_checked}.json',{'checked_decisions':decision_checked,'checked_queries':query_checked,'workflow_seconds':time.perf_counter()-started,'new_science':0})")
    inverse=changed
    for item in reversed(edits):
        assert inverse.count(item['after'])==item['count'],item['after'][:100]
        inverse=inverse.replace(item['after'],item['before'])
    assert inverse==original
    oldnodes={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(original).body if isinstance(n,ast.FunctionDef)}
    newnodes={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(changed).body if isinstance(n,ast.FunctionDef)}
    untouched=['forbidden','check_current_context','audit_decision']
    assert all(oldnodes[n]==newnodes[n] for n in untouched)
    with NEW.open('x',encoding='utf-8',newline='\n') as f:f.write(changed)
    report=R/'outputs/receding_checkpoints_linear_audit_20261018/Independent_Checkpoint_Audit.json'
    proof=json.loads(report.read_text());assert proof['status'].startswith('PASS_ALL25_') and len(proof['checkpoints'])==25
    put(P/'Protocol.json',{'role':'ADDITIVE_INDEPENDENT_ALL_RECORDED_POLICY_PHYSICS_PARTIAL_READER',
        'analysis_bound_seconds':7200,'scientific_calls_allowed':0,
        'scope':'ALL recorded complete decisions, closed query receipts, saved physical outputs, source menu/forecast/ranking/verifier/first-only commits and full costs. ALL25 complete checkpoints composed with pinned independent linear certificate.',
        'original_science_and_old_analysis_budgets_not_extended':True,
        'partial_gate':'Original26th state remains missing; all-four/full-policy gate UNKNOWN. No science repeated or new performance arm.',
        'prior_actors_must_be_ended':True,'never_duplicate_restart_reader':True,
        'timing':'Software reader work only; no solver/deployment efficiency claim.'})
    put(P/'Source_Equivalence.json',{'status':'PASS_EXACT_INVERSE_SOURCE_TRANSFORM',
        'original_sha256':sha(OLD),'reader_sha256':sha(NEW),'exact_edits':edits,
        'unchanged_function_ASTs':untouched,'check_query_only_replaces_two_exact_input_equality_predicates':True,
        'scientific_point_IDs_masks_scope_Q_guard_scores_policy_performance_gates_unchanged':True,
        'all_checkpoint_assertions_composed_from_all25_independent_certificate':True})
    paths=[OLD,NEW,R/'work/exact_input_pair_equality_v1_20261018.py',
        R/'outputs/exact_input_pair_equality_20261018/Results.json',
        R/'work/audit_receding_checkpoints_linear_20261018.py',report,
        R/'outputs/receding_checkpoints_linear_audit_20261018/Protocol.json',
        R/'outputs/receding_checkpoints_linear_audit_20261018/Closed_Manifest.json',
        R/'outputs/full_receding_paid_campaign_20261015/Protocol.json',
        R/'outputs/full_receding_paid_campaign_20261015/actual/Result.json',
        R/'outputs/full_receding_paid_campaign_20261015/actual/Closed_Manifest.json',
        P/'Protocol.json',P/'Source_Equivalence.json']
    put(P/'Independent_Reader_Lock.json',{'status':'PASS_SOURCE_INPUT_CHECKPOINT_COMPOSITION_LOCK',
        'reader_sha256':sha(NEW),'checkpoint_certificate':str(report.relative_to(R)),
        'pinned_files':{str(path.relative_to(R)):sha(path) for path in paths}})
    print(json.dumps({'prepared_reader':'PASS','source_inverse_exact':True,'untouched_ASTs':untouched,'science':0}))
if __name__=='__main__':main()
