"""Named, positive-only original-paper input/action port; no inference or physics.

The federation parser and trained weights stay untouched. This module admits
literal sub-Mvar increments, with the native per-round capability, and keeps
four zone roles when only three actuators exist. It is NOT a full paper-system
implementation or a signed inverter policy.
"""
import copy
import hashlib
import json
import math
from collections import deque

import numpy as np

from check_native_parser_contract_v3_20261021 import native_unit_normalizer

STEP_CAP = float(np.float32(0.3))
PORT_NAME = 'PAPER_NATIVE13_POSITIVE_LITERAL_FOUR_ZONE_INPUT_CONTRACT_V1'
HISTORY_FIELDS = {'round', 'zone', 'bus', 'increment_Mvar', 'accepted', 'reason'}


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def physical_contract(bus_ids, actuator_buses, reference_bus, Y):
    buses = [int(v) for v in bus_ids]
    devices = [int(v) for v in actuator_buses]
    y = np.asarray(Y)
    if len(buses) != 13 or len(set(buses)) != 13:
        raise ValueError('This named contract requires thirteen distinct ordered buses')
    if len(devices) != 3 or len(set(devices)) != 3 or not set(devices) <= set(buses):
        raise ValueError('Three distinct native controlled bus identities are required')
    if reference_bus not in buses or reference_bus in devices:
        raise ValueError('The native reference must be distinct from controlled buses')
    if y.shape != (13, 13) or not np.isfinite(y).all():
        raise ValueError('Complete finite current native admittance required')
    roots = [int(reference_bus)] + sorted(devices)
    adjacency = {b: [] for b in buses}
    for i, b in enumerate(buses):
        adjacency[b] = sorted(buses[j] for j in range(13)
                              if i != j and (y[i, j] != 0 or y[j, i] != 0))
    distances = []
    for root in roots:
        dist = {root: 0}
        queue = deque([root])
        while queue:
            b = queue.popleft()
            for other in adjacency[b]:
                if other not in dist:
                    dist[other] = dist[b] + 1
                    queue.append(other)
        if len(dist) != 13:
            raise ValueError('Disconnected plant requires a separate island contract')
        distances.append(dist)
    zones = {f'MG{z + 1}': [] for z in range(4)}
    for b in buses:
        z = min(range(4), key=lambda i: (distances[i][b], i))
        zones[f'MG{z + 1}'].append(b)
    allowed = {z: [b for b in devices if b in members] for z, members in zones.items()}
    return {'name': PORT_NAME, 'bus_ids': buses, 'actuator_buses': devices,
            'reference_bus': int(reference_bus), 'roots': roots,
            'zones': zones, 'allowed': allowed, 'per_round_increment_cap_Mvar': STEP_CAP,
            'partition_rule': 'Reference plus three sorted controlled buses; current-Y graph distance, root-index ties. No voltage or outcome used.',
            'absolute_Q_cap': None,
            'absolute_Q_cap_reason': 'Native source bounds each increment, not cumulative inverter Q. No federation450Mvar cap is silently imposed.'}


def observation_frame(contract, current_VM, current_Q, round_index, history=()):
    vm = np.asarray(current_VM, dtype=np.float64)
    q = np.asarray(current_Q, dtype=np.float64)
    if vm.shape != (13,) or q.shape != (3,) or not np.isfinite(vm).all() or not np.isfinite(q).all():
        raise ValueError('Finite complete current voltage and exact actuator-order Q required')
    if type(round_index) is not int or not 0 <= round_index < 100:
        raise ValueError('Native round must be in the fixed 100-round opportunity range')
    past = []
    previous = -1
    for row in history:
        if set(row) != HISTORY_FIELDS:
            raise ValueError('History admits only causal request/verdict fields, no hidden labels')
        if type(row['round']) is not int or not previous <= row['round'] < round_index:
            raise ValueError('Future, current-round, or reordered feedback rejected')
        if row['zone'] not in contract['zones'] or row['bus'] not in contract['allowed'][row['zone']]:
            raise ValueError('History recipient must belong to its source zone')
        if type(row['accepted']) is not bool or not isinstance(row['reason'], str):
            raise ValueError('Explicit request verdict required')
        amount = row['increment_Mvar']
        if isinstance(amount, bool) or not isinstance(amount, (int, float)) or not math.isfinite(amount) or not 0 < amount <= STEP_CAP:
            raise ValueError('History cannot smuggle an unsupported request')
        previous = row['round']
        past.append(copy.deepcopy(row))
    return {'round': round_index, 'current_VM': vm.tolist(), 'current_Q_Mvar': q.tolist(),
            'causal_request_history': past}


def agent_packet(contract, frame, zone):
    if zone not in contract['zones']:
        raise ValueError('Unknown zone')
    vm = dict(zip(contract['bus_ids'], frame['current_VM']))
    local = {str(b): vm[b] for b in contract['zones'][zone]}
    uv = {str(b): vm[b] for b in contract['bus_ids'] if vm[b] < .95}
    allowed = contract['allowed'][zone]
    disposition = ('PAPER_UV_STOP_NO_MODEL_CALL' if not uv else
                   'EMPTY_ACTUATOR_ZONE_NO_MODEL_CALL' if not allowed else 'MODEL_INPUT_AVAILABLE')
    if disposition != 'MODEL_INPUT_AVAILABLE':
        return {'zone': zone, 'disposition': disposition, 'messages': None}
    state = {'zone': zone, 'round': frame['round'], 'local_current_VM_pu': local,
             'global_current_UV_pu': uv,
             'native_recipients': [{'bus': b,
                                    'current_Q_Mvar': frame['current_Q_Mvar'][contract['actuator_buses'].index(b)],
                                    'maximum_positive_increment_Mvar': STEP_CAP}
                                   for b in allowed],
             'causal_feedback': [r for r in frame['causal_request_history'] if r['zone'] == zone]}
    messages = [
        {'role': 'system', 'content': 'You are a microgrid zone agent. Return only valid JSON. No prose.'},
        {'role': 'user', 'content':
         'This is an explicitly adapted positive-only native inverter role. '
         'Use a literal positive Mvar INCREMENT, not a federation shunt command or absolute Q target. '
         'Do not rescale units. Do not request absorption. Only the listed zone recipients are legal. '
         'Each proposed increment must be at most the stated native per-round bound. '
         'Return {"bus":"BUS_ID","q_mvar":POSITIVE_INCREMENT} or null. '
         'The physical verifier, refinement and fallback are separate paid operations.\n'
         'CURRENT_CAUSAL_OBSERVATION:\n' + _canonical(state)}]
    return {'zone': zone, 'disposition': disposition, 'messages': messages,
            'current_observation_sha256': hashlib.sha256(_canonical(state).encode()).hexdigest()}


def admit_request(parsed, contract, frame, zone):
    if zone not in contract['zones']:
        raise ValueError('Unknown zone')
    normalize, _ = native_unit_normalizer()
    canonical = normalize(parsed)
    if canonical is None:
        return {'valid': False, 'reason': 'null_or_original_syntax_rejected', 'native_u': None}
    values = canonical.get('add_shunts_q_mvar', {})
    if len(values) != 1:
        return {'valid': False, 'reason': 'exactly_one_recipient_required', 'native_u': None}
    bus_s, value = next(iter(values.items()))
    bus = int(bus_s)
    delta = float(value)
    if bus not in contract['allowed'][zone]:
        return {'valid': False, 'reason': 'foreign_or_uncontrolled_recipient', 'native_u': None}
    if not math.isfinite(delta) or not 0 < delta <= STEP_CAP:
        return {'valid': False, 'reason': 'native_increment_cap_no_clip_or_rescale', 'native_u': None}
    u = np.zeros(3, dtype=np.float32)
    index = contract['actuator_buses'].index(bus)
    u[index] = -delta
    if u[index] == 0:
        return {'valid': False, 'reason': 'float32_underflow_is_not_corrective_support', 'native_u': None}
    q = np.asarray(frame['current_Q_Mvar'], dtype=np.float64) - u.astype(np.float64)
    return {'valid': True, 'reason': 'native_positive_increment_admitted_not_physically_verified',
            'bus': bus, 'literal_request_Mvar': delta,
            'actual_float32_increment_Mvar': float(-u[index]),
            'native_u': u.tolist(), 'candidate_absolute_Q_Mvar': q.tolist(),
            'original_unit_grid_removed_explicitly': True,
            'no_new_shunt_or_topology_change': True, 'physical_verification_pending': True}
