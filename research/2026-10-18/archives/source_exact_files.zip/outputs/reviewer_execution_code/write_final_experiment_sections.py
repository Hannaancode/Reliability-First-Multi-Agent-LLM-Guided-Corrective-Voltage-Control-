"""Render completed experiment summaries as replacement results, without tuning."""
from pathlib import Path
import json
from reviewer_completion_gates import completion_gates

def completed_sections(out=Path('outputs')):
    gate=completion_gates(out)
    assert gate['all_required_experimental_evidence_complete'], gate['open_gates']
    central=json.loads((out/'central_matched_summary.json').read_text())
    reference=json.loads((out/'ac_reference_controller_comparison_summary.json').read_text())
    assert central['case_count']==reference['case_count']==62
    fmt=lambda x: 'not estimated' if x is None else f'{x:.6g}' if isinstance(x,float) else str(x)
    band_note='The original saved full_restoration boolean denotes zero residual undervoltage. It does not establish the full 0.95–1.05 normal voltage band. The separate 1.06 hard ceiling and declared operating limits remain distinct checks.\n'
    value_audit=out/'llm_value_development/incremental_value_audit.json'
    if value_audit.exists():
        bands=json.loads(value_audit.read_text())['saved_physical_terminal_band_diagnostics']
        band_note+=('Among 60 valid selected main endpoints, separately labelled 1e-8 diagnostics found both normal bands met in '+str(bands['D-SE']['terminal_both_normal_bands_met_with_1e8_diagnostic'])+' D-SE and '+str(bands['HG-SE']['terminal_both_normal_bands_met_with_1e8_diagnostic'])+' HG-SE cases; soft upper-band exceedance occurred in '+str(bands['D-SE']['terminal_soft_upper_band_exceeded_beyond_1e8'])+' and '+str(bands['HG-SE']['terminal_soft_upper_band_exceeded_beyond_1e8'])+' respectively. These diagnostics do not alter original strict success counts.\n')
    lines=['\n## Completed central and reference evidence appendix\n',band_note,
           '### Results: centralized versus zonal proposal contexts\n',
           'Both standalone proposers were executed on the full locked bank with alternating order and the same frozen zonally trained adapter. The table includes all 62 cases and charges failed or invalid attempts. Finite UV-clear counts are voltage outcomes; the separate physical audit retains load-service and operating-limit flags.\n',
           '| Measure | Zonal HG-VF | Central VF |', '|---|---:|---:|']
    for name,key in [('Finite UV-clear cases / full bank','success'),('PF attempts','pf_attempts'),('PF exceptions','pf_exceptions'),('LLM calls','llm_calls'),('LLM exceptions','llm_exceptions'),('Input tokens','input_tokens'),('Output tokens','output_tokens'),('Branch wall seconds','wall_seconds'),('Measured PF seconds','pf_wall_seconds'),('CUDA-synchronized generation seconds','llm_wall_seconds')]:
        values=[]
        for branch in ['HG-VF','CENTRAL-VF']:
            values.append(str(central['finite_uv_clear_success_by_branch'][branch])+'/62' if key=='success' else fmt(central['full_bank_standalone_costs_including_invalid_cases'][branch][key]))
        lines.append('| '+name+' | '+' | '.join(values)+' |')
    differences=central['paired_differences']
    lines+=['\nPaired effect estimates use '+str(central['complete_valid_family_count'])+' complete valid outage families, with both load levels retained in each cluster. '+str(len(central['invalid_case_ids']))+' invalid pairs remain in the full-bank ledger and are excluded only from numeric differences. Positive differences mean a larger central value. These are secondary architecture comparisons, not additional confirmatory superiority tests.\n',
            '| Central minus zonal measure | Family mean | Family bootstrap 95% interval |','|---|---:|---|']
    for key in ['uv_count','deficit_sum','accepted_actions','nominal_support_mvar','wall_seconds','pf_attempts','llm_calls','input_tokens','output_tokens']:
        d=differences.get(key)
        if d:
            interval=d['outage_family_percentile_bootstrap_95_percent_ci']
            lines.append(f'| {key} | {fmt(d["mean_CENTRAL_minus_ZONAL"])} | [{fmt(interval[0])}, {fmt(interval[1])}] |')
    effect=differences.get('uv_count',{}).get('mean_CENTRAL_minus_ZONAL')
    interpretation=('No numeric paired UV effect is estimated because no complete valid family remains.' if effect is None else
                    'The observed central proposer has fewer residual UV buses on average.' if effect<0 else
                    'The observed zonal proposer has fewer residual UV buses on average.' if effect>0 else
                    'The observed family-average residual UV difference is zero; this does not establish equivalence.')
    lines+=['\n'+interpretation+' The comparison is conditional on one adapter trained with local zone contexts, this network, and the locked bank. It does not establish intrinsic zoning superiority or performance of a separately trained central model.\n',
            'Common-DFF envelopes are reported separately: zonal '+str(central['finite_uv_clear_success_by_envelope']['HG-SE-ZONAL'])+'/62 and central '+str(central['finite_uv_clear_success_by_envelope']['HG-SE-CENTRAL'])+'/62 finite UV-clear outcomes. The same saved DFF computation is charged to each envelope; its prior-campaign time is kept separate from current proposer time. Standalone outcomes remain the architecture comparison because a common fallback can mask proposer differences.\n',
            'Recorded context and proposal-diversity audits: `'+json.dumps(central['prompt_context_audit'],sort_keys=True)+'`. Parsing, repair, distinct-bus counts, failures, and selected-envelope branches are available in the full summary and paired ledger.\n',
            '### Results: conventional local AC shunt endpoint reference\n',
            f'All 62 original cases were processed. Independently checked voltage-only reference endpoints were found in {reference["references_found"]}/62 cases. Unsuccessful starts and invalid initial conditions remain recorded; absence of a local reference is not an infeasibility proof. The necessary fixed-P slack exclusion applies to {reference["all_declared_slack_necessary_exclusions"]}/62 cases, so these are not fully operating-limit-feasible AC-OPF solutions.\n',
            '| Controller | Available same-band reference pairs | Mean nominal controller minus reference support, MVAr | Controller lower / reference lower / equal |','|---|---:|---:|---|']
    for method in ['D-SE','HG-SE']:
        d=reference['available_reference_subset_comparisons'][method]
        lines.append('| '+method+' | '+str(d['available_same_band_pairs'])+' | '+fmt(d['mean_controller_minus_reference_nominal_support_mvar'])+' | '+str(d['controller_lower_support_cases'])+' / '+str(d['reference_lower_support_cases'])+' / '+str(d['equal_support_cases'])+' |')
    lines+=['\nThese differences compare nominal support only where both endpoints satisfy the same finite-voltage, scheduled-load-service, strict-UV, and disclosed upper-band diagnostic checks. They are descriptive differences from a local continuous endpoint search, not optimality gaps. The relaxed continuous/all-bus endpoint may be unreachable under the discrete 25-action controller and its progress gates; a controller can also beat an unsuccessful local optimizer without proving global optimality. Realized voltage-dependent reactive injections remain separately reported.\n',
            'All local reference computation, including failed cases and fresh endpoint probes: `'+json.dumps(reference['local_actual_costs_including_failed_cases'],sort_keys=True)+'`. Warm-start DFF work is charged once in the case ledger. CPU solver times and the previous GPU DFF times are separate and do not establish a matched-hardware speedup.\n',
            'The reference status ledger and paired availability list are retained in `ac_reference_controller_comparison_summary.json` and `ac_reference_controller_comparison.csv`; the complete architecture evidence is in `central_matched_summary.json`, `central_matched_paired_ledger.csv`, and the independent central physical replays. The primary main-bank HG-SE/D-SE conclusion remains unchanged by these secondary comparisons.\n']
    return '\n'.join(lines)
