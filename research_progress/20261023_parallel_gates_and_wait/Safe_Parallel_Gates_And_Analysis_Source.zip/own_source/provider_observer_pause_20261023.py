"""Keep original commitment tracing, exclude nested provider implementation.

No source local, return value, model, physics, action or budget is changed.
Existing trace bindings on the caller stack are restored even on exceptions.
This is prepared for future owners only, never injected into a live study.
"""
import functools,sys

def without_nested_observer(provider):
    @functools.wraps(provider)
    def observed(*args,**kwargs):
        original=sys.gettrace()
        if original is None:return provider(*args,**kwargs)
        frames=[];frame=sys._getframe()
        while frame is not None:
            if frame.f_trace is not None:frames.append((frame,frame.f_trace,frame.f_trace_lines,frame.f_trace_opcodes))
            frame=frame.f_back
        sys.settrace(None)
        try:return provider(*args,**kwargs)
        finally:
            sys.settrace(original)
            for frame,trace,lines,opcodes in frames:
                frame.f_trace=trace;frame.f_trace_lines=lines;frame.f_trace_opcodes=opcodes
    return observed
