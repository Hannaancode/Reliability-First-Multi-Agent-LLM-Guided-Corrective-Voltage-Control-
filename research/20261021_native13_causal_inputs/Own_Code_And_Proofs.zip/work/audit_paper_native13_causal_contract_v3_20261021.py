"""Independent saved-packet/input audit. Zero model, PF or optimizer calls."""
import ast
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/paper_native13_causal_contract_v3_20261021'
O = P / 'independent_input_audit'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    started = time.monotonic()
    admission = read(P / 'Software_Input_Admission.json')
    assert admission['status'] == 'PASS_ALL500_CAUSAL_INITIAL_INPUT_AND_POSITIVE_LITERAL_NATIVE_ROLE_SOFTWARE_ONLY'
    for name, digest in admission['source_hashes'].items():
        assert sha(R / name) == digest
    root_name = 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json'
    numeric_pin = read(R / 'outputs/public13_matched_numeric_preparation_20261021/Protocol.json')['source_and_input_hashes'][root_name]
    assert sha(R / root_name) == numeric_pin == admission['source_roots_sha256']
    roots = read(R / root_name)['roots']
    frames = read(P / 'All500_Initial_Causal_Frames.json')
    contracts = read(P / 'All500_Physical_Role_Contracts.json')
    assert len(frames) == len(contracts) == len(roots) == 500
    # Verify the allowed source parser transformation independently as AST text.
    source = R / 'work/e/audit/phase2g_rescue_runner.py'
    node = next(n for n in ast.parse(source.read_text(encoding='utf-8')).body
                if isinstance(n, ast.FunctionDef) and n.name == 'normalize_action')
    original_hash = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
    removed = []
    for loop in [n for n in ast.walk(node) if isinstance(n, ast.For)]:
        remaining = []
        for stmt in loop.body:
            text = ast.unparse(stmt)
            if text in ['q = round(q / 25.0) * 25.0', 'q = max(25.0, min(300.0, q))']:
                removed.append(text)
            else:
                remaining.append(stmt)
        loop.body = remaining
    assert len(removed) == 2
    adapted_hash = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
    assert admission['parser_AST_adaptation']['original_AST_sha256'] == original_hash
    assert admission['parser_AST_adaptation']['adapted_AST_sha256'] == adapted_hash
    counts = {'MODEL_INPUT_AVAILABLE': 0, 'EMPTY_ACTUATOR_ZONE_NO_MODEL_CALL': 0,
              'PAPER_UV_STOP_NO_MODEL_CALL': 0}
    tokens = 0
    max_tokens = 0
    prefix_keys = {'zone', 'round', 'local_current_VM_pu', 'global_current_UV_pu',
                   'native_recipients', 'causal_feedback'}
    for seed, (root, row, cr) in enumerate(zip(roots, frames, contracts)):
        assert seed == root['seed'] == row['administrative_seed_NOT_in_prompt'] == cr['seed']
        assert row['source_NET'] == root['path'] and row['source_NET_sha256'] == root['sha256'] == cr['source_NET_sha256']
        frame, contract = row['frame'], cr['contract']
        assert frame == {'round': 0, 'current_VM': root['all13_initial_vm'],
                         'current_Q_Mvar': root['initial_control_Q'], 'causal_request_history': []}
        assert contract == contracts[0]['contract']
        assert sorted(b for members in contract['zones'].values() for b in members) == list(range(13))
        assert sorted(b for devices in contract['allowed'].values() for b in devices) == [2, 7, 9]
        assert contract['roots'] == [0, 2, 7, 9] and contract['absolute_Q_cap'] is None
        assert len(row['packets']) == 4
        uv = {str(i): value for i, value in enumerate(root['all13_initial_vm']) if value < .95}
        for zone, packet in zip(contract['zones'], row['packets']):
            assert packet['zone'] == zone
            allowed = contract['allowed'][zone]
            expected = ('PAPER_UV_STOP_NO_MODEL_CALL' if not uv else
                        'EMPTY_ACTUATOR_ZONE_NO_MODEL_CALL' if not allowed else 'MODEL_INPUT_AVAILABLE')
            assert packet['disposition'] == expected
            counts[expected] += 1
            if expected != 'MODEL_INPUT_AVAILABLE':
                assert packet['messages'] is None
                continue
            messages = packet['messages']
            assert len(messages) == 2 and [m['role'] for m in messages] == ['system', 'user']
            state = json.loads(messages[1]['content'].split('CURRENT_CAUSAL_OBSERVATION:\n')[1])
            assert set(state) == prefix_keys and state['zone'] == zone and state['round'] == 0
            assert state['local_current_VM_pu'] == {str(b): root['all13_initial_vm'][b] for b in contract['zones'][zone]}
            assert state['global_current_UV_pu'] == uv and state['causal_feedback'] == []
            assert [a['bus'] for a in state['native_recipients']] == allowed
            for device in state['native_recipients']:
                index = [2, 7, 9].index(device['bus'])
                assert set(device) == {'bus', 'current_Q_Mvar', 'maximum_positive_increment_Mvar'}
                assert device['current_Q_Mvar'] == root['initial_control_Q'][index]
                assert device['maximum_positive_increment_Mvar'] == 0.30000001192092896
            ids = packet['actual_input_ids']
            assert len(ids) == packet['input_tokens'] and all(type(v) is int for v in ids)
            assert len(ids) + 384 <= 8192
            max_tokens = max(max_tokens, len(ids))
            tokens += len(ids)
    assert counts == admission['input_dispositions'] and max_tokens == admission['maximum_actual_input_tokens']
    O.mkdir(exist_ok=False)
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_SAVED_ALL500_INPUT_SOURCE_ANCHORS_CAUSAL_SCOPE_NAMESPACE_AND_DISPOSITIONS_ONLY',
              'cases': 500, 'zone_frames': 2000, 'dispositions': counts,
              'retained_input_token_ID_count': tokens, 'maximum_actual_input_tokens': max_tokens,
              'source_parser_only_two_declared_assignments_removed': True,
              'admission_sha256': sha(P / 'Software_Input_Admission.json'),
              'all500_frames_sha256': sha(P / 'All500_Initial_Causal_Frames.json'),
              'all500_contracts_sha256': sha(P / 'All500_Physical_Role_Contracts.json'),
              'reader_source_sha256': sha(Path(__file__)),
              'new_model_PF_conversion_derivative_LP_optimizer_GPU_calls': 0,
              'audit_seconds': time.monotonic() - started,
              'scope_limit': 'Saved inputs and literal action contract, not full controller, model behavior, independently retokenized sequences, persistent process recovery, physical performance, or superiority.'}
    with (O / 'Independent_Input_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
