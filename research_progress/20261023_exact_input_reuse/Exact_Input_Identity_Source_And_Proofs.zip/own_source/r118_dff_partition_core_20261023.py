"""New missing-only study: unchanged control, exact solver-input receipt reuse."""
from r118_dff_missing_continuation_core_20261023 import *
from r118_dff_missing_continuation_core_20261023 import Registry as StrictRegistry
from reflection118_remaining_cases_core_20261023 import complete_dff_receipts

P=R/'outputs/r118_dff_partition_continuation_preparation_20261023'
E=R/'outputs/r118_dff_partition_continuation_execution_20261023'
A=R/'outputs/r118_dff_partition_continuation_independent_20261023'

def current_receipts():
    rows=complete_dff_receipts()
    d=R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023'
    assert read(d/'Independent_Audit.json')['status'].startswith('PASS_EXACT_ARGUMENTS')
    rec=read(d/'Mapped_Receipt.json')
    rows.append(dict(directory=d,source=(d/'Mapped_Receipt.json').relative_to(R).as_posix(),source_sha256=sha(d/'Mapped_Receipt.json'),before=rec['before'],after=rec['after'],kwargs=rec['kwargs'],exception=None))
    return rows

class Registry(StrictRegistry):
    def __init__(self,receipts,proof_directory=None):
        super().__init__(receipts)
        self.proof_directory=proof_directory or E/'solver_input_identity'
        self.preparation_costs=dict(native_input_attempts=0,native_input_returns=0,source_result_extractions=0,native_algorithm_invocations=0,identity_receipts=0,proof_bytes=0,seconds=0.)
    def lookup(self,net,kwargs):
        try:return super().lookup(net,kwargs)
        except BaseException as stopped:
            allowed=('PRIOR_NECESSARY_COMPONENT_COLLISION_NO_CALL:','PRIOR_EXACT_INPUT_WITH_UNRECOVERED_OR_OTHER_CONTRACT_NO_CALL:')
            if not str(stopped).startswith(allowed):raise
            candidates=self.items.get(self.key(net),[])
            for item in candidates:
                if item['kwargs']!=kwargs or item['after'] is None or item['exception'] is not None:continue
                before=saved_net(item['directory'],item['before']);paid=saved_net(item['directory'],item['after'])
                try:
                    import pandas as pd
                    for name,value in net.items():
                        if isinstance(value,pd.DataFrame) and name!='shunt' and not str(name).startswith('res_'):
                            pd.testing.assert_frame_equal(value,before[name],check_exact=True)
                except (AssertionError,KeyError,ValueError):continue
                # Freeze the first qualifying reference before its preparation
                # outcome. No alternative reference, epsilon or solver rescue
                # is tried if exact source argument identity does not hold.
                self.proof_directory.mkdir(parents=True,exist_ok=True)
                number=self.preparation_costs['identity_receipts'];d=self.proof_directory/f'identity_{number:05d}';d.mkdir(exist_ok=False)
                put(d/'Reservation.json',dict(reference=item['source'],reference_sha256=item['source_sha256'],kwargs=kwargs,source_sha256=sha(__file__),new_nonlinear_calls_allowed=0))
                target=capsule(d/'Target_Before.zlib',net);self.preparation_costs['proof_bytes']+=target['bytes']
                from native_solver_input_identity_v3_20261023 import native_input_prefix,assert_solver_input_identity,map_paid_return
                tick=time.perf_counter();self.preparation_costs['native_input_attempts']+=1
                newargs=native_input_prefix(copy.deepcopy(net),kwargs);self.preparation_costs['native_input_returns']+=1
                n=capsule(d/'New_Native_Arguments.zlib',newargs);self.preparation_costs['proof_bytes']+=n['bytes']
                self.preparation_costs['native_input_attempts']+=1
                oldargs=native_input_prefix(copy.deepcopy(before),kwargs);self.preparation_costs['native_input_returns']+=1
                o=capsule(d/'Old_Native_Arguments.zlib',oldargs);self.preparation_costs['proof_bytes']+=o['bytes']
                assert_solver_input_identity(newargs,oldargs)
                mapped=map_paid_return(newargs,paid);self.preparation_costs['source_result_extractions']+=1
                frames_equal(mapped,net)
                import numpy as np
                assert np.array_equal(mapped.res_bus.vm_pu.values,paid.res_bus.vm_pu.values) and np.array_equal(mapped.res_bus.va_degree.values,paid.res_bus.va_degree.values)
                out=capsule(d/'Mapped_After.zlib',mapped);self.preparation_costs['proof_bytes']+=out['bytes']
                self.preparation_costs['identity_receipts']+=1;self.preparation_costs['seconds']+=time.perf_counter()-tick
                put(d/'Receipt.json',dict(receipt_type='DERIVED_FROM_EXACT_NATIVE_SOLVER_ARGUMENT_IDENTITY_NOT_NEW_PF',reference={k:v for k,v in item.items() if k!='directory'},reference_directory=item['directory'].relative_to(R).as_posix(),before=target,after=out,new_native_arguments=n,old_native_arguments=o,kwargs=kwargs,exception=None,native_solver_invocations=0))
                return mapped,None,dict(kind='EXACT_NATIVE_SOLVER_INPUT_IDENTITY_REUSE_NOT_NEW_PF',source=(d/'Receipt.json').relative_to(R).as_posix(),source_sha256=sha(d/'Receipt.json'),old_paid_query=item['source'],additional_preparation_paid=True)
            raise stopped
