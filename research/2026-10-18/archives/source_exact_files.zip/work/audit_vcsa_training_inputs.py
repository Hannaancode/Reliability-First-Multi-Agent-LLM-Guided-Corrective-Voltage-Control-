"""Streaming input/provenance audit. Zero model, GPU, or solver calls.

Local measurements are indexed as observations, never asserted to be complete
physical states. Outputs are additive and exclusive; frozen inputs are read-only.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, time, zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/vcsa_development/t0_input_audit'

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write(name, value):
    with (OUT/name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')

def signature(scenario):
    # Same comparison contract as the recovered overlap audit, without metadata.
    mods = []
    for raw in scenario['modifications']:
        item = dict(raw)
        for k, value in item.items():
            if isinstance(value, list):
                item[k] = sorted(value)
        mods.append(item)
    return digest({'system': scenario['system'],
                   'modifications': sorted(mods, key=canonical)})

def main():
    start = time.monotonic()
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT/'audit.claim').open('x') as f:
        f.write(str(os.getpid()))
    source_manifest = ROOT/'outputs/llm_value_development/VAC_LoRA_Training_Manifest.json'
    provenance = read(source_manifest)
    recovered = read(ROOT/'outputs/recovered_training_provenance_assets.json')
    splits = read(Path(provenance['split_map']))
    split_keys = {'train': 'train_ids', 'validation': 'val_ids', 'test': 'test_ids'}
    expected_counts = {'train': 16000, 'validation': 2000, 'test': 2000}
    archive = Path(provenance['source_archive'])
    assert sha(archive) == provenance['source_archive_sha256']
    assert recovered['archive_sha256'] == provenance['source_archive_sha256']
    archived_checks = {}
    with zipfile.ZipFile(archive) as z:
        archive_members = [{'name': i.filename, 'bytes': i.file_size, 'crc': i.CRC}
                           for i in z.infolist() if not i.is_dir()]
        for member, spec in recovered['files'].items():
            h = hashlib.sha256()
            with z.open(member) as f:
                for chunk in iter(lambda: f.read(1024*1024), b''):
                    h.update(chunk)
            local = ROOT/spec['extracted_path'].replace('\\', '/')
            assert h.hexdigest() == spec['sha256'] == sha(local)
            archived_checks[member] = {'sha256': h.hexdigest(), 'bytes': local.stat().st_size}
    split_sets = {s: set(splits[key]) for s, key in split_keys.items()}
    assert all(not split_sets[a] & split_sets[b] for a in split_sets for b in split_sets if a != b)
    scenarios = {p.stem: read(p) for p in (ROOT/'work/e/pack/scenarios/federation').glob('*.json')}
    scenario_hashes = {sid: signature(s) for sid, s in scenarios.items()}
    scenario_file_hashes = {sid: sha(ROOT/f'work/e/pack/scenarios/federation/{sid}.json') for sid in scenarios}
    all_archive_sids = set().union(*split_sets.values())
    assert all_archive_sids <= scenarios.keys()
    bank = {p.stem: signature(read(p)) for p in (ROOT/'work/e/bank/scenarios').glob('*.json')}
    stage3 = read(ROOT/'outputs/llm_value_stage3_development/protocol.json')
    stage3_signatures = {c['scenario_id']: scenario_hashes[c['scenario_id']] for c in stage3['scenarios']}
    indices, reports, observation_sets = {}, {}, {}
    for label, spec in provenance['files'].items():
        path = Path(spec['path'])
        assert sha(path) == spec['sha256']
        records = Counter()
        fields = Counter()
        assistant_fields = Counter()
        verdicts = Counter()
        actions = Counter()
        obs_index = {}
        reply_index = defaultdict(set)
        local_by_scenario_zone = defaultdict(set)
        candidate_fields = Counter()
        numeric_variants = defaultdict(set)
        parse_errors = []
        rows = 0
        for line_number, line in enumerate(path.open(encoding='utf-8'), 1):
            if not line.strip(): continue
            rows += 1
            row = json.loads(line)
            try:
                users = [m['content'] for m in row['messages'] if m['role'] == 'user']
                replies = [m['content'] for m in row['messages'] if m['role'] == 'assistant']
                assert len(users) == len(replies) == 1
                obs = json.loads(users[0]); reply = json.loads(replies[0])
                sid, zone = obs['scenario_id'], obs['zone']
                assert sid in split_sets[label]
                measurements = obs['local_measurements']
                assert isinstance(measurements['bus_voltages'], dict)
                obs_hash = digest({'scenario_id': sid, 'zone': zone, 'local_measurements': measurements})
                measurements_hash = digest(measurements)
                full_obs_hash = digest(obs)
                fields.update(obs.keys()); assistant_fields.update(reply.keys())
                records[sid] += 1
                local_by_scenario_zone[(sid, zone)].add(measurements_hash)
                reply_index[obs_hash].add(digest(reply))
                numeric_variants[sid].add(measurements_hash)
                for k in obs:
                    if any(term in k.lower() for term in ['candidate', 'trajectory', 'step', 'solver', 'counterfactual']):
                        candidate_fields[k] += 1
                verdicts[str(reply.get('verification', {}).get('verdict'))] += 1
                action = reply.get('proposed_action', '__MISSING__')
                actions['none' if action is None else 'missing' if action == '__MISSING__' else 'non_null'] += 1
                entry = obs_index.setdefault(obs_hash, {
                    'scenario_id': sid, 'zone': zone, 'local_measurements_sha256': measurements_hash,
                    'observation_sha256': full_obs_hash, 'first_line': line_number, 'record_count': 0,
                    'scenario_file': f'work/e/pack/scenarios/federation/{sid}.json',
                    'scenario_file_sha256': scenario_file_hashes[sid],
                    'physical_modification_sha256': scenario_hashes[sid]})
                entry['record_count'] += 1
            except (AssertionError, KeyError, TypeError, ValueError) as exc:
                parse_errors.append({'line': line_number, 'type': type(exc).__name__})
        assert rows == expected_counts[label] == spec['records']
        physical = {scenario_hashes[sid] for sid in records}
        indices[label] = obs_index
        observation_sets[label] = set(obs_index)
        reports[label] = {
            'records': rows, 'scenario_ids': len(records), 'scenario_id_record_counts': dict(records),
            'unique_physical_scenario_signatures': len(physical),
            'unique_local_observations': len(obs_index),
            'observations_with_multiple_distinct_replies': sum(len(v)>1 for v in reply_index.values()),
            'scenario_zone_pairs': len(local_by_scenario_zone),
            'scenario_zone_pairs_with_multiple_measurement_vectors': sum(len(v)>1 for v in local_by_scenario_zone.values()),
            'top_level_observation_fields': dict(fields), 'assistant_fields': dict(assistant_fields),
            'explicit_candidate_or_trajectory_fields': dict(candidate_fields),
            'recorded_actions': dict(actions), 'recorded_verdicts': dict(verdicts),
            'parse_errors': parse_errors, 'sha256': sha(path),
            'bank_physical_overlap_count': len(physical & set(bank.values())),
            'stage3_physical_overlap': sorted(sid for sid,h in stage3_signatures.items() if h in physical),
        }
        assert not parse_errors
        assert not reports[label]['bank_physical_overlap_count']
    physical_split_overlaps = {}
    for a,b in [('train','validation'),('train','test'),('validation','test')]:
        left={scenario_hashes[sid] for sid in split_sets[a]}
        right={scenario_hashes[sid] for sid in split_sets[b]}
        physical_split_overlaps[a+'__'+b] = sorted(left & right)
    assert all(not values for values in physical_split_overlaps.values())
    contradictions = {
        'previous_manifest_claim': provenance.get('exact_recovered_historical_overlap'),
        'actual_all_archive_scenarios_are_recovered_historical_files': True,
        'actual_train_stage3_overlap': reports['train']['stage3_physical_overlap'],
        'interpretation': 'Archived train states overlapping inspected historical study cases are training/development. Do not claim zero historical overlap or unused confirmation.'}
    summary = {
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'input_audit_complete_physical_reconstruction_gate_pending',
        'split_counts': {s:len(v) for s,v in split_sets.items()}, 'splits': reports,
        'physical_split_overlaps': physical_split_overlaps,
        'record_observation_split_overlap_counts': {a+'__'+b: len(observation_sets[a]&observation_sets[b]) for a,b in [('train','validation'),('train','test'),('validation','test')]},
        'physical_state_identity_limit': 'Local prompt measurements are partial observations, not full networks or complete trajectories. Reconstruction must be replayed from saved scenario plus frozen network and independently matched before candidate labeling.',
        'previous_manifest_correction': contradictions,
        'new_model_calls': 0, 'new_PF_calls': 0, 'allocations': 0,
        'elapsed_seconds': time.monotonic()-start,
        'archive_sha256': sha(archive), 'source_manifest_sha256': sha(source_manifest),
        'audit_program_sha256': sha(Path(__file__)),
        'frozen_network_sha256': sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'),
        'archived_crc_and_extracted_hash_checks': archived_checks,
        'source_archive_members': archive_members,
    }
    write('unique_local_observation_index.json', indices)
    write('summary.json', summary)
    manifest={n:{'sha256':sha(OUT/n),'bytes':(OUT/n).stat().st_size}
              for n in ['summary.json','unique_local_observation_index.json']}
    write('manifest.json', manifest)
    print(json.dumps({k:summary[k] for k in ['status','split_counts','elapsed_seconds','new_model_calls','new_PF_calls']}))
    print(json.dumps({s:{k:reports[s][k] for k in ['records','unique_local_observations','scenario_zone_pairs_with_multiple_measurement_vectors','recorded_actions','stage3_physical_overlap']} for s in reports}))

if __name__ == '__main__':
    main()
