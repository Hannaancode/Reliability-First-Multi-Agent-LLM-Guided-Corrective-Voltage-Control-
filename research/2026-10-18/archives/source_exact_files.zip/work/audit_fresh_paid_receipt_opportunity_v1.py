"""New labelled software checks and separate no-PF audit of new receipts only."""
import ast
import copy
import json
import os
import time
from pathlib import Path
from prepare_fresh_paid_receipt_opportunity_v1 import ROOT, OUT as PRE, Q_GRID, canonical, exclusive_claim, now, sha, write
from run_fresh_paid_receipt_opportunity_v1 import ARMS, choose_query, estimated_score, interpolate, source_gate


def software_checks():
    checks = []
    legal = [{'bus': 0, 'Q_index': 0}, {'bus': 0, 'Q_index': 1}, {'bus': 1, 'Q_index': 0}]
    before = {'uv_count': 1, 'deficit_sum': .1, 'vmin': .85, 'vmax': 1.}
    priors = {(0, 0): {'uv_count': 1, 'deficit_sum': .04, 'vmin': .91, 'vmax': 1.02},
              (0, 1): {'uv_count': 1, 'deficit_sum': .01, 'vmin': .94, 'vmax': 1.04},
              (1, 0): {'uv_count': 1, 'deficit_sum': .03, 'vmin': .92, 'vmax': 1.03}}
    bad = {'uv_count': 1, 'deficit_sum': .09, 'vmin': .86, 'vmax': 1.08}
    receipt = [{'request': legal[0], 'response': {'mediated_verifier': {'converged': True, 'after': bad}}}]
    assert choose_query(legal, before, [.85, .9], priors, [], ARMS[0]) == legal[0]
    checks.append('low_voltage_then_original_Q_order')
    assert choose_query(legal, before, [.85, .9], priors, receipt, ARMS[1]) == legal[1]
    assert choose_query(legal, before, [.85, .9], priors, receipt, ARMS[2]) == legal[2]
    checks.append('only_returned_same_bus_residual_changes_next_query')
    zero_error = copy.deepcopy(receipt); zero_error[0]['response']['mediated_verifier']['after'] = priors[(0, 0)]
    assert choose_query(legal, before, [.85, .9], priors, zero_error, ARMS[2]) == legal[1]
    checks.append('returned_feedback_values_determine_correction')
    seen = [{'request': a, 'response': {}} for a in legal]
    assert choose_query(legal, before, [.85, .9], priors, seen, ARMS[2]) is None
    checks.append('no_repeated_or_non_native_action')
    assert interpolate([(25., .02), (50., .04)], 12.5) == .01
    assert interpolate([(25., .02)], 100.) == .02
    checks.append('declared_zero_anchor_interpolation_constant_extrapolation')
    assert estimated_score(before, {**priors[(0, 0)], 'vmax': 1.05000002}, 25.) == (-999,) * 5
    assert estimated_score(before, None, 25.) == (-999,) * 5
    checks.append('normal_band_and_UNKNOWN_forecast_handling')
    runner = ast.parse((ROOT / 'work/run_fresh_paid_receipt_opportunity_v1.py').read_text(encoding='utf8'))
    for node in runner.body:
        # Scientific imports only occur inside the explicitly authorized run.
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            module = node.module if isinstance(node, ast.ImportFrom) else node.names[0].name
            assert module not in ('pandapower', 'numpy', 'frozen_physics_loader', 'current_state_linearized_control_native_v3')
    calls = [ast.unparse(n.func) for n in ast.walk(runner) if isinstance(n, ast.Call)]
    assert not any('controller' in name or 'run_one_scenario' in name or name.endswith('run_dff_alt') for name in calls)
    assert 'sensitivity_at_observed_state' in calls and 'runner.rescue.verify_action' in calls
    assert 'v2.v0.run_pf' in calls and 'runner.rescue.r.run_pf' in calls and 'runner.rescue.apply_action' in calls
    checks.append('source_binds_real_original_functions_and_existing_Jacobian_without_controller_calls')
    definitions = [n for n in ast.walk(runner) if isinstance(n, ast.FunctionDef) and n.name == 'choose_query']
    names = {n.id for n in ast.walk(definitions[0]) if isinstance(n, ast.Name)}
    assert not names & {'closed', 'record', 'scenario', 'root_id', 'full_table', 'oracle'}
    checks.append('actor_function_has_no_administrator_table_or_world_ID_access')
    for name in ('work/prepare_fresh_paid_receipt_opportunity_v1.py', 'work/run_fresh_paid_receipt_opportunity_v1.py',
                 'work/audit_fresh_paid_receipt_opportunity_v1.py'):
        compile((ROOT / name).read_text(encoding='utf8'), name, 'exec')
    checks.append('all_three_new_sources_compile_without_execution')
    return {'all_passed': True, 'check_count': len(checks), 'labelled_software_checks': checks,
            'fixtures_are_not_physical_or_learning_evidence': True,
            'actual_full_current_observation_Jacobian_root_action_integration': 'UNTESTED'}


def run():
    started = time.perf_counter(); execution = PRE / 'execution'; output = PRE / 'receipt_audit'
    assert not output.exists(), 'Never restart an existing receipt audit owner'
    protocol = json.loads((PRE / 'Protocol.json').read_text(encoding='utf8')); source_gate(protocol)
    manifest = json.loads((execution / 'Closed_Manifest.json').read_text(encoding='utf8'))
    assert manifest['protocol_sha256'] == sha(PRE / 'Protocol.json')
    for name, expected in manifest['files'].items():
        assert sha(execution / name) == expected, name
    output.mkdir(); exclusive_claim(output / 'audit.claim', {'pid': os.getpid(), 'at_utc': now(), 'no_PF_or_forecast_or_solve': True})
    roots = json.loads((execution / 'All_Eight_Roots.json').read_text(encoding='utf8')); assert len(roots) == 8
    decisions = []; eligible = 0; invalid_nomination_count = 0; measured_model_allowances = []
    effects = {arm: [] for arm in ARMS[:2]}; positive = {arm: 0 for arm in ARMS[:2]}
    for root in roots:
        legal = root['legal_actions']; table = {(q['request']['bus'], q['request']['Q_index']): q for q in root['queries']}
        assert len(table) == len(root['queries'])
        replay = root['replay']; complete = (root['status'] == 'complete_fixed_root_table')
        expected_replays = (1 + sum('query_observation' in q for q in root['queries'])) if 'root_observation' in root else 0
        assert len(replay) == expected_replays
        replay_pass = len(replay) == expected_replays and all(r['status'] == 'PASS' for r in replay)
        is_eligible = (complete and replay_pass and root.get('stressed') is True and root.get('initially_normal_upper_protected') is True)
        eligible += int(is_eligible)
        row = {'root_id': root['root_id'], 'root_status': root['status'], 'eligible_protected_stressed_root': is_eligible,
               'all_healthy_invalid_partial_upper_unsafe_roots_retained': True, 'policies': {}}
        if 'root_observation' not in root or root['Jacobian']['status'] != 'finite_current_Jacobian_forecasts':
            for arm in effects:
                effects[arm].append([-1., 1.])
            row['status'] = 'UNKNOWN_no_supported_causal_policy_input'; decisions.append(row); continue
        current = root['root_observation']; before = current['global_metrics']
        frame = current['physical_tables']['res_bus']; col = frame['columns'].index('vm_pu')
        vm = {int(i): float(v[col]) for i, v in zip(frame['index'], frame['values'])}
        priors = {(p['bus'], p['Q_index']): p['metrics'] for p in root['Jacobian']['priors']}
        assert set(priors) == {(a['bus'], a['Q_index']) for a in legal}
        accepted = [q for q in root['queries'] if q.get('mediated_verifier', {}).get('accepted') is True
                    and q['mediated_verifier'].get('converged') is True]
        oracle = max((tuple(q['original_score']) for q in accepted), default=None)
        row['full_table_descriptive_best_score'] = oracle if complete else 'UNKNOWN_incomplete_table'
        row['optimistic_one_query_oracle_cost_seconds'] = (min(q['end_to_end_seconds'] for q in accepted if tuple(q['original_score']) == oracle)
                                                        if complete and oracle is not None else None)
        for arm in ARMS:
            policy_tick = time.perf_counter(); history = []
            for _ in range(min(8, len(legal))):
                request = choose_query(legal, before, vm, priors, history, arm)
                pair = (request['bus'], request['Q_index']); response = table[pair]
                # Only requested receipt fields enter the next actor call.
                exposed = {k: response[k] for k in ('status', 'mediated_verifier') if k in response}
                history.append({'request': request, 'response': exposed})
            selected = [table[(h['request']['bus'], h['request']['Q_index'])] for h in history
                        if table[(h['request']['bus'], h['request']['Q_index'])].get('mediated_verifier', {}).get('accepted') is True]
            nomination = max(selected, key=lambda q: tuple(q['original_score'])) if selected else None
            if nomination:
                valid = (nomination['mediated_verifier'].get('converged') is True and nomination['mediated_verifier']['after']['vmax'] <= 1.05 + 1e-8)
                invalid_nomination_count += int(not valid)
            policy_seconds = time.perf_counter() - policy_tick
            query_seconds = sum(table[(h['request']['bus'], h['request']['Q_index'])].get('end_to_end_seconds', 0.) for h in history)
            numerical_preparation = root['Jacobian']['seconds'] if arm != ARMS[0] else 0.
            known = complete and replay_pass and all(h['response'].get('status') == 'returned_original_verifier' for h in history)
            inclusion = (int(nomination is not None and tuple(nomination['original_score']) == oracle) if oracle is not None
                         else int(nomination is None)) if known else None
            row['policies'][arm] = {'query_trace': history, 'query_count': len(history), 'nomination': None if nomination is None else nomination['request'],
                'full_table_best_inclusion': inclusion, 'nomination_score': None if nomination is None else nomination['original_score'],
                'policy_arithmetic_seconds': policy_seconds, 'measured_selected_query_seconds': query_seconds,
                'numerical_preparation_seconds_charged': numerical_preparation,
                'known_tool_and_numerical_seconds': query_seconds + numerical_preparation + policy_seconds,
                'actual_committed_actions': 0, 'this_is_masked_descriptive_replay_of_NEW_paid_receipts': True}
        feedback = row['policies'][ARMS[2]]
        for arm in effects:
            static = row['policies'][arm]
            if feedback['full_table_best_inclusion'] is not None and static['full_table_best_inclusion'] is not None:
                change = feedback['full_table_best_inclusion'] - static['full_table_best_inclusion']
                effects[arm].append([change, change]); positive[arm] += int(change > 0)
            else:
                effects[arm].append([-1., 1.])
        if complete and replay_pass and feedback['query_count']:
            cheapest_static = min(row['policies'][arm]['known_tool_and_numerical_seconds'] for arm in ARMS[:2])
            allowance = (cheapest_static - feedback['known_tool_and_numerical_seconds']) / feedback['query_count']
            row['max_affordable_ADDITIONAL_model_seconds_per_query_decision'] = allowance
            measured_model_allowances.append(allowance)
        decisions.append(row)
    bounds = {arm: [sum(x[0] for x in values) / 8., sum(x[1] for x in values) / 8.] for arm, values in effects.items()}
    gate = (eligible >= 6 and invalid_nomination_count == 0 and
            all(bounds[arm][0] >= .05 and positive[arm] >= 3 for arm in effects))
    result = {'status': 'necessary_numerical_opportunity_screen_PASS' if gate else 'NOT_PASSED_stopped_or_UNKNOWN_support',
              'all_eight_equal_world_effect_bounds': bounds, 'positive_worlds_against_each_static': positive,
              'eligible_finite_initial_UV_normal_upper_complete_replayed_roots': eligible,
              'invalid_nomination_count': invalid_nomination_count, 'actual_committed_actions': 0,
              'conditional_planning_model_allowance_seconds_per_decision': 1.,
              'equal_world_mean_max_affordable_ADDITIONAL_model_seconds_per_decision':
                    sum(measured_model_allowances) / len(measured_model_allowances) if len(measured_model_allowances) == 8 else None,
              'model_cost_and_full_economics_gate': 'UNKNOWN_conditional_only_no_measured_LLM_final_training_preparation_N_workload',
              'these_controls_are_not_final_strong_trained_or_full_native_controls': True,
              'not_DSE_or_LLM_superiority_or_unused_confirmation': True, 'no_model_GPU_automatic_launch': True,
              'actual_new_PF_controller_model_native_forecast_solve_cloud_calls': 0,
              'audit_workflow_seconds_before_closure': time.perf_counter() - started,
              'protocol_sha256': sha(PRE / 'Protocol.json')}
    write(output / 'All_Eight_Receipt_Policy_Decisions.json', decisions)
    write(output / 'Decision_And_Cost_Bounds.json', result)
    source_gate(protocol)
    write(output / 'Closed_Manifest.json', {'source_sha256': protocol['source_sha256'], 'protocol_sha256': sha(PRE / 'Protocol.json'),
          'input_manifest_sha256': sha(execution / 'Closed_Manifest.json'),
          'files': {p.name: sha(p) for p in output.iterdir() if p.is_file() and p.name != 'Closed_Manifest.json'}})
    print(canonical(result))


if __name__ == '__main__':
    run()
