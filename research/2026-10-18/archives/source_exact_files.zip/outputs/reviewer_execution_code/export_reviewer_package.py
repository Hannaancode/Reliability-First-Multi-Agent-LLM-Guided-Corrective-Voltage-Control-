"""Curated, hash-verified research snapshot and a clean Colab notebook.

No credential/cache/venv files, external publishing, or replacement assets.
Final labeling requires complete matched, central, reference and physical data.
"""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,zipfile,shutil,time
from checkpoint_io import read_json_ready
from reviewer_completion_gates import completion_gates
from write_final_experiment_sections import completed_sections
root=Path('outputs');sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name):
    p=root/name
    return read_json_ready(p) if p.exists() else {}
main=load('main_campaign_detailed_audit.json');ac=load('ac_reference_controller_comparison_summary.json');central=load('central_matched_summary.json');dev=load('central_gpu_development_validation.json');cp=load('central_physical_replay/summary.json');phy=load('physical_replay_audit/overview.json');pres=load('execution_preservation_verification.json')
completion_evidence=completion_gates(root)
complete=completion_evidence['all_required_experimental_evidence_complete']
stamp=datetime.now(timezone.utc).isoformat();files={}
def add(path,name=None):
    p=Path(path)
    if p.is_file():
        for attempt in range(5):
            raw=p.read_bytes()
            try:
                if p.suffix=='.json':json.loads(raw)
                break
            except json.JSONDecodeError:
                if attempt==4:raise
                time.sleep(.25)
        files[name or p.as_posix()]=raw
sources=['frozen_physics_loader.py','dff_alt.py','run_matched_campaign.py','central_ablation.py','run_central_experiment.py','analyze_central_campaign.py','audit_central_checkpoints.py','validate_central_development.py','ac_shunt_reference.py','reference_endpoint_check.py','run_ac_reference_campaign.py','summarize_ac_reference_bank.py','compare_ac_reference.py','physical_replay_audit.py','summarize_trajectory_validity.py','physical_effort_ledger.py','analyze_family_pairs.py','analyze_main_closure.py','audit_training_bank_overlap.py','audit_effective_operating_points.py','audit_fixed_p_feasibility.py','audit_locked_topology.py','remote_environment_check.py','verify_execution_preservation.py','checkpoint_io.py','plot_confirmed_results.py','reviewer_completion_gates.py','write_final_experiment_sections.py','export_reviewer_package.py','write_reviewer_closure.py']
code=root/'reviewer_execution_code';code.mkdir(exist_ok=True)
for name in sources:
    p=Path('work')/name
    if p.exists():add(p);shutil.copy2(p,code/name)
for name in ['frozen_gpu_requirements.txt','frozen_dependency_closure.txt','uv_bootstrap_version.txt','historical_v4_results.json']:add(Path('work')/name)
for p in Path('work/e/audit').glob('*.py'):add(p)
add('work/e/pack/scripts/phase2d_iterative_blackboard_v0.py')
for folder in ['work/e/pack/testbeds','work/e/pack/scenarios/federation','work/e/bank','work/e/training_provenance']:
    for p in Path(folder).rglob('*'):
        if p.is_file() and p.suffix in ['.json','.jsonl']:add(p)
for p in Path('work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1').iterdir():
    if p.is_file():add(p)
for folder in ['matched_campaign','central_gpu_development','central_matched_campaign','physical_replay_audit','central_physical_replay','ac_reference_development','ac_reference_campaign']:
    for p in (root/folder).rglob('*'):
        if p.is_file() and p.suffix in ['.json','.pt']:add(p)
reports=['execution_input_manifest.json','frozen_input_verification.json','matched_campaign_protocol.json','matched_campaign_config.json','matched_campaign_family_analysis.json','matched_campaign_summary.json','main_campaign_detailed_audit.json','main_campaign_detailed_ledger.csv','physical_effort_ledger.csv','physical_trajectory_validity.json','fixed_p_feasibility_audit.json','locked_topology_audit.json','training_bank_physical_overlap.json','effective_operating_point_overlap.json','recovered_training_provenance_assets.json','execution_preservation_verification.json','dff_alt_development_validation.json','historical_replay_verification.json','historical_model_smoke_verification.json','base_repository_provenance.json','paired_analysis_protocol.json','central_ablation_development_checks.json','analysis_oracle_validation.json','central_gpu_development_validation.json','central_experiment_protocol.json','central_matched_summary.json','central_matched_paired_ledger.csv','ac_reference_campaign_protocol.json','ac_reference_development_validation.json','ac_reference_bank_summary.json','ac_reference_bank_ledger.csv','ac_reference_controller_comparison_summary.json','ac_reference_controller_comparison.csv','reporting_environment_versions.json']
for name in reports:add(root/name)
for name in ['central_recovery_provenance.json','central_recovery_resume_verification.json','central_recovery_execution.log','central_recovery_timing_sensitivity.json']:add(root/name)
if (root/'central_cpu_replay/integration_audit.json').exists():
    for name in ['integration_audit.json','input_manifest.json','staged_manifest.json','staged/central_cpu_replay/environment.json']:
        add(root/'central_cpu_replay'/name)
    add('work/integrate_central_cpu_replay.py')
for name in ['incremental_value_audit.json','Learned_Search_Diagnosis.md','Current_Result_Interpretation_Corrections.md']:
    add(root/'llm_value_development'/name)
if (root/'llm_value_development/incremental_value_audit.json').exists():add('work/audit_llm_incremental_value.py')
if (root/'central_recovery_provenance.json').exists():
    add('work/integrate_staged_central.py')
    add('work/analyze_central_recovery_sensitivity.py')
for name in ['isolated_cli_validation.json','isolated_gpu_execution_verification.json']:add(root/name)
# Match the main runner's actual expected progress/config locations.
add(root/'matched_campaign_progress.json','outputs/matched_campaign/progress.json')
add(root/'matched_campaign_config.json','outputs/matched_campaign/config.json')
captured_count=lambda folder:sum(n.startswith('outputs/'+folder+'/cases/') and n.endswith('.json') for n in files)
completion={'snapshot_at_utc':stamp,'experimental_campaigns_complete':complete,'main_cases':captured_count('matched_campaign'),'AC_cases':captured_count('ac_reference_campaign'),'central_cases':captured_count('central_matched_campaign'),'count_basis':'Actual captured case members, not a later live directory count','limitations':['No credentials, venvs, or model base cache included; immutable public base identity and weight hash recorded.','Original manuscript and archives remain untouched.','Central and full-reference claims require their complete ledgers.','The four-comment coverage is based on the supplied paraphrase, not verbatim reviewer correspondence.','While a campaign is active, reports are timestamped checkpoint snapshots; the captured case membership is authoritative for this working archive.']}
if complete:assert completion['main_cases']==completion['AC_cases']==completion['central_cases']==62
if (root/'central_recovery_provenance.json').exists():completion['limitations'].append('Central results retain 60 original pairs and two explicitly authorized RNG-checkpoint recovery executions on a fresh standard T4; original full remote log was unavailable. Recovery provenance, original-prefix preservation proof and timing sensitivity are included.')
files['outputs/EVIDENCE_SNAPSHOT.json']=json.dumps(completion,indent=2).encode()

def archive(path,payload):
    path=Path(path);temporary=path.with_suffix(path.suffix+'.tmp')
    manifest={n:{'sha256':sha(b),'bytes':len(b)} for n,b in payload.items()}
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in payload.items():
            assert not n.startswith(('/','\\')) and '..' not in Path(n).parts
            z.writestr(n,b)
        z.writestr('RESEARCH_FILE_MANIFEST.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None
        assert all(sha(z.read(n))==d['sha256'] and len(z.read(n))==d['bytes'] for n,d in manifest.items())
    temporary.replace(path)
    return {'archive_sha256':sha(Path(path).read_bytes()),'member_count':len(manifest)+1,'all_member_hashes_verified':True,'bytes':Path(path).stat().st_size}

inputs=root/'HierGrid_Reviewer_Execution_Inputs.zip';input_info=archive(inputs,files)
tree=ast.parse(Path('work/colab_environment_prepare.py').read_text());setup=next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='code' for t in n.targets) and isinstance(n.value,ast.Constant))
setup=setup[setup.index('os.chdir(root);'):].replace('uv==0.8.22','uv=='+Path('work/uv_bootstrap_version.txt').read_text().strip())
cells=[]
def md(text):cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(keepends=True)})
def py(text):cells.append({'cell_type':'code','metadata':{},'source':text.splitlines(keepends=True),'execution_count':None,'outputs':[]})
md('''# Frozen HierGrid reviewer execution

New clean orchestration, not the older reflection notebook. Original model, network, 62-case bank, numerical controls, and mature function sources stay frozen. Central historical development must pass before central locked execution. No security experiments run here.

Select a T4 runtime using your normal Google session. Upload the adjacent `HierGrid_Reviewer_Execution_Inputs.zip` when prompted. The existing CLI/ADC access is separate from browser login; no tokens or credential files belong in this notebook. Download complete case/RNG checkpoints before releasing the runtime.
''')
py("""import subprocess, torch, json
gpu = subprocess.run(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'], capture_output=True, text=True, check=True).stdout.strip()
assert torch.cuda.is_available() and 'T4' in gpu, 'Actual T4 GPU required before execution'
assert torch.tensor([1.,2.,3.], device='cuda').sum().item()==6.
print(json.dumps({'gpu':gpu,'cuda_verified':True}))
""")
py(f"""from google.colab import files
from pathlib import Path
import hashlib, zipfile, json, os
os.chdir('/content')
uploaded = files.upload()
assert 'HierGrid_Reviewer_Execution_Inputs.zip' in uploaded
archive = Path('/content/HierGrid_Reviewer_Execution_Inputs.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '{input_info['archive_sha256']}'
root = Path('/content/hiergrid_execution'); root.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    manifest = json.loads(z.read('RESEARCH_FILE_MANIFEST.json'))
    for name, entry in manifest.items():
        data=z.read(name); assert hashlib.sha256(data).hexdigest()==entry['sha256']
        target=(root/name).resolve(); assert target.is_relative_to(root.resolve())
        if target.exists(): assert hashlib.sha256(target.read_bytes()).hexdigest()==entry['sha256'], 'Existing research file differs; do not overwrite it'
        else: target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
os.chdir(root)
print('Original research inputs and checkpoint hashes verified')
""")
md('Restore Python 3.12.14 and the exact 111 recorded execution dependency versions. Bootstrap uv is a setup helper, not a controller dependency. Model/base-weight identities are verified; no training occurs.')
py('import sys,subprocess,shutil,os,json\n'+setup)
md('Historical central GPU validation: two pre-existing development cases outside the locked bank. The rule is frozen by source hash only after structural/physical execution checks pass; no performance tuning on the locked bank.')
py("""subprocess.run(['env/bin/python','work/run_central_experiment.py','--development','--resume'], check=True)
validation=json.loads(Path('outputs/central_gpu_development_validation.json').read_text())
assert validation['passed']
print('Historical GPU checks passed; central protocol frozen')
""")
md('Run the matched central/zonal bank with alternating branch order, original verifier/refinement/fallback, measured costs, and case/RNG resume guards. Preserve failures. The main HG-SE/D-SE campaign is already complete and is not rerun here.')
py("""assert json.loads(Path('outputs/central_gpu_development_validation.json').read_text())['passed']
subprocess.run(['env/bin/python','work/run_central_experiment.py','--locked','--resume'], check=True)
print('Central paired bank completed; export checkpoints before disconnecting')
""")
py("""import zipfile
destination=Path('/content/HierGrid_Central_Checkpoints.zip')
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
    for folder in ['outputs/central_gpu_development','outputs/central_matched_campaign']:
        for p in Path(folder).rglob('*'):
            if p.is_file():z.write(p,p.as_posix())
    for name in ['outputs/central_gpu_development_validation.json','outputs/central_experiment_protocol.json']:
        if Path(name).exists():z.write(name,name)
files.download(str(destination))
""")
notebook=root/'HierGrid_Reviewer_Execution.ipynb';notebook.write_text(json.dumps({'cells':cells,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'colab':{'provenance':[]},'accelerator':'GPU'},'nbformat':4,'nbformat_minor':5},indent=2))
for cell in cells:
    if cell['cell_type']=='code':compile(''.join(cell['source']),str(notebook),'exec')
for i,cell in enumerate(cells):cell['id']='hiergrid_'+str(i)
document=json.loads(notebook.read_text());document['cells']=cells;notebook.write_text(json.dumps(document,indent=2))
if complete:
    paper=root/'HierGrid_Revision_Sections.md';text=paper.read_text(encoding='utf-8');text=text.replace('**No central performance result is available yet.**','**Central experimental evidence is complete; see the final evidence appendix below.**').replace('**The full 62-case reference analysis is pending.**','**The full 62-case reference evidence is complete; see the final evidence appendix below.**').replace('They are not a final manuscript: central GPU execution and the remaining AC-reference cases are still outstanding.','All planned reviewer experiments are complete; these are experiment-backed replacement sections, not a claim of reviewer acceptance or a rebuilt full manuscript.')
    marker='\n## Completed central and reference evidence appendix\n'
    if marker in text:text=text.split(marker)[0]
    text=text.replace('Architecture and optimization conclusions must wait for their remaining experiments.','The completed secondary architecture and local optimization comparisons are reported in the evidence appendix below, with their conditional-model and relaxation limits.')
    text+=completed_sections(root);paper.write_text(text,encoding='utf-8')
for name in ['HierGrid_Revision_Sections.md','Experiment_Method_Justification.md']:add(root/name)
add(root/'Compute_Allocation_Plan.md')
# The live closure includes the package verification gate; embedding its pre-export
# version in a final archive would misleadingly keep step 10 open inside that ZIP.
if not complete:add(root/'Reviewer_Comment_Closure.md')
files['outputs/EXPERIMENTAL_COMPLETION_GATES.json']=json.dumps(completion_evidence,indent=2).encode()
for p in (root/'reviewer_figures').glob('*'):add(p)
add(notebook)
files['REPRODUCTION_README.md']=('''# HierGrid reviewer research snapshot

This is a curated snapshot of actual inputs, new orchestration, and saved results. Read outputs/EVIDENCE_SNAPSHOT.json for complete versus pending campaign counts. No credential files or base-model cache are included. Original archives remain in their original locations; hashes are recorded.

Use the adjacent clean Colab notebook with HierGrid_Reviewer_Execution_Inputs.zip for central GPU execution. Do not Run All on the old reflection notebook. A live GPU is not implied by CLI authentication. The canonical public base revision/weight hash and exact execution requirements are recorded.

Local CPU AC resume uses work/run_ac_reference_campaign.py under the previously verified numerical environment. It verifies the frozen protocol and skips only complete matching cases; unfinished intermediate solver work is recomputed. Full-bank comparison scripts refuse incomplete ledgers. Outcomes, failure flags and computation remain separate.

Work scripts are newly written wrappers/analyses around recovered mature functions. Read outputs/Experiment_Method_Justification.md and outputs/HierGrid_Revision_Sections.md for formulation limits. Cybersecurity is deliberately absent from this reviewer campaign.
''').encode()
name='HierGrid_Reviewer_Reproducibility.zip' if complete else 'HierGrid_Reviewer_Working_Snapshot.zip';info=archive(root/name,files)
manifest={'snapshot_at_utc':stamp,'experimental_campaigns_complete':complete,'package_file':name,**info,'execution_inputs':{'file':inputs.name,**input_info},'notebook_file':notebook.name,'notebook_cells_syntax_verified':True,'credentials_or_runtime_tokens_included':False,'case_counts':completion,'new_code_source_hashes':{n:sha((Path('work')/n).read_bytes()) for n in sources if (Path('work')/n).exists()}}
(root/'reviewer_reproducibility_package_manifest.json').write_text(json.dumps(manifest,indent=2));print('RESEARCH_PACKAGE_EXPORTED',name,'complete',complete,'members',info['member_count'],'bytes',info['bytes'],flush=True)
