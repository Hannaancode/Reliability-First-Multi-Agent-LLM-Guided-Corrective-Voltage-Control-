from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/RAG_metadata_publication_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8')
def main():
    assert not O.exists();O.mkdir()
    qa=R/'outputs/thesis_RAG_lineage_20261029/Final_Visual_And_Evidence_QA.json'
    q=json.loads(qa.read_text('utf-8'));assert q['pages']==133 and q['status'].startswith('PASS_')
    tasks=json.loads((R/'outputs/thesis_research_closure_20261028/Tasks.json').read_text('utf-8'));assert tasks['completed_requirement_count']==20
    members=['work/nerc_reference_metadata_broker_20261029.py','work/check_nerc_reference_metadata_broker_20261029.py','work/audit_nerc_reference_metadata_broker_20261029.py',
      'work/integrate_thesis_RAG_lineage_20261029.py','work/repair_RAG_lineage_thesis_layout_20261029.py','work/paginate_RAG_lineage_thesis_20261029.ps1','work/render_RAG_lineage_thesis_20261029.py','work/render_RAG_lineage_thesis_final_20261029.py','work/close_RAG_lineage_thesis_20261029.py','work/'+Path(__file__).name,
      'outputs/nerc_reference_metadata_broker_20261029/Protocol.json','outputs/nerc_reference_metadata_broker_20261029/Result.json','outputs/nerc_reference_metadata_broker_20261029/Independent_Saved_Output_Audit.json','outputs/nerc_reference_metadata_broker_20261029/Literature_And_Next_Decision.txt',
      'outputs/thesis_RAG_lineage_20261029/Preparation_Failure.json','outputs/thesis_RAG_lineage_20261029/Preserved_Failed_Builder.py','outputs/thesis_RAG_lineage_20261029/Integration_Record.json','outputs/thesis_RAG_lineage_20261029/Layout_Repair.json','outputs/thesis_RAG_lineage_20261029/Final_Visual_And_Evidence_QA.json','outputs/thesis_RAG_lineage_20261029/Visual_Review_Record.json']
    index=[]
    with zipfile.ZipFile(O/'Own_Code_And_Metadata_Proofs.zip','x',zipfile.ZIP_DEFLATED) as z:
        for rel in members:
            p=R/rel;b=p.read_bytes();assert not any(pattern.search(b.decode('utf-8-sig')) for pattern in SECRET),rel
            z.writestr(rel,b);index.append({'path':rel,'bytes':len(b),'sha256':sha(p)})
    with zipfile.ZipFile(O/'Own_Code_And_Metadata_Proofs.zip') as z:
        assert z.testzip() is None
        for e in index:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
    put(O/'Artifact_Index.json',{'members':index,'private_raw_or_complete_thesis_published':False,'complete_raw_backup':False})
    put(O/'Current_Progress.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'thesis_complete':20,'thesis_total':35,'all_six_final_goals':'OPEN','new_closed_task':'T14 documentation alternative only; causal retrieval unproven','thesis_pages':133,'tables':19,'figures':22,'references':37,'metadata_all98_entries':True,'response_checks':892,'loader_negative_checks':4,'saved_output_independent_audit':'PASS','T12_T13':'PARTIAL','new_model_PF_training_calls':0,'owned_scientific_jobs':[],'GPU_assignments':[],'waiting_timer':None})
    (O/'Thesis_Checklist.json').write_bytes((R/'outputs/thesis_research_closure_20261028/Tasks.json').read_bytes())
    (O/'Literature_And_Next_Decision.txt').write_bytes((R/'outputs/nerc_reference_metadata_broker_20261029/Literature_And_Next_Decision.txt').read_bytes())
    files=[]
    for p in sorted(O.iterdir()):
        b=p.read_bytes();files.append({'local':p.relative_to(R).as_posix(),'path':'research_progress/20261029_RAG_metadata/'+p.name,'bytes':len(b),'sha256':sha(p),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
    put(O/'Publication_Map.json',files);print(json.dumps({'files':len(files),'archive_members':len(index)}))
if __name__=='__main__':main()
