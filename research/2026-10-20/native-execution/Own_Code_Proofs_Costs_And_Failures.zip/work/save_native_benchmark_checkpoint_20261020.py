"""Save verified closed evidence and exact benchmark-first continuation state."""
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/native_benchmark_execution_handoff_20261020'

def read(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def main():
    OUT.mkdir(exist_ok=False)
    now = datetime.now(timezone.utc).isoformat()
    result = read('outputs/tpa_native_second_identity_engineering_20261020/Result.json')
    audit = read('outputs/tpa_native_second_identity_engineering_20261020/independent_audit/Independent_Audit.json')
    complete = read('outputs/tpa_native_second_identity_coordination_20261020/Completion.json')
    units = read('outputs/original_teacher_native_action_units_20261020/Results.json')
    unit_audit = read('outputs/original_teacher_native_action_units_20261020/independent_audit/Independent_Audit.json')
    assert audit['status'].startswith('PASS_') and complete['all_owned_scientist_reader_chains_ended']
    assert unit_audit['status'].startswith('PASS') and units['all3_literal_nonnull_teacher_actions_outside_even_conservative_native_caps']
    checkpoint = {
        'at_utc': now,
        'priority_order': ['G3', 'G2', 'G1', 'G4', 'G5', 'G6'],
        'all_six_final_goals': 'OPEN',
        'scientific_model_GPU_jobs': 'NONE; fresh exact source/command inventory found no owned Python actors',
        'timers_active': False,
        'TPA_native_engineering': {
            'identity': result['identity'], 'status': 'COMPLETE_INDEPENDENT_REPLAY_PASS',
            'before_UV': 108, 'after_UV': 77, 'before_OV': 0, 'after_OV': 0,
            'primary_PF_returns': 2, 'independent_PF_returns': 2,
            'actual_TPA_policy_attempts': 2, 'actual_TPA_policy_returns': 2,
            'cold_policy_exact': True, 'all_numeric_replay_field_delta': 0.0,
            'primary_workflow_seconds': result['workflow_seconds'],
            'reader_workflow_seconds': audit['workflow_seconds'],
            'evidence': 'outputs/tpa_native_second_identity_engineering_20261020/independent_audit/Independent_Audit.json',
            'interpretation': 'Published comparator engineering on second ordered author identity; not our model or aggregate benchmark win. CPU device/schema compatibility port, not historical CUDA byte reproduction.'},
        'first_author_identity': {
            'status': 'TERMINAL_PARTIAL_RETAINED_UNKNOWN_ACTION', 'root_UV': 66,
            'actual_PF_attempts_returns': [1, 1], 'actual_TPA_policy_attempts_returns': [1, 0],
            'learned_init_projection_executed': True,
            'cause': 'Missed encoder hard-coded CUDA ordinal after learned projection; no action returned.',
            'root_independent_physics_replay': 'NOT_YET_EXECUTED',
            'zero_science_partial_audit': 'outputs/tpa_native_one_step_engineering_v3_20261020/partial_audit/Independent_Partial_Audit.json',
            'no_scientific_retry': True},
        'finite_original_teacher_native_unit_gate': {
            'status': 'COMPLETE_INDEPENDENT_PASS_FINITE_SUPPORT_MISMATCH',
            'TRAIN_rows': 16000, 'nonnull_actions': 12118, 'null_actions': 3882,
            'all_nonnull_Q_Mvar': [25, 50, 75, 100, 150],
            'all3_native_caps_smaller_than_minimum_nonnull_label': True,
            'evidence': 'outputs/original_teacher_native_action_units_20261020/independent_audit/Independent_Audit.json',
            'interpretation': 'Literal existing teacher commands are incompatible with native inverter units. Not a universal limit on unseen LLM outputs. New native-inverter serving adaptation must be explicitly named; no hidden rescale/clip/shunt reinterpretation.'},
        'this_turn_actual_science_totals': {
            'PF_attempts': 5, 'PF_returns': 5, 'PF_exceptions': 0,
            'TPA_policy_attempts': 3, 'TPA_policy_returns': 2,
            'LLM_optimizer_backward_training_GPU_allocation_calls': 0,
            'setup_load_import_and_failure_costs': 'All separate original outputs/claims/stderr retained; no zero-forward claim for first partial.'},
        'next': [
            'Freeze explicitly named native signed-inverter contract and fixed current-only schema/unit screen for original trained LLM. No automatic GPU allocation or full benchmark launch.',
            'Prepare a source-bound strong centralized current-Jacobian numerical engineering reference on the second already verified root; reuse saved root, no repeated root solve. Same native absolute inverter caps and native L1+.1mean|Q| objective; model/information differences disclosed.',
            'If first-root current packet needs full independent physics certification, prospectively freeze one remaining independent replay, explicitly charged; never repeat its original model attempt.',
            'Only after causal input, loader/base, strict parser, full context, unit, ownership, preservation and strong control gates pass may a new fixed actual LLM native-interface study run. No prompt/seed/Q/budget rescue.',
            'Continue public benchmark with all120 original identities retained, missing/partial UNKNOWN; one engineering point is not a selected performance subset.'
        ],
        'current_GPU_access_evidence': 'Three authenticated/T4eligible/zeroassignment profiles at05:38UTC; fourth not found. No current free-hours/reset/lifetime promise.',
        'publication': {'previous_verified_head': 'c5db0b880aa81a702b73023267888d4349168db8', 'current_turn': 'PENDING_COMPACT_CODE_AND_PROOFS_LEASED_PUBLICATION'},
        'limits': 'Original DFF/DFF-ALT/unchanged DSE both branches and FULL BOTH plus model/training/preparation/failure costs remain required on original plant. No LLM/fullDSE/zero-all/security superiority achieved. All stopped/partial/UNKNOWN/frozen assets preserved.'
    }
    write(OUT / 'Checkpoint.json', checkpoint)
    write(OUT / 'Current_Resume.json', checkpoint)
    report = f'''# Native benchmark execution checkpoint

Saved {now}. All six final goals remain open; published-model benchmarking and public testing are first.

Before: an official published TPA checkpoint was preserved but not runnable. After: its real 322-bus observation, 38-agent policy, native inverter action, fresh cold model and two independent all-field physics replays pass on the second ordered author identity. UV108→77, OV0→0. This is the published comparator, not HierGrid superiority. Primary14.813s and reader13.859s include separate model/load/physics/setup work; no deployment speed claim.

Before: native command-unit compatibility was unresolved. After: all16000 original TRAIN rows were checked; all12118 nonnull commands are25–150Mvar and exceed every native inverter's possible action capacity on all3 public networks. Independent finite-support check passes. This is a reason to specify a genuine inverter adaptation, not evidence that a language model cannot emit unseen smaller values.

The first author case remains terminal partial: root66UV, one PF return, one model attempt with a learned projection but no returned action after a missed CUDA device call. Its source, costs and UNKNOWN action are retained. A zero-new-science partial audit passes; no independent root replay yet. No executed science was repeated and no failed case dropped. Across this turn:5PF returns,3TPA policy attempts/2returns,0LLM/optimizer/training/GPU allocations. All owners are ended, no timer.

Next: explicit native actuator/parser contract and strong current-Jacobian numerical reference engineering, then a fixed cheap actual-model interface gate only if its complete source/base/input/ownership/preservation gates pass. No raw TPA source or weight redistribution: inspected author tree has no license. No private notebook/model/manuscript publication.
'''
    (OUT / 'Results_And_Next_Decision.md').write_text(report, encoding='utf-8')
    tasks_path = ROOT / 'outputs/research_tasks_20261014/Tasks.json'
    tasks = read('outputs/research_tasks_20261014/Tasks.json'); tasks['at_utc'] = now
    for task in tasks['tasks']:
        if task['checklist_id'] in ('G3', 'G2'):
            task['status'] = 'PUBLISHED_TPA_NATIVE_ONE_STEP_ENGINEERING_INDEPENDENT_PASS_OUR_NATIVE_ROLE_PENDING'
            task['current_result'] = 'Official TPA CPU compatibility reference second author identity108to77UV/0OV; fresh cold action exact,4PF returns including independent replay. First author identity partial66UV,failed action retained UNKNOWN. Literal originalTRAINshunt commands incompatible with all3native inverter units; finite support independently verified. No our-model matched benchmark or superiority.'
            task['next'] = checkpoint['next'][0] + ' ' + checkpoint['next'][1]
            if not any(t['id'] == 'G3.2a' for t in task['subtasks']) and task['checklist_id'] == 'G3':
                task['subtasks'].append({'id': 'G3.2a', 'completed': True, 'description': 'Execute official pretrained TPA native observation/action/cold engineering and independent physics replay with failed first identity preserved.', 'evidence': checkpoint['TPA_native_engineering']['evidence'], 'verified_at_save': now})
    write(tasks_path, tasks)
    task_md = ROOT / 'RESEARCH_TASKS.md'
    text = task_md.read_text(encoding='utf-8')
    task_md.write_text(f'''## Latest benchmark execution — {now}

- [x] G3.2a: official TPA native 322-bus one-step/cold-model/independent physics engineering complete.108→77UV,0OV, second ordered identity; first partial retained UNKNOWN.
- [x] Finite native unit gate: all16000 original TRAIN rows checked; every nonnull25–150Mvar teacher command exceeds native inverter capacity on all3 public networks. This is not universal LLM impossibility.
- [ ] G3.2/G3.3/G2.4: explicit HierGrid native inverter role, strong equally informed controls and matched full public benchmark remain open.

All six final goals OPEN. Resume outputs/native_benchmark_execution_handoff_20261020/Current_Resume.json. No owned jobs/GPU/timer at this checkpoint.

''' + text, encoding='utf-8')
    header = f'''## Latest native published comparator execution — {now}

OfficialTPA322secondorderedauthoridentity108to77UV/0OV,exactcoldaction,4PFreturns includingtwoindependentreplays/allnumericdelta0,ninefrozenPASS. Firstauthoridentitypartial66UV/1PFreturn/onelearnedprojectionthenfailedCUDAmodelattempt/noactionretainedUNKNOWN;zero-sciencepartialauditPASS,no retry. All16000originalTRAINcommandunits independentlyaudited:all12118nonnull25to150Mvar exceedall3nativeinvertercaps;explicitnewinverteradaptationrequired,notuniversalLLMinability. Thisturn5PFreturns/3TPAattempts2returns/0LLMtrainingGPU. AllownersENDED/notimer,all6goalsOPEN,G3/G2first. Resume outputs/native_benchmark_execution_handoff_20261020/Current_Resume.json. Strongnativecontrol/actualLLMservingcontractpending;noaggregatebenchmark/superiorityclaim. Sources/failures/costs/frozenassets preserved.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md']:
        path = ROOT / rel; path.write_text(header + path.read_text(encoding='utf-8'), encoding='utf-8')
    for rel in ['outputs/notebook_reference_review_20261020/Current_Resume.json', 'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json', 'outputs/remaining_three_fixed_queries_20261019/verified_completion/Current_Resume_20261019.json']:
        path = ROOT / rel
        if path.exists():
            old = json.loads(path.read_text(encoding='utf-8'));old['latest_continuation_supersedes_operational_notes'] = 'outputs/native_benchmark_execution_handoff_20261020/Current_Resume.json';old['latest_continuation_at_utc'] = now;write(path, old)
    with (ROOT / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n\n' + report + '\n')
    print(json.dumps({'saved': str(OUT), 'all6finalgoals': 'OPEN', 'new_completed_engineering_subtask': 'G3.2a'}))

if __name__ == '__main__':
    main()
