"""One new bounded missing-only full native DFF continuation on ALL4 roots."""
import traceback
from r118_dff_missing_continuation_core_20261023 import *

def main():
    E.mkdir(exist_ok=False);began=time.monotonic()
    put(E/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    wait_ack(E,began);p=read(P/'Protocol.json');validate_pins(p)
    np,pp,v2,runner,reflection=setup()
    put(E/'Frozen_Original_Before.json',frozen_checks())
    from public_size_u61_preservation import journal
    assert runner.MAX_ITERATIONS==25
    registry=Registry(current_receipts());native=pp.runpp
    bindings=read(R/p['bindings']);base=pp.from_json(str(R/p['base_net']));zones=read(R/p['metadata'])['zones']
    costs=dict(new_PF_attempts=0,new_PF_returns=0,new_PF_exceptions=0,new_PF_seconds=0.,paid_initial_reuses=0,paid_return_reuses=0,paid_failure_reuses=0,cold_cached_reuses=0,new_model_optimizer_derivative_training_calls=0,binary_bytes=0)
    calls=[];results=[];failure=None;active={};previous='0'*64;next_id=0
    def event(kind,**fields):
        nonlocal previous
        row=dict(kind=kind,active=active,elapsed_seconds=time.monotonic()-began,previous=previous,**fields)
        previous=hashlib.sha256(canonical(row)).hexdigest();journal(E/'events.jsonl',dict(event=row,sha256=previous))
    def bound():
        if time.monotonic()-began>=p['science_seconds']:raise OperationalStop('FIXED_NEW_STUDY_TIME_BOUND_NO_EXTENSION')
        if costs['binary_bytes']+4*1024**2>p['binary_bytes']:raise OperationalStop('FIXED_BINARY_PRESERVATION_BOUND')
    def progress():
        tmp=E/'Status.pending';tmp.write_text(json.dumps(dict(active=active,complete_branches=len(results),closed_calls=len(calls),costs=costs,elapsed_seconds=time.monotonic()-began)),encoding='utf-8');os.replace(tmp,E/'Status.json')
    try:
        for binding in bindings:
            active=dict(case_id=binding['case_id'],committed_operations=0)
            directory=E/binding['case_id'];directory.mkdir()
            initial=True;branch_calls=[];commitments=[];first_gate=False
            root=net_value(pickle.loads((R/binding['solved_payload']).read_bytes()))
            saved_first=pickle.loads(zlib.decompress((R/p['first_commit_cursors']/(binding['case_id']+'_cold.zlib')).read_bytes()))
            random.seed(p['seed']);np.random.seed(p['seed'])
            def provider(net,**kwargs):
                nonlocal initial,next_id
                bound();identity=next_id;next_id+=1
                before=capsule(directory/f'call_{identity:06d}_before.zlib',net);costs['binary_bytes']+=before['bytes']
                exception=None;seconds=0.
                if initial:
                    assert kwargs==binding['solver_kwargs'];restore_exact(net,root);initial=False
                    provenance=dict(kind='PAID_ORIGINAL_INITIAL_REUSE',root_sha256=binding['payload_sha256']);costs['paid_initial_reuses']+=1
                else:
                    assert kwargs==p['solver_kwargs']
                    saved,exception,provenance=registry.lookup(net,kwargs)
                    if saved is not None:
                        restore_exact(net,saved)
                        costs['paid_return_reuses' if exception is None else 'paid_failure_reuses']+=1
                    else:
                        if not first_gate:raise OperationalStop('NO_NEW_PF_BEFORE_SOURCE_FIRST_COMMIT_GATE')
                        # Exclusive fsynced reservation plus full NET must exist
                        # before the sole native attempt. No retry path exists.
                        bound();event('NEW_NATIVE_ATTEMPT_RESERVED',identity=identity,before=before,directory=directory.relative_to(E).as_posix(),kwargs=kwargs,scope=provenance)
                        costs['new_PF_attempts']+=1;tick=time.perf_counter()
                        try:native(net,**kwargs);assert net.converged;costs['new_PF_returns']+=1
                        except Exception as exc:exception=dict(type=type(exc).__name__,message=str(exc));costs['new_PF_exceptions']+=1
                        seconds=time.perf_counter()-tick;costs['new_PF_seconds']+=seconds
                        provenance=dict(kind='NEW_NATIVE_ATTEMPT',coverage=provenance)
                after=capsule(directory/f'call_{identity:06d}_after.zlib',net);costs['binary_bytes']+=after['bytes']
                rec=dict(identity=identity,case_id=binding['case_id'],before=before,after=after,kwargs=kwargs,exception=exception,seconds=seconds,provenance=provenance)
                path=directory/f'call_{identity:06d}.json';put(path,rec)
                registry.add(directory,path,rec)
                ref=path.relative_to(E).as_posix();calls.append(ref);branch_calls.append(ref)
                event('NATIVE_CALL_CLOSED',identity=identity,record=ref,record_sha256=sha(path),exception=exception)
                if len(calls)%25==0:progress()
                if exception is not None:raise RuntimeError(failure_message(exception))
            def on_commit(state):
                nonlocal first_gate
                count=len(state['result']['executed_actions']);assert 1<=count<=25
                active['committed_operations']=count
                if count==1:
                    checkpoint_equal(state,saved_first);first_gate=True
                    event('SOURCE_FIRST_COMMIT_EXACT_PAID_PREFIX_GATE',remaining_operations=24,cached_prefix_calls=len(branch_calls))
                descriptor=capsule(directory/f'commit_{count:02d}.zlib',dict(source_frame=state,call_cursor=len(branch_calls),paid_query_registry_records=list(calls),costs=copy.deepcopy(costs),original_absolute_deadline=began+p['science_seconds'],source_protocol_sha256=sha(P/'Protocol.json')))
                costs['binary_bytes']+=descriptor['bytes'];cold=decode(directory,descriptor)
                checkpoint_equal(cold['source_frame'],state);assert cold['call_cursor']==len(branch_calls)
                commitments.append(descriptor);put(directory/f'commit_{count:02d}.json',dict(capsule=descriptor,call_cursor=len(branch_calls),metrics=state['result']['executed_actions'][-1]['post_metrics'],remaining_original_operations=25-count,persistent_NET_history_rng_cursor_cost_source_deadline_equal=True))
                event('SOURCE_COMMIT_CHECKPOINT',count=count,descriptor=descriptor,remaining_operations=25-count);progress()
            result=source_run(v2,runner,reflection,read(R/binding['registration']['recipe']),base,zones,provider,on_commit)
            assert first_gate and len(result['executed_actions'])==len(commitments)
            put(directory/'Result.json',result);put(directory/'Call_Order.json',dict(records=branch_calls,commitments=commitments))
            summary=reflection.summarize_result(result);summary['case_id']=binding['case_id'];summary['strict_final_OV']=result['final_metrics']['ov_count']
            results.append(summary);event('FULL_SOURCE_BRANCH_CLOSED',summary=summary);progress()
    except BaseException as exc:
        failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),active=active)
        put(E/'Failure.json',failure)
    finally:
        pp.runpp=native
        put(E/'Result.json',dict(status='COMPLETE_ALL4_ORIGINAL_DFF_REQUIRE_FIRST_NEW_RETURN_READER' if len(results)==4 and failure is None else 'TERMINAL_PARTIAL_REMAINDER_UNKNOWN_NO_RESTART',summaries=results,call_records=calls,costs=costs,failure=failure,active_at_end=active,all4_complete=len(results)==4,native_guard=1.06,strict_report_band=[.95,1.05],no_model_or_whole_DSE_superiority=True,workflow_seconds=time.monotonic()-began))
        put(E/'Frozen_Original_Checks.json',frozen_checks());progress()
        put(E/'Closed_Manifest.json',dict(members={f.relative_to(E).as_posix():sha(f) for f in E.rglob('*') if f.is_file()}))

if __name__=='__main__':main()
