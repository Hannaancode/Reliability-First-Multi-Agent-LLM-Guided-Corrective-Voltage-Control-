"""Extract the verified paid search callbacks without changing their equations."""
import ast,copy,hashlib,json,os,textwrap
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/receding_paid_engine_source_20261014';B.mkdir(exist_ok=False)
old=R/'work/bounded_paid_lookahead_physics_20261014.py'
new=R/'work/receding_paid_decision_engine_v1.py'
tree=ast.parse(old.read_text('utf-8'));worker=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worker')
selected=[];cert={}
for name in ['ensure','make_menu','query']:
    node=next(n for n in ast.walk(worker) if isinstance(n,ast.FunctionDef) and n.name==name)
    clone=copy.deepcopy(node)
    if name=='query':
        literals=[n for n in ast.walk(clone) if isinstance(n,ast.Constant) and n.value=='NEW_LOOKAHEAD_'];assert len(literals)==1
        literals[0].value='NEW_RECEDING_'
        inverse=copy.deepcopy(clone)
        next(n for n in ast.walk(inverse) if isinstance(n,ast.Constant) and n.value=='NEW_RECEDING_').value='NEW_LOOKAHEAD_'
        assert ast.dump(inverse,include_attributes=False)==ast.dump(node,include_attributes=False)
    else:assert ast.dump(clone,include_attributes=False)==ast.dump(node,include_attributes=False)
    cert[name]={'all_source_predicates_AST_unchanged':True,'only_change':'New receipt namespace literal' if name=='query' else None}
    selected.append(textwrap.indent(ast.unparse(clone),'        '))
header='''"""Verified source-derived paid decision engine, separately prospective runtime.

This module supplies no launch or automatic permission to use a model. Original
bounded search callbacks retain all physical, menu, cache and cost equations.
Caller owns durable history/checkpoint/absolute bounds and actual first commits.
"""
import copy,os,time
import numpy as np
from bounded_paid_lookahead_physics_20261014 import (load_after,build_current_domain,point_key,compile_current,
    forecast,order_all_current_forecasts,resource_eligible,action_key,build_verifier,action,receipt,
    common_accept,sha,runner if False else pp)
'''
# Explicit ordinary imports; no conditional import syntax or old main calls.
header=header.replace('common_accept,sha,runner if False else pp)','common_accept,sha)')
header+='from operation_aware_paid_lookahead_v1 import plan,MissingEvidence\nimport full_joint_suffix_benchmark_20261014 as prior\n\n'
prefix='''class PaidDecisionEngine:
    def __init__(self,*,out,evidence,runner,zones,cache,blocked,contexts,numeric_cost,history):
        self.out=out;self.evidence=evidence;self.runner=runner;self.zones=zones
        self.cache=cache;self.blocked=blocked;self.contexts=contexts;self.numeric_cost=numeric_cost
        self.history=history;self.saved_contexts=set();self.serial=0
    def decision(self,original,original_cursor,world,mode,decision):
        evidence=self.evidence;runner=self.runner;zones=self.zones;out=self.out
        cache=self.cache;blocked=self.blocked;contexts=self.contexts;numeric_cost=self.numeric_cost
        saved_contexts=self.saved_contexts;serial=self.serial
        context={'world':world,'method':mode,'decision':decision};nodes={};log=[];menus=[]
        branch={'attributed_query_PF_calls':0,'attributed_query_solver_seconds':0.,'cached_query_receipts':0,
                'new_query_PF_calls':0,'root_query_count':0,'second_query_count':0}
        root=f'{world}|{mode}|{decision}|ROOT'
        domain=build_current_domain(original,original_cursor,runner=runner,zones=zones)
        nodes[root]={'net':copy.deepcopy(original),'cursor':domain['expanded_cursor_for_separately_fixed_future_protocol']}
        root_refs=[]
'''
suffix='''
        result=plan(root,runner.rescue.grid_metrics(original),original_cursor['remaining_original_device_operation_slots'],
            lambda parent,slots:make_menu(parent,slots),lambda parent,slots,k:make_menu(parent,slots,k),query,mode=mode)
        if root_refs:
            evidence.event('complete_cached_root_menu_ACK',{**context,'records':root_refs});root_refs.clear()
        self.serial=serial
        report={**context,'root':root,'plan':result,'menus':menus,'query_messages':log,'attributed_costs':branch}
        self.history.append('complete_paid_receding_decision',report)
        # Nodes remain local actual paid NET/receipt handles, not a simulated
        # second leaf that the controller could mistake for a first commit.
        return {**report,'nodes':nodes,'resolve_paid_state':ensure}
'''
source=header+prefix+'\n'.join(selected)+suffix
ast.parse(source)
with new.open('x',encoding='utf-8') as f:f.write(source);f.flush();os.fsync(f.fileno())
proof={'at_utc':datetime.now(timezone.utc).isoformat(),'source':'work/bounded_paid_lookahead_physics_20261014.py',
    'source_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'new_source_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),
    'callback_AST_certificates':cert,'new_scientific_calls':0,'new_runtime_only':'Decision label/receipt namespace/durable history integration; no original scientist source modified.',
    'not_automatically_performance_ready':True}
with (B/'Verified_Callback_Extraction.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2);f.flush();os.fsync(f.fileno())
print(json.dumps({'three_verified_paid_callbacks_extracted':True,'equations_changed':False,'new_science_calls':0}))
