"""One bounded framework/cache setup, launched asynchronously by the owner."""
import json,shutil,subprocess,sys,time,zipfile
from pathlib import Path
ROOT=Path('/content/hiergrid_execution');ROOT.mkdir(exist_ok=True)
with zipfile.ZipFile('/content/public_size_input.zip') as z:
    for name in z.namelist():assert (ROOT/name).resolve().is_relative_to(ROOT.resolve())
    z.extractall(ROOT)
(ROOT/'prep/selected_arm.json').write_text(json.dumps({'arm':sys.argv[1]}))
from_path=ROOT/'outputs';from_path.mkdir(exist_ok=True)
began=time.monotonic();code=1;error=None
try:
    with (from_path/'public_size_setup.log').open('w') as log:
        version=(ROOT/'work/uv_bootstrap_version.txt').read_text().strip()
        def run(args):
            remaining=1750-(time.monotonic()-began);assert remaining>0
            subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=remaining)
        run([sys.executable,'-m','pip','install','--disable-pip-version-check','uv=='+version])
        uv=shutil.which('uv');assert uv
        run([uv,'python','install','3.12.14'])
        run([uv,'venv','--python','3.12.14','env'])
        for name in ['frozen_gpu_requirements.txt','frozen_dependency_closure.txt']:
            run([uv,'pip','install','--python','env/bin/python','--extra-index-url','https://download.pytorch.org/whl/cu128',
                 '--index-strategy','unsafe-best-match','-r','work/'+name])
        run([uv,'pip','install','--python','env/bin/python','--reinstall','--no-deps','--index','https://pypi.org/simple','torchao==0.17.0'])
        run(['env/bin/python','work/native13_lora_environment_check_v2_20261020.py'])
    code=0
except BaseException as exc:error=type(exc).__name__
out={'exit_code':code,'setup_process_ended':True,'failure_type':error,'seconds':time.monotonic()-began}
tmp=from_path/'public_size_setup_exit.tmp';tmp.write_text(json.dumps(out));tmp.replace(from_path/'public_size_setup_exit.json')
sys.exit(code)
