"""Full-bank standalone architecture comparison; no envelope substitution."""
from pathlib import Path
import json,hashlib,csv,math
from collections import Counter
import numpy as np
from analyze_family_pairs import family,SEED,REPLICATES
from frozen_physics_loader import load_stack
def analyze():
    root=Path('outputs');protocol=json.loads((root/'central_experiment_protocol.json').read_text());lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());expected={Path(n).stem:h for n,h in lock['scenario_file_sha256'].items()};paths=list((root/'central_matched_campaign/cases').glob('*.json'));assert {p.stem for p in paths}==set(expected),'Full central matched 62-case ledger required'
    assert protocol['analysis_source_sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'Central analysis source differs from frozen protocol'
    rows=[];groups={};promptfits=[];_,_,ref=load_stack();selection=Counter();diversity={m:Counter() for m in ['HG-VF','CENTRAL-VF']}
    for p in sorted(paths):
        d=json.loads(p.read_text());assert d['protocol']==protocol and d['scenario_sha256']==expected[p.stem]
        row={'scenario_id':p.stem,'family':family(p.stem),'valid_numerical_pair':d['paired_terminal_metrics_valid']}
        for name in ['HG-VF','CENTRAL-VF']:
            b=d['branches'][name];m=b.get('final_metrics') or {};own_valid=bool(b.get('base_converged') and m and all(isinstance(v,(int,float)) and math.isfinite(v) for v in m.values()));row[name+'_exception']=b.get('exception_type');row[name+'_finite_uv_clear_success']=bool(own_valid and m['uv_count']==0)
            if own_valid:
                for k in ['uv_count','deficit_sum','vmin','vmax']:row[name+'_'+k]=m[k]
                row[name+'_accepted_actions']=len(b['executed_actions']);row[name+'_nominal_support_mvar']=sum(abs(float(q)) for a in b['executed_actions'] for q in a['action']['add_shunts_q_mvar'].values())
            for k,v in d['costs'][name].items():row[name+'_'+k]=v
            per_iteration={}
            for log in b.get('logs',[]):
                info=log.get('llm_info')
                if not info:continue
                diversity[name]['parse_failures_final_reply']+=not info.get('parse_valid',False);diversity[name]['invalid_final_reply']+=not info.get('valid_action',False);diversity[name]['repair_calls']+=bool(info.get('reprompted'))
                item=per_iteration.setdefault(log['iteration'],{'buses':[],'accepted':0})
                if log.get('action'):item['buses']+=list(log['action']['add_shunts_q_mvar'])
                item['accepted']+=bool(log.get('verif',{}).get('accepted'))
            for item in per_iteration.values():
                diversity[name]['iterations']+=1;diversity[name]['valid_direct_proposals']+=len(item['buses']);diversity[name]['distinct_direct_bus_proposals']+=len(set(item['buses']));diversity[name]['duplicate_bus_proposals']+=len(item['buses'])-len(set(item['buses']));diversity[name]['physically_accepted_direct_proposals']+=item['accepted']
            if name=='CENTRAL-VF':
                for log in b.get('logs',[]):
                    fit=log.get('llm_info',{}).get('central_prompt')
                    if fit:promptfits.append(fit)
        baseline_path=root/'matched_campaign/cases'/p.name;baseline=json.loads(baseline_path.read_text());assert baseline['scenario_sha256']==expected[p.stem] and baseline['protocol_sha256']==protocol['parent_matched_protocol_sha256'];dff=baseline['branches']['DFF'];dm=dff.get('final_metrics') or {};row['valid_envelope_pair']=bool(d['paired_terminal_metrics_valid'] and dff.get('base_converged') and dm and all(isinstance(v,(int,float)) and math.isfinite(v) for v in dm.values()));row['source_DFF_case_sha256']=hashlib.sha256(baseline_path.read_bytes()).hexdigest()
        for env,name in [('HG-SE-ZONAL','HG-VF'),('HG-SE-CENTRAL','CENTRAL-VF')]:
            bm=d['branches'][name].get('final_metrics') or {};own_env_valid=bool(dff.get('base_converged') and dm and all(isinstance(v,(int,float)) and math.isfinite(v) for v in dm.values()) and d['branches'][name].get('base_converged') and bm and all(isinstance(v,(int,float)) and math.isfinite(v) for v in bm.values()));row[env+'_valid']=own_env_valid
            if own_env_valid:
                chosen=name if ref.choose_safety_envelope(ref.summarize_result(dff),ref.summarize_result(d['branches'][name]))=='reflection_v2' else 'DFF';b=dff if chosen=='DFF' else d['branches'][name];row[env+'_selected_branch']=chosen;selection[env+':'+chosen]+=1
                for k in ['uv_count','deficit_sum','vmin','vmax']:row[env+'_'+k]=b['final_metrics'][k]
                row[env+'_accepted_actions']=len(b['executed_actions']);row[env+'_nominal_support_mvar']=sum(abs(float(q)) for a in b['executed_actions'] for q in a['action']['add_shunts_q_mvar'].values())
            row[env+'_finite_uv_clear_success']=bool(own_env_valid and row[env+'_uv_count']==0)
            for k in ['pf_attempts','pf_returns','pf_exceptions','llm_calls','llm_exceptions','input_tokens','output_tokens']:row[env+'_'+k]=baseline['costs']['DFF'][k]+d['costs'][name][k]
            row[env+'_source_DFF_previous_campaign_wall_seconds']=baseline['costs']['DFF']['wall_seconds'];row[env+'_current_paired_proposer_wall_seconds']=d['costs'][name]['wall_seconds']
        rows.append(row);groups.setdefault(row['family'],[]).append(row)
    assert len(groups)==31 and all(len(rs)==2 for rs in groups.values())
    metrics=['uv_count','deficit_sum','accepted_actions','nominal_support_mvar','wall_seconds','pf_attempts','llm_calls','input_tokens','output_tokens'];valid={f:rs for f,rs in groups.items() if all(r['valid_numerical_pair'] for r in rs)};differences={};pvalue=None
    if valid:
        matrix=np.array([[np.mean([r['CENTRAL-VF_'+m]-r['HG-VF_'+m] for r in rs]) for m in metrics] for rs in valid.values()],float);rng=np.random.default_rng(SEED);samples=matrix[rng.integers(0,len(matrix),size=(REPLICATES,len(matrix)))].mean(axis=1);observed=matrix.mean(axis=0)
        for i,m in enumerate(metrics):differences[m]={'mean_CENTRAL_minus_ZONAL':float(observed[i]),'outage_family_percentile_bootstrap_95_percent_ci':np.quantile(samples[:,i],[.025,.975]).tolist()}
        null=(rng.choice([-1.,1.],size=(REPLICATES,len(matrix)))*matrix[:,0]).mean(axis=1);pvalue=float((1+np.count_nonzero(np.abs(null)>=abs(observed[0])-1e-12))/(REPLICATES+1))
    cols=list(dict.fromkeys(k for row in rows for k in row))
    with (root/'central_matched_paired_ledger.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
    report={'case_count':len(rows),'invalid_case_ids':[r['scenario_id'] for r in rows if not r['valid_numerical_pair']],'complete_valid_family_count':len(valid),'cluster_unit':'same outage line/zone across both load levels','bootstrap_replicates':REPLICATES,'seed':SEED,'primary_uv_cluster_sign_flip_pvalue':pvalue,'scope':'Paired standalone zonal HG-VF and central VF under the same frozen zonally trained adapter and matched call/output allowance. Input tokens differ and are measured. Cluster sign symmetry/exchangeability assumption; local bank only. Invalid cases retained and not zero-imputed. Physical replay and declared-resource audit required separately.','paired_differences':differences,'prompt_context_audit':{'recorded_primary_queries':len(promptfits),'maximum_input_tokens':max((p['input_tokens'] for p in promptfits),default=None),'feedback_memory_reductions':sum(p['memory_reduced'] for p in promptfits),'physical_observation_truncations':sum(p['physical_observation_truncated'] for p in promptfits),'generation_reserved':384,'context_limit':4096}}
    report['analysis_role']='Secondary architecture analysis; the primary hypothesis remains main-campaign HG-SE versus D-SE. No equivalence from nonsignificance or multiple confirmatory superiority claims.'
    report['finite_uv_clear_success_by_branch']={n:sum(r[n+'_finite_uv_clear_success'] for r in rows) for n in ['HG-VF','CENTRAL-VF']}
    report['finite_uv_clear_success_by_envelope']={n:sum(r[n+'_finite_uv_clear_success'] for r in rows) for n in ['HG-SE-ZONAL','HG-SE-CENTRAL']}
    report['full_bank_standalone_costs_including_invalid_cases']={n:{k:sum(r[n+'_'+k] for r in rows) for k in ['pf_attempts','pf_returns','pf_exceptions','pf_wall_seconds','llm_calls','llm_exceptions','llm_wall_seconds','input_tokens','output_tokens','wall_seconds']} for n in ['HG-VF','CENTRAL-VF']}
    report['proposal_diversity_and_parsing']={n:dict(v) for n,v in diversity.items()};report['envelope_selected_branch_counts']=dict(selection)
    env_groups={f:rs for f,rs in groups.items() if all(r['valid_envelope_pair'] for r in rs)};env_metrics=['uv_count','deficit_sum','accepted_actions','nominal_support_mvar','pf_attempts','llm_calls','input_tokens','output_tokens'];env_diff={}
    if env_groups:
        matrix=np.array([[np.mean([r['HG-SE-CENTRAL_'+m]-r['HG-SE-ZONAL_'+m] for r in rs]) for m in env_metrics] for rs in env_groups.values()],float);rng=np.random.default_rng(SEED);samples=matrix[rng.integers(0,len(matrix),size=(REPLICATES,len(matrix)))].mean(axis=1)
        env_diff={m:{'mean_CENTRAL_envelope_minus_ZONAL_envelope':float(matrix[:,i].mean()),'outage_family_percentile_bootstrap_95_percent_ci':np.quantile(samples[:,i],[.025,.975]).tolist()} for i,m in enumerate(env_metrics)}
    report['envelope_outcome_comparison']={'complete_valid_family_count':len(env_groups),'invalid_pair_ids':[r['scenario_id'] for r in rows if not r['valid_envelope_pair']],'paired_differences':env_diff,'timing_note':'Charge the same saved DFF to each portfolio. Retain its previous-campaign wall time separately from current proposer wall time; no matched portfolio speedup claim across sessions.'}
    assert report['prompt_context_audit']['physical_observation_truncations']==0
    (root/'central_matched_summary.json').write_text(json.dumps(report,indent=2,allow_nan=False));return report
if __name__=='__main__':print(json.dumps(analyze(),indent=2))
