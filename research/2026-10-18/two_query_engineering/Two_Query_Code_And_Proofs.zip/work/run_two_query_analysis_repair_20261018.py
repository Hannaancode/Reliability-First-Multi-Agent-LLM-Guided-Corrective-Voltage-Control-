"""One additive reader after actual old actors ended; never launches science."""
import importlib.metadata,json,os
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from exact_two_paid_query_engineering_20261018 import B,launch,now
from equal_operation_benchmark_v2 import process
def main():
    out=B/'reader_source_claim_repair_v2';out.mkdir(exist_ok=False);p=read(B/'Protocol.json')
    claims=[B/'Coordinator_Claim.json',B/'warm/owner.claim',B/'cold/owner.claim',B/'audit/owner.claim'];actors=[]
    for path in claims:
        v=read(path);pid=v['actual_pid'];parent=v.get('actual_parent_pid',v.get('parent_pid'))
        assert process(pid) is None,(path,pid)
        if parent and path.name!='Coordinator_Claim.json':assert process(parent) is None,(path,parent)
        actors.append({'claim':str(path.relative_to(R)),'actual_pid':pid,'parent':parent,'fresh_actual_PID_ended':True})
    for phase in ('warm','cold'):assert read(B/(phase+'_End_ACK.json'))['exit_code']==0
    assert 'assert c[\'source_sha256\']==sha(source)' in Path(R/'work/exact_two_paid_query_engineering_20261018.py').read_text('utf-8')
    assert 'AssertionError' in (B/'audit_console.log').read_text('utf-8') and not (B/'audit/Launcher_ACK.json').exists()
    put(out/'Original_Actors_Ended.json',{'at_utc':now(),'all_original_actors_ended':True,'actors':actors,'original_audit_entered_saved_evidence_reading':False,
        'failure':'Imported claim() bound __file__ to worker source, so coordinator correctly rejected reader source provenance; unacknowledged reader timed out before analysis. No scientific failure/retry.'})
    put(out/'Original_Coordinator_Failure.json',{'type':'AssertionError','line':'assert c[source_sha256]==sha(source) and c[protocol_sha256]==sha(B/Protocol.json)',
        'source_sha256':sha(R/'work/exact_two_paid_query_engineering_20261018.py'),'original_reader_claim':read(B/'audit/owner.claim'),
        'original_reader_stderr_sha256':sha(B/'audit_console.log'),'original_completion':read(B/'Completion.json'),'all_four_actual_PF_calls_retained':True})
    reader=R/'work/audit_exact_two_query_source_claim_v2_20261018.py';original=R/'work/audit_exact_two_paid_query_engineering_20261018.py'
    files=[Path(__file__),reader,original,R/'work/exact_two_paid_query_engineering_20261018.py',B/'Protocol.json',out/'Original_Actors_Ended.json',out/'Original_Coordinator_Failure.json']
    put(out/'Repair_Protocol.json',{'status':'FROZEN_ZERO_SCIENCE_READER_CLAIM_OUTPUT_ONLY_REPAIR','reader_source_sha256':sha(reader),'original_reader_sha256':sha(original),
        'original_protocol_sha256':sha(B/'Protocol.json'),'source_input_sha256':{str(x.relative_to(R)):sha(x) for x in files},'runtime_versions':p['runtime_versions'],
        'allowed_changes':['new separate analysis output directory','exact original claim function rebound to actual reader entrypoint source hash'],
        'unchanged':'All original main verifier/action/native input/replay/cost/state/source/frozen checks and original absolute deadline; no executed query or physical replay is repeated.',
        'new_model_PF_derivative_factor_solve_calls':0,'no_original_source_or_settings_edits':True})
    code=launch(reader,'reader',B/'audit_source_claim_v2',p)
    put(out/'Completion.json',{'at_utc':now(),'reader_exit_code':code,'new_scientific_calls':0,'no_retry':True});manifest(out)
    print(json.dumps({'additive_reader_exit_code':code,'new_science':0}))
if __name__=='__main__':main()
