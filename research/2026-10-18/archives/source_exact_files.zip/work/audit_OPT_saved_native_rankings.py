"""Independent direct saved-source reader; no inventory imports or science."""
import gzip,hashlib,json,math,os,time
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT,read,sha,write,seal,frozen_checks
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';B=ROOT/'outputs/llm_value_candidate_development_20261009'
S=P/'OPT_saved_native_ranking_headroom';OUT=P/'OPT_saved_native_ranking_external_audit';PRE=P/'OPT_saved_native_ranking_preparation'
assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
proto=read(PRE/'Protocol.json')
for n,h in proto['source_hashes'].items():assert sha(ROOT/n)==h,n
manifest=read(S/'Closed_Scientific_Manifest.json')
assert set(manifest)=={p.name for p in S.iterdir() if p.is_file() and p.name not in {'owner.claim','status.json','Closed_Scientific_Manifest.json'}}
for n,d in manifest.items():assert (S/n).stat().st_size==d['bytes'] and sha(S/n)==d['sha256']
def load(p):
 with gzip.open(p,'rt',encoding='utf8') as f:return [json.loads(l) for l in f]
raw=load(B/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz')
inputs={r['observation_id']:r for r in raw if r['split']=='optimization'}
truths={r['observation_id']:r for r in load(B/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz') if r['split']=='optimization'}
forecasts={r['observation_id']:r for r in read(B/'current_state_sensitivity_diagnostic/Actual_Current_Sensitivity_Records.json') if r['split']=='optimization'}
supports={r['observation_id']:r for r in load(B/'current_added_support_observables/Current_Control_State_Observables.jsonl.gz') if r['observation_id'] in inputs}
states=read(S/'Actual_All239_OPT_Ranking_Records.json');records={r['observation_id']:r for r in states}
assert len(states)==len(records)==239 and set(records)==set(inputs)==set(forecasts)==set(supports)
assert len(truths)==187 and len({r['world_sha256'] for r in states})==23
worlds={w['scenario_sha256']:w for w in proto['all_OPT_worlds']}
saved=read(P/'observed_constraint_affine_diagnostic/Supplement_Manifest.json')
action_lookup={};score_lookup={};checked_actions=0;native_predictions=0;available=0;target_available=0
for ident in sorted(inputs):
 r=records[ident];i=inputs[ident];obs=i['model_input']['current_physical_observation'];q=i['model_input']['original_Q_grid'];add=supports[ident]['current_added_support_MVAr_by_bus']
 assert r['world_sha256']==i['world_sha256'] and r['family']==worlds[i['world_sha256']]['family']
 assert r['current_input_sha256']==i['model_input_sha256']
 h=hashlib.sha256(json.dumps(obs,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 assert r['current_observation_sha256']==h
 buses=set().union(*(set(p) for p in obs['raw_common_and_zone_pools'].values()))
 allowed=set()
 for bus in buses:
  for j,value in enumerate(q):
   if add[bus]+value<=450:allowed.add((bus,j))
 assert q==[25.,50.,75.,100.,125.,150.,200.,250.,300.] and supports[ident]['original_cap_MVAr']==450
 assert r['allowed_actions']==len(allowed)
 prior=forecasts[ident];pp=prior.get('candidate_predictions',[]);pk=[(p['bus'],p['Q_index']) for p in pp]
 assert len(pk)==len(set(pk)) and r['prior_status']==prior['status']
 assert set(pk)==allowed if prior['status']=='finite_current_linear_system' else not pk
 pred=dict(zip(pk,pp));native_predictions+=len(pk)
 for pair,p in pred.items():assert p['q_MVAr']==q[pair[1]] and p['actual_PF_convergence'] is None
 finite=[p for p in pp if p['status']=='finite_linear_forecast']
 # Original stable sort is reproduced from the cached source list; complete
 # score ties retain that list's native Q ordering, rather than fabricated ties.
 order=sorted(range(len(finite)),key=lambda j:(tuple(finite[j]['estimated_original_score']),-finite[j]['bus']),reverse=True)
 ranked=[finite[j] for j in order];assert r['finite_ranked_predictions']==len(ranked)
 assert r['nonfinite_or_nonphysical_predictions']==len(pp)-len(ranked)
 tt={}
 for c in truths.get(ident,{}).get('measured_candidates',[]):
  t=c['target'];a=(t['bus'],t['Q_index']);assert a not in tt and a[0] in buses and t['q_mvar']==q[a[1]];tt[a]=t;checked_actions+=1
 assert r['measured_labels']==len(tt) and r['has_measured_targets']==(ident in truths)
 assert r['out_cap_measured_actions']==[list(a) for a in tt if a not in allowed]
 scores={a:tuple(t['recorded_original_score']) for a,t in tt.items() if a in allowed and t['recorded_verifier']['accepted']}
 maximum=max(scores.values(),default=None);best=sorted([list(a) for a,s in scores.items() if s==maximum])
 assert r['admissible_recorded_best_actions']==best and r['best_recorded_score']==(list(maximum) if maximum is not None else None)
 action_lookup[ident]=tt;score_lookup[ident]=pred
 for k in (1,4,8):
  actual=r['K'][str(k)];chosen=ranked[:k];expected=[];counts=Counter()
  for p in chosen:
   a=(p['bus'],p['Q_index']);category=('accepted' if tt[a]['recorded_verifier']['accepted'] else 'rejected') if a in tt else 'unmeasured'
   expected.append({'action':list(a),'predicted_score':p['estimated_original_score'],'measured_status':category});counts[category]+=1
  assert actual['shortlist']==expected
  for c,n in (('accepted','known_accepted'),('rejected','known_rejected'),('unmeasured','unknown_unmeasured')):assert actual[n]==counts[c]
  assert actual['unavailable_slots']==max(0,k-len(chosen))
  inclusion=bool({tuple(a) for a in best}&{(p['bus'],p['Q_index']) for p in chosen}) if best else None
  assert actual['recorded_best_included']==inclusion
  old=prior.get('recorded_oracle_priority',{}).get(str(k))
  if old is not None:assert old['recorded_best_score_included']==inclusion and old['known_admissible_oracle_exists']==bool(best)
 name='states/'+h+'.npz'
 assert r['saved_current_YV_member']==(name if name in saved else None) and r['saved_current_YV_member_descriptor']==saved.get(name)
 if name in saved:assert (P/'observed_constraint_affine_diagnostic'/name).is_file();available+=1;target_available+=ident in truths
assert checked_actions==30510
source_pairs=load(P/'actual_representation_and_OPT_support/Measured_OPT_Native_Quality_Preference_Pairs.jsonl.gz')
actual_pairs=read(S/'Actual_Existing_Pair_Prior_Relations.json');assert len(source_pairs)==len(actual_pairs)==11884
totals=Counter();perstate={i:Counter() for i in inputs}
for p,s in zip(source_pairs,actual_pairs):
 ident=p['observation_id'];a,b=tuple(p['preferred_action']),tuple(p['other_action']);tt=action_lookup[ident]
 assert s['observation_id']==ident and s['world_sha256']==inputs[ident]['world_sha256']==p['world_sha256']
 assert s['preferred_action']==list(a) and s['other_action']==list(b)
 assert list(a) in records[ident]['admissible_recorded_best_actions'] and tt[b]['recorded_verifier']['accepted']
 sa,sb=tt[a]['recorded_original_score'],tt[b]['recorded_original_score'];assert tuple(sa)>tuple(sb)
 j=next(j for j in range(5) if sa[j]!=sb[j]);assert j==p['native_score_first_different_coordinate'] and j<4
 if j in (2,3):assert abs(sa[j]-sb[j])>1e-10
 pa,pb=score_lookup[ident].get(a),score_lookup[ident].get(b);label='unknown'
 if pa and pb and pa['status']==pb['status']=='finite_linear_forecast':
  x,y=tuple(pa['estimated_original_score']),tuple(pb['estimated_original_score'])
  label='score_tied' if x==y else ('aligned' if x>y else 'reversed')
 assert s['prior_score_relation']==label;totals[label]+=1;perstate[ident][label]+=1
for i,r in records.items():assert r['quality_pair_counts']=={n:perstate[i][n] for n in ('aligned','score_tied','reversed','unknown')}
summary=read(S/'Summary.json');assert summary['quality_pair_prior_relations']==dict(totals)
assert summary['saved_current_YV_coverage']=={'all_inputs':available,'target_states':target_available,'missing_inputs':239-available}
def cov(rs):return {'states':len(rs),'worlds':len({r['world_sha256'] for r in rs}),'families':sorted({r['family'] for r in rs})}
assert summary['reversed_pair_coverage']==cov([r for r in states if perstate[r['observation_id']]['reversed']])
assert summary['tied_pair_coverage']==cov([r for r in states if perstate[r['observation_id']]['score_tied']])
for k in ('1','4','8'):
 d=summary['K'][k];oracles=[r for r in states if r['admissible_recorded_best_actions']]
 assert d['oracle_states']==len(oracles) and d['included']==sum(r['K'][k]['recorded_best_included'] for r in oracles)
 worldrates=[]
 for w in worlds:
  rr=[r for r in states if r['world_sha256']==w];oo=[r for r in rr if r['admissible_recorded_best_actions']];wins=sum(r['K'][k]['recorded_best_included'] for r in oo)
  expected={'all_inputs':len(rr),'oracle_states':len(oo),'included':wins,'rate':wins/len(oo) if oo else None}
  assert d['all23_world_denominators'][w]==expected
  if oo:worldrates.append(wins/len(oo))
 assert d['equal_world_inclusion']==sum(worldrates)/len(worldrates)
 assert d['shortlist_totals']=={n:sum(r['K'][k][n] for r in states) for n in ('known_accepted','known_rejected','unknown_unmeasured','unavailable_slots')}
 assert d['miss_coverage']==cov([r for r in oracles if not r['K'][k]['recorded_best_included']])
denom=read(B/'input_and_target_contract_nullable_v2/World_and_Invalid_Denominators.json')
assert summary['original_invalid_TRAIN_inputs']==denom['original_invalid_TRAIN_inputs'] and summary['original_missing_candidate_ledgers']==denom['missing_candidate_ledgers']
assert summary['OPT_unlabelled_inputs']==239-187==52 and summary['held_label_metrics_computed']==0 and all(v==0 for v in summary['new_scientific_calls'].values())
certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'exact_OPT_input_identities':239,'exact_OPT_worlds':23,
 'target_states':187,'unique_target_action_checks':checked_actions,'cached_native_prediction_checks':native_predictions,'exact_existing_quality_pair_checks':11884,
 'K1_4_8_scores_ties_denominators_unknowns_source_scope_cap_cost_checks_passed':True,'source_bound_YV_coverage_checked':True,
 'held_target_statistics':0,'new_model_PF_optimizer_controller_cloud_conversion_derivative_linear_solve_calls':0,
 'audit_seconds':time.perf_counter()-start,'training_or_DSE_superiority_inferred':False}
write(OUT/'Independent_Saved_OPT_Ranking_and_Preference_Audit.json',certificate);write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
decision=['# Saved OPT action-ranking inventory','',
 'This is a descriptive development audit of the preserved old AC prior. It does not show a learned contribution or authorize a new model run.','',
 f"All239 fixed OPT inputs/23worlds are retained:187 target states/30,510 measured actions and52 unlabelled inputs. Existing11,884 preference pairs are reused from the failed relational experiment.",'',
 f"K4 recorded-best inclusion: {summary['K']['4']['included']}/{summary['K']['4']['oracle_states']} oracle states; equal-world rate {summary['K']['4']['equal_world_inclusion']:.6f}. Miss coverage: {summary['K']['4']['miss_coverage']}.",'',
 f"Prior preference scores: {dict(totals)}. Strictly reversed-pair coverage: {summary['reversed_pair_coverage']}.",'',
 f"Saved current Y/V coverage: {summary['saved_current_YV_coverage']}. Missing current arrays are genuinely missing numerical derivations, not permission to rerun any previous completed solve.",'',
 'The next prerequisite is a prospective full native action-ranking control using the strong source-latched numerical method, with current-only inputs, complete unknown/failure denominators and all costs. Its stored single-action forecasts must be reused. A successful stronger prior could eliminate the apparent headroom identified here. No automatic GPU allocation, learning, new physical performance study, checkpoint selection or parameter sweep follows.','',
 'The original literal D-SE portfolio and complete both-branch costs remain the primary final comparator. Recorded best is conditional on sparse measured candidates; it is not an unmeasured-action optimum. Historical OPT/held/bank observations are development data.']
(OUT/'Results.md').write_text('\n'.join(decision)+'\n',encoding='utf8')
files={n:S/n for n in manifest};files['Closed_Scientific_Manifest.json']=S/'Closed_Scientific_Manifest.json'
files['Protocol.json']=PRE/'Protocol.json'
for n in ('prepare_OPT_saved_native_ranking_inventory.py','inventory_OPT_saved_native_rankings.py','audit_OPT_saved_native_rankings.py'):files['sources/'+n]=ROOT/'work'/n
for n in ('Independent_Saved_OPT_Ranking_and_Preference_Audit.json','Fresh_Frozen_Preservation.json','Results.md'):files[n]=OUT/n
archive=seal(OUT,files,'Saved_OPT_Native_Ranking_Evidence.zip')
write(OUT/'status.json',{'stage':'complete_independent_saved_OPT_inventory_audit','all_passed':True})
print(json.dumps({'audit':certificate,'K4':{k:summary['K']['4'][k] for k in ('oracle_states','included','equal_world_inclusion','miss_coverage','shortlist_totals')},'pairs':dict(totals),'archive':archive}))
