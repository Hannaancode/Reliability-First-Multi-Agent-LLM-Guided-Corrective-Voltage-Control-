"""One additive bounded reader after ended original chain, no primary science restart."""
import json,os,time,subprocess,hashlib
from pathlib import Path
from datetime import datetime,timezone
from coordinate_native_inverter_linear_reference_20261020 import process,sha,put
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_inverter_reader_metadata_coordination_v2_20261020'
def main():
    old=ROOT/'outputs/native_inverter_linear_reference_coordination_20261020'
    for name in ['run_native_inverter_linear_reference_20261020_End_ACK.json','audit_native_inverter_linear_reference_20261020_End_ACK.json']:
        ack=json.loads((old/name).read_text(encoding='utf-8'));assert ack['actual_owned_chain_ended'] and process(ack['actual_pid']) is None and process(ack['launcher_pid']) is None
    original=json.loads((old/'owner.claim').read_text(encoding='utf-8'));assert process(original['actual_pid']) is None
    repair=json.loads((ROOT/'outputs/native_inverter_linear_reference_preparation_20261020/Reader_Metadata_Repair_Protocol.json').read_text(encoding='utf-8'))
    source=ROOT/'work/audit_native_inverter_linear_reference_metadata_v2_20261020.py';directory=ROOT/'outputs/native_inverter_linear_reference_20261020/independent_audit_v2'
    assert sha(source)==repair['new_reader_sha256'] and not directory.exists()
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    with (OUT/'Reader.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(source)],cwd=ROOT,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);t=time.monotonic()
        while not (directory/'owner.claim').exists():assert child.poll() is None and time.monotonic()-t<60;time.sleep(.1)
        claim=json.loads((directory/'owner.claim').read_text(encoding='utf-8'));actual=process(claim['actual_pid']);parent=process(claim['parent_pid'])
        assert actual and parent and actual['ParentProcessId']==claim['parent_pid']==child.pid and source.name in actual['CommandLine'] and claim['source_sha256']==sha(source)
        put(directory/'Launcher_ACK.json',{'actual_pid':claim['actual_pid'],'actual_parent_pid':child.pid,'actual_command':actual['CommandLine'],'parent_command':parent['CommandLine'],'fresh_exact_source_PID_parent_command':True,'at_utc':datetime.now(timezone.utc).isoformat()})
        try:code=child.wait(timeout=max(1,repair['reader_bound_seconds']-(time.monotonic()-t)))
        except subprocess.TimeoutExpired:
            current=process(claim['actual_pid'])
            if current and source.name in current['CommandLine']:subprocess.run(['taskkill.exe','/PID',str(claim['actual_pid']),'/T','/F'],capture_output=True,timeout=30)
            child.wait(timeout=30);raise
    assert process(claim['actual_pid']) is None and process(child.pid) is None
    put(OUT/'Reader_End_ACK.json',{'actual_pid':claim['actual_pid'],'launcher_pid':child.pid,'exit_code':code,'actual_owned_chain_ended':True,'elapsed_seconds':time.monotonic()-t})
    assert code==0,'Retain reader failure, never repeat physics'
    put(OUT/'Completion.json',{'status':'ADDITIVE_READER_COMPLETE','all_owned_actors_ended':True,'at_utc':datetime.now(timezone.utc).isoformat()});print('ADDITIVE_READER_COMPLETE')
if __name__=='__main__':main()
