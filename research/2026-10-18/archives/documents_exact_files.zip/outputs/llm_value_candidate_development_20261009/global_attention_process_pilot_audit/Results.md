# Numerical candidate-process results

The independently verified numerical learner completed 935 CPU AdamW steps and 1,868 actual numerical forwards. All 311 final predictions reproduced exactly after a fresh checkpoint reload. The model has 9,088,003 parameters,36 more than the expected copied-LoRA plus shared-interface reference. Zero pretrained/model-generation, controller, PF or cloud calls occurred.

On the eight historical held-development world groups, equal-world standardized measured-gain MSE changed from 1.963964 before training to 1.669842 at the fixed final epoch. Full per-world denominators, classification Brier and all K=1/4/8 recorded-oracle inclusion diagnostics are retained in Actual_Measured_Learning_Results.json. Unknown unmeasured candidate predictions remain unknown. One original invalid input, 73 unlabelled current states and four missing reused ledgers stay explicit.

This is numerical learning/data evidence, not a physical policy rollout, LLM contribution or superiority over literal D-SE. The raw current inputs, known support-cap rule and all targets must be common to later arms. An independently justified pretrained-body test and its attribution controls still require a separate prospective protocol and real integration. No parameter, Q, prompt, budget, seed or checkpoint sweep is authorized by these findings.
