"""Current-state boundary and training-only conditioning; no model/solver.

Raw fields/types round-trip through the existing typed codec. Numeric table
conditioning groups refer to their actual column names, not mixed columns.
"""
import copy,json,math,statistics
from vcsa_common_information_codec import flatten,reconstruct

ROOT_FIELDS={'schema_version','physical_tables','zone_buses','zone_reports','global_metrics',
             'literal_fallback_bus_pool','raw_zonal_bus_pools','raw_common_and_zone_pools'}
Q_GRID=(25.,50.,75.,100.,125.,150.,200.,250.,300.)
class InputContractError(ValueError):pass
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def validate_observation(observation):
    if set(observation)!=ROOT_FIELDS:raise InputContractError('Exact current-observation fields; no labels/identities')
    for name,frame in observation['physical_tables'].items():
        if set(frame)!={'columns','index','values'}:raise InputContractError('Exact saved table schema required')
        if len(frame['index'])!=len(frame['values']) or any(len(row)!=len(frame['columns']) for row in frame['values']):
            raise InputContractError('Table position/column correspondence required')
    frame=observation['physical_tables']['res_bus'];col=frame['columns'].index('vm_pu')
    if set(frame['index'])!=set(range(118)):raise InputContractError('All118 current buses required')
    vm=[]
    for row in frame['values']:
        v=row[col]
        if type(v) not in (int,float) or not math.isfinite(v):raise InputContractError('Actual finite voltage required')
        vm.append(v)
    metrics=observation['global_metrics']
    if set(metrics)!={'vmin','vmax','vmean','uv_count','ov_count','deficit_sum'}:
        raise InputContractError('Actual current global metric schema required')
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in metrics.values()):
        raise InputContractError('Finite current metrics required')
    if metrics['uv_count']!=sum(v<.95 for v in vm) or metrics['ov_count']!=sum(v>1.05 for v in vm):
        raise InputContractError('Current counters must match their own actual voltage vector')
    for pool in observation['raw_common_and_zone_pools'].values():
        if any(type(bus) is not int or not 0<=bus<118 for bus in pool):raise InputContractError('Actual native bus IDs required')
    # This preserves optional tagged missing fields; it never creates a numeric truth value.
    records=flatten(observation)
    if canonical(reconstruct(records))!=canonical(observation):raise InputContractError('All field/value/type round-trip required')
    return records
def model_input(observation):
    validate_observation(observation)
    return {'current_physical_observation':copy.deepcopy(observation),'original_Q_grid':list(Q_GRID)}
def group_for(observation,path):
    if len(path)==5 and path[0]=='physical_tables' and path[2]=='values':
        table=path[1];column=observation['physical_tables'][table]['columns'][path[4]]
        return canonical(['physical_tables',table,'column',column])
    result=list(path)
    if len(result)>=4 and result[0]=='zone_reports' and result[2] in ('undervoltage_buses','lowest_voltage_buses'):
        result[3]='<bus_id>'
    result=['<array_index>' if type(p) is int else p for p in result]
    return canonical(result)
def fit_input_normalization(observations):
    values={};schema=set()
    for observation in observations:
        for record in flatten(observation):
            key=group_for(observation,record['path']);schema.add((key,record['kind']))
            if record['kind'] in ('int','float'):values.setdefault(key,[]).append(float(record['value']))
    numeric={}
    for key,samples in sorted(values.items()):
        mean=statistics.mean(samples);std=statistics.pstdev(samples);floor=1e-6*max(1.,abs(mean))
        numeric[key]={'mean':mean,'std':std,'scale':std if std>=floor else 1.,'near_constant_floor':floor,'count':len(samples)}
    return {'numeric':numeric,'typed_semantic_schema':[list(x) for x in sorted(schema)],
            'fit':'optimization-world current input observations only, without target/held-world values',
            'tagged_missing_fields_retained_not_zero_imputed':True}
def audit_normalized_input(observation,normal):
    records=validate_observation(observation);known={tuple(x) for x in normal['typed_semantic_schema']}
    unsupported=set();numeric=0;tags=0
    for record in records:
        key=group_for(observation,record['path'])
        if (key,record['kind']) not in known:unsupported.add((key,record['kind']))
        if record['kind'] in ('int','float'):
            numeric+=1;stats=normal['numeric'].get(key)
            if stats is not None and not math.isfinite((record['value']-stats['mean'])/stats['scale']):
                raise InputContractError('Finite conditioned input required')
        if record['kind']=='null' or '__missing__' in record['path']:tags+=1
    return {'typed_fields':len(records),'numeric_fields':numeric,'tagged_or_null_records':tags,
            'unsupported_semantic_types':[list(x) for x in sorted(unsupported)],
            'no_after_labels_or_world_IDs_in_model_input':True}
