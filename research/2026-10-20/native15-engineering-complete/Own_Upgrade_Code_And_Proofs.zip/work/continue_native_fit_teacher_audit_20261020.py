"""Bind one actual FIT owner; launch its one pinned prefix reader after actual end only."""
import os,json,time,subprocess
from pathlib import Path
from candidate_process_evidence_utils import read,write,sha
from coordinate_native_inverter_linear_reference_20261020 import process
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_fit_teacher_handoff_20261020';PRIMARY=ROOT/'outputs/native_fit_teacher_execution_20261020'
def main():
    OUT.mkdir(exist_ok=False);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))});claim=read(PRIMARY/'owner.claim');actor=process(claim['actual_pid']);assert actor and actor['ParentProcessId']==claim['parent_pid'] and 'run_native_fit_teacher_20261020.py' in actor['CommandLine'] and claim['source_sha256']==sha(ROOT/'work/run_native_fit_teacher_20261020.py');write(OUT/'Bound_Actual_Source_Owner.json',{'claim':claim,'fresh_actual_command':actor['CommandLine']})
    began=time.monotonic();end=ROOT/'outputs/native_fit_teacher_coordination_20261020/End_ACK.json';rp=ROOT/'outputs/native_fit_teacher_preparation_20261020/independent_Owner_Protocol.json';reader=read(rp)['single_owner'];assert sha(ROOT/reader['source'])==reader['sha256'];assert not (ROOT/reader['output']).exists()
    while not end.exists():assert time.monotonic()-began<1000;time.sleep(3)
    ended=read(end);assert ended['actual_owned_chain_ended'] and ended['actual_pid']==claim['actual_pid'] and ended['exit_code']==0 and (PRIMARY/'Result.json').is_file() and (PRIMARY/'Closed_Manifest.json').is_file()
    for pid in [claim['actual_pid'],claim['parent_pid']]:
        actor=process(pid);assert actor is None or 'run_native_fit_teacher_20261020.py' not in (actor.get('CommandLine') or '')
    write(OUT/'Prior_Actual_End_ACK.json',ended)
    with (OUT/'Reader_Coordinator.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen(['python.exe','-X','utf8',str(ROOT/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str(rp)],cwd=ROOT,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);write(OUT/'Reader_Dispatch.json',{'coordinator_pid':child.pid,'reader_source_sha256':reader['sha256'],'prior_scientist_ended':True});code=child.wait(timeout=1000)
    write(OUT/'End_ACK.json',{'exit_code':code,'all_dispatched_children_ended':True,'workflow_seconds':time.monotonic()-began});assert code==0,'Preserve failure; no reader/science retry'
    audit=read(ROOT/reader['output']/'Independent_Audit.json');write(OUT/'Completion.json',{'status':'CLOSED_FIT_PREFIX_INDEPENDENT_AUDIT_COMPLETE','scientific_status':audit['primary_scientific_status'],'audit_status':audit['status'],'model_training_not_automatic':True});print('FIT_PRIMARY_AND_PINNED_READER_ENDED')
if __name__=='__main__':main()
