"""Fixed lexicographic full-grid minimax band / absolute-Q LP; no physical solver or model."""
import numpy as np
def problem(vm,sensitivity,q0):
    vm=np.asarray(vm,dtype=float);s=np.asarray(sensitivity,dtype=float);q0=np.asarray(q0,dtype=float);m=len(q0);assert s.shape==(len(vm),m) and m==3
    rows=[];bs=[];n=2*m+1
    for v,row in zip(vm,s):
        for sign,limit in [(1,1.05),(-1,-.95)]:
            a=np.zeros(n);a[:m]=sign*row;a[-1]=-1;rows.append(a);bs.append(limit-sign*v)
        if .95<=v<=1.05:
            for sign,limit in [(1,1.05),(-1,-.95)]:
                a=np.zeros(n);a[:m]=sign*row;rows.append(a);bs.append(limit-sign*v)
    for i in range(m):
        for sign in [1,-1]:
            a=np.zeros(n);a[i]=sign;a[m+i]=-1;rows.append(a);bs.append(-sign*q0[i])
    c=np.zeros(n);c[-1]=1;cap=float(np.float32(.3));bounds=[(-cap,cap)]*m+[(0,None)]*(m+1)
    return c,np.asarray(rows),np.asarray(bs),bounds
def second_problem(c,a,b,bounds,t):
    c2=np.zeros_like(c);c2[3:6]=1;row=np.zeros_like(c);row[-1]=1
    return c2,np.vstack([a,row]),np.r_[b,float(t)+1e-10],bounds
