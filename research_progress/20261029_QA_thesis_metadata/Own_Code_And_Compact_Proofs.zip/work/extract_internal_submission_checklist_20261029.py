"""Move the internal finalisation checklist out of the examinable thesis body."""
from pathlib import Path
from docx import Document
import json,hashlib,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_caption_QA_v2_20261029'
def main():
    p=O/'Hannaan_Thesis_Caption_And_QA_Update.docx';q=O/'Internal_Submission_Checklist.txt';assert not q.exists()
    d=Document(p);ps=d.paragraphs;title='Appendix C Finalisation checklist for the submitted thesis'
    a=next(i for i,x in enumerate(ps) if x.text==title);b=next(i for i,x in enumerate(ps) if i>a and x.text=='References')
    removed=[x.text for x in ps[a:b]];assert len(removed)>1
    # This appendix contains prose only. Preserve it verbatim outside the thesis.
    ael=ps[a]._p;bel=ps[b]._p;nodes=[];node=ael
    while node is not bel:
        assert node is not None and node.tag.endswith('}p') and not node.xpath('.//w:drawing')
        nodes.append(node);node=node.getnext()
    shutil.copy2(p,O/'Before_Internal_Checklist_Extraction.docx')
    q.write_text('\n\n'.join(removed)+'\n','utf-8')
    for node in nodes:node.getparent().remove(node)
    indices=[x for x in d.paragraphs if x.text.startswith(title+'\t')];assert len(indices)==1
    indices[0]._p.getparent().remove(indices[0]._p)
    assert len(d.inline_shapes)==22 and len(d.tables)==19
    d.save(p)
    (O/'Internal_Checklist_Extraction.json').write_text(json.dumps({'status':'INTERNAL_CHECKLIST_REMOVED_FROM_WORKING_THESIS_PRESERVED_SEPARATELY','removed_paragraph_count':len(removed),'external_checklist':str(q.relative_to(R)),'external_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'prior_docx_preserved':True,'limitations':'Working draft still requires final research/admin/supervisor decisions; no university-specific exemption is assumed.','new_science':0},indent=2)+'\n','utf-8')
    print(json.dumps({'internal_checklist_extracted':True,'figures':22,'tables':19}))
if __name__=='__main__':main()
