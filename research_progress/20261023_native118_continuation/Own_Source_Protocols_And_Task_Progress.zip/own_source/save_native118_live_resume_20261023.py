"""Append current verified ownership and exact continuation, no science."""
from datetime import datetime,timezone
from r118_dff_missing_continuation_core_20261023 import *
from finalize_r118_dff_prelaunch_and_task_snapshot_20261023 import replace_json

def main():
    from coordinate_native_inverter_linear_reference_20261020 import process
    O=R/'outputs/r118_native_comparison_continuation_20261023';O.mkdir(exist_ok=True)
    claims=[]
    for directory in [E,R/'outputs/r118_dff_missing_continuation_handoff_20261023']:
        c=read(directory/'owner.claim');actual=process(c['actual_pid']);parent=process(c['parent_pid'])
        assert actual and parent and actual['ParentProcessId']==c['parent_pid'] and sha(R/('work/run_r118_dff_missing_continuation_20261023.py' if directory==E else 'work/coordinate_r118_dff_missing_continuation_20261023.py'))==c['source_sha256']
        claims.append(dict(directory=directory.relative_to(R).as_posix(),claim=c,actual=actual,parent=parent))
    now=datetime.now(timezone.utc).isoformat()
    value=dict(at_utc=now,status='LIVE_SINGLE_NEW_ALL4_DFF_CONTINUATION_AND_PINNED_READER_HANDOFF',claims=claims,exec_session=17503,preparation=P.relative_to(R).as_posix(),current_GPU_assignments=0,current_timers=[],all6_final_goals='OPEN',next=['Observe exact original owner status/journal; never restart or duplicate. Coordinator alone starts pinned partial-aware first-new-return reader after primary actual end/exit0/closed manifest.','Prepare remaining3 original Reflection-v4 full-case serving/integration/prospective source locks in parallel. No GPU allocation from software alone; do not overlap physical queries with the current DFF owner.','Only after all DFF scientist/reader/coordinator end, bind its complete current attempt registry including exceptions/unrecovered reservations before any subsequent physical campaign.','Save and publish true results/costs/unknowns. No full DSE, external or LLM superiority claim without complete matched evidence.'],progress_snapshot=(P/'Human_Task_Progress_Snapshot.json').relative_to(R).as_posix(),old2034queries_not_repeated=True)
    put(O/'Verified_Actual_Live_Checkpoint.json',value)
    replace_json(O/'Current_Resume.json',value)
    registry=R/'outputs/research_tasks_20261014/Tasks.json';d=read(registry);d['updated_at_utc']=now;d['latest_resume']=(O/'Current_Resume.json').relative_to(R).as_posix();d['current_owned_jobs']=claims;d['current_GPU_assignments']=0;d['current_waiting_automations']=[]
    for t in d['tasks']:
        if t['checklist_id']=='G3':
            t['status']='LIVE_ALL4_ORIGINAL_DFF_MISSING_ONLY_FULL_TRAJECTORY_CONTINUATION'
            t['next']='Single frozen primary then partial-aware independent first-new-return reader; complete original trained Reflection-v4 remaining3cases and external source-native comparisons under separately frozen protocols.'
            t['current_result']='All2034 initial-menu identities closed; original first-choice committed cursors bound onall4. New full DFF continuation live; counts are not endpoints. Full matched external/DSE/LLM comparison remains open.'
        if t['checklist_id']=='G4':
            t['status']='COMPLETE_FIXED_THREE_ENCODER_ARMS_GATE_FAILED_NO_RETUNE'
            t['current_result']='Actual frozen encoder fixed readout: trained0.5B71.875%,public0.5B59.375%,public1.5B64.5833%,numeric75%; failed80%gate. No physical or unused-generalization claim.'
    replace_json(registry,d)
    header=f"## Current all4 native DFF continuation LIVE; percentages are checklist counts — {now}\n\nRead outputs/r118_native_comparison_continuation_20261023/Current_Resume.json first. Single actual CPU scientist{claims[0]['claim']['actual_pid']} and coordinator{claims[1]['claim']['actual_pid']}, pinned reader after actual end only; fixed7200sec newscience/7200reader/8GiB. Reuse complete2034 first menus and first-commit cursors; original25operations/source/9Q/450cap/native1.06unchanged, strict0.95/1.05 reported. No duplicate/restart/live edit/extension. No currentGPU/timer. All6finalgoalsOPEN. Remaining3 original Reflection-v4 GPU-case protocols are preparation only, no auto allocation or overlapping physics.\n\n"
    for file in [R/'outputs/Unattended_Execution_Runbook.md',R/'outputs/llm_value_development/Next_Phase_Plan.md']:
        file.write_text(header+file.read_text(encoding='utf-8-sig'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write(f"\n[{now}] New all4 original DFF missing-only continuation launched under a prospective7200sec/8GiB protocol with one independently bounded partial-aware reader queued. Complete2034 earlier first-menu identities and24remaining-operation source cursors reused, no old scientific calls repeated. Actual source/PID/parent/claim verified; all6goals remain open. Task percentages are existing main milestone counts, not cases solved or winning confidence. Exact resume: outputs/r118_native_comparison_continuation_20261023/Current_Resume.json. GPUs currently0.\n")
    print(json.dumps(dict(saved=value['status'],actual_scientist=claims[0]['claim']['actual_pid'],coordinator=claims[1]['claim']['actual_pid'])))

if __name__=='__main__':main()
