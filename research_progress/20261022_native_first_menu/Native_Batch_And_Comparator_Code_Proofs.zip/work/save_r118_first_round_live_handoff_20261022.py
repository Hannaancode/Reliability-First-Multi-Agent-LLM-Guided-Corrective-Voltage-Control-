"""Save exact live assignment and bounded next-reader obligations."""
import json,hashlib,subprocess
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'outputs/r118_first_round_missing_only_handoff_20261022'
def read(p):return json.loads((R/p).read_text('utf-8'))
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def main():
    now=datetime.now(timezone.utc).isoformat();worker=read('outputs/r118_first_round_missing_only_execution_20261022/owner.claim');root=read('outputs/r118_first_round_missing_only_handoff_20261022/owner.claim')
    ack=read('outputs/r118_first_round_missing_only_execution_20261022/Launcher_ACK.json');assert ack['fresh_exact_source_PID_parent_command'] and ack['actual_pid']==worker['actual_pid']
    status=read('outputs/r118_first_round_missing_only_execution_20261022/Status.json')
    cp=subprocess.run(['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -match '(run_r118_first_round_missing_only|coordinate_r118_first_round_missing_only|audit_r118_first_round_missing_only)' } | Select-Object ProcessId,ParentProcessId,CommandLine,CreationDate | ConvertTo-Json -Depth 3"],capture_output=True,text=True,check=True,timeout=30)
    processes=json.loads(cp.stdout) if cp.stdout.strip() else [];assert any(p['ProcessId']==worker['actual_pid'] and p['ParentProcessId']==worker['parent_pid'] for p in processes)
    state=dict(at_utc=now,status='SINGLE_MISSING_ONLY_NATIVE_DFF_FIRST_MENU_OWNER_LIVE',exec_session=55532,
        primary=worker,coordinator=root,fresh_exact_processes=processes,source_protocol_sha256=sha('outputs/r118_first_round_missing_only_preparation_20261022/Protocol.json'),
        current_progress_only=status,declared_first_menu_queries=2034,planned_new_unexecuted_only=1989,paid_reuses=42,known_contract_unknowns_no_call=3,
        bounds=dict(primary_seconds=1800,first_reader_seconds=1800,each_launcher_seconds=2000),
        next='Sole coordinator invokes pinned first-new-return reader only after actual primary exit0 and closed manifest. Partial and known collisions stay UNKNOWN. Never restart/duplicate/live-edit/extend/replay old or failed calls.',
        no_actual_commits_or_new_model_calls=True,current_GPU_assignments=0,all3_previous_GPU_arms_ended_released=True,
        all6_final_goals='OPEN',last_verified_GitHub='329c4b8837e898a501e34fad7af5467fbdd56f15',
        result_paths=['outputs/r118_first_round_missing_only_execution_20261022/Result.json','outputs/r118_first_round_missing_only_independent_20261022/Independent_Audit.json','outputs/r118_first_round_missing_only_handoff_20261022/Completion.json'],
        waiting_policy='Only a one-time estimated check if this live result becomes the sole ready dependency and no useful parallel task remains; rearm only genuinely live, delete at terminal. No recurring monitor.')
    with (O/'Current_Resume.json').open('x',encoding='utf-8') as f:json.dump(state,f,indent=2)
    header='## Missing-only native DFF first-menu batch running — '+now+'\n\nSole science actual'+str(worker['actual_pid'])+'/parent'+str(worker['parent_pid'])+'; sole coordinator'+str(root['actual_pid'])+'/parent'+str(root['parent_pid'])+'; exec55532. Read outputs/r118_first_round_missing_only_handoff_20261022/Current_Resume.json. Exact2034source queries:1989new/unexecuted,42paid80reuses,3prior-contractUNKNOWN/no call. All404current primary/failed/unentered beforecapsules checked. Fixed1800science/1800reader; sole pinned reader follows actual primary end/exit0/closedmanifest. No duplicate/restart/live edit/extension/old or failed call replay. First fsynced receipt/cursor+saved-source cold verifier PASS0newPF in cold; counts are not comparison completion. No actual commits/model/GPU. Previous3T4encoder study complete, released and audited; private71.875% versusnumeric75%,fixedgateFAIL. All6goalsOPEN. GitHub329c4b8837e898a501e34fad7af5467fbdd56f15 all5remote exactbytechecksPASS; this live source/protocol pending publication.\n\n'
    for path in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/path;p.write_text(header+p.read_text('utf-8'),encoding='utf-8')
    registry=read('outputs/research_tasks_20261014/Tasks.json');registry.update(latest_verified_update=now,latest_resume=(O/'Current_Resume.json').relative_to(R).as_posix(),current_GPU_assignments=0,current_owned_jobs=[worker,root])
    (R/'outputs/research_tasks_20261014/Tasks.json').write_text(json.dumps(registry,indent=2),encoding='utf-8')
    for path in ['outputs/f118_actual_completion_handoff_20261022/Live_Continuation_Addendum.json','outputs/full_system_comparison_20261021/Latest_Continuation_20261022.json']:
        with (R/path).open('x',encoding='utf-8') as f:json.dump(dict(at_utc=now,newest_active_continuation=(O/'Current_Resume.json').relative_to(R).as_posix(),previous_closure_remains_valid_at_its_time=True),f,indent=2)
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+header+'\n')
    print(json.dumps(dict(saved=True,actual_primary=worker['actual_pid'],current_GPU_assignments=0,progress_is_not_completion=True)))
if __name__=='__main__':main()
