"""Capture and independently cold-check the exact pending source frame.

No nonlinear solver, model, GPU, training or independent physical replay calls.
This is state reconstruction, not completion of the old scientific studies.
"""
from reflection118_remaining_cases_v2_core_20261023 import *
from immutable_response_transport_20261028 import read_response


class FrontierBoundary(BaseException):
    pass


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['capture','verify'],required=True);mode=parser.parse_args().mode
    out=R/'outputs/pending_source_state_20261028'/mode
    out.mkdir(exist_ok=False)
    began=time.monotonic();deadline=began+300
    put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),fixed_seconds=300,scope='SAVED_ONLY_NO_NATIVE_CALLS'));wait_ack(out,began)
    np,pp,v2,runner,reflection=setup()
    results=[]
    def bound():
        if time.monotonic()>=deadline:raise TimeoutError('Saved-only fixed bound reached')
    for index in [1,3]:
        host=R/'outputs/reflection118_remaining_cases_v2_execution_20261023'/f'case_{index:02d}'
        prior=read(R/'outputs/reflection118_remaining_cases_v2_independent_20261023'/f'case_{index:02d}'/'Independent_Audit.json')
        assert prior['status']=='PASS_PRESERVED_PARTIAL_FULL_CASE_UNKNOWN'
        status=read(host/'status.json')
        assert status['runtime_released'] and status['scientific_process_ended'] and status['all_actual_closed_artifacts_preserved']
        p=read(TOP/f'case_{index:02d}'/'Frozen_Engineering_Protocol.json')
        for name,h in p['local_source_hashes'].items():assert sha(R/name)==h
        binding=read(R/p['bindings'])[index];d=host/'local_controller'/binding['case_id']/'reflection_v2'
        calls=read(d/'Call_Order.json');manifest=read(host/'remote_closed_descriptor.json')['members']
        o=out/f'case_{index:02d}';o.mkdir()
        pi=gi=0;frontier=None;last_state=None
        def physics(net,**kwargs):
            nonlocal pi,frontier
            bound()
            if pi==len(calls['PF']):
                desc=capsule(o/'next_unexecuted_input.zlib',net)
                frontier=dict(kind='PHYSICS_REQUEST_NOT_EXECUTED',input=desc,kwargs=kwargs)
                raise FrontierBoundary()
            rec=calls['PF'][pi];pi+=1
            assert kwargs==rec['kwargs'];frames_equal(net,saved_net(d,rec['before']))
            restore_exact(net,saved_net(d,rec['after']))
            if rec['exception'] is not None:raise RuntimeError(failure_message(rec['exception']))
        def model(messages):
            nonlocal gi,frontier
            bound();name=f'response_{gi:05d}.json'
            if name not in manifest:
                import inspect
                frame=inspect.currentframe()
                while frame is not None and frame.f_code is not reflection.run_one_scenario_two_best_v2.__code__:frame=frame.f_back
                assert frame is not None
                state=copy.deepcopy({k:frame.f_locals[k] for k in ['net','result','failed_sigs','failed_actions','feedback_state','it'] if k in frame.f_locals})
                state.update(python_rng=random.getstate(),numpy_rng=np.random.get_state(),pending_messages=copy.deepcopy(messages),PF_cursor=pi,model_cursor=gi)
                if mode=='capture':
                    descriptor=capsule(o/'Pending_Source_State.zlib',state);put(o/'Pending_Source_State.json',descriptor)
                else:
                    previous=R/'outputs/pending_source_state_20261028/capture'/f'case_{index:02d}'
                    checkpoint_equal(state,decode(previous,read(previous/'Pending_Source_State.json')))
                    assert read(previous/'Frontier.json')['frontier']['messages']==messages
                    put(o/'Cold_State_Check.json',dict(status='PASS_EXACT_PENDING_NET_HISTORY_FEEDBACK_FAILURE_RNG_REQUEST_CURSORS',new_PF_model_calls=0))
                frontier=dict(kind='MODEL_REQUEST_NOT_EXECUTED',number=gi,messages=messages)
                raise FrontierBoundary()
            req=read(host/'local_controller/requests'/f'request_{gi:05d}.json')
            assert req['messages']==messages
            ans,_=read_response(host/'staged/study'/name,req,manifest[name]['sha256'],deadline)
            gi+=1;return ans['raw_text']
        def commit(state):
            nonlocal last_state
            bound();last_state=state
        random.seed(p['seed']);np.random.seed(p['seed'])
        base=pp.from_json(str(R/p['base_net']));zones=read(R/p['metadata'])['zones']
        try:
            result,_=run_original(v2,runner,reflection,read(R/binding['registration']['recipe']),base,zones,model,physics,commit_callback=commit)
            frontier=dict(kind='SAVED_SOURCE_TERMINAL',result=result)
        except FrontierBoundary:pass
        if last_state is not None:
            # Preserve the exact controller frame for later prospective admission.
            payload=pickle.dumps(last_state,protocol=5)
            (o/'last_commit_state.pkl').write_bytes(payload)
        record=dict(case_id=binding['case_id'],paid_PF_consumed=pi,paid_model_responses_consumed=gi,
            old_source_model_returns=len(calls['generations']),new_saved_response_consumed=gi>len(calls['generations']),
            frontier=frontier,new_PF_model_optimizer_training_calls=0,
            limitation='Frontier is not historical-absence proof or scientific launch authority; complete exact history, cursor and new bounded protocol still required.')
        put(o/'Frontier.json',record);results.append(record)
    put(out/'Results.json',dict(status='EXACT_PENDING_SOURCE_STATE_'+mode.upper(),cases=results,workflow_seconds=time.monotonic()-began,new_PF_model_calls=0))
    print(json.dumps({'status':'EXACT_PENDING_SOURCE_STATE_'+mode.upper(),'cases':[{k:x[k] for k in ['case_id','paid_PF_consumed','paid_model_responses_consumed','new_saved_response_consumed']} for x in results]}))

if __name__=='__main__':main()
