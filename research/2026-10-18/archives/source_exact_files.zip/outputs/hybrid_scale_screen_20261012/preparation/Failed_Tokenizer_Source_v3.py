"""Lossless original-role token closure; tokenizer calls only, zero model/PF."""
import hashlib,json,os,time
from pathlib import Path
os.environ.update(HF_HUB_DISABLE_IMPLICIT_TOKEN='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false',USE_TORCH='0',USE_TF='0')
from huggingface_hub import snapshot_download
import sys
import transformers
import transformers.utils as hf_utils
import transformers.utils.import_utils as hf_imports
assert 'torch' not in sys.modules
hf_imports.is_torch_available=lambda:False
hf_utils.is_torch_available=lambda:False
transformers.is_torch_available=lambda:False
from transformers import AutoTokenizer
assert 'torch' not in sys.modules
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/hybrid_scale_screen_20261012/preparation'
read=lambda p:json.loads(p.read_text('utf-8'))
def put(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    started=time.perf_counter();cases=read(PREP/'Causal_Prompt_Cases.json');base=read(PREP/'Original_Private_Base_Metadata.json')
    models=[{'arm':'private_0p5B','path':ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'},
        {'arm':'unadapted_identical_0p5B_base',**base}]+[{'arm':'public_'+m['repo'].split('/')[-1].replace('Qwen2.5-','').replace('-Instruct',''),**m} for m in read(PREP/'Public_Model_Metadata.json')]
    records=[]
    for m in models:
        folder=m.get('path')
        if folder is None:folder=Path(snapshot_download(m['repo'],revision=m['revision'],allow_patterns=['config.json','*tokenizer*','chat_template.jinja','vocab.json','merges.txt','special_tokens_map.json'],cache_dir=str(PREP/'tokenizer_cache')))
        tokenizer=AutoTokenizer.from_pretrained(str(folder),local_files_only=True,trust_remote_code=False)
        rows=[]
        for c in cases:
            tokens=tokenizer.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True)
            assert len(tokens)+384<=4096,'Full actual current prompt plus fixed generation allowance exceeds4096; no truncation/drop/retry'
            rows.append({'case_id':c['case_id'],'input_ids':tokens,'prefix_tokens':len(tokens),
                'prefix_utf8_bytes':len(tokenizer.apply_chat_template(c['messages'],tokenize=False,add_generation_prompt=True).encode())})
        entry={'arm':m['arm'],'full16_prefixes':rows,'longest_prefix_tokens':max(r['prefix_tokens'] for r in rows),'max_new_tokens':384,'original_lengths_preserved_no_truncation':True}
        records.append(entry);put(PREP/(m['arm']+'_Token_Closure.json'),entry)
    report={'status':'PASS_ALL_FIVE_MODEL_TOKENIZER_CURRENT_ROLE_INPUT_CLOSURE','models':[{k:r[k] for k in ('arm','longest_prefix_tokens','max_new_tokens')} for r in records],
        'case_ids_identical_for_all_arms':True,'model_PF_optimizer_calls':0,'tokenizer_preparation_seconds':time.perf_counter()-started}
    put(PREP/'Token_Closure_Summary.json',report);print(json.dumps(report))
if __name__=='__main__':main()
