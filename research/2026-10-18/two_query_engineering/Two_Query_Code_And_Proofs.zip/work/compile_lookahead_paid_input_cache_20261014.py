"""Read-only compatible paid-receipt index; never starts an old scientist.

Receiver scopes may widen only as an explicit source-derived domain adaptation.
The key retains all physical inputs/results/current case, resource/stock/caps and
actual native masks. A reused action must remain legal in the new causal scope.
Incomplete old intents are blocked rather than repeated or labelled negative.
"""
import copy,hashlib,json,os,sys,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandapower as pp
import full_joint_suffix_benchmark_20261014 as prior
from equal_operation_benchmark_v2 import decode_capsule,initial_data
from joint_reallocation_opportunity_core_v1 import load_endpoint
from frozen_physics_loader import load_stack
from shared_original_serving_action_domain_v1 import build_current_domain

R=Path(__file__).resolve().parents[1];B=R/'outputs/operation_aware_lookahead_input_cache_20261014'
PH=R/'outputs/shared_current_domain_physics_guarded_v2_20261014'
FULL=R/'outputs/full_joint_suffix_benchmark_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
TWO=R/'outputs/equal_operation_benchmark_v2_20261013'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
ORIGINAL_STATE_KEY=prior.state_key
def point_key(net,cursor):
    c=copy.deepcopy(cursor);c['raw_current_receiver_scope']=[]
    inner=net['_ppc']['internal']
    return hashlib.sha256(canon({'physical_case_and_resource_identity':ORIGINAL_STATE_KEY(net,c),
        'actual_native_ref':np.asarray(inner['ref'],dtype=int).tolist(),
        'actual_native_PV':np.asarray(inner['pv'],dtype=int).tolist(),
        'actual_native_PQ':np.asarray(inner['pq'],dtype=int).tolist()})).hexdigest()
def action_key(row):return prior.action_key(row)
def external(ref,base):
    if ref is None:return None
    if ref['kind']=='new':return {'kind':'external_capsule','base':str(base.relative_to(R)),'descriptor':ref['descriptor']}
    if ref['kind'] in ('old','two'):
        where=OLD if ref['kind']=='old' else TWO
        return {'kind':'external_capsule','base':str(where.relative_to(R)),'descriptor':ref['descriptor']}
    assert ref['kind']=='engineering'
    return {'kind':'legacy_engineering_container','reference':ref}
def load_ref(ref):
    if ref['kind']=='legacy_engineering_container':return prior.load_after(ref['reference'],None)
    assert ref['kind']=='external_capsule'
    base=(R/ref['base']).resolve();assert base.is_relative_to(R)
    with (base/'actual/capsules.bin').open('rb') as f:return decode_capsule(f,ref['descriptor'])
def compact(record,base,source,eventhash):
    return {'candidate':record['candidate'],'verdict':record['verdict'],'original_score':record['original_score'],
        'after_reference':external(record['after_reference'],base),'receipt_id':record['receipt_id'],
        'attributed_PF_calls':record['attributed_PF_calls'],'attributed_solver_seconds':record['attributed_solver_seconds'],
        'source':source,'source_event_or_record_sha256':eventhash,
        'scope':'Paid native verifier result; physical nonconvergence is an operational rejection, not infeasibility proof or a negative training label.'}
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'argv':sys.argv})
    def blocked(*a,**k):raise AssertionError('Receipt-index preparation forbids all physics/model/derivative/solve callbacks')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,blocked)
    audit=read(FULL/'partial_audit_v1/Independent_Preserved_Prefix_Audit.json')
    assert audit['status'].startswith('PASS_RECORDED_CLOSED_')
    assert read(PH/'Completion.json')['science_exit']==read(PH/'Completion.json')['reader_exit']==0
    put(B/'Preparation_Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),
        'purpose':'New scope-compatible paid input index for separately prospective bounded nonlinear lookahead; no old owner/reader restart.',
        'all_four_worlds':[e['world'] for e in read(OLD/'preparation/Protocol.json')['current_endpoints']],
        'scope_rule':'Only raw receiver-scope namespace omitted from physical cache identity. Current fields/complete case/actual masks/stock/remaining ops/positive and withdrawn caps retained. Caller must certify source/current action legality before reuse.',
        'unknown_rule':'Every old PF intent without a closed candidate verdict is a blocked identity; never execute it again or fabricate a rejection.',
        'new_model_PF_derivative_forecast_solve_calls':0,'preparation_bound_seconds':180.,
        'not_performance_or_automatic_launch':True})
    maps={};proofs={};oldfn=prior.state_key
    def traced(net,cursor):
        original=oldfn(net,cursor);new=point_key(net,cursor)
        if original in maps:assert maps[original]==new
        maps[original]=new;proofs[new]={'source_receiver_scope':cursor['raw_current_receiver_scope'],
            'remaining_operations':cursor['remaining_original_device_operation_slots'],
            'source_stock_rows':[{k:r[k] for k in ['index','bus','name','q_mvar']} for r in cursor['owned_bank_rows']]}
        return original
    prior.state_key=traced
    try:old,legacy,roots,_=prior.legacy_cache()
    finally:prior.state_key=oldfn
    cache={};by_receipt={};blocked_intents={}
    def add(point,ak,record):
        k=point+'|'+ak
        if k in cache:
            previous=cache[k]
            assert previous['verdict']==record['verdict'] and previous['original_score']==record['original_score']
        else:cache[k]=record
        by_receipt[record['receipt_id']]=record
    for (oldkey,ak),record in legacy.items():
        assert oldkey in maps
        add(maps[oldkey],ak,compact(record,FULL,'LEGACY_PAID_INITIAL_OR_TWOOP_OR_ENGINEERING',hashlib.sha256(canon(record)).hexdigest()))
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    root_domains={};world_points={}
    for e in old['current_endpoints']:
        net,cursor,_=load_endpoint(e);domain=build_current_domain(net,cursor,runner=runner,zones=zones)
        cursor=domain['expanded_cursor_for_separately_fixed_future_protocol'];point=point_key(net,cursor)
        assert point==maps[ORIGINAL_STATE_KEY(roots[e['world']][0],roots[e['world']][1])]
        world_points[e['world']]=point;root_domains[e['world']]=domain
    additions=read(PH/'actual/Actual_New_Action_Records.json')['records'];assert len(additions)==2371
    for x in additions:
        measured=x['measured_receipt'];record={'candidate':x['candidate'],'verdict':x['verdict'],
            'original_score':x['original_score'],'receipt_id':'SHARED_ROOT_NEW_'+str(measured['PF_id']),
            'after_reference':{'kind':'new','descriptor':measured['after']} if measured['outcome']=='RETURNED' else None,
            'attributed_PF_calls':1,'attributed_solver_seconds':measured['seconds']}
        add(world_points[x['world']],action_key(x['candidate']),compact(record,PH,'SHARED_ROOT_PAID_NEW',hashlib.sha256(canon(x)).hexdigest()))
    # Reuse the independently checked CLOSED prefix only, never assume that old
    # terminal-partial science supplied missing branches or unfinished verdicts.
    journal=FULL/'actual/scientific.jsonl';manifest=read(FULL/'actual/Closed_Manifest.json')
    assert sha(journal)==manifest['members']['scientific.jsonl']['sha256']
    current_point=None;current_oldkey=None;chain='0'*64;seen_events=0
    with journal.open('rb') as stream,(FULL/'actual/capsules.bin').open('rb') as pack:
        for line in stream:
            assert time.perf_counter()-started<180
            e=json.loads(line);assert e['previous_sha256']==chain;chain=hashlib.sha256(line.rstrip(b'\n')).hexdigest();seen_events+=1
            data=e['data'];kind=e['event']
            if kind=='branch_initialized':
                net=decode_capsule(pack,data['initial_capsule'])['net'];c=data['current_cursor']
                current_oldkey=ORIGINAL_STATE_KEY(net,c);current_point=traced(net,c)
                # traced returns the old identity; the physical point is the
                # separately logged mapping, with actual masks still retained.
                current_point=maps[current_oldkey]
            elif kind=='PF_intent' and data['context'].get('phase')=='NEW_PRIMARY_QUERY':
                context=data['context'];assert context['state_key']==current_oldkey
                k=current_point+'|'+action_key(context['candidate'])
                blocked_intents[k]={'source':'OLD_FULL_SUFFIX_PF_INTENT','event_sha256':chain,'reason':'Native result not yet bound to closed verifier record'}
            elif kind in ('paid_query_reused','new_candidate_closed'):
                assert data['state_key']==current_oldkey
                rec=compact(data['record'],FULL,'OLD_CLOSED_FULL_SUFFIX_PREFIX',chain)
                add(current_point,data['action_key'],rec);blocked_intents.pop(current_point+'|'+data['action_key'],None)
            elif kind=='actual_commit':
                record=data['record'];selected=by_receipt[record['selected_receipt_id']]
                target=load_ref(selected['after_reference'])['net'];c=record['following_cursor']
                current_oldkey=ORIGINAL_STATE_KEY(target,c);traced(target,c);current_point=maps[current_oldkey]
    root_counts={}
    for world,domain in root_domains.items():
        point=world_points[world];rows=domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
        assert all(point+'|'+action_key(row) in cache for row in rows)
        root_counts[world]=len(rows)
    assert sum(root_counts.values())==6372
    put(B/'Compatible_Paid_Receipt_Index.json',{'cache':cache,'point_resource_proofs':proofs,'blocked_prior_incomplete_identities':blocked_intents,
        'all_four_root_cache_counts':root_counts,'all6372_root_receipts_present':True,
        'source_closed_prefix_journal_sha256':sha(journal),'source_events_read':seen_events,
        'new_model_PF_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Index preparation, not new controller performance. Original partial/exception/failed/missing results stay partial/UNKNOWN.'})
    put(B/'Result.json',{'exit_code':0,'status':'COMPATIBLE_PAID_INPUT_INDEX_COMPLETE_REQUIRES_EXTERNAL_SOURCE_AUDIT',
        'cache_entries':len(cache),'blocked_incomplete_identities':len(blocked_intents),'root_receipts':6372,
        'source_hashes':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),R/'work/operation_aware_paid_lookahead_v1.py',
            R/'work/project_paid_joint_successor_v1.py',R/'work/full_joint_suffix_benchmark_20261014.py',
            PH/'audit/Independent_Shared_Domain_Physics_Audit.json',FULL/'partial_audit_v1/Independent_Preserved_Prefix_Audit.json']},
        'new_model_PF_calls':0})
    print(json.dumps({'cache_entries':len(cache),'root_receipts':6372,'blocked_uncertain_prior_ids':len(blocked_intents),'new_model_PF_calls':0}))
if __name__=='__main__':main()
