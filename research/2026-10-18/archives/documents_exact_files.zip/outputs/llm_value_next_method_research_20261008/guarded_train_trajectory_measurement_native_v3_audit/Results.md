# TRAIN trajectory measurement results

The external reader verified 62 exact declared branch identities, 342 physical observation inputs, 44649 recorded candidate outcomes, and the original portfolio selector and both-branch cost arithmetic. It performed zero new solver/model calls. Physical observation derivation and continuous replay were actual separately charged numerical work in the collection.

Protected nontrivial episode worlds: 24; represented families: 4; informative distinct-first-action root pairs: 19; protected-versus-nonprotected pairs: 1. The predeclared target-feasibility gate is not passed; no episode-recovery model training is justified by this collection.

Four original guarded searches were reused; 58 genuinely missing guarded branches were planned. The literal unguarded D-SE dataset is preserved separately, and this dataset is labelled G-DSE. The nullable-field readiness failure, its one real solver return and all unexecuted records remain preserved separately. Current table fields are measured data; missing fields are explicit tags, never zero-imputed. Candidate outcomes are one-step labels only. Root contrasts contain outcomes of actual executed sequences; no unexecuted candidate has a fabricated episode reward.

Native and current OV display counters are retained separately at numerically equal 1.05 boundaries; they are not asserted equal. All per-bus UV memberships remain exact, and continuous voltages/metrics agree within1e-10. Current full-table observations receive their own strict independent replay. Original solver, score, verifier, selector and1.05+1e-8 common guard remain unchanged. The first failed reuse-readiness attempt had one real solver return and zero new controller searches; its closed source/data package is preserved separately.

This is historical TRAIN development data, not independent confirmation, LLM performance, novelty or superiority. Exact physical input and branch costs are retained. Previously evaluated validation cases and the sealed bank remain excluded. The stopped VCSA intervention remains stopped.
