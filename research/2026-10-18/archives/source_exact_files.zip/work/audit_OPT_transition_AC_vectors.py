"""Separate saved-array reader: source/identity/algebra/cost checks, zero solves."""
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import gzip, json, math, os, time
import numpy as np
from candidate_process_evidence_utils import ROOT, read, sha, write, seal

P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
S=P/'OPT_transition_AC_vector_measurement'; T=P/'measured_OPT_transition_inventory'
OUT=P/'OPT_transition_AC_vector_external_audit'
assert read(S/'status.json')['stage']=='complete_OPT_vector_measurement'
assert not OUT.exists(), 'No duplicate reader'
OUT.mkdir(); started=time.perf_counter()
write(OUT/'audit.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__)),'started_at_utc':datetime.now(timezone.utc).isoformat()})
manifest=read(S/'Supplement_Manifest.json')
assert all(sha(S/name)==v['sha256'] and (S/name).stat().st_size==v['bytes']
           for name,v in manifest.items() if not name.startswith('source/'))
protocol=read(S/'Protocol.json'); summary=read(S/'Summary.json'); states=read(S/'Actual_State_Records.json')
assert sha(ROOT/'work/measure_OPT_transition_AC_vectors.py')==protocol['source_sha256']
assert sha(ROOT/'work/current_state_linearized_control_native_v3.py')==protocol['original_control_source_sha256']
assert sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json')==protocol['network_sha256']
assert sha(T/'Actual_OPT_Transition_Rows.jsonl.gz')==protocol['transition_rows_sha256']
assert read(P/'measured_OPT_transition_inventory_external_audit_v2/Independent_Transition_Source_and_Target_Audit.json')['all_passed']
def rows(path):
    with gzip.open(path,'rt',encoding='utf8') as f:return [json.loads(line) for line in f]
def vector(frame):
    i=frame['columns'].index('vm_pu'); values={b:r[i] for b,r in zip(frame['index'],frame['values'])}
    return np.array([values[b] for b in range(118)],dtype=np.float64)
original={r['transition_id']:r for r in rows(T/'Actual_OPT_Transition_Rows.jsonl.gz')}
actual={r['transition_id']:r for r in rows(S/'Actual_Transition_Vector_Records.jsonl.gz')}
assert set(original)==set(actual)==set(protocol['all_transition_ids']) and len(actual)==216
assert {r['before_sha256'] for r in states}==set(protocol['all_current_hashes']) and len(states)==193
arrays={}; algebra_checks=0
for r in states:
    h=r['before_sha256']
    if r['status']=='failed_response_unknown':continue
    path=S/'states'/(h+'.npz'); assert sha(path)==r['array_sha256']
    with np.load(path,allow_pickle=False) as data:a={k:data[k] for k in data.files}
    assert set(a)=={'current_vm','dVm_per_MVAr','jacobian','rhs','response'}
    assert a['current_vm'].shape==(118,) and a['dVm_per_MVAr'].shape==(118,118)
    assert all(np.isfinite(v).all() for v in a.values())
    assert np.max(np.abs(a['jacobian']@a['response']-a['rhs']))<=1e-8
    # Infer original native PQ row IDs from the single nonzero action column
    # of each Q-equation RHS; independently reconstruct magnitude response.
    pq_rhs=a['rhs'][117:]; pq_response=a['response'][117:]
    reconstructed=np.zeros((118,118))
    for rhs,response in zip(pq_rhs,pq_response):
        columns=np.flatnonzero(rhs); assert len(columns)==1
        bus=int(columns[0]); reconstructed[bus]=response
    assert np.allclose(reconstructed,a['dVm_per_MVAr'],atol=1e-14,rtol=0)
    arrays[h]=a; algebra_checks+=1
worlds=defaultdict(list); forecasts=0; scalar_checks=0
for ident,r in actual.items():
    src=original[ident]; h=src['before_observation_sha256']
    assert r['before_sha256']==h and r['action']==src['model_input']['candidate_action']
    assert r['provenance']==src['audit']['source_provenance']
    before=vector(src['model_input']['current_physical_observation']['physical_tables']['res_bus'])
    after=vector(src['measured_target']['next_res_bus'])
    assert np.array_equal(before,r['current_vm']) and np.array_equal(after,r['measured_next_vm'])
    assert np.array_equal(after-before,r['measured_delta_vm']);scalar_checks+=118*3
    energy=float(np.mean((after-before)**2));assert abs(energy-r['persistence_MSE'])<=1e-18
    assert r['actual_native_PF_convergence_of_analytic_forecast'] is None
    if h not in arrays:
        assert r['status']=='unknown_failed_analytic_state';continue
    a=arrays[h];assert np.allclose(a['current_vm'],before,atol=1e-14,rtol=0)
    pred=a['current_vm']+r['action']['q_abs_mvar']*a['dVm_per_MVAr'][:,r['action']['bus']]
    assert np.array_equal(pred,r['analytic_next_vm'])
    assert np.array_equal(pred-before,r['analytic_delta_vm']);scalar_checks+=118*2
    mse=float(np.mean((pred-after)**2)); assert abs(mse-r['AC_MSE'])<=1e-18
    assert abs(float(np.max(np.abs(pred-after)))-r['AC_max_abs_error'])<=1e-14
    assert r['predicted_upper_guard_excess']==bool(pred.max()>1.05+1e-8)
    assert r['measured_upper_guard_excess']==bool(after.max()>1.05+1e-8)
    for p in r['provenance']:worlds[p['world_sha256']].append((mse,energy))
    forecasts+=1
assert len(worlds)==summary['actual_worlds']
for w,v in worlds.items():
    for index,key in enumerate(('AC_MSE','persistence_MSE')):
        assert abs(sum(x[index] for x in v)/len(v)-summary['worlds'][w][key])<=1e-18
for key in ('AC_MSE','persistence_MSE'):
    expected=sum(v[key] for v in summary['worlds'].values())/len(worlds)
    assert abs(expected-summary['equal_world_MSE'][key])<=1e-18
groups=read(T/'Exact_Same_Before_Action_Contrast_Groups.json')
assert len(groups)==len(summary['same_before_contrasts'])==23
for g,result in zip(groups,summary['same_before_contrasts']):
    assert g['transition_ids']==result['transition_ids']
    a,b=(actual[i] for i in g['transition_ids'])
    diff=np.array(a['measured_next_vm'])-b['measured_next_vm']
    assert abs(float(np.mean(diff**2))-result['measured_contrast_energy'])<=1e-18
    if result['AC_contrast_MSE'] is not None:
        pdiff=np.array(a['analytic_next_vm'])-b['analytic_next_vm']
        assert abs(float(np.mean((pdiff-diff)**2))-result['AC_contrast_MSE'])<=1e-18
journal=[json.loads(l) for l in (S/'Actual_State_Journal.jsonl').read_text().splitlines()]
assert [r['before_sha256'] for r in journal if r['event']=='state_attempt']==protocol['all_current_hashes']
assert [r['before_sha256'] for r in journal if r['event']=='state_closed']==protocol['all_current_hashes']
c=summary['costs'];assert c['linear_solve_attempts']==c['linear_solve_returns']==algebra_checks==193
assert c['direct_converter_attempts']==c['direct_converter_returns']==2*algebra_checks
assert c['analytic_action_vectors']==forecasts==216 and c['state_exceptions']==0
assert c['new_PF_calls']==c['new_model_calls']==c['new_optimizer_steps']==c['new_cloud_calls']==0
assert math.isclose(sum(r['workflow_seconds'] for r in states),c['derivation_seconds'],rel_tol=1e-12)
certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,
    'actual_transition_identities':216,'actual_native_magnitude_vectors':216,'actual_J_response_projection_checks':algebra_checks,
    'actual_vector_scalar_checks':scalar_checks,'same_before_contrast_checks':23,'OPT_worlds':23,
    'exact_actual_new_cost_arithmetic_and_journal_prefixes_verified':True,'original_AC_source_and_old_results_unchanged':True,
    'all_UNKNOWN_convergence_and_teacher_selection_limits_retained':True,
    'new_reader_model_PF_optimizer_linear_solve_cloud_calls':0,'reader_seconds':time.perf_counter()-started}
write(OUT/'Independent_Source_Vector_Algebra_and_Cost_Audit.json',certificate)
seal(OUT,{'Independent_Source_Vector_Algebra_and_Cost_Audit.json':OUT/'Independent_Source_Vector_Algebra_and_Cost_Audit.json',
    'original_measurement_protocol.json':S/'Protocol.json','original_measurement_summary.json':S/'Summary.json',
    'source/reader.py':Path(__file__)},'Verified_OPT_Transition_Vector_Audit.zip')
write(OUT/'status.json',{'stage':'complete_saved_vector_external_audit','all_passed':True,'new_model_PF_linear_solves':0})
print(json.dumps(certificate,indent=2))
