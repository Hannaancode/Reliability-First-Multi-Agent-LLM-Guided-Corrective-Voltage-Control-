"""Save verified task progress and prepare a bounded own-code/proof publication."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/environment_and_qa_publication_20261029'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def rd(p):
    return json.loads((R / p).read_text('utf-8-sig'))

def put(p, x):
    p.write_text(json.dumps(x, indent=2, ensure_ascii=False) + '\n', 'utf-8')

def main():
    assert not O.exists()
    audit = 'outputs/veragrid_native_prompt_contract_20261029/Independent_Prompt_Pack_Audit.json'
    assert rd(audit)['status'] == 'PASS_ALL150_EXACT_NATIVE_NO_TOOL_PROMPTS_AND_PINNED_INPUTS'
    qa = 'outputs/thesis_environment_contracts_20261029/Final_Visual_And_Evidence_QA.json'
    assert rd(qa)['status'].startswith('PASS_')
    now = datetime.now(timezone.utc).isoformat()
    resume_path = R / 'outputs/research_resumption_20261028/Current_Resume.json'
    resume = rd(resume_path.relative_to(R))
    resume.update(at_utc=now, updated_at_utc=now, public_QA_native_prompts=audit,
                  public_QA_next='outputs/veragrid_native_prompt_contract_20261029/Verified_Decision_And_Next_Work.md')
    resume['next'][0] = ('G2/G3 QA: exact native full-circuit/no-tool prompt pack ALL150 independently PASS. Full runner final-letter parser supersedes provisional standalone-evaluator primary; no actual outcomes accessed. Next bind recovered RAG recipe/model/index to exact available artifacts, check training overlap and freeze a named public no-tool scale/controls/inference-cost protocol with actual loader/token/context/preservation gates. Do not label a public-base QA test as original trained voltage/RAG performance.')
    put(resume_path, resume)
    tasks_path = R / 'outputs/research_tasks_20261014/Tasks.json'
    tasks = rd(tasks_path.relative_to(R))
    g2 = next(x for x in tasks['tasks'] if x['checklist_id'] == 'G2')
    assert all(x['id'] != 'G2.5b' for x in g2['subtasks'])
    g2['subtasks'].append({'id': 'G2.5b', 'completed': True, 'description': 'Recover the actual author no-tool circuit/prompt/parser contract and independently reconstruct all150 label-hidden prompts. No inference or performance claim.', 'evidence': audit, 'verified_at_save': now})
    tasks['updated_at_utc'] = now
    put(tasks_path, tasks)
    msg = ('T19 closed and 14/35 thesis requirements complete; reviewed draft121pages/18tables/22figures/35references. Public VeraGrid all150 label-hidden input views and exact full-circuit no-tool prompts independently PASS. Actual native final-letter parser identified; earlier standalone-primary suggestion superseded before any model result. G2.5a/G2.5b preparation complete, G2 and all6 final research goals remain OPEN.0newmodel/PF/OPF/training/GPU; no active result dependency/timer. Exact RAG500 historical recipe uses public0.5B without adapter; runtime/index/revisions still unresolved. Do not substitute private voltage-command adapter or claim a winning benchmark.')
    head = '## Public QA native prompt contract verified — ' + now + '\n\n' + msg + '\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        p = R / rel
        p.write_text(head + p.read_text('utf-8-sig'), 'utf-8')
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n' + now + '\n' + msg + '\n')
    O.mkdir()
    public_files = {
        'Environment_Contracts.json': 'outputs/environment_contracts_20261029/Environment_Contracts.json',
        'Environment_Contract_Check.json': 'outputs/environment_contracts_20261029/Source_And_Arithmetic_Check.json',
        'Public_QA_Prompt_Audit.json': audit,
        'Public_QA_Next_Decision.md': resume['public_QA_next'],
        'Thesis_Visual_And_Evidence_QA.json': qa,
        'Thesis_Checklist.json': 'outputs/thesis_research_closure_20261028/Tasks.json'
    }
    for name, source in public_files.items():
        shutil.copyfile(R / source, O / name)
    codes = ['build_environment_contracts_20261029.py', 'check_environment_contracts_20261029.py',
             'integrate_environment_contracts_thesis_20261029.py', 'finish_environment_thesis_layout_20261029.py',
             'paginate_environment_thesis_20261029.ps1', 'close_environment_thesis_20261029.py',
             'veragrid_label_hidden_interface_20261029.py', 'check_veragrid_interface_boundary_20261029.py',
             'admit_veragrid_frozen_questions_20261029.py', 'audit_veragrid_frozen_views_20261029.py',
             'build_veragrid_native_prompt_pack_20261029.py', 'audit_veragrid_native_prompt_pack_20261029.py',
             'save_and_publish_prompt_contracts_20261029.py']
    proofs = ['outputs/veragrid_source_admission_20261029/' + f for f in ['Intake_Record.json', 'Source_Transfer_Correction.json', 'Dataset_Intake_Protocol.json', 'Synthetic_Boundary_And_Parser_Check.json', 'Actual150_Admission.json', 'Independent_Input_View_Audit.json']]
    proofs += ['outputs/veragrid_native_prompt_contract_20261029/' + f for f in ['Pinned_Input_Files.json', 'Prospective_Prompt_Pack_Protocol.json', 'Prompt_Pack_Result.json', 'Independent_Prompt_Pack_Audit.json']]
    proofs += ['outputs/thesis_environment_contracts_20261029/' + f for f in ['Integration_Record.json', 'Layout_Repair_Record.json', 'Visual_Review_Record.json', 'Pagination_Record.json', 'Thesis_Evidence_Navigation.json']]
    members = ['work/' + f for f in codes] + proofs
    optional = R / 'outputs/veragrid_native_prompt_contract_20261029/Circuit_Transfer_Newline_Correction.json'
    if optional.exists(): members.append(optional.relative_to(R).as_posix())
    from prepare_github_research_snapshot_20261018 import SECRET
    index = []
    with zipfile.ZipFile(O / 'Own_Code_And_Compact_Proofs.zip', 'x', zipfile.ZIP_DEFLATED) as z:
        for name in members:
            p = R / name
            text = p.read_text('utf-8-sig')
            assert not any(s.search(text) for s in SECRET), name
            assert '/source/' not in name and '/participant/' not in name and '/administrator/' not in name
            z.write(p, name)
            index.append({'path': name, 'bytes': p.stat().st_size, 'sha256': sha(p)})
    with zipfile.ZipFile(O / 'Own_Code_And_Compact_Proofs.zip') as z:
        assert z.testzip() is None
        for row in index: assert hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256']
    put(O / 'Artifact_Index.json', {'at_utc': now, 'members': index, 'raw_backup_complete': False,
        'excluded': ['private weights and physical NETs', 'third-party sources and full public questions/circuit/reference labels', 'model outputs and raw RAG transcripts', 'full thesis DOCX/PDF'], 'new_scientific_calls': 0, 'all_six_goals': 'OPEN'})
    compact = {k: resume[k] for k in ['at_utc', 'all_six_final_goals', 'scientific_jobs', 'gpu_assignments', 'waiting_check', 'thesis_integration', 'thesis_closed_requirements', 'next', 'public_QA_admission', 'public_QA_native_prompts', 'public_QA_next']}
    put(O / 'Current_Progress.json', compact)
    files = []
    for p in sorted(O.iterdir()):
        b = p.read_bytes()
        if p.suffix != '.zip': assert not any(s.search(b.decode('utf-8')) for s in SECRET)
        files.append({'local': p.relative_to(R).as_posix(), 'path': 'research_progress/20261029_environment_publicQA/' + p.name,
                      'bytes': len(b), 'sha256': sha(p), 'blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()})
    put(O / 'Publication_Map.json', files)
    print(json.dumps({'files': len(files), 'members': len(index), 'bytes': sum(f['bytes'] for f in files), 'thesis_complete': 14, 'new_science': 0}))

if __name__ == '__main__':
    main()
