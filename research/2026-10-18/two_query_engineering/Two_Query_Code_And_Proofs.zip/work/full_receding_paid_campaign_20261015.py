"""Prospective complete receding numerical comparison, no LLM attribution claim.

The source has no import-time launch. A single coordinator starts this worker
once, waits for its actual process to end, then starts one independent reader.
"""
import argparse,ast,copy,hashlib,importlib.metadata,json,os,random,subprocess,sys,time,traceback
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
from receding_paid_runtime_v2 import PaidRecedingRuntime,restore_dependency_prefix,sha,read,put
from paid_receding_commit_and_history_v1 import History,initialize,restore_complete,fields,fingerprint
from bounded_paid_lookahead_physics_20261014 import Evidence as PreviousEvidence,canon
from joint_reallocation_opportunity_core_v1 import load_endpoint
from dynamic_actual_mask_guidance_v1 import identity
from compile_lookahead_paid_input_cache_20261014 import point_key
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks
from durable_opaque_evidence_store_v1 import inventory
R=Path(__file__).resolve().parents[1];B=R/'outputs/full_receding_paid_campaign_20261015'
DEP=R/'outputs/receding_warm_dependency_closure_20261015'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
METHODS=('immediate1_followup16','breadth4_followup4')
class Evidence(PreviousEvidence):
    def event(self,name,data):
        start=time.perf_counter();raw=canon({'event':name,'data':data,'previous_sha256':self.previous,'protocol_sha256':self.p['protocol_sha256']})
        self.previous=hashlib.sha256(raw).hexdigest();self.journal.write(raw+b'\n');self.journal.flush();os.fsync(self.journal.fileno())
        self.costs['preservation_seconds']+=time.perf_counter()-start
def local_source_closure(paths):
    pending=list(paths);seen=set()
    while pending:
        path=Path(pending.pop()).resolve()
        if path in seen:continue
        seen.add(path)
        if path.suffix!='.py':continue
        for node in ast.walk(ast.parse(path.read_text('utf-8-sig'))):
            names=[a.name for a in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
            for name in names:
                other=R/'work'/Path(*name.split('.')).with_suffix('.py')
                if other.is_file() and other.resolve() not in seen:pending.append(other)
    return sorted(seen)
def pin(p):
    for name,h in p['source_input_sha256'].items():assert sha(R/name)==h,name
    assert {n:importlib.metadata.version(n) for n in p['runtime_versions']}==p['runtime_versions']
def prepare():
    B.mkdir(exist_ok=False)
    a=read(R/'outputs/receding_durable_engine_independent_audit_20261015/Independent_Warm_Engine_Audit.json')
    assert a['checked_decisions']==8 and a['checked_ordered_query_messages']==12872
    entries=read(OLD/'preparation/Protocol.json')['current_endpoints'];assert len(entries)==4
    _,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    files=local_source_closure([Path(__file__),R/'work/audit_full_receding_paid_campaign_20261015.py',R/'work/run_full_receding_paid_pipeline_20261015.py'])
    files += [DEP/'Paid_Warm_Dependencies.json',DEP/'Result.json',OLD/'preparation/Protocol.json',
        R/'outputs/receding_durable_engine_independent_audit_20261015/Independent_Warm_Engine_Audit.json',
        R/'outputs/receding_dependency_cold_prefix_20261015/Result.json',
        R/'outputs/receding_runtime_v2_source_20261015/Source_Certificate.json']
    refs={};worlds=[]
    context_files=list((R/'outputs/bounded_paid_lookahead_physics_20261014/actual/contexts').glob('*.npz'))
    context_files+=list((R/'outputs/actual_mask_jacobian_engineering_20261014/actual').glob('*Context.npz'))
    context_files+=list((R/'outputs/all30_dynamic_actual_guidance_storage_v2_20261014/actual').glob('*.npz'))
    for path in sorted(context_files):
        with np.load(path,allow_pickle=False) as z:c={k:z[k].copy() for k in z.files}
        ident=identity(c);refs[ident]={'identity':ident,'path':str(path.relative_to(R)),'sha256':sha(path)};files.append(path)
    for e in entries:
        net,c,_=load_endpoint(e);domain=build_current_domain(net,c,runner=runner,zones=zones)
        expanded=initialize(net,domain['expanded_cursor_for_separately_fixed_future_protocol'])
        worlds.append({'world':e['world'],'exact_initial_point_key':point_key(net,expanded),'initial_metrics':runner.rescue.grid_metrics(net),
            'remaining_original_operations':expanded['remaining_original_device_operation_slots'],
            'full_original_budget':25,'inspected_development_NOT_unused_confirmation':True})
        descriptor=read(R/e['endpoint_record']);files.extend([R/e['endpoint_record'],R/e['decoded_net_container_root']/descriptor['endpoint']['path']])
    p={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'study':'Full first-move receding paid nonlinear planning after exact inspected trained-LoRA prefixes; numerical comparison only.',
        'source_input_sha256':{str(path.relative_to(R)):sha(path) for path in sorted(set(files))},
        'runtime_versions':{n:importlib.metadata.version(n) for n in ('numpy','scipy','pandas','pandapower')},
        'endpoints':entries,'all4_initial_identities':worlds,'methods':list(METHODS),
        'execution_order':[[e['world'],m] for e in entries for m in METHODS],
        'warm_numeric_contexts':list(refs.values()),'warm_dependency_sha256':sha(DEP/'Paid_Warm_Dependencies.json'),
        'runtime_source_sha256':sha(R/'work/receding_paid_runtime_v2.py'),
        'solver_kwargs':read(R/'outputs/shared_current_domain_physics_guarded_v2_20261014/Protocol.json')['solver_kwargs'],
        'science_bound_seconds':14400,'reader_bound_seconds':7200,'cold_bound_seconds':300,
        'maximum_PF_attempts':150000,'maximum_storage_bytes':96*1024**3,'maximum_history_bytes':2*1024**3,
        'fixed_primary_gate':'ALL8 complete protected suffixes, source/cost/continuous replay/checkpoint/independent audit PASS; breadth strictly lower finalUV in >=2ofALL4 exact worlds, noUVloss. Otherwise FAIL if complete; any partial branch makes all4 gate UNKNOWN.',
        'control':'Identical all-current ordinary/owned-donor domain, full paid first menu,16followup query allowance and original remaining operation/cap/guard limits for both methods. Width4x4 versus immediate1x16 already fixed BEFORE new full outcomes; first move only then actual-state replan.',
        'old_evidence':'22721 exact paid physical receipts/24641 paid numerical forecasts and prior contexts reused by exact current identity. All old costs attributed, not free; no repeated old primary query. Independent selected-commit continuous replay is an explicitly NEW charged role.',
        'stop_rules':'UV0, original remaining device operations0, or complete current native menu no accepted protected first move. Unknown/missing/timeout/nonfinite evidence never means a negative or physical impossibility.',
        'failure':'No scientific retry, source/settings change, old/new budget extension or automatic replacement. Always preserve partial journals/capsules/checkpoints/closed branches and all exceptions; reader audits closed prefixes and leaves unexecuted identities UNKNOWN.',
        'cold_gate':'First complete actual runtime commitment checkpoint restored in a real cold process BEFORE more science; all state,complete source/input/event/receipt/context/forecast/RNG/deadline/next-phase prefixes verified,0newscience. Every further checkpoint independently restored by reader.',
        'scope':'Not original full DSE, all federation cases, hardware intermediate switching certificate, fresh LLM inference/effect, deployment speed, novelty, or unused confirmation. Report all4 roots and full actual and attributed costs even on failure.',
        'next_after_pass':'Separately prospective severe-world expansion and original LOCAL family-v2 actual-model versus equally informed trained/numerical proposer controls; no automatic GPU from a planning gate.',
        'original_frozen_assets_unchanged':True}
    put(B/'Protocol.json',p);put(B/'Preparation_Frozen_Checks.json',frozen_checks())
    put(B/'Preparation_Actual_Input_Readiness.json',{'status':'PASS_ALL4_SOURCE_CAUSAL_INPUTS_AND_PRIOR_COMPONENT_CERTIFICATES',
        'prepared_inputs':worlds,'new_scientific_calls':0,'science_not_launched':True})
    print(json.dumps({'full_receding_protocol_prepared':True,'all4_worlds':4,'new_scientific_calls':0}))
def execution_protocol():
    p=read(B/'Protocol.json');pin(p);bound=read(B/'Execution_Bound.json')
    p.update(absolute_deadline_utc=bound['absolute_deadline_utc'],protocol_sha256=sha(B/'Protocol.json'))
    assert bound['protocol_sha256']==p['protocol_sha256']
    return p
def cold(request_path):
    p=execution_protocol();out=Path(request_path).parent/'cold';out.mkdir(exist_ok=False)
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'argv':sys.argv})
    def forbidden(*a,**k):raise AssertionError('Cold process cannot make scientific calls')
    for n in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,n,forbidden)
    started=time.perf_counter();request=read(Path(request_path));state,history=restore_complete(R/request['checkpoint'],request['receipt'])
    assert state['protocol_sha256']==p['protocol_sha256'] and state['absolute_deadline_utc']==request['original_deadline_utc']==p['absolute_deadline_utc']
    assert datetime.now(timezone.utc)<datetime.fromisoformat(p['absolute_deadline_utc'])
    dependencies=restore_dependency_prefix(state,warm_dependencies=read(DEP/'Paid_Warm_Dependencies.json'),source_anchors=request['source_anchors'])
    assert point_key(state['net'],state['cursor'])==request['expected_point_key']
    assert history[-1]['event']=='actual_receding_first_commit' and state['next_phase']['lookahead_second_is_not_automatically_committed']
    random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
    assert fingerprint(state['net'],state['cursor'])==request['receipt']['state_fingerprint']
    assert dependencies['saved_prefix_only'] and dependencies['new_scientific_calls']==0
    put(out/'Result.json',{'status':'PASS_COLD_COMPLETE_RECEDING_PREFIX','new_scientific_calls':0,
        'closed_scientific_identities':len(dependencies['closed_intent_ids']),'restored_paid_cache_entries':len(dependencies['cache']),
        'restored_forecasts':len(dependencies['paid_forecasts']),'complete_history_records':len(history),
        'restored_numeric_contexts':len(dependencies['contexts']),'workflow_seconds':time.perf_counter()-started,
        'original_absolute_deadline_utc':state['absolute_deadline_utc'],'point_key':request['expected_point_key']})
def worker():
    p=execution_protocol();out=B/'actual';out.mkdir(exist_ok=False);(out/'contexts').mkdir();(out/'checkpoints').mkdir()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'argv':sys.argv,'protocol_sha256':p['protocol_sha256']})
    started=time.perf_counter();evidence=None;history=None;branches=[];code=1;runtime=None
    numeric={k:0 for k in ('public_derivative_attempts','public_derivative_returns','LU_factor_attempts','LU_factor_returns',
        'LU_solve_attempts','LU_solve_returns','RHS_columns','exact_context_reuses','compile_seconds','new_forecasts','exact_paid_forecast_reuses')}
    try:
        put(out/'Start_Frozen_Checks.json',frozen_checks());evidence=Evidence(p,out);pp.runpp=evidence.solve
        warm=read(DEP/'Paid_Warm_Dependencies.json');contexts={}
        for r in p['warm_numeric_contexts']:
            with np.load(R/r['path'],allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
            assert identity(c)==r['identity'];contexts[r['identity']]=c
        _,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
        history=History(out/'Complete_Runtime_History.bin',source_anchor=p['runtime_source_sha256'],input_anchor=p['warm_dependency_sha256'],max_bytes=p['maximum_history_bytes'])
        source_anchors={'runtime':p['runtime_source_sha256'],'worker':sha(Path(__file__)),'protocol':p['protocol_sha256']}
        def cold_gate(request):
            path=B/'actual_cold_request';path.mkdir(exist_ok=False);put(path/'Request.json',request)
            with (path/'console.log').open('x',encoding='utf-8') as log:
                child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold',str(path/'Request.json')],
                    stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
                status=child.wait(timeout=p['cold_bound_seconds'])
            assert status==0,'Actual runtime cold gate failed; stop science, preserve source/logs.'
            return read(path/'cold/Result.json')
        runtime=PaidRecedingRuntime(out=out,protocol=p,evidence=evidence,history=history,runner=runner,zones=zones,
            cache=copy.deepcopy(warm['cache']),blocked=warm['blocked_prior_incomplete_identities'],contexts=contexts,
            numeric_cost=numeric,paid_forecasts=copy.deepcopy(warm['existing_numeric_forecasts']),warm_dependency_path=DEP/'Paid_Warm_Dependencies.json',
            warm_context_refs=p['warm_numeric_contexts'],source_anchors=source_anchors,cold_gate=cold_gate)
        for e in p['endpoints']:
            for mode in METHODS:
                evidence.admit();net,original,rng=load_endpoint(e);domain=build_current_domain(net,original,runner=runner,zones=zones)
                cursor=initialize(net,domain['expanded_cursor_for_separately_fixed_future_protocol'])
                random.setstate(rng['python_rng']);np.random.set_state(rng['numpy_rng'])
                evidence.event('receding_branch_initialized',{'world':e['world'],'method':mode,'initial_point':point_key(net,cursor),
                    'initial_metrics':runner.rescue.grid_metrics(net),'initial_cursor':cursor,'initial_net':evidence.capsule(net,'branch_initial')})
                _,_,result=runtime.run_branch(net,cursor,world=e['world'],mode=mode)
                result['world']=e['world'];put(out/f'Branch_{len(branches)+1}.json',result);branches.append(result)
                put(out/f'Progress_{len(branches)}.json',{'closed_branches':len(branches),'current':{'world':e['world'],'method':mode},
                    'actual_costs':copy.deepcopy(evidence.costs),'numerical_costs':copy.deepcopy(numeric),'all4_gate':'PENDING_INDEPENDENT_READER'})
        code=0
    except BaseException as error:
        with (out/'Failure_Traceback.txt').open('x',encoding='utf-8') as f:traceback.print_exc(file=f);f.flush();os.fsync(f.fileno())
        if evidence:evidence.event('terminal_partial_failure',{'exception':type(error).__name__,'message':str(error),'all4_gate':'UNKNOWN','no_scientific_retry':True})
    finally:
        costs=copy.deepcopy(evidence.costs) if evidence else None
        if evidence:evidence.close()
        if history:history.close()
        put(out/'Result.json',{'exit_code':code,'scientific_status':'COMPLETE' if code==0 else 'TERMINAL_PARTIAL',
            'branches':branches,'missing_closed_branch_identities':[[w,m] for w,m in p['execution_order'] if not any(b['world']==w and b['mode']==m for b in branches)],
            'actual_new_costs':costs,'numerical_costs':numeric,'checkpoint_requests':runtime.checkpoints if runtime else [],
            'workflow_seconds_before_manifest':time.perf_counter()-started,'all4_gate':'REQUIRES_INDEPENDENT_COMPLETE_READER' if code==0 else 'UNKNOWN',
            'fresh_LLM_inference_or_whole_DSE_superiority':'NOT_TESTED','old_evidence_costs_still_payable':True})
        put(out/'Closed_Manifest.json',{'exit_code':code,'members':inventory(out,hashes=True)})
    raise SystemExit(code)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--worker',action='store_true');parser.add_argument('--cold')
    args=parser.parse_args();assert sum((bool(args.prepare),bool(args.worker),bool(args.cold)))==1
    if args.prepare:prepare()
    elif args.worker:worker()
    else:cold(args.cold)
