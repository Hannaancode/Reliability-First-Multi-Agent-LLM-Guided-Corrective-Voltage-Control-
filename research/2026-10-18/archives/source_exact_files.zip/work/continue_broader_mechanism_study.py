"""One conditional CPU owner: independent broader audit, then fixed component study."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes, hashlib, json, os, subprocess, sys, time
from ctypes import wintypes
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
OUT=ROOT/'outputs/llm_value_broader_development'
read=lambda p:json.loads(p.read_text())
with (OUT/'mechanism_continuation.claim').open('x') as f:f.write(str(os.getpid()))
state={'owner_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat(),
       'stage':'waiting_for_completed_120_row_screen_and_stopped_writers','new_model_calls':0,'original_rows_rerun':False}
def save():
    state['updated_at_utc']=datetime.now(timezone.utc).isoformat()
    temporary=OUT/'mechanism_continuation.tmp';temporary.write_text(json.dumps(state,indent=2));temporary.replace(OUT/'mechanism_continuation_status.json')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
def alive(pid):
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:
        if ctypes.get_last_error()==87:return False
        raise RuntimeError('Cannot verify old owner liveness')
    try:
        code=wintypes.DWORD();assert kernel.GetExitCodeProcess(handle,ctypes.byref(code));return code.value==259
    finally:kernel.CloseHandle(handle)
def run(script,log,*args):
    with (OUT/log).open('x') as f:
        subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),script,*args],stdout=f,stderr=subprocess.STDOUT,check=True)
save()
try:
    def verify_ready_sources():
        manifest=read(OUT/'Followon_Readiness_Manifest.json')
        for name,digest in manifest['source_sha256'].items():
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest, 'Prospective follow-on source changed'
    verify_ready_sources()
    deadline=time.monotonic()+14400
    while time.monotonic()<deadline:
        upstream=read(OUT/'clean_analysis_continuation_status.json')
        pid=int((OUT/'clean_analysis_continuation.claim').read_text())
        if not alive(pid):
            assert upstream['stage']=='genuine_clean_value_screen_complete_pending_report','Upstream did not complete; preserve partials'
            break
        time.sleep(20)
    else:raise RuntimeError('Bounded upstream wait ended')
    for name in ['gpu_execution','cpu_controls','cpu_screen']:
        assert not alive(int((OUT/(name+'.claim')).read_text())), 'Upstream writer still active'
    assert read(OUT/'gpu_execution_status.json')['runtime_released']
    verify_ready_sources()
    state['stage']='auditing_120_actual_rows';save()
    run('work/audit_broader_value_and_components.py','broader_independent_audit.log')
    assert read(OUT/'Broader_Screen_Completion_Audit.json')['all_gates_passed']
    assert not (OUT/'bus_Q_attribution').exists()
    state['stage']='executing_16_prospective_bus_Q_component_trials';save()
    run('work/run_broader_bus_Q_attribution.py','broader_component_trials.log')
    state['stage']='auditing_16_actual_component_trials';save()
    run('work/audit_broader_value_and_components.py','broader_component_audit.log','components')
    state.update(stage='broader_screen_and_component_study_complete_audited',finished_at_utc=datetime.now(timezone.utc).isoformat());save()
except Exception as exc:
    state.update(stage='mechanism_continuation_failed_preserve_actual_outcomes',failure_type=type(exc).__name__);save();raise
