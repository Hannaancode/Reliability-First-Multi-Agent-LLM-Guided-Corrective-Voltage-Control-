"""Locked partial-aware independent physics and continuous policy replay."""
import copy,hashlib,json,os,pickle,time,traceback
from pathlib import Path
from datetime import datetime,timezone
from run_public13_remaining_published_cohort_20261021 import sha,put,binary,regime,metrics
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/public13_full_cohort_preparation_20261021';PRIMARY=ROOT/'outputs/public13_remaining_published_cohort_20261021';OUT=ROOT/'outputs/public13_published_cohort_independent_20261021'
def main():
    OUT.mkdir(exist_ok=False);began=time.monotonic();put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    p=json.loads((PREP/'Protocol.json').read_text());deadline=began+p['reader_seconds'];end=json.loads((ROOT/p['primary_coordination']/'End_ACK.json').read_text());assert end['actual_owned_chain_ended'] and end['exit_code']==0
    for n,h in p['source_and_input_hashes'].items():assert sha(ROOT/n)==h
    for f in json.loads((PRIMARY/'Closed_Manifest.json').read_text())['files']:assert (PRIMARY/f['path']).stat().st_size==f['bytes'] and sha(PRIMARY/f['path'])==f['sha256']
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    from pandapower.pypower.makeSbus import makeSbus
    np=b.np;torch=b.torch;torch.set_num_threads(1);costs={k:0 for k in ['PF_attempts','PF_returns','PF_exceptions','agent_forward_attempts','agent_forward_returns','checkpoint_loads','native_conversions','control_transition_paid_replay_lookups']};costs['new_LLM_training_optimizer_GPU_calls']=0
    stream=(OUT/'events.jsonl').open('x',encoding='utf-8');previous='0'*64
    def event(kind,**data):
        nonlocal previous
        v={'kind':kind,'seconds':time.monotonic()-began,'previous':previous,**data};h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest();stream.write(json.dumps({'event':v,'sha256':h})+'\n');stream.flush();os.fsync(stream.fileno());previous=h
    def bound():assert time.monotonic()<deadline-10,'Original independent-reader bound; no retry/extension'
    try:
        result=json.loads((PRIMARY/'Result.json').read_text());receipts={r['index']:r for r in result['receipts']};verified={};graph=np.load(ROOT/p['graph']);recipes=np.load(ROOT/p['recipes']);maximum=0.;put(OUT/'Frozen_Before.json',frozen_checks())
        prior='0'*64;counts={}
        for line in (PRIMARY/'events.jsonl').read_text().splitlines():
            item=json.loads(line);v=item['event'];assert v['previous']==prior and hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==item['sha256'];prior=item['sha256'];counts[v['kind']]=counts.get(v['kind'],0)+1
        assert prior==json.loads((PRIMARY/'Closed_Manifest.json').read_text())['journal_last_sha256']
        assert counts.get('PF_attempt',0)==result['costs']['PF_attempts'] and counts.get('PF_return',0)==result['costs']['PF_returns'] and counts.get('PF_exception',0)==result['costs']['PF_exceptions'] and counts.get('agent_forward_return',0)==result['costs']['agent_forward_returns']
        (OUT/'replay').mkdir()
        for index,r in receipts.items():
            bound()
            if r['status']!='RETURNED':event('failed_or_unreturned_science_not_repeated',index=index,status=r['status']);continue
            before=PRIMARY/'physics'/f'PF{index:06d}_before.pkl';assert sha(before)==r['before_sha256'];net=pickle.loads(before.read_bytes());assert signature(net)==r['physical_signature'] and regime(net)==p['remaining_regimes'][str(r['context']['seed'])] and regime(net) not in p['paid_prior_regimes'];costs['PF_attempts']+=1;event('independent_PF_attempt',index=index);t=time.perf_counter()
            try:b.pp.runpp(net,**r['kwargs'])
            except BaseException:costs['PF_exceptions']+=1;raise
            costs['PF_returns']+=1;assert net.converged and signature(net)==r['physical_signature'];saved=np.load(PRIMARY/'physics'/f'PF{index:06d}_fields.npz');fields={n:net[n].select_dtypes(include=[np.number]).to_numpy(float) for n in saved.files}
            for n in saved.files:
                assert np.array_equal(np.isnan(fields[n]),np.isnan(saved[n])) and np.allclose(fields[n],saved[n],atol=1e-10,rtol=0,equal_nan=True)
                finite=np.isfinite(fields[n])&np.isfinite(saved[n]);maximum=max(maximum,float(np.max(np.abs(fields[n][finite]-saved[n][finite]),initial=0.)))
            ppc=net._ppc;assert np.array_equal(ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and ppc['baseMVA']==float(graph['baseMVA']);v=ppc['bus'][:,7]*np.exp(1j*np.deg2rad(ppc['bus'][:,8]));s=makeSbus(ppc['baseMVA'],ppc['bus'],ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert kcl<=1e-7;verified[index]=True
            put(OUT/'replay'/f'PF{index:06d}.json',{'index':index,'physical_signature':signature(net),'all_fields_atol':1e-10,'KCL_max_pu':kcl,'seconds':time.perf_counter()-t});event('independent_PF_return',index=index,KCL_max_pu=kcl)
        env,proxy,_=b.environment();costs['native_conversions']+=1;models,_,_=b.load_three(env);costs['checkpoint_loads']+=9;params=np.load(PRIMARY/'All9_Immutable_Parameters_Before.npz');after=np.load(PRIMARY/'All9_Immutable_Parameters_After.npz')
        for algorithm,group in models.items():
            for i,m in enumerate(group):
                for name,value in m.state_dict().items():key=f'{algorithm}::{i}::{name}';assert np.array_equal(params[key],after[key]) and np.array_equal(params[key],value.detach().cpu().numpy())
        active={}
        def checked_paid(net,*args,**kwargs):
            assert not args and kwargs=={'algorithm':'bfsw','init':'dc'};r=receipts[active['receipt']];assert r['kwargs']==kwargs and signature(net)==r['physical_signature'] and verified.get(r['index']);saved=pickle.loads((PRIMARY/'physics'/f"PF{r['index']:06d}_after.pkl").read_bytes());net.update(saved);costs['control_transition_paid_replay_lookups']+=1
        proxy.runpp=checked_paid;checked_steps=0;case_rows=[]
        for world in result['worlds']:
            seed=world['seed'];d=PRIMARY/f'seed{seed:03d}'
            if world['root_status']!='RETURNED':case_rows.append({'seed':seed,'status':'UNKNOWN_ROOT'});continue
            assert verified[world['root_receipt']];root=pickle.loads((d/'Root_Complete_ENV.pkl').read_bytes());assert sha(d/'Root_Complete_ENV.pkl')==world['root_ENV_sha256'];assert signature(root['network'])==world['root_physical_signature']
            for n,tab,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(root['network'][tab][col].to_numpy(),recipes[n][seed])
            for branch in world['algorithms']:
                algorithm=branch['algorithm'];env.__dict__.clear();env.__dict__.update(copy.deepcopy(root));last=np.zeros((3,1));history=[]
                for pos,row in enumerate(branch['steps'],1):
                    bound();assert row['step']==pos;sd=d/f'{algorithm}_{pos:03d}';assert sha(sd/'Full_Cursor.pkl')==row['cursor_sha256'];cursor=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());assert cursor['next_step']==pos and cursor['remaining_source_horizon']==101-pos and cursor['protocol_sha256']==sha(PREP/'Protocol.json') and cursor['history']==history and signature(cursor['environment']['network'])==signature(env.network)==row['before_physical_signature'];assert np.array_equal(cursor['state'],env.state) and np.array_equal(cursor['last_Q'],last);raw=[]
                    for i,m in enumerate(models[algorithm]):
                        costs['agent_forward_attempts']+=1
                        with torch.no_grad():a=m.get_action(np.asarray([env.state[i]]))
                        costs['agent_forward_returns']+=1;raw.append(a.copy())
                    raw=np.asarray(raw);assert np.array_equal(raw,np.asarray(row['raw_policy']));action=last-np.clip(raw,-.3,.3);assert np.array_equal(action,np.asarray(row['absolute_Q_Mvar']));active['receipt']=row['PF_receipt'];state,reward,_,done=env.step_Preward(action,last-action);vm=env.network.res_bus.vm_pu.to_numpy(copy=True);assert np.array_equal(state,np.asarray(row['controlled_vm_after'])) and np.array_equal(vm,np.asarray(row['all13_vm_after'])) and float(reward)==row['reward'] and bool(done)==row['native_done'] and metrics(vm)=={n:row[n] for n in metrics(vm)};last=action.copy();history.append(row);checked_steps+=1
                if branch['status']=='COMPLETE_NATIVE_EPISODE':assert history and (history[-1]['native_done'] or len(history)==100) and branch['endpoint']==history[-1]
                case_rows.append({'seed':seed,'algorithm':algorithm,'status':branch['status'],'completed_steps':len(history),'endpoint':branch.get('endpoint'),'partial_or_failure_retained':branch.get('failure')})
        audit={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_INDEPENDENT_ALL_AVAILABLE_PUBLIC13_AUTHOR_COHORT_SOURCE_INPUT_POLICY_CONTINUOUS_PHYSICS_COST_AUDIT','scientific_status':result['status'],'all499_complete':result['status'].startswith('COMPLETE_'),'all_new_scientific_identity_PF_returns_independently_replayed':len(verified),'continuous_policy_steps_verified':checked_steps,'full_fields_max_delta':maximum,'actual_independent_costs':costs,'primary_costs_retained':result['costs'],'cases':case_rows,'unentered_seeds_UNKNOWN':result['unentered_seeds'],'our_complete_paper_new_hybrid_or_superiority':'NOT_MEASURED_UNKNOWN','native_policy_guard_stopping_scope':result['native_vs_common'],'workflow_seconds':time.monotonic()-began};put(OUT/'Independent_Audit.json',audit);put(OUT/'Frozen_After.json',frozen_checks());event('closed',audit_sha256=sha(OUT/'Independent_Audit.json'));stream.close();put(OUT/'Closed_Manifest.json',{'files':[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()],'journal_last_sha256':previous});print(audit['status'])
    except BaseException as exc:
        put(OUT/'Failure.json',{'type':type(exc).__name__,'failure':str(exc),'traceback':traceback.format_exc(),'costs':costs,'workflow_seconds':time.monotonic()-began});stream.close();raise
if __name__=='__main__':main()
