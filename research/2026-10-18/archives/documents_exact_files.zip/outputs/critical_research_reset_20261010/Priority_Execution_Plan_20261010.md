# Priority plan: test a useful mechanism before another full LLM run

Prepared 10 October 2026 in response to the request for a concrete, critical plan and immediate justified execution. Original notebooks are references; recovering every notebook is not a launch prerequisite. No calibrated 90% probability of discovery, novelty or superiority is supported. The eventual confirmation can use a prospectively specified 90% confidence procedure; that does not give this untested plan a 90% chance of winning.

## Where the goal stands

The original trained 0.5B command-format ability and paper architecture are preserved. Original ten-step evidence and full-cost literal D-SE are sealed. We have verified physical action data, stronger numerical controls, genuine pretrained-body training, fresh checkpoint reloads and reliable preservation. These remove engineering ambiguity from several negative results.

There is still **no demonstrated incremental LLM advantage over D-SE**, and no honest percentage-complete estimate for that scientific discovery. The strongest completed AC numerical control reached equal-world recorded-best K4 inclusion 0.38596491228070173 on inspected development data. The dense copied-body intervention failed its fixed learning gate; the relational intervention performed substantially worse; VCSA selected the same actions as frozen heads on all 47 finite views. Loss reductions, valid JSON and changed weights did not produce better decisions. These branches stay stopped.

The unadapted public 1.5B strict-interface screen was a different contract. It did not test an equivalently trained upgrade of the original actor. The recovered notebook clarifies that the original actor used compact messages, not the long raw teacher chats. Raw context and raw full-answer audits must not be attributed to that original compact training.

The new lossless current-local input resolves all identified compact-input action collisions in the original TRAIN corpus: 16,000 rows, 109 historical worlds, 432 current observations, zero contradictory action classes. This is information readiness, not learned physical value. It does not certify missing live global, controller/cap or history fields. Only 432 distinct observations also explains why 16,000 rows must not be treated as 16,000 independent scientific examples.

## The selected hypothesis

**A receipt-conditioned language policy may reduce the physical checks needed to reach a protected decision by learning which native bus/Q action to verify next, when to stop, and when to abstain.** Returned convergence, constraint and voltage responses are evidence; generated predictions never become verifier authority. A commit requires an actual accepted receipt at the same current root. No unqueried action or predicted future reward is trusted.

This addresses a different problem from predicting an exact immediate maximizer after all action outcomes are already known. Exact DFF argmax on the same fully verified state/action set cannot be improved under the same score. Acquisition cost, subsequent protected trajectories, or both must supply the gain.

Language pretraining could help interpret heterogeneous failures and interactions across a changing receipt history. This is an explicit hypothesis. If stable numerical fields and categorical codes already support equally good decisions, a cheaper numerical learner may win and the language route stops. A 1.5B model is the requested candidate capacity only after opportunity survives; model size is not the mechanism.

Generic adaptive acquisition, decision-focused test selection and computation stopping are prior art: [LMABO](https://arxiv.org/html/2602.07904v1), [Javdani et al.](https://proceedings.mlr.press/v33/javdani14.pdf), and [Hay et al.](https://arxiv.org/pdf/1207.5879). A possible contribution is the particular learned native-action receipt-and-cost policy, causal protected commitment and fully paid grid-portfolio comparison. Novelty is not established by this plan.

## Execution order and binding decisions

| Stage | Work | Decision that permits the next stage |
|---|---|---|
| 0: finish genuinely missing input checks | Encode only the fixed 939 previously unexecuted TRAIN pair keys and 102 missing prefix packages; reuse every completed package. New exclusive CPU owner, 300-second entry bound, original partial unchanged. | Complete identities, lossless fields, actual spans, no known context/reserve violation or size-token mismatch. This only certifies the proposed input, not learning. |
| 1: fresh paid-receipt opportunity test | Eight prospectively fixed new development roots: two global-load, four regional-load, two combined-load/tie cases. All cases retained, including invalid and healthy ones. Full legal native action tables at isolated same-root copies, original solver/verifier/Q/cap/scope/score; common normal-upper guard. Measure each query and preparation cost and save all fields. Independent replay is separately charged. Fixed 600-second measurement-entry bound, no retry. | Causal field/source identities and replay pass; enough stressed roots; useful headroom and receipt-adaptive ordering improve under the fixed gates below. Missing measurements remain UNKNOWN. |
| 2: strong numerical acquisition pilot | One prospectively fixed trained numerical receipt policy, with the same current/process/receipt information, legal queries, world grouping, target and budget; retain strongest analytic/static and adaptive controls. | A useful residual opportunity remains after the strong numerical control, and optimistic full-cost savings can accommodate an actual model. No learning launch solely because software passes. |
| 3: minimal actual 1.5B integration | Frozen public base revision, new copied adapter, exact current/history context, action-only deployed target, strict legal decoder plus abstain, actual collator mask/gradient/memory checks and cold full optimizer/RNG/cursor restore. Preserve original adapter. | Real integration succeeds within memory/time bounds and measured inference/setup/preservation cost fits the Stage 1–2 allowance. Any setup partial is not a learning result. |
| 4: one learning pilot | One seed, budget, world partition and final checkpoint fixed before outcomes. Include matched 0.5B/1.5B adapted input-role comparison where required, strongest same-information numerical control, and architecture/pretraining attribution. Every model/tool/training/failure cost paid. | Strict decision and net-cost improvement over the strongest applicable control without increased unsafe, missing or malformed outcomes. Failed gate stops this intervention; no prompt/LR/Q/seed/checkpoint/budget sweep. |
| 5: actual protected trajectories | Fresh per-state inference; unchanged physical rules and common raw scopes. Original DFF and DFF-ALT individually and unchanged D-SE with FULL BOTH branch costs. Continuous independent replay and complete actual costs. | A fixed practically useful physical/economic effect survives development before unused confirmation. Saved-label or query-table performance is insufficient. |
| 6: unused confirmation | Freeze effect estimand, practically useful margin, world-level design, missing/failure rules and a 90% confidence procedure before any confirmation outcomes. | Only this supports a superiority claim within the stated scope. Security/FDIA remains a separate later requirement. |

Stages 2–6 are conditional designs, not launch-ready production implementations. The next implemented source/protocol must instantiate their exact settings before measurement. A passed earlier gate cannot silently authorize a later experiment with unresolved controls.

## The first substantive experiment

Stage 1 is deliberately a small physical opportunity test, not another full training study. Cases are chosen by fixed physical transformations before outcomes, checked against old exact modifications, and never filtered for useful results. Their evidence becomes development data, not unused confirmation.

Each query begins from the identical saved solved root. Record all current tables and global/per-bus voltages and angles, legal common AND zone scope, accumulated support/cap, original action, convergence, verifier acceptance/reason, normal-upper protection, original score, preparation/solver/end-to-end time and failures. The actor sees only current information and receipts it actually requested. Full hidden-table measurement is a paid development cost, not a free deployed oracle.

Fixed eight-query nominations compare a low-voltage/Q static order, an actually implemented current-Jacobian order and the receipt-conditioned same-bus numerical correction. The rule does not stop because an administrator knows the best action. A full-table oracle supplies only an optimistic opportunity/cost bound, never deployable performance. Current-Jacobian native convergence remains uncertified until actual receipts return.

The fixed initial support gate requires at least six valid stressed roots, feedback equal-world recorded-best inclusion at least five percentage points above both static controls, strict improvement in at least three roots against each, and zero unsafe/unqueried commits. Partial comparisons remain UNKNOWN. These are evidence for that numerical feedback mechanism, not proof that language can improve it. Failure stops this specified route; a general theorem about every LLM is not inferred.

Report the maximum affordable extra inference time from actual query savings. A one-second-per-query-decision model allowance is an explicitly conditional planning screen, not measured 1.5B latency. Training, teacher collection, numerical preparation, preservation and failure costs remain separate and must be included in a later actual economic gate. Report break-even workload rather than claiming amortization at an invented deployment volume. If even an optimistic oracle leaves no useful paid margin, stop before allocating a GPU.

## Avoiding the earlier waste

Do not restart failed methods or the old partial receipt replay. Do not repeat old encodings, physics, models or numerical forecasts. Do not expand this opportunity budget or replace adverse worlds. Do not substitute lower reconstruction loss, nicer output, cached labels, guard benefit or fewer queries for full protected recovery and cost evidence. Use notebooks only when a concrete source/serving uncertainty requires them.

The immediate priority is decisive opportunity evidence and an independently challenged plan. The aligned bigger-model question remains valid, but training it before these economic and strong-control gates would risk another expensive answer to the wrong question.

Evidence: full_current_compact_output_research_handoff_v1/Results_And_Next_Decision.md; original_compact_training_contract_review/Source_Recovery_Correction_And_Next_Decision.md; Review_Status_And_Gated_Next_Plan_20261010.md; paid_feedback_partial_gate_interpretation/Decision.md; completed relational/dense/VCSA external evidence. The fresh Stage 1 preparation and actual results will be recorded separately when ready; this document does not claim they already ran.
