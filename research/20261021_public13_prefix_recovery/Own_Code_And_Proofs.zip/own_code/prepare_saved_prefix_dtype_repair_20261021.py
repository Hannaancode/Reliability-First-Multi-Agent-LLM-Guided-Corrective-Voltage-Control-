"""Additive analysis-only float32 materialization repair; never repeat equations/science."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    old=ROOT/'work/preserve_and_audit_public13_terminal_prefix_20261021.py';text=old.read_text(encoding='utf-8');text=text.replace("OUT=ROOT/'outputs/public13_terminal_saved_prefix_20261021'","OUT=ROOT/'outputs/public13_terminal_saved_prefix_v2_20261021'")
    start=text.index('    source=ROOT/');end=text.index("    complete_worlds=[];",start)
    replaced="""
    import shutil
    previous_output=ROOT/'outputs/public13_terminal_saved_prefix_20261021'
    previous_claim=json.loads((previous_output/'owner.claim').read_text());assert previous_claim['source_sha256']==sha(ROOT/'work/preserve_and_audit_public13_terminal_prefix_20261021.py')
    previous_end=json.loads((ROOT/'outputs/public13_terminal_saved_prefix_coordination_20261021/End_ACK.json').read_text());assert previous_end['actual_owned_chain_ended'] and previous_end['exit_code']==1
    previous_log=(ROOT/'outputs/public13_terminal_saved_prefix_coordination_20261021/Owner.log').read_text();assert 'np.array_equal(q,np.asarray(row' in previous_log
    # The equation loop and source projection completed before this continuity
    # assertion failed. Reuse their exact phase outputs; no repeated KCL/projection.
    for name in ['All_Saved_Equation_Checks.json','Source_Normalization_Diagnosis.json','Derived_Source_Projected_Parameters_NOT_Actual_Final.npz']:shutil.copyfile(previous_output/name,OUT/name)
    index_rows=json.loads((OUT/'All_Saved_Equation_Checks.json').read_text());receipts=failure['receipts'];assert len(index_rows)==len(receipts)==2787
    for r,a in zip(receipts,index_rows):assert a['index']==r['index'] and a['physical_signature']==r['physical_signature'] and a['status']=='SAVED_NATIVE_EQUATIONS_PASS_NEW_SOLVER_REPLAY_NOT_EXECUTED'
    maximum_kcl=max(a['KCL_max_pu'] for a in index_rows);maximum_flow=max(a['complex_branch_flow_max_MVA'] for a in index_rows);assert maximum_kcl<=1e-7 and maximum_flow<=1e-7
    root_recipes=np.load(ROOT/p['recipes']);costs['reused_completed_saved_equation_checks']=len(index_rows)
    diagnosis=json.loads((OUT/'Source_Normalization_Diagnosis.json').read_text());assert diagnosis['status'].startswith('PASS_');costs['inherited_source_state_projection_vector_operations']=sum(a['source_call_count'] for a in diagnosis['saved_state_projections'])
    put(OUT/'Mechanical_Dtype_Repair_Proof.json',{'original_saved_audit_source_sha256':sha(ROOT/'work/preserve_and_audit_public13_terminal_prefix_20261021.py'),'original_saved_audit_end':previous_end,'phase_artifacts_reused':[{'name':n,'sha256':sha(previous_output/n)} for n in ['All_Saved_Equation_Checks.json','Source_Normalization_Diagnosis.json','Derived_Source_Projected_Parameters_NOT_Actual_Final.npz']],'defect':'Raw returned float32 actions were serialized as JSON numbers, then reloaded float64 before clipping. Native clipping uses float32 .3, not float64 .3. Restore source dtype with exact roundtrip check before native clip; do not relax tolerances.','new_model_PF_solver_policy_calls':0,'completed_equation_or_projection_phases_repeated':False})
"""
    text=text[:start]+replaced+text[end:]
    old_raw="raw=np.asarray(row['raw_policy']);q=last-np.clip(raw,-.3,.3);"
    new_raw="raw=np.asarray(row['raw_policy'],dtype=np.float32);assert np.array_equal(raw.astype(np.float64),np.asarray(row['raw_policy'],dtype=np.float64));q=last-np.clip(raw,-.3,.3);"
    assert text.count(old_raw)==1;text=text.replace(old_raw,new_raw)
    source=ROOT/'work/preserve_and_audit_public13_terminal_prefix_v2_20261021.py';source.write_text(text,encoding='utf-8')
    protocol={'single_owner':{'source':source.relative_to(ROOT).as_posix(),'sha256':sha(source),'output':'outputs/public13_terminal_saved_prefix_v2_20261021','coordination':'outputs/public13_terminal_saved_prefix_v2_coordination_20261021','python':'work/vcsa_module_env/Scripts/python.exe','bound_seconds':1900},'scope':'Zero-science additive saved cursor dtype/preservation repair. Reuse completed source-projection and2787equation phases; all old failure claims/sources remain.'}
    (ROOT/'outputs/public13_terminal_saved_prefix_v2_Owner_Protocol_20261021.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8');print('PREPARED_ZERO_SCIENCE_DTYPE_REPAIR')
if __name__=='__main__':main()
