"""Additive pre-forward control repair. Original scientific protocol untouched."""
from pathlib import Path
from datetime import datetime,timezone
import ast, difflib, hashlib, json, shutil, zipfile
from candidate_process_evidence_utils import ROOT,read,write,sha,frozen_checks,seal
BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
OLD=BASE/'pretrained_learning_preparation';OUT=BASE/'pretrained_learning_trainability_preparation_v3'
assert not (BASE/'pretrained_learning_trainability_execution_v3').exists()
assert not (OUT/'protocol.json').exists() and not (OUT/'Cloud_Payload_Manifest.json').exists()
failure=read(BASE/'pretrained_learning_zero_forward_failure_audit/Independent_Zero_Forward_Failure_Audit.json')
fixture=read(BASE/'frozen_restoration_software_readiness_v2/Software_Readiness.json')
assert failure['all_partial_integrity_and_identity_gates_passed'] and fixture['old_bug_independently_reproduced'] and fixture['all_passed']
assert read(BASE/'pretrained_learning_execution/status.json')['runtime_released']
OUT.mkdir(exist_ok=True)
def adapt(oldname,newname,replacements):
    source=ROOT/'work'/oldname; old=source.read_text(encoding='utf-8');new=old
    for before,after,expected in replacements:
        assert new.count(before)==expected,(oldname,before,new.count(before),expected)
        new=new.replace(before,after)
    ast.parse(new);destination=ROOT/'work'/newname
    if destination.exists(): assert destination.read_text(encoding='utf-8')==new, 'Previously adapted source changed'
    else: destination.write_text(new,encoding='utf-8')
    return {'original_source':source.relative_to(ROOT).as_posix(),'original_sha256':sha(source),
      'additive_source':destination.relative_to(ROOT).as_posix(),'additive_sha256':sha(destination),
      'exact_replacements':[(x,y,n) for x,y,n in replacements],
      'diff':list(difflib.unified_diff(old.splitlines(),new.splitlines(),fromfile=oldname,tofile=newname))}
changes=[]
changes.append(adapt('candidate_process_pretrained_loader.py','candidate_process_pretrained_loader_trainability_v2.py',[
 ('copied=verify_copy_state(model,expected);trainable=set_body_trainability(model,train_body)\n    restoration=enabled_restored_gate(model);torch.cuda.synchronize()',
  'from candidate_process_trainability_contract_v2 import restore_and_enforce_requested_mask\n    copied=verify_copy_state(model,expected)\n    trainable,restoration=restore_and_enforce_requested_mask(model,train_body)\n    assert verify_copy_state(model,expected)==copied\n    torch.cuda.synchronize()',1)]))
remote='candidate_process_pretrained_learning_trainability_v3_remote.py'
changes.append(adapt('candidate_process_pretrained_learning_remote.py',remote,[
 ('from candidate_process_pretrained_loader import load_isolated_body,preservation_inventory,ADAPTER_NAME','from candidate_process_pretrained_loader_trainability_v2 import load_isolated_body,preservation_inventory,ADAPTER_NAME',1),
 ('/pretrained_learning_preparation','/pretrained_learning_trainability_preparation_v3',1),
 ('/pretrained_learning_science','/pretrained_learning_trainability_science_v3',1),
 ("model,load=load_isolated_body(snapshot,adapter,train_body=train_body);loads.append({'arm':arm,'stage':'learning',**load})",
  "model,load=load_isolated_body(snapshot,adapter,train_body=train_body);loads.append({'arm':arm,'stage':'learning',**load})\n            write(folder/'Actual_Initial_Load_Record.json',load)",1),
 ('assert sum(p.numel() for p in actual.values())==expected',
  "write(folder/'Actual_Trainability_Before_First_Forward.json',{'actual_body_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),'actual_wrapper_parameters':sum(p.numel() for p in actual.values()),'expected_wrapper_parameters':expected})\n            assert sum(p.numel() for p in actual.values())==expected\n            assert sum(p.numel() for p in model.parameters() if p.requires_grad)==(8798208 if train_body else 0)\n            event('actual_load_and_trainability_gate_passed',load=load,actual_wrapper_parameters=expected)",1),
 ('del optimizer,wrapper,shared,model,actual,original_copy,updated,checkpoint,score,loss,target;',
  'del optimizer,optimizer_groups,wrapper,shared,model,actual,original_copy,updated,checkpoint,score,loss,target;',1),
 ("fresh,load2=load_isolated_body(snapshot,adapter,train_body=False);loads.append({'arm':arm,'stage':'fresh_checkpoint_reload',**load2})",
  "fresh,load2=load_isolated_body(snapshot,adapter,train_body=False);loads.append({'arm':arm,'stage':'fresh_checkpoint_reload',**load2})\n            write(folder/'Actual_Fresh_Load_Record.json',load2)",1),
 ("set_peft_model_state_dict(fresh,checkpoint['copied_adapter'],adapter_name=ADAPTER_NAME)",
  "set_peft_model_state_dict(fresh,checkpoint['copied_adapter'],adapter_name=ADAPTER_NAME)\n            assert not any(p.requires_grad for p in fresh.parameters())",1)]))
env='candidate_process_learning_trainability_v3_environment_check.py'
changes.append(adapt('candidate_process_learning_environment_check.py',env,[('/pretrained_learning_preparation','/pretrained_learning_trainability_preparation_v3',1)]))
owner='run_candidate_process_learning_trainability_v3_colab.py'
changes.append(adapt('run_candidate_process_pretrained_learning_colab_chunked_v2.py',owner,[
 ('/pretrained_learning_preparation','/pretrained_learning_trainability_preparation_v3',1),
 ('/pretrained_learning_execution','/pretrained_learning_trainability_execution_v3',1),
 ('candidate_process_learning_environment_check.py',env,1),
 ('candidate_process_pretrained_learning_remote.py',remote,1),
 ('/pretrained_learning_science','/pretrained_learning_trainability_science_v3',2),
 ('Launch_Readiness_Transfer_v2.json','Launch_Readiness_Transfer_v3.json',1)]))
reader='analyze_candidate_process_learning_trainability_v3.py'
changes.append(adapt('analyze_candidate_process_pretrained_learning.py',reader,[
 ('Launch_Readiness_Transfer_v2.json','Launch_Readiness_Transfer_v3.json',1),
 ('pretrained_learning_preparation','pretrained_learning_trainability_preparation_v3',1),
 ('pretrained_learning_execution','pretrained_learning_trainability_execution_v3',1),
 ('pretrained_learning_external_audit','pretrained_learning_trainability_external_audit_v3',1),
 ("summary=read(SCI/'summary.json');assert summary['completed']",
  "loads=read(SCI/'Actual_Model_Load_Records.json');assert len(loads)==4\nfor load in loads:\n    trainable=8798208 if load['arm']=='copied_original_LoRA_body' and load['stage']=='learning' else 0\n    assert load['trainable_body_parameters']==load['actual_final_body_trainable_parameters']==trainable\n    assert load['exact_requested_gradient_mask_enforced_after_restoration'] and load['source_tensor_values_identical']\nfor arm in read(PREP/'protocol.json')['arms']:\n    gate=read(SCI/arm/'Actual_Trainability_Before_First_Forward.json')\n    assert gate['actual_body_parameters']==(8798208 if arm=='copied_original_LoRA_body' else 0)\n    assert gate['actual_wrapper_parameters']==gate['expected_wrapper_parameters']==(9087967 if arm=='copied_original_LoRA_body' else 289759)\nsummary=read(SCI/'summary.json');assert summary['completed']",1)]))
handoff='continue_candidate_process_learning_trainability_v3_audit.py'
changes.append(adapt('continue_candidate_process_pretrained_learning_audit.py',handoff,[
 ('pretrained_learning_audit_continuation','pretrained_learning_trainability_audit_continuation_v3',1),
 ('pretrained_learning_execution','pretrained_learning_trainability_execution_v3',1),
 ('run_candidate_process_pretrained_learning_colab_chunked_v2.py',owner,1),
 ('pretrained_learning_external_audit','pretrained_learning_trainability_external_audit_v3',2),
 ('analyze_candidate_process_pretrained_learning.py',reader,1)]))
for p in OLD.rglob('*'):
    if p.is_file() and (p.suffix=='.pt' or p.name in ['Input_Index.json','Target_Index.json','Node_Normalization.json','Target_Normalization.json','Expected_Environment.json']):
        q=OUT/p.relative_to(OLD);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);assert sha(p)==sha(q)
oldprotocol=read(OLD/'protocol.json');protocol=dict(oldprotocol)
protocol['control_repair_provenance']={
 'declared_at_utc':datetime.now(timezone.utc).isoformat(),'old_exact_science_protocol_sha256':sha(OLD/'protocol.json'),
 'old_zero_forward_failure_audit_sha256':sha(BASE/'pretrained_learning_zero_forward_failure_audit/Independent_Zero_Forward_Failure_Audit.json'),
 'original_study_no_forward_backward_optimizer_executed':True,'first_scientific_execution_after_pre_forward_control_repair':True,
 'old_owner_and_failure_remain_terminal_preserved_no_restart':True,
 'only_correction':'after PEFT enabled/disabled/restored check enforce originally requested exact gradient mask; persist genuine actual load/trainability gates before first forward; release unused optimizer parameter references before fresh-model reload',
 'actual_same_seed_data_objective_epochs_optimizer_Q_masks_decoder_partition_gates':True,
 'software_bug_reproduction_certificate_sha256':sha(BASE/'frozen_restoration_software_readiness_v2/Software_Readiness.json'),
 'new_plan_maximum_one_selected_Sheena_allocation_no_fallback_or_second_request':True,
 'failed_resource_setup_costs_separate_not_free':True,'genuine_pre_forward_gate_failure_stops_new_owner':True}
assert {k:v for k,v in protocol.items() if k!='control_repair_provenance'}==oldprotocol
write(OUT/'protocol.json',protocol)
write(OUT/'Additive_Source_Adaptation_Audit.json',{'all_AST_parsed':True,'original_sources_preserved':True,'only_listed_additive_control_differences':changes})
write(OUT/'Fresh_Frozen_Asset_Audit.json',frozen_checks())
science_sources=['candidate_process_pretrained_loader.py','candidate_process_pretrained_loader_trainability_v2.py','candidate_process_trainability_contract_v2.py',
 'candidate_process_body_intervention_query_v2.py','candidate_process_numerical_predictor.py',remote,env,'vcsa_memory_execution.py','vcsa_common_information_control.py','vcsa_modules_v2.py','vcsa_modules.py']
members={'work/'+n:ROOT/'work'/n for n in science_sources}
for n in ['frozen_gpu_requirements.txt','frozen_dependency_closure.txt']:members['work/'+n]=ROOT/'work'/n
members['outputs/frozen_input_verification.json']=ROOT/'outputs/frozen_input_verification.json'
adapter=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
for n,h in read(ROOT/'outputs/frozen_input_verification.json')['model_files'].items():
    assert sha(adapter/n)==h;members[(adapter/n).relative_to(ROOT).as_posix()]=adapter/n
for p in OUT.rglob('*'):
    if p.is_file() and p.name not in ['Fresh_Frozen_Asset_Audit.json','Additive_Source_Adaptation_Audit.json']: members[p.relative_to(ROOT).as_posix()]=p
program={n:sha(p) for n,p in members.items()};write(OUT/'Program_Input_Manifest.json',program)
members[(OUT/'Program_Input_Manifest.json').relative_to(ROOT).as_posix()]=OUT/'Program_Input_Manifest.json'
descriptor={n:sha(p) for n,p in members.items()};archive=OUT/'Pretrained_Dense_Process_Trainability_Continuation_v3_Inputs.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for n,p in members.items():z.write(p,n)
    z.writestr('CANDIDATE_PROCESS_INPUT_MANIFEST.json',json.dumps(descriptor,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)+1
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in descriptor.items())
payload={'archive':archive.relative_to(ROOT).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':descriptor,
 'destination':'one sheenahammed@gmail.com Colab T4','action':'first actual execution of fixed two-arm dense-process study after independently reproduced zero-forward trainability control failure',
 'direct_human_overnight_authority_record_sha256':sha(ROOT/'outputs/overnight_research_authorization_20261009.json'),
 'all_private_data_and_labels_unchanged_from_prior_exact_payload':True,'maximum_allocation_requests':1}
write(OUT/'Cloud_Payload_Manifest.json',payload)
write(OUT/'Direct_Human_Authority_for_Exact_Payload.json',{'trusted_overnight_record_sha256':payload['direct_human_overnight_authority_record_sha256'],
 'exact_bytes':payload['bytes'],'exact_sha256':payload['sha256'],'destination':payload['destination'],'action':payload['action'],
 'no_old_owner_restart_or_repeat_of_any_executed_forward_optimizer_step':True,'no_permission_or_resource_denial_bypass':True})
source_names=science_sources+[owner,reader,handoff,'prepare_candidate_learning_trainability_continuation_v3.py','finish_candidate_trainability_control_preparation_v4.py']
write(OUT/'Launch_Readiness_Audit.json',{'passed':True,'old_zero_forward_failure_independently_verified':True,'actual_PEFT_frozen_mask_bug_reproduced_and_both_masks_verified':True,
 'all_private_case_tensor_target_normalization_initialization_and_scientific_settings_unchanged':True,'genuine_T4_mask_gate_required_before_first_forward':True,
 'source_hashes':{'work/'+n:sha(ROOT/'work'/n) for n in source_names},'payload_bytes':payload['bytes'],'payload_sha256':payload['sha256'],'new_pretrained_model_optimizer_PF_calls':0})
write(OUT/'Launch_Readiness_Transfer_v3.json',{'new_owner_source_sha256':sha(ROOT/'work'/owner),'same_proved_chunked_preservation_control':True})
handoff_local=BASE/'pretrained_learning_trainability_local_readiness_v3';handoff_local.mkdir()
files={p.relative_to(ROOT).as_posix():p for p in [ROOT/'work'/n for n in source_names]}
for p in OUT.iterdir():
    if p.is_file() and p.suffix in ['.json']:files[p.relative_to(ROOT).as_posix()]=p
for p in [BASE/'pretrained_learning_zero_forward_failure_audit/Independent_Zero_Forward_Failure_Audit.json',BASE/'frozen_restoration_software_readiness_v2/Software_Readiness.json',ROOT/'work/test_candidate_process_frozen_restoration_v2.py']:
    files[p.relative_to(ROOT).as_posix()]=p
print(json.dumps({'ready':True,'payload_bytes':payload['bytes'],'payload_sha256':payload['sha256'],'archive':seal(handoff_local,files,'Verified_Trainability_Control_Continuation_Readiness.zip')},indent=2))
