"""Saved-only raw/normalised/verified/committed action attribution, all4roots."""
import ast,collections,hashlib,json,re,math
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];O=R/'outputs/original118_raw_action_attribution_v2_20261028'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False)
def function(path,names,namespace):
    tree=ast.parse(path.read_text('utf-8-sig'));nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert len(nodes)==len(names);exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
    return {n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in nodes}
def main():
    O.mkdir(exist_ok=False);sourcefiles=[R/'work/e/audit/phase2g_multiagent_llm_runner.py',R/'work/e/audit/phase2g_rescue_runner.py',R/'work/e/audit/phase2g_llm_guided_rescue_runner.py']
    # Only pure parsing/normalisation/validation definitions are loaded.
    ns={'json':json};hashes={}
    hashes.update(function(sourcefiles[0],{'extract_json'},ns));hashes.update(function(sourcefiles[1],{'normalize_action'},ns));hashes.update(function(sourcefiles[2],{'action_bus','validate_action_against_candidates'},ns))
    comparison=read(R/'outputs/original118_closed_comparison_20261028/Comparison.json');allrows=[];receipts=[];totals=collections.Counter();allsemantic=collections.Counter()
    protocol=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_SAVED_ONLY_ALL4_RAW_ATTRIBUTION_BEFORE_COUNTS',source_sha256=sha(Path(__file__)),
       source_files={p.relative_to(R).as_posix():sha(p) for p in sourcefiles},unchanged_function_AST=hashes,
       raw_contract='Entire response json.loads succeeds; exactly bus(string integer identifier) and q_mvar(numeric in originalALLOWED_Q). Count separately from source accepted alternatives.',
       counts='All controller responses, first and second attempts separately; source parser and normalizer retained. Normalisation changes are counted, not credited as raw success. Numerical acceptance is per direct candidate test; finalcommit origin is separate.',
       new_model_PF_controller_optimizer_calls=0,all4_required=True)
    put(O/'Protocol.json',protocol)
    for i,row in enumerate(comparison['rows']):
        cid=row['case_id']
        if i==0:host=R/'outputs/r118chrono_20261022'
        elif i==2:host=R/'outputs/reflection118_remaining_cases_v2_execution_20261023/case_02'
        else:host=R/f'outputs/original_missing_suffix_execution_20261028/case_{i:02d}'
        d=host/'local_controller'/cid/'reflection_v2';result=read(d/'Result.json');calls=read(d/'Call_Order.json')
        generations=[]
        if i in [1,3]:
            old=R/f'outputs/reflection118_remaining_cases_v2_execution_20261023/case_{i:02d}'
            manifest=read(old/'remote_closed_descriptor.json')['members']
            for name in sorted(n for n in manifest if re.fullmatch(r'response_\d{5}\.json',n)):
                f=old/'staged/study'/name;assert sha(f)==manifest[name]['sha256'];generations.append(read(f)['raw_text'])
        generations += [x['text'] for x in calls['generations']]
        expanded=[];c=collections.Counter();reasons=collections.Counter();normalizations=[]
        for j,log in enumerate(result['logs']):
            info=log.get('llm_info');assert info is not None
            if info.get('raw') is None:c['non_generation_zone_skips']+=1;continue
            c['zone_decisions_with_generation']+=1
            attempts=[('first',info.get('first_raw'),info.get('first_parsed'),info.get('first_valid_reason'))] if info.get('reprompted') else []
            attempts.append(('second' if info.get('reprompted') else 'first',info['raw'],info['parsed'],info['valid_reason']))
            c['reprompted_zone_decisions']+=int(bool(info.get('reprompted')))
            for attempt,raw,parsed_saved,reason_saved in attempts:
                assert isinstance(raw,str);expanded.append(raw);c['all_controller_responses']+=1;c[attempt+'_responses']+=1
                parsed,ok,err=ns['extract_json'](raw);assert parsed==parsed_saved
                action=ns['normalize_action'](parsed);valid,reason=ns['validate_action_against_candidates'](action,info['candidate_buses']);assert reason==reason_saved
                strict=False;whole=False;shape=False;qchanged=False
                try:
                    literal=json.loads(raw);whole=True
                    shape=isinstance(literal,dict) and set(literal)=={'bus','q_mvar'} and isinstance(literal['bus'],str) and bool(re.fullmatch(r'\d+',literal['bus'])) and type(literal['q_mvar']) in [int,float]
                    strict=shape and literal['q_mvar'] in [25,50,75,100,125,150,200,250,300]
                    if shape and action:qchanged=float(literal['q_mvar'])!=next(iter(action['add_shunts_q_mvar'].values()))
                except (ValueError,TypeError):pass
                c['whole_response_JSON']+=int(whole);c['requested_compact_schema_valid']+=int(strict);c['source_extractor_parse_valid']+=int(ok)
                c['source_candidate_semantically_valid_after_normalization']+=int(valid);c[attempt+'_candidate_valid']+=int(valid);c['numeric_Q_changed_by_normalizer']+=int(qchanged)
                c['accepted_alternative_or_extracted_format']+=int(valid and not strict);reasons[reason]+=1
                normalizations.append(dict(log=j,iteration=log['iteration'],zone=log['zone'],attempt=attempt,raw_sha256=hashlib.sha256(raw.encode()).hexdigest(),whole_response_JSON=whole,requested_compact_schema_valid=strict,
                    source_parse_valid=ok,normalized_action=action,candidate_valid=valid,reason=reason,numeric_Q_changed=qchanged))
            # Source's final attempt, numerical test and eventual selected
            # commitment have different denominators and are never conflated.
            assert bool(valid)==bool(info['valid_action']) and bool(ok)==bool(info['parse_valid'])
            if log.get('verif') is not None:
                c['direct_candidate_verifier_records']+=1;c['direct_candidate_numerically_accepted']+=int(bool(log['verif']['accepted']))
        assert expanded==generations,'Complete original raw response order mismatch'
        committed=collections.Counter(x['source'] for x in result['executed_actions'])
        assert committed['llm_direct']==row['HGVF_direct'] and committed['llm_guided_refinement']==row['HGVF_guided'] and committed['safety_fallback_physics_refinement']==row['HGVF_fallback']
        proof=dict(case_id=cid,counts=dict(c),source_validity_reasons=dict(reasons),commit_origins=dict(committed),all_raw_response_order_bound=True,
                   result_path=(d/'Result.json').relative_to(R).as_posix(),result_sha256=sha(d/'Result.json'),call_order_sha256=sha(d/'Call_Order.json'))
        put(O/f'case_{i:02d}_Attribution.json',dict(summary=proof,response_checks=normalizations));allrows.append(proof);totals.update(c);allsemantic.update(reasons)
    outcome=dict(status='COMPLETE_SAVED_ALL4_RAW_NORMALIZED_VERIFIED_COMMITTED_ATTRIBUTION',cases=allrows,totals=dict(totals),source_validity_reasons=dict(allsemantic),
        new_model_PF_controller_optimizer_calls=0,independent_second_reader='NOT_YET_RUN',
        limitations='Source semantic validity tests normalized candidate membership, not raw prompt compliance or electrical safety. Per-test acceptance is not finalcommit. Guided/fallback numerical search is not rawLLMsuccess. Four inspected developmentroots, not freshgeneralization.')
    put(O/'Results.json',outcome);put(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))
    print(json.dumps(dict(status=outcome['status'],totals=dict(totals))))
if __name__=='__main__':main()
