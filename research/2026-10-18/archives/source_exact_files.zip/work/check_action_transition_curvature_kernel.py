from pathlib import Path
from datetime import datetime,timezone
from action_transition_curvature_kernel import local_algebra_certificate
from candidate_process_evidence_utils import ROOT,write,sha,seal
OUT=ROOT/'outputs/llm_value_relational_adaptation_research_20261009/action_transition_curvature_algebra_readiness'
assert not OUT.exists();OUT.mkdir()
proof=local_algebra_certificate()
proof.update(checked_at_utc=datetime.now(timezone.utc).isoformat(),
    source_sha256=sha(ROOT/'work/action_transition_curvature_kernel.py'),
    actual_model_forward_optimizer_PF_controller_cloud_calls=0,
    label='Mathematical/software fixtures, not a learned or physical experiment')
write(OUT/'Algebra_Readiness.json',proof)
seal(OUT,{'Algebra_Readiness.json':OUT/'Algebra_Readiness.json','source/kernel.py':ROOT/'work/action_transition_curvature_kernel.py',
    'source/checker.py':Path(__file__)},'Action_Transition_Curvature_Algebra.zip')
print('Two scalar zero-action/tangent algebra fixtures passed; zero model/PF calls.')
