"""Additive integrity tests; no repeated policy suite or scientific calls."""
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal
from saved_query_receipt_anchored_dataset import EXPECTED_ORIGINAL_EVIDENCE, verify_original_evidence, open_anchored_OPT_administrator
from saved_query_receipt_interface import ReceiptContractError

OUT = ROOT / 'outputs/critical_research_reset_20261010/saved_query_fixed_original_anchor_readiness'
assert not OUT.exists()
OUT.mkdir(); start = time.perf_counter()
write(OUT / 'owner.claim', {'actual_pid': os.getpid()})
sources = [Path(__file__), ROOT / 'work/saved_query_receipt_anchored_dataset.py']
write(OUT / 'Prospective_Original_Anchor_Checks.json', {
    'declared_at_utc': datetime.now(timezone.utc).isoformat(),
    'purpose': 'Refuse original data-plus-manifest replacement and committed-successor replacement before loading a session',
    'source_sha256': {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in sources},
    'fixed_original_evidence_sha256': EXPECTED_ORIGINAL_EVIDENCE,
    'older_complete_causal_boundary_suite_not_rerun_or_modified': True,
    'negative_fixtures': 'Copies only in labelled fixture directories under this new output; original scientific files untouched.',
    'actual_new_model_optimizer_PF_controller_forecast_solve_cloud_calls': 0})
baseline = read(ROOT / 'outputs/critical_research_reset_20261010/saved_query_receipt_actual_software_readiness/Software_Readiness.json')
assert baseline['all_software_boundary_checks_passed']
assert verify_original_evidence(ROOT) == EXPECTED_ORIGINAL_EVIDENCE

names = list(EXPECTED_ORIGINAL_EVIDENCE)
def copy_anchor(target_root, name):
    p = target_root / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((ROOT / name).read_bytes())
    return p

# Actual manifest mutation in a separate test root. The changed manifest and
# fabricated replacement member agree with each other, but not original science.
fake = OUT / 'LABELLED_DATA_AND_MANIFEST_REPLACEMENT_FIXTURE'
manifest = copy_anchor(fake, names[0]); m = json.loads(manifest.read_text(encoding='utf8'))
member = fake / 'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz'
member.write_bytes(b'LABELLED_SOFTWARE_REPLACEMENT_NOT_GRID_DATA')
m[member.name] = {'bytes': member.stat().st_size, 'sha256': sha(member)}
manifest.write_text(json.dumps(m, indent=2), encoding='utf8')
try: open_anchored_OPT_administrator(fake)
except ReceiptContractError as e: assert str(e) == 'Changed original evidence anchor: ' + names[0]
else: raise AssertionError('Replaced data and nearby matching manifest accepted')

# Preserve two real original manifests, then alter one original edge in a copy.
fake2 = OUT / 'LABELLED_SUCCESSOR_REPLACEMENT_FIXTURE'
copy_anchor(fake2, names[0]); copy_anchor(fake2, names[1]); edge = copy_anchor(fake2, names[2])
v = json.loads(edge.read_text(encoding='utf8')); v[0]['after_observation_id'] = 'LABELLED_FORGED_SUCCESSOR'
edge.write_text(json.dumps(v, indent=2), encoding='utf8')
try: open_anchored_OPT_administrator(fake2)
except ReceiptContractError as e: assert str(e) == 'Changed original evidence anchor: ' + names[2]
else: raise AssertionError('Changed committed successor accepted')

# A positive construction exercises the same fixed guard before the old factory.
data = open_anchored_OPT_administrator(ROOT)
session = data.session(min(data.inputs), max_requests=8)
assert session.actor_view()['past_requested_receipts'] == []
assert session._store.receipt_lookup_calls == session._store.successor_lookup_calls == 0
assert len(data.inputs) == 239 and len(data.held_ids) == 72
assert verify_original_evidence(ROOT) == EXPECTED_ORIGINAL_EVIDENCE
result = {'all_anchor_checks_passed': True, 'original_fixed_members_checked': len(EXPECTED_ORIGINAL_EVIDENCE),
    'matching_but_forged_data_manifest_pair_refused_before_factory': True,
    'forged_committed_successor_refused_before_factory': True,
    'positive_anchored_all239_OPT_administrator_constructed': True,
    'original_scientific_files_and_old_software_sources_unchanged': True,
    'old11_boundary_checks_reused_not_rerun': True,
    'actual_new_model_PF_optimizer_controller_forecast_solve_cloud_calls': 0,
    'elapsed_seconds': time.perf_counter() - start}
write(OUT / 'Original_Evidence_Anchor_Readiness.json', result)
files = {p.name: p for p in OUT.iterdir() if p.is_file()}
for p in sources: files['source/' + p.name] = p
for p in OUT.glob('LABELLED_*_FIXTURE/**/*'):
    if p.is_file(): files['labelled_fixture/' + str(p.relative_to(OUT)).replace('\\', '/')] = p
print(json.dumps({'result': result, 'archive': seal(OUT, files, 'Saved_Query_Fixed_Original_Anchor_Readiness.zip')}, indent=2))
