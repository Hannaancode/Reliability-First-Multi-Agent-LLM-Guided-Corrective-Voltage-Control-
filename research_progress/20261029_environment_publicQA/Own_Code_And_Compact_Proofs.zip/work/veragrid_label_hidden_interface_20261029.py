"""Provisional local MCQ boundary. No model, dataset download or solver entry point."""
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class QuestionView:
    question_id: int
    question: str
    options: tuple[tuple[str,str], ...]

    def user_prompt(self):
        return f'Q{self.question_id}. {self.question}\n'+'\n'.join(f'{k}. {v}' for k,v in self.options)

def make_view(record):
    """Whitelist public text only. Administrator labels never enter the view object."""
    if not isinstance(record,dict):raise ValueError('Question must be an object')
    qid=record.get('id');text=record.get('question');options=record.get('options')
    if type(qid) is not int or qid<1:raise ValueError('Explicit positive integer ID required')
    if not isinstance(text,str) or not text.strip():raise ValueError('Question text required')
    # Only this source shape is currently admitted. Actual150 schema not yet inspected.
    if not isinstance(options,dict) or set(options)!={'A','B','C','D'}:raise ValueError('Exact four-option mapping required')
    if not all(isinstance(v,str) and v.strip() for v in options.values()):raise ValueError('Nonempty option strings required')
    return QuestionView(qid,text.strip(),tuple((k,options[k]) for k in 'ABCD'))

def make_all_views(records,expected_count=150):
    if not isinstance(records,list) or len(records)!=expected_count:raise ValueError('Complete declared denominator required')
    views=tuple(make_view(r) for r in records)
    if len({v.question_id for v in views})!=expected_count:raise ValueError('Duplicate identities forbidden')
    return views

def strict_letter(response):
    """Secondary format diagnostic only; never substitute for the author's primary parser."""
    s=response.strip().upper() if isinstance(response,str) else ''
    return s if re.fullmatch('[A-D]',s) else '?'
