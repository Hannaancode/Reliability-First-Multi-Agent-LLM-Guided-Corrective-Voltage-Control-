"""Source-proved actuator-unit adaptation, no performance/model/PF calls."""
import ast, hashlib, json, math, time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]

def native_unit_normalizer():
    source=ROOT/'work/e/audit/phase2g_rescue_runner.py'
    node=next(n for n in ast.parse(source.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='normalize_action')
    original=ast.dump(node,include_attributes=False)
    removed=[]
    for loop in [n for n in ast.walk(node) if isinstance(n,ast.For)]:
        body=[]
        for n in loop.body:
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='q' and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='max':
                assert ast.unparse(n)=='q = max(25.0, min(300.0, q))';removed.append(ast.unparse(n))
            elif isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='q' and isinstance(n.value,ast.BinOp):
                assert ast.unparse(n)=='q = round(q / 25.0) * 25.0';removed.append(ast.unparse(n))
            else:body.append(n)
        loop.body=body
    assert len(removed)==2
    ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(source)+'::NATIVE_UNIT_ADAPTATION', 'exec'),ns)
    return ns['normalize_action'],{'original_AST_sha256':hashlib.sha256(original.encode()).hexdigest(),'adapted_AST_sha256':hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest(),'only_removed_assignments':removed,'original_source_modified':False}

def main():
    out=ROOT/'outputs/paper_framework_native_PV_port_v2_20261021';out.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime,sys,pickle,copy
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np
    from transformers import AutoTokenizer
    import paper_framework_native_PV_port_20261021 as port
    legacy,legacy_hash=port.paper_normalizer();normalize,proof=native_unit_normalizer()
    tpa=ROOT/'outputs/tpa_native_second_identity_engineering_20261020'
    initial=pickle.loads((tpa/'PF0_before.pkl').read_bytes());root=pickle.loads((tpa/'PF1_before.pkl').read_bytes());root.sgen['q_mvar']=initial.sgen.q_mvar.to_numpy(copy=True)
    for name in ['bus','line','trafo','sgen','load','ext_grid','gen','shunt','switch']:assert root[name].equals(initial[name])
    f=np.load(tpa/'PF0_fields.npz')
    for n in f.files:assert np.array_equal(root[n].select_dtypes(include=[np.number]).to_numpy(float),f[n],equal_nan=True)
    model=np.load(ROOT/'outputs/native_inverter_linear_reference_20261020/Linear_Problem.npz')
    maxima=np.array(json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text())['native_column_max']);caps=.8*np.sqrt((1.2*maxima)**2-root.sgen.p_mw.to_numpy()**2)
    assert np.array_equal(caps,model['caps']) and np.array_equal(root.sgen.q_mvar.to_numpy(),model['root_q'])
    contract=port.native_contract(root.bus.index.to_numpy(),root.sgen.bus.to_numpy(),model['root_q'],caps,model['Y'])
    originals=[]
    for i,bus in enumerate(contract['PV_bus_ids']):
        amount=float((caps[i]-model['root_q'][i])/2);a=legacy({'bus':str(bus),'q_mvar':amount});assert a=={'add_shunts_q_mvar':{str(bus):25.}}
        originals.append({'bus':bus,'literal_native_increment':amount,'original_parser_increment':25.,'native_cap':float(caps[i]),'legacy_rejected':True})
    # Make parser adaptation explicit in this NEW software interface. No response,
    # model weights, learned action, or scientific outcome was used for the change.
    port.paper_normalizer=lambda:(normalize,proof['adapted_AST_sha256'])
    for row in originals:
        a=port.request_to_native_Q({'bus':str(row['bus']),'q_mvar':row['literal_native_increment']},contract)
        assert a['valid'] and a['increment_Mvar']==row['literal_native_increment'] and (np.abs(a['native_Q'])<=caps+1e-12).all()
        assert not port.request_to_native_Q({'bus':str(row['bus']),'q_mvar':25.},contract)['valid']
    negatives=[None,{},[],{'bus':'not_an_int','q_mvar':.01},{'bus':'9999999','q_mvar':.01},{'bus':'2','q_mvar':-1},{'bus':'2','q_mvar':float('nan')}]
    rejected=0
    for value in negatives:
        try:a=port.request_to_native_Q(value,contract);assert not a['valid']
        except (ValueError,TypeError):pass
        rejected+=1
    menu=port.native_positive_refinement_menu(contract);assert len(menu)==342
    tokenizer=AutoTokenizer.from_pretrained(str(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'),local_files_only=True,trust_remote_code=False)
    packets=[]
    for label,vm in [('paid_root108UV',f['res_bus'][:,0]),('paid_following77UV',np.load(tpa/'PF1_fields.npz')['res_bus'][:,0])]:
        for zone in contract['zones']:
            messages=port.messages_for_zone(contract,vm,zone);ids=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True);assert len(ids)+384<=8192
            packets.append({'administrative_context_not_forwarded':label,'zone':zone,'messages':messages,'actual_input_ids':ids,'input_tokens':len(ids)})
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_NAMED_NATIVE_UNIT_PARSER_AND_INPUT_SOFTWARE_ONLY_NOT_FULL_POLICY_OR_INFERENCE',
            'port_name':'PAPER_FRAMEWORK_NATIVE_PV_PORT_V2_EXPLICIT_PARSER_UNIT_ADAPTATION','v1_failed_assertion_preserved':True,'v1_failure_reason':'Unchanged source normalizer snaps every positive input to tested25Mvar grid and clamps minimum25; cannot represent native subMvar commands.',
            'parser_proof':proof,'all38_actual_devices':originals,'native_literal_preservation_checks':len(originals),'legacy25Mvar_cap_rejections':len(originals),'invalid_boundary_checks':rejected,'native_refinement_menu':len(menu),
            'full_current_packets':len(packets),'maximum_input_tokens':max(p['input_tokens'] for p in packets),'context':8192,'max_new_tokens':384,'no_truncation':True,
            'all_new_model_PF_optimizer_derivative_forecast_solve_GPU_calls':0,'elapsed_seconds':time.monotonic()-start,
            'limitations':['Explicit actuator/parser/prompt/context/partition adaptation, not original unchanged federation system.','Positive-only role, not bidirectional native policy.','No complete router/reflection/SE/LLM/noLLM comparator or real loader/cold/memory/preservation/physics readiness follows.','Old failed u_mvar interface remains STOPPED; this does not repair or reclassify its model outputs.']}
    for name,obj in [('Software_Readiness.json',result),('All8_Full_Current_Packets.json',packets)]:
        with (out/name).open('x',encoding='utf-8') as handle:json.dump(obj,handle,indent=2,allow_nan=False)
    print(json.dumps({k:result[k] for k in ['status','native_literal_preservation_checks','full_current_packets','maximum_input_tokens','all_new_model_PF_optimizer_derivative_forecast_solve_GPU_calls']}))
if __name__=='__main__':main()
