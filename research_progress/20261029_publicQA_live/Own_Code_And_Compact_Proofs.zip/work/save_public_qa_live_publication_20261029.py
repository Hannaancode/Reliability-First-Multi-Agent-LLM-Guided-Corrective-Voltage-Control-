"""Record actual owned execution and prepare compact own-code publication."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,sys
from coordinate_native_inverter_linear_reference_20261020 import process
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/public_qa_live_publication_20261029'
def read(p):return json.loads((R/p).read_text('utf-8'))
def put(p,v):
    p=R/p;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n','utf-8');t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists();O.mkdir();now=datetime.now(timezone.utc).isoformat()
    protocol='outputs/public_qa_execution_preparation_20261029/final/Final_Protocol.json';p=read(protocol);actors=[]
    for arm in p['arms']:
        d=R/arm['execution'];c=json.loads((d/'owner.claim').read_text());s=json.loads((d/'status.json').read_text())
        actual=process(c['actual_pid']);parent=process(c['parent_pid'])
        if actual:
            assert actual['ParentProcessId']==c['parent_pid'] and 'run_public_qa_colab_20261029.py' in actual['CommandLine']
            assert c['source_sha256']==sha(R/'work/run_public_qa_colab_20261029.py')
        actors.append({'arm':arm['id'],'profile':arm['profile'],'claim':c,'actual':actual,'parent':parent,
            'state':{k:s.get(k) for k in ['stage','runtime_allocated','runtime_released','science_started','preserved_packets','failure_type','all_artifacts_preserved']}})
    c=read(p['coordination']+'/owner.claim');coord={'claim':c,'actual':process(c['actual_pid']),'parent':process(c['parent_pid'])}
    checkpoint={'at_utc':now,'arms':actors,'coordinator':coord,'exec_session':33456,'protocol':protocol,
        'no_performance_conclusion_from_counts':True,'waiting_timer':None,'useful_parallel_work':'T20 method/source binding; T21 cohort identity gaps and thesis integration; T26 contribution evidence'}
    put('outputs/public_qa_execution_preparation_20261029/final/Current_Live_Resume.json',checkpoint)
    resume=read('outputs/public_qa_scale_design_20261029/Exact_Resume.json')
    resume.update(at_utc=now,status='FIXED_THREE_PROFILE_PUBLIC_QA_ACTUAL_EXECUTION',
        previous_goal_turn='PROGRESS: final software/source/payload gates closed; all3T4allocations succeeded, fixed owners launched and actual ownership checked. Thesis T21 cohort register and draft insert added.',
        prepared_protocol=protocol,owned_scientific_jobs=[{'arm':x['arm'],'actual_pid':x['claim']['actual_pid'],'parent_pid':x['claim']['parent_pid'],'state':x['state']} for x in actors],
        GPU_assignments=[x['profile'] for x in actors if x['state']['runtime_allocated'] and not x['state']['runtime_released']],
        exact_live_checkpoint='outputs/public_qa_execution_preparation_20261029/final/Current_Live_Resume.json',waiting_timer=None,
        new_model_PF_OPF_training_GPU_calls='Actual model attempts now tracked in per-arm journals; no newPF/OPF/training. Do not infer counts from setup flags.',
        next_ordered_actions=['Do not edit frozen live source/protocol/payload or restart any owner. Coordinator alone invokes the saved reader after all fixed arms close and exact runtimes release.',
            'Observe actual owned PID/parent/source and journals only when needed; inspect final manifests/hostEnd/readerEnd/Independent_Audit/Completion at closure. Preserve every partial/no-entry/unknown failure and full costs.',
            'Advance T20 and T26 thesis evidence work while inference runs. T21 source register covers6identity-bound cohorts and11other families; membership gaps remain, so it isPARTIAL.',
            'Integrate the cohort-use insert into the thesis, render and review before delivering; original121page thesis remains unchanged.',
            'If a live result becomes the sole dependency, use one estimated check and remove it at closure. No recurring monitor.'])
    put('outputs/public_qa_scale_design_20261029/Exact_Resume.json',resume)
    tasks=read('outputs/thesis_research_closure_20261028/Tasks.json')
    t=next(x for x in tasks['tasks'] if x['id']=='T21');t.update(status='PARTIAL',new_scoped_progress='Source-bound6cohort register plus11reported/development families and Chapter7insert prepared; unresolved identity joins and reviewed thesis integration remain.')
    for e in ['outputs/thesis_cohort_use_20261029/Cohort_Use_Register.json','outputs/thesis_cohort_use_20261029/Chapter7_Development_And_Confirmation_Insert.md']:
        if e not in t['evidence']:t['evidence'].append(e)
    tasks['updated_utc']=now;put('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    main_tasks=read('outputs/research_tasks_20261014/Tasks.json')
    main_tasks['public_QA_execution_20261029']={'status':'ACTUAL_FIXED_THREE_PROFILE_EXECUTION','protocol':protocol,
        'live_resume':resume['exact_live_checkpoint'],'no_performance_result_yet':True,'all_six_final_goals':'OPEN'}
    put('outputs/research_tasks_20261014/Tasks.json',main_tasks)
    header='## Three fixed public QA arms executing — '+now+'\n\nAll3fixedT4allocations succeeded; actual owners and coordinator checked. Final protocol outputs/public_qa_execution_preparation_20261029/final/Final_Protocol.json; exactlive resume outputs/public_qa_scale_design_20261029/Exact_Resume.json, exec33456. Actual engineering/inference attempts in per-armjournals; setup/counts are not performance. Do not duplicate, restart or edit live source. Coordinator alone follows closure/release with pinned reader. T21 cohort register covers6bound cohorts/11otherfamilies, unresolved membership gaps and thesis integration remain;14/35complete,all6goalsOPEN. UsefulparallelT20/T21/T26 remains;no timer.\n\n'
    for name in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        q=R/name;q.write_text(header+q.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write('\n'+now+' | Three actual publicQA arms and parallel thesis evidence\nFinal gates passed; each fixed own profile allocated oneT4. Same150questions/publiccircuit/prompt and greedy256 output contract across0.5/1.5/3B. Actual expectedweight SHA checks, synthetic full1252token capacity, two real Linux watchdog child checks and cold model gate precede testentry. No accuracy/voltage claim before final audit. Saved files/requests/costs persist with localACKbefore next call. All original stopped science preserved.\nT21:6identity-bound cohorts plus11reported/development families mapped; exact fresh128 seeds1000..1127 retain partial status, unentered1055..1127; historical137latertrajectoryjoin and61vs68membership unresolved. Draftinsert prepared;121page thesis unchanged.14/35complete;all6goalsOPEN.\n')
    codes=['public_qa_inference_worker_20261029.py','public_qa_inference_worker_v2_20261029.py','public_qa_transfer_20261029.py',
        'public_qa_remote_supervisor_20261029.py','public_qa_remote_setup_20261029.py','run_public_qa_colab_20261029.py',
        'audit_public_qa_worker_20261029.py','audit_public_qa_scientific_20261029.py','coordinate_public_qa_20261029.py',
        'check_public_qa_linux_watchdog_20261029.py','check_public_qa_supervision_20261029.py','check_public_qa_supervision_v2_20261029.py',
        'check_public_qa_host_lifecycle_20261029.py','check_public_qa_host_lifecycle_v2_20261029.py','check_public_qa_reader_20261029.py',
        'check_public_qa_reader_v2_20261029.py','check_public_qa_synthetic_capacity_20261029.py','pin_public_qa_weight_manifests_20261029.py',
        'prepare_public_qa_execution_draft_20261029.py','freeze_public_qa_execution_20261029.py','build_thesis_cohort_use_register_20261029.py',Path(__file__).name]
    proofs=['outputs/public_qa_supervision_20261029/'+x for x in ['software_v2/Result.json','host_lifecycle_v2/Result.json','reader_checks_v2/Result.json',
        'Synthetic_Capacity.json','Software_Fixture_Bound_Failure.json','Synthetic_Capacity_Entry_Failure.json','weight_metadata/Result.json']]
    proofs+=['outputs/public_qa_execution_preparation_20261029/final/Final_Readiness.json',protocol,
        'outputs/thesis_cohort_use_20261029/Cohort_Use_Register.json','outputs/thesis_cohort_use_20261029/Chapter7_Development_And_Confirmation_Insert.md',
        'outputs/public_qa_scale_design_20261029/Focused_Method_Review_And_Decisions.md']
    index=[]
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip','x',zipfile.ZIP_DEFLATED) as z:
        for name in ['work/'+n for n in codes]+proofs:
            file=R/name;b=file.read_bytes();assert not any(s.search(b.decode('utf-8-sig')) for s in SECRET),name
            z.writestr(name,b);index.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip') as z:
        assert z.testzip() is None
        for x in index:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
    compact={'at_utc':now,'status':'ACTUAL_EXECUTION_NO_AUDITED_PERFORMANCE_YET','arms':[{'arm':x['arm'],'profile':x['profile'],'actual_owner_live':x['actual'] is not None,**x['state']} for x in actors],
        'thesis_complete':14,'thesis_total':35,'all_six_goals':'OPEN','T21':'PARTIAL_REGISTER_AND_DRAFT_INSERT','raw_backup_complete':False,
        'excluded':['private model weights and NETs','raw questions/circuit/labels/tokenpacks/model outputs','third-party sources','fullthesisDOCX/PDF','credentials/runtimeproxydata']}
    put(str((O/'Current_Progress.json').relative_to(R)),compact)
    put(str((O/'Artifact_Index.json').relative_to(R)),{'members':index,'raw_backup_complete':False})
    for dest,source in [('Thesis_Checklist.json','outputs/thesis_research_closure_20261028/Tasks.json'),('Cohort_Use_Register.json','outputs/thesis_cohort_use_20261029/Cohort_Use_Register.json')]:
        (O/dest).write_bytes((R/source).read_bytes())
    files=[]
    for q in sorted(O.iterdir()):
        b=q.read_bytes();files.append({'local':str(q.relative_to(R)).replace('\\','/'),'path':'research_progress/20261029_publicQA_live/'+q.name,
            'bytes':len(b),'sha256':sha(q),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
    put(str((O/'Publication_Map.json').relative_to(R)),files)
    print(json.dumps({'status':'SAVED_LIVE_AND_PUBLICATION_PREPARED','files':len(files),'members':len(index),'bytes':sum(x['bytes'] for x in files)}))
if __name__=='__main__':main()
