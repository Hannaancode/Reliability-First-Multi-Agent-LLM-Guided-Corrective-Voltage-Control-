"""One bounded model interface owner followed by its sole zero-model reader."""
import os,json,subprocess,hashlib
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
P=R/'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'
O=R/'outputs/native13_fullband_original_adapter_engineering_handoff_20261021'
def put(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'at_utc':datetime.now(timezone.utc).isoformat()})
 ready=json.loads((P/'Launch_Readiness_Audit.json').read_text(encoding='utf-8'))
 assert ready['passed']
 for n,h in ready['source_hashes'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf-8') as f:
   code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),{'exit_code':code,'at_utc':datetime.now(timezone.utc).isoformat()});assert code==0,'Preserve failed/partial/denied attempt; no model or allocation retry'
 put(O/'Completion.json',{'status':'MODEL_INTERFACE_ENGINEERING_AND_SOLE_READER_TERMINAL','at_utc':datetime.now(timezone.utc).isoformat()})
if __name__=='__main__':main()
