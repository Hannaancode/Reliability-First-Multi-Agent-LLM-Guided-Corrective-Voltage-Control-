"""Final exact input/ownership lock before any allocation or outcome."""
import ast,json,shutil
from reflection118_chronological_core_20261022 import R,read,put,sha
P=R/'outputs/reflection118_chronological_preparation_20261022'
assert not (R/'outputs/r118chrono_20261022').exists()
assert not (R/'outputs/r118chrono_handoff_20261022').exists()
ready=read(P/'Launch_Readiness_Audit.json')
paths=[R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json',
    R/'outputs/registered_severe_federation_root_binding_20261022/independent_audit/Independent_Audit.json',
    R/'work/e/pack/testbeds/federation_4mg_ieee118.json',R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json',
    R/'outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz',
    R/'outputs/original_role_remaining_native_history_scope_20261022/All_Saved_Snapshot_Components.json']
for row in read(paths[0]):
    assert sha(R/row['solved_payload'])==row['payload_sha256']
    assert sha(R/row['registration']['recipe'])==row['registration']['recipe_sha256']
    paths.extend([R/row['solved_payload'],R/row['registration']['recipe']])
for n in ['run_reflection118_chronological_colab_20261022.py','coordinate_reflection118_chronological_20261022.py',
          'reflection118_model_service_guardian_20261022.py']:
    ast.parse((R/'work'/n).read_text('utf-8'))
put(P/'Input_Source_Lock.json',{'status':'PASS_FINAL_EXACT_FOUR_ROOT_INPUT_SOURCE_LOCK_BEFORE_ALLOCATION',
    'pins':{x.relative_to(R).as_posix():sha(x) for x in paths},'new_PF_model_calls':0,
    'no_cropping_or_silent_root_regeneration':True,'private_NET_exported':False})
shutil.copyfile(P/'Launch_Readiness_Audit.json',P/'Launch_Readiness_Before_Final_Input_Lock.json')
ready['source_hashes'].update(read(P/'Input_Source_Lock.json')['pins'])
ready['source_hashes'][(P/'Input_Source_Lock.json').relative_to(R).as_posix()]=sha(P/'Input_Source_Lock.json')
(P/'Launch_Readiness_Audit.json').write_text(json.dumps(ready,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'exact_root_cases':4,'source_input_pins':len(ready['source_hashes']),'science_started':False}))
