"""Independent saved-evidence/source audit, with no scientific calculations.

This reader checks the new engine's eight complete durable decision records
against already audited decisions. It does not re-run the engine or any solver.
"""
import ast,copy,hashlib,json,os,struct,time
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1]
B=R/'outputs/receding_durable_engine_independent_audit_20261015'
W=R/'outputs/receding_engine_durable_v2_integration_20261015'
D=R/'outputs/receding_warm_dependency_closure_20261015'
P=R/'outputs/bounded_paid_lookahead_physics_20261014'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while block:=f.read(1024**2):h.update(block)
    return h.hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def dump(n):return ast.dump(n,include_attributes=False)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    reference=read(P/'verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json')
    assert reference['fixed_opportunity_gate']=='PASS'
    oldpath=R/'work/bounded_paid_lookahead_physics_20261014.py'
    newpath=R/'work/receding_paid_decision_engine_durable_v2.py'
    old=ast.parse(oldpath.read_text('utf-8'))
    certificate=read(R/'outputs/receding_engine_durable_v2_preparation_20261015/Additive_Source_Certificate.json')
    assert certificate['new_source_sha256']==sha(newpath)
    restored=newpath.read_text('utf-8')
    for change in reversed(certificate['changes']):
        assert restored.count(change['after'])==1
        restored=restored.replace(change['after'],change['before'])
    assert restored==(R/certificate['old_source']).read_text('utf-8')
    assert certificate['old_source_sha256']==sha(R/certificate['old_source'])
    new=ast.parse(restored)
    certificates={}
    for name in ('ensure','make_menu','query'):
        original=next(n for n in ast.walk(old) if isinstance(n,ast.FunctionDef) and n.name==name)
        current=copy.deepcopy(next(n for n in ast.walk(new) if isinstance(n,ast.FunctionDef) and n.name==name))
        if name=='query':
            hits=[n for n in ast.walk(current) if isinstance(n,ast.Constant) and n.value=='NEW_RECEDING_'];assert len(hits)==1
            hits[0].value='NEW_LOOKAHEAD_'
        assert dump(original)==dump(current),name
        certificates[name]='EXACT_ORIGINAL_AST_EXCEPT_DECLARED_RECEIPT_NAMESPACE'
    assert any(isinstance(n,ast.ImportFrom) and n.module=='project_paid_joint_successor_v1' and
               [a.name for a in n.names]==['project'] for n in new.body)
    initial=read(R/'outputs/receding_paid_engine_source_20261014/Verified_Callback_Extraction.json')
    assert sha(oldpath)==initial['source_sha256']
    # The first builder proof preceded the missing project import fix. Keep it
    # intact and explicitly certify the actual imported, tested current source.
    source_proof={'original_builder_proof_preserved':True,'original_builder_generated_sha256':initial['new_source_sha256'],
        'actual_tested_source_sha256':sha(newpath),'prelaunch_import_dependency_fix':'project imported explicitly',
        'all_three_callback_AST_certificates':certificates,'no_old_scientific_source_changed':True}
    deps=read(D/'Paid_Warm_Dependencies.json');warm=read(W/'Actual_All8_Warm_Engine_Integration.json')
    for name,h in warm['source_sha256'].items():assert sha(R/name)==h,name
    for name,h in deps['source_sha256'].items():assert sha(R/name)==h,name
    prior_cache=read(R/'outputs/operation_aware_lookahead_input_cache_20261014/Compatible_Paid_Receipt_Index.json')
    assert all(deps['cache'][k]==v for k,v in prior_cache['cache'].items())
    prefix='0'*64;intents={};forecasts={}
    with (P/'actual/scientific.jsonl').open('rb') as stream:
        for line in stream:
            e=json.loads(line);assert e['previous_sha256']==prefix;prefix=hashlib.sha256(line.rstrip(b'\n')).hexdigest()
            d=e['data']
            if e['event']=='PF_intent' and d['context']['phase']=='NEW_PRIMARY_QUERY':intents[d['identity']]=d
            if e['event']=='second_causal_context_and_forecasts':
                for row in d['rows']:
                    aid=hashlib.sha256(canonical({k:row[k] for k in ('kind','receiver','q','donor_index','donor_bus')})).hexdigest()
                    k=d['context_identity']+'|'+aid
                    if k in forecasts:assert forecasts[k]==row['ordering_forecast']
                    forecasts[k]=row['ordering_forecast']
    assert forecasts==deps['existing_numeric_forecasts'] and len(forecasts)==24641
    ids=set()
    for i in range(1,9):
        branch=read(P/'actual'/f'Branch_{i}.json')
        for msg in branch['query_messages']:
            rec=msg['record'];measurement=rec.get('actual_measured_receipt')
            if not measurement:continue
            c=intents[measurement['PF_id']]['context'];assert c['action_key']==msg['aid']
            expected=copy.deepcopy(rec)
            if expected['after_reference']:
                ref=expected['after_reference'];assert ref['kind']=='new'
                expected['after_reference']={'kind':'external_capsule','base':str(P.relative_to(R)),'descriptor':ref['descriptor']}
            expected['source_existing_measured_receipt']=expected.pop('actual_measured_receipt')
            expected['source']='INDEPENDENTLY_VERIFIED_BOUNDED_LOOKAHEAD_20261014'
            assert deps['cache'][c['point']+'|'+c['action_key']]==expected
            ids.add(measurement['PF_id'])
    assert ids==set(intents)==set(deps['newly_indexed_already_paid_query_ids']) and len(ids)==68
    anchor=warm['complete_durable_history_anchor'];file=R/anchor['path']
    assert file.stat().st_size==anchor['bytes'] and sha(file)==anchor['sha256']
    chain='0'*64;records=[]
    with file.open('rb') as stream:
        while header:=stream.read(8):
            assert len(header)==8;size=struct.unpack('<Q',header)[0];data=stream.read(size);assert len(data)==size
            e=json.loads(data);assert e['previous']==chain and e['source_anchor']==anchor['source_anchor'] and e['input_anchor']==anchor['input_anchor']
            chain=hashlib.sha256(data).hexdigest();records.append(e)
    assert len(records)==anchor['records']==8 and chain==anchor['last_record_sha256']
    assert anchor['source_anchor']==sha(R/'work/check_receding_engine_durable_v2_20261015.py') and anchor['input_anchor']==sha(D/'Paid_Warm_Dependencies.json')
    checked=0
    for i,e in enumerate(records,1):
        assert e['event']=='complete_paid_receding_decision';actual=e['payload'];original=read(P/'actual'/f'Branch_{i}.json')
        assert actual['world']==original['world'] and actual['method']==original['method'] and actual['decision']==0
        # Handles include a new prospective decision index; identify structure
        # through causal actions, never through an after-result chosen subset.
        am=actual['plan'];om=original['plan']
        for k in ('status','root_queries','second_queries'):assert am[k]==om[k],k
        for k in ('first','second','measured_leaf','operations'):assert am['selected'][k]==om['selected'][k],k
        assert len(actual['menus'])==len(original['menus']) and len(actual['query_messages'])==len(original['query_messages'])
        for a,b in zip(actual['menus'],original['menus']):
            for k in ('slots','k','ids'):assert a[k]==b[k],k
        for a,b in zip(actual['query_messages'],original['query_messages']):
            assert a['aid']==b['aid'] and a['row']==b['row']
            for k in ('verdict','original_score','attributed_PF_calls','attributed_solver_seconds','receipt_id'):
                assert a['record'][k]==b['record'][k],k
            checked+=1
        for k in ('attributed_query_PF_calls','attributed_query_solver_seconds','root_query_count','second_query_count'):
            assert actual['attributed_costs'][k]==original['attributed_costs'][k],k
        assert actual['attributed_costs']['new_query_PF_calls']==0
    assert warm['new_forecasts']==0
    assert warm['new_PF_model_derivative_solve_forecast_calls']==0 and warm['already_paid_forecasts_reused']==30842
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_INDEPENDENT_ALL8_DURABLE_DECISIONS_PAID_DEPENDENCIES_AND_SOURCE',
        'checked_decisions':8,'checked_ordered_query_messages':checked,'paid_cache_entries':len(deps['cache']),
        'newly_indexed_old_query_ids':68,'exact_old_forecast_entries':24641,'warm_forecast_reuses':30842,
        'source_dependency_closure':source_proof,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'scope':'Software integration and prior-cost identity; no new physical/model/performance outcome',
        'full_trajectory_and_real_LLM_pending':True,'source_sha256':sha(Path(__file__))}
    put(B/'Independent_Warm_Engine_Audit.json',result)
    put(B/'Closed_Manifest.json',{'exit_code':0,'members':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()}})
    print(json.dumps({k:result[k] for k in ('status','checked_decisions','checked_ordered_query_messages','new_scientific_calls')}))
if __name__=='__main__':main()
