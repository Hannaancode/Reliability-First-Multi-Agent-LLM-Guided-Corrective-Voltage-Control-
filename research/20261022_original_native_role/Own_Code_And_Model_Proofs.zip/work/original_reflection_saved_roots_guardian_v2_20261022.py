"""Own one bounded child; preserve actual files after complete or partial science."""
import json,subprocess,sys,time
from pathlib import Path
from public_size_u61_preservation import atomic_json,file_hash
ROOT=Path(__file__).resolve().parents[1]
protocol=json.loads((ROOT/'prep/protocol.json').read_text());started=time.monotonic()
with (ROOT/'outputs/public_size_science.log').open('w') as log:
    child=subprocess.Popen([sys.executable,str(ROOT/'work/run_original_reflection_saved_roots_remote_v2_20261022.py')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    atomic_json(ROOT/'outputs/public_size_scientific_pid.json',{'pid':child.pid,'started_at_unix':time.time(),'source':'work/run_original_reflection_saved_roots_remote_v2_20261022.py'})
    timeout=False
    try:code=child.wait(timeout=protocol['science_process_seconds'])
    except subprocess.TimeoutExpired:
        timeout=True;child.terminate()
        try:code=child.wait(timeout=30)
        except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=30)
study=ROOT/'outputs/public_size_science'
if study.exists():
    manifest={p.relative_to(study).as_posix():{'bytes':p.stat().st_size,'sha256':file_hash(p)}
              for p in study.rglob('*') if p.is_file() and p.name!='progress.json' and not p.name.endswith('.tmp')}
    parts=ROOT/'outputs/public_size_closed_parts';parts.mkdir(exist_ok=False)
    for number,(name,record) in enumerate(sorted(manifest.items())):
        record['parts']=[]
        with (study/name).open('rb') as f:
            for i,raw in enumerate(iter(lambda:f.read(2*1024*1024),b'')):
                part=f'file_{number:05d}_part_{i:04d}.bin';(parts/part).write_bytes(raw)
                record['parts'].append({'name':part,'bytes':len(raw),'sha256':file_hash(parts/part)})
    atomic_json(ROOT/'outputs/public_size_closed_descriptor.json',{'members':manifest,'science_pid':child.pid,'exit_code':code,
       'hard_bound_enforced':timeout,'guardian_seconds':time.monotonic()-started,'scientific_process_ended':True})
atomic_json(ROOT/'outputs/public_size_exit.json',{'exit_code':code,'scientific_process_ended':True,'hard_bound_enforced':timeout})
