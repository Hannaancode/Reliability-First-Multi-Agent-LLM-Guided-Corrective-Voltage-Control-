"""Durable evidence/unknowns/resume and public proofs, no scientific calls."""
import hashlib,json,os,zipfile
from datetime import datetime,timezone
from pathlib import Path
from fixed_four_query_core_20261019 import B,PHASES
from public118_slsqp_native_20261018 import R,read,put,sha
from save_fixed_three_progress_20261019 import atomic
from candidate_process_evidence_utils import seal,frozen_checks
from equal_operation_benchmark_v2 import process
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
SCREEN=R/'outputs/fixed_nine_preserved_receipts_screen_v3_20261019'

def main():
    out=B/'verified_checkpoint';out.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    audit=read(B/'audit/Independent_Audit.json');custody=read(B/'custody_repair/Completion.json')
    assert custody['original_physical_evidence_checks_completed'] and custody['original_overall_complete_gate']=='UNKNOWN_LAST_PROCESS_EXIT'
    assert audit['counts']['PF_returns']==8 and audit['counts']['PF_exceptions']==0
    actors=[]
    for phase in (*PHASES,'audit'):
        c=read(B/phase/'owner.claim');assert process(c['actual_pid']) is None and process(c['actual_parent_pid']) is None
        actors.append({'phase':phase,'source_claim':c,'end':read(B/(phase+'_End_ACK.json'))})
    table=[]
    for phase in PHASES:
        d=read(B/phase/'Result.json')['receipt'];v=d['message']['record']['verdict'];table.append({'phase':phase,'row':d['message']['row'],'point_action_key':d['point_action_key'],'accepted':v['accepted'],'before':v['before'],'after':v['after'],'original_score':d['message']['record']['original_score'],'replay_maximum_all118_field_delta':d['replay']['maximum_field_delta']})
    assert all(x['accepted'] and x['before']['uv_count']==17 and x['after']['uv_count']==14 and x['after']['vmax']<=1.05+1e-8 and x['replay_maximum_all118_field_delta']==0 for x in table)
    live=None
    if (SCREEN/'owner.claim').exists():
        c=read(SCREEN/'owner.claim');q=process(c['actual_pid'])
        if q:
            assert 'replay_fixed_nine_preserved_receipts_v3_20261019.py' in q['CommandLine'] and q['ParentProcessId']==c['parent_pid']
            live={'source':'work/replay_fixed_nine_preserved_receipts_v3_20261019.py','actual_pid':c['actual_pid'],'parent_pid':c['parent_pid'],'actual_command':q['CommandLine'],'source_sha256':sha(R/'work/replay_fixed_nine_preserved_receipts_v3_20261019.py'),'new_scientific_calls':0,'fixed_bound_seconds':900}
    result={'status':'ALL4_PHYSICAL_QUERY_AND_REPLAY_EVIDENCE_VERIFIED_LIFECYCLE_GATE_PARTIAL','at_utc':at,'source_point':read(B/'Protocol.json')['point'],'all4_original_order_results':table,'physical_source_replay_checks':'PASS_ALL8','overall_complete_gate':'UNKNOWN_LAST_PROCESS_EXIT','original_reader_result':audit,'custody_repair':custody,'actors':actors,'no_actual_new_commit_or_LLM_DSE_claim':True,'all6goals':'OPEN','active_readonly_analysis':live,'GPU_allocations':[],'timers':[],'new_today_PF_across_earlier3_and_these4':14,'limitations':'Seven safe alternative queries at TWO different saved17UVstates; not seven sequential reductions or seven solved cases. Last original child exit code was not captured; do not relabel complete. All original failed/adverse/UNKNOWN costs remain retained.'}
    put(out/'Verified_Research_Checkpoint.json',result);put(out/'Frozen_Completion.json',frozen_checks())
    nexts=['Observe only the exact saved read-only owner if still live; never duplicate/restart it. It reuses all nine paid receipts and existing full-native numerical contexts, zero new science.','On closure preserve exact next missing identity/menu/context and all costs/UNKNOWNs. Do not invent missing physical outputs or silently launch new PF.','Four-query source/physical/full-state/replay evidence passed; original last child exit0 gate remainsUNKNOWN forever unless actual OS evidence appears. No scientific repeat to repair it.','Before any genuinely unexecuted measurement, freeze exact causal-input/menu/action/native-verifier/persistent/ownership/independent-reader/full-cost gates. No action/Q/seed/width/objective/budget retunes.','Keep all six goals OPEN; continue toward complete matched severe-case protected trajectories, actual fresh LLM attribution, full both-DSE costs and unused confirmation.']
    current=R/'outputs/remaining_three_fixed_queries_20261019/verified_completion/Current_Resume_20261019.json';resume=read(current);resume.update(at_utc=at,status=result['status'],latest_closed_evidence=str((out/'Verified_Research_Checkpoint.json').relative_to(R)),active_analysis=live,next_steps_in_order=nexts,waiting_check={'status':'NONE'},all6finalgoals='OPEN');atomic(current,resume)
    canonical=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';v=read(canonical);v.update(at_utc=at,current_task={'status':result['status'],'evidence':str((out/'Verified_Research_Checkpoint.json').relative_to(R))},active_owned_jobs=[live] if live else [],timers=[],next_tasks=nexts,latest_closed_continuation=str(current.relative_to(R)));atomic(canonical,v)
    taskpath=R/'outputs/research_tasks_20261014/Tasks.json';v=read(taskpath);v['at_utc']=at;v['tasks'][0]['latest_20261019_four_query']=str((out/'Verified_Research_Checkpoint.json').relative_to(R));v['tasks'][0]['next']=nexts[0];v['latest_exact_execution_state']=str(current.relative_to(R));atomic(taskpath,v)
    master=R/'RESEARCH_TASKS.md';lines=master.read_text('utf-8').splitlines();lines[2]=f'Updated {at}. All six final goals remain open; verified subtasks retain their original evidence.';master.write_text('\n'.join(lines)+'\n\n19October second distinct17UV saved state: all4fixed alternative queries safely17to14UV;8chargedPF incl4exactreplays, source/physics/cold-state auditpassed. Original last child exit codeUNKNOWN leaves overall lifecycle gatePARTIAL. No actualcommit/DSE/LLMsuperiority. [Evidence](outputs/fixed_four_query_acquisition_20261019/verified_checkpoint/Verified_Research_Checkpoint.json).\n','utf-8')
    report='# Fixed four-query evidence and continuation\n\nAll four originally selected actions at this distinct saved state passed the original safety verifier: **17 → 14 UV**, with Vmmax within1.05+1e-8. Eight PF calls returned, including four explicitly charged replays; every118-bus Vm/angle/P/Q replay field matched exactly. No exceptions, fresh model calls, GPU or actual commits.\n\nThe original coordinator failed reading a claim file before its JSON write finished. The same waiting final child received a fresh source/PID/parent/command acknowledgement and ran once. Its output and complete state are preserved, but its OS exit code was not captured: **overall lifecycle gate remains PARTIAL/UNKNOWN**. The original independent reader ran once and passed every saved source/input/physical/replay/state/cost assertion; its original partial result is preserved.\n\nThese are alternative actions at one state, not sequential reductions or a completed trajectory. Earlier three safe queries were at a different state. Full deterministic and incremental LLM superiority remain unachieved.\n\n|Rank|Recipient|Q MVAr|UV before|UV after|Accepted|\n|---|---:|---:|---:|---:|---|\n'
    for i,x in enumerate(table,1):report+=f"|{i}|{x['row']['receiver']}|{x['row']['q']}|17|14|yes|\n"
    report+='\nNext: finish the unchanged-policy saved-data analysis, preserving its next exact gap and all unknowns. No automatically authorized extra measurement from this result.\n'
    (out/'Results_And_Next.md').write_text(report,'utf-8')
    header=f'LATEST FOUR-QUERY PRESERVED PHYSICS {at}\n\nALL4fixedqueriesatsecond17UVstate accepted17to14;8PFreturns0exceptions,4exactchargedreplays. Originalsource/physical/state/costreaderschecksPASS; finalchildOSexitUNKNOWN, originalcompletegatePARTIALretained. Allscience/readersended, sole readonlyanalysis '+(str(live['actual_pid']) if live else 'NONE')+' maybelive; freshsourcecheckrequired. NoGPU/timers/actualcommit/wholeDSE/LLMclaim. Read outputs/fixed_four_query_acquisition_20261019/verified_checkpoint/Verified_Research_Checkpoint.json and currentresume. No oldrestart/repeatedscience/outcomeretune/budgetextension. All6goalsOPEN.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+at+' —Four fixed queries at distinct saved17UVstate ALL accepted17to14UV; normalupper1.05+1e-8 guard unchanged.8PF8returns0exceptions incl4chargedreplays/all118fieldsdelta0. Original claim JSON partial-write caused coordinator exit; same live waiting child ACKed/no restart. Actual finalchild exitUNKNOWN, original readerpartial retained; source/native/input/fullstate/replay/cost checks passed. No actualcommit/newLLM/GPU or wholepolicy win. New readonly all-nine registry first additive missingOverlayimport failed BEFOREquery use, source/outputs retained; separate v3 imports only, zero science. Old next-cell public pack stopped at missingzipfile import in preserved source; additive packaging below does not repeat any physics. Actualcosts '+json.dumps(audit['costs'])+'.\n');f.flush();os.fsync(f.fileno())
    localfiles={p.relative_to(R).as_posix():p for p in B.rglob('*') if p.is_file() and 'verified_checkpoint' not in p.parts and 'publication' not in p.parts}
    for p in out.iterdir():localfiles[p.relative_to(R).as_posix()]=p
    seal(out,localfiles,'Complete_Local_Four_Query_Evidence.zip')
    public=B/'publication';public.mkdir();selected={}
    for rel in read(B/'Protocol.json')['source_input_sha256']:
        p=R/rel
        if p.suffix=='.py':selected[p.relative_to(R).as_posix()]=p
    for p in (R/'work').glob('*fixed*20261019.py'):selected[p.relative_to(R).as_posix()]=p
    for p in B.rglob('*'):
        if p.is_file() and 'publication' not in p.parts and (p.suffix in ('.json','.md','.log') or p.name=='owner.claim'):selected[p.relative_to(R).as_posix()]=p
    for rel in ('RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json','outputs/next_fixed_physical_cell_20261019/Exact_Next_Cell.json'):
        p=R/rel;selected[rel]=p
    withheld=[]
    for n,p in list(selected.items()):
        if SECRET_NAME.search(p.name) or any(s.search(p.read_text('utf-8')) for s in SECRET):withheld.append(n);del selected[n]
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in selected.items()};put(public/'Manifest.json',{'files':desc,'withheld':withheld,'rawNET_checkpoints_models':'LOCAL_ONLY_NO_FULL_RAW_BACKUP_CLAIM','all6goals':'OPEN'})
    dest=public/'Four_Query_Code_And_Proofs.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in selected.items():z.write(p,n)
        z.write(public/'Manifest.json','Manifest.json')
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(selected)+1
        for n,d in desc.items():raw=z.read(n);assert len(raw)==d['bytes'] and hashlib.sha256(raw).hexdigest()==d['sha256']
    put(public/'Package_Audit.json',{'status':'PASS_UNIQUE_CRC_ALL_HASH_SECRET_SCREEN','bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(selected)+1,'withheld':withheld})
    print(json.dumps({'saved':True,'queries_safe':4,'UV':'17to14','overall_lifecycle':'PARTIAL_UNKNOWN_EXIT','active_analysis':live,'public_pack_bytes':dest.stat().st_size}))
if __name__=='__main__':main()
