"""Original native FIRST_ZONE query, original conditional reprompt, two roots.

Compare the unchanged private LoRA and the same adapter-disabled base. No
physics, fine-tuning, feedback fabrication or physical performance claim.
"""
import os
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
os.environ['HF_HUB_OFFLINE'] = '1'
import contextlib
import functools
import gc
import hashlib
import json
import time
import traceback
from pathlib import Path
from public_size_u61_preservation import atomic_json, journal, Publisher, file_hash

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/public_size_science'
OUT.mkdir(exist_ok=False)
started = time.monotonic()
p = json.loads((ROOT / 'prep/protocol.json').read_text())
inputs = json.loads((ROOT / 'prep/All2_Original_FIRST_ZONE_Inputs.json').read_text())
environment = json.loads((ROOT / 'outputs/public_size_environment.json').read_text())
atomic_json(OUT / 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(),
    'source_sha256': file_hash(__file__), 'protocol_sha256': file_hash(ROOT / 'prep/protocol.json'),
    'started_at_unix': time.time()})
costs = {'model_load_attempts': 0, 'model_load_returns': 0, 'query_attempts': 0,
         'query_returns': 0, 'generation_attempts': 0, 'generation_returns': 0,
         'pretrained_forward_attempts': 0, 'pretrained_forward_returns': 0,
         'generated_token_count': 0, 'PF_optimizer_backward_training_calls': 0}
events = OUT / 'events.jsonl'
previous = '0' * 64


def event(kind, **data):
    global previous
    assert time.monotonic() - started < p['science_process_seconds']
    row = {'kind': kind, 'elapsed_seconds': time.monotonic() - started,
           'previous': previous, **data}
    h = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    journal(events, {'event': row, 'sha256': h})
    previous = h


def progress(stage):
    atomic_json(OUT / 'progress.json', {'stage': stage, 'costs': costs, 'updated_unix': time.time()})


publisher = Publisher(OUT, ROOT / 'outputs/public_size_transfer', wait_seconds=120)
try:
    import numpy as np
    import torch
    from transformers import AutoTokenizer
    from candidate_process_pretrained_loader_native13_v2_20261020 import (
        load_isolated_body, preservation_inventory, verify_copy_state, source_adapter_state)
    from original_reflection_serving_pure_20261022 import original_query, initial_messages, definitions
    from original_reflection_tokenizer_tensor_view_v2_20261022 import TensorTemplateView
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0) == 'Tesla T4'
    assert len(inputs) == 2 and [x['root'] for x in inputs] == ['L1', 'L2']
    adapter = ROOT / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for name, h in p['private_adapter_tokenizer_unchanged'].items():
        assert file_hash(adapter / name) == h
    for name, h in p['original_serving_sources'].items():
        assert file_hash(ROOT / name) == h
    tokenizer = AutoTokenizer.from_pretrained(str(adapter), local_files_only=True, trust_remote_code=False)
    for item in inputs:
        assert initial_messages(item) == item['messages']
        encoded = tokenizer.apply_chat_template(item['messages'], tokenize=True, add_generation_prompt=True)
        ids = encoded['input_ids'] if hasattr(encoded, 'keys') else encoded
        assert ids == item['token_ids'] and len(ids) + 384 <= 4096
    atomic_json(OUT / 'Input_And_Loader_Preconditions.json', {
        'actual_two_source_order_paid_roots': True, 'original_FIRST_ZONE_and_empty_initial_feedback_only': True,
        'all_initial_messages_and_token_ids_exact': True, 'longest_prefix': max(len(x['token_ids']) for x in inputs),
        'max_new_tokens': 384, 'all_private_file_hashes_exact': True,
        'exact_dependency_count': environment['exact_dependency_count'],
        'base_weight_sha256': environment['base_weight_sha256'], 'new_model_queries_before_this_gate': 0})
    event('input_source_context_preconditions_pass')
    publisher.publish('source_input_context_preconditions')

    def run_replica(replica):
        torch.manual_seed(p['seed']); torch.cuda.manual_seed_all(p['seed']); np.random.seed(p['seed'])
        torch.cuda.reset_peak_memory_stats()
        costs['model_load_attempts'] += 1
        event('model_load_attempt', replica=replica)
        tick = time.perf_counter()
        model, proof = load_isolated_body(Path(environment['base_snapshot']), adapter, train_body=False)
        assert not any(x.requires_grad for x in model.parameters())
        costs['model_load_returns'] += 1
        event('model_load_return', replica=replica, seconds=time.perf_counter() - tick)
        atomic_json(OUT / f'{replica}_Loader_Proof.json', proof)
        before = preservation_inventory(model)
        atomic_json(OUT / f'{replica}_Immutable_Values_Before.json', before)
        core = model.get_base_model()
        original_forward, original_generate = core.forward, model.generate
        current = {}

        @functools.wraps(original_forward)
        def counted(*args, **kwargs):
            costs['pretrained_forward_attempts'] += 1
            number = costs['pretrained_forward_attempts']
            event('pretrained_forward_attempt', replica=replica, number=number, **current)
            tick = time.perf_counter(); answer = original_forward(*args, **kwargs)
            assert torch.isfinite(answer.logits).all()
            costs['pretrained_forward_returns'] += 1
            event('pretrained_forward_return', replica=replica, number=number,
                  seconds=time.perf_counter() - tick, **current)
            return answer

        core.forward = counted
        results = []
        for arm in p['arms']:
            context = model.disable_adapter() if arm == 'base_disabled' else contextlib.nullcontext()
            with context:
                flags = {n: m.disable_adapters for n, m in model.named_modules()
                         if isinstance(getattr(m, 'disable_adapters', None), bool)}
                assert flags and all(v == (arm == 'base_disabled') for v in flags.values())
                atomic_json(OUT / f'{replica}_{arm}_Actual_Adapter_Enable_State.json', flags)
                for item in inputs:
                    current.clear(); current.update(arm=arm, agent=item['agent'], root=item['root'])
                    request_calls = []
                    base_generate = definitions('base', {'torch': torch})['generate_response']

                    def generate(actual_model, actual_tokenizer, messages):
                        assert actual_model is model and actual_tokenizer is tokenizer
                        encoded = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
                        ids = encoded['input_ids'] if hasattr(encoded, 'keys') else encoded
                        assert 0 < len(ids) and len(ids) + 384 <= 4096
                        call = len(request_calls) + 1
                        assert call <= 2
                        if call == 1:
                            assert messages == item['messages'] and ids == item['token_ids']
                        receipt = {'replica': replica, **current, 'query_call': call,
                                   'messages': messages, 'input_token_ids': ids}

                        @functools.wraps(original_generate)
                        def generated(*args, **kwargs):
                            assert not args and kwargs['max_new_tokens'] == 384 and not kwargs['do_sample']
                            assert kwargs['use_cache'] is True
                            prefix = kwargs['input_ids']; mask = kwargs['attention_mask']
                            assert prefix.tolist() == [ids] and bool(mask.all())
                            costs['generation_attempts'] += 1
                            number = costs['generation_attempts']
                            event('generation_attempt', replica=replica, number=number, query_call=call,
                                  input_tokens=len(ids), **current)
                            tick = time.perf_counter(); fc = costs['pretrained_forward_returns']
                            with torch.inference_mode():
                                sequence = original_generate(*args, **kwargs)
                            torch.cuda.synchronize()
                            new = sequence[0, len(ids):].detach().cpu().tolist()
                            assert 0 < len(new) <= 384 and costs['pretrained_forward_returns'] - fc == len(new)
                            assert sequence[0, :len(ids)].cpu().tolist() == ids
                            costs['generation_returns'] += 1; costs['generated_token_count'] += len(new)
                            receipt.update(output_token_ids=new, generation_seconds=time.perf_counter() - tick,
                                           actual_forward_returns=len(new),
                                           peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                                           peak_reserved_bytes=torch.cuda.max_memory_reserved())
                            assert receipt['peak_allocated_bytes'] <= 12 * 1024 ** 3
                            event('generation_return', replica=replica, number=number, query_call=call,
                                  generated_tokens=len(new), seconds=receipt['generation_seconds'], **current)
                            return sequence

                        model.generate = generated
                        try:
                            text = base_generate(model, TensorTemplateView(tokenizer), messages)
                        finally:
                            model.generate = original_generate
                        receipt['raw_text'] = text
                        request_calls.append(receipt)
                        atomic_json(OUT / f'{replica}_{arm}_{item["root"]}_Call_{call}.json', receipt)
                        progress('actual_original_query_return_preserving')
                        publisher.publish(f'{replica}_{arm}_{item["root"]}_call_{call}')
                        return text

                    costs['query_attempts'] += 1
                    action, info = original_query(item, generate, torch_module=torch, model=model, tokenizer=tokenizer)
                    costs['query_returns'] += 1
                    assert len(request_calls) == (2 if info.get('reprompted') else 1)
                    record = {'replica': replica, 'arm': arm, 'root': item['root'], 'agent': item['agent'],
                              'original_action': action, 'original_info': info,
                              'actual_generation_calls': len(request_calls),
                              'all_generation_token_ids': [x['output_token_ids'] for x in request_calls],
                              'no_physical_verification_or_commit': True}
                    atomic_json(OUT / f'{replica}_{arm}_{item["root"]}_Query_Result.json', record)
                    results.append(record)
        after = preservation_inventory(model)
        assert before == after
        atomic_json(OUT / f'{replica}_Immutable_Values_After.json', after)
        atomic_json(OUT / f'{replica}_Memory_And_Source_Proof.json', {
            'peak_allocated_bytes': torch.cuda.max_memory_allocated(),
            'peak_reserved_bytes': torch.cuda.max_memory_reserved(),
            'actual_private_LoRA_copy_after': verify_copy_state(model, source_adapter_state(adapter)[1]),
            'all_base_private_quantized_values_and_buffers_unchanged': True, 'optimizer_and_trainable_parameters': 0})
        core.forward = original_forward; model.generate = original_generate
        del model, core, original_forward, original_generate
        gc.collect(); torch.cuda.empty_cache()
        return results

    primary = run_replica('primary')
    cold = run_replica('cold')
    assert len(primary) == len(cold) == 4
    for a, b in zip(primary, cold):
        assert (a['arm'], a['root']) == (b['arm'], b['root'])
        assert a['all_generation_token_ids'] == b['all_generation_token_ids']
        assert a['original_action'] == b['original_action'] and a['original_info'] == b['original_info']
    assert costs['query_attempts'] == costs['query_returns'] == 8
    assert 8 <= costs['generation_attempts'] == costs['generation_returns'] <= 16
    result = {'status': 'COMPLETE_ORIGINAL_FEDERATION_FIRST_ZONE_TWO_ROOT_LORA_BASE_AND_COLD',
        'actual_costs': costs, 'cold_all_query_paths_and_tokens_exact': True, 'model_loads': 2,
        'base_revision': p['base_for_new_experiment']['revision'], 'private_weights_unchanged': True,
        'original_native_query_parser_and_conditional_reprompt_AST_unchanged': True,
        'fixed_gate_to_be_assessed_independently': 'Both original-LoRA final queries valid plus full cold/source/cost preservation; no automatic physical rollout.',
        'no_new_PF_optimizer_training_or_physical_performance': True,
        'workflow_seconds': time.monotonic() - started, 'journal_last_before_result': previous}
    atomic_json(OUT / 'Results.json', result)
    event('closed_results', result_sha256=file_hash(OUT / 'Results.json'))
    progress('complete_preserving_final')
    publisher.publish('complete_results_and_immutable_source_proofs')
except BaseException as exc:
    atomic_json(OUT / 'Failure.json', {'failure_type': type(exc).__name__, 'failure': str(exc),
        'traceback': traceback.format_exc(), 'actual_costs': costs, 'workflow_seconds': time.monotonic() - started})
    progress('failed_partial_preserved')
    raise
