"""Independent partial reader, no model/PF/download or scientific retry."""
import hashlib,json,os,time
from pathlib import Path
import numpy as np
from durable_opaque_evidence_store_v1 import process_alive
ROOT=Path(__file__).resolve().parents[1];B=ROOT/'outputs/hybrid_scale_screen_20261012';X=B/'execution';S=X/'staged/study';O=B/'partial_audit';O.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
status=read(X/'status.json');claim=read(X/'owner.claim');launcher=read(B/'Launcher.json')
assert all(not process_alive(p) for p in [claim['pid'],launcher['launcher_pid']])
assert status['scientific_process_ended'] and status['runtime_released'] and status['all_actual_closed_artifacts_preserved']
(O/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'source_sha256':sha(Path(__file__))}))
manifest=read(S/'Closed_Manifest.json')
for n,m in manifest.items():assert (S/n).stat().st_size==m['bytes'] and sha(S/n)==m['sha256']
e=[json.loads(l) for l in (S/'events.jsonl').read_text().splitlines()];f=[r for r in e if r['kind']=='forward_attempt'];ret=[r for r in e if r['kind']=='forward_return']
assert len(f)==len(ret)==57 and [r['sequence'] for r in f]==list(range(1,58))==[r['sequence'] for r in ret]
for r in ret:
 p=S/r['logits_file'];assert sha(p)==r['logits_sha256']
 with np.load(p,allow_pickle=False) as z:
  a=z['logits'];assert a.shape==(r['vocab_size'],) and np.isfinite(a).all() and int(np.argmax(a))==r['greedy_argmax_token_id']
g=[r for r in f if r['phase']=='proposal'];gr=[r for r in ret if r['phase']=='proposal'];dif=[]
for i in range(len(g)-1):
 if g[i+1]['input_ids'][-1]!=gr[i]['greedy_argmax_token_id']:dif.append(i)
assert dif==[4,11] and len(g)==56
fit=read(S/'private_0p5B/Fit_Status.json');assert fit['longest_prefix_tokens']==1625 and fit['all_parameters_frozen']
report={'state':'PASS_INDEPENDENT_PRESERVED_PARTIAL_AUDIT_NOT_COMPLETE_MODEL_COMPARISON','recorded_forward_attempts_and_returns':57,'real_longest_private_prefill_returns':1,'private_first_generation_forward_returns':56,'actual_subsequent_step_input_evidence_positions':55,'raw_argmax_vs_actual_next_input_mismatch_positions':dif,'cause_of_strict_rawargmax_assumption':'Pinned base generation config has repetition_penalty1.1; raw unprocessed logits are not processed greedy scores. Source assertion preserves false rawargmax assumption. Exact lost final sequence/caller output and final model tensor preservation UNKNOWN.','actual_fit':fit,'old_partial_science_workflow_seconds':read(S/'Final_Status.json')['science_workflow_seconds'],'all_closed_member_hashes_finite_logits_identity_passed':True,'old_account_assignment_exactly_released':True,'all_original_owners_ended':True,'new_model_PF_optimizer_download_calls':0,'never_repeat_private_attempt':'This original private arm is terminal partial. All remaining public model arms were genuinely unexecuted; require additive prospective identities/source/cost/ownership protocol before any measurement.'}
(O/'Independent_Preserved_Prefix_Audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'state':report['state'],'forwards':57,'no_new_model_or_PF':True}))
