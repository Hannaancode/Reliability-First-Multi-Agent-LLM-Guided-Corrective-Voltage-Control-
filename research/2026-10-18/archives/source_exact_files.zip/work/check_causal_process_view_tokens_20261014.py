"""16 new exact current/process prefixes; no neural or physical calls.

Use the actual frozen Rust tokenizer backend. Render only the source-inspected
plain two-string system/user branch of its saved Jinja template. Full deployed
HF rendering equivalence remains an explicit before-first-forward gate.
"""
import array, copy, hashlib, importlib.metadata, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path
from tokenizers import Tokenizer
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import load_endpoint
from paid_joint_commit_v2 import initialize
from shared_original_serving_action_domain_v1 import build_current_domain
from causal_owned_support_process_view_v1 import build_process_view

R = Path(__file__).resolve().parents[1]
B = R/'outputs/causal_owned_process_view_20261014'
MODEL = R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
canon = lambda v: json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)

def put(path,value):
    with path.open('x',encoding='utf8') as file:
        json.dump(value,file,indent=2,allow_nan=False); file.flush(); os.fsync(file.fileno())

def render_supported_source_branch(messages):
    assert len(messages)==2 and [m['role'] for m in messages]==['system','user']
    assert all(set(m)=={'role','content'} and type(m['content']) is str for m in messages)
    return ''.join('<|im_start|>'+m['role']+'\n'+m['content']+'<|im_end|>\n' for m in messages)+'<|im_start|>assistant\n'

def main():
    B.mkdir(exist_ok=False); put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),
        'source_sha256':sha(Path(__file__)),'software_only_no_model_PF':True})
    source_template = (MODEL/'chat_template.jinja').read_text('utf8')
    assert "messages[0]['role'] == 'system'" in source_template
    assert "'<|im_start|>system\\n' + messages[0]['content'] + '<|im_end|>\\n'" in source_template
    assert "'<|im_start|>' + message.role + '\\n' + message.content + '<|im_end|>' + '\\n'" in source_template
    assert "'<|im_start|>assistant\\n'" in source_template
    protocol = {'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),
        'representation_source_sha256':sha(R/'work/causal_owned_support_process_view_v1.py'),
        'original_tokenizer_backend_sha256':sha(MODEL/'tokenizer.json'),'original_template_sha256':sha(MODEL/'chat_template.jinja'),
        'all4inspected_current_roots_4zones':True,'fixed_context_limit':4096,'generation_reserve':384,
        'no_crop_rounding_input_deletion_or_context_sweep':True,
        'renderer_scope':'Only source-inspected plain2string system/user/no-tools branch; not full AutoTokenizer runtime proof',
        'model_PF_optimizer_or_allocation':False}
    put(B/'Prospective_View_And_Token_Protocol.json',protocol)
    tokenizer = Tokenizer.from_file(str(MODEL/'tokenizer.json')); tokenizer.no_truncation(); tokenizer.no_padding()
    _,runner,_ = load_stack(); meta = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = meta.get('zones',meta)
    old = read(R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012/preparation/Protocol.json')
    cases = []; checks = []
    for entry in old['current_endpoints']:
        net,original,_ = load_endpoint(entry); cursor = initialize(net,original)
        domain = build_current_domain(net,cursor,runner=runner,zones=zones)
        process = build_process_view(net,cursor,domain)
        corrupted = copy.deepcopy(cursor); corrupted.update(world='HIDDEN_WORLD_SENTINEL',
            unqueried_action_labels={'secret_best':999},future_terminal_reward='HIDDEN_FUTURE_SENTINEL')
        assert build_process_view(net,corrupted,domain)==process
        checks.append(entry['world']+'|hidden_admin_and_unqueried_labels_do_not_enter_process_view')
        assert process['remaining_original_device_operations'] == cursor['remaining_original_device_operation_slots']
        assert all(b['nominal_capacitive_support_remaining_MVAr_nonnegative']>=0 for b in process['owned_support_banks'])
        global_uv = runner.rescue.global_uv_buses(net)
        for zone in sorted(zones):
            current = domain['zone_current_views'][zone]
            allowed = domain['original_LOCAL_allowed_per_zone'][zone]
            original_messages = runner.build_mandatory_llm_prompt(current,global_uv,allowed,[])
            messages = copy.deepcopy(original_messages)
            messages[1]['content'] += '\n\nNEW_EXPERIMENTAL_CURRENT_PROCESS_ONLY:\n'+canon(process)
            text = render_supported_source_branch(messages)
            assert 'HIDDEN_WORLD_SENTINEL' not in text and 'HIDDEN_FUTURE_SENTINEL' not in text
            ids = tokenizer.encode(text,add_special_tokens=False).ids
            cases.append({'administrator_world_not_forward':entry['world'],'zone':zone,
                'messages':messages,'original_messages_reference':original_messages,'current_process_view':process,
                'rendered_utf8_sha256':hashlib.sha256(text.encode()).hexdigest(),'exact_token_ids':ids,
                'token_ID_sha256':hashlib.sha256(array.array('I',ids).tobytes()).hexdigest(),
                'prefix_tokens':len(ids),'prefix_plus384_fits4096':len(ids)+384<=4096,
                'sufficient_long_horizon_observation_or_model_benefit':'UNPROVED'})
            checks.append(entry['world']+'|'+zone+'|current_only_original_units_and_exact_new_backend_encoding')
    assert len(cases)==16
    fits = all(c['prefix_plus384_fits4096'] for c in cases)
    result = {'status':'PASS_CAUSAL_PROCESS_AND_FIXED_CONTEXT_INPUT_SOFTWARE' if fits else 'FAIL_FIXED4096_INPUT_NO_CROPPING_OR_RETUNE',
        'cases':len(cases),'checks':checks,'max_prefix_tokens':max(c['prefix_tokens'] for c in cases),
        'generation_reserve_tokens':384,'actual_tokenizer_calls':16,'actual_new_model_PF_optimizer_calls':0,
        'tokenizers_version':importlib.metadata.version('tokenizers'),'source_inspected_plain_template_branch':True,
        'actual_deployed_HF_template_tokens_logits_memory_generation_and_policy':'NOT_EXECUTED_UNKNOWN',
        'current_case_goal_band_Qgrid_stock_caps_and_ops_preserved':True,
        'new_experimental_context_NOT_original_historical_serving_reproduction':True,
        'automatic_model_or_GPU_launch':False,'no_winning_confidence_or_novelty':True}
    put(B/'All16_Current_Process_Prefixes.json',{'cases':cases}); put(B/'Verified_Process_View_And_Token_Checkpoint.json',result)
    event = {'event_id':'causal_owned_support_process_view_and_actual_token_backend_20261014',
        'method':'Whitelist actual current owned-bank/operation/lifetime-cap/generator-limit state and append to original serving references; inspect actual saved plain chat-template branch andencode16newprefixes usingoriginal frozen tokenizerbackend.',
        'result':result['status']+'; maxprefix='+str(result['max_prefix_tokens'])+';16newtokenizer calls; hiddenworld/unqueried/future-label controls passed; zero model/PF/optimizer calls.',
        'improvements':'Future joint policy can explicitly receive the actual owned support, non-refunded caps and remaining operations. Exact16newcontext encodings retained without crop/rounding/drop/context sweep.',
        'limitations':'New experimental context, not oldSFT/serving reproduction. Full deployedHF rendering equivalence/logits/memory/coldgeneration remainUNKNOWN. Causality and inputfit do not prove sufficient longhorizon state, learningbenefit or physicalsuperiority.',
        'decision':'Keep liveCPUstudy/source/settings andscheduledcheck unchanged. Before futuremodel allocation require actual loader/source/token equality and supported fixeddecision/economic/control protocol; no automatic launch from tokenizer pass.',
        'sources':[str((B/'Verified_Process_View_And_Token_Checkpoint.json').relative_to(R)),str((B/'Prospective_View_And_Token_Protocol.json').relative_to(R)),
                   'work/causal_owned_support_process_view_v1.py','work/check_causal_process_view_tokens_20261014.py']}
    put(B/'Research_Progress_Entry.json',event)
    logged = subprocess.run([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(R/'work/append_research_progress.py'),
        '--entry-json',str(B/'Research_Progress_Entry.json')],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert logged.returncode==0,logged.stderr
    path = R/'outputs/critical_research_reset_20261010/Research_Resume_20261012.json'; resume = read(path)
    resume['latest_causal_owned_process_view_and_token_input'] = str((B/'Verified_Process_View_And_Token_Checkpoint.json').relative_to(R))
    with path.open('w',encoding='utf8') as file:json.dump(resume,file,indent=2);file.flush();os.fsync(file.fileno())
    print(json.dumps({k:result[k] for k in ['status','max_prefix_tokens','actual_tokenizer_calls','actual_new_model_PF_optimizer_calls']}))

if __name__=='__main__':main()
