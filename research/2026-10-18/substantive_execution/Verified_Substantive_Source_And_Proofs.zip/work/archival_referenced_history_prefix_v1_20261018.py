"""Read-only historical checkpoint prefixes; never a live restore/rollback API."""
import ast,hashlib,json
from pathlib import Path
import bounded_chunk_evidence_store_v1_20261015 as live
from paid_receding_journal_reference_history_v2_20261018 import (
    canon,expand_reference_record,MAX_QUERY_REFERENCES,MAX_REFERENCE_BYTES,
    MAX_DECISION_METADATA_BYTES,MAX_REFERENCED_RECORD_BYTES)
source=Path(live.__file__).read_text('utf-8')
before="if index.stat().st_size!=anchor['index_bytes']:raise ValueError('Missing/torn/stale journal; no cursor rollback')"
after="if index.stat().st_size<anchor['index_bytes']:raise ValueError('Missing/torn archived prefix')"
assert source.count(before)==1
changed=source.replace(before,after);assert changed.replace(after,before)==source
node=next(n for n in ast.parse(changed).body if isinstance(n,ast.FunctionDef) and n.name=='restore')
node.name='read_archival_chunk_prefix';env=live.__dict__.copy()
exec(compile(ast.Module(body=[node],type_ignores=[]),str(Path(__file__)),'exec'),env)
_read_prefix=env[node.name]
SOURCE_CERTIFICATE={'live_restore_source_sha256':hashlib.sha256(Path(live.__file__).read_bytes()).hexdigest(),
    'live_antirollback_restore_unchanged':True,'exact_single_archival_predicate_substitution':{'before':before,'after':after},
    'chunk_source_input_size_count_hash_chain_wholepayload_prefix_assertions_unchanged':True,
    'execution_authorized':False}
def read_archival_reference_prefix(anchor,*,scientific_journal,scientific_prefix_bytes,scientific_protocol):
    if type(anchor['index_bytes']) is not int or anchor['index_bytes']<=0:raise ValueError('Bounded nonempty archived prefix required')
    if type(scientific_prefix_bytes) is not int or scientific_prefix_bytes<0:raise ValueError('Exact paid scientific prefix required')
    blocks=_read_prefix(anchor);previous='0'*64;records=[];queries=0
    for i,block in enumerate(blocks):
        record=json.loads(block['payload'])
        assert record['previous']==previous and record['source_anchor']==anchor['source_anchor'] and record['input_anchor']==anchor['input_anchor']
        assert block['event_id']==f'{i:08d}:'+record['event']
        previous=hashlib.sha256(block['payload']).hexdigest()
        if record['event']=='complete_paid_receding_decision':
            payload=record['payload'];refs=payload['query_references']
            if payload['scientific_protocol_sha256']!=scientific_protocol:raise ValueError('Foreign scientific protocol')
            if len(refs)>MAX_QUERY_REFERENCES or len(canon(payload))>MAX_REFERENCED_RECORD_BYTES or len(canon(payload['report_without_query_messages']))>MAX_DECISION_METADATA_BYTES:raise ValueError('Unsupported reference encoding envelope')
            for ref in refs:
                if len(canon(ref))>MAX_REFERENCE_BYTES or Path(ref['journal'])!=Path(scientific_journal):raise ValueError('Foreign journal or oversized reference')
                if type(ref['offset']) is not int or ref['offset']<0 or ref['offset']+ref['bytes']>scientific_prefix_bytes:raise ValueError('Future query outside archived scientific prefix')
            expanded=expand_reference_record(payload);queries+=len(expanded['query_messages'])
        records.append(record)
    assert previous==anchor['logical_last_record_sha256']
    return {'records':records,'exact_referenced_queries':queries,'execution_authorized':False,'mode':'ARCHIVAL_READ_ONLY_NOT_CONTROLLER_RESTORE','new_scientific_calls':0}
