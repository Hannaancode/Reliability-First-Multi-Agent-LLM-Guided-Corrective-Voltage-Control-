"""New necessary-support question on saved OPT edges, zero scientific execution."""
import argparse, hashlib, json, math, os, sys, time, traceback
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/later_fork_process_support_20261011'
A=ROOT/'outputs/critical_research_reset_20261010/actual_query_and_continuation_receipt_inventory_v3'
D=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3'
T=ROOT/'outputs/llm_value_relational_adaptation_research_20261009/measured_OPT_transition_inventory'
C=ROOT/'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2'
INPUTS={'edges':A/'All216_Actual_Action_Linked_Successor_Records.json','prior_summary':A/'summary.json',
 'prior_reader':ROOT/'outputs/critical_research_reset_20261010/actual_query_receipt_inventory_independent_reader/Independent_Actual_Receipt_Check.json',
 'partition':C/'protocol.json','raw_protocol':D/'protocol.json','transition_protocol':T/'Protocol.json'}
SOURCES={'literal':ROOT/'work/e/audit/run_reflection_v4_safety_envelope.py','ALT':ROOT/'work/dff_alt.py',
 'observer':ROOT/'work/train_trajectory_measurement_nullable_v2.py','base_observer':ROOT/'work/value_observe_original_DFF.py'}
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(p.read_text('utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
def pair(a):
 assert isinstance(a,dict) and set(a)=={'add_shunts_q_mvar'} and len(a['add_shunts_q_mvar'])==1
 b,q=next(iter(a['add_shunts_q_mvar'].items()));b=int(b)
 assert not isinstance(q,bool) and isinstance(q,(int,float)) and math.isfinite(q)
 return [b,float(q)]
def prepare():
 p=OUT/'preparation';p.mkdir(parents=True,exist_ok=False)
 partition=read(INPUTS['partition']);raw=read(INPUTS['raw_protocol']);tp=read(INPUTS['transition_protocol'])
 opt=set(partition['optimization_world_sha256']);held=set(partition['development_held_world_sha256'])
 assert len(opt)==23 and len(held)==8 and not opt&held
 paths=[];latched={k.replace('\\','/'):v for k,v in tp['source_branch_hashes'].items()}
 for world in raw['worlds']:
  if world['sha256'] in opt:
   for arm in ['DFF','DFF-ALT']:
    path=D/('branches/'+world['scenario_id']+'__'+arm+'.json');rel=path.relative_to(ROOT).as_posix()
    assert rel in latched
    paths.append({'world_sha256':world['sha256'],'branch':arm,'path':rel,'sha256':latched[rel]})
 assert len(paths)==46
 protocol={'at_utc':now(),'source_sha256':sha(Path(__file__)),'input_sha256':{k:sha(v) for k,v in INPUTS.items()},
  'source_sha256_by_role':{k:sha(v) for k,v in SOURCES.items()},'latched_OPT_branches':paths,
  'optimization_world_sha256':sorted(opt),'declared_held_world_sha256_NOT_READ':sorted(held),
  'question':'Do existing216guardedOPTcommitted edges contain a noninitial physical-observation fork, even after relaxing all controller process/cap/history distinctions?',
  'new_question_not_old_inventory_recomputation':'Classify physical multiaction nodes by actual raw before/after decision occurrence; prior216edges/23aggregateforks reused. No receipt inventory, scores, terminal metrics or forecasts recomputed.',
  'relaxation':'Physical before_observation_id alone groups allworlds/branches/decisions. Full identical process state must refine this grouping. A multiaction node with any actual before decision>0 is an optimistic later candidate, including root/later collisions. It is NOT a certified full-process fork.',
  'indexing':'Initial solved observation decision0; each successful commitment advances decision by1; before k -> next selection iteration k+1. Use actual observed indices, never infer failure/terminal state from action counts.',
  'fixed_gate':'If all listed edges join complete observed consecutive prefixes and optimistic later_multiaction_nodes==0: NO_RETAINED_LATER_FORK_SUPPORT_STOP_EXISTING_DATA_TRAINING. Any optimistic later candidate: UNKNOWN_NEEDS_FULL_PROCESS_AND_PROTECTED_CONTINUATIONS. Missing/partial identity: UNKNOWN_NO_IMPUTATION. Root alternatives cannot pass.',
  'scope':'These guarded23OPT historical worlds only. All31originalworld identities/held8denominators retained. Does not cover unmeasured alternatives or all historical datasets; no negative physical/learning result.',
  'unknown_receipts_and_unmeasured_continuations_retained':'30312queryreceipts withoutfullsuccessors remain UNKNOWN; absenceoftrainingedges isnotabsenceofphysicalopportunity.',
  'bound_seconds':120,'new_model_PF_optimizer_controller_forecast_solve_fit_tokenizer_cloud_calls':0,
  'no_full_process_or_restorable_solver_claim':True,'no_automatic_allocation_learning_or_physics':True}
 write(p/'Protocol.json',protocol);print(str(p))
def run():
 protocol=read(OUT/'preparation/Protocol.json');assert sha(Path(__file__))==protocol['source_sha256']
 lock=read(OUT/'preparation/Reader_Source_Lock.json');reader=ROOT/'work/audit_relaxed_later_fork_support_20261011.py';ready=ROOT/'work/relaxed_later_fork_reader_readiness_20261011.json'
 assert sha(reader)==lock['reader_source_sha256'] and sha(ready)==lock['reader_readiness_sha256']
 assert read(ready)['production_source_sha256']==protocol['source_sha256']
 assert read(ready)['protocol_sha256']==sha(OUT/'preparation/Protocol.json')
 for k,v in INPUTS.items():assert sha(v)==protocol['input_sha256'][k]
 for k,v in SOURCES.items():assert sha(v)==protocol['source_sha256_by_role'][k]
 out=OUT/'execution';out.mkdir(exist_ok=False);started=time.perf_counter()
 write(out/'owner.claim',{'actual_pid':os.getpid(),'at_utc':now(),'command':sys.argv,'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(OUT/'preparation/Protocol.json')})
 cost={'raw_OPT_branch_read_returns':0,'new_edge_occurrence_classifications':0,'new_model_PF_optimizer_controller_forecast_solve_fit_tokenizer_cloud_calls':0,'old_archive_rehashes':0}
 try:
  assert read(INPUTS['prior_reader'])['all_passed'] is True
  previous=read(INPUTS['prior_summary']);assert previous['unique_actual_committed_successor_edges']==216 and previous['before_states_with_multiple_actual_committed_actions']==23
  edges=read(INPUTS['edges']);assert len(edges)==216
  indexed={};occurrences=[];worlds=set()
  for e in edges:
   key=(e['world_sha256'],e['branch'],e['before_observation_id'],tuple(e['action']),e['after_observation_id'])
   assert key not in indexed;indexed[key]=e
  for entry in protocol['latched_OPT_branches']:
   assert time.perf_counter()-started<protocol['bound_seconds']
   path=ROOT/entry['path'];assert sha(path)==entry['sha256'];r=read(path);cost['raw_OPT_branch_read_returns']+=1
   assert r['scenario_sha256']==entry['world_sha256'] and r['branch']==entry['branch']
   worlds.add(r['scenario_sha256']);observations=r['observations']
   assert observations and observations[0]['decision']==0 and observations[0]['committed_action'] is None
   assert r['independent_all_field_replay_passed_1e10'] is True and r['base_network_preserved'] is True
   for before,after in zip(observations,observations[1:]):
    k=before['decision'];d=after['decision'];assert type(k) is int and type(d) is int and d==k+1 and 0<=k<25
    action=pair(after['committed_action']);key=(r['scenario_sha256'],r['branch'],before['observation_sha256'],tuple(action),after['observation_sha256'])
    assert key in indexed
    occurrences.append({'world_sha256':key[0],'branch':key[1],'before_observation_id':key[2],'action':action,'after_observation_id':key[4],'transition_id':indexed[key]['transition_id'],
     'actual_before_decision':k,'actual_after_decision':d,'original_selection_iteration':k+1,'recorded_remaining_iteration_slots':25-k,
     'classification':'INITIAL_ROOT_COMMITMENT' if k==0 else 'LATER_RECORDED_COMMITMENT','full_process_identity':'UNRESOLVED_NOT_NEEDED_FOR_RELAXED_ABSENCE_PROOF'})
  assert worlds==set(protocol['optimization_world_sha256']) and len(occurrences)==216
  assert len({(x['world_sha256'],x['branch'],x['before_observation_id'],tuple(x['action']),x['after_observation_id']) for x in occurrences})==216
  nodes=defaultdict(list)
  for e in occurrences:nodes[e['before_observation_id']].append(e)
  forks=[]
  for oid,rows in sorted(nodes.items()):
   actions={tuple(x['action']) for x in rows}
   if len(actions)>1:forks.append({'before_observation_id':oid,'distinct_actions':[list(x) for x in sorted(actions)],'occurrences':rows,'contains_later_occurrence':any(x['actual_before_decision']>0 for x in rows)})
  assert len(forks)==previous['before_states_with_multiple_actual_committed_actions']
  later=sum(f['contains_later_occurrence'] for f in forks)
  result={'at_utc':now(),'all216edges_joined':True,'all46OPTbranches_retained':True,'all31world_identities_retained_held8unread':True,
   'physical_multiaction_nodes':len(forks),'initial_only_multiaction_nodes':len(forks)-later,'optimistic_later_multiaction_nodes':later,
   'initial_commitment_occurrences':sum(x['actual_before_decision']==0 for x in occurrences),'later_commitment_occurrences':sum(x['actual_before_decision']>0 for x in occurrences),
   'fixed_gate':'NO_RETAINED_LATER_FORK_SUPPORT_STOP_EXISTING_DATA_TRAINING' if later==0 else 'UNKNOWN_NEEDS_FULL_PROCESS_AND_PROTECTED_CONTINUATIONS',
   'absence_proof_scope':'Any exact complete-process later fork withinthese216edges would also appear in the relaxed physical grouping. No conclusionaboutunmeasuredalternatives or otherdatasets.',
   'full_process_protected_terminal_rewards_physical_or_LLM_benefit':'UNMEASURED','unmeasured_query_receipt_successors_UNKNOWN':previous['recorded_query_receipts_without_measured_successor'],
   'no_automatic_learning_or_physics':True}
  cost['new_edge_occurrence_classifications']=len(occurrences)
  write(out/'All_Actual_Edge_Decision_Occurrences.json',occurrences);write(out/'All_Optimistic_Physical_Forks.json',forks);write(out/'Results.json',result)
 except BaseException as ex:
  write(out/'Failure.json',{'error':repr(ex),'traceback':traceback.format_exc(),'no_retry':True});raise
 finally:
  cost['workflow_seconds_before_manifest']=time.perf_counter()-started;write(out/'Actual_Costs.json',cost)
  complete=(out/'Results.json').exists() and not (out/'Failure.json').exists()
  write(out/'Closed_Manifest.json',{'at_utc':now(),'members':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()},'complete':complete,'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(OUT/'preparation/Protocol.json')})
  write(out/'status.json',{'state':'ENDED_COMPLETE' if complete else 'ENDED_PARTIAL','actual_pid':os.getpid(),'manifest_closed':True,'at_utc':now()})
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--execute-authorized',action='store_true');a=ap.parse_args();assert a.prepare!=a.execute_authorized
 prepare() if a.prepare else run()
