"""One joint reader: old certified response plus new exact untouched identities."""
import collections,json,os,sys,time,zipfile
from pathlib import Path
import candidate_process_runtime
import numpy as np
from transformers import AutoTokenizer
from public_size_local_preservation_v2 import extended
from public_size_screen_reader_contract_v2_20261010 import validate_fixed_case,parse_response,compare_known_pair
from audit_public_size_screen_20261010 import rows,measure
from candidate_process_evidence_utils import read as raw_read,sha as raw_sha,write,seal,frozen_checks
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'outputs/critical_research_reset_20261010'
PREP=R/'public_size_u61_v2_preparation';EX=R/'public_size_u61_v2_execution';OUT=R/'public_size_u61_v2_external_audit'
def read(p):return raw_read(extended(p))
def sha(p):return raw_sha(extended(p))
def main():
    assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
    write(OUT/'audit.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__))})
    protocol=read(PREP/'protocol.json');ready=read(PREP/'Launch_Readiness_Audit.json')
    for p,h in ready['source_hashes'].items():assert sha(ROOT/p)==h
    for p,h in protocol['local_analysis_source_hashes'].items():assert sha(ROOT/p)==h
    prior=read(R/'public_size_partial_external_audit_v2/Independent_Actual_Output_Audit.json')
    assert prior['actual_attempts']==prior['actual_returns']==385 and prior['all_closed_member_hashes_and_saved_greedy_logits_verified']
    cases=read(PREP/'cases.json');assert len(cases)==31
    for c in cases:validate_fixed_case(c)
    target_path=ROOT/protocol['targets']['path'];assert sha(target_path)==protocol['targets']['sha256']
    targets={r['observation_id']:r for r in rows(target_path)}
    assert sha(PREP/'Local_Numerical_Control_References.json')==protocol['local_control_references_sha256']
    controls=read(PREP/'Local_Numerical_Control_References.json')
    old_record=read(ROOT/protocol['prior_response']['path']);assert sha(ROOT/protocol['prior_response']['path'])==protocol['prior_response']['sha256']
    old_id=old_record['observation_id'];results={};by_case={};all_costs={};all_complete=True
    for declaration in protocol['models']:
        arm=declaration['arm'];owner=extended(EX/arm);status=read(owner/'status.json')
        assert status['finished_at_utc'] and (not status['runtime_allocated'] or status['runtime_released'])
        tokenizer=AutoTokenizer.from_pretrained(str(PREP/'tokenizers'/arm),local_files_only=True,trust_remote_code=False)
        events=[];attempts={};returns={};gen_attempts=[];gen_returns=[];gates_known=False;final=None;study=owner/'staged/study'
        if status['science_started']:
            assert status['all_actual_closed_artifacts_preserved']
            desc=read(owner/'remote_closed_descriptor.json');assert desc['scientific_process_ended']
            with zipfile.ZipFile(owner/'preserved_remote_science.zip') as z:
                assert z.testzip() is None and set(z.namelist())==set(desc['members'])
                for name,m in desc['members'].items():
                    import hashlib
                    data=z.read(name);assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
                    assert sha(study/name)==m['sha256']
            identity=read(study/'scientific_identity.json');assert identity['protocol_sha256']==sha(PREP/'protocol.json') and identity['cases_sha256']==sha(PREP/'cases.json')
            assert identity['source_hashes']==protocol['remote_source_hashes']
            env=read(owner/'staged/public_size_environment.json');assert env==identity['environment']
            assert env['versions']==protocol['framework_versions'] and env['device']=='Tesla T4' and len(env['models'])==1
            actual=env['models'][0]
            for key in ['arm','repo','revision','files']:assert actual[key]==declaration[key]
            assert actual['actual_header_parameters']==declaration['public_safetensors_parameters']
            vocab=read(PREP/'tokenizers'/arm/'config.json')['vocab_size']
            events=[json.loads(x) for x in (study/'events.jsonl').read_text().splitlines()]
            for e in events:
                if e['kind']=='forward_attempt':
                    k=(e['arm'],e['sequence']);assert k not in attempts and e['arm'] in [arm,arm+'_cold'];attempts[k]=e
                    assert len(e['input_ids'])==e['input_tokens']>0 and all(type(i) is int and 0<=i<vocab for i in e['input_ids'])
                elif e['kind']=='forward_return':
                    k=(e['arm'],e['sequence']);assert k in attempts and k not in returns
                    assert all(e[n]==attempts[k][n] for n in ['arm','sequence','phase','observation_id','input_tokens'])
                    assert sha(study/e['logits_file'])==e['logits_sha256']
                    with np.load(study/e['logits_file'],allow_pickle=False) as z:
                        assert set(z.files)=={'logits'};a=z['logits']
                        assert a.ndim==1 and len(a)==e['vocab_size']==vocab and np.isfinite(a).all()
                        assert str(a.dtype)==e['last_logits_dtype'] and int(np.argmax(a))==e['greedy_argmax_token_id']
                    returns[k]=e
                elif e['kind']=='generation_attempt':gen_attempts.append(e['observation_id']);assert e['arm']==arm
                elif e['kind']=='generation_return':
                    gen_returns.append(e['observation_id']);assert e['arm']==arm and sha(study/e['response_file'])==e['response_sha256']
            assert len(gen_attempts)==len(set(gen_attempts)) and len(gen_returns)==len(set(gen_returns)) and set(gen_returns)<=set(gen_attempts)
            assert set(gen_attempts)<=set(protocol['remaining_observation_ids_by_arm'][arm])
            final=read(study/'Final_Status.json') if (study/'Final_Status.json').is_file() else None
            initial_gate=study/arm/'Initial_Model_Gates.json';final_gate=study/arm/'Final_Model_Gates.json'
            if final_gate.is_file():
                initial=read(initial_gate);last=read(final_gate)
                assert initial['all_parameters_frozen'] and initial['actual_4bit_cuda_model']
                assert initial['before_state']==last['after_state']==last['cold_loaded_state']
                cold=[e for e in returns.values() if e['arm']==arm+'_cold' and e['phase']=='engineering_cold_prefill']
                assert len(cold)==1 and cold[0]['observation_id']==protocol['engineering_context_observation_id']
                if arm=='public_0_5B':
                    assert initial['old_full_context_prefill_reused'] and initial['before_state']==read(PREP/'old_public_0_5B_initial_gates.json')['before_state']
                    reference=PREP/'old_public_0_5B_initial_logits.npz'
                else:
                    init=[e for e in returns.values() if e['arm']==arm and e['phase']=='engineering_initial_prefill']
                    assert len(init)==1 and init[0]['observation_id']==cold[0]['observation_id'];reference=study/init[0]['logits_file']
                with np.load(reference,allow_pickle=False) as a,np.load(study/cold[0]['logits_file'],allow_pickle=False) as b:assert np.array_equal(a['logits'],b['logits'])
                gates_known=True
        arm_rows=[];claimed=set()
        for c in cases:
            id=c['observation_id'];path=study/arm/'responses'/f'{id}.json';origin='new_unattempted_study'
            if arm=='public_0_5B' and id==old_id:record=old_record;origin='prior_independently_verified_partial_response'
            elif path.is_file():record=read(path);assert id in gen_returns
            else:
                row={'observation_id':id,'world_sha256':c['world_sha256'],'response_status':'attempt_without_closed_response' if id in gen_attempts else 'unexecuted','outcome':{'outcome_status':'missing_model_response','physical_outcome_known':False}}
                by_case[(arm,id)]=row;arm_rows.append(row);continue
            for n in ['observation_id','world_sha256','current_input_sha256','message_sha256']:assert record[n]==c[n]
            ids=tokenizer.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False)
            assert ids==record['prompt_ids'];generated=record['generated_ids'];assert 0<len(generated)<=protocol['max_new_tokens']
            assert tokenizer.decode(generated,skip_special_tokens=True)==record['raw_text'] and tokenizer.decode(generated,skip_special_tokens=False)==record['full_decoded_text']
            if origin=='new_unattempted_study':
                keys=[(arm,i) for i in record['forward_sequences']];assert len(keys)==len(set(keys)) and not claimed.intersection(keys);claimed.update(keys)
                rr=[returns[k] for k in keys];assert len(rr)==len(generated) and generated==[e['greedy_argmax_token_id'] for e in rr]
                assert all(e['phase']=='generation' and e['observation_id']==id for e in rr)
                assert attempts[keys[0]]['input_ids']==ids
                for j,k in enumerate(keys[1:],1):assert attempts[k]['input_ids']==[generated[j-1]] or attempts[k]['input_ids']==ids+generated[:j]
            parsed=parse_response(record['raw_text'],c['selected_same_information_input'])
            row={'observation_id':id,'world_sha256':c['world_sha256'],'split':c['split'],'origin':origin,'response_status':'returned','parsed':parsed,
                 'outcome':measure(c,parsed,targets.get(id)),'generated_tokens':len(generated),'generation_seconds':record['generation_seconds_includes_instrumentation']}
            by_case[(arm,id)]=row;arm_rows.append(row)
        complete=bool(final and final['complete'] and gates_known and set(gen_returns)==set(gen_attempts)==set(protocol['remaining_observation_ids_by_arm'][arm]))
        if complete:
            assert len(attempts)==len(returns) and claimed=={k for k,e in returns.items() if e['phase']=='generation'}
            assert final['optimizer_steps']==final['PF_calls']==0
            assert len([e for e in returns.values() if e['phase'].startswith('engineering_')])==(1 if arm=='public_0_5B' else 2)
        results[arm]={'all31_rows':arm_rows,'new_arm_complete':complete,'genuine_new_cold_gates_verified':gates_known,'outcome_counts':dict(collections.Counter(r['outcome']['outcome_status'] for r in arm_rows)),'denominator':32}
        all_complete &= complete
        all_costs[arm]={'actual_new_forward_attempts':len(attempts),'actual_new_forward_returns':len(returns),'new_generation_attempts':len(gen_attempts),'new_generation_returns':len(gen_returns),
         'returned_input_tokens':sum(e['input_tokens'] for e in returns.values()),'forward_wall_seconds':sum(e['model_wall_seconds'] for e in returns.values()),
         'science_workflow_seconds':final['science_workflow_seconds'] if final else None,'owner_status':status,'actual_transfers':read(owner/'Transfer_Costs.json'),
         'setup_cost':read(owner/'staged/public_size_setup_exit.json') if (owner/'staged/public_size_setup_exit.json').exists() else None,'unobserved_partial_costs_UNKNOWN':not complete}
    pairs=[];reference_rows=[]
    for c in cases:
        id=c['observation_id'];left=by_case[('public_1_5B',id)]['outcome'];right=by_case[('public_0_5B',id)]['outcome']
        pairs.append({'observation_id':id,'world_sha256':c['world_sha256'],'larger_vs_smaller':compare_known_pair(left,right)})
        for method,items in controls['methods'].items():
            ref=next(r for r in items if r['observation_id']==id);assert ref['world_sha256']==c['world_sha256']
            if ref['action_pair'] is None:outcome={'physical_outcome_known':False,'outcome_status':ref['status']}
            else:
                parsed=parse_response(json.dumps({'bus':ref['action_pair'][0],'Q_index':ref['action_pair'][1]}),c['selected_same_information_input']);assert parsed['kind']=='command'
                outcome=measure(c,parsed,targets.get(id))
            reference_rows.append({'method':method,'observation_id':id,'reference':ref,'outcome':outcome,'larger_vs_reference':compare_known_pair(left,outcome) if ref['ranking_complete'] else 'unknown_incomplete_reference_rank'})
    decision={'complete_original_response_inventory':all_complete,'old_after_tensor_gate_remains_UNKNOWN':True,'development_only':True,
      'paired_counts':dict(collections.Counter(p['larger_vs_smaller'] for p in pairs)),'no_missing_rejected_invalid_or_unexecuted_outcome_removed':True,
      'no_automatic_training_or_physical_campaign':True,'full_DSE_and_unused_confirmation_required':True,'goal_achieved':False}
    write(OUT/'All_Paired_And_Control_Results.json',{'models':results,'pairs':pairs,'numerical_controls':reference_rows,'invalid_and_world_denominators':read(PREP/'denominators.json')})
    write(OUT/'Actual_Costs.json',{'new_arms':all_costs,'old_partial_costs':read(R/'public_size_partial_external_audit_v2/Actual_Compute_And_Preservation.json'),
      'prior_numerical_physical_costs':controls['prior_paid_costs'],'all_prior_and_failed_costs_separate_not_free':True,'nested_costs_not_summed_twice':True})
    write(OUT/'Prospective_Diagnostic_Decision.json',decision)
    write(OUT/'Independent_Actual_Output_Audit.json',{'all_current_members_logits_and_identity_checks_passed':True,'old_first_response_certificate_reused_not_rerun':True,
      'complete_response_inventory':all_complete,'new_forward_attempts':sum(x['actual_new_forward_attempts'] for x in all_costs.values()),'new_forward_returns':sum(x['actual_new_forward_returns'] for x in all_costs.values()),
      'zero_new_model_PF_solver_calls_by_reader':True,'seconds_before_seal':time.perf_counter()-started})
    write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
    (OUT/'Results.md').write_text('Public model-size development diagnostic, all31worlds plusoriginalinvalid.\n\n'+json.dumps(decision,indent=2)+'\n\nThe original first0.5B response is reused, not generated again. Its old post-weight gate remainsUNKNOWN. Full-table numerical controls receive stronger information; publicmodels share fixed partialprompts. Architecture/pretraining/post-training/precision/FLOP differences remain. This is not protected full-trajectory D-SE superiority or independent confirmation.\n',encoding='utf-8')
    files={p.name:p for p in OUT.iterdir() if p.is_file()};files['source/joint_reader.py']=Path(__file__)
    print(json.dumps({'decision':decision,'archive':seal(OUT,files,'Public_Size_U61_Independent_Audit.zip')}))
if __name__=='__main__':main()
