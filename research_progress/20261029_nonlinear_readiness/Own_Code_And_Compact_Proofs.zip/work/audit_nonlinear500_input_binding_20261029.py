"""First independent saved-input review of the new500-context certificate.
No producer binder, kernel, equation, optimizer, PF or model invocation.
Uses the pinned data-only unpickler only as a serialization reader.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,time
import numpy as np
from remaining85_source_binder_v2_20261029 import DataUnpickler
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_input_binding_independent_20261029'
P=R/'outputs/nonlinear500_source_binding_20261029/v2_validated_full_admittance'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def main():
    O.mkdir(exist_ok=False);start=time.perf_counter();closed=load(P/'Closed_Manifest.json');hashes={x['path']:x['sha256'] for x in closed['files']}
    for n in ['Results.json','Source_Input_Freeze.json']:assert sha((P/n).read_bytes())==hashes[n]
    res=load(P/'Results.json');freeze=load(P/'Source_Input_Freeze.json')
    assert res['count']==500 and res['statuses']=={'BOUND_INPUT_ONLY':500} and res['bound_sources']==freeze['sources']
    for p,h in freeze['sources'].items():assert sha((R/p).read_bytes())==h,p
    manifest=load(R/'outputs/remaining85_mechanism_review_20261029/All500_Nonlinear_Preparation_Input_Manifest.json')
    graphref=manifest['saved_graph_source'];raw=(R/graphref['path']).read_bytes();assert sha(raw)==graphref['sha256']
    graph=np.load(io.BytesIO(raw),allow_pickle=False);rows=[]
    assert [x['seed'] for x in res['rows']]==list(range(500))
    for expected,row in zip(manifest['entries'],res['rows']):
        try:
            assert expected['seed']==row['seed'] and row['exact_root']==expected['exact_root']
            ref=row['exact_root'];raw=(R/ref['path']).read_bytes();assert sha(raw)==ref['sha256']
            obj=DataUnpickler(io.BytesIO(raw)).load();net=obj if ref['kind']=='NET' else obj['network']
            ppc=net['_ppc'];opt=net['_options'];sg=net['sgen'].iloc[:3]
            refpack=row['bound_pack'];rawpack=(R/refpack['path']).read_bytes();assert sha(rawpack)==refpack['sha256']
            assert hashes[(R/refpack['path']).relative_to(P).as_posix()]==refpack['sha256']
            with np.load(io.BytesIO(rawpack),allow_pickle=False) as pack:
                lookup=np.asarray(net['_pd2ppc_lookups']['bus'])[net['bus'].index.to_numpy()]
                control=np.asarray(net['_pd2ppc_lookups']['bus'])[sg.bus.to_numpy()]
                assert np.issubdtype(lookup.dtype,np.integer) and np.issubdtype(control.dtype,np.integer)
                expected_values=dict(Y=graph['Y'],V_current=ppc['bus'][:,7]*np.exp(1j*ppc['bus'][:,8]*np.pi/180.),
                  ppc_bus=ppc['bus'],ppc_gen=ppc['gen'],baseMVA=np.asarray(ppc['baseMVA']),lookup=lookup,control=control,
                  current_vm=net['res_bus'].vm_pu.to_numpy(),current_q=sg.q_mvar.to_numpy(),
                  control_scaling=sg.scaling.to_numpy(),control_in_service=sg.in_service.to_numpy(),
                  enforce_q_lims=np.asarray(opt['enforce_q_lims']),distributed_slack=np.asarray(opt['distributed_slack']))
                assert set(pack.files)==set(expected_values)
                for k,v in expected_values.items():
                    # Independent angle conversion may differ at the last bit;
                    # native magnitude and phase remain exact source arrays.
                    if k=='V_current':assert np.allclose(pack[k],v,rtol=0,atol=1e-15)
                    else:assert np.array_equal(pack[k],v),k
                assert pack['V_current'].dtype==np.complex128 and pack['Y'].dtype==np.complex128
                assert np.array_equal(pack['current_vm'],expected['initial_all13_vm'])
                assert np.array_equal(pack['current_q'],expected['initial_control_Q_Mvar'])
                assert np.array_equal(pack['control_scaling'],np.ones(3)) and np.all(pack['control_in_service'])
                assert np.array_equal(sg.bus.to_numpy(),[2,7,9]) and np.array_equal(sg.index.to_numpy(),[0,1,2])
                assert np.array_equal(np.flatnonzero(pack['ppc_bus'][:,1]==3),[0])
                assert len(np.flatnonzero(pack['ppc_bus'][:,1]==1))==12
            for k,v in dict(enforce_q_lims=False,enforce_p_lims=False,distributed_slack=False,voltage_depend_loads=False,tdpf=False,consider_line_temperature=False,ac=True,mode='pf',algorithm='bfsw').items():assert opt[k]==v,k
            assert np.array_equal(ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(ppc['branch'][:,21:26],graph['branch'][:,21:26])
            assert np.array_equal(ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and ppc['baseMVA']==graph['baseMVA']
            assert np.all(ppc['bus'][:,[13,14,16,17]]==0)
            rows.append(dict(seed=row['seed'],status='PASS_NATIVE_ROOT_TO_PACK_BINDING'))
        except BaseException as exc:rows.append(dict(seed=row['seed'],status='FAIL',type=type(exc).__name__,message=str(exc)))
    passed=all(x['status'].startswith('PASS') for x in rows) and len(rows)==500
    out=dict(status='PASS_ALL500_INDEPENDENT_NATIVE_ROOT_TO_PACK_BINDING' if passed else 'FAIL_BINDING',at_utc=datetime.now(timezone.utc).isoformat(),
      count=len(rows),rows=rows,workflow_seconds=time.perf_counter()-start,root_decodes=len(rows),pack_decodes=len(rows),
      new_equation_derivative_optimizer_PF_model_calls=0,producer_binding_not_rerun=True,
      source_sha256=sha(Path(__file__).read_bytes()),certificate_manifest_sha256=sha((P/'Closed_Manifest.json').read_bytes()))
    (O/'Independent_Audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in out.items() if k!='rows'}));assert passed
if __name__=='__main__':main()
