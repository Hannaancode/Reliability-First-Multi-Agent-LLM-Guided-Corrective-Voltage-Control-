"""Positive-only byte equality fast path for the existing frame check.

Unequal encodings, unfamiliar classes or object cells fall back to the old
exact DataFrame comparison. No hash collision assumption, physical relaxation,
aggregate shortcut, novel solver or control action is introduced.
"""
import pickle

def encode_supported(net):
    import numpy as np,pandas as pd
    selected={k:v for k,v in net.items() if isinstance(v,pd.DataFrame) and not str(k).startswith('res_')}
    for frame in selected.values():
        if type(frame) is not pd.DataFrame:return None
        for col in frame.select_dtypes(include=['object']).columns:
            for value in frame[col].array:
                if value is None or value is pd.NA or value is pd.NaT:continue
                if type(value) in (str,int,float,bool,complex,bytes):continue
                if isinstance(value,np.generic) and not value.dtype.hasobject:continue
                return None
    return pickle.dumps(([(k,selected[k]) for k in sorted(selected)],float(net.sn_mva),float(net.f_hz)),protocol=5)

def frames_equal(a,b):
    left=encode_supported(a);right=encode_supported(b)
    if left is not None and left==right:return 'EXACT_SUPPORTED_INPUT_BYTES_EQUAL'
    from reflection118_chronological_core_20261022 import frames_equal as original
    original(a,b)
    return 'ORIGINAL_EXACT_FRAME_CHECK_FALLBACK'
