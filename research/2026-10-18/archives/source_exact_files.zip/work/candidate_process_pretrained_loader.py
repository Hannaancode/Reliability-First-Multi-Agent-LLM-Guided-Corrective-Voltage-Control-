"""Actual isolated HF/PEFT loader; no automatic cloud API, data or training.

The caller supplies a pinned local snapshot and immutable private adapter path.
Original files are read-only inputs. Only the explicitly named in-memory COPY
can become trainable. The unquantized fixture path is not production evidence.
"""
import hashlib, json, time
from pathlib import Path
import torch
from peft import PeftModel, get_peft_model_state_dict
from safetensors.torch import load_file
from transformers import AutoModelForCausalLM

ADAPTER_NAME='candidate_process_copy'
EXPECTED_MODULES={'q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj'}
EXPECTED_BODY_PARAMETERS=8798208
def tensor_digest(tensor):
    value=tensor.detach().contiguous().cpu()
    raw=value.reshape(-1).view(torch.uint8).numpy().tobytes()
    return {'shape':list(value.shape),'dtype':str(value.dtype),'sha256':hashlib.sha256(raw).hexdigest()}
def source_adapter_state(adapter_dir):
    folder=Path(adapter_dir);cfg=json.loads((folder/'adapter_config.json').read_text())
    assert cfg['r']==16 and cfg['lora_alpha']==16 and cfg['lora_dropout']==0
    assert cfg['bias']=='none' and set(cfg['target_modules'])==EXPECTED_MODULES
    assert not cfg.get('use_dora') and not cfg.get('use_rslora')
    state=load_file(str(folder/'adapter_model.safetensors'),device='cpu')
    assert len(state)==336 and sum(t.numel() for t in state.values())==EXPECTED_BODY_PARAMETERS
    assert all(t.dtype==torch.float32 and bool(torch.isfinite(t).all()) for t in state.values())
    return cfg,state
def verify_copy_state(model,expected):
    actual=get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False)
    assert set(actual)==set(expected),'Unexpected copied adapter tensor identities'
    for name,value in actual.items():
        assert value.dtype==torch.float32 and torch.equal(value.detach().cpu(),expected[name]),name
    return {'exact_copied_tensors':len(actual),'exact_copied_parameters':sum(t.numel() for t in actual.values()),'source_tensor_values_identical':True}
def set_body_trainability(model,train_body):
    for name,p in model.named_parameters():
        selected=('.lora_A.'+ADAPTER_NAME+'.' in name or '.lora_B.'+ADAPTER_NAME+'.' in name)
        p.requires_grad_(bool(train_body and selected))
    actual={name:p for name,p in model.named_parameters() if p.requires_grad}
    assert len(actual)==(336 if train_body else 0)
    assert sum(p.numel() for p in actual.values())==(EXPECTED_BODY_PARAMETERS if train_body else 0)
    assert all(p.dtype==torch.float32 for p in actual.values())
    return actual
def preservation_inventory(model):
    """Non-COPY parameters/buffers plus native quantization metadata values."""
    parameters={n:tensor_digest(p) for n,p in model.named_parameters() if '.lora_A.'+ADAPTER_NAME+'.' not in n and '.lora_B.'+ADAPTER_NAME+'.' not in n}
    buffers={n:tensor_digest(p) for n,p in model.named_buffers()}
    quantization={}
    for name,p in model.named_parameters():
        state=getattr(p,'quant_state',None)
        if state is not None:
            packed=state.as_dict(packed=True)
            assert all(isinstance(value,torch.Tensor) for value in packed.values())
            quantization[name]={key:tensor_digest(value) for key,value in packed.items()}
    return {'parameters':parameters,'buffers':buffers,'quantization':quantization}
def enabled_restored_gate(model,expected_layers=168):
    states=model.get_layer_status();assert len(states)==expected_layers
    assert all(s.enabled and not s.merged_adapters and s.active_adapters==[ADAPTER_NAME] for s in states)
    with model.disable_adapter():assert all(not s.enabled and not s.merged_adapters for s in model.get_layer_status())
    assert all(s.enabled and not s.merged_adapters and s.active_adapters==[ADAPTER_NAME] for s in model.get_layer_status())
    return {'actual_layer_count':len(states),'enabled_disabled_restored_unmerged':True}
def load_isolated_body(snapshot,adapter_dir,*,train_body):
    started=time.perf_counter();cfg,expected=source_adapter_state(adapter_dir)
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
    base=AutoModelForCausalLM.from_pretrained(str(snapshot),local_files_only=True,dtype=torch.float16,
        device_map={'':'cuda:0'},attn_implementation='sdpa')
    assert base.is_loaded_in_4bit and base.config.model_type=='qwen2'
    assert base.config.hidden_size==896 and base.config.num_hidden_layers==24 and base.config.num_attention_heads==14
    # No renaming/rewriting original adapter files. PEFT makes a named in-memory copy.
    model=PeftModel.from_pretrained(base,str(adapter_dir),adapter_name=ADAPTER_NAME,is_trainable=True,
        local_files_only=True,autocast_adapter_dtype=True)
    model.set_adapter(ADAPTER_NAME);model.eval()
    copied=verify_copy_state(model,expected);trainable=set_body_trainability(model,train_body)
    restoration=enabled_restored_gate(model);torch.cuda.synchronize()
    return model,{'pretrained_loaded':True,'four_bit_base':True,'pinned_HF_PEFT_SDPA_backend':True,
        'independent_adapter_name':ADAPTER_NAME,'trainable_body_parameters':sum(p.numel() for p in trainable.values()),
        'model_load_seconds':time.perf_counter()-started,**copied,**restoration}
