"""Posthoc saved-score diagnostic, not a new method, model call or threshold test."""
import candidate_process_runtime
from pathlib import Path
import gzip, json
import torch
from candidate_process_evidence_utils import ROOT, read, write, sha, seal
from candidate_process_diagnostics import priority

BASE = ROOT / 'outputs/llm_value_candidate_development_20261009'
PREP = BASE / 'reliable_replication_preparation_v2'
EX = BASE / 'reliable_replication_execution_control_v3'
SCI = EX / 'staged/study'
PRIMARY = BASE / 'reliable_replication_external_audit'
OUT = BASE / 'completed_learning_ranking_readonly_diagnostic'
assert read(BASE / 'reliable_replication_verified_scientific_package/status.json')['all_passed']
assert read(BASE / 'reliable_replication_cost_and_preservation_audit/status.json')['all_passed']
assert not read(PRIMARY / 'Prospective_Gate_Decision.json')['fixed_internal_body_gate_passed']
assert not OUT.exists(); OUT.mkdir()
torch.set_num_threads(2)
program = read(PREP / 'Program_Input_Manifest.json')
assert sha(ROOT / 'work/candidate_process_diagnostics.py') == program['work/candidate_process_diagnostics.py']
index = {r['observation_id']: r for r in read(PREP / 'Input_Index.json')}
targets = read(PREP / 'Target_Index.json')
normal = read(PREP / 'Target_Normalization.json')
arms = read(PREP / 'protocol.json')['arms']
scores = {a: torch.load(SCI / a / 'final_epoch5_scores.pt', weights_only=True, map_location='cpu') for a in arms}
with gzip.open(BASE / 'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz', 'rt', encoding='utf-8') as f:
    labels = {r['observation_id']: r for r in map(json.loads, f)}
assert len(labels) == len(targets) == 238
rows = []
for r in targets:
    ident = r['observation_id']
    allowed = torch.load(PREP / index[ident]['tensor_path'], weights_only=True, map_location='cpu')['allowed_actions']
    actual = {(c['target']['bus'], c['target']['Q_index']): c['target'] for c in labels[ident]['measured_candidates']}
    admissible = {k: t for k, t in actual.items() if bool(allowed[k]) and t['recorded_verifier']['accepted']}
    best = max((tuple(t['recorded_original_score']) for t in admissible.values()), default=None)
    oracle = {k for k, t in admissible.items() if tuple(t['recorded_original_score']) == best}
    row = {'observation_id': ident, 'world_sha256': r['world_sha256'], 'split': r['split'],
        'known_measured_candidates': len(actual), 'known_admissible_candidates': len(admissible),
        'known_oracle_exists': bool(oracle), 'known_oracle_actions': sorted(map(list, oracle)), 'arms': {}}
    for arm in arms:
        p = scores[arm][ident]
        ordering = priority(p, allowed, normal)
        rank = {k: i + 1 for i, k in enumerate(ordering)}
        probability = torch.sigmoid(p[..., :3])
        gains = p[..., 3:] * torch.tensor(normal['scale']) + torch.tensor(normal['mean'])
        def predicted_feasible(k):
            b, q = k
            return bool(probability[b, q, 0] >= .5 and probability[b, q, 1] >= .5 and gains[b, q, 3] >= 0.)
        top = ordering[:4]
        row['arms'][arm] = {'first_allowed_action': list(ordering[0]) if ordering else None,
            'known_oracle_first_rank': min((rank[k] for k in oracle), default=None),
            'known_oracle_predicted_feasible': sum(predicted_feasible(k) for k in oracle),
            'known_oracle_predicted_nonfeasible': sum(not predicted_feasible(k) for k in oracle),
            'top4_known_accepted': sum(k in admissible for k in top),
            'top4_known_rejected': sum(k in actual and k not in admissible for k in top),
            'top4_unknown_unmeasured': sum(k not in actual for k in top),
            'known_best_included': {str(k): bool(oracle.intersection(ordering[:k])) if oracle else None for k in [1, 4, 8]}}
    rows.append(row)
summary = {}
for split in ['optimization', 'development_held']:
    subset = [r for r in rows if r['split'] == split]
    supported = [r for r in subset if r['known_oracle_exists']]
    summary[split] = {'measured_target_states': len(subset), 'recorded_oracle_supported_states': len(supported),
        'different_first_actions': sum(r['arms'][arms[0]]['first_allowed_action'] != r['arms'][arms[1]]['first_allowed_action'] for r in subset),
        'heads_top4_hit_body_miss': sum(r['arms'][arms[0]]['known_best_included']['4'] and not r['arms'][arms[1]]['known_best_included']['4'] for r in supported),
        'body_top4_hit_heads_miss': sum(r['arms'][arms[1]]['known_best_included']['4'] and not r['arms'][arms[0]]['known_best_included']['4'] for r in supported),
        'all_arms': {}}
    for arm in arms:
        primary = read(PRIMARY / 'Actual_All_Arms_Results.json')['metrics'][arm]['final_epoch5'][split]
        hits = {str(k): sum(r['arms'][arm]['known_best_included'][str(k)] for r in supported) for k in [1, 4, 8]}
        assert all(hits[str(k)] == primary['all_K'][str(k)]['recorded_best_included_states'] for k in [1, 4, 8])
        summary[split]['all_arms'][arm] = {'actual_K1_K4_K8_pooled_hits': hits,
            'primary_equal_world_top4': primary['all_K']['4']['equal_world_inclusion'],
            'primary_equal_world_gain_MSE': primary['equal_world_gain_MSE'],
            'primary_masked_classification_Brier': primary['masked_classification_Brier'],
            'known_oracle_states_with_zero_predicted_feasible_oracles': sum(r['arms'][arm]['known_oracle_predicted_feasible'] == 0 for r in supported),
            'top4_known_accepted_sum': sum(r['arms'][arm]['top4_known_accepted'] for r in subset),
            'top4_known_rejected_sum': sum(r['arms'][arm]['top4_known_rejected'] for r in subset),
            'top4_unknown_sum': sum(r['arms'][arm]['top4_unknown_unmeasured'] for r in subset)}
write(OUT / 'All238_Fixed_Decoder_State_Diagnostics.json', rows)
write(OUT / 'Diagnostic_Summary.json', {'all_passed': True, 'splits': summary,
    'same_final_epoch5_scores_and_original_decoder_only': True,
    'no_threshold_K_objective_model_weight_or_world_changes': True,
    'all_K1_K4_K8_preserved_no_favorable_budget_selection': True,
    'posthoc_descriptive_not_causal_component_identification': True,
    'new_model_optimizer_PF_or_controller_calls': 0,
    'new_performance_study_not_authorized_by_diagnostic': True,
    'original_failed_intervention_remains_stopped': True,
    'source_sha256': sha(Path(__file__))})
files = {'audit/' + p.name: p for p in OUT.iterdir() if p.is_file()}
files['source/' + Path(__file__).name] = Path(__file__)
archive = seal(OUT, files, 'Completed_Learning_Ranking_Diagnostic.zip')
print(json.dumps({'summary': summary, 'archive': archive}, indent=2))
