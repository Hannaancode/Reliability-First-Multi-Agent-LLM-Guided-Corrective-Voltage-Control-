"""Read-only identity/selection/cost audit, seal reports without new experiments."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/llm_value_development'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify_manifest(base,manifest):
    for name,item in manifest.items():
        p=base/name;assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
def score(test):
    before,after=test['verification']['before'],test['verification']['after']
    return (int(after['uv_count']==0),before['uv_count']-after['uv_count'],
            before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],
            -sum(abs(float(q)) for q in test['action']['add_shunts_q_mvar'].values()))
def audit_selection(row,metrics_key='executed_after_metrics'):
    accepted=[t for t in row['tested'] if t['verification']['accepted']]
    best=max(accepted,key=score) if accepted else None
    assert row['selected_action']==(best['action'] if best else None)
    if best:
        after=best['verification']['after']
        assert all(abs(float(after[k])-float(row[metrics_key][k]))<=1e-10 for k in after)
def main():
    destination=OUT/'First_Clean_Screen_Completion_Audit.json';assert not destination.exists()
    gpu=read(OUT/'gpu_execution_status.json');assert gpu['runtime_released'] and gpu['actual_batches_preserved']==12
    verify_manifest(OUT/'gpu_staged',read(OUT/'GPU_Staged_Manifest.json'))
    verify_manifest(OUT/'cpu_controls',read(OUT/'CPU_Control_Manifest.json'))
    analysis=read(OUT/'clean_value_screen_analysis.json');summary=read(OUT/'cpu_screen_summary.json')
    protocol=read(OUT/'clean_value_development_protocol.json')
    expected={c['scenario_id']+'__'+p+'__B'+str(b) for c in protocol['initial_screen_scenarios']
              for p in protocol['first_screen_policies'] for b in protocol['candidate_evaluation_budget_grid']}
    assert set(analysis['input_row_sha256'])==expected and len(expected)==30
    for key,digest in analysis['input_row_sha256'].items():
        p=OUT/'cpu_screen_cases'/(key+'.json');assert sha(p)==digest;row=read(p)
        case=next(c for c in protocol['initial_screen_scenarios'] if c['scenario_id']==row['scenario_id'])
        assert row['scenario_sha256']==case['sha256']==sha(ROOT/case['path'])
        assert row['true_state_preserved'] and row['candidate_PF_counts']['attempts']<=row['budget']
        assert row['tested_candidate_count']==len(row['tested'])<=row['budget']
        assert row['execution_PF_counts']['attempts']<=1
        audit_selection(row)
    assert summary['actual_trials']==analysis['actual_trials']==30
    assert summary['actual_GPU_calls']==analysis['actual_GPU_calls']==63
    assert summary['preserved_control_rows_reused_without_rerun']==18
    assert summary['actual_local_PF_counts_all_executed_stages']=={'attempts':1614,'returns':1614,'exceptions':0}
    for n,digest in read(ROOT/'outputs/matched_campaign_protocol.json')['source_sha256'].items():assert sha(ROOT/n.replace('\\','/'))==digest
    component=OUT/'bus_Q_attribution';verify_manifest(component,read(component/'manifest.json'))
    cp=read(component/'protocol.json');cs=read(component/'summary.json')
    assert sha(ROOT/'work/run_bus_Q_attribution.py')==cp['driver_sha256']
    assert sha(OUT/'Bus_Q_Attribution_Protocol_Design.md')==cp['design_sha256']
    assert cs['actual_new_CPU_trials']==4 and cs['actual_new_model_calls']==0
    assert cs['actual_new_PF_counts']=={'attempts':134,'returns':134,'exceptions':0}
    for result in cs['rows']:
        row=read(component/(result['trial_id']+'.json'));audit_selection(row)
        assert row['source_state_preserved'] and row['selected_action_execution_matches_verification_1e10']
        assert len(row['tested'])==32 and row['actual_candidate_PF_counts']['attempts']==32
        assert row['actual_execution_PF_counts']['attempts']==1
    audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'auditor_sha256':sha(Path(__file__)),
           'first_screen_30_exact_rows_sha_identity_selection_and_cost_checks_passed':True,
           'genuine_model_batches':12,'actual_primary_query_opportunities':48,'actual_generations_including_repairs':63,
           'GPU_staged_manifest_members_verified':len(read(OUT/'GPU_Staged_Manifest.json')),
           'original_18_control_rows_preserved_without_rerun':True,
           'first_screen_actual_local_PF_all_stages':summary['actual_local_PF_counts_all_executed_stages'],
           'first_screen_primary_UV_deltas':analysis['primary_residual_UV_deltas'],
           'component_exact_four_rows_and_original_manifest_verified':True,
           'component_new_PF':134,'component_new_model_calls':0,
           'runtime_released':True,'frozen_controller_source_hashes_preserved':True,
           'new_model_or_PF_calls_by_this_audit':0,
           'scope':'Completed historical development with adverse/null findings; no confirmatory superiority, closed-loop or full security claim'}
    destination.write_text(json.dumps(audit,indent=2))
    members={p.relative_to(OUT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)}
             for p in sorted((OUT/'cpu_screen_cases').glob('*.json'))}
    for name in ['cpu_screen_summary.json','cpu_screen_progress.json','clean_value_screen_analysis.json','genuine_clean_GPU_artifact_audit.json','First_Clean_Screen_Completion_Audit.json']:
        p=OUT/name;members[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
    (OUT/'First_Clean_Screen_Results_Manifest.json').write_text(json.dumps(members,indent=2))
    print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
