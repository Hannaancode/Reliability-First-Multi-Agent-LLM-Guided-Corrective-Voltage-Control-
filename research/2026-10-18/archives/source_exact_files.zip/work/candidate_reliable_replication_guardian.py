"""One finite scientific child; closed small-file retrieval descriptor only."""
from pathlib import Path
import hashlib,json,os,subprocess
os.chdir('/content/hiergrid_execution')
with open('outputs/reliable_science.log','w') as log:
    child=subprocess.Popen(['env/bin/python','work/candidate_reliable_replication_remote.py'],stdout=log,stderr=subprocess.STDOUT)
    Path('outputs/reliable_science_pid.json').write_text(json.dumps({'pid':child.pid}))
    try:result=child.wait(timeout=5100)
    except subprocess.TimeoutExpired:
        child.terminate()
        try:result=child.wait(timeout=30)
        except subprocess.TimeoutExpired:child.kill();result=child.wait()
root=Path('outputs/llm_value_candidate_development_20261009/reliable_replication_science')
parts_root=Path('outputs/reliable_closed_parts');parts_root.mkdir()
members={}
for p in root.rglob('*'):
    if not p.is_file():continue
    name=p.relative_to(root).as_posix();folder=hashlib.sha256(name.encode()).hexdigest();(parts_root/folder).mkdir()
    pieces=[]
    with p.open('rb') as f:
        while raw:=f.read(2*1024*1024):
            part=f'{folder}/part_{len(pieces):04d}.bin';(parts_root/part).write_bytes(raw)
            pieces.append({'path':part,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    members[name]={'bytes':p.stat().st_size,'sha256':h,'parts':pieces}
Path('outputs/reliable_closed_descriptor.json').write_text(json.dumps({'members':members,'scientific_exit_code':result},indent=2))
Path('outputs/reliable_exit.json').write_text(json.dumps({'exit_code':result,'actual_scientific_pid':child.pid,'no_scientific_restart':True}))
