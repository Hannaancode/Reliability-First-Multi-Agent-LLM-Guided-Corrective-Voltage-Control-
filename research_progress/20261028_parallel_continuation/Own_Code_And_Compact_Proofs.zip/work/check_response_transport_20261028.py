"""Saved-response and synthetic transport checks; zero model or solver calls."""
import hashlib
import json
import os
import tempfile
import time
from pathlib import Path
from immutable_response_transport_20261028 import publish_once, read_response

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/response_transport_recovery_20261028'


def main():
    OUT.mkdir(exist_ok=False)
    (OUT / 'owner.claim').write_text(json.dumps({'pid': os.getpid(), 'parent': os.getppid(),
        'source': str(Path(__file__).resolve()), 'scope': 'saved bytes and synthetic local I/O only'}))
    checks = []
    saved = []
    for case, number in [(1, 34), (3, 37)]:
        root = ROOT / 'outputs/reflection118_remaining_cases_v2_execution_20261023' / f'case_{case:02d}'
        name = f'response_{number:05d}.json'
        manifest = json.loads((root / 'remote_closed_descriptor.json').read_text())
        pin = manifest['members'][name]['sha256']
        local = root / 'local_controller/responses' / name
        staged = root / 'staged/study' / name
        raw = local.read_bytes()
        assert raw == staged.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == pin
        request = json.loads((root / 'local_controller/requests' / f'request_{number:05d}.json').read_text())
        value, costs = read_response(local, request, pin, time.monotonic()+2)
        saved.append({'case_index': case, 'response_number': number, 'sha256': pin,
                      'local_staged_descriptor_agree': True, 'request_identity_exact': True,
                      'bytes': len(raw), 'local_read_cost': costs,
                      'old_failure': json.loads((root/'local_controller/Results.json').read_text())['failure']['type']})
    checks.append('Both interrupted response bytes already preserved and request-bound')
    with tempfile.TemporaryDirectory(dir=OUT) as temporary:
        p = Path(temporary)/'response.json'
        payload=json.dumps({'number':0,'request':{'number':0},'text':'fixture'}).encode()
        pin=hashlib.sha256(payload).hexdigest()
        publish_once(p,payload,pin)
        publish_once(p,payload,pin)
        assert p.read_bytes()==payload
        checks.append('Identical publication is idempotent')
        other=payload+b' '
        try:publish_once(p,other,hashlib.sha256(other).hexdigest())
        except ValueError:pass
        else:raise AssertionError('Changed bytes replaced existing response')
        assert p.read_bytes()==payload
        checks.append('Conflicting publication rejected without replacement')
        ticks=[0.0]; calls=[0]
        def transient():
            calls[0]+=1
            if calls[0]<=2:raise PermissionError('synthetic sharing denial')
            return payload
        value,cost=read_response(p,{'number':0},pin,1,read_bytes=transient,
            clock=lambda:ticks[0],sleep=lambda dt:ticks.__setitem__(0,ticks[0]+dt))
        assert cost['local_read_attempts']==['PermissionError','PermissionError','returned']
        checks.append('Transient sharing denial retries only local reads with exact bytes')
        def denied():raise PermissionError('synthetic permanent denial')
        ticks[0]=0
        try:read_response(p,{'number':0},pin,.12,read_bytes=denied,clock=lambda:ticks[0],sleep=lambda dt:ticks.__setitem__(0,ticks[0]+dt))
        except TimeoutError:pass
        else:raise AssertionError('Deadline extended')
        assert ticks[0]==.12
        checks.append('Persistent denial stops at original absolute deadline')
        for req,expected,label in [({'number':1},pin,'Wrong request rejected'),({'number':0},'0'*64,'Wrong byte hash rejected')]:
            try:read_response(p,req,expected,time.monotonic()+1)
            except ValueError:pass
            else:raise AssertionError(label)
            checks.append(label)
        bad=b'not json';publish_once(Path(temporary)/'bad',bad,hashlib.sha256(bad).hexdigest())
        try:read_response(Path(temporary)/'bad',{'number':0},hashlib.sha256(bad).hexdigest(),time.monotonic()+1)
        except json.JSONDecodeError:pass
        else:raise AssertionError('Malformed payload accepted')
        checks.append('Malformed payload rejected without content repair')
    result={'status':'PASS_SAVED_BYTES_AND_SOFTWARE_ONLY','checks':checks,'saved_responses':saved,
        'new_model_PF_optimizer_training_calls':0,
        'cause_limit':'Old trace proves local read PermissionError; historical OS locking actor is unproven.',
        'continuation_limit':'No old worker restarted, no old budget extended. Future missing-only source/cursor/registry/ownership protocol required.',
        'gate_note':'Four-case primary contrast remains UNKNOWN; complete case84 already has additional strict OV, so its fixed no-additional-OV condition is violated.',
        'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name('immutable_response_transport_20261028.py')]}}
    (OUT/'Results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
