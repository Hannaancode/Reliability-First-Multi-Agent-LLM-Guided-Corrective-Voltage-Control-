# A falsifiable acquisition mechanism before another LLM campaign

10 October 2026. This review was written after freezing the four-policy saved-replay protocol, before reading its performance. It does not restart the stopped immediate predictors, two-shortlist selector, root selector or fixed public1.5B command interface. It does not replace the full superiority objective with a saved-data accuracy target.

The actual scientific question is whether a policy can use already requested physical feedback to choose its next verification more effectively across the original legal action universe. This differs from learning an immediate maximizer after receiving every action's outcome. The earlier exact-argmax ceiling remains valid for identical verified state/action sets. It does not establish an optimal order for acquiring initially hidden outcomes or an optimal recovery trajectory.

## What the cheap numerical screen can establish

Four newly fixed controls use both preserved native numerical priors: static ordering and causal same-bus residual interpolation. All original legal queries remain available, including actions with unavailable or nonphysical numerical predictions. Such predictions remain provisional, not nonlinear convergence certificates. The common scope, nine-Q grid, accumulated450MVAr cap, normal-upper protection and original lexicographic score are unchanged. Static controls receive the same protection as feedback controls.

Each control requests eight distinct receipts, or all legal actions when fewer exist, then nominates the best actually accepted/converged returned action or abstains. It cannot see unqueried labels, teacher-successor coverage or administrative IDs. No oracle, hindsight label coverage or favorable early success stops the query loop. Only after irreversible saved commitment can the interface expose an existing recorded successor, which this one-state screen does not use to evaluate trajectories.

Residual interpolation corrects approximate global metrics using only returned finite converged observations. It includes rejected-but-converged receipts, uses no cross-bus transfer and asserts no physical monotonicity. Rounded UV counts and projected metric ranges are explicitly numerical approximations. The new priority evaluations and interpolated estimates are counted and charged; they are not mislabeled as zero numerical work.

The fixed primary development diagnostic is eight-query inclusion of a recorded best protected action, averaged equally by historical world on the pre-existing measured-oracle denominator. All239 optimization inputs,23 worlds,52 unlabelled states, invalid denominators, unavailable priors, rejected queries and unknown outcomes remain separately reported. All-input conservative bounds retain missing measurements; they are not statistical confidence intervals. No held outcomes are newly inspected.

The numerical-feedback support gate requires at least five percentage points above both static controls and improvement in at least three exact worlds against each. A failed numerical rule is evidence against that particular interpolation mechanism, not proof that every adaptive policy or LLM must fail. An optimistic target ceiling can reject the fixed five-point target when even an oracle lacks that much headroom. Passing either condition does not trigger GPU work.

## Critical literature and originality boundary

[LMABO, author preprint v1](https://arxiv.org/html/2602.07904v1), sections3–4 and appendicesD–E, already places an LLM over a numerical predictor to select acquisition strategies from process feedback. It compares static and adaptive portfolios and examines curated portfolio costs. Thus adaptive acquisition, a numerical backbone and an LLM strategist are prior art. Its continuous Bayesian-optimization setting and runtime accounting do not prove advantage over HierGrid's protected deterministic portfolio. A claim for our eventual implementation needs a specific new mechanism and equally informed trained numerical and architecture/pretraining controls.

## What still prevents a justified LLM launch

No language-relevant advantage has been identified by this control. The current observation channel is chiefly physical tables and numbers. A future method must explain why useful language pretraining should improve the chosen decision, then test that explanation against a matched architecture without useful pretraining. Merely using an LLM to perform numerical interpolation cannot establish such a mechanism.

A strong trained numerical acquisition policy is still required, with the same current fields, priors, returned feedback, legal queries, target, world grouping and budget. The present untrained rules do not substitute for that comparison. A causal history representation and decision-aligned learning target remain to be implemented and prospectively fixed. Missing action successors cannot be invented as episode rewards or full voltage vectors.

Saved lookup latency is not online power-flow latency. Existing aggregate solver timing lacks an action-by-action attribution, while costs for a new LLM context, inference, preparation and failure handling are unmeasured. Consequently the economic gate remains UNKNOWN regardless of saved-replay success. Any proposed deployment must pay for both numerical prior construction and physical verification, not obtain expensive prior forecasts or teacher labels for free.

Finally, a saved-label improvement would only justify further design. The full objective still requires fresh per-state model inference, matched protected physical trajectories, continuous independent replay, full model/numerical/preparation/failure costs, original DFF and DFF-ALT individually, their unchanged D-SE portfolio with BOTH branch costs, strong attribution controls and genuinely unused authorized confirmation. No99%success or novelty claim follows from this review.
