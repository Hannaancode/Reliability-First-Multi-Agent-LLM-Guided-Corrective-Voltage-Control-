"""One previously unentered original Reflection-v4 case; no numerical substitute."""
import traceback
from original_missing_suffix_core_20261028 import *

def main():
    index,Pcase,Host=case_paths();O=Host/'local_controller';O.mkdir(exist_ok=False)
    began=time.monotonic();put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-began<120;time.sleep(.1)
    ack=read(O/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['fresh_exact_source_PID_parent_command']
    p=read(Pcase/'Frozen_Engineering_Protocol.json')
    for name,digest in p['local_source_hashes'].items():assert sha(R/name)==digest
    for name,digest in p['input_hashes'].items():assert sha(R/name)==digest
    np,pp,v2,runner,reflection=setup()
    from public_size_u61_preservation import journal
    require_partition_closed()
    registry=ClosedPaidRegistry(R/p['closed_paid_registry'],O/'solver_input_identity');native=pp.runpp
    binding=read(R/p['bindings'])[index];assert binding['case_id']==p['case_order'][0]
    root=net_value(pickle.loads((R/binding['solved_payload']).read_bytes()))
    base=pp.from_json(str(R/p['base_net']));zones=read(R/p['metadata'])['zones'];scenario=read(R/binding['registration']['recipe'])
    d=O/binding['case_id']/'reflection_v2';d.mkdir(parents=True)
    costs=dict(new_PF_attempts=0,new_PF_returns=0,new_PF_exceptions=0,new_PF_seconds=0.,paid_initial_reuses=0,paid_return_reuses=0,paid_failure_reuses=0,model_requests=0,cold_cached_physics_calls=0,cold_cached_model_responses=0,binary_bytes=0,new_optimizer_derivative_training_calls=0)
    costs['exact_solver_input_preparation']=registry.preparation_costs
    from run_reflection118_chronological_local_20261022 import necessary
    fixed_case_component=necessary(root)
    previous='0'*64;pf_rows=[];gen_rows=[];initial=False;warm=None;stage='missing_suffix';result=None;failure=None;request=0;pi=gi=0;boundary_pf=boundary_gen=0;cold_checked=False
    active=dict(case_id=binding['case_id'],arm='reflection_v2')
    def bound():
        if time.monotonic()-began>=p['local_controller_seconds']:raise OperationalStop('FIXED_NEW_LOCAL_CONTROLLER_BOUND_NO_EXTENSION')
        if costs['binary_bytes']+registry.preparation_costs['proof_bytes']+4*1024**2>p['local_binary_bound_bytes']:raise OperationalStop('FIXED_NEW_LOCAL_BINARY_BOUND')
    def event(kind,**fields):
        nonlocal previous
        row=dict(kind=kind,active=active,elapsed_seconds=time.monotonic()-began,previous=previous,**fields)
        previous=hashlib.sha256(canonical(row)).hexdigest();journal(O/'events.jsonl',dict(event=row,sha256=previous))
    def progress():
        tmp=O/'Status.pending';tmp.write_text(json.dumps(dict(case_id=binding['case_id'],stage=stage,costs=costs,actual_model_responses=len(gen_rows),closed_PF_calls=len(pf_rows),elapsed_seconds=time.monotonic()-began)),encoding='utf-8');os.replace(tmp,O/'Status.json')
    def primary_model(messages):
        nonlocal request
        assert suffix.admitted
        bound();number=request;request+=1;req=dict(number=number,active=active,messages=messages)
        from immutable_response_transport_20261028 import publish_once
        request_bytes=canonical(req)
        publish_once(O/'requests'/f'request_{number:05d}.json',request_bytes,hashlib.sha256(request_bytes).hexdigest());costs['model_requests']+=1
        event('model_request',number=number,messages_sha256=hashlib.sha256(canonical(messages)).hexdigest())
        from immutable_response_transport_20261028 import read_response
        path=O/'responses'/f'response_{number:05d}.json';ready=path.with_suffix('.ready.json');tick=time.monotonic()
        while not ready.exists():
            bound();assert not (O/'Remote_Ended.json').exists() and time.monotonic()-tick<300,'Actual response unavailable; no model retry'
            time.sleep(.2)
        receipt=read(ready)
        ans,transport=read_response(path,req,receipt['sha256'],min(began+p['local_controller_seconds'],tick+300))
        event('local_response_read',**transport)
        event('model_return',number=number,response_sha256=sha(path))
        gen_rows.append(dict(messages=copy.deepcopy(messages),text=ans['raw_text'],request=number));progress()
        return ans['raw_text']
    def primary_pf(net,**kwargs):
        nonlocal initial
        assert suffix.admitted
        assert necessary(net)==fixed_case_component,'Fixed case load/outage changed; parallel physical identities could collide'
        bound();number=len(pf_rows);before=capsule(d/f'pf_{number:06d}_before.zlib',net);costs['binary_bytes']+=before['bytes'];exception=None;seconds=0.
        if initial:
            assert kwargs==binding['solver_kwargs'];restore_exact(net,root);initial=False;provenance=dict(kind='PAID_ORIGINAL_INITIAL_REUSE');costs['paid_initial_reuses']+=1
        else:
            saved,exception,provenance=registry.lookup(net,kwargs)
            if saved is not None:
                restore_exact(net,saved);costs['paid_return_reuses' if exception is None else 'paid_failure_reuses']+=1
            else:
                bound();event('new_PF_attempt_reserved',number=number,before=before,kwargs=kwargs,coverage=provenance);costs['new_PF_attempts']+=1;tick=time.perf_counter()
                try:native(net,**kwargs);assert net.converged;costs['new_PF_returns']+=1
                except Exception as exc:exception=dict(type=type(exc).__name__,message=str(exc));costs['new_PF_exceptions']+=1
                seconds=time.perf_counter()-tick;costs['new_PF_seconds']+=seconds;provenance=dict(kind='NEW_PRIMARY_RETURN' if exception is None else 'NEW_PRIMARY_EXCEPTION',scope=provenance)
        after=capsule(d/f'pf_{number:06d}_after.zlib',net);costs['binary_bytes']+=after['bytes']
        rec=dict(before=before,after=after,kwargs=kwargs,provenance=provenance,exception=exception,seconds=seconds)
        path=d/f'pf_{number:06d}.json';put(path,rec);pf_rows.append(rec);registry.add(d,path,rec)
        event('PF_closed',number=number,record=path.relative_to(O).as_posix(),record_sha256=sha(path),exception=exception)
        if exception is not None:raise RuntimeError(failure_message(exception))
    def save_commit(state):
        if not suffix.admitted:return
        count=len(state['result']['executed_actions']);assert 1<=count<=25
        packet=capsule(d/f'commit_{stage}_{count:02d}.zlib',dict(source_frame=state,PF_cursor=len(pf_rows),model_cursor=len(gen_rows),PF_record_hashes=[sha(d/f'pf_{i:06d}.json') for i in range(len(pf_rows))],model_requests=[r['request'] for r in gen_rows],costs=copy.deepcopy(costs),original_absolute_deadline=began+p['local_controller_seconds'],protocol_sha256=sha(Pcase/'Frozen_Engineering_Protocol.json')))
        costs['binary_bytes']+=packet['bytes'];cold=decode(d,packet);checkpoint_equal(state,cold['source_frame'])
        put(d/f'commit_{stage}_{count:02d}.json',dict(descriptor=packet,PF_cursor=len(pf_rows),model_cursor=len(gen_rows),remaining_original_operations=25-count))
        event('complete_commit_checkpoint',stage=stage,count=count,descriptor=packet);progress()
    suffix=OriginalMissingSuffix(index,reflection,primary_model,primary_pf)
    try:
        put(O/'Frozen_Before.json',frozen_checks());random.seed(p['seed']);np.random.seed(p['seed'])
        result,_=run_original(v2,runner,reflection,scenario,base,zones,suffix.model,suffix.physics,commit_callback=save_commit)
        assert suffix.admitted
        put(d/'Cold_Continuation_Gate.json',dict(status='PASS_EXACT_PENDING_FRAME_BEFORE_FIRST_UNENTERED_MODEL_REQUEST',paid_prefix=suffix.costs))
        put(d/'Result.json',result)
    except BaseException as exc:
        failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc());put(O/'Failure.json',failure)
    finally:
        pp.runpp=native
        costs['prior_source_reconstruction']=suffix.costs
        put(d/'Call_Order.json',dict(PF=pf_rows,generations=gen_rows))
        summaries=[]
        if result is not None:
            summary=reflection.summarize_result(result);summary['case_id']=binding['case_id'];summary['strict_OV']=result['final_metrics']['ov_count'];summaries.append(summary)
        put(O/'Results.json',dict(status='COMPLETE_ONE_UNENTERED_ORIGINAL_REFLECTION_CASE_REQUIRE_READER' if result is not None and failure is None else 'TERMINAL_PARTIAL_REMAINDER_UNKNOWN',summaries=summaries,costs=costs,failure=failure,workflow_seconds=time.monotonic()-began,no_full_DSE_external_or_unused_confirmation=True))
        put(O/'Frozen_After.json',frozen_checks());progress()
        put(O/'Closed_Manifest.json',dict(members={f.relative_to(O).as_posix():sha(f) for f in O.rglob('*') if f.is_file()}))
        put(O/'Local_Controller_Ended.json',dict(at_unix=time.time(),pid=os.getpid(),no_retry=True))

if __name__=='__main__':main()
