import argparse
from next_ordinary_query_core_20261019 import reader,helpers,B
from public118_slsqp_native_20261018 import read,put,manifest

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--reader',action='store_true');p.add_argument('--identity-fixture',action='store_true');a=p.parse_args()
    if a.identity_fixture:
        h=helpers(__file__);out=B/'fixture_reader';h['claim'](out,read(B/'Protocol.json'));put(out/'Result.json',{'status':'PASS_ACTUAL_READER_SOURCE_CLAIM','new_scientific_calls':0});manifest(out)
    else:reader(__file__)()
