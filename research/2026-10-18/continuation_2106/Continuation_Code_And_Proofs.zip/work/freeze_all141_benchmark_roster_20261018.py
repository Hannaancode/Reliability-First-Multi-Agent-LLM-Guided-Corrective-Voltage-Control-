"""Bind the EXISTING severity inventory to exact141recipe bytes, not outcomes.

No new classification threshold or physics experiment. This is a complete
development roster prerequisite, not a benchmark result/launch permission.
"""
import collections,json
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from candidate_process_evidence_utils import frozen_checks
B=R/'outputs/all141_benchmark_roster_20261018'
I=R/'outputs/research_tasks_20261014/All141_Federation_Case_Status.json'
D=R/'work/e/pack/scenarios/federation'

def independent_check():
    p=read(B/'Roster_Protocol.json');data=read(B/'All141_Exact_Recipe_Roster.json');old=read(I);actual={v.name:v for v in D.glob('*.json')}
    assert len(actual)==len(data)==141 and {v['recipe'] for v in data}==set(actual)=={v['recipe'] for v in old['all_cases']}
    source={v['world']:v for v in old['all_cases']};counts=collections.Counter();primary=[];broader=[];unknown=[]
    for v in data:
        s=source[v['world']];path=actual[v['recipe']];assert v['world']==Path(v['recipe']).stem
        assert path.stat().st_size==v['recipe_bytes'] and sha(path)==v['recipe_sha256'];read(path)
        n=s['recorded_initial_UV'];expected='UNKNOWN_INITIAL_RETAIN_FOR_SCREENING' if n is None else 'PRIMARY_GE60' if n>=60 else 'BROADER_GE50' if n>=50 else 'OTHER_KNOWN_INITIAL'
        assert v['stratum']==expected and v['recorded_initial_UV']==n and set(v)=={'world','recipe','recipe_path','recipe_bytes','recipe_sha256','recorded_initial_UV','stratum','data_role','comparison_status'}
        assert v['comparison_status']=='NOT_NEWLY_TESTED' and v['data_role']=='INSPECTED_DEVELOPMENT_NOT_UNUSED_CONFIRMATION'
        counts[expected]+=1
        if n is None:unknown.append(v['world'])
        if n is not None and n>=60:primary.append(v['world'])
        if n is not None and n>=50:broader.append(v['world'])
    assert primary==p['primary_known_ge60'] and broader==p['all_known_ge50'] and unknown==p['unknown_initials_retained']
    return {'status':'PASS_EXACT_ALL141_RECIPE_BYTES_EXISTING_INITIAL_ONLY_STRATA_AND_NO_OUTCOME_SELECTION','recipe_count':141,'stratum_counts':dict(counts),
        'primary_known_ge60':primary,'all_known_ge50':broader,'unknown_initial_count':len(unknown),'new_scientific_calls':0,
        'limitations':'Existing inspected development initial counts, not newly measured case starts. No matched outcomes, feasibility, zero-all, wholeDSE or LLM result; all unknowns retained.'}

def main():
    B.mkdir(exist_ok=False);source=read(I);names={p.name:p for p in D.glob('*.json')};assert len(names)==source['recipe_count']==141
    rows=[]
    for v in source['all_cases']:
        path=names[v['recipe']];read(path);n=v['recorded_initial_UV']
        tag='UNKNOWN_INITIAL_RETAIN_FOR_SCREENING' if n is None else 'PRIMARY_GE60' if n>=60 else 'BROADER_GE50' if n>=50 else 'OTHER_KNOWN_INITIAL'
        rows.append({'world':v['world'],'recipe':v['recipe'],'recipe_path':str(path.relative_to(R)),'recipe_bytes':path.stat().st_size,'recipe_sha256':sha(path),
            'recorded_initial_UV':n,'stratum':tag,'data_role':'INSPECTED_DEVELOPMENT_NOT_UNUSED_CONFIRMATION','comparison_status':'NOT_NEWLY_TESTED'})
    put(B/'All141_Exact_Recipe_Roster.json',rows)
    known=lambda threshold:[v['world'] for v in rows if v['recorded_initial_UV'] is not None and v['recorded_initial_UV']>=threshold]
    put(B/'Roster_Protocol.json',{'status':'FROZEN_ALL141_DEVELOPMENT_ROSTER_PREREQUISITE_NOT_SCIENTIFIC_LAUNCH','at_utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':sha(__file__),'existing_inventory_sha256':sha(I),'roster_sha256':sha(B/'All141_Exact_Recipe_Roster.json'),
        'classification':'Keep ORIGINAL14October initial>=60 primary and>=50 broader thresholds; all141 retained. Do not select by outcomes or by which currentNET was easy to recover.',
        'primary_known_ge60':known(60),'all_known_ge50':known(50),'unknown_initials_retained':[v['world'] for v in rows if v['recorded_initial_UV'] is None],
        'comparison_contract':['Actual full causal source-bound initialNET needed for each recipe; historical names/partial logs alone do not join to the frozen62bank.',
            'Every declared severe identity needs hybrid,DFF,DFFALT,unchangedDSE plus equally capable numerical control under common raw scopes/actions/protection/25ops/cap450/no-refund/ownedstock.',
            'Charge BOTH DSE branches, model/training/preparation/query/replay/failure costs; charge independent replay explicitly; no guessing missing timing or free historical data.',
            'No reused inference is called fresh; archived trained-LLM prefixes remain distinct from fresh model policy decisions.',
            'Initial PF exceptions/missing data remainUNKNOWN, never excluded as nonsevere or counted negative. No original locked bank/model/controller regeneration.',
            'Preserve all cases and declared costs, source/ownership/persistent complete state and independent-reader gates before performance. No automatic run from this roster.',
            'Zero-all and superiority need complete matched protected trajectories and unused authorized confirmation; this development roster cannot supply unused confirmation.'],
        'new_scientific_calls':0})
    audit=independent_check();put(B/'Independent_Roster_Check.json',audit);put(B/'Frozen_Checks.json',frozen_checks());manifest(B)
    print(json.dumps({'roster':'PASS','all_recipes':141,'counts':audit['stratum_counts'],'primary_severe':audit['primary_known_ge60'],'new_science':0}))
if __name__=='__main__':main()
