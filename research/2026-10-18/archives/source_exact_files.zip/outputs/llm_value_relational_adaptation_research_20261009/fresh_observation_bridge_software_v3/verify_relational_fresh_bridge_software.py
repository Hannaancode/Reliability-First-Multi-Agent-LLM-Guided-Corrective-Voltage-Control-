"""Saved-input/mock-capture checks. Zero neural, solver or controller calls."""
import candidate_process_runtime
import copy
import gzip
import json
import os
import sys
import time
from datetime import datetime, timezone
from types import SimpleNamespace, ModuleType
from unittest.mock import patch

import torch
from candidate_process_evidence_utils import ROOT, read, write, sha, seal
from relational_current_state_codec import decode, digest
from relational_fresh_observation_bridge import compile_observation, capture_current, FORWARD_FIELDS
from candidate_predictor_input_contract import Q_GRID

P = ROOT / 'outputs/llm_value_relational_adaptation_research_20261009'
C = P / 'current_relational_tensor_cache_v2'
OUT = P / 'fresh_observation_bridge_software_v3'
assert not OUT.exists()
OUT.mkdir()
write(OUT / 'owner.claim', {'pid': os.getpid(), 'started_at_utc': datetime.now(timezone.utc).isoformat()})
started = time.perf_counter()
checks = []


def prove(name, ok):
    assert ok, name
    checks.append({'check': name, 'passed': True})


def rejects(name, fn):
    try:
        fn()
    except (ValueError, AssertionError):
        checks.append({'check': name, 'passed': True})
    else:
        raise AssertionError(name)


conditioning = read(C / 'OPT_Input_Conditioning.json')
conditioning_identity = digest(conditioning)
index = read(C / 'Input_Index.json')
# Three ascending identities, selected without target/outcome access.
selected = sorted(index, key=lambda r: r['observation_id'])[:3]
wanted = {r['observation_id'] for r in selected}
records = {}
raw_file = P / 'actual_representation_and_OPT_support/Actual_Relational_Current_Input_Records.jsonl.gz'
with gzip.open(raw_file, 'rt', encoding='utf8') as f:
    for line in f:
        row = json.loads(line)
        identity = row['audit_identity']['observation_id']
        if identity in wanted:
            records[identity] = decode(row['model_input_codec'])
prove('three prospectively selected saved current inputs found', set(records) == wanted)
audits = []
for item in selected:
    actual_file = C / item['path']
    assert sha(actual_file) == item['sha256']
    current = records[item['observation_id']]
    obs = current['current_physical_observation']
    support = current['current_control_state']['added_abs_Q_MVAr_by_bus']
    compiled, audit = compile_observation(obs, support, conditioning)
    cached = torch.load(actual_file, weights_only=False)['model_input']
    prove('exact unchanged cached thirteen-field input ' + item['observation_id'], compiled == cached)
    prove('identities/audit/labels excluded from forward ' + item['observation_id'], set(compiled) == FORWARD_FIELDS)
    audits.append(audit)

current = records[selected[0]['observation_id']]
obs = current['current_physical_observation']
support = current['current_control_state']['added_abs_Q_MVAr_by_bus']
bad = copy.deepcopy(obs)
bad['scenario_id'] = 'fixture'
rejects('scenario identity rejected at observation boundary', lambda: compile_observation(bad, support, conditioning))
bad_scope = copy.deepcopy(obs)
zone = next(iter(bad_scope['raw_common_and_zone_pools']))
bad_scope['raw_common_and_zone_pools'][zone].append(0)
rejects('invented raw common-zone intersection rejected', lambda: compile_observation(bad_scope, support, conditioning))
rejects('nonfinite current support rejected', lambda: compile_observation(obs, [float('nan')] + support[1:], conditioning))
rejects('wrong support length rejected', lambda: compile_observation(obs, support[:-1], conditioning))
bad_schema = copy.deepcopy(obs)
bad_schema['zone_reports']['fixture_unknown'] = {'new_field': 1.}
rejects('unseen semantic field rejected without normalization refit', lambda: compile_observation(bad_schema, support, conditioning))
prove('OPT normalization not changed by compilation or failures', digest(conditioning) == conditioning_identity)

# The live adapter is exercised with an explicitly MOCKED observer/getter.
# This does not claim a new physical observation or original solver execution.
runner = SimpleNamespace(rescue=SimpleNamespace(Q_SWEEP=list(Q_GRID), MAX_ABS_Q_PER_BUS=450.,
    llm_q_abs_at_bus=lambda net, bus: support[bus]))
net = SimpleNamespace(converged=True)
mock_observer = ModuleType('train_trajectory_measurement_nullable_v2')
mock_observer.observation = lambda *args: copy.deepcopy(obs)
with patch.dict(sys.modules, {'train_trajectory_measurement_nullable_v2': mock_observer}):
    result, audit = capture_current(net, runner, obs['zone_buses'], conditioning)
prove('mock live capture uses original-getter interface and exact compiler', result == torch.load(C / selected[0]['path'], weights_only=False)['model_input'])
rejects('unconverged current network rejected before capture', lambda: capture_current(SimpleNamespace(converged=False), runner, obs['zone_buses'], conditioning))
changed = copy.deepcopy(obs)
changed['global_metrics']['vmean'] += .001
with patch.dict(sys.modules, {'train_trajectory_measurement_nullable_v2': mock_observer}), patch.object(mock_observer, 'observation', side_effect=[copy.deepcopy(obs), changed]):
    rejects('state change during capture detected', lambda: capture_current(net, runner, obs['zone_buses'], conditioning))
runner.rescue.Q_SWEEP = [25.]
rejects('changed original Q grid rejected before capture', lambda: capture_current(net, runner, obs['zone_buses'], conditioning))

summary = {'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'evidence_kind': 'saved_input_and_mock_capture_software_only',
    'checks': checks, 'checks_passed': len(checks), 'all_passed': True,
    'saved_input_selection': 'first three ascending observation SHA identities; no outcome access',
    'selected_saved_identities': sorted(wanted), 'saved_input_audits': audits,
    'actual_model_forward_optimizer_PF_controller_cloud_calls': 0,
    'fresh_real_live_observations': 0,
    'prior_fixture_failures_preserved': ['fresh_observation_bridge_software/owner.claim', 'fresh_observation_bridge_software_v2/owner.claim'],
    'prior_fixture_failure_reason': 'torch-only environment lacks pandas; early validation now precedes physical observer import; no model/PF calls occurred',
    'no_learning_or_physical_performance_or_rollout_authorization_claim': True,
    'workflow_seconds': time.perf_counter() - started,
    'new_sources': {p.name: sha(p) for p in (ROOT/'work/relational_fresh_observation_bridge.py', ROOT/'work/verify_relational_fresh_bridge_software.py')},
    'frozen_compiler_sources': {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in (
        ROOT/'work/relational_current_state_codec.py', ROOT/'work/relational_neural_input_v2.py',
        ROOT/'work/train_trajectory_measurement_nullable_v2.py', ROOT/'work/e/audit/phase2g_rescue_runner.py')},
    'OPT_conditioning_sha256': sha(C/'OPT_Input_Conditioning.json'),
}
write(OUT/'Software_Readiness.json', summary)
for source in (ROOT/'work/relational_fresh_observation_bridge.py', ROOT/'work/verify_relational_fresh_bridge_software.py'):
    (OUT/source.name).write_bytes(source.read_bytes())
write(OUT/'Scientific_Manifest.json', {p.name: {'bytes':p.stat().st_size, 'sha256':sha(p)} for p in OUT.iterdir() if p.is_file() and p.name != 'owner.claim'})
seal(OUT, {p.name:p for p in OUT.iterdir() if p.is_file() and p.name != 'owner.claim'}, 'Software_Only_Evidence.zip')
write(OUT/'status.json', {'stage':'complete_software_only', 'all_passed':True})
print(json.dumps({'checks_passed':len(checks), 'actual_model_PF_cloud_calls':0, 'fresh_real_observations':0, 'workflow_seconds':summary['workflow_seconds']}))
