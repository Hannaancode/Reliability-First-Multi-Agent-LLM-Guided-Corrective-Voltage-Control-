"""Create separately identified prototype dispatch extension; preserve original."""
from pathlib import Path
import ast,hashlib
ROOT=Path(__file__).resolve().parent
source=ROOT/'value_closed_loop_cpu.py';destination=ROOT/'value_coverage_closed_loop_cpu.py'
old=source.read_text();original_sha=hashlib.sha256(source.read_bytes()).hexdigest()
old_import='from value_candidate_ordering import universe, order'
old_guard="if policy not in ('frozen_enumeration', 'lowest_voltage', 'seeded_random'):"
assert old.count(old_import)==1 and old.count(old_guard)==1 and not destination.exists()
new=old.replace(old_import,'from value_candidate_ordering import universe\nfrom value_diverse_candidate_ordering import order').replace(old_guard,"if policy not in ('frozen_enumeration', 'lowest_voltage', 'seeded_random', 'bus_first_voltage'):")
new=new.replace('Only the three no-model ordering controls are currently wired.','The three existing no-model controls plus bus-first coverage are wired here.').replace('This is new development software, not a recovered original runner or D-SE.','Separately identified coverage-dispatch development clone; original remains unchanged.').replace("'Learned closed-loop inference is not wired or validated'","'Unknown policy; learned closed-loop inference remains unwired'")
ast.parse(new);destination.write_text(new)
assert hashlib.sha256(source.read_bytes()).hexdigest()==original_sha
print('SEPARATE_COVERAGE_PROTOTYPE_CREATED',flush=True)
