"""Independent exact-source/menu/necessary-component scope gate, no PF."""
import copy,gzip,hashlib,json,pickle,zlib
from pathlib import Path
from next_ordinary_query_core_20261019 import B,I,helpers,known_keys
from public118_slsqp_native_20261018 import R,read,put,sha
from frozen_physics_loader import load_stack
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component

def certify():
    info=read(I/'Exact_Candidate_Inputs.json');assert info['status']=='PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE'
    for rel,h in info['evidence_sha256'].items():assert sha(R/rel)==h
    assert sha(I/'Exact_Current_Input.zlib')==info['input_state_sha256'];state=helpers(__file__)['input_state']()
    ref=info['source_frontier'];base=R/info['source_screen'];encoded=(base/ref['path']).read_bytes();assert hashlib.sha256(encoded).hexdigest()==ref['encoded_sha256'];raw=zlib.decompress(encoded);assert hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];original=pickle.loads(raw)
    from strict_saved_native_input_match_v2_20261018 import require_same
    require_same(state['net'],original['net']);assert state['cursor']==original['cursor']
    _,runner,_=load_stack();assert runner.rescue.grid_metrics(state['net'])==info['current_metrics'];point=point_key(state['net'],state['cursor']);assert point==info['point']
    item=info['exact_new_query_rows'][0];key=point+'|'+action_key(item['row']);assert key==original['key']==item['point_action_key'] and key not in known_keys()
    _,actuate,native=build_verifier(runner.rescue,state['cursor']);assert native==info['native_verifier_certificate'] and native['reverse_AST_exact']
    candidate=actuate(copy.deepcopy(state['net']),action(item['row']));h,values=component(candidate);assert h==independent_component(candidate)==item['component_sha256'] and values==item['perbus_rational_component']
    for rel in ['outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz','outputs/fresh_static_component_index_20261018/All_Static_Component_References.json.gz']:
        assert not json.loads(gzip.decompress((R/rel).read_bytes())).get(h)
    assert all(info[k]==0 for k in ['tracked60426_component_matches','static3418_component_matches','recent26_component_matches'])
    result={'status':'PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE','exact_candidate_keys':[key],'input_preparation_sha256':sha(I/'Exact_Candidate_Inputs.json'),'reader_source_sha256':sha(__file__),
        'exact_rows':[item],'native_verifier_certificate':native,'evidence_sha256':{**info['evidence_sha256'],str((I/'Exact_Candidate_Inputs.json').relative_to(R)):sha(I/'Exact_Candidate_Inputs.json'),str((I/'Exact_Current_Input.zlib').relative_to(R)):sha(I/'Exact_Current_Input.zlib')},
        'limits':'Independent source/input/rational component equality and closed-index lookups.26recent BEFORE comparisons are source producer evidence pinned here; no universal history claim or standalone execution permission.','new_scientific_calls':0}
    put(B/'Attempt_Coverage_Certificate.json',result);return result

if __name__=='__main__':print(json.dumps({'coverage':certify()['status']}))
