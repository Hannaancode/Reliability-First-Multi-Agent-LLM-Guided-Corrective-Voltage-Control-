"""Check only the newly combined indexed identity/observer integration.

No repeats of the old scientific or software owners. Original saved boundary
outputs are reused as references; new wrapper paths are exercised once.
"""
import ast
from reflection118_remaining_cases_v2_core_20261023 import *

def main():
    O=TOP/'integration';O.mkdir(exist_ok=False);began=time.monotonic()
    put(O/'Protocol.json',dict(fixed_cases=[1,2,3],expected='Exact previously saved causal first messages; distinct fixed load/outage domains; known returned/failed/derived receipts preserve outcome',new_scientific_calls_allowed=0,no_allocation=True,source_sha256=sha(__file__)))
    np,pp,v2,runner,reflection=setup()
    def forbidden(*a,**k):raise OperationalStop('NEW_INTEGRATION_FORBIDS_MODEL_PF_NATIVE_INPUT_PREPARATION')
    pp.runpp=forbidden
    import pandapower.run as unused
    import importlib
    native_module=importlib.import_module('pandapower.run');native_module.runpp=forbidden
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    from run_reflection118_chronological_local_20261022 import necessary
    base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'));zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    reference=R/'outputs/reflection118_remaining_cases_preparation_20261023/integration';cases=[];domains=[]
    for i in [1,2,3]:
        b=bindings[i];root=net_value(pickle.loads((R/b['solved_payload']).read_bytes()));domains.append(necessary(root));seen=[];calls=[]
        def physical(net,**kw):
            assert not calls and kw==b['solver_kwargs'];restore_exact(net,root);calls.append(True)
        def model(messages):seen.append(messages);raise PaidBoundary('BEFORE_ANY_NEW_MODEL_APPLICATION')
        seed=read(TOP/f'case_{i:02d}'/'Frozen_Engineering_Protocol.json')['seed'];random.seed(seed);np.random.seed(seed)
        try:run_original(v2,runner,reflection,read(R/b['registration']['recipe']),base,zones,model,physical)
        except PaidBoundary:pass
        else:raise AssertionError('Missing original causal model boundary')
        ref=read(reference/f'case_{i:02d}_First_Actual_Source_Messages.json')
        assert calls==[True] and seen==[ref['messages']]
        cases.append(dict(case_index=i,case_id=b['case_id'],prior_boundary_reference_sha256=sha(reference/f'case_{i:02d}_First_Actual_Source_Messages.json'),new_observer_provider_integration_exact=True,causal_context_tokens=len(ref['input_token_ids'])))
    assert len({canonical(d) for d in domains})==3
    fixture=read(reference/'Fixture_Lazy_Registry.json');d=R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023';rec=read(d/'Mapped_Receipt.json')
    from prior_physical_query_footprints_20261018 import component
    net=saved_net(d,rec['before']);key=component(net)[0]+':'+hashlib.sha256(canonical(necessary(net))).hexdigest()
    fixture['rows'].append(dict(resource_key=key,directory=d.relative_to(R).as_posix(),source=(d/'Mapped_Receipt.json').relative_to(R).as_posix(),source_sha256=sha(d/'Mapped_Receipt.json'),before=rec['before'],after=rec['after'],kwargs=rec['kwargs'],exception=None))
    put(O/'New_Combined_Registry_Fixture.json',fixture);reg=ClosedPaidRegistry(O/'New_Combined_Registry_Fixture.json',O/'forbidden_new_identity_proof');checks=[]
    for row in fixture['rows']:
        n=saved_net(R/row['directory'],row['before']);paid,exc,provenance=reg.lookup(n,row['kwargs']);assert paid is not None and exc==row['exception']
        frames_equal(paid,saved_net(R/row['directory'],row['after']));checks.append(provenance['kind'])
    assert reg.preparation_costs['native_input_attempts']==0 and not (O/'forbidden_new_identity_proof').exists()
    for path in ['run_reflection118_remaining_v2_local_20261023.py','audit_reflection118_remaining_v2_case_20261023.py','run_reflection118_remaining_v2_colab_20261023.py','coordinate_reflection118_remaining_v2_cases_20261023.py']:
        ast.parse((R/'work'/path).read_text('utf-8'))
    put(O/'New_Integration_Readiness.json',dict(status='PASS_NEW_ALL3_COMBINED_CAUSAL_OBSERVER_AND_INDEXED_RECEIPT_PATHS',cases=cases,distinct_fixed_load_outage_domains=True,known_return_failure_derived_paths=checks,new_model_PF_preparation_optimizer_allocations=0,workflow_seconds=time.monotonic()-began,allocation_ready=False,remaining='Closed incremental index and final source/input/reader/payload locks'))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(status='PASS_ALL3_NEW_COMBINED_INTEGRATION',new_scientific_calls=0)))
if __name__=='__main__':main()
