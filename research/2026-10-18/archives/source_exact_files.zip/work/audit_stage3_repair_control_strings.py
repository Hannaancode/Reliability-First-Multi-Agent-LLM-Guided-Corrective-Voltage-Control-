"""Parse every generated control string locally before touching owned runtime."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
ROOT=Path(__file__).resolve().parents[1];target=ROOT/'work/repair_stage3_same_assignment_launch.py'
source=target.read_text();prior=hashlib.sha256(target.read_bytes()).hexdigest()
# Avoid nested backslash quoting in the generated hash-verification command.
old="name.replace('\\\\','/')";assert source.count(old)==1
source=source.replace(old,"name.replace(chr(92),'/')")
preserved=ROOT/'work/repair_stage3_same_assignment_launch_prepared_v1.py';assert not preserved.exists();preserved.write_text(target.read_text())
target.write_text(source)
tree=ast.parse(source);namespace={}
for name in ['verification','wrapper','launch']:
    assignment=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
    value=eval(compile(ast.Expression(assignment.value),'<generated control string>','eval'),{'repr':repr},namespace)
    ast.parse(value);namespace[name]=value
OUT=ROOT/'outputs/llm_value_stage3_development'
with (OUT/'Prepared_Control_Repair_Launch_String_Audit.json').open('x') as f:json.dump({
 'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_three_generated_code_strings_parse':True,
 'prepared_v1_preserved_source_sha256':prior,'actual_final_control_repair_source_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
 'generated_code_sha256':{n:hashlib.sha256(v.encode()).hexdigest() for n,v in namespace.items()},
 'new_model_calls':0,'new_PF_calls':0,'new_allocation_requests':0,'scientific_driver_protocol_source_changed':False},f,indent=2)
print('ALL_THREE_EXACT_GENERATED_CONTROL_STRINGS_AST_VALIDATED')
