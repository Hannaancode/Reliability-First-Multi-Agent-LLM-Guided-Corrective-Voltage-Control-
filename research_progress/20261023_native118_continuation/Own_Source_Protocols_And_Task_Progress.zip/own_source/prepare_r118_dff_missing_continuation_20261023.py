"""Freeze ALL4 native trajectories before entering any new physical input."""
import ast
from datetime import datetime,timezone
from r118_dff_missing_continuation_core_20261023 import *

def main():
    # A failed saved-only metadata admission may be repaired before a protocol
    # exists. Its failure receipt stays in the preparation directory.
    P.mkdir(exist_ok=True);assert not (P/'Protocol.json').exists();began=time.monotonic()
    np,pp,v2,runner,reflection=setup()
    def forbidden(*a,**k):raise BaseException('PREPARATION_FORBIDS_MODEL_AND_PF')
    pp.runpp=forbidden
    assert runner.MAX_ITERATIONS==25 and runner.rescue.HARD_OV==1.06 and runner.rescue.MAX_ABS_Q_PER_BUS==450.
    assert runner.rescue.Q_SWEEP==[25.,50.,75.,100.,125.,150.,200.,250.,300.]
    bindings='outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json'
    cursors='outputs/r118_source_first_commit_reconstruction_v2_20261022'
    certificate=read(R/cursors/'Verified_First_Commit_And_Continuation_Gates.json')
    assert certificate['status'].startswith('PASS_ALL4') and len(certificate['cases'])==4
    assert all(r['remaining_original_operations']==24 for r in certificate['cases'])
    prior=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json')
    rows=read(R/bindings);assert [r['case_id'] for r in rows]==prior['case_order']
    receipts=current_receipts();registry=Registry(receipts,include_history=False)
    # Exercise new registry's actual saved-return and failed-return branches,
    # serialization and a changed action, without re-running any solver.
    checks=[]
    for binding in rows:
        root=net_value(pickle.loads((R/binding['solved_payload']).read_bytes()))
        test=copy.deepcopy(root);runner.rescue.apply_action(test,{'add_shunts_q_mvar':{'95':300.}})
        kwargs={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True}
        saved,exc,provenance=registry.lookup(test,kwargs);assert saved is not None and exc is None
        state=pickle.loads(zlib.decompress((R/cursors/(binding['case_id']+'_cold.zlib')).read_bytes()))
        frames_equal(saved,state['net']);assert np.array_equal(saved.res_bus.vm_pu.to_numpy(),state['net'].res_bus.vm_pu.to_numpy())
        packet=capsule(P/(binding['case_id']+'_Registry_Receipt.zlib'),dict(before=test,after=saved,kwargs=kwargs,provenance=provenance))
        cold=decode(P,packet);frames_equal(cold['before'],test);frames_equal(cold['after'],saved)
        bad=copy.deepcopy(test);bad.load.at[bad.load.index[0],'p_mw']+=.125
        assert registry.key(test)!=registry.key(bad)
        checks.append(dict(case_id=binding['case_id'],first_chosen_commit_input_exact=True,saved_receipt_equals_source_cursor=True,changed_load_excluded=True,serialized_cold_receipt_exact=True))
    failed=[r for r in receipts if r['exception'] is not None and r['after'] is not None and r['kwargs'] is not None]
    assert failed
    f=failed[0];_,exc,prov=Registry([f],include_history=False).lookup(saved_net(f['directory'],f['before']),f['kwargs'])
    assert exc is not None and prov['kind']=='PAID_FAILED_INPUT_NO_RETRY'
    unknown=dict(f,after=None,kwargs=None,exception='UNRECOVERED')
    try:Registry([unknown],include_history=False).lookup(saved_net(f['directory'],f['before']),f['kwargs'])
    except OperationalStop:unknown_rejected=True
    else:raise AssertionError('An unrecovered prior input must stop before science')
    sources=[Path(__file__),R/'work/r118_dff_missing_continuation_core_20261023.py',R/'work/run_r118_dff_missing_continuation_20261023.py',R/'work/audit_r118_dff_missing_continuation_20261023.py',R/'work/coordinate_r118_dff_missing_continuation_20261023.py',R/'work/coordinate_f118_encoder_owner_20261022.py',R/'work/reflection118_chronological_core_20261022.py',R/'work/frozen_physics_loader.py',R/'work/run_reflection118_chronological_local_20261022.py',R/'work/prior_physical_query_footprints_20261018.py',R/'work/public_size_u61_preservation.py']
    for f in sources:ast.parse(f.read_text(encoding='utf-8'))
    pins={f.relative_to(R).as_posix():sha(f) for f in sources};pins.update(prior['original_serving_sources'])
    inputs=[bindings,cursors+'/Verified_First_Commit_And_Continuation_Gates.json','outputs/r118_first_round_missing_only_report_v2_20261022/Case_Summaries.json','outputs/r118_first_round_missing_only_execution_20261022/Result.json','outputs/r118_first_round_missing_only_independent_20261022/Independent_Audit.json','outputs/r118_remaining_native80_contracts_execution_20261022/Results.json','outputs/r118_remaining_native80_contracts_independent_20261022/Independent_Audit.json','outputs/reflection118_chronological_preparation_20261022/Additional_Prior_Attempt_References.json','outputs/original_role_remaining_native_history_scope_20261022/All_Saved_Snapshot_Components.json','outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz']
    for r in rows:
        inputs.extend([r['solved_payload'],r['registration']['recipe'],cursors+'/'+r['case_id']+'_cold.zlib'])
    protocol=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_ALL4_NEW_MISSING_ONLY_ORIGINAL_DFF_FULL_TRAJECTORIES',bindings=bindings,first_commit_cursors=cursors,base_net='work/e/pack/testbeds/federation_4mg_ieee118.json',metadata='work/e/pack/testbeds/federation_4mg_ieee118_metadata.json',source_hashes=pins,input_hashes={n:sha(R/n) for n in inputs},seed=prior['seed'],solver_kwargs=kwargs,science_seconds=7200,reader_seconds=7200,binary_bytes=8*1024**3,
        primary_question='Complete unchanged original DFF on ALL4 fixed severe development roots from already paid source-first-commit prefixes. Original25total/24remaining operations, full fallback menu, Q grid,450cap, native1.06 verifier, strict0.95/1.05 reporting and source tie ordering unchanged.',
        selection='All4 original source roots in registered order; no chosen successful case or outcome-selected menu. Future queries are generated only by the unchanged source controller at its actual causal current state.',
        reuse='Existing2034 first-menu outcomes and current chronological/Graph/contract attempts are included. Full60426/9297/738 named historical scope is checked before any unentered query. Same exact input/kwargs successful result reused; failed same-contract attempt reused as failure, never retried; unrecovered/different-contract or physical-component collision stops before new PF.',
        scoped_history_not_universal_notebook_knowledge=True,persistent_preservation='Exclusive before capsule and fsynced event reservation before each new native call; returned/failed NETs, record, hash chain, every source commitment NET/result/failed-signatures/RNG/call cursor/receipt registry/full costs/source/original absolute deadline. First source commitment must exactly match prior warm/cold cursor before new science.',
        independent_reader='One independently charged first replay of each NEW returned physical input only. Preserve failed calls; never replay old receipts. All8numeric result tables1e-10,KCL1e-7,continuous original source decisions and full commitment checkpoints. Partial-aware: only all4 complete endpoints can form all4 comparisons; missing trajectories UNKNOWN.',
        cost='All historical model/training/preparation/query/failure/replay costs remain separate paid obligations; cached reuse is not free original/deployment cost. New workflow/solver/storage/source-audit/replay costs recorded. No model/GPU/derivative/optimizer/training calls.',
        no_guaranteed_win_or_outcome_tuning=True,no_restart_old_owner_or_extend_old_budget=True,no_full_DSE_external_LLM_or_unused_confirmation_claim=True)
    put(P/'Protocol.json',protocol)
    for name,source,out,coord in [('Owner_Protocol.json','run_r118_dff_missing_continuation_20261023.py','r118_dff_missing_continuation_execution_20261023','r118_dff_missing_continuation_coordination_20261023'),('Reader_Owner_Protocol.json','audit_r118_dff_missing_continuation_20261023.py','r118_dff_missing_continuation_independent_20261023','r118_dff_missing_continuation_reader_coordination_20261023')]:
        path=R/'work'/source
        put(P/name,dict(single_owner=dict(source=path.relative_to(R).as_posix(),sha256=sha(path),python='work/vcsa_module_env/Scripts/python.exe',output='outputs/'+out,coordination='outputs/'+coord,bound_seconds=7500)))
    put(P/'Readiness.json',dict(status='PASS_PROSPECTIVE_ALL4_SOURCE_PREFIX_CURRENT_QUERY_REGISTRY_FAILURE_AND_COLD_GATES',cases=checks,current_receipt_or_reservation_count=len(receipts),existing_failed_inputs_never_retried=True,unknown_old_input_rejected=unknown_rejected,new_PF_model_calls=0,source_function_AST_unchanged=True,protocol_sha256=sha(P/'Protocol.json'),workflow_seconds=time.monotonic()-began))
    print(json.dumps(dict(status='FROZEN_READY',cases=4,current_receipts=len(receipts),new_science_in_preparation=0)))

if __name__=='__main__':main()
