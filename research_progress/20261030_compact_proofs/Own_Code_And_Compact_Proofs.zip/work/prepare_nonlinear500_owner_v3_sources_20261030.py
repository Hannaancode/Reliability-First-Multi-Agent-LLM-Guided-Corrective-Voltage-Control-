"""Prepare distinct v3 owner sources only; no freeze, owner or scientific call."""
from pathlib import Path
import ast,json,hashlib
R=Path(__file__).resolve().parents[1]
O=R/'outputs/nonlinear500_receding_acquisition_v3_source_preparation_20261030'

def main():
 O.mkdir(exist_ok=False)
 rows=[]
 for stem in ('run','audit','coordinate','freeze'):
  before=R/f'work/{stem}_nonlinear500_receding_acquisition_v2_20261030.py'
  after=R/f'work/{stem}_nonlinear500_receding_acquisition_v3_20261030.py'
  text=before.read_text(encoding='utf-8').replace('nonlinear500_receding_acquisition_v2_','nonlinear500_receding_acquisition_v3_')
  text=text.replace('nonlinear500_isolated_owner_runtime_20261030','nonlinear500_isolated_owner_runtime_v3_20261030')
  ast.parse(text)
  with after.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
  rows.append(dict(original=before.relative_to(R).as_posix(),original_sha256=hashlib.sha256(before.read_bytes()).hexdigest(),
   additive=after.relative_to(R).as_posix(),initial_additive_sha256=hashlib.sha256(after.read_bytes()).hexdigest()))
 before=R/'work/nonlinear500_isolated_owner_runtime_20261030.py'
 after=R/'work/nonlinear500_isolated_owner_runtime_v3_20261030.py'
 text=before.read_text(encoding='utf-8').replace('work/nonlinear500_isolated_owner_runtime_20261030.py','work/nonlinear500_isolated_owner_runtime_v3_20261030.py')
 text=text.replace("'nonlinear500_receding_acquisition_v2_20261030'","'nonlinear500_receding_acquisition_v3_20261030'").replace('distinct v2','distinct v3')
 with after.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
 with (O/'Initial_Path_Only_Preparation.json').open('x',encoding='utf-8') as f:
  json.dump(dict(status='INITIAL_PATH_ONLY_DRAFT_MISSING_V2_FAILURE_AND_HOST_GATES_NO_FREEZE_NO_LAUNCH',rows=rows,
   original_runtime_helper_sha256=hashlib.sha256(before.read_bytes()).hexdigest(),scientific_calls=0),f,indent=2)
if __name__=='__main__':main()
