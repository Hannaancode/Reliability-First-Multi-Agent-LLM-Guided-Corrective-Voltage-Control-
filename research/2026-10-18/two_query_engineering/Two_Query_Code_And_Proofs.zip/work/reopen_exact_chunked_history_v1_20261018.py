"""Exact latest-anchor append, separate from historical read-only prefixes."""
import hashlib
from pathlib import Path
from bounded_chunk_evidence_store_v1_20261015 import Store,restore,location,ROOT
from paid_receding_chunked_history_v2_20261018 import History,verify_history
def reopen_latest_history(anchor):
    records=verify_history(anchor);blocks=restore(anchor);root=location(ROOT/anchor['path'])
    actual=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
    if actual!=anchor['committed_physical_bytes']:raise ValueError('Orphan/torn storage is preserved; no live append or guessed repair')
    store=Store.__new__(Store);store.root=root;store.source=anchor['source_anchor'];store.input=anchor['input_anchor'];store.bound=anchor['max_total_bytes']
    store.last=anchor['last_record_sha256'];store.ids={b['event_id'] for b in blocks};store.count=anchor['records'];store.used=actual
    store.prefix=hashlib.sha256((root/'index.bin').read_bytes());store.stream=(root/'index.bin').open('ab')
    history=History.__new__(History);history.store=store;history.source=anchor['source_anchor'];history.input=anchor['input_anchor']
    history.previous=anchor['logical_last_record_sha256'];history.count=len(records)
    return history
