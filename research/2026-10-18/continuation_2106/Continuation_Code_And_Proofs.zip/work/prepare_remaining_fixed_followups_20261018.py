"""Exact remaining originalK4 followups; zero science and no launch authority.

Selection is proven identical to the menu saved BEFORE today's physical
outcomes, not a new Q/width/seed/threshold sweep.
"""
import copy,gzip,hashlib,json,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from exact_two_paid_query_engineering_20261018 import I as ORIGINAL,B as TWO
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from strict_saved_native_input_match_v2_20261018 import require_same
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
from lazy_paid_lineage_receipts_v1_20261018 import ArchivedLineage
B=R/'outputs/remaining_fixed_followup_preparation_20261018'
SCREEN=R/'outputs/unstarted_paid_suffix_new_receipts_v3_20261018'

def selected_menu(path,parent):
    matches=[]
    with path.open('rb') as f:
        for raw in f:
            e=json.loads(raw)
            if e['event']=='second_causal_context_and_forecasts' and e['data']['parent']==parent:matches.append(e['data'])
    assert len(matches)==1;return matches[0]

def main():
    B.mkdir(exist_ok=False);leg=read(SCREEN/'Leg_1.json');ref=leg['frontier_input'];encoded=(SCREEN/ref['path']).read_bytes()
    assert hashlib.sha256(encoded).hexdigest()==ref['encoded_sha256'];raw=zlib.decompress(encoded);assert len(raw)==ref['raw_bytes'] and hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];front=pickle.loads(raw)
    old=pickle.loads(zlib.decompress((ORIGINAL/'Exact_Current_Input.zlib').read_bytes()));require_same(front['net'],old['net']);assert front['cursor']==old['cursor']
    data=read(ORIGINAL/'Exact_Candidate_Inputs.json');parent=front['parent'];assert parent==data['parent_handle']
    menu=selected_menu(SCREEN/'scientific.jsonl',parent)
    prior=R/'outputs/unstarted_paid_suffix_support_screen_numeric_v2_20261018/scientific.jsonl';oldmenu=selected_menu(prior,parent)
    assert menu['selected_ids']==oldmenu['selected_ids'] and menu['rows']==oldmenu['rows'] and menu['context_identity']==oldmenu['context_identity']
    archive=ArchivedLineage();paid={x['point_action_key'] for x in data['exact_new_query_rows']};point=point_key(old['net'],old['cursor']);assert point==data['point']
    rows={action_key(row):{k:row[k] for k in ('kind','receiver','q','donor_index','donor_bus','universe_index')} for row in menu['rows']}
    _,runner,_=load_stack();_,actuate,certificate=build_verifier(runner.rescue,old['cursor']);remaining=[];all4=[]
    base=R/'outputs/prior_physical_query_footprints_20261018/actual';file=base/'Physical_Component_Input_References.json.gz'
    expected=read(base/'Closed_Manifest.json')['members'][file.name];expected=expected['sha256'] if isinstance(expected,dict) else expected
    assert sha(file)==expected;index=json.loads(gzip.decompress(file.read_bytes()))
    for rank,aid in enumerate(menu['selected_ids'],1):
        row=rows[aid];key=point+'|'+aid;status='KNOWN_OLD_PAID' if key in archive.index else 'NEW_TWO_QUERY_ALREADY_PAID' if key in paid else 'UNEXECUTED_IN_TRACKED_EXACT_KEY_LINEAGE'
        item={'fixed_rank':rank,'row':row,'point_action_key':key,'status':status};all4.append(item)
        if status=='UNEXECUTED_IN_TRACKED_EXACT_KEY_LINEAGE':
            native=actuate(copy.deepcopy(old['net']),action(row));h,values=component(native);assert independent_component(native)==h
            item={**item,'physical_component_sha256':h,'perbus_rational_component':values,'tracked_prior_component_matches':len(index.get(h,[])),
                'prior_component_references':index.get(h,[]),'new_science_permission':'NONE_PENDING_FRESH_OBSERVED_SCOPE_AND_NEW_PROSPECTIVE_OWNER_SOURCE_READER_PRESERVATION_PROTOCOL'}
            remaining.append(item)
    assert remaining and remaining[0]['point_action_key']==front['key']
    put(B/'Exact_Remaining_Followups.json',{'status':'PREPARED_EXACT_ORIGINAL_K4_REMAINING_INPUTS_NOT_PF_PERMISSION','point':point,'parent':parent,
        'context_identity':menu['context_identity'],'all4_original_order':all4,'all_remaining_ordered_identities':remaining,
        'pre_existing_menu_before_new_physics_sha256':sha(prior),'new_receipt_screen_journal_sha256':sha(SCREEN/'scientific.jsonl'),
        'current_input_reference':{'path':str((ORIGINAL/'Exact_Current_Input.zlib').relative_to(R)),'sha256':sha(ORIGINAL/'Exact_Current_Input.zlib')},
        'source_native_verifier_certificate':certificate,'source_actual_current_UV':runner.rescue.grid_metrics(old['net'])['uv_count'],
        'causal_role':'Hypothetical paid query AFTER at17UV; actual graph root remains23UV, no new commit/complete policy outcome.',
        'no_outcome_retune':'Same original native9Q/full universe/K4/order/context/score/actions/scope/resources/guard as before first new query. No more/fewer/favorable Qs chosen.',
        'new_scientific_calls':0})
    manifest(B);print(json.dumps({'remaining_exact_original_followups':len(remaining),'tracked_component_hits':[v['tracked_prior_component_matches'] for v in remaining],'new_science':0,'permission':'NOT_READY'}))
if __name__=='__main__':main()
