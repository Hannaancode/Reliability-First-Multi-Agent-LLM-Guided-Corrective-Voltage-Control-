"""Prospective causal read-only support screen, not new physical trajectories.

All five originally unstarted suffixes, fixed policies/25ops/cap/raw scopes.
Import independently verified old first decisions rather than repeat them.
Only queried, exactly matched observed paid successors can be traversed. Stop
UNKNOWN at the first required missing receipt/context/forecast; never simulate
an unobserved AFTER, score a partial menu as complete or perform new science.
"""
import copy,gzip,hashlib,json,os,pickle,time,zlib
from pathlib import Path
import numpy as np,pandapower as pp
import verified_paid_cache_engine_v2_20261018 as binding
from full_receding_paid_campaign_20261015 import R,B as OLD,read,put,sha,METHODS
from paid_receding_journal_reference_history_v2_20261018 import ReferencedHistory,ReceiptJournalIndex
from dynamic_actual_mask_guidance_v1 import current_inputs,identity
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from project_paid_joint_successor_v1 import project
from bounded_paid_lookahead_physics_20261014 import load_after
from frozen_physics_loader import load_stack
from lazy_paid_lineage_receipts_v1_20261018 import UnknownLineageIdentity
import paid_receding_referenced_commit_v2_20261018 as transport
B=R/'outputs/unstarted_paid_suffix_support_screen_20261018'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
class MissingPaidNumericalContext(BaseException):pass
class MissingPaidForecast(BaseException):pass
class SoftwareResourceStop(BaseException):pass
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();p=read(OLD/'Protocol.json')
    oldscope=read(R/'outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json')
    initialized={(d['world'],d['method']) for d in oldscope['initialized_branches']}
    legs=[(e,m) for e in p['endpoints'] for m in METHODS if (e['world'],m) not in initialized];assert len(legs)==5
    put(B/'Protocol.json',{'role':'FIVE_FIXED_UNSTARTED_SUFFIX_CAUSAL_PAID_OBSERVATION_GRAPH_SUPPORT_SCREEN',
        'source_sha256':sha(Path(__file__)),'bound_seconds':1800,'selection':'ALL five original declared uninitialized suffixes. The three already initialized source legs are retained as archived observations, including the unclosed but independently verified line36 UV0 prefix.',
        'fixed_methods':list(METHODS),'original_operation_allowance':25,'all_current_native9Q_common_AND_zone_scope':True,'cap450_no_refund':True,
        'new_science_allowed':False,'no_imputed_AFTER_or_partial_menu_decision':True,
        'imported_first_decisions':'Original independently audited all8 bounded first decisions, exact_source/plan/menu proof and independently verified paid dependencies. New complete changed-cache-path replay1576receipts also PASS.',
        'projection_role':'Only the original observed-paid-successor resource projection; NO new actual commits, fresh inference, continuous physical replay, missing old checkpoint or unused confirmation claim.',
        'decision_gates':'Stop each suffix UNKNOWN at first missing exact receipt/context/score; an observed-supported legal endpoint is a development graph result only. Original all4 fullphysical gate stays UNKNOWN. No new learning/physical campaign automatically follows.'})
    phash=sha(B/'Protocol.json');put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    forbidden=[]
    def forbid(*a,**k):forbidden.append(True);raise AssertionError('Read-only support screen cannot perform new science')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,forbid)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    reuse=R/'outputs/full_paid_numeric_reuse_separate_roles_v2_20261018';raw=(reuse/'All_Existing_Complete_Forecasts.json.gz').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==read(reuse/'Results.json')['forecast_index_sha256'];forecasts=json.loads(gzip.decompress(raw));contexts={}
    for ref in read(reuse/'All_Existing_Contexts.json'):
        assert sha(R/ref['path'])==ref['sha256']
        with np.load(R/ref['path'],allow_pickle=False) as z:c={k:z[k].copy() for k in z.files}
        assert identity(c)==ref['identity'];contexts[ref['identity']]=c
    def cached_context_only(net,cache,cost,event):
        current=current_inputs(net);ident=identity(current)
        if ident not in cache:raise MissingPaidNumericalContext(ident)
        c=cache[ident];assert all(np.array_equal(current[k],c[k]) for k in current)
        cost['exact_context_reuses']+=1;event('exact_context_reused',{'context':ident});return c,ident
    def no_forecast(row,c,before):raise MissingPaidForecast(identity(c)+'|'+action_key(row))
    binding.SourceEngine.decision.__globals__['compile_current']=cached_context_only
    binding.SourceEngine.decision.__globals__['forecast']=no_forecast
    registry=binding.VerifiedPaidUseRegistry(B/'verified_uses',runner=runner,zones=zones)
    class Evidence:
        def __init__(self):
            self.costs={'preservation_seconds':0.,'archived_receipt_verification_CPU_seconds':0.};self.previous='0'*64
            self.journal=(B/'scientific.jsonl').open('xb');self.pack=(B/'capsules.bin').open('x+b');self.index=ReceiptJournalIndex(B/'scientific.jsonl',protocol_sha256=phash)
        def admit(self):
            if time.perf_counter()-started>=1800:raise SoftwareResourceStop('Fixed read-only screen bound; no extension')
        def event(self,name,data):
            t=time.perf_counter();offset=self.journal.tell();raw=canon({'event':name,'data':data,'protocol_sha256':phash,'previous_sha256':self.previous})+b'\n'
            self.journal.write(raw);self.journal.flush();os.fsync(self.journal.fileno());self.previous=hashlib.sha256(raw[:-1]).hexdigest()
            if name=='every_query_receipt_closed_before_more_science':self.index.observe_closed_durable_query(offset,raw)
            self.costs['preservation_seconds']+=time.perf_counter()-t
    evidence=Evidence();history=ReferencedHistory(B/'history',source_anchor=sha(Path(__file__)),input_anchor=phash,max_bytes=256*1024**2,query_index=evidence.index)
    class ReadOnlyEngine(binding.SourceEngine):
        def certified_cached_record(self,node,row,key):
            evidence.admit();record=registry.lookup(node,row,key)
            evidence.costs['archived_receipt_verification_CPU_seconds']+=record['verified_use_reference']['actual_verification_CPU_seconds']
            return record
    cost={'public_derivative_attempts':0,'public_derivative_returns':0,'LU_factor_attempts':0,'LU_factor_returns':0,'LU_solve_attempts':0,'LU_solve_returns':0,
        'RHS_columns':0,'compile_seconds':0.,'exact_context_reuses':0,'exact_paid_forecast_reuses':0,'new_forecasts':0}
    (B/'contexts').mkdir();engine=ReadOnlyEngine(out=B,evidence=evidence,runner=runner,zones=zones,cache=registry.cache,blocked=set(),contexts=contexts,numeric_cost=cost,history=history,paid_forecasts=forecasts)
    oldbounded=R/'outputs/bounded_paid_lookahead_physics_20261014/actual';firsts=[read(oldbounded/f'Branch_{i}.json') for i in range(1,9)]
    prior=read(R/'outputs/receding_durable_engine_independent_audit_20261015/Independent_Warm_Engine_Audit.json');assert prior['checked_decisions']==8 and prior['checked_ordered_query_messages']==12872
    results=[];global_stop=False
    for number,(entry,mode) in enumerate(legs,1):
        net,oldcursor,_=load_endpoint(entry);cursor=transport.initialize(net,build_current_domain(net,oldcursor,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
        original_metrics=runner.rescue.grid_metrics(net);branch=next(d for d in firsts if (d['world'],d['method'])==(entry['world'],mode))
        item={'world':entry['world'],'method':mode,'initial_metrics':original_metrics,'projection_trace':[],
            'imported_first_decision_paid_costs':branch['attributed_costs'],'fresh_model_PF_actual_commit_calls':0}
        chosen=branch['plan']['selected']
        if chosen is not None:
            msg=next(m for m in branch['query_messages'] if m['parent']==branch['root'] and m['aid']==chosen['first'])
            sourcekey=point_key(net,cursor)+'|'+action_key(msg['row']);rec=registry.archive.archived_receipt(sourcekey)
            assert rec['verdict']==msg['record']['verdict'] and rec['original_score']==msg['record']['original_score']
            target=load_after(rec['after_reference'],evidence.pack)['net'];cursor=project(net,target,cursor,msg['row'],rec,runner=runner,zones=zones);net=target
            item['projection_trace'].append({'role':'IMPORTED_INDEPENDENTLY_VERIFIED_FIRST_DECISION_NOT_RERUN','row':msg['row'],'paid_source_key':sourcekey,
                'after_reference':rec['after_reference'],'metrics':runner.rescue.grid_metrics(net),'remaining_operations':cursor['remaining_original_device_operation_slots']})
        step=1
        try:
            while True:
                evidence.admit();metrics=runner.rescue.grid_metrics(net)
                if metrics['uv_count']==0:item['status']='SUPPORTED_OBSERVED_GRAPH_ZERO_UV';break
                if cursor['remaining_original_device_operation_slots']==0:item['status']='SUPPORTED_OBSERVED_GRAPH_OPERATION_LIMIT';break
                report=engine.decision(net,cursor,entry['world'],mode,step);selected=report['plan']['selected']
                if selected is None:item['status']='SUPPORTED_COMPLETE_DECLARED_MENU_NO_SAFE_FIRST';break
                message=next(m for m in report['query_messages'] if m['parent']==report['root'] and m['aid']==selected['first'])
                node=report['resolve_paid_state'](message['successor']);cursor=node['cursor'];net=node['net']
                item['projection_trace'].append({'role':'COMPLETE_CAUSAL_OBSERVED_GRAPH_FIRST_ONLY_PROJECTION_NOT_ACTUAL_COMMIT','row':message['row'],
                    'paid_source_key':point_key(net,cursor),'after_reference':message['record']['after_reference'],'metrics':runner.rescue.grid_metrics(net),
                    'remaining_operations':cursor['remaining_original_device_operation_slots'],'attributed_query_costs':report['attributed_costs']})
                step+=1
        except (UnknownLineageIdentity,MissingPaidNumericalContext,MissingPaidForecast,SoftwareResourceStop) as exc:
            reason=type(exc).__name__;item['status']='UNKNOWN_'+reason;item['missing_identity']=str(exc)
            trace=exc.__traceback__;frame=None
            while trace:
                loc=trace.tb_frame.f_locals
                if trace.tb_frame.f_code.co_name in ['query','make_menu'] and 'node' in loc:frame=loc
                trace=trace.tb_next
            if frame is not None:
                node=frame['node'];payload={'net':node['net'],'cursor':node['cursor'],'source_paid_projection_not_actual_commit':True,
                    'kind':reason,'row':frame.get('row'),'key':frame.get('key'),'parent':frame.get('parent'),'context':frame.get('context')}
            else:payload={'net':net,'cursor':cursor,'source_paid_projection_not_actual_commit':True,'kind':reason}
            packet=pickle.dumps(payload,protocol=5);name=f'Frontier_{number}.zlib';encoded=zlib.compress(packet,6)
            with (B/name).open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
            item['frontier_input']={'path':name,'raw_sha256':hashlib.sha256(packet).hexdigest(),'encoded_sha256':hashlib.sha256(encoded).hexdigest(),'raw_bytes':len(packet)}
            if reason=='SoftwareResourceStop':global_stop=True
        item['latest_supported_metrics']=runner.rescue.grid_metrics(net);item['remaining_original_operations']=cursor['remaining_original_device_operation_slots']
        item['completed_supported_steps_including_imported_first']=len(item['projection_trace']);results.append(item);put(B/f'Leg_{number}.json',item)
        if global_stop:break
    assert not forbidden and all(cost[k]==0 for k in ['public_derivative_attempts','LU_factor_attempts','LU_solve_attempts','new_forecasts'])
    history.close();registry.close();evidence.journal.close();evidence.pack.close()
    put(B/'Results.json',{'status':'CLOSED_READONLY_SUPPORT_SCREEN_WITH_EXPLICIT_SUPPORTED_OR_UNKNOWN_LEGS','all_original_unstarted_legs':[(e['world'],m) for e,m in legs],
        'legs':results,'unexecuted_screen_legs':[(e['world'],m) for e,m in legs[len(results):]],'numeric_costs':cost,'actual_CPU_verification_preservation_costs':evidence.costs,
        'old_full_four_world_physical_gate':'UNKNOWN','new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Observed transition graph replay/projections only. No actual new commits, continuous independent physics replay, complete new physical trajectory, fresh LLM contribution, unused confirmation or scientific launch permission. Unsupported never means negative.'})
    put(B/'Closed_Manifest.json',{'members':{str(x.relative_to(B)):sha(x) for x in B.rglob('*') if x.is_file()},'new_science':0})
    print(json.dumps({'paid_suffix_screen':'CLOSED','legs':[(x['world'],x['method'],x['status']) for x in results],'new_science':0}))
if __name__=='__main__':main()
