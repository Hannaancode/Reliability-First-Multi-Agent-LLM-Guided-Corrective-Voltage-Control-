"""Source-native saved-feedback transition/cursor engineering, zero new PF.

Four already paid first-query after-states are used as labelled hypothetical
policy prefixes. No new physical commitment or full episode is claimed.
"""
import copy,json,pickle,sys,time
from pathlib import Path
from reflection118_chronological_core_20261022 import *
O=R/'outputs/published_graph118_paid_transition_20261022'
def main():
    O.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np,pandas as pd,pandapower as pp
    def forbidden(*a,**k):raise BaseException('SAVED_TRANSITION_ENGINEERING_FORBIDS_PF_MODEL')
    pp.runpp=forbidden
    from published_graph118_backend_20261022 import Graph118Env,author_policy
    E=R/'outputs/published_graph118_first_queries_execution_20261022'
    audit=read(R/'outputs/published_graph118_first_queries_independent_20261022/Independent_Audit.json');assert audit['first_independent_PF_replays']==4
    semantics=read(R/'outputs/published_graph118_environment_source_20261022/compatible_archived/Compatible_Source_Semantics.json')
    assert semantics['action_cap_expression']=='2 * self.num_gens + 2 * self.num_shunts'
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    records=read(E/'Results.json')['rows'];Policy,astsha=author_policy(O);rows=[]
    for i,(binding,rec) in enumerate(zip(bindings,records)):
        assert binding['case_id']==rec['case_id'] and rec['exception'] is None
        root=pickle.loads((R/binding['solved_payload']).read_bytes())['net'];env=Graph118Env(root,O)
        hot=Policy(env=env,file_str='warm_'+str(i),random=False);hot.init_episode();first=int(hot.get_action([]))
        expected,action=env.apply_only(first);assert action==rec['action']
        saved=decode(E,rec['after'])['net'];frames_equal(expected,saved);assert saved.converged
        env.net=copy.deepcopy(saved);env.saw.net=env.net
        for j,(bus,devices) in enumerate(env.controls.items()):
            refs=[float(env.net[table].at[index,'vm_pu']) for table,index,_ in devices];assert all(v==refs[0] for v in refs)
            env.gen_obs_data.loc[j,'GenVoltSet']=refs[0]
        env.shunt_status_arr=np.asarray([int(bool(env.net.shunt.at[k,'in_service']) and int(env.net.shunt.at[k,'step'])==1) for k in env.shunts])
        gen_units=sum(len(devices) for devices in env.controls.values());cap=2*gen_units+2*env.num_shunts
        state=dict(net=copy.deepcopy(env.net),gen_obs_data=env.gen_obs_data.copy(),shunt_status=env.shunt_status_arr.copy(),
            agent_fields={k:copy.deepcopy(v) for k,v in vars(hot).items() if k!='env'},action_history=[first],action_count=1,absolute_native_action_cap=cap,
            root_anchor=binding['payload_sha256'],first_paid_receipt=rec['after'],author_AST_sha256=astsha,
            exact_env_source_sha256=semantics['source_sha256'])
        desc=capsule(O/f'cursor_{i:02d}.zlib',state);restored=decode(O,desc)
        cold_env=Graph118Env(restored['net'],O);cold_env.gen_obs_data=restored['gen_obs_data'];cold_env.shunt_status_arr=restored['shunt_status']
        cold=Policy(env=cold_env,file_str='cold_'+str(i),random=False);vars(cold).update(restored['agent_fields'])
        frames_equal(env.net,cold_env.net);pd.testing.assert_frame_equal(env.gen_obs_data,cold_env.gen_obs_data,check_exact=True)
        assert np.array_equal(env.shunt_status_arr,cold_env.shunt_status_arr) and restored['action_count']==1 and restored['absolute_native_action_cap']==cap
        next_hot=int(hot.get_action([first]));next_cold=int(cold.get_action(restored['action_history']));assert next_hot==next_cold and next_hot!=first
        assert env.saw.calls==1 and cold_env.saw.calls==0,'Cold must restore the initial static source graph, not recompute topology from a successor'
        rows.append(dict(case_id=binding['case_id'],paid_first_action=action,source_first_action_id=first,
            hypothetical_next_action_id=next_hot,hypothetical_next_action=env.decode(next_hot),
            cursor=desc,source_native_action_cap=cap,native_generator_units=gen_units,installed_binary_shunts=env.num_shunts,
            all_saved_NET_and_observations_exact=True,next_source_choice_warm_cold_exact=True,source_initial_graph_restored_without_rebuild=True,
            new_PF_model_or_commit_calls=0,successor_of_second_action='UNKNOWN_UNQUERIED'))
    put(O/'Saved_Transition_And_Cursor_Readiness.json',dict(status='PASS_ALL4_SAVED_FEEDBACK_SOURCE_CURSOR_AND_NEXT_CHOICE_ENGINEERING',rows=rows,
        author_policy_class_AST_sha256=astsha,compatible_environment_semantics_sha256=sha(R/'outputs/published_graph118_environment_source_20261022/compatible_archived/Compatible_Source_Semantics.json'),
        scope='Serialized object cold restoration in this CPU process. Not full fresh-process controller restart, new trajectory, actual commitment or performance.',
        native_horizon_is_not_our25_operation_budget=True,
        unresolved='Full process/cursor/ownership/attempt coverage/persistent/full-cost/independent reader gates before rollout. Source native controls and safety differ from HierGrid; native and shared-role comparisons must be labelled.',
        actual_new_PF_model_training_commit_calls=0,full_policy_performance_ready=False,source_sha256=sha(__file__),workflow_seconds=time.monotonic()-start))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(all4_saved_transitions='PASS',native_action_caps=[r['source_native_action_cap'] for r in rows],new_scientific_calls=0,full_policy_ready=False)))
if __name__=='__main__':main()
