"""Source-native100step episode suffix, persistent cold state and charged independent replay."""
import copy,hashlib,json,os,pickle,time,random
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020';PREP=ROOT/'outputs/stable_ddpg_native_episode_preparation_20261020';PRIMARY=ROOT/'outputs/stable_ddpg_native_episode_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def binary(p,v):
    with p.open('xb') as f:pickle.dump(v,f,protocol=5);f.flush();os.fsync(f.fileno())
def execute(out,mode):
    import stable_ddpg_native_bridge_20261020 as b
    np=b.np;torch=b.torch;pd=b.pd
    from pandapower.pypower.makeSbus import makeSbus
    from candidate_process_evidence_utils import frozen_checks
    start=time.monotonic();p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));deadline=start+p['worker_bound_seconds' if mode=='primary' else 'reader_bound_seconds']
    for f,h in p['sources'].items():assert sha(ROOT/'work'/f)==h
    for f,h in p['inputs'].items():assert sha(ROOT/f)==h
    costs={'checkpoint_load_attempts':0,'checkpoint_load_returns':0,'agent_policy_attempts':0,'agent_policy_returns':0,'cold_agent_policy_attempts':0,'cold_agent_policy_returns':0,'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'cached_paid_PF_views':0,'native_network_conversions':0,'optimizer_backward_training_LLM_GPU_calls':0}
    put(out/'Frozen_Before.json',frozen_checks());torch.set_num_threads(1);torch.manual_seed(10);stream=(out/'Journal.jsonl').open('x',encoding='utf-8');prev='0'*64
    def event(kind,**data):
        nonlocal prev
        assert time.monotonic()<deadline
        if kind=='checkpoint_load_attempt':costs['checkpoint_load_attempts']+=1
        if kind=='checkpoint_load_return':costs['checkpoint_load_returns']+=1
        row={'kind':kind,'elapsed_seconds':time.monotonic()-start,'previous':prev,**data};h=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest();stream.write(json.dumps({'event':row,'sha256':h})+'\n');stream.flush();os.fsync(stream.fileno());prev=h
    try:
        env,proxy,_=b.environment();costs['native_network_conversions']+=1;models,_,_=b.load_three(env,event)
        if mode=='primary':
            cold_env,_,_=b.environment();costs['native_network_conversions']+=1;cold_models,_,_=b.load_three(cold_env,event)
        graph=np.load(ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz')
        oldresults=json.loads((OLD/'Result.json').read_text(encoding='utf-8'));cache={};known_input_kwargs={};receipts=[]
        def signature(net):
            h=hashlib.sha256()
            for name in ['bus','line','trafo','gen','sgen','load','ext_grid','shunt','switch']:
                h.update(name.encode());h.update(pd.util.hash_pandas_object(net[name],index=True).to_numpy().tobytes())
            return h.hexdigest()
        # Every old entry was independently physically verified; sharing is charged reuse,not new inference.
        for i in range(4):
            with (OLD/f'PF{i}_after.pkl').open('rb') as f:net=pickle.load(f)
            key=signature(net);kwargs={'algorithm':'bfsw'} if i==0 else {'algorithm':'bfsw','init':'dc'}
            cache[(key,json.dumps(kwargs,sort_keys=True))]={'net':net,'reference':f'oldPF{i}'};known_input_kwargs[key]=json.dumps(kwargs,sort_keys=True)
        context={};steps=[];endpoints=[]
        def tracked(net,*args,**kwargs):
            assert not args and kwargs=={'algorithm':'bfsw','init':'dc'}
            key=signature(net);kw=json.dumps(kwargs,sort_keys=True);identity=(key,kw)
            if key in known_input_kwargs and known_input_kwargs[key]!=kw:raise RuntimeError('ExactoldphysicalinputundernewinitializerUNKNOWN;no repeatedPF orsilent init substitution')
            if identity in cache:
                costs['cached_paid_PF_views']+=1;item=cache[identity];net.update(copy.deepcopy(item['net']));context['receipt']=item['reference'];event('paid_exact_PF_reuse',**context,physical_input_sha256=key);return
            index=costs['PF_attempts'];assert index<297;directory=out/'physics';directory.mkdir(exist_ok=True);before=directory/f'PF{index:03d}_before.pkl';binary(before,net)
            costs['PF_attempts']+=1;event('PF_attempt',**context,index=index,physical_input_sha256=key,before_sha256=sha(before),kwargs=kwargs);t=time.monotonic()
            try:b.pp.runpp(net,**kwargs)
            except BaseException as e:costs['PF_exceptions']+=1;event('PF_exception',**context,index=index,exception=type(e).__name__,seconds=time.monotonic()-t);raise
            costs['PF_returns']+=1;assert net.converged
            binary(directory/f'PF{index:03d}_after.pkl',net)
            ppc=net._ppc;assert np.array_equal(ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and ppc['baseMVA']==float(graph['baseMVA'])
            v=ppc['bus'][:,7]*np.exp(1j*np.deg2rad(ppc['bus'][:,8]));s=makeSbus(ppc['baseMVA'],ppc['bus'],ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert kcl<=1e-7
            arrays={name:net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float) for name in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};np.savez(directory/f'PF{index:03d}_fields.npz',**arrays)
            ref=f'newPF{index:03d}';cache[identity]={'net':copy.deepcopy(net),'reference':ref};known_input_kwargs[key]=kw;context['receipt']=ref
            receipts.append({'reference':ref,'physical_input_sha256':key,'kwargs':kwargs,'context':copy.deepcopy(context),'all_numeric_fields_sha256':sha(directory/f'PF{index:03d}_fields.npz'),'KCL_max_pu':kcl});event('PF_return',**context,index=index,KCL_max_pu=kcl,seconds=time.monotonic()-t)
        proxy.runpp=tracked
        def parameters(group):return {f'{i}::{n}':v.detach().cpu().numpy().copy() for i,m in enumerate(group) for n,v in m.state_dict().items()}
        def restore(group,state):
            for i,m in enumerate(group):
                data={n:torch.from_numpy(state[f'{i}::{n}'].copy()) for n in m.state_dict()};m.load_state_dict(data,strict=True)
            assert all(np.array_equal(v,state[n]) for n,v in parameters(group).items())
        def forward(group,state,algorithm,step,cold=False):
            raw=[]
            for i,m in enumerate(group):
                prefix='cold_agent_policy' if cold else 'agent_policy';costs[prefix+'_attempts']+=1;event(prefix+'_attempt',algorithm=algorithm,step=step,agent=i);t=time.monotonic()
                with torch.no_grad():a=m.get_action(np.asarray([state[i]]))
                costs[prefix+'_returns']+=1;assert a.shape==(1,) and np.isfinite(a).all() and not any(v.grad is not None for v in m.parameters());raw.append(a.copy());event(prefix+'_return',algorithm=algorithm,step=step,agent=i,seconds=time.monotonic()-t)
            return np.asarray(raw)
        packets=out/'checkpoints';packets.mkdir()
        for algorithm in p['algorithms']:
            prefix=next(x for x in oldresults['results'] if x['algorithm']==algorithm);assert not prefix['native_controlled_done']
            with (OLD/f"PF{prefix['source_PF']}_after.pkl").open('rb') as f:env.network=pickle.load(f)
            env.state=env.network.res_bus.iloc[env.injection_bus].vm_pu.to_numpy();state=env.state.copy();last=np.load(OLD/f'{algorithm}_Native_Absolute_Q.npy').copy();assert np.array_equal(last.flatten(),env.network.sgen.q_mvar.to_numpy()[:3])
            initial=np.load(OLD/f'{algorithm}_primary_weights_after.npz');restore(models[algorithm],{n:initial[n] for n in initial.files})
            with (OLD/'Root_Complete_RNG.pkl').open('rb') as f:rng=pickle.load(f)
            np.random.set_state(rng['numpy']);torch.set_rng_state(torch.from_numpy(rng['torch']));history=[]
            def packet(completed):
                return {'algorithm':algorithm,'seed':0,'completed_steps':completed,'maximum_original_steps':100,'remaining_original_steps':100-completed,'environment':copy.deepcopy(env.__dict__),'last_action':last.copy(),'state':state.copy(),'parameters':parameters(models[algorithm]),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'python_rng':random.getstate(),'absolute_owner_deadline_monotonic':deadline,'costs':copy.deepcopy(costs),'history_references':copy.deepcopy(history),'source_protocol_sha256':sha(PREP/'Protocol.json')}
            first=packet(1);path=packets/f'{algorithm}_001.pkl';binary(path,first);loaded=pickle.loads(path.read_bytes());assert loaded['completed_steps']==1 and loaded['remaining_original_steps']==99 and loaded['absolute_owner_deadline_monotonic']==deadline
            if mode=='primary':
                cold_env.__dict__.update(copy.deepcopy(loaded['environment']));restore(cold_models[algorithm],loaded['parameters']);assert np.array_equal(cold_env.state,state) and np.array_equal(cold_env.network._ppc['bus'],env.network._ppc['bus'])
                for table in ['bus','line','trafo','gen','sgen','load','ext_grid','shunt','switch','res_bus']:assert cold_env.network[table].equals(env.network[table])
            for step in range(2,101):
                context.clear();context.update(algorithm=algorithm,step=step);raw=forward(models[algorithm],state,algorithm,step)
                if step==2 and mode=='primary':
                    # Persisted full cursor/NET/model states feed fresh objects; no extra physics/replayed old action.
                    observed=forward(cold_models[algorithm],loaded['state'],algorithm,step,cold=True);assert np.array_equal(raw,observed)
                    assert all(np.array_equal(v,parameters(cold_models[algorithm])[k]) for k,v in parameters(models[algorithm]).items());event('persisted_fresh_object_next_action_exact',algorithm=algorithm,step=step,checkpoint_sha256=sha(path),original_deadline_unchanged=True)
                action=last-np.clip(raw,-.3,.3);previous=state.copy();nextstate,reward,reward_sep,done=env.step_Preward(action,last-action);vm=env.network.res_bus.vm_pu.to_numpy(copy=True)
                row={'algorithm':algorithm,'step':step,'previous_controlled_state':previous.tolist(),'raw_policy_output':raw.tolist(),'absolute_Q_Mvar':action.tolist(),'next_controlled_state':nextstate.tolist(),'all_bus_vm_pu':vm.tolist(),'all_bus_UV':int((vm<.95).sum()),'all_bus_OV':int((vm>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'native_controlled_done':bool(done),'native_reward':float(reward),'receipt':context['receipt']};steps.append(row);history.append({'step':step,'receipt':context['receipt']});last=action.copy();state=nextstate.copy()
                path=packets/f'{algorithm}_{step:03d}.pkl';binary(path,packet(step));assert pickle.loads(path.read_bytes())['remaining_original_steps']==100-step;event('checkpoint_local_hash_ACK',algorithm=algorithm,step=step,checkpoint_sha256=sha(path),bytes=path.stat().st_size);put(out/f'{algorithm}_Step_{step:03d}.json',row)
                if done:break
            endpoints.append({**steps[-1],'completed_original_steps':step,'new_suffix_steps':step-1,'terminal':'NATIVE_CONTROLLED_DONE' if done else 'ORIGINAL100STEP_HORIZON_REACHED','all_bus_restored':bool(np.all(vm>=.95)&np.all(vm<=1.05))})
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_ALL3_FIRST_AUTHOR_EPISODES_FROM_PAID_STEP1','mode':mode,'seed':0,'endpoints':endpoints,'steps':steps,'receipts':receipts,'costs':costs,'retained_original_costs':p['already_paid_costs'],'complete_original_horizon':100,'workflow_seconds':time.monotonic()-start,'our_LLM_or_aggregate_benchmark_superiority_claim':False,'cold_scope':'Persisted complete fresh-object next-action equivalence onall3;not a secondOSprocesscoldtest. Independent reader separately reexecutes whole new suffix/model/physics from prior paidstep1.','metric_scope':'Bothauthor3controlleddone andall13busbandmetrics;allsteps/OV/failedsourcecosts retained.'}
        put(out/'Result.json',result);put(out/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(out/'Result.json'));stream.close();put(out/'Closed_Manifest.json',{'files':[{'path':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in out.rglob('*') if f.is_file()],'journal_last_sha256':prev});return result
    except BaseException as e:put(out/'Failure.json',{'failure':str(e),'type':type(e).__name__,'costs':costs,'completed_new_steps':locals().get('steps',[]),'workflow_seconds':time.monotonic()-start});stream.close();raise
