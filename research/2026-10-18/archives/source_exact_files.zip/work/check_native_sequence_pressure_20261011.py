"""Prospective saved-evidence mechanism diagnostic, not counterfactual science.

Do resource/protection constraints appear in residual terminal development
states? Report both branches, all OPT worlds and every unknown. No new PF,
model, fitted control, numeric forecast, optimizer, controller or cloud call.
"""
import hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/native_sequence_pressure_20261011'
DATA=ROOT/'outputs/critical_research_reset_20261010/native_cached_contexts_20261011'
CEILING=ROOT/'outputs/critical_research_reset_20261010/saved_DSE_primary_ceiling_20261011/Results.json'
PHYS=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3/protocol.json'
def ext(p):return Path('\\\\?\\'+str(p)) if os.name=='nt' and not str(p).startswith('\\\\?\\') else p
def read(p):return json.loads(ext(p).read_text('utf8'))
def sha(p):return hashlib.sha256(ext(p).read_bytes()).hexdigest()
def write(p,v):
 with ext(p).open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
 OUT.mkdir(exist_ok=False);start=time.perf_counter();index=read(DATA/'Descriptor_Index.json');source=read(DATA/'Protocol.json');physics=read(PHYS)
 opt=sorted({r['world_sha256'] for r in index});assert len(opt)==23 and len(index)==262
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'input_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [DATA/'Descriptor_Index.json',DATA/'Protocol.json',CEILING,PHYS]},'fixed_all23_OPT_world_sha256':opt,'fixed_all46_OPT_branch_source_identities':source['OPT_branches'],'all31_ids_retained':source['all31_worlds_retained'],'held8_raw_outcomes_NOT_READ':source['held8_branch_files_NOT_READ'],'fixed_question':'Does a protected irreversible sequence-allocation hypothesis have observed resource or voltage-headroom pressure in residual terminal OPT states before any new continuation measurement?','pressure_definitions':{'slots':'Actually consumed25 native commitments with positive finalUV','cap':'An exact retained terminal menu action rejects as q_cap_exceeded, matching named-cap plus original grid Q>450','normal_upper':'An actual finite converged terminal receipt would strictly lower UV but its vmax exceeds unchanged1.05+1e-8; it remains rejected, not a trusted safe successor'},'prospective_support_gate':{'complete_exact_terminal_joins_required':True,'worlds_with_original_AND_guarded_DSE_positive_UV_and_pressure_at_either_guarded_branch':2,'distinct_families_among_those_worlds':2},'gate_scope':'Observational justification for one separately fixed numerical sequence-opportunity protocol ONLY. NOT a causal improvement, learning, economic, novelty or GPU gate. Failure stops this proposed resource/protection-preservation route on this retained dataset; it is not universal nonmyopic or LLM impossibility.','resource_seconds':180,'new_scientific_calls':0,'no_favorable_world_selection_or_new_selector':True}
 write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':Path(__file__).name,'protocol_sha256':sha(OUT/'Protocol.json')})
 ceiling=read(CEILING);comparators={arm:{r['scenario_sha256']:r for r in data['rows']} for arm,data in ceiling['arms'].items()}
 worldmap={w['sha256']:w for w in physics['worlds']};branches={};nodes={};rows=[];state_counts={'occurrences':0,'cached_menu_occurrences':0,'cap_rejected_receipts':0,'upper_blocked_UV_reducing_receipts':0,'accepted_receipts':0};proof_discrepancies=[]
 for binding in source['OPT_branches']:
  path=ROOT/binding['path'];assert sha(path)==binding['sha256'];branches[(binding['world_sha256'],binding['branch'])]=read(path)
 for row in index:
  assert time.perf_counter()-start<180,'Original resource bound; no extension or retry'
  node=read(DATA/row['path']);assert sha(DATA/row['path'])==row['sha256'];key=(row['world_sha256'],row['branch'],row['after_commit']);nodes[key]=node
  state_counts['occurrences']+=1
  if node['status']=='BOUND_PAID_NATIVE_MENU':state_counts['cached_menu_occurrences']+=1
  cap_rejections=[];upper_blocked=[];accepted=0
  for c in node['candidates']:
   v=c['verif'];bus=str(c['bus']);q=abs(float(c['q_abs']));predicted_cap_rejection=node['cap_totals'].get(bus,0.)+q>450
   actual_cap_rejection=v['reason']=='q_cap_exceeded'
   if predicted_cap_rejection!=actual_cap_rejection:proof_discrepancies.append({'node':key,'bus':bus,'q':q,'predicted_cap_rejection':predicted_cap_rejection,'actual_reason':v['reason']})
   if actual_cap_rejection:cap_rejections.append({'bus':bus,'q':q,'current_named_Q':node['cap_totals'].get(bus,0.)})
   if v['accepted']:accepted+=1
   after=v.get('after')
   if v.get('converged') is True and after is not None and after['uv_count']<v['before']['uv_count'] and after['vmax']>1.05+1e-8:
    assert not v['accepted'];upper_blocked.append({'bus':bus,'q':q,'before_uv':v['before']['uv_count'],'after_uv':after['uv_count'],'after_vmax':after['vmax'],'reason':v['reason'],'unsafe_NOT_a_safe_successor':True})
  node['_diagnostic']={'cap_rejected_count':len(cap_rejections),'cap_rejected_receipts':cap_rejections,'upper_blocked_UV_reducing_count':len(upper_blocked),'upper_blocked_UV_reducing_receipts':upper_blocked,'accepted_count':accepted}
  state_counts['cap_rejected_receipts']+=len(cap_rejections);state_counts['upper_blocked_UV_reducing_receipts']+=len(upper_blocked);state_counts['accepted_receipts']+=accepted
 for key,branch in branches.items():
  world,arm=key;result=branch['result'];k=len(result['executed_actions']);node=nodes[(world,arm,k)];native=node['native_current']['metrics'];diag=node['_diagnostic'];unknown=[]
  if native!=result['final_metrics']:unknown.append('ORIGINAL_RESULT_VS_NATIVE_FINAL_METRIC_DIFFERENCE')
  if node['unknown_reasons']:unknown+=node['unknown_reasons']
  uv=native['uv_count'];stop=result['stop_reason'];slot_pressure=k==25 and uv>0
  # Pressure is descriptive evidence, not a claim that removing it repairs UV.
  pressure=uv>0 and (slot_pressure or diag['cap_rejected_count']>0 or diag['upper_blocked_UV_reducing_count']>0)
  if stop=='no_accepted_action' and diag['accepted_count']!=0:unknown.append('NATIVE_NO_ACCEPTED_STOP_MENU_DISAGREEMENT')
  rows.append({'world_sha256':world,'scenario_id':node['scenario_id'],'family':worldmap[world]['family'],'branch':arm,'native_terminal_UV':uv,'committed_steps':k,'remaining_native_slots':25-k,'original_stop_reason':stop,'slot_pressure':slot_pressure,'terminal_named_caps':node['cap_totals'],'terminal_cached_candidate_count':len(node['candidates']),'terminal_menu_diagnostic':diag,'observed_resource_or_upper_pressure':pressure,'unknown_reasons':unknown,'original_literal_DSE_selected':comparators['original_literal_DSE'][world],'common_guard_DSE_selected_SEPARATE_CONTROL':comparators['common_guard_reference_NOT_LLM_benefit'][world]})
 assert len(rows)==46 and len(nodes)==262
 world_rows=[]
 for world in opt:
  pair=[r for r in rows if r['world_sha256']==world];assert len(pair)==2
  original=comparators['original_literal_DSE'][world];guarded=comparators['common_guard_reference_NOT_LLM_benefit'][world]
  unknown=any(r['unknown_reasons'] for r in pair)
  both_positive=original['selected_final_uv']>0 and guarded['selected_final_uv']>0
  observed=both_positive and any(r['observed_resource_or_upper_pressure'] for r in pair)
  world_rows.append({'world_sha256':world,'scenario_id':pair[0]['scenario_id'],'family':pair[0]['family'],'both_DSE_controls_positive_UV':both_positive,'pressure_observed_at_guarded_branch':any(r['observed_resource_or_upper_pressure'] for r in pair),'gate_support_world':observed and not unknown,'unknown':unknown,'not_a_chosen_evaluation_subset':True})
 supporting=[r for r in world_rows if r['gate_support_world']];families=sorted({r['family'] for r in supporting});complete=not proof_discrepancies and not any(r['unknown'] for r in world_rows)
 gate='UNKNOWN_INCOMPLETE_SAVED_EVIDENCE' if not complete else 'OBSERVED_PRESSURE_ALLOWS_NUMERICAL_PROTOCOL_DESIGN_ONLY' if len(supporting)>=2 and len(families)>=2 else 'STOP_RESOURCE_PROTECTION_PRESERVATION_ROUTE_ON_RETAINED_DATASET'
 results={'at_utc':datetime.now(timezone.utc).isoformat(),'all23_OPT_worlds_retained':True,'all46_branches_retained':True,'all262_current_occurrences_retained':True,'held8_branch_files_unread':True,'actual_branch_reads':46,'actual_descriptor_reads':262,'state_receipt_counts':state_counts,'terminal_stop_reason_counts':{s:sum(r['original_stop_reason']==s for r in rows) for s in sorted({r['original_stop_reason'] for r in rows})},'positive_native_terminal_branch_count':sum(r['native_terminal_UV']>0 for r in rows),'slot_pressure_branch_count':sum(r['slot_pressure'] for r in rows),'cap_pressure_positive_terminal_branch_count':sum(r['native_terminal_UV']>0 and r['terminal_menu_diagnostic']['cap_rejected_count']>0 for r in rows),'upper_pressure_positive_terminal_branch_count':sum(r['native_terminal_UV']>0 and r['terminal_menu_diagnostic']['upper_blocked_UV_reducing_count']>0 for r in rows),'supporting_world_count':len(supporting),'supporting_families':families,'complete_saved_evidence_joins':complete,'cap_source_predicate_discrepancies':proof_discrepancies,'prospective_observational_gate':gate,'workflow_seconds_before_report_manifest':time.perf_counter()-start,'new_PF_model_fit_optimizer_controller_converter_derivative_forecast_solve_cloud_calls':0,'new_counterfactual_terminal_outcomes':'UNKNOWN_NOT_MEASURED','causal_sequence_improvement':'UNPROVED','LLM_superiority':'UNPROVED','no_scientific_or_training_job_authorized_by_gate':True}
 write(OUT/'All46_Terminal_Mechanism_Records.json',rows);write(OUT/'All23_World_Denominators.json',world_rows);write(OUT/'Results.json',results)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
 print(json.dumps({k:v for k,v in results.items() if k not in ['cap_source_predicate_discrepancies']}))
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':os.getpid(),'state':'TERMINAL_READONLY_DIAGNOSTIC_PARTIAL_NO_AUTOMATIC_RETRY','exception':type(exc).__name__,'message':str(exc),'new_scientific_calls':0})
  raise
