"""Whole FIT-only causal packet binding plus original observer static coverage."""
import ast,copy,hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path
from matched_scale_serving_packet_gate import REQUIRED_MEASUREMENT_GROUPS,complete_local_messages
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/matched_scale_20261011';OUT=BASE/'serving_admission'
assert not OUT.exists();OUT.mkdir();began=time.perf_counter()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fit_path=BASE/'preparation/fit.json';fit=json.loads(fit_path.read_text('utf8'));assert len(fit)==340
passed=[]
for r in fit:
    packet=copy.deepcopy(r['packet']);before=json.dumps(packet,sort_keys=True)
    assert complete_local_messages(packet)==r['messages'] and json.dumps(packet,sort_keys=True)==before
    passed.append(r['id'])
bad=copy.deepcopy(fit[0]['packet']);del bad['local_measurements']['tie_line_flows']
controls={'missing_tie_flows':bad,'old_aggregate_observer':{'zone':fit[0]['packet']['zone'],'local_measurements':{'min_voltage_pu':.9,'max_voltage_pu':1.,'n_undervoltage':1,'n_overvoltage':0,'state_summary':'source-style aggregate'}},
 'after_added':copy.deepcopy(fit[0]['packet'])}
controls['after_added']['local_measurements']['after']={'bus_voltages':{'1':1.}}
rejections={}
for name,packet in controls.items():
    try:complete_local_messages(packet)
    except (ValueError,TypeError) as e:rejections[name]=type(e).__name__
    else:raise AssertionError('Incomplete or target-derived packet admitted')
snapshot=ROOT/'outputs/critical_research_reset_20261010/original_training_notebook_source_snapshot/Original_Account_Phase2A_Download.ipynb'
doc=json.loads(snapshot.read_text('utf8'));source=''.join(doc['cells'][49]['source'])
plain=''.join(line for line in source.splitlines(True) if not line.lstrip().startswith(('%','!')))
tree=ast.parse(plain);observer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='extract_zone_state')
returns=[n for n in ast.walk(observer) if isinstance(n,ast.Return) and isinstance(n.value,ast.Dict)]
assert len(returns)==1;old_fields={k.value for k in returns[0].value.keys if isinstance(k,ast.Constant)}
missing=sorted(REQUIRED_MEASUREMENT_GROUPS-old_fields)
assert missing==['boundary_voltages','gen_status','sgen_status','storage_status','tie_line_flows','total_load_mvar']
# Original make_messages additionally converts state to the six aggregate values;
# it does not create the new raw packet. Source cells are never executed/imported.
old_prompt=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='make_messages')
assert 'local_measurements' not in ast.unparse(old_prompt)
result={'at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'FIT_packets_losslessly_bound':340,
 'FIT_source_sha256':sha(fit_path),'gate_source_sha256':sha(ROOT/'work/matched_scale_serving_packet_gate.py'),
 'three_labelled_controls_rejected':rejections,'old_observer_missing_required_groups':missing,
 'snapshot_sha256':sha(snapshot),'original_observer_function_ast_sha256':hashlib.sha256(ast.dump(observer).encode()).hexdigest(),
 'old_observer_is_valid_for_its_original_compact_role':True,'direct_unchanged_old_observer_for_NEW_rich_models':'STOP',
 'new_actual_network_observer_and_full_physical_rollout':'NOT IMPLEMENTED/CERTIFIED by this gate',
 'normal_band_and_cap_verifier_benefit_is_not_model_value':True,'no_training_source_data_protocol_or_old_asset_changes':True,
 'new_model_PF_optimizer_controller_forecast_solver_converter_calls':0,'HELD_output_inspections':0,'seconds':time.perf_counter()-began}
(OUT/'Serving_Admission_Readiness.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
(OUT/'Next_Physical_Binding_Requirements.md').write_text('The new paired rich-current models require eight exact measured CURRENT groups. The original Phase2C observer and six-value prompt remain valid for the original private compact model; they cannot supply the new packet unchanged. No fields may be reconstructed from labels, successor data, unsupported analytic forecasts or zero defaults. A future new physical study must implement and independently bind the actual live observation producer, tokenizer/full context and current solver receipt; disclose archival name-key collisions and partial observability; apply identical cap/global normal-band/protection controls to all methods; retain the literal D-SE branches and FULL BOTH costs. This shape gate is not a convergence certificate, an action verifier, a learned-policy gain or permission for automatic physical rollout. Current training remains unchanged.\n',encoding='utf8')
