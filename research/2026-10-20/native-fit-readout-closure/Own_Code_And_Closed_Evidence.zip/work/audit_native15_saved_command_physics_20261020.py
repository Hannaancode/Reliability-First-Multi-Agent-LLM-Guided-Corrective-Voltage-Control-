from native15_saved_command_physics_integration_20261020 import run
if __name__=='__main__':run('independent')
