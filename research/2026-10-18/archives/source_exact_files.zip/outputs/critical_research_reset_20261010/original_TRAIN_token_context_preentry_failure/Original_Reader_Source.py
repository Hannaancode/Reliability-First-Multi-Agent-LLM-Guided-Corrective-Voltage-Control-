"""Complete original TRAIN chat tokenizer check. No neural model or export."""
import os
os.environ['HF_HUB_OFFLINE']='1'; os.environ['TRANSFORMERS_OFFLINE']='1'; os.environ['TOKENIZERS_PARALLELISM']='false'
import array, hashlib, json, sys, time, zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from transformers import AutoTokenizer
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended

OUT=extended(ROOT/'outputs/critical_research_reset_20261010/original_TRAIN_matched_token_contexts')
DESKTOP=Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm')
PUBLIC=ROOT/'outputs/critical_research_reset_20261010/public_size_production_preparation_v4'
SMALL=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
LARGE=PUBLIC/'tokenizers/public_1_5B'


def token_hash(ids):return hashlib.sha256(array.array('I',ids).tobytes()).hexdigest()


def run():
    assert not OUT.exists(); OUT.mkdir(); started=time.perf_counter()
    write(OUT/'owner.claim',{'actual_pid':os.getpid(),'source_sha256':sha(Path(__file__)),'at_utc':datetime.now(timezone.utc).isoformat()})
    member='hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'
    with zipfile.ZipFile(DESKTOP/'phase2b_training_inputs.zip') as z: raw=z.read(member)
    actual=hashlib.sha256(raw).hexdigest(); original=read(ROOT/'outputs/critical_research_reset_20261010/original_desktop_pipeline_alignment/Original_Training_Model_and_Contract_Reconciliation.json')
    assert original['source_members']['phase2b_training_inputs.zip::'+member]['sha256']==actual
    manifest=read(PUBLIC/'PUBLIC_SIZE_INPUT_MANIFEST.json')
    for name in ('tokenizer.json','tokenizer_config.json','vocab.json','merges.txt'):
        assert sha(LARGE/name)==manifest['prep/tokenizers/public_1_5B/'+name]['sha256']
    for name in ('tokenizer.json','tokenizer_config.json'):
        assert sha(SMALL/name)==original['model_files'][name]['frozen_workspace_sha256']
    protocol={'declared_at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Full original TRAIN message/template/token compatibility only; no learning or physical result',
        'all16000_original_TRAIN_rows_only':True,'validation_test_outcome_metrics_untouched':True,'no_truncation_or_schema_projection_or_label_removal':True,
        'full_chat_add_generation_prompt':False,'current_input_prefix_add_generation_prompt':True,
        'prospective_common_context_tokens':4096,'prospective_generation_reserve_tokens':384,
        'not_reconstruction_of_unknown_original_training_maxlength':True,'generation_reserve_not_required_to_reproduce_entire_verbose_teacher_answer':True,
        'no_model_weights_download_or_load_no_cloud_private_export':True,'local_files_only_trust_remote_code_false':True,
        'exact_duplicate_chat_cache_counted_separately':True,'resource_bound_seconds':600,'no_retry_or_shortening_if_failed':True,
        'input_member_sha256':actual,'source_sha256':sha(Path(__file__)),
        'tokenizer_files_sha256':{str(p.relative_to(ROOT)):sha(p) for folder in (SMALL,LARGE) for p in (folder/'tokenizer.json',folder/'tokenizer_config.json')},
        'public15B_repo':'Qwen/Qwen2.5-1.5B-Instruct','public15B_revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'}
    write(OUT/'Prospective_Tokenizer_Context_Protocol.json',protocol)
    tokenizers=[AutoTokenizer.from_pretrained(str(p),local_files_only=True,trust_remote_code=False) for p in (SMALL,LARGE)]
    identity={'classes':[type(t).__name__ for t in tokenizers],'vocabularies_equal':tokenizers[0].get_vocab()==tokenizers[1].get_vocab(),
        'chat_templates_equal':tokenizers[0].chat_template==tokenizers[1].chat_template,
        'backend_tokenizer_JSON_equal':json.loads(tokenizers[0].backend_tokenizer.to_str())==json.loads(tokenizers[1].backend_tokenizer.to_str()),
        'special_token_maps_equal':tokenizers[0].special_tokens_map==tokenizers[1].special_tokens_map,
        'metadata_model_max_lengths':[t.model_max_length for t in tokenizers],'token_ID_hash_byteorder':sys.byteorder}
    write(OUT/'Actual_Loaded_Tokenizer_Identity.json',identity)
    cache={}; costs=Counter(); result=[]; deadline=False
    for index,line in enumerate(raw.decode('utf8').splitlines()):
        r=json.loads(line); messages=r['messages']; assert messages[-1]['role']=='assistant'
        row={'TRAIN_row_index':index,'messages_sha256':hashlib.sha256(json.dumps(messages,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()}
        key=row['messages_sha256']
        if time.perf_counter()-started>protocol['resource_bound_seconds']:deadline=True
        if deadline: row['status']='UNKNOWN_unexecuted_resource_bound'
        elif key in cache: row.update(cache[key]);costs['exact_duplicate_chat_cache_hits']+=1
        else:
            values=[]
            for ti,tok in enumerate(tokenizers):
                costs['full_chat_tokenizer_attempts']+=1
                ids=tok.apply_chat_template(messages,tokenize=True,add_generation_prompt=False,truncation=False)
                costs['full_chat_tokenizer_returns']+=1;costs['actual_full_chat_tokens_processed']+=len(ids)
                costs['prefix_tokenizer_attempts']+=1
                prefix=tok.apply_chat_template(messages[:-1],tokenize=True,add_generation_prompt=True,truncation=False)
                costs['prefix_tokenizer_returns']+=1;costs['actual_prefix_tokens_processed']+=len(prefix)
                values.append({'full_chat_tokens':len(ids),'full_token_ID_sha256':token_hash(ids),'current_prefix_tokens':len(prefix),
                    'prefix_token_ID_sha256':token_hash(prefix),'full_sequence_fits4096':len(ids)<=4096,'prefix_plus384_fits4096':len(prefix)+384<=4096})
            record={'status':'complete_actual_tokenizer_check','tokenizers':values,
                'full_token_ID_arrays_identical':values[0]['full_token_ID_sha256']==values[1]['full_token_ID_sha256'],
                'prefix_token_ID_arrays_identical':values[0]['prefix_token_ID_sha256']==values[1]['prefix_token_ID_sha256']}
            cache[key]=record;row.update(record);costs['unique_chat_sequences_actually_encoded']+=1
        result.append(row)
    assert len(result)==16000
    known=[r for r in result if r['status']=='complete_actual_tokenizer_check'];metrics=[]
    for ti in range(2):
        lengths=[r['tokenizers'][ti]['full_chat_tokens'] for r in known]
        prefixes=[r['tokenizers'][ti]['current_prefix_tokens'] for r in known]
        metrics.append({'rows_checked':len(known),'full_chat_min_tokens':min(lengths,default=None),'full_chat_max_tokens':max(lengths,default=None),
            'full_chat_total_tokens_across_original_rows':sum(lengths),'full_chat_rows_over4096':sum(n>4096 for n in lengths),
            'current_prefix_max_tokens':max(prefixes,default=None),'prefix_plus384_rows_over4096':sum(n+384>4096 for n in prefixes)})
    readiness={'all16000_rows_retained':True,'all_rows_checked':len(known)==16000,'metrics_original05B_then_public15B':metrics,
        'actual_full_token_ID_mismatch_rows':sum(not r['full_token_ID_arrays_identical'] for r in known),
        'actual_prefix_token_ID_mismatch_rows':sum(not r['prefix_token_ID_arrays_identical'] for r in known),
        'common4096_complete_sequence_compatibility':'UNKNOWN_resource_partial' if deadline else 'PASS' if all(m['full_chat_rows_over4096']==0 and m['prefix_plus384_rows_over4096']==0 for m in metrics) else 'FAIL_DECLARED_CONTEXT_NO_SHORTENING',
        'actual_costs':dict(costs),'workflow_seconds_before_frozen_checks_and_seal':time.perf_counter()-started,
        'actual_new_neural_model_forward_optimizer_PF_native_forecast_cloud_calls':0,
        'VRAM_gradient_trainability_loss_mask_old_training_reproduction_and_policy_value_not_certified':True,
        'automatic_training_or_GPU_launch':False,'exact_token_hashes_not_independently_retokenized':True}
    write(OUT/'All16000_Original_TRAIN_Token_Context_Records.json',result);write(OUT/'Actual_Tokenizer_Context_Readiness.json',readiness)
    write(OUT/'Fresh_Frozen_Asset_Checks.json',frozen_checks())
    files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'};files['sources/reader.py']=Path(__file__)
    print(json.dumps({'readiness':readiness,'archive':seal(OUT,files,'Token_Context_Audit.zip')}))

if __name__=='__main__':run()
