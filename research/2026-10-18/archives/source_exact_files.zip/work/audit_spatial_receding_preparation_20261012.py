"""One external component-readiness reader. ZERO science, no suite reruns."""
import ast
import hashlib
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from candidate_process_evidence_utils import frozen_checks, seal
from native_continuation_preservation_v2 import extended_local_path

ROOT = Path(__file__).resolve().parents[1]
RESET = ROOT/'outputs/critical_research_reset_20261010'
OUT = RESET/'spatial_receding_preparation_audit_20261012'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf8') as f:
        json.dump(value, f, indent=2, allow_nan=False)


def run():
    begun = time.perf_counter()
    OUT.mkdir(exist_ok=False)
    write(OUT/'reader.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(),
        'executable': sys.executable, 'argv': sys.argv,
        'source_sha256': sha(Path(__file__)), 'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'EXTERNAL_ZERO_SCIENCE_COMPONENT_READER'})
    first = RESET/'spatial_receding_software_20261012/Software_Checks.json'
    second = RESET/'spatial_fixed_gate_software_20261012/Software_Checks.json'
    certificates = [read(first), read(second)]
    assert [len(c['checks']) for c in certificates] == [35, 21]
    assert all(c['all_passed'] and all(x['passed'] for x in c['checks']) for c in certificates)
    names = [x['name'] for c in certificates for x in c['checks']]
    assert len(names) == len(set(names)) == 56
    assert certificates[0]['new_PF_model_optimizer_controller_science_calls'] == certificates[1]['new_scientific_calls'] == 0
    assert certificates[0]['full_25_step_actual_physics_certified'] is False
    assert certificates[1]['actual_cold_storage_handoff_tested'] is False
    pins = {}
    for c in certificates:
        for name, digest in c['source_sha256'].items():
            assert sha(ROOT/name) == digest
            pins[name] = digest
    # Independently compile sources without importing their execution paths.
    for name in pins:
        tree = ast.parse((ROOT/name).read_text('utf8'))
        compile(tree, name, 'exec')
    inventory = []
    directory = extended_local_path(RESET/'spatial_receding_software_20261012/storage_fixture')
    for path in directory.rglob('*'):
        if path.is_file():
            inventory.append({'relative': path.relative_to(directory).as_posix(),
                              'bytes': path.stat().st_size, 'sha256': sha(path)})
    assert len(inventory) == 5 and sum(p['bytes'] for p in inventory) == 210
    assert any(len(str(directory/p['relative'])) > 260 for p in inventory)
    roots = {}
    input_dir = RESET/'spatial_allocation_input_preparation_v2_20261011'
    for name in ('L1', 'L2', 'S1', 'S2', 'T1', 'T2', 'C1', 'C2'):
        path = input_dir/(name+'.json')
        roots[name] = {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path)}
    pins['work/audit_spatial_receding_preparation_20261012.py'] = sha(Path(__file__))
    certificate = {'audited_at_utc': datetime.now(timezone.utc).isoformat(),
        'independent_component_audit_passed': True, 'labelled_software_checks_verified': 56,
        'new_model_PF_optimizer_controller_science_calls': 0,
        'software_checks_not_rerun_by_reader': True,
        'source_sha256': pins, 'all_eight_fixed_development_roots': roots,
        'full_storage_fixture_independently_counted': inventory,
        'whole_25_step_physics_cold_guard_runtime_and_performance_certified': False,
        'full_owner_comparator_cost_bindings_and_independent_trajectory_reader_ready': False,
        'LLM_advantage_or_90_percent_probability_established': False,
        'next_tasks': [
            'Bind actual charged root/commit/failure full-state owner callbacks to the new irreversible loop; direct-cost ledger must stay live in every checkpoint.',
            'Certify complete-storage guard/cost wrapper in a fresh separately fixed actual process gate, retaining original deadline and the same exclusive evidence tree. No old engineering restart.',
            'Complete original literal/control preservation, all eight root/arm/failed identity accounting, continuous physical rebuild and source-locked independent full-policy reader BEFORE numerical performance.',
            'Freeze economical acquisition rationale without changing beam width or choosing favorable roots. Expensive diagnostic search alone is not deployable LLM value.',
            'Launch only a justified complete prospective numerical protocol; no new GPU, stopped-method retraining or automatic language rollout.'],
        'reader_seconds_before_certificate_and_archive_write': time.perf_counter()-begun}
    write(OUT/'Independent_Component_Readiness_Audit.json', certificate)
    write(OUT/'Fresh_Frozen_Checks.json', frozen_checks())
    files = {name: ROOT/name for name in pins}
    files.update({'first_suite/Software_Checks.json': first, 'second_suite/Software_Checks.json': second,
        'Independent_Component_Readiness_Audit.json': OUT/'Independent_Component_Readiness_Audit.json',
        'Fresh_Frozen_Checks.json': OUT/'Fresh_Frozen_Checks.json'})
    for name, item in roots.items():
        files['fixed_roots/'+name+'.json'] = ROOT/item['path']
    archive = seal(OUT, files, 'Verified_Receding_Component_Preparation.zip')
    write(OUT/'Completion.json', {'status': 'COMPLETE_SOFTWARE_COMPONENTS_ONLY',
        'actual_reader_pid': os.getpid(), 'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'reader_seconds_including_archive_and_hash_verification': time.perf_counter()-begun,
        'archive': archive, 'new_scientific_calls': 0})
    print(json.dumps({'independent_audit': 'PASS', 'verified_checks': 56,
                     'archive': archive, 'actual_reader_pid': os.getpid(), 'new_scientific_calls': 0}))


if __name__ == '__main__':
    run()
