"""Reuse unchanged original selection/scope audit on 74 preserved records.

No 80-record completion gate is bypassed: this has a different output namespace,
states the missing artifacts, retains all80 identities and performs zeroPF/model.
Campaign-global totals cannot be verified without the lost final summary.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import ast,copy,hashlib,json,os
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack
from value_candidate_ordering import universe
from value_model_prefix_inputs import scoped_raw_proposals
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'outputs/llm_value_stage3_development'
OUT=PARENT/'partial_external_analysis'
REMOTE=PARENT/'staged/remote'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,x):
    with (OUT/name).open('x') as f:json.dump(x,f,indent=2)
def main():
    assert not OUT.exists(),'Preserve partial external analysis; do not repeat'
    preserved=read(PARENT/'partial_preservation_audit/audit.json')
    assert preserved['actual_preserved_trajectory_count']==74 and not preserved['full_campaign_complete']
    OUT.mkdir();(OUT/'owner.claim').write_text(str(os.getpid()))
    (OUT/'protocol.json').write_bytes((PARENT/'protocol.json').read_bytes())
    protocol=read(OUT/'protocol.json')
    for name,digest in {**protocol['source_sha256'],**protocol['frozen_source_sha256']}.items():assert sha(ROOT/name.replace('\\','/'))==digest
    staged_manifest=read(PARENT/'partial_preservation_audit/Preserved_Partial_Artifact_Manifest.json')
    for name,item in staged_manifest.items():assert sha(PARENT/name)==item['sha256'] and (PARENT/name).stat().st_size==item['bytes']
    # Audit the existing original function AST, retaining its scientific checks.
    original=ROOT/'work/analyze_stage3_matched_results.py';tree=ast.parse(original.read_text())
    method=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    begin=next(i for i,n in enumerate(method.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='config' for t in n.targets))
    end=next(i for i,n in enumerate(method.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='summary' for t in n.targets) and isinstance(n.value,ast.Call) and "REMOTE / 'summary.json'" in ast.unparse(n.value))
    nodes=method.body[begin:end];removed=[];kept=[]
    for node in nodes:
        if isinstance(node,ast.Assert) and ast.unparse(node.test)=='trials.keys() == expected':
            removed.append(ast.unparse(node));continue
        if isinstance(node,ast.Assert) and 'staged/exact_dependency_check.json' in ast.unparse(node):
            # Original exact closure lives under PARENT, not this new output dir.
            assert read(PARENT/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
            removed.append(ast.unparse(node));continue
        kept.append(node)
    ns=dict(globals());ns['protocol']=protocol
    exec(compile(ast.Module(body=kept,type_ignores=[]),str(original),'exec'),ns)
    trials=ns['trials'];expected=ns['expected'];table=ns['table'];costs=ns['costs']
    assert set(trials)<=expected and len(trials)==len(table)==74
    assert sorted(expected-set(trials))==preserved['missing_declared_identities']
    ref=ns['ref'];portfolios=[];paired=[]
    for case in protocol['scenarios']:
        for name,arms in protocol['predeclared_portfolios'].items():
            branches=[next((t for t in table if t['scenario_id']==case['scenario_id'] and t['arm']==arm),None) for arm in arms]
            valid=all(t is not None and t['status']=='complete' for t in branches);chosen=None
            if valid:
                chosen=branches[1 if ref.choose_safety_envelope(*[t['summary_for_original_selector'] for t in branches])=='reflection_v2' else 0]
            portfolios.append({'scenario_id':case['scenario_id'],'portfolio':name,'valid':valid,
                'missing_arms':[a for a,t in zip(arms,branches) if t is None],
                'selected_arm':chosen['arm'] if chosen else None,'selected_metrics':chosen['metrics'] if chosen else None,
                'full_both_branch_controller_PF_attempts':sum(t['actual_incremental_costs']['PF']['controller']['PF_attempts'] for t in branches) if valid else None,
                'full_both_branch_generations_with_initial_acquisitions':sum(t['actual_incremental_costs']['generation']['generation_entries']+(t['inherited_initial_generation_costs'] or {}).get('generation_entries',0) for t in branches) if valid else None,
                'original_selector_zero_missing_handling_preserved':True})
        scoped={t['arm']:t for t in table if t['scenario_id']==case['scenario_id']}
        for left,right in [('LoRA_fresh_guarded','LoRA_held_initial_guarded'),('LoRA_fresh_guarded','base_fresh_guarded'),('LoRA_fresh_guarded','lowest_guarded')]:
            valid=left in scoped and right in scoped
            paired.append({'scenario_id':case['scenario_id'],'comparison':left+'__minus__'+right,'available':valid,
                'UV_delta':scoped[left]['metrics']['uv_count']-scoped[right]['metrics']['uv_count'] if valid else None,
                'joint_voltage_success_left':scoped[left]['strict_UV_zero_and_normal_upper'] if valid else None,
                'joint_voltage_success_right':scoped[right]['strict_UV_zero_and_normal_upper'] if valid else None,
                'PF_delta':scoped[left]['actual_incremental_costs']['PF']['controller']['PF_attempts']-scoped[right]['actual_incremental_costs']['PF']['controller']['PF_attempts'] if valid else None})
    model_totals={k:sum(c['generation'][k] for c in costs) for k in costs[0]['generation']}
    pf_totals={phase:{k:sum(c['PF'][phase][k] for c in costs) for k in costs[0]['PF'][phase]} for phase in costs[0]['PF']}
    audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'actual_records_audited':74,'declared_denominator':80,
        'missing_original_identities':preserved['missing_declared_identities'],'source_and_case_hashes_verified':True,
        'actual_selected_action_oracle_checks':ns['selection_checks'],'actual_raw_or_cached_scope_checks':ns['raw_scope_checks'],
        'original_scientific_selection_and_scope_AST_unchanged':True,'explicitly_changed_operational_checks':removed,
        'reported_continuous_physical_replay_passed_for_all_preserved_complete_records':True,
        'campaign_global_totals_against_original_summary_verified':False,
        'preserved_cost_totals_include_preparation_and_unique_initial_acquisitions':model_totals,
        'preserved_PF_totals':pf_totals,'unknown_unpreserved_execution_costs_not_zeroed':True,
        'actual_new_audit_PF_calls':0,'actual_new_audit_model_calls':0,
        'original_full_analyzer_not_run_or_modified':True,'full_campaign_complete':False,'LLM_superiority_established':False,
        'partial_audit_source_sha256':sha(Path(__file__)),'original_analyzer_source_sha256':sha(original),
        'limits':'Partial historical development. Seven complete ten-arm points, final point lacks sixCPU controls. Initial tokenization/setup and unpreserved costs prevent full deployment cost/runtime claims.'}
    for name,obj in [('Action_Scope_and_Cost_Audit.json',audit),('Actual_74_Trajectory_Table.json',table),('Declared_40_Portfolio_Table.json',portfolios),('All_8_Paired_Attribution_Table.json',paired)]:write(name,obj)
    lines=['# Partial Stage3 action/scope/cost audit','',audit['limits'],'',
        f'Independently checked {ns["selection_checks"]} selected actions and {ns["raw_scope_checks"]} raw/cached scope entries. Zero newPF/model calls. Six missing original identities remain unknown, not failed or invented outcomes.','',
        '| Case | Comparison | Available | UV delta | Joint left/right | PF delta |','|---|---|---|---:|---|---:|']
    for r in paired:lines.append(f'| {r["scenario_id"]} | {r["comparison"]} | {r["available"]} | {r["UV_delta"]} | {r["joint_voltage_success_left"]}/{r["joint_voltage_success_right"]} | {r["PF_delta"]} |')
    (OUT/'Results.md').write_text('\n'.join(lines),encoding='utf-8')
    write('Analysis_Manifest.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.glob('*') if p.is_file() and p.name!='owner.claim'})
    print(json.dumps({k:audit[k] for k in ['actual_records_audited','actual_selected_action_oracle_checks','actual_raw_or_cached_scope_checks','preserved_cost_totals_include_preparation_and_unique_initial_acquisitions']}))
if __name__=='__main__':main()
