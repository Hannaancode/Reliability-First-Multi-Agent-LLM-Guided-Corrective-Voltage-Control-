# Fixed public QA comparison

All three fixed arms completed, the pinned saved-output audit passed, and all three T4 runtimes were released. These are150questions about one public circuit, without retrieval, tools, private adapters or training.

| Public model | Native-parser correct | Strict single-letter correct | Strict valid | Output-cap hits |
|---|---:|---:|---:|---:|
| Qwen2.5-0.5B-Instruct | 37/150 | 12/150 | 65/150 | 73/150 |
| Qwen2.5-1.5B-Instruct | 0/150 | 0/150 | 0/150 | 150/150 |
| Qwen2.5-3B-Instruct | 37/150 | 37/150 | 150/150 | 0/150 |

The1.5B arm produced a repeated exclamation-mark stream in every answer, including its earlier synthetic warm/cold probes. The3B arm produced valid single letters on every question: A16/B98/C29/D7. The independent audit confirms what ran and how the frozen parser scored it; it does not establish normal model capability. The cold gate checked reproducibility but missed degenerate output and did not record finite logits. The exact numerical cause remains unknown.

The fixed study is stopped. No prompt, dtype, decoder, seed, token limit or answer is changed to obtain a favourable replacement result. Future model work needs a separately frozen, label-free numerical and behavior gate.

Costs:450scientific generations plus6engineering generations;0PF/OPF/training. Individual returned-generation timing, engineering, host/setup/transfer/release and overlapping workflow costs are retained in Verified_Completion.json. Prior preparation/failure costs remain separate. No deployment-speed claim.

All six research goals remain open. This comparison does not certify the original RAG system, the trained voltage-control model or superiority over published controllers.
