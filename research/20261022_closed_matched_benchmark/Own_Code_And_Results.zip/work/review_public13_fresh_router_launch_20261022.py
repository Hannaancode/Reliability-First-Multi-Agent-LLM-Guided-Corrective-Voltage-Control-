"""Separate static admission reader; no PF, actor, derivative or solver calls."""
import ast,json,subprocess,hashlib
from datetime import datetime,timezone
from public13_fresh_router_engine_20261022 import R,P,PRIMARY,READER,put,read,sha

def main():
    p=read(P/'Protocol.json')
    for rel,h in p['source_and_input_hashes'].items():assert sha(R/rel)==h,rel
    assert not PRIMARY.exists() and not READER.exists() and not (R/'outputs/public13_fresh_router_handoff_20261022').exists()
    lock=read(P/'Independent_Reader_Lock.json');assert lock['protocol_sha256']==sha(P/'Protocol.json') and lock['engine_sha256']==sha(R/'work/public13_fresh_router_engine_20261022.py') and lock['reader_sha256']==sha(R/lock['reader'])
    inputs=R/'outputs/public13_fresh_input_router_preparation_v2_20261021'
    ids=read(inputs/'All128_Prospective_Identities.json');assert [v['seed'] for v in ids]==list(range(1000,1128))
    sw=read(R/'outputs/public13_fresh_router_software_checks_v2_20261022/Software_Checks.json');assert all(sw['checks'].values()) and sw['engine_sha256']==lock['engine_sha256']
    saved=read(P/'Actual_No_Forward_State_Readiness.json');assert saved['actual_checkpoint_load_returns']==9 and all(saved['negative_controls'].values()) and saved['new_actor_PF_derivative_LP_training_calls']==0
    tree=ast.parse((R/'work/public13_fresh_router_engine_20261022.py').read_text(encoding='utf-8'))
    calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)]
    named=lambda name:[n for n in calls if isinstance(n.func,ast.Name) and n.func.id==name]
    assert len(named('propose'))==1 and len(named('verify'))==1 and len(named('original_guard'))==1
    assert not any(isinstance(n.func,ast.Attribute) and n.func.attr in ('backward','optimizer_step','generate','from_pretrained') for n in calls)
    # The two actual entry points cannot override the shared primary/reader path.
    for label,mode in [('Primary','primary'),('Reader','independent')]:
        owner=read(P/(label+'_Owner_Protocol.json'))['single_owner'];src=(R/owner['source']).read_text(encoding='utf-8');assert f"run('{mode}')" in src and sha(R/owner['source'])==owner['sha256'] and owner['bound_seconds']==7500
    cmd="Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python' -and $_.CommandLine -match '(run_public13_fresh_router_20261022.py|audit_public13_fresh_router_20261022.py|coordinate_public13_fresh_router_20261022.py)' } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    current=subprocess.run(['powershell.exe','-NoProfile','-Command',cmd],capture_output=True,text=True,check=True,timeout=30)
    assert not current.stdout.strip(),'An exact new scientific/reader/coordinator source is already live'
    report=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='PASS_SOURCE_INPUT_STATE_SCOPE_OWNERSHIP_STATIC_REVIEW',protocol_sha256=sha(P/'Protocol.json'),reader_lock=lock,
        gates=dict(all128_exact_ordered_inputs=True,source_and_input_hashes=True,scope_disjointness_input_audit=True,
        labelled_mock_boundaries_and_e2e=19,actual_checkpoint_reads_no_forwards=9,actual_saved_state_and_missing_tensor_history_bound_negatives=True,
        original_numeric_propose_dense_certificate_and_guard_references_unchanged=True,source_native_environment_AST_unchanged=True,
        separately_mutable_router_banks=True,partial_aware_reader_no_failed_PF_replay=True,no_existing_output_claim_or_matching_live_source=True,
        fixed_prospective_comparison_before_outcomes=True),
        limitations=['Mock fixtures are not measured scientific outputs.','First actual physical integration may fail; preserve all costs/UNKNOWN without retries.',
        'Source mutable b/c normalization creates ordered state dependence; fixed case-root intervals are a screening statistic, not calibrated final confirmation.',
        'This composite contains a published trained control expert, but no new LLM inference or incremental LLM attribution.','Fresh local source seeds are not certified absent from external model training.'],
        new_actor_PF_LP_derivative_training_calls=0,review_source_sha256=sha(__file__))
    put(P/'Independent_Launch_Review.json',report);print(report['status'])

if __name__=='__main__':main()
