"""Independent closed-owner contract reader; no frozen-function or science execution."""
import ast, ctypes, gzip, hashlib, json, math, os, sys, time, traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import frozen_checks, seal

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/initial_reflection_target_compatibility_20261011'
OLD=ROOT/'outputs/critical_research_reset_20261010/original_role_numeric_gate_20261011/execution'
PRODUCTION=ROOT/'work/check_initial_reflection_target_compatibility_20261011.py'
READY=ROOT/'work/initial_reflection_target_reader_readiness_20261011.json'
INPUTS=['FIT_Current_Packets_And_Targets.json.gz','HELD_Current_Packets_And_Targets.json.gz','All_Row_Identities.json']
CONFLICTS=['MANDATORY_NULL_UNSUPPORTED','TARGET_SCHEMA_OR_Q_UNSUPPORTED','TARGET_BUS_OUTSIDE_CANDIDATES']

def now():return datetime.now(timezone.utc).isoformat()
def compact(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def bh(v):return hashlib.sha256(v).hexdigest()
def sha(p):return bh(p.read_bytes())
def read(p):return json.loads(p.read_text('utf8'))
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.flush();os.fsync(f.fileno())
def typed(v):
 if v is None:return ['null']
 if isinstance(v,bool):return ['bool',v]
 if isinstance(v,(int,float)):
  assert math.isfinite(v);n,d=v.as_integer_ratio();return ['number',str(n),str(d)]
 if isinstance(v,str):return ['string',v]
 if isinstance(v,list):return ['list',[typed(x) for x in v]]
 assert isinstance(v,dict);return ['object',[[k,typed(v[k])] for k in sorted(v)]]
def identity(v):return bh(compact(typed(v)).encode())
def number(v):return not isinstance(v,bool) and isinstance(v,(int,float)) and math.isfinite(v)
def compare(expected,actual):
 if isinstance(expected,dict):
  assert isinstance(actual,dict)
  for k,v in expected.items():assert k in actual,k;compare(v,actual[k])
 elif isinstance(expected,list):
  assert isinstance(actual,list) and len(expected)==len(actual)
  for a,b in zip(expected,actual):compare(a,b)
 else:assert type(expected)==type(actual) and expected==actual,(expected,actual)
def ended(pid):
 if os.name!='nt':
  try:os.kill(pid,0);return False
  except ProcessLookupError:return True
 kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p
 h=kernel.OpenProcess(0x1000,0,pid)
 if not h:assert ctypes.get_last_error()==87,'Owner end cannot be certified';return True
 try:
  code=ctypes.c_ulong();kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
  assert kernel.GetExitCodeProcess(h,ctypes.byref(code));return code.value!=259
 finally:kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.CloseHandle(h)
def source_inventory(path,names):
 tree=ast.parse(path.read_text('utf8'));constants={};functions={}
 for n in tree.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:constants[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
  if isinstance(n,ast.FunctionDef) and n.name in names:
   assert n.name not in functions;functions[n.name]=bh(ast.dump(n,include_attributes=False).encode())
   if n.name=='severity_stage':constants['_STAGE_RULES']={a:b for a,b in [ast.literal_eval(x.value) for x in ast.walk(n) if isinstance(x,ast.Return)]}
 assert set(functions)==set(names)
 return constants,{'source_sha256':sha(path),'function_ast_sha256':functions,'full_module_imported':False}
def causal_bindings(production):
 tree=ast.parse(production.read_text('utf8'));run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
 expected={'global_uv_buses':['net'],'extract_zone_state_full':['net','z','zones'],'get_zone_candidate_buses':['net','z','zones','zs'],
  'init_feedback_state':[],'build_two_best_prompt_v2':["'reflection_v2'",'zs','uv','cands','[]','mem']}
 counts=Counter()
 for n in ast.walk(run):
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Subscript) and isinstance(n.func.slice,ast.Constant) and n.func.slice.value in expected:
   name=n.func.slice.value;assert [ast.unparse(a) for a in n.args]==expected[name] and not n.keywords;counts[name]+=1
  if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='net' for a in n.targets):
   assert not ({x.id for x in ast.walk(n.value) if isinstance(x,ast.Name)}&{'action','teacher','target','rows','r'})
 assert counts==Counter({k:1 for k in expected})
def line(text,label):
 hits=[x[len(label):] for x in text.splitlines() if x.startswith(label)]
 assert len(hits)==1,label;return hits[0]
def check_prompt(fixture,record,uv,allowed,stage,stage_rules):
 messages=fixture['messages'];assert len(messages)==2 and [m['role'] for m in messages]==['system','user']
 assert all(set(m)=={'role','content'} and isinstance(m['content'],str) for m in messages)
 assert messages[0]['content']=='Return only valid JSON. No markdown. No prose. Use exactly the requested compact JSON schema.'
 text=messages[1]['content'];zs=record['zone_state']
 assert int(line(text,'GLOBAL_UNDERVOLTAGE_COUNT: '))==len(uv)
 assert json.loads(line(text,'GLOBAL_UNDERVOLTAGE_BUSES: '))==uv
 for name in ['zone','min_voltage_pu','max_voltage_pu','n_undervoltage','n_overvoltage','worst_bus']:
  assert line(text,name+': ')==str(zs[name]),name
 for name in ['undervoltage_buses','lowest_voltage_buses']:assert json.loads(line(text,name+': '))==zs[name]
 assert json.loads(line(text,'CANDIDATE_BUSES_YOU_MAY_USE: '))==record['candidates']
 assert json.loads(line(text,'ALLOWED_Q_MVAR_VALUES: '))==allowed
 assert json.loads(line(text,'FAILED_ACTIONS_TO_AVOID_SHORT: '))==[]
 assert text.split('VERIFIER_FEEDBACK_MEMORY:\n',1)[1].split('\n\n',1)[0]=='None'
 assert line(text,'SEVERITY_STAGE: ')==stage
 assert line(text,'STAGE_RULE: ')==stage_rules[stage]
 assert 'COMPACT_VERIFIER_REFLECTION_INSTRUCTION:' in text and '{"bus":"BUS_ID","q_mvar":Q_MVAR}' in text
 for key in ['world_sha256','input_sha256','teacher_action_sha256']:assert record[key] not in text
 assert fixture['prompt_sha256']==record['prompt_sha256']==bh(compact(messages).encode())

def run():
 start=time.perf_counter();prep=BASE/'preparation';execution=BASE/'execution'
 status=read(execution/'status.json');owner=read(execution/'owner.claim');closed=read(execution/'Closed_Manifest.json')
 assert status['state'] in {'ENDED_COMPLETE','ENDED_PARTIAL'} and status['manifest_closed'] is True
 assert owner['actual_pid']==status['actual_pid'] and ended(owner['actual_pid'])
 protocol=read(prep/'Protocol.json');ready=read(READY);lock=read(prep/'Reader_Source_Lock.json')
 assert sha(Path(__file__))==ready['reader_source_sha256']==lock['reader_source_sha256']
 assert sha(READY)==lock['reader_readiness_sha256']
 stamps=[protocol['at_utc'],owner['at_utc'],closed['at_utc'],status['at_utc']]
 assert all(datetime.fromisoformat(a)<=datetime.fromisoformat(b) for a,b in zip(stamps,stamps[1:]))
 assert datetime.fromisoformat(ready['prepared_at_utc'])<datetime.fromisoformat(owner['at_utc'])
 assert sha(PRODUCTION)==protocol['source_sha256']==ready['production_source_sha256']==owner['source_sha256']==closed['source_sha256']
 assert sha(prep/'Protocol.json')==owner['protocol_sha256']==closed['protocol_sha256']
 assert sha(prep/'Protocol.json')==ready['protocol_sha256']
 assert sha(ROOT/'work/candidate_process_evidence_utils.py')==ready['evidence_utils_sha256']
 assert protocol['fits_forwards_PF_optimizer_controller_forecast_tokenizer_cloud_calls']==0 and protocol['bound_seconds']==120
 out=BASE/'independent_audit';out.mkdir(exist_ok=False)
 write(out/'reader.claim',{'actual_pid':os.getpid(),'at_utc':now(),'reader_source_sha256':sha(Path(__file__)),
  'closed_production_manifest_sha256':sha(execution/'Closed_Manifest.json'),'no_frozen_function_or_science_calls':True})
 cost={'independent_current_join_and_contract_analyses':0,'independent_prompt_field_checks':0,'frozen_check_invocations':0,
  'new_fits_model_PF_optimizer_controller_forecast_tokenizer_cloud_calls':0,'frozen_function_invocations':0,'old_archive_rehashes':0,'analysis_and_IO_paid':True}
 report={'all_passed':False,'gate':'UNKNOWN'};failure=None
 try:
  assert set(closed['members'])=={p.name for p in execution.iterdir() if p.is_file()}-{'Closed_Manifest.json','status.json'}
  for name,d in closed['members'].items():assert Path(name).name==name and (execution/name).stat().st_size==d['bytes'] and sha(execution/name)==d['sha256'],name
  constants={};cert={}
  causal_bindings(PRODUCTION)
  for name,d in protocol['source_files'].items():assert sha(Path(d['path']))==d['sha256'],name
  for name,names in protocol['actual_functions'].items():constants[name],cert[name]=source_inventory(Path(protocol['source_files'][name]['path']),names)
  assert sha(OLD/'Closed_Manifest.json')==protocol['old_closed_manifest_sha256']
  oldmanifest=read(OLD/'Closed_Manifest.json');assert set(protocol['old_input_members'])==set(INPUTS)
  for name,d in protocol['old_input_members'].items():
   assert d==oldmanifest['members'][name] and (OLD/name).stat().st_size==d['bytes'] and sha(OLD/name)==d['sha256'],name
  grouped=defaultdict(dict);saved={}
  for member in INPUTS[:2]:
   with gzip.open(OLD/member,'rt',encoding='utf8') as stream:records=json.load(stream)
   for r in records:
    packet=r['packet'];assert set(packet)=={'zone','local_measurements'}
    assert identity(packet)==r['input_sha256'] and identity(r['action'])==r['action_sha256']
    w=r['world_sha256'];z=packet['zone'];assert z not in grouped[w];grouped[w][z]=r
    saved[w,r['input_sha256']]=r
  rows=read(OLD/INPUTS[2]);assert len(rows)==16000 and {r['row_index'] for r in rows}==set(range(16000)) and len(grouped)==109 and len(saved)==436
  counts=Counter((r['world_sha256'],r['input_sha256']) for r in rows)
  assert set(counts)==set(saved)
  for row in rows:assert saved[row['world_sha256'],row['input_sha256']]['action_sha256']==row['action_sha256']
  for key,r in saved.items():assert r['multiplicity']==counts[key]
  assert read(execution/'Actual_Costs.json')['new_model_PF_optimizer_controller_forecast_tokenizer_cloud_calls']==0
  partial=(execution/'Failure.json').exists() or status['state']=='ENDED_PARTIAL'
  if partial:
   assert closed['complete'] is False
   report={'all_passed':True,'gate':'UNKNOWN_OWNER_PARTIAL_NO_RETRY','original_rows':16000,'contract_outcome_certified':False,'no_scientific_retry':True}
  else:
   assert closed['complete'] is True
   import pandas as pd
   compare(cert,read(execution/'Unchanged_Actual_Function_AST_Certificates.json'))
   vmin=constants['rescue']['V_MIN'];vmax=constants['rescue']['V_MAX'];anchors=constants['guided']['ZONE_ANCHORS'];allowed=constants['reflection']['ALLOWED_Q']
   zones={z:[int(b) for b in bs] for z,bs in read(Path(protocol['source_files']['metadata']['path']))['zones'].items()}
   assert set(zones)=={'MG1','MG2','MG3','MG4'} and sum(map(len,zones.values()))==118 and {b for bs in zones.values() for b in bs}==set(range(118))
   pairs=[];worlds=[];unknown=[];expectedfixtures={};uvmaps={}
   for w,views in sorted(grouped.items()):
    if set(views)!=set(zones):unknown.append({'world_sha256':w,'reason':'missing_or_extra_zone'});continue
    joined={};issues=[]
    for z,r in views.items():
     vm=r['packet']['local_measurements'].get('bus_voltages')
     if not isinstance(vm,dict) or {int(b) for b in vm}!=set(zones[z]):issues.append(z+':scope');continue
     for b,v in vm.items():
      if not number(v):issues.append(z+':nonfinite');continue
      assert int(b) not in joined;joined[int(b)]=float(v)
    if set(joined)!=set(range(118)):issues.append('global_scope')
    for z,r in views.items():
     boundary=r['packet']['local_measurements'].get('boundary_voltages')
     if not isinstance(boundary,dict):issues.append(z+':boundary_missing');continue
     for b,v in boundary.items():
      if int(b) not in joined or not number(v) or abs(joined[int(b)]-v)>1e-10:issues.append(z+':boundary_mismatch')
    if issues:unknown.append({'world_sha256':w,'reasons':issues});continue
    uv={str(b):joined[b] for b in sorted(joined) if joined[b]<vmin};uvmaps[w]=uv
    stage='CRITICAL' if len(uv)>40 else 'HIGH' if len(uv)>15 else 'FINISHING'
    worlds.append({'world_sha256':w,'joined_current_vm_sha256':bh(compact(joined).encode()),'initial_global_UV_count':len(uv),'stage':stage,
     'observed_current_join_complete':True,'historical_snapshot_lineage':'UNKNOWN','FIRST_ZONE':sorted(zones)[0]})
    for slot,z in enumerate(sorted(zones)):
     r=views[z];vm=pd.Series([joined[b] for b in zones[z]],index=zones[z],dtype='float64');lowest=vm.sort_values().head(8)
     low={str(int(b)):float(v) for b,v in vm.items() if v<vmin};ov={str(int(b)):float(v) for b,v in vm.items() if v>vmax}
     zs={'zone':z,'min_voltage_pu':float(vm.min()),'max_voltage_pu':float(vm.max()),'n_undervoltage':len(low),'n_overvoltage':len(ov),
      'worst_bus':int(vm.idxmin()),'undervoltage_buses':low,'lowest_voltage_buses':{str(int(b)):float(v) for b,v in lowest.items()}}
     cands=sorted(({int(b) for b in low}|{int(b) for b in zs['lowest_voltage_buses']}|{zs['worst_bus']}|set(anchors.get(z,[])))&set(zones[z]))
     action=r['action'];bus=None;q=None
     if not uv:category='NO_LIVE_SLOT_GLOBAL_HEALTHY'
     elif not cands:category='NO_LIVE_SLOT_NO_CANDIDATES'
     elif action is None:category='MANDATORY_NULL_UNSUPPORTED'
     else:
      sh=action.get('add_shunts_q_mvar') if isinstance(action,dict) else None
      if not isinstance(action,dict) or set(action)!={'add_shunts_q_mvar'} or not isinstance(sh,dict) or len(sh)!=1:category='TARGET_SCHEMA_OR_Q_UNSUPPORTED'
      else:
       try:bus=int(next(iter(sh)))
       except (ValueError,TypeError):bus=None
       q=next(iter(sh.values()))
       category='TARGET_SCHEMA_OR_Q_UNSUPPORTED' if bus is None or not number(q) or q not in allowed else 'TARGET_BUS_OUTSIDE_CANDIDATES' if bus not in cands else 'GRAMMAR_COMPATIBLE_NOT_PHYSICS_CERTIFIED'
     kind='NO_LIVE_CALL' if not uv or not cands else 'INITIAL_FIRST_ZONE_SOURCE_TEMPLATE' if slot==0 else 'COUNTERFACTUAL_EMPTY_HISTORY_LATER_ZONE'
     record={'world_sha256':w,'zone':z,'input_sha256':r['input_sha256'],'teacher_action_sha256':r['action_sha256'],'rows':r['multiplicity'],
      'initial_global_UV_count':len(uv),'candidates':cands,'zone_state':zs,'nominal_teacher_bus':bus,'nominal_teacher_Q':q,'category':category,
      'prompt_kind':kind,'historical_snapshot_lineage':'UNKNOWN','teacher_physics_acceptance':'UNKNOWN_INDEPENDENT_CERTIFICATE'}
     pairs.append(record)
     if kind!='NO_LIVE_CALL':expectedfixtures[w,z]=(record,action,uv,stage)
     else:record['prompt_sha256']=None
   actualpairs=read(execution/'All_Initial_Contract_Compatibility_Records.json');compare(pairs,actualpairs);compare(worlds,read(execution/'All_World_Current_Joins.json'))
   actualmap={(r['world_sha256'],r['zone']):r for r in actualpairs};assert len(actualmap)==len(pairs)
   with gzip.open(execution/'Pure_Prompt_Fixtures_NO_MODEL.json.gz','rt',encoding='utf8') as stream:fixtures=json.load(stream)
   assert len(fixtures)==len(expectedfixtures) and len({(f['world_sha256_ADMIN_NOT_FORWARD'],f['zone']) for f in fixtures})==len(fixtures)
   for f in fixtures:
    key=(f['world_sha256_ADMIN_NOT_FORWARD'],f['zone']);record,action,uv,stage=expectedfixtures[key]
    assert f['kind']==record['prompt_kind'] and f['teacher_target_NOT_FORWARD']==action
    assert f['history_status']==('EMPTY_INITIAL_SOURCE_TEMPLATE' if record['prompt_kind']=='INITIAL_FIRST_ZONE_SOURCE_TEMPLATE' else 'UNKNOWN_ACTUAL;EMPTY_ONLY_FIXTURE')
    check_prompt(f,actualmap[key],uv,allowed,stage,constants['reflection']['_STAGE_RULES']);cost['independent_prompt_field_checks']+=1
   categories=Counter(r['category'] for r in pairs);rowcounts=Counter()
   for r in pairs:rowcounts[r['category']]+=r['rows']
   conflicts=sum(categories[c] for c in CONFLICTS);first=[r for r in pairs if r['prompt_kind']=='INITIAL_FIRST_ZONE_SOURCE_TEMPLATE']
   gate='DIRECT_UNMODIFIED_TARGET_REUSE_FAIL' if conflicts else 'UNKNOWN_COHEENCE_OR_HISTORY' if unknown else 'INITIAL_GRAMMAR_COMPATIBLE_FULL_HISTORY_PHYSICS_UNKNOWN'
   expected={'all_original_rows_retained':True,'original_rows':16000,'worlds':109,'observed_worlds_current_join_complete':len(worlds),'unknown_worlds':unknown,
    'world_zone_pairs_checked':len(pairs),'categories_by_pair':dict(categories),'categories_by_original_row':dict(rowcounts),'mandatory_target_conflicts':conflicts,
    'fixed_gate':gate,'first_zone_templates':len(first),'first_zone_template_categories':dict(Counter(r['category'] for r in first)),
    'all_later_actual_history':'UNKNOWN','exact_historical_execution_snapshot_lineage':'UNKNOWN','physical_outcome_and_LLM_advantage':'UNMEASURED',
    'sourceconsistent_currentjoin_not_original_asset_regeneration':True,'no_automatic_learning_or_GPU':True}
   compare(expected,read(execution/'Results.json'));cost['independent_current_join_and_contract_analyses']=len(pairs)
   calls=read(execution/'Actual_Costs.json')
   compare({'observed_global_uv_extract_returns':len(worlds),'observed_zone_extract_returns':len(pairs),'candidate_function_returns':len(pairs),
    'pure_prompt_fixture_returns':len(fixtures),'faithful_initial_FIRST_ZONE_template_returns':len(first),
    'counterfactual_later_empty_history_fixture_returns':len(fixtures)-len(first)},calls)
   assert number(calls['workflow_seconds_before_manifest']) and 0<=calls['workflow_seconds_before_manifest']<protocol['bound_seconds']
   assert sum(rowcounts.values())+sum(r['multiplicity'] for w in {u['world_sha256'] for u in unknown} for r in grouped[w].values())==16000
   report={'all_passed':True,'gate':gate,'independently_derived':expected,'pandas_version_for_exact_default_ties':pd.__version__,
    'prompt_dynamic_fields_current_only_and_empty_fixture_history_verified':True,'frozen_function_equations_independently_derived_not_invoked':True,
    'action_payload_compatibility_not_unchanged_full_assistant_response_format':True,'full_history_lineage_and_physical_certificates':'UNKNOWN'}
  assert not any(m=='torch' or m=='transformers' or m.startswith('pandapower') or m.startswith('sklearn') for m in sys.modules)
 except BaseException as ex:
  failure=ex;report={'all_passed':False,'gate':'INDEPENDENT_AUDIT_FAIL_NO_RETRY','error':repr(ex),'traceback':traceback.format_exc()}
 fresh=frozen_checks();cost['frozen_check_invocations']=1;assert len(fresh['checks'])==9;write(out/'Fresh_Frozen_Asset_Checks.json',fresh)
 write(out/'Independent_Audit.json',report);cost['workflow_seconds_before_seal']=time.perf_counter()-start;write(out/'Actual_Reader_Costs.json',cost)
 files={p.name:p for p in out.iterdir() if p.is_file()};files.update({'sources/reader.py':Path(__file__),'sources/production.py':PRODUCTION,
  'sources/reader_readiness.json':READY,'sources/evidence_utils.py':ROOT/'work/candidate_process_evidence_utils.py'})
 for directory,label in [(prep,'preparation'),(execution,'execution')]:
  for p in directory.iterdir():
   if p.is_file():files[label+'/'+p.name]=p
 for name in INPUTS:files['locked_existing_inputs/'+name]=OLD/name
 archive=seal(out,files,'Independent_Initial_Reflection_Contract_Gate.zip')
 write(out/'Actual_Reader_Final_Workflow_Cost.json',{'workflow_seconds_including_frozen_checks_and_archive':time.perf_counter()-start,
  'new_science_or_frozen_function_calls':0,'old_archive_rehashes':0,'all_analysis_and_IO_paid':True})
 print(compact({'audit':report,'archive':archive,'workflow_seconds':time.perf_counter()-start}))
 if failure is not None:raise RuntimeError('Independent audit failed; retained once, no retry') from failure

if __name__=='__main__':run()
