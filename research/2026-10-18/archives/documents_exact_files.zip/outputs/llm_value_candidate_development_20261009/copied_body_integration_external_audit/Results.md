# Actual copied-body integration

The separately named original LoRA copy passed the two-step T4 engineering integration. All336 original attention/MLP copy tensors and shared-interface tensors received finite nonzero gradients and actually changed. Frozen base parameters/buffers/quantization and original adapter/tokenizer files remained unchanged. Six real pretrained forwards used237 soft positions each; both actual final scores reproduced exactly after loading a fresh base/model and the preserved step2 checkpoint. Exact runtime release and every closed scientific artifact were verified.

This is genuine internal-weight engineering evidence, not a policy, LLM-superiority or novelty result. Full training, controls/attribution, physical matched trajectories and unused confirmation require separately prospective gates. All actual timing, memory, setup and prior costs remain in the compute summary.
