"""Additive exact v1 engine with source snapshot locks for per-use verification."""
from pathlib import Path
import verified_paid_cache_engine_v1_20261018 as prior
from locked_source_receipt_verifier_v1_20261018 import LockedReceiptVerifier,SOURCE_CERTIFICATE as LEASE_CERTIFICATE
text=Path(prior.__file__).read_text('utf-8');changed=text;edits=[]
def edit(before,after):
    global changed
    assert changed.count(before)==1,(before,changed.count(before))
    changed=changed.replace(before,after);edits.append((before,after))
edit("self.path=Path(path).resolve();assert self.path.is_relative_to(R)","self.path=Path(path).resolve();assert self.path.is_relative_to(R)\n        self.locked_verifier=LockedReceiptVerifier()")
edit("self.pins['warm_independent_certificates']={p:sha(R/p) for p in paths}","self.pins['warm_independent_certificates']={p:sha(R/p) for p in paths}\n        self.pins['locked_source_snapshot']=self.locked_verifier.anchor()")
edit("certify(node['net'],node['cursor'],row,self.primary[key],runner=self.runner,zones=self.zones,ack_path=target)","self.locked_verifier.certify(node['net'],node['cursor'],row,self.primary[key],runner=self.runner,zones=self.zones,ack_path=target)")
edit("def close(self):self.stream.close()","def close(self):self.stream.close();self.locked_verifier.close()")
inverse=changed
for before,after in reversed(edits):assert inverse.count(after)==1;inverse=inverse.replace(after,before)
assert inverse==text
exec(compile(changed,str(Path(__file__)),'exec'),globals())
SOURCE_CERTIFICATE={**SOURCE_CERTIFICATE,'v1_module_retained':True,'v1_inverse_transform_exact':True,
    'locked_pin_service':LEASE_CERTIFICATE,'new_science_or_policy_change':False}
