"""Compact durable resume and screened incremental publication preparation."""
import hashlib,json,os,zipfile
from datetime import datetime,timezone
from pathlib import Path
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];B=R/'outputs/linear_audit_and_admission_handoff_20261018'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    B.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    linear=read(R/'outputs/receding_checkpoints_linear_audit_20261018/Independent_Checkpoint_Audit.json')
    admission=read(R/'outputs/admitted_referenced_runtime_binding_20261018/Results.json')
    lazy=read(R/'outputs/lazy_paid_lineage_receipts_20261018/Results.json')
    assert linear['status'].startswith('PASS_ALL25_') and admission['status'].startswith('PASS_') and lazy['status'].startswith('PASS_')
    audit=R/'outputs/full_receding_paid_campaign_20261015/audit_linear_composed_v4_20261018'
    owner=read(audit/'owner.claim')
    status={'at_utc':at,'status':'ALL25_CHECKPOINT_AUDIT_PASS_ADMISSION_BOUND_FULL_RECORDED_POLICY_READER_RUNNING',
        'verified_all25_checkpoint_prefixes':{'certificate':str((R/'outputs/receding_checkpoints_linear_audit_20261018/Independent_Checkpoint_Audit.json').relative_to(R)),
            'sha256':sha(R/'outputs/receding_checkpoints_linear_audit_20261018/Independent_Checkpoint_Audit.json'),
            'workflow_seconds':linear['workflow_seconds'],'missing26th_state':'UNKNOWN_NOT_RECONSTRUCTED'},
        'predecision_admission':'ALL4 actual roots x BOTH fixed methods;8valid entries,8invalid/expired pre-entry rejections. Actual scientific decision body stubbed for this SOFTWARE gate.',
        'full_native_input_schema':'8 actual input/method admissions and12negative controls; 118buses,9Q,25operations,27,628reference capacity; prospective future states readmitted.',
        'lazy_source_lookup':{'keys':lazy['all_keys'],'boundary_checks':len(lazy['checks']),'science':0,
            'physical_execution_cache':'BLOCKED_PENDING_FULL_PHYSICAL_READER_PASS; absent keys UNKNOWN, not permission. Additivev2 fixes unique-primary versus all-query counter distinction.'},
        'comparison_software_timing':'Fingerprint prototype41checksPASS but slower3.788s vs3.475s, NOT adopted. Direct41checksPASS measured4.074s vs6.029s in separate paired run; timing varies, no solver/deployment gain claimed.',
        'active_reader':{'source':'work/audit_full_receding_linear_composed_v4_20261018.py','actual_pid':owner['actual_pid'],'parent_pid':owner['actual_parent_pid'],
            'source_sha256':owner['source_sha256'],'exec_session':80819,'analysis_bound_seconds':7200,
            'output':str(audit.relative_to(R)),'console':'outputs/receding_linear_composed_reader_console_20261018.log',
            'scope':'ALL recorded policy decisions/closed queries/physical saved outputs/menus/forecasts/commits/full costs plus pinned ALL25 checkpoint audit. Zero new science. Original source/failures preserved.',
            'never_restart_duplicate_or_extend':True},
        'new_model_PF_optimizer_derivative_forecast_factor_solve_calls':0,'GPU_jobs':[],
        'known_physics':'Earlier scoped audit17to0 residualUV on both closed line35 numerical suffixes;11vs14 addedops, no advantage over immediate, no freshLLM/fullDSE/all-severe claim.',
        'all_four_full_policy_gate':'UNKNOWN','all_six_goals':'UNACHIEVED',
        'next_tasks_in_order':[
            'When actual reader11300 and shim15812 end, inspect actual complete report/closed manifest or preserve console failure. No busy-polling/restart/scientific retry.',
            'If readerPASS, bind lazy archived receipts/forecasts/contexts with exact old source references and costs to a new prospective owner. No missing/old attempt repeats; absence in inspected lineage is not global history closure.',
            'Complete new referenced-format ARCHIVAL checkpoint-prefix reader separately from live antirollback restore. Preserve all future-query/reference bounds, original cursor/RNG/full costs/cold/source anchors.',
            'Freeze genuinely unexecuted point/action measurement protocol for ALL previously declared unfinished roots and BOTH fixed methods/strong controls, exact source/ownership/budget/preservation/complete-vs-partial reader BEFORE new physics. No old budget/owner resume.',
            'Only then bind genuine causal original LOCAL-model/family broker and numerical/trained-control ablations for matched complete trajectories; no further size-only imitation reruns. Published benchmark/security gates remain pending.' ],
        'timer_policy':'No new timer yet; use a single estimated waiting check only if confirmed live result becomes sole dependency and no substantive parallel task remains. Prior recurring timers stay deleted.'}
    put(B/'Exact_Next_Execution_State.json',status)
    note=f'''Continued at {at}.

Before:25 complete checkpoints required repeated scans of a growing journal.
After:all25 saved states, journal/history prefixes, paid caches/forecasts, native
contexts, cursor/caps/stock/RNG/source and cost boundaries passed one linear
independent audit. Missing26th complete state remains UNKNOWN.

Before:full-native input checks were standalone.
After:checks are bound before every actual engine decision and before queries;
ALL4 roots x2methods pass, invalid inputs and expired budgets reject before
entry. This software test stubs the scientific body: no policy gain follows.

Read-only lazy lookup retains all60,377 inspected-lineage identities and exact
source references without expanding all receipts into checkpoints.7boundary
checks passed. It blocks execution reuse pending the full physical reader,
and missing keys are UNKNOWN. Prior solver exceptions and paid costs remain.
The first fingerprint shortcut was slower and is retained as adverse evidence.
The direct exact comparator passed41checks on29actual NETs; software timing is
not a physical or deployment-efficiency result.

The new sole full recorded-policy reader is running at actualPID{owner['actual_pid']},
parent{owner['actual_parent_pid']}, execsession80819, fixed7200-second analysis bound.
Original worker/reader sources and failures remain. No new scientific/model/
GPU call or old owner restart. ALL4/fullpolicy/LLM superiority gates UNKNOWN.
See Exact_Next_Execution_State.json for exact continuation and limitations.
'''
    (B/'Results_And_Next_Execution.md').write_text(note,encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+note)
    header=f'18OCT ALL25 CHECKPOINT PREFIXES PASS; ADMISSION BOUND; FULL PHYSICAL POLICY READER LIVE {at}\n\n'+note+'\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_INDEX.md']:
        path=R/rel;path.write_text(header+path.read_text('utf-8'),encoding='utf-8')
    for rel in ['outputs/critical_research_reset_20261010/Research_Resume_20261012.json','outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json']:
        path=R/rel;d=read(path);d['latest_20261018_linear_audit_and_admission']=status;put(path,d)
    path=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(path)
    tasks['tasks'][0]['status']=status['status'];tasks['tasks'][0]['done']+=' All25 complete checkpoint prefixes independently PASS, actualengine predecision admission8valid/8rejectionsPASS;lazy60377source lookup7boundariesPASS. Fullrecordedpolicyzero-science additive readerlive; fullgateUNKNOWN.'
    tasks['tasks'][0]['next']='Read outputs/linear_audit_and_admission_handoff_20261018/Exact_Next_Execution_State.json. Do not duplicate/restart active reader or new physics before all prospective gates.';tasks['at_utc']=at;put(path,tasks)
    # Screen only this bounded incremental unit; never package raw journals,
    # capsules, checkpoint tensors, credentials, runtime/cache or live outputs.
    names=['exact_input_fingerprint_v1_20261018.py','check_exact_input_fingerprint_20261018.py',
        'exact_input_pair_equality_v1_20261018.py','check_exact_input_pair_equality_20261018.py',
        'referenced_runtime_input_admission_v1_20261018.py','check_referenced_runtime_input_admission_20261018.py',
        'audit_receding_checkpoints_linear_20261018.py','prepare_receding_linear_composed_reader_20261018.py','audit_full_receding_linear_composed_v4_20261018.py',
        'receding_paid_admitted_referenced_runtime_v1_20261018.py','check_admitted_referenced_runtime_binding_20261018.py',
        'lazy_paid_lineage_receipts_v1_20261018.py','lazy_paid_lineage_receipts_v2_20261018.py','check_lazy_paid_lineage_receipts_20261018.py',Path(__file__).name]
    files=[R/'work'/name for name in names]
    for rel in ['exact_input_fingerprint_20261018','exact_input_pair_equality_20261018','referenced_runtime_input_admission_20261018',
        'receding_checkpoints_linear_audit_20261018','receding_linear_composed_reader_preparation_20261018',
        'admitted_referenced_runtime_binding_20261018','lazy_paid_lineage_receipts_20261018']:
        files+=list((R/'outputs'/rel).glob('*.json'))
    files+=[B/'Exact_Next_Execution_State.json',B/'Results_And_Next_Execution.md']
    files=sorted(set(files));members={}
    archive=B/'Linear_Checkpoints_Admission_And_Reader_Source_20261018.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in files:
            raw=path.read_bytes();text=raw.decode('utf-8');assert not any(p.search(text) for p in SECRET),str(path)
            key=str(path.relative_to(R)).replace('\\','/');z.writestr(key,raw);members[key]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for key,item in members.items():assert hashlib.sha256(z.read(key)).hexdigest()==item['sha256']
    put(B/'Local_Incremental_Archive_Audit.json',{'status':'PASS_CRC_EVERY_MEMBER_SHA256_SECRET_SCREEN','archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':members,
        'raw_checkpoint_capsule_journal_data_stays_local':True,'live_reader_result_not_claimed':True})
    print(json.dumps({'saved':'PASS','archive_members':len(files),'archive_bytes':archive.stat().st_size,'active_reader_pid':owner['actual_pid'],'new_science':0}))
if __name__=='__main__':main()
