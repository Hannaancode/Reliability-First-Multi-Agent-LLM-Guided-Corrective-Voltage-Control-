"""Frozen native GraphAgent continuation with paid-input history and full state."""
import copy,gzip,hashlib,json,os,pickle,sys,time,traceback
from pathlib import Path
from datetime import datetime,timezone
from reflection118_chronological_core_20261022 import R,read,put,sha,capsule,decode,canonical,frames_equal
P=R/'outputs/graph118_native_campaign_preparation_20261028'
E=R/'outputs/graph118_native_campaign_execution_20261028'
A=R/'outputs/graph118_native_campaign_independent_20261028'
OLD=R/'outputs/published_graph118_paid_transition_20261022'
class StopBeforeEntry(BaseException):pass

def setup():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np,pandapower as pp
    return np,pp

def pins(p):
    for name,h in p['source_hashes'].items(): assert sha(R/name)==h,name
    for name,h in p['input_hashes'].items(): assert sha(R/name)==h,name

def owner(out,began):
    out.mkdir(exist_ok=False)
    put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid()))
    while not (out/'Launcher_ACK.json').exists():
        assert time.monotonic()-began<120;time.sleep(.1)
    a=read(out/'Launcher_ACK.json')
    assert a['actual_pid']==os.getpid() and a['parent_pid']==os.getppid() and a['fresh_exact_source_PID_parent_command']

def metrics(net):
    import numpy as np
    if not net.converged:return dict(UV=None,OV=None,whole_band=None,converged=False)
    v=net.res_bus.vm_pu.to_numpy(float);assert len(v)==118 and np.isfinite(v).all()
    return dict(UV=int((v<.95).sum()),OV=int((v>1.05).sum()),whole_band=bool(((v>=.95)&(v<=1.05)).all()),
                vmin=float(v.min()),vmax=float(v.max()),deficit=float(np.maximum(.95-v,0).sum()),converged=True)

def controls(net):
    return {t:[[int(i),int(x.bus),float(x.vm_pu)] for i,x in net[t].iterrows()
               if bool(x.in_service) and bool(net.bus.at[int(x.bus),'in_service'])] for t in ['gen','ext_grid']}

class History:
    def __init__(self,p,proof_folder):
        from prior_physical_query_footprints_20261018 import component,decode as prior_decode
        from run_reflection118_chronological_local_20261022 import necessary
        from resolve_original_role_input_component_collisions_20261022 import load_component
        self.component,self.prior_decode,self.necessary,self.load_component=component,prior_decode,necessary,load_component
        self.rows=read(R/p['registry'])['rows'];self.groups={};self.proof_folder=proof_folder
        for r in self.rows:self.groups.setdefault(r['resource_key'],[]).append(r)
        self.tracked=json.loads(gzip.decompress((R/p['tracked']).read_bytes()))
        self.extra=read(R/p['extra']);self.snapshots=read(R/p['snapshots']);self.decoded={}
        self.costs=dict(native_input_attempts=0,native_input_returns=0,source_result_extractions=0,identity_receipts=0,native_algorithm_invocations=0,seconds=0.)
    def key(self,net):return self.component(net)[0]+':'+hashlib.sha256(canonical(self.necessary(net))).hexdigest()
    def add(self,folder,path,row):
        r=dict(directory=folder.relative_to(R).as_posix(),source=path.relative_to(R).as_posix(),source_sha256=sha(path),
               before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=row['exception'])
        from r118_dff_missing_continuation_core_20261023 import saved_net
        self.groups.setdefault(self.key(saved_net(folder,row['before'])),[]).append(r)
    def lookup(self,net,kwargs):
        from r118_dff_missing_continuation_core_20261023 import saved_net
        needed=self.necessary(net);shunt=self.component(net)[0];c=controls(net);witness=[];same=[]
        for r in self.groups.get(self.key(net),[]):
            before=saved_net(R/r['directory'],r['before'])
            if controls(before)!=c:witness.append(dict(source=r['source'],reason='DIFFERENT_ACTIVE_REGULATOR_INPUT'));continue
            same.append((r,before))
        # Use one first qualifying same-contract record only. Identity failure
        # blocks entry; no alternative-reference or fresh-physics rescue.
        if same:
            r,before=same[0]
            if r.get('kwargs')!=kwargs or r.get('after') is None or r.get('exception') is not None:
                raise StopBeforeEntry('PRIOR_FAILED_UNCLOSED_OR_DIFFERENT_CONTRACT_INPUT: '+r['source'])
            from native_solver_input_identity_v3_20261023 import native_input_prefix,assert_solver_input_identity,map_paid_return
            d=self.proof_folder/f"identity_{self.costs['identity_receipts']:05d}";d.mkdir(parents=True,exist_ok=False)
            put(d/'Reservation.json',dict(reference=r,kwargs=kwargs,new_nonlinear_calls_allowed=0))
            target=capsule(d/'target.zlib',net);tick=time.perf_counter()
            self.costs['native_input_attempts']+=1;newargs=native_input_prefix(copy.deepcopy(net),kwargs);self.costs['native_input_returns']+=1
            new=capsule(d/'newargs.zlib',newargs)
            self.costs['native_input_attempts']+=1;oldargs=native_input_prefix(copy.deepcopy(before),kwargs);self.costs['native_input_returns']+=1
            old=capsule(d/'oldargs.zlib',oldargs);assert_solver_input_identity(newargs,oldargs)
            returned=map_paid_return(newargs,saved_net(R/r['directory'],r['after']));self.costs['source_result_extractions']+=1
            frames_equal(net,returned);after=capsule(d/'mapped.zlib',returned)
            self.costs['identity_receipts']+=1;self.costs['seconds']+=time.perf_counter()-tick
            proof=dict(kind='DERIVED_EXACT_NATIVE_INPUT_NOT_NEW_PF',reference=r,before=target,after=after,newargs=new,oldargs=old,kwargs=kwargs)
            put(d/'Receipt.json',proof)
            return returned,dict(kind=proof['kind'],proof=(d/'Receipt.json').relative_to(R).as_posix(),proof_sha256=sha(d/'Receipt.json'))
        for ref in self.tracked.get(shunt,[]):
            before=self.prior_decode((R/ref['journal']).parent,ref['before'])
            if self.necessary(before)!=needed:reason='DIFFERENT_LOAD_OR_OUTAGE'
            elif controls(before)!=c:reason='DIFFERENT_ACTIVE_REGULATOR_INPUT'
            else:raise StopBeforeEntry('RETAINED_TRACKED_INPUT_UNRESOLVED: '+ref['id'])
            witness.append(dict(reference=ref,reason=reason))
        extra=[x for x in self.extra.get(shunt,[]) if x['necessary_input']==needed]
        loadkey=hashlib.sha256(canonical(self.load_component(net.bus,net.load))).hexdigest()
        snapshots=[x for x in self.snapshots if x.get('shunt_key')==shunt and x.get('nominal_load_key')==loadkey]
        if extra or snapshots:raise StopBeforeEntry('RETAINED_EXTRA_OR_SNAPSHOT_INPUT_UNRESOLVED')
        return None,dict(kind='UNENTERED_IN_FIXED_RETAINED_SCOPE',exclusions=witness,additional_unresolved=0,snapshot_unresolved=0)

def manifest(out):
    put(out/'Closed_Manifest.json',dict(members={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}))

def check_manifest(out):
    for name,h in read(out/'Closed_Manifest.json')['members'].items():assert sha(out/name)==h,name

def frozen():
    from candidate_process_evidence_utils import frozen_checks
    return frozen_checks()
