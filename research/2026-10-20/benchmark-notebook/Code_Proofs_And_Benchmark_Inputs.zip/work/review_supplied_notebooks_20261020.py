"""Read-only notebook reference intake. Never execute notebook code or outputs."""
import hashlib,json,re,zipfile
from pathlib import Path
from datetime import datetime,timezone
from prepare_github_research_snapshot_20261018 import SECRET

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/notebook_reference_review_20261020'
NAMES=['RAG_Based_Integration_NERC (3).ipynb','RAG_Based_Integration (4).ipynb','Lora_rebbutal_1 (1).ipynb','25_ietration_run.ipynb','reflection (1).ipynb','phase_2A_Lora_traininf_1ipynb.ipynb']
SELECT={NAMES[0]:[2,5,8],NAMES[1]:[2,6,7,15],NAMES[2]:[53,106,125,216],NAMES[3]:[4,35,36],NAMES[4]:[4,46,51],NAMES[5]:[9,26,29,37,38,40,41,46,50]}
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
def clean(s):
    return '\n'.join('[CREDENTIAL-LIKE LINE WITHHELD]' if any(p.search(l) for p in SECRET) else l for l in s.splitlines())
def outtext(c):
    rows=[]
    for o in c.get('outputs',[]):
        t=o.get('text',o.get('data',{}).get('text/plain',[]))
        rows.append(''.join(t) if isinstance(t,list) else str(t))
    return '\n'.join(rows)
def main():
    OUT.mkdir(exist_ok=False);(OUT/'local_reference_extracts').mkdir()
    inv=[];evidence=[]
    for k,name in enumerate(NAMES):
        p=Path(r'C:\Users\HOME\Downloads')/name;raw=p.read_bytes();n=json.loads(raw.decode('utf-8'))
        cells=n['cells'];source='\n'.join(''.join(c.get('source',[])) for c in cells if c['cell_type']=='code')
        inv.append({'file':name,'local_original':str(p),'bytes':len(raw),'sha256':sha(raw),'code_cells':sum(c['cell_type']=='code' for c in cells),'markdown_cells':sum(c['cell_type']=='markdown' for c in cells),'cells_with_saved_outputs':sum(bool(c.get('outputs')) for c in cells),'saved_error_outputs':sum(o.get('output_type')=='error' for c in cells for o in c.get('outputs',[])),'cells_executed_by_this_review':0,'contains_credential_like_source':any(p.search(source) for p in SECRET)})
        for num in SELECT[name]:
            c=cells[num-1];s=''.join(c.get('source',[]));text=outtext(c)
            path=OUT/'local_reference_extracts'/f'notebook_{k+1}_cell_{num:03d}.txt'
            path.write_text(clean(s),encoding='utf-8')
            hits=[clean(l) for l in text.splitlines() if re.search(r'Num Epochs|Total steps|Trainable parameters|Saved full ultra|Max tokens:|Records over|Bank fingerprint:|Retained:|Rejected:|phase2g_total_final_uv_matched|router_total_final_uv_matched|matched_case|cases_where_2g',l)]
            evidence.append({'notebook':name,'cell_one_based':num,'source_sha256':sha(s.encode()),'sanitized_local_extract':str(path.relative_to(ROOT)),'historical_output_excerpt':hits[:20],'output_is_not_fresh_execution_or_independent_audit':True})
    put(OUT/'Notebook_Inventory.json',inv);put(OUT/'Cell_Indexed_Evidence.json',evidence)
    # Read JSON metadata only; never deserialize optimizer/training_args binaries.
    archive=Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\zone_agent_shared_lora_qwen05b_ultra_v1.zip')
    with zipfile.ZipFile(archive) as z:
        root=next(n for n in z.namelist() if n.endswith('/adapter_config.json') and 'checkpoint-' not in n)
        final=next(n for n in z.namelist() if n.endswith('/checkpoint-2000/trainer_state.json'))
        a=json.loads(z.read(root));t=json.loads(z.read(final))
        metadata={'archive_local':str(archive),'adapter_member':root,'adapter_member_sha256':sha(z.read(root)),'trainer_member':final,'trainer_member_sha256':sha(z.read(final)),
          'adapter':{k:a.get(k) for k in ['base_model_name_or_path','r','lora_alpha','lora_dropout','target_modules','peft_type','task_type']},
          'final_trainer':{k:t.get(k) for k in ['epoch','global_step','max_steps','num_train_epochs','train_batch_size','best_model_checkpoint']},
          'last_saved_evaluation':t.get('log_history',[])[-1:],
          'supports_notebook_ultra_recipe_consistency':t['global_step']==2000 and t['train_batch_size']==4 and a['r']==16 and a['lora_alpha']==16,
          'exact_notebook_run_to_adapter_weight_identity_proved':False,'base_revision_and_actual_collator_loss_mask_not_recovered':True,'whole_archive_not_rehashed':True}
    put(OUT/'Original_Adapter_Metadata_Reconciliation.json',metadata)
    resources=sorted((ROOT/'outputs/resource_checks').glob('20261020_*.json'))
    assert resources
    report=json.loads(resources[-1].read_text(encoding='utf-8'))
    assert all(x['check_succeeded'] for x in report['profiles'].values())
    put(OUT/'Current_Colab_Access.json',report)
    put(OUT/'Review_Checkpoint.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'SIX_NOTEBOOK_REFERENCE_INTAKE_AND_THREE_PROFILE_ACCESS_COMPLETE','notebook_cells_executed':0,'model_PF_optimizer_allocation_calls':0,'verified_profiles':3,'fourth_configured_profile_found':False,'new_findings':['Recovered original ultra-compact training transformation and512-token rank16 two-epoch recipe, with saved2000-step trainer metadata consistency.','Notebook has no explicit assistant-only masking collator; actual historical dependency/default loss mask remains unverified.','Full-chat original, compact1024 and ultra512 records are distinct representations. Old full-chat context audit is not an audit of the ultra512 training representation.','RAG answer similarity/citation tests and federatedSAC/EV experiments are distinct tasks from corrective-voltage LLM control.','Saved131-case comparison reports188 residual Phase2G UV versus437 router on matched historical cohort; saved output alone does not independently prove fairness or current-system superiority.'],'next':'Continue G3/G2 native benchmark input/action/observation/split contracts; recover strong native baselines and fix explicit model adaptation before performance. No old scientific owner resumed.'})
    print(json.dumps({'notebooks':len(inv),'cell_evidence_records':len(evidence),'verified_profiles':3,'new_science_calls':0}))
if __name__=='__main__':main()
