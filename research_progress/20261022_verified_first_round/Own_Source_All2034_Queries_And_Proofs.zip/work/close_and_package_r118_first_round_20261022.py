"""Save complete first-menu evidence and exact unfinished trajectory tasks."""
import hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/r118_verified_first_round_completion_20261022'
def read(p):return json.loads((R/p).read_text('utf-8'))
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf-8')
def main():
    O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    summary=read('outputs/r118_first_round_missing_only_report_v2_20261022/Case_Summaries.json')
    assert all(c['first_round_source_choice_status']=='EXACT_FROM_COMPLETE_FIXED_MENU' for c in summary['cases'])
    prefix=read('outputs/r118_source_first_commit_reconstruction_v2_20261022/Verified_First_Commit_And_Continuation_Gates.json');assert prefix['status'].startswith('PASS_ALL4_ORIGINAL_DFF')
    put(O/'Verified_First_Round_Results.json',summary)
    resume=dict(at_utc=now,status='COMPLETE_VERIFIED_FIRST_MENUS_AND_SOURCE_FIRST_COMMIT_CURSORS',all6_final_goals='OPEN',current_owned_jobs=[],current_GPU_assignments=0,current_timers=[],
        completed='All2034 original first-menu identities across all4 fixed severe roots have measured/reused native80 results or one preserved actual solver failure; no missing-contract identities remain after a separate3query/3replay prospective addendum.',
        native_costs=dict(bulk_attempts=1989,bulk_returns=1988,bulk_exceptions=1,bulk_first_replays=1988,remaining_contract_attempts=3,remaining_contract_returns=3,remaining_first_replays=3,old_paid_native80_reuses=42,earlier_one_input_bridge_attempts=1,earlier_one_input_bridge_first_replays=1),
        reader_quality=dict(maximum_new_return_field_delta=0.,maximum_KCL_pu=summary['maximum_KCL_pu']),
        source_first_commit_cursors='outputs/r118_source_first_commit_reconstruction_v2_20261022',remaining_original_operations=24,
        source_prefix_caveat='Original outer controller/generator/score/apply executed against exact memoized paid verifier receipts, warm/cold checkpoints equal. Cached reconstruction, not a fresh or complete25step trajectory; all underlying costs remain paid.',
        next_tasks=[
          'Freeze a missing-only FULL original DFF continuation for all4 fixed source roots. Bind these first-commit source cursors,24remaining operations, exact original native solver/Q/cap/verifier/score and complete old/new successful/failed/unknown query registry. Cold reconstruct from paid first menus without new physics before any new context. One prospective owner/reader/fullcost protocol with fixed bounds, no old restart/extension.',
          'Complete original trained Reflection-v4 on the other3 unexecuted registered roots under separate source/loader/context/causal-memory/preservation/ownership/first-new-replay gates. Reuse paid exact physics only; retain every actual model call and full both-branch/model/training/preparation/failure costs. Historical development remains development.',
          'Complete published GraphAgent full native and explicitly named shared-role protocols. Compatible archived source/native cap136/truncationFalse and ALL4 actual fresh-process cursor tests are saved. Actuators/horizons/protection differ; do not count native integration as a same-resource win or exact historical PowerWorld replay.',
          'Any new LLM intervention needs a materially justified objective and strong same-information numerical/architecture/pretraining controls. Fixed frozen-encoder test failed80% gate and stays stopped; no minor retuning or automatic GPU campaign.'],
        all_unknown_adverse_partial_failed_and_frozen_original_evidence_preserved=True,
        no_full_DSE_LLM_or_external_superiority_or_security_claim=True,
        latest_verified_GitHub='6b56694ccb36967cb347f7cf51292a14873d51d3',publication='This closure/results pack pending leased publication; previous exact-byte receipts retained.')
    put(O/'Current_Resume.json',resume)
    text='''# Verified progress — 22 October 2026

All current science and reader jobs ended. All three earlier T4 runtimes were released. The one-time audit timer was deleted when its result completed.

The complete first-round DFF candidate menus on all four fixed severe118 roots are now verified:2,034 identities, including42 reused native80 returns. The new bulk measured1,989 inputs (1,988 returns and one preserved solver exception). A separate prospective three-input native80 contract study and three first replays resolved the remaining gaps; no old50 call or already executed80 call was repeated. Every new successful return reproduced all recorded numerical fields exactly. The original exception remains a policy rejection, not proof of physical infeasibility.

| Fixed root | Initial UV | Original DFF first choice UV | Strict OV after |
| --- | ---: | ---: | ---: |
| line35 MG1 | 56 | 37 | 1 |
| line36 MG1 | 58 | 39 | 2 |
| line84 MG2 | 57 | 37 | 3 |
| line127 MG3 | 55 | 37 | 2 |

These are first-round choices under the unchanged native1.06 verifier, with strict1.05 overvoltage reported separately. They are not full25step endpoints or a matched contrast against the original model's17step56to7UV/twoOV episode. Complete all-case trajectories, full literalDSE/both branches and costs, strong controls and unused confirmation are still required.

The original DFF outer controller, candidate generator, score and action application have now produced identical warm/cold first-commit source cursors for all four cases using the exact paid verifier table. Each has24original operations remaining. This cache reconstruction made no new model or physics call and is not a fresh trajectory. The original namespace engineering failure is retained with its additive repair.

The three-GPU frozen-feature test completed and passed feature/cold/readout audits: trained0.5B71.875%, public0.5B59.375%, public1.5B64.583%, same-current numeric75% exact teacher action. The fixed80% primary gate failed and stops. Historical private training overlap is disclosed; no unseen or physical superiority is established.

Published GraphAgent integration now has a compatible archived environment pin and full actual fresh-process cursor checks on all four saved prefixes, with zero new physics/model/commits. Native cap136 and disabled voltage truncation are documented. Native actuator/horizon/safety differences require explicit protocols before full comparison.

All six final goals remain open. Next priority is complete matched trajectories and relevant external methods on the same cases. No outcome-driven rescue, weakened comparator or guaranteed win. All old data/source/costs/failures stay; private raw NETs and weights remain local. Compact public source/proofs are not a complete raw backup.
'''
    (O/'Results_And_Next_Decision.md').write_text(text,encoding='utf-8')
    paths=[R/'outputs/r118_first_round_missing_only_report_v2_20261022/All2034_Queries.csv']
    for pattern in ['*remaining_r118_native80*20261022.py','*r118_remaining_native80*20261022.py','*r118_first_round_contract_addendum*20261022.py','summarize_verified_r118_first_round_v2_20261022.py','normalize_native80_receipt_labels_before_launch_20261022.py','reconstruct_r118_source_first_commit*20261022.py','repair_r118_first_commit_namespace_v2_20261022.py']:
        paths.extend((R/'work').glob(pattern))
    paths.extend([Path(__file__),R/'outputs/r118_remaining_native80_contracts_preparation_20261022/Protocol.json',R/'outputs/r118_remaining_native80_contracts_independent_20261022/Independent_Audit.json',R/'outputs/r118_source_first_commit_reconstruction_v2_20261022/Verified_First_Commit_And_Continuation_Gates.json',R/'outputs/r118_source_first_commit_reconstruction_20261022/Failure.json'])
    members=[];pack=O/'Own_Source_All2034_Queries_And_Proofs.zip'
    with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(paths)):
            b=p.read_bytes();assert not any(s.search(b.decode('utf-8')) for s in SECRET);n=p.relative_to(R).as_posix();z.writestr(n,b);members.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    with zipfile.ZipFile(pack) as z:assert z.testzip() is None
    put(O/'Artifact_Index.json',dict(members=members,all2034query_rows_included=True,private_raw_NET_and_weights_local_only=True,new_scientific_calls_in_packaging=0))
    files=[]
    for p in [pack,O/'Artifact_Index.json',O/'Verified_First_Round_Results.json',O/'Results_And_Next_Decision.md',O/'Current_Resume.json']:
        b=p.read_bytes();files.append(dict(local=p.relative_to(R).as_posix(),path='research_progress/20261022_verified_first_round/'+p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
    put(O/'Publication_Files.json',files)
    header='## All4 native first menus independently COMPLETE; no current jobs/GPU/timer — '+now+'\n\nRead outputs/r118_verified_first_round_completion_20261022/Current_Resume.json. All2034 first-round identities accounted:bulk1989attempts/1988returns/1exception,42paid80reuses,remaining3native-contract queries+3firstreplays COMPLETE/PASS. All new fields reproduced exactly; failed/old physics not repeated. First source choices UV56to37,58to39,57to37,55to37 withstrictOV1/2/3/2 underoriginal1.06guard. These are first choices,not25step endpoints/LLM superiority. Original source first-commit memoized warm/cold cursors PASS all4,24remaining operations; no new physics. ThreeT4featurearms complete/released,fixedgateFAIL71.875%vsnumeric75%;no retunes. ExternalGraph actualfreshcursor/sourceversion gatesPASS,no fullpolicy. All6finalgoalsOPEN. LastGitHub6b56694ccb36967cb347f7cf51292a14873d51d3 exactbytes; this results pack publication pending.\n\n'
    for n in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/n;p.write_text(header+p.read_text('utf-8'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+text+'\nSaved '+now+'\n')
    tasks=read('outputs/research_tasks_20261014/Tasks.json');tasks.update(latest_verified_update=now,latest_resume=(O/'Current_Resume.json').relative_to(R).as_posix(),current_owned_jobs=[],current_GPU_assignments=0,current_waiting_automations=[])
    t=next(t for t in tasks['tasks'] if t['checklist_id']=='G3');t.setdefault('subtasks',[]).append(dict(id='G3.native118.all_first_menus_20261022',completed=True,description='Verify all2034 original first-round source decisions, retain one failure, resolve3native contracts, and reconstruct all4first-commit cursors. Whole trajectories still open.',evidence=(O/'Verified_First_Round_Results.json').relative_to(R).as_posix(),verified_at_save=now));t['completed']=False
    (R/'outputs/research_tasks_20261014/Tasks.json').write_text(json.dumps(tasks,indent=2),encoding='utf-8')
    put(R/'outputs/full_system_comparison_20261021/Verified_First_Round_Continuation_20261022.json',dict(at_utc=now,newest_active_continuation=(O/'Current_Resume.json').relative_to(R).as_posix(),all_jobs_ended=True,timers_deleted=True))
    print(json.dumps(dict(saved=True,publication_files=5,zip_bytes=pack.stat().st_size(),all6_goals='OPEN')))
if __name__=='__main__':main()
