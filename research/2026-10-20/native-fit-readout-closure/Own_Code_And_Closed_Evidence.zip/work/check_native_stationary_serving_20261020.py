"""Check actual paid FIT serving identity and rejected boundaries; zero scientific calls."""
import json,hashlib,copy,time
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from native_stationary_serving_contract_20261020 import extract_joint_state,stationary_state,encode_current,native_transition,native_guard
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    started=time.perf_counter();out=ROOT/'outputs/native_stationary_serving_boundary_20261020';out.mkdir(exist_ok=False)
    prep=ROOT/'outputs/native_stationary_readout_preparation_20261020';data=np.load(prep/'Grouped_Same_Current_Only_Numeric_FIT.npz')
    items=json.loads((prep/'All_Complete_Grouped_Causal_Text_And_Actual_Token_IDs.json').read_text(encoding='utf-8'))
    rows=json.loads((ROOT/'outputs/native_fit_training_inputs_20261020/All_FIT_Complete_Causal_Inputs_And_Separated_Labels.json').read_text(encoding='utf-8'))
    graph=np.load(ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz')
    proof=[]
    for item in items:
        first=item['metadata_not_forwarded']['all_source_rows'][0];state=stationary_state(extract_joint_state(rows[first]['input_text']));before=copy.deepcopy(state)
        text,features=encode_current(state,graph['Y'],float(graph['baseMVA']));assert state==before
        assert text==item['input_text'] and hashlib.sha256(text.encode()).hexdigest()==item['input_sha256']
        assert np.array_equal(features,data['X'][item['id']]) and item['attention_mask']==[1]*len(item['input_ids'])
        proof.append({'id':item['id'],'text_sha256':item['input_sha256'],'all400_numeric_features_exact':True,'tokens':item['tokens'],'original_multiplicity':len(item['metadata_not_forwarded']['all_source_rows'])})
    teacher=json.loads((ROOT/'outputs/native_fit_teacher_execution_20261020/Result.json').read_text(encoding='utf-8'));decisions=0;guard_rejections=0
    for world in teacher['all_worlds']:
        for d in world['steps']:
            q=np.asarray(d['current_Q'],dtype=np.float64);u=np.asarray(d['raw_teacher_u'],dtype=np.float32)
            assert np.array_equal(native_transition(q,u),q-u)
            accepted=native_guard(d['current_vm'],d['candidate_vm']);assert accepted==d['accepted'];guard_rejections+=not accepted;decisions+=1
    assert len(proof)==241 and sum(v['original_multiplicity'] for v in proof)==decisions==1929 and guard_rejections==11
    state=stationary_state(extract_joint_state(rows[0]['input_text']));negative=[]
    def reject(name,change):
        changed=copy.deepcopy(state);change(changed)
        try:encode_current(changed,graph['Y'],float(graph['baseMVA']))
        except (ValueError,TypeError):negative.append(name)
        else:raise AssertionError('Bad serving input accepted: '+name)
    reject('teacher_label_in_forward',lambda s:s.update(target=[0,0,0]))
    reject('teacher_label_nested',lambda s:s['network'].update(teacher='secret'))
    reject('missing_current_P',lambda s:s['current_measurements'].pop('net_P_injection_mw'))
    reject('nonfinite_VM',lambda s:s['current_measurements']['Vm_pu'].__setitem__(0,float('nan')))
    reject('wrong_actuator_namespace',lambda s:s['control'].__setitem__('actuator_bus_ids',[1,6,8]))
    reject('invented_Q_cap',lambda s:s['control'].__setitem__('absolute_Q_hardware_cap',.3))
    reject('wrong_native_units',lambda s:s['control'].__setitem__('transition','absolute Q output'))
    reject('duplicate_Y_entry',lambda s:s['network']['Ybus_pu_sparse_ij_real_imag'].append(s['network']['Ybus_pu_sparse_ij_real_imag'][0]))
    reject('missing_Y_entry',lambda s:s['network']['Ybus_pu_sparse_ij_real_imag'].pop())
    reject('changed_voltage_band',lambda s:s['operating_rule'].__setitem__('whole_grid_voltage_band_pu',[.94,1.06]))
    try:native_transition(np.zeros(3,dtype=np.float32),np.zeros(3,dtype=np.float32))
    except ValueError:negative.append('float32_Q_cursor_rejected')
    else:raise AssertionError('Q precision weakened')
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ACTUAL241_SERVING_TEXT_TOKEN_PROVENANCE_NUMERIC400_ALL1929_NATIVE_TRANSITIONS_GUARDS_AND11_NEGATIVE_BOUNDARIES',
            'actual_current_inputs':241,'all_weighted_rows':1929,'all_current_text_bytes_and400_features_exact':True,
            'cached_actual_paired_tokenIDs_reused_from_byte_identical_text':True,'new_tokenizer_encodings':0,
            'native_float64Q_minus_float32u_checks':decisions,'all_measured_guards_exact':decisions,'rejected_guard_cases_retained':11,
            'negative_boundaries_rejected':negative,'new_model_PF_optimizer_derivative_factor_solve_GPU_calls':0,
            'readiness_scope':'Serving software only; no DEV/confirmation inference, feature extraction, physical result, novelty or LLM superiority.',
            'serving_source_sha256':sha(ROOT/'work/native_stationary_serving_contract_20261020.py'),
            'checker_source_sha256':sha(Path(__file__)),'workflow_seconds':time.perf_counter()-started}
    with (out/'Readiness.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
    with (out/'All241_Serving_Input_Proofs.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
    print(result['status'])
if __name__=='__main__':main()
