"""Independent saved-message reader using line parsing, no primary functions."""
from pathlib import Path
import json,hashlib,collections
R=Path(__file__).resolve().parents[1];D=R/'outputs/original_prompt_candidate_diagnosis_20261028';O=D/'independent'
def rd(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 O.mkdir(exist_ok=False);result=rd(D/'Results.json');rows=rd(D/'Per_Response_Checks.json');totals={k:collections.Counter() for k in ('ALL','first','second')};cursor=0
 for i in range(4):
  a=rd(R/f'outputs/original118_raw_action_attribution_v2_20261028/case_{i:02d}_Attribution.json');f=R/a['summary']['result_path'];res=rd(f);gens=[]
  if i in (1,3):
   old=R/f'outputs/reflection118_remaining_cases_v2_execution_20261023/case_{i:02d}';members=rd(old/'remote_closed_descriptor.json')['members']
   names=sorted(k for k in members if k.startswith('response_') and k.endswith('.json'))
   for name in names:
    fp=old/'staged/study'/name;assert sha(fp)==members[name]['sha256'];v=rd(fp);gens.append((v['request']['messages'],v['raw_text']))
  gens.extend((x['messages'],x['text']) for x in rd(f.with_name('Call_Order.json'))['generations'])
  for (messages,text),ch in zip(gens,a['response_checks'],strict=True):
   row=rows[cursor];cursor+=1;assert row['case_id']==a['summary']['case_id']
   lines=messages[-1]['content'].splitlines();line=next(s for s in lines if s.startswith(('CANDIDATE_BUSES_YOU_MAY_USE:','You must choose exactly one bus from this list:')))
   candidate=json.loads(line.split(':',1)[1].strip());assert candidate==res['logs'][ch['log']]['llm_info']['candidate_buses']==row['candidate_buses']
   tail=messages[-1]['content'].rsplit('Example:',1)[1].strip();example=json.JSONDecoder().raw_decode(tail)[0];eb=int(example['bus'])
   try:literal=json.loads(text)
   except ValueError:literal=None
   eq=isinstance(literal,dict) and str(literal.get('bus'))==str(example['bus'])
   if ch['normalized_action']:
    nb=int(next(iter(ch['normalized_action']['add_shunts_q_mvar'])));valid=nb in candidate
   else:valid=False
   assert valid==row['candidate_valid']==ch['candidate_valid'];assert eb==row['example_bus'] and eq==row['raw_bus_equals_example']
   assert hashlib.sha256(text.encode()).hexdigest()==ch['raw_sha256']==row['raw_sha256']
   assert hashlib.sha256(json.dumps(messages,sort_keys=True,ensure_ascii=False).encode()).hexdigest()==row['messages_sha256']
   vals={'responses':1,'exact_candidate_list_binding':1,'example_outside_candidates':int(eb not in candidate),'raw_bus_equals_example':int(eq),'raw_exact_example':int(literal==example),'invalid_output_equal_example_bus':int(eq and not valid),'candidate_valid':int(valid),'example_outside_and_output_chooses_it':int(eb not in candidate and eq)}
   for group in ('ALL',ch['attempt']):totals[group].update(vals)
 assert cursor==len(rows)==459
 assert {k:dict(v) for k,v in totals.items()}==result['counts']
 record={'status':'PASS_ALL459_SAVED_PROMPTS_SOURCE_CANDIDATES_EXAMPLES_AND_RESPONSES','counts':{k:dict(v) for k,v in totals.items()},'all4_included':True,'new_model_PF_controller_optimizer_calls':0,'reader_sha256':sha(Path(__file__)),'source_result_sha256':sha(D/'Results.json'),'limits':result['limits']}
 (O/'Independent_Audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');(O/'Closed_Manifest.json').write_text(json.dumps({'members':{'Independent_Audit.json':sha(O/'Independent_Audit.json')}},indent=2)+'\n',encoding='utf-8');print(record['status'])
if __name__=='__main__':main()
