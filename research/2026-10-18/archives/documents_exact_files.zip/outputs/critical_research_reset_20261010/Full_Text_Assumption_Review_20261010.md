# Full-text assumption review and implications for HierGrid

This supplements the sealed master review. Primary full-text methods, evaluation sections and the specified assumptions were inspected; this is not an exhaustive proof audit or proof of novelty. DeepSPI's relevant assumptions were read in arXiv v2 and cross-checked against its actual conference PDF, pages 5-7 and 10. The PNAS-related source is an older author preprint. Those versions must not be silently equated with final publications.

## Preference uncertainty: useful evidence, unsupported transfer

[UNM-DPO v1](https://arxiv.org/html/2609.38647v1) uses strength annotations, five out-of-fold auxiliary policies and a fitted scale before final training. Its language-response results use model judges; the main hardware is A100-80GB, and matched final updates exclude pilot costs. It includes a constant-scale comparison, but intervals are conditional on selected checkpoints and do not correct all selection. The fitted scale is not certified latent annotation noise. Sections 3-5 and appendices B.3, E.6 and F.5 matter more here than headline wins.

Our interpretation: physical score gaps are not human strength annotations. Adding this machinery cannot repair missing observations or identify nonlinear convergence. Hold a grid adaptation until its uncertainty target and total pilot cost are justified.

## Semantic hypotheses: a meaningful alternative role

[LLM4PDR](https://arxiv.org/html/2609.30131v1), sections IV-V, lets GPT o3 propose word-level helpers that the formal engine validates. Its unchanged-engine ablation supports helper value on hardware verification; gains vary across suites. This is not an experiment with our small models, AC voltage recovery, or a matched non-language helper generator. The inspected timing tables do not establish a complete separate generation-cost ledger.

Our interpretation: a hypothesis generator is a credible different role, but a grid hypothesis needs an actual checker and useful consequences. Merely naming an unsafe bus, repeating scope/cap rules, or giving an explanation adds no demonstrated policy information. Keep a numerical/symbolic hypothesis generator and all checking costs in any future comparison.

## Safe-policy theorems: assumption coverage comes first

[DeepSPI](https://proceedings.iclr.cc/paper_files/paper/2026/file/0212b0dff7b4aa3bd8b8cc4ce24fd384-Paper-Conference.pdf), sections 4-7, preserves policy support, assumes full support for its finite-space convergence theorem, and needs model-error/Lipschitz conditions for return bounds. Policy representation is fixed during the relevant update theorem. Empirical work is on-policy ALE, not AC grids. A reported model-planning variant has weaker aggregate results. Return control does not establish our per-state voltage protection.

Our interpretation: missing transitions, unspecified support and uncertified constants prevent importing these guarantees. A strict support-preserving neighborhood around a deterministic singleton policy permits no different action. The continuity-to-Lipschitz remark in both inspected versions is insufficient mathematically; this does not invalidate results with separately enforced constants. Do not launch a world-model campaign on an abstract's guarantee.

## Statistics: shared examples and many experiments are not independent evidence

[Shared-evaluation statistics](https://arxiv.org/pdf/2608.22659), sections 2-6 and appendix B, emphasizes paired comparisons, clustering and multiplicity. It also reports different conclusions from different random-effect structures. Its balanced-model testing assumptions and MMLU example do not establish independence of our development worlds or repair repeated inspection.

Our interpretation: report matched world differences, preserve every declared world and avoid treating action labels as independent samples. A random world intercept shared by both models cancels from their difference; it alone does not model world-dependent model advantages. Historical development results remain descriptive. A future confirmation requires unused world groups and a prospectively fixed primary comparison; significance cannot mean 99% probability of novelty or success.

## Numerical-language robustness: preserve semantics rather than chase format

[Liu et al. author preprint v3](https://arxiv.org/html/2508.19563v3), sections 3-6, studies synthetic tabular fitting and sensitivity to representation changes. It is not the final PNAS article and does not prove Qwen/grid failure. Different training seeds and rounded numbers are not exact semantic invariance interventions.

Our interpretation: canonical serialization and cold reproduction are necessary, but neither certifies representation robustness. Do not add post-result prompt variants to seek a win. A separately fixed future robustness study should distinguish exact lossless permutations/relabelings from genuine changes of information or physical precision, and charge every call. The currently declared 62-call size diagnostic stays unchanged.

## Four cheap assumption checks, with deliberately narrow claims

The executable `work/check_literature_transfer_assumptions_20261010.py` records exact rational witnesses and general algebraic arguments in `literature_transfer_assumption_checks`. It reads no grid outcomes and makes no model, optimizer, PF, controller, linear-solve or cloud call. Finite witness counts verify arithmetic; the general conclusions come from the arguments, not extrapolation of those counts.

1. **Support:** a normalized nonnegative distribution on one action is uniquely the point mass. This rejects a direct strict support-preserving improvement theorem for a deterministic reference. A separately defined stochastic reference is a different method assumption; the original D-SE comparator must remain literal and fully costed.
2. **Regularity:** on `[0,1]`, `f(x)=sqrt(x)` is continuous. At `x=1/n^2`, its quotient relative to zero is `n`, exceeding any proposed finite constant for sufficiently large integer `n`. Compact continuity alone cannot establish the regularity a transferred bound requires.
3. **Scale identification:** for `t=(D r-c)/q`, if `c=D h`, substituting `r'=a r+(1-a)h`, `q'=a q` leaves `t` unchanged for any positive `a`. Additive utility-gap margins alone therefore cannot recover an unrestricted local scale. Extra restrictions can choose a scale without identifying physical uncertainty.
4. **Pairing:** `(alpha_A+u+e_A)-(alpha_B+u+e_B)=alpha_A-alpha_B+e_A-e_B`. A shared nuisance intercept cancels; dependence in the paired differences still needs analysis. This is not a rejection of all mixed-effects models.

These checks can decisively reject specified mathematical transfers. They cannot prove that a larger model or every future objective has no value.

## Resulting research decisions

- Do not add an uncertainty-normalized preference sweep or world-model RL study merely because a paper reports a guarantee or a language win. Their evidence does not meet our information, target and cost requirements.
- Keep the verified restricted-pool ceiling and all failed branches stopped. A different hypothesis must address their actual limits; parameter count alone cannot remove a mathematically restricted action pool or supply missing physical fields.
- Continue the human-requested public0.5B/public1.5B paired diagnostic with the frozen 31-world input selection and unchanged prompt. It tests a specific size association, not novelty, learning superiority, or the actual full D-SE portfolio.
- Before its first scientific generation, freeze the production source, one owner, incremental preservation, external reader, and all missing/invalid/rejected denominators. Quantization and generation settings must be common and declared; actual CUDA load/memory gates precede the calls.
- The reader must preserve raw text and token IDs, parse without repairing responses, verify current raw scope and cumulative cap, and keep abstentions distinct from missing or malformed outputs. Existing exact state/action reports may be reused with their original costs. No unsupported proposed outcome is treated as true. Public-size differences and stronger numerical-control results must both be shown.
- A favorable saved-state response does not trigger full training or physical deployment. Further work still needs a justified objective, same-information numerical and pretraining/architecture controls, continuous matched physical trajectories with protection checks, full costs of both original D-SE branches, and genuinely unused confirmation.

The review has changed which transfers deserve compute. It has not established a 99% winning probability, universal failure test, novel method or LLM superiority. No new GPU or physical performance experiment was launched by this review.
