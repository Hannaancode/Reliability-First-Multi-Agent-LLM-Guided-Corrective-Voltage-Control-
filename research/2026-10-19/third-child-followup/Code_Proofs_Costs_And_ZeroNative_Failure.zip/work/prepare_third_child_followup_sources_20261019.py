"""Bind the next closed-policy K4 cell before outcomes; no scientific calls."""
import ast,copy,hashlib,json,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from equal_operation_benchmark_v2 import process
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component

def main():
    screen=R/'outputs/resumed16_next_fifth_context_20261019';claim=read(screen/'owner.claim')
    assert process(claim['actual_pid']) is None and process(claim['parent_pid']) is None
    assert sha(R/'work/resume16_next_fifth_context_20261019.py')==claim['source_sha256']
    result=read(screen/'Results.json');leg=read(screen/'Leg_1.json')
    assert result['legs'][0]==leg and leg['status']=='UNKNOWN_UnknownLineageIdentity'
    assert [v['metrics']['uv_count'] for v in leg['projection_trace']]==[23,16]
    ref=leg['frontier_input'];encoded=(screen/ref['path']).read_bytes();raw=zlib.decompress(encoded)
    assert sha(screen/ref['path'])==ref['encoded_sha256'] and hashlib.sha256(raw).hexdigest()==ref['raw_sha256']
    for name in ['Results.json','Leg_1.json',ref['path'],'scientific.jsonl','Protocol.json','owner.claim']:
        assert sha(screen/name)==read(screen/'Closed_Manifest.json')['members'][name]
    state=pickle.loads(raw);_,runner,_=load_stack();metrics=runner.rescue.grid_metrics(state['net'])
    assert metrics['uv_count']==13 and state['cursor']['remaining_original_device_operation_slots']==13
    point=point_key(state['net'],state['cursor']);menus=[]
    for line in (screen/'scientific.jsonl').read_bytes().splitlines():
        e=json.loads(line)
        if e['event']=='menu_declared' and e['data']['parent']==state['parent']:menus.append(e['data'])
    assert len(menus)==1 and menus[0]['k']==4 and len(menus[0]['ids'])==4
    numeric=R/'outputs/fifth_required_numeric_context_20261019'
    assert read(numeric/'Completion.json')['exit_codes']=={'actual':0,'independent_audit':0}
    assert read(numeric/'independent_audit/Independent_Audit.json')['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
    table=read(numeric/'actual/All_Current_Native_Forecasts.json')
    _,actuate,native=build_verifier(runner.rescue,state['cursor']);rows=[]
    for rank,aid in enumerate(menus[0]['ids'],1):
        found=[v['row'] for k,v in table.items() if k.endswith('|'+aid)];assert len(found)==1
        row=found[0];net=actuate(copy.deepcopy(state['net']),action(row));h,values=component(net);assert independent_component(net)==h
        rows.append({'row':row,'point_action_key':point+'|'+action_key(row),'fixed_rank':rank,'role':'NEXT_REQUIRED_ORIGINAL_K4_RANK_'+str(rank),'component_sha256':h,'perbus_rational_component':values})
    assert rows[0]['row']==state['row'] and rows[0]['point_action_key']==state['key']
    i=R/'outputs/third_child_fixed_four_followup_input_20261019';i.mkdir(exist_ok=False);(i/'Exact_Current_Input.zlib').write_bytes(encoded)
    cell={'point':point,'parent':state['parent'],'current_metrics':metrics,'native_verifier_certificate':native,'current_input':{'path':str((i/'Exact_Current_Input.zlib').relative_to(R)),'raw_sha256':ref['raw_sha256'],'encoded_sha256':ref['encoded_sha256']},'all_unexecuted_original_menu_queries':rows,'all4_pre_physics_menu':rows,'original_declared_menu':menus[0],'source_closed_manifest_sha256':sha(screen/'Closed_Manifest.json'),'remaining_original_operations':13,'no_new_scientific_calls':0,'source_policy_directory':str(screen.relative_to(R)),'source_frontier':ref,'source_numeric_directory':str(numeric.relative_to(R))}
    put(i/'Exact_Current_Cell.json',cell);put(i/'Exact_Candidate_Inputs.json',{'point':point,'parent':state['parent'],'exact_new_query_rows':rows,'new_scientific_calls':0})
    pairs=[('next_fixed_four_followup_core_20261019.py','third_child_fixed_four_followup_core_20261019.py'),('run_next_fixed_four_followup_20261019.py','run_third_child_fixed_four_followup_20261019.py'),('audit_next_fixed_four_followup_20261019.py','audit_third_child_fixed_four_followup_20261019.py'),('certify_next_fixed_four_followup_20261019.py','certify_third_child_fixed_four_followup_20261019.py'),('prepare_next_fixed_four_followup_20261019.py','prepare_third_child_fixed_four_followup_20261019.py')]
    proofs=[]
    for before,after in pairs:
        source=R/'work'/before;text=source.read_text('utf-8');changed=text.replace('next_fixed_four_followup','third_child_fixed_four_followup')
        if before.startswith('next_'):
            needle="('ordinary_followup_remaining_three_acquisition_20261019',('warm','cold_1','cold_2'))]"
            replacement="('ordinary_followup_remaining_three_acquisition_20261019',('warm','cold_1','cold_2')),('next_fixed_four_followup_acquisition_20261019',('warm','cold_1','cold_2','cold_3'))]"
            assert changed.count(needle)==1;changed=changed.replace(needle,replacement)
            changed=changed.replace('exact_third_point_four_query_','exact_third_child_four_query_')
        elif before.startswith('audit_'):
            assert changed.count("['uv_count']==12")==1;changed=changed.replace("['uv_count']==12","['uv_count']==13")
        elif before.startswith('certify_'):
            assert changed.count("['uv_count']==12")==1;changed=changed.replace("['uv_count']==12","['uv_count']==13")
            needle="('ordinary_followup_remaining_three_acquisition_20261019',('warm','cold_1','cold_2'),'audit/Independent_Audit.json','PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY')]"
            replacement="('ordinary_followup_remaining_three_acquisition_20261019',('warm','cold_1','cold_2'),'audit/Independent_Audit.json','PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'),('next_fixed_four_followup_acquisition_20261019',('warm','cold_1','cold_2','cold_3'),'audit/Independent_Audit.json','PASS_COMPLETE_FIXED_FOUR_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY')]"
            assert changed.count(needle)==1;changed=changed.replace(needle,replacement).replace('len(recent)==34','len(recent)==42').replace('recent34_input','recent42_input').replace('and34recentBEFORE','and42recentBEFORE')
            anchor="    assert rows==cell['all4_pre_physics_menu']==cell['all_unexecuted_original_menu_queries']"
            extra="""
    source=R/cell['source_policy_directory'];numeric=R/cell['source_numeric_directory']
    assert sha(source/'Closed_Manifest.json')==cell['source_closed_manifest_sha256']
    assert read(source/'Leg_1.json')['frontier_input']==cell['source_frontier']
    menu=[]
    for line in (source/'scientific.jsonl').read_bytes().splitlines():
        event=json.loads(line)
        if event['event']=='menu_declared' and event['data']['parent']==cell['parent']:menu.append(event['data'])
    assert menu==[cell['original_declared_menu']]
    assert [action_key(x['row']) for x in rows]==menu[0]['ids']
    table=read(numeric/'actual/All_Current_Native_Forecasts.json')
    for item in rows:
        found=[v['row'] for k,v in table.items() if k.endswith('|'+action_key(item['row']))]
        assert found==[item['row']]
    for name in ['Results.json','Leg_1.json','scientific.jsonl','Closed_Manifest.json','Protocol.json']:
        files.append(source/name)
    for name in ['actual/All_Current_Native_Forecasts.json','actual/Closed_Manifest.json','independent_audit/Independent_Audit.json','Full_Native_Menu_ACK.json']:
        files.append(numeric/name)
"""
            assert changed.count(anchor)==1;changed=changed.replace(anchor,anchor+extra)
        elif before.startswith('prepare_'):
            changed=changed.replace('current12UV','current13UV').replace('at12UV','at13UV')
        target=R/'work'/after;assert not target.exists();ast.parse(changed);target.write_text(changed,encoding='utf-8')
        proofs.append({'base_source':str(source.relative_to(R)),'base_sha256':sha(source),'new_source':str(target.relative_to(R)),'new_sha256':sha(target)})
    put(i/'Source_And_Input_Binding.json',{'status':'PREPARED_ONLY_NEXT_CLOSED_POLICY_K4_CELL_NO_SCIENCE','query_point':point,'source_metrics':metrics,'rows':[v['row'] for v in rows],'source_transformations':proofs,'new_scientific_calls':0,'limits':'Fixed original menu selection, not physical permission from absent lineage. Full independent relevant-history/native-input/cold/cost/source/reader gates must pass before new science.'})
    print(json.dumps({'prepared_next_K4_rows':[v['row'] for v in rows],'source_uv':13,'new_science':0}))

if __name__=='__main__':main()
