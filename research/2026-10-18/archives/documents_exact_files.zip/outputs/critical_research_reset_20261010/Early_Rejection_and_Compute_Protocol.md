# Reject unsuitable ideas before expensive experiments

The human asks for accurate preliminary tests with 100% confidence that an unsuitable method will not improve the LLM. No finite preliminary test can prove that an arbitrary learning method will never improve on any future data, seed, budget or task. The useful replacement is a scoped mathematical rejection where possible, followed by inexpensive empirical gates with their uncertainty retained. Passing a gate only permits the next stage; it is not a promised win.

## The four decisions

| Decision | Meaning | Action |
|---|---|---|
| PROVED_OUT_OF_SCOPE | A necessary condition for this exact design, dataset, information contract, budget and target is mathematically false. | Stop that design. State the proof's scope. |
| FAILED_MEASURED_GATE | A completed, prospectively fixed measurement failed its criterion. | Stop the tested intervention/dataset; preserve its result. Do not infer universal impossibility. |
| UNKNOWN | Required outcomes, identities, costs, support or artifacts are missing. | Hold dependent work. Missing evidence is neither a negative result nor permission to run anyway. |
| ELIGIBLE_FOR_NEXT_GATE | Every requirement for the next bounded stage is satisfied. | Proceed only under that stage's separately fixed protocol; no superiority claim. |

## Screen 1: Is the claimed improvement even reachable?

Before training, define the exact output universe, real inference/query budget, primary metric and minimum meaningful gain. Use only already measured labels for a read-only optimistic oracle: give the proposed policy perfect selection among its permitted candidates. Preserve all declared worlds, zero-oracle cases, unlabelled actions and unavailable outputs. Use best-case bounds for missing evidence; never make unknown outcomes negative.

If this ideal selector's upper gain is below the target, every realizable selector restricted to the same candidates fails that target on those measured worlds. This is a deterministic ceiling, conditional on the verified records and definitions. It cannot certify unseen-world performance or rule out a different action universe.

**Actual example:** the fixed union of the two numerical top-four lists, with four output actions, has coverage upper .7224159678705133. The old numerical comparator has coverage lower .6893379347924802. Therefore the gain is at most **3.31 percentage points**, below the required five points. The 2.30-point conservative lower gain was not its maximum. This candidate is stopped without GPU training or new PF. The arithmetic uses sealed data; no forecast is repeated. The additive certificate records the exact source hashes and the distinction between bounds.

Contrast support is checked separately. Five recoverable misses in four worlds of one family did not meet the previously declared two-family criterion. Absence of suitable support prevents justifying this pilot; it is not a universal theorem about language learning.

## Screen 2: Can the method use its inputs legitimately?

Freeze the actor-visible information, action scope, units, missing fields and input representation before tokenizer measurements. Check every declared context, outcome/identity exclusion and exact retained-field roundtrip. A fixed interface exceeding its context limit cannot execute as specified. This is an interface failure, not proof that every other justified interface fails. Future, measured AFTER and scenario labels may supervise training but cannot leak into current-state inference. Missing successor vectors or hidden solver modes remain missing.

The raw current tables and the separately fixed partial view already failed their context checks. Do not repeat them or change formatting until a materially different information contract is justified.

## Screen 3: Does the proposed mathematics implement the claim?

Derive the actual deployed score, normalization, reference margin, decoder and tie/unknown handling. Prove initialization identities and inspect whether a preference loss cancels the numerical prior it is supposedly correcting. Check whether the claimed novel element is already present in ARM, DPO, LiPO, residual policies or baseline-preserving improvement methods. An algebraic identity can be proved; a novelty probability or future policy benefit cannot be inferred from it.

Require actual production input/source closure and a bounded software check before genuine pretrained calls. Mock/random checks are software evidence only. A parameter that is frozen cannot be adapted by that optimizer, but a finite gradient test cannot prove every future gradient will be zero.

## Screen 4: Could a strong numerical method already solve it?

Use the completed physical and numerical controls without rerunning them. Any genuinely new preference/control pilot needs a materially specified objective, the same actor information and numerical prior, plus a stronger full-table/physical comparator. Fix one seed, one budget and the final checkpoint in advance. Retain every world and all failures. A numerical win removes a proposed language-only explanation; a numerical miss merely leaves a hypothesis to test. It is not proof the LLM will fill the gap.

A planning ceiling of 20 minutes for a new CPU pilot is conditional, not a current launch or a prediction of completion. No such new pilot is ready until its method and input gates are complete.

## Screen 5: Does the real model execute the proposed mechanism?

Only after Screens 1–4, use a bounded genuine engineering test with the real longest context, reference restoration, trainability masks, gradient paths, memory and independent cold optimizer/RNG/cursor checkpoint restoration. Preserve small hashed transfers before more science. These checks can establish that a mechanism runs; they do not measure policy advantage. Old integration tests with a different interface cannot replace this gate.

## Screen 6: Is there enough decision evidence to justify a full campaign?

Freeze a small development learning study and evaluate the actual primary action metric against the strongest numerical and matched reference controls. Do not select an intermediate favorable checkpoint, K, family, prompt or budget. An empirical null result has uncertainty. Predeclare a meaningful-effect floor and, where suitable, a confidence upper bound below that floor as a futility criterion; do not call it proof of zero effect. Cluster at world level and avoid treating thousands of correlated actions as independent trials. A partial is UNKNOWN. A failed measured criterion stops the intervention/dataset.

Full matched physical trajectories and genuinely unused confirmation are downstream requirements. Actual D-SE remains DFF plus DFF-ALT with its unchanged selector and full costs of both branches. Better loss, candidate coverage, a common guard or cheaper search alone is not LLM superiority.

## Current execution decision

The restricted two-prior selector is PROVED_OUT_OF_SCOPE for the fixed five-point development target, and it also failed the contrast-support gate. The full-universe language hypothesis has unresolved information, mathematical and novelty gates. No GPU or new physical campaign is ready. The review-first instruction is in force and the overall research goal remains active/unachieved. Permission is already present; the remaining barrier is scientific justification.
