"""Assemble already audited original118 outcomes under the 23Oct frozen metrics.

No model, power-flow, training or old-reader execution. Refuses live or partial inputs.
"""
from pathlib import Path
import ast,csv,datetime,hashlib,json,os
import psutil
R=Path(__file__).resolve().parents[1]
O=R/'outputs/original118_closed_comparison_20261028'
def read(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def ended(path,source):
    c=read(path)
    for pid in [c.get('actual_pid'),c.get('parent_pid'),c.get('actual_parent_pid')]:
        if pid and psutil.pid_exists(pid):
            args=psutil.Process(pid).cmdline()
            assert not any(Path(x).name==Path(source).name for x in args),('owned actor still live',pid,args)
def closed_audit(folder,filename='Independent_Audit.json'):
    d=read(folder+'/'+filename);m=read(folder+'/Closed_Manifest.json')
    assert m['members'][filename]==sha(folder+'/'+filename)
    return d
def main():
    # Admission checks happen before the output namespace is claimed.
    protocol=read('outputs/original118_matched_analysis_preparation_20261023/Protocol.json')
    lock=read('outputs/original118_analysis_binding_20261028/Prepared_Analysis_Lock.json')
    assert lock['assembler_sha256']==sha('work/assemble_original118_closed_comparison_20261028.py')
    assert lock['original_metric_protocol_sha256']==sha('outputs/original118_matched_analysis_preparation_20261023/Protocol.json')
    for path,digest in lock['already_closed_evidence_hashes'].items():assert sha(path)==digest
    handoff='outputs/original_missing_suffix_handoff_20261028'
    assert (R/handoff/'Completion.json').exists()
    ended(handoff+'/owner.claim','work/coordinate_original_missing_suffix_20261028.py')
    current=[]
    for i in (1,3):
        host=f'outputs/original_missing_suffix_execution_20261028/case_{i:02d}'
        for folder,source in [(host,'work/run_original_missing_suffix_colab_20261028.py'),
          (host+'/local_controller','work/run_original_missing_suffix_local_20261028.py'),
          (f'outputs/original_missing_suffix_independent_20261028/case_{i:02d}','work/audit_original_missing_suffix_20261028.py')]:
            ended(folder+'/owner.claim',source)
        for stem in ['coordination','reader_coordination']:
            e=read(f'outputs/original_missing_suffix_{stem}_20261028/case_{i:02d}/End_ACK.json')
            assert e['exit_code']==0 and e['actual_owned_chain_ended']
        status=read(host+'/status.json')
        assert status['runtime_released'] and status['all_actual_closed_artifacts_preserved'] and status['scientific_process_ended']
        a=closed_audit(f'outputs/original_missing_suffix_independent_20261028/case_{i:02d}')
        assert a['complete'] and a['status']=='PASS_ONE_COMPLETE_ORIGINAL_REFLECTION_CASE'
        current.append(a)
    dff=closed_audit('outputs/r118_dff_partition_continuation_independent_20261023')
    assert dff['all4_complete'] and dff['status']=='PASS_ALL4_COMPLETE_NATIVE_DFF_SOURCE_PHYSICS_COST'
    old0=closed_audit('outputs/r118chrono_audit_20261022')
    assert old0['all_causal_original_policy_outputs_exact']
    old2=closed_audit('outputs/reflection118_remaining_cases_v2_independent_20261023/case_02')
    assert old2['complete'] and old2['status']=='PASS_ONE_COMPLETE_ORIGINAL_REFLECTION_CASE'
    llm_rows=old0['complete_branches']+[old2['summary']]+[a['summary'] for a in current]
    llm={r['scenario_id']:r for r in llm_rows};num={r['scenario_id']:r for r in dff['summaries']}
    assert set(llm)==set(num)==set(protocol['case_order']) and len(llm_rows)==4
    selector_path='work/e/audit/run_reflection_v4_safety_envelope.py'
    assert sha(selector_path)==protocol['source_hashes'][selector_path]
    tree=ast.parse((R/selector_path).read_text('utf-8-sig'))
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='choose_safety_envelope')
    ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),selector_path,'exec'),ns)
    choose=ns['choose_safety_envelope']
    rows=[]
    for cid in protocol['case_order']:
        n,l=num[cid],llm[cid];assert n['base_uv']==l['base_uv']
        assert all(x[k] is not None for x in (n,l) for k in ['final_uv','accepted_actions','final_deficit'])
        selected=choose(n,l);s=l if selected=='reflection_v2' else n
        sov=l['strict_OV'] if s is l else n['strict_final_OV']
        rows.append({'case_id':cid,'initial_UV':n['base_uv'],'DFF_UV':n['final_uv'],'DFF_OV':n['strict_final_OV'],
          'HGVF_UV':l['final_uv'],'HGVF_OV':l['strict_OV'],'UV_difference_HGVF_minus_DFF':l['final_uv']-n['final_uv'],
          'DFF_actions':n['accepted_actions'],'HGVF_actions':l['accepted_actions'],
          'HGVF_direct':l['llm_direct'],'HGVF_guided':l['llm_guided'],'HGVF_fallback':l['fallback'],
          'DFF_deficit':n['final_deficit'],'HGVF_deficit':l['final_deficit'],
          'DFF_Vmin':n['final_vmin'],'HGVF_Vmin':l['final_vmin'],
          'HGSE_selected':selected,'HGSE_UV':s['final_uv'],'HGSE_OV':sov,'HGSE_selected_actions':s['accepted_actions'],
          'HGVF_whole_band':l['final_uv']==0 and l['strict_OV']==0,
          'DFF_whole_band':n['final_uv']==0 and n['strict_final_OV']==0})
    wins=sum(x['HGVF_UV']<x['DFF_UV'] for x in rows);losses=sum(x['HGVF_UV']>x['DFF_UV'] for x in rows)
    extraOV=[x['case_id'] for x in rows if x['HGVF_OV']>x['DFF_OV']]
    gate='PASS' if wins>=2 and losses==0 and not extraOV else 'FAIL'
    O.mkdir(exist_ok=False)
    (O/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha('work/assemble_original118_closed_comparison_20261028.py')}),'utf-8')
    costs={'DFF_closed_study':dff,'old_original_case0_partial_study':old0,'old_original_case2':old2,
      'new_missing_suffix_cases':current,
      'old_interrupted_case1':read('outputs/reflection118_remaining_cases_v2_independent_20261023/case_01/Independent_Audit.json'),
      'old_interrupted_case3':read('outputs/reflection118_remaining_cases_v2_independent_20261023/case_03/Independent_Audit.json'),
      'scope':'Preserved per-source cost blocks, not summed as latency. Old shared root/menu/physics, training, setup, failed engineering and preparation remain separately paid. No equal-cost claim. Reconstructed prior-prefix calls are references to old calls, not extra new measurements.'}
    result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ALL4_AUDITED_DESCRIPTIVE_ORIGINAL_NATIVE_COMPARISON',
       'protocol':protocol,'rows':rows,'HGVF_UV_wins':wins,'ties':4-wins-losses,'losses':losses,'additional_OV_cases':extraOV,
       'fixed_development_gate':gate,'totals':{k:sum(x[k] for x in rows) for k in ['initial_UV','DFF_UV','DFF_OV','HGVF_UV','HGVF_OV','HGSE_UV','HGSE_OV','DFF_actions','HGVF_actions','HGSE_selected_actions']},
       'no_iid_confidence_or_unused_confirmation':True,'HGSE_offline_selector_full_both_costs_required':True,
       'literal_numerical_DSE_external_and_causal_LLM_superiority':'UNPROVEN',
       'root_binding':'Same four predeclared registered roots; source/physical/cursor identity proved by the reused individual audits. No new physics or independent stage rerun.',
       'historical_case0_reader_OS_exit':'UNKNOWN in original supervisor failure; closed independent outputs and prior terminal certificate reused; no fabricated exit0.',
       'secondary_cost_and_full_bus_detail':'Retained in individual audits/capsules. This assembly does not repeat numerical replay or infer missing historical costs.',
       'new_model_PF_optimizer_derivative_calls':0}
    for name,obj in [('Comparison.json',result),('Full_Cost_Source_Blocks.json',costs)]:
        (O/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n','utf-8')
    with (O/'Comparison.csv').open('x',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    lines=['# Original Reflection v4 and DFF on four registered severe roots','',
      'All endpoints below are independently audited under the original native 1.06 guard; OV is reported strictly above 1.05. These are inspected development roots, not unused confirmation.','',
      '| Root | Initial UV | DFF UV / OV | HG-VF UV / OV | Offline HG-SE UV / OV |','| --- | ---: | ---: | ---: | ---: |']
    lines += [f"| {x['case_id']} | {x['initial_UV']} | {x['DFF_UV']} / {x['DFF_OV']} | {x['HGVF_UV']} / {x['HGVF_OV']} | {x['HGSE_UV']} / {x['HGSE_OV']} |" for x in rows]
    lines += ['',f'Frozen development gate: **{gate}**. HG-VF UV wins/ties/losses: {wins}/{4-wins-losses}/{losses}. Additional strict OV occurs in {len(extraOV)} case(s).',
      '', 'HG-SE chooses between both completed branches and pays both search costs. It is not a fresh online LLM choice or the numerical DFF-plus-DFF-ALT envelope. Source-specific full cost blocks and all historical failures remain retained. This comparison does not establish an equal-cost, external-method or causal LLM advantage.']
    (O/'Results.md').write_text('\n'.join(lines)+'\n','utf-8')
    (O/'Closed_Manifest.json').write_text(json.dumps({'members':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()}},indent=2)+'\n','utf-8')
    print(json.dumps({'status':result['status'],'gate':gate,'wins':wins,'losses':losses}))
if __name__=='__main__':main()
