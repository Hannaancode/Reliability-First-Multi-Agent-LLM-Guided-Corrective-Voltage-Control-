from pathlib import Path
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
import json,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_RAG_lineage_20261029'
def main():
    assert not (O/'Layout_Repair.json').exists()
    p=O/'Hannaan_Thesis_RAG_And_Lineage_Update.docx'
    shutil.copy2(p,O/'Pre_Review_Layout.docx');shutil.copy2(O/'Integrated_Thesis_QA.pdf',O/'Pre_Review_Layout.pdf')
    d=Document(p)
    anchor=next(x for x in d.paragraphs if x.text.startswith('[35]'))
    for num in [36,37]:
        ref=next(x for x in d.paragraphs if x.text.startswith(f'[{num}]'))
        ref._p.getparent().remove(ref._p);anchor._p.addnext(ref._p);anchor=ref
        ref.alignment=WD_ALIGN_PARAGRAPH.LEFT
        ref.paragraph_format.space_after=Pt(8);ref.paragraph_format.keep_together=True
    old=next(x for x in d.paragraphs if x.text.startswith('The broker is tested application software'))
    previous=old.text
    revised='The broker is tested application software and is not integrated into the answering pipeline. Semantic answer truth and out-of-scope refusal remain untested. The historical RAG figures are reported whole-system results, not evidence of a causal retrieval benefit. Such a test needs matched model, questions, prompts, decoding and scoring, with index and retrieval costs included.'
    old.text=revised
    d.save(p)
    record=json.loads((O/'Integration_Record.json').read_text('utf-8'))
    for x in record['added']:
        if x['text']==previous:x['text']=revised
        if x['text'].startswith(('[36]','[37]')):x['anchor']='After original reference35'
    (O/'Integration_Record.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n','utf-8')
    repair={'status':'REPAIRED_AWAITING_SECOND_RENDER','changes':['Moved new references36/37 after35 in existing bibliography, not beforeAppendixA.','Shortened new scope paragraph without changing limitations to remove two-line orphan page.'],'previous_scope_paragraph':previous,'revised_scope_paragraph':revised,'source_or_science_changes':0}
    (O/'Layout_Repair.json').write_text(json.dumps(repair,indent=2)+'\n','utf-8')
    s=(R/'work/render_RAG_lineage_thesis_20261029.py').read_text('utf-8').replace("out=O/'render'","out=O/'render_final'").replace("f'contact-{start+1:03}.jpg'","f'final-contact-{start+1:03}.jpg'").replace("O/'Rendered_Pages.json'","O/'Final_Rendered_Pages.json'")
    (R/'work/render_RAG_lineage_thesis_final_20261029.py').write_text(s,'utf-8')
    print('Layout corrected; prior preview retained')
if __name__=='__main__':main()
