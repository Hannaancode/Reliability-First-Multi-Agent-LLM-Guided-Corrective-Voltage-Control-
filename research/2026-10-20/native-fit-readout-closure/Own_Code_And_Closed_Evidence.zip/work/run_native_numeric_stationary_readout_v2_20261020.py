from pathlib import Path
from fit_native_stationary_readout_v2_20261020 import main
if __name__=='__main__':main('numeric',Path(__file__))
