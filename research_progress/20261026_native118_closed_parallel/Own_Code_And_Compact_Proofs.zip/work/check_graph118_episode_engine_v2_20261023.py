"""Labelled mock transition/stop/cold tests of the new full-episode adapter.

Saved roots/cursors are dependencies only. Synthetic after-fields are NEVER
recorded as physical evidence or benchmark performance.
"""
import ast,types,traceback
from reflection118_remaining_cases_v2_core_20261023 import *
O=R/'outputs/published_graph118_episode_software_v2_20261023'

def main():
    O.mkdir(exist_ok=False);began=time.monotonic()
    put(O/'Protocol.json',dict(status='FROZEN_NEW_LABELLED_SOFTWARE_CHECKS',cases='All four saved source cursors',checks=['pending intention cannot be requested twice','exact pending warm/cold state','source native step counter and static graph','normal band, one-ULP upper, no-op, cap, failure stops'],new_model_PF_conversion_allowed=0,not_physical_outcomes=True,source_sha256=sha(__file__)))
    try:
        np,pp,_,_,_=setup()
        def forbidden(*a,**k):raise OperationalStop('MOCK_EPISODE_FORBIDS_NEW_PHYSICS')
        pp.runpp=forbidden
        from published_graph118_episode_engine_20261023 import NativeGraphEpisode
        from exact_graph_cursor_compare_20261023 import require_same
        s=R/'outputs/published_graph118_environment_source_20261022/compatible_archived/voltage_control_env.py';raw=s.read_bytes()
        semantics=read(s.parent/'Compatible_Source_Semantics.json');assert sha(s)==semantics['source_sha256']
        node=next(x for x in ast.walk(ast.parse(raw)) if isinstance(x,ast.FunctionDef) and x.name=='_check_done')
        assert hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==semantics['source_method_AST_hashes']['_check_done']
        namespace={};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(s),'exec'),namespace)
        old=R/'outputs/published_graph118_paid_transition_20261022';rows=read(old/'Saved_Transition_And_Cursor_Readiness.json')['rows'];checked=[]
        for i,row in enumerate(rows):
            saved=decode(old,row['cursor']);folder=O/f'case_{i:02d}';folder.mkdir()
            a=NativeGraphEpisode(folder,saved);intent=a.next_intent()
            assert intent['action']==row['hypothetical_next_action_id'] and intent['decoded']==row['hypothetical_next_action']
            try:a.next_intent()
            except AssertionError:pass
            else:raise AssertionError('Duplicate unclosed intention accepted')
            cold=NativeGraphEpisode.restore(folder,pickle.loads(pickle.dumps(a.snapshot(),protocol=5)))
            require_same(a.snapshot(),cold.snapshot(),'NEW_PENDING_COLD_STATE')
            assert a.env.saw.calls==cold.env.saw.calls==0
            # Keep the prior solved field vector as a MOCK after-state only.
            mock=copy.deepcopy(intent['before']);mock.converged=True
            ra=a.accept(intent,mock);rb=cold.accept(copy.deepcopy(intent),copy.deepcopy(mock));assert ra==rb
            require_same(a.snapshot(),cold.snapshot(),'NEW_POST_MOCK_TRANSITION_COLD_STATE')
            assert a.count==2 and a.history[-1]==intent['action']
            assert ra['done']==namespace['_check_done'](types.SimpleNamespace(action_count=2,action_cap=a.cap,all_v_in_range=a.env.all_v_in_range))
            checks=[]
            for label,voltages,cap,fail in [
                ('normal_endpoints',np.array([.95,1.05]+[1.]*116),136,False),
                ('strict_upper_one_ulp',np.array([np.nextafter(1.05,np.inf)]+[1.]*117),136,False),
                ('native_cap',np.full(118,.94),2,False),
                ('native_failure',np.full(118,.94),136,True),
                ('author_no_op_with_unresolved_band',np.full(118,np.nextafter(1.05,np.inf)),136,False)]:
                x=NativeGraphEpisode(folder,saved)
                if label=='author_no_op_with_unresolved_band':
                    x.env.net.res_bus.vm_pu=voltages
                    # Float32 rounds this to1.05; original actor chooses no-op,
                    # while raw strict band retains the violation.
                qi=x.next_intent();answer=copy.deepcopy(qi['before']);answer.res_bus.vm_pu=voltages;answer.converged=not fail;x.cap=cap
                ans=x.accept(qi,answer,dict(type='LABELLED_MOCK_FAILURE') if fail else None)
                source_done=bool(fail or namespace['_check_done'](types.SimpleNamespace(action_count=2,action_cap=cap,all_v_in_range=bool(np.all((voltages>=.95)&(voltages<=1.05))))))
                expected=source_done or qi['action']==0
                assert ans['done']==expected
                if label=='strict_upper_one_ulp':assert not ans['source_success']
                if label=='author_no_op_with_unresolved_band':assert qi['action']==0 and ans['done'] and not ans['source_success']
                checks.append(dict(label=label,passed=True,synthetic_not_physics=True))
            checked.append(dict(case_id=row['case_id'],new_pending_and_post_mock_cold_state_exact=True,duplicate_intention_rejected=True,tests=checks,source_native_action_cap=a.cap))
        put(O/'Results.json',dict(status='PASS_NEW_FULL_EPISODE_PENDING_COLD_AND_SOURCE_STOP_SOFTWARE',rows=checked,environment_source_sha256=sha(s),episode_engine_sha256=sha(R/'work/published_graph118_episode_engine_20261023.py'),new_PF_model_conversion_calls=0,no_new_physical_performance=True,remaining='Actual relevant-history/source/query ownership/preservation/first-replay lock before complete native episodes; native controls/horizon differ from HierGrid.',workflow_seconds=time.monotonic()-began))
        print(json.dumps(dict(status='PASS_GRAPH_EPISODE_SOFTWARE',cases=4,labelled_stop_checks=20,new_physics=0)))
    except BaseException as exc:
        put(O/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),new_scientific_calls=0));raise
    finally:put(O/'Closed_Manifest.json',dict(members={p.relative_to(O).as_posix():sha(p) for p in O.rglob('*') if p.is_file()}))
if __name__=='__main__':main()
