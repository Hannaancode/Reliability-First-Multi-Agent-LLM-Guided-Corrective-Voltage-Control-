"""Single read-only post-reference audit; no model/solver calls or scientific reruns."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes,hashlib,json,os,time
from ctypes import wintypes
from frozen_physics_loader import load_stack
from value_baseline_gate import require_sealed_baseline
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT);OUT=ROOT/'outputs/actual_DSE_development_reference'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (OUT/'audit_owner.claim').open('x') as f:f.write(str(os.getpid()))
state={'owner_pid':os.getpid(),'stage':'waiting_for_original_reference_owner_to_finish','new_model_calls':0,'new_PF_calls':0}
def save():
 state['updated_at_utc']=datetime.now(timezone.utc).isoformat();temporary=OUT/'audit_status.tmp';temporary.write_text(json.dumps(state,indent=2));temporary.replace(OUT/'audit_status.json')
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
def alive(pid):
 handle=kernel.OpenProcess(0x1000,False,pid)
 if not handle:
  if ctypes.get_last_error()==87:return False
  raise RuntimeError('Cannot establish source owner ended')
 try:
  code=wintypes.DWORD();assert kernel.GetExitCodeProcess(handle,ctypes.byref(code));return code.value==259
 finally:kernel.CloseHandle(handle)
save()
try:
 deadline=time.monotonic()+14400
 while time.monotonic()<deadline:
  status=read(OUT/'status.json')
  if not alive(int((OUT/'owner.claim').read_text())):
   assert status['stage']=='8_exact_actual_DSE_development_references_complete_pending_independent_audit','Original reference owner did not complete'
   break
  time.sleep(30)
 else:raise RuntimeError('Bounded reference wait elapsed; preserve partials')
 state['stage']='auditing_exact_branches_portfolio_selector_physics_and_costs';save()
 protocol=read(OUT/'protocol.json');manifest=read(OUT/'manifest.json');summary=read(OUT/'summary.json')
 for name,item in manifest.items():
  p=OUT/name;assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
 assert len(manifest)==27 and summary['actual_branches']==16 and summary['actual_portfolios']==8
 _,_,reflection=load_stack();totals={k:0 for k in ['attempts','returns','exceptions']};replay={k:0 for k in totals};quality=[]
 expected={c['scenario_id'] for c in protocol['scenarios']};assert {p.stem for p in (OUT/'portfolios').glob('*.json')}==expected
 for case in protocol['scenarios']:
  assert sha(ROOT/case['path'])==case['sha256'];portfolio=read(OUT/'portfolios'/(case['scenario_id']+'.json'))
  records={b:read(OUT/'branches'/(case['scenario_id']+'__'+b+'.json')) for b in ['DFF','DFF-ALT']}
  for b,row in records.items():
   assert row['scenario_sha256']==case['sha256'] and row['protocol_sha256']==sha(OUT/'protocol.json') and row['base_network_preserved']
   assert row['actual_controller_costs']['llm_calls']==0
   for k in totals:
    totals[k]+=row['actual_controller_costs'][k];replay[k]+=row['independent_committed_state_physical_replay']['costs'][k]
  if portfolio['valid']:
   assert all(r['independent_committed_state_physical_replay']['passed'] for r in records.values())
   summaries={b:reflection.summarize_result(r['result']) for b,r in records.items()}
   chosen='DFF-ALT' if reflection.choose_safety_envelope(summaries['DFF'],summaries['DFF-ALT'])=='reflection_v2' else 'DFF'
   assert portfolio['selected_branch']==chosen and portfolio['summaries']==summaries
   assert portfolio['selected_final_metrics']==records[chosen]['result']['final_metrics']
  for k in totals:
   assert portfolio['full_two_branch_charged_costs'][k]==sum(r['actual_controller_costs'][k] for r in records.values())
  fm=portfolio['selected_final_metrics'];quality.append({'scenario_id':case['scenario_id'],'valid':portfolio['valid'],
     'selected_branch':portfolio['selected_branch'],'final_metrics':fm,
     'strict_UV_zero_and_normal_upper_at_diagnostic1e8':bool(fm and fm['uv_count']==0 and fm['vmax']<=1.05+1e-8),
     'portfolio_full_charged_costs':portfolio['full_two_branch_charged_costs']})
 assert totals==summary['actual_controller_PF_counts'] and replay==summary['independent_replay_PF_counts']
 for name,digest in protocol['frozen_source_sha256'].items():assert sha(ROOT/name.replace('\\','/'))==digest
 baseline=require_sealed_baseline(ROOT)
 audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_identity_selector_manifest_and_cost_gates_passed':True,
        'actual_primary_comparator':'D-SE, original DFF plus DFF-ALT and selector','exact_branches':16,'exact_portfolios':8,
        'manifest_members_verified':27,'actual_controller_PF_counts':totals,'actual_independent_replay_PF_counts':replay,
        'all_branch_physical_replays_passed':all(r['valid'] for r in quality),'quality':quality,
        'new_model_or_PF_calls_by_auditor':0,'original_baseline_seal':baseline,'LLM_superiority_established':False,
        'scope':protocol['scope']}
 with (OUT/'Independent_Completion_Audit.json').open('x') as f:json.dump(audit,f,indent=2)
 state.update(stage='actual_DSE_development_references_independently_audited',physical_replay_all_passed=audit['all_branch_physical_replays_passed']);save()
except Exception as exc:
 state.update(stage='actual_DSE_reference_audit_failed_preserve_data',failure_type=type(exc).__name__);save();raise
