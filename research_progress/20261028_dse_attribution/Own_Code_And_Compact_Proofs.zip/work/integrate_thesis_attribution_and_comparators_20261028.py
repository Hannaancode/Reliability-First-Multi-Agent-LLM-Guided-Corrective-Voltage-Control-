"""Add independently closed attribution and comparator evidence to a new thesis copy.

No scientific calls. The reviewed 109-page draft and all scientific records stay intact.
"""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import hashlib, json, sys, zipfile
from docx import Document
from docx.shared import Pt, Mm, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_attribution_and_comparators_20261028'
BASE=R/'outputs/thesis_integrated_evidence_20261028/Hannaan_Thesis_Integrated_Evidence.docx'
def read(p): return json.loads((R/p).read_text('utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v): p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def main():
    assert not O.exists(); O.mkdir()
    oldsha=sha(BASE); d=Document(BASE)
    a=read('outputs/original118_raw_action_attribution_v2_20261028/independent/Independent_Audit.json')
    assert a['status']=='PASS_ALL4_INDEPENDENT_RAW_NORMALIZATION_AND_ATTRIBUTION'
    assert a['totals']['all_controller_responses']==459
    assert a['selected_direct_totals']=={'llm_direct_commits':51,'direct_commit_with_Q_changed':9,'direct_commit_requested_compact_schema_valid':42}
    attribution=read('outputs/original118_raw_action_attribution_v2_20261028/Results.json')
    def anchor(s):
        p=[p for p in d.paragraphs if p.text==s]; assert len(p)==1,(s,len(p)); return p[0]._p
    def para(before,text,style='Normal'):
        p=d.add_paragraph(text,style)
        if style=='Normal':
            p.paragraph_format.space_after=Pt(6)
        for rr in p.runs:
            rr.font.name='Times New Roman';rr.font.color.rgb=RGBColor(0,0,0)
            if style=='Normal': rr.font.size=Pt(12)
        before.addprevious(p._p);return p
    def table(before,caption,headers,rows,widths):
        cp=para(before,caption,'Caption');cp.paragraph_format.keep_with_next=True
        t=d.add_table(rows=1,cols=len(headers));t.autofit=False
        for c,w in zip(t.columns,widths):c.width=Mm(w)
        for j,x in enumerate(headers):t.rows[0].cells[j].text=str(x)
        for vals in rows:
            row=t.add_row()
            for j,x in enumerate(vals):row.cells[j].text=str(x)
        borders=OxmlElement('w:tblBorders')
        for edge in ('top','left','bottom','right','insideH','insideV'):
            el=OxmlElement('w:'+edge);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
        t._tbl.tblPr.append(borders)
        for i,row in enumerate(t.rows):
            pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
            if i==0:pr.append(OxmlElement('w:tblHeader'))
            for j,c in enumerate(row.cells):
                c.width=Mm(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tcpr=c._tc.get_or_add_tcPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E7EBEF' if i==0 else ('F7F8FA' if i%2==0 else 'FFFFFF'));tcpr.append(sh)
                mar=OxmlElement('w:tcMar')
                for side in ('top','left','bottom','right'):
                    e=OxmlElement('w:'+side);e.set(qn('w:w'),'75');e.set(qn('w:type'),'dxa');mar.append(e)
                tcpr.append(mar)
                for p in c.paragraphs:
                    p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_after=Pt(3)
                    if j>0 and len(headers)==3:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                    for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(10.5);rr.font.color.rgb=RGBColor(0,0,0);rr.bold=i==0
        before.addprevious(t._tbl);return t
    chapter3=anchor('Chapter 3 Research contributions and their evidence')
    para(chapter3,'2.20 Closest recent grid agent studies','Heading 2')
    literature=[
      'The nearest studies use language models in different operating roles. Table 2.2 separates the information and authority given to each system so that a shared grid name does not imply a matched experiment. The five versioned records are preprints; repository availability and reported results are assessed separately from execution in this thesis.',
      'Chehade and Zhu adapt a model for corrective switching, including preference learning from AC evaluations [31]. Yang et al. study day-ahead scheduling through experience retrieval [32], and their separate two-stage work combines language decisions with reinforcement learning [33]. These are relevant prior art for adaptation, feedback and hybrid control. They do not by themselves provide equal-resource scores for positive shunt correction on our severe federation cases.',
      'VeraGrid-Agent provides a candidate public QA evaluation [34], while FLARE addresses restoration under degraded observations [35]. Neither score can be substituted for our strict voltage endpoint. The latter repository omits the exact grid substrate and generated test panels, so a reproducible benchmark is not established by code availability alone.',
      'Our demonstrated work combines a grid QA resource, structured local proposals, numerical verification and retained experiment evidence. Retrieval, reflection, fine-tuning, multi-agent organisation and safety checks are established ingredients. The specific empirical claims are therefore restricted to the measured cohorts and contracts. A new causal advantage from the language model remains an open research question.'
    ]
    for s in literature:para(chapter3,s)
    table(chapter3,'Table 2.2 Closest recent language model grid studies and comparison boundaries',
      ['Work','Information and decision role','Numerical evidence','Security and admission'],[
      ['Chehade and Zhu [31]','Adapted LLM; open-only switching on IEEE 118 PSPS cases','AC evaluation, DPO and best-of-N','PSPS is not a cyber test; different actuator'],
      ['Yang et al. [32]','Forecasts and retrieved experience; day-ahead Volt/Var schedules','Simulation results reported by authors','Supplementary PDF found; executable controller unverified'],
      ['Yang et al. [33]','LLM tap/capacitor schedule; RL intra-day PV reactive power','Primary abstract describes hybrid evaluation','Full code, weights and security evidence unverified'],
      ['VeraGrid-Agent [34]','Tool-using agent; 150 numerical multiple-choice questions','Solver-grounded references; tool/no-tool comparison','QA, not physical voltage or cyber certification'],
      ['FLARE [35]','Restoration agent with evidence acquisition and switching','Physical guards; different voltage envelope','Degraded observations; exact substrates/panels omitted'],
      ['This thesis','RAG assistant and local language agents with numerical coordinator','Saved source, full-field replay and explicit failed cases','Language stress tests; comprehensive cyber validation open']
      ],[28,45,39,34])
    para(chapter3,'The pinned intake records identify four repositories and their exact commits. No new model or power-flow run was made for this literature review. Only the primary abstract was verified for [33], and missing code or test data are recorded as unresolved rather than counted as defeated methods.')

    chapter7=anchor('Chapter 7 Experimental results and critical analysis')
    para(chapter7,'6.15 Raw proposals software corrections and committed actions','Heading 2')
    attribution_text=[
      'An independent saved-response audit separates what the original model generated from what the controller repaired, tested and committed. It covers all four completed severe development roots in Section 7.8. The response order includes the earlier paid prefixes and their missing-only continuations without generating any response again. The audit binds each response to the executed parser and candidate list, then joins selected actions to the corresponding verifier record.',
      'There were 308 zone decisions with generation and 151 of them used a second prompt, giving 459 controller responses. Whole-response JSON parsing succeeded for 458 responses and 413 met the strict compact format requested in the prompt. That format required a bus string containing an integer and a numeric Q from the displayed allowed set. These format counts do not establish that a proposed bus was permitted at the current state.',
      'The executed normalizer accepted additional wrappers and aliases, selected the first valid payload and snapped Q to the nearest 25 Mvar before clamping it to 25–300 Mvar. It changed a numeric Q in 37 responses. Candidate validation then accepted 192 normalized responses, including 157 first responses and 35 second responses. The validator checked membership in the current bus candidate list; it did not independently enforce the original raw Q list. Thus accepted normalized actions are not equivalent to strict raw prompt compliance.',
      'The saved source reasons contain 120 responses naming bus 52 and 102 naming bus 32 when that bus was outside the current candidate list. This describes the observed interface failures, but the counts do not determine whether their cause was the training distribution, the current prompt or model behaviour. The same response can contribute to format and normalization categories, so these counts must not be added as disjoint failures.'
    ]
    for s in attribution_text:para(chapter7,s)
    table(chapter7,'Table 6.3 Original model output and action attribution on four severe development roots',
      ['Stage or event','Count','Denominator'],[
      ['Zone decisions with generation',308,'308 decisions'],['Second prompt required',151,'308 decisions'],
      ['Whole-response JSON valid',458,'459 responses'],['Strict requested compact schema valid',413,'459 responses'],
      ['Numeric Q changed by normalizer',37,'459 responses'],['Candidate valid after normalization',192,'459 responses'],
      ['Direct-candidate verifier accepted',68,'308 verifier records'],['Selected direct commits',51,'73 total commits'],
      ['Direct commits with changed Q',9,'51 direct commits'],['Selected guided numerical refinement',13,'73 total commits'],
      ['Selected numerical fallback',9,'73 total commits']],[88,22,36])
    para(chapter7,'Of 308 direct-candidate verifier records, 68 were numerically accepted tests, while 51 direct actions were actually selected and committed. These are different events because the coordinator compares candidates before commitment. Nine of the 51 direct commits used a Q changed by the normalizer, and 42 met the strict compact output format. The 13 guided refinements and nine fallback actions are numerical search contributions. They are retained in the controller result but must not be reported as unrepaired model outputs.')
    para(chapter7,'The source label llm_direct therefore identifies the direct proposal route after software interpretation and numerical protection. It does not certify an untouched model action or prove that the language model caused the final voltage improvement. The saved-only audit made zero new model, power-flow, controller or optimizer calls. Its separate reader reproduced the counts and action joins, while the earlier bookkeeping failure caused by action-label aliases remains preserved. Causal value still requires equally informed controls and fresh matched trajectories.')

    chapter8=anchor('Chapter 8 Cybersecurity scope existing stress tests and evaluation design')
    para(chapter8,'7.13 External native GraphAgent on the same severe roots','Heading 2')
    graphtext=[
      'A source-bound port of the author GraphAgent [29] was executed on the same four hashed initial federation networks used in Section 7.8. It is a numerical policy from the author comparison code, not a newly trained DQN or a language model. The compatible backend and its source contract are recorded, so this is not presented as a reproduction of the historical PowerWorld runtime.',
      'All four native episodes terminated when the Newton–Raphson solve did not converge within 80 iterations. In each case the failing action set generator index 23 at zero-based bus 55 to 1.05 p.u. The failures occurred after 19, 21, 21 and 21 total operations. Final UV, OV and full-band restoration are unknown because the final physical solve did not return. The last converged prefix is retained as diagnostic evidence and is not substituted for a successful terminal result.'
    ]
    for s in graphtext:para(chapter8,s)
    table(chapter8,'Table 7.8 Terminal status of the external native GraphAgent port on four matched roots',
      ['Root','Initial UV','Operations','Terminal result'],[
      ['35 MG1',56,19,'Solver nonconvergence; endpoint unknown'],
      ['36 MG1',58,21,'Solver nonconvergence; endpoint unknown'],
      ['84 MG2',57,21,'Solver nonconvergence; endpoint unknown'],
      ['127 MG3',55,21,'Solver nonconvergence; endpoint unknown']],[28,25,28,65])
    para(chapter8,'The campaign made 78 new power-flow attempts with 74 returns and four exceptions, and reused four earlier first-action results. The independent reader replayed the 74 new returned inputs once, with zero difference in checked numerical fields and a maximum KCL residual of 8.261534595604988e−9. Failed calls were not retried. The original reader stopped before any replay because an old entry cursor lacked RNG state; the additive reader bound the saved actual case-entry RNG while retaining the within-case state checks and every physical result.')
    para(chapter8,'Original DFF and HG-VF completed these four cases with converged endpoints, although both left UV and OV violations. This is a measured difference in completion on shared initial cases. The external policy changes generator or slack voltage and existing binary shunts with a native 136-operation allowance, whereas HierGrid adds shunts under its 450 Mvar cap and 25-operation limit. These differences prevent an equal-resource ranking or a general claim that HierGrid is superior. No GPU, language inference or training was used by the GraphAgent campaign.')

    # Append versioned references within the existing reference section.
    refs=[
      '[31] M. Chehade and H. Zhu, Fine-Tuning LLMs to Generate Economical and Reliable Actions for the Power Grid, arXiv:2602.15350v1, 17 February 2026. Preprint. https://arxiv.org/abs/2602.15350v1',
      '[32] X. Yang et al., Large Language Model as An Operator: An Experience-Driven Solution for Distribution Network Voltage Control, arXiv:2507.14800v2, revised 12 April 2026. Versioned abstract-page title; preprint. https://arxiv.org/abs/2507.14800v2',
      '[33] X. Yang et al., Two-Stage Active Distribution Network Voltage Control via LLM-RL Collaboration: A Hybrid Knowledge-Data-Driven Approach, arXiv:2602.21715v1, 25 February 2026. Primary abstract verified; preprint. https://arxiv.org/abs/2602.21715v1',
      '[34] S. Tripathi, H. Mohsenian-Rad and M. Raissi, VeraGrid-Agent: Tool-Augmented LLMs for Distribution Optimal Power Flow at the Grid Edge, arXiv:2607.25155v1, 28 July 2026. Preprint. https://arxiv.org/abs/2607.25155v1',
      '[35] B. Subrahmanyam and N. Choudhary, FLARE: Physics-Grounded Evaluation of Language-Model Agents for Feeder Restoration with Degraded Observations, arXiv:2610.23251v1, 16 October 2026. Preprint. https://arxiv.org/abs/2610.23251v1'
    ]
    last=next(p for p in d.paragraphs if p.text.startswith('[30]'))
    for text in refs:
        p=d.add_paragraph(text);last._p.addnext(p._p);last=p
        p.paragraph_format.space_after=Pt(6)
        for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(11)
    # Preserve the thesis's manual list design and insert the three new captions.
    listbase=next(p for p in d.paragraphs if p.text.startswith('Table 2.1 ') and '\t' in p.text)
    from docx.text.paragraph import Paragraph
    for after,caption in [('Table 2.1 ','Table 2.2 Closest recent language model grid studies and comparison boundaries'),
                         ('Table 6.2 ','Table 6.3 Original model output and action attribution on four severe development roots'),
                         ('Table 7.7 ','Table 7.8 Terminal status of the external native GraphAgent port on four matched roots')]:
        pos=next(p for p in d.paragraphs if p.text.startswith(after) and '\t' in p.text)
        e=deepcopy(listbase._p);np=Paragraph(e,pos._parent);np.text=caption+'\t0';pos._p.addnext(e)
    out=O/'Hannaan_Thesis_Attribution_And_Comparators.docx';d.save(out)
    def media(p):
        with zipfile.ZipFile(p) as z:return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/'))
    assert media(BASE)==media(out);assert sha(BASE)==oldsha
    assert len(d.tables)==15
    # Save the new prose as a source supplement without changing old reviewed sources.
    supplement='\n\n'.join(['# Thesis evidence supplement 28 October 2026','## 2.20 Closest recent grid agent studies',*literature,'## 6.15 Raw proposals software corrections and committed actions',*attribution_text,'## 7.13 External native GraphAgent on the same severe roots',*graphtext])+'\n'
    (O/'Thesis_Source_Supplement.md').write_text(supplement,encoding='utf-8')
    dump(O/'Integration_Record.json',{'status':'CREATED_AWAITING_PAGINATION_AND_VISUAL_QA','base_sha256':oldsha,'base_unchanged':True,'tables':15,'references':35,'new_science':0,'new_sections':['2.20','6.15','7.13'],'attribution_result':'outputs/original118_raw_action_attribution_v2_20261028/Results.json','attribution_audit':'outputs/original118_raw_action_attribution_v2_20261028/independent/Independent_Audit.json','limitations':['Four inspected development roots, no causal LLM proof','Native Graph different actuators and budgets; final failed endpoints unknown','Five focused recent records, not all literature','Original 109-page draft retained']})
    print(json.dumps({'docx':str(out),'tables':len(d.tables),'references':35,'new_science':0}))
if __name__=='__main__':main()
