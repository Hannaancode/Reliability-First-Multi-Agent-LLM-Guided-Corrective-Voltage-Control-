"""Save current closed evidence and prepare an explicit compact publication."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/qa_thesis_metadata_publication_20261029'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def put(p,x):
    p=R/p;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8');t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists();O.mkdir();now=datetime.now(timezone.utc).isoformat()
    meta='outputs/source_metadata_admission_20261029/Source_Counterexamples_And_Prototype_Check.json'
    m=rd(meta);assert m['status']=='PASS_SOURCE_COUNTEREXAMPLES_AND15_STRUCTURED_METADATA_FIXTURES'
    thesis='outputs/thesis_caption_QA_v2_20261029/Final_Visual_And_Evidence_QA.json';assert rd(thesis)['status']=='PASS_REVIEWED_WORKING_THESIS_CAPTIONS_AND_QA'
    msg='T12 progressed: selected actual notebook functions accept an answer with no claims, accept a nonentailing quoted claim, display first-retrieved citation rather than cited-source identity, and miss changed page/year/URL values when the metadata class exists in context. Six controlled source counterexamples used synthetic stub outputs, no model/retrieval calls. Separate structured metadata validator passed15fixed checks; source/citation binding and unknown fields explicit. Not an end-to-end prose/refusal/security guarantee. Historical200summary recovered but only11printed case headers; exact fullcases/runtime remain unknown. T12 PARTIAL, notcomplete.'
    decision=R/'outputs/source_metadata_admission_20261029/Findings_And_Next_Decision.txt'
    decision.write_text('SOURCE-METADATA FINDINGS — '+now+'\n\n'+msg+'\n\nThe notebook reports impossible-requirement failure0.893 across28cases and out-of-scope failure0.360 across25cases. Those printed aggregate rates are preserved; no new historical rate is inferred from our synthetic cases. The selected source functions were executed under the recorded local Pydantic version with fake generator output, not the unknown historical serving runtime.\n\nNext: bind real retrieved source bytes and authoritative field extraction to the prototype; define the output envelope so unchecked free text cannot be presented as validated metadata. Keep technical-answer support and answerability/refusal evaluation separate. Freeze a complete fixed-case evaluation contract before actual inference, include answerable positives as well as unsupported requests, and measure both over-refusal and fabricated values. No model rerun or performance claim is authorized by the software checks alone.\n','utf-8')
    tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json');t=next(x for x in tasks['tasks'] if x['id']=='T12')
    assert t['status']=='OPEN';t.update(status='PARTIAL_SOURCE_COUNTEREXAMPLES_AND_METADATA_PROTOTYPE',evidence=[meta,'outputs/source_metadata_admission_20261029/Protocol.json'],new_scoped_progress=msg)
    tasks['updated_utc']=now;assert tasks['completed_requirement_count']==19;put('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    exact={'at_utc':now,'status':'CLOSED_PUBLIC_QA_AND_REVIEWED_THESIS_READY_FOR_NEXT_SCOPED_WORK','all_six_final_goals':'OPEN','priority_order':['G3','G1','G2','G4','G5','G6'],
      'thesis_complete':19,'thesis_total':35,'newly_completed_this_run':['T20','T26','T28','T32','T34'],
      'thesis_current':'outputs/thesis_caption_QA_v2_20261029/Hannaan_Thesis_Caption_And_QA_Update.docx','thesis_qa':thesis,
      'public_QA_completion':'outputs/public_qa_completion_20261029/Verified_Completion.json','public_QA_fixed_intervention':'STOPPED_NO_OUTCOME_RESCUE',
      'owned_jobs':[],'GPU_assignments':[],'waiting_timer':None,'actual_usage_lifecycle':'ACTIVE goal; no assumed quota reset or promise of ongoing background compute',
      'source_metadata_progress':meta,'numerical_admission':'outputs/inference_numerical_admission_20261029/tensor_hook/Result.json','external118_source_correction':'outputs/common118_DER_admission_correction_20261029/Corrected_Source_Admission.json',
      'next_ordered_tasks':[
        {'task':'G3 common118 external-control admission','action':'Use corrected4PV+4diesel inventory. Establish real capability/profile data for native inverter role, or separately name a common-shunt algorithm adaptation with equal observations/actions/training/resources. Do not invent ratings or count allsgens asPV. No trainedpolicy ready.'},
        {'task':'T12 source-metadata reliability','action':'Integrate typed citation validator with authoritative byte-bound source loader and output rendering. Evaluate exact metadata values, supported-answer positives and refusal negatives under a frozen future contract; keep arbitrary prose entailment separate.'},
        {'task':'G4/G2 future inference engineering','action':'Bind tested raw-logit observer to actual source/runtime/owner/persistent stop and independent reader. Only new non-test engineering identities under a separately fixed protocol may diagnose numerical behavior; old150QAitems and stoppedscale studies must not be rerun for rescue.'},
        {'task':'G1 new mechanism','action':'Before any new joint-allocation campaign, compare exact action/operation/stock semantics against prior complete and failed branch studies; freeze novelty-relative mechanism and equal numerical controls, relevant attempt identity coverage and full cost. No automaticphysicslaunch.'},
        {'task':'Open thesis source gaps','action':'T04later137rawjoin,T09fullcost,T11historical99percent,T13lineage,T14matchedRAG,T21holdouts andadmin/remainingitems stay open. Preserve all17remaining scopes without inventing evidence.'}],
      'stop_rules':['No oldowner/readerrun/retrain or scientific retry.','No retuning failed gates or weakened controls.','No GPU allocation merely because profiles may have time.','No claim of final LLM/fullsecurity/zero-all/superiority.']}
    # There are16 incomplete checklist items after19closures; retain that exact count.
    exact['next_ordered_tasks'][-1]['action']=exact['next_ordered_tasks'][-1]['action'].replace('all17remaining','all16remaining')
    put('outputs/research_resumption_20261028/Next_Exact_Work_20261029.json',exact)
    for rel in ['outputs/research_resumption_20261028/Current_Resume.json','outputs/public_qa_scale_design_20261029/Exact_Resume.json']:
        x=rd(rel);x.update(at_utc=now,source_metadata_progress=meta,exact_next_work='outputs/research_resumption_20261028/Next_Exact_Work_20261029.json');put(rel,x)
    header='## Source-metadata counterexamples and next work saved — '+now+'\n\n19/35thesisrequirements complete; all6researchgoalsOPEN. Three fixed publicQAarms/auditended,T4sreleased. Thesis130pages/19tables/22figures/35references reviewed. '+msg+' Exactnextwork:outputs/research_resumption_20261028/Next_Exact_Work_20261029.json. No waitingtimer; oldexperimentsstaySTOPPED.\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text(header+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+msg+'\n19/35documentationrequirementscomplete; all6finalgoalsopen.\n')
    codes=['close_public_qa_comparison_20261029.py','close_public_qa_comparison_v2_20261029.py','inference_numerical_admission_gate_20261029.py','check_inference_numerical_admission_gate_20261029.py','check_raw_logit_observer_tensor_20261029.py','reconcile_common118_DER_admission_20261029.py','source_metadata_admission_20261029.py','check_source_metadata_admission_20261029.py','close_cohort_reference_thesis_20261029.py','integrate_thesis_caption_and_QA_20261029.py','repair_thesis_caption_drawing_preservation_20261029.py','integrate_thesis_caption_and_QA_v2_20261029.py','extract_internal_submission_checklist_20261029.py','render_caption_QA_v2_final_20261029.py','close_caption_QA_thesis_20261029.py',Path(__file__).name]
    proofs=['outputs/public_qa_completion_20261029/'+x for x in ['Verified_Completion.json','Saved_Output_Diagnosis.json','Results_And_Next_Decision.md']]
    proofs+=['outputs/public_qa_completion_preparation_20261029/Preserved_Closure_Assertion_Failure.json',
      'outputs/inference_numerical_admission_20261029/Software_And_Saved_Evidence_Check.json','outputs/inference_numerical_admission_20261029/Synthetic_Probe_Design.json','outputs/inference_numerical_admission_20261029/tensor_hook/Result.json',
      'outputs/common118_DER_admission_correction_20261029/Corrected_Source_Admission.json','outputs/common118_DER_admission_correction_20261029/Decision.md',meta,'outputs/source_metadata_admission_20261029/Protocol.json','outputs/source_metadata_admission_20261029/Findings_And_Next_Decision.txt',
      'outputs/thesis_bibliography_review_20261029/Verified_Reference_Register.json','outputs/thesis_method_versions_20261029/Method_Version_Register.json','outputs/thesis_contribution_claim_review_20261029/Contribution_Claim_Review.json','outputs/thesis_cohort_use_20261029/Cohort_Use_Register.json','outputs/thesis_cohorts_references_20261029/Final_Visual_And_Evidence_QA.json',thesis,
      'outputs/thesis_caption_QA_v2_20261029/Visual_Review_Record.json','outputs/thesis_caption_QA_v2_20261029/Internal_Checklist_Extraction.json','outputs/public_qa_scale_design_20261029/Focused_Method_Review_And_Decisions.md']
    index=[]
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip','x',zipfile.ZIP_DEFLATED) as z:
        for rel in ['work/'+x for x in codes]+proofs:
            p=R/rel;b=p.read_bytes();assert not any(s.search(b.decode('utf-8-sig')) for s in SECRET),rel
            z.writestr(rel,b);index.append({'path':rel,'bytes':len(b),'sha256':sha(p)})
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip') as z:
        assert z.testzip() is None
        for x in index:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
    put((O/'Artifact_Index.json').relative_to(R),{'members':index,'raw_backup_complete':False,'excluded':['privateweights/NETs','rawquestions/circuit/labels/tokenpacks/modeloutputs','rawnotebooks/transcripts','thirdpartysource/rawabstracts','fullthesisDOCX/PDF','credentials/runtimeproxydata']})
    compact={**exact,'publication_scope':'Own code and compact evidence only; not a complete private raw backup','public_QA_native_correct':{'0.5B':37,'1.5B':0,'3B':37},'public_QA_denominator_each':150,'public_QA_failure':'1.5B150repeated-tokenresponses; numericalcauseUNKNOWN; oldoutcomesneverreplaced','new_literature_review':'Four targeted primary sources;3fullHTMLrelevantsections+1abstract. Prior art distinguishes safeoptimization/learnedPFwarmstarts/graphACOPF/constrainedMARL; no novelty/superiority claim.'}
    put((O/'Current_Progress.json').relative_to(R),compact)
    for dest,source in [('Thesis_Checklist.json','outputs/thesis_research_closure_20261028/Tasks.json'),('Public_QA_Completion.json','outputs/public_qa_completion_20261029/Verified_Completion.json'),('Thesis_Visual_And_Evidence_QA.json',thesis),('Metadata_Source_Findings.json',meta)]:
        (O/dest).write_bytes((R/source).read_bytes())
    files=[]
    for p in sorted(O.iterdir()):
        b=p.read_bytes();files.append({'local':p.relative_to(R).as_posix(),'path':'research_progress/20261029_QA_thesis_metadata/'+p.name,'bytes':len(b),'sha256':sha(p),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
    put((O/'Publication_Map.json').relative_to(R),files)
    print(json.dumps({'status':'SAVED_AND_PUBLICATION_PREPARED','thesis_complete':19,'T12':'PARTIAL','files':len(files),'members':len(index),'bytes':sum(x['bytes'] for x in files)}))
if __name__=='__main__':main()
