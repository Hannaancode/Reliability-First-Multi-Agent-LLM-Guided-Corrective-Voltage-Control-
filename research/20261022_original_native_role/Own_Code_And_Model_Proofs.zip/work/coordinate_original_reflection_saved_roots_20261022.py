"""One original-role model owner followed by its only zero-model reader."""
import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
P=R/'outputs/original_reflection_saved_root_preparation_20261022'
O=R/'outputs/original_reflection_saved_root_handoff_20261022'
def put(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
 O.mkdir(exist_ok=False)
 put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'at_utc':datetime.now(timezone.utc).isoformat()})
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf8') as f:
   code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_atomic_source_owner_20261022.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),{'exit_code':code,'at_utc':datetime.now(timezone.utc).isoformat()})
  assert code==0,'Preserve all partial/failure; no model/allocation/reader retry'
 put(O/'Completion.json',{'status':'ORIGINAL_NATIVE_ROLE_MODEL_AND_SOLE_READER_TERMINAL','at_utc':datetime.now(timezone.utc).isoformat()})
if __name__=='__main__':main()
