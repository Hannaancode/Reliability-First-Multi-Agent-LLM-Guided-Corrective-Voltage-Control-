"""Source/weights/mutations/action/allbus/cost audit and unique independent PF replay."""
import hashlib,json,pickle,os,sys,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020';OUT=SRC/'independent_audit';PREP=ROOT/'outputs/stable_ddpg_native_remaining_preparation_v2_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();costs={'checkpoint_metadata_loads':0,'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'model_forward_backward_optimizer_GPU_calls':0}
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    try:
        sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'));import candidate_process_runtime
        import numpy as np
        import torch
        import pandapower as pp
        from pandapower.pypower.makeSbus import makeSbus
        from candidate_process_evidence_utils import frozen_checks
        p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));manifest=json.loads((SRC/'Closed_Manifest.json').read_text(encoding='utf-8'));result=json.loads((SRC/'Result.json').read_text(encoding='utf-8'))
        for n,h in p['sources'].items():assert sha(ROOT/'work'/n)==h
        author=ROOT/'outputs/stable_ddpg_author_intake_20261020/author_reference'
        for n,h in p['author_inputs'].items():assert sha(author/n)==h
        for f in manifest['files']:assert sha(SRC/f['path'])==f['sha256'] and (SRC/f['path']).stat().st_size==f['bytes']
        prev='0'*64;events=[]
        for line in (SRC/'Journal.jsonl').read_text(encoding='utf-8').splitlines():
            row=json.loads(line);e=row['event'];assert e['previous']==prev and hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest()==row['sha256'];prev=row['sha256'];events.append(e)
        assert prev==manifest['journal_last_sha256']
        assert sum(e['kind']=='policy_agent_attempt' for e in events)==sum(e['kind']=='policy_agent_return' for e in events)==result['costs']['policy_agent_returns']==18
        assert sum(e['kind']=='checkpoint_load_return' for e in events)==result['costs']['checkpoint_load_returns']==18
        joins=json.loads((SRC/'Checkpoint_Load_Joins.json').read_text(encoding='utf-8'));assert len(joins['primary'])==len(joins['cold'])==9
        for algorithm in p['algorithms_in_author_order']:
            raw=np.load(SRC/f'{algorithm}_primary_Raw.npy');cold=np.load(SRC/f'{algorithm}_cold_Raw.npy');q=np.load(SRC/f'{algorithm}_Native_Absolute_Q.npy');assert np.array_equal(raw,cold) and raw.shape==q.shape==(3,1)
            assert np.array_equal(q,-np.clip(raw,-.3,.3)) and np.max(np.abs(q))<=.3+1e-7
            before=np.load(SRC/f'{algorithm}_primary_weights_before.npz');cb=np.load(SRC/f'{algorithm}_cold_weights_before.npz');after=np.load(SRC/f'{algorithm}_primary_weights_after.npz');ca=np.load(SRC/f'{algorithm}_cold_weights_after.npz')
            for i in range(3):
                name=f'checkpoints/single-phase/13bus/{algorithm}/policy_net_checkpoint_a{i}.pth';state=torch.load(author/name,map_location='cpu',weights_only=True);costs['checkpoint_metadata_loads']+=1
                assert {n.split('::',1)[1] for n in before.files if n.startswith(f'{i}::')}==set(state)
                for name,t in state.items():
                    key=f'{i}::{name}';assert np.array_equal(before[key],t.numpy()) and np.array_equal(cb[key],t.numpy()) and np.array_equal(after[key],ca[key])
                    if algorithm!='safe-ddpg' or name not in ('b','c'):assert np.array_equal(before[key],after[key]),(algorithm,key)
                    else:assert np.isfinite(after[key]).all() and np.min(after[key])>=0 and abs(float(np.abs(after[key]).sum())-.15)<1e-6
        rootstate=np.load(SRC/'Root_Controlled_State.npy');checks=[]
        oldroot=ROOT/'outputs/stable_ddpg_native_engineering_20261020';proof=json.loads((oldroot/'preserved_root_independent_audit/Independent_Partial_Audit.json').read_text(encoding='utf-8'));assert proof['status'].startswith('PASS_')
        for name in ['PF0_before.pkl','PF0_after.pkl','PF0_fields.npz']:assert sha(SRC/name)==sha(oldroot/name)
        with (SRC/'PF0_after.pkl').open('rb') as f:rootnet=pickle.load(f)
        physical={0:{'vm':rootnet.res_bus.vm_pu.to_numpy(copy=True),'q':rootnet.sgen.q_mvar.to_numpy(copy=True)}}
        graph=np.load(oldroot/'preserved_root_independent_audit/Verified_Admittance_And_State.npz')
        for index in range(1,result['costs']['PF_attempts']+1):
            identity=json.loads((SRC/f'PF{index}_Identity.json').read_text(encoding='utf-8'))
            with (SRC/f'PF{index}_before.pkl').open('rb') as f:net=pickle.load(f)
            if index==0:
                assert list(net.sgen.bus[:3])==[2,7,9]
                # Independent literal source RNG sequence at first author test repetition.
                rng=np.random.RandomState(0);assert int(rng.choice([0,1]))==0
                expected=np.zeros(len(net.sgen));expected[0]=-.5*rng.uniform(1,7);expected[1]=-.8*rng.uniform(1,4);expected[2]=-.3*rng.uniform(1,5)
                assert np.array_equal(net.sgen.p_mw.to_numpy(),expected) and np.all(net.sgen.q_mvar.to_numpy()==0) and np.all(net.load.p_mw.to_numpy()==0) and np.all(net.load.q_mvar.to_numpy()==0)
            else:
                algorithm=identity['label'];expected=np.load(SRC/f'{algorithm}_Native_Absolute_Q.npy').flatten();assert np.array_equal(net.sgen.q_mvar.to_numpy()[:3],expected)
                with (SRC/'PF0_before.pkl').open('rb') as f:root=pickle.load(f)
                assert np.array_equal(net.sgen.q_mvar.to_numpy()[3:],root.sgen.q_mvar.to_numpy()[3:])
                for table in ['bus','line','trafo','load','gen','ext_grid','shunt','switch']:assert net[table].equals(root[table])
                assert np.array_equal(net.sgen.p_mw.to_numpy(),root.sgen.p_mw.to_numpy())
            before_q=net.sgen.q_mvar.to_numpy(copy=True);stored=np.load(SRC/f'PF{index}_fields.npz');costs['PF_attempts']+=1;t=time.monotonic()
            try:pp.runpp(net,**identity['kwargs'])
            except BaseException:costs['PF_exceptions']+=1;raise
            costs['PF_returns']+=1;assert net.converged;delta=0.
            for name in stored.files:
                actual=net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float);target=stored[name];assert actual.shape==target.shape and np.allclose(actual,target,rtol=0,atol=1e-9,equal_nan=True)
                finite=np.isfinite(actual)&np.isfinite(target)
                if finite.any():delta=max(delta,float(np.max(np.abs(actual[finite]-target[finite]))))
            ppc=net._ppc;v=ppc['bus'][:,7]*np.exp(1j*np.deg2rad(ppc['bus'][:,8]));s=makeSbus(ppc['baseMVA'],ppc['bus'],ppc['gen']);assert np.array_equal(ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and ppc['baseMVA']==float(graph['baseMVA']);kcl=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert kcl<=1e-7
            vm=net.res_bus.vm_pu.to_numpy(copy=True);physical[index]={'vm':vm,'q':before_q};checks.append({'identity':index,'all_numeric_field_delta':delta,'KCL_max_pu':kcl,'PF_seconds':time.monotonic()-t,'all_bus_UV':int((vm<.95).sum()),'all_bus_OV':int((vm>1.05).sum())})
        assert np.array_equal(rootstate,physical[0]['vm'][[2,7,9]])
        for row in result['results']:
            q=np.load(SRC/f"{row['algorithm']}_Native_Absolute_Q.npy").flatten();actual=physical[row['source_PF']];vm=actual['vm'];controlled=vm[[2,7,9]]
            assert np.array_equal(q,actual['q'][:3]) and int((vm<.95).sum())==row['all_bus_UV'] and int((vm>1.05).sum())==row['all_bus_OV']
            assert row['native_controlled_done']==bool(np.min(controlled)>.95 and np.max(controlled)<1.05)
            assert (row['controlled_UV'],row['controlled_OV'])==(int((controlled<.95).sum()),int((controlled>1.05).sum()))
        assert time.monotonic()-start<p['fixed_reader_bound_seconds']
        put(OUT/'Frozen_After.json',frozen_checks());audit={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_AUTHOR_SOURCE_NATIVE_PI_ACTION_ALL9_WEIGHTS_COLD_OUTPUTS_MUTATIONS_ROOT_RNG_ALLBUS_AND_UNIQUE_PHYSICS_REPLAYS','source_costs':result['costs'],'costs':costs,'physics_checks':checks,'results':result['results'],'primary_plus_reader_PF_attempts':result['costs']['PF_attempts']+costs['PF_attempts'],'agent_policy_applications':18,'preparation_checkpoint_loads_separate':9,'old_partial_checkpoint_loads_separate':18,'old_primary_and_independent_root_PF_separate':2,'workflow_seconds':time.monotonic()-start,'our_model_or_full_paper_benchmark_or_superiority_claim':False}
        put(OUT/'Independent_Audit.json',audit);print(json.dumps({'independent':'PASS','actual_PF_total':audit['primary_plus_reader_PF_attempts'],'results':result['results']}))
    except BaseException as e:put(OUT/'Failure.json',{'failure':str(e),'traceback':traceback.format_exc(),'costs':costs});raise
if __name__=='__main__':main()
