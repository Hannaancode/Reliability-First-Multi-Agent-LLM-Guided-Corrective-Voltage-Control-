"""Preserve the new native comparison once and checkpoint verified limits."""
import zipfile
from graph118_native_campaign_core_20261028 import *
O=R/'outputs/graph118_native_comparison_completion_20261028'
def main():
    O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    audited=R/'outputs/graph118_native_campaign_independent_rng_v2_20261028';audit=read(audited/'Independent_Audit.json')
    assert audit['status']=='PASS_ALL4_COMPLETE_NATIVE_GRAPH_EPISODES' and audit['first_replay_returns']==74
    comparison='outputs/graph118_native_context_comparison_rng_v2_20261028/Comparison.json';assert read(R/comparison)['status']=='ALL4_IDENTICAL_INITIAL_ROOTS_NATIVE_ROLE_CONTEXT_COMPARISON'
    primary=read(E/'Result.json');diagnostics=[]
    for c in primary['cases']:
        last=read(E/c['calls'][-1]);prior=read(E/c['calls'][-2])
        assert last['exception']['type']=='LoadflowNotConverged' and last['decoded']['bus']==55 and last['decoded']['vm_pu']==1.05
        diagnostics.append(dict(case_id=c['case_id'],termination='NATIVE_PF_EXCEPTION',total_operations=c['action_count'],failed_action=last['decoded'],exception=last['exception'],
          last_returned_pre_failure=prior['strict_metrics'],last_return_is_not_final_success=True,physical_infeasibility='NOT_PROVED',no_retry_or_threshold_change=True))
    put(O/'All4_Terminal_Diagnostics.json',dict(status='SAVED_ONLY_ALL4_DIAGNOSTICS',rows=diagnostics,new_PF_model_calls=0))
    folders=[E,A,audited,P,R/'outputs/graph118_reader_rng_binding_v2_preparation_20261028',R/'outputs/graph118_native_context_comparison_rng_v2_20261028',
             R/'outputs/graph118_native_campaign_handoff_20261028',R/'outputs/graph118_reader_rng_v2_handoff_20261028']
    files=[f for d in folders for f in d.rglob('*') if f.is_file()]
    sources=set(read(P/'Protocol.json')['source_hashes'])|set(read(P/'Launch_And_Reader_Lock.json')['additional_source_hashes'])
    sources|={'work/audit_graph118_native_campaign_rng_v2_20261028.py','work/coordinate_graph118_reader_rng_v2_20261028.py','work/assemble_graph118_native_context_comparison_rng_v2_20261028.py'}
    # Include owned code only; third-party source remains pinned by hash.
    files += [R/n for n in sorted(sources) if n.startswith('work/')]
    entries={f.relative_to(R).as_posix():sha(f) for f in files}
    archive=O/'Native_Graph_All4_Source_And_Evidence.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for name in entries:z.write(R/name,name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(entries)
        for name,h in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
    put(O/'Archive_Certificate.json',dict(members=len(entries),bytes=archive.stat().st_size,sha256=sha(archive),CRC_and_every_member_hash='PASS',members_sha256=entries,
        old_paid_prefix_assets_referenced_not_duplicated=True,not_complete_project_backup=True))
    result=dict(at_utc=now,status='COMPLETE_ALL4_NATIVE_COMPARISON_INDEPENDENT_PASS',audit=(audited/'Independent_Audit.json').relative_to(R).as_posix(),comparison=comparison,
        primary_new_PF_attempts=78,primary_returns=74,primary_exceptions=4,first_independent_return_replays=74,maximum_field_delta=0.,maximum_KCL_pu=audit['maximum_KCL_pu'],
        native_episode_outcome='All4 source-native episodes terminated on80iterationNRnonconvergence; finalUV/OVUNKNOWN, no endpoint safety success. Lastreturned states are diagnostic only.',
        interpretation='OriginalDFF/HGVF retained converged endpoints on same4roots but residualUV/OV. Different native actuators/horizons/backend; not general/equalresource/causalLLM superiority.',
        source_initial_rng_repair='Oldcursor lackedRNG; allotherentryfields exact, actualcaseentryRNGbound. Every oldauditassertion retained; originalfailedreader0replays. No primary retry or independent-phase repeat.',
        costs='Primary, firstreader, engineering, original0replayreaderfailure and paidprefix costs remain separately retained.',
        new_LLM_GPU_training_calls=0,all_actors_ended=True,all_six_final_goals='OPEN')
    put(O/'Verified_Completion.json',result)
    f=R/'outputs/research_resumption_20261028/Current_Resume.json';resume=read(f)
    resume.update(at_utc=now,scientific_jobs=[],coordinator=None,exec_session=None,gpu_assignments=0,waiting_check=None,new_status='ORIGINAL_AND_EXTERNAL_NATIVE_ALL4_COMPARISONS_CLOSED_WITH_LIMITATIONS',
                  external_graph118_completion=(O/'Verified_Completion.json').relative_to(R).as_posix())
    resume['next']=['Publish current compact own-code/thesis/evidence/literature/comparison with freshlease/exactbytechecks.',
      'Continue external trained118 admission with common information/actuator/resource controls; source-nativeGraph complete, no rerun or retune.',
      'Integrate new closest-method literature and nativecomparison limits into next reviewed thesis revision;109pageworkingcopy staysverified.',
      'Remaining original137rawlineage, RAGadjudication and actualrawaction-attribution gaps need saved-evidence work; no fabricated provenance or automaticGPU.',
      'VeraGrid150publicQA candidate needs version/license/labelhiddeninput/actualmodel/solver/tool/control/cost protocol. FLARE exact substrates/panels unavailable in pinned repo.']
    f.write_text(json.dumps(resume,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    taskfile=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(taskfile)
    g3=next(t for t in tasks['tasks'] if t['checklist_id']=='G3')
    tid='G3.native_graph118_all4_20261028';assert all(t['id']!=tid for t in g3['subtasks'])
    g3['subtasks'].append(dict(id=tid,completed=True,description='Complete all4 source-native external GraphAgent episodes and first74returnreplays on identical original roots, preserve4terminalsolverfailures and allcosts; nativecontrols/horizon differ.',evidence=result['audit'],verified_at_save=now))
    g3['status']='ORIGINAL_AND_NATIVE_EXTERNAL_ALL4_COMPLETE_EQUAL_RESOURCE_TRAINED_COMPARISONS_OPEN'
    g3['current_result']='OriginalDFF51UV/11OV,HGVF26/11,offlineHGSE20/12; nativeexternalGraph all4terminalPFfailure/finalUVOVUNKNOWN. No equalresource/general superiority.'
    tasks.update(updated_at_utc=now,current_owned_jobs=[],current_GPU_assignments=0,current_waiting_automations=[],latest_resume='outputs/research_resumption_20261028/Current_Resume.json')
    taskfile.write_text(json.dumps(tasks,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    header=f'''## Original and external native all-four comparisons closed — {now}

Read outputs/research_resumption_20261028/Current_Resume.json and outputs/graph118_native_comparison_completion_20261028/Verified_Completion.json. All scientist/readers/coordinators ended;0GPU/timer. New native GraphAgent all4 episodes terminate at bus55target1.05 with80iteration NRnonconvergence after19/21/21/21operations; finalUV/OVUNKNOWN.78newattempts74returns4exceptions;74firstreplays independentlyPASS,delta0,KCLmax8.261534595604988e-9. OriginalDFF/HGVF remainconverged on samehashedroots butUV/OVremain. Different generatorV/existingbinaryshunts/native136oprole versus addedshunts/25ops; no equalresource/causalLLM/generalwin. Old0replayRNG-entryreaderfailure retained; additiveactualentryRNGbinding preserves allotherfields and oldchecks; no science repeated. NewarchiveCRC/everyhashPASS, do not rehash/restart.109pagethesisreviewed,8/35requirementscomplete;5closestprimarypapers/fourreposadded. All6goalsOPEN. Continue next justified admission/evidence/thesis tasks, no idleGPU/purchases/resetguesses oroutcomeretunes. Currentcompactpublicationpending.

'''
    for name in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        file=R/name;file.write_text(header+file.read_text('utf-8-sig'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write(f'\n{now} — G3 native external GraphAgent ALL4 COMPLETE, independentPASS74firstreplays/0fielddelta/KCL8.2615e-9.78newPFattempts/74returns/4exceptions. All4 source-native episodes terminate at bus55target1.05 after19/21/21/21operations; finalUV/OVUNKNOWN. Compared samehashedroots against originalDFF/HGVF/offlineHGSE; controls/horizon differ, so no general/equalresource/LLM superiority. Alloldfirst4PF reused,0newLLM/GPU/training. Initialruntimefailure0PF and originalentryRNGreaderfailure0replays retained; actualentrybindingrepair changes no sourcepolicy/metrics. Newsource/evidencearchiveCRC/everymemberPASS. All6goalsOPEN; nextwork saved.\n')
    print(json.dumps(dict(status=result['status'],archive_members=len(entries),archive_bytes=archive.stat().st_size,all_owned_jobs=0)))
if __name__=='__main__':main()
