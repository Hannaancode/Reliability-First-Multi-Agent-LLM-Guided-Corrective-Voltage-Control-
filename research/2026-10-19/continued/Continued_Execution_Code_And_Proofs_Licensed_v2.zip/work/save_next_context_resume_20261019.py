"""Durable exact resume and numerical evidence; no scientific worker launch."""
import hashlib,json,os,zipfile
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from candidate_process_evidence_utils import seal
from equal_operation_benchmark_v2 import process
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
NUM=R/'outputs/next_required_numeric_context_20261019'
STUDY=R/'outputs/remaining_three_fixed_queries_20261019'
SCREEN=R/'outputs/fixed_receipt_next_context_screen_20261019'
OUT=R/'outputs/next_context_resume_20261019'
def atomic(path,data):
    temp=path.with_name(path.name+'.new')
    with temp.open('w',encoding='utf-8') as f:json.dump(data,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(temp,path)
def main():
    OUT.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    proof=read(NUM/'independent_audit/Independent_Audit.json');assert proof['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
    assert read(NUM/'menu_join_repair_v2_preparation/Completion.json')['reader_exit_code']==0
    full=read(NUM/'additive_menu_join_v2/Full_Native_Menu_ACK.json');assert full['all_forecast_keys']==proof['forecasts']==1430
    claim=read(SCREEN/'owner.claim');actual=process(claim['actual_pid'])
    if actual:assert actual['ParentProcessId']==claim['parent_pid'] and 'replay_fixed_receipts_with_next_context_20261019.py' in actual['CommandLine']
    waiting={'automation_id':'hiergrid-next-context-result-check','status':'ACTIVE_ONE_TIME','due_Asia_Qatar':'2026-10-19 10:43','due_UTC':'2026-10-19T07:43:00+00:00','delete_at_terminal':True,'rearm_only_if_exact_source_still_live':True,'do_not_revive_recurring_monitors':True}
    next_steps=[
        'Read newest runbook/Next_Phase_Plan headers and this Current_Resume first. All six final goals remain OPEN;13earlier verified subtasks retained, no fake whole-goal completion.',
        'Sole read-only policy analysis work/replay_fixed_receipts_with_next_context_20261019.py actualPID2272/shim13928, execsession91672, fixed900sec. Verify fresh exact actual PID/parent/command/claim before any intervention. No duplicate, old-source restart, in-flight edit or budget extension.',
        'At the estimated10:43Asia/Qatar one-time check, inspect actual Results.json/Leg_1.json/Closed_Manifest only after owner truly ended. Delete waiting timer at terminal, rearm only if trulylive. Normal/unchanged progress staysquiet. No newmodel/PF/derivative/forecast/solve is permitted in this analysis.',
        'Use exact next missing input from the completed screen. A complete observed-paid decision/projection is not a fresh actual commit, continuous replay, full protected physical trajectory or LLM/DSE superiority. Missing/partial states stayUNKNOWN.',
        'Any next genuinely unexecuted measurement needs prospective exact causal input/identity/source/solver/native-mask/scope/Q/cap/stock/guard/full-cost/persistent-state/ownership/independent-reader gates; no automatic PF from absent key or software success. Reuse all paid receipts with their costs; never repeat today\'s5physical queries or their5chargedreplays.',
        'New numerical context7bfff3... was computed ONCE,1dS/1factor/1solve118RHS and1430forecasts. Original full equation auditPASS, later menu-tail importerror preserved. Corrected menu join is additive_menu_join_v2/Full_Native_Menu_ACK.json with repairCompletion0. Do not rerun any old producer/reader/calculation or copy the known wrong action_key import into a new protocol.',
        'Keep all141development recipes and all70unknowninitials in scope. Eightknown>=50 include highest61/60 cases; do not substitute the four inspected root studies or frozen62bank as all-cases evidence. Preserve stopped larger-model trials/public benchmark failures and all adverse/UNKNOWN provenance.',
        'Update reseacrh progress.txt/checklist/exactresume and publish new code/proofs to research-progress-20261018 with current-head lease and exact remote-byte checks. No credentials/model/base cache/rawNET export or fullrawbackup claim.',
        'Original literalDFF+DFFALT+unchangedDSE requires both individualbranches and fullBOTHcosts plusmodel/training/preparation/solver/failurecosts. Fresh matched protected trajectories, strong equally informed controls, attribution and unused authorized confirmation remain necessary. No purchases/quotaevasion/guaranteedwinner/usageLimitedoverride.'
    ]
    checkpoint={'at_utc':at,'status':'SAFE17TO14_PHYSICS_AND_SINGLE_NUMERIC_CONTEXT_VERIFIED_POLICY_ANALYSIS_PENDING','all6finalgoals':'OPEN',
        'new_physics':'ALL3originalK4 remainingqueries accepted17to14UV/Vmmax<=1.05,6PF incl3chargedreplays,6returns0exceptions,all118fieldsreplayexact; noactualcommit/freshLLM/completepolicy result.',
        'physical_completion_reference':str((STUDY/'verified_completion/Verified_Completion.json').relative_to(R)),
        'new_numeric_context':proof,'full_native_menu_proof':full,'numeric_actual_result':read(NUM/'actual/Result.json'),
        'preserved_reader_failure':{'original_completion':read(NUM/'Completion.json'),'original_stderr_sha256':sha(NUM/'independent_audit_console.log'),'additive_repair':read(NUM/'menu_join_repair_v2_preparation/Completion.json'),'new_science_repeated':0},
        'active_analysis':{'actual_live':bool(actual),'actual_pid':claim['actual_pid'],'shim_pid':claim['parent_pid'],'source': 'work/replay_fixed_receipts_with_next_context_20261019.py','source_sha256':claim['source_sha256'],'actual_command':actual['CommandLine'] if actual else None,'execsession':91672,'fixed_bound_seconds':900,'new_scientific_calls':0},
        'waiting_check':waiting,'GPU_allocations':[],'next_steps_in_order':next_steps,'latest_verified_published_head':'c78d4285d6c79538944a92ebc4bf6719917dcc94'}
    path=STUDY/'verified_completion/Current_Resume_20261019.json';atomic(path,checkpoint)
    tasks_path=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(tasks_path);tasks['at_utc']=at;tasks['tasks'][0]['next']='Use Current_Resume_20261019.json; check sole read-only analysis once at10:43Asia/Qatar. Reuse5paidqueries and72known contexts; do not duplicate any science.'
    tasks['latest_exact_execution_state']=str(path.relative_to(R));atomic(tasks_path,tasks)
    resume_path=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';resume=read(resume_path);resume.update(at_utc=at,
        active_owned_jobs=[checkpoint['active_analysis']] if actual else [],latest_closed_continuation=str(path.relative_to(R)),current_task={'status':checkpoint['status'],'exact_resume':str(path.relative_to(R))},
        timers=[waiting],next_tasks=next_steps,latest_verified_GitHub_head=checkpoint['latest_verified_published_head'])
    atomic(resume_path,resume)
    header=f'LATEST EXACT CONTINUATION {at}\n\nSafequery17to14UV independentlyverified; noactualcommit/LLM/fullpolicyclaim. One NEWrequiredcurrentmaskcontext andALL1430forecasts independentlyPASS; failedextraimport and additive0science menujoinrepair preserved. Sole readonlyanalysis actual2272/shim13928/source replay_fixed_receipts_with_next_context_20261019.py maybelive, fixed900sec,0newscience. Estimatedone-timecheck10:43Asia/Qatar19October; deleteatterminal/rearmonlyiftrulylive. NoGPU. Read outputs/remaining_three_fixed_queries_20261019/verified_completion/Current_Resume_20261019.json plusRESEARCH_TASKS.md. All6goalsopen. Nooldrestart/duplicate/retune/budgetextension/frozenassetchange; fullBOTH DSEcosts/strongcontrols/unusedconfirmation preserved.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    note=f'\n\n{at} —Further19Oct progress: newcurrentmaskcontext '+proof['identity']+' computedONCE;1publicderivative/1LUfactor/1LUsolve118RHS/1430fullnativeforecasts. Independentderivative/JX=B/forecast/source/costPASS; maxJX-B '+str(proof['JXminusB_maxresidual'])+'. NativefullmenuACKPASS. Originalreaderextensionwrong-import failure preserved, additive0science repairPASS; no numerical retry. CPUcompile0.2842853sec, fullproducerworkflow85.7348455sec includes1430durableattempt/returnjournals; no deploymentlatencyclaim. All3newphysicalqueriesaccepted17to14UV safely aspreviouslysaved. Sole changed-evidence readonlyanalysis2272/shim13928 liveperexactcheck, fixed900sec, no model/PF/derivative/forecasts/solve/newcommit. One-time10:43Qatar resultcheckhiergrid-next-context-result-check,deleteatterminal. All6goalsopen, noGPU. Exactresume '+str(path.relative_to(R))+'.\n'
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write(note);f.flush();os.fsync(f.fileno())
    sources=['next_required_numeric_context_20261019.py','audit_next_required_numeric_context_20261019.py','repair_next_context_menu_join_20261019.py','replay_fixed_receipts_with_next_context_20261019.py','save_next_context_resume_20261019.py']
    local={p.relative_to(R).as_posix():p for p in NUM.rglob('*') if p.is_file()}
    for n in sources:local['work/'+n]=R/'work'/n
    local['Current_Resume_20261019.json']=path
    local_archive=seal(OUT,local,'Complete_Local_Numeric_Context_Evidence.zip')
    public={n:p for n,p in local.items() if p.suffix in ('.json','.md','.py','.log') or p.name=='owner.claim'}
    for rel in ('RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json'):public[rel]=R/rel
    for n,p in public.items():assert not SECRET_NAME.search(p.name) and not any(s.search(p.read_text('utf-8')) for s in SECRET),n
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in public.items()};put(OUT/'Manifest.json',{'files':desc,'local_complete_archive':local_archive,'no_raw_NET_model_or_full_backup_export':True,'all6goalsopen':True})
    dest=OUT/'Next_Context_Code_And_Proofs.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in public.items():z.write(p,n)
        z.write(OUT/'Manifest.json','Manifest.json')
    with zipfile.ZipFile(dest) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(public)+1 and z.testzip() is None
        for n,m in desc.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
    put(OUT/'Package_Audit.json',{'status':'PASS_UNIQUE_CRC_EVERY_HASH_SECRET_SCREEN','bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(public)+1})
    print(json.dumps({'saved':True,'analysis_live':bool(actual),'one_time_check_Qatar':'10:43','public_archive_bytes':dest.stat().st_size,'new_numeric_context':proof['identity']}))
if __name__=='__main__':main()
