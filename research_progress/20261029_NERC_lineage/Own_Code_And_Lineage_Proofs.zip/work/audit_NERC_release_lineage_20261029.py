"""Independent raw-decode reader of the new saved-release lineage analysis."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,re,time,zipfile
R=Path(__file__).resolve().parents[1];O=R/'outputs/nerc_release_lineage_v2_20261029';A=O/'independent_audit'
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def main():
    assert not A.exists();A.mkdir();start=time.perf_counter()
    p=json.loads((O/'Protocol.json').read_text('utf-8'));r=json.loads((O/'Release_Lineage_And_Grouping.json').read_text('utf-8'))
    assert digest((O/'Protocol.json').read_bytes())==r['protocol_sha256']
    assert digest((R/'work/analyse_NERC_release_lineage_v2_20261029.py').read_bytes())==p['source_sha256']
    with zipfile.ZipFile('C:/Users/HOME/Downloads/PowerGridQA-main.zip') as z:raw=z.read(p['input_member']);refraw=z.read(p['reference_member'])
    assert digest(raw)==p['expected_member_sha256']==r['input_member_sha256'];assert digest(refraw)==p['expected_reference_sha256']==r['reference_member_sha256']
    refs=json.loads(refraw);strict=[];comma=[];other=[];decoder=json.JSONDecoder();empty_q=[];empty_a=[]
    for lineno,line in enumerate(raw.decode('utf-8-sig').splitlines(),1):
        s=line.strip()
        if not s:continue
        try:value,end=decoder.raw_decode(s)
        except json.JSONDecodeError:other.append(lineno);continue
        assert isinstance(value,dict) and set(value)=={'question','answer'} and all(isinstance(v,str) for v in value.values())
        suffix=s[end:].strip();assert suffix in ['',','],(lineno,suffix)
        (strict if suffix=='' else comma).append((lineno,value))
        if not value['question'].strip():empty_q.append(lineno)
        if not value['answer'].strip():empty_a.append(lineno)
    original=json.loads((O/'All_Row_Identity_And_Source_Groups_LOCAL_ONLY.json').read_text('utf-8'));candidate=json.loads((O/'Candidate_Syntax_Repair_Views_LOCAL_ONLY.json').read_text('utf-8'));invalid=json.loads((O/'Invalid_Line_Preservation_LOCAL_ONLY.json').read_text('utf-8'))
    assert len(original)==len(strict)==r['records']==4597 and len(comma)==len(candidate)==99
    assert len(other)==91 and len(invalid)==190 and len(strict)+len(comma)+len(other)==r['nonblank_source_lines']==4787
    for i,(lineno,v) in enumerate(strict):
        assert original[i]['ordinal']==i and original[i]['line']==lineno and original[i]['record_sha256']==digest(canonical(v))
        found=re.search('LL[0-9]{8}',v['question']);identifier=found[0] if found else None
        assert original[i]['lesson_id']==identifier and original[i]['mapped_reference']==(identifier in refs if identifier else False)
    for i,(lineno,v) in enumerate(comma):assert candidate[i]['line']==lineno and candidate[i]['record']==v and candidate[i]['record_sha256']==digest(canonical(v))
    assert len(strict)+len(comma)==4696
    counts=Counter(x['lesson_id'] for x in original);assert sum(n for k,n in counts.items() if k is not None)==4397 and counts[None]==200
    assert sum(x['mapped_reference'] for x in original)==4340
    assert not empty_q and not empty_a
    source=Path('C:/Users/HOME/Downloads/RAG_Based_Integration_NERC (3).ipynb');nb=json.loads(source.read_text('utf-8'));cell=''.join(nb['cells'][1]['source'])
    assert digest(source.read_bytes())==p['source_notebook_sha256'] and digest(cell.encode())==p['source_cell_sha256']
    assert 'except json.JSONDecodeError' in cell and 'continue' in cell
    out={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_RAW_DECODE_ALL_LINE_ACCOUNTING_AND_EXACT_MEMBERSHIPS','strict_JSONL_QA':4597,'single_trailing_comma_QA':99,'other_nonblank_lines':91,'total_nonblank':4787,'content_QA_total_with_only_comma_syntax_normalization':4696,
      'strict_question_identifier_matches':4397,'strict_missing_identifier':200,'reference_mapped_strict_rows':4340,'empty_question_or_answer_records':0,
      'reported4396_retrieval_membership':'UNRESOLVED_ONE_FEWER_THAN_STRICT_IDENTIFIER_FILTER_NOT_FORCED_TO_MATCH',
      'source_loader_behavior':'Cell2 catchesJSONDecodeError and continues. This strictline recipe excludes99syntacticallyrecoverableQA lines along with91nonrecord lines if applied to these exactbytes. Historical actual runtime input bytes remain unknown.',
      'independence':'JSONDecoder.raw_decode plus explicit suffix classification, compared all4597strict and99candidate record hashes and source line numbers; no producer imports, no model, retrieval or native physical execution.',
      'new_model_retrieval_PF_training_calls':0,'workflow_seconds':time.perf_counter()-start,
      'input_sha256':digest(raw),'producer_result_sha256':digest((O/'Release_Lineage_And_Grouping.json').read_bytes()),'reader_source_sha256':digest(Path(__file__).read_bytes()),
      'limits':['Count agreement with4696does not certify the paper runtime release or evaluation membership.','4396vs4397remains unresolved; no case removed to make it match.','No train/test membership or model-pretraining leakage claim.','Original source file unchanged; syntax-candidate view is separate and not substituted in old experiments.']}
    (A/'Independent_Lineage_Audit.json').write_text(json.dumps(out,indent=2)+'\n','utf-8')
    print(json.dumps({k:out[k] for k in ['status','strict_JSONL_QA','single_trailing_comma_QA','content_QA_total_with_only_comma_syntax_normalization','strict_question_identifier_matches','empty_question_or_answer_records']}))
if __name__=='__main__':main()
