"""Static preparation only: bind ALL500 root references and a distinct design.

Does not unpickle networks, run equations, solve, call models, or launch jobs.
The output is explicitly NOT an execution protocol: solver/equation/owner gates
must be completed and frozen before any new numerical or physical measurement.
"""
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/remaining85_mechanism_review_20261029'


def read(p):
    return json.loads((R / p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256((R / p).read_bytes()).hexdigest()


def put(name, data):
    with (O / name).open('x', encoding='utf-8') as f:
        json.dump(data, f, indent=2, allow_nan=False)


def main():
    root_source = 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json'
    primary_source = 'outputs/public13_matched_numeric_execution_20261021/Result.json'
    graph_source = 'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz'
    roots = read(root_source)['roots']
    first_models = {m['scope']['seed']: m for m in read(primary_source)['math_receipts']
                    if m['status'] == 'RETURNED' and m['scope']['step'] == 1}
    assert [r['seed'] for r in roots] == list(range(500))
    entries = []
    for root in roots:
        normal = all(.95 <= v <= 1.05 for v in root['all13_initial_vm'])
        model = first_models.get(root['seed'])
        if not normal:
            assert model is not None
            assert model['current_NET']['path'] == root['path']
            assert model['current_NET']['sha256'] == root['sha256']
        entries.append({
            'seed': root['seed'],
            'exact_root': {k: root[k] for k in ['path', 'kind', 'sha256', 'physical_signature', 'noncontrolled_regime']},
            'root_reference_file_present': (R / root['path']).is_file(),
            'initial_all13_vm': root['all13_initial_vm'],
            'initial_control_Q_Mvar': root['initial_control_Q'],
            'initial_state_already_in_original_band': normal,
            'saved_initial_equation_model': None if model is None else {
                'path': model['directory'] + '/Current_Model.npz',
                'sha256': model['proof_hashes']['Current_Model.npz'],
                'fields': ['Y', 'V', 'pq', 'lookup', 'control', 'baseMVA', 'vm', 'q', 'J', 'rhs', 'response', 'S'],
                'reuse_scope': 'Read existing full-state and mapping evidence only; no reused LP action treated as a new nonlinear proposal.',
            },
        })
    assert all(e['root_reference_file_present'] for e in entries)
    put('All500_Nonlinear_Preparation_Input_Manifest.json', {
        'status': 'STATIC_ALL500_EXACT_ROOT_REFERENCE_BINDING_READY_NO_EQUATION_OR_SCIENTIFIC_CALLS',
        'root_source': {'path': root_source, 'sha256': sha(root_source)},
        'prior_model_source': {'path': primary_source, 'sha256': sha(primary_source)},
        'saved_graph_source': {'path': graph_source, 'sha256': sha(graph_source)},
        'count': 500,
        'source_order': list(range(500)),
        'saved_initial_model_count': len(first_models),
        'already_in_original_band_count': sum(e['initial_state_already_in_original_band'] for e in entries),
        'root_data_redownload_or_new_root_PF_needed': False,
        'all_old_cases_are_inspected_development_cases': True,
        'entries': entries,
    })
    put('Distinct_Mechanism_And_First_Measurement.json', {
        'status': 'CONCRETE_CPU_PREPARATION_SPEC_NOT_SCIENCE_LAUNCH_AUTHORIZATION',
        'mechanism': 'Nonlinear AC equality constrained voltage-feasibility restoration, replacing the local affine VM prediction within the proposal optimizer.',
        'causal_hypothesis': 'The saved affine boundary solution passes its own normal-bus constraints, while the returned nonlinear plant voltage violates them in all85; incorporating those nonlinear equations before proposal may prevent this specific mismatch. This is a testable mechanism, not a restoration guarantee.',
        'preserved': {
            'all_roots': 'All500 exact native roots in source order, outcomes never used by the executor to select cases or methods.',
            'actuators': 'Exactly native sgen rows0..2 at buses2/7/9; q_next=q_current-u; float32 native increments with abs(u)<=float32(0.3).',
            'noncontrolled_plant': 'Identical loads, real power, network, initializers and unactuated equipment.',
            'horizon': 100,
            'guard': 'Byte-identical original normal-band and non-increasing strict UV/OV-count guard; first rejection holds and stops. Epsilon scoring does not silently change this guard.',
            'objective': 'Retain lexicographic full13 minimax band-distance first and total absolute final Q second, including the original second-stage1e-10 allowance; change the state-equation model rather than tune Q or scoring.',
            'reporting': 'Report raw VM, original strict score, and uniformly authorized common1e-8 score. The old264/415 results remain historical numerical rows.',
        },
        'new_equation_spec': {
            'variables': 'Three native deltaQ values and all non-slack complex-voltage states; slack voltage fixed to the saved root/current state.',
            'equations': 'At all non-slack buses impose the exact source-compatible AC complex-power balance. Native deltaQ changes only the three admitted reactive injections. Bind bus order, signs, baseMVA, bus types, transformer/tap/shunt conventions and load model from the original saved network/PPC.',
            'constraints': 'Native increment box; minimax full13 voltage band; original-current normal-bus band constraints. Re-evaluate constraints on the final representable float32 proposal; never round/clip measured VM or repair an invalid candidate into success.',
            'solver_unknowns': 'Nonconvex solver/version, deterministic initialization, precision, tolerances, iteration/evaluation cap and timeout require a source-level implementation and prospective lock before execution. A local optimum or solver failure is not an AC infeasibility certificate.',
        },
        'first_admissible_cpu_work': [
            'Use All500_Nonlinear_Preparation_Input_Manifest.json to bind the483 nontrivial initial models and17 already-in-band roots. No downloads, GPU, new root solves or endpoint reselection are needed.',
            'Implement a source-compatible nonlinear residual/constraint module with explicit native injection signs and bus maps. Preserve the old controller source and import no old running campaign.',
            'Before any optimizer/PF call, freeze an engineering protocol for source-equation parity on saved solved states, representable-action admission, save/load continuity, attempted-input accounting and exact runtime/cost instrumentation. These parity evaluations would be NEW computational work and are not claimed performed here.',
            'Resolve all parity discrepancies as implementation defects without changing the controller objective/guard/action role or inspecting prospective performance. Then freeze one deterministic solver recipe and the all500 independent-reader protocol. No parameter/solver/seed search or allocation is licensed by this preparation.',
        ],
        'first_new_scientific_measurement_after_gates': {
            'population': 'A complete all500 episode campaign of that single newly frozen nonlinear controller, beginning from the saved exact initial roots; not a rescue from the85 held states.',
            'main_mechanism_readout': 'For every entered decision, log proposed nonlinear-state voltages, the final float32 action, exact returned physical voltages, normal-bus prediction error, original-guard acceptance and terminal raw/strict/common1e-8 outcomes.',
            'performance_readout': 'All500 full13 common1e-8 restoration with original strict results beside it, plus paired changes versus the fixed affine row and each unmodified native SafeDDPG, linear and DDPG row. Disclose original information advantages and all non-restored/unknown cases.',
            'strong_controls': 'Keep all three published native rows primary. Saved common-guard prefixes remain sensitivity. The current affine controller is the direct same-information numerical mechanism control; no published policy is weakened to manufacture advantage.',
            'stopping': 'Single locked campaign; no continuation after original first-rejection or fixed resource exhaustion, no solver retries after failure and no outcome retuning. Unknowns remain in the500 denominator. No newly-inspected case can be called unused confirmation.',
            'gates': 'Success requires auditable completed all500 outcomes, no guard/range/source violations, all costs, and the prospectively declared paired comparison. Any claim of500/500 requires500 verified returned endpoints; infeasibility, partial and unknown cannot count as restored.',
            'independent_reader': 'Validate newly returned physical inputs once under locked paid-history semantics, retain failed or unentered calls, independently check saved nonlinear equation/constraint residuals and state continuity. Read costs separately and additively.',
            'costs': 'Every new residual/equation evaluation, Jacobian/Hessian/linear solve, nonlinear optimizer iteration, PF attempt/return/failure, cache reuse, rejected/accepted/hold decision, setup/IO/wall time and peak memory; retained historical root/source/training/primary/reader failures remain additive. No intrinsic deployment speed claim from workflow time.',
        },
        'GPU_needed_for_this_next_work': False,
        'GPU_rationale': 'The immediate work is source/model correspondence and small13-bus numerical control preparation. It has no model-training or pretrained-forward operation; available T4 eligibility does not resolve any missing scientific gate.',
        'not_claimed': ['500/500 attainable under the retained guard', 'global AC feasibility or infeasibility', 'thermal/generator/security feasibility', 'causal LLM contribution', 'unused confirmation'],
    })
    llm_sources = [
        'outputs/native13_fullband_original_adapter_engineering_independent_20261021/Independent_Functional_Audit.json',
        'outputs/native13_adapter_disabled_diagnostic_independent_v2_20261021/Independent_Functional_Audit.json',
        'outputs/native13_fullband_original_adapter_engineering_execution_20261021/staged/study/primary_Loader_Proof.json',
        'outputs/original_lora_native13_transfer_completion_20261020/Verified_Completion_And_Stop_Decision.json',
    ]
    put('LLM_Contribution_Readiness_From_Inspected_Records.json', {
        'status': 'SAVED_SOURCE_GATES_DISTINGUISHED_FROM_UNESTABLISHED_FUTURE_NATIVE_ROLE',
        'source_hashes': {p: sha(p) for p in llm_sources},
        'already_established_not_missing': [
            'The inspected pinned public-base plus unchanged private-adapter loader succeeded:336 copied tensors,8,798,208 parameters,168 actual layers, source-value equality, disabled/enabled restoration.',
            'All six fullband engineering input sequences reproduced exactly in a fresh model load. Do not claim that the existing loader simply has never worked.',
            'Original500 physical root references, saved bus maps/currentVM/Q and Y evidence are available. Data access is not the immediate85-case blocker.',
        ],
        'failed_existing_gates_to_keep_stopped': [
            'The unchanged private adapter admitted0/6 strict JSON-or-null outputs in the signed fullband native role; no legal positive UV or negative OV action.',
            'The adapter-disabled paired control also admitted0/6. Neither supports usable native control or a causal adapter benefit. This does not establish universal LLM inability.',
            'The earlier native PI transfer admitted0/3 primary outputs; its exact intervention remains stopped.',
        ],
        'actual_future_data_state_loader_gates': [
            'Specify a materially new role and native signed-action training/input contract, with exact state/observation/action units, authorized actuator set, target derivation and candidate schema. A new source-matched training/validation corpus for that role is not established by these inspected records. Do not use outcome-selected85 cases as the main dataset/evaluation.',
            'Separate inspected development roots from genuinely unused confirmation before label generation/training. Any retained source500 test remains development/replication; protect target/source leakage and disclose all teacher and simulation costs.',
            'For any new model weights, pin the exact base/tokenizer/adapter revisions and compare actual tensor values, token IDs, attention masks, truncation and adapter enabled/disabled state. The historical SFT base revision is marked UNRECOVERED in the saved completion report; pinned-new-base reproducibility must not be presented as exact historical training reproduction.',
            'Admit raw native actions without posthoc repair, validate both action signs/actuator/range/abstention behavior under a frozen functional gate, then bind complete physical and model state:NET/PPC/Y,currentQ/VM,history,turn cursor,RNG,generation state,cache/attempt journals,remaining horizon and fixed deadline. Preserve before/after cold-state continuity.',
            'For causal contribution use a frozen paired intervention with the same information, action contract, nonlinear feasibility validator and resource accounting. Compare complete LLM system to the strong nonlinear numerical control and matched model-off/base or numeric proposal controls. Attribute only observed proposal/action/outcome differences beyond the common validator; record unchanged/rejected outputs too.',
        ],
        'GPU_gate': 'GPU use becomes justified only for a newly specified, source-certified model-forward/training measurement after the data/interface/control/state/loader/cost protocols are frozen. No GPU is needed for the completed85 taxonomy or immediate nonlinear CPU preparation.',
        'new_model_PF_optimizer_training_GPU_calls': 0,
    })
    print(json.dumps({'status': 'PREPARATION_WRITTEN', 'cases': len(entries), 'saved_initial_models': len(first_models), 'already_in_band': sum(e['initial_state_already_in_original_band'] for e in entries), 'new_science_calls': 0}))


if __name__ == '__main__':
    main()
