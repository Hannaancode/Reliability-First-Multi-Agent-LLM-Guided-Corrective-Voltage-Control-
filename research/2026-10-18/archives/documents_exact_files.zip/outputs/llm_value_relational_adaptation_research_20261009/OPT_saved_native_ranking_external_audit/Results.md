# Saved OPT action-ranking inventory

This is a descriptive development audit of the preserved old AC prior. It does not show a learned contribution or authorize a new model run.

All239 fixed OPT inputs/23worlds are retained:187 target states/30,510 measured actions and52 unlabelled inputs. Existing11,884 preference pairs are reused from the failed relational experiment.

K4 recorded-best inclusion: 74/176 oracle states; equal-world rate 0.403919. Miss coverage: {'states': 102, 'worlds': 21, 'families': ['DER_drop', 'N1_tieline', 'combined']}.

Prior preference scores: {'aligned': 8397, 'score_tied': 814, 'reversed': 2673}. Strictly reversed-pair coverage: {'states': 103, 'worlds': 22, 'families': ['DER_drop', 'N1_tieline', 'combined']}.

Saved current Y/V coverage: {'all_inputs': 193, 'target_states': 176, 'missing_inputs': 46}. Missing current arrays are genuinely missing numerical derivations, not permission to rerun any previous completed solve.

The next prerequisite is a prospective full native action-ranking control using the strong source-latched numerical method, with current-only inputs, complete unknown/failure denominators and all costs. Its stored single-action forecasts must be reused. A successful stronger prior could eliminate the apparent headroom identified here. No automatic GPU allocation, learning, new physical performance study, checkpoint selection or parameter sweep follows.

The original literal D-SE portfolio and complete both-branch costs remain the primary final comparator. Recorded best is conditional on sparse measured candidates; it is not an unmeasured-action optimum. Historical OPT/held/bank observations are development data.
