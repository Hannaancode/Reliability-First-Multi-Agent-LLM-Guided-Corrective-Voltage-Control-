"""Complete fresh-root shunt-component scope; zero solver/model calls.

Prior observations contain the static shunt table after each native solver.
The producer and a separately written reader equation must agree on EVERY
observed component. This is observed-input scope, not full native-case reuse.
"""
import hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
import pandas as pd
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
B=R/'outputs/fresh_observed_shunt_scope_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();base=R/'outputs/prior_physical_query_footprints_20261018'
    p=read(base/'Protocol.json');complete=read(base/'independent_audit/Independent_Audit.json')
    assert complete['status']=='PASS_ALL60426_TRACKED_PF_INPUT_COMPONENT_REFERENCES_AND_INDEPENDENT_ARITHMETIC'
    prior=read(R/'outputs/fresh_root_query_nonoverlap_20261018/Independent_Audit.json');path=R/'outputs/critical_research_reset_20261010/fresh_paid_receipt_opportunity_preparation_v1/execution/Actual_Observation_Journal.jsonl'
    put(B/'Protocol.json',{'role':'ALL3418_PRIOR_STATIC_OBSERVED_SHUNT_COMPONENTS_NO_NEW_PHYSICS','source_sha256':sha(__file__),'prior_journal':str(path.relative_to(R)),
        'prior_journal_sha256':prior['actual_prior_journal_sha256'],'targets':p['targets'],'bound_seconds':180,
        'producer_equation_source_sha256':sha(R/'work/prior_physical_query_footprints_20261018.py'),'independent_equation_source_sha256':sha(R/'work/audit_prior_physical_query_footprints_20261018.py'),
        'limits':'Static shunt table is observed after original PF; not a full native BEFORE-input reconstruction. No conclusion about controller-modified shunts or unseen history. No automatic new PF or performance authority.'})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    whole=hashlib.sha256();pending=None;count=0;components=set();hits={t['point_action_key']:[] for t in p['targets']}
    def frame(t):
        assert len(t['index'])==len(t['values']);return pd.DataFrame(t['values'],index=t['index'],columns=t['columns'])
    with path.open('rb') as f:
        for raw in f:
            assert time.perf_counter()-started<180,'Fixed scope bound; no extension'
            whole.update(raw);e=json.loads(raw)
            if e['event']=='solver_attempt':assert pending is None;pending=(e['identity'],e['phase'],e['arguments'])
            elif e['event']=='solver_closed':
                assert pending==(e['identity'],e['phase'],e['arguments']);pending=None
                assert e['exception'] is None and e['observation'] is not None
                tables=e['observation']['physical_tables'];net=SimpleNamespace(bus=frame(tables['bus']),shunt=frame(tables['shunt']))
                key,_=component(net);assert independent_component(net)==key;count+=1;components.add(key)
                for target in p['targets']:
                    if key==target['physical_component_sha256']:hits[target['point_action_key']].append({'identity':e['identity'],'phase':e['phase'],'line_sha256':hashlib.sha256(raw).hexdigest()})
    assert pending is None and count==3418 and whole.hexdigest()==prior['actual_prior_journal_sha256']
    put(B/'Results.json',{'status':'PASS_ALL3418_STATIC_OBSERVED_SHUNT_COMPONENTS_DUAL_EQUATIONS_AND_SOURCE_HASH','closed_observations':count,'unique_components':len(components),
        'target_match_counts':{k:len(v) for k,v in hits.items()},'target_matches':hits,'prior_journal_sha256':whole.hexdigest(),'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'coverage_limit':'Observed static shunt-component scope; complete prior native BEFORE equivalence is not inferred. Broader history/current verifier/persistent execution gates remain; no performance/LLM result.'})
    manifest(B);print(json.dumps({'fresh_observed_component_scope':'PASS','observations':count,'matches':{k:len(v) for k,v in hits.items()}}))
if __name__=='__main__':main()
