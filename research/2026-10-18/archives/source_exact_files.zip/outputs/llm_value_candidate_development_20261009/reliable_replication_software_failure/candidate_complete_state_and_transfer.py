"""Full AdamW/RNG checkpoint and acknowledged small-file preservation.

No allocation, model loading or scientific retry. Callers own the fixed study.
"""
from pathlib import Path
import hashlib, json, os, random, time, zipfile
import numpy as np
import torch

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def cpu_tree(value):
    if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:cpu_tree(v) for k,v in value.items()}
    if isinstance(value,list):return [cpu_tree(v) for v in value]
    if isinstance(value,tuple):return tuple(cpu_tree(v) for v in value)
    return value

def capture_rng():
    n=np.random.get_state()
    return {'python':random.getstate(),'numpy':{'kind':n[0],'keys':torch.from_numpy(n[1].astype(np.int64)),
      'position':n[2],'has_gauss':n[3],'cached_gaussian':n[4]},'torch_CPU':torch.get_rng_state(),
      'torch_CUDA':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}

def restore_rng(state):
    random.setstate(state['python']);n=state['numpy']
    np.random.set_state((n['kind'],n['keys'].numpy().astype(np.uint32),n['position'],n['has_gauss'],n['cached_gaussian']))
    torch.set_rng_state(state['torch_CPU'])
    if state['torch_CUDA']:
        assert torch.cuda.is_available() and len(state['torch_CUDA'])==torch.cuda.device_count()
        torch.cuda.set_rng_state_all(state['torch_CUDA'])

def full_checkpoint(common,copied_adapter,optimizer,group_parameter_names,cursor,contract):
    assert len(group_parameter_names)==len(optimizer.param_groups)
    assert all(len(n)==len(g['params']) for n,g in zip(group_parameter_names,optimizer.param_groups))
    return {'common':cpu_tree(common),'copied_adapter':cpu_tree(copied_adapter),
      'optimizer':cpu_tree(optimizer.state_dict()),'optimizer_group_parameter_names':group_parameter_names,
      'rng':capture_rng(),'cursor':cursor,'contract':contract}

def verify_complete_checkpoint(checkpoint,expected_contract,expected_steps):
    assert set(checkpoint)=={'common','copied_adapter','optimizer','optimizer_group_parameter_names','rng','cursor','contract'}
    assert checkpoint['contract']==expected_contract and checkpoint['cursor']['completed_optimizer_steps']==expected_steps
    assert checkpoint['cursor']['next_epoch']==expected_steps//187+1 and checkpoint['cursor']['next_epoch_offset']==expected_steps%187
    opt=checkpoint['optimizer'];names=checkpoint['optimizer_group_parameter_names']
    assert len(names)==len(opt['param_groups']) and all(len(n)==len(g['params']) for n,g in zip(names,opt['param_groups']))
    indexes=[i for g in opt['param_groups'] for i in g['params']]
    if expected_steps:
        assert set(opt['state'])==set(indexes)
        for value in opt['state'].values():
            assert set(value)=={'step','exp_avg','exp_avg_sq'}
            assert int(value['step'])==expected_steps and bool(torch.isfinite(value['exp_avg']).all()) and bool(torch.isfinite(value['exp_avg_sq']).all())
    return True

def safe_relative(name):
    p=Path(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
    return p

def make_package(package_root,number,files,journal,identity):
    package_root=Path(package_root);folder=package_root/f'package_{number:03d}'
    folder.mkdir(parents=True,exist_ok=False)
    prefix=journal.read_bytes();assert prefix.endswith(b'\n')
    prefix_path=folder/'journal_prefix.jsonl';prefix_path.write_bytes(prefix)
    members={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
    assert all(safe_relative(n) for n in members)
    archive=folder/'artifact_package.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,p in files.items():z.write(p,n)
        z.write(prefix_path,'journal_prefix.jsonl')
    parts=[]
    with archive.open('rb') as f:
        while raw:=f.read(2*1024*1024):
            name=f'part_{len(parts):04d}.bin';p=folder/name;p.write_bytes(raw)
            parts.append({'name':name,'bytes':len(raw),'sha256':sha(p)})
    descriptor={'number':number,'identity':identity,'members':members,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
      'journal_prefix_bytes':len(prefix),'journal_prefix_sha256':hashlib.sha256(prefix).hexdigest(),'parts':parts}
    path=folder/'descriptor.json'
    with path.open('x') as f:json.dump(descriptor,f,indent=2);f.flush();os.fsync(f.fileno())
    return folder,descriptor

def expected_ack(descriptor):
    return {'number':descriptor['number'],'identity':descriptor['identity'],'archive_sha256':descriptor['archive_sha256'],
      'journal_prefix_sha256':descriptor['journal_prefix_sha256'],'all_files_and_full_state_verified_locally':True}

def wait_for_ack(folder,descriptor,bound_seconds=300):
    began=time.monotonic();p=folder/'ack.json'
    while time.monotonic()-began<bound_seconds:
        if p.exists():
            assert json.loads(p.read_text())==expected_ack(descriptor),'Wrong or stale preservation acknowledgement'
            return time.monotonic()-began
        time.sleep(.5)
    raise TimeoutError('No verified local preservation acknowledgement; stop before more model calls')

def validate_package(archive,descriptor):
    assert Path(archive).stat().st_size==descriptor['archive_bytes'] and sha(archive)==descriptor['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(set(z.namelist())) and z.testzip() is None
        assert set(z.namelist())==set(descriptor['members'])|{'journal_prefix.jsonl'}
        for name,m in descriptor['members'].items():
            safe_relative(name);b=z.read(name);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
        raw=z.read('journal_prefix.jsonl')
        assert len(raw)==descriptor['journal_prefix_bytes'] and hashlib.sha256(raw).hexdigest()==descriptor['journal_prefix_sha256']
        assert raw.endswith(b'\n')
    return True
