"""TRAIN-only information/label support audit, with no neural or physics calls."""
import hashlib
import json
import math
import os
import time
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended

OUT = extended(ROOT / 'outputs/critical_research_reset_20261010/original_TRAIN_causal_label_support')
DESKTOP = Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm')
MEMBER = 'hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'

def canonical(value):
    """Preserve exact parsed float values and distinguish missing/null/boolean."""
    if isinstance(value, bool): return ['bool', value]
    if value is None: return ['null']
    if isinstance(value, (int,float)):
        assert math.isfinite(value)
        numerator, denominator = value.as_integer_ratio()
        return ['number', str(numerator), str(denominator)]
    if isinstance(value,str): return ['string',value]
    if isinstance(value,list): return ['list', [canonical(x) for x in value]]
    assert isinstance(value,dict)
    return ['object', [[k,canonical(value[k])] for k in sorted(value)]]

def digest(value):
    return hashlib.sha256(json.dumps(canonical(value),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def run():
    assert not OUT.exists()
    OUT.mkdir(); start=time.perf_counter()
    write(OUT/'audit.claim',{'actual_pid':os.getpid(),'source_sha256':sha(Path(__file__)),'at_utc':datetime.now(timezone.utc).isoformat()})
    protocol={
        'declared_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'All16000 original TRAIN rows only; no validation/test outcomes',
        'primary_projection':'zone and ALL original local_measurements; exclude scenario_id/type/severity and linguistic instructions',
        'secondary_projection':'zone and bus_voltages only; deliberately less information, not current deployed global prompt',
        'target':'Exact proposed_action JSON, including null. Coordinator candidate and verifier fields counted separately.',
        'numeric_canonicalization':'Exact parsed integer ratios; no rounding, binning, zero imputation or physical precision change',
        'conflict_bound':'Sum largest action-label frequency in each equal-input group divided by16000; empirical row-weighted deterministic exact-teacher-match ceiling only',
        'not_physical_success_or_generalization_bound':True,
        'positive_gate':'No automatic pilot; absence of conflicts does not prove learnability, capacity adequacy or useful proposals',
        'negative_gate':'Conflicting exact labels disprove deterministic zero teacher error only for the stated information projection; no universal LLM rejection',
        'no_new_model_optimizer_PF_forecast_controller_cloud_calls':True,
        'all_original_rows_groups_and_ambiguous_cases_retained':True,
    }
    write(OUT/'Prospective_TRAIN_Information_Protocol.json',protocol)
    certificate=read(ROOT/'outputs/critical_research_reset_20261010/original_desktop_pipeline_alignment/Original_Training_Model_and_Contract_Reconciliation.json')
    with zipfile.ZipFile(DESKTOP/'phase2b_training_inputs.zip') as archive: raw=archive.read(MEMBER)
    input_sha=hashlib.sha256(raw).hexdigest()
    assert certificate['source_members']['phase2b_training_inputs.zip::'+MEMBER]['sha256']==input_sha
    groups={n:defaultdict(Counter) for n in ('full_current_local_information','voltage_only_information')}
    group_worlds={n:defaultdict(set) for n in groups}
    records=[]; worlds=Counter(); counts=Counter(); types=Counter(); evidence_keys=Counter()
    for index,line in enumerate(raw.decode('utf8').splitlines()):
        item=json.loads(line); messages=item['messages']
        users=[m for m in messages if m['role']=='user']; assert len(users)==1 and messages[-1]['role']=='assistant'
        observation=json.loads(users[0]['content']); target=json.loads(messages[-1]['content'])
        local=observation['local_measurements']; zone=observation['zone']; world=str(observation['scenario_id'])
        world_hash=hashlib.sha256(world.encode()).hexdigest(); worlds[world_hash]+=1
        action=target['proposed_action']; action_hash=digest(action)
        verification=target.get('verification'); assert isinstance(verification,dict)
        evidence_keys.update(verification.keys())
        types[verification.get('verdict','MISSING')]+=1
        counts['nonnull_proposed_action' if action is not None else 'null_proposed_action']+=1
        counts['coordinator_candidate_present' if target.get('candidate_action_for_coordinator') is not None else 'coordinator_candidate_null_or_missing']+=1
        counts['old_global_metrics_present' if isinstance(verification.get('old_global'),dict) else 'old_global_metrics_absent']+=1
        counts['new_global_metrics_present' if isinstance(verification.get('new_global'),dict) else 'new_global_metrics_absent']+=1
        counts['selected_trial_present' if isinstance(verification.get('selected_trial'),dict) else 'selected_trial_absent']+=1
        counts['top_level_verifier_convergence_boolean_present' if isinstance(verification.get('converged'),bool) else 'top_level_verifier_convergence_boolean_absent']+=1
        if action is not None:
            assert isinstance(action,dict)
            shunts=action.get('add_shunts_q_mvar')
            if isinstance(shunts,dict):
                counts['shunt_action_schema']+=1
                counts['shunt_buses_in_local_observed_scope' if all(str(bus) in local['bus_voltages'] for bus in shunts) else 'shunt_bus_outside_local_observed_scope']+=1
                counts['all_shunt_Q_positive_finite' if all(isinstance(q,(int,float)) and not isinstance(q,bool) and math.isfinite(q) and q>0 for q in shunts.values()) else 'nonpositive_or_nonfinite_shunt_Q']+=1
            else: counts['other_action_schema']+=1
        projection_values={
            'full_current_local_information':{'zone':zone,'local_measurements':local},
            'voltage_only_information':{'zone':zone,'bus_voltages':local['bus_voltages']},
        }
        row={'TRAIN_row_index':index,'world_sha256':world_hash,'target_proposed_action_sha256':action_hash,'projections':{}}
        for name,value in projection_values.items():
            key=digest(value); groups[name][key][action_hash]+=1; group_worlds[name][key].add(world_hash)
            row['projections'][name]=key
        records.append(row)
    assert len(records)==16000 and len(worlds)==109
    summaries={}; classes={}
    for name,group in groups.items():
        classes[name]=[{ 'current_input_sha256':key,'rows':sum(frequencies.values()),
            'distinct_world_groups':len(group_worlds[name][key]),'exact_action_counts':dict(frequencies),
            'exact_label_ambiguous':len(frequencies)>1} for key,frequencies in sorted(group.items())]
        n_ambiguous=sum(len(c)>1 for c in group.values())
        largest_sum=sum(max(c.values()) for c in group.values())
        summaries[name]={
            'distinct_current_observations':len(group),'ambiguous_exact_action_classes':n_ambiguous,
            'TRAIN_rows_in_ambiguous_classes':sum(sum(c.values()) for c in group.values() if len(c)>1),
            'row_weighted_deterministic_exact_teacher_action_upper_fraction':largest_sum/16000,
            'minimum_row_weighted_exact_teacher_errors_under_projection':16000-largest_sum,
            'cross_world_same_current_input_classes':sum(len(v)>1 for v in group_worlds[name].values()),
            'not_a_physical_or_held_generalization_metric':True,
        }
    summary={
        'at_utc':datetime.now(timezone.utc).isoformat(),'all16000_TRAIN_rows_retained':True,
        'exact_original_TRAIN_member_sha256':input_sha,'original_TRAIN_world_groups':len(worlds),
        'input_action_information':summaries,'label_and_evidence_structure_counts':dict(counts),
        'verdict_counts':dict(types),'verifier_key_counts':dict(evidence_keys),
        'original_pipeline_and_saved_eval_not_rerun':True,
        'teacher_embedded_metrics_are_not_independent_solver_certificates':True,
        'missing_top_level_convergence_not_claimed_nonconvergence':True,
        'old_global_new_global_selected_trial_contents_not_verified_against_fresh_PF':True,
        'no_measurement_of_causal_generalization_or_LLMSuperiority':True,
        'actual_neural_optimizer_PF_forecast_controller_cloud_calls':0,
        'workflow_seconds_before_frozen_checks_and_seal':time.perf_counter()-start,
        'automatic_learning_or_GPU_launch':False,
    }
    write(OUT/'All16000_TRAIN_Identity_and_Projection_Records.json',records)
    write(OUT/'Exact_Current_Input_Action_Equivalence_Classes.json',classes)
    write(OUT/'Original_TRAIN_Causal_Label_Support.json',summary)
    write(OUT/'Fresh_Frozen_Asset_Checks.json',frozen_checks())
    files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='audit.claim'}
    files['sources/reader.py']=Path(__file__)
    archive=seal(OUT,files,'TRAIN_Label_Support.zip')
    print(json.dumps({'summary':summary,'archive':archive}))

if __name__=='__main__':run()
