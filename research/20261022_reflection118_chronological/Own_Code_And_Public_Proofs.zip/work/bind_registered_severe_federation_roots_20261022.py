"""Bind four registered severe118 cases to already paid solved NETs.

This recovers current benchmark inputs, not historical137 trajectory identity.
Original failed/partial jobs and costs stay retained; no initial PF is rerun.
"""
import copy, hashlib, json, os, pickle, sys, time, zlib
from datetime import datetime, timezone
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/registered_severe_federation_root_binding_20261022'
B = R / 'outputs/critical_research_reset_20261010'
SOURCES = [B / 'severe_joint_current_engineering_20261012/actual/scientific.jsonl',
           B / 'severe_joint_current_engineering_continuation_v2_20261012/actual/scientific.jsonl']
CASES = ['fed_combined_load_1p5_line_35_MG1', 'fed_combined_load_1p5_line_36_MG1',
         'fed_combined_load_1p5_line_84_MG2', 'fed_combined_load_1p5_line_127_MG3']
def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(folder, name, value):
    with (folder / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False); f.flush(); os.fsync(f.fileno())

def runtime():
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandas as pd, pandapower as pp
    def forbidden(*a, **k): raise BaseException('No physics/model in exact root binding')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, forbidden)
    return pd, pp

def payload(directory, d):
    p = directory / d['path']; raw = p.read_bytes()
    assert len(raw) == d['encoded_bytes'] and hashlib.sha256(raw).hexdigest() == d['encoded_sha256']
    b = zlib.decompress(raw)
    assert len(b) == d['raw_bytes'] and hashlib.sha256(b).hexdigest() == d['raw_sha256']
    return pickle.loads(b), b

def exact_frames(pd, a, b):
    frames = {k for k, v in a.items() if isinstance(v, pd.DataFrame) and not str(k).startswith('res_')}
    assert frames == {k for k, v in b.items() if isinstance(v, pd.DataFrame) and not str(k).startswith('res_')}
    for k in frames: pd.testing.assert_frame_equal(a[k], b[k], check_exact=True, check_dtype=True)
    return len(frames)

def produce():
    O.mkdir(exist_ok=False); started = time.perf_counter(); pd, pp = runtime()
    import numpy as np
    from frozen_physics_loader import load_stack, AUDIT
    v2, runner, _ = load_stack(); assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    registry_path = R / 'outputs/full_system_comparison_20261021/All203_Existing_Federation_Input_Cases.json'
    registry = read(registry_path)
    certificates = [B / 'severe_joint_current_engineering_20261012/partial_cold_reader_v2/Cold_Partial_Analysis.json',
                    B / 'severe_joint_current_engineering_continuation_v2_20261012/cold_reader/Cold_Reader_Result.json']
    assert all(read(p)['status'].startswith('PASS_') for p in certificates)
    network = R / 'work/e/pack/testbeds/federation_4mg_ieee118.json'
    metadata = R / 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
    write(O, 'Protocol.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
        'source_sha256': sha(Path(__file__)), 'fixed_seconds': 180,
        'case_order': CASES, 'selection': 'All four old fixed severe cases, registered in FED141; not selected from new model/external outcomes',
        'registry_sha256': sha(registry_path), 'network_sha256': sha(network), 'metadata_sha256': sha(metadata),
        'old_journals': {p.relative_to(R).as_posix(): sha(p) for p in SOURCES},
        'old_saved_prefix_certificates': {p.relative_to(R).as_posix(): sha(p) for p in certificates},
        'source_settings': 'Unchanged original recipe application/initial NR auto enforceQ max50; source+all physical frames+all118returnedfields checked.',
        'historical_identity_limit': 'These are source-bound paid12October initializations, not a claim of bit-identical lost original paper runtime. Existing root physical return reused; no root PF repetition.',
        'old_failure': 'First donor-exact current replay owner exit1/partial retained; only its valid saved initial return is used.',
        'new_scientific_calls': 0})
    write(O, 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(Path(__file__))})
    base = pp.from_json(str(network)); zones = read(metadata)['zones']; result = []
    for path in SOURCES:
        closed = read(path.parent / 'Closed_Manifest.json')['members']; assert sha(path) == closed['scientific.jsonl']['sha256']
        pending = {}
        for raw in path.open('rb'):
            e = json.loads(raw); d = e.get('data', {})
            if e['event'] == 'PF_intent' and d.get('role') == 'initial': pending[d['id']] = d
            elif e['event'] == 'PF_return' and d.get('id') in pending:
                intent = pending.pop(d['id']); case = intent['world']; assert case in CASES
                reg = [x for x in registry if x['cohort'] == 'FED141_DEVELOPMENT' and x['case_id'] == case]
                assert len(reg) == 1; reg = reg[0]; recipe = R / reg['recipe']; assert sha(recipe) == reg['recipe_sha256']
                a, _ = payload(path.parent, intent['before']); b, decoded = payload(path.parent, d['after'])
                before, after = a['net'], b['net']; expected = v2.v0.apply_scenario_to_net(copy.deepcopy(base), read(recipe), zones)
                n = exact_frames(pd, before, expected); exact_frames(pd, before, after)
                assert intent['kwargs'] == {'algorithm': 'nr', 'init': 'auto', 'enforce_q_lims': True, 'max_iteration': 50}
                assert len(after.bus) == len(after.res_bus) == 118 and after.converged is True
                fields = after.res_bus[['vm_pu', 'va_degree', 'p_mw', 'q_mvar']]
                assert np.isfinite(fields.to_numpy()).all()
                assert {str(int(i)): {k: float(v) for k, v in row.items()} for i, row in fields.iterrows()} == d['fields']
                assert all(not str(n).startswith('llm_shunt') for n in after.shunt['name'])
                out = O / (case + '.pkl'); out.write_bytes(decoded)
                result.append({'case_id': case, 'registration': reg, 'solved_payload': out.relative_to(R).as_posix(),
                    'payload_bytes': len(decoded), 'payload_sha256': hashlib.sha256(decoded).hexdigest(),
                    'source_journal': path.relative_to(R).as_posix(), 'source_initial_intent': intent,
                    'source_return': {k: v for k, v in d.items() if k != 'fields'},
                    'source_return_line_sha256': hashlib.sha256(raw).hexdigest(),
                    'all_non_result_frames_exact': n, 'all118_fields_finite_exact_source_return': True,
                    'initial_metrics': runner.rescue.grid_metrics(after), 'solver_kwargs': intent['kwargs'],
                    'prior_initial_PF_seconds_remain_paid': d.get('seconds', d.get('elapsed_seconds', 'UNKNOWN_NOT_FREE')),
                    'new_initial_PF_calls': 0, 'historical_paper_full_trajectory_identity': 'UNKNOWN_NOT_RECOVERED_BY_THIS_BINDING'})
        assert not pending
    result.sort(key=lambda x: CASES.index(x['case_id'])); assert [x['case_id'] for x in result] == CASES
    write(O, 'All4_Registered_Solved_Root_Bindings.json', result)
    write(O, 'Result.json', {'status': 'PASS_FOUR_REGISTERED_SEVERE118_CURRENT_ROOT_BINDINGS_REQUIRE_READER',
        'cases': CASES, 'initial_UV': [x['initial_metrics']['uv_count'] for x in result],
        'initial_strict_OV': [x['initial_metrics']['ov_count'] for x in result],
        'all203_registration_closure': '4FED141_BOUND_OTHER199_PENDING', 'new_PF_model_calls': 0,
        'pure_network_decodes': 1, 'pure_recipe_applications': 4, 'workflow_seconds': time.perf_counter() - started})
    write(O, 'Closed_Manifest.json', {'members': {p.name: sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps(read(O / 'Result.json')))

def audit():
    A = O / 'independent_audit'; A.mkdir(exist_ok=False); started = time.perf_counter(); pd, pp = runtime()
    from audit_spatial_allocation_inputs_v2_20261011 import independent_apply
    from frozen_physics_loader import load_stack
    _, runner, _ = load_stack(); p = read(O / 'Protocol.json')
    assert sha(Path(__file__)) == p['source_sha256']
    assert all(sha(O / n) == h for n, h in read(O / 'Closed_Manifest.json')['members'].items())
    assert all(sha(R / n) == h for n, h in p['old_saved_prefix_certificates'].items())
    rows = read(O / 'All4_Registered_Solved_Root_Bindings.json')
    base = pp.from_json(str(R / 'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones = read(R / 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    for row in rows:
        data = (R / row['solved_payload']).read_bytes(); assert hashlib.sha256(data).hexdigest() == row['payload_sha256']
        net = pickle.loads(data)['net']; scenario = read(R / row['registration']['recipe'])
        expected = independent_apply(base, scenario.get('modifications', []), zones)
        assert exact_frames(pd, net, expected) == row['all_non_result_frames_exact']
        assert runner.rescue.grid_metrics(net) == row['initial_metrics']
        path = R / row['source_journal']; assert sha(path) == p['old_journals'][row['source_journal']]
        witness = [raw for raw in path.open('rb') if hashlib.sha256(raw).hexdigest() == row['source_return_line_sha256']]
        assert len(witness) == 1 and json.loads(witness[0])['data']['after'] == row['source_return']['after']
    result = {'status': 'PASS_INDEPENDENT_FOUR_REGISTERED_ROOT_RECIPE_INPUT_RETURN_BINDINGS',
        'case_order': CASES, 'initial_UV': [r['initial_metrics']['uv_count'] for r in rows],
        'all203_root_bindings': '4BOUND_199PENDING', 'native_band': 'Strict0.95/1.05counts retained; no boundary rounding.',
        'new_PF_model_calls': 0, 'pure_network_decodes': 1, 'pure_recipe_applications': 4,
        'not_full_method_or_historical137_trajectory_proof': True, 'workflow_seconds': time.perf_counter() - started}
    write(A, 'Independent_Audit.json', result)
    write(A, 'Closed_Manifest.json', {'members': {'Independent_Audit.json': sha(A / 'Independent_Audit.json')}})
    print(json.dumps(result))

if __name__ == '__main__': audit() if '--reader' in sys.argv else produce()
