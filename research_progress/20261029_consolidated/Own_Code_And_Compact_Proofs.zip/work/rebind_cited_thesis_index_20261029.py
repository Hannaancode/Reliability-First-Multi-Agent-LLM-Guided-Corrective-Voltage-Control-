from pathlib import Path
from datetime import datetime, timezone
import json,hashlib
R=Path(__file__).resolve().parents[1]
S=R/'outputs/thesis_current_comparison_20261029'
O=R/'outputs/thesis_citations_integrated_20261029'
record=json.loads((O/'Citation_Integration_Record.json').read_text(encoding='utf-8'))
doc=R/record['current'];old=R/record['base']
j=json.loads((S/'Thesis_Evidence_Navigation.json').read_text(encoding='utf-8'))
assert Path(j['current_docx'])==Path(record['base']) and j['docx_sha256']==record['base_sha256']
assert record['table_citation_changes']==[]
j.update(at_utc=datetime.now(timezone.utc).isoformat(),current_docx=record['current'],docx_sha256=hashlib.sha256(doc.read_bytes()).hexdigest(),
 citation_reconciliation='outputs/thesis_citation_reconciliation_20261029/citation_reconciliation.json',reference_count=71,
 page_status='User will compile. New revision pagination unverified; all57 local automatic page fields retained.',
 inherited_unchanged_table_figure_binding_check='outputs/thesis_current_comparison_20261029/Independent_Content_Fields_And_Index_Check.json')
with (O/'Thesis_Evidence_Navigation.json').open('x',encoding='utf-8') as f:json.dump(j,f,indent=2,ensure_ascii=False)
h=(S/'Evidence_Index.html').read_text(encoding='utf-8');assert old.as_uri() in h
h=h.replace(old.as_uri(),doc.as_uri());assert 'page None' not in h
with (O/'Evidence_Index.html').open('x',encoding='utf-8') as f:f.write(h)
print(json.dumps(dict(status='INDEX_REBOUND_TO_CITATION_DOCX',tables=len(j['tables']),figures=len(j['figures']),references=71)))
