"""All old primary intent references, never repeat science to recover evidence.

Supports a separately prospective per-use independent receipt verifier. Does
not pass the old partial full-policy gate or certify physical outcomes itself.
"""
import gzip,hashlib,json,os,time
from pathlib import Path
from full_receding_paid_campaign_20261015 import read,put,sha,R,B as OLD,pin
B=R/'outputs/primary_input_reference_index_20261018'
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();p=read(OLD/'Protocol.json');pin(p)
    protocol=sha(OLD/'Protocol.json');manifest=read(OLD/'actual/Closed_Manifest.json')['members']['scientific.jsonl']
    put(B/'Protocol.json',{'role':'ALL_PRIMARY_INTENT_SOURCE_BYTE_REFERENCES_FOR_FUTURE_PERUSE_PHYSICAL_AUDIT',
        'source_sha256':sha(Path(__file__)),'analysis_bound_seconds':300,'scientific_journal_sha256':manifest['sha256'],
        'source_protocol_sha256':protocol,'selection':'Every source NEW_PRIMARY_QUERY attempt and closed query, no outcome/world subset.',
        'new_scientific_calls':0,'old_full_policy_gate':'UNKNOWN_UNCHANGED',
        'future_requirement':'Before any old receipt execution reuse, independently reconstruct current source/action input and saved-result verifier with zeroPF; durable exact keyed verification ACK. Unknown keys are not execution permission.'})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    front=R/'outputs/paid_lineage_frontier_20261018';fp=read(front/'Protocol.json');raw=(front/'All_Lineage_Attempt_Keys.json.gz').read_bytes()
    assert digest(raw)==read(front/'Results.json')['frontier_sha256']
    assert read(front/'audit/Independent_Frontier_Audit.json')['status']=='PASS_ALL_LINEAGE_ATTEMPT_KEYS_AND_EXACT_SOURCE_RECEIPT_REFERENCES'
    frontier=json.loads(gzip.decompress(raw));assert fp['journal_sha256']==manifest['sha256']
    intents={};closed={};entries={};previous='0'*64;offset=0;whole=hashlib.sha256()
    with (OLD/'actual/scientific.jsonl').open('rb') as f:
        for line in f:
            assert time.perf_counter()-started<300,'Fixed metadata reader bound, no extension'
            e=json.loads(line);assert e['previous_sha256']==previous and e['protocol_sha256']==protocol
            d=e['data'];kind=e['event']
            if kind=='PF_intent' and d['context']['phase']=='NEW_PRIMARY_QUERY':
                key=d['context']['point']+'|'+d['context']['action_key'];pid=d['identity']
                assert pid not in intents and frontier[key]['PF_id']==pid and d['kwargs']==p['solver_kwargs']
                intents[pid]={'key':key,'intent':d,'intent_reference':{'offset':offset,'bytes':len(line),'sha256':digest(line)}}
            elif kind in ['PF_return','PF_exception'] and d['PF_id'] in intents:
                assert d['PF_id'] not in closed;closed[d['PF_id']]=digest(canonical(d))
            elif kind=='every_query_receipt_closed_before_more_science' and d['record'].get('actual_measured_receipt'):
                m=d['record']['actual_measured_receipt'];pid=m['PF_id'];item=intents[pid];key=item['key'];entry=frontier[key]
                assert digest(canonical(m))==closed[pid]==entry['PF_close_data_sha256']
                assert d['aid']==item['intent']['context']['action_key'] and d['row']==item['intent']['context']['candidate']
                if key not in entries:
                    assert offset==entry['journal_offset'] and len(line)==entry['journal_bytes'] and digest(line)==entry['journal_line_sha256']
                    entries[key]={**item,'record_reference':entry,'before_capsule':item['intent']['before'],
                        'source_protocol_sha256':protocol,'source_journal_sha256':manifest['sha256'],
                        'physical_verification_status':'NOT_YET_PERUSE_VERIFIED_NO_EXECUTION_PERMISSION'}
            previous=digest(line.rstrip(b'\n'));whole.update(line);offset+=len(line)
    assert whole.hexdigest()==manifest['sha256'] and offset==manifest['bytes']
    expected={k for k,v in frontier.items() if v['classification']=='RECORDED_CLOSED_RECEIPT_REQUIRES_INDEPENDENT_SOURCE_RESULT_CHECK'}
    assert set(entries)==expected and len(entries)==len(intents)==len(closed)==37656
    dest=B/'All_Primary_Input_References.json.gz'
    with gzip.open(dest,'wb') as f:f.write(canonical(entries))
    assert json.loads(gzip.decompress(dest.read_bytes()))==entries
    put(B/'Results.json',{'status':'PASS_ALL37656_SOURCE_PRIMARY_INPUT_OUTPUT_REFERENCE_CLOSURE','keys':len(entries),
        'index_bytes':dest.stat().st_size,'index_sha256':sha(dest),'scientific_journal_sha256':whole.hexdigest(),
        'new_model_PF_optimizer_derivative_forecast_factor_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Source/identity/byte-reference metadata only. Old full-policy audit remains incomplete; no physical receipt or new execution permission follows. Future per-use verifier must retain source/native guard/scope/score/cost checks and a durable ACK.'})
    put(B/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()},'new_science':0})
    print(json.dumps({'primary_input_reference_index':'PASS','keys':len(entries),'new_science':0}))
if __name__=='__main__':main()
