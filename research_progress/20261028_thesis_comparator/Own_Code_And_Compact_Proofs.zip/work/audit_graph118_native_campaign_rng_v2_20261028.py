"""First independent new-return replay and continuous native-policy audit."""
from graph118_native_campaign_core_20261028 import *
A=R/'outputs/graph118_native_campaign_independent_rng_v2_20261028'
repair=read(R/'outputs/graph118_reader_rng_binding_v2_preparation_20261028/Protocol.json')
assert sha(__file__)==repair['new_reader_sha256']

def main():
    began=time.monotonic();owner(A,began);p=read(P/'Protocol.json');pins(p)
    end=read(E/'End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended'];check_manifest(E)
    np,pp=setup()
    from published_graph118_episode_engine_v2_20261026 import NativeGraphEpisode
    from exact_graph_cursor_compare_20261023 import require_same
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    from public_size_u61_preservation import journal
    from prepare_graph118_current_history_gate_20261028 import independent_controls
    primary=read(E/'Result.json');cursors=read(OLD/'Saved_Transition_And_Cursor_Readiness.json')['rows']
    history=History(p,A/'native_identity');rows=[];replays=0;replay_attempts=0;replay_seconds=0.;maximum=0.;kclmax=0.;decisions=0;derived=0
    previous='0'*64
    for line in (E/'events.jsonl').read_text('utf-8').splitlines():
        ev=json.loads(line);assert ev['event']['previous']==previous and hashlib.sha256(canonical(ev['event'])).hexdigest()==ev['sha256'];previous=ev['sha256']
    assert previous==primary['journal_last_sha256']
    def bound():
        if time.monotonic()-began>=p['reader_seconds']:raise StopBeforeEntry('FIXED_READER_BOUND_NO_RESTART')
    try:
        for i,case in enumerate(primary['cases']):
            assert case['case_id']==p['case_ids'][i]==cursors[i]['case_id']
            d=A/f'case_{i:02d}';d.mkdir();episode=NativeGraphEpisode.restore(d,decode(OLD,cursors[i]['cursor']))
            # Old paid first-action cursors predate RNG preservation. Bind the
            # actual primary case-entry RNG, while requiring every other old
            # cursor field to match. All later full RNG checks stay unchanged.
            import random
            first_path=E/case['calls'][0]
            first_saved=decode(first_path.parent,read(first_path)['pre_state'])['episode']
            initial=episode.snapshot()
            for key in ['python_rng','numpy_rng']:initial[key]=copy.deepcopy(first_saved[key])
            require_same(initial,first_saved,'ORIGINAL_CURSOR_ALL_NON_RNG_FIELDS')
            random.setstate(first_saved['python_rng']);np.random.set_state(first_saved['numpy_rng'])
            for name in case['calls']:
                bound();path=E/name;rec=read(path);saved=decode(path.parent,rec['pre_state'])
                assert saved['absolute_budget_seconds']==p['science_seconds'] and saved['registry_sha256']==p['input_hashes'][p['registry']]
                require_same(episode.snapshot(),saved['episode'],'CONTINUOUS_PRE_STATE')
                intent=episode.next_intent();decisions+=1;assert intent['action']==rec['action'] and intent['decoded']==rec['decoded'] and intent['prior_count']==rec['number']
                before=decode(path.parent,rec['before']);require_same(intent['before'],before,'EXACT_QUERY_INPUT');assert controls(before)==independent_controls(before)
                require_same(episode.snapshot(),decode(path.parent,rec['pending']),'CONTINUOUS_PENDING')
                mapped,scope=history.lookup(before,p['solver_kwargs']);assert scope['kind']==rec['scope']['kind']
                after=decode(path.parent,rec['after']);frames_equal(before,after)
                if mapped is not None:
                    derived+=1;require_same(mapped,after,'INDEPENDENT_NATIVE_IDENTITY_MAPPING')
                    assert rec['exception'] is None and rec['seconds']==0.
                elif rec['exception'] is None:
                    replay_attempts+=1;journal(A/'Replay_Attempts.jsonl',dict(number=replay_attempts,record=name,before=rec['before'],first_replay_only=True))
                    tick=time.perf_counter();pp.runpp(before,**p['solver_kwargs']);seconds=time.perf_counter()-tick;replay_seconds+=seconds;replays+=1
                    assert before.converged and after.converged;delta=0.
                    for table in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
                        x=before[table].select_dtypes(include=[np.number]).to_numpy(float);y=after[table].select_dtypes(include=[np.number]).to_numpy(float)
                        assert x.shape==y.shape and np.array_equal(np.isnan(x),np.isnan(y)) and np.allclose(x,y,atol=1e-10,rtol=0,equal_nan=True)
                        m=np.isfinite(x)&np.isfinite(y);delta=max(delta,float(np.max(abs(x[m]-y[m]),initial=0)))
                    q=before._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0];V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]))
                    kcl=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
                    maximum=max(maximum,delta);kclmax=max(kclmax,kcl)
                    put(d/f"replay_{rec['number']:03d}.json",dict(source_record=name,seconds=seconds,max_field_delta=delta,KCL_pu=kcl,first_replay_only=True))
                # Failed primary calls are retained without replay or conversion
                # into a physical endpoint success.
                result=episode.accept(intent,after,rec['exception']);assert result==rec['transition'];assert metrics(after)==rec['strict_metrics']
                require_same(episode.snapshot(),decode(path.parent,rec['post_state']),'CONTINUOUS_POST_STATE')
                history.add(path.parent,path,rec)
            if case.get('pending_query'):
                pending=case['pending_query'];intent=episode.next_intent();decisions+=1
                assert intent['action']==pending['action'] and intent['decoded']==pending['decoded'] and intent['prior_count']==pending['number']
                require_same(intent['before'],decode(E/f'case_{i:02d}',pending['before']),'UNENTERED_PENDING_INPUT')
                require_same(episode.snapshot(),decode(E/f'case_{i:02d}',pending['pending']),'UNENTERED_PENDING_STATE')
                assert case['status']=='PARTIAL' and not primary['all4_complete']
            if case['status']=='COMPLETE_NATIVE_EPISODE':
                assert episode.done and metrics(episode.env.net)==case['endpoint'] and episode.count==case['action_count']
                assert result['source_success']==case['source_success'] and result['termination']==case['termination']
            rows.append(dict(case_id=case['case_id'],status=case['status'],endpoint=case.get('endpoint'),action_count=case.get('action_count'),termination=case.get('termination')))
        c=primary['costs'];assert replays==c['new_PF_returns'] and derived==c['derived_paid_returns']
        assert decisions==c['native_policy_calls']==c['cold_policy_checks']
        assert c['new_PF_attempts']==c['new_PF_returns']+c['new_PF_exceptions']
        all4=primary['all4_complete'];assert all4==(len(rows)==4 and all(r['status']=='COMPLETE_NATIVE_EPISODE' for r in rows))
        put(A/'Independent_Audit.json',dict(status='PASS_ALL4_COMPLETE_NATIVE_GRAPH_EPISODES' if all4 else 'PASS_PRESERVED_PREFIX_FULL4_UNKNOWN',all4_complete=all4,rows=rows,
            first_replay_attempts=replay_attempts,first_replay_returns=replays,first_replay_seconds=replay_seconds,maximum_field_delta=maximum,maximum_KCL_pu=kclmax,
            independent_policy_calls=decisions,independent_admittance_balance_constructions=replays,independent_native_identity_preparation=history.costs,
            primary_costs=c,old_costs_separately_retained=p['old_cost_sources'],new_LLM_GPU_training_calls=0,whole_method_equal_resource_or_LLM_superiority='NOT_ESTABLISHED',workflow_seconds=time.monotonic()-began))
        put(A/'Frozen_Original_Checks.json',frozen())
    except BaseException as exc:
        put(A/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),first_replay_attempts=replay_attempts,first_replay_returns=replays,new_science_must_not_be_repeated=True));raise
    finally:manifest(A)
    print(json.dumps(dict(independent='PASS',all4_complete=all4,replays=replays,max_delta=maximum)))
if __name__=='__main__':main()
