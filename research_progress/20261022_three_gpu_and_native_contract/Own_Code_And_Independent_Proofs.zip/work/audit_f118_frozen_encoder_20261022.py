"""Partial-aware, zero-model outside evidence reader for three frozen encoders."""
import hashlib,json,os,sys,time,traceback
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/f118_encoder_readout_preparation_20261022'
O=R/'outputs/f118_encoder_readout_independent_20261022'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    O.mkdir(exist_ok=False);start=time.monotonic();put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-start<180;time.sleep(.1)
    import numpy as np
    p=read(P/'Protocol.json');assert sha(__file__)==read(P/'Independent_Reader_Lock.json')['sha256']
    inputs=read(P/'Causal_Inputs_Only.json');assert len(inputs)==432
    results={};all_features={}
    try:
        for arm in p['arms']:
            base=R/'outputs/f118_encoder_readout_execution_20261022'/arm
            state=read(base/'status.json');end=read(R/'outputs/f118_encoder_readout_coordination_20261022'/arm/'End_ACK.json')
            assert end['actual_owned_chain_ended']
            if not state.get('all_actual_closed_artifacts_preserved'):
                results[arm]={'status':'UNENTERED_OR_UNPRESERVED_FEATURES_UNKNOWN','host_exit_code':end['exit_code'],'state':{k:state.get(k) for k in ['runtime_allocated','runtime_released','science_started','failure_type','allocation_requests']}}
                continue
            assert state['runtime_released'] and state['scientific_process_ended']
            study=base/'staged/study';desc=read(base/'remote_closed_descriptor.json')
            for rel,v in desc['members'].items():assert (study/rel).stat().st_size==v['bytes'] and sha(study/rel)==v['sha256']
            events=[];previous='0'*64
            for line in (study/'events.jsonl').open('r',encoding='utf-8'):
                row=json.loads(line);assert row['event']['previous']==previous
                previous=hashlib.sha256(json.dumps(row['event'],sort_keys=True,separators=(',',':')).encode()).hexdigest();assert previous==row['sha256'];events.append(row['event'])
            attempts=[e for e in events if e['kind']=='body_forward_attempt'];returns=[e for e in events if e['kind']=='body_forward_return']
            for e in attempts:
                item=inputs[e['id']];assert e['tokens']==e['attention_mask_ones']==item['tokens']
                assert e['input_ids_sha256']==hashlib.sha256(np.asarray(item['input_ids'],dtype=np.int64).tobytes()).hexdigest()
            for e in returns:
                assert any(a['id']==e['id'] and a['replica']==e['replica'] and a['zero_path']==e['zero_path'] for a in attempts)
            if not (study/'Results.json').exists():
                results[arm]={'status':'PRESERVED_PARTIAL_NO_COMPLETE_READOUT_ADMISSION','attempts':len(attempts),'returns':len(returns),'failure_preserved':(study/'Failure.json').exists()};continue
            result=read(study/'Results.json');expected=864+2*int(arm=='private_0_5B')
            assert result['status'].startswith('COMPLETE_ALL432') and len(attempts)==len(returns)==expected
            assert result['actual_costs']['body_forward_attempts']==result['actual_costs']['body_forward_returns']==expected
            assert result['actual_costs']['model_load_returns']==2 and result['actual_costs']['generation_backward_optimizer_PF_calls']==0
            for replica in ['primary','cold']:
                assert sorted(e['id'] for e in attempts if e['replica']==replica and not e['zero_path'])==list(range(432))
                assert read(study/f'{replica}_Immutable_Before.json')==read(study/f'{replica}_Immutable_After.json')
            a=np.load(study/'primary_All432_Features.npy');b=np.load(study/'cold_All432_Features.npy')
            assert a.shape==b.shape==(432,p['models'][arm]['hidden_size']) and a.dtype==b.dtype==np.float32 and np.array_equal(a,b) and np.isfinite(a).all()
            for e in returns:
                if not e['zero_path']:assert hashlib.sha256(a[e['id']].tobytes()).hexdigest()==e['feature_sha256']
            all_features[arm]=a;results[arm]={'status':'PASS_COMPLETE_IMMUTABLE_CAUSAL_PRIMARY_COLD_FEATURES','actual_costs':result['actual_costs'],'rows':432,'width':a.shape[1],'peak_allocated_bytes':result['peak_allocated_bytes'],'workflow_seconds':result['workflow_seconds']}
        complete=len(all_features)==3
        if complete:
            d=R/'outputs/f118_encoder_readout_execution_20261022/private_0_5B/staged/study'
            for replica in ['primary','cold']:
                identity=read(d/f'{replica}_Zero_Path_Identity.json');zero=np.load(d/f'{replica}_Public_Base_Zero_Path.npy')
                assert np.array_equal(zero,all_features['public_0_5B'][identity['case_id']])
        put(O/'Independent_Audit.json',{'status':'PASS_COMPLETE_THREE_FROZEN_ENCODERS_READOUT_ONLY_ADMITTED' if complete else 'PASS_PRESERVED_PARTIAL_MISSING_ENCODER_RESULTS_UNKNOWN',
            'models':results,'all3_complete':complete,'private_zero_path_matches_same_base':True if complete else 'UNKNOWN',
            'readout_allowed':complete,'fresh_physical_performance_or_superiority_allowed':False,
            'private_adapter_HELD_training_overlap':'POSSIBLE_ALL109ORIGINAL_WORLD_TRAINING; readoutHELD is not private-adapter holdout',
            'new_model_PF_optimizer_calls':0,'workflow_seconds':time.monotonic()-start})
    except BaseException as e:
        put(O/'Failure.json',{'type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'new_model_PF_calls':0});raise
    finally:put(O/'Closed_Manifest.json',{'files':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'all3_complete':complete,'readout_allowed':complete,'new_model_PF_calls':0}))
if __name__=='__main__':main()
