"""New shared structured-input process interface; not a production loader.

Pretrained LoRA selection, old-base preservation, CUDA/checkpoint ownership and
real PEFT integration remain external required gates. Nothing loads an LLM.
"""
import torch
from torch import nn
from vcsa_common_information_control import ByteEncoder
from vcsa_modules_v2 import StateEncoder
class SharedCurrentProcessInterface(nn.Module):
    def __init__(self,semantic_types,hidden=896):
        super().__init__();self.hidden=hidden
        self.field=nn.Embedding(semantic_types,32);self.text=ByteEncoder()
        self.cells=nn.Sequential(nn.Linear(76,64),nn.Tanh(),nn.Linear(64,64),nn.LayerNorm(64),nn.Tanh())
        self.graph=StateEncoder(13,64,118)
        self.node_projection=nn.Linear(64,hidden);self.global_projection=nn.Linear(128,hidden)
        self.token_norm=nn.LayerNorm(hidden)
        self.process=nn.Sequential(nn.Linear(hidden+64,64),nn.Tanh(),nn.Linear(64,9*7))
    def encode(self,x):
        assert set(x)=={'field_ids','kind','numeric','coordinates','value_bytes','node_features','adjacency','zone_ids','allowed_actions'}
        device=next(self.parameters()).device;n=len(x['field_ids']);present=[i for i,s in enumerate(x['value_bytes']) if s]
        text=self.field.weight.new_zeros((n,32))
        if present:text=text.index_copy(0,torch.tensor(present,device=device),self.text([x['value_bytes'][i] for i in present],device))
        fields=self.field(x['field_ids'].to(device));cells=self.cells(torch.cat([fields,text,x['kind'].to(device),x['numeric'].to(device),x['coordinates'].to(device)],-1))
        nodes=self.graph(x['node_features'].to(device)[None],torch.arange(118,device=device)[None],x['zone_ids'].to(device)[None],x['adjacency'].to(device)[None],torch.ones(1,118,dtype=torch.bool,device=device))
        global_value=torch.cat([cells.mean(0,keepdim=True),nodes.mean(1)],-1)
        tokens=self.token_norm(torch.cat([self.global_projection(global_value)[:,None,:],self.node_projection(nodes)],1))
        assert tokens.shape==(1,119,self.hidden) and bool(torch.isfinite(tokens).all())
        return nodes,tokens
    def decode(self,nodes,body_states):
        assert body_states.shape==(1,119,self.hidden)
        scores=self.process(torch.cat([body_states[:,1:].float(),nodes],-1)).reshape(118,9,7)
        assert bool(torch.isfinite(scores).all());return scores
class PretrainedCurrentProcessPrototype(nn.Module):
    """Caller supplies the real isolated PEFT model and separately verifies it."""
    def __init__(self,interface,causal_model):
        super().__init__();self.interface=interface;self.causal_model=causal_model
        assert causal_model.config.hidden_size==interface.hidden
    def train(self,mode=True):
        super().train(mode)
        # Fixed deterministic body execution; gradients still flow to explicitly
        # selected copied-LoRA parameters. The genuine loader must prove this.
        self.causal_model.eval();return self
    def forward(self,x):
        nodes,tokens=self.interface.encode(x)
        dtype=self.causal_model.get_input_embeddings().weight.dtype
        result=self.causal_model(inputs_embeds=tokens.to(dtype),attention_mask=torch.ones(1,119,dtype=torch.long,device=tokens.device),
            use_cache=False,output_hidden_states=True,return_dict=True,logits_to_keep=1)
        return self.interface.decode(nodes,result.hidden_states[-1])
class GlobalAttentionProcessControl(nn.Module):
    """New strong global numerical control; analytic capacity fixed in advance."""
    def __init__(self,interface,body_parameter_target=8798208):
        super().__init__();self.interface=interface;h=interface.hidden;assert h==896
        # Two standard self-attention layers: total 2*(4*h*h+9*h+(2*h+1)*FF).
        self.ff_width=min(range(1,16385),key=lambda w:(abs(2*(4*h*h+9*h+(2*h+1)*w)-body_parameter_target),w))
        layer=nn.TransformerEncoderLayer(d_model=h,nhead=14,dim_feedforward=self.ff_width,dropout=0.,batch_first=True,norm_first=True)
        self.attention=nn.TransformerEncoder(layer,num_layers=2,enable_nested_tensor=False)
        self.actual_body_parameters=sum(p.numel() for p in self.attention.parameters())
        self.actual_total_parameters=sum(p.numel() for p in self.parameters())
        assert abs(self.actual_body_parameters-body_parameter_target)<.001*body_parameter_target
    def forward(self,x):
        nodes,tokens=self.interface.encode(x)
        states=self.attention(tokens) # Bidirectional numerical control, not a weakened causal replacement.
        return self.interface.decode(nodes,states)
