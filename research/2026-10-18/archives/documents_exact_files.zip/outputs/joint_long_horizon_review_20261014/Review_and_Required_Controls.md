# Joint-control learning: what the primary literature actually supports

This focused update uses the already preserved local studies and newly fetched
primary-paper PDF sections. It runs no model, optimizer, forecast, solver or
physical simulation. It does not modify the running four-state suffix study,
revive a failed intervention, or turn the existing plan into a launch-ready
learning campaign. The original command-format learning remains an achievement.

## Primary sources and the limits of transfer

| Primary source and inspected sections | Verified method/comparison fact | Consequence for this project |
|---|---|---|
| [Yang et al., two-stage LLM–RL voltage control](https://arxiv.org/pdf/2602.21715), sections III–IV, tables I–II and execution baselines | Qwen-Plus schedules OLTC/shunt capacitors from coarse forecasts; RL handles PV reactive control. It includes a Pure-RL comparison. Its separate No-LLM ablation disables OLTC and capacitors. | Copying the actuator-removing ablation would confound model contribution. Keep those devices/actions available to our numeric control. This day-ahead/intraday setting does not establish benefit for our discrete IEEE118 recovery grammar. |
| [Yang et al., experience-driven LLM operator](https://arxiv.org/pdf/2507.14800), experience retrieval/modification and case-study tables | Uses historical contexts, actions and outcomes for day-ahead OLTC/capacitor scheduling. Its main comparison table lists experience/reasoning/control ablations; offline refined strategies are physically evaluated before memory replacement. | Retrieval is established prior art. Count expert experience construction and every offline trial. The listed ablations do not substitute for our full D-SE plus an equally informed numerical planner. Unread supplementary material is not characterized here. |
| [Toroa et al., Koopman-based microgrid control](https://arxiv.org/pdf/2208.13682), sections 2.1.2, 3 and numerical MPC comparisons | Builds a data-driven lifted predictor and constrained distributed predictive controller; compares with nonlinear MPC. | A learned numerical predictive controller is a relevant stronger comparator for future-horizon learning. Its inverter dynamics and predictor constraints must not be relabelled as our exact meshed-grid discrete-bank model or an infeasibility certificate. |
| [Chen et al., SAVER](https://arxiv.org/pdf/2111.15152), sections II–IV and table I | Combines a learned inverter policy with a safety projection under a radial feeder formulation. The reported table includes a small nonzero voltage-violation fraction. | Safety-filter benefit is not automatically language-pretraining benefit. Its model and empirical safety result do not certify our strict per-state nonlinear upper-band gate; retain actual PF and independent replay. |

All four public PDFs were accessible. The two LLM papers' attempted HTML URLs
returned404; that is not a subscription barrier. The inspected text covers the
sections above, not a claim that every figure or supplementary implementation
has been audited. No university credentials were used or requested.

The sources support the relevance of learning, retrieval, predictive control
and physical feedback. None proves a90-percent chance of HierGrid superiority,
novelty of our combination, a private0.5B-to-Qwen-Plus capability equivalence,
or the adequacy of our existing training target.

## The actual remaining learning bottleneck

The current complete native greedy controller already chooses the maximum
original immediate score after paying for every candidate in its declared set.
An LLM that merely imitates that choice or rearranges the order of a completely
enumerated set cannot raise that same-state maximum. Its useful role must change
the deployed decision objective, the future sequence, or measured acquisition
cost while preserving equally informed controls. This is the project's scoped
argmax evidence, not a general theorem that language models can never help.

Three existing local results remain adverse: copied-body/relational learning
failed their fixed decision gates; adapted1.5B improved teacher exact-action
accuracy over adapted0.5B but remained below the completed numerical control;
and the public7B generic-contract screen failed its fixed positive-action
interface. None authorizes another seed/LR/Q/prompt/checkpoint sweep. The newly
bound original mandatory/reflection contracts and trained command-format
achievement are retained separately from those experiments.

The candidate-domain audit found17/7/11/17 additional original LOCAL-allowed
buses outside common numeric fallback across the four inspected states. The
new shared-domain component gives both future controls the same source-derived
union. Any gain caused by adding those receivers or by adding a withdrawal
actuator is a domain/device effect until model-disabled and same-action numeric
controls establish an incremental model effect.

## One defensible next learning hypothesis, still conditional

**Use a learned comparative prior for paid protected descendant evaluation,
targeting terminal recovery under the remaining original operation budget.**
The proposed question is whether learning helps choose a safe first move whose
remaining-budget recovery is better than the strongest numerical planning
control. It is not another one-step action imitation or a smaller hidden
shortlist. All original shared-domain candidates remain available; any paid
evaluation allowance and stopping/commitment policy must be identical and
prospectively specified for the competing guides.

The current four-state run measures complete GREEDY suffixes. It cannot by
itself establish a non-greedy sequence opportunity. Nor can it supply a
terminal label for every counterfactual candidate. A retained solved candidate
NET is an observed ONE-step successor. Unexecuted descendants and their
returns remain UNKNOWN. Historical paid queries remain queries; they are not
retroactively committed episodes. Genuinely new prospective forks would need
exact initial physical/cursor identities, remaining-budget accounting,
exclusive ownership, immutable bounds and full preservation.

## Gates before any new expensive learning

1. Finish the actual current scientist/coordinator and locked external audit.
   Preserve all four endpoints, both methods, source identities, tradeoffs and
   every reused/new/replay/preparation/persistence/failure cost. A resource
   partial remains UNKNOWN; do not extend or restart the old job.
2. Close an exact physical-support inventory for a new prospective descendant
   study. Match the source-defined common/LOCAL union for BOTH model and
   numeric controls, original9Q, owned stock, non-refunded450 lifetime cap,
   joint two-operation debit and intermediate normal protection. No sampled
   favourable worlds or oracle stopping.
3. Specify an actual numerical lookahead/search control. A finite-horizon
   sensitivity/learned-dynamics predictor may ORDER evaluations; only measured
   native PF can certify acceptance and labels. Include a same-data trained
   numerical value/search guide and model-disabled joint-planner ablation.
   A heuristic optimizer failure cannot certify no better sequence exists.
4. Freeze the protected terminal target and paid evaluation budget before
   measuring opportunity. Only actual complete descendants can supervise that
   target. Register enough outcome-independent development roots/world groups
   for meaningful training/validation; four inspected roots do not establish
   independent confirmation or a universal training distribution.
5. Only a surviving fixed opportunity/economic/support gate justifies a learner.
   Its causal representation needs current physical measurements, owned banks,
   cumulative caps, remaining operations and legitimately acquired receipts.
   Bind actual original serving units/schema/parser and explicit new action
   eligibility. Show full tokenizer/context/loss-mask/gradient/memory gates and
   complete optimizer/RNG/cursor preservation under a fixed protocol.
6. Attribute language pretraining with numerical/architecture/random-pretraining
   controls under the same information, actuators and measurement budget. Do
   not count a shared guard, cache, added donor action or broader receiver list
   as an LLM gain. Count training and all failed preparations; no free teacher
   or simulated lookahead.
7. A final claim still needs fresh per-state inference and complete protected
   trajectories against original literal DFF and DFF-ALT, their unchanged
   selector and FULL BOTH costs, plus truly unused authorized confirmation.
   The current suffix inputs are inspected development. Security waits that
   clean attribution. No manuscript expansion or superiority claim is ready.

This is a refinement of the preserved non-greedy spatial hypothesis, not a new
claim that long-horizon learning or safety-filtered control is novel. The new
concrete requirements are matched original LOCAL action support, actual owned
stock/cap/operation state and physically supported descendant targets. Numeric
lookahead must be competitive before a language learner is credited.
