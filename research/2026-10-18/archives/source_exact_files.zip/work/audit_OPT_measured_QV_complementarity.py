"""Read-only nominal generator Q/V constitutive target check; no new solves.

This tests the physically usual piecewise Q/V relation, not unrecorded modes.
Violations are retained as evidence, not fixed by editing measured outputs.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter,defaultdict
import json,time,os
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';S=P/'OPT_generator_bound_event_inventory'
OUT=P/'OPT_measured_QV_complementarity_audit';assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
protocol={'declared_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'All216 fixed OPT transitions, both current and measured successor, all53 native generators',
 'purpose':'Check usual generator Q/V relation before implementing a complementarity constraint-selection control',
 'relation':'interior:Vm=command; near_max:Vm<=command; near_min:Vm>=command',
 'voltage_tolerance_pu':1e-10,'Q_occupancy_tolerance_MVAr':1e-8,
 'reason':'Existing continuous physical equality tolerance and frozen nominal-bound occupancy tolerance; no sweep',
 'source_sha256':sha(Path(__file__)),'prior_inventory_rows_sha256':sha(S/'Actual_Generator_Bound_Records.json'),
 'no_inference_of_hidden_internal_modes_or_solver_failure_from_this_predicate':True,
 'no_label_edit_imputation_or_repeated_PF_model_controller_optimizer_cloud_calls':True,
 'target_gate':'Any measured bound-direction violation means these nominal occupancy labels cannot be assumed to certify that complementarity system; freeze further implementation until exact original solver logic is checked',
 'bounds_seconds':120}
write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'pid':os.getpid(),'source_sha256':protocol['source_sha256']})
rows=read(S/'Actual_Generator_Bound_Records.json');proto=read(S/'Protocol.json');sources={}
for name,h in proto['source_branch_hashes'].items():assert sha(ROOT/name)==h;sources[h]=read(ROOT/name)
def frame(f):return {i:dict(zip(f['columns'],r)) for i,r in zip(f['index'],f['values'])}
all_records=[];counts=Counter();worlds=defaultdict(set);transitions=defaultdict(set);maxviolation=defaultdict(float);scalar_checks=0
for r in rows:
    assert time.perf_counter()-start<120
    p=r['source_provenance'][0];src=sources[p['source_record_sha256']];n=p['prefix']
    for side,idx in [('before',n),('after',n+1)]:
        tabs=src['observations'][idx]['input_observation']['physical_tables'];g=frame(tabs['gen']);res=frame(tabs['res_gen'])
        for m in r['generator_measurements']:
            gen=m['native_gen_id'];q=res[gen]['q_mvar'];lo=g[gen]['min_q_mvar'];hi=g[gen]['max_q_mvar']
            v=res[gen]['vm_pu'];command=g[gen]['vm_pu'];label=m[side+'_nominal_occupancy']
            assert m[side+'_q_mvar']==q and m[side+'_vm_pu']==v and m['voltage_setpoint_pu']==command
            assert label==('near_min' if abs(q-lo)<=1e-8 else 'near_max' if abs(q-hi)<=1e-8 else 'interior')
            scalar_checks+=5
            residual=abs(v-command) if label=='interior' else v-command if label=='near_max' else command-v
            violation=residual>1e-10;counts[(side,label)]+=1;counts[(side,'violations')]+=int(violation)
            maxviolation[side]=max(maxviolation[side],residual)
            if violation:worlds[side].add(p['world_sha256']);transitions[side].add(r['transition_id'])
            all_records.append({'transition_id':r['transition_id'],'world_sha256':p['world_sha256'],'family':p['family'],
             'side':side,'gen_id':gen,'native_bus':g[gen]['bus'],'occupancy':label,
             'q_mvar':q,'vm_pu':v,'voltage_command_pu':command,'constitutive_residual_pu':residual,
             'usual_QV_relation_violated':violation,'source_record_sha256':p['source_record_sha256'],'source_prefix':idx})
assert len(all_records)==22896 and scalar_checks==114480
result={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all22896_records_source_bound':True,
 'source_scalar_checks':scalar_checks,'usual_QV_relation_violation_pairs':{s:counts[(s,'violations')] for s in ('before','after')},
 'worlds_with_violations':{s:sorted(worlds[s]) for s in ('before','after')},
 'transition_ids_with_violations':{s:sorted(transitions[s]) for s in ('before','after')},
 'maximum_positive_voltage_relation_residual_pu':dict(maxviolation),
 'nominal_occupancy_labels_certify_usual_complementarity':all(counts[(s,'violations')]==0 for s in ('before','after')),
 'existing_oracle_identity_equation_results_preserved_not_invalidated':True,
 'unrecorded_original_solver_modes_remain_UNKNOWN':True,'new_PF_model_optimizer_controller_cloud_calls':0,
 'reader_seconds':time.perf_counter()-start}
write(OUT/'Actual_All_Generator_QV_Predicates.json',all_records);write(OUT/'Summary.json',result)
files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'};files['source/reader.py']=Path(__file__)
archive=seal(OUT,files,'Measured_OPT_QV_Constitutive_Target_Audit.zip')
print(json.dumps({'summary':{k:v for k,v in result.items() if k not in ('worlds_with_violations','transition_ids_with_violations')},
 'violating_world_counts':{s:len(worlds[s]) for s in ('before','after')},
 'violating_transition_counts':{s:len(transitions[s]) for s in ('before','after')},'archive':archive}))
