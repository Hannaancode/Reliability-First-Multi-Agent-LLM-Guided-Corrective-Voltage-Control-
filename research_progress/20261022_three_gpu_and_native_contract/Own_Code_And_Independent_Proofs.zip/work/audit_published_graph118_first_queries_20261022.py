"""FIRST independently charged replay of only newly returned graph queries."""
import json,os,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'work'))
from reflection118_chronological_core_20261022 import read,put,sha,decode,frames_equal
P=R/'outputs/published_graph118_first_queries_preparation_20261022';E=R/'outputs/published_graph118_first_queries_execution_20261022';O=R/'outputs/published_graph118_first_queries_independent_20261022'
def main():
    O.mkdir(exist_ok=False);start=time.monotonic();put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-start<180;time.sleep(.1)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp,numpy as np
    from pandapower.pypower.makeSbus import makeSbus
    from pandapower.pypower.makeYbus import makeYbus
    p=read(P/'Protocol.json');assert sha(__file__)==p['source_hashes']['work/audit_published_graph118_first_queries_20261022.py']
    end=read(R/'outputs/published_graph118_first_queries_coordination_20261022/End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    for n,h in read(E/'Closed_Manifest.json')['members'].items():assert sha(E/n)==h
    result=read(E/'Results.json');assert len(result['rows'])==4;rows=[];replays=0;maximum=0.;kclmax=0.
    for i,(target,record) in enumerate(zip(p['targets'],result['rows'])):
        assert target['case_id']==record['case_id'] and target['source_action']==record['action']
        if record['status']!='RETURNED_NEW_QUERY':rows.append({'case_id':record['case_id'],'outcome':'UNKNOWN_RETAINED_EXCEPTION_NO_RETRY'});continue
        assert time.monotonic()-start<p['reader_seconds']
        before=decode(E,record['before']);after=decode(E,record['after']);net=before['net'];tick=time.perf_counter();pp.runpp(net,**p['solver_kwargs']);replays+=1
        frames_equal(net,after['net']);assert net.converged and after['net'].converged
        delta=0.
        for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
            a=net[name].select_dtypes(include=[np.number]).to_numpy(float);b=after['net'][name].select_dtypes(include=[np.number]).to_numpy(float)
            assert a.shape==b.shape and np.array_equal(np.isnan(a),np.isnan(b)) and np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True)
            m=np.isfinite(a)&np.isfinite(b);delta=max(delta,float(np.max(abs(a[m]-b[m]),initial=0)))
        q=net._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0];V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]));kcl=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
        maximum=max(maximum,delta);kclmax=max(kclmax,kcl);rows.append({'case_id':record['case_id'],'action':record['action'],'strict_all118_fields':record['strict_all118_fields'],'maximum_field_delta':delta,'KCL_pu':kcl,'first_replay_seconds':time.perf_counter()-tick,'actual_policy_commit':False})
        put(O/f'first_replay_{i:02d}.json',rows[-1])
    put(O/'Independent_Audit.json',{'status':'PASS_PRESERVED_ALL4_FIRST_SOURCE_GRAPH_QUERY_OUTCOMES','rows':rows,'first_independent_PF_replays':replays,'maximum_numeric_field_delta':maximum,'maximum_KCL_pu':kclmax,
        'primary_costs':result['costs'],'new_model_training_optimizer_calls':0,'full_policy_same_resource_superiority':'NOT_TESTED','workflow_seconds':time.monotonic()-start})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'independent_graph_first_query_audit':'PASS','new_first_replays':replays,'max_delta':maximum,'rows':rows}))
if __name__=='__main__':main()
