"""Prospective remaining original-policy cases, three fixed own profiles.

This creates source/design only while the DFF owner is live. Final input,
history, independent-reader and allocation locks require actual DFF closure.
"""
import ast,collections
from datetime import datetime,timezone
from reflection118_remaining_cases_core_20261023 import *
TOP=R/'outputs/reflection118_remaining_cases_preparation_20261023'

def save_script(name,text):
    ast.parse(text);path=R/'work'/name
    with path.open('x',encoding='utf-8') as f:f.write(text);f.flush();os.fsync(f.fileno())

def main():
    TOP.mkdir(exist_ok=False)
    old=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json')
    rows=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    oldrequests=[]
    for path in (R/'outputs/r118chrono_20261022/local_controller/requests').glob('request_*.json'):
        oldrequests.append(read(path)['active']['case_id'])
    counts=collections.Counter(oldrequests)
    assert all(counts[r['case_id']]==0 for r in rows[1:])
    profiles=[('OWN_PROFILE_EMAIL_REDACTED','original'),('OWN_PROFILE_EMAIL_REDACTED','ahammedsheen'),('OWN_PROFILE_EMAIL_REDACTED','sheenahammed')]
    # Host collection/ownership and remote immutable original model source are
    # reused as implementation, in a new study namespace with explicit inputs.
    host=(R/'work/run_reflection118_chronological_colab_20261022.py').read_text('utf-8')
    oldglobals="PREP=R/'reflection118_chronological_preparation_20261022'\narm='public_0_5B'\nOUT=extended(R/'r118chrono_20261022')"
    newglobals="""_parser=argparse.ArgumentParser();_parser.add_argument('--case-index',required=True,type=int,choices=[1,2,3])
case_index=_parser.parse_args().case_index
PREP=R/'reflection118_remaining_cases_preparation_20261023'/f'case_{case_index:02d}'
arm='public_0_5B'
OUT=extended(R/'reflection118_remaining_cases_execution_20261023'/f'case_{case_index:02d}')"""
    assert oldglobals in host;host=host.replace(oldglobals,newglobals)
    a=host.index("    profile['credential_path']=");b=host.index("    state=",a)
    host=host[:a]+"    profile['credential_path']={'original':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud\\application_default_credentials.json','ahammedsheen':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud-hiergrid-ahammedsheen\\application_default_credentials.json','sheenahammed':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud-hiergrid-sheenah\\application_default_credentials.json'}[protocol['local_profile_label']]\n"+host[b:]
    host=host.replace('reflection118_model_service_guardian_20261022.py','reflection118_remaining_model_service_guardian_20261023.py')
    host=host.replace('hiergrid-original-reflection118-chronological','hiergrid-original-reflection118-remaining-three')
    host=host.replace('run_reflection118_chronological_local_20261022.py','run_reflection118_remaining_local_20261023.py')
    needle="str(ROOT/'work/run_reflection118_remaining_local_20261023.py')],cwd=ROOT"
    assert needle in host;host=host.replace(needle,"str(ROOT/'work/run_reflection118_remaining_local_20261023.py'),'--case-index',str(case_index)],cwd=ROOT")
    # The local child gets the same ACK structure as the integrated host, and
    # a single-case local partial is explicitly preserved/closed.
    host=host.replace("'local_result_present':(local/'Results.json').exists()","'local_result_present':(local/'Results.json').exists()")
    gate="""        # Actual previous scientist, reader and coordinator must be terminal;
        # no allocation may be requested merely because this software exists.
        closure=read(ROOT/'outputs/r118_dff_missing_continuation_handoff_20261023/Completion.json')
        assert closure['independent_audit_status'].startswith('PASS_')
        assert read(PREP/'Final_Allocation_Readiness.json')['passed']
"""
    assert "        assert ready['passed']\n" in host;host=host.replace("        assert ready['passed']\n","        assert ready['passed']\n"+gate)
    assert host.count('client.assign(')==1
    save_script('run_reflection118_remaining_colab_20261023.py',host)
    remote=(R/'work/run_reflection118_model_service_remote_20261022.py').read_text('utf-8')
    save_script('run_reflection118_remaining_model_remote_20261023.py',remote)
    guardian=(R/'work/reflection118_model_service_guardian_20261022.py').read_text('utf-8').replace('run_reflection118_model_service_remote_20261022.py','run_reflection118_remaining_model_remote_20261023.py')
    save_script('reflection118_remaining_model_service_guardian_20261023.py',guardian)
    # Phase coordinator starts ALL3 primary hosts together, then ALL3 sole
    # readers. Different roots have distinct necessary load/outage inputs.
    coordinator='''"""Three fixed own-profile case owners, no replacement or rotation."""
import subprocess
from reflection118_remaining_cases_core_20261023 import *
TOP=R/'outputs/reflection118_remaining_cases_preparation_20261023'
O=R/'outputs/reflection118_remaining_cases_handoff_20261023'
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
 assert read(TOP/'Final_All3_Readiness.json')['passed']
 for phase in ['Primary','Reader']:
  children=[]
  for index in [1,2,3]:
   path=TOP/f'case_{index:02d}'/(phase+'_Owner_Protocol.json')
   log=(O/f'{phase}_{index:02d}.log').open('x',encoding='utf-8')
   child=subprocess.Popen([sys.executable,'-X','utf8',str(R/'work/coordinate_single_owner_arguments_v2_20261022.py'),'--protocol',str(path.relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
   put(O/f'{phase}_{index:02d}_Launch.json',dict(pid=child.pid,parent=os.getpid(),protocol_sha256=sha(path)));children.append((index,child,log))
  outcomes=[]
  for index,child,log in children:
   code=child.wait(timeout=13800 if phase=='Primary' else 7800);log.close();outcomes.append(dict(case_index=index,exit_code=code));put(O/f'{phase}_{index:02d}_End.json',outcomes[-1])
  assert all(x['exit_code']==0 for x in outcomes),'No retry/fallback; preserve every failure and do not start a complete-only next phase'
 put(O/'Completion.json',dict(status='ALL3_CASE_OWNERS_AND_SOLE_READERS_TERMINAL',all6_final_goals='OPEN'))
if __name__=='__main__':main()
'''
    save_script('coordinate_reflection118_remaining_cases_20261023.py',coordinator)
    localnames=['reflection118_remaining_cases_core_20261023.py','run_reflection118_remaining_local_20261023.py','audit_reflection118_remaining_case_20261023.py','r118_dff_missing_continuation_core_20261023.py','reflection118_chronological_core_20261022.py','frozen_physics_loader.py','run_reflection118_chronological_local_20261022.py','prior_physical_query_footprints_20261018.py','public_size_u61_preservation.py','candidate_process_evidence_utils.py']
    for f in localnames:ast.parse((R/'work'/f).read_text('utf-8'))
    for index,(account,label) in zip([1,2,3],profiles):
        prep=TOP/f'case_{index:02d}';prep.mkdir()
        binding=rows[index]
        p={k:copy.deepcopy(v) for k,v in old.items()}
        p.update(at_utc=datetime.now(timezone.utc).isoformat(),status='DESIGN_ONLY_REMAINING_ORIGINAL_REFLECTION_CASE_NO_ALLOCATION_READY',
            question='Complete this previously unentered original Reflection-v4 case under unchanged source, on the exact same physical root as the DFF comparison.',
            case_order=[binding['case_id']],all4_original_comparison_order=[r['case_id'] for r in rows],source_case_index=index,profiles={'public_0_5B':{'account':account}},local_profile_label=label,
            bindings='outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json',base_net='work/e/pack/testbeds/federation_4mg_ieee118.json',metadata='work/e/pack/testbeds/federation_4mg_ieee118_metadata.json',
            local_source_hashes={('work/'+n):sha(R/'work'/n) for n in localnames}|old['original_serving_sources'],
            three_profile_policy='Fixed one case/one own profile per case selected before new outcomes. One T4 request each, no replacement or account switch if denied. Separate VRAM, no pooled quota or reset/lifetime promise.',
            nonrepeat_gate='Actual prior DFF scientist/reader/coordinator all terminal and audited first. Include all its returned/failed/unclosed input records with all earlier named histories. Three roots have distinct exact necessary load/outage keys; per-process registry preserves every new reservation. No old model root0/prompt/physics retry or old budget extension.',
            old_model_calls_for_this_case=counts[binding['case_id']],
            persistent_full_process_gate='Every actual source commitment NET/result/failed-actions/feedback/RNG plus PF/model cursor, hashes, source, costs and absolute bound persisted. Full original source cold replay of first commitment uses paid replies/physics only before continuation. This certifies source reconstruction, not process availability or deployment timing.',
            authority='Direct human requests continue fair118 original Reflection-v4 comparison and use all3ownGPUprofiles. Necessary unchanged private adapter and causal current prompts may be served in these own profiles; no credentials, NET, bank or teacher labels uploaded.',
            scope='Remaining3 previously unentered cases from original fixed4, not restart/extension of the ended old study; old complete root0 trajectory and its costs reused. Historical development, not unused confirmation.')
        put(prep/'Frozen_Engineering_Protocol.json',p)
        put(prep/'Direct_Human_Authority.json',dict(scope=p['authority'],no_purchases_rotation_or_guaranteed_win=True,original_explicit_three_GPU_request_preserved=True))
    put(TOP/'Source_And_Design_Readiness.json',dict(status='SOURCE_DESIGN_PREPARED_NOT_ALLOCATION_OR_PERFORMANCE_READY',remaining_case_indices=[1,2,3],old_model_requests_by_case=dict(counts),all3_remaining_original_roots_unentered=True,local_sources_parsed=True,actual_model_PF_GPU_allocations_in_preparation=0,
        required_next=['Wait for real DFF owner/reader/coordinator closure, then independently bind its full returned/failed/reserved input registry and all original file anchors.','Run actual saved-input source/prompt/registry/cold boundary engineering with zero new model/PF calls. Freeze full independent-reader/owner/preservation/source/input locks and exact one-assignment-per-case protocol.','Only then form authorized private model payloads and request exactly three fixed-profile assignments. Failed eligibility/allocation stops that arm; no fallback.'],not_a_new_scientific_result=True))
    print(json.dumps(dict(prepared_remaining_original_cases=3,new_scientific_calls=0,GPU_allocations=0,ready_for_allocation=False)))

if __name__=='__main__':main()
