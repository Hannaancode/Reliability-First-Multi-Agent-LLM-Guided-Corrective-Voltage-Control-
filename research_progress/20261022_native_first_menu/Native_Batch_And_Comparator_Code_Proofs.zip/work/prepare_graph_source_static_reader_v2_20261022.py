"""Preserve a static alias-reader error and correct conditional source modes."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
old=R/'work/record_compatible_graph_environment_semantics_20261022.py'
s=old.read_text('utf-8')
p=R/'outputs/published_graph118_environment_source_20261022/compatible_archived/Static_Reader_V1_Failure.json'
with p.open('x',encoding='utf-8') as f:json.dump(dict(status='STATIC_READER_KEYERROR_NO_SOURCE_EXECUTION',missing_attribute='_solve_and_observe is assigned to default or truncate helper at runtime',original_reader_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),new_PF_model_install_calls=0),f,indent=2)
s=s.replace('failed power flow/robust voltage-range violation','failed power flow; robust voltage-range rejection applies only in truncate_voltages mode')
s=s.replace('source_voltage_constants=constants,normal_band_success=',"truncate_mode='Author experiment sets truncate_voltages=False, selecting _solve_and_observe_default. MIN_V/MAX_V rejection is conditional and must not be imposed on this experiment.',source_voltage_constants=constants,normal_band_success=")
s=s.replace("'all_v_in_range','_solve_and_observe'","'all_v_in_range','_solve_and_observe_default','_solve_and_observe_truncate'")
new=R/'work/record_compatible_graph_environment_semantics_v2_20261022.py';assert not new.exists();new.write_text(s,encoding='utf-8')
