"""External closed-data reader and local seal; zero new model or solver calls."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,os,subprocess,zipfile
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack
from dff_alt import choose_candidate
from guarded_native_prefix_replay import native_metric_certificate
from train_trajectory_measurement_nullable_v2 import (observation,digest,safe,compare_observations,check_literal_selections)
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3'
OUT=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3_audit'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(safe(v),f,indent=2,allow_nan=False)
def decode(x):
    if isinstance(x,dict) and set(x)=={'missing'}:
        assert x['missing']=='pandas.NA';return pd.NA
    if isinstance(x,dict) and set(x)=={'nonfinite'}:return float(x['nonfinite'])
    if isinstance(x,list):return [decode(v) for v in x]
    if isinstance(x,dict):return {k:decode(v) for k,v in x.items()}
    return x
class RecordedNet(dict):
    def __getattr__(self,k):
        if k not in self:raise AttributeError(k)
        return self[k]
def reconstruct(view):
    return RecordedNet({n:pd.DataFrame(decode(t['values']),columns=t['columns'],index=t['index'])
                        for n,t in view['physical_tables'].items()})
def audit():
    status=read(DATA/'status.json');assert status['stage']=='collection_closed_pending_external_audit'
    pid=int(status['owner_pid'])
    command=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"
    live=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,check=True).stdout.strip()
    assert not live,'Audit waits for actual owner end; PID reuse requires separate ownership inspection'
    assert not OUT.exists(),'Never overwrite a completed/partial audit'
    OUT.mkdir()
    with (OUT/'audit.claim').open('x') as f:f.write(str(os.getpid()))
    protocol=read(DATA/'protocol.json');summary=read(DATA/'summary.json');manifest=read(DATA/'manifest.json')
    for n,m in manifest.items():
        p=DATA/n;assert sha(p)==m['sha256'] and p.stat().st_size==m['bytes']
    for n,h in protocol['frozen_source_sha256'].items():assert sha(ROOT/n)==h
    old=ROOT/'outputs/llm_value_next_method_research_20261008/train_trajectory_collection'
    assert sha(old/'protocol.json')==protocol['prior_failed_protocol_sha256']
    old_summary=read(old/'summary.json')
    assert old_summary['actual_new_PF_costs_by_phase']['new_old_prefix_observation_derivation']['attempts']==1
    v2,runner,ref=load_stack()
    def forbidden(*a,**kw):raise AssertionError('No numerical solver entry permitted in external saved-data audit')
    originalPF=pp.runpp;pp.runpp=forbidden
    try:
        planned={(w['scenario_id'],b):w for w in protocol['worlds'] for b in ('DFF','DFF-ALT')}
        records={};counts={};inputs=0;candidate_rows=0;selected_checks=0;reused=0;contrasts=[]
        for p in sorted((DATA/'branches').glob('*.json')):
            r=read(p);identity=(r['scenario_id'],r['branch']);assert identity in planned and identity not in records
            w=planned[identity];assert r['scenario_sha256']==w['sha256'] and sha(ROOT/w['path'])==w['sha256']
            records[identity]=r
            for phase,cost in r['new_actual_costs'].items():
                assert cost['attempts']==cost['returns']+cost['exceptions']
                total=counts.setdefault(phase,{'attempts':0,'returns':0,'exceptions':0,'solver_seconds':0.})
                for k in total:total[k]+=cost[k]
            if r['status'].startswith('unexecuted'):
                assert r['result'] is None and r['new_actual_costs']=={};continue
            journal=[json.loads(s) for s in (DATA/'journals'/(p.stem+'.jsonl')).read_text(encoding='utf-8').splitlines()]
            assert [e['event_index'] for e in journal]==list(range(1,len(journal)+1))
            assert len(journal)==r['journal_events'] and journal[-1]['event']=='branch_closed'
            assert journal[-1]['payload']['status']==r['status']
            assert journal[-1]['payload']['new_actual_costs']==r['new_actual_costs']
            assert all(e['scenario_sha256']==w['sha256'] and e['branch']==r['branch'] and e['protocol_sha256']==sha(DATA/'protocol.json') for e in journal)
            if r['source_role']=='reused_verified_prior_guarded':
                original=read(ROOT/w['existing_branches'][r['branch']]['path']);reused+=1
                prior=original['record'];pc=prior['actual_costs']
                assert r['result']==prior['original_function_result']
                assert r['original_controller_costs']=={**{k:pc['PF_'+k] for k in ('attempts','returns','exceptions')},'wall_seconds':pc['wall_seconds'],'solver_seconds':pc['PF_seconds']}
                assert r['measured_decisions'] is None and 'new_common_guard_controller' not in r['new_actual_costs']
                assert r['prior_native_per_bus_states_match_current_derivation_1e10']
                assert r['original_candidate_verifications']==prior['actual_candidate_verifications']
                if 'retained_prior_initial_derivation' in r:
                    retained=r['retained_prior_initial_derivation'];assert retained==protocol['retained_initial_prefix_derivation']
                    assert sha(ROOT/retained['path'])==retained['sha256']
                    old_entries=[json.loads(s) for s in (ROOT/retained['path']).read_text(encoding='utf-8').splitlines()]
                    old_states=[e['payload'] for e in old_entries if e['event']=='native_guarded_prefix_reproduction']
                    assert old_states==r['observations'] and r['new_actual_costs']['new_old_prefix_observation_derivation']['attempts']==0
                # Recheck native recorded candidate order, common guard and exact
                # selection independently; no Windows reorder or new solve.
                committed={a['iteration']:a['action'] for a in r['result']['executed_actions']}
                for decision in sorted({c['decision'] for c in r['original_candidate_verifications']}):
                    candidates=[{'action':c['action'],'verif':c['verification']} for c in r['original_candidate_verifications'] if c['decision']==decision]
                    accepted=[c for c in candidates if c['verif']['accepted']]
                    chosen=(max(accepted,key=runner.rescue.score_candidate) if accepted else None) if r['branch']=='DFF' else choose_candidate(candidates,decision,runner.rescue.score_candidate,runner.action_signature)[0]
                    if decision in committed:assert chosen is not None and chosen['action']==committed[decision]
                    else:assert chosen is None
                    for c in candidates:
                        v=c['verif'];band=bool(v.get('after') is not None and math.isfinite(float(v['after']['vmax'])) and v['after']['vmax']<=1.05+1e-8)
                        assert v['accepted']==bool(v['original_verifier_accepted'] and band)
                        assert v['normal_upper_mediation']['upper']==1.05 and v['normal_upper_mediation']['tolerance']==1e-8
            if r['status']!='complete_verified_measurement':continue
            assert r['independent_all_field_replay_passed_1e10'] and r['base_network_preserved']
            result=r['result'];states=r['observations'];assert len(states)==1+len(result['executed_actions'])
            expected=[(0,None,result['base_metrics'])]+[(a['iteration'],a['action'],a['post_metrics']) for a in result['executed_actions']]
            for position,(item,(decision,action,metrics)) in enumerate(zip(states,expected)):
                assert item['decision']==decision and item['committed_action']==action
                view=item['input_observation'];assert digest(view)==item['observation_sha256']
                assert not {'scenario_id','branch','terminal_metrics','candidate_labels','label','split'} & set(view)
                actual=observation(reconstruct(view),runner,view['zone_buses'])
                compare_observations(actual,view)
                if r['source_role']=='reused_verified_prior_guarded':
                    native=prior['actual_solved_states'][position]
                    frame=view['physical_tables']['res_bus'];col=frame['columns'].index('vm_pu')
                    vm={str(int(b)):values[col] for b,values in zip(frame['index'],frame['values'])}
                    compare_observations(native['metrics'],metrics)
                    proof=native_metric_certificate(view['global_metrics'],native['metrics'],vm,native['vm_pu'])
                    compare_observations(proof,item['native_metric_reproduction'])
                else:compare_observations(view['global_metrics'],metrics)
                assert len(view['physical_tables']['res_bus']['index'])==118
                inputs+=1
            if r['source_role']=='reused_verified_prior_guarded':
                compare_observations(prior['actual_solved_states'][-1]['metrics'],result['final_metrics'])
            else:compare_observations(states[-1]['input_observation']['global_metrics'],result['final_metrics'])
            assert all(s['input_observation']['global_metrics']['vmax']<=1.05+1e-8 for s in states)
            check_literal_selections(r,runner,choose_candidate)
            if r['measured_decisions'] is not None:
                assert len(r['measured_decisions'])==len(result['logs'])
                for d,log in zip(r['measured_decisions'],result['logs']):
                    assert d['decision']==log['iteration']
                    assert len(d['candidates'])==log['fallback_tests']
                    assert sum(c['verif']['accepted'] for c in d['candidates'])==log['accepted_fallback']
                    for c in d['candidates']:
                        compare_observations(c['verif']['before'],log['current_metrics']);candidate_rows+=1
                        v=c['verif'];band=bool(v.get('after') is not None and math.isfinite(float(v['after']['vmax'])) and v['after']['vmax']<=1.05+1e-8)
                        assert v['accepted']==bool(v['original_verifier_accepted'] and band)
                        assert v['normal_upper_mediation']['band_admissible']==band
                        assert v['normal_upper_mediation']['upper']==1.05 and v['normal_upper_mediation']['tolerance']==1e-8
                cost=r['new_actual_costs']['new_common_guard_controller']
                expected_attempts=1+len(result['executed_actions'])+sum(c['verif']['reason'] not in ('q_cap_exceeded','no_action') for d in r['measured_decisions'] for c in d['candidates'])
                if str(result['stop_reason']).startswith('execution_pf_failed'):expected_attempts+=1
                assert cost['attempts']==expected_attempts
                observer=r['observer_controller_PF_counts']
                assert [cost[k] for k in ('attempts','returns','exceptions')]==[observer[k] for k in ('PF_attempts','PF_returns','PF_exceptions')]
                selected_checks+=len(result['executed_actions'])
        assert set(records)==set(planned) and len(records)==62
        assert counts.keys()==summary['actual_new_PF_costs_by_phase'].keys()
        for phase in counts:
            for k,v in counts[phase].items():
                tolerance=1e-7 if k=='solver_seconds' else 0
                assert abs(v-summary['actual_new_PF_costs_by_phase'][phase][k])<=tolerance
        values={'nontrivial_protected_success_worlds':0,'protected_success_families':0,
                'same_root_distinct_first_action_informative_pairs':0,'protected_vs_nonprotected_terminal_pairs':0,
                'ALT_lower_terminal_UV_than_DFF_worlds':0,'ALT_lower_UV_families':0,'DFF_lower_terminal_UV_than_ALT_worlds':0}
        families=set();alt_families=set();all_valid=True
        for w in protocol['worlds']:
            pair={b:records[(w['scenario_id'],b)] for b in ('DFF','DFF-ALT')}
            portfolio=read(DATA/'portfolios'/(w['scenario_id']+'.json'))
            valid=all(r['status']=='complete_verified_measurement' for r in pair.values())
            assert portfolio['valid']==valid;all_valid=all_valid and valid
            if not valid:continue
            roots={b:r['observations'][0]['input_observation'] for b,r in pair.items()}
            compare_observations(roots['DFF'],roots['DFF-ALT'])
            root_equal=digest(roots['DFF'])==digest(roots['DFF-ALT'])
            results={b:r['result'] for b,r in pair.items()};summaries={b:ref.summarize_result(r) for b,r in results.items()}
            selected='DFF-ALT' if ref.choose_safety_envelope(summaries['DFF'],summaries['DFF-ALT'])=='reflection_v2' else 'DFF'
            assert selected==portfolio['selected_branch'] and results[selected]['final_metrics']==portfolio['selected_final_metrics']
            costs={b:r.get('original_controller_costs',r['new_actual_costs'].get('new_common_guard_controller')) for b,r in pair.items()}
            assert portfolio['full_original_controller_costs_both_branches']=={k:sum(costs[b][k] for b in costs) for k in ('attempts','returns','exceptions','wall_seconds')}
            protected={b:results[b]['base_metrics']['uv_count']>0 and results[b]['final_metrics']['uv_count']==0 and
                          all(s['input_observation']['global_metrics']['vmax']<=1.05+1e-8 for s in pair[b]['observations']) for b in pair}
            assert portfolio['nontrivial_protected_episode_by_branch']==protected
            if any(protected.values()):values['nontrivial_protected_success_worlds']+=1;families.add(w['family'])
            first={b:results[b]['executed_actions'][0]['action'] if results[b]['executed_actions'] else None for b in pair}
            different=all(first.values()) and first['DFF']!=first['DFF-ALT']
            endpoints={b:results[b]['final_metrics'] for b in pair}
            meaningful=protected['DFF']!=protected['DFF-ALT'] or endpoints['DFF']['uv_count']!=endpoints['DFF-ALT']['uv_count'] or abs(endpoints['DFF']['deficit_sum']-endpoints['DFF-ALT']['deficit_sum'])>1e-9 or costs['DFF']['attempts']!=costs['DFF-ALT']['attempts']
            if different and meaningful:values['same_root_distinct_first_action_informative_pairs']+=1
            if different and protected['DFF']!=protected['DFF-ALT']:values['protected_vs_nonprotected_terminal_pairs']+=1
            assert all(all(s['input_observation']['global_metrics']['vmax']<=1.05+1e-8 for s in pair[b]['observations']) for b in pair)
            if different and endpoints['DFF-ALT']['uv_count']<endpoints['DFF']['uv_count']:
                values['ALT_lower_terminal_UV_than_DFF_worlds']+=1;alt_families.add(w['family'])
            if different and endpoints['DFF']['uv_count']<endpoints['DFF-ALT']['uv_count']:values['DFF_lower_terminal_UV_than_ALT_worlds']+=1
            contrasts.append({'scenario_sha256':w['sha256'],'same_physical_root_1e10':True,'same_root_observation_byte_hash':root_equal,
               'root_observation_sha256':{b:digest(roots[b]) for b in pair},'executed_first_actions':first,
               'protected_episode':protected,'actual_terminal_metrics':endpoints,'full_branch_controller_costs':costs,
               'full_selected_action_sequences':{b:results[b]['executed_actions'] for b in pair},
               'unsupported_future_candidate_labels_inferred':False})
        values['protected_success_families']=len(families)
        values['ALT_lower_UV_families']=len(alt_families)
        assert values==summary['target_feasibility_counts']
        passed=all_valid and all(values[k]>=v for k,v in protocol['minimum_delayed_value_gate'].items())
        assert passed==summary['target_feasibility_gate_passed']
        lock=read(ROOT/'work/e/bank/BANK_LOCK.json')
        bank_manifest=read(ROOT/'work/e/bank/scenario_manifest.json')
        matched=read(ROOT/'outputs/matched_campaign_protocol.json')
        model_proof=read(ROOT/'outputs/frozen_input_verification.json')
        frozen_checks={'frozen_matched_protocol_sha256':sha(ROOT/'outputs/matched_campaign_protocol.json')=='a2d18b90656d541b29ca35062503b2bc6156aee28e1f5a794b392e91b35a3aa7',
         'frozen_controller_sources':all(sha(ROOT/p)==h for p,h in matched['source_sha256'].items()),
         'all_62_scenario_files':len(lock['scenario_file_sha256'])==62 and all(sha(ROOT/'work/e/bank/scenarios'/n)==h for n,h in lock['scenario_file_sha256'].items()),
         'locked_file_set':set(lock['scenario_file_sha256'])=={p.name for p in (ROOT/'work/e/bank/scenarios').glob('*.json')},
         'bank_manifest':sha(ROOT/'work/e/bank/scenario_manifest.json')==lock['manifest_sha256'],
         'bank_sanity_report':sha(ROOT/'work/e/bank/sanity_report.json')==lock['sanity_report_sha256'],
         'network':sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json')==bank_manifest['frozen_asset_hashes']['federation_network_sha256'],
         'metadata':sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')==bank_manifest['frozen_asset_hashes']['federation_metadata_sha256'],
         'model_root_files':all(sha(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'/n)==h for n,h in model_proof['model_files'].items())}
        assert all(frozen_checks.values())
        write(OUT/'Fresh_Frozen_Preservation.json',{'checks':frozen_checks,'all_passed':True,'new_model_or_PF_calls':0})
        write(OUT/'Supported_Executed_Root_Contrasts.json',contrasts)
        write(OUT/'Independent_Identity_State_Scope_Selection_Cost_Audit.json',{
          'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_closed_member_hashes_and_mechanical_gates_passed':True,
          'verified_scientific_members':len(manifest),'exact_declared_branch_identities':len(records),
          'verified_all_table_per_bus_state_inputs':inputs,'verified_candidate_label_rows':candidate_rows,
          'literal_new_committed_selection_checks':selected_checks,'reused_complete_prior_guarded_branches':reused,
          'complete_physical_measurements':sum(r['status']=='complete_verified_measurement' for r in records.values()),
          'retained_other_statuses':{s:sum(r['status']==s for r in records.values()) for s in sorted({r['status'] for r in records.values()})},
          'target_feasibility_counts':values,'target_feasibility_gate_passed':passed,
          'all_source_input_identity_and_cost_arithmetic_checked':True,'new_model_calls':0,'new_PF_calls':0,
          'original_failure_costs_separate':protocol['prior_schema_readiness_failure_costs'],
          'prior_native_replay_readiness_one_PF_return_separate':protocol['prior_guarded_readiness_costs'],
          'prior_retained_ten_prefix_measurement_returns_separate':protocol['prior_control_scope_failure_costs'],
          'native_replay_contract_and_OV_discrepancies_disclosed':protocol['native_replay_contract'],
          'literal_original_DSE_preserved_separately':True,'common_guarded_G_DSE_settings_and_original_selector_verified':True,'LLM_superiority_established':False})
        text=f'''# TRAIN trajectory measurement results

The external reader verified {len(records)} exact declared branch identities, {inputs} physical observation inputs, {candidate_rows} recorded candidate outcomes, and the original portfolio selector and both-branch cost arithmetic. It performed zero new solver/model calls. Physical observation derivation and continuous replay were actual separately charged numerical work in the collection.

Protected nontrivial episode worlds: {values['nontrivial_protected_success_worlds']}; represented families: {values['protected_success_families']}; informative distinct-first-action root pairs: {values['same_root_distinct_first_action_informative_pairs']}; protected-versus-nonprotected pairs: {values['protected_vs_nonprotected_terminal_pairs']}. The predeclared target-feasibility gate is {'passed, permitting method design only' if passed else 'not passed; no episode-recovery model training is justified by this collection'}.

Four original guarded searches were reused; 58 genuinely missing guarded branches were planned. The literal unguarded D-SE dataset is preserved separately, and this dataset is labelled G-DSE. The nullable-field readiness failure, its one real solver return and all unexecuted records remain preserved separately. Current table fields are measured data; missing fields are explicit tags, never zero-imputed. Candidate outcomes are one-step labels only. Root contrasts contain outcomes of actual executed sequences; no unexecuted candidate has a fabricated episode reward.

Native and current OV display counters are retained separately at numerically equal 1.05 boundaries; they are not asserted equal. All per-bus UV memberships remain exact, and continuous voltages/metrics agree within1e-10. Current full-table observations receive their own strict independent replay. Original solver, score, verifier, selector and1.05+1e-8 common guard remain unchanged. The first failed reuse-readiness attempt had one real solver return and zero new controller searches; its closed source/data package is preserved separately.

This is historical TRAIN development data, not independent confirmation, LLM performance, novelty or superiority. Exact physical input and branch costs are retained. Previously evaluated validation cases and the sealed bank remain excluded. The stopped VCSA intervention remains stopped.
'''
        (OUT/'Results.md').write_text(text,encoding='utf-8')
        package={}
        def add(path,name):
            name=name.replace('\\','/')
            assert '\\' not in name and name not in package;package[name]=path
        for n in manifest:add(DATA/n,'collection/'+n)
        add(DATA/'manifest.json','collection/manifest.json')
        for p in OUT.glob('*'):
            if p.is_file() and p.suffix in ('.json','.md'):add(p,'external_audit/'+p.name)
        for n in protocol['frozen_source_sha256']:add(ROOT/n,'sources/'+n)
        add(Path(__file__),'sources/work/'+Path(__file__).name)
        for w in protocol['worlds']:add(ROOT/w['path'],'inputs/'+w['path'])
        for w in protocol['worlds']:
            for b,r in w['existing_branches'].items():add(ROOT/r['path'],'prior_individual_guarded_reference/'+Path(r['path']).name)
        add(ROOT/'outputs/llm_value_stage3_development/partial_external_analysis_v2/Action_Scope_and_Cost_Audit.json','prior_individual_guarded_reference/Partial_Campaign_Limits.json')
        add(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json','inputs/network.json')
        add(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json','inputs/metadata.json')
        reference=ROOT/'outputs/actual_DSE_development_reference'
        for n in read(reference/'Verified_Scientific_Manifest.json'):add(reference/n,'prior_verified_DSE_reference/'+n)
        add(reference/'Verified_Scientific_Manifest.json','prior_verified_DSE_reference/Verified_Scientific_Manifest.json')
        for n in read(old/'manifest.json'):add(old/n,'prior_schema_readiness_failure/'+n)
        add(old/'manifest.json','prior_schema_readiness_failure/manifest.json')
        for n,h in read(old/'protocol.json')['frozen_source_sha256'].items():
            assert sha(ROOT/n)==h;add(ROOT/n,'prior_schema_readiness_sources/'+n)
        preparation=DATA
        for name in ('New_Guard_Observer_Software_Gates.json','Program_Adaptation_Manifest.json','External_Reader_Readiness.json','Native_Replay_Control_Repair_Decision.json','Native_Replay_Software_and_Saved_Root_Gates.json','Control_Scope_Repair_and_Actual_State_Reuse.json'):
            add(preparation/name,'observer_preparation/'+name)
        descriptor={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in package.items()}
        write(OUT/'Supplement_Manifest.json',descriptor)
        archive=OUT/'Guarded_TRAIN_Trajectory_Measurement_Supplement.zip'
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for n,p in package.items():z.write(p,n)
            z.write(OUT/'Supplement_Manifest.json','Supplement_Manifest.json')
        with zipfile.ZipFile(archive) as z:
            names=z.namelist();assert len(names)==len(set(names))==len(package)+1 and z.testzip() is None
            for n,m in descriptor.items():data=z.read(n);assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
        write(OUT/'Local_Archive_Audit.json',{'unique_members':len(package)+1,'CRC_and_every_member_hash_passed':True,
               'bytes':archive.stat().st_size,'sha256':sha(archive),'local_only':True,'private_export':False})
        print('EXTERNAL_GUARDED_TRAIN_DATA_AUDIT_AND_LOCAL_SEAL_COMPLETE',passed)
    finally:pp.runpp=originalPF
if __name__=='__main__':audit()
