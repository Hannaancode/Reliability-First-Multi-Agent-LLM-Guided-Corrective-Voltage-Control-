import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
home = Path(r'C:\Users\HOME')
candidates = [
    home / 'AppData/Local/Google/Cloud SDK/google-cloud-sdk/bin/gcloud.cmd',
    Path(r'C:\Program Files\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd'),
    Path(r'C:\Program Files (x86)\Google\Cloud SDK\google-cloud-sdk\bin\gcloud.cmd'),
]
print('AUTH_DISCOVERY_ONLY: no token or credential values will be displayed', flush=True)
found = shutil.which('gcloud')
for candidate in candidates:
    if candidate.is_file():
        found = str(candidate)
        break
print('GCLOUD_EXECUTABLE', found, flush=True)
adc = home / 'AppData/Roaming/gcloud/application_default_credentials.json'
print('ADC_DEFAULT_PATH_PRESENT', adc.is_file(), flush=True)
if adc.is_file():
    data = json.loads(adc.read_text(encoding='utf-8'))
    print('ADC_TYPE', data.get('type', 'unspecified'), flush=True)
    print('ADC_HAS_REFRESH_TOKEN', bool(data.get('refresh_token')), flush=True)
    print('ADC_HAS_CLIENT_CONFIGURATION', bool(data.get('client_id') and data.get('client_secret')), flush=True)
    print('ADC_CONFIGURED_SCOPES', data.get('scopes', 'not recorded'), flush=True)
    del data
print('ADC_OVERRIDE_PRESENT', bool(os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')), flush=True)
for module in ['google.auth', 'requests', 'google_colab_cli']:
    try:
        print('MODULE_PRESENT', module, importlib.util.find_spec(module) is not None, flush=True)
    except ModuleNotFoundError:
        print('MODULE_PRESENT', module, False, flush=True)
for name in ['colab', 'wsl', 'gcloud']:
    print('PATH_EXECUTABLE', name, shutil.which(name), flush=True)
if found:
    env = os.environ.copy()
    env['CLOUDSDK_CORE_DISABLE_FILE_LOGGING'] = 'true'
    env['CLOUDSDK_CORE_DISABLE_USAGE_REPORTING'] = 'true'
    try:
        result = subprocess.run([found, '--version'], capture_output=True, env=env, timeout=30, shell=False)
        print('GCLOUD_VERSION_EXIT', result.returncode, flush=True)
        print(result.stdout.decode('utf-8', errors='replace')[:1500], flush=True)
    except subprocess.TimeoutExpired:
        print('GCLOUD_VERSION_TIMEOUT', flush=True)
