"""New orchestration around saved DFF/HG-VF functions and validated DFF-ALT.

No frozen source/model/scenario file is modified. This is not a reconstructed
controller: all original candidate, verifier, ranking and model-prompt functions
come from the saved sources via the audited definition loader.
"""
from pathlib import Path
import argparse,copy,hashlib,json,math,os,random,time,traceback,sys,warnings
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True)
warnings.filterwarnings('ignore') # same global setting as the saved base runner
os.environ['HF_HOME']=str(Path('cache/huggingface').resolve())
os.environ['UNSLOTH_DISABLE_STATISTICS']='1'
os.environ['HF_HUB_OFFLINE']='1'
import numpy as np
import torch
from unsloth import FastLanguageModel
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack,AUDIT
from dff_alt import build_dff_alt
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def strict_json(value,paths=None,path='$'):
    paths=[] if paths is None else paths
    if isinstance(value,float) and not math.isfinite(value):paths.append(path);return {'nonfinite':str(value)}
    if isinstance(value,dict):return {str(k):strict_json(v,paths,path+'.'+str(k)) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [strict_json(v,paths,path+f'[{i}]') for i,v in enumerate(value)]
    return value
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix(path.suffix+'.tmp')
    paths=[];encoded=strict_json(value,paths)
    if paths and isinstance(encoded,dict):encoded['nonfinite_value_paths']=paths
    temp.write_text(json.dumps(encoded,indent=2,default=str,allow_nan=False),encoding='utf-8');temp.replace(path)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--historical-smoke',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    protocol_path=Path('outputs/matched_campaign_protocol.json');protocol=json.loads(protocol_path.read_text())
    for name,expected in protocol['source_sha256'].items():assert sha(name.replace('\\','/'))==expected,'Frozen source hash mismatch '+name
    lock=json.loads((ROOT/'bank/BANK_LOCK.json').read_text());manifest=json.loads((ROOT/'bank/scenario_manifest.json').read_text())
    assert sha(ROOT/'bank/scenario_manifest.json')==lock['manifest_sha256']
    assert manifest['bank_digest_sha256']==lock['bank_digest_sha256']==protocol['bank_digest']
    for name,h in lock['scenario_file_sha256'].items():assert sha(ROOT/'bank/scenarios'/name)==h
    files=sorted((ROOT/'bank/scenarios').glob('*.json'));assert {p.name for p in files}==set(lock['scenario_file_sha256']) and len(files)==62
    assert sha(ROOT/'pack/testbeds/federation_4mg_ieee118.json')==manifest['frozen_asset_hashes']['federation_network_sha256']
    assert sha(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')==manifest['frozen_asset_hashes']['federation_metadata_sha256']
    adapter=ROOT/'pack/models/zone_agent_shared_lora_qwen05b_ultra_v1';inputs=json.loads(Path('outputs/frozen_input_verification.json').read_text())
    for n,h in inputs['model_files'].items():assert sha(adapter/n)==h
    env=json.loads(Path('outputs/remote_frozen_environment.json').read_text());assert env['model_loaded'] and env['base_revision_verified']==protocol['base_revision']
    dependency_check=json.loads(Path('outputs/exact_dependency_check.json').read_text());assert not dependency_check['differences'] and dependency_check['checked_count']==111
    v2,runner,ref=load_stack();runner.base_runner.__dict__['torch']=torch
    assert runner.MAX_ITERATIONS==25
    model,tokenizer=FastLanguageModel.from_pretrained(model_name=str(adapter),max_seq_length=4096,dtype=None,load_in_4bit=True)
    FastLanguageModel.for_inference(model);model.eval();torch.cuda.synchronize()
    run_alt,_=build_dff_alt(ref,runner)
    base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
    random.seed(protocol['seed']);np.random.seed(protocol['seed']);torch.manual_seed(protocol['seed']);torch.cuda.manual_seed_all(protocol['seed'])
    out=Path('outputs/historical_model_smoke' if args.historical_smoke else 'outputs/matched_campaign');out.mkdir(parents=True,exist_ok=True)
    config={'protocol_sha256':sha(protocol_path),'runner_sha256':sha(__file__),'frozen_environment':env,'exact_recorded_dependency_check':dependency_check,'source_loader_audit':AUDIT,'historical_smoke':args.historical_smoke,'model_file_hashes':inputs['model_files']}
    if (out/'config.json').exists():assert json.loads((out/'config.json').read_text())==config,'Resume config identity mismatch'
    else:save(out/'config.json',config)
    if args.historical_smoke:files=[ROOT/'pack/scenarios/federation/fed_combined_load_1p25_line_101_MG1.json']
    counts={'pf_attempts':0,'pf_returns':0,'pf_exceptions':0,'llm_calls':0,'llm_exceptions':0,'input_tokens':0,'output_tokens':0}
    runpp_original=pp.runpp;generate_original=model.generate
    def runpp_counted(*a,**kw):
        counts['pf_attempts']+=1
        try:r=runpp_original(*a,**kw);counts['pf_returns']+=1;return r
        except Exception:counts['pf_exceptions']+=1;raise
    def generate_counted(*a,**kw):
        counts['llm_calls']+=1;ids=kw.get('input_ids',a[0] if a else None);n=int(ids.numel()) if ids is not None else 0;counts['input_tokens']+=n
        try:
            r=generate_original(*a,**kw);seq=r.sequences if hasattr(r,'sequences') else r
            counts['output_tokens']+=int(seq.numel())-n;return r
        except Exception:counts['llm_exceptions']+=1;raise
    pp.runpp=runpp_counted;model.generate=generate_counted
    completed=[]
    for idx,sf in enumerate(files,1):
        result_path=out/'cases'/f'{sf.stem}.json';rng_path=out/'rng'/f'{idx:03d}.pt'
        if args.resume and result_path.exists():
            existing=json.loads(result_path.read_text());assert existing['scenario_sha256']==sha(sf) and existing['protocol_sha256']==sha(protocol_path)
            # Load only RNG checkpoints written by this same protocol and runner.
            state=torch.load(rng_path,weights_only=False,map_location='cpu');random.setstate(state['python']);np.random.set_state(state['numpy']);torch.set_rng_state(state['torch']);torch.cuda.set_rng_state_all(state['cuda']);completed.append(sf.stem);continue
        scenario=json.loads(sf.read_text());record={'scenario_id':sf.stem,'scenario_sha256':sha(sf),'protocol_sha256':sha(protocol_path),'index_1based':idx,'branches':{},'costs':{}}
        branch_calls={'DFF':lambda:ref.run_one_scenario_no_llm_fallback_first(scenario,base,zones,v2),'DFF-ALT':lambda:run_alt(scenario=scenario,base_net=base,zones=zones,v2=v2),'HG-VF':lambda:ref.run_one_scenario_two_best_v2(scenario,base,zones,v2,model,tokenizer,mode='reflection_v2')}
        for name,call in branch_calls.items():
            prior=counts.copy();torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
            try:record['branches'][name]=call()
            except Exception as exc:record['branches'][name]={'status':'exception','exception_type':type(exc).__name__,'traceback':traceback.format_exc()}
            torch.cuda.synchronize();record['costs'][name]={'wall_seconds':time.perf_counter()-start,**{k:counts[k]-prior[k] for k in counts},'peak_gpu_memory_allocated_bytes':torch.cuda.max_memory_allocated()}
        valid=all(b.get('base_converged') and b.get('final_metrics') and all(isinstance(x,(float,int)) and math.isfinite(x) for x in b['final_metrics'].values()) for b in record['branches'].values())
        record['paired_terminal_metrics_valid']=valid
        if valid:
            summaries={k:ref.summarize_result(b) for k,b in record['branches'].items()};record['summaries']=summaries;record['portfolios']={}
            assert all(b['base_metrics']==record['branches']['DFF']['base_metrics'] for b in record['branches'].values())
            for portfolio,second in [('D-SE','DFF-ALT'),('HG-SE','HG-VF')]:
                selected=ref.choose_safety_envelope(summaries['DFF'],summaries[second]);chosen=second if selected=='reflection_v2' else 'DFF'
                cost={k:record['costs']['DFF'][k]+record['costs'][second][k] for k in ['wall_seconds','pf_attempts','pf_returns','pf_exceptions','llm_calls','llm_exceptions','input_tokens','output_tokens']}
                record['portfolios'][portfolio]={'selected_branch':chosen,'summary':summaries[chosen],'charged_cost':cost}
        save(result_path,record);rng_path.parent.mkdir(parents=True,exist_ok=True)
        torch.save({'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all()},rng_path)
        completed.append(sf.stem);save(out/'progress.json',{'status':'running','completed_count':len(completed),'planned_count':len(files),'completed_ids':completed})
        print('CASE_SAVED',sf.stem,'paired_valid',valid,flush=True)
    save(out/'progress.json',{'status':'complete','completed_count':len(completed),'planned_count':len(files),'completed_ids':completed})
if __name__=='__main__':main()
