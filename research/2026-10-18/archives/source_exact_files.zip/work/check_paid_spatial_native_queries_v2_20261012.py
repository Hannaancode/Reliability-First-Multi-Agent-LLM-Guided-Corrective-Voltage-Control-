"""Actual native verifier on labelled SYNTHETIC nets with MOCK solver only.

Tests operational failure boundaries, not nonlinear physics or policy benefit.
No real runpp/model/training/forecast call, original data or source is changed.
"""
import copy,hashlib,json,os,tempfile
from contextlib import contextmanager
from datetime import datetime,timezone,timedelta
from pathlib import Path
import pandas as pd
import pandapower as pp
import paid_spatial_native_queries_v2 as binding
from paid_spatial_native_queries_v2 import NativeQueriesV2,OperationalStop
from native_continuation_preservation_v2 import EvidenceJournal
from value_normal_band_mediation import NormalUpperMediation
from frozen_physics_loader import load_stack,AUDIT
from trusted_causal_controller_snapshot import SOLVER_ROLES

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/spatial_native_query_v2_software_20261012'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
class FakeClock:
    def __init__(self):self.t=0.
    def __call__(self):return self.t
    def advance(self,t):self.t+=t

def main():
    OUT.mkdir(exist_ok=False);checks=[];mock_calls=[];native_verifier_calls=[]
    _,runner,_=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    real_pf=pp.runpp;real_write=binding.write_bytes
    @contextmanager
    def fixture(mode='return',storage=None):
        # Public numeric table construction is not a physical solved state.
        net=pp.create_empty_network()
        for _ in range(3):pp.create_bus(net,vn_kv=110.)
        net.res_bus=pd.DataFrame({'vm_pu':[.92,.94,1.0],'va_degree':[0.,0.,0.],
                                 'p_mw':[1.,1.,1.],'q_mvar':[0.,0.,0.]},index=net.bus.index)
        net['converged']=True
        clock=FakeClock();holder={}
        def mock_solver(trial,**kwargs):
            assert kwargs==SOLVER_ROLES['trial'];mock_calls.append(mode);clock.advance(2.)
            if mode=='solver_exception':raise RuntimeError('LABELLED_MOCK_NONCONVERGENCE')
            trial.res_bus.loc[:,'vm_pu']=[.94,.96,1.01]
            if mode=='nonfinite_return':trial.res_bus.at[0,'vm_pu']=float('nan')
            if mode=='deadline_cross':holder['q'].deadline=datetime.now(timezone.utc)-timedelta(seconds=1)
            return None
        pp.runpp=mock_solver
        p=Path(tempfile.mkdtemp(prefix='LABELLED_MOCK_',dir=OUT))
        protocol={'actual_query_binding_authorized':True,'scope':'GLOBAL_ORIGINAL_DFF_MENU',
                  'absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=300)).isoformat(),
                  'new_query_limit':3,'payload_byte_limit':10000000,
                  'execution_kind':'LABELLED_SOFTWARE_MOCK_NOT_PHYSICS',
                  'source_sha256':{'work/paid_spatial_native_queries.py':sha(ROOT/'work/paid_spatial_native_queries.py'),
                                   'work/paid_spatial_native_queries_v2.py':sha(ROOT/'work/paid_spatial_native_queries_v2.py')}}
        h=hashlib.sha256(json.dumps(protocol,sort_keys=True).encode()).hexdigest()
        (p/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'protocol_sha256':h,'mock_only':True}),encoding='utf8')
        journal=EvidenceJournal(p/'mock_events.jsonl',h)
        q=None
        try:
            with NormalUpperMediation(runner.rescue,1.05,1e-8) as mediation:
                original_verify=mediation.original
                def counted_verify(net,action):native_verifier_calls.append(mode);return original_verify(net,action)
                mediation.original=counted_verify
                q=NativeQueriesV2(pp,runner,{'MG1':[0,1,2]},p,journal,protocol,h);holder['q']=q
                parent=q.register(net,{'episode':'LABELLED_MOCK','remaining_slots':25},label='SYNTHETIC_ROOT_NOT_MEASURED_PHYSICS')
                q.clock=clock
                if storage is not None:q.storage_limit=q.payload_bytes+storage
                action=q.menu(parent)[0]
                yield q,parent,action,clock,p,mediation,mock_solver
        finally:
            binding.write_bytes=real_write
            if q is not None:q.close()
            journal.close();pp.runpp=real_pf
    def check(name,condition):assert condition,name;checks.append(name)
    with fixture() as (q,p,a,c,d,m,pf):
        def delayed_write(path,data):
            c.advance(7.);return real_write(path,data)
        binding.write_bytes=delayed_write
        r=q.query(p,a)
        check('native_verifier_accepts_labelled_mock_receipt',r.accepted and r.successor is not None)
        check('pure_mock_solver_time_excludes_storage',q.pf_seconds==2. and q.preservation_seconds>=21.)
        check('attempt_return_exception_arithmetic',q.pf_attempts==q.pf_returns==1 and q.pf_exceptions==0)
        r2=q.query(p,a)
        check('paid_receipt_reuse_makes_no_mock_solver_retry',r2==r and q.pf_attempts==1 and q.new_queries==1 and q.reused_receipts==1)
        restored=q.restore(r.successor)
        check('full_mock_net_and_hypothetical_process_are_preserved',len(restored['net'].res_bus)==3 and restored['process']['hypothetical_parent']==p)
        check('backend_restored_after_query',pp.runpp is pf)
    with fixture('solver_exception') as (q,p,a,c,d,m,pf):
        r=q.query(p,a)
        check('real_native_broad_catch_handles_only_mock_solver_exception',not r.accepted and r.successor is None and q.pf_exceptions==1 and q.pf_returns==0 and q.pf_seconds==2.)
        check('failed_mock_state_preserved_without_successor_claim',len(list((d/'queries').rglob('failed_trial.pkl')))==1)
        q.query(p,a)
        check('explicit_failed_receipt_is_reused_not_reexecuted',q.pf_attempts==1 and q.reused_receipts==1)
    with fixture() as (q,p,a,c,d,m,pf):
        def broken_write(path,data):
            if path.name=='trusted_local_state.pkl':raise OSError('LABELLED_MOCK_PRESERVATION_FAILURE')
            return real_write(path,data)
        binding.write_bytes=broken_write
        try:q.query(p,a)
        except OperationalStop:checks.append('I_O_failure_escapes_original_Exception_catch')
        else:raise AssertionError('I/O stop became a negative receipt')
        check('paid_return_count_retained_on_I_O_failure',q.pf_attempts==q.pf_returns==1 and q.pf_exceptions==0 and not q.receipts)
        try:q.query(p,a)
        except OperationalStop:checks.append('incomplete_paid_identity_cannot_be_retried')
        else:raise AssertionError('Scientific retry allowed')
        check('backend_restored_after_operational_stop',pp.runpp is pf and not q.inflight)
    with fixture('deadline_cross') as (q,p,a,c,d,m,pf):
        r=q.query(p,a)
        check('already_returned_state_preserved_after_deadline_cross',r.accepted and r.successor in q.handles)
        try:q.query(p,q.menu(p)[1])
        except OperationalStop:checks.append('expired_deadline_blocks_further_entry')
        else:raise AssertionError('Deadline extension')
    with fixture(storage=1) as (q,p,a,c,d,m,pf):
        r=q.query(p,a)
        check('final_return_preserved_even_when_storage_estimate_crossed',r.successor in q.handles and q.payload_bytes>q.storage_limit)
        try:q.query(p,a)
        except OperationalStop:checks.append('storage_overrun_stops_before_more_science')
        else:raise AssertionError('Storage extension')
    with fixture('nonfinite_return') as (q,p,a,c,d,m,pf):
        try:q.query(p,a)
        except OperationalStop:checks.append('nonfinite_return_preserved_but_no_false_admission')
        else:raise AssertionError('Nonfinite result admitted')
        check('nonfinite_paid_return_capsule_and_counts_retained',q.pf_returns==1 and len(q.handles)==2 and not q.receipts)
    with fixture() as (q,p,a,c,d,m,pf):
        def wrong_options(net,action):
            try:pp.runpp(copy.deepcopy(net),algorithm='bfsw')
            except Exception:return {'accepted':False,'reason':'SWALLOWED_BUG'}
        m.original=wrong_options
        try:q.query(p,a)
        except OperationalStop:checks.append('changed_solver_options_cannot_be_swallowed_or_executed')
        else:raise AssertionError('Changed kwargs became negative label')
        check('bad_kwargs_execute_zero_mock_solver_calls',q.pf_attempts==0 and not q.receipts)
    with fixture() as (q,p,a,c,d,m,pf):
        def duplicate(net,action):
            pp.runpp(copy.deepcopy(net),**SOLVER_ROLES['trial'])
            pp.runpp(copy.deepcopy(net),**SOLVER_ROLES['trial'])
        m.original=duplicate
        try:q.query(p,a)
        except OperationalStop:checks.append('unexpected_native_second_solve_is_refused')
        else:raise AssertionError('Second solve allowed')
        check('only_first_mock_call_charged_and_preserved',q.pf_attempts==1 and q.pf_returns==1 and len(q.handles)==2 and not q.receipts)
    assert pp.runpp is real_pf and not hasattr(pp,'_paid_spatial_query_owner')
    result={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'checks':checks,'check_count':len(checks),
            'source_sha256':sha(ROOT/'work/paid_spatial_native_queries_v2.py'),
            'old_source_preserved_sha256':sha(ROOT/'work/paid_spatial_native_queries.py'),
            'actual_physical_PF_model_optimizer_forecast_cloud_calls':0,
            'labelled_mock_solver_calls':len(mock_calls),'actual_native_verifier_calls_on_synthetic_nets':len(native_verifier_calls),
            'all_loaded_native_function_ASTs_unchanged':True,
            'no_actual_learning_policy_or_physical_opportunity':True,
            'limitations':['No real native nonlinear solve, real cold following trajectory or actual commit has run through this adapter.','Mock clock establishes clock boundaries, not physical latency.','No new performance/GPU campaign becomes ready from these checks.']}
    with (OUT/'Software_Readiness.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'passed_checks':len(checks),'mock_solver_calls':len(mock_calls),'actual_PF_model_calls':0}))
if __name__=='__main__':main()
