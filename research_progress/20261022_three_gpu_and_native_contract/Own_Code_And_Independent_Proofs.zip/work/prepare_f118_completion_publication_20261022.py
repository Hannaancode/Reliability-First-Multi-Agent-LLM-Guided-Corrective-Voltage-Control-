"""Curated own-code/proof publication; no raw NET, model or token data."""
import hashlib,json,re,zipfile
from pathlib import Path
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/f118_completion_publication_20261022'
def main():
    O.mkdir(exist_ok=False);sources=set((R/'work').glob('*f118*20261022.py'))
    for pattern in ['*r118*20261022.py','*published_graph118*20261022.py']:
        sources.update((R/'work').glob(pattern))
    for name in ['native_frozen_feature_environment_20261020.py','coordinate_single_owner_arguments_v2_20261022.py','correct_federation_PV_source_admission_20261022.py','verify_github_exact_snapshot_20261022.py']:
        sources.add(R/'work'/name)
    proofs=[
      'outputs/f118_encoder_readout_preparation_20261022/Protocol.json','outputs/f118_encoder_readout_preparation_20261022/Fixed_Readout_Protocol.json',
      'outputs/f118_encoder_readout_preparation_20261022/Independent_Reader_Lock.json','outputs/f118_encoder_readout_preparation_20261022/Handoff_Source_Lock.json',
      'outputs/f118_encoder_readout_preparation_20261022/Prelaunch_Causal_And_Transfer_Gates.json',
      'outputs/f118_encoder_readout_handoff_20261022/Completion.json','outputs/f118_encoder_readout_handoff_20261022/All_Coordinators_Ended.json',
      'outputs/f118_encoder_readout_independent_20261022/Independent_Audit.json','outputs/f118_fixed_encoder_readouts_20261022/Results.json',
      'outputs/f118_fixed_encoder_readout_audit_20261022/Independent_Audit.json','outputs/f118_fixed_numeric_readouts_20261022/Results.json',
      'outputs/f118_fixed_numeric_readout_audit_20261022/Independent_Audit.json',
      'outputs/published_graph118_backend_20261022/Author_Policy_Backend_Admission.json',
      'outputs/published_graph118_first_queries_preparation_20261022/Protocol.json',
      'outputs/published_graph118_first_queries_execution_20261022/Results.json',
      'outputs/published_graph118_first_queries_independent_20261022/Independent_Audit.json',
      'outputs/federation_PV_source_admission_correction_20261022/Corrected_Source_Admission.json',
      'outputs/f118_physical_and_workflow_bottlenecks_20261022/Measured_Bottlenecks.json',
      'outputs/recovered_actual_reflection118_terminal_20261022/Verified_Physical_State_Recovery.json',
      'outputs/r118_solver_contract_bridge_preparation_20261022/Protocol.json',
      'outputs/r118_solver_contract_bridge_preparation_20261022/Explicit_Human_Clarification.json',
      'outputs/r118_solver_contract_bridge_preparation_20261022/Argument_Only_Mechanical_Repair.json',
      'outputs/r118_solver_contract_bridge_coordination_20261022/Owner.log',
      'outputs/r118_solver_contract_bridge_execution_20261022/Result.json',
      'outputs/r118_solver_contract_bridge_coordination_v2_20261022/End_ACK.json',
      'outputs/r118_solver_contract_bridge_independent_20261022/Independent_Audit.json',
      'outputs/r118_solver_contract_bridge_reader_coordination_20261022/End_ACK.json',
      'outputs/r118_dff_paid_prefix_continuation_20261022/Invalidated_Engineering_Gate_Addendum.json',
      'outputs/r118_dff_paid_prefix_continuation_v2_20261022/Typed_Cache_Admission.json',
      'outputs/r118_dff_paid_prefix_continuation_v2_20261022/Continuation_Readiness.json']
    sources.update(R/p for p in proofs);files=[]
    for p in sorted(sources):
        raw=p.read_bytes();text=raw.decode('utf-8');assert not any(s.search(text) for s in SECRET),str(p)
        safe=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','ACCOUNT_IDENTIFIER_REDACTED',text).encode('utf-8')
        files.append(dict(path=p.relative_to(R).as_posix(),actual_bytes=len(raw),actual_sha256=hashlib.sha256(raw).hexdigest(),published_bytes=len(safe),published_sha256=hashlib.sha256(safe).hexdigest(),
            status='EXACT_BYTES' if raw==safe else 'ACCOUNT_IDENTIFIERS_REDACTED_COPY_ORIGINAL_UNCHANGED',raw=safe))
    pack=O/'Own_Code_And_Independent_Proofs.zip'
    with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in files:z.writestr(f['path'],f['raw'])
    with zipfile.ZipFile(pack) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)
        for f in files:assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['published_sha256']
    manifest=dict(status='PREPARED_SCREENED_COMPACT_OWN_CODE_PROOFS_NOT_RAW_BACKUP',files=[{k:v for k,v in f.items() if k!='raw'} for f in files],
        zip=dict(path=pack.name,bytes=pack.stat().st_size,sha256=hashlib.sha256(pack.read_bytes()).hexdigest()),
        excluded='Private NET/capsules, weights, credentials, cached token IDs, teacher packets, features/fit arrays and third-party source remain local. Six complete metric outputs and adverse/failed gates retained.',
        new_scientific_calls=0)
    (O/'Artifact_Index.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    listed=[]
    for local in [pack,O/'Artifact_Index.json',R/'outputs/f118_actual_completion_handoff_20261022/Results_And_Next_Decision.md',R/'outputs/f118_actual_completion_handoff_20261022/Verified_Results_And_Costs.json',R/'outputs/f118_actual_completion_handoff_20261022/Current_Resume.json']:
        raw=local.read_bytes();listed.append(dict(local=local.relative_to(R).as_posix(),path='research_progress/20261022_three_gpu_and_native_contract/'+local.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()))
    (O/'Publication_Files.json').write_text(json.dumps(listed,indent=2),encoding='utf-8')
    print(json.dumps(dict(files_in_pack=len(files),zip_bytes=pack.stat().st_size,publish_files=len(listed),new_scientific_calls=0)))
if __name__=='__main__':main()
