"""Separate source/tensor/target/static-embedding reader; no neural/PF calls."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import gzip,json,time,numpy as np,torch
from safetensors import safe_open
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
from relational_current_state_codec import encode,decode,digest
from relational_neural_input_v2 import compile_current

P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';S=P/'transition_OPT_tensor_preparation'
OUT=P/'transition_OPT_tensor_external_audit'
assert read(S/'status.json')['stage']=='complete_OPT_transition_tensor_preparation'
assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
protocol=read(S/'Preparation_Protocol.json');manifest=read(S/'Supplement_Manifest.json')
for name,m in manifest.items():
    if not name.startswith('source/'):
        assert sha(S/name)==m['sha256'] and (S/name).stat().st_size==m['bytes']
for name,h in protocol['compiler_sources'].items():assert sha(ROOT/'work'/name)==h
assert sha(ROOT/'work/prepare_action_transition_numerical_inputs.py')==protocol['source_sha256']
def rows(path):
    with gzip.open(path,'rt',encoding='utf8') as f:return [json.loads(l) for l in f]
source={r['transition_id']:r for r in rows(P/'measured_OPT_transition_inventory/Actual_OPT_Transition_Rows.jsonl.gz')}
vectors={r['transition_id']:r for r in rows(P/'OPT_transition_AC_vector_measurement/Actual_Transition_Vector_Records.jsonl.gz')}
index=read(S/'Input_Index.json');target={r['transition_id']:r for r in read(S/'Target_Index.json')};cond=read(S/'Reused_OPT_Conditioning.json')
assert len(index)==216 and {r['transition_id'] for r in index}==set(source)==set(target)
cells=0;scalar_checks=0;worlds=set();cache={}
for r in index:
    ident=r['transition_id'];src=source[ident];v=vectors[ident];t=target[ident]
    x=torch.load(S/r['path'],weights_only=True)
    assert set(x)=={'row_input','candidate_bus','q_abs_mvar','AC_direction_per_MVAr'} and digest(x)==r['input_canonical_sha256']
    inp=src['model_input'];h=src['before_observation_sha256'];assert h==r['before_sha256']
    current={k:value for k,value in inp.items() if k!='candidate_action'}
    if h not in cache:
        e=encode(current);assert decode(e)==current;cache[h]=compile_current(e,cond)
    assert x['row_input']==cache[h]
    assert x['candidate_bus']==inp['candidate_action']['bus'] and x['q_abs_mvar']==inp['candidate_action']['q_abs_mvar']
    assert x['row_input']['allowed_actions'][x['candidate_bus']][x['row_input']['original_Q_grid'].index(x['q_abs_mvar'])]
    with np.load(P/'OPT_transition_AC_vector_measurement/states'/(h+'.npz'),allow_pickle=False) as z:
        assert np.array_equal(z['dVm_per_MVAr'][:,x['candidate_bus']],x['AC_direction_per_MVAr'])
    assert t['actual_next_vm']==v['measured_next_vm'] and t['current_vm']==v['current_vm']
    assert t['analytic_next_vm']==v['analytic_next_vm'] and t['measured_delta_vm']==v['measured_delta_vm']
    assert t['measured_minus_analytic_vm']==[a-f for a,f in zip(v['measured_next_vm'],v['analytic_next_vm'])]
    assert t['original_actual_target_sha256']==digest(src['measured_target'])
    world={p['world_sha256'] for p in src['audit']['source_provenance']};assert world=={r['world_sha256']};worlds|=world
    scalar_checks+=118*5;cells+=len(x['row_input']['field_ids'])
assert len(worlds)==23 and len(cache)==193
schema=read(S/'Fixed_Schema_Labels_and_Tokens.json');emb=torch.load(S/'Fixed_Native_Schema_Embeddings.pt',weights_only=True)
base=read(ROOT/'outputs/vcsa_development/local_public_base_restoration/summary.json')
with safe_open(str(Path(base['snapshot_path'])/'model.safetensors'),framework='pt',device='cpu') as f:
    sl=f.get_slice('model.embed_tokens.weight');pool={i:sl[i:i+1].float()[0] for i in sorted({i for ids in schema['tokens'] for i in ids})}
    expected=torch.stack([torch.stack([pool[i] for i in ids]).mean(0) for ids in schema['tokens']])
assert torch.equal(emb,expected)
for (key,kind),label in zip(cond['semantic_kinds'],schema['labels']):
    assert label=='current physical schema '+' '.join(str(v) for v in json.loads(key))+' value type '+kind
summary={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'exact_OPT_transitions':216,
    'exact_current_states':193,'OPT_worlds':23,'actual_loss_side_vector_scalar_checks':scalar_checks,
    'actual_typed_current_fields_checked_with_repeated_actions':cells,'all_action_scope_cap_and_compiler_fields_match_actual_sources':True,
    'every_static_native_embedding_exact':True,'targets_and_audit_IDs_excluded_from_forward':True,
    'new_reader_contextual_model_optimizer_PF_cloud_calls':0,'held_targets_read':0,
    'reader_wall_seconds':time.perf_counter()-started,'not_neural_projection_losslessness_or_learning_evidence':True}
write(OUT/'Independent_Source_Tensor_Target_and_Embedding_Audit.json',summary)
seal(OUT,{'Independent_Source_Tensor_Target_and_Embedding_Audit.json':OUT/'Independent_Source_Tensor_Target_and_Embedding_Audit.json',
    'source/reader.py':Path(__file__)},'Verified_OPT_Transition_Tensor_Audit.zip')
write(OUT/'status.json',{'stage':'complete_OPT_tensor_external_audit','all_passed':True})
print(json.dumps(summary,indent=2))
