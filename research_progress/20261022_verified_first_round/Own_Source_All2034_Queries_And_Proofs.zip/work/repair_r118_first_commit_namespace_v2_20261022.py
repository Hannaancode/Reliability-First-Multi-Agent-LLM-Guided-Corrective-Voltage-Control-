"""Additive zero-science namespace repair; retain the failed reconstruction."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];old=R/'work/reconstruct_r118_source_first_commit_20261022.py'
with (R/'outputs/r118_source_first_commit_reconstruction_20261022/Failure.json').open('x',encoding='utf-8') as f:json.dump(dict(status='NAMEERROR_V2_BINDING_BEFORE_CONTROLLER_EXECUTION',source_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),new_PF_model_or_actual_commit_calls=0),f,indent=2)
s=old.read_text('utf-8').replace("O=R/'outputs/r118_source_first_commit_reconstruction_20261022'","O=R/'outputs/r118_source_first_commit_reconstruction_v2_20261022'")
s=s.replace('_,runner,reflection=load_stack()','v2,runner,reflection=load_stack()')
new=R/'work/reconstruct_r118_source_first_commit_v2_20261022.py';assert not new.exists();new.write_text(s,encoding='utf-8')
