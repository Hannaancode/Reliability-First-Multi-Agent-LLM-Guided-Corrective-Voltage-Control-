"""Freeze one first-required unseen ordinary query and execute zero-PF gates."""
import copy,importlib.metadata,json,time,traceback
from datetime import datetime,timezone,timedelta
from pathlib import Path
import pandapower as pp
from next_ordinary_query_core_20261019 import B,I,helpers,certificate
from certify_next_ordinary_query_20261019 import certify
from public118_slsqp_native_20261018 import R,read,put,sha
from frozen_physics_loader import load_stack,AUDIT
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from strict_saved_native_input_match_v2_20261018 import require_same
from candidate_process_evidence_utils import frozen_checks
from prepare_exact_two_paid_query_engineering_20261018 import local_closure

def main():
    B.mkdir(exist_ok=False);start=time.perf_counter()
    try:
        proof=certificate();coverage=certify();info=read(I/'Exact_Candidate_Inputs.json');h=helpers(__file__);state=h['input_state']();_,runner,_=load_stack()
        verify,actuate,native=build_verifier(runner.rescue,state['cursor']);item=info['exact_new_query_rows'][0];calls=[];backend=pp.runpp
        def stub(net,**kwargs):
            require_same(net,actuate(copy.deepcopy(state['net']),action(item['row'])));calls.append(kwargs);raise RuntimeError('SOFTWARE_ONLY_NO_NATIVE_KERNEL')
        pp.runpp=stub
        try:
            initial=copy.deepcopy(state['net']);v=verify(state['net'],action(item['row']));assert v['reason']=='pf_failed' and v['after'] is None;require_same(state['net'],initial)
        finally:pp.runpp=backend
        solver={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True};assert calls==[solver]
        put(B/'Source_Transformation_Proof.json',proof);scope=R/'work/certify_next_ordinary_query_20261019.py';source=R/'work/run_next_ordinary_query_20261019.py';reader=R/'work/audit_next_ordinary_query_20261019.py'
        put(B/'Independent_Coverage_Reader_Lock.json',{'reader_source':str(scope.relative_to(R)),'reader_sha256':sha(scope)})
        files=local_closure([Path(__file__),source,reader,scope])+[Path(x['file']) for x in AUDIT]+[R/rel for rel in coverage['evidence_sha256']]+[B/'Attempt_Coverage_Certificate.json',B/'Source_Transformation_Proof.json',B/'Independent_Coverage_Reader_Lock.json']
        protocol={'status':'FROZEN_FIRST_REQUIRED_SINGLE_ORDINARY_QUERY','created_utc':datetime.now(timezone.utc).isoformat(),'absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=900)).isoformat(),
          'exact_query_count':1,'maximum_PF_attempts':2,'maximum_storage_bytes':64*1024**2,'seed':20261019,'solver_kwargs':solver,'field_tolerance':1e-10,
          'point':info['point'],'parent_handle':info['parent'],'source_metrics':info['current_metrics'],'exact_new_query_rows':[{k:item[k] for k in ['row','point_action_key','role']}],
          'input_state_sha256':info['input_state_sha256'],'input_preparation_sha256':sha(I/'Exact_Candidate_Inputs.json'),
          'attempt_coverage_certificate':{'path':str((B/'Attempt_Coverage_Certificate.json').relative_to(R)),'sha256':sha(B/'Attempt_Coverage_Certificate.json')},
          'independent_coverage_reader_lock':{'path':str((B/'Independent_Coverage_Reader_Lock.json').relative_to(R)),'sha256':sha(B/'Independent_Coverage_Reader_Lock.json')},
          'source_input_sha256':{str(p.relative_to(R)):sha(p) for p in sorted(set(files))},'runtime_versions':{n:importlib.metadata.version(n) for n in ['numpy','scipy','pandas','pandapower']},
          'independent_reader_source':str(reader.relative_to(R)),'independent_reader_sha256':sha(reader),
          'selection':'First exact missing receipt of unchanged original breadth4/followup4 policy, ordinary receiver37Q300 at archived12UV child after hypothetical receiver43Q75. Not a fresh16UV actual commit or outcome-selected Q/width/budget.',
          'fixed_gate':'One reserved primary once plus one charged replay if converged; all118fields <=1e-10, unchanged native verifier/input/score, complete source/claim/persistent NET/cursor/registry/history/RNG/costs/cold-reader evidence. Rejection is a valid outcome. Incomplete/exception remains partial/UNKNOWN.',
          'stop':'No second primary/retry/replacement/old-owner restart/old-budget extension/actual deployment commit/model/GPU. One new absolute900second whole-workflow bound; no further science from output alone.',
          'original_resources':'Remaining13original device slots at queried child, original9Q/fullscope/cap450/no-refund/ownedstock/1.05+1e-8 protection unchanged. Simulation query only; source selected root remains16UV with15slots.',
          'limits':'Query-only development evidence, not whole-policy/DSE/LLM superiority, all-severe zeroUV or confirmation.'}
        put(B/'Protocol.json',protocol);h=helpers(__file__);codes={}
        for mode in ['fixture-warm','fixture-cold']:
            codes[mode]=h['launch'](source,mode,B/mode.replace('-','_'),protocol);assert codes[mode]==0
        codes['reader_identity']=h['launch'](reader,'identity-fixture',B/'fixture_reader',protocol);assert codes['reader_identity']==0
        put(B/'Frozen_Prelaunch.json',frozen_checks());put(B/'Readiness.json',{'status':'PASS_FIXED_SINGLE_QUERY_PRELAUNCH_ZERO_SCIENCE','fixture_exit_codes':codes,'exact_native_stub_inputs':1,'actual_cold_process_handoff':True,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-start})
        print(json.dumps({'single_query_prelaunch':'PASS','newPF':0}))
    except BaseException:
        put(B/'Preparation_Failure.json',{'traceback':traceback.format_exc(),'new_science_launched':False});raise

if __name__=='__main__':main()
