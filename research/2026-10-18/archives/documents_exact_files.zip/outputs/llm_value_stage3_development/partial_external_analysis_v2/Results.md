# Partial Stage3 action/scope/cost audit

Partial historical development. Seven complete ten-arm points, final point lacks sixCPU controls. Initial tokenization/setup and unpreserved costs prevent full deployment cost/runtime claims.

Independently checked 524 selected actions and 217 raw/cached scope entries. Zero newPF/model calls. Six missing original identities remain unknown, not failed or invented outcomes.

| Case | Comparison | Available | UV delta | Joint left/right | PF delta |
|---|---|---|---:|---|---:|
| fed_combined_load_1p25_line_35_MG1 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | -1 | True/False | -197 |
| fed_combined_load_1p25_line_35_MG1 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | -1 | True/False | -263 |
| fed_combined_load_1p25_line_35_MG1 | LoRA_fresh_guarded__minus__lowest_guarded | True | 0 | True/True | 33 |
| fed_combined_load_1p5_line_35_MG1 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | -19 | False/False | 99 |
| fed_combined_load_1p5_line_35_MG1 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | -16 | False/False | 132 |
| fed_combined_load_1p5_line_35_MG1 | LoRA_fresh_guarded__minus__lowest_guarded | True | 15 | False/False | 0 |
| fed_combined_load_1p25_line_84_MG2 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | 2 | False/True | 197 |
| fed_combined_load_1p25_line_84_MG2 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | 1 | False/False | -33 |
| fed_combined_load_1p25_line_84_MG2 | LoRA_fresh_guarded__minus__lowest_guarded | True | 2 | False/True | 263 |
| fed_combined_load_1p5_line_84_MG2 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | -14 | False/False | 33 |
| fed_combined_load_1p5_line_84_MG2 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | 13 | False/False | -198 |
| fed_combined_load_1p5_line_84_MG2 | LoRA_fresh_guarded__minus__lowest_guarded | True | 19 | False/False | -132 |
| fed_combined_load_1p25_line_127_MG3 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | -1 | True/False | -263 |
| fed_combined_load_1p25_line_127_MG3 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | -1 | True/False | -296 |
| fed_combined_load_1p25_line_127_MG3 | LoRA_fresh_guarded__minus__lowest_guarded | True | 0 | True/True | 0 |
| fed_combined_load_1p5_line_127_MG3 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | 2 | False/False | 0 |
| fed_combined_load_1p5_line_127_MG3 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | 1 | False/False | -132 |
| fed_combined_load_1p5_line_127_MG3 | LoRA_fresh_guarded__minus__lowest_guarded | True | 10 | False/False | 33 |
| fed_combined_load_1p25_line_36_MG1 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | 0 | True/True | 132 |
| fed_combined_load_1p25_line_36_MG1 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | -1 | True/False | 1 |
| fed_combined_load_1p25_line_36_MG1 | LoRA_fresh_guarded__minus__lowest_guarded | True | 0 | True/True | 231 |
| fed_combined_load_1p5_line_36_MG1 | LoRA_fresh_guarded__minus__LoRA_held_initial_guarded | True | 7 | False/False | -33 |
| fed_combined_load_1p5_line_36_MG1 | LoRA_fresh_guarded__minus__base_fresh_guarded | True | 19 | False/False | -99 |
| fed_combined_load_1p5_line_36_MG1 | LoRA_fresh_guarded__minus__lowest_guarded | False | None | None/None | None |