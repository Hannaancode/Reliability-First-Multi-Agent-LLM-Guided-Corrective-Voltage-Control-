# Genuine LoRA/base screen: no primary incremental-value advantage

The unchanged30-row historical screen completed9:03Qatar on8October2026 and passed an independent identity/selection/cost audit at9:21. Twelve genuine frozen-model batches contained48 primary query opportunities and63 actual generations including15 repairs. All model/source/case/environment/adapter gates and19 staged-manifest files passed. The owned T4 was released. The eighteen earlier controls were preserved; only twelve learned numerical rows were newly executed. Total local PF across both actual stages:1,614, zero exceptions. GPU-stage preparation solves and setup/inference timing remain separately charged; no unsupported same-hardware speed claim.

| Load | Budget | Lowest-voltage UV | LoRA raw-prefix UV | Base raw-prefix UV |
|---|---:|---:|---:|---:|
|1.25|8|4|5|4|
|1.25|32, primary|4|5|4|
|1.25|128|4|4|4|
|1.50|8|52|54|56|
|1.50|32, primary|49|54|56|
|1.50|128|43|43|43|

At the declared primary budget32, LoRA lost to lowest-voltage by1 and5 residual undervoltage buses. The mild learned action also exceeded the diagnostic normal upper band; the primary deterministic action did not. The severe LoRA action beat the weaker base/frozen-enumeration result by2 buses, but this secondary result does not establish incremental value over the fixed strong control. All secondary random/enumeration/base comparisons and deficit/voltage/cost details remain in `clean_value_screen_analysis.json`. Two historical points from one family support descriptive development only.

The predeclared four-trial bus/Q component experiment reused genuineB32 proposals with zero new model calls. It kept the same32-test allowance, original scoring/verifier/Qgrid and hardOV gate. Newly charged CPU PF:134, zero exceptions; every selected action freshly solved and matched within1e-10. LoRA bus-selection with numerical Q search tied the mild primary control atUV4 and retainedUV53 versus49 on the severe point. Base bus-selection with numerical Q search tiedUV4/49 at both points. Original raw-prefix rows remained unchanged. Better magnitude search improved some raw proposals but did not demonstrate superiority over the primary control.

These observations separate validity, location, magnitude and fallback effects; they do not justify a prompt/Q/threshold/budget sweep. The next fixed-method characterization uses exactly the eight/four-family archived inputs selected before this screen's outcomes, with every control/budget retained. Broader results remain development/training-related, not independent confirmation. Full learned closed-loop and matched security evidence remain pending their own gates. See `First_Clean_Screen_Completion_Audit.json`, `First_Clean_Screen_Results_Manifest.json`, `bus_Q_attribution/manifest.json` and `Broader_Historical_Screen_Decision.md`.
