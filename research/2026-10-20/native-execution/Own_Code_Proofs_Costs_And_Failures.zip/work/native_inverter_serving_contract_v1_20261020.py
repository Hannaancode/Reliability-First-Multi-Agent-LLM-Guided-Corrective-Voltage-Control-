"""New native inverter role: explicit absolute signed Mvar, never old shunt semantics."""
import json,math

SYSTEM = ('You are a microgrid zone agent for a NEW native inverter-control contract. '
          'This contract sets instantaneous inverter reactive power; it does not add shunts. '
          'Use only the supplied current local measurements. Positive Q injects reactive power. '
          'Return only strict JSON: {"set_inverter_q_mvar":{"BUS":NUMBER,...}} with every listed '
          'controlled bus exactly once, or {"abstain":true}. Each Q must be within the exact signed '
          'Mvar bounds supplied. Do not rescale units, invent buses, copy old shunt commands, '
          'add prose or use code fences. Abstention is legal and will remain an abstention.')

def messages(current):
    assert set(current)=={'zone','voltage_limits_pu','buses','inverters'}
    assert current['voltage_limits_pu']==[.95,1.05]
    return [{'role':'system','content':SYSTEM},
            {'role':'user','content':'CURRENT_LOCAL_STATE_JSON\n'+json.dumps(current,separators=(',',':'),allow_nan=False)}]

def _object(pairs):
    out={}
    for k,v in pairs:
        if k in out:raise ValueError('Duplicate JSON key')
        out[k]=v
    return out

def parse(text,current):
    def invalid_constant(value):raise ValueError('Nonfinite JSON constant')
    obj=json.loads(text,object_pairs_hook=_object,parse_constant=invalid_constant)
    if type(obj)!=dict:raise ValueError('Object required')
    if obj=={'abstain':True} and type(obj['abstain']) is bool:return {'kind':'abstain'}
    if set(obj)!={'set_inverter_q_mvar'} or type(obj['set_inverter_q_mvar'])!=dict:raise ValueError('Exact native schema required')
    q=obj['set_inverter_q_mvar'];bounds={str(x['bus']):(x['q_min_mvar'],x['q_max_mvar']) for x in current['inverters']}
    if set(q)!=set(bounds):raise ValueError('Every controlled bus exactly once; no extra buses')
    for bus,value in q.items():
        if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('Finite numeric Mvar required')
        low,high=bounds[bus]
        if value<low or value>high:raise ValueError('Outside exact absolute physical Mvar bounds')
    return {'kind':'native_absolute_Q_set','Q_Mvar':q}
