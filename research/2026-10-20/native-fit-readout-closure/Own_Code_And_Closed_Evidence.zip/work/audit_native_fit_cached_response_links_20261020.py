"""Additive cached-response link proof AFTER original audit ends; zero new PF/model/math solves."""
import os,json,pickle,hashlib,time,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/native_fit_teacher_execution_20261020';AUD=ROOT/'outputs/native_fit_teacher_independent_20261020';OUT=ROOT/'outputs/native_fit_cached_response_supplement_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    assert json.loads((ROOT/'outputs/native_fit_teacher_handoff_20261020/End_ACK.json').read_text())['all_dispatched_children_ended'];original=json.loads((AUD/'Independent_Audit.json').read_text());assert original['status'].startswith('PASS_');OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    np=b.np;primary=json.loads((SRC/'Result.json').read_text());manifest=json.loads((SRC/'Closed_Manifest.json').read_text());records={f['path']:f for f in manifest['files']};paid={(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True)):r for r in primary['receipts'] if r['status']=='RETURNED'};checks=[];negative=False
    def match(actual,saved):
        for name in saved.files:
            values=actual[name].select_dtypes(include=[np.number]).to_numpy(dtype=float);assert values.shape==saved[name].shape and np.allclose(values,saved[name],atol=1e-10,rtol=0,equal_nan=True)
    for world in primary['all_worlds']:
        for decision in world['steps']:
            if not decision['paid_cache_reuse']:continue
            path=ROOT/decision['directory']/'Candidate_ENV_After.pkl';rel=path.relative_to(SRC).as_posix();assert sha(path)==records[rel]['sha256']
            with path.open('rb') as f:net=pickle.load(f)['network']
            key=(signature(net),json.dumps({'algorithm':'bfsw','init':'dc'},sort_keys=True));assert key in paid;r=paid[key];proof=AUD/'replay_fields'/f'PF{r["index"]:05d}.npz';assert proof.is_file();saved=np.load(proof);match(net,saved);checks.append({'seed':world['seed'],'step':decision['step'],'paid_primary_receipt':r['index'],'independent_replay_fields_sha256':sha(proof),'status':'PASS_EXACT_NATIVE_QUERY_CACHE_TO_CHARGED_INDEPENDENT_PF_RETURN'})
            if not negative:
                corrupted=copy.deepcopy(net);corrupted.res_bus.iloc[0,corrupted.res_bus.columns.get_loc('vm_pu')]+=.0001
                try:match(corrupted,saved)
                except AssertionError:negative=True
                assert negative,'Corruptedcachefield negativecontrol must reject'
    assert len(checks)==primary['actual_costs']['paid_cache_uses'] and (negative or not checks)
    audit={'status':'PASS_ADDITIVE_ALL_CACHED_CANDIDATE_RESPONSES_LINKED_TO_ACTUAL_PAID_AND_INDEPENDENTLY_REPLAYED_NATIVE_RETURNS','source_original_audit_sha256':sha(AUD/'Independent_Audit.json'),'primary_status':primary['status'],'cached_responses_checked':len(checks),'mutated_cached_VM_negative_control_rejected':negative,'all_cached_links':checks,'original_source_claim_results_and_reader_preserved':True,'reason':'Originalreader checked eachnewreturnedPF and LP/nativecursor/guardcontinuity; it didnot explicitlylink cachedcandidate fields to a particular independentlyreplayedPFrecord. This additiveproof closes that saved-output link without rerunning anyscience or oldreader.','new_PF_derivative_LU_LP_model_optimizer_GPU_calls':0,'workflow_seconds':time.monotonic()-start};put(OUT/'Independent_Cached_Response_Link_Audit.json',audit);put(OUT/'Closed_Manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}});print('CACHED_PAID_RESPONSE_LINKS_PASS',len(checks))
if __name__=='__main__':main()
