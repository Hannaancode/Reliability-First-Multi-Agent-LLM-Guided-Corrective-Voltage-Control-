"""Lossless protocol5 ndarray CAS plus compressed packet, exact local integrity.

Numerical arrays are stored once per exact protocol5 payload. Instance IDs keep
within-packet aliases without merging distinct equal arrays. Object arrays use
normal pickle semantics. No model, policy, controller, timing budget or physics.
"""
import hashlib,io,os,pickle,re,zlib
from pathlib import Path
import numpy as np
MAGIC=b'HG_TYPED_P5_CAS_V1\0'

def digest(raw):return hashlib.sha256(raw).hexdigest()

class Store:
    def __init__(self,directory,capacity_bytes):
        self.directory=Path(directory);self.directory.mkdir(exist_ok=True)
        self.capacity_bytes=capacity_bytes;self.bytes_written=sum(p.stat().st_size for p in self.directory.rglob('*') if p.is_file())
        self.blobs=self.directory/'array_blobs';self.blobs.mkdir(exist_ok=True)
    def _write(self,path,raw):
        if self.bytes_written+len(raw)>self.capacity_bytes:raise TimeoutError('Fixed new-study preservation bound; no extension')
        assert not path.exists();temporary=path.with_name(path.name+'.pending')
        with temporary.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(temporary,path);self.bytes_written+=len(raw)
    def dump(self,path,value):
        path=Path(path);instances={};store=self
        class PacketPickler(pickle.Pickler):
            def persistent_id(self,obj):
                if not isinstance(obj,np.ndarray) or obj.dtype.hasobject:return None
                oid=id(obj)
                if oid in instances:return instances[oid][1]
                raw=pickle.dumps(obj,protocol=5);h=digest(raw);blob=store.blobs/(h+'.p5')
                if blob.exists():assert digest(blob.read_bytes())==h
                else:store._write(blob,raw)
                # Keep the original alive: reducers can otherwise create a
                # temporary array whose Python id is reused later in this dump.
                tag=('NDARRAY_PROTOCOL5',len(instances),h);instances[oid]=(obj,tag);return tag
        buffer=io.BytesIO();PacketPickler(buffer,protocol=5).dump(value)
        payload=buffer.getvalue();raw=MAGIC+hashlib.sha256(payload).digest()+zlib.compress(payload,level=3)
        store._write(path,raw);return dict(bytes=len(raw),sha256=digest(raw),codec='HG_TYPED_P5_CAS_V1')
    def load(self,path):
        raw=Path(path).read_bytes();assert raw.startswith(MAGIC),'Wrong typed-state codec'
        offset=len(MAGIC);payload=zlib.decompress(raw[offset+32:]);assert hashlib.sha256(payload).digest()==raw[offset:offset+32],'Packet checksum mismatch'
        instances={};store=self
        class PacketUnpickler(pickle.Unpickler):
            def persistent_load(self,tag):
                assert isinstance(tag,tuple) and len(tag)==3 and tag[0]=='NDARRAY_PROTOCOL5' and isinstance(tag[1],int) and tag[1]>=0 and re.fullmatch('[0-9a-f]{64}',tag[2])
                if tag[1] not in instances:
                    payload=(store.blobs/(tag[2]+'.p5')).read_bytes();assert digest(payload)==tag[2],'Array blob checksum mismatch'
                    value=pickle.loads(payload);assert isinstance(value,np.ndarray) and not value.dtype.hasobject;instances[tag[1]]=(tag[2],value)
                h,value=instances[tag[1]];assert h==tag[2],'Aliasing identifier changed payload';return value
        return PacketUnpickler(io.BytesIO(payload)).load()

def atomic_json(path,value):
    import json
    path=Path(path);assert not path.exists();tmp=path.with_name(path.name+'.pending')
    with tmp.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
