"""Sole prospective compressed reader; never launches science or old readers.

Each declared closed identity is retained, including failures. A portfolio is
assembled only from TWO independently complete physical branches. Partial,
missing or unmatched evidence stays UNKNOWN. The original study stays closed.
"""
import hashlib
import importlib.metadata
import json
import os
import re
import sys
import time
import traceback
from datetime import datetime,timezone
from pathlib import Path

from compressed_literal_DSE_independent_reader_v2 import audit_closed_job
from durable_opaque_evidence_store_v1 import EvidenceStop,inventory,local_root
from frozen_physics_loader import load_stack
from native_continuation_preservation_v2 import canonical
from paid_spatial_literal_comparator_binding_v1 import bind_literal_controls,close_full_both_portfolio
from trusted_causal_controller_snapshot import write_bytes

ROOT=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def assemble_only_complete_portfolios(protocol,records):
    """Reuse exact original selector/FULLBOTH; missing evidence never discounts."""
    _,runner,reflection=load_stack()
    binding=bind_literal_controls(reflection,runner,protocol['source_sha256'])
    portfolios={}
    for root in protocol['roots']:
        portfolios[root]={}
        for variant in ('literal','protected'):
            specs=[s for s in protocol['jobs'] if s['root']==root and s['variant']==variant]
            if len(specs)!=2 or {s['branch'] for s in specs}!={'DFF','DFF-ALT'}:
                portfolios[root][variant]={'status':'UNKNOWN','reason':'Both exact declared branches unavailable'}
                continue
            data={s['branch']:records.get(s['job_id']) for s in specs}
            if any(x is None or x['status']!='PASS_COMPLETE_SOURCE_FIELDS_PAID_REPLAY_COST_AND_CLOSURE' for x in data.values()):
                portfolios[root][variant]={'status':'UNKNOWN','reason':'At least one declared branch is partial, missing or unaudited',
                    'both_individual_branches':data,'FULL_BOTH_costs':'UNKNOWN; actual available costs retained individually'}
                continue
            roots={canonical({k:s[k] for k in ('root','variant','guard','scenario_sha256','canonical_input_signature','canonical_input_tables')}) for s in specs}
            if len(roots)!=1:raise EvidenceStop('Portfolio branches have different exact physical identity/protection')
            results={}
            costs={}
            for name,item in data.items():
                source=item['original_complete_source_check'];a=source['actual_costs']
                replay=item['additional_independent_replay_fields']['full_replay_costs_not_free']
                results[name]={'independent_physical_complete':True,'root_identity':next(iter(roots)).decode('utf8'),
                    'result':source['result']}
                costs[name]={'measurement_PF_attempts':a['new_PF_attempts'],'measurement_PF_returns':a['PF_returns'],
                    'measurement_PF_exceptions':a['PF_exceptions'],'measurement_pure_solver_seconds':a['pure_solver_seconds'],
                    'replay_PF_attempts':replay['attempts'],'replay_PF_returns':replay['returns'],
                    'replay_PF_exceptions':replay['exceptions'],'replay_pure_solver_seconds':replay['pure_solver_seconds'],
                    'whole_measurement_owner_seconds':item['whole_branch_owned_seconds'],
                    'whole_replay_owner_seconds':item['whole_replay_owned_seconds'],
                    'online_observed_original_branch_seconds':a['online_observed_original_branch_seconds']}
            combined=close_full_both_portfolio(binding,results,costs)
            portfolios[root][variant]={'status':'PASS_COMPLETE_BOTH_BRANCH_PORTFOLIO_AGGREGATION',
                **combined,'both_individual_branch_results_and_costs':data,'selected_branch_discount':False,
                'cost_columns_are_intervals_or_counts_not_additive_whole_time_components':True,
                'study_preparation_training_reader_failures_and_paid_reuse_costs_remain_separate_not_free':True,
                'LLM_value_or_all_eight_headroom_claim':False}
    return portfolios


def main():
    study=Path(sys.argv[sys.argv.index('--study')+1]).resolve()
    assert study.is_relative_to(ROOT/'outputs')
    assert study!=ROOT/'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012'
    protocol_path=study/'preparation/Protocol.json';p=read(protocol_path);ph=sha(protocol_path)
    assert p['reader_worker_path']=='work/audit_literal_DSE_compressed_study_v1.py'
    assert p['separately_prospective_genuinely_unexecuted_measurement'] is True
    for file,digest in p['source_sha256'].items():assert sha(ROOT/file)==digest,file
    assert {n:importlib.metadata.version(n) for n in p['runtime_identity']}==p['runtime_identity']
    launch=read(study/'Reader_Launch.json')
    assert launch['reader_source_sha256']==sha(Path(__file__)) and launch['protocol_sha256']==ph
    ownership_raw=(study/'Ownership_And_Costs.json').read_bytes()
    assert hashlib.sha256(ownership_raw).hexdigest()==launch['ownership_sha256']
    ownership=json.loads(ownership_raw)
    assert ownership['all_actual_science_and_replay_owners_ended'] is True
    assert {x['job_id'] for x in ownership['entries']}=={s['job_id'] for s in p['jobs']}
    assert len(p['jobs'])==len({s['job_id'] for s in p['jobs']})
    assert all(re.fullmatch('[A-Za-z0-9_-]{1,64}',s['job_id']) for s in p['jobs'])
    out=local_root(study/'compressed_independent_audit_v1');out.mkdir(exist_ok=False)
    started=time.perf_counter();code=1;results={}
    write_bytes(out/'reader.claim',canonical({'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),
        'argv':sys.argv,'protocol_sha256':ph,'source_sha256':sha(Path(__file__)),
        'new_model_PF_optimizer_calls':0}))
    def bound():
        if (time.perf_counter()-started>=p['reader_resource_seconds'] or
            datetime.now(timezone.utc)>=datetime.fromisoformat(launch['absolute_reader_deadline_utc'])):
            raise EvidenceStop('Original prospective reader bound; no automatic retry/extension')
    try:
        while not (out/'Reader_ACK.json').exists():bound();time.sleep(.2)
        ack=read(out/'Reader_ACK.json')
        assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid()
        assert ack['source_sha256']==sha(Path(__file__)) and ack['protocol_sha256']==ph
        assert ack['exact_PID_parent_command_verified'] is True
        for spec in p['jobs']:
            bound()
            item=audit_closed_job(study,spec,p,ownership,ph)
            results[spec['job_id']]=item
            write_bytes(out/(spec['job_id']+'_Verified_Record.json'),canonical(item))
        bound()
        portfolios=assemble_only_complete_portfolios(p,results)
        write_bytes(out/'All_Declared_Identities_And_FULLBOTH_Costs.json',canonical({'identities':results,'portfolios':portfolios,
            'no_selected_completed_prefix_as_evaluation_subset':True,
            'old_reference_study_status':'TERMINAL_PARTIAL_UNCHANGED',
            'old_all_eight_gate':'UNKNOWN_UNCHANGED','LLM_superiority':'UNACHIEVED',
            'global_preparation_training_failure_and_reader_costs':ownership['global_paid_and_unknown_costs']}))
        bound()
        write_bytes(out/'Independent_Audit.json',canonical({'status':'PASS_ALL_DECLARED_PRESERVED_EVIDENCE_WITH_EXPLICIT_UNKNOWNS',
            'actual_reader_pid':os.getpid(),'declared_identities':len(results),'protocol_sha256':ph,
            'new_model_PF_optimizer_calls':0,'source_sha256':p['source_sha256'],
            'reader_seconds_before_final_write':time.perf_counter()-started,
            'all_eight_success_or_LLM_advantage':'UNPROVED','automatic_training_or_rollout_allowed':False}))
        code=0
    except BaseException as exc:
        write_bytes(out/'Failure.json',canonical({'exception_type':type(exc).__name__,'message':str(exc),
            'traceback':traceback.format_exc(),'verified_job_ids_retained':list(results),
            'whole_scientific_performance_and_gates':'UNKNOWN','no_scientific_retry':True,'new_science':0}))
    finally:
        write_bytes(out/'Completion.json',canonical({'exit_code':code,'actual_pid':os.getpid(),
            'owned_seconds_before_final_manifest':time.perf_counter()-started,'new_model_PF_optimizer_calls':0,
            'final_manifest_write_and_process_exit_must_be_charged_by_actual_parent':True}))
        files=inventory(out,hashes=True)
        write_bytes(out/'Closed_Manifest.json',canonical({'exit_code':code,'members':files}))
    if code:raise SystemExit(code)


if __name__=='__main__':main()
