"""Actual Windows exclusive ACK lock, same-source bounded read, zero science."""
import ctypes,hashlib,json,threading,time
from pathlib import Path
from fourth_required_numeric_context_v2_20261019 import read_exact_launcher_ack
from public118_slsqp_native_20261018 import R,put,sha,manifest
B=R/'outputs/exact_launcher_ack_read_preparation_20261019'

def main():
    B.mkdir(exist_ok=False);path=B/'Launcher_ACK.json';payload={'actual_pid':123,'actual_parent_pid':456,'fresh_exact_PID_parent_command':True,'software_fixture':True};raw=json.dumps(payload).encode()
    k=ctypes.WinDLL('kernel32',use_last_error=True);k.CreateFileW.restype=ctypes.c_void_p
    handle=k.CreateFileW(str(path),0x40000000,0,None,1,0,None);assert handle not in (None,ctypes.c_void_p(-1).value)
    written=ctypes.c_ulong();assert k.WriteFile(ctypes.c_void_p(handle),raw,len(raw),ctypes.byref(written),None) and written.value==len(raw)
    assert k.FlushFileBuffers(ctypes.c_void_p(handle))
    def unlock():time.sleep(.4);assert k.CloseHandle(ctypes.c_void_p(handle))
    t=threading.Thread(target=unlock);t.start();actual,errors=read_exact_launcher_ack(path,maximum_seconds=2);t.join();assert actual==payload and errors.get('PermissionError',0)>0
    put(B/'Results.json',{'status':'PASS_ACTUAL_WINDOWS_EXCLUSIVE_ACK_READ_TRANSIENT_NO_PERMISSION_CHANGE','source_sha256':sha(__file__),'reader_source_sha256':sha(R/'work/fourth_required_numeric_context_v2_20261019.py'),'observed_errors':errors,'same_exact_JSON_recovered':True,'new_scientific_calls':0,'scope':'Own ACK file only; bounded read, no restart, ACL changes, alternative profile or scientific work.'});manifest(B)
    print(json.dumps({'exact_ACK':'PASS','observed_PermissionError':errors['PermissionError'],'newPF':0}))

if __name__=='__main__':main()
