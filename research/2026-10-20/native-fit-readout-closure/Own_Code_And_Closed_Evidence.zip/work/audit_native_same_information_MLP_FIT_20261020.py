"""Saved complete MLP state/fit-only normalization/direct caller costs and fresh CPU predictions."""
import os,json,hashlib,time,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/native_same_information_MLP_FIT_20261020';INPUT=ROOT/'outputs/native_fit_training_inputs_20261020';OUT=ROOT/'outputs/native_same_information_MLP_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import candidate_process_runtime
    import torch,numpy as np
    from native_same_information_MLP_20261020 import NativeMLP
    assert json.loads((ROOT/'outputs/native_same_information_MLP_coordination_20261020/End_ACK.json').read_text())['actual_owned_chain_ended'];r=json.loads((SRC/'Results.json').read_text());assert r['status'].startswith('COMPLETE_FIXED500');N=r['FIT_rows'];steps=500*math.ceil(N/32);manifest=json.loads((SRC/'Closed_Manifest.json').read_text())
    for rel,v in manifest['files'].items():assert (SRC/rel).stat().st_size==v['bytes'] and sha(SRC/rel)==v['sha256']
    prev='0'*64;updates=0
    for line in (SRC/'events.jsonl').read_text().splitlines():
        row=json.loads(line);assert row['event']['previous']==prev;prev=hashlib.sha256(json.dumps(row['event'],sort_keys=True,separators=(',',':')).encode()).hexdigest();assert row['sha256']==prev
        if row['event']['kind']=='optimizer_return':updates+=1;assert row['event']['update']==updates and row['event']['finite_gradient_tensors']==6
    assert updates==steps and r['actual_costs']['optimizer_attempts']==r['actual_costs']['optimizer_returns']==r['actual_costs']['backward_returns']==steps
    file=INPUT/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz';z=np.load(file);saved=torch.load(SRC/'final500_complete.pt',weights_only=False);assert saved['contract']['input_sha256']==sha(file);assert saved['contract']['source_sha256']==sha(ROOT/'work/run_native_same_information_MLP_FIT_20261020.py');assert saved['contract']['architecture_sha256']==sha(ROOT/'work/native_same_information_MLP_20261020.py')
    mu=np.average(z['X'],axis=0,weights=z['weight']);sd=np.maximum(np.sqrt(np.average((z['X']-mu)**2,axis=0,weights=z['weight'])),1e-8);assert np.array_equal(mu,saved['normalization']['mean']) and np.array_equal(sd,saved['normalization']['std']);assert saved['cursor']=={'completed_updates':steps,'epoch':500,'next_batch':math.ceil(N/32)}
    assert len(saved['model'])==6 and sum(t.numel() for t in saved['model'].values())==178179 and all(torch.isfinite(t).all() for t in saved['model'].values());assert len(saved['optimizer']['state'])==6
    for s in saved['optimizer']['state'].values():assert int(s['step'])==steps and torch.isfinite(s['exp_avg']).all() and torch.isfinite(s['exp_avg_sq']).all() and (s['exp_avg_sq']>=0).all()
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True);model=NativeMLP();model.load_state_dict(saved['model'],strict=True);model.eval();X=torch.tensor((z['X']-mu)/sd,dtype=torch.float32);calls=0;outputs=[]
    with torch.no_grad():
        for x in X.split(128):outputs.append(model(x));calls+=1
    actual=torch.cat(outputs);reference=torch.load(SRC/'Cold_Exact_FIT_Outputs.pt',weights_only=False)['final_FIT_actions'];assert torch.equal(actual,reference) and torch.isfinite(actual).all() and (actual.abs()<=torch.tensor(.3)).all()
    audit={'status':'PASS_INDEPENDENT_FIXED500_FINAL_MLP_COMPLETE_STATE_FIT_NORMALIZATION_FRESH_CPU_ACTION_COST_AUDIT','FIT_rows':N,'FIT_worlds':64,'parameters':178179,'actual_primary_costs':r['actual_costs'],'actual_reader_numeric_forward_calls':calls,'all6moment_steps':steps,'final_actions_all_bit_exact':True,'normalization_FIT_only':True,'DEV_confirmation_pretrained_LLM_PF_optimizer_GPU_calls':0,'no_benchmark_or_LLM_superiority_claim':True,'workflow_seconds':time.monotonic()-start};put(OUT/'Independent_Audit.json',audit);put(OUT/'Closed_Manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}});print('INDEPENDENT_STRONG_MLP_FIT_STATE_PASS')
if __name__=='__main__':main()
