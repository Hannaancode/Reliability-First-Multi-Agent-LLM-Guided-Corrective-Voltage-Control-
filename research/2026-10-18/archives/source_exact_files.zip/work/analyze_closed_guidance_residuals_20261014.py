"""New diagnostic over ALL30 already-paid closed controller checkpoints.

No old science/audit restart, model, PF, public derivative, or linear solve.
Root-linear cumulative predictions are diagnostic arithmetic, not new receipts.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import pickle
import sys
import time
import zlib
import numpy as np

R = Path(__file__).resolve().parents[1]
B = R/'outputs/closed_guidance_residuals_20261014'
S = R/'outputs/full_joint_suffix_benchmark_20261014'
G = R/'outputs/shared_domain_numeric_guidance_20261014'
J = R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012/actual'
SOURCE_SCIENCE = '1854319177489d66f3b4b59e998835f533274c4298690cf5ae0b6d363ca61edf'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p, v):
    with p.open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())

def prepare():
    B.mkdir(exist_ok=False)
    a = read(S/'partial_audit_v1/Independent_Preserved_Prefix_Audit.json')
    assert a['status'].startswith('PASS_') and a['actual_commits_checked']==a['complete_checkpoints_checked']==30
    cp = sorted((S/'actual/checkpoints').iterdir(), key=lambda p:int(p.name))
    assert [int(x.name) for x in cp]==list(range(1,31))
    inputs = [Path(__file__), S/'partial_audit_v1/Independent_Preserved_Prefix_Audit.json',
              S/'verified_partial_handoff/Local_Archive_Audit.json', G/'actual/Compiled_Causal_Guidance.json']
    inputs += [J/f'W{i}_Current_Jacobian.npz' for i in range(1,5)]
    inputs += [f for d in cp for f in [d/'Manifest.json',d/'State.zlib']]
    put(B/'Protocol.json', {'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
        'question': 'How far does the original fixed-current linear guide differ from the already-measured closed trajectory voltages, and are saved bus types changing?',
        'ALL_closed_checkpoint_ids': list(range(1,31)), 'source_input_sha256': {str(p.relative_to(R)):sha(p) for p in inputs},
        'analysis_arithmetic': 'Vroot + Sroot*(source-owned nominal support now minus original source-owned support), on all118 buses of all30 closed snapshots',
        'reported_outputs': 'All30 max/mean error, true versus root-linear UV/OV, saved bus-type differences, exact nominal deltas and paid-data provenance',
        'no_case_or_subsequence_selection': True, 'no_new_model_PF_MILP_LU_public_derivative_training_calls': True,
        'numerical_diagnostic_vector_reconstructions_planned': 30,
        'limits': 'Nonlinear coupling, active-set changes, shunt V-squared scaling, initial-donor support restriction and future receiver scopes can all matter. Correlation is not an exclusive causal explanation; this is inspected development, not a performance/learning gate.',
        'root_bus_zero_sensitivity_input_inspection_before_this_protocol': 'All4 roots had no undervoltage bus with an exactly zero sensitivity row; input inspection only, not an attainability result.',
        'scientific_owner_absolute_bound_seconds': 120., 'automatic_rollout_training_or_old_retry': False})
    print(json.dumps({'prepared':str(B),'closed_saved_states':30,'new_PF_model_calls':0}))

def pins():
    p = read(B/'Protocol.json')
    for name,h in p['source_input_sha256'].items(): assert sha(R/name)==h,name
    return p

def own(mode):
    out=B/mode; out.mkdir(exist_ok=False)
    put(out/'owner.claim', {'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),
        'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(B/'Protocol.json'),'argv':sys.argv,
        'permissions':'READ_ONLY_SAVED_DATA;ZERO_NEW_MODEL_PF_NUMERICAL_SOLVER'})
    return out

def worker():
    p=pins(); out=own('actual'); start=time.perf_counter()
    import pandapower as pp
    def blocked(*a,**kw): raise AssertionError('No new physical solving in this saved-data diagnostic')
    for name in ('runpp','runopp','rundcpp','rundcopp'): setattr(pp,name,blocked)
    d=read(G/'actual/Compiled_Causal_Guidance.json'); roots={}; packet={}; rows=[]
    for i,w in enumerate(d['worlds'],1):
        with np.load(J/f'W{i}_Current_Jacobian.npz',allow_pickle=False) as f:
            ctx={k:f[k].copy() for k in ('sensitivity','current_vm','actual_bus_types','mapping')}
        bank=np.zeros(118)
        for x in w['cursor']['owned_bank_rows']: bank[x['bus']] += -x['q_mvar']
        roots[w['world']]=(ctx,bank)
        packet[f'W{i}_sensitivity']=ctx['sensitivity'];packet[f'W{i}_vm']=ctx['current_vm'];packet[f'W{i}_types']=ctx['actual_bus_types']
    world_index={w['world']:i for i,w in enumerate(d['worlds'],1)}
    for ident in p['ALL_closed_checkpoint_ids']:
        assert time.perf_counter()-start < p['scientific_owner_absolute_bound_seconds']
        folder=S/'actual/checkpoints'/str(ident); manifest=read(folder/'Manifest.json')
        assert manifest['anchors']['source']==SOURCE_SCIENCE
        encoded=(folder/'State.zlib').read_bytes()
        assert len(encoded)==manifest['encoded_bytes'] and hashlib.sha256(encoded).hexdigest()==manifest['encoded_sha256']
        raw=zlib.decompress(encoded)
        assert len(raw)==manifest['raw_bytes'] and hashlib.sha256(raw).hexdigest()==manifest['raw_sha256']
        state=pickle.loads(raw); net=state['net'];cursor=state['cursor'];phase=state['next_phase']
        world=cursor['world'];ctx,initial=roots[world]
        assert np.array_equal(ctx['mapping'],net['_pd2ppc_lookups']['bus'])
        assert net.converged and len(net.res_bus)==118
        support=np.zeros(118)
        for owned in cursor['owned_bank_rows']:
            bank=net.shunt.loc[owned['index']]
            assert int(bank['bus'])==int(owned['bus']) and float(bank['q_mvar'])==float(owned['q_mvar'])
            support[int(bank['bus'])] += -float(bank['q_mvar'])
        delta=support-initial
        prediction=ctx['current_vm']+ctx['sensitivity']@delta
        observed=net.res_bus.loc[range(118),'vm_pu'].to_numpy()
        current_types=net['_ppc']['bus'][:,1].astype(int)
        assert np.isfinite(prediction).all() and np.isfinite(observed).all()
        error=prediction-observed
        entry={'checkpoint':ident,'world':world,'world_index':world_index[world],
            'method':phase['method'],'decision':phase['decision'],
            'committed_transitions':len(cursor['committed_transitions']),
            'max_abs_voltage_error':float(np.max(np.abs(error))),
            'mean_abs_voltage_error':float(np.mean(np.abs(error))),
            'actual_UV':int((observed<.95).sum()),'root_linear_UV':int((prediction<.95).sum()),
            'actual_tolerance_OV':int((observed>1.05+1e-8).sum()),
            'root_linear_tolerance_OV':int((prediction>1.05+1e-8).sum()),
            'bus_types_differing_from_root':np.flatnonzero(current_types!=ctx['actual_bus_types']).tolist(),
            'root_PV_to_current_PQ_buses':np.flatnonzero((ctx['actual_bus_types']==2)&(current_types==1)).tolist(),
            'root_PQ_to_current_PV_buses':np.flatnonzero((ctx['actual_bus_types']==1)&(current_types==2)).tolist(),
            'original_checkpoint_manifest_sha256':sha(folder/'Manifest.json'),
            'not_a_new_physical_measurement_or_performance_subset':True}
        for label,arr in [('delta',delta),('observed',observed),('predicted',prediction),('types',current_types)]:
            packet[f'C{ident}_{label}']=arr
        rows.append(entry)
    # Store derived arithmetic inputs and exact paid observations for a separate
    # reader; no additional reads or reinterpretation of scientific capsules.
    np.savez_compressed(out/'Derived_Diagnostic_Arrays.npz',**packet)
    put(out/'All_Checkpoint_Diagnostics.json', {'rows':rows,'all30closed_commits_retained':True,
        'numerical_diagnostic_vector_reconstructions':len(rows),'new_PF_model_MILP_LU_public_derivative_training_calls':0,
        'seconds':time.perf_counter()-start,'data_status':'INSPECTED_DEVELOPMENT_SAVED_PAID_PHYSICAL_OBSERVATIONS'})
    put(out/'Closed_Manifest.json', {'files':{x.name:sha(x) for x in out.iterdir() if x.is_file()}})
    put(out/'Result.json', {'exit_code':0,'complete_saved_diagnostic':True,'new_physics_calls':0})
    print(json.dumps({'diagnosed_closed_states':len(rows),'new_PF_model_calls':0}))

def audit():
    pins();out=own('audit');saved=read(B/'actual/All_Checkpoint_Diagnostics.json')
    assert read(B/'actual/Result.json')['exit_code']==0
    manifest=read(B/'actual/Closed_Manifest.json')
    for name,h in manifest['files'].items(): assert sha(B/'actual'/name)==h
    assert [x['checkpoint'] for x in saved['rows']]==list(range(1,31))
    with np.load(B/'actual/Derived_Diagnostic_Arrays.npz',allow_pickle=False) as f:
        for row in saved['rows']:
            i=row['checkpoint'];w=row['world_index'];s=f[f'W{w}_sensitivity'];v=f[f'W{w}_vm'];delta=f[f'C{i}_delta']
            pred=v+np.sum(s*delta[None,:],axis=1); actual=f[f'C{i}_observed'];types=f[f'C{i}_types'];root_types=f[f'W{w}_types']
            assert np.max(np.abs(pred-f[f'C{i}_predicted']))<=1e-12
            error=np.abs(pred-actual)
            assert abs(float(error.max())-row['max_abs_voltage_error'])<=1e-12
            assert abs(float(error.mean())-row['mean_abs_voltage_error'])<=1e-12
            assert row['actual_UV']==int((actual<.95).sum()) and row['root_linear_UV']==int((pred<.95).sum())
            assert row['actual_tolerance_OV']==int((actual>1.05+1e-8).sum())
            assert row['root_linear_tolerance_OV']==int((pred>1.05+1e-8).sum())
            assert row['bus_types_differing_from_root']==np.flatnonzero(types!=root_types).tolist()
            assert row['root_PV_to_current_PQ_buses']==np.flatnonzero((root_types==2)&(types==1)).tolist()
            assert row['root_PQ_to_current_PV_buses']==np.flatnonzero((root_types==1)&(types==2)).tolist()
    rows=saved['rows']
    report={'status':'PASS_ALL30_SAVED_OBSERVATION_AND_INDEPENDENT_ARITHMETIC_IDENTITIES',
        'closed_states':len(rows),'new_PF_model_MILP_LU_public_derivative_training_calls':0,
        'largest_root_linear_voltage_error':max(x['max_abs_voltage_error'] for x in rows),
        'median_checkpoint_max_error':float(np.median([x['max_abs_voltage_error'] for x in rows])),
        'states_with_UV_count_disagreement':sum(x['actual_UV']!=x['root_linear_UV'] for x in rows),
        'states_with_changed_case_bus_types':sum(bool(x['bus_types_differing_from_root']) for x in rows),
        'states_with_root_PV_to_PQ':sum(bool(x['root_PV_to_current_PQ_buses']) for x in rows),
        'not_selected_performance_or_held_confirmation':True,
        'causal_attribution':'Observed discrepancies do not exclusively identify their cause; nonlinear state dependence, voltage-dependent shunts and active masks/support restrictions require separate tests.',
        'fixed_global_MILP_surrogate_gate_remains_FAILED':True,
        'old_study_all_four_gate_remains_UNKNOWN':True,'automatic_new_model_or_physical_campaign':False}
    put(out/'Independent_Diagnostic_Audit.json',report)
    put(out/'Result.json',{'exit_code':0,'saved_diagnostic_audit':'PASS'})
    print(json.dumps(report))

if __name__=='__main__':
    cli=argparse.ArgumentParser()
    for x in ('prepare','worker','audit'):cli.add_argument('--'+x,action='store_true')
    args=cli.parse_args();assert sum(vars(args).values())==1
    if args.prepare:prepare()
    elif args.worker:worker()
    else:audit()
