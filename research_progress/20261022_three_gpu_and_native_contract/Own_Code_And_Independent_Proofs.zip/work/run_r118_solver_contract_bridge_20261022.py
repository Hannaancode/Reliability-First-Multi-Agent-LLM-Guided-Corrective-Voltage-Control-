"""Prepared ONLY: one explicitly authorized missing native80 contract call.

The old50call is never executed. This shares an already paid physical input,
so explicit clarification of the human no-repeat rule is required first.
"""
import argparse,hashlib,json,os,pickle,sys,time,zlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/r118_solver_contract_bridge_preparation_20261022';O=R/'outputs/r118_solver_contract_bridge_execution_20261022'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');args=ap.parse_args()
    if not args.execute:print('PREPARED_ONLY_REQUIRES_EXPLICIT_HUMAN_CONSTRAINT_CLARIFICATION');return
    protocol=read(P/'Protocol.json');approval=read(P/'Explicit_Human_Clarification.json')
    assert approval['approved_single_new80_measurement_and_first_verification'] and approval['protocol_sha256']==sha(P/'Protocol.json')
    assert sha(__file__)==protocol['source_hashes']['work/run_r118_solver_contract_bridge_20261022.py']
    O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    claimed=time.monotonic()
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-claimed<120;time.sleep(.1)
    ack=read(O/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    from reflection118_chronological_core_20261022 import capsule
    raw=(P/'Exact_Blocked_Input.zlib').read_bytes();assert hashlib.sha256(raw).hexdigest()==protocol['input_sha256'];net=pickle.loads(zlib.decompress(raw));before=capsule(O/'before.zlib',{'net':net})
    put(O/'Before_Call_Reservation.json',{'input':before,'solver_kwargs':protocol['new_native_kwargs'],'old50result_remains_paid_and_preserved':True,'new_contract_attempts':1})
    start=time.perf_counter();error=None
    try:pp.runpp(net,**protocol['new_native_kwargs']);assert net.converged
    except Exception as e:error={'type':type(e).__name__,'message':str(e)}
    after=capsule(O/'after.zlib',{'net':net})
    put(O/'Result.json',{'status':'NEW80_CONTRACT_RETURN_REQUIRE_FIRST_INDEPENDENT_REPLAY' if error is None else 'NEW80_CONTRACT_EXCEPTION_UNKNOWN_NO_RETRY','before':before,'after':after,'exception':error,'seconds':time.perf_counter()-start,'new_PF_attempts':1,'new_PF_returns':int(error is None),'old50calls_repeated':0,'new_model_calls':0})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
if __name__=='__main__':main()
