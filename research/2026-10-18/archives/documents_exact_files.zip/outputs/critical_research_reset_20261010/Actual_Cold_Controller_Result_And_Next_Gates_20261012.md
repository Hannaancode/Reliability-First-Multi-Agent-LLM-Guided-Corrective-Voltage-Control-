# Actual cold-controller result and next gates

The fixed L2 development engineering prefix is complete. Warm owner 5564,
cold owner 9004, replay owner 18576, coordinator 26144 and independent reader
25252 ended with exit0. The new 900-second total scientific bound was shared
across phases; its deadline was 2026-10-12T01:59:57.886596Z. No old L1 owner or
600-second budget was restarted or extended.

420 actual nonlinear PF calls returned, zero exceptions. These comprise 414
complete original first-menu trials, one current following trial, warm initial
and commitment calls, and THREE separately charged independent continuous
rebuild calls. The fresh cold process reused all 414 saved positive/negative
receipts without PF and restored the full commitment cursor/history, state and
query registries, RNG, source/input/runtime identities, costs and deadline.
One actual commitment and one following trial are verified; no full 25-step
controller or language policy was run.

The independent rebuild matched Vm, angle, P and Q exactly at the root,
committed state and following trial (maximum deltas 0.0). Exact UV memberships,
named-shunt caps, raw common/zone inputs, original Q/menu/score and common
upper 1.05+1e-8 passed. Raw OV counts remain separate near 1.05. Nine original
frozen checks passed. This proves the tested engineering prefix, not physical
optimality, improved full trajectories, generic crash recovery or LLM value.

Measured pure solver time was 32.07099230005406 seconds. Full owned phase
walltimes, including imports/setup/preservation/exit, were warm
237.61752710002474, cold 168.80501600005664 and replay 15.581196099985391 seconds.
The reader's full owned interval was 28.65968700009398 seconds. Preparation,
coordinator overhead outside phase intervals and full-path preservation repair
are separate costs; unknown costs are not zero or imputed. These timings are
not an intrinsic solver/deployment-efficiency comparison.

## Preserved packaging fault and additive repair

The original plain Windows `BASE.rglob` archive omitted 834 deep state files.
Its 512-member CRC/hash certificate described a subset and did not establish
full coverage. Original reader/source/claims/subset ZIP were retained.
After every original owner/reader ended, a preservation-only reader used
extended paths and independently joined every actual state/query file to the
closed checkpoint's expected hashes. It made zero PF/model calls. The complete
archive has 1329 members, 63,860,364 bytes, SHA256
`a6fac8bfebc1d800d752b4ef32b8ebdb5271e847bdfe6754450fed5f30b89d9e`;
CRC and every member hash passed. Reuse the certificate without rehashing each
heartbeat. Original scientific calls/results/gates were not rerun or changed.

The runtime's plain-path total-size inventory also omitted deep states. This
actual preserved prefix remains below the original 4GiB total storage bound,
verified against complete extended-path inventory. A future scientific worker
must use complete-path storage accounting before entry; this prefix does not
certify the old storage guard generically.

## Next source-closed work before performance

1. Add complete extended-path inventory and explicit storage/write cost
   accounting to a NEW future owner; preserve the completed sources. Avoid
   rescanning the entire tree for read-only cache reuses if an independently
   anchored exclusive-writer ledger can track their small journal writes.
   Such an optimization requires labelled correctness/overflow/UNKNOWN checks,
   not an assumed speed claim or a rerun of completed physics.
2. Implement the receding 25-step coordinator's irreversible commitment loop,
   legal stop rules, current-only new query ancestry, complete history/cursor,
   failed/pending identities, full persistent checkpoints and stopped-state
   behavior. No hypothetical leaf is silently committed or called a terminal
   trajectory. Solver/interruption/preservation failures stay explicit.
3. Bind unchanged original DFF, root-only DFF-ALT and `choose_safety_envelope`:
   preserve literal zero/missing behavior, both individual results and FULL
   BOTH branch costs. Also fix common protected counterparts and strong equally
   informed numerical acquisition/planning controls. Reused receipts have paid
   provenance and separate costs; they are not free online tools.
4. Before any full performance outcome, fix all eight development roots,
   source/input identities, control information/action/Q/protection scopes,
   complete economic and failure denominators, exact prospective unexecuted
   query/commitment identities, total bounds, exclusive ownership and independent
   continuous replay/reader. L1 and L2 are inspected development; never relabel
   them unused confirmation or omit adverse roots.
5. Preflight the query economics structurally before an expensive campaign.
   With equal menu sizes N, a complete depth-two beam with B first children
   needs (1+B)N trials for that decision, whereas two original root branches
   use about 2N trials. B=8 therefore gives a nominal 4.5 ratio at that decision;
   it does NOT prove episode cost or impossibility because menu sizes, early
   stopping, trajectory lengths and reuse differ. Do not assume the draft
   beam fits a full 1.5-times-BOTH-DSE economic allowance. Freeze the mechanism
   and acquisition rule from prospective information/resource reasoning; do
   not select a width from favorable L1/L2 outcomes or weaken a stopped gate.
6. Only a surviving fixed physical/numerical opportunity can justify a
   separate causal language acquisition/coordination study, matched trained
   numerical controls, real fresh inference and architecture/pretraining
   attribution. Exact same-information immediate argmax is still a ceiling:
   predicting its already known winner again is not LLM advantage. Final
   superiority still needs matched complete protected trajectories/full costs
   and genuinely unused authorized confirmation.

No current jobs or ready GPU/full-policy performance campaign remain. The
matched adapted scale intervention and all older failed/partial/stopped methods
stay stopped. Validated LLM superiority/full security and a calibrated 90%
winning probability remain unachieved.
