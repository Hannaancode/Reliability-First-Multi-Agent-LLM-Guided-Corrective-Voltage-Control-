"""Additive source-bound analysis of an omitted, immutable zero-PQ input.

No PF, recipe replay, converter, model, old-reader restart or scientific calls.
The original conservative UNKNOWN result remains untouched.
"""
import ast,copy,hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
PRIOR=ROOT/'outputs/critical_research_reset_20261010/OPT_native_current_recipe_20261011'
OUT=ROOT/'outputs/critical_research_reset_20261010/fixed_storage_recipe_binding_20261011'
CACHE=ROOT/'outputs/critical_research_reset_20261010/native_solver_cache_readset_20261011'
NETWORK=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'
PACKAGE=ROOT/'work/physics_env/Lib/site-packages/pandapower'
def read(p):return json.loads(p.read_text('utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def function(path,name):return next(n for n in ast.parse(path.read_text('utf8')).body if isinstance(n,ast.FunctionDef) and n.name==name)
def main():
 OUT.mkdir(exist_ok=False);start=time.perf_counter();prior_protocol=read(PRIOR/'Protocol.json');cache_protocol=read(CACHE/'Protocol.json')
 assert sha(NETWORK)==prior_protocol['input_sha256']['network']==cache_protocol['network_sha256']
 source={'scenario':ROOT/'work/e/pack/scripts/phase2d_iterative_blackboard_v0.py','action':ROOT/'work/e/audit/phase2g_rescue_runner.py','controller':ROOT/'work/e/audit/run_reflection_v4_safety_envelope.py','solver':ROOT/'work/e/audit/phase2g_multiagent_llm_runner.py','runpp':PACKAGE/'run.py','PQ_builder':PACKAGE/'build_bus.py','results_writer':PACKAGE/'results_bus.py'}
 write(OUT/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'source_sha256_by_role':{k:sha(p) for k,p in source.items()},'input_sha256':{'network':sha(NETWORK),'prior_rows':sha(PRIOR/'All_Current_Readset_Records.json'),'prior_results':sha(PRIOR/'Results.json'),'source_options':sha(CACHE/'Source_And_Actual_Options_Result.json')},'scope':'ONLY_ORIGINAL_FIXED_STORAGE_WITH_ZERO_P_Q_UNDER_PINNED_NO_CONTROL_PF; ALL_OTHER_UNKNOWN_REASONS_RETAINED','gate':'Require explicit immutable base storage and unmodified scenario/action/controller route; do not invent unknown native vectors or edit scientific thresholds','resource_seconds':60,'new_PF_recipe_replay_converter_model_optimizer_fit_forecast_cloud_calls':0})
 write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':'check_fixed_storage_recipe_binding_20261011.py','protocol_sha256':sha(OUT/'Protocol.json')})
 encoded=read(NETWORK)['_object']['storage'];table=json.loads(encoded['_object']);columns=table['columns'];positions={c:columns.index(c) for c in ['bus','p_mw','q_mvar','scaling','in_service']}
 assert len(table['index'])==len(table['data'])==4 and all(float(r[positions['p_mw']])==float(r[positions['q_mvar']])==0 for r in table['data'])
 assert all(r[positions['in_service']] is True and float(r[positions['scaling']])==1 for r in table['data'])
 nodes={role:function(source[role],name) for role,name in [('scenario','apply_scenario_to_net'),('action','apply_action'),('controller','run_one_scenario_no_llm_fallback_first'),('solver','run_pf')]}
 # This is a narrowly auditable closed source route, not a generic arbitrary
 # program non-mutation theorem. Source bodies are saved verbatim below.
 assert all(not any((isinstance(n,ast.Attribute) and n.attr=='storage') or (isinstance(n,ast.Constant) and n.value=='storage') for n in ast.walk(fn)) for fn in nodes.values())
 assert 'pp.create_shunt' in ast.unparse(nodes['action']) and 'run_one_scenario' not in ast.unparse(nodes['action'])
 runpp=function(source['runpp'],'runpp');defaults=dict(zip([a.arg for a in runpp.args.args][-len(runpp.args.defaults):],runpp.args.defaults))
 assert ast.literal_eval(defaults['run_control']) is False
 calls=[n for n in ast.walk(nodes['solver']) if isinstance(n,ast.Call) and ast.unparse(n.func)=='pp.runpp'];assert len(calls)==1 and not any(k.arg in ['run_control','recycle'] for k in calls[0].keywords)
 options=read(CACHE/'Source_And_Actual_Options_Result.json');assert options['proof']['raw_user_pf_options_empty'] and options['effective_options']['distributed_slack'] is False
 source_text={k:p.read_text('utf8') for k,p in source.items()}
 assert '"storage"' in source_text['PQ_builder'] and 'write_pq_results_to_element(net, ppc, element)' in source_text['results_writer']
 for role,fn in nodes.items():write(OUT/(role+'_Source_Body.json'),{'path':str(source[role].relative_to(ROOT)),'source_sha256':sha(source[role]),'body':ast.unparse(fn)})
 base=read(PRIOR/'All_Current_Readset_Records.json');updated=[]
 for row in base:
  r=copy.deepcopy(row);r['original_conservative_gate']=r['entry_field_gate'];r['storage_input_binding']='PINNED_ORIGINAL_FOUR_ZERO_PQ_ROWS_RETAINED_BY_RECIPE; not guessed or dropped'
  r['unknown_reasons']=[x for x in r['unknown_reasons'] if x!='UNOBSERVED_NONEMPTY_INPUTS:storage']
  r['entry_field_gate']='SOURCE_BOUND_INPUT_AND_EXACT_NATIVE_CURRENT' if not r['unknown_reasons'] else 'UNKNOWN'
  if r['entry_field_gate']!='UNKNOWN':assert r['recipe_physical_inputs_exact'] and r['actual_native_vector_present'] and r['native_metric_exact'] and r['native_scope_exact']
  updated.append(r)
 summary={'all262_current_occurrences_retained':len(updated)==262,'original_unknown_262_result_preserved':True,'source_bound_native_current_count':sum(r['entry_field_gate']!='UNKNOWN' for r in updated),'still_unknown_count':sum(r['entry_field_gate']=='UNKNOWN' for r in updated),'missing_native_vector_count_retained':sum(not r['actual_native_vector_present'] for r in updated),'all31_world_ids_and_held8_retention_unchanged':True,'no_held_branch_file_opened':True,'source_binding':{'original_storage_input':table,'base_storage_frame_sha256':hashlib.sha256(json.dumps(table,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'controller_path':'Scenario changes loads/lines/sgens; DFF actions only add shunts; run_control defaults false; storage stays fixed input','solver_semantics':'Source PQ builder reads table values; PF results stored separately. Source/controller witness supports original storage input, not an unobserved time-series controller.','scope_limits':'Conditional on pinned frozen native execution and unchanged inputs. No arbitrary external storage writer, OPF, time-series or run_control route is certified.'},'new_PF_model_converter_optimizer_fit_forecast_recipe_replay_cloud_calls':0,'no_actual_resume_or_physical_LLM_performance_claim':True,'no_automatic_performance_launch':True,'workflow_seconds_before_report_manifest':time.perf_counter()-start}
 assert summary['missing_native_vector_count_retained']==summary['still_unknown_count']==20
 assert time.perf_counter()-start<60
 write(OUT/'Source_Bound_Current_Records.json',updated);write(OUT/'Results.json',summary)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
 print(json.dumps({k:v for k,v in summary.items() if k!='source_binding'}))
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'actual_pid':os.getpid(),'exception':type(exc).__name__,'message':str(exc),'state':'TERMINAL_SOURCE_BINDING_PARTIAL_NO_AUTOMATIC_RETRY','new_scientific_calls':0})
  raise
