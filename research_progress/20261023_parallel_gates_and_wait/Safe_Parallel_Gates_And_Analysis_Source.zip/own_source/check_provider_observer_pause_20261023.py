"""Exact original paid commitment/context/RNG integration, no new science."""
from datetime import datetime,timezone
from reflection118_remaining_cases_core_20261023 import *
O=R/'outputs/provider_observer_pause_20261023'

def main():
    O.mkdir(exist_ok=False);began=time.monotonic();np,pp,v2,runner,reflection=setup()
    from provider_observer_pause_20261023 import without_nested_observer
    case='fed_combined_load_1p5_line_35_MG1';d=R/'outputs/r118chrono_20261022/local_controller'/case/'reflection_v2'
    calls=read(d/'Call_Order.json');warmfile=d/'First_Commit_Warm_State.zlib'
    assert warmfile.exists();expected=pickle.loads(zlib.decompress(warmfile.read_bytes()))
    put(O/'Protocol.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_NEW_OBSERVER_BINDING_GATE_USING_PAID_FIRST_COMMIT_ONLY',source_sha256=sha(R/'work/provider_observer_pause_20261023.py'),old_source_warm_checkpoint_sha256=sha(warmfile),
        gate='Unchanged actual original Reflection-v4 must reach exact saved first commitment, including all input frames, feedback/failures, result and Python/numpyRNG; source prompts and PF inputs/kwargs exact. Providers restore trace bindings on normal returns and exceptions. No new inference/solver or active-source edit.',
        microbenchmark='Fixed3 saved frame pairs under the existing style of global call observer, once with/without provider observation; not intrinsic solver or deployment timing.'))
    root=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')[0]
    base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'));zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    pi=gi=0;captured=[]
    def physics(net,**kwargs):
        nonlocal pi
        rec=calls['PF'][pi];pi+=1;assert kwargs==rec['kwargs'];frames_equal(net,saved_net(d,rec['before']));restore_exact(net,saved_net(d,rec['after']))
    def model(messages):
        nonlocal gi
        rec=calls['generations'][gi];gi+=1;assert messages==rec['messages'];return rec['text']
    def boundary(state):captured.append(state);raise FirstCommitBoundary()
    p=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json');random.seed(p['seed']);np.random.seed(p['seed'])
    oldtrace=sys.gettrace()
    try:run_original(v2,runner,reflection,read(R/root['registration']['recipe']),base,zones,without_nested_observer(model),without_nested_observer(physics),first_callback=boundary)
    except FirstCommitBoundary:pass
    assert len(captured)==1;checkpoint_equal(captured[0],expected);assert sys.gettrace() is oldtrace
    # Trace restoration must also survive a provider exception.
    def test_trace(frame,event,arg):return None
    def error():raise ValueError('LABELLED_PROVIDER_EXCEPTION_NO_SCIENCE')
    sys.settrace(test_trace)
    try:
        try:without_nested_observer(error)()
        except ValueError:pass
        assert sys.gettrace() is test_trace
    finally:sys.settrace(oldtrace)
    timings=[]
    for i in [0,1,2]:
        rec=calls['PF'][i];a=saved_net(d,rec['before']);b=saved_net(d,rec['after'])
        def check():frames_equal(a,b)
        def non_target_trace(frame,event,arg):return None
        sys.settrace(non_target_trace)
        try:
            tick=time.perf_counter();check();observed=time.perf_counter()-tick
            tick=time.perf_counter();without_nested_observer(check)();paused=time.perf_counter()-tick
        finally:sys.settrace(oldtrace)
        timings.append(dict(saved_pair=i,observed_seconds=observed,provider_paused_seconds=paused))
    put(O/'Results.json',dict(status='PASS_ACTUAL_ORIGINAL_FIRST_COMMIT_FULL_STATE_AND_TRACE_RESTORATION',paid_physics_calls_reused=pi,paid_model_responses_reused=gi,source_checkpoint_NET_feedback_failure_history_result_RNG_exact=True,exception_trace_restoration=True,fixed_saved_pair_timings=timings,
        no_new_PF_model_conversion_optimizer_calls=True,no_live_worker_source_changed=True,not_a_control_improvement_or_deployment_latency_claim=True,
        next='Future separately frozen owners may use the provider wrapper after their own actual prefix/cursor/reader gates. Current live owner remains unchanged.',workflow_seconds=time.monotonic()-began))
    put(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))
    print(json.dumps(dict(status='PASS_SOURCE_COMMIT_AND_OBSERVER_PAUSE',paid_PF_prefix=pi,paid_model_prefix=gi,timings=timings,new_scientific_calls=0)))

if __name__=='__main__':main()
