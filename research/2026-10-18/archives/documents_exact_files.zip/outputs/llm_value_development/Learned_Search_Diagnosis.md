# Actual learned-search diagnosis

Saved-trace analysis; no new inference or power-flow outcomes.

Main: 60 valid pairs; HG-SE selected DFF and exactly reproduced its saved summary in 60.
Portfolio selections: {"D-SE:DFF": 52, "HG-SE:DFF": 60, "D-SE:DFF-ALT": 8}
HG-VF executed action sources: {"llm_direct": 626, "llm_guided_refinement": 206, "safety_fallback_physics_refinement": 77}
CENTRAL-VF executed action sources: {"llm_guided_refinement": 151, "llm_direct": 367, "safety_fallback_physics_refinement": 217}

These source counts show participation, not causal incremental value.

| Pilot arm | Proposals | Final candidate-list failures | Final parse failures | Repairs | Accepted |
|---|---:|---:|---:|---:|---:|
| length_control | 32 | 4 | 0 | 17 | 24 |
| powergridqa | 32 | 2 | 0 | 23 | 18 |
| retrieval_off | 32 | 3 | 0 | 20 | 23 |

The three retrieved answers explain reactive compensation in general. They do not specify which state-dependent bus or Q to select. This is direct content inspection, not proof of irrelevance or a certified relevance score.

Normal-band endpoint diagnostics from original independent replay: {"D-SE": {"valid_selected_trajectories": 60, "terminal_original_strict_UV_zero": 60, "terminal_soft_upper_band_exceeded_beyond_1e8": 59, "terminal_both_normal_bands_met_with_1e8_diagnostic": 1, "terminal_hard_upper_limit_exceeded_beyond_1e8": 0}, "HG-SE": {"valid_selected_trajectories": 60, "terminal_original_strict_UV_zero": 59, "terminal_soft_upper_band_exceeded_beyond_1e8": 60, "terminal_both_normal_bands_met_with_1e8_diagnostic": 0, "terminal_hard_upper_limit_exceeded_beyond_1e8": 0}}. The 1e-8 labels are separate diagnostics, not changes to original strict success thresholds.

Next: clean candidate-ordering/interface validation, matched-budget numerical search controls, then frozen-model historical validation. Do not train on or tune against the reviewed bank while claiming it is untouched.
