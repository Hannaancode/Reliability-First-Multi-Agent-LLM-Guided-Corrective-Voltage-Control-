"""Independent saved-evidence reader. ZERO nonlinear/model/numerical calls.

Re-evaluates the ORIGINAL native verifier against saved solver results,
checks full actuated BEFORE inputs, all118 replay fields and every paid call.
Partial engineering is never a negative/pass policy performance result.
"""
import argparse,copy,hashlib,json,time,traceback
from pathlib import Path
import pandapower as pp
from exact_two_paid_query_engineering_20261018 import B,I,now,claim,admit,input_state,restore_state,verify_file
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import action,build_verifier
from compile_lookahead_paid_input_cache_20261014 import action_key,point_key
from strict_saved_native_input_match_v2_20261018 import require_same
from equal_operation_benchmark_v2 import decode_capsule
from audit_full_receding_linear_composed_v4_20261018 import check_query
from paid_receding_chunked_history_v2_20261018 import verify_history
from paid_joint_commit_v1 import fields
from candidate_process_evidence_utils import frozen_checks

def forbidden(*a,**k):raise AssertionError('Reader cannot perform new scientific calls')
def main():
    p=read(B/'Protocol.json');out=B/'audit';claim(out,p);begun=time.perf_counter();code=1;lock=None
    try:
        lock=LockedSourceSnapshot(B/'Protocol.json');lock.verify(p)
        for n in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,n,forbidden)
        _,runner,_=load_stack();source=input_state();assert runner.rescue.grid_metrics(source['net'])['uv_count']==17
        source_point=point_key(source['net'],source['cursor']);assert source_point==p['point']
        counts={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'new_query_PF_attempts':0,'continuous_replay_PF_attempts':0};seconds=0.;seen=set();all_messages=[];replays=[];phase_results=[];failure_phases=[]
        for phase in ('warm','cold'):
            d=B/phase
            if not d.exists():failure_phases.append(phase+'_NOT_STARTED');continue
            ack=read(B/(phase+'_End_ACK.json'));assert ack['actual_owned_chain_ended'] and sha(d/'Closed_Manifest.json')==ack['closed_manifest_sha256']
            closed=read(d/'Closed_Manifest.json')
            for rel,h in closed['members'].items():admit(p);assert sha(d/rel)==h,rel
            if ack['exit_code']!=0:failure_phases.append(phase+'_EXIT_NONZERO')
            if not (d/'scientific.jsonl').exists():continue
            previous='0'*64;intents={};returns={};exceptions={};msgs=[];phase_replays=[]
            with (d/'scientific.jsonl').open('rb') as f,(d/'capsules.bin').open('rb') as pack:
                for raw in f:
                    admit(p);e=json.loads(raw);assert e['previous_sha256']==previous and e['protocol_sha256']==sha(B/'Protocol.json');previous=hashlib.sha256(raw.rstrip(b'\n')).hexdigest();v=e['data']
                    if e['event']=='PF_intent':
                        pid=v['identity'];assert pid not in seen and v['kwargs']==p['solver_kwargs'];seen.add(pid);intents[pid]=v;counts['PF_attempts']+=1
                        context=v['context'];index=0 if phase=='warm' else 1;item=p['exact_new_query_rows'][index]
                        assert context['point']==source_point and context['action_key']==action_key(item['row'])
                        expected=build_verifier(runner.rescue,source['cursor'])[1](copy.deepcopy(source['net']),action(item['row']))
                        before=decode_capsule(pack,v['before'])['net'];require_same(expected,before)
                        which='new_query_PF_attempts' if context['phase']=='NEW_PRIMARY_QUERY' else 'continuous_replay_PF_attempts';counts[which]+=1
                        if which=='continuous_replay_PF_attempts':assert context['role']=='CHARGED_QUERY_REPLAY_NOT_A_COMMIT' and context['primary_PF_id'] in returns
                    elif e['event'] in ('PF_return','PF_exception'):
                        pid=v['PF_id'];assert pid in intents and pid not in returns and pid not in exceptions
                        if e['event']=='PF_return':
                            returns[pid]=v;counts['PF_returns']+=1;target=decode_capsule(pack,v['after'])['net'];assert bool(target.converged)==v['converged']
                            if target.converged:assert fields(target)==v['fields']
                        else:exceptions[pid]=v;counts['PF_exceptions']+=1;decode_capsule(pack,v['after'])
                        seconds+=v['seconds']
                    elif e['event']=='fixed_primary_query_closed':msgs.append(v)
                    elif e['event']=='charged_query_replay_closed':phase_replays.append(v)
                for msg in msgs:
                    node={'net':source['net'],'cursor':source['cursor'],'immutable_point_key':source_point}
                    check_query(node,msg['row'],msg,cache={},intents=intents,returns=returns,exceptions=exceptions,pack=pack,p=p,runner=runner)
                    all_messages.append(msg)
                for entry in phase_replays:
                    r=entry['receipt'];native=returns[r['PF_id']];original=returns[entry['primary_PF_id']]
                    assert all(native[k]==r[k] for k in native) and native['converged'] and original['converged']
                    delta=max(abs(native['fields'][b][k]-original['fields'][b][k]) for b in original['fields'] for k in original['fields'][b])
                    assert delta==r['maximum_field_delta'] and delta<=p['field_tolerance'];replays.append(entry)
                assert set(intents)==set(returns)|set(exceptions),'Every entered call must close; incomplete calls stay partial'
            if (d/'Result.json').exists():phase_results.append(read(d/'Result.json'))
        complete=not failure_phases and len(all_messages)==2 and len(replays)==2 and counts['PF_attempts']==4 and counts['PF_returns']==4 and counts['PF_exceptions']==0
        costs=None
        if (B/'Final_State_ACK.json').exists():
            final=restore_state(read(B/'Final_State_ACK.json'));warm=restore_state(read(B/'Warm_State_ACK.json'))
            for state in (warm,final):
                require_same(state['net'],source['net']);assert state['cursor']==source['cursor'] and state['absolute_deadline_utc']==p['absolute_deadline_utc'] and state['protocol_sha256']==sha(B/'Protocol.json')
                for a in state['closed_prefix_files']:verify_file(a)
            assert warm['next_index']==1 and final['next_index']==2 and len(final['paid_query_registry'])==2
            history=verify_history(final['history_anchor']);assert len(history)==2
            for n,entry in enumerate(history):assert entry['payload']==final['paid_query_registry'][p['exact_new_query_rows'][n]['point_action_key']]
            # Decode reservation hash-chain independently, without opening a writer.
            a=final['reservation_anchor'];ledger=R/a['path']/'events.jsonl';assert ledger.stat().st_size==a['bytes'] and sha(ledger)==a['sha256']
            previous='0'*64;reserved={};started={};closed={}
            for raw in ledger.read_bytes().splitlines():
                e=json.loads(raw);assert e['previous']==previous;previous=hashlib.sha256(raw).hexdigest();v=e['data'];key=v['point_action_key']
                if e['event']=='reserved_exact_identity_before_physics':assert key not in reserved;reserved[key]=v
                elif e['event']=='native_PF_intent_bound_to_exact_reservation':assert key in reserved and key not in started;started[key]=v
                elif e['event']=='native_PF_return_or_exception_preserved':assert key in started and key not in closed;closed[key]=v
                else:raise AssertionError('Undeclared reservation event')
            assert set(reserved)==set(started)==set(closed)==set(final['paid_query_registry']) and previous==a['last_event_sha256']
            for msg in all_messages:
                key=source_point+'|'+msg['aid'];m=msg['record']['actual_measured_receipt'];assert started[key]['PF_id']==closed[key]['PF_id']==m['PF_id']
                encoded=json.dumps(m,sort_keys=True,separators=(',',':'),allow_nan=False).encode();assert closed[key]['receipt_sha256']==hashlib.sha256(encoded).hexdigest()
            assert read(B/'cold/Cold_Restore_Proof.json')['status'].startswith('PASS_EXACT_LATEST_QUERY_ONLY_STATE')
            costs=final['cumulative_costs']
            for k,v in counts.items():assert costs[k]==v,k
            assert abs(costs['PF_seconds']-seconds)<=1e-9
            assert all(costs[k]==0 for k in ('new_model_calls','new_optimizer_steps','new_derivative_forecast_linear_solve_calls'))
        else:complete=False
        put(out/'Independent_Audit.json',{'status':'PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING' if complete else 'PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE',
            'counts':counts,'PF_seconds':seconds,'costs':costs,'query_outcomes':[{'row':m['row'],'verdict':m['record']['verdict'],'original_score':m['record']['original_score']} for m in all_messages],
            'cold_restore_verified':complete,'all118_replay_tolerance':p['field_tolerance'],'failure_or_unstarted_phases':failure_phases,'original_verifier_and_native_BEFORE_inputs_checked':True,
            'query_only_no_actual_commits':True,'new_model_PF_derivative_factor_solve_calls':0,'whole_policy_DSE_LLM_superiority':'NOT_TESTED',
            'prior_source_costs':'Retained by source references; not imputed per call, waived or pooled into a deployment speed claim.','workflow_seconds':time.perf_counter()-begun})
        put(out/'Frozen_After.json',frozen_checks());code=0
    except BaseException:put(out/'Failure.json',{'traceback':traceback.format_exc(),'no_science_retry':True})
    finally:
        if lock:lock.close()
        manifest(out)
    raise SystemExit(code)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--reader',action='store_true');a.parse_args();main()
