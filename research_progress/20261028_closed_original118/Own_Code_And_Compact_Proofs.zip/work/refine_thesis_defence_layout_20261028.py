"""Mechanical readability corrections to the new defence artifact only."""
from pathlib import Path
import json
from docx import Document
from docx.shared import Mm
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_evidence_update_20261028'
changes={
 'native1.06':'native 1.06','Case0':'Case 0','the4,396-versus4,696':'the 4,396 versus 4,696',
 'Historical500':'Historical 500','public0.5B':'public 0.5B','top3':'top three','greedy256':'greedy 256',
 'exact99%':'exact 99%','Does99%':'Does 99%',';342':'; 342','schema100%':'schema 100%',
 'accepted73':'accepted 73',':51direct,13guided,9fallback':': 51 direct, 13 guided and 9 fallback',
 'positive25-Mvar':'positive 25-Mvar','All4 original118':'All four original 118-bus',
 'public13all500numerical/published':'all 500 public 13-bus numerical and published-policy',
 'HG-VF26':'HG-VF 26','DFF51':'DFF 51','3wins1loss':'3 wins and 1 loss','OfflineHG-SE20UV':'Offline HG-SE 20 UV',
 'Public13numerical264/500whole-band':'Public 13-bus numerical 264/500 whole-band',
 'publishedDDPG363/500':'published DDPG 363/500','Two118cases':'Two 118-bus cases','strictOV':'strict OV',
 'no118case':'no 118-bus case','Published13policies':'Published 13-bus policies',
 'failedfixedgate':'failed fixed gate','fullbothcosts':'full costs of both branches',
 'original118.':'original 118-bus cases.','improves41.6667%':'improves 41.6667%',
 'to53.125%':'to 53.125%','numeric72.9167%':'numeric 72.9167%',
 'Fixedscalegate':'Fixed scale gate','fails;3Bpartial and7Bmemoryfailure':'fails; the 3B partial result and 7B memory failure',
 'NumericalDSE':'Numerical D-SE','Manuscript200-case':'Manuscript 200-case','including28impossible-metadata and25out-of-scope':'including 28 impossible-metadata and 25 out-of-scope',
 'later24-trial96-proposal':'later 24-trial, 96-proposal','rates89.3%':'rates 89.3%','and36%':'and 36%',
 'Chapter7':'Chapter 7','historical500record':'historical 500-record','Matched0.5B':'Matched 0.5B',
 'Public13matched500case':'Public 13-bus matched 500-case','reported137-scenario':'reported 137-scenario',
 'RAG99%':'RAG 99%','external118controller':'external 118-bus controller',
 'all thermal limits':'all branch thermal limits',
}
def clean(s):
    for a,b in changes.items():s=s.replace(a,b)
    return s
doc=Document(O/'Verified_Results_and_Thesis_Defence.docx')
for p in doc.paragraphs:
    updated=clean(p.text)
    if updated!=p.text:p.text=updated
for t in doc.tables:
    for row in t.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                updated=clean(p.text)
                if updated!=p.text:p.text=updated
    if t.rows[0].cells[0].text=='ID':
        t.autofit=False
        for col,w in zip(t.columns,[14,110,40]):col.width=Mm(w)
        for row in t.rows:
            for cell,w in zip(row.cells,[14,110,40]):cell.width=Mm(w)
doc.save(O/'Verified_Results_and_Thesis_Defence.docx')
def walk(obj):
    if isinstance(obj,str):return clean(obj)
    if isinstance(obj,list):return [walk(x) for x in obj]
    if isinstance(obj,dict):return {k:walk(v) for k,v in obj.items()}
    return obj
p=O/'Research_Question_Evidence_and_Defence.json'
p.write_text(json.dumps(walk(json.loads(p.read_text('utf-8'))),indent=2,ensure_ascii=False)+'\n','utf-8')
print('Readability and checklist column widths corrected; no scientific data changed.')
