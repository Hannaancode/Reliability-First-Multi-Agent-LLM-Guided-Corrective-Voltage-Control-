"""Sole raw-data extractor, byte/source claim; zero model or physics calls."""
import os,time,traceback
from datetime import datetime,timezone
import intake_pfdelta_declared_118_test_cohort_20261019 as intake
from public118_slsqp_native_20261018 import read,put,sha
def main():
    b=intake.B;p=read(b/'Protocol.json');assert read(b/'Download_Result.json')['status']=='PASS_PINNED_ALL_AUTHOR_ARCHIVE_BYTES_SHA256'
    assert sha(intake.__file__)==p['source_sha256'] and not (b/'selected36').exists()
    put(b/'Extraction_Claim.json',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'intake_source_sha256':sha(intake.__file__),'protocol_sha256':sha(b/'Protocol.json'),'started_utc':datetime.now(timezone.utc).isoformat(),'mode':'SAFE_PUBLIC_JSON_MEMBER_EXTRACTION_ZERO_SCIENCE'})
    t=time.perf_counter()
    try:
        intake.extract();m=read(b/'selected36/Input_Manifest.json');put(b/'Extraction_Completion.json',{'exit_code':0,'status':m['status'],'records':len(m['records']),'missing':m['missing'],'workflow_seconds':time.perf_counter()-t,'scientific_calls':0})
    except BaseException:put(b/'Extraction_Failure.json',{'traceback':traceback.format_exc(),'scientific_calls':0,'raw_archive_preserved':True});raise
if __name__=='__main__':main()
