"""Sole independent all-field replay, with two separately charged real PF calls."""
import hashlib,json,os,pickle,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/tpa_native_one_step_engineering_v3_20261020';OUT=SRC/'independent_audit'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();costs={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'model_optimizer_training_GPU_calls':0}
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    try:
        import sys
        sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
        import numpy as np
        import pandapower as pp
        from pandapower.pypower.makeSbus import makeSbus
        protocol=json.loads((ROOT/'outputs/tpa_native_one_step_preparation_v3_20261020/Execution_Protocol.json').read_text(encoding='utf-8'));assert sha(Path(__file__))==protocol['sources'][Path(__file__).name]
        manifest=json.loads((SRC/'Closed_Manifest.json').read_text(encoding='utf-8'))
        for f in manifest['files']:assert (SRC/f['path']).stat().st_size==f['bytes'] and sha(SRC/f['path'])==f['sha256']
        prev='0'*64;events=[]
        for line in (SRC/'Journal.jsonl').read_text(encoding='utf-8').splitlines():
            r=json.loads(line);assert r['event']['previous']==prev;raw=json.dumps(r['event'],sort_keys=True,separators=(',',':'));assert hashlib.sha256(raw.encode()).hexdigest()==r['sha256'];prev=r['sha256'];events.append(r['event'])
        assert prev==manifest['journal_last_sha256']
        result=json.loads((SRC/'Result.json').read_text(encoding='utf-8'));assert result['costs']['PF_returns']==result['costs']['policy_returns']==2
        assert sum(e['kind']=='PF_attempt' for e in events)==sum(e['kind']=='PF_return' for e in events)==2
        assert sum(e['kind']=='policy_attempt' for e in events)==sum(e['kind']=='policy_return' for e in events)==2
        raw=np.load(SRC/'Native_Raw_Action.npy');cold=np.load(SRC/'Native_Cold_Raw_Action.npy');fractions=np.load(SRC/'Native_Scaled_Fractions.npy');assert np.array_equal(raw,cold)
        independent_scaled=.5*(np.clip(raw.squeeze(),-1.,1.)+1.)*1.6-.8;assert np.array_equal(fractions,independent_scaled)
        maxima=json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text(encoding='utf-8'))['native_column_max'];checks=[]
        for index in [0,1]:
            with (SRC/f'PF{index}_before.pkl').open('rb') as f:net=pickle.load(f)
            if index==1:
                expected=np.sqrt((1.2*np.array(maxima))**2-net.sgen.p_mw.to_numpy()**2)*fractions;assert np.array_equal(expected,net.sgen.q_mvar.to_numpy())
            stored=np.load(SRC/f'PF{index}_fields.npz');costs['PF_attempts']+=1;t=time.monotonic()
            try:pp.runpp(net)
            except BaseException:costs['PF_exceptions']+=1;raise
            costs['PF_returns']+=1;assert net.converged;maximum=0.
            for name in stored.files:
                actual=net[name].select_dtypes(include=[np.number]).to_numpy(dtype=np.float64);expected=stored[name];assert actual.shape==expected.shape
                assert np.allclose(actual,expected,rtol=0.,atol=1e-9,equal_nan=True)
                finite=np.isfinite(actual)&np.isfinite(expected)
                if finite.any():maximum=max(maximum,float(np.max(np.abs(actual[finite]-expected[finite]))))
            v=net._ppc['internal']['V'];y=net._ppc['internal']['Ybus'];s=makeSbus(net._ppc['baseMVA'],net._ppc['bus'],net._ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(y@v)-s)));assert kcl<=1e-7
            checks.append({'identity':index,'all_numeric_fields_delta_max':maximum,'KCL_max_pu':kcl,'UV':int((net.res_bus.vm_pu<.95).sum()),'OV':int((net.res_bus.vm_pu>1.05).sum()),'seconds':time.monotonic()-t})
        assert time.monotonic()-start<protocol['reader_bound_seconds']
        from candidate_process_evidence_utils import frozen_checks
        put(OUT/'Frozen_After.json',frozen_checks());put(OUT/'Independent_Audit.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_NATIVE_PRIMARY_SOURCE_HASHCHAIN_ACTION_COLD_POLICY_AND_TWO_FULL_PHYSICS_REPLAYS','costs':costs,'checks':checks,'source_costs_retained':result['costs'],'workflow_seconds':time.monotonic()-start,'total_actual_PF_attempts':result['costs']['PF_attempts']+costs['PF_attempts'],'total_actual_policy_applications':2,'native_runtime_compatibility_only':True,'performance_superiority_or_generalization_claim':False})
        print(json.dumps({'independent_audit':'PASS','actual_primary_plus_replay_PF':4,'actual_TPA_policy_applications':2,'field_deltas':[r['all_numeric_fields_delta_max'] for r in checks]}))
    except BaseException as e:put(OUT/'Failure.json',{'failure_type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'costs':costs});raise
if __name__=='__main__':main()
