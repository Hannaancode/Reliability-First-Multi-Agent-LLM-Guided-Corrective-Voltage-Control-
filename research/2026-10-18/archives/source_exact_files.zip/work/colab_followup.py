"""Operate only the Colab runtime created and recorded by this task."""
import json,logging,sys,uuid,re,time
from pathlib import Path
from types import SimpleNamespace
sys.stdout.reconfigure(encoding='utf-8');logging.disable(logging.CRITICAL)
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from colab_cli.runtime import ColabRuntime
from colab_cli.contents import ContentsClient
mode=sys.argv[1];status=json.loads(Path('outputs/colab_frozen_restore_status.json').read_text());assert status['created_by_this_task'] and not status['runtime_released']
credentials=Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud\application_default_credentials.json');credentials.refresh(Request())
session=AuthorizedSession(credentials);client=Client(Prod(),session);runtime=None
try:
 assignment=client._get_assignment(uuid.UUID(status['notebook_hash']),variant=Variant.GPU,accelerator=Accelerator.T4)
 assert hasattr(assignment,'runtime_proxy_info'),'Recorded runtime is no longer assigned'
 runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-frozen-execution')
 contents=ContentsClient(SimpleNamespace(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token))
 if mode=='align':
  contents.upload('work/frozen_dependency_closure.txt','content/hiergrid_execution/work/frozen_dependency_closure.txt')
  code="""
import subprocess,os,shutil,json
from pathlib import Path
os.chdir('/content/hiergrid_execution')
log=open('outputs/dependency_alignment.log','w')
subprocess.run([shutil.which('uv'),'pip','install','--python','env/bin/python','--extra-index-url','https://download.pytorch.org/whl/cu128','--index-strategy','unsafe-best-match','-r','work/frozen_dependency_closure.txt'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([shutil.which('uv'),'pip','install','--python','env/bin/python','--reinstall','--no-deps','--index','https://pypi.org/simple','torchao==0.17.0'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['env/bin/python','work/remote_environment_check.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['env/bin/python','-c',"import importlib.metadata as m,json;from pathlib import Path;pins=[l.split('==') for l in Path('work/frozen_dependency_closure.txt').read_text().splitlines()];diff={n:{'expected':v,'actual':m.version(n)} for n,v in pins if m.version(n)!=v};Path('outputs/exact_dependency_check.json').write_text(json.dumps({'checked_count':len(pins),'differences':diff}));assert not diff"],stdout=log,stderr=subprocess.STDOUT,check=True)
log.close();print('HIERGRID_ALIGNMENT_COMPLETED')
"""
  result=runtime.execute_code(code,timeout=600)
  for out in result:
   if out.get('output_type')=='error':print('ALIGNMENT_ERROR_TYPE',out.get('ename'),flush=True)
   if 'HIERGRID_ALIGNMENT_COMPLETED' in out.get('text',''):print('ALL_RECORDED_DEPENDENCY_PINS_MATCH',flush=True)
  for name in ['dependency_alignment.log','remote_frozen_environment.json','exact_dependency_check.json']:
   try:contents.download('content/hiergrid_execution/outputs/'+name,'outputs/'+name)
   except Exception:pass
 elif mode=='smoke':
  mapping={'work/run_matched_campaign.py':'work/run_matched_campaign.py','outputs/matched_campaign_protocol.json':'outputs/matched_campaign_protocol.json','outputs/frozen_input_verification.json':'outputs/frozen_input_verification.json'}
  for local,remote in mapping.items():contents.upload(local,'content/hiergrid_execution/'+remote)
  code="""
import os,subprocess
from pathlib import Path
os.chdir('/content/hiergrid_execution')
log=open('outputs/historical_model_smoke.log','w')
proc=subprocess.Popen(['env/bin/python','work/run_matched_campaign.py','--historical-smoke'],stdout=log,stderr=subprocess.STDOUT)
print('HIERGRID_SMOKE_PROCESS_STARTED',proc.pid)
"""
  outputs=runtime.execute_code(code,timeout=30)
  for out in outputs:
   if out.get('output_type')=='stream':print(out.get('text','').strip(),flush=True)
   elif out.get('output_type')=='error':print('SMOKE_START_ERROR',out.get('ename'),flush=True)
 elif mode=='smoke-status':
  for remote,local in [('historical_model_smoke.log','historical_model_smoke.log'),('historical_model_smoke/progress.json','historical_model_smoke_progress.json'),('historical_model_smoke/cases/fed_combined_load_1p25_line_101_MG1.json','historical_model_smoke_case.json')]:
   try:contents.download('content/hiergrid_execution/outputs/'+remote,'outputs/'+local);print('DOWNLOADED',local,flush=True)
   except Exception:pass
 elif mode=='campaign':
  contents.upload('work/run_matched_campaign.py','content/hiergrid_execution/work/run_matched_campaign.py')
  code="""
import os,subprocess,json
from pathlib import Path
os.chdir('/content/hiergrid_execution')
assert json.loads(Path('outputs/historical_model_smoke/progress.json').read_text())['status']=='complete'
log=open('outputs/matched_campaign.log','w')
proc=subprocess.Popen(['env/bin/python','work/run_matched_campaign.py','--resume'],stdout=log,stderr=subprocess.STDOUT)
Path('outputs/matched_campaign_process.json').write_text(json.dumps({'pid':proc.pid,'created_by_this_task':True}))
print('HIERGRID_MATCHED_CAMPAIGN_STARTED',proc.pid)
"""
  outputs=runtime.execute_code(code,timeout=30)
  for out in outputs:
   if out.get('output_type')=='stream':print(out.get('text','').strip(),flush=True)
   elif out.get('output_type')=='error':print('CAMPAIGN_START_ERROR',out.get('ename'),flush=True)
 elif mode=='campaign-status':
  for remote,local in [('matched_campaign.log','matched_campaign.log'),('matched_campaign/progress.json','matched_campaign_progress.json'),('matched_campaign/config.json','matched_campaign_config.json')]:
   try:contents.download('content/hiergrid_execution/outputs/'+remote,'outputs/'+local)
   except Exception:pass
  progress=Path('outputs/matched_campaign_progress.json')
  if progress.exists():
   p=json.loads(progress.read_text());print('CAMPAIGN_PROGRESS',p['status'],p['completed_count'],p['planned_count'],flush=True)
   for sid in p['completed_ids']:
    dest=Path('outputs/matched_campaign/cases')/(sid+'.json')
    if not dest.exists():
     dest.parent.mkdir(parents=True,exist_ok=True)
     contents.download('content/hiergrid_execution/outputs/matched_campaign/cases/'+sid+'.json',str(dest))
     rec=json.loads(dest.read_text());print('CASE_CHECKPOINT_DOWNLOADED',sid,'valid',rec['paired_terminal_metrics_valid'],flush=True)
     rng=Path('outputs/matched_campaign/rng')/f"{rec['index_1based']:03d}.pt";rng.parent.mkdir(parents=True,exist_ok=True)
     contents.download('content/hiergrid_execution/outputs/matched_campaign/rng/'+rng.name,str(rng))
  else:print('CAMPAIGN_INITIALIZING_OR_FIRST_CASE_RUNNING',flush=True)
 elif mode=='release':
  client.unassign(assignment.endpoint);status['runtime_released']=True;Path('outputs/colab_frozen_restore_status.json').write_text(json.dumps(status,indent=2));print('TASK_CREATED_RUNTIME_RELEASED',flush=True)
 else:raise ValueError('Unknown operation')
except Exception as e:print('FOLLOWUP_FAILURE_TYPE',type(e).__name__,flush=True)
finally:
 if runtime is not None:runtime.stop()
 session.close()
