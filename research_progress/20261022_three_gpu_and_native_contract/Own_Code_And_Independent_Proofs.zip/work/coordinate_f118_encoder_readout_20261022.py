"""Own three independently assigned encoder arms, then one zero-model reader.

An account is never substituted for a failed arm. Old allocations and old
scientific sources are never restarted. The CPU readout is conditional only
on the complete frozen-feature audit, never on a favorable feature outcome.
"""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];P=R/'outputs/f118_encoder_readout_preparation_20261022'
O=R/'outputs/f118_encoder_readout_handoff_20261022'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    O.mkdir(exist_ok=False);start=time.monotonic();p=read(P/'Protocol.json');gate=read(P/'Prelaunch_Causal_And_Transfer_Gates.json')
    assert gate['status'].startswith('PASS_') and sha(__file__)==read(P/'Handoff_Source_Lock.json')['sha256']
    numeric=read(R/'outputs/f118_fixed_numeric_readouts_20261022/Results.json');assert numeric['GPU_diagnostic_admitted_by_headroom_only']
    put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    for name in ['f118_encoder_readout_execution_20261022','f118_encoder_readout_coordination_20261022']:(R/'outputs'/name).mkdir(exist_ok=False)
    jobs={};logs=[];records={}
    for arm in p['arms']:
        log=(O/(arm+'.log')).open('x',encoding='utf-8');logs.append(log)
        protocol=P/arm/'Owner_Protocol.json'
        command=[str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_f118_encoder_owner_20261022.py'),'--protocol',str(protocol.relative_to(R))]
        job=subprocess.Popen(command,cwd=R,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        jobs[arm]=job;records[arm]={'coordinator_launcher_pid':job.pid,'owner_protocol_sha256':sha(protocol)}
    put(O/'Prospective_Launches.json',records)
    while any(job.poll() is None for job in jobs.values()):
        assert time.monotonic()-start<5550,'Fixed three-owner bound, no extension'
        states={}
        for arm,job in jobs.items():
            d=R/'outputs/f118_encoder_readout_execution_20261022'/arm
            states[arm]={'coordinator_exit':job.poll()}
            for name in ['owner.claim','Launcher_ACK.json','status.json']:
                try:states[arm][name]=read(d/name)
                except (FileNotFoundError,json.JSONDecodeError):pass
        tmp=O/'Live_Status.pending';tmp.write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'arms':states}),encoding='utf-8');os.replace(tmp,O/'Live_Status.json')
        time.sleep(10)
    for log in logs:log.close()
    put(O/'All_Coordinators_Ended.json',{arm:{'launcher_pid':job.pid,'exit_code':job.returncode} for arm,job in jobs.items()})
    # The reader is partial-aware and never calls models, PF or an optimizer.
    lock=read(P/'Independent_Reader_Lock.json');assert sha(R/lock['source'])==lock['sha256']
    rp=P/'Reader_Owner_Protocol.json';assert not (R/'outputs/f118_encoder_readout_independent_20261022').exists()
    with (O/'Independent_Reader.log').open('x',encoding='utf-8') as log:
        reader=subprocess.run([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_f118_encoder_owner_20261022.py'),'--protocol',str(rp.relative_to(R))],cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=900,creationflags=subprocess.CREATE_NO_WINDOW)
    put(O/'Independent_Reader_End.json',{'coordinator_exit_code':reader.returncode})
    assert reader.returncode==0,'Preserve outside reader failure; no automatic repeat'
    audit=read(R/'outputs/f118_encoder_readout_independent_20261022/Independent_Audit.json')
    readout=None
    if audit['all3_complete'] and audit['readout_allowed']:
        fixed=read(P/'Fixed_Readout_Protocol.json');source=R/'work/fit_f118_fixed_encoder_readouts_20261022.py';assert sha(source)==fixed['readout_source_sha256']
        with (O/'Fixed_Readout.log').open('x',encoding='utf-8') as log:
            result=subprocess.run([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(source)],cwd=R,stdout=log,stderr=subprocess.STDOUT,timeout=300,creationflags=subprocess.CREATE_NO_WINDOW)
        put(O/'Fixed_Readout_End.json',{'exit_code':result.returncode});assert result.returncode==0
        readout=read(R/'outputs/f118_fixed_encoder_readouts_20261022/Results.json')
    put(O/'Completion.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'THREE_ARM_FEATURE_AND_FIXED_READOUT_COMPLETE' if readout else 'TERMINAL_PARTIAL_ENCODER_COMPARISON_UNKNOWN',
        'all3_features_complete':audit['all3_complete'],'private_readout_gate':readout.get('private_primary_gate') if readout else 'UNKNOWN',
        'no_physical_superiority_unused_confirmation_or_automatic_rollout':True,'old_studies_untouched':True,'workflow_seconds':time.monotonic()-start})
    print(json.dumps(read(O/'Completion.json')))
if __name__=='__main__':main()
