"""New bounded missing-identity measurement; never repeats a saved encoding."""
import array
import gzip
import hashlib
import json
import os
import sys
import time
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

# Importing this closed source loads offline tokenizers' API, not weights or encodings.
from measure_full_current_compact_output_TRAIN_v1 import (
    ROOT, R, RAW_ARCHIVE, MEMBER, EXPECTED_RAW, SMALL, LARGE, AutoTokenizer,
    build_current_messages, compact_teacher_target_for_training_only,
    digest, ids_hash, extended, read, sha, write, seal, frozen_checks,
)

OLD = extended(R / 'full_current_compact_output_TRAIN_readiness_v1')
MISSING = extended(R / 'full_current_compact_output_missing_identity_preparation_v1')
OUT = extended(R / 'full_current_missing_only_token_closure_v1')
LIMIT = 300

def records(path):
    with gzip.open(path, 'rt', encoding='utf8') as f:
        return [json.loads(line) for line in f]

def line(f, value, durable=False):
    f.write(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n')
    f.flush()
    if durable:
        os.fsync(f.fileno())

def main():
    assert not OUT.exists(), 'No restart or overwrite'
    OUT.mkdir()
    t0 = time.perf_counter()
    source_locks = {
        'work/full_current_compact_output_interface_v1.py': '32bcc9a6f85e82c8a0bfa9586b10aff347c76b7f0907e6d0012ee018b8d3f6da',
        'work/measure_full_current_compact_output_TRAIN_v1.py': '61bcca64ba075d4a13d055e57514507f132ebda91d3b3c14c8a62fb154f20eb7',
    }
    assert all(sha(ROOT / p) == h for p, h in source_locks.items())
    claim = {'at_utc': datetime.now(timezone.utc).isoformat(), 'actual_pid': os.getpid(),
             'actual_parent_pid': os.getppid(), 'command': sys.argv, 'source_sha256': sha(Path(__file__))}
    write(OUT / 'owner.claim', claim)
    missing_path = MISSING / 'Exact_Genuinely_Unexecuted_Encoding_Identities.json'
    missing = read(missing_path)
    inventory = read(MISSING / 'Saved_Cache_And_Missing_Identity_Inventory.json')
    assert len(missing) == 939 and inventory['missing_whole_chat_tokenizer_packages'] == 1878
    write(OUT / 'Prospective_Missing_Only_Protocol.json', {
        **claim, 'justification': 'Resolve whole-corpus context/mask feasibility before any adapted-scale allocation. Measure only previously unexecuted identities; not an extension/retry of the closed old owner.',
        'exact_identity_file_sha256': sha(missing_path), 'fixed_pairs': 939,
        'fixed_missing_whole_packages': 1878, 'fixed_missing_prefix_packages': 102,
        'order': 'ascending first TRAIN row index; no outcome selection',
        'entry_cutoff_seconds': LIMIT, 'source_locks': source_locks,
        'input_output_template_label_mask_context4096_reserve384_unchanged': True,
        'old_successful_encoding_repetition_forbidden': True,
        'old_closed_files_statuses_and_resource_budget_unchanged': True,
        'gate': 'Any lost identity, token mismatch or context/mask violation FAILS specified interface; missing evidence UNKNOWN. PASS only complete all16000.',
        'no_model_PF_optimizer_controller_forecast_solve_cloud_allocation': True,
        'pass_is_not_learning_benefit_or_automatic_GPU_authorization': True,
    })
    manifest = read(OLD / 'Supplement_Manifest.json')
    for name in ('Actual_Encoded_Prefixes.jsonl.gz', 'Actual_Encoded_Continuations.jsonl.gz',
                 'All16000_Current_Contract_Identity_Records.jsonl.gz', 'Actual_Tokenizer_Identity.json'):
        assert sha(OLD / name) == manifest[name]['sha256']
    prefixes = {(x['tokenizer_index'], x['actor_messages_sha256']): x for x in records(OLD / 'Actual_Encoded_Prefixes.jsonl.gz')}
    full = {(x['tokenizer_index'], x['training_pair_sha256']): x for x in records(OLD / 'Actual_Encoded_Continuations.jsonl.gz')}
    old_prefix_keys, old_full_keys = set(prefixes), set(full)
    old_rows = records(OLD / 'All16000_Current_Contract_Identity_Records.jsonl.gz')
    assert len(old_rows) == 16000 and len(full) == 6506 and len(prefixes) == 762
    with zipfile.ZipFile(RAW_ARCHIVE) as z:
        raw = z.read(MEMBER)
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_RAW
    cases = [json.loads(s) for s in raw.decode('utf8').splitlines()]
    token_identity = read(OLD / 'Actual_Tokenizer_Identity.json')
    for relative, h in token_identity['files'].items():
        assert sha(ROOT / relative) == h
    toks = [AutoTokenizer.from_pretrained(str(p), local_files_only=True, trust_remote_code=False) for p in (SMALL, LARGE)]
    assert 'torch' not in sys.modules
    counter = Counter()
    with gzip.open(OUT / 'New_Missing_Prefix_Arrays.jsonl.gz', 'xt', encoding='utf8') as pf, gzip.open(OUT / 'New_Missing_Continuation_Arrays.jsonl.gz', 'xt', encoding='utf8') as ff, (OUT / 'Actual_New_Encoding_Journal.jsonl').open('x', encoding='utf8') as jf:
        for item in missing:
            if time.perf_counter() - t0 > LIMIT:
                break
            i = item['first_TRAIN_row_index']
            case = cases[i]
            user = json.loads(case['messages'][1]['content'])
            current = {'zone': user['zone'], 'local_measurements': user['local_measurements']}
            messages = build_current_messages(current)
            target = compact_teacher_target_for_training_only(json.loads(case['messages'][2]['content']))
            pk, fk = digest(messages), digest([messages, target])
            assert pk == item['actor_messages_sha256'] and fk == item['training_pair_sha256']
            assert digest(target) == item['compact_target_sha256']
            answer = json.dumps(target, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
            for ti in item['missing_tokenizer_indices']:
                assert (ti, fk) not in full, 'Never repeat completed whole-chat encoding'
                tok = toks[ti]
                if (ti, pk) not in prefixes:
                    assert [ti, pk] in inventory['missing_prefixes']
                    text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                    event = {'phase': 'prefix', 'tokenizer_index': ti, 'TRAIN_row_index': i, 'key': pk}
                    line(jf, dict(event, event='attempt'), True); counter['prefix_attempts'] += 1
                    ids = tok(text, add_special_tokens=False, truncation=False)['input_ids']
                    counter['prefix_returns'] += 1; counter['prefix_tokens'] += len(ids)
                    p = {'tokenizer_index': ti, 'actor_messages_sha256': pk, 'input_ids': ids,
                         'input_ids_sha256': ids_hash(ids), 'all_attention_mask_values': 1,
                         'current_packet_json': current}
                    line(pf, p); prefixes[ti, pk] = p
                    line(jf, dict(event, event='return', tokens=len(ids), token_ID_sha256=ids_hash(ids)), True)
                p = prefixes[ti, pk]
                prefix_text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                text = tok.apply_chat_template(messages + [{'role': 'assistant', 'content': answer}], tokenize=False, add_generation_prompt=False) + tok.eos_token
                assert text.startswith(prefix_text)
                event = {'phase': 'whole', 'tokenizer_index': ti, 'TRAIN_row_index': i, 'key': fk}
                line(jf, dict(event, event='attempt'), True); counter['whole_attempts'] += 1
                value = tok(text, add_special_tokens=False, truncation=False, return_offsets_mapping=True)
                ids, offsets = value['input_ids'], value['offset_mapping']
                counter['whole_returns'] += 1; counter['whole_tokens'] += len(ids)
                count = len(p['input_ids'])
                assert ids[:count] == p['input_ids'] and ids[-1] == tok.eos_token_id
                spans = {}
                for field in target:
                    needle = json.dumps(field, ensure_ascii=False) + ':'
                    pos = len(prefix_text) + answer.index(needle)
                    touched = [j for j, (a, b) in enumerate(offsets) if b > pos and a < pos + len(needle)]
                    assert touched and min(touched) >= count
                    spans[field] = [min(touched), max(touched) + 1]
                facts = {'tokenizer_index': ti, 'actor_messages_sha256': pk, 'training_pair_sha256': fk,
                    'prefix_tokens': count, 'full_tokens': len(ids), 'supervised_continuation_tokens': len(ids) - count,
                    'continuation_ids': ids[count:], 'full_input_ids_sha256': ids_hash(ids),
                    'ignore_prefix_label_count': count, 'all_unpadded_attention_mask_values': 1,
                    'target_field_supervised_spans': spans, 'full_sequence_fits4096': len(ids) <= 4096,
                    'prefix_plus384_fits4096': count + 384 <= 4096,
                    'compact_continuation_fits384': len(ids) - count <= 384,
                    'no_truncation_packing_padding_or_target_in_generation_prefix': True}
                line(ff, facts); full[ti, fk] = facts
                line(jf, dict(event, event='return', tokens=len(ids), token_ID_sha256=ids_hash(ids)), True)
            counter['complete_new_pairs'] += 1
    known = unknown = mismatch = 0
    metrics = [{'full_max_tokens': 0, 'prefix_max_tokens': 0, 'continuation_max_tokens': 0, 'violations': 0} for _ in range(2)]
    with gzip.open(OUT / 'Closed_All16000_Identity_Records.jsonl.gz', 'xt', encoding='utf8') as f:
        for old in old_rows:
            fk = old['complete_training_pair_sha256']
            values = [full.get((ti, fk)) for ti in range(2)]
            row = dict(old, closure_status='complete' if all(values) else 'UNKNOWN_unexecuted',
                       closure_tokenizer_records=values)
            if all(values):
                known += 1
                mismatch += values[0]['full_input_ids_sha256'] != values[1]['full_input_ids_sha256']
                for ti, v in enumerate(values):
                    m = metrics[ti]
                    for key, value in [('full_max_tokens', v['full_tokens']), ('prefix_max_tokens', v['prefix_tokens']), ('continuation_max_tokens', v['supervised_continuation_tokens'])]:
                        m[key] = max(m[key], value)
                    m['violations'] += not all(v[k] for k in ('full_sequence_fits4096', 'prefix_plus384_fits4096', 'compact_continuation_fits384'))
            else:
                unknown += 1
            line(f, row)
    assert set(prefixes) - old_prefix_keys <= {tuple(x) for x in inventory['missing_prefixes']}
    assert set(full) - old_full_keys <= {(ti, x['training_pair_sha256']) for x in missing for ti in x['missing_tokenizer_indices']}
    result = {'at_utc': datetime.now(timezone.utc).isoformat(), 'complete_rows': known, 'unknown_rows': unknown,
        'all16000_token_ID_mismatch_rows': mismatch, 'metrics': metrics,
        'new_encoding_cost_counters': dict(counter), 'old762_prefix6506_whole_returns_reused_not_free': True,
        'old_original_partial_status_unchanged': True,
        'gate': 'UNKNOWN_resource_partial' if unknown else 'FAIL' if mismatch or any(x['violations'] for x in metrics) else 'PASS',
        'before_frozen_checks_archive_seconds': time.perf_counter() - t0,
        'model_PF_optimizer_controller_forecast_solve_cloud_allocation_calls': 0,
        'no_Torch_import_or_weights': 'torch' not in sys.modules,
        'no_automatic_learning_or_superiority_claim': True}
    write(OUT / 'Actual_Missing_Only_Closure_Result.json', result)
    write(OUT / 'Fresh_Frozen_Asset_Checks.json', frozen_checks())
    files = {p.name: p for p in OUT.iterdir() if p.is_file() and p.name != 'owner.claim'}
    files['sources/missing_only_owner.py'] = Path(__file__)
    files['sources/interface.py'] = ROOT / 'work/full_current_compact_output_interface_v1.py'
    archive = seal(OUT, files, 'Missing_Only_Current_Contract_Closure.zip')
    write(OUT / 'Actual_CPU_Workflow_Cost.json', {'workflow_seconds_including_IO_hash_archive': time.perf_counter() - t0,
        'all_prior_data_encoding_reader_failure_costs_separate_not_free': True})
    print(json.dumps({'gate': result['gate'], 'known': known, 'unknown': unknown, 'actual_new_encodings': dict(counter), 'archive': archive}))

if __name__ == '__main__':
    main()
