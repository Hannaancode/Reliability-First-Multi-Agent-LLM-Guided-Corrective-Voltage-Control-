"""Audit preserved original prefix and prepare an explicit missing-output ledger."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
root=Path('outputs');stage=root/'central_transfer_recovery';lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());protocol=json.loads((root/'central_experiment_protocol.json').read_text());expected=[Path(n).stem for n in sorted(lock['scenario_file_sha256'])]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[];missing=[]
for i,sid in enumerate(expected,1):
    case=stage/'central_matched_campaign/cases'/(sid+'.json');rng=stage/'central_matched_campaign/rng'/f'{i:03d}.pt'
    if not case.exists() or not rng.exists():missing.append({'index':i,'scenario_id':sid,'case_present':case.exists(),'RNG_present':rng.exists()});continue
    d=json.loads(case.read_text());assert d['scenario_id']==sid and d['protocol']==protocol and d['scenario_sha256']==lock['scenario_file_sha256'][case.name]
    with zipfile.ZipFile(rng) as z:assert z.testzip() is None
    if (root/'central_matched_campaign/cases'/case.name).exists():assert sha(case)==sha(root/'central_matched_campaign/cases'/case.name)
    rows.append({'index':i,'scenario_id':sid,'case_sha256':sha(case),'rng_sha256':sha(rng),'scenario_sha256':d['scenario_sha256']})
assert [r['scenario_id'] for r in rows]==expected[:len(rows)]
proof={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'verified_original_pairs':len(rows),'all_expected_pairs_present':not missing,'missing':missing,'verified_prefix':rows,'last_preserved_rng':f'{len(rows):03d}.pt','model_network_controller_settings_bank_unchanged':True,'live_files_modified':False,'runtime_released':json.loads((root/'next_gpu_stage_status.json').read_text())['runtime_released'],'current_blocker':'Original remote campaign returned exit 0, but transfer stopped after 60 pairs and its released assignment no longer exposes files. Missing final outputs cannot be declared complete.','proposed_recovery':'If authorized, resume the unchanged locked runner from the verified case-60 RNG checkpoint to execute only missing cases 61 and 62 on the frozen environment and standard T4. Preserve all original 60 files and record that two results are recovery executions, not recovered originals.','authorization_boundary':'Current heartbeat explicitly says never rerun experiments due to transfer failure. Do not launch this proposed recovery without user authorization.'}
(stage/'VERIFIED_PRESERVED_PREFIX_MANIFEST.json').write_text(json.dumps(proof,indent=2))
print(json.dumps({k:v for k,v in proof.items() if k!='verified_prefix'},indent=2))
