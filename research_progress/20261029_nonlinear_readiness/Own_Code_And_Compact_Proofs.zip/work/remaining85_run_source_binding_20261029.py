"""Freeze and run one all500 saved-input binding pass; zero scientific calls."""
import collections
import hashlib
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
import numpy as np
from remaining85_source_binder_20261029 import bind_entry, load_bound_kernel

O = R / 'outputs/nonlinear500_source_binding_20261029'
MANIFEST = 'outputs/remaining85_mechanism_review_20261029/All500_Nonlinear_Preparation_Input_Manifest.json'
SOURCE_PATHS = [
    'work/remaining85_source_binder_20261029.py', 'work/remaining85_run_source_binding_20261029.py',
    'work/remaining85_nonlinear_kernel_20261029.py', 'work/public13_matched_numeric_engine_20261021.py',
    'work/native_fit_teacher_math_20261020.py', 'work/native_full_grid_affine_core_20261020.py',
    'work/physics_env/Lib/site-packages/pandapower/auxiliary.py',
    'work/physics_env/Lib/site-packages/pandapower/build_bus.py',
    'work/physics_env/Lib/site-packages/pandapower/pypower/makeSbus.py',
    'work/physics_env/Lib/site-packages/pandapower/pypower/newtonpf.py',
    'work/physics_env/Lib/site-packages/pandapower/pf/run_bfswpf.py',
]


def sha(path):
    return hashlib.sha256((R / path).read_bytes()).hexdigest()


def put(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())


def main():
    started = time.perf_counter()
    O.mkdir(exist_ok=False)
    (O / 'bound_inputs').mkdir()
    source_hashes = {p: sha(p) for p in SOURCE_PATHS}
    m = json.loads((R / MANIFEST).read_text(encoding='utf-8'))
    assert [r['seed'] for r in m['entries']] == list(range(500))
    graph_ref = m['saved_graph_source']
    assert sha(graph_ref['path']) == graph_ref['sha256']
    assert sha(m['root_source']['path']) == m['root_source']['sha256']
    freeze = {'status': 'FROZEN_BEFORE_NEW_ALL500_DATA_BINDING_ONLY', 'at_utc': datetime.now(timezone.utc).isoformat(),
              'owner': {'pid': os.getpid(), 'parent_pid': os.getppid(), 'argv': sys.argv, 'executable': sys.executable},
              'sources': source_hashes, 'manifest': {'path': MANIFEST, 'sha256': sha(MANIFEST)},
              'graph': graph_ref, 'cases': list(range(500)),
              'scope': 'Data decoding/hash/field/source binding and constructor validation. No equation/KCL/PF/derivative/optimizer/model calls or old audit rerun.',
              'on_mismatch': 'Retain every root and mismatch/unknown; no repair or favorable subset.',
              'old_kernel_unchanged': True, 'max_wall_seconds': 300}
    put(O / 'Source_Input_Freeze.json', freeze)
    with np.load(R / graph_ref['path'], allow_pickle=False) as z:
        graph = {k: z[k].copy() for k in z.files}
    rows = []
    for e in m['entries']:
        if time.perf_counter() - started > 300:
            row = {'seed': e['seed'], 'status': 'UNKNOWN_FIXED_BINDING_DEADLINE', 'mismatches': []}
        else:
            row, arrays = bind_entry(R, e, graph)
            if arrays is not None:
                out = O / 'bound_inputs' / f"seed{e['seed']:03d}.npz"
                with out.open('xb') as f:
                    np.savez(f, **arrays)
                row['bound_pack'] = {'path': out.relative_to(R).as_posix(), 'sha256': sha(out.relative_to(R).as_posix()), 'bytes': out.stat().st_size}
                # First use of the newly implemented packed-input loader; this is
                # constructor-only roundtrip, not a scientific state replay.
                again = load_bound_kernel(R, row['bound_pack'])
                if again.costs:
                    row['status'] = 'UNKNOWN_UNEXPECTED_KERNEL_EVALUATION'
                row['packed_loader_roundtrip_current_arrays_exact'] = all(np.array_equal(getattr(again, k), arrays[k])
                    for k in ['Y', 'V_current', 'ppc_bus', 'ppc_gen', 'lookup', 'control', 'current_vm', 'current_q'])
                if not row['packed_loader_roundtrip_current_arrays_exact']:
                    row['status'] = 'UNKNOWN_PACKED_LOADER_MISMATCH'
        rows.append(row)
        put(O / f"seed{e['seed']:03d}_Binding.json", row)
    assert source_hashes == {p: sha(p) for p in SOURCE_PATHS}
    statuses = dict(collections.Counter(r['status'] for r in rows))
    result = {'status': 'COMPLETE_ALL500_SOURCE_BINDING_PASS' if statuses == {'BOUND_INPUT_ONLY': 500}
              else 'COMPLETE_ALL500_SOURCE_BINDING_WITH_REJECTIONS_OR_UNKNOWNS',
              'count': len(rows), 'statuses': statuses,
              'mismatch_counts': dict(collections.Counter(k for r in rows for k in r.get('mismatches', []))),
              'unknowns': [{'seed': r['seed'], 'status': r['status'], 'exception': r.get('exception')} for r in rows if r['status'].startswith('UNKNOWN')],
              'saved_initial_model_bound_count': sum(r.get('binding_fields', {}).get('saved_initial_model_available', False) for r in rows),
              'already_inband_without_model_count': sum(r['saved_initial_equation_model'] is None for r in m['entries']),
              'sources_unchanged_during_binding': True,
              'bound_sources': source_hashes,
              'costs': {'root_unpickle_attempts': sum(r['status'] != 'UNKNOWN_FIXED_BINDING_DEADLINE' for r in rows),
                        'bound_input_packs': sum('bound_pack' in r for r in rows),
                        'constructor_and_packed_loader_roundtrips': sum('bound_pack' in r for r in rows),
                        'nonlinear_equation_evaluations': 0, 'KCL_checks': 0, 'PF': 0, 'derivative': 0,
                        'LP_optimizer': 0, 'pretrained_model': 0, 'training': 0, 'GPU': 0},
              'workflow_seconds': time.perf_counter() - started,
              'readiness': 'Pure initial-input loader/binder only. No optimizer, rollout, prospective-state continuity or performance certification.',
              'remaining_gates': ['Independent source-binding review and kernel admission review.',
                                  'Per-decision current-state packing/validation under a frozen owner; this manifest covers initial roots only.',
                                  'One deterministic solver recipe, representable-action feasibility handling, attempted-input history, full cost/state journal and independent-reader protocol.',
                                  'Parent review/freeze before any optimizer, physical validation or performance call.'],
              'rows': rows}
    put(O / 'Results.json', result)
    put(O / 'Closed_Manifest.json', {'files': [{'path': p.relative_to(O).as_posix(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
                                             for p in sorted(O.rglob('*')) if p.is_file()]})
    print(json.dumps({k: result[k] for k in ['status', 'count', 'statuses', 'mismatch_counts', 'unknowns', 'costs', 'workflow_seconds']}))


if __name__ == '__main__':
    main()
