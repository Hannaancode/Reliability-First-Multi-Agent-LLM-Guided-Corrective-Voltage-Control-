"""Full-size CPU mock-target gradients/resource/reload tests, not performance."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import copy,json,os,time,torch
from action_transition_models import make_frontend,make_control,LORA_R4_PARAMETERS
from candidate_process_evidence_utils import ROOT,read,sha,write,seal

P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';D=P/'transition_OPT_tensor_preparation'
OUT=P/'transition_numerical_software_resource_readiness'
assert read(P/'transition_OPT_tensor_external_audit/Independent_Source_Tensor_Target_and_Embedding_Audit.json')['all_passed']
assert not OUT.exists();OUT.mkdir();started=time.perf_counter();torch.set_num_threads(4)
emb=torch.load(D/'Fixed_Native_Schema_Embeddings.pt',weights_only=True);tables=len(read(D/'Reused_OPT_Conditioning.json')['tables'])
front=make_frontend(emb,tables);common=front.state_dict();torch.save(common,OUT/'Fixed_New_Common_Initialization.pt')
index=read(D/'Input_Index.json');fixtures=index[:3]
inputs=[torch.load(D/r['path'],weights_only=True) for r in fixtures]
checks=[];arms={}
def rejects(name,call):
    try:call()
    except ValueError:checks.append(name);return
    raise AssertionError('Altered input was accepted: '+name)
for arm in ('graph','row_attention'):
    torch.manual_seed(20261009);model=make_control(arm,emb,tables,common)
    parameters=dict(model.named_parameters());optimizer=torch.optim.AdamW(parameters.values(),lr=.001,weight_decay=.01)
    fixed={n:v.clone() for n,v in model.named_buffers()};samples=[]
    torch.manual_seed(20261009)
    # Independently generated mock coefficient targets; no measured AFTER or
    # held values used in this software/resource fixture.
    mock=torch.randn(3,118)
    for offset,x in enumerate(inputs):
        assert time.perf_counter()-started<600
        optimizer.zero_grad(set_to_none=True);tick=time.perf_counter();y=model(x);forward=time.perf_counter()-tick
        assert y.shape==(118,) and bool(torch.isfinite(y).all())
        loss=torch.nn.functional.mse_loss(y,mock[offset]);tick=time.perf_counter();loss.backward();backward=time.perf_counter()-tick
        assert all(p.grad is not None and bool(torch.isfinite(p.grad).all()) for p in parameters.values())
        torch.nn.utils.clip_grad_norm_(parameters.values(),1.);tick=time.perf_counter();optimizer.step();step=time.perf_counter()-tick
        samples.append({'forward_seconds':forward,'backward_seconds':backward,'optimizer_seconds':step,
            'all_active_parameter_tensors_have_finite_non_None_gradients':True})
    assert all(torch.equal(v,dict(model.named_buffers())[n]) for n,v in fixed.items())
    model.eval()
    with torch.no_grad():saved=model(inputs[0]).clone()
    path=OUT/(arm+'_MOCK_ONLY_state.pt');torch.save(model.state_dict(),path)
    fresh=make_control(arm,emb,tables,common);fresh.load_state_dict(torch.load(path,weights_only=True));fresh.eval()
    with torch.no_grad():reloaded=fresh(inputs[0]);assert torch.equal(saved,reloaded)
    altered=copy.deepcopy(inputs[0]);q=next(q for j,q in enumerate(altered['row_input']['original_Q_grid'])
        if q!=altered['q_abs_mvar'] and altered['row_input']['allowed_actions'][altered['candidate_bus']][j])
    altered['q_abs_mvar']=q
    with torch.no_grad():assert not torch.equal(saved,model(altered))
    checks.append(arm+'_candidate_Q_reaches_body_output')
    bad=copy.deepcopy(inputs[0]);bad['after']=[1.]*118
    rejects(arm+'_reject_after',lambda:model(bad))
    bad=copy.deepcopy(inputs[0]);bad['row_input']['world_sha256']='bad'
    rejects(arm+'_reject_identity_in_row_input',lambda:model(bad))
    bad=copy.deepcopy(inputs[0]);bad['row_input']['allowed_actions'][bad['candidate_bus']][bad['row_input']['original_Q_grid'].index(bad['q_abs_mvar'])]=False
    rejects(arm+'_reject_unallowed_action',lambda:model(bad))
    shared=sum(p.numel() for p in model.frontend.parameters());active=sum(p.numel() for p in model.parameters())
    assert all(p.requires_grad for p in model.parameters())
    arms[arm]={'active_parameters':active,'shared_active_parameters':shared,'body_parameters':model.body_parameters,
        'rank4_LM_body_target':LORA_R4_PARAMETERS,'body_capacity_difference':model.body_parameters-LORA_R4_PARAMETERS,
        'all_active_parameter_tensors_with_gradient_each_mock_step':len(parameters),
        'mock_optimizer_steps':3,'mock_neural_forwards':6,'cold_reload_prediction_bit_exact':True,
        'fixed_schema_buffer_unchanged':True,'actual_full_size_mock_timing':samples}
    del model,optimizer,fresh
result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'all_software_resource_checks_passed':True,
    'label':'Full-size numerical CPU MOCK-target fixtures ONLY, no trained-task performance',
    'source_sha256':sha(ROOT/'work/action_transition_models.py'),'arms':arms,'checks':checks,
    'mock_optimizer_steps_total':6,'mock_neural_forwards_total':12,
    'actual_pretrained_contextual_model_PF_cloud_calls':0,'actual_measured_target_or_held_performance_training_steps':0,
    'future_science_must_reinitialize_not_reuse_mock_weights':True,'wall_seconds':time.perf_counter()-started}
write(OUT/'Software_Capacity_Gradient_Resource_Readiness.json',result)
files={p.name:p for p in OUT.iterdir() if p.is_file()}
files['source/model.py']=ROOT/'work/action_transition_models.py';files['source/checker.py']=Path(__file__)
seal(OUT,files,'Transition_Numerical_Mock_Resource_Readiness.zip')
print(json.dumps(result,indent=2))
