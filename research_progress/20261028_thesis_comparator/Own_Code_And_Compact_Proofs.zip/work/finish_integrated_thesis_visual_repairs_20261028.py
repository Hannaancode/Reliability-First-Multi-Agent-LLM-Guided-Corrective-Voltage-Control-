"""Three bounded layout repairs after full-document visual review; no scientific edits."""
from pathlib import Path
import json, shutil
from docx import Document
from docx.shared import Mm, Pt

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/thesis_integrated_evidence_20261028'
P = O / 'Hannaan_Thesis_Integrated_Evidence.docx'
record = O / 'Final_Layout_Repairs.json'
assert not record.exists(), 'Do not repeat a closed layout repair.'
shutil.copy2(O / 'Integrated_Thesis_QA.pdf', O / 'Before_Final_Layout_Repairs.pdf')
d = Document(P)
changed = []
for p in d.paragraphs:
    if '\t' not in p.text:
        continue
    for prefix, label in [
        ('Table 6.2', 'Table 6.2 Conditions checked by the original verifier'),
        ('Table 9.1', 'Table 9.1 Research questions, completed evidence and limits'),
    ]:
        if p.text.startswith(prefix):
            before = p.text
            p.text = label + '\t' + before.rsplit('\t', 1)[1]
            changed.append({'before': before, 'after': p.text})
assert len(changed) == 2
t = d.tables[1]
assert t.rows[0].cells[0].text == 'Research output'
for col, w in zip(t.columns, [30, 54, 62]):
    col.width = Mm(w)
for row in t.rows:
    for c, w in zip(row.cells, [30, 54, 62]):
        c.width = Mm(w)
t = d.tables[10]
assert t.rows[0].cells[0].text == 'Controller'
row = next(r for r in t.rows if r.cells[2].text == '765')
assert row.cells[3].text == '5'
for c in row.cells[2:]:
    for p in c.paragraphs:
        for run in p.runs:
            run.font.name = 'Times New Roman'
            run.font.size = Pt(10.5)
d.save(P)
record.write_text(json.dumps({'index_labels': changed, 'table_3_1_widths_mm': [30,54,62],
    'table_7_7_two_numeric_cell_font_pt': 10.5, 'scientific_changes': 0,
    'status': 'REQUIRES_FINAL_RENDER_CHECK'}, indent=2) + '\n', encoding='utf-8')
print('Three layout repairs saved; original thesis untouched.')
