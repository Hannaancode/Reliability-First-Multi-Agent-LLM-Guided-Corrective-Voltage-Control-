"""New-only numerical forecasts from four already-paid actual Jacobians.

No nonlinear PF, derivative, linear solve, model or training is performed.
All4001 previously returned forecasts are reused, never scientifically rerun.
This is causal numerical guidance preparation, not a safety/performance gate.
"""
import argparse, copy, hashlib, importlib.metadata, json, os, subprocess, sys, time
from datetime import datetime, timezone, timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
from equal_operation_benchmark_v2 import initial_data, process
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import load_endpoint, forecast
from joint_admissibility_order_v1 import order_all_current_forecasts, KEYS
from shared_original_serving_action_domain_v1 import build_current_domain

R = Path(__file__).resolve().parents[1]
B = R/'outputs/shared_domain_numeric_guidance_20261014'
OLD = R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
canon = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
key = lambda r: canon({k:r[k] for k in ('kind','receiver','q','donor_index','donor_bus')}).decode()

def put(path, value):
    with path.open('xb') as file: file.write(canon(value)); file.flush(); os.fsync(file.fileno())

def inputs():
    old, records, _ = initial_data(); _, runner, _ = load_stack()
    meta = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = meta.get('zones',meta)
    paid = {(r['world'],key(r)):copy.deepcopy(r['ordering_forecast']) for r in records}
    assert len(paid) == 4001
    worlds = []
    for index, entry in enumerate(old['current_endpoints'],1):
        net, cursor, _ = load_endpoint(entry); domain = build_current_domain(net,cursor,runner=runner,zones=zones)
        context_file = OLD/'actual'/f'W{index}_Current_Jacobian.npz'
        with np.load(context_file,allow_pickle=False) as packet: ctx = {k:packet[k] for k in packet.files}
        assert ctx['sensitivity'].shape == (118,118) and np.isfinite(ctx['sensitivity']).all()
        assert np.array_equal(ctx['mapping'],net['_pd2ppc_lookups']['bus'])
        assert np.array_equal(ctx['actual_bus_types'],net['_ppc']['bus'][:,1].astype(int))
        assert np.array_equal(ctx['current_vm'],net.res_bus.loc[range(118),'vm_pu'].to_numpy())
        assert np.max(np.abs(ctx['V']-net['_ppc']['internal']['V'])) <= 1e-14
        worlds.append({'world':entry['world'],'cursor':domain['expanded_cursor_for_separately_fixed_future_protocol'],
            'rows':domain['all_declared_original9Q_ordinary_and_owned_joint_identities'],
            'before':runner.rescue.grid_metrics(net),'context':ctx,'context_file':str(context_file.relative_to(R))})
    return worlds,paid

def ownership(out):
    out.mkdir(exist_ok=False); put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),
        'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(B/'Protocol.json'),'argv':sys.argv})
    while not (out/'Launcher_ACK.json').exists():
        assert datetime.now(timezone.utc) < datetime.fromisoformat(read(B/'Protocol.json')['deadline_utc']); time.sleep(.05)
    ack = read(out/'Launcher_ACK.json'); assert ack['actual_pid'] == os.getpid() and ack['actual_parent_pid'] == os.getppid() and ack['fresh_PID_parent_command']

def pins(p):
    for name,h in p['source_input_sha256'].items(): assert sha(R/name) == h,name

def blocked(*args,**kwargs): raise AssertionError('This preparation haszero PF/model/derivative/linear-solve permission')

def worker():
    out = B/'actual'; ownership(out); p = read(B/'Protocol.json'); pins(p)
    for name in ('runpp','runopp','rundcpp','rundcopp'): setattr(pp,name,blocked)
    worlds,paid = inputs(); attempts = 0; returned = 0; reused = 0; elapsed = 0.; outputs = []
    for w in worlds:
        rows = []
        for original in w['rows']:
            assert datetime.now(timezone.utc) < datetime.fromisoformat(p['deadline_utc'])
            row = copy.deepcopy(original); identifier = (w['world'],key(row))
            if identifier in paid:
                f = copy.deepcopy(paid[identifier]); reused += 1; source = 'REUSED_EXACT_PRIOR_FORECAST_NOT_RERUN'
            else:
                assert row['receiver'] in p['new_only_receiver_buses'][w['world']]
                attempts += 1; start = time.perf_counter(); f = forecast(row,w['context'],w['before'])
                elapsed += time.perf_counter()-start; returned += 1; source = 'NEW_FORECAST_ADDITIONAL_SOURCE_DEFINED_RECEIVER'
            row['ordering_forecast'] = f; assert set(row) == KEYS
            rows.append({'causal_forecast_row':row,'source':source,'actual_nonlinear_outcome':'UNKNOWN'})
        ordering = order_all_current_forecasts([r['causal_forecast_row'] for r in rows],w['before'],w['cursor'])
        outputs.append({'world':w['world'],'before':w['before'],'cursor':w['cursor'],'rows':rows,
            'complete_causal_ordering_universe_indices':[r['universe_index'] for r in ordering],
            'forecast_is_not_physical_label_or_safety_certificate':True})
    assert attempts == returned == p['new_only_forecast_count'] == 2371 and reused == 4001
    put(out/'Compiled_Causal_Guidance.json',{'worlds':outputs,'new_forecast_attempts':attempts,'new_forecast_returns':returned,
        'old_forecasts_reused_not_rerun':reused,'cumulative_declared_forecasts':attempts+reused,
        'new_forecast_function_seconds':elapsed,'new_PF_derivative_LU_model_optimizer_calls':0,
        'paid_old_derivatives_factors_solves':{'public_derivatives':4,'LU_factors':4,'LU_solves':4,'RHS_columns':472},
        'physical_improvement_economic_advantage_LLMvalue_or_confirmation':'NOT_TESTED'})
    put(out/'Completion.json',{'exit_code':0,'actual_pid':os.getpid(),'gate':'NUMERICAL_PREPARATION_ONLY_REQUIRES_READER'})

def audit():
    out = B/'audit'; ownership(out); p = read(B/'Protocol.json'); pins(p)
    end = read(B/'worker_End_ACK.json'); assert end['exit_code'] == 0 and process(end['actual_pid']) is None and process(end['launcher_pid']) is None
    assert sha(B/'actual/Compiled_Causal_Guidance.json') == end['output_sha256']
    for name in ('runpp','runopp','rundcpp','rundcopp'): setattr(pp,name,blocked)
    worlds,paid = inputs(); result = read(B/'actual/Compiled_Causal_Guidance.json'); new_count = 0; old_count = 0
    for w,saved in zip(worlds,result['worlds']):
        assert w['world'] == saved['world'] and len(w['rows']) == len(saved['rows'])
        assert w['cursor'] == saved['cursor'] and w['before'] == saved['before']
        for expected,record in zip(w['rows'],saved['rows']):
            row = record['causal_forecast_row']; assert set(row) == KEYS
            assert {k:v for k,v in row.items() if k!='ordering_forecast'} == expected
            identifier = (w['world'],key(row)); actual = row['ordering_forecast']
            if identifier in paid:
                assert actual == paid[identifier] and record['source'] == 'REUSED_EXACT_PRIOR_FORECAST_NOT_RERUN'; old_count += 1
            else:
                # Independent equation arithmetic, zero invocation of the
                # scientific forecasting function or any solver/model.
                s = w['context']['sensitivity']; vm = w['context']['current_vm'].copy()
                vm += row['q']*s[:,row['receiver']]
                if row['donor_bus'] is not None: vm -= row['q']*s[:,row['donor_bus']]
                if not np.isfinite(vm).all() or (vm<=0).any():
                    assert actual['status'] == 'UNKNOWN_NONPHYSICAL_LINEAR_FORECAST'
                else:
                    after = {'uv_count':int((vm<.95).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum()),
                             'vmin':float(vm.min()),'vmax':float(vm.max())}
                    assert actual['status'] == 'FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE'
                    assert all(abs(after[k]-actual['after'][k]) <= 1e-12 for k in after)
                    before = w['before']; expected_score = [int(after['uv_count']==0),before['uv_count']-after['uv_count'],
                        before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],-row['q']]
                    assert all(abs(a-b)<=1e-12 for a,b in zip(expected_score,actual['score']))
                assert row['receiver'] in p['new_only_receiver_buses'][w['world']]; new_count += 1
            assert record['actual_nonlinear_outcome'] == 'UNKNOWN'
        order = order_all_current_forecasts([r['causal_forecast_row'] for r in saved['rows']],w['before'],w['cursor'])
        assert [r['universe_index'] for r in order] == saved['complete_causal_ordering_universe_indices']
    assert new_count == result['new_forecast_returns'] == 2371 and old_count == result['old_forecasts_reused_not_rerun'] == 4001
    put(out/'Independent_Numeric_Guidance_Audit.json',{'status':'PASS_ALL6372_SOURCE_DOMAIN_CAUSAL_FORECAST_IDENTITIES_AND_NEW2371_EQUATIONS',
        'new_forecast_identities':new_count,'prior_forecast_identities_reused':old_count,'all_four_worlds_retained':True,
        'reader_new_forecast_function_PF_model_derivative_solve_calls':0,
        'no_nonlinear_safety_performance_novelty_or_LLMvalue_claim':True})

def launch(mode):
    with (B/(mode+'_console.log')).open('x',encoding='utf8') as log:
        child = subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--'+mode],
                                 stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        start = time.perf_counter(); out = B/('actual' if mode=='worker' else 'audit')
        while not (out/'owner.claim').exists():
            assert child.poll() is None and time.perf_counter()-start<60; time.sleep(.05)
        claim = read(out/'owner.claim'); actual = process(claim['actual_pid'])
        assert actual and actual['ParentProcessId']==child.pid and Path(__file__).name in actual['CommandLine'] and '--'+mode in actual['CommandLine']
        put(out/'Launcher_ACK.json',{'actual_pid':claim['actual_pid'],'actual_parent_pid':child.pid,'fresh_PID_parent_command':True})
        code = child.wait()
    put(B/(mode+'_End_ACK.json'),{'actual_pid':claim['actual_pid'],'launcher_pid':child.pid,'exit_code':code,
        'output_sha256':sha(B/'actual/Compiled_Causal_Guidance.json') if (B/'actual/Compiled_Causal_Guidance.json').exists() else None})
    return code

def prepare_run():
    B.mkdir(exist_ok=False); worlds,paid = inputs()
    new_rows = {w['world']:[r for r in w['rows'] if (w['world'],key(r)) not in paid] for w in worlds}
    assert sum(map(len,new_rows.values())) == 2371
    sources = ['work/compile_shared_domain_numeric_guidance_20261014.py','work/shared_original_serving_action_domain_v1.py',
        'work/joint_reallocation_opportunity_core_v1.py','work/joint_admissibility_order_v1.py','work/equal_operation_benchmark_v2.py',
        'work/frozen_physics_loader.py','work/owned_bank_joint_reallocation_v1.py']
    pins_map = {name:sha(R/name) for name in sources}
    for w in worlds: pins_map[w['context_file']] = sha(R/w['context_file'])
    oldp = read(OLD/'preparation/Protocol.json')
    for entry in oldp['current_endpoints']: pins_map[entry['endpoint_record']] = sha(R/entry['endpoint_record'])
    for file in [OLD/'preparation/Protocol.json',OLD/'actual/Closed_Manifest.json',R/'outputs/shared_original_serving_domain_20261014/Verified_Shared_Domain_Software_Checkpoint.json']:
        pins_map[str(file.relative_to(R))] = sha(file)
    now = datetime.now(timezone.utc)
    put(B/'Protocol.json',{'frozen_at_utc':now.isoformat(),'deadline_utc':(now+timedelta(seconds=120)).isoformat(),
        'new_only_forecast_count':2371,'old_forecasts_never_rerun':4001,'all_four_worlds':[w['world'] for w in worlds],
        'new_only_receiver_buses':{w['world']:sorted({r['receiver'] for r in new_rows[w['world']]}) for w in worlds},
        'all_new_exact_identities_before_execution':new_rows,'source_input_sha256':pins_map,
        'runtime_numpy':importlib.metadata.version('numpy'),'source_locked_reader':str(Path(__file__).relative_to(R)),
        'prior_actual_jacobians_reused_with_costs':True,'model_PF_derivative_LU_optimizer_permissions':False,
        'no_repeat_after_scientific_failure':True,'FORECAST_NOT_PHYSICAL_SAFETY_OR_EPISODE_LABEL':True,
        'running_full_suffix_inputs_sources_settings_unchanged':True})
    scientific = launch('worker'); reader = launch('audit') if scientific==0 else None
    put(B/'Completion.json',{'forecast_exit':scientific,'reader_exit':reader,'all_owned_chains_ended':True,
        'completed_at_utc':datetime.now(timezone.utc).isoformat(),'no_scientific_retry':True})
    print(json.dumps({'forecast_exit':scientific,'reader_exit':reader,'new_forecasts':2371,'old_not_recomputed':4001,'newPF_model_solves':0}))

if __name__=='__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--worker',action='store_true'); parser.add_argument('--audit',action='store_true')
    args = parser.parse_args()
    if args.worker: worker()
    elif args.audit: audit()
    else: prepare_run()
