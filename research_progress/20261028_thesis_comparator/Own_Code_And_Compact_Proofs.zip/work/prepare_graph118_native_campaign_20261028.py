"""Prospective fixed all-four external native-actuator campaign, no execution."""
from graph118_native_campaign_core_20261028 import *

def main():
    P.mkdir(exist_ok=False)
    prior=read(R/'outputs/graph118_current_history_preparation_20261028/Protocol.json')
    sources=list(prior['source_and_small_record_hashes'])
    sources=[x for x in sources if x.startswith('work/')]+[
      'work/graph118_native_campaign_core_20261028.py','work/run_graph118_native_campaign_20261028.py','work/audit_graph118_native_campaign_20261028.py',
      'work/prepare_graph118_native_campaign_20261028.py','work/check_graph118_native_campaign_integration_20261028.py','work/exact_graph_cursor_compare_20261023.py','work/strict_saved_native_input_match_v2_20261018.py',
      'work/native_solver_input_identity_v3_20261023.py','work/reflection118_chronological_core_20261022.py','work/prior_physical_query_footprints_20261018.py',
      'work/run_reflection118_chronological_local_20261022.py','work/r118_dff_missing_continuation_core_20261023.py',
      'work/prepare_graph118_current_history_gate_20261028.py','work/public_size_u61_preservation.py','work/candidate_process_evidence_utils.py',
      'work/resolve_original_role_input_component_collisions_20261022.py',
      'outputs/published_voltage_source_intake_20261022/blthayer__drl-powerworld/source/experiments/compare_agents.py']
    registry='outputs/closed_missing_suffix_registry_20261028/build/Closed_Physical_Receipt_Registry.json'
    tracked='outputs/prior_physical_query_footprints_20261018/actual/Physical_Component_Input_References.json.gz'
    extra='outputs/reflection118_chronological_preparation_20261022/Additional_Prior_Attempt_References.json'
    snapshots='outputs/original_role_remaining_native_history_scope_20261022/All_Saved_Snapshot_Components.json'
    inputs=[x for x in prior['source_and_small_record_hashes'] if x.startswith('outputs/')]+[registry,tracked,extra,snapshots,
      'outputs/graph118_current_history_admission_20261028/Verified_Completion.json',
      'outputs/graph118_current_history_admission_20261028/build/Result.json','outputs/graph118_current_history_admission_20261028/audit/Result.json',
      'outputs/published_graph118_episode_software_v2_20261023/Results.json','outputs/published_graph118_fresh_process_cursor_20261022/Fresh_Process_Cursor_Audit.json']
    complete=read(R/inputs[-5]);assert complete['status']=='COMPLETE_SCOPED_NEXT_INPUT_HISTORY_ADMISSION_ALL4'
    rows=read(OLD/'Saved_Transition_And_Cursor_Readiness.json')['rows']
    p=dict(status='FROZEN_BEFORE_NEW_EPISODE_OUTCOMES',at_utc=datetime.now(timezone.utc).isoformat(),
      question='What are complete native GraphAgent outcomes on all four exact inspected federation roots, with every prior paid first action reused?',
      source_hashes={x:sha(R/x) for x in sources},input_hashes={x:sha(R/x) for x in inputs},registry=registry,tracked=tracked,extra=extra,snapshots=snapshots,
      case_ids=[x['case_id'] for x in rows],science_seconds=7200,reader_seconds=7200,binary_bytes=1024**3,
      source_native_total_operations=136,remaining_max_per_case=135,new_primary_PF_max=540,first_replay_new_return_max=540,
      solver_kwargs=read(R/'outputs/published_graph118_first_queries_preparation_20261022/Protocol.json')['solver_kwargs'],
      original_author_AST_unchanged=True,original_first_calls_never_repeated=True,native_generator_and_existing_shunt_controls=True,
      primary_metrics=['all118 strict whole .95 to1.05 band','UV','OV','vmin','vmax','deficit','native operations','all solver/preparation/failure/reader costs'],
      analysis='All4 complete or all-four comparison UNKNOWN. No significance/superiority gate: these4 inspected roots and differing actuator/horizon/information roles cannot establish equal-resource superiority. Preserve per-case outcomes and adverse comparisons against DFF/HGVF/offlineHGSE.',
      old_cost_sources=['outputs/published_graph118_first_queries_execution_20261022/Results.json','outputs/published_graph118_first_queries_independent_20261022/Independent_Audit.json',
        'outputs/published_graph118_paid_transition_20261022/Saved_Transition_And_Cursor_Readiness.json','outputs/original118_closed_comparison_20261028/Full_Cost_Source_Blocks.json'],
      no_new_LLM_GPU_training=True,history_scope='Fixed enlarged14479closedregistry,60426trackedcomponent refs,additionalattempts/snapshots. Unknowncollision stops beforeentry. Newregistry covers allactual attemptedinputs. Exact nativeargument proof required for paid reuse.',
      no_retries_extensions_or_tuning=True,actual_cold_each_query_and_commit=True,
      required_before_launch='Separate source review and no-physics actual input/pending/cold/provider integration; fresh exact owner/claim check; sole first reader only after primary closed exit0.')
    put(P/'Protocol.json',p)
    print(json.dumps(dict(status=p['status'],cases=4,new_calls_executed=0)))
if __name__=='__main__':main()
