"""Independent complete/partial reader; no model, native PF, dS, factor or solve.

Reconstructs native menus, saved-result verifier outcomes, two-step selection,
first-only commits, complete checkpoints and full costs. Partial prefixes never
become negative/full-gate performance results.
"""
import argparse,copy,hashlib,json,os,time
from pathlib import Path
import numpy as np
import pandapower as pp
from full_receding_paid_campaign_20261015 import R,B,DEP,METHODS,pin,read,put,sha
from operation_aware_paid_lookahead_v1 import Receipt,plan
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import load_endpoint,build_verifier,action
from project_paid_joint_successor_v1 import project
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible
from joint_admissibility_order_v1 import order_all_current_forecasts
from dynamic_actual_mask_guidance_v1 import current_inputs,identity
from bounded_paid_lookahead_physics_20261014 import common_accept,load_after
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks
from equal_operation_benchmark_v2 import decode_capsule
from paid_receding_commit_and_history_v1 import (initialize,restore_complete,fields,fingerprint,commit_paid,verify_history)
from receding_paid_runtime_v2 import restore_dependency_prefix
import full_joint_suffix_benchmark_20261014 as prior
def forbidden(*a,**k):raise AssertionError('Independent reader cannot perform scientific calls')
def check_current_context(node,path):
    exact=current_inputs(node)
    with np.load(path,allow_pickle=False) as arrays:c={k:arrays[k].copy() for k in arrays.files}
    for k in exact:assert np.array_equal(exact[k],c[k]),k
    nr=c['nonref'];pq=c['actual_PQ'];V=c['V'];Y=c['Y'];dv=np.diag(V);di=np.diag(Y@V);norm=np.diag(V/abs(V))
    assert np.allclose(c['m'],dv@np.conj(Y@norm)+np.conj(di)@norm,atol=1e-8,rtol=1e-12)
    assert np.allclose(c['a'],1j*dv@np.conj(di-Y@dv),atol=1e-8,rtol=1e-12)
    J=np.block([[c['a'].real[np.ix_(nr,nr)],c['m'].real[np.ix_(nr,pq)]],[c['a'].imag[np.ix_(pq,nr)],c['m'].imag[np.ix_(pq,pq)]]])
    assert np.array_equal(J,c['J']) and np.max(abs(J@c['X']-c['B']))<=1e-8
    rhs=np.zeros_like(c['B']);positions={int(j):i for i,j in enumerate(pq)}
    for bus,j in enumerate(c['mapping']):
        if int(j) in positions:rhs[len(nr)+positions[int(j)],bus]=abs(V[j])**2/float(c['baseMVA'])
    assert np.array_equal(rhs,c['B'])
    S=np.zeros((118,118));S[pq,:]=c['X'][len(nr):,:];assert np.array_equal(S[c['mapping'],:],c['sensitivity'])
    return c
def check_query(node,row,message,*,cache,intents,returns,exceptions,pack,p,runner):
    aid=action_key(row);assert message['aid']==aid and message['row']==row
    record=message['record'];key=point_key(node['net'],node['cursor'])+'|'+aid
    if key in cache:
        old=cache[key]
        for k in ('verdict','original_score','after_reference','attributed_PF_calls','attributed_solver_seconds','actual_measured_receipt'):
            assert old.get(k)==record.get(k),k
    elif record.get('actual_measured_receipt'):
        m=record['actual_measured_receipt'];pid=m['PF_id']
        assert m==(returns if m['outcome']=='RETURNED' else exceptions)[pid]
        intent=intents[pid];context=intent['context']
        assert context['phase']=='NEW_PRIMARY_QUERY' and context['point']==point_key(node['net'],node['cursor']) and context['action_key']==aid
        _,actuate,_=build_verifier(runner.rescue,node['cursor']);expected=actuate(copy.deepcopy(node['net']),action(row))
        input_net=decode_capsule(pack,intent['before'])['net'];assert prior.signature(expected)==prior.signature(input_net)
        if m['outcome']=='RETURNED':
            target=decode_capsule(pack,m['after'])['net']
            def saved_result(net,**kwargs):
                assert kwargs==p['solver_kwargs'] and prior.signature(net)==prior.signature(input_net)
                net.clear();net.update(copy.deepcopy(target))
        else:
            def saved_result(net,**kwargs):
                assert kwargs==p['solver_kwargs'];raise RuntimeError('Recorded native exception, no new PF')
        backend=pp.runpp;pp.runpp=saved_result
        try:v=prior.verdict(build_verifier(runner.rescue,node['cursor'])[0](node['net'],action(row)))
        finally:pp.runpp=backend
        assert v==record['verdict'] and record['attributed_PF_calls']==1 and record['attributed_solver_seconds']==m['seconds']
        cache[key]=copy.deepcopy(record)
    else:
        assert not resource_eligible(row,node['cursor']) and record['attributed_PF_calls']==0 and record['after_reference'] is None
        assert record['verdict']['reason']=='exact_resource_cap_or_stock_rejection_noPF'
        cache[key]=copy.deepcopy(record)
    if record['attributed_PF_calls']:
        assert list(runner.rescue.score_candidate({'action':action(row),'verif':record['verdict']}))==record['original_score']
    successor=message['parent']+'/'+aid
    assert message['successor']==(successor if common_accept(record) else None)
    return record
def audit_decision(branch,original,cursor,*,actual,cache,intents,returns,exceptions,pack,p,runner,zones,admit):
    nodes={branch['root']:{'net':original,'cursor':build_current_domain(original,cursor,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol']}}
    messages={(m['parent'],m['aid']):m for m in branch['query_messages']};assert len(messages)==len(branch['query_messages'])
    visited=[];paidPF=0;paidSeconds=0.;menus=[]
    def ensure(handle):
        node=nodes[handle]
        if 'net' not in node:
            parent=ensure(node['parent']);target=load_after(node['record']['after_reference'],pack)['net']
            node.update(net=target,cursor=project(parent['net'],target,parent['cursor'],node['row'],node['record'],runner=runner,zones=zones))
        return node
    def menu(parent,slots,k=None):
        admit();node=ensure(parent);domain=build_current_domain(node['net'],node['cursor'],runner=runner,zones=zones);node['cursor']=domain['expanded_cursor_for_separately_fixed_future_protocol']
        rows=[r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if (1 if r['kind']=='ordinary' else 2)<=slots]
        if k is not None:
            ident=identity(current_inputs(node['net']));c=check_current_context(node['net'],actual/'contexts'/(ident+'.npz'))
            before=runner.rescue.grid_metrics(node['net']);guided=[]
            for row in rows:
                response=c['sensitivity'][:,row['receiver']].copy()
                if row['donor_bus'] is not None:response-=c['sensitivity'][:,row['donor_bus']]
                vm=c['current_vm']+row['q']*response
                if not np.isfinite(vm).all() or (vm<=0).any():f={'status':'UNKNOWN_NONPHYSICAL_LINEAR_FORECAST','score':[-999]*5}
                else:
                    a={'uv_count':int((vm<.95).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum()),'vmin':float(vm.min()),'vmax':float(vm.max())}
                    f={'status':'FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE','after':a,
                       'score':[int(a['uv_count']==0),before['uv_count']-a['uv_count'],before['deficit_sum']-a['deficit_sum'],a['vmin']-before['vmin'],-row['q']]}
                guided.append({**row,'ordering_forecast':f})
            ordered=order_all_current_forecasts(guided,before,node['cursor'])
            rows=[{key:r[key] for key in ('kind','receiver','q','donor_index','donor_bus','universe_index')} for r in ordered if resource_eligible(r,node['cursor'])][:k]
        ids=[action_key(r) for r in rows];menus.append({'parent':parent,'slots':slots,'k':k,'ids':ids})
        node.setdefault('rows',{}).update({action_key(r):r for r in rows});return ids
    def query(parent,aid):
        nonlocal paidPF,paidSeconds
        admit();node=ensure(parent);row=node['rows'][aid];msg=messages[(parent,aid)]
        record=check_query(node,row,msg,cache=cache,intents=intents,returns=returns,exceptions=exceptions,pack=pack,p=p,runner=runner)
        visited.append((parent,aid));paidPF+=record['attributed_PF_calls'];paidSeconds+=record['attributed_solver_seconds']
        accepted=common_accept(record);successor=parent+'/'+aid
        if accepted:nodes[successor]={'parent':parent,'row':row,'record':record}
        return Receipt(parent,aid,True,accepted,1 if row['kind']=='ordinary' else 2,successor if accepted else None,
            record['verdict']['after'] if accepted else None,tuple(record['original_score']) if accepted else None,
            bool(record['attributed_PF_calls'] and record['after_reference'] is None))
    reconstructed=plan(branch['root'],runner.rescue.grid_metrics(original),cursor['remaining_original_device_operation_slots'],
        lambda parent,slots:menu(parent,slots),lambda parent,slots,k:menu(parent,slots,k),query,mode=branch['method'])
    assert reconstructed==branch['plan'] and menus==branch['menus']
    assert visited==[(m['parent'],m['aid']) for m in branch['query_messages']]
    assert paidPF==branch['attributed_costs']['attributed_query_PF_calls'] and abs(paidSeconds-branch['attributed_costs']['attributed_query_solver_seconds'])<=1e-9
    return reconstructed,nodes,ensure,len(visited)
def main():
    p=read(B/'Protocol.json');pin(p);protocol_hash=sha(B/'Protocol.json');result=read(B/'actual/Result.json')
    manifest=read(B/'actual/Closed_Manifest.json');assert result['exit_code']==manifest['exit_code']
    out=B/'audit';out.mkdir(exist_ok=False);started=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    def admit():assert time.perf_counter()-started<p['reader_bound_seconds'],'Fixed reader resource bound, no extension'
    for name,data in manifest['members'].items():admit();path=B/'actual'/name;assert path.stat().st_size==data['bytes'] and sha(path)==data['sha256'],name
    for name in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,name,forbidden)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    warm=read(DEP/'Paid_Warm_Dependencies.json');cache=copy.deepcopy(warm['cache']);forecast_keys=set(warm['existing_numeric_forecasts'])
    previous='0'*64;intents={};returns={};exceptions={};closed_queries=[];initials=[];commits=[];acks=[];branch_events=[]
    numeric_counts={};new_forecasts=reused_forecasts=0
    with (B/'actual/scientific.jsonl').open('rb') as stream,(B/'actual/capsules.bin').open('rb') as pack:
        for line in stream:
            admit();e=json.loads(line);assert e['previous_sha256']==previous and e['protocol_sha256']==protocol_hash
            previous=hashlib.sha256(line.rstrip(b'\n')).hexdigest();d=e['data'];kind=e['event']
            if kind=='PF_intent':assert d['identity'] not in intents and d['kwargs']==p['solver_kwargs'];intents[d['identity']]=d
            elif kind=='PF_return':
                assert d['PF_id'] in intents and d['PF_id'] not in returns and d['PF_id'] not in exceptions
                target=decode_capsule(pack,d['after'])['net'];assert bool(target.converged)==d['converged']
                assert fields(target)==d['fields'] if target.converged else d['fields'] is None
                returns[d['PF_id']]=d
            elif kind=='PF_exception':
                assert d['PF_id'] in intents and d['PF_id'] not in returns and d['PF_id'] not in exceptions
                decode_capsule(pack,d['after']);exceptions[d['PF_id']]=d
            elif kind=='receding_branch_initialized':initials.append(d)
            elif kind=='every_query_receipt_closed_before_more_science':closed_queries.append(d)
            elif kind=='actual_receding_first_commit':commits.append(d)
            elif kind=='complete_receding_checkpoint_ACK':acks.append(d)
            elif kind=='receding_controller_closed':branch_events.append(d)
            elif kind.startswith('numeric_'):numeric_counts[kind]=numeric_counts.get(kind,0)+1
            elif kind=='second_causal_context_and_forecasts':
                for row in d['rows']:
                    key=d['context_identity']+'|'+action_key(row)
                    if key in forecast_keys:reused_forecasts+=1
                    else:new_forecasts+=1;forecast_keys.add(key)
    costs=result['actual_new_costs'];assert costs is not None
    assert costs['PF_returns']==len(returns) and costs['PF_exceptions']==len(exceptions)
    closed_ids=set(returns)|set(exceptions);assert not set(returns)&set(exceptions) and closed_ids<=set(intents)
    assert len(closed_ids)<=costs['PF_attempts']<=len(intents)
    assert abs(costs['PF_seconds']-sum(x['seconds'] for x in [*returns.values(),*exceptions.values()]))<=1e-8
    assert costs['PF_attempts']<=p['maximum_PF_attempts'] and costs['new_model_calls']==costs['new_optimizer_steps']==0
    nc=result['numerical_costs']
    for field,event in [('public_derivative_attempts','public_derivative_attempt'),('public_derivative_returns','public_derivative_return'),
        ('LU_factor_attempts','LU_factor_attempt'),('LU_factor_returns','LU_factor_return'),('LU_solve_attempts','LU_solve_attempt'),('LU_solve_returns','LU_solve_return'),('exact_context_reuses','exact_context_reused')]:
        assert nc[field]==numeric_counts.get('numeric_'+event,0),field
    assert nc['RHS_columns']==118*nc['LU_solve_returns'] and nc['new_forecasts']==new_forecasts and nc['exact_paid_forecast_reuses']==reused_forecasts
    # Every declared completed decision is independently reconstructed. An
    # interrupted search can still have closed paid queries; they are separately
    # checked below and cannot supply an endpoint or a negative full gate.
    histories=[];history_path=B/'actual/Complete_Runtime_History.bin'
    if result['checkpoint_requests']:
        state,_=restore_complete(R/result['checkpoint_requests'][-1]['checkpoint'],result['checkpoint_requests'][-1]['receipt'])
        anchor=state['paid_query_registry']['__COMPLETE_DURABLE_PAID_QUERY_HISTORY_PREFIX__']
        # A terminal completed no-action search may lie after the last commit's
        # checkpoint. Its durable full-file prefix is parsed independently too.
    import struct
    if history_path.is_file():
        prev='0'*64
        with history_path.open('rb') as stream:
            while header:=stream.read(8):
                admit();assert len(header)==8;size=struct.unpack('<Q',header)[0];assert 0<size<=32*1024**2
                raw=stream.read(size);assert len(raw)==size;e=json.loads(raw);assert e['previous']==prev
                assert e['source_anchor']==p['runtime_source_sha256'] and e['input_anchor']==p['warm_dependency_sha256']
                prev=hashlib.sha256(raw).hexdigest();histories.append(e)
    decision_records=[h['payload'] for h in histories if h['event']=='complete_paid_receding_decision']
    commit_records=[h['payload'] for h in histories if h['event']=='actual_receding_first_commit']
    assert commit_records==[d['record'] for d in commits] and len(commits)==len(acks)==len(result['checkpoint_requests'])
    roots={};decision_checked=query_checked=0;seen_queries=set();trajectory_summaries=[];all_commit_ids=[]
    with (B/'actual/capsules.bin').open('rb') as pack:
        for e in p['endpoints']:
            for mode in METHODS:
                key=(e['world'],mode);net,old,_=load_endpoint(e);cursor=initialize(net,build_current_domain(net,old,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
                initial=runner.rescue.grid_metrics(net);ops=0;step=0;branch_commits=[]
                for branch in [d for d in decision_records if (d['world'],d['method'])==key]:
                    admit();assert branch['decision']==step
                    reconstructed,nodes,ensure,count=audit_decision(branch,net,cursor,actual=B/'actual',cache=cache,intents=intents,returns=returns,exceptions=exceptions,pack=pack,p=p,runner=runner,zones=zones,admit=admit)
                    query_checked+=count;decision_checked+=1
                    seen_queries.update((branch['world'],branch['method'],branch['decision'],m['parent'],m['aid']) for m in branch['query_messages'])
                    if reconstructed['selected'] is None:
                        assert reconstructed['status']=='complete_declared_menu_no_safe_first';break
                    selected=reconstructed['selected'];d=next(c for c in commits if (c['world'],c['method'],c['decision'])==(*key,step));record=d['record']
                    msg=next(m for m in branch['query_messages'] if m['parent']==branch['root'] and m['aid']==selected['first'])
                    assert record['first_action_id']==selected['first'] and record['paid_successor_id']==selected['first_successor']
                    assert record['hypothetical_second_not_committed'] and record['candidate']==msg['row']
                    target=ensure(msg['successor'])['net'];row=msg['row'];m=record['replay_receipt']
                    assert m==returns[m['PF_id']] and intents[m['PF_id']]['context']['phase']=='CONTINUOUS_SELECTED_COMMIT_REPLAY'
                    _,actuate,_=build_verifier(runner.rescue,cursor);expected=actuate(copy.deepcopy(net),action(row))
                    assert prior.signature(expected)==prior.signature(decode_capsule(pack,intents[m['PF_id']]['before'])['net'])
                    observed=m['fields'];f=fields(target);delta=max(abs(f[b][k]-observed[b][k]) for b in f for k in f[b])
                    assert delta==record['replay_field_delta'] and delta<=1e-10
                    receipt={'receipt_id':msg['record']['receipt_id'],'accepted':True,'converged':True,'fields':f,'before_fingerprint':fingerprint(net,cursor)}
                    next_scope=build_current_domain(target,cursor,runner=runner,zones=zones)['shared_raw_receivers_for_BOTH_controls']
                    following=commit_paid(net,target,cursor,row,receipt,commit_id=record['commit_id'],actuate=actuate,next_scope=next_scope)
                    assert following==record['following_cursor'];before=runner.rescue.grid_metrics(net);after=runner.rescue.grid_metrics(target)
                    assert after['vmax']<=1.05+1e-8 and after['uv_count']<=before['uv_count'] and after['deficit_sum']<=before['deficit_sum']+1e-9
                    assert after['uv_count']<before['uv_count'] or after['deficit_sum']<before['deficit_sum']-1e-9 or after['vmin']>before['vmin']+1e-9
                    ops+=record['device_operations_debited'];branch_commits.append(record);all_commit_ids.append(record['commit_id']);step+=1;net=target;cursor=following
                roots[key]={'net':net,'cursor':cursor,'next_decision':step}
                completed=[b for b in result['branches'] if (b['world'],b['mode'])==key]
                if completed:
                    assert len(completed)==1;closed=completed[0]
                    assert closed['initial_metrics']==initial and closed['final_metrics']==runner.rescue.grid_metrics(net)
                    assert closed['commits']==branch_commits and closed['new_device_operations']==ops and closed['remaining_original_operations']==cursor['remaining_original_device_operation_slots']
                    if closed['stop_reason']=='full_UV_restoration':assert closed['final_metrics']['uv_count']==0
                    elif closed['stop_reason']=='original_operation_bound_exhausted':assert cursor['remaining_original_device_operation_slots']==0
                    else:assert closed['stop_reason']=='complete_current_native_menu_no_protected_accepted_action'
                    trajectory_summaries.append({'world':key[0],'method':mode,'final_UV':closed['final_metrics']['uv_count'],'operations':ops,'stop_reason':closed['stop_reason']})
        # Audit actual receipts in a terminal interrupted decision, without
        # interpreting its incomplete menu as a failure or performing any PF.
        partial_nodes={}
        for d in closed_queries:
            ident=(d['world'],d['method'],d['decision'],d['parent'],d['aid'])
            if ident in seen_queries:continue
            key=(d['world'],d['method']);root=f'{key[0]}|{key[1]}|{d["decision"]}|ROOT'
            if root not in partial_nodes:
                current=roots[key];assert d['decision']==current['next_decision']
                partial_nodes[root]={'net':current['net'],'cursor':current['cursor']}
            parent=partial_nodes[d['parent']]
            domain=build_current_domain(parent['net'],parent['cursor'],runner=runner,zones=zones);parent['cursor']=domain['expanded_cursor_for_separately_fixed_future_protocol']
            row=next(r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if action_key(r)==d['aid'])
            record=check_query(parent,row,d,cache=cache,intents=intents,returns=returns,exceptions=exceptions,pack=pack,p=p,runner=runner)
            if common_accept(record):
                target=load_after(record['after_reference'],pack)['net'];partial_nodes[d['successor']]={'net':target,'cursor':project(parent['net'],target,parent['cursor'],row,record,runner=runner,zones=zones)}
            query_checked+=1
    assert query_checked==len(closed_queries) and len(set(all_commit_ids))==len(all_commit_ids)
    for request in result['checkpoint_requests']:
        admit();state,history=restore_complete(R/request['checkpoint'],request['receipt'])
        assert state['protocol_sha256']==protocol_hash and state['absolute_deadline_utc']==request['original_deadline_utc']
        assert point_key(state['net'],state['cursor'])==request['expected_point_key'] and history[-1]['event']=='actual_receding_first_commit'
        restored=restore_dependency_prefix(state,warm_dependencies=warm,source_anchors=request['source_anchors'])
        assert restored['new_scientific_calls']==0
    complete=result['exit_code']==0
    if complete:
        assert len(result['branches'])==len(trajectory_summaries)==8 and not result['missing_closed_branch_identities']
        assert set(intents)==closed_ids and costs['PF_attempts']==len(intents)
        assert read(B/'actual_cold_request/cold/Result.json')['status']=='PASS_COLD_COMPLETE_RECEDING_PREFIX'
        wins=losses=0
        for e in p['endpoints']:
            values={s['method']:s['final_UV'] for s in trajectory_summaries if s['world']==e['world']}
            wins+=int(values[METHODS[1]]<values[METHODS[0]]);losses+=int(values[METHODS[1]]>values[METHODS[0]])
        gate='PASS' if wins>=2 and losses==0 else 'FAIL'
    else:wins=losses=None;gate='UNKNOWN'
    put(out/'Fresh_Frozen_Checks.json',frozen_checks())
    put(out/'Independent_Audit.json',{'status':'PASS_COMPLETE_RECEDING_SOURCE_PHYSICS_COST_CHECKPOINTS' if complete else 'PASS_PRESERVED_RECEDING_PREFIX_PARTIAL_FULL_GATE_UNKNOWN',
        'fixed_primary_gate':gate,'strict_UV_wins':wins,'UV_losses':losses,'all_closed_branches':trajectory_summaries,
        'independent_completed_decisions':decision_checked,'closed_query_receipts_checked':query_checked,'commits_checked':len(commits),'checkpoints_checked':len(acks),
        'actual_new_costs':costs,'numerical_costs':nc,'unclosed_intent_identities':sorted(set(intents)-closed_ids),
        'missing_closed_branch_identities':result['missing_closed_branch_identities'],'workflow_seconds':time.perf_counter()-started,
        'new_model_PF_derivative_factor_solve_calls':0,'equation_checks_are_paid_reader_CPU_work':True,
        'limits':p['scope'],'all_prior_paid_preparation_training_queries_failures_and_unknown_costs_retained':True})
    put(out/'Closed_Manifest.json',{'exit_code':0,'members':{str(path.relative_to(out)):sha(path) for path in out.rglob('*') if path.is_file()}})
    print(json.dumps({'independent_audit':'PASS','fixed_gate':gate,'complete_branches':len(trajectory_summaries),'new_PF_model_calls':0}))
if __name__=='__main__':main()
