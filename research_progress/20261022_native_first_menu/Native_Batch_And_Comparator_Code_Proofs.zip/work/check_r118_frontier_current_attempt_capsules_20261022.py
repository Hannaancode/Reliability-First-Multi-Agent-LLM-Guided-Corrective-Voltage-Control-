"""Extend the new menu map to include current failed/unentered before capsules."""
import copy,hashlib,json,pickle,sys,time,zlib
from collections import Counter,defaultdict
from pathlib import Path
from reflection118_chronological_core_20261022 import *
O=R/'outputs/r118_all4_first_round_attempt_coverage_20261022'
def main():
    O.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    from frozen_physics_loader import load_stack,AUDIT
    from prior_physical_query_footprints_20261018 import component
    def forbidden(*a,**k):raise BaseException('NO_NEW_PHYSICS_OR_MODEL')
    pp.runpp=forbidden;_,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    frontier=R/'outputs/r118_all4_first_round_query_frontier_20261022'
    old=read(frontier/'All_Classifications.json');assert read(frontier/'Frontier_Summary.json')['classified_queries']==2034
    paths=list((R/'outputs/r118chrono_20261022/local_controller').glob('*/*/pf_*_before.zlib'))
    paths+=list((R/'outputs/published_graph118_first_queries_execution_20261022').glob('*_before.zlib'))
    paths.append(R/'outputs/r118_solver_contract_bridge_execution_20261022/before.zlib')
    index=defaultdict(list)
    for p in sorted(paths):
        value=pickle.loads(zlib.decompress(p.read_bytes()))
        net=value['net'] if isinstance(value,dict) and 'net' in value else value
        index[component(net)[0]].append((p,net))
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    roots={r['case_id']:pickle.loads((R/r['solved_payload']).read_bytes())['net'] for r in roots}
    rows=[];new_collisions=[]
    for row in old['classified']:
        assert time.monotonic()-start<300
        target=copy.deepcopy(roots[row['case_id']]);runner.rescue.apply_action(target,row['action'])
        exact=[];exclusions=0
        for path,net in index.get(component(target)[0],[]):
            try:frames_equal(target,net)
            except (AssertionError,ValueError,KeyError):exclusions+=1;continue
            exact.append(dict(path=path.relative_to(R).as_posix(),sha256=sha(path)))
        out=dict(row,current_before_capsule_exact_matches=exact,current_same_component_full_input_exclusions=exclusions)
        if exact and row['status']=='NO_MATCH_IN_NAMED_TRACKED_SCOPE_NOT_GLOBAL_ABSENCE':
            out['status']='CURRENT_FAILED_OR_UNENTERED_ATTEMPT_COLLISION_UNKNOWN_NO_AUTOMATIC_CALL';new_collisions.append(out)
        rows.append(out)
    counts=Counter(r['status'] for r in rows)
    put(O/'All2034_Classifications_With_Attempt_Capsules.json',dict(rows=rows))
    put(O/'Current_Attempt_Coverage.json',dict(status='PASS_ALL2034_CURRENT_PRIMARY_FAILED_UNENTERED_BEFORE_CAPSULE_SCOPE',
        classified_queries=len(rows),counts=dict(counts),current_before_capsules=len(paths),new_unknown_collisions=len(new_collisions),
        new_collisions=new_collisions,original_frontier_sha256=sha(frontier/'All_Classifications.json'),
        no_new_PF_model_optimizer_derivative_calls=True,not_a_full_first_round_physics_result_or_execution_permission=True,
        next_required='Freeze exact unexecuted-only worker/reader/ownership/cold/persistent/fullcost protocol. Known contract/failed/unentered collisions stay UNKNOWN unless separately resolved. No automatic launch from this map.',
        source_sha256=sha(__file__),workflow_seconds=time.monotonic()-start))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(counts=dict(counts),before_capsules=len(paths),new_unknown_collisions=len(new_collisions),new_science=0)))
if __name__=='__main__':main()
