"""Explicit CPU compatibility bridge; author policy and plant equations unchanged."""
import ast,copy,hashlib,json,sys,types
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1]
AUTHOR=ROOT/'outputs/published_method_roster_addendum_20261020/TPA_author_reference'
NATIVE=ROOT/'outputs/mapdn_native_contract_v2_20261020'
PHYSICS_SITE=ROOT/'work/physics_env/Lib/site-packages'
# The scientific process has its own sys.path; neither installed environment is edited.
sys.path.insert(0,str(AUTHOR));sys.path.append(str(PHYSICS_SITE))
import numpy as np
import yaml
import torch
import pandas as pd

CHECKPOINT=AUTHOR/'trial/model_save/var_voltage_control-case322_3min_final-distributed-tpamaddpg-l1-53-example322tpa/model.pt'

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def static_args():
    n=json.loads((NATIVE/'case322_3min_final_native_input_tables.json').read_text(encoding='utf-8'))
    bus=sorted(n['bus'],key=lambda x:x['index']);pv=n['sgen'];zones=np.append(np.unique([b['zone'] for b in bus]),'all')
    zone_buses={z:[b['index'] for b in bus if b['zone']==z] for z in zones}
    counts=np.array([len(zone_buses[x['name']]) for x in pv]);maximum=int(max(counts))
    edges={b['index']:{b['index']} for b in bus}
    for name,a,b in [('line','from_bus','to_bus'),('trafo','hv_bus','lv_bus')]:
        for e in n[name]:
            if e['in_service']:edges[e[a]].add(e[b]);edges[e[b]].add(e[a])
    adjacency=[]
    for z in zones:
        if z in ['main','all']:continue
        m=np.zeros((maximum,maximum))
        for i,a in enumerate(zone_buses[z]):
            for j,b in enumerate(zone_buses[z]):m[i,j]=float(b in edges[a])
        adjacency.append(m)
    default=yaml.safe_load((AUTHOR/'args/default.yaml').read_text(encoding='utf-8'))
    algo=yaml.safe_load((AUTHOR/'args/alg_args/tpamaddpg.yaml').read_text(encoding='utf-8'))['alg_args']
    d={**default,**algo,'cuda':False,'action_scale':.8,'action_bias':0.,'agent_num':len(pv),'obs_size':maximum*6,'obs_bus_dim':6,'obs_bus_num':counts,
      'action_dim':1,'bus_num':len(bus),'region_num':len(zones),'constraint_mask':np.ones((len(pv),len(zones))),
      'agent2region':np.array([list(zones).index(x['name'])-1 for x in pv]),'agent_index_in_obs':np.array([zone_buses[x['name']].index(x['bus']) for x in pv]),
      'region_adj':adjacency,'tp':100,'time_dims':3,'jieqi_info':None}
    return SimpleNamespace(**d),n

def load_policy(args):
    from models.tpa_maddpg import TPAMADDPG
    state=torch.load(CHECKPOINT,map_location='cpu',weights_only=True)
    assert set(state)=={'model_state_dict'} and all(torch.isfinite(x).all() for x in state['model_state_dict'].values())
    target=TPAMADDPG(args) if args.target else None
    model=TPAMADDPG(args,target) if target is not None else TPAMADDPG(args)
    model.load_state_dict(state['model_state_dict'],strict=True);model.eval()
    return model,state

def headless_environment_class():
    """Drop only the unused plotting import; certify all class ASTs unchanged."""
    path=AUTHOR/'environment/var_voltage_control/voltage_control_env.py';tree=ast.parse(path.read_text(encoding='utf-8'))
    original=copy.deepcopy(tree)
    tree.body=[n for n in tree.body if not(isinstance(n,ast.ImportFrom) and n.module=='pf_res_plot')]
    assert len(original.body)-len(tree.body)==1
    for a in [n for n in original.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))]:
        b=next(n for n in tree.body if isinstance(n,type(a)) and n.name==a.name);assert ast.dump(a)==ast.dump(b)
    module=types.ModuleType('environment.var_voltage_control.hiergrid_headless');module.__package__='environment.var_voltage_control'
    exec(compile(tree,str(path),'exec'),module.__dict__)
    return module.VoltageControl,{'only_unused_plot_import_removed':True,'all_function_and_class_ASTs_identical':True,'source_sha256':digest(path)}
