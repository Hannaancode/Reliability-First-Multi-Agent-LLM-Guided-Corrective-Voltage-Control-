"""Three-process linked checkpoint SOFTWARE fixture, zero real PF/model.

Uses new synthetic fixtures and the unchanged original verifier with explicitly
mocked solver returns. Cursor advances are simulated, never physical commits.
No old scientific call, fixture output or completed owner is resumed.
"""
import copy
import json
import os
import random
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandapower as pp
import check_spatial_controller_closed_phase_20261012 as warm_fixture
import paid_spatial_controller_checkpoint_v3 as linked
from paid_spatial_controller_checkpoint_v1 import process_alive
from paid_spatial_native_queries_v2 import NativeQueriesV2
from native_continuation_preservation_v2 import EvidenceJournal, canonical, extended_local_path
from trusted_causal_controller_snapshot import SOLVER_ROLES, write_bytes
from value_normal_band_mediation import NormalUpperMediation
from frozen_physics_loader import load_stack, AUDIT

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/critical_research_reset_20261010/spatial_linked_checkpoint_software_20261012'
warm_fixture.suite.OUT = OUT
previous_sources = warm_fixture.suite.sources
def sources():
    return {**previous_sources(), **{name: warm_fixture.suite.sha((ROOT/name).read_bytes()) for name in
        ['work/paid_spatial_controller_checkpoint_v3.py', 'work/check_spatial_linked_checkpoints_20261012.py']}}
warm_fixture.suite.sources = sources
read = lambda path: json.loads(path.read_text('utf8'))
sha = warm_fixture.suite.sha


def replace_fixture(path, data):
    assert path.resolve().is_relative_to(extended_local_path(OUT/'fixture').resolve())
    with path.open('wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def receiver(label, prior, *, next_vm):
    protocol = read(OUT/'Protocol.json')
    ph = sha((OUT/'Protocol.json').read_bytes())
    directory = extended_local_path(OUT/'fixture')
    state, manifest = linked.read_checkpoint(prior['anchor'], expected_protocol=protocol,
        expected_protocol_sha256=ph, expected_controller_identity=prior['controller'], expected_directory=directory)
    assert not process_alive(prior['issuer_pid']) and prior['issuer_pid'] != os.getpid()
    previous_claim = (directory/'owner.claim').read_bytes()
    history = directory/'phase_claims'
    history.mkdir(exist_ok=True)
    write_bytes(history/(label+'_predecessor.claim'), previous_claim)
    replace_fixture(directory/'owner.claim', canonical({'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(),
        'protocol_sha256': ph, 'inherited_checkpoint_sha256': prior['anchor']['payload_sha256'],
        'phase': label, 'command': sys.argv, 'labelled_software_only': True}))
    _, runner, _ = load_stack()
    assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    original_pf = pp.runpp
    mocks = []
    def mock(trial, **kwargs):
        assert kwargs == SOLVER_ROLES['trial']
        mocks.append(kwargs)
        trial.res_bus.loc[:, 'vm_pu'] = next_vm
    pp.runpp = mock
    journal = EvidenceJournal(directory/(label+'_controls.jsonl'), ph)
    q = None
    checks = []
    try:
        with NormalUpperMediation(runner.rescue, 1.05, 1e-8):
            q = NativeQueriesV2(pp, runner, {'MG1': [0, 1, 2]}, directory, journal, protocol, ph)
            handoff = {'issuer_pid': prior['issuer_pid'], 'receiver_pid': os.getpid(),
                'checkpoint_sha256': prior['anchor']['payload_sha256'], 'issuer_exit_code': 0,
                'phase': 'PLANNED_PRESERVED_HANDOFF_NOT_TERMINAL_SCIENCE_RETRY'}
            # Identity/cost state is inherited, not set from an empty fresh tail.
            controller = linked.bind_planned_handoff(q, state, manifest, anchor=prior['anchor'],
                handoff=handoff, closed_phase_anchor=prior['closed_phase_anchor'],
                journal_name=label+'_cumulative.jsonl')
            assert controller == prior['controller'] and q.deadline.isoformat() == protocol['absolute_deadline_utc']
            checks.extend(['complete_cursor_history_deadline_retained', 'prior_owner_really_ended'])
            if label == 'middle':
                evidence = read(OUT/'Warm_Returned_Anchor.json')
                assert [random.random() for _ in range(5)] == evidence['expected_rng']['python']
                assert np.random.random(5).tolist() == evidence['expected_rng']['numpy']
                checks.append('RNG_exact_across_first_process_handoff')
            before = q.pf_attempts
            # Historical receipts can be inspected/reused; no new query on an
            # obsolete committed parent is made by this causal fixture.
            for key, receipt in state['receipts'].items():
                assert q.query(*key) == receipt
            assert q.pf_attempts == before and not mocks
            checks.append('all_previous_success_and_failure_receipts_reused_without_solver')
            current = controller['current_handle']
            actions = q.menu(current)
            action_id = next(a for a in actions if (current, a) not in q.attempted)
            receipt = q.query(current, action_id)
            assert receipt.accepted and receipt.successor and len(mocks) == 1 and q.pf_attempts == before+1
            checks.append('only_new_identity_at_actual_current_cursor_executes_mock_solver')
            if label == 'middle':
                action = q.menus[current][action_id]
                old_net_process = q.restore(current)['process']
                process = {**old_net_process, 'actual_commit_count': 2, 'remaining_slots': 23,
                    'actual_action_history': old_net_process['actual_action_history']+[action]}
                handle = q.register(q.restore(receipt.successor)['net'], process,
                    label='SYNTHETIC_SECOND_CURSOR_NOT_PHYSICAL_COMMIT')
                controller = {**controller, 'actual_commit_count': 2, 'remaining_slots': 23,
                    'current_handle': handle, 'actual_action_history': controller['actual_action_history']+[
                        {'iteration': 2, 'parent_handle': current, 'selected_action_id': action_id,
                         'trial_successor': receipt.successor, 'action': action, 'committed_handle': handle}]}
                a = linked.save_checkpoint(q, controller, 'middle_after_simulated_second_commit')
                reloaded, _ = linked.read_checkpoint(a, expected_protocol=protocol,
                    expected_protocol_sha256=ph, expected_controller_identity=controller, expected_directory=directory)
                assert reloaded['controller']['remaining_slots'] == 23 and len(linked.validate_linkages(reloaded, directory)) == 1
                checks.append('second_checkpoint_after_handoff_verified_without_single_handoff_reset')
                # Independent second checkpoint in the SAME owner; all previous
                # checkpoint bytes/time stay in the cumulative costs.
                final_anchor = linked.save_checkpoint(q, controller, 'middle_second_safe_checkpoint')
                checks.append('repeated_same_owner_checkpoint_preserves_complete_prefix')
            else:
                final_anchor = linked.save_checkpoint(q, controller, 'third_complete_current_query_prefix')
                final_state, _ = linked.read_checkpoint(final_anchor, expected_protocol=protocol,
                    expected_protocol_sha256=ph, expected_controller_identity=controller, expected_directory=directory)
                links = linked.validate_linkages(final_state, directory)
                assert len(links) == 2 and len(final_state['controller']['actual_action_history']) == 2
                checks.append('two_planned_handoffs_and_two_commit_cursor_entries_preserved')
                # Direct wrong-prefix challenge: both trust anchors may match a
                # snapshot, but its historical file cannot silently change.
                old_file = directory/next(row['payload']['inherited_journal_relative_path']
                    for row in linked.validate_chain(final_state['journal_bytes'], ph)[0]
                    if row['event'] == 'linked_journal_segment_opened')
                saved = old_file.read_bytes()
                try:
                    replace_fixture(old_file, saved+b'{}\n')
                    try:
                        linked.read_checkpoint(final_anchor, expected_protocol=protocol,
                            expected_protocol_sha256=ph, expected_controller_identity=controller, expected_directory=directory)
                    except ValueError:
                        checks.append('changed_earlier_inherited_journal_rejected')
                    else:
                        raise AssertionError('Older prefix alteration accepted')
                finally:
                    replace_fixture(old_file, saved)
                # Strict non-promotion after science: this final cumulative
                # journal contains paid work, so its rows cannot be rebased as
                # a new administrative-only receiving segment.
                assert any(x['event'] == 'PF_intent' for x in linked.validate_chain(
                    final_state['journal_bytes'], ph)[0])
            final_costs = {k: getattr(q, k) for k in linked.COUNTERS} if hasattr(linked, 'COUNTERS') else {
                k: getattr(q, k) for k in ('new_queries', 'pf_attempts', 'pf_returns', 'pf_exceptions',
                                         'pf_seconds', 'payload_bytes', 'preservation_seconds', 'reused_receipts')}
            closed_anchor = linked.close_planned_phase(q, controller, final_anchor)
            result = {'issuer_pid': os.getpid(), 'actual_parent_pid': os.getppid(), 'phase': label,
                'anchor': final_anchor, 'closed_phase_anchor': closed_anchor, 'controller': controller,
                'mock_solver_calls_in_this_phase': len(mocks), 'actual_new_nonlinear_PF_model_calls': 0,
                'checks': checks, 'final_query_costs': final_costs, 'new_query_identity': [current, action_id]}
            write_bytes(OUT/(label+'_Result.json'), canonical(result))
            return result
    finally:
        if q is not None:
            q.close()
            q.journal.close()
        else:
            journal.close()
        pp.runpp = original_pf


def run_phase(name):
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    child = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--'+name], capture_output=True,
        timeout=180, creationflags=flags)
    write_bytes(OUT/(name+'_stdout.txt'), child.stdout)
    write_bytes(OUT/(name+'_stderr.txt'), child.stderr)
    assert child.returncode == 0, child.stderr.decode(errors='replace')


def main():
    OUT.mkdir(exist_ok=False)
    begun = time.perf_counter()
    protocol = {'execution_kind': 'THREE_PROCESS_SYNTHETIC_MOCK_SOFTWARE_NOT_PHYSICS',
        'actual_query_binding_authorized': True, 'planned_process_handoff_authorized': True,
        'scope': 'GLOBAL_ORIGINAL_DFF_MENU', 'new_query_limit': 8, 'payload_byte_limit': 10000000,
        'absolute_deadline_utc': (datetime.now(timezone.utc)+timedelta(seconds=600)).isoformat(),
        'source_sha256': sources()}
    write_bytes(OUT/'Protocol.json', canonical(protocol))
    run_phase('warm')
    warm = read(OUT/'Warm_Returned_Anchor.json')
    assert not process_alive(warm['warm_pid'])
    run_phase('middle')
    middle = read(OUT/'middle_Result.json')
    assert not process_alive(middle['issuer_pid']) and warm['warm_pid'] != middle['issuer_pid']
    third = receiver('third', middle, next_vm=[.947, .968, 1.014])
    assert os.getpid() not in [warm['warm_pid'], middle['issuer_pid']]
    assert third['controller']['actual_commit_count'] == 2 and third['controller']['remaining_slots'] == 23
    assert third['final_query_costs']['new_queries'] == third['final_query_costs']['pf_attempts'] == 4
    assert third['final_query_costs']['pf_returns'] == 3 and third['final_query_costs']['pf_exceptions'] == 1
    assert third['final_query_costs']['reused_receipts'] == 5
    checks = ['three_distinct_actual_software_processes', 'two_predecessor_phases_exit0_and_ended',
              'cumulative_four_mock_attempts_three_returns_one_exception', 'five_paid_cache_reuses_zero_repeated_mock_calls']
    checks += ['middle:'+x for x in middle['checks']]+['third:'+x for x in third['checks']]
    result = {'saved_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS', 'checks': checks,
        'check_count': len(checks), 'source_sha256': sources(), 'protocol_sha256': sha((OUT/'Protocol.json').read_bytes()),
        'software_pids': [warm['warm_pid'], middle['issuer_pid'], os.getpid()], 'actual_new_PF_model_optimizer_forecast_cloud_calls': 0,
        'labelled_mock_solver_calls': 4, 'planned_handoffs': 2, 'complete_checkpoint_count': 4,
        'final_cumulative_query_costs': third['final_query_costs'],
        'software_workflow_seconds_before_final_report': time.perf_counter()-begun,
        'limitations': ['All nets/cursor advances are synthetic mock fixtures; no actual physical commitment or full controller cold-process physics equivalence.',
                       'Only two planned handoffs/four checkpoint boundaries tested; arbitrary crash recovery is not certified.',
                       'Unfinished calls and terminal/expired/resource-limited states never grant a scientific retry.',
                       'Full owner/import/receipt-write/reader timing must remain separately charged in an actual protocol.',
                       'No full 25-step/control campaign, language learner, superiority, novelty or calibrated winning confidence.']}
    write_bytes(OUT/'Linked_Checkpoint_Software_Readiness.json', canonical(result))
    print(json.dumps({'status': 'PASS', 'checks': len(checks), 'planned_handoffs': 2, 'actual_new_PF_model_calls': 0}))


if __name__ == '__main__':
    if '--warm' in sys.argv:
        warm_fixture.warm()
    elif '--middle' in sys.argv:
        warm = read(OUT/'Warm_Returned_Anchor.json')
        receiver('middle', {'anchor': warm['anchor'], 'closed_phase_anchor': warm['closed_phase_anchor'],
            'controller': warm['controller'], 'issuer_pid': warm['warm_pid']}, next_vm=[.945, .965, 1.012])
    else:
        main()
