"""Bind authentic historical inputs and explicit device-only CPU source projection."""
import sys,json,hashlib
from pathlib import Path
import candidate_process_runtime
import tpa_benchmark_bridge_20261020 as bridge
ROOT=Path(__file__).resolve().parents[1]
CPU=ROOT/'work/tpa_cpu_compat_20261020'
bridge.AUTHOR=CPU
sys.path.insert(0,str(CPU))
def prepare_args():
    args,native=bridge.static_args()
    path=ROOT/'outputs/tpa_native_one_step_preparation_20261020/Exact_Native_Seasonal_Input.npz'
    proof=json.loads((path.parent/'Seasonal_Input_Result.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['npz_sha256']
    args.jieqi_info=bridge.np.load(path)['jieqi_info'];assert args.jieqi_info.shape==(24,480,3)
    return args,native
