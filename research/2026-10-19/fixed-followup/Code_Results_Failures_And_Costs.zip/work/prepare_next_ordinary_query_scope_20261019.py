"""Bind first unknown ordinary query and relevant prior-input scope, zero PF."""
import copy,gzip,hashlib,json,pickle,time,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from original_local_paid_branch_broker_v1 import resource_eligible
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
from equal_operation_benchmark_v2 import decode_capsule
I=R/'outputs/next_ordinary_query_input_20261019'
SCREEN=R/'outputs/resumed16_paid_policy_support_20261019'

def main():
    I.mkdir(exist_ok=False);start=time.perf_counter()
    for rel,h in read(SCREEN/'Closed_Manifest.json')['members'].items():assert sha(SCREEN/rel)==h
    leg=read(SCREEN/'Leg_1.json');assert leg['status']=='UNKNOWN_UnknownLineageIdentity'
    ref=leg['frontier_input'];enc=(SCREEN/ref['path']).read_bytes();assert hashlib.sha256(enc).hexdigest()==ref['encoded_sha256'];raw=zlib.decompress(enc);assert hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];state=pickle.loads(raw)
    row=state['row'];assert row=={'kind':'ordinary','receiver':37,'q':300.0,'donor_index':None,'donor_bus':None,'universe_index':98}
    _,runner,_=load_stack();net=state['net'];cursor=state['cursor'];domain=build_current_domain(net,cursor,runner=runner,zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones'])
    assert row in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] and resource_eligible(row,cursor)
    key=point_key(net,cursor)+'|'+action_key(row);assert key==state['key']
    _,actuate,native=build_verifier(runner.rescue,cursor);candidate=actuate(copy.deepcopy(net),action(row));h,values=component(candidate);assert independent_component(candidate)==h
    base=R/'outputs/prior_physical_query_footprints_20261018';audit=read(base/'independent_audit/Independent_Audit.json');assert audit['status'].startswith('PASS_ALL60426_')
    idx=base/'actual/Physical_Component_Input_References.json.gz';closed=read(base/'actual/Closed_Manifest.json')['members'][idx.name];assert sha(idx)==(closed['sha256'] if isinstance(closed,dict) else closed)
    index=json.loads(gzip.decompress(idx.read_bytes()));matches=index.get(h,[])
    static=R/'outputs/fresh_static_component_index_20261018';r=read(static/'Results.json');sp=static/'All_Static_Component_References.json.gz';assert sha(sp)==r['index_sha256'];sm=json.loads(gzip.decompress(sp.read_bytes())).get(h,[])
    recent=[];recent_keys=[];pins=[base/'independent_audit/Independent_Audit.json',base/'actual/Closed_Manifest.json',static/'Results.json',sp]
    for folder,phases in [('exact_two_paid_query_engineering_20261018',('warm','cold')),('remaining_three_fixed_queries_20261019',('warm','cold_1','cold_2')),('fixed_four_query_acquisition_20261019',('warm','cold_1','cold_2','cold_3')),('third_point_four_query_acquisition_20261019',('warm',)),('third_point_remaining_three_query_acquisition_20261019',('warm','cold_1','cold_2'))]:
        root=R/'outputs'/folder;p=read(root/'Protocol.json');pins.append(root/'Protocol.json')
        for phase in phases:
            d=root/phase;m=read(d/'Closed_Manifest.json')['members']
            for name in ['scientific.jsonl','capsules.bin']:assert sha(d/name)==m[name]
            with (d/'capsules.bin').open('rb') as pack:
                for rawline in (d/'scientific.jsonl').read_bytes().splitlines():
                    e=json.loads(rawline)
                    if e['event']=='PF_intent':
                        physical=decode_capsule(pack,e['data']['before'])['net'];c,_=component(physical);assert c==independent_component(physical);recent.append(c)
            recent_keys.append(read(d/'Result.json')['receipt']['point_action_key']);pins += [d/'Closed_Manifest.json',d/'Result.json',d/'scientific.jsonl']
    assert len(recent)==26 and len(recent_keys)==13
    history=R/'outputs/paid_lineage_frontier_20261018/All_Lineage_Attempt_Keys.json.gz';known=set(json.loads(gzip.decompress(history.read_bytes())))|set(recent_keys)
    status='PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE' if not matches and not sm and h not in recent and key not in known else 'UNKNOWN_PRIOR_COMPONENT_OR_IDENTITY_MATCH_NO_NEW_EXECUTION'
    state['source_edge']={'role':'FIRST_REQUIRED_UNKNOWN_PAID_FOLLOWUP_OF_UNCHANGED_POLICY','saved_frontier':str((SCREEN/ref['path']).relative_to(R)),'source_raw_sha256':ref['raw_sha256'],'not_actual_commit':True,'prior_costs':'All imported prefix and queries remain separately paid; no free inputs or restarted deadline.'}
    encoded=zlib.compress(pickle.dumps(state,5),6);(I/'Exact_Current_Input.zlib').write_bytes(encoded)
    data={'status':status,'source_screen':str(SCREEN.relative_to(R)),'source_closed_manifest_sha256':sha(SCREEN/'Closed_Manifest.json'),'source_frontier':ref,'point':point_key(net,cursor),'parent':state['parent'],'current_metrics':runner.rescue.grid_metrics(net),
       'exact_new_query_rows':[{'row':row,'point_action_key':key,'role':'FIRST_REQUIRED_UNKNOWN_ORIGINAL_K4_FOLLOWUP','component_sha256':h,'perbus_rational_component':values}],
       'native_verifier_certificate':native,'remaining_original_operations':cursor['remaining_original_device_operation_slots'],'input_state_sha256':sha(I/'Exact_Current_Input.zlib'),
       'tracked60426_component_matches':len(matches),'static3418_component_matches':len(sm),'recent26_component_matches':recent.count(h),'old_exact_key_match':key in known,
       'all_recent13_paid_keys':recent_keys,'coverage_source_sha256':sha(__file__),'evidence_sha256':{str(p.relative_to(R)):sha(p) for p in pins},'workflow_seconds':time.perf_counter()-start,'new_scientific_calls':0,
       'limits':'Relevant closed source-role component absence and exact input/menu check, not universal historical closure or standalone PF authorization. New prospective owner/native verifier/persistence/source-reader gates still required. Hypothetical paid12UV child, not a new actual16UV commit.'}
    put(I/'Exact_Candidate_Inputs.json',data);manifest(I);print(json.dumps({k:data[k] for k in ['status','current_metrics','tracked60426_component_matches','static3418_component_matches','recent26_component_matches','new_scientific_calls']}))

if __name__=='__main__':main()
