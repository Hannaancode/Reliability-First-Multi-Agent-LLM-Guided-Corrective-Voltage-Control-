"""One bounded scientist then one bounded reader, exact Windows ownership ACKs."""
import hashlib,json,os,subprocess,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_inverter_linear_reference_coordination_20261020';PREP=ROOT/'outputs/native_inverter_linear_reference_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def process(pid):
    command=f'Get-CimInstance Win32_Process -Filter "ProcessId={int(pid)}" | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],capture_output=True,text=True,encoding='utf-8',timeout=30,creationflags=subprocess.CREATE_NO_WINDOW);assert r.returncode==0
    return json.loads(r.stdout) if r.stdout.strip() else None
def main():
    OUT.mkdir(exist_ok=False);p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    def launch(source,python,directory,bound):
        assert not directory.exists() and sha(source)==p['sources'][source.name]
        with (OUT/(source.stem+'.log')).open('x',encoding='utf-8') as log:
            child=subprocess.Popen([str(python),'-X','utf8',str(source)],cwd=ROOT,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);t=time.monotonic()
            while not (directory/'owner.claim').exists():assert child.poll() is None and time.monotonic()-t<60;time.sleep(.1)
            claim=json.loads((directory/'owner.claim').read_text(encoding='utf-8'));actual=process(claim['actual_pid']);parent=process(claim['parent_pid'])
            assert actual and parent and actual['ParentProcessId']==claim['parent_pid']==child.pid and source.name in actual['CommandLine'] and claim['source_sha256']==sha(source)
            put(directory/'Launcher_ACK.json',{'actual_pid':claim['actual_pid'],'actual_parent_pid':child.pid,'actual_command':actual['CommandLine'],'parent_command':parent['CommandLine'],'fresh_exact_source_PID_parent_command':True,'at_utc':datetime.now(timezone.utc).isoformat()})
            try:code=child.wait(timeout=max(1,bound-(time.monotonic()-t)))
            except subprocess.TimeoutExpired:
                current=process(claim['actual_pid'])
                if current and source.name in current['CommandLine']:subprocess.run(['taskkill.exe','/PID',str(claim['actual_pid']),'/T','/F'],capture_output=True,timeout=30)
                child.wait(timeout=30);raise
        assert process(claim['actual_pid']) is None and process(child.pid) is None
        put(OUT/(source.stem+'_End_ACK.json'),{'actual_pid':claim['actual_pid'],'launcher_pid':child.pid,'exit_code':code,'actual_owned_chain_ended':True,'elapsed_seconds':time.monotonic()-t})
        return code
    try:
        code=launch(ROOT/'work/run_native_inverter_linear_reference_20261020.py',ROOT/'work/physics_env/Scripts/python.exe',ROOT/'outputs/native_inverter_linear_reference_20261020',p['worker_bound_seconds'])
        assert code==0,'Primary partial/failed; complete-only reader must not run'
        assert (ROOT/'outputs/native_inverter_linear_reference_20261020/Closed_Manifest.json').exists()
        code=launch(ROOT/'work/audit_native_inverter_linear_reference_20261020.py',ROOT/'work/physics_env/Scripts/python.exe',ROOT/'outputs/native_inverter_linear_reference_20261020/independent_audit',p['reader_bound_seconds'])
        assert code==0,'Reader failed; preserve original claim/source/stderr; no scientific retry'
        put(OUT/'Completion.json',{'status':'PRIMARY_AND_INDEPENDENT_REPLAY_COMPLETE','at_utc':datetime.now(timezone.utc).isoformat(),'all_owned_scientist_reader_chains_ended':True,'model_PF_calls_in_coordinator':0});print('NATIVE_NUMERIC_ENGINEERING_AND_REPLAY_COMPLETE')
    except BaseException as e:put(OUT/'Failure.json',{'failure_type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main()
