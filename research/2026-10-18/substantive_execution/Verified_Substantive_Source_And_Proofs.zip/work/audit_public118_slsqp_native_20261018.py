"""Independent direct native equations, zero PF/optimizer/model applications."""
import ast,hashlib,json,os,time
from pathlib import Path
import numpy as np
from public118_slsqp_native_20261018 import R,B,read,put,sha,pins,manifest
from audit_public118_native_acopf_reference_20261015 import certify
def verify(directory):
    m=read(directory/'Closed_Manifest.json')
    for name,h in m['members'].items():assert sha(directory/name)==h,name
def main():
    started=time.perf_counter();p=read(B/'Protocol.json');pins(p);assert sha(__file__)==p['independent_reader_sha256']
    out=B/'independent_audit';out.mkdir(exist_ok=False);put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    verify(B/'actual');rows=[]
    for i,rec in enumerate(p['cases'],1):
        d=B/'actual'/f'case{i}';row={'case':rec['case'],'status':'UNKNOWN_NO_CLOSED_SOLVER_OUTPUT'}
        if (d/'Closed_Manifest.json').exists():
            verify(d);r=read(d/'Result.json');row['actual_costs']=r
            previous='0'*64;events=[]
            for line in (d/'Optimizer_Journal.jsonl').read_bytes().splitlines():
                v=json.loads(line);assert v['previous_sha256']==previous;previous=hashlib.sha256(line).hexdigest();events.append(v['event'])
            assert previous==r['journal_final_sha256'];row['journal_events']=len(events)
            if (d/'Actual_Solver_Arrays.npz').exists():
                with np.load(R/rec['full_native_ppc_path'],allow_pickle=False) as z:native={k:z[k].copy() for k in z.files}
                with np.load(d/'Actual_Solver_Arrays.npz',allow_pickle=False) as z:a={k:z[k].copy() for k in z.files}
                m=read(d/'Actual_Solver_Metadata.json');assert np.array_equal(a['gencost'],native['gencost'])
                row['native_physics']=certify(native,a['bus'],a['gen'],a['branch'],m['f'],p['native_tolerance'])
                row['solver']=m;row['status']='PASS_INDEPENDENT_NATIVE_FEASIBLE_FINAL_POINT' if row['native_physics']['all_native_constraints_and_saved_fields_pass'] else 'FINAL_POINT_FAILS_NATIVE_FEASIBILITY_NOT_A_PROOF_OF_INFEASIBILITY'
                assert events.count('optimizer_attempt')==1 and events.count('optimizer_return')==1
                assert events.count('constraint_application_attempt')==events.count('constraint_application_return')==r['actual_profile_counts']['opf_consfcn']
                assert events.count('cost_application_attempt')==events.count('cost_application_return')==r['actual_profile_counts']['opf_costfcn']
                assert r['actual_profile_counts']['makeYbus']==1
            else:row['status']='UNKNOWN_EXCEPTION_WITH_COSTS_RETAINED'
        rows.append(row)
    from candidate_process_evidence_utils import frozen_checks
    put(out/'Fresh_Frozen_Checks.json',frozen_checks())
    put(out/'Independent_Audit.json',{'status':'COMPLETE_ALL3_IDENTITIES_AVAILABLE_OUTPUTS_AND_COSTS_AUDITED','all3':rows,
        'verified_native_feasible_final_points':sum(x['status']=='PASS_INDEPENDENT_NATIVE_FEASIBLE_FINAL_POINT' for x in rows),
        'scientific_calls':0,'workflow_seconds':time.perf_counter()-started,'global_optimality':'NOT_PROVEN',
        'LLM_discrete_shunt_DSE_benchmark':'NOT_TESTED; native public all-generator ACOPF is a distinct benchmark/initialization role',
        'native_voltage_limits_preserved':'Original0.95/1.05 counts are diagnostics only, not substituted native bounds.'})
    manifest(out);print(json.dumps({'independent_all3_audit':'COMPLETE','feasible_points':sum(x['status']=='PASS_INDEPENDENT_NATIVE_FEASIBLE_FINAL_POINT' for x in rows)}))
if __name__=='__main__':main()
