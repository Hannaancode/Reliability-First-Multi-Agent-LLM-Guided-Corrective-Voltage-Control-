"""Original frozen private0.5B, six new full-band contexts and six cold outputs; no PF/training."""
import os,json,time,hashlib,gc,functools,traceback
from pathlib import Path
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN']='1';os.environ['HF_HUB_DISABLE_TELEMETRY']='1';os.environ['HF_HUB_OFFLINE']='1'
ROOT=Path(__file__).resolve().parents[1]
from public_size_u61_preservation import atomic_json,journal,Publisher,file_hash
OUT=ROOT/'outputs/public_size_science';OUT.mkdir(exist_ok=False);started=time.monotonic()
p=json.loads((ROOT/'prep/protocol.json').read_text());inputs=json.loads((ROOT/'prep/All6_Messages_And_Token_IDs.json').read_text());environment=json.loads((ROOT/'outputs/public_size_environment.json').read_text())
atomic_json(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':file_hash(__file__),'protocol_sha256':file_hash(ROOT/'prep/protocol.json'),'started_at_unix':time.time()})
costs={'model_load_attempts':0,'model_load_returns':0,'generation_attempts':0,'generation_returns':0,'pretrained_forward_attempts':0,'pretrained_forward_returns':0,'generated_token_count':0,'PF_optimizer_backward_training_calls':0};events=OUT/'events.jsonl';previous='0'*64
def event(kind,**data):
    global previous
    assert time.monotonic()-started<p['science_process_seconds']
    row={'kind':kind,'elapsed_seconds':time.monotonic()-started,'previous':previous,**data};h=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest();journal(events,{'event':row,'sha256':h});previous=h
def progress(stage):atomic_json(OUT/'progress.json',{'stage':stage,'costs':costs,'updated_unix':time.time()})
publisher=Publisher(OUT,ROOT/'outputs/public_size_transfer',wait_seconds=120)
try:
    import numpy as np
    import torch
    from transformers import AutoTokenizer
    from candidate_process_pretrained_loader_native13_v2_20261020 import load_isolated_body,preservation_inventory,verify_copy_state,source_adapter_state
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
    adapter=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for name,h in p['private_adapter_tokenizer_unchanged'].items():assert file_hash(adapter/name)==h
    tokenizer=AutoTokenizer.from_pretrained(str(adapter),local_files_only=True,trust_remote_code=False)
    for item in inputs:
        encoded=tokenizer.apply_chat_template(item['messages'],tokenize=True,add_generation_prompt=True);ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
        assert ids==item['token_ids'] and len(ids)+384<=4096
    atomic_json(OUT/'Input_And_Loader_Preconditions.json',{'all6_complete_token_sequences_exact':True,'longest_prefix':max(len(x['token_ids']) for x in inputs),'max_new_tokens':384,'all_private_file_hashes_exact':True,'exact_dependency_count':environment['exact_dependency_count'],'base_weight_sha256':environment['base_weight_sha256'],'new_serving_role_explicit':True,'no_model_generation_before_this_gate':True})
    event('input_source_context_preconditions_pass');publisher.publish('source_input_context_preconditions')
    def run_model(replica):
        torch.manual_seed(20261021);torch.cuda.manual_seed_all(20261021);np.random.seed(20261021);torch.cuda.reset_peak_memory_stats()
        costs['model_load_attempts']+=1;event('model_load_attempt',replica=replica);t=time.perf_counter()
        model,proof=load_isolated_body(Path(environment['base_snapshot']),adapter,train_body=False);costs['model_load_returns']+=1;assert not any(x.requires_grad for x in model.parameters());event('model_load_return',replica=replica,seconds=time.perf_counter()-t)
        atomic_json(OUT/f'{replica}_Loader_Proof.json',proof);before=preservation_inventory(model);atomic_json(OUT/f'{replica}_Immutable_Values_Before.json',before)
        core=model.get_base_model();original=core.forward
        @functools.wraps(original)
        def counted(*args,**kwargs):
            costs['pretrained_forward_attempts']+=1;number=costs['pretrained_forward_attempts'];event('pretrained_forward_attempt',replica=replica,number=number);t0=time.perf_counter();result=original(*args,**kwargs)
            assert torch.isfinite(result.logits).all();costs['pretrained_forward_returns']+=1;event('pretrained_forward_return',replica=replica,number=number,seconds=time.perf_counter()-t0);return result
        core.forward=counted;outputs=[]
        for item in inputs:
            prefix=torch.tensor([item['token_ids']],dtype=torch.long,device='cuda:0');mask=torch.ones_like(prefix);assert torch.equal(prefix.cpu(),torch.tensor([item['token_ids']],dtype=torch.long)) and bool(mask.all())
            costs['generation_attempts']+=1;number=costs['generation_attempts'];event('generation_attempt',replica=replica,agent=item['agent'],number=number,prefix_tokens=prefix.shape[1]);t0=time.perf_counter();forward_before=costs['pretrained_forward_returns']
            with torch.inference_mode():sequence=model.generate(input_ids=prefix,attention_mask=mask,do_sample=False,num_beams=1,max_new_tokens=384,use_cache=True,return_dict_in_generate=False,pad_token_id=tokenizer.eos_token_id)
            torch.cuda.synchronize();costs['generation_returns']+=1;new=sequence[0,prefix.shape[1]:].detach().cpu().tolist();costs['generated_token_count']+=len(new);assert 0<len(new)<=384 and costs['pretrained_forward_returns']-forward_before==len(new)
            assert torch.equal(sequence[0,:prefix.shape[1]].cpu(),prefix[0].cpu());text=tokenizer.decode(new,skip_special_tokens=True)
            result={'replica':replica,'agent':item['agent'],'physical_bus':item['physical_bus'],'token_ids':new,'raw_text':text,'prefix_token_count':prefix.shape[1],'actual_forward_returns':len(new),'generation_seconds':time.perf_counter()-t0,'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_reserved_bytes':torch.cuda.max_memory_reserved()};assert result['peak_allocated_bytes']<=12*1024**3
            atomic_json(OUT/f'{replica}_Agent_{item["agent"]}.json',result);outputs.append(result);event('generation_return',replica=replica,agent=item['agent'],number=number,generated_tokens=len(new),seconds=result['generation_seconds']);progress('one_actual_generation_preserving');publisher.publish(f'{replica}_agent_{item["agent"]}')
        after=preservation_inventory(model);atomic_json(OUT/f'{replica}_Immutable_Values_After.json',after);assert before==after;copied_after=verify_copy_state(model,source_adapter_state(adapter)[1]);atomic_json(OUT/f'{replica}_Memory_And_Source_Proof.json',{'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_reserved_bytes':torch.cuda.max_memory_reserved(),'private_input_hashes_unchanged':all(file_hash(adapter/n)==h for n,h in p['private_adapter_tokenizer_unchanged'].items()),'actual_private_LoRA_copy_after':copied_after,'all_base_private_quantized_values_and_buffers_unchanged':True,'optimizer_and_trainable_parameters':0})
        core.forward=original;del model,core,original;gc.collect();torch.cuda.empty_cache();return outputs
    primary=run_model('primary');cold=run_model('cold');assert all(a['token_ids']==b['token_ids'] for a,b in zip(primary,cold));assert costs['generation_attempts']==costs['generation_returns']==12
    result={'status':'COMPLETE_ALL6_ORIGINAL_TRAINED_LORA_PRIMARY_AND_FRESH_MODEL_COLD_FULLBAND_ENGINEERING_OUTPUTS','actual_costs':costs,'cold_all6_token_sequences_exact':True,'model_loads':2,'base_revision':p['base_for_new_experiment']['revision'],'private_weights_unchanged':True,'native_contract':'New named bidirectional full-band bus/q_mvar literal increment role; no physical calls or performance claim; strict local reader admits raw outputs without repair','model_outputs_not_physical_superiority':True,'workflow_seconds':time.monotonic()-started,'journal_last_before_result':previous}
    atomic_json(OUT/'Results.json',result);event('closed_results',result_sha256=file_hash(OUT/'Results.json'));progress('complete_preserving_final');publisher.publish('complete_results_and_immutable_source_proofs')
except BaseException as exc:
    atomic_json(OUT/'Failure.json',{'failure_type':type(exc).__name__,'failure':str(exc),'traceback':traceback.format_exc(),'actual_costs':costs,'workflow_seconds':time.monotonic()-started});progress('failed_partial_preserved');raise
