"""UNEXECUTED v2 independent saved-evidence verifier; never imports physics/model.

Run once only after collector PID9052 has ended and Closed_Manifest.json exists.
Calls the frozen receipt audit once in this same PID, retaining it even on FAIL.
"""
import ctypes
import hashlib
import json
import math
import os
import time
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PRE = ROOT / 'outputs/critical_research_reset_20261010/fresh_paid_receipt_opportunity_preparation_v1'
EXPECTED_PROTOCOL = '5bb86a39d1182be1592e364d551a8bdd42271b6a8c11b2675eac111c06a8cf0c'
GRID = [25., 50., 75., 100., 125., 150., 200., 250., 300.]
EXCLUDED = {'name', 'geo', 'geometry', 'coords', 'std_type'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def sha(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            hasher.update(block)
    return hasher.hexdigest()


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(encode(value).encode()).hexdigest()


def write(path, value):
    with Path(path).open('x', encoding='utf8') as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
        handle.flush(); os.fsync(handle.fileno())


def compare(actual, expected, tolerance=1e-10, skip_metrics=False):
    if isinstance(expected, dict):
        assert isinstance(actual, dict) and actual.keys() == expected.keys()
        for key in expected:
            if skip_metrics and key == 'global_metrics':
                continue
            compare(actual[key], expected[key], tolerance, skip_metrics)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(actual) == len(expected)
        for a, b in zip(actual, expected):
            compare(a, b, tolerance, skip_metrics)
    elif isinstance(expected, bool) or expected is None or isinstance(expected, str):
        assert actual == expected
    else:
        assert type(actual) in (int, float) and math.isfinite(float(actual))
        assert abs(float(actual) - float(expected)) <= tolerance


def frame(value):
    assert len(value['index']) == len(value['values'])
    assert len(set(value['index'])) == len(value['index'])
    assert all(len(row) == len(value['columns']) for row in value['values'])
    return {int(i): dict(zip(value['columns'], row)) for i, row in zip(value['index'], value['values'])}


def metrics(observation):
    tables = observation['physical_tables']; buses = frame(tables['res_bus'])
    assert set(buses) == set(range(118))
    vm = [buses[i]['vm_pu'] for i in range(118)]
    va = [buses[i]['va_degree'] for i in range(118)]
    assert all(type(v) in (int, float) and math.isfinite(v) for v in vm + va)
    result = {'vmin': min(vm), 'vmax': max(vm), 'vmean': sum(vm) / 118.,
              'uv_count': sum(v < .95 for v in vm), 'ov_count': sum(v > 1.05 for v in vm),
              'deficit_sum': sum(max(.95 - v, 0.) for v in vm)}
    compare(observation['global_metrics'], result)
    assert observation['global_metrics']['uv_count'] == result['uv_count']
    assert observation['global_metrics']['ov_count'] == result['ov_count']
    for zone, buses_in_zone in observation['zone_buses'].items():
        report = observation['zone_reports'][zone]
        zone_vm = {int(b): vm[int(b)] for b in buses_in_zone}
        assert report['zone'] == zone
        assert report['n_undervoltage'] == sum(v < .95 for v in zone_vm.values())
        assert report['n_overvoltage'] == sum(v > 1.05 for v in zone_vm.values())
        assert abs(report['min_voltage_pu'] - min(zone_vm.values())) <= 1e-10
        assert abs(report['max_voltage_pu'] - max(zone_vm.values())) <= 1e-10
        assert set(report['undervoltage_buses']) == {str(b) for b, v in zone_vm.items() if v < .95}
        for b, v in report['undervoltage_buses'].items():
            assert abs(v - zone_vm[int(b)]) <= 1e-10
    for table in tables.values():
        frame(table)
    return result, {'native_UV': [i for i, v in enumerate(vm) if v < .95],
                    'native_OV': [i for i, v in enumerate(vm) if v > 1.05],
                    'guard_OV': [i for i, v in enumerate(vm) if v > 1.05 + 1e-8]}, vm


def raw_base(protocol):
    raw = read(ROOT / 'work/e/pack/testbeds/federation_4mg_ieee118.json')['_object']
    result = {}
    for table, value in raw.items():
        if isinstance(value, dict) and value.get('_class') == 'DataFrame':
            rawframe = json.loads(value['_object'])
            result[table] = {int(i): dict(zip(rawframe['columns'], row))
                             for i, row in zip(rawframe['index'], rawframe['data'])}
    return result


def scenario_values(scenario, base, zones):
    values = {'load_scaling': {i: float(r['scaling']) for i, r in base['load'].items()},
              'sgen_p_mw': {i: float(r['p_mw']) for i, r in base['sgen'].items()},
              'line_in_service': {i: bool(r['in_service']) for i, r in base['line'].items()}}
    for mod in scenario['modifications']:
        if mod['action'] in ('scale_all_loads', 'scale_loads_by_zone'):
            scope = None if mod['action'] == 'scale_all_loads' else set(zones[mod['zone']])
            for i, row in base['load'].items():
                if scope is None or int(row['bus']) in scope:
                    values['load_scaling'][i] *= float(mod['factor'])
        elif mod['action'] == 'open_line':
            assert int(mod['line_idx']) in values['line_in_service']
            values['line_in_service'][int(mod['line_idx'])] = False
        else:
            raise AssertionError('Undeclared prospective modification')
    return values


def verify_receipt(root, query, root_metrics, q_metrics, base):
    original = query['original_verifier']; mediated = query['mediated_verifier']
    compare(original['before'], root_metrics)
    action = query['request']; q = GRID[action['Q_index']]
    assert action['q_abs_MVAr'] == q
    assert query['action'] == {'add_shunts_q_mvar': {str(action['bus']): q}}
    cumulative = sum(abs(float(row['q_mvar'])) for row in base.get('shunt', {}).values()
                     if int(row['bus']) == action['bus'] and str(row.get('name', '')).startswith('llm_shunt'))
    assert cumulative + q <= 450.
    if original['converged'] is False:
        assert original['after'] is None and original['accepted'] is False and original['reason'] == 'pf_failed'
        assert mediated['accepted'] is False and mediated['reason'] == 'pf_failed'
        compare(query['raw_original_score'], [-999] * 5)
        compare(query['original_score'], [-999] * 5)
        return
    assert original['converged'] is True and q_metrics is not None
    compare(original['after'], q_metrics)
    before, after = original['before'], original['after']
    reasons = []
    if after['vmax'] > 1.06:
        reasons.append('hard_overvoltage')
    if after['uv_count'] > before['uv_count']:
        reasons.append('uv_increased')
    if after['deficit_sum'] > before['deficit_sum'] + 1e-9:
        reasons.append('deficit_increased')
    improved = (after['uv_count'] < before['uv_count'] or after['deficit_sum'] < before['deficit_sum'] - 1e-9
                or after['vmin'] > before['vmin'] + 1e-9)
    if not improved:
        reasons.append('no_improvement')
    native_accept = not reasons
    assert original['accepted'] is native_accept
    assert original['reason'] == ('ACCEPTED' if native_accept else ';'.join(reasons))
    guard = after['vmax'] <= 1.05 + 1e-8
    assert mediated['original_verifier_accepted'] is native_accept
    assert mediated['original_verifier_reason'] == original['reason']
    assert mediated['accepted'] is (native_accept and guard)
    assert mediated['reason'] == ('normal_upper_band_mediation' if native_accept and not guard else original['reason'])
    mediation = mediated['normal_upper_mediation']
    assert mediation == {'upper': 1.05, 'tolerance': 1e-8, 'band_admissible': guard,
                         'rejected_original_accepted': native_accept and not guard}
    score = [int(after['uv_count'] == 0), before['uv_count'] - after['uv_count'],
             before['deficit_sum'] - after['deficit_sum'], after['vmin'] - before['vmin'], -q]
    compare(query['raw_original_score'], score if native_accept else [-999] * 5)
    compare(query['original_score'], score if native_accept and guard else [-999] * 5)


def verify_clone(root_obs, query_obs, request):
    root_tables, query_tables = root_obs['physical_tables'], query_obs['physical_tables']
    assert root_tables.keys() == query_tables.keys()
    for name in root_tables:
        if name.startswith('res_') or name == 'shunt':
            continue
        compare(query_tables[name], root_tables[name])
    root_shunts, query_shunts = frame(root_tables['shunt']), frame(query_tables['shunt'])
    assert set(root_shunts) < set(query_shunts) and len(query_shunts) == len(root_shunts) + 1
    for i in root_shunts:
        compare(query_shunts[i], root_shunts[i])
    new = query_shunts[next(iter(set(query_shunts) - set(root_shunts)))]
    assert new['bus'] == request['bus'] and new['q_mvar'] == -request['q_abs_MVAr']
    assert new['p_mw'] == 0. and new['in_service'] is True


def run():
    started = time.perf_counter(); execution = PRE / 'execution'; output = PRE / 'independent_physical_evidence_v2'
    assert not output.exists(), 'Never restart verifier owner'
    if os.name == 'nt':
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, 9052)
        if handle:
            ctypes.windll.kernel32.CloseHandle(handle)
            raise AssertionError('Collector PID9052 still exists: do not read live outputs')
    assert (execution / 'Closed_Manifest.json').exists(), 'Complete collector closure required'
    assert sha(PRE / 'Protocol.json') == EXPECTED_PROTOCOL
    protocol = read(PRE / 'Protocol.json'); manifest = read(execution / 'Closed_Manifest.json')
    assert manifest['protocol_sha256'] == EXPECTED_PROTOCOL
    assert manifest['all_source_gates_closed_unchanged'] is True
    for name, expected in manifest['files'].items():
        assert sha(execution / name) == expected, name
    for name, expected in protocol['source_sha256'].items():
        assert sha(ROOT / name) == expected, name
    assert not (PRE / 'receipt_audit').exists(), 'Frozen audit must be invoked once by this wrapper'
    output.mkdir()
    write(output / 'owner.claim', {'pid': os.getpid(), 'at_utc': datetime.now(timezone.utc).isoformat(),
                                 'reader_source_sha256': sha(Path(__file__)), 'protocol_sha256': EXPECTED_PROTOCOL})
    write(output / 'Prospective_Reader_Source_And_Protocol_Snapshot.json', {'reader_source_sha256': sha(Path(__file__)),
          'protocol_sha256': EXPECTED_PROTOCOL, 'source_sha256': protocol['source_sha256'],
          'complete_fixed_gate_fail_distinct_from_partial_UNKNOWN': True, 'new_physics_model_forecast_solve_calls': 0})
    success = False; report = {'threshold_sensitive_replay_differences': [], 'limitations': [], 'journal_accounting_contradictions': []}
    try:
        from audit_fresh_paid_receipt_opportunity_v1 import run as frozen_audit
        frozen_audit()  # Exactly ONCE in this SAME PID; never retries.
        roots = read(execution / 'All_Eight_Roots.json'); assert len(roots) == 8
        assert [r['scenario'] for r in roots] == protocol['scenarios']
        assert len({r['root_id'] for r in roots}) == 8
        base = raw_base(protocol); zones = read(ROOT / 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
        observed_queries = 0; complete_roots = 0
        for root in roots:
            values = scenario_values(root['scenario'], base, zones)
            identity = digest({'frozen_network_sha256': protocol['source_sha256']['work/e/pack/testbeds/federation_4mg_ieee118.json'],
                               'resulting_physical_values': values})
            assert root['root_id'] == identity == root['scenario']['physical_modification_sha256']
            assert root['scenario']['scenario_id'] in {s['scenario_id'] for s in protocol['scenarios']}
            if 'root_observation' not in root:
                assert root['status'] in ('invalid_root_PF_failure', 'UNKNOWN_unexecuted_resource_bound')
                continue
            observation = root['root_observation']; m, counts, vm = metrics(observation)
            assert digest(observation) == root['root_observation_sha256']
            assert observation['zone_buses'] == zones
            for table, field, value_key in (('load', 'scaling', 'load_scaling'), ('sgen', 'p_mw', 'sgen_p_mw'),
                                             ('line', 'in_service', 'line_in_service')):
                actual = {i: row[field] for i, row in frame(observation['physical_tables'][table]).items()}
                compare(actual, values[value_key])
            expected = {}
            for zone in zones:
                intersection = [b for b in observation['literal_fallback_bus_pool'] if b in observation['raw_zonal_bus_pools'][zone]]
                assert observation['raw_common_and_zone_pools'][zone] == intersection
                for bus in intersection:
                    for qi, q in enumerate(GRID):
                        cap = sum(abs(float(row['q_mvar'])) for row in base.get('shunt', {}).values()
                                  if int(row['bus']) == bus and str(row.get('name', '')).startswith('llm_shunt'))
                        if cap + q <= 450.:
                            expected.setdefault((bus, qi), []).append(zone)
            legal = [{'bus': b, 'Q_index': qi, 'q_abs_MVAr': GRID[qi], 'raw_common_AND_zone_scopes': sorted(scopes)}
                     for (b, qi), scopes in sorted(expected.items())]
            assert root['legal_actions'] == legal and [q['request'] for q in root['queries']] == legal
            query_by_pair = {(q['request']['bus'], q['request']['Q_index']): q for q in root['queries']}
            for query in root['queries']:
                if query['status'] == 'UNKNOWN_unexecuted_resource_bound':
                    continue
                observed_queries += 1; after_metrics = None
                if 'query_observation' in query:
                    after_metrics, _, _ = metrics(query['query_observation'])
                    verify_clone(observation, query['query_observation'], query['request'])
                if query['status'] == 'returned_original_verifier':
                    verify_receipt(root, query, m, after_metrics, base)
                else:
                    assert query['status'] == 'native_verifier_exception' and query['exception_type']
                assert query['end_to_end_seconds'] >= query['query_preparation_seconds'] >= 0.
                assert query['end_to_end_seconds'] + 1e-8 >= sum(c['solver_seconds'] for c in query['actual_solver_calls'])
            expected_replays = {('root', None)} | {('query', (q['request']['bus'], q['request']['Q_index']))
                                                  for q in root['queries'] if 'query_observation' in q}
            actual_replays = {(r['kind'], None if r['action'] is None else (r['action']['bus'], r['action']['Q_index'])) for r in root['replay']}
            assert expected_replays == actual_replays and len(root['replay']) == len(expected_replays)
            for replay in root['replay']:
                assert replay['status'] in ('PASS', 'FAIL')  # Original status is retained, never promoted.
                target = observation if replay['kind'] == 'root' else query_by_pair[(replay['action']['bus'], replay['action']['Q_index'])]['query_observation']
                assert replay['solver_calls'] and replay['solver_calls'][-1].get('observation') is not None, 'Actual full replay observation unavailable'
                actual = replay['solver_calls'][-1]['observation']; actual_metrics, actual_counts, actual_vm = metrics(actual)
                target_metrics, target_counts, target_vm = metrics(target)
                assert max(abs(a - b) for a, b in zip(actual_vm, target_vm)) <= 1e-10
                # UV and common guard memberships must agree EXACTLY. Only
                # native >1.05 membership at a regulated numerical boundary
                # is separately labelled; it never repairs original FAIL.
                assert actual_counts['native_UV'] == target_counts['native_UV'], 'Native UV replay membership mismatch'
                assert actual_counts['guard_OV'] == target_counts['guard_OV'], 'Common guard OV replay membership mismatch'
                normalized_actual = actual
                if actual_counts['native_OV'] != target_counts['native_OV']:
                    changed = set(actual_counts['native_OV']) ^ set(target_counts['native_OV'])
                    assert all(abs(target_vm[b] - 1.05) <= 1e-10 and abs(actual_vm[b] - 1.05) <= 1e-10 for b in changed)
                    generators = frame(target['physical_tables']['gen'])
                    regulated = {int(g['bus']) for g in generators.values()
                                 if g['in_service'] is True and abs(float(g['vm_pu']) - 1.05) <= 1e-14}
                    assert changed <= regulated, 'Native OV-only difference is not a regulated 1.05 boundary'
                    report['threshold_sensitive_replay_differences'].append({'root_id': root['root_id'], 'action': replay['action'],
                        'original_strict_replay_status_preserved': replay['status'], 'difference': 'native_OV_only_at_regulated_1.05',
                        'changed_regulated_buses': sorted(changed), 'original_discrete': target_counts, 'replayed_discrete': actual_counts,
                        'native_UV_and_guard_OV_exact': True, 'continuous_agreement_1e10': True, 'does_not_promote_original_gate': True})
                    # Shallow copies avoid duplicating full physical tables.
                    normalized_actual = dict(actual)
                    normalized_actual['zone_reports'] = {zone: {**values, 'n_overvoltage': target['zone_reports'][zone]['n_overvoltage']}
                                                         for zone, values in actual['zone_reports'].items()}
                compare(normalized_actual, target, skip_metrics=True)
                for field in ('vmin', 'vmax', 'vmean', 'deficit_sum'):
                    assert abs(actual_metrics[field] - target_metrics[field]) <= 1e-10
                if replay['status'] == 'PASS':
                    assert digest(actual) == replay['actual_observation_sha256']
                elif replay.get('actual_observation_sha256') is not None:
                    assert digest(actual) == replay['actual_observation_sha256']
                report.setdefault('original_replay_status_counts', Counter())[replay['status']] += 1
            complete_roots += int(root['status'] == 'complete_fixed_root_table')
        costs = read(execution / 'Actual_Costs_And_Closure.json')['costs']
        # Stream one JSONL event at a time; do not retain duplicated full
        # physical observations from the large solver journal.
        tallies = {}; pending = None; journal_count = 0
        with (execution / 'Actual_Observation_Journal.jsonl').open(encoding='utf8') as stream:
            for line in stream:
                event = json.loads(line); journal_count += 1
                assert event['event_index'] == journal_count
                if event['event'] == 'solver_attempt':
                    assert pending is None
                    pending = {k: event[k] for k in ('identity', 'phase', 'arguments')}
                    tallies.setdefault(event['phase'], Counter())['attempts'] += 1
                elif event['event'] == 'solver_closed':
                    assert pending is not None
                    assert pending['identity'] == event['identity'] and pending['phase'] == event['phase']
                    assert pending['arguments'] == event['arguments']
                    assert event['arguments'] in protocol['original_solver'].values()
                    assert 0. <= event['solver_seconds'] <= event['solver_and_observation_seconds']
                    tally = tallies.setdefault(event['phase'], Counter())
                    tally['closures'] += 1
                    tally['recorded_no_exception_returns'] += int(event['exception'] is None)
                    tally['recorded_exceptions'] += int(event['exception'] is not None)
                    tally['solver_seconds'] += event['solver_seconds']
                    tally['solver_and_observation_seconds'] += event['solver_and_observation_seconds']
                    pending = None
        assert pending is None and costs['journal_events'] == journal_count
        for phase in ('measurement', 'independent_new_observation_audit'):
            tally = tallies.get(phase, Counter())
            assert costs.get(phase + '_PF_attempts', 0) == tally['attempts'] == tally['closures']
            # Frozen observed_runpp increments returns immediately after
            # original_pf, then captures observation inside the SAME try.
            # Observation failure can additionally increment exceptions.
            # Its journal does not identify exception origin: any inconsistent
            # return/exception accounting remains UNKNOWN, never repaired.
            for suffix, expected in (('_PF_returns', tally['recorded_no_exception_returns']),
                                     ('_PF_exceptions', tally['recorded_exceptions'])):
                if costs.get(phase + suffix, 0) != expected:
                    report['journal_accounting_contradictions'].append({'phase': phase, 'counter': suffix,
                        'stored': costs.get(phase + suffix, 0), 'independent': expected,
                        'source_possible_cause': 'observation exception after successful original PF return; exception origin not independently saved',
                        'disposition': 'UNKNOWN'})
            for field, record_field in (('_PF_solver_seconds', 'solver_seconds'), ('_PF_end_to_end_seconds', 'solver_and_observation_seconds')):
                assert abs(costs.get(phase + field, 0.) - tally[record_field]) <= 1e-8
            obs = costs.get(phase + '_observation_seconds', 0.)
            assert 0. <= obs <= tally['solver_and_observation_seconds'] - tally['solver_seconds'] + 1e-8
        decision = read(PRE / 'receipt_audit/Decision_And_Cost_Bounds.json')
        fully_measured = (complete_roots == 8 and
                          all(r['Jacobian']['status'] == 'finite_current_Jacobian_forecasts' and
                              math.isfinite(r['Jacobian']['linear_system_residual']) and
                              r['Jacobian']['linear_system_residual'] <= 1e-8 for r in roots) and
                          all(q['status'] == 'returned_original_verifier' for r in roots for q in r['queries']) and
                          all(r['replay'] and all(replay['status'] == 'PASS' for replay in r['replay']) for r in roots))
        gate_pass = decision['status'] == 'necessary_numerical_opportunity_screen_PASS'
        disposition = ('COMPLETE_FIXED_GATE_PASS' if gate_pass else 'COMPLETE_FIXED_GATE_FAIL') if fully_measured else 'UNKNOWN_PARTIAL_OR_ORIGINAL_REPLAY_JACOBIAN_SUPPORT'
        if report['journal_accounting_contradictions']:
            disposition = 'UNKNOWN_PF_OBSERVATION_EXCEPTION_ACCOUNTING_CONTRADICTION'
        if disposition == 'COMPLETE_FIXED_GATE_FAIL':
            report['stop_this_intervention_without_retune'] = True
        from candidate_process_evidence_utils import frozen_checks
        frozen = frozen_checks()  # Nine frozen original gates exactly once.
        assert len(frozen['checks']) == 9 and frozen['all_passed']
        write(output / 'Independent_Nine_Frozen_Asset_Checks.json', frozen)
        report.update(all_independent_checks_passed=True, scientific_disposition=disposition, complete_root_tables=complete_roots,
                      actual_measured_queries=observed_queries, original_reader_decision_preserved=decision,
                      no_new_PF_controller_model_forecast_solve_cloud_calls=True,
                      costs_verified=not bool(report['journal_accounting_contradictions']),
                      original_source_identities_verified=True,
                      root_unchanged_evidence='frozen source compare assertion precedes every query_closed; independently checked same-root input-table and sole-shunt clone effects',
                      actual_continuous_observation_replay_tolerance=1e-10)
        report['current_Jacobian_independent_equation_certificate'] = 'UNKNOWN_saved_J_rhs_dVm_vectors_absent; frozen existing numerical source and recorded residual are bound, no prohibited solve/forecast reconstruction'
        report['limitations'].append('Original replay FAIL always leaves the frozen fixed gate UNKNOWN, even when independent continuous fields/native UV/guard OV agree and only regulated native OV counts differ. No promotion or rerun.')
        success = True
    except BaseException as exc:
        report.update(all_independent_checks_passed=False, scientific_disposition='EVIDENCE_VERIFICATION_FAILED_NO_RETRY',
                      exception_type=type(exc).__name__, message=str(exc), original_reader_outputs_preserved=True)
    if not (output / 'Independent_Nine_Frozen_Asset_Checks.json').exists():
        from candidate_process_evidence_utils import frozen_checks
        try:
            frozen = frozen_checks()  # Once even if preceding evidence checks failed.
            assert len(frozen['checks']) == 9 and frozen['all_passed']
            write(output / 'Independent_Nine_Frozen_Asset_Checks.json', frozen)
        except BaseException as exc:
            report.update(all_independent_checks_passed=False, scientific_disposition='EVIDENCE_VERIFICATION_FAILED_NO_RETRY',
                          frozen_gate_exception_type=type(exc).__name__, frozen_gate_message=str(exc))
            success = False
    write(output / 'Independent_Physical_Evidence_Report.json', report)
    write(output / 'Independent_Verifier_Costs.json', {'workflow_seconds_before_seal': time.perf_counter() - started,
          'new_PF_controller_model_forecast_solve_cloud_calls': 0, 'frozen_reader_invocations': 1,
          'verifier_source_sha256': sha(Path(__file__)), 'protocol_sha256': EXPECTED_PROTOCOL, 'status': 'PASS' if success else 'FAIL'})
    files = {'sources/' + Path(__file__).name: Path(__file__)}
    for folder, prefix in ((execution, 'new_study'), (PRE / 'receipt_audit', 'frozen_receipt_reader'), (output, 'independent_reader')):
        for path in folder.rglob('*'):
            if path.is_file():
                files[prefix + '/' + path.relative_to(folder).as_posix()] = path
    for name in ('Protocol.json', 'Source_Lock.json', 'Physical_Identity_Nonoverlap.json', 'Software_Readiness.json'):
        files['preparation/' + name] = PRE / name
    descriptor = {name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in files.items()}
    write(output / 'Archive_Member_Manifest.json', descriptor)
    archive = output / 'New_Study_And_Independent_Evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
        for name, path in files.items():
            zipped.write(path, name)
        zipped.write(output / 'Archive_Member_Manifest.json', 'Archive_Member_Manifest.json')
    with zipfile.ZipFile(archive) as zipped:
        assert len(zipped.namelist()) == len(set(zipped.namelist())) == len(files) + 1 and zipped.testzip() is None
        for name, item in descriptor.items():
            hasher = hashlib.sha256(); actual_bytes = 0
            with zipped.open(name) as member:
                while True:
                    block = member.read(1024 * 1024)
                    if not block:
                        break
                    actual_bytes += len(block); hasher.update(block)
            assert actual_bytes == item['bytes'] and hasher.hexdigest() == item['sha256']
    write(output / 'Local_CRC_And_All_Member_Archive_Audit.json', {'members': len(files) + 1, 'bytes': archive.stat().st_size,
          'sha256': sha(archive), 'CRC_and_all_member_hashes_passed': True, 'local_only': True,
          'total_verifier_workflow_seconds': time.perf_counter() - started})
    print(encode({'status': 'PASS' if success else 'FAIL', 'scientific_disposition': report['scientific_disposition'], 'output': str(output)}))
    if not success:
        raise RuntimeError('Independent evidence verification failed; frozen reader preserved, no retry')


if __name__ == '__main__':
    run()
