"""Read-only account resource snapshots; never allocate, switch or copy credentials."""
from pathlib import Path
from datetime import datetime,timezone
import json,logging
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
logging.disable(logging.CRITICAL)
ROOT=Path(__file__).resolve().parents[1]
profiles={'original':Path(r'C:\Users\HOME\AppData\Roaming\gcloud\application_default_credentials.json'),'isolated':Path(r'C:\Users\HOME\AppData\Roaming\gcloud-hiergrid-sheenah\application_default_credentials.json')}
class BoundedSession(AuthorizedSession):
    def request(self,*args,**kwargs):
        kwargs.setdefault('timeout',(10,25));return super().request(*args,**kwargs)
transport=Request()
def refresh(*args,**kwargs):kwargs.setdefault('timeout',25);return transport(*args,**kwargs)
def get(session,endpoint):
    response=session.get('https://colab.research.google.com/tun/m/'+endpoint,params={'authuser':'0'},headers={'X-Colab-Client-Agent':'colab-cli','Accept':'application/json'})
    response.raise_for_status();raw=response.text
    if raw.startswith(")]}'\n"):raw=raw[5:]
    return json.loads(raw)
report={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'read_only':True,'runtime_allocated':False,'credentials_copied':False,'profiles':{},'free_GPU_remaining_hours':None,'free_GPU_reset_time':None,'interpretation':'Paid compute-unit balance is not free GPU quota. Eligibility is a snapshot, not a promise of allocation or lifetime. No fixed reset or unpublished remaining hours inferred.'}
for name,path in profiles.items():
    row={'profile':name};session=None
    try:
        credentials=Credentials.from_authorized_user_file(str(path));credentials.refresh(refresh)
        session=BoundedSession(credentials,refresh_timeout=25)
        identity=session.get('https://www.googleapis.com/oauth2/v2/userinfo').json().get('email')
        if name=='isolated':assert identity=='sheenahammed@gmail.com'
        assert identity
        row['verified_account']=identity
        row['check_stage']='usage';usage=get(session,'ccu-info')
        row['usage_response_type']=type(usage).__name__
        assert isinstance(usage,dict),'Usage response is not the documented object'
        row['resource_status']={k:usage.get(k) for k in ['currentBalance','consumptionRateHourly','assignmentsCount','eligibleGpus','ineligibleGpus']}
        row['check_stage']='assignments';assignment_data=get(session,'assignments')
        assert isinstance(assignment_data,dict),'Assignments response is not the documented object'
        assignments=assignment_data.get('assignments',[])
        row['active_assignment_count']=len(assignments)
        row['active_hardware']=[{k:a.get(k) for k in ['accelerator','variant','machineShape']} for a in assignments]
        row['check_succeeded']=True
    except Exception as exc:
        row.update(check_succeeded=False,failure_type=type(exc).__name__)
        response=getattr(exc,'response',None)
        if response is not None:row['failure_http_status']=response.status_code
    finally:
        if session is not None:session.close()
    report['profiles'][name]=row
out=ROOT/'outputs/resource_checks';out.mkdir(exist_ok=True)
(out/(datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+'.json')).write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
