"""New exact18UV point, fixed four original-menu queries; no science in preparation."""
import ast,hashlib,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
def sub(t,a,b):assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
def main():
    prep=R/'outputs/third_point_four_source_preparation_20261019';prep.mkdir(exist_ok=False)
    cellpath=R/'outputs/third_point_exact_cell_20261019/Exact_Next_Cell_Scope_Addendum.json';d=read(cellpath)
    assert d['current_metrics']['uv_count']==18 and len(d['all_unexecuted_original_menu_queries'])==4
    # Prefix scanner verified eighteen recent BEFOREs; its legacy keyword
    # name retained "recent10". Add a correctly named immutable descriptor.
    for group in ('all4_pre_physics_menu','all_unexecuted_original_menu_queries'):
        for row in d[group]:row['recent18_BEFORE_matches']=row.pop('recent10_BEFORE_matches');assert row['recent18_BEFORE_matches']==row['tracked_BEFORE_matches']==row['static_observed_matches']==0
    fixed=prep/'Exact_Current_Cell.json';put(fixed,d)
    inp=R/'outputs/third_point_four_input_20261019';inp.mkdir(exist_ok=False);raw=zlib.decompress((R/d['current_input']['path']).read_bytes());assert hashlib.sha256(raw).hexdigest()==d['current_input']['raw_sha256'];state=pickle.loads(raw)
    state['source_edge']={'original_projection':state['source_paid_projection_not_actual_commit'],'frontier':d['current_input'],'point':d['point'],'all_parent_costs_retained':True}
    (inp/'Exact_Current_Input.zlib').write_bytes(zlib.compress(pickle.dumps(state,5),6));put(inp/'Exact_Candidate_Inputs.json',{'point':d['point'],'parent':d['parent'],'exact_new_query_rows':d['all_unexecuted_original_menu_queries']})
    oldnames=['fixed_four_query_core_20261019','run_fixed_four_queries_20261019','audit_fixed_four_queries_20261019','certify_fixed_four_coverage_20261019','prepare_fixed_four_queries_20261019']
    newnames=['third_point_four_query_core_20261019','run_third_point_four_queries_20261019','audit_third_point_four_queries_20261019','certify_third_point_four_coverage_20261019','prepare_third_point_four_queries_20261019']
    for old,new in zip(oldnames,newnames):
        t=(R/'work'/f'{old}.py').read_text('utf-8')
        for a,b in zip(oldnames,newnames):t=t.replace(a,b)
        t=t.replace("B=R/'outputs/fixed_four_query_acquisition_20261019'","B=R/'outputs/third_point_four_query_acquisition_20261019'").replace("I=R/'outputs/fixed_four_query_input_20261019'","I=R/'outputs/third_point_four_input_20261019'")
        if old==oldnames[0]:
            t=sub(t,'from pathlib import Path','from pathlib import Path\nfrom prospective_query_custody_v2_20261019 import bind')
            before="    from fixed_three_query_core_20261019 import known_keys as prior_keys\n    past=read(R/'outputs/remaining_three_fixed_queries_20261019/Protocol.json')\n    return set(prior_keys())|{v['point_action_key'] for v in past['exact_new_query_rows']}"
            after="    from fixed_four_query_core_20261019 import known_keys as prior_keys\n    past=read(R/'outputs/fixed_four_query_acquisition_20261019/Protocol.json')\n    return set(prior_keys())|{v['point_action_key'] for v in past['exact_new_query_rows']}"
            t=sub(t,before,after);t=sub(t,'    return env\n','    return bind(env,entrypoint)\n')
            t=t.replace("f'exact_four_fixed_query_{index + 1}'","f'exact_third_point_four_query_{index + 1}'")
        if old==oldnames[2]:
            t=sub(t,'EDITS=[','EDITS=[\n    ("assert runner.rescue.grid_metrics(source[\'net\'])[\'uv_count\']==17", "assert runner.rescue.grid_metrics(source[\'net\'])[\'uv_count\']==18"),')
        if old==oldnames[3]:
            t=t.replace("outputs/next_fixed_physical_cell_20261019/Exact_Next_Cell.json","outputs/third_point_four_source_preparation_20261019/Exact_Current_Cell.json").replace("cell['current_metrics']['uv_count']==17","cell['current_metrics']['uv_count']==18")
            marker="'PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY')]:"
            t=sub(t,marker,"'PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'),('fixed_four_query_acquisition_20261019',('warm','cold_1','cold_2','cold_3'),'audit/Independent_Audit.json','PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE')]:")
            t=t.replace('assert len(recent)==10','assert len(recent)==18').replace('recent10','recent18')
            t=sub(t,"    recent=[];files=", "    prior=read(R/'outputs/fixed_four_query_acquisition_20261019/custody_repair/Completion.json');assert prior['original_physical_evidence_checks_completed'] and prior['original_overall_complete_gate']=='UNKNOWN_LAST_PROCESS_EXIT'\n    recent=[];files=")
        if old==oldnames[4]:t=t.replace('current17UV','current18UV')
        ast.parse(t);target=R/'work'/f'{new}.py';assert not target.exists();target.write_text(t,'utf-8')
    put(prep/'Source_Preparation.json',{'new_scientific_calls':0,'source_hashes':{f'work/{n}.py':sha(R/'work'/f'{n}.py') for n in newnames},'source_current_UV_identity':18,'unchanged_thresholds_actions_solver_score_original9Q_cap_stock':True,'future_custody_cases_source':'outputs/prospective_query_custody_v2_20261019/Results.json','all4_fixed_before_outcomes':True,'old_complete_lifecycle_gate':'UNKNOWN_RETAINED','raw_scope_prefix':str(cellpath.relative_to(R))})
    print('Third-point fixed four source prepared, no science')
if __name__=='__main__':main()
