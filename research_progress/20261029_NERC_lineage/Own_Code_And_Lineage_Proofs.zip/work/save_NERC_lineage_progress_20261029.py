"""Preserve a scoped dataset finding and publish only own compact evidence."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/nerc_lineage_publication_20261029'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    p=R/p;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n','utf-8');t.replace(p)
def main():
    assert not O.exists();O.mkdir();now=datetime.now(timezone.utc).isoformat()
    evidence='outputs/nerc_release_lineage_v2_20261029/Release_Lineage_And_Grouping.json';audit='outputs/nerc_release_lineage_v2_20261029/independent_audit_v2/Independent_Lineage_Audit.json';a=rd(audit);r=rd(evidence)
    assert a['status']=='PASS_RAW_DECODE_ALL_LINE_ACCOUNTING_AND_EXACT_MEMBERSHIPS' and a['producer_result_sha256']==sha(R/evidence)
    assert a['strict_JSONL_QA']==4597 and a['single_trailing_comma_QA']==99 and a['content_QA_total_with_only_comma_syntax_normalization']==4696
    prior=rd('outputs/qa_thesis_metadata_publication_20261029/Verified_GitHub_Receipt.json');assert prior['head']=='88501897dfc852d41138cab4339dc990ad951fce' and prior['verified_downloaded_files']==7
    message='T13new independent source finding: exact archived NERC member contains4597strict JSONLQArecords plus99QArecords with one terminalcomma, giving4696contentQArecords under a separate syntax-only candidate view.91other nonblank lines retained(78lessonheadings/13other); all4787lines accounted. Notebookcell2 catchesJSONDecodeError and continues, so it would silently exclude those99QArows on these exactbytes. Originaldata/index/experiments remain unchanged. Strictquestion-ID rule gives4397rows,200withoutID,4340mappedreference rows/108distinctIDs; published4396membership stillUNRESOLVED. No exactduplicatequestions;112cross-document normalizedquestiontemplate groups are a leakage-risk map, not proof of actual split overlap. Allrows/failures/costs preserved,0model/retrieval/PF/training. T13PARTIAL;19/35complete,all6goalsOPEN.'
    (O/'Finding_And_Limits.txt').write_text('NERC RELEASE LINEAGE FINDING\n'+now+'\n\n'+message+'\n\nBefore: the reason for4597parseable versus4696paper records was unbound. After:99single-trailing-commaQArows are individually identified and independently checked. This demonstrates a concrete serialization/ingestion boundary, not a new LLM performance result. Count agreement alone does not bind the exact historical paper/index runtime.\n\nNext: locate the exact4396evaluation manifest and final source-grouped train/test membership; bind those identities to the archive views without dropping a row merely to match a reported count. Keep all data normalization as a separately versioned release, never silently replace original inputs. The current130page thesis remains unchanged; this finding is a pending evidence insert.\n','utf-8')
    insert='The archived NERC file has a mixed serialization format. A new source-bound analysis identifies4,597strictlyparseableJSON-linesrecords,99additionalquestion-answerobjectswithsingleterminalcommas,and91non-recordlines. An independent raw-decode reader confirms that the strict and candidate syntax-normalized QA views contain4,597and4,696records respectively. The supplied index-building recipe catches JSON decoding failures and continues; it would therefore skip the99comma-terminated QA objects if applied to these archived bytes. The original file is preserved, and the candidate view is not substituted into past experiments.\n\nThe same archived strict view contains4,397questions matching the notebook’s lesson-identifier pattern,200without such a match and4,340with an identifier present in the reference map. This does not reproduce the paper’s4,396retrieval-evaluation membership. Exact duplicate questions are absent in this strict view, while112normalizedquestiontemplate groups span more than one lesson identifier. These groups identify a split-design risk; they do not prove leakage into an unknown historical training or test split. The exact finalrelease,evaluationmanifestandsource-groupedpartitionsremainnecessary.\n'
    # Human-readable spacing; no original thesis or dataset mutation.
    for old,new in [('4,597strictlyparseableJSON-linesrecords','4,597 strictly parseable JSON-lines records'),('99additionalquestion-answerobjectswithsingleterminalcommas,and91non-recordlines','99 additional question-answer objects with single terminal commas, and 91 non-record lines'),('4,597and4,696records','4,597 and 4,696 records'),('the99comma-terminated','the 99 comma-terminated'),('contains4,397questions','contains 4,397 questions'),('pattern,200without','pattern, 200 without'),('match and4,340with','match and 4,340 with'),('paper’s4,396retrieval-evaluation','paper’s 4,396 retrieval-evaluation'),('while112normalizedquestiontemplate','while 112 normalized question-template'),('finalrelease,evaluationmanifestandsource-groupedpartitionsremainnecessary','final release, evaluation manifest and source-grouped partitions remain necessary')]:insert=insert.replace(old,new)
    (R/'outputs/nerc_release_lineage_v2_20261029/Thesis_Insert_Pending.txt').write_text(insert,'utf-8')
    tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json');t=next(t for t in tasks['tasks'] if t['id']=='T13');assert t['status']=='OPEN'
    t.update(status='PARTIAL_RELEASE_FORMAT_AND_SOURCE_GROUPS_INDEPENDENTLY_VERIFIED',new_scoped_progress=message);t['evidence'] += [evidence,audit]
    tasks['updated_utc']=now;assert tasks['completed_requirement_count']==19;put('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    for rel in ['outputs/research_resumption_20261028/Current_Resume.json','outputs/public_qa_scale_design_20261029/Exact_Resume.json','outputs/research_resumption_20261028/Next_Exact_Work_20261029.json']:
        x=rd(rel);x.update(at_utc=now,NERC_lineage_progress=evidence,NERC_independent_audit=audit,latest_verified_GitHub=prior['head'],latest_verified_GitHub_receipt='outputs/qa_thesis_metadata_publication_20261029/Verified_GitHub_Receipt.json');put(rel,x)
    header='## Independent NERC serialization/lineage finding — '+now+'\n\n'+message+' No ownedscientific/GPUjob. Latestreviewedthesis130pages; this newfindingpendingintegration. Exactnextwork:outputs/research_resumption_20261028/Next_Exact_Work_20261029.json.\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text(header+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+message+'\nPrevious compact publication88501897dfc852d41138cab4339dc990ad951fce verified all7remote bytes.\n')
    members=['work/analyse_NERC_release_lineage_20261029.py','work/analyse_NERC_release_lineage_v2_20261029.py','work/audit_NERC_release_lineage_20261029.py','work/audit_NERC_release_lineage_v2_20261029.py','work/'+Path(__file__).name,
      'outputs/nerc_release_lineage_20261029/Protocol.json','outputs/nerc_release_lineage_20261029/Failure.json','outputs/nerc_release_lineage_v2_20261029/Protocol.json',evidence,audit,'outputs/nerc_release_lineage_v2_20261029/independent_audit/Failure.json','outputs/nerc_release_lineage_v2_20261029/Thesis_Insert_Pending.txt']
    index=[]
    with zipfile.ZipFile(O/'Own_Code_And_Lineage_Proofs.zip','x',zipfile.ZIP_DEFLATED) as z:
        for rel in members:
            p=R/rel;b=p.read_bytes();assert not any(s.search(b.decode('utf-8-sig')) for s in SECRET),rel
            z.writestr(rel,b);index.append({'path':rel,'bytes':len(b),'sha256':sha(p)})
    with zipfile.ZipFile(O/'Own_Code_And_Lineage_Proofs.zip') as z:
        assert z.testzip() is None
        for x in index:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
    put((O/'Artifact_Index.json').relative_to(R),{'members':index,'raw_dataset_or_transcripts_published':False,'complete_raw_backup':False})
    put((O/'Current_Progress.json').relative_to(R),{'at_utc':now,'thesis_complete':19,'thesis_total':35,'all_six_goals':'OPEN','T12':'PARTIAL_SOURCE_METADATA_VALIDATOR','T13':'PARTIAL_INDEPENDENT_LINEAGE_FINDING','new_finding':message,'owned_scientific_jobs':[],'GPU_assignments':[],'waiting_timer':None,'current_reviewed_thesis_pages':130,'new_thesis_insert_pending':True})
    (O/'Thesis_Checklist.json').write_bytes((R/'outputs/thesis_research_closure_20261028/Tasks.json').read_bytes())
    files=[]
    for p in sorted(O.iterdir()):
        b=p.read_bytes();files.append({'local':p.relative_to(R).as_posix(),'path':'research_progress/20261029_NERC_lineage/'+p.name,'bytes':len(b),'sha256':sha(p),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
    put((O/'Publication_Map.json').relative_to(R),files);print(json.dumps({'status':'SAVED_SCOPED_LINEAGE_AND_PUBLICATION_PREPARED','files':len(files),'members':len(index),'thesis_complete':19}))
if __name__=='__main__':main()
