"""Evidence-driven ten-step status; unfinished campaigns never become closed."""
from pathlib import Path
import json,hashlib,datetime
from checkpoint_io import read_json_ready
from reviewer_completion_gates import completion_gates
out=Path('outputs');stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(name):
    p=out/name
    return read_json_ready(p) if p.exists() else {}
def link(name):return '['+name+'](<'+(out/name).resolve().as_posix()+'>)'
main=read('main_campaign_detailed_audit.json');preserved=read('execution_preservation_verification.json');overlap=read('training_bank_physical_overlap.json');ac=read('ac_reference_campaign_status.json');gpu=read('next_gpu_stage_status.json');auth=read('local_auth_status.json');refsum=read('ac_reference_bank_summary.json');central=read('central_matched_summary.json');centraldev=read('central_gpu_development_validation.json');phys=read('physical_replay_audit/overview.json');centralphys=read('central_physical_replay/summary.json');accompare=read('ac_reference_controller_comparison_summary.json')
main_done=main.get('checkpoint_checks',{}).get('cases')==62 and main.get('checkpoint_checks',{}).get('rng_checkpoints')==62 and preserved.get('all_passed')
ac_done=ac.get('status')=='complete' and accompare.get('case_count')==62
central_done=central.get('case_count')==62 and centraldev.get('passed') and centralphys.get('audited_case_count')==62
physical_done=phys.get('audited_cases')==62
completion=completion_gates(out)
closed=completion['all_required_experimental_evidence_complete']
package=read('reviewer_reproducibility_package_manifest.json');ten_done=bool(closed and package.get('experimental_campaigns_complete') and package.get('all_member_hashes_verified'))
states=[('Confirm saved checkpoints','complete' if main_done else 'needs_verification','62 main case and RNG files verified'),('Preserve and verify frozen assets','complete' if preserved.get('all_passed') else 'needs_verification','Model/network/settings/bank/source hashes'),('Reuse existing Google authentication','complete' if auth.get('adc_refresh_succeeded') and auth.get('assignments_http_status')==200 else 'blocked','Existing ADC refreshed; no secrets copied'),('Diagnose setup and verify current Colab GPU','complete' if centraldev.get('passed') else 'blocked_gpu_allocation','Current T4 POST attempts returned HTTP503; no assignment was left; browser check was signed out'),('Complete AC reference campaign','complete' if ac_done else ac.get('status','not_started'),f"{ac.get('completed_count',0)}/62 complete records; frozen protocol preserved"),('Validate central historical GPU cases','complete' if centraldev.get('passed') else 'awaiting_gpu','CPU context/parser/diversity checks pass; GPU checks are required'),('Complete central/zonal matched bank','complete' if central_done else 'not_started_blocked' if not gpu.get('central_bank_started') else gpu.get('stage','not_started'),f"{gpu.get('central_matched_campaign_completed_count',0)}/62 complete records"),('Finalize main paired analysis','complete' if main_done else 'pending','Full bank, clustered uncertainty, pilot/family sensitivity, failures and charged costs'),('Consolidate physical validity and reference effort','complete' if physical_done and ac_done and central_done else 'partly_complete','Main physical audit complete; reference/central integration pending'),('Close reviewer evidence and reproducibility package','complete' if closed else 'open_required_experiments','All four experiment gates required; cybersecurity remains deferred')]
comments=[{'id':1,'concern':'LLM complementarity versus deterministic trajectory diversity','status':'experimental_evidence_complete_with_null_or_adverse_result' if main_done else 'pending','evidence':['matched_campaign_protocol.json','dff_alt_development_validation.json','main_campaign_detailed_audit.json','matched_campaign_family_analysis.json','physical_effort_ledger.csv'],'conclusion':'No residual-UV advantage of HG-SE over the specified D-SE. Fewer PF calls accompany greater wall time; common DFF was selected by HG-SE in every valid case.'},{'id':2,'concern':'Evaluation on unseen physical operating points','status':'archived_input_and_bank_evidence_complete_with_lineage_and_family_limits' if main_done and overlap.get('locked_case_count')==62 else 'pending','evidence':['frozen_input_verification.json','recovered_training_provenance_assets.json','training_bank_physical_overlap.json','main_campaign_detailed_audit.json'],'conclusion':'No exact physical-modification overlap with recovered train/val/test or historical cases; all62 share training outage/DER patterns. Prior pilot awareness and incomplete final-adapter training invocation history are disclosed; no broad OOD claim.'},{'id':3,'concern':'Centralized versus four-zone proposer','status':'experimental_evidence_complete' if central_done else 'blocked_gpu_validation_and_bank_execution','evidence':['central_ablation_development_checks.json','next_gpu_stage_status.json','colab_frozen_restore_status.json'],'conclusion':'Prepared four global slots with bus-diversity exclusion, original verifier/refinement/fallback, actual token/context audits, standalone and envelope analysis. GPU performance remains unmeasured.' if not central_done else 'See complete standalone/envelope results and physical replay; claims are conditional on the frozen zonally trained adapter.'},{'id':4,'concern':'Conventional AC optimization/ORPD reference','status':'experimental_evidence_complete_with_declared_relaxation_limits' if ac_done else 'running_full_bank_reference','evidence':['ac_reference_campaign_protocol.json','ac_reference_development_validation.json','ac_reference_bank_summary.json','fixed_p_feasibility_audit.json'],'conclusion':f"{ac.get('completed_count',0)}/62 reference records; {refsum.get('voltage_only_local_references_found',0)} independently checked voltage-only references currently found. Full operating-limit feasibility is excluded by fixed-P slack balance; local solve failures are separate from infeasibility."}]
report={'updated_at_utc':stamp,'all_four_planned_reviewer_experiments_complete':closed,'coverage_basis':'Four concerns from supplied reviewer-plan paraphrase; verbatim reviewer email not present. This is experimental closure, not a claim of reviewer acceptance.','steps':[{'number':i,'task':n,'status':s,'evidence_note':e} for i,(n,s,e) in enumerate(states,1)],'comments':comments,'primary_blocker':None if central_done else 'Current free-T4 allocation fails HTTP503 despite successful existing ADC and Colab backend checks; underlying quota/capacity cause is unconfirmed.','next_dependency':'Finish active AC run and integration, then recheck GPU allocation for historical central validation before final bank. Do not change frozen controls/bank or enter cybersecurity while reviewer evidence is incomplete.'}
report['all_ten_steps_complete']=ten_done
restore=read('colab_frozen_restore_status.json');actual_gpu=read('isolated_gpu_execution_verification.json')
hardware_verified=actual_gpu.get('verified') is True and actual_gpu.get('notebook_hash')==restore.get('notebook_hash')
gpu_active=gpu.get('stage') in ['preparing_same_frozen_environment','central_gpu_development','central_matched_campaign']
if hardware_verified:
    states[3]=(states[3][0],'complete','Actual isolated-account Tesla T4, CUDA tensor execution, and frozen environment verified')
    report['steps'][3].update(status=states[3][1],evidence_note=states[3][2])
if centraldev.get('passed'):
    states[5]=(states[5][0],'complete','Both original historical GPU cases passed the frozen structural, context, diversity, and physical/numerical criteria')
    report['steps'][5].update(status=states[5][1],evidence_note=states[5][2])
    comments[2]['evidence']+=['central_gpu_development_validation.json','central_experiment_protocol.json']
if not centraldev.get('passed') and gpu.get('stage')=='central_gpu_development':
    states[5]=(states[5][0],'running_historical_GPU_validation','Two original historical development cases before any locked-bank execution')
    report['steps'][5].update(status=states[5][1],evidence_note=states[5][2])
if hardware_verified and not gpu.get('central_bank_started') and not central_done:
    states[6]=(states[6][0],'awaiting_historical_GPU_validation',states[6][2])
    report['steps'][6]['status']=states[6][1]
if gpu_active or gpu.get('stage')=='complete':
    report['primary_blocker']=None
elif not central_done and gpu.get('stage')=='interrupted' and hardware_verified:
    report['primary_blocker']=gpu.get('blocker','Central execution stopped; inspect preserved checkpoints and logs')
if not central_done and gpu_active:
    comments[2]['status']='running_historical_GPU_validation' if gpu.get('stage')=='central_gpu_development' else 'running_matched_GPU_campaign' if gpu.get('central_bank_started') else 'preparing_verified_GPU_execution'
    comments[2]['conclusion']=('Both original historical GPU cases passed; the frozen matched bank is running on the verified isolated-account T4.' if centraldev.get('passed') and gpu.get('central_bank_started') else 'Verified isolated-account T4 execution. Historical validation precedes the matched bank.')+' No architecture-performance conclusion before complete data and physical audit.'
    comments[2]['evidence']+=['isolated_cli_validation.json','isolated_gpu_execution_verification.json']
report['next_dependency']='Run central historical validation and its matched bank on the verified T4 alongside the existing local AC run, then integrate complete physical/statistical evidence and verify the final package. Cybersecurity remains deferred.' if not closed else 'All required experimental evidence is complete; verify the final reproducibility package before closing step 10.'
prefix=read('central_transfer_recovery/VERIFIED_PRESERVED_PREFIX_MANIFEST.json')
central_display=f"{gpu.get('central_matched_campaign_completed_count',0)}/62 live records"
if not central_done and prefix.get('verified_original_pairs') and not prefix.get('all_expected_pairs_present'):
    preserved_count=prefix['verified_original_pairs'];missing_ids=[r['scenario_id'] for r in prefix['missing']]
    central_display=f"{preserved_count}/62 verified original pairs in separate staging; {gpu.get('central_matched_campaign_completed_count',0)}/62 live records"
    note=f"{preserved_count}/62 original case/RNG pairs independently verified in staging; final two missing; no incomplete publication"
    states[6]=(states[6][0],'blocked_missing_saved_case_RNG_pairs',note)
    report['steps'][6].update(status=states[6][1],evidence_note=note)
    report['primary_blocker']='Central remote experiment returned exit 0, but transfer stopped after 60 pairs and the original runtime was released. Final two case/RNG pairs are unavailable; controlled two-case checkpoint recovery awaits user authorization. This is not a current GPU allocation failure.'
    report['next_dependency']='Continue active AC independently. Obtain authorization for only the two missing central cases from verified case-60 RNG, then verify complete identities before integration, physical/statistical audits and final package. Authorized historical security development is separate; its GPU queue is stopped behind preservation gates.'
    comments[2].update(status='blocked_missing_final_outputs_after_completed_remote_execution',conclusion=note+'. Missing IDs: '+', '.join(missing_ids)+'. No final architecture conclusion without the complete ledger and audit.')
    comments[2]['evidence']+=['central_transfer_recovery/VERIFIED_PRESERVED_PREFIX_MANIFEST.json','central_transfer_recovery/RECOVERY_BLOCKER.md']
recovery=read('central_checkpoint_recovery/status.json')
if not central_done and recovery.get('user_authorized_missing_indices')==[61,62]:
    recovery_stage=recovery.get('stage','unknown')
    ready=recovery.get('new_central_pairs_downloaded')==2 and read('central_transfer_recovery/status.json').get('stage')=='existing_runtime_files_staged_only'
    if ready:
        central_display='62/62 preserved pairs: 60 originals plus two authorized checkpoint recovery executions'
        note=central_display+'; complete physical/statistical audits still required'
        state_name='awaiting_integration_and_audits'
        if gpu.get('verified_case_RNG_integration') is True and central.get('case_count')==62:
            state_name='awaiting_full_physical_replay'
            note=central_display+'; verified integration and paired analysis complete; independent physical replay '+str(centralphys.get('audited_case_count',0))+'/62'
        report['primary_blocker']=None
    else:
        note='60 original pairs preserved; authorized recovery of only final two is '+recovery_stage
        state_name='running_authorized_two_case_recovery' if recovery_stage!='blocked_or_interrupted' else 'checkpoint_recovery_interrupted'
        report['primary_blocker']=None if recovery_stage!='blocked_or_interrupted' else 'Approved checkpoint recovery interrupted; inspect its sanitized status and retained-runtime ownership before resuming'
    states[6]=(states[6][0],state_name,note);report['steps'][6].update(status=state_name,evidence_note=note)
    comments[2].update(status=state_name,conclusion=note+'. No final architecture claim before the full ledger and independent audits.')
    comments[2]['evidence']+=['central_checkpoint_recovery/status.json']
    report['next_dependency']='The single approved controller recovers only two missing cases and then runs the historical security pilot on the same validated T4. Integrate only verified complete artifacts, continue AC independently, then complete physical/statistical audits and final reproducibility gates.'
    if ready and gpu.get('verified_case_RNG_integration') is True:
        report['next_dependency']='Finish the active AC reference, complete its comparison and all central physical replays, then verify preservation and the final reproducibility package through the single ordered supervisor. The recovered central files are integrated and their paired analysis is complete; the separate real-model historical security pilot is completed and audited.'
        comments[2]['evidence']+=['central_recovery_provenance.json','central_recovery_resume_verification.json','central_recovery_timing_sensitivity.json','central_matched_summary.json']
report['steps'][-1]['evidence_note']='All four reviewer evidence gates required; full security evaluation awaits baseline closure; historical security development tracked separately'
states[-1]=(states[-1][0],states[-1][1],report['steps'][-1]['evidence_note'])
report['completion_evidence_gates']=completion
states[-1]=(states[-1][0],'complete' if ten_done else 'open_final_package' if closed else 'open_required_experiments',states[-1][2])
report['steps'][-1]['status']=states[-1][1]
(out/'reviewer_closure_status.json').write_text(json.dumps(report,indent=2))
lines=['# Reviewer experiment closure',f'\nUpdated {stamp}.\n',report['coverage_basis'],'\nAll four planned experiments complete: **'+str(closed)+'**.\n','| Step | Task | Status | Evidence / next requirement |','|---:|---|---|---|']
lines += [f'| {i} | {n} | {s} | {e} |' for i,(n,s,e) in enumerate(states,1)]
for c in comments:
    lines+=['\n## Comment '+str(c['id'])+': '+c['concern'],'\nStatus: **'+c['status']+'**.\n',c['conclusion'],'\nEvidence: '+', '.join(link(p) for p in c['evidence'])+'.\n']
lines+=['\n## Paper and justification','\n'+link('HierGrid_Revision_Sections.md')+' contains focused replacement sections based on confirmed results. '+link('Experiment_Method_Justification.md')+' connects design decisions to primary literature. Central and full-reference conclusions remain explicit pending sections until their data are complete.','\nFull security evaluation awaits audited baseline closure. Authorized historical development is tracked separately in '+link('security/Experiment_Protocol.md')+'. The original paper, model, settings, and locked bank are preserved.']
lines+=['\nAdditional completed checks: '+link('effective_operating_point_overlap.json')+' compares the actually applied physical inputs, and '+link('physical_trajectory_validity.json')+' aggregates all initial and accepted-action replay states. The completion gates above retain every missing experimental dependency.']
(out/'Reviewer_Comment_Closure.md').write_text('\n'.join(lines),encoding='utf-8')
active='# Active experiment status\n\nUpdated '+stamp+'.\n\n'+f"Main: 62/62 complete. AC reference: {ac.get('completed_count',0)}/62 complete; status `{ac.get('status','unknown')}`. Central: {gpu.get('central_matched_campaign_completed_count',0)}/62; status `{gpu.get('stage','unknown')}`.\n\n"+link('Reviewer_Comment_Closure.md')+' is the current ten-step and four-comment evidence tracker. Earlier pause/status notes are historical snapshots. Original frozen assets remain unchanged.\n\nNext dependency: finish the active AC campaign and its full-bank audit, then retry GPU access for historical central validation and the matched bank. Final packaging is gated on complete evidence. Cybersecurity remains deferred.\n'
(out/'Active_Experiments.md').write_text(active,encoding='utf-8')
active=active.replace('Next dependency: finish the active AC campaign and its full-bank audit, then retry GPU access for historical central validation and the matched bank. Final packaging is gated on complete evidence. Cybersecurity remains deferred.','Next dependency: '+report['next_dependency'])
active=active.replace(f"Central: {gpu.get('central_matched_campaign_completed_count',0)}/62;",'Central: '+central_display+';')
(out/'Active_Experiments.md').write_text(active,encoding='utf-8')
print('REVIEWER_CLOSURE_UPDATED','all_four_complete',closed,'AC',ac.get('completed_count',0),'central',gpu.get('central_matched_campaign_completed_count',0),flush=True)
