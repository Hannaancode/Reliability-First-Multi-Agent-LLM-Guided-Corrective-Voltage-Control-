"""Fixed two-arm dense-response learning; new study, no solver or cloud API."""
from pathlib import Path
from datetime import datetime,timezone
import gc,hashlib,json,os,time,traceback
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
os.environ.update(HF_HOME=str(ROOT/'cache/huggingface'),HF_HUB_OFFLINE='1',HF_HUB_DISABLE_IMPLICIT_TOKEN='1',HF_HUB_DISABLE_TELEMETRY='1',CUBLAS_WORKSPACE_CONFIG=':4096:8')
import torch,pandapower as pp
from peft import get_peft_model_state_dict,set_peft_model_state_dict
from huggingface_hub import snapshot_download
from candidate_process_pretrained_loader import load_isolated_body,preservation_inventory,ADAPTER_NAME
from candidate_process_body_intervention_query_v2 import SharedCurrentProcessInterface,PretrainedCurrentProcessPrototype
from candidate_process_numerical_predictor import process_objective
from vcsa_memory_execution import MemoryExecution
PREP=ROOT/'outputs/llm_value_candidate_development_20261009/pretrained_learning_preparation'
OUT=ROOT/'outputs/llm_value_candidate_development_20261009/pretrained_learning_science'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def main():
    assert not OUT.exists();OUT.mkdir(parents=True);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
    began=time.perf_counter();protocol=read(PREP/'protocol.json');journal=(OUT/'events.jsonl').open('x');all_counts={};loads=[];memory=None;active_arm=None
    forbidden={'PF_attempts':0,'generation_attempts':0}
    def event(kind,**kw):
        record={'event':kind,'arm':active_arm,'elapsed_seconds':time.perf_counter()-began,**kw}
        journal.write(json.dumps(record,allow_nan=False)+'\n');journal.flush();os.fsync(journal.fileno())
        tmp=OUT/'progress.tmp';tmp.write_text(json.dumps({'stage':kind,'active_arm':active_arm,'counts':all_counts,'elapsed_seconds':time.perf_counter()-began}));tmp.replace(OUT/'progress.json')
    def prohibit_PF(*a,**kw):forbidden['PF_attempts']+=1;raise AssertionError('No numerical PF in pretrained learning')
    pp.runpp=prohibit_PF
    import pandapower.powerflow
    pandapower.powerflow._powerflow=prohibit_PF
    def bound():assert time.perf_counter()-began<protocol['science_bound_seconds'],'Fixed science bound reached; retain actual partials'
    def forward(wrapper,row,phase,inputs,counts):
        bound();ident=row['observation_id'];x=inputs[ident];call=counts['forward_attempts']+1
        counts['forward_attempts']+=1;counts['soft_embedding_positions']+=237
        counts['typed_record_inputs']+=len(x['field_ids']);counts['value_utf8_input_bytes']+=sum(map(len,x['value_bytes']))
        event('forward_attempt',phase=phase,call=call,observation_id=ident);tick=time.perf_counter()
        try:score=wrapper(x);torch.cuda.synchronize()
        except BaseException:counts['forward_exceptions']+=1;event('forward_exception',phase=phase,call=call,observation_id=ident);raise
        counts['forward_returns']+=1;event('forward_return',phase=phase,call=call,observation_id=ident,seconds=time.perf_counter()-tick)
        return score
    def evaluate(wrapper,rows,phase,inputs,counts,folder):
        wrapper.eval();tick=time.perf_counter();scores={}
        with torch.no_grad():
            for row in rows:scores[row['observation_id']]=forward(wrapper,row,phase,inputs,counts).cpu()
        torch.save(scores,folder/(phase+'_scores.pt'))
        elapsed=time.perf_counter()-tick;counts['evaluation_and_reload_seconds']+=elapsed
        event('evaluation_closed',phase=phase,actual_ids=len(scores),seconds=elapsed);return scores
    try:
        for name,digest in read(PREP/'Program_Input_Manifest.json').items():assert sha(ROOT/name)==digest
        assert read(ROOT/'outputs/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
        environment=read(ROOT/'outputs/remote_frozen_environment.json');assert environment==read(PREP/'Expected_Environment.json')
        assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
        torch.use_deterministic_algorithms(True);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
        torch.backends.cuda.enable_flash_sdp(False);torch.backends.cuda.enable_mem_efficient_sdp(False);torch.backends.cuda.enable_math_sdp(True)
        proof=read(ROOT/'outputs/frozen_input_verification.json');adapter=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
        cfg=read(adapter/'adapter_config.json');snapshot=Path(snapshot_download(cfg['base_model_name_or_path'],revision=environment['base_revision_verified'],local_files_only=True))
        assert sha(snapshot/'model.safetensors')==environment['base_weight_sha256']
        rows=sorted(read(PREP/'Input_Index.json'),key=lambda r:r['observation_id']);targets_index=read(PREP/'Target_Index.json')
        assert len(rows)==311 and len(targets_index)==238
        inputs={r['observation_id']:torch.load(PREP/r['tensor_path'],weights_only=True,map_location='cpu') for r in rows}
        targets={r['observation_id']:torch.load(PREP/r['tensor_path'],weights_only=True,map_location='cpu') for r in targets_index}
        training=sorted((r for r in targets_index if r['split']=='optimization'),key=lambda r:r['observation_id']);assert len(training)==187
        common=torch.load(PREP/'Common_Initial_Interface.pt',weights_only=True,map_location='cpu')
        write(OUT/'protocol.json',protocol);write(OUT/'Initial_Identity.json',{'actual_T4':True,'exact_owned_runtime_released':False,'engineering_integration_certificate_sha256':protocol['integration_certificate_sha256']})
        for arm in protocol['arms']:
            active_arm=arm;torch.manual_seed(protocol['seed']);folder=OUT/arm;folder.mkdir()
            counts={'forward_attempts':0,'forward_returns':0,'forward_exceptions':0,'backward_attempts':0,'backward_returns':0,'optimizer_steps':0,
              'optimizer_exceptions':0,'soft_embedding_positions':0,'typed_record_inputs':0,'value_utf8_input_bytes':0,'training_workflow_seconds':0.,'evaluation_and_reload_seconds':0.}
            all_counts[arm]=counts;train_body=arm=='copied_original_LoRA_body'
            model,load=load_isolated_body(snapshot,adapter,train_body=train_body);loads.append({'arm':arm,'stage':'learning',**load})
            def prohibit_generation(*a,**kw):forbidden['generation_attempts']+=1;raise AssertionError('No language generation in process forward')
            model.generate=prohibit_generation
            shared=SharedCurrentProcessInterface(protocol['semantic_types']).cuda();shared.load_state_dict(common)
            wrapper=PretrainedCurrentProcessPrototype(shared,model)
            actual={n:p for n,p in wrapper.named_parameters() if p.requires_grad};expected=9087967 if train_body else 289759
            assert sum(p.numel() for p in actual.values())==expected
            before=preservation_inventory(model);write(folder/'Frozen_Base_Before.json',before)
            original_copy={n:v.cpu().clone() for n,v in get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False).items()}
            optimizer_groups=[{'params':list(shared.parameters()),'lr':protocol['common_learning_rate']}]
            if train_body:optimizer_groups.append({'params':[p for p in model.parameters() if p.requires_grad],'lr':protocol['copy_learning_rate']})
            optimizer=torch.optim.AdamW(optimizer_groups,weight_decay=protocol['weight_decay'])
            torch.cuda.reset_peak_memory_stats();memory=MemoryExecution(model)
            evaluate(wrapper,rows,'untrained',inputs,counts,folder)
            training_tick=time.perf_counter();history=[]
            for epoch in range(1,6):
                wrapper.train();losses=[]
                for row in training:
                    optimizer.zero_grad(set_to_none=True);score=forward(wrapper,row,'training',inputs,counts)
                    target={n:v.cuda() for n,v in targets[row['observation_id']].items()}
                    loss,parts=process_objective(score,target)
                    weight=187/(protocol['active_optimization_worlds']*protocol['optimization_world_target_counts'][row['world_sha256']])
                    event('backward_attempt',epoch=epoch,observation_id=row['observation_id'],world_weight=weight,loss=float(loss.detach()),parts=parts)
                    counts['backward_attempts']+=1;(loss*weight).backward();torch.cuda.synchronize();counts['backward_returns']+=1
                    assert all(p.grad is not None and bool(torch.isfinite(p.grad).all()) for p in actual.values())
                    norm=torch.nn.utils.clip_grad_norm_(actual.values(),protocol['gradient_clip'],error_if_nonfinite=True)
                    event('backward_return',epoch=epoch,observation_id=row['observation_id'],actual_gradient_tensors=len(actual),gradient_clip_norm=float(norm))
                    event('optimizer_attempt',epoch=epoch,observation_id=row['observation_id'],step=counts['optimizer_steps']+1)
                    try:optimizer.step();torch.cuda.synchronize()
                    except BaseException:counts['optimizer_exceptions']+=1;raise
                    counts['optimizer_steps']+=1;event('optimizer_return',epoch=epoch,observation_id=row['observation_id'],step=counts['optimizer_steps'])
                    losses.append(float(loss.detach()))
                checkpoint={'common':shared.state_dict(),'copied_adapter':get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False)}
                checkpoint_path=folder/f'Epoch{epoch}_Actual_Checkpoint.pt';tick=time.perf_counter();torch.save(checkpoint,checkpoint_path)
                event('epoch_checkpoint_preserved',epoch=epoch,checkpoint=str(checkpoint_path.relative_to(OUT)).replace('\\','/'),sha256=sha(checkpoint_path),seconds=time.perf_counter()-tick,actual_steps=counts['optimizer_steps'])
                history.append({'epoch':epoch,'actual_steps':187,'state_loss_mean':sum(losses)/len(losses)})
            counts['training_workflow_seconds']=time.perf_counter()-training_tick;write(folder/'Actual_Training_History.json',history)
            final=evaluate(wrapper,rows,'final_epoch5',inputs,counts,folder)
            updated=get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False)
            changed={name:not torch.equal(updated[name].cpu(),value) for name,value in original_copy.items()}
            assert all(changed.values()) if train_body else not any(changed.values())
            write(folder/'Actual_Copy_Tensor_Updates.json',changed)
            write(folder/'Frozen_Base_After.json',preservation_inventory(model));assert preservation_inventory(model)==before
            assert all(sha(adapter/n)==h for n,h in proof['model_files'].items())
            execution={'actual_decoder_invocations':memory.decoder_invocations,'actual_checkpoint_requests':memory.checkpoint_requests};memory.close();memory=None
            peak={'allocated_bytes':torch.cuda.max_memory_allocated(),'reserved_bytes':torch.cuda.max_memory_reserved()}
            del optimizer,wrapper,shared,model,actual,original_copy,updated,checkpoint,score,loss,target;gc.collect();torch.cuda.empty_cache()
            fresh,load2=load_isolated_body(snapshot,adapter,train_body=False);loads.append({'arm':arm,'stage':'fresh_checkpoint_reload',**load2})
            checkpoint=torch.load(folder/'Epoch5_Actual_Checkpoint.pt',weights_only=True,map_location='cpu')
            set_peft_model_state_dict(fresh,checkpoint['copied_adapter'],adapter_name=ADAPTER_NAME)
            actual_adapter=get_peft_model_state_dict(fresh,adapter_name=ADAPTER_NAME,save_embedding_layers=False)
            assert all(torch.equal(v.cpu(),checkpoint['copied_adapter'][n]) for n,v in actual_adapter.items())
            shared=SharedCurrentProcessInterface(protocol['semantic_types']).cuda();shared.load_state_dict(checkpoint['common'])
            replay_wrapper=PretrainedCurrentProcessPrototype(shared,fresh)
            replay=evaluate(replay_wrapper,rows,'fresh_model_checkpoint_reload',inputs,counts,folder)
            assert all(torch.equal(final[i],replay[i]) for i in final) and preservation_inventory(fresh)==before
            assert counts['optimizer_steps']==counts['backward_returns']==counts['backward_attempts']==935
            assert counts['forward_attempts']==counts['forward_returns']==1868
            write(folder/'summary.json',{'completed':True,'counts':counts,'actual_trainable_parameters':expected,'all311_fresh_scores_exact':True,
               'actual_copy_tensors_changed':sum(changed.values()),'frozen_base_and_private_files_unchanged':True,'CUDA_peak_memory':peak,'decoder_execution':execution})
            event('arm_complete',counts=counts);del fresh,shared,replay_wrapper,actual_adapter,checkpoint;gc.collect();torch.cuda.empty_cache()
        assert forbidden=={'PF_attempts':0,'generation_attempts':0}
        assert all(sha(adapter/n)==h for n,h in proof['model_files'].items()) and sha(snapshot/'model.safetensors')==environment['base_weight_sha256']
        write(OUT/'Actual_Model_Load_Records.json',loads)
        summary={'completed':True,'completed_at_utc':datetime.now(timezone.utc).isoformat(),'actual_total_science_workflow_seconds':time.perf_counter()-began,
          'arms':all_counts,'forbidden_call_counts':forbidden,'total_optimizer_steps':1870,'total_pretrained_forwards':3736,'all_fresh_checkpoints_exact':True,
          'full_policy_and_LLM_superiority_not_established_by_training':True}
        write(OUT/'summary.json',summary);event('science_complete',summary=summary)
    except BaseException as exc:
        event('terminal_failure',exception=type(exc).__name__,all_actual_counts=all_counts)
        write(OUT/'Terminal_Failure.json',{'exception':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'actual_counts':all_counts,'forbidden_counts':forbidden,'no_scientific_restart':True})
        raise
    finally:
        if memory is not None:memory.close()
        journal.close()
        files={p.relative_to(OUT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.rglob('*') if p.is_file() and p.name not in {'owner.claim','progress.json'}}
        write(OUT/'Closed_Actual_Manifest.json',files)
if __name__=='__main__':main()
