"""New source-specific software gates. No model, dataset label or GPU calls."""
from pathlib import Path
import hashlib, json, shutil
from public_qa_inference_worker_v2_20261029 import run
from audit_public_qa_worker_20261029 import audit
from public_qa_remote_supervisor_20261029 import watchdog_reason
from public_qa_transfer_20261029 import publish_packet, accept_packet
R = Path(__file__).resolve().parents[1]; O = R / 'outputs/public_qa_supervision_20261029/software'

class Fake:
    calls = 0
    def __init__(self, a, o): self.a = a; self.n = 0; self.cold = False
    def verify_input(self, row): assert row['input_ids'] == [1]
    def seed(self): pass
    def synthetic_ids(self, n): return [2] * n
    def reload(self): self.cold = True
    def capture(self, p): p.write_bytes(b'FAKE'); return hashlib.sha256(b'FAKE').hexdigest()
    def generate(self, ids, bound, minimum=0):
        Fake.calls += 1
        if minimum: assert minimum == bound == 256
        else:
            self.n += 1
            if self.n == self.a.get('fake_fail'): raise RuntimeError('Synthetic call failure')
        return {'new_token_ids':[65] * (256 if minimum else 1), 'raw_text':'A' * (256 if minimum else 1),
            'elapsed_seconds':0., 'peak_allocated_bytes':0, 'peak_reserved_bytes':0}

def main():
    O.mkdir(exist_ok=False)
    a = {'model':'MOCK', 'revision':'MOCK', 'records':150, 'seed':1, 'setup_seconds':30, 'science_seconds':30}
    pack = {'model':'MOCK','revision':'MOCK','questions':[{'question_id':i,'rendered_prefix':'MOCK','input_ids':[1],'input_tokens':1} for i in range(150)]}
    checks = []; acknowledgements = []
    def callback(stage):
        n = len(acknowledgements); d = publish_packet(O/'complete', O/'transfer', n)
        blocks = [(O/'transfer'/f'packet_{n:03d}'/x['name']).read_bytes() for x in d['parts']]
        acknowledgements.append(accept_packet(d,blocks,O/'host_copy'))
    result = run(a, pack, O/'complete', Fake, callback)
    assert result['status'] == 'COMPLETE' and len(acknowledgements) == 151
    d = publish_packet(O/'complete', O/'transfer', 151,True,0)
    blocks = [(O/'transfer'/'packet_151'/x['name']).read_bytes() for x in d['parts']]
    accept_packet(d,blocks,O/'host_copy'); audit(O/'host_copy/study',list(range(150)))
    checks.append('complete150_every_barrier_preserved_and_audited')
    run({**a,'fake_fail':4}, pack,O/'failure',Fake)
    proof = audit(O/'failure',list(range(150))); assert proof['completed']==3 and proof['unknown_attempts']==1
    checks.append('single_failed_attempt_retained_no_repeat')
    def unavailable(stage): raise TimeoutError('Mock host missing; refuse science')
    run(a,pack,O/'unacknowledged',Fake,unavailable)
    assert audit(O/'unacknowledged',list(range(150)))['attempted']==0
    checks.append('no_local_ack_no_test_inference')
    before = Fake.calls; run(a,{**pack,'model':'WRONG'},O/'bad_input',Fake)
    assert Fake.calls==before and (O/'bad_input/Closed_Manifest.json').exists()
    checks.append('invalid_input_closed_before_backend')
    limits={'process_seconds':50,'setup_seconds':10,'science_seconds':20,'call_seconds':5}
    for events, now, expected in [([],10,'absolute_setup_bound'),([],50,'absolute_process_bound'),
        ([{'kind':'science_start','at_monotonic':3}],23,'absolute_science_bound'),
        ([{'kind':'science_start','at_monotonic':3},{'kind':'generation_attempt','at_monotonic':4}],9,'single_call_bound')]:
        assert watchdog_reason(events,now,0,limits)==expected; checks.append(expected)
    assert watchdog_reason([{'kind':'science_start','at_monotonic':3},{'kind':'generation_attempt','at_monotonic':4},
        {'kind':'generation_return','at_monotonic':5}],9,0,limits) is None
    checks.append('completed_call_not_timed_out')
    forged=json.loads(json.dumps(d)); forged['members']['../escape']=forged['members'].pop('Result.json')
    try: accept_packet(forged,blocks,O/'forged_host')
    except AssertionError: checks.append('forged_transfer_member_rejected')
    else: raise AssertionError('Forged path accepted')
    tampered=list(blocks); tampered[0]=b'x'+tampered[0][1:]
    try: accept_packet(d,tampered,O/'tampered_host')
    except AssertionError: checks.append('changed_transfer_bytes_rejected')
    else: raise AssertionError('Changed bytes accepted')
    report={'status':'PASS_11_NEW_SOURCE_BOUND_SOFTWARE_GATES','checks':checks,'actual_model_GPU_PF_calls':0,
        'source_sha256':{n:hashlib.sha256((R/'work'/n).read_bytes()).hexdigest() for n in [
        'public_qa_inference_worker_v2_20261029.py','public_qa_transfer_20261029.py','public_qa_remote_supervisor_20261029.py',Path(__file__).name]},
        'limits':'Mocks exercise transfer and watchdog decisions; actual Linux signal/process integration and GPU integration are separate unentered gates.'}
    assert len(checks)==11
    (O/'Result.json').write_text(json.dumps(report,indent=2),'utf-8'); print(json.dumps({'status':report['status'],'checks':len(checks)}))
if __name__=='__main__':main()
