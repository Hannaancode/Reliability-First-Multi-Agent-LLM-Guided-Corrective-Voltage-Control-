"""Read-only descriptive snapshot of saved cases; never a full-bank analysis."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, math
from checkpoint_io import read_json_ready

out=Path('outputs')
stage=out/'central_transfer_recovery/central_matched_campaign'
progress=read_json_ready(stage/'progress.json')
protocol=read_json_ready(out/'central_experiment_protocol.json')
lock=read_json_ready(Path('work/e/bank/BANK_LOCK.json'))
expected=[Path(n).stem for n in sorted(lock['scenario_file_sha256'])]
assert progress['completed_ids']==expected[:progress['completed_count']]
branches=['HG-VF','CENTRAL-VF']
totals={name:Counter() for name in branches}; comparisons=Counter(); invalid=[]; groups=Counter(); rows=[]; fits=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for sid in list(progress['completed_ids']):
    path=stage/'cases'/(sid+'.json')
    rng=stage/'rng'/f'{expected.index(sid)+1:03d}.pt'
    if not path.exists() or not rng.exists():break
    record=read_json_ready(path)
    assert record['protocol']==protocol and record['scenario_sha256']==lock['scenario_file_sha256'][path.name]
    groups['load_1p3' if '_1p3_' in sid else 'load_1p4']+=1
    metrics={}
    for name in branches:
        branch=record['branches'][name]; final=branch.get('final_metrics') or {}
        finite=bool(branch.get('base_converged') and final and all(isinstance(v,(int,float)) and math.isfinite(v) for v in final.values()))
        totals[name]['finite_terminal_cases']+=int(finite)
        totals[name]['finite_uv_clear_cases']+=int(finite and final['uv_count']==0)
        if finite:
            totals[name]['residual_uv_sum']+=final['uv_count'];metrics[name]=final
        totals[name]['branch_exceptions']+=int(branch.get('status')=='exception')
        for key in ['pf_attempts','pf_exceptions','llm_calls','llm_exceptions','input_tokens','output_tokens','wall_seconds','pf_wall_seconds','llm_wall_seconds']:
            totals[name][key]+=record['costs'][name][key]
        if name=='CENTRAL-VF':
            fits.extend(log.get('llm_info',{}).get('central_prompt') for log in branch.get('logs',[]) if log.get('llm_info',{}).get('central_prompt'))
    if len(metrics)==2:
        delta=metrics['CENTRAL-VF']['uv_count']-metrics['HG-VF']['uv_count']
        comparisons['central_fewer_residual_uv' if delta<0 else 'zonal_fewer_residual_uv' if delta>0 else 'equal_residual_uv']+=1
    else:invalid.append(sid)
    rows.append({'scenario_id':sid,'case_sha256':sha(path),'rng_sha256':sha(rng)})
ac_status=read_json_ready(out/'ac_reference_campaign_status.json')
ac_rows=[]
for sid in list(ac_status['completed_ids']):
    path=out/'ac_reference_campaign/cases'/(sid+'.json');case=read_json_ready(path)
    ac_rows.append({'scenario_id':sid,'case_sha256':sha(path),'reference_found':case.get('selected_local_voltage_reference') is not None})
report={'snapshot_at_utc':datetime.now(timezone.utc).isoformat(),'descriptive_only':True,'not_final_analysis_or_significance_test':True,'central_cases_captured':len(rows),'load_composition':dict(groups),'central_invalid_numeric_pair_ids':invalid,'central_standalone_branch_totals':{k:dict(v) for k,v in totals.items()},'central_paired_residual_uv_counts':dict(comparisons),'central_prompt_checks':{'queries_audited':len(fits),'physical_observation_truncations':sum(bool(f['physical_observation_truncated']) for f in fits),'max_input_tokens':max((f['input_tokens'] for f in fits),default=None),'input_plus_generation_within_4096':all(f['input_tokens']+384<=4096 for f in fits)},'ac_completed_records_captured':len(ac_rows),'ac_voltage_only_references_found':sum(r['reference_found'] for r in ac_rows),'central_source_records':rows,'ac_source_records':ac_rows,'limitations':['Sorted, incomplete bank; load groups are currently unbalanced. No final effect, p-value, or superiority claim.','Central independent physical replay remains pending except the first case; frozen full operating-limit feasibility is a separate issue.','No frozen controls, model, bank, campaign outputs, final analysis, or completion status modified.']}
target=out/'interim_descriptive_results.json';temporary=target.with_suffix('.tmp');temporary.write_text(json.dumps(report,indent=2,allow_nan=False));temporary.replace(target)
print(json.dumps({k:v for k,v in report.items() if k not in ['central_source_records','ac_source_records']},indent=2),flush=True)
