"""Preserve closed fixed QA results, full costs and a saved-only failure diagnosis.

This is not a second scoring audit or an inference retry. Scores are copied from
the pinned reader. New observations summarize already preserved token streams.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import ast,hashlib,json
from coordinate_native_inverter_linear_reference_20261020 import process
R=Path(__file__).resolve().parents[1];O=R/'outputs/public_qa_completion_20261029'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    p=R/p;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8');t.replace(p)
def main():
    assert not O.exists()
    proto=rd('outputs/public_qa_execution_preparation_20261029/final/Final_Protocol.json')
    cdir=Path(proto['coordination']);completion=rd(cdir/'Completion.json');readerend=rd(cdir/'Reader_End_ACK.json')
    auditrel=Path(proto['independent_audit'])/'Independent_Audit.json';audit=rd(auditrel)
    assert completion['audit_sha256']==sha(R/auditrel) and audit['status']=='PASS_SAVED_SCIENTIFIC_OUTPUT_AND_SCORING_AUDIT'
    assert readerend['exit_code']==0 and readerend['actual_owned_chain_ended']
    coord=rd(cdir/'owner.claim')
    assert process(coord['actual_pid']) is None and process(coord['parent_pid']) is None
    assert process(readerend['actual_pid']) is None and process(readerend['launcher_pid']) is None
    for rel,digest in proto['source_hashes'].items():assert sha(R/rel)==digest
    rows=[];bindings=[{'path':str(auditrel).replace('\\','/'),'sha256':sha(R/auditrel)}]
    for arm,result in zip(proto['arms'],audit['arms']):
        d=Path(arm['execution']);claim=rd(d/'owner.claim');status=rd(d/'status.json')
        assert process(claim['actual_pid']) is None and process(claim['parent_pid']) is None
        end=rd(cdir/(arm['id']+'_End_ACK.json'));remote=rd(d/'Remote_End.json');host=rd(d/'Host_End.json');reaped=rd(d/'Supervisor_Reaped.json')
        assert end['exit_code']==remote['exit_code']==reaped['exit_code']==0 and end['actual_owned_chain_ended']
        assert remote['actual_child_ended'] and reaped['actual_supervisor_ended']
        assert status['runtime_released'] and status['all_artifacts_preserved'] and status['actual_remote_child_ended']
        assert host['runtime_released'] and host['all_artifacts_preserved']
        assert result['result_status']=='COMPLETE' and result['actual_returned_science_generations']==result['actual_attempted_science_generations']==150
        outputs=[rd(d/'study'/f'output_{i:03}.json') for i in range(150)]
        raw=Counter(x['raw_text'] for x in outputs)
        ids=Counter(t for x in outputs for t in x['new_token_ids'])
        warm=rd(d/'study/Engineering_Warm.json');cold=rd(d/'study/Engineering_Cold.json')
        transfer=rd(d/'Transfer_Costs.json');integration=rd(d/'study/Actual_Integration.json')
        for name in ['Host_End.json','Remote_End.json','Supervisor_Reaped.json','Transfer_Costs.json','study/Result.json','study/Closed_Manifest.json','study/Actual_Integration.json']:
            p=d/name;bindings.append({'path':p.as_posix(),'sha256':sha(R/p)})
        rows.append({'arm':arm['id'],'model':result['model'],'primary_correct':result['primary_correct'],'denominator':150,
            'primary_accuracy':result['primary_fraction'],'strict_correct':result['strict_correct'],'strict_valid':result['strict_valid'],
            'unique_raw_outputs':len(raw),'most_common_raw_outputs':[{'text':text,'count':n} for text,n in raw.most_common(3)],
            'all_zero_token_streams':sum(bool(x['new_token_ids']) and set(x['new_token_ids'])=={0} for x in outputs),
            'top_token_counts':ids.most_common(5),'output_cap_hits':result['output_cap_hits'],
            'engineering_warm_all_zero_ids':set(warm['new_token_ids'])=={0},'engineering_cold_all_zero_ids':set(cold['new_token_ids'])=={0},
            'engineering_warm_cold_equal':warm['new_token_ids']==cold['new_token_ids'],
            'runtime':{k:integration[k] for k in ['revision','torch','transformers','device','dtype','attention']},
            'costs':{'science_generations':150,'engineering_generations':2,'science_generated_tokens':result['science_generated_tokens'],
                'returned_science_generation_seconds':result['science_returned_generation_seconds'],
                'engineering_generation_seconds':result['engineering_generation_seconds'],
                'worker_wall_seconds':result['worker_wall_seconds'],'host_wall_seconds':host['wall_seconds'],
                'supervisor_wall_seconds':remote['elapsed_seconds'],'coordination_arm_elapsed_seconds':end['seconds'],
                'transfer_requests':len(transfer),'transfer_request_seconds':sum(x['seconds'] for x in transfer),
                'transfer_status_counts':dict(Counter(str(x.get('http_status')) for x in transfer)),
                'logged_transfer_response_bytes':sum(x.get('response_bytes',0) for x in transfer),
                'science_peak_allocated_bytes':result['peak_allocated_bytes'],
                'engineering_peak_allocated_bytes':max(warm['peak_allocated_bytes'],cold['peak_allocated_bytes']),
                'note':'Host, worker, supervisor, transfer and generation timings overlap and must not be added as independent elapsed time. Preparation, prior failed studies and source review remain separate paid work; these are not deployment latency.'},
            'terminal':'HOST_AND_CHILD_ENDED_RUNTIME_RELEASED_ALL_ARTIFACTS_PRESERVED'})
    bad=next(x for x in rows if x['arm']=='size15');assert bad['all_zero_token_streams']==150 and bad['engineering_warm_all_zero_ids'] and bad['engineering_cold_all_zero_ids']
    big=next(x for x in rows if x['arm']=='size3');assert big['unique_raw_outputs']==4 and big['strict_valid']==150
    source=(R/'work/public_qa_inference_worker_v2_20261029.py').read_text('utf-8');tree=ast.parse(source)
    assert not any(isinstance(n,ast.Attribute) and n.attr=='isfinite' for n in ast.walk(tree))
    now=datetime.now(timezone.utc).isoformat();O.mkdir()
    diagnosis={'status':'POSTHOC_SAVED_OUTPUT_AND_SOURCE_DIAGNOSIS_NOT_CAUSAL_NUMERICAL_PROOF',
        'observation':'1.5B emits token0 repeated256 times on every question and on both earlier synthetic warm/cold probes. 3B emits valid single letters on all150questions: A16/B98/C29/D7; it is not a constant-answer stream. 0.5B has mixed outputs.',
        'engineering_gap':'The actual cold gate checked byte-identical reload and capacity, but neither finite raw logits nor meaningful non-test response behavior. A reproducible degenerate stream passed. This gate was insufficient and consumed preventable compute.',
        'unknown':'No raw logits or intermediate activations were saved. NaN/overflow, dtype, library implementation and prompt behavior cannot be causally separated from these saved strings. Do not label the zero score intrinsic model incapacity or silently repair the run.',
        'source_facts':{'worker_has_isfinite_check':False,'worker_sha256':proto['worker_sha256'],'current_fixed_contract':'FP16/eager/Transformers5.5.0/T4'},
        'official_precision_reference':'https://qwen.readthedocs.io/en/v2.5/inference/chat.html',
        'reference_scope':'Qwen2.5 documentation recommends auto/BF16 and also allows explicitly specified FP16. This is a precision-design reference, not evidence that FP16 caused this failure.',
        'next_gate':'Before any future independent model campaign, freeze non-test finite raw-logit and semantic smoke gates, failure termination, actual supported precision and cold restoration. A separate synthetic-only numerical diagnosis may investigate the cause; do not rerun this benchmark or select a replacement score.'}
    put((O/'Saved_Output_Diagnosis.json').relative_to(R),diagnosis)
    report={'at_utc':now,'status':'COMPLETE_ALL450_FIXED_ATTEMPTS_INDEPENDENT_SAVED_AUDIT_PASS_NO_SCALE_BENEFIT_ESTABLISHED',
        'reader_scope':'Pinned saved-source/journal/token-decode/scoring audit; no repeat inference. Reader source emits its audit and owner claim, not a Closed_Manifest. This additive certificate binds the actual reader artifact and endACK without inventing a missing reader phase.',
        'all_actors_ended':True,'all_three_allocated_T4s_released':True,'active_owned_jobs':0,'rows':rows,
        'primary_reader':{'path':auditrel.as_posix(),'sha256':sha(R/auditrel),'exit_code':readerend['exit_code'],'elapsed_seconds':readerend['seconds']},
        'paired':audit['paired'],'source_bindings':bindings,'total_actual_generations':456,'science_generations':450,'engineering_generations':6,
        'new_model_PF_OPF_training_calls_for_this_closure':0,'study_new_PF_OPF_training_calls':0,
        'decision':'STOP_FIXED_INTERVENTION_NO_RETRY_OR_OUTCOME_RETUNING. Operational scores retained; size capability/causal failure explanation unresolved. 3B strict formatting and strict accuracy improve over0.5B, but native-parser accuracy ties; no size or system superiority follows.',
        'limitations':audit['limits']+['No external author score is claimed beaten. Three-model public QA transfer is not the private trained control adapter, original RAG pipeline or matched adapted-scale experiment.','All six final goals remain OPEN.'],
        'diagnosis':(O/'Saved_Output_Diagnosis.json').relative_to(R).as_posix()}
    put((O/'Verified_Completion.json').relative_to(R),report)
    lines=['# Fixed public QA comparison','', 'All three fixed arms completed, the pinned saved-output audit passed, and all three T4 runtimes were released. These are150questions about one public circuit, without retrieval, tools, private adapters or training.','', '| Public model | Native-parser correct | Strict single-letter correct | Strict valid | Output-cap hits |','|---|---:|---:|---:|---:|']
    for x in rows:lines.append(f"| {x['model'].split('/')[-1]} | {x['primary_correct']}/150 | {x['strict_correct']}/150 | {x['strict_valid']}/150 | {x['output_cap_hits']}/150 |")
    lines+=['', 'The1.5B arm produced a repeated exclamation-mark stream in every answer, including its earlier synthetic warm/cold probes. The3B arm produced valid single letters on every question: A16/B98/C29/D7. The independent audit confirms what ran and how the frozen parser scored it; it does not establish normal model capability. The cold gate checked reproducibility but missed degenerate output and did not record finite logits. The exact numerical cause remains unknown.','', 'The fixed study is stopped. No prompt, dtype, decoder, seed, token limit or answer is changed to obtain a favourable replacement result. Future model work needs a separately frozen, label-free numerical and behavior gate.','', 'Costs:450scientific generations plus6engineering generations;0PF/OPF/training. Individual returned-generation timing, engineering, host/setup/transfer/release and overlapping workflow costs are retained in Verified_Completion.json. Prior preparation/failure costs remain separate. No deployment-speed claim.','', 'All six research goals remain open. This comparison does not certify the original RAG system, the trained voltage-control model or superiority over published controllers.']
    (O/'Results_And_Next_Decision.md').write_text('\n'.join(lines)+'\n','utf-8')
    exact=rd('outputs/public_qa_scale_design_20261029/Exact_Resume.json')
    exact.update(at_utc=now,status=report['status'],owned_scientific_jobs=[],GPU_assignments=[],waiting_timer=None,
        completion=(O/'Verified_Completion.json').relative_to(R).as_posix(),saved_diagnosis=report['diagnosis'],thesis_requirements_complete=17,
        next_ordered_actions=['Preserve fixed QA scores, degenerate outputs and all456generation costs; no rerun or score rescue.','T32: review and integrate29prepared caption clarifications, then render and verify.','Prepare a separate non-test finite-logit/semantic/cold gate before any future model allocation; saved outputs do not establish an overflow cause.','Advance justified common118control/benchmark design and evidence gaps; all six goals open.','Publish new own-code/compact proofs with fresh lease and exact downloaded-byte check; private raw assets remain local.'])
    put('outputs/public_qa_scale_design_20261029/Exact_Resume.json',exact)
    resume=rd('outputs/research_resumption_20261028/Current_Resume.json');resume.update(at_utc=now,updated_at_utc=now,public_QA_completion=exact['completion'],owned_jobs=[],active_GPU_assignments=[],waiting_timer=None,thesis_closed_requirements=17,next=exact['next_ordered_actions']);put('outputs/research_resumption_20261028/Current_Resume.json',resume)
    tasks=rd('outputs/research_tasks_20261014/Tasks.json');tasks.update(updated_at_utc=now,public_QA_execution_20261029={'status':report['status'],'evidence':exact['completion'],'active_GPUs':0,'all_six_final_goals':'OPEN'})
    g2=next(t for t in tasks['tasks'] if t['checklist_id']=='G2');assert all(t['id']!='G2.5c' for t in g2['subtasks']);g2['subtasks'].append({'id':'G2.5c','completed':True,'description':'Execute fixed public0.5/1.5/3B no-tool QA comparison on all150questions and independently verify saved outputs/costs. Operational failure diagnosed; no overall research goal or scale benefit closed.','evidence':exact['completion'],'verified_at_save':now});put('outputs/research_tasks_20261014/Tasks.json',tasks)
    msg='All450fixed publicQA answers complete and saved-output auditPASS;6engineering generations separately paid,all3T4sreleased,noownedjobs. Native-parser scores0.5B37/150,1.5B0/150,3B37/150.1.5B all256token0 streams including oldsynthetic probes;3B validlettersA16/B98/C29/D7. Finite logits were not saved/checked, so collapse cause and intrinsic size capability remainUNKNOWN. Cold repeatability alone was insufficient. STOPfixedstudy,no rerun/retune.17/35thesis requirementscomplete,all6goalsOPEN. Next usefulwork: captionintegration and separately prospective non-test numerical gates, not idleGPUallocation.'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text('## Fixed public QA comparison closed; gate limitation diagnosed — '+now+'\n\n'+msg+'\n\n'+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+msg+'\n')
    print(json.dumps({'status':report['status'],'scores':[r['primary_correct'] for r in rows],'actual_generations':456,'active_GPU':0,'new_science_in_closure':0}))
if __name__=='__main__':main()
