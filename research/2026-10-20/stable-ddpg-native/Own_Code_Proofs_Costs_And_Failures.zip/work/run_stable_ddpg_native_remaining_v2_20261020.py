"""One first-source-seed native root, all3author policies, cold outputs and unique action PFs."""
import hashlib,json,os,pickle,time,traceback,copy
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/stable_ddpg_native_remaining_preparation_v2_20261020';OUT=ROOT/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'))
    for name,h in p['sources'].items():assert sha(ROOT/'work'/name)==h
    for name,h in p['author_inputs'].items():assert sha(ROOT/'outputs/stable_ddpg_author_intake_20261020/author_reference'/name)==h
    assert json.loads((ROOT/'outputs/stable_ddpg_native_engineering_preparation_20261020/Readiness.json').read_text(encoding='utf-8'))['status'].startswith('PASS_')
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'protocol_sha256':sha(PREP/'Protocol.json'),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    costs={'checkpoint_load_attempts':0,'checkpoint_load_returns':0,'policy_agent_attempts':0,'policy_agent_returns':0,'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'native_network_conversions':0,'model_backward_optimizer_training_GPU_calls':0};stream=(OUT/'Journal.jsonl').open('x',encoding='utf-8');prev='0'*64
    def event(kind,**data):
        nonlocal prev
        if kind=='checkpoint_load_attempt':costs['checkpoint_load_attempts']+=1
        if kind=='checkpoint_load_return':costs['checkpoint_load_returns']+=1
        r={'kind':kind,'elapsed_seconds':time.monotonic()-start,'previous':prev,**data};h=hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':')).encode()).hexdigest();stream.write(json.dumps({'event':r,'sha256':h})+'\n');stream.flush();os.fsync(stream.fileno());prev=h;assert time.monotonic()-start<p['fixed_worker_bound_seconds']
    try:
        import stable_ddpg_native_bridge_20261020 as b
        np=b.np;pd=b.pd;torch=b.torch
        from candidate_process_evidence_utils import frozen_checks
        from pandapower.pypower.makeSbus import makeSbus
        put(OUT/'Frozen_Before.json',frozen_checks());torch.set_num_threads(1);torch.manual_seed(10)
        event('native_network_conversion_attempt');env,proxy,envproof=b.environment();costs['native_network_conversions']+=1;event('native_network_conversion_return')
        event('load_primary');models,primaryloads,policyproof=b.load_three(env,event);event('load_cold');cold,coldloads,_=b.load_three(env,event);put(OUT/'Checkpoint_Load_Joins.json',{'primary':primaryloads,'cold':coldloads})
        context={'label':'root'};captures=[];cache={}
        oldroot=ROOT/'outputs/stable_ddpg_native_engineering_20261020'
        rootproof=json.loads((oldroot/'preserved_root_independent_audit/Independent_Partial_Audit.json').read_text(encoding='utf-8'));assert rootproof['status'].startswith('PASS_')
        graph=np.load(oldroot/'preserved_root_independent_audit/Verified_Admittance_And_State.npz')
        def signature(net):
            h=hashlib.sha256()
            for name in ['bus','line','trafo','gen','sgen','load','ext_grid','shunt','switch']:
                h.update(name.encode());h.update(pd.util.hash_pandas_object(net[name],index=True).to_numpy().tobytes())
            return h.hexdigest()
        def tracked(net,*args,**kwargs):
            assert not args and kwargs in ({'algorithm':'bfsw'},{'algorithm':'bfsw','init':'dc'})
            key=signature(net)
            if key in cache:
                saved=cache[key]
                net.update(copy.deepcopy(saved['complete_NET']))
                net['converged']=True;captures.append({'label':context['label'],'source_PF':saved['number'],'reused_exact_paid_input':True});event('paid_PF_identity_reuse',label=context['label'],source_PF=saved['number']);return None
            index=costs['PF_attempts']+1;assert index<=3
            before=OUT/f'PF{index}_before.pkl'
            with before.open('xb') as f:pickle.dump(net,f,protocol=5)
            costs['PF_attempts']+=1;event('PF_attempt',number=index,label=context['label'],kwargs=kwargs,before_sha256=sha(before),physical_input_sha256=key);t=time.monotonic()
            try:b.pp.runpp(net,**kwargs)
            except BaseException as e:costs['PF_exceptions']+=1;event('PF_exception',number=index,type=type(e).__name__,seconds=time.monotonic()-t);raise
            costs['PF_returns']+=1
            with (OUT/f'PF{index}_after.pkl').open('xb') as f:pickle.dump(net,f,protocol=5)
            assert net.converged
            arrays={name:net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float) for name in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};np.savez(OUT/f'PF{index}_fields.npz',**arrays)
            ppc=net._ppc;v=ppc['bus'][:,7]*np.exp(1j*np.pi/180*ppc['bus'][:,8]);y=graph['Y'];assert np.array_equal(ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and ppc['baseMVA']==float(graph['baseMVA']);s=makeSbus(ppc['baseMVA'],ppc['bus'],ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(y@v)-s)));assert kcl<=1e-7
            vm=net.res_bus.vm_pu.to_numpy(copy=True);controlled=vm[[2,7,9]];assert np.isfinite(vm).all()
            record={'number':index,'label':context['label'],'kwargs':kwargs,'physical_input_sha256':key,'all_bus_UV':int((vm<.95).sum()),'all_bus_OV':int((vm>1.05).sum()),'controlled_UV':int((controlled<.95).sum()),'controlled_OV':int((controlled>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'KCL_max_pu':kcl,'seconds':time.monotonic()-t}
            cache[key]={'number':index,'complete_NET':copy.deepcopy(net)};captures.append({'label':context['label'],'source_PF':index,'reused_exact_paid_input':False});put(OUT/f'PF{index}_Identity.json',record);event('PF_return',**record);return None
        proxy.runpp=tracked
        import shutil
        for name in ['PF0_before.pkl','PF0_after.pkl','PF0_fields.npz']:shutil.copyfile(oldroot/name,OUT/name)
        with (oldroot/'PF0_after.pkl').open('rb') as f:env.network=pickle.load(f)
        env.state=env.network.res_bus.iloc[env.injection_bus].vm_pu.to_numpy();rootstate=env.state.copy();np.save(OUT/'Root_Controlled_State.npy',rootstate)
        rng=np.random.RandomState(0);assert rng.choice([0,1])==0;expected=np.zeros(len(env.network.sgen));expected[0]=-.5*rng.uniform(1,7);expected[1]=-.8*rng.uniform(1,4);expected[2]=-.3*rng.uniform(1,5);assert np.array_equal(expected,env.network.sgen.p_mw.to_numpy());np.random.set_state(rng.get_state())
        cache[signature(env.network)]={'number':0,'complete_NET':copy.deepcopy(env.network)};captures.append({'label':'root','source_PF':0,'reused_exact_paid_input':True});event('original_paid_root_restored_without_PF',source_PF_returns=1,original_independent_replay_PF_returns=1,old_model_forward_attempts=0)
        with (OUT/'Root_Completed_NET.pkl').open('xb') as f:pickle.dump(env.network,f,protocol=5)
        with (OUT/'Root_Complete_RNG.pkl').open('xb') as f:pickle.dump({'numpy':np.random.get_state(),'torch':torch.get_rng_state().numpy()},f,protocol=5)
        results=[]
        for algorithm in p['algorithms_in_author_order']:
            outputs={}
            for label,group in [('primary',models[algorithm]),('cold',cold[algorithm])]:
                np.savez(OUT/f'{algorithm}_{label}_weights_before.npz',**{f'{i}::{name}':value.detach().cpu().numpy() for i,m in enumerate(group) for name,value in m.state_dict().items()})
                raw=[]
                for i,m in enumerate(group):
                    costs['policy_agent_attempts']+=1;event('policy_agent_attempt',algorithm=algorithm,replica=label,agent=i);t=time.monotonic()
                    with torch.no_grad():a=m.get_action(np.asarray([rootstate[i]]))
                    costs['policy_agent_returns']+=1;assert a.shape==(1,) and np.isfinite(a).all();assert not any(v.grad is not None for v in m.parameters());raw.append(a.copy());event('policy_agent_return',algorithm=algorithm,replica=label,agent=i,seconds=time.monotonic()-t)
                np.savez(OUT/f'{algorithm}_{label}_weights_after.npz',**{f'{i}::{name}':value.detach().cpu().numpy() for i,m in enumerate(group) for name,value in m.state_dict().items()})
                outputs[label]=np.asarray(raw);np.save(OUT/f'{algorithm}_{label}_Raw.npy',outputs[label])
            assert np.array_equal(outputs['primary'],outputs['cold'])
            action=np.zeros((3,1))-np.clip(outputs['primary'],-.3,.3);np.save(OUT/f'{algorithm}_Native_Absolute_Q.npy',action)
            branch=copy.deepcopy(env);context['label']=algorithm
            state,reward,reward_sep,done=branch.step_Preward(action,np.zeros((3,1))-action)
            allvm=branch.network.res_bus.vm_pu.to_numpy(copy=True)
            result={'algorithm':algorithm,'source_PF':captures[-1]['source_PF'],'all_bus_UV':int((allvm<.95).sum()),'all_bus_OV':int((allvm>1.05).sum()),'controlled_UV':int((state<.95).sum()),'controlled_OV':int((state>1.05).sum()),'native_controlled_done':bool(done),'native_reward':float(reward),'vmin':float(allvm.min()),'vmax':float(allvm.max()),'absolute_Q_Mvar':action.flatten().tolist(),'native_delta_cap':.3,'cold_action_exact':True,'reused_paid_physics':captures[-1]['reused_exact_paid_input']};results.append(result)
        assert costs['policy_agent_returns']==costs['policy_agent_attempts']==18 and costs['checkpoint_load_returns']==18
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_NATIVE_FIRST_REPETITION_ONE_STEP_ALL3_POLICIES_AWAITING_READER','seed':0,'root_source_PF':0,'results':results,'captures':captures,'costs':costs,'environment_AST':envproof,'policy_AST':policyproof,'workflow_seconds':time.monotonic()-start,'our_LLM_or_full_benchmark_or_superiority_claim':False,'scope':'Previously unexecuted native13bus first-action policy identities only,from independently preserved oldroot. Oldroot primary+replay2PF and failedoldload/setup costs remain separately paid. All13bus metrics retain native3controlledbus done distinction. Not original federation or full500x100paper.'}
        put(OUT/'Frozen_After.json',frozen_checks());put(OUT/'Result.json',result);event('closed',result_sha256=sha(OUT/'Result.json'));stream.close();put(OUT/'Closed_Manifest.json',{'files':[{'path':x.name,'bytes':x.stat().st_size,'sha256':sha(x)} for x in OUT.iterdir() if x.is_file()],'journal_last_sha256':prev,'costs':costs});print(json.dumps({'status':result['status'],'results':results,'costs':costs}))
    except BaseException as e:put(OUT/'Failure.json',{'type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'costs':costs,'workflow_seconds':time.monotonic()-start});stream.close();raise
if __name__=='__main__':main()
