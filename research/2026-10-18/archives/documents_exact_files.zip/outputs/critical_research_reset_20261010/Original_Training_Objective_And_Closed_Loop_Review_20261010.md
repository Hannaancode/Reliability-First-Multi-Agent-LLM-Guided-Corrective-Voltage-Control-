# Original training objective and the closed-loop evidence gap

This review continues the human-requested critical review while original Colab notebooks are being attached. It uses the already verified local evidence and newly read primary documentation/paper sections. It runs no notebook cells, model, optimizer, nonlinear PF, controller, native forecast or cloud allocation. It does not replace any stopped study or declare a launch-ready experiment.

## What has already been achieved

The original adapted 0.5B zone proposer learned its command format under the saved original evaluator. The retained architecture includes normalization, schema/zone checks, AC verification, magnitude refinement and deterministic coordination/fallback. The public unadapted 1.5B strict parser experiment and later structured-head studies do not reproduce this trained text-command role. Their failures remain valid within their own frozen protocols and do not erase original format learning.

The existing original-role reconciliation is authoritative: 16,000 TRAIN rows from 109 scenario groups, 432 distinct full current local observations, no exact-input proposed-action conflicts, saved two-epoch/2,000-step checkpoints and a balanced saved evaluation with 64.25% effective exact-action matching. The 20,000 linguistic examples are not 20,000 independent physical worlds. Format accuracy and physical policy value require separate measurements.

## The preprocessing contract is part of the method

Current [TRL SFT documentation](https://huggingface.co/docs/trl/en/sft_trainer), sections on dataset types, label shifting/masking, assistant-only/completion-only loss and pretokenized inputs, distinguishes which tokens are supervised. Assistant masks depend on the template, while explicit labels use -100 to exclude tokens. This supports inspecting actual prepared labels rather than accepting a configuration flag as proof. Current documentation cannot reconstruct the older notebook's package version, defaults or loss mask.

Review inference: a model can receive a correctly formatted chat while optimizing a different token objective than intended. Before a future SFT study, recover the old formatting function, template, tokenization/truncation, collator, labels, packing boundaries, EOS/pad handling and base snapshot. Classify each as recovered source, saved execution evidence, or UNKNOWN. An assistant-only change may be reasonable but is a new method choice; it must not be called a faithful reproduction if the original mask differs or remains unknown.

Cheap prospective checks for any new implementation should inspect actual token IDs and labels without neural calls: every retained training answer has its declared supervised span and terminal token; no label/AFTER information enters the prompt; padding and packing follow the declared contract; the action fields survive preprocessing; and no sample is silently shortened or dropped. Counts and code flags do not substitute for these checks. No such new executable suite was run by this review.

The completed local context audit already rejected the proposed lossless 4,096-token TRAIN configuration: 822 of 16,000 complete chats exceed it, with maximum 4,932. All current TRAIN prefixes plus the separately declared 384-token serving reserve fit, which answers a different question. The [Qwen2.5-1.5B-Instruct model card](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct) advertises a 32,768-token context and 28 layers/1.54B parameters. That architecture limit does not certify full-length T4 training memory, a faithful original base variant, or a speed/quality gain. A new full-length configuration must be separately declared and genuinely integrated before science; the stopped 4,096 configuration is not silently enlarged.

## Saved imitation accuracy is not an episode guarantee

The primary [DAgger paper](https://proceedings.mlr.press/v15/ross11a/ross11a.pdf), pages 1-5, Algorithm 3.1 and Theorems 4.1-4.2, addresses observations whose distribution changes with the learner's own actions. It acquires expert labels on visited trajectories; its bounds involve surrogate loss, regret and additional assumptions. This motivates a distribution-shift audit, not automatic grid rollout or a claim that teacher labels guarantee recovery.

Review inference for HierGrid: the original saved examples and receipt replays do not supply complete counterfactual successors for arbitrary learner actions. We cannot substitute saved teacher trajectories for fresh learner-induced physical trajectories or invent long-horizon rewards. DAgger is established prior art; combining it with LoRA is not a novelty argument. Its validation selection procedure also does not override our prospectively fixed final-checkpoint rule or permit outcome-driven checkpoint selection.

## Two different research questions must stay separate

1. **Faithful adapted-scale question:** Does a newly adapted 1.5B proposer improve the original zone-command role relative to the preserved trained 0.5B under a disclosed, aligned pipeline? This can establish a development engineering result. Missing historical preprocessing prevents pure parameter-count attribution; architecture, adaptation, precision and total costs must be disclosed. It does not by itself establish a novel contribution or D-SE superiority.
2. **Incremental decision-value question:** Does language pretraining add measured protected recovery or economic value beyond equally informed strong numerical methods and the fully costed literal D-SE portfolio? This needs a supported decision target and fresh matched trajectories, not merely higher token accuracy, imitation accuracy or lower loss.

The original local-normal/null target and a later global-UV-required action prompt differ. Until the actual deployment notebook is reconciled, this remains a role-mismatch hypothesis rather than a measured causal explanation. Retraining on unchanged local labels cannot be assumed to solve a global intervention requirement.

## Strong cheap comparisons before expensive learning

The existing 432-observation consistency result justifies an empirical exact-observation lookup as an in-support teacher-imitation ceiling. It does not justify using held labels in that lookup or claiming generalization. A future same-information numerical control should include a TRAIN-only lookup/nearest-neighbor proposer and a genuinely trained numerical proposer, with identical action grammar, normalizer, verifier, guard and downstream refinement. Their preparation and inference costs are paid. None has been launched here.

A decisive cheap rejection can apply to a specified contract: a missing action label after truncation, contradictory labels under identical permitted inputs, a forbidden output action, or an unattainable same-state maximum. Passing those checks cannot give 100% confidence of improvement. The original DFF exact-immediate-argmax ceiling still applies to the SAME state/candidate set/verifier/score; beating copied teacher decisions is not a route to exceeding that ceiling. A different costed acquisition or long-horizon objective must demonstrate its own information and target support before training.

## Next concrete work

Use the attached notebooks first to bind actual original SFT and Phase 2G serving sources to the preserved adapter/data and saved outputs. The expanded filename checklist identifies newly discovered baseline, augmentation, critic and testbed notebooks plus both Phase 2A training notebooks. Filename inspection alone is not code review and notebook source alone is not proof that every cell was executed.

Then write one separately prospective aligned-scale protocol if the source/target/context/control gates support it. Declare one seed/budget/final checkpoint and retain all worlds, failures, unknowns and full costs. No GPU allocation or training follows automatically from source recovery or this review. Preserve stopped adverse branches, the frozen original model/network/controller/settings/locked bank, literal DFF+DFF-ALT+unchanged selector and FULL BOTH-branch costs. Overall incremental LLM advantage and full security remain unachieved; unused authorized confirmation and independent physical replay remain required.

Sources: original_scale_and_label_review_handoff/Review_and_Next_Decision.md; original_desktop_pipeline_alignment/Alignment_Review.md; original_TRAIN_matched_token_contexts_v3; original_TRAIN_causal_label_support; the linked primary sources. Scope of new reading: current SFT preprocessing/masking sections, Qwen model-card architecture/context fields, and DAgger algorithm/assumption/bound sections, not an exhaustive literature search or proof audit.
