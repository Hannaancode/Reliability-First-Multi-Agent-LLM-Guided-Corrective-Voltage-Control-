"""Prospective software/source/cold serialization checks, not model/PF performance."""
import ast,copy,json,pickle,time,random,hashlib,subprocess
from pathlib import Path
import stable_ddpg_native_bridge_20261020 as b
from public13_matched_numeric_engine_20261021 import original_guard
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_matched_numeric_preparation_20261021';np=b.np
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)
def main():
    checks=[];tree=ast.parse((R/'work/run_native_fit_teacher_20261020.py').read_text(encoding='utf-8'));node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='safe');space={'np':np};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'UNCHANGED_EXISTING_GUARD','exec'),space)
    rng=np.random.default_rng(20261021);count=0
    for _ in range(512):
        before=rng.uniform(.85,1.15,13);after=rng.uniform(.85,1.15,13);assert original_guard(before,after)==space['safe'](before,after);count+=1
    checks.append({'label':'unchanged_source_guard_on512_labeled_mock_arrays','pass':True,'mock_arrays':count})
    for label,before,after,expected in [('normal_to_OV_rejected',[1.,1.,1.],[1.,1.051,1.],False),('UV_recovery_accepted',[.94,1.,1.],[.96,1.,1.],True),('new_UV_rejected',[1.,1.,1.],[.949,1.,1.],False),('new_UV_count_offset_but_normal_break_rejected',[.94,1.,1.],[.96,.94,1.],False),('nonfinite_after_rejected',[1.,1.,1.],[1.,float('nan'),1.],False)]:
        assert original_guard(np.array(before),np.array(after))==expected;checks.append({'label':label,'pass':True})
    # Structural invariants: public numerical equations/objective/float32 action
    # come from the already executed immutable source, not this new cohort.
    source=R/'work/public13_matched_numeric_engine_20261021.py';text=source.read_text(encoding='utf-8');ast.parse(text)
    for name in ['propose','verify']:
        assert name in text
    assert 'range(1,101)' in text and "kwargs={'algorithm':'bfsw','init':'dc'}" in text and "if sig in attempted:raise RuntimeError" in text and "reader_replaying and k in targets" in text
    checks.append({'label':'same100horizon_native_kwargs_no_repeat_and_reader_identity_gate','pass':True})
    roots=json.load(open(P/'All500_Audited_Exact_Roots.json',encoding='utf-8'))['roots'];assert [r['seed'] for r in roots]==list(range(500));checks.append({'label':'all500_source_ordered_roots_no_selected_subset','pass':True})
    fixture=P/'cold_cursor_software_fixture';fixture.mkdir(exist_ok=False);root=roots[0];data=pickle.loads((R/root['path']).read_bytes());net=data['network'] if root['kind']=='ENV' else data
    cursor={'seed':0,'next_step':1,'remaining_original_horizon':100,'current_NET':{k:root[k] for k in ['path','sha256','kind']},'current_vm':net.res_bus.vm_pu.to_numpy(copy=True),'current_Q':net.sgen.q_mvar.to_numpy()[:3].copy(),'history':[],'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':b.torch.get_rng_state().numpy(),'absolute_deadline_monotonic':time.monotonic()+600,'old_physical_index_sha256':hashlib.sha256((P/'Historical_Paid_Physical_Index.json').read_bytes()).hexdigest()}
    with (fixture/'Full_Cursor.pkl').open('xb') as f:pickle.dump(cursor,f,protocol=5)
    call=subprocess.run([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/inspect_public13_numeric_cold_cursor_20261021.py'),'--cursor',str((fixture/'Full_Cursor.pkl').relative_to(R))],capture_output=True,text=True,encoding='utf-8',timeout=60);assert call.returncode==0,call.stderr;proof=json.loads(call.stdout);assert proof['absolute_deadline_monotonic_UNCHANGED']==cursor['absolute_deadline_monotonic'];put(fixture/'Fresh_Process_Proof.json',proof);checks.append({'label':'actual_new_process_cold_NET_Q_VM_RNG_cursor_bound_serialization','pass':True})
    for label,mutator in [('missing_NET_rejected',lambda v:v['current_NET'].update(sha256='0'*64)),('renewed_horizon_rejected',lambda v:v.update(remaining_original_horizon=101)),('changed_Q_rejected',lambda v:v['current_Q'].__setitem__(0,1.))]:
        value=copy.deepcopy(cursor);mutator(value);path=fixture/(label+'.pkl')
        with path.open('xb') as f:pickle.dump(value,f,protocol=5)
        result=subprocess.run([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/inspect_public13_numeric_cold_cursor_20261021.py'),'--cursor',str(path.relative_to(R))],capture_output=True,text=True,encoding='utf-8',timeout=60);assert result.returncode!=0;checks.append({'label':label,'pass':True})
    result={'status':'PASS_SOURCE_SOFTWARE_AND_ACTUAL_FRESH_PROCESS_COLD_INSPECTION_ONLY','checks':checks,'count':len(checks),'cold_scope':'Fresh process decodes actual paid root and exact currentQ/VM/fullRNG/cursor/horizon/bound bytes. No restart/resume or performance implied. Per-step production cursors add fsynced history/receipt/math registry anchors.','new_model_PF_derivative_factor_LP_optimizer_converter_calls':0,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()};put(P/'Software_Readiness.json',result);print(json.dumps({'status':result['status'],'checks':len(checks),'new_science':0}))
if __name__=='__main__':main()
