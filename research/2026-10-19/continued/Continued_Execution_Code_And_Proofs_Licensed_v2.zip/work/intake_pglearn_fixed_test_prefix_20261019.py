"""Pinned official published data intake, first16 test rows fixed before labels.

No model, optimizer, network solver or new physical evaluation. Raw licensed
data local; later native equation/role audits required before model tests.
"""
import argparse,hashlib,json,os,sys,time,traceback,urllib.request
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/pglearn_fixed_test_prefix_20261019'
REV='b72971c6245c66763bf4a7a836650fd676d856d9'
REPO='PGLearn/PGLearn-Small-118_ieee'
FILE='118_ieee/test-00000-of-00133.parquet'
EXPECTED='5a250b4514357315ab0663e640c26fa6c18eec049f7806c61eff9cb031714b48'
def fetch():
    B.mkdir(exist_ok=False);start=time.perf_counter();source=sha(__file__)
    put(B/'Protocol.json',{'status':'FIXED_BEFORE_TARGET_DATA_DOWNLOAD','created_utc':datetime.now(timezone.utc).isoformat(),'dataset':REPO,'revision':REV,'shard':FILE,'expected_bytes':85559012,'expected_lfs_sha256':EXPECTED,'selection':'ALL first16 provider test rows0..15 in original order, no feasibility/status/value filtering; this inspected prefix is DEVELOPMENT, not unused confirmation.','license':'CC-BY-SA-4.0 per official dataset card; preserve attribution/source/license on any derived redistribution. Raw shard retained local.','source_sha256':source,'maximum_download_bytes':100*1024**2,'one_download_attempt_no_fallback':True,'role':'Published solved operating-state candidate intake. Data feasibility/action/constraint/model-input adaptation are not established by download.','all_new_model_PF_OPF_optimizer_derivative_forecast_solve_calls':0})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':source,'mode':'PUBLIC_DATA_INTAKE_NO_SCIENCE'})
    try:
        url=f'https://huggingface.co/datasets/{REPO}/resolve/{REV}/README.md'
        card=urllib.request.urlopen(url,timeout=30).read(1024**2);assert len(card)<1024**2;(B/'Official_Dataset_Card.md').write_bytes(card)
        url=f'https://huggingface.co/datasets/{REPO}/resolve/{REV}/{FILE}'
        h=hashlib.sha256();count=0
        with urllib.request.urlopen(url,timeout=60) as response,(B/'test-00000.parquet').open('xb') as f:
            while raw:=response.read(1024**2):
                count+=len(raw);assert count<=100*1024**2;f.write(raw);h.update(raw)
            f.flush();os.fsync(f.fileno())
        assert count==85559012 and h.hexdigest()==EXPECTED
        put(B/'Download_Result.json',{'status':'PASS_PINNED_AUTHOR_SHARD_BYTES_AND_SHA256','bytes':count,'sha256':h.hexdigest(),'original_public_url':url,'workflow_seconds':time.perf_counter()-start,'scientific_calls':0})
    except BaseException:put(B/'Download_Failure.json',{'traceback':traceback.format_exc(),'scientific_calls':0,'no_automatic_retry':True});raise

def extract():
    sys.path.insert(0,str(R/'work/public_parquet_reader_deps_20261019'))
    import pyarrow,pyarrow.parquet as pq
    assert pyarrow.__version__=='19.0.1';assert read(B/'Download_Result.json')['sha256']==EXPECTED and sha(B/'test-00000.parquet')==EXPECTED
    out=B/'fixed16';out.mkdir(exist_ok=False);start=time.perf_counter();p=pq.ParquetFile(B/'test-00000.parquet')
    columns=[n for n in p.schema_arrow.names if n=='case/json' or n.startswith('input/') or n.startswith('ACOPF/primal/') or n.startswith('ACOPF/meta/')]
    batch=next(p.iter_batches(batch_size=16,columns=columns));rows=batch.to_pylist();assert len(rows)==16
    summary=[]
    for i,row in enumerate(rows):
        put(out/f'row_{i:04}.json',row);case=json.loads(row['case/json'])
        summary.append({'provider_test_index':i,'row_sha256':sha(out/f'row_{i:04}.json'),'case_json_sha256':hashlib.sha256(row['case/json'].encode()).hexdigest(),'case_keys':list(case),'case_field_types':{k:type(v).__name__ for k,v in case.items()},'primal_status':row.get('ACOPF/meta/primal_status'),'termination_status':row.get('ACOPF/meta/termination_status'),'voltage_length':len(row['ACOPF/primal/vm']),'source_float_precision':str(p.schema_arrow.field('ACOPF/primal/vm').type)})
    put(out/'Input_Manifest.json',{'status':'PASS_ALL16_FIXED_PROVIDER_TEST_ROWS_EXTRACTED_NO_FILTER','rows':summary,'shard_total_rows':p.metadata.num_rows,'source_schema':str(p.schema_arrow),'column_selection':columns,'reader_version':pyarrow.__version__,'reader_CPU_workflow_seconds':time.perf_counter()-start,'scientific_calls':0,'native_feasibility':'NOT_YET_AUDITED','model_test':'NOT_EXECUTED','unused_confirmation':False})
    manifest(out);print(json.dumps({'official_published_test_rows':16,'case_keys':summary[0]['case_keys'],'source_float_precision':summary[0]['source_float_precision'],'scientific_calls':0}))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--fetch',action='store_true');a.add_argument('--extract',action='store_true');args=a.parse_args()
    if args.fetch:fetch()
    elif args.extract:extract()
