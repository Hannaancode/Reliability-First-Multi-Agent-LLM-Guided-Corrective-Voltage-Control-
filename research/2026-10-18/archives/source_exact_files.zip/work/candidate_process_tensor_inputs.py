"""Input-only tensor compiler for numerical preparation. Never consumes labels."""
import math
import torch
from vcsa_common_information_codec import flatten
from candidate_predictor_input_contract import group_for,validate_observation,Q_GRID

KINDS=('object','array','null','bool','int','float','str')
NODE_FIELDS=('vm_pu','va_degree','solved_p_mw','solved_q_mvar','load_p_mw','load_q_mvar',
             'sgen_p_mw','sgen_q_mvar','gen_p_mw','shunt_p_mw','shunt_q_mvar','solved_gen_q_mvar','added_support_MVAr')
def rows(observation,name):
    f=observation['physical_tables'][name]
    return [(i,dict(zip(f['columns'],v))) for i,v in zip(f['index'],f['values'])]
def number(value):
    if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('Required measured node field missing; no numeric truth imputation')
    return float(value)
def node_observables(observation,support):
    values=[[0.]*13 for _ in range(118)]
    # Zero device sums mean genuinely no devices at that bus, not a missing field.
    for bus,r in rows(observation,'res_bus'):
        values[bus][:4]=[number(r[k]) for k in ('vm_pu','va_degree','p_mw','q_mvar')]
    for name,fields in (('load',(('p_mw',4),('q_mvar',5))),('sgen',(('p_mw',6),('q_mvar',7))),
                        ('gen',(('p_mw',8),)),('shunt',(('p_mw',9),('q_mvar',10)))):
        for i,r in rows(observation,name):
            if r.get('in_service',True) is False:continue
            bus=int(r['bus'])
            for key,position in fields:values[bus][position]+=number(r[key])
    gen={i:r for i,r in rows(observation,'gen')}
    for i,r in rows(observation,'res_gen'):values[int(gen[i]['bus'])][11]+=number(r['q_mvar'])
    for b,value in enumerate(support):values[b][12]=number(value)
    adjacency=[[0.]*118 for _ in range(118)]
    for name,ends in (('line',('from_bus','to_bus')),('trafo',('hv_bus','lv_bus'))):
        for i,r in rows(observation,name):
            if r['in_service'] is False:continue
            a,b=(int(r[k]) for k in ends);adjacency[a][b]+=1.;adjacency[b][a]+=1.
    for b in range(118):adjacency[b][b]+=1.
    zones=[-1]*118
    for zone,buses in observation['zone_buses'].items():
        index=int(zone.removeprefix('MG'))-1
        for b in buses:
            assert zones[b]==-1;zones[b]=index
    assert all(0<=z<4 for z in zones)
    return values,adjacency,zones
def compile_input(augmented,normal,node_normal):
    assert set(augmented)=={'current_physical_observation','original_Q_grid','current_control_state'}
    observation=augmented['current_physical_observation'];records=validate_observation(observation)
    assert tuple(augmented['original_Q_grid'])==Q_GRID
    control=augmented['current_control_state'];assert control['original_per_bus_added_support_cap_MVAr']==450.
    support=control['added_abs_Q_MVAr_by_bus'];assert len(support)==118
    known={tuple(x):i for i,x in enumerate(normal['typed_semantic_schema'])}
    ids=[];kinds=[];numeric=[];coordinates=[];texts=[]
    for r in records:
        key=group_for(observation,r['path']);ids.append(known[(key,r['kind'])]);kinds.append(KINDS.index(r['kind']))
        v=0. # Masked numeric-channel padding for nonnumeric kinds, not a truth field.
        if r['kind'] in ('int','float'):
            stats=normal['numeric'][key];v=(r['value']-stats['mean'])/stats['scale']
        numeric.append([v,float(r['value']) if r['kind']=='bool' else 0.,r.get('length',0)/118.])
        positions=[p for p in r['path'] if type(p)is int]
        bus_keys=[int(p) for p in r['path'] if type(p)is str and p.isdecimal()]
        coordinates.append([(positions[0] if positions else bus_keys[0] if bus_keys else 0)/118.,(positions[1] if len(positions)>1 else 0)/118.])
        texts.append(list(r['value'].encode('utf-8')) if r['kind']=='str' else [])
    raw_nodes,adjacency,zones=node_observables(observation,support)
    nodes=[[((v-node_normal['mean'][j])/node_normal['scale'][j]) for j,v in enumerate(row)] for row in raw_nodes]
    pools=set(b for p in observation['raw_common_and_zone_pools'].values() for b in p)
    allowed=[[b in pools and support[b]+q<=450. for q in Q_GRID] for b in range(118)]
    result={'field_ids':torch.tensor(ids,dtype=torch.long),'kind':torch.nn.functional.one_hot(torch.tensor(kinds),num_classes=7).float(),
            'numeric':torch.tensor(numeric,dtype=torch.float32),'coordinates':torch.tensor(coordinates,dtype=torch.float32),'value_bytes':texts,
            'node_features':torch.tensor(nodes,dtype=torch.float32),'adjacency':torch.tensor(adjacency,dtype=torch.float32),
            'zone_ids':torch.tensor(zones,dtype=torch.long),'allowed_actions':torch.tensor(allowed,dtype=torch.bool)}
    assert all(bool(torch.isfinite(x).all()) for x in (result['numeric'],result['coordinates'],result['node_features'],result['adjacency']))
    return result
