"""Save the exact closed scope checkpoint and compact publication artifacts."""
import hashlib, json, os, zipfile
from datetime import datetime, timezone
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_native_role_scope_handoff_20261022'
def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('w', encoding='utf-8', newline='') as f:
        if isinstance(value, str): f.write(value)
        else: json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush(); os.fsync(f.fileno())

def main():
    O.mkdir(exist_ok=False); at = datetime.now(timezone.utc).isoformat()
    stages = {
      'closed60426_index_reuse_for_all45': 'outputs/original_role_prior_input_scope_20261022',
      'all9297_named_extra_attempts': 'outputs/original_role_additional_history_scope_v2_20261022',
      'all36_shunt_collision_load_witnesses': 'outputs/original_role_input_collision_resolution_20261022',
      'all_remaining738_snapshots_and204_recipes': 'outputs/original_role_remaining_native_history_scope_20261022'}
    evidence = {}; costs = []
    for label, rel in stages.items():
        p = R / rel; result = read(p / 'Result.json'); audit = read(p / 'independent_audit/Independent_Audit.json')
        assert audit['status'].startswith('PASS_')
        evidence[label] = {'result': result, 'independent_audit': audit,
            'result_sha256': sha(p / 'Result.json'), 'audit_sha256': sha(p / 'independent_audit/Independent_Audit.json')}
        costs.extend([result['workflow_seconds'], audit['workflow_seconds']])
    assert evidence['closed60426_index_reuse_for_all45']['result']['targets_excluded_in_this_index'] == 45
    assert evidence['all36_shunt_collision_load_witnesses']['result']['excluded_in_named9297_scope'] == 45
    final = evidence['all_remaining738_snapshots_and204_recipes']['independent_audit']
    assert final['source_journal_closure_complete'] and final['target_snapshot_matches_UNKNOWN'] == final['recipe_load_matches_UNKNOWN'] == 0
    summary = {'at_utc': at, 'status': 'PASS_ALL45_NAMED_HISTORY_INPUT_SCOPE_CHECKS',
        'all45_targets': 45, 'tracked_PF_attempts_covered': 69723,
        'extra_saved_snapshot_files': 738, 'named_original_recipe_load_inputs': 204,
        'false_shunt_only_collisions_resolved_by_different_load_inputs': 36,
        'all_closed_independent_checks_PASS': True,
        'new_PF_model_optimizer_derivative_forecast_training_calls': 0,
        'pure_new_network_decodes': 2, 'pure_new_scenario_applications': 408,
        'closed_successful_saved_analysis_workflow_seconds': sum(costs),
        'old_failed_read_only_v1_runtime': 'UNKNOWN_NOT_FREE; original source/protocol/claim preserved; Windows260character path error, exact capsule exists via extended path. No scientific call repeated.',
        'scope_limit': 'Named tracked workspace lineages and204recipe inputs, not a universal assertion about all untracked historical executions. Subsequent-root/assignment/source reconciliation must be explicit in a new prospective study.',
        'not_a_physical_performance_result_or_full_controller_comparison': True,
        'new_physics_study_or_GPU_launched_by_this_gate': False, 'evidence': evidence}
    write(O / 'Verified_Scope_Results.json', summary)
    plan = {
        'at_utc': at, 'status': 'NATIVE_MODEL_AND_NAMED_HISTORY_GATES_CLOSED_FULL_CONTROLLER_WORK_OPEN',
        'all6goals': 'OPEN', 'current_owner': None, 'current_GPU_assignments': 0, 'timers': [],
        'original_native_model_resume': 'outputs/original_reflection_native_role_handoff_20261022/Current_Resume.json',
        'closed_named_history_scope': str((O / 'Verified_Scope_Results.json').relative_to(R)),
        'latest_verified_GitHub': '22ba0b2fffe534675a2df707f9c0be2bedb2d49f',
        'new_scientific_execution_ready': False,
        'remaining_execution_tasks': [
          {'id': 'G3.F118.4c', 'status': 'OPEN', 'task': 'Freeze a genuinely missing-only ALL45 native FIRST_ZONE measurement protocol/source/reader. Bind exact two captured roots, original9Q/native450cap/raw candidate menu/native verifier/normal-band score/solver kwargs, known history scope and any subsequent lineage assignments. Ownership/persistent pre-call reservation/warm-cold/RNG/boundary/failure preservation and separately charged first NEW-return replay must pass before entry. No original initial solve or99paidqueries repeated.'},
          {'id': 'G3.F118.6b', 'status': 'OPEN', 'task': 'Integrate actual four-zone Reflection-v4 serving and full25-step original chronological controller. Empty feedback is legal only the first zone of the first iteration. Later prompts must come from actual protected current-state receipts, committed history and remaining slots. Persist every model token/attempt, candidate/refinement/commit and full DFF+LLM branch costs. Never call the two-root prompt screen a whole policy result.'},
          {'id': 'G3.F118.5', 'status': 'OPEN', 'task': 'Bind compatible trained external118method artifacts or an explicit faithful source-grounded common-actuator adaptation/training protocol. Native generator-Q/continuous inverter controls cannot silently become the paper positive discrete shunt parser. Preserve source-fidelity rows separately from shared information/action/protection/cost rows.'},
          {'id': 'G3.F118.7', 'status': 'OPEN', 'task': 'Before performance freeze entire outcome-independent case cohort, actual baselines and equally informed trained numerical/constant bus12Q50/base-disabled controls; score all wins/ties/losses/unsafe/partial/unknown states and full costs. Two additional inspected development roots are not registered203closure or unused confirmation.'}],
        'prohibited_shortcuts': ['No source/settings changes to an in-flight owner', 'No restart of old terminated/partial owners or scientific retries', 'No guard/Q/prompt/checkpoint/seed/budget outcome sweeps', 'No unearned90percentconfidence or claimed victory', 'No GPU solely because it is idle', 'No full137rawjoin or all-published-method superiority claim'],
        'published_primary_source_intake': 'outputs/federation_matched_benchmark_20261022/external118_additional_primary_sources_20261022/Primary_Source_Compatibility_Addendum.json',
        'full_DSE_LLM_zero_all_security': 'UNACHIEVED'}
    write(O / 'Current_Resume.json', plan)
    entry = f'''{at}
Method: queried ALL45 missing native FIRST_ZONE identities against the already independently closed60426PFinput index; independently read9297additional named attempts including3failedcalls, resolved ALL36 shunt-only apparent overlaps by exact different nominal-load inputs, then checked ALL738 saved warm/cold/reference-replay snapshots and ALL204 named recipe load inputs. All scoped independent checks PASS. No solver/model/training/derivative/forecast was called. Two pure network decodes and408pure scenario applications were paid; successful saved-analysis workflows total{sum(costs):.6f}seconds. Failedv1reader path handling cost remains UNKNOWN/notfree; source/claim/protocol retained; distinctv2extended-path repair made no scientific retry.
Improvement: the45missing actions now have source-bound exclusions across these named histories, rather than only a missing CSV record. Apparent action/shunt matches were checked against the actual different load conditions. Every failure and unknown scope remains explicit.
Limitations: this is input/measurement-readiness evidence, not new UV reduction, original fullReflection-v4 performance, a universal historical absence proof, unused confirmation or LLM superiority. No new physics or GPU campaign launched. Original137paper290/291/193 and actual saved67v4DFF32/HGVF29/HGSE19 remain distinct cohorts. The new2rootmodel study remains a native first-zone probe: LoRA needed original reprompt, chose constantbus12Q50both, L2saved46to44accepted; no whole-controller victory.
Next: exact prospective missing-only ALL45 source/ownership/persistence/first-replay gates, then actual causal four-zone/full25-step original controller and compatible external118trained baselines/common-action controls. All6finalgoals OPEN. No livejob/GPU/timer.
'''
    write(O / 'Research_Progress_Entry.md', entry)
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f: f.write('\n' + entry + '\n')
    for rel in ['outputs/full_system_comparison_20261021/Current_Resume.json', 'outputs/federation_matched_benchmark_20261022/Current_Resume.json', 'outputs/original_reflection_native_role_handoff_20261022/Current_Resume.json']:
        p = R / rel; d = read(p); d.update(updated_at_utc=at, native_scope_resume=str((O / 'Current_Resume.json').relative_to(R)), current_owner=None,
            native_named_history_gate='PASS_NAMED_SCOPE_NOT_AUTOMATIC_PHYSICS_AUTHORITY', current_GPU_assignments=0, timers=[])
        write(p, d)
    p = R / 'outputs/research_tasks_20261014/Tasks.json'; d = read(p)
    for t in d['tasks']:
        if t.get('checklist_id') != 'G3': continue
        if not any(s.get('id') == 'G3.F118.4b' for s in t.get('subtasks', [])):
            t.setdefault('subtasks', []).append({'id': 'G3.F118.4b', 'completed': True,
              'description': 'ALL45named-history exclusions:69723attempts/738snapshots/204recipes, source-bound36load collision witnesses; independentPASS,0newscience. Scoped, not automatic PF authority.',
              'evidence': str((O / 'Verified_Scope_Results.json').relative_to(R))})
        t['next'] = plan['remaining_execution_tasks'][0]['task']
    d.update(updated_at_utc=at, latest_resume=str((O / 'Current_Resume.json').relative_to(R))); write(p, d)
    header = f'''## Native-role history gates closed; full matched controller comparison OPEN — {at}

All45missing FIRST_ZONE actions excluded from69723named tracked attempts,738remaining saved snapshots and204named recipe load inputs; independentPASS.36shunt-only overlaps had different actual loads. Newscience0. Windows260path failure preserved; additivev2saved-reader repair only. Named finite scope, not universal history/PF permission. No livejob/GPU/timer. All6finalgoalsOPEN.

Resume outputs/original_native_role_scope_handoff_20261022/Current_Resume.json. Next freeze exact missing-only source/native/ownership/persistentwarmcold/firstchargedNEWreplay gates, complete actual four-zone/full25step Reflection-v4, then compatible trained external118ports and fair fullcost controls. Empty later-zone feedback, native-to-foreign unit relabelling and data-readiness-to-performance claims are prohibited. Original frozen assets/literalDSE/bothbranches/FULLBOTH and alladverse/partial/UNKNOWN retained.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        p = R / rel; write(p, header + p.read_text('utf-8'))
    PUB = O / 'publication'; PUB.mkdir()
    write(PUB / 'README.md', '# Native original-role measurement history checkpoint\n\nSource-bound readiness evidence; no new UV/performance result. All6goalsOPEN. Source/table/action differences and every failure remain explicit. Private weights,NETs,full private trainbank,credentials and third-party sources are not included. This compact publication is not a complete rawbackup.\n')
    write(PUB / 'Research_Progress_Entry.md', entry)
    write(PUB / 'Current_Resume.json', plan)
    write(PUB / 'Verified_Scope_Results.json', summary)
    write(PUB / 'All45_Missing_Identities.json', read(R / 'outputs/original_reflection_native_role_handoff_20261022/Exact45_Missing_Paid_Action_Identities_NOT_Execution_Authority.json'))
    source_names = ['query_original_role_prior_input_scope_20261022.py', 'audit_original_role_prior_input_scope_20261022.py',
       'close_original_role_additional_histories_20261022.py', 'audit_original_role_additional_histories_20261022.py',
       'prepare_additional_history_path_repair_v2_20261022.py', 'close_original_role_additional_histories_v2_20261022.py',
       'audit_original_role_additional_histories_v2_20261022.py', 'resolve_original_role_input_component_collisions_20261022.py',
       'close_original_role_remaining_native_histories_20261022.py', Path(__file__).name]
    files = [R / 'work' / n for n in source_names]
    for rel in stages.values():
        p = R / rel
        files.extend([p / 'Protocol.json', p / 'Result.json', p / 'Closed_Manifest.json',
                      p / 'independent_audit/Independent_Audit.json', p / 'independent_audit/Closed_Manifest.json'])
    files.append(R / 'outputs/original_role_additional_history_scope_20261022/Preserved_Terminal_Failure.json')
    files.append(R / plan['published_primary_source_intake'])
    manifest = {'members': {str(p.relative_to(R)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in files}}
    zpath = PUB / 'Own_Code_And_Proofs.zip'
    with zipfile.ZipFile(zpath, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files: z.write(p, str(p.relative_to(R)))
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        assert all(hashlib.sha256(z.read(n)).hexdigest() == row['sha256'] for n, row in manifest['members'].items())
    manifest.update(zip_bytes=zpath.stat().st_size, zip_sha256=sha(zpath), zip_members=len(files), CRC_and_every_member_hash='PASS')
    write(PUB / 'Evidence_Manifest.json', manifest)
    expected = [{'local': str(p.relative_to(R)), 'remote': 'research/20261022_original_role_history/' + p.name,
                 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(PUB.iterdir()) if p.is_file()]
    assert len(expected) == 7
    write(O / 'Expected_Remote_Files.json', expected)
    print(json.dumps({'checkpoint_saved': str(O.relative_to(R)), 'all6goals': 'OPEN', 'publication_files': 7, 'zip_bytes': zpath.stat().st_size}))

if __name__ == '__main__': main()
