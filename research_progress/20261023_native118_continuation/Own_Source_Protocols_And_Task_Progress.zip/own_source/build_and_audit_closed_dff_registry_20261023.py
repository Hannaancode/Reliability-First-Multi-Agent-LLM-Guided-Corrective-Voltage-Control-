"""One saved-only producer and independent equation reader, never new PF."""
from fractions import Fraction
from datetime import datetime,timezone
from reflection118_remaining_cases_core_20261023 import *
TOP=R/'outputs/reflection118_remaining_cases_preparation_20261023'

def direct_key(net):
    # Independent table-cell equations, without calling Registry.key,
    # component(), necessary() or using the producer's stored intermediate.
    shunts={};loads={}
    for i in net.shunt.index:
        s=net.shunt.loc[i];bus=int(s['bus'])
        if not bool(s['in_service']) or not bool(net.bus.at[bus,'in_service']):continue
        factor=(Fraction(float(net.bus.at[bus,'vn_kv']))/Fraction(float(s['vn_kv'])))**2*Fraction(float(s['step']))
        p,q=shunts.get(bus,(Fraction(0),Fraction(0)))
        shunts[bus]=p+factor*Fraction(float(s['p_mw'])),q+factor*Fraction(float(s['q_mvar']))
    sr=[[b,[p.numerator,p.denominator],[q.numerator,q.denominator]] for b,(p,q) in sorted(shunts.items()) if p or q]
    for i in net.load.index:
        s=net.load.loc[i];b=int(s['bus'])
        if not bool(s['in_service']) or not bool(net.bus.at[b,'in_service']):continue
        p,q=loads.get(b,(Fraction(0),Fraction(0)));scale=Fraction(float(s['scaling']))
        loads[b]=p+scale*Fraction(float(s['p_mw'])),q+scale*Fraction(float(s['q_mvar']))
    value=dict(load=[[b,str(p),str(q)] for b,(p,q) in sorted(loads.items())],line_service=[[int(i),bool(net.line.at[i,'in_service'])] for i in net.line.index],bus_service=[[int(i),bool(net.bus.at[i,'in_service'])] for i in net.bus.index])
    return hashlib.sha256(canonical(sr)).hexdigest()+':'+hashlib.sha256(canonical(value)).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['build','audit'],required=True);args=ap.parse_args()
    out=TOP/('closed_registry' if args.mode=='build' else 'closed_registry_independent');out.mkdir(exist_ok=False);began=time.monotonic()
    put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    wait_ack(out,began)
    np,pp,v2,runner,reflection=setup()
    def forbidden(*a,**k):raise OperationalStop('CLOSED_INDEX_FORBIDS_PF_MODEL')
    pp.runpp=forbidden
    from coordinate_native_inverter_linear_reference_20261020 import process
    for d in ['r118_dff_missing_continuation_coordination_20261023','r118_dff_missing_continuation_reader_coordination_20261023']:
        end=read(R/'outputs'/d/'End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended'] and process(end['actual_pid']) is None and process(end['launcher_pid']) is None
    if args.mode=='build':
        from prior_physical_query_footprints_20261018 import component
        from run_reflection118_chronological_local_20261022 import necessary
        rows=[]
        for item in complete_dff_receipts():
            assert time.monotonic()-began<1800
            before=saved_net(item['directory'],item['before']);key=component(before)[0]+':'+hashlib.sha256(canonical(necessary(before))).hexdigest()
            row=dict(item);row['directory']=row['directory'].relative_to(R).as_posix();row['resource_key']=key;rows.append(row)
        put(out/'Closed_Physical_Receipt_Registry.json',dict(status='CLOSED_NAMED_CURRENT_AND_DFF_RECEIPTS_INCLUDING_FAILED_UNRECOVERED',rows=rows,record_count=len(rows),DFF_result_sha256=sha(E/'Result.json'),DFF_audit_sha256=sha(A/'Independent_Audit.json'),source_sha256=sha(__file__),no_new_scientific_calls=True))
        put(out/'Result.json',dict(status='COMPLETE_SAVED_ONLY_REGISTRY_REQUIRE_INDEPENDENT_EQUATION_READER',record_count=len(rows),new_scientific_calls=0,workflow_seconds=time.monotonic()-began))
    else:
        index=TOP/'closed_registry/Closed_Physical_Receipt_Registry.json';data=read(index)
        assert data['DFF_result_sha256']==sha(E/'Result.json') and data['DFF_audit_sha256']==sha(A/'Independent_Audit.json')
        checked=0
        for row in data['rows']:
            assert time.monotonic()-began<1800
            assert sha(R/row['source'])==row['source_sha256'];net=saved_net(R/row['directory'],row['before'])
            assert direct_key(net)==row['resource_key'];checked+=1
        assert checked==data['record_count']
        put(out/'Independent_Audit.json',dict(status='PASS_ALL_CLOSED_REGISTRY_INPUTS_AND_INDEPENDENT_RATIONAL_KEYS',rows_checked=checked,index_sha256=sha(index),source_sha256=sha(__file__),new_model_PF_derivative_optimizer_calls=0,workflow_seconds=time.monotonic()-began))
    put(out/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in out.iterdir() if f.is_file()}))

if __name__=='__main__':main()
