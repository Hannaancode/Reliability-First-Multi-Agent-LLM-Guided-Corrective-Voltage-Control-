"""Additive zero-science repair of ONLY reader claim provenance/output path.

The original reader main AST is unchanged except its new output directory.
The exact claim function is rebound to THIS actual entrypoint source, fixing
its original imported-worker __file__ mistake. No original source is edited.
"""
import argparse,ast,copy,hashlib,os
from pathlib import Path
import audit_exact_two_paid_query_engineering_20261018 as old
import exact_two_paid_query_engineering_20261018 as support
from public118_slsqp_native_20261018 import R,read,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
B=support.B

def repaired_main():
    repair=read(B/'reader_source_claim_repair_v2/Repair_Protocol.json')
    assert repair['reader_source_sha256']==sha(__file__) and repair['original_reader_sha256']==sha(old.__file__)
    assert read(B/'reader_source_claim_repair_v2/Original_Actors_Ended.json')['all_original_actors_ended']
    # Hold the repair sources/protocol immutable for this one analysis owner.
    guard=LockedSourceSnapshot(B/'reader_source_claim_repair_v2/Repair_Protocol.json')
    try:
        source=Path(support.__file__);t=ast.parse(source.read_text('utf-8'));claim=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='claim')
        cg=support.__dict__.copy();cg['__file__']=__file__;exec(compile(ast.Module(body=[claim],type_ignores=[]),str(source),'exec'),cg)
        main=copy.deepcopy(next(n for n in ast.parse(Path(old.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main'))
        old_dump=ast.dump(main,include_attributes=False);changed=0
        for n in ast.walk(main):
            if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='out' for x in n.targets):
                assert ast.unparse(n.value)=="B / 'audit'";n.value=ast.parse("B/'audit_source_claim_v2'",mode='eval').body;changed+=1
        assert changed==1
        inverse=copy.deepcopy(main)
        for n in ast.walk(inverse):
            if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='out' for x in n.targets):n.value=ast.parse("B/'audit'",mode='eval').body
        assert ast.dump(inverse,include_attributes=False)==old_dump
        env=old.__dict__.copy();env['claim']=cg['claim']
        exec(compile(ast.fix_missing_locations(ast.Module(body=[main],type_ignores=[])),str(old.__file__),'exec'),env);env['main']()
    finally:guard.close()

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--reader',action='store_true');a.parse_args();repaired_main()
