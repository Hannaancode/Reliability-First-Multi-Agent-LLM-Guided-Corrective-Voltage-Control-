"""Additive saved-output/source/equation audit. No policy inference or PF call."""
import ast,copy,hashlib,json,os,pickle,time,traceback,collections
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PRIMARY=ROOT/'outputs/public13_remaining_published_cohort_20261021';OUT=ROOT/'outputs/public13_terminal_saved_prefix_20261021'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);began=time.monotonic();put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    import candidate_process_runtime,sys
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np,torch
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    from coordinate_native_inverter_linear_reference_20261020 import process
    p=json.loads((ROOT/'outputs/public13_full_cohort_preparation_20261021/Protocol.json').read_text());end=json.loads((ROOT/p['primary_coordination']/'End_ACK.json').read_text());assert end['actual_owned_chain_ended'] and end['exit_code']==1
    for pid,source in [(13544,'run_public13_remaining_published_cohort_20261021.py'),(6736,'coordinate_public13_cohort_20261021.py')]:
        current=process(pid);assert not current or source not in (current.get('CommandLine') or '')
    assert not (ROOT/'outputs/public13_published_cohort_independent_20261021').exists(),'No reader beside an earlier claim'
    for name,h in p['source_and_input_hashes'].items():assert sha(ROOT/name)==h
    deadline=began+1800;failure=json.loads((PRIMARY/'Failure.json').read_text());assert failure['type']=='AssertionError' and 'final_parameters=parameters()' in failure['traceback'];put(OUT/'Frozen_Before.json',frozen_checks())
    costs={'new_policy_forward_calls':0,'new_PF_calls':0,'new_optimizer_backward_training_calls':0,'new_converter_derivative_factor_solve_calls':0,'saved_b_c_projection_vector_operations':0,'saved_equation_states_checked':0};prior='0'*64;counts=collections.Counter();safe_counts=collections.Counter();attempts={}
    for line in (PRIMARY/'events.jsonl').read_text(encoding='utf-8').splitlines():
        item=json.loads(line);v=item['event'];assert v['previous']==prior and hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==item['sha256'];prior=item['sha256'];counts[v['kind']]+=1
        if v['kind']=='agent_forward_return' and v['algorithm']=='safe-ddpg':safe_counts[v['agent']]+=1
        if v['kind']=='PF_attempt':assert v['index'] not in attempts;attempts[v['index']]=v
    for name,kind in [('PF_attempts','PF_attempt'),('PF_returns','PF_return'),('PF_exceptions','PF_exception'),('agent_forward_attempts','agent_forward_attempt'),('agent_forward_returns','agent_forward_return'),('checkpoint_load_returns','checkpoint_load_return')]:assert counts[kind]==failure['costs'][name]
    source=ROOT/'outputs/stable_ddpg_author_intake_20261020/author_reference/safeDDPG.py';tree=ast.parse(source.read_text());safe=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SafePolicyNetwork');forward=next(n for n in safe.body if isinstance(n,ast.FunctionDef) and n.name=='forward');mutations=[]
    for n in ast.walk(forward):
        if isinstance(n,ast.Assign):
            for target in n.targets:
                if isinstance(target,ast.Attribute) and target.attr=='data':mutations.append({'line':n.lineno,'assignment':ast.unparse(n)})
    assert [n['assignment'] for n in mutations]==['self.b.data = b','self.c.data = c']
    # Reconstruct only the deterministic inference-time parameter transformation.
    # These are saved-state norm operations, not a neural forward/output replay.
    initial=np.load(PRIMARY/'All9_Immutable_Parameters_Before.npz');derived={n:initial[n].copy() for n in initial.files};projection=[]
    for agent,ncalls in sorted(safe_counts.items()):
        for key in ['b','c']:
            name=f'safe-ddpg::{agent}::{key}';v=torch.from_numpy(derived[name].copy());first=None
            for index in range(ncalls):
                v=v.clamp(min=0);v=.15*v/torch.norm(v,1);costs['saved_b_c_projection_vector_operations']+=1
                if index==0:first=v.numpy().copy()
            derived[name]=v.numpy().copy();projection.append({'agent':agent,'parameter':key,'source_call_count':ncalls,'initial_sum_float64':float(initial[name].astype(float).sum()),'first_projection_changed_elements':int(np.count_nonzero(first!=initial[name])),'derived_final_changed_elements':int(np.count_nonzero(derived[name]!=initial[name])),'max_abs_derived_delta':float(np.max(np.abs(derived[name]-initial[name]))),'actual_primary_final_tensor_snapshot':'UNRECOVERED_NOT_CERTIFIED_BY_THIS_DERIVATION'})
    np.savez(OUT/'Derived_Source_Projected_Parameters_NOT_Actual_Final.npz',**derived);assert any(x['derived_final_changed_elements'] for x in projection)
    put(OUT/'Source_Normalization_Diagnosis.json',{'status':'PASS_SOURCE_BOUND_NONTRAINING_B_C_NORMALIZATION_EXPLAINS_INCOMPATIBLE_IMMUTABILITY_ASSUMPTION','source_sha256':sha(source),'forward_AST_sha256':hashlib.sha256(ast.dump(forward,include_attributes=False).encode()).hexdigest(),'actual_source_parameter_data_assignments':mutations,'saved_state_projections':projection,'scope':'Source-prescribed inference normalization, not new optimizer training. Final derived state is not an actual saved end snapshot. Fresh policy replay and primary end-state byte preservation remain unverified.','new_model_PF_calls':0})
    graph=np.load(ROOT/p['graph']);baseY=graph['Y'];receipts=failure['receipts'];maximum_kcl=maximum_flow=0.;root_recipes=np.load(ROOT/p['recipes']);index_rows=[]
    for r in receipts:
        assert time.monotonic()<deadline-30;index=r['index'];prefix=PRIMARY/'physics'/f'PF{index:06d}';before=prefix.with_name(prefix.name+'_before.pkl');assert sha(before)==r['before_sha256'] and attempts[index]['physical_signature']==r['physical_signature'];net0=pickle.loads(before.read_bytes());assert signature(net0)==r['physical_signature']
        if r['status']!='RETURNED':index_rows.append({'index':index,'status':'UNKNOWN_NO_REPEAT'});continue
        after=prefix.with_name(prefix.name+'_after.pkl');fields=prefix.with_name(prefix.name+'_fields.npz');assert sha(after)==r['after_sha256'] and sha(fields)==r['fields_sha256'];net=pickle.loads(after.read_bytes());assert signature(net)==r['physical_signature'];z=np.load(fields)
        for name in z.files:assert np.array_equal(net[name].select_dtypes(include=[np.number]).to_numpy(float),z[name],equal_nan=True)
        pp=net._ppc;bus=pp['bus'];br=pp['branch'];gen=pp['gen'];assert np.array_equal(br[:,:13],graph['branch'][:,:13]) and np.array_equal(bus[:,[0,4,5]],graph['bus'][:,[0,4,5]]) and pp['baseMVA']==float(graph['baseMVA']);N=len(bus);Y=np.zeros((N,N),complex);fb=br[:,0].real.astype(int);tb=br[:,1].real.astype(int);status=br[:,10].real;y=status/(br[:,2]+1j*br[:,3]);charging=status*br[:,4];ratio=br[:,8].real.copy();ratio[ratio==0]=1.;tap=ratio*np.exp(1j*np.deg2rad(br[:,9].real));yff=(y+1j*charging/2)/(tap*np.conj(tap));yft=-y/np.conj(tap);ytf=-y/tap;ytt=y+1j*charging/2
        for j in range(len(br)):Y[fb[j],fb[j]]+=yff[j];Y[fb[j],tb[j]]+=yft[j];Y[tb[j],fb[j]]+=ytf[j];Y[tb[j],tb[j]]+=ytt[j]
        Y[np.diag_indices(N)]+=(bus[:,4]+1j*bus[:,5])/pp['baseMVA'];assert np.allclose(Y,baseY,atol=1e-12,rtol=1e-12);V=bus[:,7]*np.exp(1j*np.deg2rad(bus[:,8]));S=-(bus[:,2]+1j*bus[:,3]);np.add.at(S,gen[:,0].astype(int),(gen[:,1]+1j*gen[:,2])*gen[:,7]);S/=pp['baseMVA'];kcl=float(np.max(np.abs(V*np.conj(Y@V)-S)));assert kcl<=1e-7;maximum_kcl=max(maximum_kcl,kcl)
        Sf=V[fb]*np.conj(yff*V[fb]+yft*V[tb])*pp['baseMVA'];St=V[tb]*np.conj(ytf*V[fb]+ytt*V[tb])*pp['baseMVA'];flow=float(max(np.max(np.abs(Sf-(br[:,13]+1j*br[:,14]))),np.max(np.abs(St-(br[:,15]+1j*br[:,16])))));assert flow<=1e-7;maximum_flow=max(maximum_flow,flow);costs['saved_equation_states_checked']+=1;index_rows.append({'index':index,'physical_signature':r['physical_signature'],'status':'SAVED_NATIVE_EQUATIONS_PASS_NEW_SOLVER_REPLAY_NOT_EXECUTED','KCL_max_pu':kcl,'complex_branch_flow_max_MVA':flow})
    (OUT/'All_Saved_Equation_Checks.json').write_text(json.dumps(index_rows,indent=2),encoding='utf-8')
    complete_worlds=[];branches=[];steps=0
    for world in failure['worlds']:
        seed=world['seed'];d=PRIMARY/f'seed{seed:03d}';root=pickle.loads((d/'Root_Complete_ENV.pkl').read_bytes());assert sha(d/'Root_Complete_ENV.pkl')==world['root_ENV_sha256']
        for n,tab,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(root['network'][tab][col].to_numpy(),root_recipes[n][seed])
        for branch in world['algorithms']:
            current=copy.deepcopy(root);last=np.zeros((3,1));history=[]
            for pos,row in enumerate(branch['steps'],1):
                cursor_file=d/f"{branch['algorithm']}_{pos:03d}"/'Full_Cursor.pkl';assert sha(cursor_file)==row['cursor_sha256'];cursor=pickle.loads(cursor_file.read_bytes());assert cursor['history']==history and cursor['next_step']==pos and cursor['remaining_source_horizon']==101-pos and np.array_equal(cursor['state'],current['state']) and np.array_equal(cursor['last_Q'],last) and signature(cursor['environment']['network'])==signature(current['network'])==row['before_physical_signature'];raw=np.asarray(row['raw_policy']);q=last-np.clip(raw,-.3,.3);assert np.array_equal(q,np.asarray(row['absolute_Q_Mvar']));expected=copy.deepcopy(current['network']);expected.sgen.loc[expected.sgen.index[:3],'q_mvar']=q.reshape(3);receipt=receipts[row['PF_receipt']];assert signature(expected)==receipt['physical_signature'] and receipt['status']=='RETURNED';after=pickle.loads((PRIMARY/'physics'/f"PF{receipt['index']:06d}_after.pkl").read_bytes());vm=after.res_bus.vm_pu.to_numpy();assert np.array_equal(vm,np.asarray(row['all13_vm_after']));controlled=vm[[2,7,9]];assert np.array_equal(controlled,np.asarray(row['controlled_vm_after'])) and bool(controlled.min()>.95 and controlled.max()<1.05)==row['native_done'];current['network']=after;current['state']=controlled;last=q.copy();history.append(row);steps+=1
            branches.append({'seed':seed,'algorithm':branch['algorithm'],'status':branch['status'],'completed_steps':len(history),'endpoint':branch.get('endpoint'),'scope':'Descriptive saved prefix; actual primary-final weights and fresh independent policy/PF replay remain UNKNOWN'})
        if len(world['algorithms'])==3 and all(a['status']=='COMPLETE_NATIVE_EPISODE' for a in world['algorithms']):complete_worlds.append(seed)
    put(OUT/'Preserved_Prefix_Inventory.json',{'entered_worlds':[w['seed'] for w in failure['worlds']],'all3_complete_worlds':complete_worlds,'all_branches':branches,'entirely_unentered_seeds':list(range(failure['worlds'][-1]['seed']+1,500)),'case162_linear_ddpg_unentered_or_partial':'Explicit branch status/zero-step data retained; do not infer completion.','original_seed0':'Already verified, not rerun','all500_benchmark':'UNKNOWN_NOT_COMPLETE'})
    # Capture a new immutable inventory, never fabricate original success/exit0.
    old_files=[p for p in PRIMARY.rglob('*') if p.is_file()];put(OUT/'Original_Failed_Study_File_Manifest.json',{'original_exit_code':1,'files':[{'path':f.relative_to(PRIMARY).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(old_files)],'journal_last_sha256':prior,'original_result_and_closedmanifest_absent':True,'failure_sha256':sha(PRIMARY/'Failure.json')})
    audit={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_SAVED_PREFIX_SOURCE_JOURNAL_NATIVE_EQUATION_AND_CONTINUITY_AUDIT_ONLY','scientific_study':'TERMINAL_RESOURCE_PARTIAL_WITH_FINALIZATION_ASSERTION_FAILURE','complete_original500':False,'source_normalization_explanation':'Only b/c have source-defined in-forward data normalization; original universal immutability assertion invalid for author policy. Actual final-state snapshot was not saved and stays UNKNOWN.','old_scientist_and_handoff_ended':True,'original_reader_started':False,'entered_worlds':len(failure['worlds']),'complete_all3_worlds':len(complete_worlds),'completed_branches':sum(a['status']=='COMPLETE_NATIVE_EPISODE' for a in branches),'saved_control_steps':steps,'saved_equation_states':len(index_rows),'maximum_KCL_pu':maximum_kcl,'maximum_complex_branch_power_MVA':maximum_flow,'primary_costs_retained':failure['costs'],'new_analysis_costs':costs,'full_independent_rebuilt_solver_policy_replay':'NOT_EXECUTED_NOT_CERTIFIED','actual_primary_final_parameter_bytes':'UNRECOVERED','superiority_result':'UNKNOWN_NO_OURS_ROWS','workflow_seconds':time.monotonic()-began};put(OUT/'Independent_Saved_Output_Audit.json',audit);put(OUT/'Frozen_After.json',frozen_checks());put(OUT/'Closed_Manifest.json',{'files':[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()]});print(json.dumps({k:audit[k] for k in ['status','entered_worlds','complete_all3_worlds','completed_branches','saved_equation_states','maximum_KCL_pu','actual_primary_final_parameter_bytes']}))
if __name__=='__main__':main()
