"""Extract historical printed evidence without executing notebook code or models."""
from pathlib import Path
import ast, datetime, hashlib, json, re
R=Path(__file__).resolve().parents[1]
O=R/'outputs/rag_evaluation_contract_recovery_20261028';O.mkdir(exist_ok=False)
original=Path('C:/Users/HOME/Downloads/RAG_Based_Integration (4).ipynb')
raw=original.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
inventory=json.loads((R/'outputs/notebook_reference_review_20261020/Notebook_Inventory.json').read_text('utf-8-sig'))
expected=next(x['sha256'] for x in inventory if x['file']==original.name)
assert digest==expected
n=json.loads(raw)
def source(i):return ''.join(n['cells'][i-1].get('source',[]))
def output(i):return ''.join(''.join(o.get('text',[])) for o in n['cells'][i-1].get('outputs',[]) if o.get('output_type')=='stream')
def constants(i):
 values={}
 for node in ast.parse(source(i)).body:
  if isinstance(node,ast.Assign):
   try:value=ast.literal_eval(node.value)
   except (ValueError,TypeError):continue
   for t in node.targets:
    if isinstance(t,ast.Name) and t.id in ['INPUT_FILE','DB_OUTPUT_PATH','DATASET_FILE','DB_PATH','MODEL_ID','NUM_TEST_SAMPLES','SEED','TOP_K','MAX_NEW_TOKENS','GROUNDEDNESS_THRESHOLD','NLI_MODEL_ID','MODELS_TO_TEST']:values[t.id]=value
 return values
def anchor(i):return {'notebook':original.name,'notebook_sha256':digest,'one_based_cell':i,'source_sha256':hashlib.sha256(source(i).encode()).hexdigest(),'execution_count_saved':n['cells'][i-1].get('execution_count')}

printed=output(6)
pattern=re.compile(r'📝 TEST CASE #(\d+)\s*\n-{30}\s*\n❓ QUESTION:\s*(.*?)\n-{30}\s*\n🤖 AI ANSWER:\s*(.*?)\n-{30}\s*\n📚 GOLD ANSWER:\s*(.*?)\n={70}',re.S)
matches=list(pattern.finditer(printed))
records=[{'idx':int(m[1]),'question':m[2].strip(),'ai_answer':m[3].strip(),'gold_answer':m[4].strip(),
          'printed_character_span':[m.start(),m.end()],'origin':'historical_saved_notebook_stream_only'} for m in matches]
assert [x['idx'] for x in records]==list(range(1,501)), ('full printed sequence not recovered',len(records))
assert all(x['question'] and x['ai_answer'] and x['gold_answer'] for x in records)
# A second extraction checks every marked case independently of the whole-record expression.
chunks=re.split(r'📝 TEST CASE #',printed)[1:]
assert len(chunks)==500
for i,ch in enumerate(chunks):
 assert int(ch.splitlines()[0])==records[i]['idx']
 for label,key,end in [('❓ QUESTION:','question','\n'+'-'*30),('🤖 AI ANSWER:','ai_answer','\n'+'-'*30),('📚 GOLD ANSWER:','gold_answer','\n'+'='*70)]:
  assert ch.split(label,1)[1].split(end,1)[0].strip()==records[i][key]

with (O/'Historical_500_Printed_QA_Records_LOCAL_ONLY.jsonl').open('x',encoding='utf-8') as f:
 for row in records:f.write(json.dumps(row,ensure_ascii=False)+'\n')
summary_lines=[l for l in printed.splitlines() if re.search(r'BERTScore\s*P/R/F1|ROUGE-[12L]|BLEU \(corpus\)|Avg\. groundedness|Ungrounded|Not stated.*rate|Mean|F1\s*:|BERTScore \(F1\)',l) and not l.startswith('- Case')]
# Save only numerical summary and recipe details, never credential-bearing full code.
report={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_HISTORICAL_PRINTED_RECORD_EXTRACTION_WITH_RECIPE_GAPS',
 'source_identity':{'path':str(original),'sha256':digest,'matches_prior_review':True},
 'cells':[dict(anchor(i),constants=constants(i)) for i in [2,5,6,15,16,18]],
 'historical_500_records':{'count':len(records),'ordered_ids_1_to_500':True,'independent_delimiter_crosscheck':'PASS',
   'file':'Historical_500_Printed_QA_Records_LOCAL_ONLY.jsonl','sha256':hashlib.sha256((O/'Historical_500_Printed_QA_Records_LOCAL_ONLY.jsonl').read_bytes()).hexdigest(),
   'not_fresh_generation_or_independent_model_replay':True},
 'historical_metric_summary_lines':summary_lines,
 'recipe_interpretation':{
   'retrieval_corpus': 'Cell2 indexes question plus answer records from the same named theory JSONL used to sample the cell6 evaluation. No document/source holdout is constructed in these cells.',
   'scope': 'In-corpus QA retrieval recipe; actual runtime index contents/hash and data bytes/order not recovered. This does not certify every original retrieval or establish unseen-source generalisation.',
   'generator': 'Public Qwen/Qwen2.5-0.5B-Instruct via from_pretrained, no adapter load in cell6, no revision pin.',
   'decoder': 'cell6 max_new_tokens256, do_sampleFalse, temperature0.1, top_p0.9; exact runtime implementation/version unresolved.',
   'groundedness': 'Maximum embedding cosine between answer and retrieved documents, threshold0.55; not entailment or domain expert factual adjudication.',
   'baseline_nli': 'Cells15/16 compare closed-book generation against reference using facebook/bart-large-mnli argmax, 512-token truncation. This is a separate experiment from the RAG500 metrics.',
   'cell18': 'Saved parser summary reports342 parsed baseline NLI cases and0.0526 entailment. It is not a500-case RAG score and must not replace the reported99percent figure.'},
 'claim_99_percent':{'status':'UNRESOLVED_EXACT_CONTRACT','reason':'The supplied manuscript reports99percent, but these inspected cells do not establish a matched per-question binary factual correctness label set, adjudication rubric or numerator/denominator for that claim.',
   'retain_as':'MANUSCRIPT_REPORTED_ONLY','do_not_infer':'No claim that the99percent result is false, NLI-derived, or reproduced.'},
 'remaining_missing':['Original dataset bytes/order and source-group split','Actual FAISS index bytes and metadata','Pinned generator/tokenizer/embedding/judge revisions and runtime packages','Per-case retrieval contexts and hashes','Exact99percent factual labels/rubric/cohort','Matched retrieval-on/off same-serving outputs'],
 'new_calls':{'notebook_execution':0,'model':0,'PF':0,'optimizer':0,'GPU_allocation':0}}
(O/'Recovered_Evaluation_Contract.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n','utf-8')
note='''# RAG evaluation evidence recovered from the supplied notebook

The saved cell6 output contains all500 ordered question, generated-answer and reference-answer triples. Two independent text parsers agree on every field. This recovers historical printed evidence without generating an answer or rerunning a metric. It does not recover the original model state or certify the execution independently.

The corresponding recipe uses the public Qwen2.5-0.5B-Instruct model, three retrieved items, greedy generation with a256-token output bound and a seed42 sample. No adapter is loaded in this cell. The exact model revisions, dataset bytes/order and saved FAISS index remain unresolved.

Cell2 indexes the question and answer fields from the same named theory JSONL that cell6 samples for evaluation. This is an in-corpus retrieval recipe, not evidence of generalisation to unseen source documents. The actual saved index must be recovered before making per-case overlap claims. Existing groundedness is an embedding-cosine proxy with threshold0.55 and must remain distinct from factual correctness.

The NLI experiment in cells15/16 is a separate closed-book baseline. Cell18's342-case parsed summary is not a500-case RAG result. The manuscript itself describes this NLI analysis separately. The reported99percent correctness claim still lacks a recovered exact label set, adjudication rule and matched cohort here, so it remains manuscript-reported rather than independently reproduced. This finding does not establish that the reported number is false.

T11 is partially recovered. T13 and T14 still need exact data/source grouping and a genuinely matched retrieval ablation. No third GPU experiment is ready from this evidence alone. The recovered question/answer transcript remains local and is excluded from public code/proof publication.
'''
(O/'Findings_And_Remaining_Contract.md').write_text(note,'utf-8')
tasks_path=R/'outputs/thesis_research_closure_20261028/Tasks.json'
tasks=json.loads(tasks_path.read_text('utf-8-sig'))
for t in tasks['tasks']:
 if t['id']=='T11':t['status']='HISTORICAL500_TRANSCRIPT_AND_RECIPE_RECOVERED_99PERCENT_CONTRACT_UNKNOWN'
 if t['id'] in ['T11','T13','T14']:
  t['evidence'].append('outputs/rag_evaluation_contract_recovery_20261028/Recovered_Evaluation_Contract.json')
tasks_path.write_text(json.dumps(tasks,indent=2,ensure_ascii=False)+'\n','utf-8')
with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
 f.write('\n'+report['at_utc']+' — T11/T13/T14: recovered all500 historical RAG printed QA triples with exact two-parser agreement; recipe same namedQA index/sample, public0.5B no adapter load, TOP_K3/greedy256. Distinct baseline NLI342 summary retained separately.99percent exact label/contract UNKNOWN. No new model/PF/notebook execution. Raw transcript local only.\n')
print(json.dumps({'status':report['status'],'records':len(records),'new_model_PF_calls':0,'claim_99_percent':'UNRESOLVED'}))
