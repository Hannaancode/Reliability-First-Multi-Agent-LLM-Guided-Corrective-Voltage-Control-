"""Structured metadata validation only; does not certify free-text truth or scope.

The application must construct Evidence from its trusted, byte-anchored source
loader. Model output can submit a reference to an entry, never the registry or
the expected source hash. Unknown fields remain unknown. Original notebooks
are not edited and this module is not wired to a live answering system.
"""
from dataclasses import dataclass
import hashlib

FIELDS=frozenset({'page','equation','author','year','document_id','url'})
@dataclass(frozen=True)
class Evidence:
    evidence_id:str
    source_sha256:str
    text:str
    metadata:tuple

def bind_evidence(evidence_id,source_bytes,expected_sha256,text,metadata):
    if not isinstance(evidence_id,str) or not evidence_id:raise ValueError('missing_evidence_id')
    actual=hashlib.sha256(source_bytes).hexdigest()
    if actual!=expected_sha256:raise ValueError('source_identity_mismatch')
    if not isinstance(text,str) or not text:raise ValueError('missing_source_text')
    rows=[]
    for key,value in metadata.items():
        if key not in FIELDS:raise ValueError('unsupported_metadata_field')
        if value is None:continue
        if key in {'page','year'}:
            if type(value)!=int or value<1:raise ValueError('invalid_typed_metadata')
        elif not isinstance(value,str) or not value:raise ValueError('invalid_typed_metadata')
        rows.append((key,value))
    return Evidence(evidence_id,actual,text,tuple(sorted(rows)))

def validate_metadata(request,evidence,active_source_hashes):
    if not isinstance(request,dict) or set(request)!={'evidence_id','field','value'}:
        return {'status':'REJECTED','reason':'invalid_request_schema'}
    if not isinstance(request['evidence_id'],str) or not isinstance(request['field'],str):
        return {'status':'REJECTED','reason':'invalid_request_types'}
    by_id={e.evidence_id:e for e in evidence}
    if len(by_id)!=len(evidence):return {'status':'REJECTED','reason':'duplicate_evidence_id'}
    e=by_id.get(request['evidence_id'])
    if e is None:return {'status':'REJECTED','reason':'unknown_evidence_id'}
    if active_source_hashes.get(e.evidence_id)!=e.source_sha256:
        return {'status':'REJECTED','reason':'unbound_or_changed_active_source'}
    field=request['field']
    if field not in FIELDS:return {'status':'REJECTED','reason':'unsupported_metadata_field'}
    known=dict(e.metadata)
    if field not in known:return {'status':'NOT_STATED','reason':'field_not_in_trusted_metadata','evidence_id':e.evidence_id,'field':field}
    expected=known[field];value=request['value']
    if type(value)!=type(expected) or value!=expected:
        return {'status':'REJECTED','reason':'value_not_equal_to_cited_source_metadata','evidence_id':e.evidence_id,'field':field}
    return {'status':'VERIFIED_METADATA_ONLY','evidence_id':e.evidence_id,'field':field,'value':expected,'source_sha256':e.source_sha256,
            'semantic_answer_truth':'NOT_ASSESSED','out_of_scope_refusal':'NOT_ASSESSED'}

def cited_source_metadata(evidence_ids,evidence,active_source_hashes):
    """Render only actually cited entries, never the first retrieved by default."""
    if not evidence_ids:return {'status':'REJECTED','reason':'no_cited_evidence'}
    by_id={e.evidence_id:e for e in evidence}
    if len(by_id)!=len(evidence):return {'status':'REJECTED','reason':'duplicate_evidence_id'}
    rows=[]
    for key in dict.fromkeys(evidence_ids):
        e=by_id.get(key)
        if e is None or active_source_hashes.get(key)!=e.source_sha256:
            return {'status':'REJECTED','reason':'unknown_or_unbound_citation'}
        rows.append({'evidence_id':key,'source_sha256':e.source_sha256,**dict(e.metadata)})
    return {'status':'BOUND_CITATIONS_ONLY','citations':rows,'semantic_answer_truth':'NOT_ASSESSED'}
