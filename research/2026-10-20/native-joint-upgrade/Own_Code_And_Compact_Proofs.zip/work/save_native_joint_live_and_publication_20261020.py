"""Save exact live engineering ownership plus publishable closed physical progress."""
import json,zipfile,hashlib
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import read,write,sha
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_upgrade_verified_handoff_20261020';PUB=OUT/'publication';PUB.mkdir(exist_ok=False)
now=datetime.now(timezone.utc).isoformat();claim=read(ROOT/'outputs/native_joint_15_engineering_execution_v2_20261020/owner.claim');ack=read(ROOT/'outputs/native_joint_15_engineering_execution_v2_20261020/Launcher_ACK.json');assert ack['fresh_exact_source_PID_parent_command'] and claim['actual_pid']==ack['actual_pid']
resume=read(OUT/'Current_Resume.json');resume.update(at_utc=now,status='CLOSED_PHYSICAL_PROGRESS_NATIVE15_DISPOSABLE_ENGINEERING_LIVE',current_GPU_or_timer='ONE_ORIGINAL_PROFILE_T4_NO_TIMER',all_new_scientific_owners_and_readers='Closedphysics actorsENDED;single NEWnative15engineering ownerLIVE',live_native15={'actual_pid':claim['actual_pid'],'parent_pid':claim['parent_pid'],'source':claim['command'],'source_sha256':claim['source_sha256'],'status':'outputs/native_joint_15_engineering_execution_v2_20261020/status.json','coordinator':'outputs/native_joint_15_engineering_coordination_v2_20261020','session':77982,'reader':'work/audit_native_joint_15_engineering_v2_20261020.py','reader_only_after_actual_end_release_closed_success':True,'no_restart_duplicate_or_source_settings_change':True,'actual_preentry_zero_science_failure_preserved':True})
(OUT/'Current_Resume.json').write_text(json.dumps(resume,indent=2),encoding='utf-8')
header=f'''## Latest native1.5B engineering ownership — {now}

Single original-profileT4 owner{claim['actual_pid']}/parent{claim['parent_pid']} freshlyverified; outputs/native_joint_15_engineering_execution_v2_20261020/status.json is actualstatus,exec77982. One longest3229-token current-only nativejoint-head integration,twoDISPOSABLEupdates/coldrestore planned,not completedcounts/performance. Original pre-entry wrongPython dependencyfailure retained with0allocation/forward. Neverrestart/duplicate/live-edit; fixed1800sec engineering+2100collector, exactclosedpreservation/releasebeforeone lockedreader. Noautomaticfulltraining/performance.

Closedphysicalgain:all13residualOVcontexts/fivedevelopmentworlds safelyrestored by numericalcomponent,15/24accepted/9unsafe rejected,276newPFreturnsinclchargedreplay. Extra globalinfo/query; noLLM/wholepolicywin. All6goalsOPEN. Resume outputs/native_upgrade_verified_handoff_20261020/Current_Resume.json;notimers.

'''
for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
    path=ROOT/rel;path.write_text(header+path.read_text(encoding='utf-8'),encoding='utf-8')
p=ROOT/'outputs/research_tasks_20261014/Tasks.json';tasks=read(p);tasks.update(at_utc=now,latest_resume=str((OUT/'Current_Resume.json').relative_to(ROOT)),process_ownership_at_save=resume['live_native15']);p.write_text(json.dumps(tasks,indent=2),encoding='utf-8')
p=ROOT/'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json';status=read(p);status.update(latest_verified_at_utc=now,latest_verified_resume=tasks['latest_resume'],owned_jobs_latest=[resume['live_native15']],timers_latest=[]);p.write_text(json.dumps(status,indent=2),encoding='utf-8')
with (ROOT/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+header)
# Only our code and compact evidence; raw scientific states, pretrained/private weights remain local.
sources=sorted(set(p for pattern in ['*native*upgrade*20261020.py','*native*affine*20261020.py','native_slm*20261020.py','*native_joint*20261020.py','prepare_native_joint_inputs_20261020.py'] for p in (ROOT/'work').glob(pattern)))
manifest={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sources}
pack=PUB/'Own_Code_And_Compact_Proofs.zip'
proofs=[OUT/'Verified_Progress.json',OUT/'Local_Archive_Audit.json',OUT/'Fresh_Frozen_Asset_Checks.json',ROOT/'outputs/native_affine_physics_independent_20261020/Independent_Audit.json',ROOT/'outputs/native_action_upgrade_support_independent_20261020/Independent_Audit.json',ROOT/'outputs/native_full_grid_affine_independent_20261020/Independent_Audit.json']
with zipfile.ZipFile(pack,'x',zipfile.ZIP_DEFLATED) as z:
    for path in sources+proofs:z.write(path,path.relative_to(ROOT).as_posix())
    z.writestr('OWN_CODE_SOURCE_MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(pack) as z:assert z.testzip() is None
write(PUB/'Code_Pack_Manifest.json',{'members':len(sources)+len(proofs)+1,'bytes':pack.stat().st_size,'sha256':sha(pack),'no_private_credentials_weights_network_raw_NETs_or_thirdparty_weight_export':True,'source_files':manifest})
index='''# Native public benchmark progress and model upgrade\n\nAll eight fixed new development roots and all24published Stable-DDPG/linear/DDPG episodes were retained. Each removed all UV under the source three-controlled-bus stop, but full13bus restoration was3/8,3/8,5/8. A separately frozen global-current-Jacobian numerical correction safely resolved all13residualOVterminal contexts acrossfiveworlds. All24proposals were measured:15accepted/nineunsafe rejected. Independent physical replay/source/cost/frozen gates passed;276newPFreturns overall includingchargedreplays,0exceptions. This extra globalinformation/query component is neither an LLM gain nor a fair complete-policy superiority claim. All initial UV in this cohort was alreadyremoved.\n\nNative1.5B upgrade uses one complete causal current-state input and bounded three-actuator head; full3229tokens/currentfloat64Qcursor checked. One bounded original-profileT4 disposable two-update integration is now live; plannedcounts are not results. No fulltraining/performance is authorized automatically. Original freeformnative transfer remains failed/stopped; all6finalgoals open.\n\nCode pack contains our own code and compact proofs only. Raw scientific assets and model checkpoints remain local. Publication is not a complete raw backup.\n'''
(PUB/'Execution_Index.md').write_text(index,encoding='utf-8');write(PUB/'Checkpoint.json',read(OUT/'Verified_Progress.json'));write(PUB/'Live_Resume_At_Publication.json',resume)
entries=[('RESEARCH_TASKS.md','research/RESEARCH_TASKS.md'),('outputs/research_tasks_20261014/Tasks.json','research/Tasks.json')]
for rel,path in entries:(PUB/Path(rel).name).write_bytes((ROOT/rel).read_bytes())
files=[{'local':str((PUB/Path(rel).name).relative_to(ROOT)),'path':path} for rel,path in entries]
for name in ['Execution_Index.md','Checkpoint.json','Code_Pack_Manifest.json','Own_Code_And_Compact_Proofs.zip','Live_Resume_At_Publication.json']:files.append({'local':str((PUB/name).relative_to(ROOT)),'path':'research/2026-10-20/native-joint-upgrade/'+name})
for row in files:
    raw=(ROOT/row['local']).read_bytes();row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())
write(PUB/'Expected_Remote_Files.json',{'previous_head':'e8b51292cc324e14dcce28fa4f867a76f5e6dec8','files':files});print(json.dumps({'publication_files':len(files),'pack_bytes':pack.stat().st_size,'live_actual_pid':claim['actual_pid']}))
