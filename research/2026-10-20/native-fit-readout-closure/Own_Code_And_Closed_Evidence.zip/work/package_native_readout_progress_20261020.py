"""Own source and compact proof publication only; no raw weights/NETs/credentials."""
import json,hashlib,zipfile,re,shutil
from pathlib import Path
from datetime import datetime,timezone
from prepare_github_research_snapshot_20261018 import SECRET
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/native_readout_progress_handoff_20261020'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False)
def main():
    out=BASE/'publication';out.mkdir(exist_ok=False)
    names=[
      'native_fit_teacher_math_20261020.py','run_native_fit_teacher_20261020.py','audit_native_fit_teacher_20261020.py','prepare_native_fit_teacher_20261020.py','continue_native_fit_teacher_audit_20261020.py',
      'audit_native_fit_cached_response_links_20261020.py','compile_native_fit_training_inputs_20261020.py',
      'native_same_information_MLP_20261020.py','run_native_same_information_MLP_FIT_20261020.py','prepare_native_same_information_MLP_FIT_20261020.py','audit_native_same_information_MLP_FIT_20261020.py',
      'native15_saved_command_physics_integration_20261020.py','run_native15_saved_command_physics_20261020.py','audit_native15_saved_command_physics_20261020.py','prepare_native15_saved_command_physics_20261020.py',
      'prepare_native_stationary_feature_readout_20261020.py','fit_native_stationary_readout_20261020.py','fit_native_stationary_readout_v2_20261020.py','run_native_numeric_stationary_readout_v2_20261020.py','prepare_unentered_numeric_readout_v2_20261020.py',
      'native_frozen_feature_remote_20261020.py','native_frozen_feature_environment_20261020.py','native_frozen_feature_setup_20261020.py','native_frozen_feature_guardian_20261020.py','validate_native_feature_transfer_20261020.py','audit_native_frozen_features_20261020.py',
      'audit_native_closed_CPU_evidence_20261020.py','audit_native_closed_CPU_evidence_v2_20261020.py','audit_native_closed_CPU_evidence_v3_20261020.py','prepare_closed_CPU_reader_repair_20261020.py','prepare_closed_CPU_reader_Y_repair_20261020.py',
      'analyse_saved_native_teacher_bottleneck_20261020.py','native_stationary_serving_contract_20261020.py','check_native_stationary_serving_20261020.py','save_native_readout_progress_20261020.py','package_native_readout_progress_20261020.py'
    ]
    files={('work/'+n):ROOT/'work'/n for n in names}
    proofs=[
      'outputs/native_fit_teacher_handoff_20261020/Completion.json','outputs/native_fit_teacher_handoff_20261020/Saved_Only_Full64_Residual_Diagnostic.json',
      'outputs/native_fit_training_inputs_20261020/Readiness.json','outputs/native_same_information_MLP_FIT_20261020/Failure.json',
      'outputs/native_same_information_MLP_coordination_20261020/End_ACK.json','outputs/native_stationary_readout_fit_20261020/numeric_v2/Results.json',
      'outputs/native_stationary_readout_preparation_20261020/Exact_Current_Input_Support_Proof.json',
      'outputs/native_stationary_readout_preparation_20261020/Prospective_Readout_Protocol.json',
      'outputs/native_closed_CPU_evidence_audit_v3_20261020/Independent_Audit.json','outputs/native_closed_CPU_evidence_audit_v3_20261020/All55_Partial_MLP_State_Proofs.json',
      'outputs/native_closed_CPU_evidence_audit_v3_20261020/Preserved_Partial_MLP_File_Manifest.json',
      'outputs/native_closed_CPU_evidence_repair_preparation_20261020/Saved_Only_Arithmetic_Diagnosis.json',
      'outputs/native_closed_CPU_evidence_repair_preparation_20261020/Static_Repair_Readiness.json','outputs/native_closed_CPU_evidence_Y_repair_preparation_20261020/Static_Readiness.json',
      'outputs/native_closed_CPU_evidence_coordination_20261020/Owner.log','outputs/native_closed_CPU_evidence_coordination_v2_20261020/Owner.log',
      'outputs/native_stationary_serving_boundary_20261020/Readiness.json','outputs/native_stationary_serving_boundary_20261020/All241_Serving_Input_Proofs.json',
      'outputs/native_readout_progress_handoff_20261020/Saved_Only_Teacher_Learning_Bottleneck.json',
      'outputs/native_readout_progress_handoff_20261020/Next_Matched_Benchmark_Contract.md'
    ]
    for rel in proofs:
        path=ROOT/rel
        if path.exists():files[rel]=path
    # Account identities/credential locations are unnecessary in a public proof.
    probe=json.loads((ROOT/'outputs/native_feature_exact_assignment_probe_20261020/All_Selected_Exact_Assignments.json').read_text(encoding='utf-8'))
    public={k:{a:b for a,b in v.items() if a!='original_expected_account'} for k,v in probe.items()}
    public['scope']='Exact selected account identities were verified locally; public account addresses withheld. All original raw evidence retained.'
    put(out/'Exact_Assignment_Probe_Public.json',public);files['proofs/Exact_Assignment_Probe_Public.json']=out/'Exact_Assignment_Probe_Public.json'
    descriptor={}
    for rel,p in files.items():
        assert p.exists(),rel;raw=p.read_bytes();text=raw.decode('utf-8');assert not any(pattern.search(text) for pattern in SECRET),rel
        assert not re.search(r'(?:access_token|refresh_token|client_secret)\s*[:=]\s*[\"\'][A-Za-z0-9._/=+-]{25,}',text)
        descriptor[rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    put(out/'Code_Pack_Manifest.json',{'files':descriptor,'scope':'Own scientific sources/compact proofs, including failures. No raw trained/base weights, checkpoints, native NETs, private adapter or credential contents.','all6finalgoals':'OPEN'})
    archive=out/'Own_Code_And_Closed_Evidence.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel,p in files.items():z.write(p,rel)
        z.write(out/'Code_Pack_Manifest.json','Code_Pack_Manifest.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)+1
        for rel,m in descriptor.items():b=z.read(rel);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
    put(out/'Archive_Audit.json',{'members':len(files)+1,'bytes':archive.stat().st_size,'sha256':sha(archive),'CRC_and_every_member_hash_PASS':True,'raw_backup_complete':False})
    for source,target in [('RESEARCH_TASKS.md','RESEARCH_TASKS.md'),('outputs/research_tasks_20261014/Tasks.json','Tasks.json'),
                          ('outputs/native_readout_progress_handoff_20261020/Verified_Progress_And_Limitations.json','Checkpoint.json'),
                          ('outputs/native_readout_progress_handoff_20261020/Current_Resume.json','Resume_At_Publication.json'),
                          ('outputs/native_readout_progress_handoff_20261020/Next_Matched_Benchmark_Contract.md','Execution_Index.md')]:
        shutil.copyfile(ROOT/source,out/target)
    prefix='research/2026-10-20/native-fit-readout-closure/'
    routes=[('RESEARCH_TASKS.md','research/RESEARCH_TASKS.md'),('Tasks.json','research/Tasks.json'),('Checkpoint.json',prefix+'Checkpoint.json'),('Resume_At_Publication.json',prefix+'Resume_At_Publication.json'),('Execution_Index.md',prefix+'Execution_Index.md'),('Code_Pack_Manifest.json',prefix+'Code_Pack_Manifest.json'),('Own_Code_And_Closed_Evidence.zip',prefix+'Own_Code_And_Closed_Evidence.zip')]
    rows=[]
    for local,remote in routes:
        p=out/local;b=p.read_bytes()
        if p.suffix!='.zip':assert not any(pattern.search(b.decode('utf-8')) for pattern in SECRET)
        rows.append({'local':p.relative_to(ROOT).as_posix(),'path':remote,'bytes':len(b),'sha256':sha(p),'blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
    put(out/'Upload_Plan.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'previous_head':'e7fc00089296a54eb840be01ce91eb31e5cc0842','base_tree':'26e003fe30e51990fbb2ffbe921b3b3f094b7280','files':rows})
    print(json.dumps({'own_source_and_proof_members':len(files)+1,'archive_bytes':archive.stat().st_size,'files_to_publish':len(rows)}))
if __name__=='__main__':main()
