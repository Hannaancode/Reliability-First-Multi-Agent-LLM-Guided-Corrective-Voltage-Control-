"""Locked independent saved-array/support ceiling reader: zero new forecasts."""
from pathlib import Path
import json,os,time
import numpy as np
from actual_mask_original_role_ceiling_20261014 import B,R,PHYS,MASK,pins,read,sha,put,best
from shared_current_domain_physics_guarded_v2_20261014 import inputs,key
from joint_admissibility_order_v1 import order_all_current_forecasts
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible,numerical_only_branches

def main():
    p=pins();lock=read(B/'Independent_Reader_Lock.json')
    assert lock['reader_source_sha256']==sha(Path(__file__)) and lock['worker_protocol_sha256']==sha(B/'Protocol.json')
    result=read(B/'actual/Result.json');assert result['exit_code']==0
    assert read(PHYS/'Completion.json')['science_exit']==read(PHYS/'Completion.json')['reader_exit']==0
    bind=read(B/'actual/Actual_Complete_Physics_Input_Binding.json')
    assert bind['New_Action_Records']==sha(PHYS/'actual/Actual_New_Action_Records.json')
    assert bind['Independent_Physics_Audit']==sha(PHYS/'audit/Independent_Shared_Domain_Physics_Audit.json')
    out=B/'audit';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'reader_sha256':sha(Path(__file__)),'protocol_sha256':sha(B/'Protocol.json')})
    worlds,runner,zones,times=inputs()
    new={(x['world'],key(x['candidate'])):x for x in read(PHYS/'actual/Actual_New_Action_Records.json')['records']}
    checked=0;wins=0;losses=0;unknown=False;summaries=[]
    for w in worlds:
        assert time.perf_counter()-start<p['resource_bound_seconds']
        saved=read(B/'actual'/f'W{w["index"]}_Role_Ceiling.json');current=runner.rescue.grid_metrics(w['net'])
        assert saved['world']==w['world'] and saved['initial']==current
        domain=build_current_domain(w['net'],w['source_cursor'],runner=runner,zones=zones)
        with np.load(MASK/'actual'/f'W{w["index"]}_Actual_Final_Mask_Context.npz',allow_pickle=False) as f:s=f['sensitivity'];v=f['current_vm']
        prior={key(x):x for x in w['paid']}
        for expected,row,measured in zip(w['rows'],saved['new_causal_forecasts'],saved['all_measured_rows']):
            assert {k:row[k] for k in expected}==expected and measured['candidate']==expected
            delta=expected['q']*s[:,expected['receiver']]
            if expected['donor_bus'] is not None:delta-=expected['q']*s[:,expected['donor_bus']]
            vm=v+delta;pred=row['ordering_forecast']
            if not np.isfinite(vm).all() or (vm<=0).any():assert pred['status']=='UNKNOWN_NONPHYSICAL_LINEAR_FORECAST'
            else:
                assert pred['status']=='FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE'
                metrics={'uv_count':int((vm<.95).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum()),'vmin':float(vm.min()),'vmax':float(vm.max())}
                assert all(abs(metrics[k]-pred['after'][k])<=1e-12 for k in metrics)
                score=[int(metrics['uv_count']==0),current['uv_count']-metrics['uv_count'],current['deficit_sum']-metrics['deficit_sum'],metrics['vmin']-current['vmin'],-expected['q']]
                assert all(abs(a-b)<=1e-12 for a,b in zip(score,pred['score']))
            k=key(expected)
            if k in prior:
                truth=prior[k];assert measured['verdict']==truth['verif'] and measured['original_score']==truth['original_score']
            else:
                truth=new[(w['world'],k)];assert measured['verdict']==truth['verdict'] and measured['original_score']==truth['original_score']
            checked+=1
        assert len(saved['new_causal_forecasts'])==len(saved['all_measured_rows'])==len(w['rows'])
        order=[x['universe_index'] for x in order_all_current_forecasts(saved['new_causal_forecasts'],current,w['cursor'])]
        assert order==saved['full_order']
        measured={x['candidate']['universe_index']:x for x in saved['all_measured_rows']}
        numeric=numerical_only_branches(domain=domain,ordering=order)
        b=best([measured[x['universe_index']] for x in numeric],current);assert b==saved['numericK4']
        possible={}
        for zone,pool in domain['original_LOCAL_allowed_per_zone'].items():
            mapping={}
            for uid in order:
                row=measured[uid]['candidate'];group=(row['receiver'],row['q'])
                if row['receiver'] in pool and group not in mapping and resource_eligible(row,w['cursor']):mapping[group]=uid
            expected=[{'recipient':r,'q':q,'broker_candidate':uid} for (r,q),uid in mapping.items()]
            assert expected==saved['all_original_LOCAL_groups'][zone]
            for uid in mapping.values():possible[uid]=measured[uid]
        ceiling=best(list(possible.values()),current);assert ceiling==saved['ideal_originalLOCAL_role_ceiling']
        wins+=int(ceiling['UV']<b['UV']);losses+=int(ceiling['UV']>b['UV'])
        this_unknown=any(x['unknown'] for x in measured.values());unknown|=this_unknown
        assert this_unknown==saved['any_unknown']
        eligible=[uid for uid in order if resource_eligible(measured[uid]['candidate'],w['cursor'])]
        for k in [1,4,8,16,32,64]:
            entries=[measured[i] for i in eligible[:k]];actual=saved['numeric_allK'][str(k)]
            assert actual['best']==best(entries,current)
            assert actual['known_rejected']==sum(not x['verdict']['accepted'] and not x['unknown'] for x in entries)
            assert actual['unknown']==sum(x['unknown'] for x in entries) and actual['actual_selected']==len(entries)
        summaries.append({'world':w['world'],'numericK4_UV':b['UV'],'perfect_recipient_Q_ceiling_UV':ceiling['UV'],'unknown':this_unknown})
    gate='UNKNOWN' if unknown else ('PASS' if wins>=2 and losses==0 else 'FAIL')
    assert checked==result['new_actual_mask_forecast_returns']==6372
    assert gate==result['role_support_gate'] and wins==result['strict_UV_oracle_ceiling_wins'] and losses==result['UV_losses']
    put(out/'Independent_Finite_Support_Role_Ceiling_Audit.json',{'status':'PASS_ALL6372_NEW_ACTUALMASK_PREDICTIONS_FULLPHYSICS_IDENTITIES_SHARED_BROKER_GROUPS_ALLK_AND_FIXED_GATE',
        'role_support_gate':gate,'all_four_worlds':summaries,'strict_UV_ceiling_wins':wins,'UV_losses':losses,
        'reader_new_PF_model_derivative_solve_forecast_function_calls':0,
        'mathematical_scope':'Mostoptimistic finite-support originalLOCALrecipient/Qplusfixednumericaldonor role atK4 only; not anonlinepolicy, learnedbenefit or100percent statement aboutallLLMs/allgrids/horizons.',
        'actual_model_memory_cold_latency_cost_economic_and_physical_policy_gates_remain':True})
    print(json.dumps({'independent_role_ceiling_audit':'PASS','role_gate':gate,'newmodel_PF_forecastcalls':0}))

if __name__=='__main__':main()
