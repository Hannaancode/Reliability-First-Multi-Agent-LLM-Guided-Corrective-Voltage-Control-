"""Actual complete FIT inputs plus fixed predeclared control/reader/full-state ownership gates."""
import json,ast,hashlib,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_same_information_MLP_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);import candidate_process_runtime
    import torch,numpy as np
    from native_same_information_MLP_20261020 import NativeMLP
    inputs=ROOT/'outputs/native_fit_training_inputs_20261020';ready=json.loads((inputs/'Readiness.json').read_text());assert ready['all_rows']==1929 and ready['DEV_confirmation_rows']==0 and ready['maximum_tokens']<=4096
    prior=json.loads((ROOT/'outputs/native_fit_teacher_preparation_20261020/Protocol.json').read_text());assert prior['prospective_learning_details_before_labels']['strong_numeric_MLP']['epochs']==500
    z=np.load(inputs/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz');mu=np.average(z['X'],axis=0,weights=z['weight']);sd=np.maximum(np.sqrt(np.average((z['X']-mu)**2,axis=0,weights=z['weight'])),1e-8);x=torch.tensor((z['X'][:1]-mu)/sd,dtype=torch.float32);torch.manual_seed(20261020);model=NativeMLP();u=model(x);assert u.shape==(1,3) and u.dtype==torch.float32 and (u.abs()<=torch.tensor(.3)).all();u.square().sum().backward();assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    sources=['work/run_native_same_information_MLP_FIT_20261020.py','work/native_same_information_MLP_20261020.py','work/audit_native_same_information_MLP_FIT_20261020.py','work/native_joint_checkpoint_contract_20261020.py']
    for rel in sources:ast.parse((ROOT/rel).read_text())
    files=sources+['outputs/native_fit_training_inputs_20261020/Readiness.json','outputs/native_fit_training_inputs_20261020/Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz']
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'FROZEN_STRONG_SAME_INFORMATION_MLP_FIT_ONLY_SOURCE_CONTROL_PROTOCOL','source_and_input_hashes':{rel:sha(ROOT/rel) for rel in files},'prelabel_hyperparameter_anchor_sha256':sha(ROOT/'outputs/native_fit_teacher_preparation_20261020/Protocol.json'),'all_FIT_rows':1929,'declared_FIT_worlds':64,'active_decision_worlds':61,'features':435,'parameters':178179,'epochs':500,'final_checkpoint_only':True,'batch':32,'seed':20261020,'AdamW_lr_decay':[.001,.01],'loss':'mean normalizednativecommitteduMSE + mean current-affine banddeficit squared,1:1,equalactiveworldweights.Noderivative/teacher/afterfeaturesinMLPinput.','checkpoint':'initial0/every100updates/final500,fsynced/fullAdamW/RNG/cursor/normalization/source and CPU state validated before further updates,allattemptsreturnsfailuresjournaled','fixed_worker_seconds':900,'training_is_not_benchmark':'Teacheritselfonly35/64fullrestorationsinFIT; no blindsuperiorityclaimfromimitationloss. All16DEV/32confirmation untouched. PairedSLM/nativephysical/economiccompletegates stillrequired.','preparation_CPU_random_MLP_forward_backward':[1,1],'preparation_optimizer_PF_pretrained_GPU_calls':0,'reader_zero_optimizer_PF_pretrained_calls':True}
    put(OUT/'Protocol.json',protocol);put(OUT/'Readiness.json',{'status':'PASS_ACTUAL_COMPLETE_INPUT_SOURCE_MASK_NATIVE_BOUND_CPU_FINITE_GRADIENT_FULL_STATE_READER_LOCK','preparation_cpu_MLP_forward_backward':[1,1],'GPU_PF_optimizer_calls':0})
    for mode,file,output,coord in [('primary',sources[0],'outputs/native_same_information_MLP_FIT_20261020','outputs/native_same_information_MLP_coordination_20261020'),('independent',sources[2],'outputs/native_same_information_MLP_independent_20261020','outputs/native_same_information_MLP_reader_coordination_20261020')]:
        put(OUT/f'{mode}_Owner_Protocol.json',{'single_owner':{'source':file,'sha256':sha(ROOT/file),'python':'work/vcsa_module_env/Scripts/python.exe','output':output,'coordination':coord,'bound_seconds':950 if mode=='primary' else 240}})
    print('FIXED_MLP_FIT_ONLY_ACTUAL_READINESS_PASS_NO_HELD_TRAINING')
if __name__=='__main__':main()
