"""ONE bounded mock-only solver audit. No real SciPy module is imported.

The model, derivatives, minimize and native SLSQP are labelled synthetic stubs.
Both preserved solver versions are tested in this one prospective fixed suite.
"""
from pathlib import Path
from datetime import datetime, timezone
from types import ModuleType
from collections import Counter
import importlib.util
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/nonlinear13_preserved_solver_review_20261029'
VERSIONS = {'v1': 'work/nonlinear13_preserved_solver_20261029.py',
            'v2': 'work/nonlinear13_preserved_solver_v2_20261029.py'}
SCENARIOS = ['success', 'unsuccessful_stage1', 'objective_callback_failure',
             'post_return_check_failure', 'native_failure', 'conversion_failure',
             'float32_recheck_failure', 'deadline_before_callback',
             'deadline_during_callback', 'byte_cap_before_proposal']


class Clock:
    now = 0.
    ticks = 0
    def monotonic(self): return self.now
    def perf_counter(self):
        self.ticks += 1
        return self.ticks / 1000.


class SyntheticResult(dict):
    def __getattr__(self, key): return self[key]


class ValidatedNonlinearNative13:
    """Explicit synthetic test double, named only to enter the runner type gate."""
    def __init__(self, scenario, clock):
        self.scenario = scenario; self.clock = clock; self.costs = {}; self.lookup = np.arange(13)
    def charge(self, key): self.costs[key] = self.costs.get(key, 0) + 1
    def initial_vector(self):
        x = np.zeros(31); x[12:24] = 1.; x[27:30] = [.2, .3, .4]; x[30] = .05
        return x
    def bounds(self): return [(None, None)] * 24 + [(-.3, .3)] * 3 + [(0., None)] * 4
    def objective(self, x, stage):
        self.charge('synthetic_objective')
        if self.scenario == 'objective_callback_failure': raise RuntimeError('SYNTHETIC_OBJECTIVE_FAILURE')
        if self.scenario == 'deadline_during_callback':
            self.clock.now = 100.; raise RuntimeError('SYNTHETIC_FAILURE_AT_EXPIRED_DEADLINE')
        return float(x[30]) if stage == 1 else float(sum(x[27:30]))
    def equality(self, x):
        self.charge('synthetic_equality')
        if self.scenario == 'post_return_check_failure': raise RuntimeError('SYNTHETIC_POST_RETURN_FAILURE')
        result = np.zeros(24)
        if self.scenario == 'float32_recheck_failure' and x[24] == .123: result[0] = 1.
        return result
    def inequalities(self, x, first=None): self.charge('synthetic_inequalities'); return np.ones(2)
    def representable_native_action(self, x):
        self.charge('synthetic_conversion')
        if self.scenario == 'conversion_failure': raise ValueError('SYNTHETIC_CONVERSION_FAILURE')
        applied = x.copy()
        if self.scenario == 'float32_recheck_failure': applied[24] = .123
        return np.zeros(3, dtype=np.float32), np.zeros(3), applied
    def voltage(self, x): self.charge('synthetic_voltage'); return np.ones(13, dtype=complex)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def journal_records(path):
    previous = '0' * 64; values = []
    for i, line in enumerate(path.read_bytes().splitlines()):
        value = json.loads(line); event = value['event']
        assert event['seq'] == i and event['previous'] == previous
        digest = hashlib.sha256(json.dumps(event, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
        assert digest == value['sha256']; previous = digest; values.append(event)
    return values, previous


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    files = list(VERSIONS.values()) + ['work/audit_nonlinear13_preserved_solver_20261029.py']
    hashes = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in files}
    protocol = {'label': 'ONE_FIXED_MOCK_ONLY_RUNNER_AUDIT_V1_AND_ADDITIVE_V2',
                'at_utc': datetime.now(timezone.utc).isoformat(), 'source_hashes': hashes,
                'scenarios_per_version': SCENARIOS,
                'extra_journal_boundaries_per_version': ['NaN_deadline', 'positive_infinity_deadline', 'exact_physical_byte_cap'],
                'absolute_mock_deadline': 100., 'normal_byte_cap': 1000000,
                'mock_minimize_calls_at_most_per_scenario': 2,
                'real_optimizer_native_derivative_PF_model_calls': 0,
                'saved_state_or_old_fixture_reads': 0}
    with (OUT / 'Protocol.json').open('x', encoding='utf-8') as f: json.dump(protocol, f, indent=2)
    scipy = ModuleType('scipy'); scipy.__version__ = '1.16.3'; scipy.__path__ = []
    optimize = ModuleType('scipy.optimize'); optimize.__path__ = []
    native = ModuleType('scipy.optimize._slsqp_py'); scipy.optimize = optimize; optimize._slsqp_py = native
    keys = ['scipy', 'scipy.optimize', 'scipy.optimize._slsqp_py']
    prior = {k: sys.modules.get(k) for k in keys}
    sys.modules.update(dict(zip(keys, [scipy, optimize, native])))
    reports = []
    try:
        for version, path in VERSIONS.items():
            module = load(path, 'synthetic_runner_' + version)
            # Replacing all derivative entry points ensures zero real derivative work.
            module.equality_jacobian = lambda m, x: (m.charge('synthetic_equality_jacobian') or np.zeros((24, 31)))
            module.inequality_jacobian = lambda m, x, t: (m.charge('synthetic_inequality_jacobian') or np.zeros((2, 31)))
            module.objective_gradient = lambda m, x, s: (m.charge('synthetic_objective_gradient') or np.zeros(31))
            rows = []
            for scenario in SCENARIOS:
                clock = Clock(); module.time = clock; model = ValidatedNonlinearNative13(scenario, clock)
                calls = []; native_calls = []
                def base_native(state, *args, **kwargs):
                    native_calls.append(dict(state))
                    if scenario == 'native_failure': raise RuntimeError('SYNTHETIC_NATIVE_FAILURE')
                    state['mode'] = 1
                native.slsqp = base_native
                def fake_minimize(fun, x, **kw):
                    stage = len(calls) + 1; calls.append({'stage': stage, 'method': kw['method'], 'options': kw['options'].copy()})
                    assert len(calls) <= 2
                    native.slsqp({'mode': 0, 'iter': stage})
                    if scenario == 'deadline_before_callback': clock.now = 100.
                    if scenario != 'post_return_check_failure':
                        fun(x); kw['jac'](x)
                        for constraint in kw['constraints']: constraint['fun'](x); constraint['jac'](x)
                        kw['callback'](x)
                    success = scenario != 'unsuccessful_stage1'
                    return SyntheticResult(x=x.copy(), success=success, status=0 if success else 9,
                                           message='SYNTHETIC_STUB_ONLY', nit=1, nfev=1, njev=1, multipliers=np.zeros(0))
                optimize.minimize = fake_minimize
                file = OUT / (version + '_' + scenario + '.jsonl')
                journal = module.PersistentCalculationJournal(file, 100., 1 if scenario == 'byte_cap_before_proposal' else 1000000)
                result = None; error = None
                try:
                    result = module.solve_once(model, journal, {'all_required_current_state_checks_passed': True, 'label': 'SYNTHETIC_ONLY'})
                except BaseException as exc:
                    error = {'type': type(exc).__name__, 'message': str(exc)}
                finally: journal.close()
                events, last = journal_records(file); kinds = Counter(e['kind'] for e in events)
                assert native.slsqp is base_native and last == journal.previous
                attempts = {e['identity'] for e in events if e['kind'] == 'calculation_attempt'}
                terminals = {e['identity'] for e in events if e['kind'] in ('calculation_return', 'calculation_failure')}
                assert terminals <= attempts
                row = {'scenario': scenario, 'mock_minimize_calls': len(calls), 'mock_native_calls': len(native_calls),
                       'stage_order': [c['stage'] for c in calls], 'native_wrapper_restored': True,
                       'journal_hash_chain_valid': True, 'journal_events': len(events),
                       'event_counts': dict(kinds), 'charged_bytes': journal.bytes, 'physical_bytes': file.stat().st_size,
                       'unreturned_calculation_identities': sorted(attempts - terminals),
                       'result_status': None if result is None else result['status'], 'exception': error,
                       'synthetic_model_costs': model.costs,
                       'result_costs': None if result is None else result['costs']}
                if scenario == 'success':
                    assert result['status'] == 'ADMITTED_UNMEASURED_PROPOSAL' and len(calls) == 2
                    assert result['costs']['optimizer_attempts'] == result['costs']['optimizer_returns'] == 2
                    assert result['costs']['native_slsqp_calls'] == 2 and result['costs']['major_iteration_callbacks'] == 2
                    assert result['costs']['optimizer_exceptions'] == 0 and kinds['calculation_attempt'] == 18
                    assert result['costs']['native_slsqp_seconds'] > 0
                    assert result['physical_guard'] == 'NOT_EVALUATED_NO_PHYSICAL_CALL'
                    assert 'UNKNOWN' in result['costs']['internal_linear_solves']
                if scenario == 'unsuccessful_stage1': assert len(calls) == 1 and result['status'] == 'FIXED_OPTIMIZER_FAILED_NO_RETRY_NO_CANDIDATE'
                if scenario in ['objective_callback_failure', 'native_failure']: assert error and kinds['optimizer_exception'] == 1 and len(calls) == 1
                if scenario == 'post_return_check_failure':
                    assert error and len(calls) == 1
                    row['returned_optimizer_payload_preserved_before_failed_check'] = bool(kinds['optimizer_raw_return'])
                    if version == 'v2': assert kinds['optimizer_raw_return'] == 1
                if scenario == 'conversion_failure':
                    assert error and len(calls) == 2
                    row['conversion_attempt_and_failure_preserved'] = bool(kinds['representable_action_attempt'] and kinds['representable_action_failure'])
                    if version == 'v2': assert row['conversion_attempt_and_failure_preserved']
                if scenario == 'float32_recheck_failure': assert result['status'] == 'FLOAT32_PROPOSAL_REJECTED_NO_REPAIR' and len(calls) == 2 and 'u' not in result
                if scenario == 'deadline_before_callback': assert error['type'] == 'TimeoutError' and len(calls) == 1 and not model.costs
                if scenario == 'deadline_during_callback': assert error['type'] == 'TimeoutError' and len(calls) == 1 and len(attempts - terminals) == 1
                if scenario == 'byte_cap_before_proposal': assert len(calls) == 0 and file.stat().st_size == 0 and error['type'] == 'TimeoutError'
                if version == 'v2': assert file.stat().st_size == journal.bytes
                rows.append(row)
            boundaries = []
            for name, value in [('NaN', float('nan')), ('positive_infinity', float('inf'))]:
                module.time = Clock(); rejected = False
                try:
                    journal = module.PersistentCalculationJournal(OUT / (version + '_' + name + '.jsonl'), value, 10000)
                except ValueError: rejected = True
                else: journal.close()
                if version == 'v2': assert rejected
                boundaries.append({'name': name + '_deadline', 'rejected': rejected})
            module.time = Clock()
            probe = module.PersistentCalculationJournal(OUT / (version + '_byte_probe.jsonl'), 100., 10000)
            probe.event('fixed_byte_boundary', value='synthetic'); probe.close()
            cap = probe.bytes
            bounded = module.PersistentCalculationJournal(OUT / (version + '_exact_byte_cap.jsonl'), 100., cap)
            bounded.event('fixed_byte_boundary', value='synthetic'); bounded.close()
            size = bounded.path.stat().st_size
            if version == 'v2': assert size == cap
            boundaries.append({'name': 'exact_physical_byte_cap', 'cap': cap, 'charged_bytes': bounded.bytes,
                               'physical_bytes': size, 'physical_cap_respected': size <= cap})
            reports.append({'version': version, 'source': path, 'scenarios': rows, 'journal_boundaries': boundaries})
    finally:
        for key, value in prior.items():
            if value is None: sys.modules.pop(key, None)
            else: sys.modules[key] = value
    assert hashes == {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in files}
    result = {'status': 'PASS_FIXED_MOCK_SUITE_V2_CORRECTS_OBSERVED_V1_GAPS',
              'at_utc': datetime.now(timezone.utc).isoformat(), 'source_hashes': hashes,
              'versions': reports, 'real_optimizer_native_derivative_PF_model_training_GPU_calls': 0,
              'saved_states_or_old_fixtures_used': 0, 'source_or_master_edits': False,
              'limits': ['Synthetic stubs verify wrapper orchestration, not SciPy native convergence or its runtime ABI.',
                         'A callback interrupted after attempt preservation can remain unreturned when the deadline prevents further journal writes. It must stay UNKNOWN, with no retry.',
                         'No physical source guard or controller episode ran. Internal native factorization and solve costs remain UNKNOWN.']}
    with (OUT / 'Results.json').open('x', encoding='utf-8') as f: json.dump(result, f, indent=2, allow_nan=False)
    print(json.dumps({'status': result['status'], 'versions': 2, 'mock_scenarios': 20,
                      'journal_boundary_cases': 6, 'real_optimizer_PF_calls': 0}))


if __name__ == '__main__': main()
