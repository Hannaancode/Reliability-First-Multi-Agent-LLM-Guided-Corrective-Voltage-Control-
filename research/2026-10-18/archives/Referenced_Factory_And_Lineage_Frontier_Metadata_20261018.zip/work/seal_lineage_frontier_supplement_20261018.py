"""Additive packaging repair only; prior supplement/source/failure preserved."""
from pathlib import Path
import json
from candidate_process_evidence_utils import seal
R=Path(__file__).resolve().parents[1];B=R/'outputs/referenced_controller_research_handoff_20261018'
def main():
    out=B/'final_frontier_supplement';out.mkdir(exist_ok=False);files={}
    for name in ['paid_receding_journal_reference_history_v2_20261018.py','paid_receding_referenced_commit_v2_20261018.py','receding_paid_referenced_runtime_v2_20261018.py','check_referenced_controller_factory_cold_capacity_v2_20261018.py','prepare_paid_lineage_frontier_20261018.py','audit_paid_lineage_frontier_20261018.py','save_lineage_frontier_and_next_execution_20261018.py',Path(__file__).name]:files['work/'+name]=R/'work'/name
    for folder in ['referenced_controller_factory_cold_capacity_v2_20261018','paid_lineage_frontier_20261018']:
        for path in (R/'outputs'/folder).rglob('*'):
            if path.is_file() and path.suffix in ['.json','.log']:files[str(path.relative_to(R)).replace('\\','/')]=path
    for path in [B/'Exact_Next_Execution_State.json',B/'Prepared_Referenced_Runtime_Local_Source_Closure.json',B/'Final_Frozen_Checks.json',B/'Results_And_Next_Execution.md',R/'outputs/save_lineage_frontier_and_next_execution_console_20261018.log']:files[str(path.relative_to(R)).replace('\\','/')]=path
    certificate=seal(out,files,'Referenced_Factory_And_Lineage_Frontier_Metadata_20261018.zip')
    print(json.dumps({'status':'PASS_SEPARATE_SUPPLEMENT_NAMESPACE','original_failure':'Attempted to reuse already sealed supplement manifest path; FileExistsError before archive, zero science; old certificate/source/log unchanged.','archive':certificate}))
if __name__=='__main__':main()
