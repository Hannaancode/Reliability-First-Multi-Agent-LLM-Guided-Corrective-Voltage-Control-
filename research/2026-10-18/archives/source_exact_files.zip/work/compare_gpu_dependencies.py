import re,json
from pathlib import Path
norm=lambda s:re.sub(r'[-_.]+','-',s).lower()
freeze={norm(l.split('==')[0]):l for l in Path('work/e/pack/pip_freeze.txt').read_text().splitlines() if '==' in l}
installed={norm(m.group(1)):m.group(2) for m in re.finditer(r'^ \+ ([\w.-]+)==([^\s]+)',Path('outputs/environment_setup.log').read_text(encoding='utf-8'),re.M)}
diff={n:{'frozen':freeze[n].split('==')[1],'restored':v} for n,v in installed.items() if n in freeze and freeze[n].split('==')[1]!=v}
requirements=[freeze[n] for n in installed if n in freeze]
Path('work/frozen_dependency_closure.txt').write_text('\n'.join(requirements)+'\n')
Path('outputs/frozen_dependency_closure_check.json').write_text(json.dumps({'installed_count':len(installed),'recorded_intersection_count':len(requirements),'version_differences':diff,'new_dependencies_not_in_original_record':{n:v for n,v in installed.items() if n not in freeze}},indent=2))
print(json.dumps(diff,indent=2))
