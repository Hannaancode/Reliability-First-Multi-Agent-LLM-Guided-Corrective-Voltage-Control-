"""Post-outcome common-band candidate analysis, reusing already charged verifications."""
from pathlib import Path
from datetime import datetime,timezone
import json
from audit_broader_mixed_value_and_components import original_score
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/llm_value_broader_development'
read=lambda p:json.loads(p.read_text())
assert read(OUT/'Broader_Screen_Completion_Audit.json')['all_gates_passed']
assert read(OUT/'Broader_Component_Completion_Audit.json')['all_gates_passed']
protocol=read(OUT/'clean_value_development_protocol.json');rows=[]
for case in protocol['initial_screen_scenarios']:
 sources={p:read(OUT/'cpu_screen_cases'/(case['scenario_id']+'__'+p+'__B32.json')) for p in ['lowest_voltage','zonal_LoRA_prefix','zonal_base_prefix']}
 for p in ['zonal_LoRA_prefix','zonal_base_prefix']:
  sources[p+'_bus_Q']=read(OUT/'bus_Q_attribution'/(case['scenario_id']+'__'+p+'__bus_Q_component_B32.json'))
 for name,row in sources.items():
  accepted=[t for t in row['tested'] if t['verification']['accepted'] and t['verification']['after']['vmax']<=1.05+1e-8]
  best=max(accepted,key=original_score) if accepted else None
  after=best['verification']['after'] if best else row['initial_metrics']
  rows.append({'scenario_id':case['scenario_id'],'policy':name,'fixed_32_candidate_pool':len(row['tested']),
               'normal_upper_guard_admissible_candidates':len(accepted),'best_recorded_candidate_action':best['action'] if best else None,
               'best_recorded_candidate_metrics':after,'already_selected_and_freshly_executed_in_original_trial':bool(best and best['action']==row['selected_action']),
               'new_PF_calls':0,'claim':'Candidate verification evidence only; a newly selected candidate is not a newly executed controller action'})
comparison=[]
for case in protocol['initial_screen_scenarios']:
 by={r['policy']:r for r in rows if r['scenario_id']==case['scenario_id']}
 comparison.append({'scenario_id':case['scenario_id'],
                    'raw_LoRA_candidate_UV_minus_lowest':by['zonal_LoRA_prefix']['best_recorded_candidate_metrics']['uv_count']-by['lowest_voltage']['best_recorded_candidate_metrics']['uv_count'],
                    'bus_Q_LoRA_candidate_UV_minus_lowest':by['zonal_LoRA_prefix_bus_Q']['best_recorded_candidate_metrics']['uv_count']-by['lowest_voltage']['best_recorded_candidate_metrics']['uv_count']})
result={'analyzed_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Post-outcome common1.05+1e-8 mediation analysis of existing recorded candidate solves, not new policy trials or superiority confirmation',
        'new_model_calls':0,'new_PF_calls':0,'existing_tested_candidates_not_expanded':True,'rows':rows,'comparisons':comparison}
with (OUT/'Common_Band_Candidate_Evidence.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(comparison,indent=2))
