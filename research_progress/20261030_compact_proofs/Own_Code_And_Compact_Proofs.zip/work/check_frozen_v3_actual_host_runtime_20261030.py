"""Actual HOME execution identity check after the isolated dependency ACL repair."""
from pathlib import Path
from datetime import datetime,timezone
import os,sys,json,hashlib,time,subprocess,ctypes
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_frozen_v3_host_admission_20261030'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 start=time.monotonic();O.mkdir(exist_ok=False)
 p=R/'outputs/nonlinear500_receding_acquisition_v3_preparation_20261030/Protocol.json';protocol=json.loads(p.read_text(encoding='utf-8'))
 checks=[];failures=[];admission=None;process=None;clock=None
 for rel,digest in protocol['sources'].items():
  try:
   actual=sha(R/rel);assert actual==digest;checks.append({'path':rel,'sha256':actual})
  except Exception as e:failures.append({'path':rel,'type':type(e).__name__,'error':str(e)})
 if not failures:
  try:
   from nonlinear500_isolated_owner_runtime_v3_20261030 import admit_isolated_runtime
   admission=admit_isolated_runtime(R,protocol)
   import psutil
   from nonlinear13_receding_policy_engine_v2_20261030 import clock_domain
   from run_nonlinear500_receding_acquisition_v3_20261030 import windows_arguments
   proc=psutil.Process();clock=clock_domain();assert clock==clock_domain()
   assert proc.pid==os.getpid() and proc.ppid()==os.getppid()
   assert windows_arguments(subprocess.list2cmdline(proc.cmdline()))==proc.cmdline()
   process={'pid':proc.pid,'parent_pid':proc.ppid(),'username':proc.username(),'command':proc.cmdline()}
   assert proc.username().lower().endswith('\\home'),'Not the actual HOME launch identity'
  except Exception as e:failures.append({'phase':'runtime_admission','type':type(e).__name__,'error':str(e)})
 result=dict(status='PASS_ACTUAL_HOST_IDENTITY_ALL_SOURCE_RUNTIME_ADMISSION' if not failures else 'FAIL_ACTUAL_HOST_RUNTIME_ADMISSION',
  at_utc=datetime.now(timezone.utc).isoformat(),protocol_ref={'path':p.relative_to(R).as_posix(),'sha256':sha(p)},
  admission_source={'path':Path(__file__).relative_to(R).as_posix(),'sha256':sha(__file__)},
  actual_process=process,python=sys.version,executable=sys.executable,all_declared_sources_read=len(checks),
  expected_source_count=len(protocol['sources']),source_checks=checks,failures=failures,admission=admission,clock_domain=clock,
  new_scientific_calls=0,old_inputs_decoded=False,workflow_seconds=time.monotonic()-start,
  ACL_repair_qualification='The repair command had two nonterminating directory ACL errors. This certificate verifies only the actual named source reads and runtime operations under HOME; it does not claim every ACL operation succeeded.',
  scope='Actual deployment identity and new access condition. Custody hashes and imports only; no owner claim, numerical proposal, optimizer, PF or model call.')
 with (O/'Result.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
 print(json.dumps({'status':result['status'],'source_count':len(checks),'failures':failures,'new_science':0}));return 0 if not failures else 1
if __name__=='__main__':raise SystemExit(main())
