from pathlib import Path
import json,hashlib
s=json.loads(Path('outputs/campaign_supervisor_status.json').read_text());print('SUPERVISOR',json.dumps(s,indent=2))
lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());ph=hashlib.sha256(Path('outputs/matched_campaign_protocol.json').read_bytes()).hexdigest()
for p in sorted(Path('outputs/matched_campaign/cases').glob('*.json')):
 d=json.loads(p.read_text());assert d['protocol_sha256']==ph and d['scenario_sha256']==lock['scenario_file_sha256'][p.name]
 rng=Path('outputs/matched_campaign/rng')/f"{d['index_1based']:03d}.pt";assert rng.exists()
 print('VERIFIED_CHECKPOINT',d['index_1based'],d['scenario_id'],'valid',d['paired_terminal_metrics_valid'],'portfolios',{n:{'chosen':v['selected_branch'],'uv':v['summary']['final_uv'],'pf_attempts':v['charged_cost']['pf_attempts'],'llm_calls':v['charged_cost']['llm_calls']} for n,v in d.get('portfolios',{}).items()})
