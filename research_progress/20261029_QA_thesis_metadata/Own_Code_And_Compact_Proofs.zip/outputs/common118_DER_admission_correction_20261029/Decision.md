# Corrected external controller admission

The four saved federation roots each contain four PV-labelled and four diesel-labelled static generators. The earlier report incorrectly counted all eight as PV and also stated that none existed. Both statements are superseded by this source-bound correction; the original report is retained.

This removes a false device-absence objection, but does not make the published residual-SAC inverter controller executable on our original task. All eight apparent-power ratings are missing, explicit reactive limits are absent, and the published environment derives ratings from its own dataset maxima. We cannot manufacture those profiles or assign inverter capabilities to diesel rows. The original method adds positive shunts; native inverter P/Q control remains a different resource permission.

Next work is an explicit common-actuator/observation/cost contract or a separately justified native inverter study with real capability data. No model, action application, power flow, training or GPU allocation occurred here.
