"""All four fixed native GraphAgent episodes from paid first-action cursors."""
from graph118_native_campaign_core_20261028 import *

def main():
    began=time.monotonic();owner(E,began);p=read(P/'Protocol.json');pins(p);np,pp=setup()
    from published_graph118_episode_engine_v2_20261026 import NativeGraphEpisode
    from exact_graph_cursor_compare_20261023 import require_same
    from public_size_u61_preservation import journal,atomic_json
    native=pp.runpp;history=History(p,E/'native_identity');previous='0'*64;rows=[]
    costs=dict(new_PF_attempts=0,new_PF_returns=0,new_PF_exceptions=0,new_PF_seconds=0.,native_policy_calls=0,cold_policy_checks=0,
               derived_paid_returns=0,new_model_GPU_training_calls=0,paid_prefix_cases=4,binary_bytes=0)
    costs['native_input_identity_preparation']=history.costs
    started=datetime.now(timezone.utc).isoformat()
    def event(kind,**fields):
        nonlocal previous
        ev=dict(kind=kind,elapsed_seconds=time.monotonic()-began,previous=previous,**fields)
        previous=hashlib.sha256(canonical(ev)).hexdigest();journal(E/'events.jsonl',dict(event=ev,sha256=previous))
    def bound():
        if time.monotonic()-began>=p['science_seconds']:raise StopBeforeEntry('FIXED_SCIENCE_BOUND_NO_EXTENSION')
        if sum(f.stat().st_size for f in E.rglob('*') if f.is_file())+8*1024**2>p['binary_bytes']:raise StopBeforeEntry('FIXED_BINARY_BOUND')
    cursors=read(OLD/'Saved_Transition_And_Cursor_Readiness.json')['rows']
    failure=None
    try:
        for i,meta in enumerate(cursors):
            d=E/f'case_{i:02d}';d.mkdir();episode=NativeGraphEpisode.restore(d,decode(OLD,meta['cursor']))
            assert episode.count==1 and episode.cap==136 and meta['case_id']==p['case_ids'][i]
            case=dict(case_id=meta['case_id'],status='PARTIAL',calls=[],paid_first_cursor=meta['cursor'],last_checkpoint=None);rows.append(case)
            while not episode.done:
                bound();n=episode.count
                state=episode.snapshot();saved=capsule(d/f'state_{n:03d}.zlib',dict(episode=state,costs=costs,closed_calls=case['calls'],started_utc=started,absolute_budget_seconds=p['science_seconds'],registry_sha256=p['input_hashes'][p['registry']]))
                cold=NativeGraphEpisode.restore(d,decode(d,saved)['episode']);require_same(state,cold.snapshot(),'FULL_STATE_COLD')
                intent=episode.next_intent();costs['native_policy_calls']+=1
                ci=cold.next_intent();costs['cold_policy_checks']+=1;require_same(intent,ci,'COLD_NEXT_INPUT');require_same(episode.snapshot(),cold.snapshot(),'COLD_PENDING_STATE')
                before=capsule(d/f'query_{n:03d}_before.zlib',intent['before'])
                pending=capsule(d/f'pending_{n:03d}.zlib',episode.snapshot())
                case['pending_query']=dict(number=n,action=intent['action'],decoded=intent['decoded'],before=before,pending=pending)
                returned,scope=history.lookup(intent['before'],p['solver_kwargs']);error=None;seconds=0.
                event('query_reserved',case=i,number=n,action=intent['action'],before=before,scope=scope,pending=pending)
                if returned is None:
                    bound();costs['new_PF_attempts']+=1;event('new_PF_attempt',case=i,number=n)
                    returned=decode(d,before);tick=time.perf_counter()
                    try:native(returned,**p['solver_kwargs']);assert returned.converged;costs['new_PF_returns']+=1
                    except Exception as exc:error=dict(type=type(exc).__name__,message=str(exc));costs['new_PF_exceptions']+=1
                    seconds=time.perf_counter()-tick;costs['new_PF_seconds']+=seconds
                else:costs['derived_paid_returns']+=1
                after=capsule(d/f'query_{n:03d}_after.zlib',returned)
                result=episode.accept(intent,returned,error);coldresult=cold.accept(ci,copy.deepcopy(returned),copy.deepcopy(error));assert result==coldresult
                require_same(episode.snapshot(),cold.snapshot(),'ACTUAL_COMMIT_WARM_COLD')
                post=capsule(d/f'post_{n:03d}.zlib',episode.snapshot())
                restored=NativeGraphEpisode.restore(d,decode(d,post));require_same(episode.snapshot(),restored.snapshot(),'ACTUAL_POST_COMMIT_COLD')
                record=dict(case_id=meta['case_id'],number=n,action=intent['action'],decoded=intent['decoded'],before=before,after=after,pre_state=saved,pending=pending,post_state=post,
                            kwargs=p['solver_kwargs'],scope=scope,exception=error,seconds=seconds,transition=result,strict_metrics=metrics(returned))
                path=d/f'query_{n:03d}.json';put(path,record);case['calls'].append(path.relative_to(E).as_posix());case['last_checkpoint']=post
                del case['pending_query']
                history.add(d,path,record);event('query_closed',case=i,number=n,record=path.relative_to(E).as_posix(),sha256=sha(path),transition=result)
                episode=restored;atomic_json(E/'Status.json',dict(cases=rows,costs=costs,elapsed_seconds=time.monotonic()-began))
            case.update(status='COMPLETE_NATIVE_EPISODE',endpoint=metrics(episode.env.net),action_count=episode.count,termination=result['termination'],source_success=result['source_success'])
            put(d/'Result.json',case)
    except StopBeforeEntry as exc:
        failure=dict(kind='OPERATIONAL_PARTIAL_NO_RETRY',reason=str(exc));event('operational_stop',**failure)
    except BaseException as exc:
        failure=dict(kind='ENGINEERING_OR_ANALYSIS_FAILURE',type=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc());put(E/'Failure.json',failure);raise
    finally:
        costs['binary_bytes']=sum(f.stat().st_size for f in E.rglob('*') if f.is_file())
        complete=len(rows)==4 and all(r['status']=='COMPLETE_NATIVE_EPISODE' for r in rows)
        put(E/'Result.json',dict(status='COMPLETE_ALL4_NATIVE_REQUIRE_INDEPENDENT_AUDIT' if complete else 'TERMINAL_PARTIAL',all4_complete=complete,cases=rows,costs=costs,
            failure=failure,unentered_case_ids=p['case_ids'][len(rows):],workflow_seconds=time.monotonic()-began,journal_last_sha256=previous,
            same_resource_or_LLM_superiority='NOT_ESTABLISHED',old_first_PF_never_repeated=True))
        put(E/'Frozen_Original_Checks.json',frozen());manifest(E)
    print(json.dumps(dict(all4_complete=complete,costs=costs)))
if __name__=='__main__':main()
