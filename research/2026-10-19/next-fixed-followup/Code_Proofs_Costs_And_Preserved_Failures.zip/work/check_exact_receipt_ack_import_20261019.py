"""Real source-bound ACK reuse plus adversarial identity mutations; zero PF."""
import copy,json,os,time
from pathlib import Path
import pandapower as pp
from verified_paid_cache_engine_v2_20261018 import VerifiedPaidUseRegistry
from frozen_physics_loader import load_stack
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/exact_receipt_ack_import_preparation_20261019'
OLD=R/'outputs/resumed16_with_fixed_followup_receipts_v2_20261019'

def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();paths=sorted((OLD/'verified_uses/acks').glob('*.json'));assert len(paths)==697
    p=paths[0];closed=read(OLD/'Closed_Manifest.json')['members'];assert sha(p)==closed[str(p.relative_to(OLD))]
    put(B/'Protocol.json',{'source_sha256':sha(__file__),'existing_API':'VerifiedPaidUseRegistry.import_existing_ack and unchanged _validate_ack','existing_registry_source_sha256':sha(R/'work/verified_paid_cache_engine_v1_20261018.py'),
       'input_ACK_sha256':sha(p),'input_source_closed_manifest_sha256':sha(OLD/'Closed_Manifest.json'),'tests':['one actual positive source-bound ACK import','changed point key','changed source protocol','changed checked record hash','changed native reader source hash'],
       'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'limits':'Tests source/record/point binding of existing API. A future job must pin all imported origins and retain prior verification costs; no weakened physical or decision gate.'})
    calls=[]
    def forbidden(*a,**k):calls.append(True);raise AssertionError('No new science in ACK import fixture')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,forbidden)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    registry=VerifiedPaidUseRegistry(B/'registry',runner=runner,zones=zones)
    try:
        value=read(p);key=value['point_action_key'];registry.import_existing_ack(p);assert key in registry.validated
        target=registry.path/registry.validated[key]['path'];assert read(target)==value and sha(target)==sha(p)
        mutations=[]
        for field in ['point_action_key','source_protocol_sha256','checked_record_sha256','native_source_bound_reader_sha256']:
            bad=copy.deepcopy(value);bad[field]='0'*64
            try:registry._validate_ack(key,bad)
            except AssertionError:mutations.append(field)
            else:raise AssertionError('Mutation must be rejected: '+field)
        assert len(mutations)==4 and not calls
        put(B/'Results.json',{'status':'PASS_ACTUAL_EXISTING_ACK_IMPORT_AND_FOUR_SOURCE_IDENTITY_MUTATIONS','positive':str(p.relative_to(R)),'positive_sha256':sha(p),'mutations_rejected':mutations,
           'unchanged_original_validator':True,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,'limits':'Software reuse gate only. Does not prove new physical trajectory, performance or LLM benefit. All prior CPU verification/source/PF costs remain separately paid.'})
    finally:registry.close()
    manifest(B);print(json.dumps({'ACK_import':'PASS','adverse_mutations':4,'newPF':0}))

if __name__=='__main__':main()
