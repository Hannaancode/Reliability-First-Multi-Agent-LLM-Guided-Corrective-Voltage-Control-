"""Pure causal numerical query policies. No filesystem, model or PF access.

Interpolated metrics are provisional numerical predictions, never measured
successors or a convergence certificate. The actor receives dictionaries only.
"""
import math

FIELDS = ('uv_count', 'deficit_sum', 'vmin', 'vmax')
ARMS = ('old_static', 'candidate_static', 'old_feedback', 'candidate_feedback')
VARIANTS = ('old_admittance_derivative', 'candidate_admittance_derivative')


def measured_score(receipt, q):
    if not receipt or receipt.get('accepted') is not True or receipt.get('converged') is not True:
        return None
    b, a = receipt['before'], receipt['after']
    assert a['vmax'] <= 1.05 + 1e-8
    return (int(a['uv_count'] == 0), b['uv_count'] - a['uv_count'],
            b['deficit_sum'] - a['deficit_sum'], a['vmin'] - b['vmin'], -abs(q))


def interpolate(knots, q):
    """Piecewise-linear residual, zero at Q=0; constant beyond last knot.

    No monotonic physical response or cross-bus residual transfer is assumed.
    """
    points = [(0., 0.)] + sorted(knots)
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if q <= x1:
            return y0 + (y1 - y0) * (q - x0) / (x1 - x0)
    return points[-1][1]


def choose_query(view, priors, arm, counters=None):
    assert arm in ARMS
    variant = VARIANTS[0 if arm.startswith('old_') else 1]
    grid = view['current_model_input']['original_Q_grid']
    before = view['current_model_input']['current_physical_observation']['global_metrics']
    legal = {(x['bus'], x['Q_index']) for x in view['legal_queries']}
    forecasts = {(x['bus'], x['Q_index']): x for x in priors[variant]}
    assert set(forecasts) == legal
    seen, knots = set(), {}
    for event in view['past_requested_receipts']:
        a = event['request']; pair = (a['bus'], a['Q_index']); seen.add(pair)
        response = event['response']; receipt = response.get('verifier')
        p = forecasts[pair]
        if arm.endswith('_feedback') and receipt and receipt.get('converged') is True and receipt.get('after') and p['metrics']:
            for field in FIELDS:
                value = receipt['after'].get(field)
                if type(value) in (int, float) and math.isfinite(value):
                    knots.setdefault((pair[0], field), []).append((grid[pair[1]], value - p['metrics'][field]))
    pending = legal - seen
    if not pending:
        return None

    def priority(pair):
        p = forecasts[pair]
        if counters is not None:
            counters['candidate_priority_evaluations'] += 1
        if p['metrics'] is None:
            # Unavailable/nonphysical predictions remain legal, last in native
            # order. UNKNOWN is not predicted failure or safe convergence.
            return (0, 0, 0, 0., 0., 0., -pair[0], -pair[1])
        after = dict(p['metrics'])
        for field in FIELDS:
            k = knots.get((pair[0], field))
            if k:
                after[field] += interpolate(k, grid[pair[1]])
                if counters is not None:
                    counters['interpolated_metric_estimates'] += 1
        # Explicit projections for approximate global metrics, not labels.
        after['uv_count'] = min(118, max(0, math.floor(after['uv_count'] + .5)))
        after['deficit_sum'] = max(0., after['deficit_sum'])
        after['vmax'] = max(after['vmax'], after['vmin'])
        predicted_admissible = (after['vmax'] <= 1.05 + 1e-8 and after['uv_count'] <= before['uv_count']
            and after['deficit_sum'] <= before['deficit_sum'] + 1e-9
            and (after['uv_count'] < before['uv_count'] or after['deficit_sum'] < before['deficit_sum'] - 1e-9
                 or after['vmin'] > before['vmin'] + 1e-9))
        score = (int(after['uv_count'] == 0), before['uv_count'] - after['uv_count'],
                 before['deficit_sum'] - after['deficit_sum'], after['vmin'] - before['vmin'], -grid[pair[1]])
        return (1 + int(predicted_admissible), *score, -pair[0], -pair[1])
    pair = max(pending, key=priority)
    return {'bus': pair[0], 'Q_index': pair[1]}


def choose_commit(view):
    grid = view['current_model_input']['original_Q_grid']; best = None; command = None
    for event in view['past_requested_receipts']:
        a = event['request']; score = measured_score(event['response'].get('verifier'), grid[a['Q_index']])
        key = (*score, -a['bus'], -a['Q_index']) if score is not None else None
        if key is not None and (best is None or key > best):
            best, command = key, dict(a)
    return command
