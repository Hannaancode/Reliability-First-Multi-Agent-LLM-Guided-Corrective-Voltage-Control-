"""Separate saved-only checker: literal source/AST/constants/arithmetic, no imports of science."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import ast, json, hashlib
R=Path(__file__).resolve().parents[1];O=R/'outputs/environment_contracts_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    target=O/'Source_And_Arithmetic_Check.json';assert not target.exists()
    d=json.loads((O/'Environment_Contracts.json').read_text('utf-8'))
    texts={};checks=[]
    for k,s in d['sources'].items():
        p=Path(s['path']);p=p if p.is_absolute() else R/p
        assert sha(p)==s['sha256'],k
        texts[k]=p.read_text('utf-8-sig')
    def check(label,condition):
        assert condition,label
        checks.append(label)
    def assignments(text):
        values={}
        for n in ast.walk(ast.parse(text)):
            if isinstance(n,ast.Assign):targets=n.targets;value=n.value
            elif isinstance(n,ast.AnnAssign):targets=[n.target];value=n.value
            else:continue
            try:v=ast.literal_eval(value)
            except (ValueError,TypeError):continue
            for t in targets:
                if isinstance(t,ast.Name):values[t.id]=v
        return values
    a=assignments(texts['rag_solver'])
    check('supplied_RAG_default_limits_and_guard',all(a[k]==v for k,v in {'vmin_pu':.95,'vmax_pu':1.061,'enable':True,'max_loops':12,'q_step_mvar':15.,'q_cap_mvar':150.,'target_vm_slack':1.03,'widen_gen_q':500.,'method':'dc_ac','max_iter':50}.items()))
    check('RAG_actual_request_limits_forwarded_to_guard','vmax=req.limits.vmax_pu' in texts['rag_solver'])
    check('RAG_caption_minima_and_body_disagreement',all(x in texts['rag_paper'] for x in ['0.982','0.986','0.966','0.971','0.04 p.u.','10% load shedding']))
    check('RAG14_decimal_change_is004_not04',Decimal('.986')-Decimal('.982')==Decimal(d['rag14_exact_minimum_difference'])==Decimal('.004'))
    c=assignments(texts['original_controller']);g=assignments(texts['original_guard'])
    check('original_exact_nonuniform_Qmenu',c['ALLOWED_Q']==g['Q_SWEEP']==[25,50,75,100,125,150,200,250,300])
    check('original_per_bus_named_shunt_cap',g['MAX_ABS_Q_PER_BUS']==450 and 'name.startswith("llm_shunt")' in texts['original_guard'])
    check('original_native_guard_and25budget',g['HARD_OV']==1.06 and 'runner.MAX_ITERATIONS = 25' in texts['original_controller'])
    check('initial50_and_action80_are_distinct','max_iteration=50' in texts['original_initial_solver'] and 'max_iteration=80' in texts['original_action_solver'])
    graph=json.loads(texts['graph_protocol'])
    check('Graph136_and_pinned_source',graph['source_native_total_operations']==136 and graph['source_hashes']['work/published_graph118_episode_engine_v2_20261026.py']==d['sources']['graph_engine']['sha256'])
    tree=ast.parse(texts['public13_env']);fun=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='step_Preward')
    seg=ast.get_source_segment(texts['public13_env'],fun)
    check('public13_actual_step_uses_BFSWdc',"algorithm='bfsw', init = 'dc'" in seg)
    check('public13_done_local_strict_open_band','np.min(self.state) > 0.95' in seg and 'np.max(self.state)< 1.05' in seg and 'iloc[self.injection_bus]' in seg)
    protocol=json.loads(texts['public13_protocol'])
    check('public13_all500_and_pinned_numeric',protocol['cases']==list(range(500)) and protocol['source_and_input_hashes']['work/public13_matched_numeric_engine_20261021.py']==d['sources']['public13_numeric']['sha256'])
    r=json.loads(texts['original_results']);check('original_closed_endpoint_totals',all(r['totals'][k]==v for k,v in {'DFF_UV':51,'DFF_OV':11,'HGVF_UV':26,'HGVF_OV':11,'HGSE_UV':20,'HGSE_OV':12}.items()))
    t=json.loads(texts['tpa_result']);n=json.loads(texts['numeric322_result'])
    check('322_one_step_saved_root_and_both_endpoints',t['PF'][0]['UV']==n['root']['UV']==108 and t['PF'][1]['UV']==77 and n['actual']['UV']==0 and t['PF'][1]['OV']==n['actual']['OV']==0)
    check('322_information_difference_explicit',n['our_LLM_or_benchmark_superiority_claim'] is False and 'Full current Ybus' in n['information_difference'])
    check('all_environments_have_contract_and_unknowns',len(d['environments'])==6 and all(all(k in x for k in ['plant','actions','disturbance','solver','guard','stopping','information','observed','partition','source_ids']) for x in d['environments']))
    check('RAG_source_not_mislabelled_as_historical_execution',d['rag_figure_runtime_binding']=='UNKNOWN' and all('NOT_EXECUTION_BOUND' in x['evidence_level'] for x in d['environments'][:2]))
    check('exact_menu_replaced_provisional_spacing_description','25,50,75,100,125,150,200,250,300' in d['environments'][2]['actions'])
    out={'status':'PASS_SEPARATE_SOURCE_AND_ARITHMETIC_CHECK','at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'source_files':len(d['sources']),'matrix_sha256':sha(O/'Environment_Contracts.json'),'checker_sha256':sha(Path(__file__)),'new_model_PF_derivative_solve_training_GPU_calls':0,'scope':'Hashes, source AST/constants and selected closed arithmetic only. Human-readable contract interpretation reviewed separately; no new independent physical audit, historical runtime proof or performance result.'}
    target.write_text(json.dumps(out,indent=2)+'\n','utf-8');print(json.dumps({'status':out['status'],'checks':len(checks),'new_science':0}))
if __name__=='__main__':main()
