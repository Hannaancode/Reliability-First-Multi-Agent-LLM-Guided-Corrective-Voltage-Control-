"""Ended partial study, audit ONLY actual warm prefix, never new science."""
import argparse,ast,copy,hashlib,json,os
from pathlib import Path
import audit_third_point_four_queries_20261019 as planned
from third_point_four_query_core_20261019 import B,helpers,transform
from prospective_query_custody_v3_20261019 import bind
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from equal_operation_benchmark_v2 import process
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
PREP=B/'partial_reader_preparation';OUT=B/'partial_prefix_audit'
def reader():
    guard=LockedSourceSnapshot(PREP/'Protocol.json');p=read(B/'Protocol.json');h=bind(helpers(__file__),__file__)
    try:
        text=Path(planned.original.__file__).read_text('utf-8');node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main');fn='\n'.join(text.splitlines()[node.lineno-1:node.end_lineno])
        fn=transform(fn,planned.EDITS)
        fn=transform(fn,[("out=B/'audit'","out=B/'partial_prefix_audit'"),("for phase in ('warm','cold_1','cold_2','cold_3'):","for phase in ('warm',):")])
        env=planned.original.__dict__.copy();env.update(B=B,claim=h['claim'],admit=h['admit'],input_state=h['input_state'],restore_state=h['restore_state'],verify_file=h['verify_file'])
        exec(compile(fn,__file__,'exec'),env)
        try:env['main']()
        except SystemExit as done:assert done.code==0
        audit=read(OUT/'Independent_Audit.json');assert audit['status']=='PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE' and audit['counts']['PF_attempts']==audit['counts']['PF_returns']==2
        state=h['restore_state'](read(B/'Warm_State_ACK.json'));source=h['input_state']();planned.original.require_same(state['net'],source['net']);assert state['cursor']==source['cursor'] and state['next_index']==1 and len(state['paid_query_registry'])==1
        assert len(planned.original.verify_history(state['history_anchor']))==1 and state['cumulative_costs']['PF_attempts']==2
        # Claim failed before worker try/body or reservation. All unexecuted
        # identities remain UNKNOWN, not failures or a complete four-arm gate.
        assert not any((B/'cold_1'/n).exists() for n in ('scientific.jsonl','capsules.bin','Launcher_ACK.json')) and not (B/'cold_2').exists() and not (B/'cold_3').exists()
        put(B/'Preserved_Prefix_State_Proof.json',{'status':'PASS_ACTUAL_WARM_PREFIX_NATIVE_PHYSICS_STATE_COSTS_ONLY','source_identity':p['point'],'paid_key':next(iter(state['paid_query_registry'])),'actual_primaries':1,'charged_replays':1,'PF_attempts':2,'PF_returns':2,'PF_exceptions':0,'remaining_original_menu_identities':'THREE_UNEXECUTED_UNKNOWN','cold_1_failed_before_ACK_or_any_reservation_or_scientific_body':True,'full_four_gate':'UNKNOWN_TERMINAL_PARTIAL','new_scientific_calls':0,'costs':state['cumulative_costs']})
    finally:guard.close()
def prepare():
    PREP.mkdir(exist_ok=False);assert not OUT.exists();c=read(B/'Coordinator_Claim.json');assert process(c['actual_pid']) is None and process(c['parent_pid']) is None
    for phase in ('warm','cold_1'):
        c=read(B/phase/'owner.claim');assert process(c['actual_pid']) is None and process(c['actual_parent_pid']) is None
    assert read(B/'Completion.json')['exit_codes']=={'warm':0}
    assert read(R/'outputs/prospective_query_custody_v3_20261019/Results.json')['status']=='PASS_FOUR_REAL_ZERO_SCIENCE_CUSTODY_CASES'
    put(PREP/'Protocol.json',{'status':'FROZEN_ADDITIVE_SAVED_WARM_PREFIX_ONLY','source_input_sha256':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),Path(planned.__file__),B/'Protocol.json',B/'Completion.json',B/'warm/Closed_Manifest.json',B/'warm_End_ACK.json',B/'cold_1_Admission_Failure.json',R/'work/prospective_query_custody_v3_20261019.py']},'runtime_versions':read(B/'Protocol.json')['runtime_versions'],'new_scientific_calls':0,'preserve_original_partial_source_and_failure':True})
    h=bind(helpers(__file__),__file__);code=h['launch'](Path(__file__),'reader',OUT,read(B/'Protocol.json'));put(PREP/'Completion.json',{'reader_exit':code,'scientific_calls':0});manifest(PREP);assert code==0;print('Actual warm prefix independently audited; remaining3UNKNOWN, no new science')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--reader',action='store_true');a=p.parse_args();reader() if a.reader else prepare()
