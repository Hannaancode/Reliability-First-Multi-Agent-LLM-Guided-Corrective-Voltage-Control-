"""Prepared single-recipe nonlinear proposal solver with persistent cost evidence.

No executable main, plant interface or automatic experiment launch is provided.
Prospective actual-owner, input-binding, engineering and independent-reader gates
must pass before solve_once is used on any physical state. The two optimizer
calls form one fixed lexicographic proposal; no retry or alternative solver.
"""
from pathlib import Path
import json,hashlib,os,time
import numpy as np
from nonlinear13_analytic_derivatives_20261029 import equality_jacobian,inequality_jacobian,objective_gradient

RECIPE={'method':'SLSQP','scipy_version':'1.16.3','maxiter_each_stage':100,'ftol':1e-10,
        'absolute_equality_acceptance':1e-7,'absolute_inequality_acceptance':1e-10,
        'use_analytic_jacobians':True,'retry_count':0,'second_stage_allowance':1e-10}

def serial(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)

class PersistentCalculationJournal:
    def __init__(self,path,absolute_deadline_monotonic,byte_cap):
        self.path=Path(path);self.deadline=float(absolute_deadline_monotonic);self.byte_cap=int(byte_cap)
        if not np.isfinite(self.deadline) or self.deadline<=time.monotonic() or self.byte_cap<=0:raise ValueError('Invalid original resource allowance')
        self.stream=self.path.open('x',encoding='utf-8',newline='\n');self.previous='0'*64;self.bytes=0;self.calls=0
    def event(self,kind,**data):
        if time.monotonic()>=self.deadline:raise TimeoutError('Original absolute deadline reached; no renewal')
        event=dict(seq=self.calls,kind=kind,previous=self.previous,monotonic=time.monotonic(),**data)
        raw=json.dumps(event,sort_keys=True,separators=(',',':'),default=serial,allow_nan=False)
        digest=hashlib.sha256(raw.encode()).hexdigest();line=json.dumps(dict(event=event,sha256=digest),default=serial,allow_nan=False)+'\n'
        length=len(line.encode('utf-8'))
        if self.bytes+length>self.byte_cap:raise TimeoutError('Original journal preservation bound reached; no extension')
        self.stream.write(line);self.stream.flush();os.fsync(self.stream.fileno())
        self.previous=digest;self.bytes+=length;self.calls+=1
    def close(self):self.stream.close()

def solve_once(model,journal,source_input_binding):
    import scipy
    import scipy.optimize._slsqp_py as native
    from scipy.optimize import minimize
    if scipy.__version__!=RECIPE['scipy_version']:raise ValueError('Unpinned optimizer version')
    if not source_input_binding.get('all_required_current_state_checks_passed'):
        raise ValueError('No current-state source/input admission')
    if type(model).__name__!='ValidatedNonlinearNative13':raise ValueError('Validated production kernel required')
    journal.event('proposal_attempt',recipe=RECIPE,source_input_binding=source_input_binding,initial_vector=model.initial_vector())
    native_call=native.slsqp;counters={'optimizer_attempts':0,'optimizer_returns':0,'optimizer_exceptions':0,
      'native_slsqp_calls':0,'native_slsqp_seconds':0.,'major_iteration_callbacks':0,
      'internal_QP_factorizations':'UNKNOWN_INSIDE_PINNED_NATIVE_LIBRARY_NOT_FREE',
      'internal_linear_solves':'UNKNOWN_INSIDE_PINNED_NATIVE_LIBRARY_NOT_FREE'}
    stage=0;first_t=None;attempt=0
    def observe_native(*args,**kwargs):
        journal.event('native_solver_call_attempt',stage=stage,state=dict(args[0]))
        counters['native_slsqp_calls']+=1;t0=time.perf_counter()
        try:return native_call(*args,**kwargs)
        finally:
            elapsed=time.perf_counter()-t0;counters['native_slsqp_seconds']+=elapsed
            journal.event('native_solver_call_end',stage=stage,elapsed_seconds=elapsed,state=dict(args[0]))
    def evaluated(name,f,x):
        nonlocal attempt
        identity=attempt;attempt+=1;journal.event('calculation_attempt',identity=identity,stage=stage,name=name,x=np.asarray(x))
        t0=time.perf_counter()
        try:
            result=f(x)
            if not np.isfinite(result).all():raise ValueError('Nonfinite calculation return')
        except BaseException as exc:
            journal.event('calculation_failure',identity=identity,type=type(exc).__name__,elapsed_seconds=time.perf_counter()-t0);raise
        journal.event('calculation_return',identity=identity,result=result,elapsed_seconds=time.perf_counter()-t0)
        return result
    def iteration(x):
        counters['major_iteration_callbacks']+=1;journal.event('major_iteration_return',stage=stage,x=x)
    def checks(x,first):
        eq=evaluated('returned_equality',model.equality,x)
        iq=evaluated('returned_inequalities',lambda z:model.inequalities(z,first),x)
        bounds=model.bounds();inside=all((lo is None or value>=lo) and (hi is None or value<=hi) for value,(lo,hi) in zip(x,bounds))
        result=dict(max_abs_equality=float(np.max(np.abs(eq))),min_inequality=float(np.min(iq)),inside_exact_bounds=inside)
        result['pass']=inside and result['max_abs_equality']<=RECIPE['absolute_equality_acceptance'] and result['min_inequality']>=-RECIPE['absolute_inequality_acceptance']
        return result
    results=[];native.slsqp=observe_native
    try:
        x=model.initial_vector()
        for stage in (1,2):
            counters['optimizer_attempts']+=1;journal.event('optimizer_attempt',stage=stage,x=x,first_stage_t=first_t)
            try:
                res=minimize(lambda z:evaluated('objective',lambda a:model.objective(a,stage),z),x,
                  jac=lambda z:evaluated('objective_gradient',lambda a:objective_gradient(model,a,stage),z),
                  bounds=model.bounds(),method=RECIPE['method'],
                  constraints=[{'type':'eq','fun':lambda z:evaluated('equality',model.equality,z),
                    'jac':lambda z:evaluated('equality_jacobian',lambda a:equality_jacobian(model,a),z)},
                    {'type':'ineq','fun':lambda z:evaluated('inequalities',lambda a:model.inequalities(a,first_t),z),
                    'jac':lambda z:evaluated('inequality_jacobian',lambda a:inequality_jacobian(model,a,first_t),z)}],
                  callback=iteration,options={'maxiter':RECIPE['maxiter_each_stage'],'ftol':RECIPE['ftol'],'disp':False})
            except BaseException as exc:
                counters['optimizer_exceptions']+=1;journal.event('optimizer_exception',stage=stage,type=type(exc).__name__,costs=counters);raise
            counters['optimizer_returns']+=1
            record=dict(stage=stage,x=res.x,success=bool(res.success),status=int(res.status),message=str(res.message),
              nit=int(res.nit),nfev=int(res.nfev),njev=int(res.njev),multipliers=np.asarray(res.get('multipliers',[])))
            journal.event('optimizer_raw_return',**record,costs=counters.copy())
            record['checks']=checks(res.x,first_t)
            results.append(record);journal.event('optimizer_return',**record)
            if not res.success or not record['checks']['pass']:
                return dict(status='FIXED_OPTIMIZER_FAILED_NO_RETRY_NO_CANDIDATE',stages=results,costs=counters,kernel_costs=model.costs.copy())
            x=np.asarray(res.x).copy()
            if stage==1:first_t=float(x[30])
        journal.event('representable_action_attempt',x=x)
        try:u,next_q,applied=model.representable_native_action(x)
        except BaseException as exc:
            journal.event('representable_action_failure',type=type(exc).__name__,costs=counters.copy(),kernel_costs=model.costs.copy());raise
        journal.event('representable_action_return',u=u,next_q=next_q,applied_x=applied)
        applied_checks=checks(applied,first_t);journal.event('representable_action_checks',u=u,next_q=next_q,checks=applied_checks)
        if not applied_checks['pass']:
            return dict(status='FLOAT32_PROPOSAL_REJECTED_NO_REPAIR',stages=results,costs=counters,kernel_costs=model.costs.copy())
        return dict(status='ADMITTED_UNMEASURED_PROPOSAL',u=u,next_q=next_q,proposed_vm=np.abs(model.voltage(applied))[model.lookup],
          applied_x=applied,stages=results,costs=counters,kernel_costs=model.costs.copy(),physical_guard='NOT_EVALUATED_NO_PHYSICAL_CALL')
    finally:native.slsqp=native_call
