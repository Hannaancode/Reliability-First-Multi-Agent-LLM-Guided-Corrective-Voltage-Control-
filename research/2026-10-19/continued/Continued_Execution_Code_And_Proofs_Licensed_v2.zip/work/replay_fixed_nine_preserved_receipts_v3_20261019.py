"""Zero-science saved-data analysis despite UNKNOWN final child exit.

Physical/source/native-menu/replay/state assertions passed on all eight calls.
The original complete lifecycle gate remains UNKNOWN, including after this
analysis. No physical or policy performance gate can be passed by this reader.
"""
import ast,copy,hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
import replay_paid_suffix_with_fixed_three_20261019 as three
import replay_fixed_receipts_with_next_context_20261019 as previous
import replay_unstarted_paid_suffix_numeric_v2_20261018 as original
import verified_paid_cache_engine_v2_20261018 as binding
from replay_paid_suffix_new_receipts_v3_20261018 import Overlay
from fixed_four_query_core_20261019 import B as FOUR,PHASES
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from strict_saved_native_input_match_v2_20261018 import require_same
from equal_operation_benchmark_v2 import decode_capsule
from audit_full_receding_linear_composed_v4_20261018 import check_query
from fixed_three_query_core_20261019 import transform
B=R/'outputs/fixed_nine_preserved_receipts_screen_v3_20261019'
PREP=R/'outputs/fixed_nine_preserved_receipts_screen_preparation_v3_20261019'
NUM=previous.NUM

def admissibility():
    d=read(FOUR/'audit/Independent_Audit.json');c=read(FOUR/'custody_repair/Completion.json')
    assert d['status']=='PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE' and d['failure_or_unstarted_phases']==['cold_3_EXIT_NONZERO']
    assert c['reader_exit_code']==0 and c['original_physical_evidence_checks_completed'] and c['original_overall_complete_gate']=='UNKNOWN_LAST_PROCESS_EXIT'
    assert d['counts']=={'PF_attempts':8,'PF_returns':8,'PF_exceptions':0,'new_query_PF_attempts':4,'continuous_replay_PF_attempts':4}
    assert len(d['query_outcomes'])==4 and d['original_verifier_and_native_BEFORE_inputs_checked']
    return True

node=next(n for n in ast.parse(Path(three.__file__).read_text('utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='Registry')
text=ast.unparse(node).replace('class Registry(TwoRegistry):','class Registry(three.Registry):').replace('self.more','self.four').replace('THREE','FOUR').replace('new_three','new_four').replace('NEW_THREE','NEW_FOUR').replace('len(self.four) == 3','len(self.four) == 4')
tree=ast.parse(text)
for n in ast.walk(tree):
    if isinstance(n,ast.FunctionDef) and n.name=='__init__':
        found=0
        for i,s in enumerate(n.body):
            if isinstance(s,ast.Assert) and "read(FOUR /" in ast.unparse(s) and any(x in ast.unparse(s) for x in ('Completion.json','Independent_Audit.json')):
                n.body[i]=ast.Assert(test=ast.Call(func=ast.Name(id='admissibility',ctx=ast.Load()),args=[],keywords=[]),msg=None);found+=1
        assert found==2
exec(compile(ast.fix_missing_locations(tree),__file__,'exec'),globals())

def main():
    admissibility();assert not B.exists() and not PREP.exists()
    n=next(n for n in ast.parse(Path(previous.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    function='\n'.join(Path(previous.__file__).read_text('utf-8').splitlines()[n.lineno-1:n.end_lineno])
    before="files=[Path(__file__),Path(original.__file__),R/'work/replay_paid_suffix_with_fixed_three_20261019.py',NUM/'Protocol.json',NUM/'Completion.json',NUM/'additive_menu_join_v2/Full_Native_Menu_ACK.json',NUM/'menu_join_repair_v2_preparation/Completion.json',NUM/'independent_audit/Independent_Audit.json',NUM/'actual/Closed_Manifest.json']"
    after=before+";files += [Path(three.__file__),Path(previous.__file__),FOUR/'Protocol.json',FOUR/'Completion.json',FOUR/'audit/Independent_Audit.json',FOUR/'custody_repair/Completion.json']"
    changed=transform(function,[(before,after)]);env=previous.__dict__.copy();env.update(B=B,PREP=PREP,Registry=Registry,FOUR=FOUR,three=three,previous=previous,__file__=__file__)
    exec(compile(changed,__file__,'exec'),env);env['main']()
if __name__=='__main__':main()
