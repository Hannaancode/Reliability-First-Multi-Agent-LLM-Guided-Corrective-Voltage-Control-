"""Append all closed original model-case attempts, including partials and failures.

Old index values are retained; independent reader checks only added keys.
No native PF, model, derivative or optimizer is permitted.
"""
from reflection118_remaining_cases_v2_core_20261023 import *
BASE=TOP/'closed_registry/Closed_Physical_Receipt_Registry.json'
BA=TOP/'closed_registry_independent/Independent_Audit.json'
NEW=R/'outputs/original_case_registry_20261028'


def entries():
    for index in [1,2,3]:
        host=R/'outputs/reflection118_remaining_cases_v2_execution_20261023'/f'case_{index:02d}'
        status=read(host/'status.json')
        assert status['runtime_released'] and status['scientific_process_ended'] and status['all_actual_closed_artifacts_preserved']
        audit=read(R/'outputs/reflection118_remaining_cases_v2_independent_20261023'/f'case_{index:02d}'/'Independent_Audit.json')
        assert audit['status'].startswith('PASS_')
        local=host/'local_controller';d=local/audit['case_id']/'reflection_v2'
        calls=read(d/'Call_Order.json');paths=[d/f'pf_{i:06d}.json' for i in range(len(calls['PF']))]
        paths+=sorted((local/'solver_input_identity').glob('identity_*/Receipt.json'))
        covered=set()
        for path in paths:
            row=read(path);covered.add((path.parent/row['before']['path']).resolve())
            yield dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),
                       before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=row['exception'])
        candidates=list(d.glob('pf_*_before.zlib'))+list((local/'solver_input_identity').glob('identity_*/Target_Before.zlib'))
        for path in sorted(candidates):
            if path.resolve() in covered:continue
            raw=path.read_bytes();decoded=zlib.decompress(raw)
            desc=dict(path=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),decoded_bytes=len(decoded),decoded_sha256=hashlib.sha256(decoded).hexdigest())
            yield dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),before=desc,after=None,kwargs=None,exception='UNCLOSED_ORIGINAL_CASE_ATTEMPT_UNKNOWN')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['build','audit'],required=True);mode=ap.parse_args().mode
    out=NEW/mode;out.mkdir(exist_ok=False);began=time.monotonic()
    put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)));wait_ack(out,began)
    np,pp,v2,runner,reflection=setup()
    def forbidden(*a,**k):raise RuntimeError('REGISTRY_NO_SCIENCE')
    pp.runpp=forbidden;runner.base_runner.generate_response=forbidden
    old=read(BASE);prior=read(BA);assert prior['index_sha256']==sha(BASE) and prior['total_rows']==len(old['rows'])
    anchors={str(BASE.relative_to(R)):sha(BASE),str(BA.relative_to(R)):sha(BA)}
    for i in [1,2,3]:
        for root,file in [('reflection118_remaining_cases_v2_execution_20261023','local_controller/Closed_Manifest.json'),('reflection118_remaining_cases_v2_independent_20261023','Independent_Audit.json')]:
            p=R/'outputs'/root/f'case_{i:02d}'/file;anchors[str(p.relative_to(R))]=sha(p)
    index=NEW/'build/Closed_Physical_Receipt_Registry.json'
    if mode=='build':
        from prior_physical_query_footprints_20261018 import component
        from run_reflection118_chronological_local_20261022 import necessary
        rows=list(old['rows']);seen={v['source'] for v in rows};added=0
        for row in entries():
            assert time.monotonic()-began<900
            assert row['source'] not in seen;seen.add(row['source'])
            net=saved_net(row['directory'],row['before'])
            row['resource_key']=component(net)[0]+':'+hashlib.sha256(canonical(necessary(net))).hexdigest()
            row['directory']=row['directory'].relative_to(R).as_posix();rows.append(row);added+=1
        put(index,dict(rows=rows,record_count=len(rows),old_prefix_count=len(old['rows']),new_record_count=added,anchors=anchors))
        result=dict(status='NEW_ORIGINAL_CASE_ROWS_BUILT_REQUIRE_READER',old_rows=len(old['rows']),new_rows=added)
    else:
        from build_and_audit_closed_dff_registry_20261023 import direct_key
        data=read(index);assert data['anchors']==anchors and data['rows'][:len(old['rows'])]==old['rows']
        expected=list(entries());fresh=data['rows'][len(old['rows']):]
        assert len(fresh)==len(expected)==data['new_record_count']
        for row,item in zip(fresh,expected):
            assert time.monotonic()-began<900
            item['directory']=item['directory'].relative_to(R).as_posix()
            assert {k:v for k,v in row.items() if k!='resource_key'}==item
            assert sha(R/row['source'])==row['source_sha256']
            assert direct_key(saved_net(R/row['directory'],row['before']))==row['resource_key']
        result=dict(status='PASS_ALL_ADDED_ORIGINAL_CASE_KEYS_AND_PRIOR_PREFIX',index_sha256=sha(index),old_rows=len(old['rows']),new_rows_checked=len(fresh),total_rows=len(data['rows']))
    result.update(new_PF_model_derivative_optimizer_calls=0,workflow_seconds=time.monotonic()-began)
    put(out/'Result.json',result);put(out/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in out.iterdir() if f.is_file()}))
    print(json.dumps(result))

if __name__=='__main__':main()
