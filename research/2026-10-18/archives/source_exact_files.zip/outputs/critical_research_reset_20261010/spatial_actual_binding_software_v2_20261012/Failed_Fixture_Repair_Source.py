"""Additive labelled mock attribute-protocol repair; original fault retained.

The old mock returned KeyError for copy.deepcopy's missing __deepcopy__ lookup.
Correct Python object lookup raises AttributeError. No actual physics ran, and
no actual binding/checkpoint/scientific source or assertion is changed here.
"""
import hashlib
import json
from pathlib import Path

import test_spatial_actual_commit_binding_20261012 as fixture


def mock_attribute(self, name):
    try:
        return self[name]
    except KeyError as exc:
        raise AttributeError(name) from exc


def main():
    root = Path(__file__).resolve().parents[1]
    old = root/'outputs/critical_research_reset_20261010/spatial_actual_binding_software_20261012'
    with (old/'Software_Fixture_Failure.json').open('x', encoding='utf8') as stream:
        json.dump({'status': 'FAILED_LABELLED_MOCK_ATTRIBUTE_PROTOCOL',
            'exception': 'KeyError __deepcopy__ in mock __getattr__',
            'location': 'copy.deepcopy before trial mock solver entry',
            'new_actual_PF_model_optimizer_calls': 0,
            'failed_fixture_source_preserved': 'Failed_Fixture_Source.py',
            'actual_binding_source_preserved': 'Actual_Binding_Source_At_Fixture_Failure.py',
            'original_mock_returned_root_preserved': True,
            'repair_changes_actual_binding_or_assertions': False}, stream, indent=2)
    fixture.OUT = root/'outputs/critical_research_reset_20261010/spatial_actual_binding_software_v2_20261012'
    fixture.MockNet.__getattr__ = mock_attribute
    fixture.run()
    path = fixture.OUT/'Software_Checks.json'
    result = json.loads(path.read_text('utf8'))
    result['source_sha256']['work/test_spatial_actual_commit_binding_fixture_v2_20261012.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result['prior_mock_fault_preserved'] = str(old.relative_to(root))
    result['fixture_attribute_protocol_only_changed'] = True
    temp = path.with_name('Software_Checks.complete.tmp')
    with temp.open('x', encoding='utf8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    temp.replace(path)


if __name__ == '__main__':
    main()
