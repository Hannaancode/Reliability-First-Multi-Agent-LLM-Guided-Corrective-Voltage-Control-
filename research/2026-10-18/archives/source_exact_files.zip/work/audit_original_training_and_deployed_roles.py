"""TRAIN-only label/input and saved-source review; no unpickling/model/PF."""
import ast, gzip, io, json, os, pickletools, statistics, time, zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal
from public_size_local_preservation_v2 import extended

DESKTOP=Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm')
OUT=extended(ROOT/'outputs/critical_research_reset_20261010/original_training_and_deployed_role_audit')
FIELDS=('per_device_train_batch_size','per_device_eval_batch_size','gradient_accumulation_steps','num_train_epochs',
        'max_steps','learning_rate','lr_scheduler_type','warmup_steps','optim','weight_decay','max_grad_norm',
        'fp16','bf16','gradient_checkpointing','save_steps','logging_steps','seed')


def run():
    assert not OUT.exists(); OUT.mkdir(); started=time.perf_counter()
    write(OUT/'audit.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__)),'at_utc':datetime.now(timezone.utc).isoformat()})
    inputs=ROOT/'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz'
    sources=('work/e/audit/phase2g_rescue_runner.py','work/e/audit/phase2g_multiagent_llm_runner.py','work/e/audit/phase2g_llm_guided_rescue_runner.py')
    matched=read(ROOT/'outputs/matched_campaign_protocol.json')
    for name,expected in matched['source_sha256'].items(): assert sha(ROOT/name)==expected,name
    write(OUT/'Prospective_ReadOnly_Scope.json',{'at_utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':{n:sha(ROOT/n) for n in sources},'reader_sha256':sha(Path(__file__)),'current_input_sha256':sha(inputs),
        'all16000_original_TRAIN_rows_no_outcome_selection':True,'val_test_only_group_counts_not_new_target_metrics':True,
        'all239_OPT_current_inputs_no_held_metric':True,'purpose':'Source/input/target alignment; no causal explanation or model performance proof',
        'pickle_policy':'Read opcode literals only; never unpickle, torch.load or execute globals/reducers',
        'no_NEW_model_PF_optimizer_controller_forecast_solve_cloud_calls':True})
    name='zone_agent_shared_lora_qwen05b_ultra_v1.zip'; member='content/hiergrid_phase2/models/zone_agent_shared_lora_qwen05b_ultra_v1/checkpoint-2000/training_args.bin'
    with zipfile.ZipFile(DESKTOP/name) as z: raw=z.read(member)
    import hashlib
    binary_sha=hashlib.sha256(raw).hexdigest()
    with zipfile.ZipFile(io.BytesIO(raw)) as z: pickled=z.read(next(n for n in z.namelist() if n.endswith('/data.pkl')))
    ops=list(pickletools.genops(pickled)); settings={}; opcode_evidence={}
    literals={'BININT','BININT1','BININT2','BINFLOAT','BINUNICODE','SHORT_BINUNICODE','UNICODE','INT','FLOAT','NONE','NEWTRUE','NEWFALSE'}
    for i,(op,arg,pos) in enumerate(ops):
        if isinstance(arg,str) and arg in FIELDS:
            assert arg not in settings
            following=[]
            for o,a,p in ops[i+1:]:
                if o.name in ('BINPUT','LONG_BINPUT','MEMOIZE'): continue
                following.append({'opcode':o.name,'argument':a,'offset':p})
                if o.name in literals:
                    settings[arg]=True if o.name=='NEWTRUE' else False if o.name=='NEWFALSE' else a
                    break
                assert o.name=='GLOBAL', 'Do not infer a value through a reducer/memo alias'
            opcode_evidence[arg]={'key_offset':pos,'literal_path':following}
    assert set(settings)==set(FIELDS)
    write(OUT/'Saved_SFT_Settings_From_Pickle_Literals.json',{'archive':str(DESKTOP/name),'member':member,'member_sha256':binary_sha,
        'settings':settings,'opcode_evidence':opcode_evidence,'pickle_executed':False,
        'not_recovered':['training preprocessing source','maximum training sequence length','loss masking/collator','original base-model snapshot hash'],
        'same_settings_not_complete_reproduction_certificate':True})
    prefix='hiergrid_phase2/zone_training_data/augmented/grouped_splits/'
    with zipfile.ZipFile(DESKTOP/'phase2b_training_inputs.zip') as z:
        train_raw=z.read(prefix+'zone_agent_train.jsonl'); splits=json.loads(z.read(prefix+'scenario_split_map.json'))
    assert len(splits['train_ids'])==109 and len(splits['val_ids'])==13 and len(splits['test_ids'])==15
    assert not(set(splits['train_ids'])&set(splits['val_ids']) or set(splits['train_ids'])&set(splits['test_ids']) or set(splits['val_ids'])&set(splits['test_ids']))
    counts=Counter(); top_fields=Counter(); local_fields=Counter(); output_fields=Counter(); verdicts=Counter(); lengths=[]; scenarios=set()
    for line in train_raw.decode('utf8').splitlines():
        r=json.loads(line); counts['TRAIN_rows']+=1
        user=next(m['content'] for m in r['messages'] if m['role']=='user'); output=next(m['content'] for m in r['messages'] if m['role']=='assistant')
        lengths.append(len(output)); u=json.loads(user); y=json.loads(output)
        assert u['scenario_id'] in splits['train_ids']; scenarios.add(u['scenario_id'])
        top_fields.update(u.keys()); local=u['local_measurements']; local_fields.update(local.keys()); output_fields.update(y.keys())
        verdicts[str(y.get('verification',{}).get('verdict','UNKNOWN_missing'))]+=1
        counts['TRAIN_input_contains_scenario_id']+=int('scenario_id' in u)
        counts['TRAIN_nonnull_proposed_action']+=int(y.get('proposed_action') is not None)
        counts['TRAIN_nonnull_candidate_for_coordinator']+=int(y.get('candidate_action_for_coordinator') is not None)
        vv=list(local['bus_voltages'].values()); uv=sum(v<.95 for v in vv)
        if uv==0:
            counts['TRAIN_no_local_UV']+=1
            counts['TRAIN_no_local_UV_and_null_proposed_action']+=int(y.get('proposed_action') is None)
        if min(vv)>=.95 and max(vv)<=1.05+1e-8:
            counts['TRAIN_locally_normal_with_common_tolerance']+=1
            counts['TRAIN_locally_normal_and_null_proposed_action']+=int(y.get('proposed_action') is None)
    assert counts['TRAIN_rows']==16000 and len(scenarios)==109
    # Counter.update(mapping) would sum numeric values; field support is about
    # names only. All count inputs above are parsed schemas, never model results.
    write(OUT/'All_Original_TRAIN_Input_and_Target_Metadata.json',{'train_member_sha256':hashlib.sha256(train_raw).hexdigest(),
        'counts':dict(counts),'top_input_fields':sorted(top_fields),'local_measurement_fields':sorted(local_fields),'target_fields':sorted(output_fields),
        'TRAIN_target_verdict_counts':dict(verdicts),'target_characters':{'min':min(lengths),'median':statistics.median(lengths),'max':max(lengths)},
        'scenario_groups':{k:len(v) for k,v in splits.items()},'new_val_test_label_metrics':False,'all_original_rows_retained':True,
        'IDs_present_not_proof_model_used_them_or_causal_leakage':True})
    current=Counter()
    with gzip.open(inputs,'rt',encoding='utf8') as f:
        for line in f:
            r=json.loads(line)
            if r['split']!='optimization':continue
            current['OPT_inputs']+=1; obs=r['model_input']['current_physical_observation']; frame=obs['physical_tables']['res_bus']
            vm_column=frame['columns'].index('vm_pu'); vm={b:values[vm_column] for b,values in zip(frame['index'],frame['values'])}
            global_uv=obs['global_metrics']['uv_count']>0
            for zone,buses in obs['zone_buses'].items():
                current['OPT_zone_views']+=1; vv=[vm[b] for b in buses]
                if global_uv and all(v>=.95 for v in vv):current['global_UV_with_no_local_UV_zone']+=1
                if global_uv and min(vv)>=.95 and max(vv)<=1.05+1e-8:current['global_UV_with_locally_normal_zone']+=1
    assert current['OPT_inputs']==239 and current['OPT_zone_views']==956
    write(OUT/'Current_OPT_Role_Context_Metadata.json',{'counts':dict(current),'not_actual_LLM_prompts_or_performance':True,
        'interpretation':'Such source contexts can request a proposal from locally normal zones while original local training often teaches abstention. Global coordination instruction changes do not establish a causal failure mechanism.'})
    source=ROOT/sources[2]; tree=ast.parse(source.read_text(encoding='utf8')); node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_mandatory_llm_prompt')
    env={'json':json}; exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),env)
    fixture={'zone':'MG1','min_voltage_pu':.96,'max_voltage_pu':1.02,'n_undervoltage':0,'n_overvoltage':0,'worst_bus':14,'undervoltage_buses':{},'lowest_voltage_buses':{'14':.96}}
    prompt=env['build_mandatory_llm_prompt'](fixture,{'40':.90},[14],[])
    assert 'MUST propose' in prompt[1]['content'] and 'Do NOT return null' in prompt[1]['content']
    write(OUT/'Labelled_Source_Role_Witness.json',{'kind':'Labelled SOFTWARE source fixture, not invented grid outcome','fixture':fixture,'global_UV_fixture':{'40':.90},
        'source_exact_prompt':prompt,'pure_original_function_only':True,'new_model_PF_calls':0})
    proof={'all_checked_original_TRAIN_rows_and_current_OPT_inputs_passed':True,'TRAIN_rows':16000,'OPT_inputs':239,
        'saved_training_settings_recovered_without_pickle_execution':True,'role_shift_present_in_sources_not_causally_isolated':True,
        'no_held_performance_or_new_scientific_calls':True,'workflow_seconds_before_seal':time.perf_counter()-started}
    write(OUT/'ReadOnly_Alignment_Audit.json',proof)
    files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='audit.claim'}; files['sources/reader.py']=Path(__file__)
    print(json.dumps({'proof':proof,'TRAIN_counts':dict(counts),'current_context_counts':dict(current),'settings':settings,'archive':seal(OUT,files,'Source_Alignment.zip')}))

if __name__=='__main__':run()
