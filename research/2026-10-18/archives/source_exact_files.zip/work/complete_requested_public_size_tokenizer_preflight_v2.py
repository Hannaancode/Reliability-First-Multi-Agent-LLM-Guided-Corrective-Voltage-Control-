"""Complete saved-input tokenizer gate in existing ML env; no repeated downloads."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',CUDA_VISIBLE_DEVICES='')
import ctypes,hashlib,json,sys,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'work'))
from candidate_process_evidence_utils import read,sha,write,seal
R=ROOT/'outputs/critical_research_reset_20261010'
OLD=R/'requested_public_size_screen_input_preflight'
OUT=R/'requested_public_size_screen_input_preflight_completion_v2'
assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
protocol=read(OLD/'Prospective_Public_Size_Screen_Input_Protocol.json')
payloads=read(OLD/'All31_Outcome_Independent_Paired_Inputs.json')
assert len(payloads)==31 and len({p['world_sha256'] for p in payloads})==31
write(OUT/'Additive_Tokenizer_Environment_Completion.json',{
 'declared_at_utc':datetime.now(timezone.utc).isoformat(),
 'original_protocol_sha256':sha(OLD/'Prospective_Public_Size_Screen_Input_Protocol.json'),
 'original_selected_payload_sha256':sha(OLD/'All31_Outcome_Independent_Paired_Inputs.json'),
 'original_source_sha256':sha(ROOT/'work/prepare_requested_public_model_size_screen_20261010.py'),
 'original_terminal_control_failure':'physics_env has no transformers; import failed after public tokenizer download and input selection, before tokenization/model calls',
 'use_existing_vcsa_module_env_without_new_package_install':True,
 'same_selected_cases_and_messages_context8192_reserve384_no_source_setting_or_outcome_change':True,
 'no_repeat_download_or_model_PF_training_cloud_calls':True,
 'original_source_folder_and_partial_files_preserved':True,
})
dll=Path('C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
guard=os.add_dll_directory(str(dll));runtime=ctypes.WinDLL(str(dll/'msvcp140.dll'))
from transformers import AutoTokenizer
import transformers
records=[];files={}
for short in ['public_0_5B','public_1_5B']:
 cache=OLD/'public_tokenizers'/short
 for name in ['config.json','tokenizer_config.json','tokenizer.json','vocab.json','merges.txt']:
  assert (cache/name).is_file();files[f'public_tokenizers/{short}/{name}']=cache/name
 tokenizer=AutoTokenizer.from_pretrained(str(cache),local_files_only=True,trust_remote_code=False)
 for p in payloads:
  assert hashlib.sha256(json.dumps(p['messages'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==p['message_sha256']
  ids=tokenizer.apply_chat_template(p['messages'],tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False)
  records.append({'model':short,'observation_id':p['observation_id'],'message_sha256':p['message_sha256'],'tokens':len(ids),
    'fits8192_with384reserve':len(ids)+384<=8192,'token_ids_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()})
small={r['observation_id']:(r['tokens'],r['token_ids_sha256']) for r in records if r['model']=='public_0_5B'}
same=all(small[r['observation_id']]==(r['tokens'],r['token_ids_sha256']) for r in records if r['model']=='public_1_5B')
summary={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'selected_worlds':31,'actual_public_tokenizer_cases':62,
 'context_tokens_min':min(r['tokens'] for r in records),'context_tokens_max':max(r['tokens'] for r in records),
 'all62_fit8192_with384reserve':all(r['fits8192_with384reserve'] for r in records),
 'all31_public_model_token_ids_identical':same,'local_transformers_version':transformers.__version__,
 'original_case_input_prompt_selection_and_failed_provenance_preserved':True,
 'targets_or_held_metrics_read':False,'no_original_private_weight_or_setting_change':True,
 'actual_model_forward_generation_optimizer_PF_cloud_calls':0,
 'real_1_5B_T4_memory_speed_performance_UNKNOWN':True,
 'production_driver_collector_external_reader_not_yet_sealed':True,
 'eligible_for_production_implementation_only':same and all(r['fits8192_with384reserve'] for r in records),
 'no_learning_superiority_or99percent_success_claim':True,'seconds_before_seal':time.perf_counter()-started}
write(OUT/'All62_Actual_Public_Tokenizer_Context_Records.json',records)
write(OUT/'Actual_Paired_Input_Readiness.json',summary)
(OUT/'Paired_Model_Size_Preflight_Decision.md').write_text('The requested paired publicQwen2.5-0.5B/1.5B screen has one minimum-observationSHA view from each of31 finite historical worlds, frozen before target/model access. Both arms receive the same partial current physical view and single-action prompt. All original invalid denominators remain separately saved.\n\n'+json.dumps(summary,indent=2)+'\n\nThis uses an explicitly new common8192context/reserve384 research contract, not an edit to the frozen private4096 baseline or a relabelling of the old projection failure. Public tokenizer/config files were reused from the original import-failed preparer; no download or scientific call was repeated. Real memory/load/cold-result/source/owner/collector/external-reader gates still precede actual inference. Fit is not sufficient input, learned value, a clean causal parameter-only intervention, independent confirmation or D-SE superiority. Public model pretraining/post-training recipe differences remain possible confounders. The private0.5B adapter cannot be transplanted; any eventual1.5B training needs its own justified adapter/protocol. No automatic training or newPF follows this preparation.\n',encoding='utf-8')
for p in OUT.iterdir():
 if p.is_file():files[p.name]=p
files['original/Prospective_Input_Protocol.json']=OLD/'Prospective_Public_Size_Screen_Input_Protocol.json'
files['original/All31_Paired_Inputs.json']=OLD/'All31_Outcome_Independent_Paired_Inputs.json'
files['original/Invalid_and_All_World_Denominators.json']=OLD/'Original_Invalid_and_All_World_Denominators.json'
files['sources/original_import_failed_preparer.py']=ROOT/'work/prepare_requested_public_model_size_screen_20261010.py'
files['sources/completion_verifier.py']=Path(__file__)
files['sources/current_view.py']=ROOT/'work/causal_voltage_reactive_language_projection.py'
archive=seal(OUT,files,'Paired_Public_Model_Size_Input_Gate.zip')
print(json.dumps({'summary':summary,'archive':archive}))
