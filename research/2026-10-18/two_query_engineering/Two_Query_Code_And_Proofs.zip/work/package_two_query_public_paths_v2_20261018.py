"""Additive publication-only path canonicalization; original failed ZIP retained."""
import hashlib,json,zipfile
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
B=R/'outputs/exact_two_paid_query_engineering_20261018'
def main():
    old=B/'publication';out=B/'publication_paths_v2';out.mkdir(exist_ok=False);prior=read(old/'Manifest.json');files={};aliases=[]
    for name,m in prior['files'].items():
        canonical=name.replace('\\','/');p=R/name;assert p.stat().st_size==m['bytes'] and sha(p)==m['sha256'],name
        if canonical in files:
            assert files[canonical].read_bytes()==p.read_bytes();aliases.append({'old_alias':name,'canonical':canonical})
        else:files[canonical]=p
    extra=Path(__file__);files[str(extra.relative_to(R)).replace('\\','/')]=extra
    failure={'status':'ORIGINAL_PUBLIC_PACK_FAILED_DUPLICATE_MEMBER_ASSERTION_RETAINED','archive':str((old/'Two_Query_Code_And_Proofs.zip').relative_to(R)),
        'bytes':(old/'Two_Query_Code_And_Proofs.zip').stat().st_size,'sha256':sha(old/'Two_Query_Code_And_Proofs.zip'),'equivalent_path_aliases':aliases,
        'repair':'Canonical slash names, identical bytes asserted before deduplication; no science/result/source/protocol changes.'}
    put(out/'Original_Packaging_Failure.json',failure);files['publication/Original_Packaging_Failure.json']=out/'Original_Packaging_Failure.json'
    for name,p in files.items():assert not SECRET_NAME.search(p.name) and not any(s.search(p.read_text('utf-8')) for s in SECRET),name
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
    put(out/'Manifest.json',{'status':'PUBLIC_CODE_PROOFS_CANONICAL_PATHS_NO_DUPLICATES','files':desc,'local_binary_evidence':prior['local_binary_evidence'],'local_complete_archive':prior['local_complete_archive'],
        'source_publication_failure_retained':failure,'no_full_raw_backup_or_model_export_claim':True,'all6finalgoalsopen':True})
    dest=out/'Two_Query_Code_And_Proofs.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in files.items():z.write(p,n)
        z.write(out/'Manifest.json','Manifest.json')
    with zipfile.ZipFile(dest) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(files)+1 and z.testzip() is None
        for n,m in desc.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
    put(out/'Package_Audit.json',{'status':'PASS_ALL_UNIQUE_MEMBERS_CRC_EVERY_HASH_SECRET_SCREEN','members':len(files)+1,'bytes':dest.stat().st_size,'sha256':sha(dest),'no_new_science':True})
    print(json.dumps({'public_pack':'PASS','members':len(files)+1,'bytes':dest.stat().st_size,'sha256':sha(dest)}))
if __name__=='__main__':main()
