"""Independent completed engineering reader: zero new solver/model calls."""
import copy,hashlib,json,math,os,pickle,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack,AUDIT
from native_continuation_preservation_v2 import canonical,extended_local_path
from native_postcommit_preservation import measured_bus_fields,check_commit
from trusted_causal_controller_snapshot import SOLVER_ROLES,cap_totals
from paid_spatial_two_step_search import value
from candidate_process_evidence_utils import frozen_checks,seal
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/spatial_native_engineering_20261012'
EX=extended_local_path(BASE/'execution');OUT=BASE/'independent_audit'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    assert not OUT.exists(),'No duplicate reader';OUT.mkdir();begun=time.perf_counter()
    write(OUT/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'command':sys.argv,'source_sha256':sha(Path(__file__))})
    protocol=read(BASE/'preparation/Protocol.json');ph=sha(BASE/'preparation/Protocol.json');owner=read(EX/'owner.claim');state=read(EX/'status.json')
    assert state['exit_code']==0 and read(EX/'Closed_Manifest.json')['exit_code']==0
    for pid in (owner['actual_pid'],owner['actual_parent_pid']):
        r=subprocess.run(['powershell','-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | Select-Object -ExpandProperty CommandLine"],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
        assert r.returncode==0 and not r.stdout.strip(),('Actual owner or launcher still exists/reused',pid)
    assert owner['protocol_sha256']==ph
    for p,h in protocol['source_sha256'].items():assert sha(ROOT/p)==h,p
    manifest=read(EX/'Closed_Manifest.json')['members']
    for n,v in manifest.items():assert (EX/n).stat().st_size==v['bytes'] and sha(EX/n)==v['sha256'],n
    result=read(EX/'Actual_Engineering_Result.json');assert result['engineering_gate_passed'] and not result['full_native_episode_or_policy_performance']
    chain=[json.loads(s) for s in (EX/'events.jsonl').read_text('utf8').splitlines()];previous=ph
    for i,v in enumerate(chain):
        row=v['row'];assert row['sequence']==i and row['previous_sha256']==previous
        assert hashlib.sha256(canonical(row)).hexdigest()==v['sha256'];previous=v['sha256']
    rows=[r['row'] for r in chain]
    capsules={r['payload']['payload']:r['payload'] for r in rows if r['event']=='owned_state_capsule'}
    def load_direct(name):
        meta=capsules[name+'.pkl'];data=(EX/meta['payload']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==meta['payload_sha256'] and sha(EX/meta['manifest'])==meta['manifest_sha256']
        return pickle.loads(data)
    handles={r['payload']['handle']:r['payload'] for r in rows if r['event']=='owned_uncommitted_state_preserved'}
    def load_handle(h):
        assert h in handles;data=(EX/'states'/h/'trusted_local_state.pkl').read_bytes()
        assert hashlib.sha256(data).hexdigest()==h and len(data)==handles[h]['bytes']
        return pickle.loads(data)
    solver_entries=[]
    original={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph')}
    def refuse(*a,**k):solver_entries.append(True);raise AssertionError('Independent reader cannot solve')
    for n in original:setattr(pp,n,refuse)
    try:
        v2,runner,_=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
        metadata=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json';network=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'
        assert sha(metadata)==protocol['metadata_sha256'] and sha(network)==protocol['network_sha256']
        scenario=read(BASE/'preparation/Scenario.json');assert sha(BASE/'preparation/Scenario.json')==protocol['scenario_sha256']
        raw=(EX/'Before_Initial_Input.pkl').read_bytes();assert hashlib.sha256(raw).hexdigest()==read(EX/'Before_Initial_Input_Anchor.json')['sha256']
        actual=pickle.loads(raw);expected=v2.v0.apply_scenario_to_net(pp.from_json(str(network)),scenario,read(metadata)['zones'])
        input_frames=[k for k,v in actual.items() if isinstance(v,pd.DataFrame) and not k.startswith('res_')]
        for k in input_frames:pd.testing.assert_frame_equal(actual[k],expected[k],check_exact=True,check_dtype=True,check_index_type=True,check_column_type=True)
        zones=read(metadata)['zones'];menus={}
        for r in rows:
            if r['event']!='complete_declared_native_menu':continue
            payload=r['payload'];net=load_handle(payload['parent'])['net']
            reports={z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
            buses=runner.rescue.candidate_buses_from_state(net,zones,reports,[])
            expected_actions=[runner.rescue.make_action(b,q) for b in buses for q in runner.rescue.Q_SWEEP]
            assert payload['actions']==expected_actions
            menus[payload['parent']]=[runner.action_signature(a) for a in expected_actions]
        receipts={}
        for r in rows:
            if r['event']!='query_receipt_return':continue
            p=r['payload'];key=(p['parent'],p['action_id']);assert key not in receipts and p['action_id'] in menus[p['parent']]
            parent=load_handle(p['parent'])['net'];ver=p['verification'];before=runner.rescue.grid_metrics(parent)
            assert ver['before']==before
            cap=sum(runner.rescue.llm_q_abs_at_bus(parent,int(b))+abs(q)>450 for b,q in p['action']['add_shunts_q_mvar'].items())
            if p['solver_handles']:
                assert len(p['solver_handles'])==1 and not p['failed']
                child=load_handle(p['solver_handles'][0])['net'];after=runner.rescue.grid_metrics(child)
                assert ver['after']==after
                assert set(child.res_bus.index)==set(parent.res_bus.index)
                expected_accepted=(after['vmax']<=1.05+1e-8 and after['uv_count']<=before['uv_count'] and after['deficit_sum']<=before['deficit_sum']+1e-9
                    and (after['uv_count']<before['uv_count'] or after['deficit_sum']<before['deficit_sum']-1e-9 or after['vmin']>before['vmin']+1e-9))
                assert ver['accepted']==expected_accepted and not cap
                if ver['accepted']:assert p['original_score']==list(runner.rescue.score_candidate({'action':p['action'],'verif':ver}))
            elif not p['failed']:
                assert cap and not ver['accepted'] and ver['reason']=='q_cap_exceeded'
            else:assert not ver['accepted'] and ver['converged'] is False
            receipts[key]=p
        proposal=result['proposal'];root=result['root_parent'];accepted=[receipts[(root,a)] for a in menus[root] if receipts[(root,a)]['verification']['accepted']]
        ordered=sorted(accepted,key=lambda c:c['original_score'],reverse=True)[:2]
        leaves=[]
        for first in ordered:
            h=first['solver_handles'][0];metrics=first['verification']['after'];second=None
            if metrics['uv_count']:
                children=[receipts[(h,a)] for a in menus[h] if receipts[(h,a)]['verification']['accepted']]
                if children:
                    child=max(children,key=lambda c:value(c['verification']['after']))
                    if value(child['verification']['after'])>value(metrics):metrics=child['verification']['after'];second=child['action_id']
            leaves.append({'first':first['action_id'],'second':second,'measured_leaf':metrics,'first_successor':h})
        assert leaves==proposal['leaves'];selected=max(leaves,key=lambda l:value(l['measured_leaf']))
        assert proposal['first']==selected['first'] and proposal['second']==selected['second'] and proposal['measured_leaf']==selected['measured_leaf']
        initial=load_direct('Initial')['net'];commit=load_direct('Committed_First')['net'];trial=load_handle(selected['first_successor'])['net']
        admission=check_commit(measured_bus_fields(trial),measured_bus_fields(commit),runner.rescue.grid_metrics(initial),cap_totals(commit))
        assert admission==result['first_commit_admission']
        follow=result['warm_cold_following'];w=receipts[(follow['warm_parent'],follow['action_id'])];c=receipts[(follow['cold_parent'],follow['action_id'])]
        assert follow['action_id']==menus[follow['warm_parent']][0] and menus[follow['warm_parent']]==menus[follow['cold_parent']]
        wn=load_handle(w['solver_handles'][0])['net'];cn=load_handle(c['solver_handles'][0])['net'];wf=measured_bus_fields(wn);cf=measured_bus_fields(cn)
        delta=max(abs(wf[b][f]-cf[b][f]) for b in wf for f in wf[b]);assert delta<=1e-10 and delta==follow['maximum_field_delta']
        assert sorted(b for b,v in wf.items() if v['vm_pu']<.95)==sorted(b for b,v in cf.items() if v['vm_pu']<.95)
        assert w['verification']['accepted']==c['verification']['accepted'] and w['original_score']==c['original_score']
        entries=[r for r in rows if r['event']=='PF_intent'];returns=[r for r in rows if r['event']=='PF_return'];exceptions=[r for r in rows if r['event']=='PF_exception']
        assert len(entries)==result['query_costs']['PF_attempts']==len(returns)+len(exceptions)
        assert len(returns)==result['query_costs']['PF_returns'] and len(exceptions)==result['query_costs']['PF_exceptions']
        assert all(r['payload']['kwargs']==SOLVER_ROLES['trial'] for r in entries)
        assert abs(sum(r['payload']['solver_seconds'] for r in returns+exceptions)-result['query_costs']['pure_solver_seconds'])<=1e-8
        direct=[r for r in rows if r['event']=='direct_PF_intent'];assert [(r['payload']['role'],r['payload']['kwargs']) for r in direct]==[('initial',SOLVER_ROLES['initial']),('commit',SOLVER_ROLES['commit'])]
        assert result['direct_costs']['initial_attempts']==result['direct_costs']['initial_returns']==1
        assert result['direct_costs']['commit_attempts']==result['direct_costs']['commit_returns']==1
        assert not solver_entries
    finally:
        for n,f in original.items():setattr(pp,n,f)
    write(OUT/'Fresh_Frozen_Checks.json',frozen_checks())
    certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'actual_owner_and_launcher_ended':True,
                 'root_input_frames_exact':len(input_frames),'native_menus_order_scope_Q_scores_exact':True,'actual_depth2_fixed_width2_proposal_verified':True,
                 'first_actual_commit_full_fields_UV_caps_guard_verified':True,'cold_following_actual_execution_reproducible':True,
                 'maximum_cold_following_field_delta':delta,'actual_new_PF':len(entries)+len(direct),
                 'actual_PF_exceptions':len(exceptions),'all_return_failure_costs_preserved':True,
                 'actual_new_model_optimizer_cloud_calls':0,'reader_new_PF_model_calls':0,'audit_seconds':time.perf_counter()-begun,
                 'science_workflow_seconds':state['workflow_seconds_including_worker_setup'],
                 'costs':{'direct':result['direct_costs'],'queries':result['query_costs']},
                 'limitations':['One new development engineering root; not full protected terminal policy performance.','No independent rebuilt full-trajectory physical replay.','GLOBAL numerical coordinator, not LOCAL language actor certification.','No LLM contribution, novelty or calibrated90percent winning probability.']}
    write(OUT/'Independent_Engineering_Audit.json',certificate)
    # Retain real closed scientific members and this new audit in one local ZIP.
    files={'execution/'+n:EX/n for n in manifest};files['execution/Closed_Manifest.json']=EX/'Closed_Manifest.json'
    for n in ('owner.claim','Fresh_Frozen_Checks.json','Independent_Engineering_Audit.json'):files['audit/'+n]=OUT/n
    for n in ('Protocol.json','Scenario.json'):files['preparation/'+n]=BASE/'preparation'/n
    seal(OUT,files,'Actual_Spatial_Engineering_Evidence.zip')
    print(json.dumps({'independent_engineering_audit':'PASS','actual_new_PF':certificate['actual_new_PF'],'cold_field_delta':delta,'full_policy_performance':False}))
if __name__=='__main__':main()
