# Primary improvement ceiling on the retained development worlds

The original literal D-SE already ends with **zero undervoltage buses in 24 of all 31 training worlds**. Seven worlds retain undervoltage. The separately labelled common-guard reference also has 24 zero and seven positive worlds. No world was removed, and no new physics or model ran.

For a saved baseline count b and any admissible new terminal count u, u is a nonnegative integer. Thus b-u <= b. When b=0, a strict undervoltage-count win is impossible. Consequently the maximum possible strict-win fraction on this complete retained set is **7/31 = 22.58%**, even for an ideal method. This is an upper bound on possible world wins, **not** an estimated probability that an LLM succeeds. It says nothing about improvement on other distributions.

The original D-SE's optimistic mean UV reduction ceiling is 54/31 = 1.74193548 buses per world; the guarded reference's is 46/31 = 1.48387097. These assume every remaining undervoltage could be removed and ignore action/protection/path feasibility. They are therefore optimistic ceilings, not reachable rewards, forecasts, measured improvements or statistical confidence intervals. The guard remains a separate control; its differences are not LLM benefit.

The analysis reused the saved selected branches from the closed, previously verified portfolios and retained the literal selector's zero/missing behavior. It did not reselect or repair that selector. All 62 portfolio files matched their existing member identities. A separate scalar reader checked identity joins, integer domains, denominators and arithmetic after the producer ended. This is not a new independent physical replay or LLM performance audit.

Original full BOTH-branch controller costs retained in the 31 portfolios total 50,221 PF attempts, 50,160 returns and 61 exceptions, with 3298.1252702998463 recorded wall seconds. Guarded full BOTH costs total 49,785 attempts, 49,713 returns and 72 exceptions, with 3434.7124410324304 seconds. These include previously reused searches and are not the same as new-only collection counters. Collection/preparation/replay/failure costs stay separate; nothing is treated as free. Original branch results remain individually preserved in their existing collection.

## What changes next

Stop treating higher one-step accuracy as sufficient evidence that terminal UV will improve. A new terminal method must demonstrate a genuine safe continuation opportunity and beat strong numerical planning on all declared worlds, including the 24 primary ties. Selecting only the seven residual worlds would change the evaluation and cannot establish whole-set superiority. This ceiling does not reopen any stopped method, certify new targets, or authorize automatic training.

The next mechanism to specify is protected action-sequence allocation under the original action grammar, cap and irreversible commitments. It must pass a physical opportunity screen before learning, rather than retrain an immediate winner or move the old binary selector to a chosen depth. The current data contain no directly paired later continuations; the snapshot helper passed only a labelled unsolved software fixture. Actual native solved-state integration and genuinely unexecuted counterfactual identities remain prerequisites.

The main objective—validated incremental LLM advantage over original D-SE—remains unachieved. Secondary voltage, fewer actions, or economic gains may be separate outcomes but must not be silently substituted for the requested primary comparison. No 90% winning confidence follows from these results.
