"""All36 prospectively selected PFDelta inputs: native equations, no solver.

PF equation consistency and operating-limit satisfaction are separate outputs.
Source IDs, statuses, radians and per-unit values are preserved; no row filtering.
"""
import hashlib,json,math,os,sys,time
from pathlib import Path
import numpy as np
from public118_slsqp_native_20261018 import R,read,put,sha,manifest,now
BASE=R/'outputs/pfdelta_declared_118_test_cohort_20261019'
B=R/'outputs/pfdelta_fixed36_native_validation_20261019'
TOL=5e-6

def extract(d):
    n=d['network'];meta=d['solution'];s=meta['solution']
    assert n['per_unit'] is True and s['per_unit'] is True
    assert float(n['baseMVA'])==float(s['baseMVA'])>0
    assert not n.get('dcline') and not n.get('storage') and not n.get('switch'),'Unsupported non-AC components remain UNKNOWN'
    ids=sorted(n['bus'],key=int);assert len(ids)==118 and set(s['bus'])==set(ids)
    ix={int(k):i for i,k in enumerate(ids)}
    assert all(int(n['bus'][k]['bus_i'])==int(k) for k in ids)
    vm=np.array([s['bus'][k]['vm'] for k in ids],float);va=np.array([s['bus'][k]['va'] for k in ids],float)
    assert np.isfinite(vm).all() and np.isfinite(va).all() and (vm>0).all()
    bids=sorted(n['branch'],key=int);active=[k for k in bids if n['branch'][k]['br_status']==1]
    assert all(n['branch'][k]['br_status'] in (0,1) for k in bids)
    assert set(active)<=set(s['branch'])
    f=np.array([ix[int(n['branch'][k]['f_bus'])] for k in active]);t=np.array([ix[int(n['branch'][k]['t_bus'])] for k in active])
    a=lambda key:np.array([n['branch'][k][key] for k in active],float)
    r=a('br_r');x=a('br_x');tap=a('tap');shift=a('shift');assert (r*r+x*x>0).all() and (tap>0).all()
    assert all(np.isfinite(a(v)).all() for v in ('br_r','br_x','tap','shift','g_fr','g_to','b_fr','b_to','angmin','angmax','rate_a'))
    saved=np.array([[s['branch'][k][v] for v in ('pf','qf','pt','qt')] for k in active],float)
    assert np.isfinite(saved).all()
    gen=np.zeros(118,complex);demand=np.zeros(118,complex);shunt=np.zeros(118,complex);gchecks=[]
    for k,v in n['gen'].items():
        assert v['gen_status'] in (0,1)
        if v['gen_status']!=1:continue
        z=s['gen'][k];p=float(z['pg']);q=float(z['qg']);assert math.isfinite(p) and math.isfinite(q)
        gen[ix[int(v['gen_bus'])]]+=p+1j*q
        gchecks.append({'id':k,'P_violation_pu':max(0.,v['pmin']-p,p-v['pmax']),'Q_violation_pu':max(0.,v['qmin']-q,q-v['qmax'])})
    for v in n['load'].values():
        assert v['status'] in (0,1)
        if v['status']==1:demand[ix[int(v['load_bus'])]]+=v['pd']+1j*v['qd']
    for v in n['shunt'].values():
        assert v['status'] in (0,1)
        if v['status']==1:shunt[ix[int(v['shunt_bus'])]]+=v['gs']+1j*v['bs']
    assert all(np.isfinite(v).all() for v in (gen,demand,shunt))
    return locals()

def complex_flows(e):
    v=e['vm']*np.exp(1j*e['va']);y=1/(e['r']+1j*e['x']);tap=e['tap']*np.exp(1j*e['shift']);a=e['a'];f=e['f'];t=e['t']
    sf=v[f]*np.conj((y+a('g_fr')+1j*a('b_fr'))/(abs(tap)**2)*v[f]-y/np.conj(tap)*v[t])
    st=v[t]*np.conj((y+a('g_to')+1j*a('b_to'))*v[t]-y/tap*v[f])
    return np.column_stack([sf.real,sf.imag,st.real,st.imag])

def polar_flows(e):
    # Independent expansion of the four native PowerModels branch equations.
    a=e['a'];den=e['r']**2+e['x']**2;g=e['r']/den;b=-e['x']/den
    f=e['f'];t=e['t'];mf=e['vm'][f];mt=e['vm'][t];angle=e['va'][f]-e['va'][t]-e['shift']
    c=np.cos(angle);s=np.sin(angle);coupled=mf*mt/e['tap']
    pf=(g+a('g_fr'))*mf**2/e['tap']**2-coupled*(g*c+b*s)
    qf=-(b+a('b_fr'))*mf**2/e['tap']**2-coupled*(g*s-b*c)
    pt=(g+a('g_to'))*mt**2-coupled*(g*c-b*s)
    qt=-(b+a('b_to'))*mt**2+coupled*(g*s+b*c)
    return np.column_stack([pf,qf,pt,qt])

def evaluate(data,formulation):
    e=extract(data);flow=formulation(e);saved=e['saved'];n=e['n'];ids=e['ids'];vm=e['vm'];va=e['va'];f=e['f'];t=e['t'];a=e['a']
    out=np.zeros(118,complex);np.add.at(out,f,flow[:,0]+1j*flow[:,1]);np.add.at(out,t,flow[:,2]+1j*flow[:,3])
    balance=e['gen']-e['demand']-out-np.conj(e['shunt'])*vm**2
    savedout=np.zeros(118,complex);np.add.at(savedout,f,saved[:,0]+1j*saved[:,1]);np.add.at(savedout,t,saved[:,2]+1j*saved[:,3])
    savedbalance=e['gen']-e['demand']-savedout-np.conj(e['shunt'])*vm**2
    mx=lambda x:float(np.max(abs(x),initial=0));pos=lambda x:float(max(0.,np.max(x,initial=0)))
    equations={'active_balance_reconstructed_pu':mx(balance.real),'reactive_balance_reconstructed_pu':mx(balance.imag),
       'active_balance_savedflows_pu':mx(savedbalance.real),'reactive_balance_savedflows_pu':mx(savedbalance.imag),'saved_branch_flow_reconstruction_pu':mx(flow-saved)}
    native={'voltage_lower_pu':pos(np.array([n['bus'][k]['vmin'] for k in ids])-vm),'voltage_upper_pu':pos(vm-np.array([n['bus'][k]['vmax'] for k in ids])),
       'generator_P_pu':max([v['P_violation_pu'] for v in e['gchecks']],default=0.),'generator_Q_pu':max([v['Q_violation_pu'] for v in e['gchecks']],default=0.),
       'angle_lower_radians':pos(a('angmin')-(va[f]-va[t])),'angle_upper_radians':pos(va[f]-va[t]-a('angmax'))}
    limited=a('rate_a')>0
    native['thermal_apparent_power_pu']=pos((np.maximum(np.hypot(flow[:,0],flow[:,1]),np.hypot(flow[:,2],flow[:,3]))-a('rate_a'))[limited])
    refs=[e['ix'][int(k)] for k in ids if n['bus'][k]['bus_type']==3]
    return {'status':'NATIVE_SAVED_FIELDS_EVALUATED','provider_termination_status':e['meta'].get('termination_status'),
       'buses':118,'active_branches':len(e['active']),'inactive_branches':len(e['bids'])-len(e['active']),
       'equation_residuals':equations,'PF_equations_pass':all(v<=TOL for v in equations.values()),'operating_limit_violations':native,'all_checked_operating_limits_pass':all(v<=TOL for v in native.values()),
       'UV_below_original_0p95':int((vm<.95).sum()),'OV_above_original_1p05plus1e8':int((vm>1.05+1e-8).sum()),'vm_min':float(vm.min()),'vm_max':float(vm.max()),
       'reference_bus_vm':[float(vm[i]) for i in refs],'reference_above_original_guard':any(vm[i]>1.05+1e-8 for i in refs),
       'source_inputs_vs_solved_fields':'Network bus/gen initial values differ legally from solved PF outputs; actual model-serving field contract not yet frozen.',
       'convergence':'Provider label retained; no new solver run or independent convergence claim.'}

def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();info=read(BASE/'selected36/Input_Manifest.json');assert len(info['records'])==36
    pins={str((BASE/'selected36'/v['local_file']).relative_to(R)):v['sha256'] for v in info['records']}
    reader=R/'work/check_pfdelta_fixed36_polar_20261019.py'
    put(B/'Protocol.json',{'status':'FROZEN_BEFORE_ALL36_NATIVE_EQUATION_OUTCOMES','at_utc':now(),'source_sha256':sha(__file__),'reader_sha256':sha(reader),'fixed_tolerance':TOL,'pins':pins,
       'cohort_protocol_sha256':sha(BASE/'Protocol.json'),'selection':'All24nominal and12near-limit predeclared files, including failures. No selection by UV, limits, labels or outcome.',
       'checks':'Native per-unit/radians/status/indexed branches, transformer taps/phase/shunts, saved PF fields, active/reactive KCL, branch reconstruction; native voltage/P/Q/angle/thermal bounds separately descriptive.',
       'new_model_PF_OPF_optimizer_derivative_forecast_linear_solve_calls':0,'resource_bound_seconds':120,'role':'Published-data input validation only, not our-model performance, corrective-control compatibility or optimum.'})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(__file__),'argv':sys.argv})
    rows=[]
    for record in info['records']:
        assert time.perf_counter()-started<120
        path=BASE/'selected36'/record['local_file'];assert sha(path)==record['sha256']
        try:result=evaluate(read(path),complex_flows)
        except Exception as error:result={'status':'UNKNOWN_UNSUPPORTED_SCHEMA_OR_FIELDS','error_type':type(error).__name__,'error':str(error)}
        rows.append({'identity':record['selected_identity'],'file':record['local_file'],'sha256':record['sha256'],'native':result})
        put(B/'rows'/record['local_file'],rows[-1])
    put(B/'Results.json',{'status':'COMPLETE_ALL36_NATIVE_SAVED_FIELD_VALIDATION','rows':rows,'all36_retained':True,'PF_equation_passes':sum(v['native'].get('PF_equations_pass',False) for v in rows),
      'checked_limit_passes':sum(v['native'].get('all_checked_operating_limits_pass',False) for v in rows),'unknown_rows':sum(v['native']['status'].startswith('UNKNOWN') for v in rows),
      'workflow_seconds':time.perf_counter()-started,'new_scientific_calls':0,'corrective_control_or_LLM_test':'NOT_EXECUTED_NOT_INFERRED'})
    manifest(B);print(json.dumps({'complete':36,'equation_passes':sum(v['native'].get('PF_equations_pass',False) for v in rows),'unknown':sum(v['native']['status'].startswith('UNKNOWN') for v in rows)}))

if __name__=='__main__':main()
