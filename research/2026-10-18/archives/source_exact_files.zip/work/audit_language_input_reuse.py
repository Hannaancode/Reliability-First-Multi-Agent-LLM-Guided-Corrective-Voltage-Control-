"""Read-only OPT tokenizer/interface audit; no LM, PF, training or fitting."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
                  OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='')
import ctypes, gzip, hashlib, json, sys, time
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'work'))
from candidate_process_evidence_utils import read,sha,write,seal
OUT=ROOT/'outputs/llm_value_relational_adaptation_research_20261009/language_input_reuse_audit'
assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
dll_path=Path('C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
guard=os.add_dll_directory(str(dll_path));runtime=ctypes.WinDLL(str(dll_path/'msvcp140.dll'))
from transformers import AutoTokenizer
model=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
frozen=read(ROOT/'outputs/frozen_input_verification.json')['model_files']
tokenizer_hashes={}
for name,h in frozen.items():
    if 'token' in name or name in ('vocab.json','merges.txt','special_tokens_map.json','adapter_config.json'):
        assert sha(model/name)==h;tokenizer_hashes[name]=h
tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True,trust_remote_code=False)
forbidden={'after','target','targets','scenario_id','scenario_sha256','world_sha256','branch','branch_id','observation_id','model_input_sha256'}
def check(value):
    if isinstance(value,dict):
        assert not (set(value)&forbidden)
        for x in value.values():check(x)
    elif isinstance(value,list):
        for x in value:check(x)
source=ROOT/'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz'
records=[];worlds=set();maximum=0
with gzip.open(source,'rt',encoding='utf-8') as f:
    for line in f:
        outer=json.loads(line)
        if outer['split']!='optimization':continue
        value=outer['model_input'];assert set(value)=={'current_physical_observation','original_Q_grid'};check(value)
        text=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
        restored=json.loads(text);assert restored==value
        messages=[{'role':'user','content':text}]
        ids=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False)
        maximum=max(maximum,len(ids));worlds.add(outer['world_sha256'])
        records.append({'observation_id':outer['observation_id'],'world_sha256':outer['world_sha256'],
                        'current_payload_sha256':hashlib.sha256(text.encode()).hexdigest(),'actual_chat_context_tokens':len(ids),
                        'fits4096_with384reserve':len(ids)+384<=4096,'token_ids_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest(),
                        'physical_table_names':sorted(value['current_physical_observation']['physical_tables']),
                        'all_current_fields_retained_exactly':True,'truncation':False,'label_and_identity_keys_in_forward':False})
assert len(records)==239 and len(worlds)==23
old_source=ROOT/'work/episode_binary_token_policy.py';old=old_source.read_text(encoding='utf-8')
assert "'one_step_measured_after':copy.deepcopy(v['after'])" in old
assert "projection_excludes_nonprompt_tables':True" in old
previous=read(ROOT/'outputs/llm_value_next_method_research_20261008/binary_policy_codec_legend_v2_preflight/summary.json')
summary={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'actual_OPT_current_contexts':239,'OPT_worlds':23,
         'actual_frozen_tokenizer_max_context_tokens':maximum,'minimum_context_tokens':min(r['actual_chat_context_tokens'] for r in records),
         'fits4096_plus384reserve':sum(r['fits4096_with384reserve'] for r in records),
         'overflow_contexts_retained':sum(not r['fits4096_with384reserve'] for r in records),'all_payload_roundtrips_exact':True,
         'all19_physical_tables_retained':all(len(r['physical_table_names'])==19 for r in records),
         'old_binary_codec_paid_one_step_outcomes_in_forward':True,'old_binary_codec_excludes_nonprompt_physical_tables':True,
         'old_fit_28_root_checks_cannot_certify_new_current_only_full_table_policy':True,
         'old_task_difference_is_legitimate_not_relabelled_label_leakage_in_old_task':True,
         'previous_branch_codec_summary_reused_not_rerun':previous,'tokenizer_files_verified':tokenizer_hashes,
         'current_input_source_sha256':sha(source),'old_binary_source_sha256':sha(old_source),'source_sha256':sha(Path(__file__)),
         'actual_new_model_PF_controller_optimizer_derivative_linear_solve_cloud_calls':0,
         'model_weights_loaded':False,'held_outcomes_or_metrics_accessed':False,
         'new_method_template_or_training_protocol_frozen':False,
         'raw_chat_serialization_only_not_a_proof_all_possible_encodings_fail':True,
         'actual_workflow_seconds_before_seal':time.perf_counter()-started}
write(OUT/'Actual_All239_Current_Context_Records.json',records);write(OUT/'Interface_and_Actual_Tokenizer_Audit.json',summary)
decision='The old binary branch selector legitimately consumed two already-paid accepted one-step receipts to predict an episode choice. Its compact input retained voltage/reports/scopes/options while omitting most physical tables. Its earlier28 root context checks do not certify a causal full-table native action proposer before candidate physics. Do not reuse them as its context or same-information proof.\n\nThis audit tests one unreduced canonical serialization of the exact current-only model input with a minimal user chat wrapper and the frozen tokenizer. It does not choose a training prompt or inspect held outcomes. All239 OPT inputs/all23 worlds and all19 physical tables remain, with exact round trips and no truncation/AFTER/labels/identity fields.\n\n'+json.dumps({k:summary[k] for k in ('minimum_context_tokens','actual_frozen_tokenizer_max_context_tokens','fits4096_plus384reserve','overflow_contexts_retained')},indent=2)+'\n\nAny overflow stops this raw full-table chat representation under the4096/384 contract. It is not a proof that every lossless or multistage representation is impossible. A future representation must define causal information, exact coverage, same-information and stronger controls, token/full-state checks and all preparation/inference costs before training. No rounding, dropped tables, paid future receipts or prompt sweeps may be hidden to claim readiness. The ongoing numerical sources/settings and all stopped methods are unchanged. No new GPU/model experiment is ready from this audit.\n'
(OUT/'Language_Interface_Reuse_Decision.md').write_text(decision,encoding='utf-8')
files={f.name:f for f in OUT.iterdir() if f.is_file()};files['sources/auditor.py']=Path(__file__)
archive=seal(OUT,files,'Current_Only_Language_Interface_Readonly_Audit.zip')
print(json.dumps({'contexts':239,'min_tokens':summary['minimum_context_tokens'],'max_tokens':maximum,'overflow':summary['overflow_contexts_retained'],'model_or_PF_calls':0,'archive':archive}))
