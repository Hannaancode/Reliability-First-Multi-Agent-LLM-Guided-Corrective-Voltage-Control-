"""Independent saved-only query/reference coverage audit, no PF/model replay."""
import copy, gzip, hashlib, json, os, pickle, sys, time
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_additional_history_scope_v2_20261022'
def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    started = time.perf_counter(); A = O / 'independent_audit'; A.mkdir(exist_ok=False)
    p = read(O / 'Protocol.json'); res = read(O / 'Result.json')
    assert sha(Path(__file__)) == p['reader_source_sha256']
    assert sha(R / 'work/close_original_role_additional_histories_v2_20261022.py') == p['source_sha256']
    assert all(sha(O / rel) == h for rel, h in read(O / 'Closed_Manifest.json')['members'].items())
    assert res['status'] == 'COMPLETE_NAMED_ADDITIONAL_INPUT_SCOPE_ONLY' and not res['unclosed_or_missing']
    refs = json.loads(gzip.decompress((O / 'All_Named_Prior_Attempt_Component_References.json.gz').read_bytes()))
    from collections import Counter
    c = Counter(x['journal'] for x in refs)
    assert len(refs) == res['actual_named_attempts_checked']
    assert c == {x['journal']: x['closed_attempts'] for x in res['source_counts']}
    assert len(c) == 7 and sum(c.values()) == 9297
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandas as pd
    import pandapower as pp
    from types import SimpleNamespace
    from native_continuation_preservation_v2 import extended_local_path
    from frozen_physics_loader import load_stack, AUDIT
    from audit_original_role_prior_input_scope_20261022 import independent_key
    assert sha(R / 'work/audit_original_role_prior_input_scope_20261022.py') == p['independent_arithmetic_helper_sha256']
    def blocked(*a, **k): raise BaseException('No solver/model call in independent saved-input arithmetic')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, blocked)
    _, runner, _ = load_stack()
    assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    # Independent source-ledger intent/closure identity multiset, including
    # the three failed reference calls. No failed call is replayed or dropped.
    for rel, h in p['sources'].items():
        path = R / rel; assert sha(path) == h
        attempts = []; ends = []; query_intents = {}; ordered = [x for x in refs if x['journal'] == rel]
        for raw in path.open('rb'):
            assert time.perf_counter() - started < 900, 'Fixed reader bound, no extension'
            row = json.loads(raw); row = row.get('row', row); e = row['event']; d = row.get('payload', row)
            if e == 'new_query_intent': query_intents[d['identity']] = d
            if e in ['literal_PF_intent', 'direct_PF_intent', 'PF_intent', 'solver_attempt']: attempts.append(json.dumps(d['identity'], sort_keys=True))
            elif e in ['literal_PF_return', 'literal_PF_exception', 'direct_PF_return', 'direct_PF_exception', 'PF_return', 'PF_exception', 'solver_closed']:
                ref = ordered[len(ends)]
                assert ref['identity'] == d['identity']
                if e.startswith('literal_'):
                    a = d['anchors']; folder = path.parent / a['relative']
                    assert sha(folder / 'Manifest.json') == a['manifest_sha256']
                    payload = extended_local_path(folder / 'trusted_local_net.pkl').read_bytes()
                    assert hashlib.sha256(payload).hexdigest() == a['payload_sha256']
                    net = pickle.loads(payload)['net']
                elif e.startswith('direct_'):
                    a = d['anchors']; payload = extended_local_path(path.parent / a['payload']).read_bytes()
                    assert hashlib.sha256(payload).hexdigest() == a['payload_sha256']
                    net = pickle.loads(payload)['net']
                elif e == 'solver_closed':
                    assert d['exception'] is None
                    t = d['observation']['physical_tables']
                    def frame(k): return pd.DataFrame(t[k]['values'], index=t[k]['index'], columns=t[k]['columns'])
                    net = SimpleNamespace(bus=frame('bus'), shunt=frame('shunt'))
                    assert not net.shunt['step_dependency_table'].any()
                else:
                    q = query_intents[d['identity']]
                    payload = extended_local_path(path.parent / 'states' / q['parent'] / 'trusted_local_state.pkl').read_bytes()
                    assert hashlib.sha256(payload).hexdigest() == q['parent']
                    net = copy.deepcopy(pickle.loads(payload)['net'])
                    runner.rescue.apply_action(net, q['action'])
                key, _ = independent_key(net)
                assert key == ref['component_sha256'], (rel, d['identity'])
                ends.append(json.dumps(d['identity'], sort_keys=True))
        assert Counter(attempts) == Counter(ends) == Counter(json.dumps(x['identity'], sort_keys=True) for x in refs if x['journal'] == rel)
    targets = read(R / 'outputs/original_role_prior_input_scope_20261022/All45_Indexed_Scope_Query.json')
    assert len(targets) == 45
    for t in targets:
        hits = [r for r in refs if r['component_sha256'] == t['physical_component_sha256']]
        assert hits == res['matching_refs'][t['physical_component_sha256']]
        assert len(hits) == res['target_match_counts'][f"{t['root']}|{t['bus']}|{t['q_mvar']}"]
    value = {'status': 'PASS_ALL_NAMED9297_ATTEMPT_ID_CLOSURES_AND_ALL45_COMPONENT_QUERIES',
        'all_checked_attempts': 9297, 'targets': 45, 'failed_reference_attempts_preserved': 3,
        'matching_components_remain_UNKNOWN': sum(v != 0 for v in res['target_match_counts'].values()),
        'new_PF_model_calls': 0, 'not_full_universal_history_closure_or_new_PF_authority': True,
        'independent_arithmetic_scope': 'ALL9297 saved attempt input components independently recomputed with separate arithmetic, full source/intent/closure identity order bound. Target arithmetic and original60426certificate reused. No new physics replay.',
        'workflow_seconds': time.perf_counter() - started}
    with (A / 'Independent_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2); f.flush(); os.fsync(f.fileno())
    with (A / 'Closed_Manifest.json').open('x', encoding='utf-8') as f:
        json.dump({'members': {'Independent_Audit.json': sha(A / 'Independent_Audit.json')}}, f, indent=2); f.flush(); os.fsync(f.fileno())
    print(json.dumps(value))

if __name__ == '__main__': main()
