"""Read-only exact archived receipt lookup, not permission for another PF call.

Use byte/hash references instead of expanding all old receipts into every new
checkpoint. Independent physical certification is mandatory before execution
reuse; absent/out-of-lineage identities remain UNKNOWN, never an empty cache.
"""
import copy,gzip,hashlib,json
from collections.abc import Mapping
from pathlib import Path
R=Path(__file__).resolve().parents[1]
FRONT=R/'outputs/paid_lineage_frontier_20261018'
OLD=R/'outputs/full_receding_paid_campaign_20261015'
WARM=R/'outputs/receding_warm_dependency_closure_20261015/Paid_Warm_Dependencies.json'
class UnknownLineageIdentity(KeyError):pass
class PriorAttemptBlocked(RuntimeError):pass
class PhysicalCertificateRequired(RuntimeError):pass
def digest(raw):return hashlib.sha256(raw).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def read(p):return json.loads(p.read_text('utf-8-sig'))
class ArchivedLineage:
    def __init__(self):
        p=read(FRONT/'Protocol.json');result=read(FRONT/'Results.json');audit=read(FRONT/'audit/Independent_Frontier_Audit.json')
        assert audit['status']=='PASS_ALL_LINEAGE_ATTEMPT_KEYS_AND_EXACT_SOURCE_RECEIPT_REFERENCES'
        raw=(FRONT/'All_Lineage_Attempt_Keys.json.gz').read_bytes();assert digest(raw)==result['frontier_sha256']
        self.index=json.loads(gzip.decompress(raw));assert len(self.index)==audit['keys']==60377
        raw=WARM.read_bytes();assert digest(raw)==p['warm_dependency_sha256'];self.warm=json.loads(raw)
        self.journal=OLD/'actual/scientific.jsonl';self.protocol=digest((OLD/'Protocol.json').read_bytes())
        manifest=read(OLD/'actual/Closed_Manifest.json')['members']['scientific.jsonl']
        assert p['journal_sha256']==manifest['sha256'] and self.journal.stat().st_size==manifest['bytes']
        self.anchors={'frontier_sha256':result['frontier_sha256'],'warm_sha256':p['warm_dependency_sha256'],
            'source_journal_sha256':p['journal_sha256'],'source_protocol_sha256':self.protocol,
            'frontier_audit_sha256':digest((FRONT/'audit/Independent_Frontier_Audit.json').read_bytes())}
    def classification(self,key):
        if key not in self.index:raise UnknownLineageIdentity('NOT_IN_THIS_INSPECTED_LINEAGE_INDEX_NO_EXECUTION_PERMISSION')
        return self.index[key]['classification']
    def archived_receipt(self,key):
        entry=self.index.get(key)
        if entry is None:raise UnknownLineageIdentity('Missing source coverage remains UNKNOWN')
        category=entry['classification']
        if category in ['PRIOR_INCOMPLETE_BLOCK_REEXECUTION','PRIOR_ATTEMPT_NO_CLOSED_RECEIPT_BLOCK_REEXECUTION']:
            raise PriorAttemptBlocked('Previously attempted identity may not be repeated')
        if category=='WARM_PAID_RECEIPT_RETAIN_OLD_COSTS':
            record=copy.deepcopy(self.warm['cache'][key]);assert record['receipt_id']==entry['receipt_id']
        else:
            assert category=='RECORDED_CLOSED_RECEIPT_REQUIRES_INDEPENDENT_SOURCE_RESULT_CHECK'
            offset=entry['journal_offset'];count=entry['journal_bytes']
            assert 0<=offset<offset+count<=self.journal.stat().st_size and 0<count<=64*1024**2
            with self.journal.open('rb') as f:f.seek(offset);line=f.read(count)
            assert len(line)==count and digest(line)==entry['journal_line_sha256']
            event=json.loads(line);assert event['event']=='every_query_receipt_closed_before_more_science' and event['protocol_sha256']==self.protocol
            message=event['data'];record=copy.deepcopy(message['record']);m=record.pop('actual_measured_receipt')
            assert m['PF_id']==entry['PF_id'] and record['receipt_id']==entry['receipt_id']
            assert digest(canonical(m))==entry['PF_close_data_sha256']
            assert (m['outcome']=='RETURNED')==(entry['outcome']=='RETURNED')
            record['source_existing_measured_receipt']=m
            if record['after_reference'] is not None:
                assert record['after_reference']['kind']=='new'
                record['after_reference']={'kind':'external_capsule','base':str(OLD.relative_to(R)),
                    'descriptor':record['after_reference']['descriptor']}
        record['archived_paid_lineage_provenance']={'key':key,'classification':category,'anchors':copy.deepcopy(self.anchors),
            'new_owner_PF_calls':0,'prior_attributed_PF_and_solver_costs_retained':True}
        return record
    def execution_cache(self,certificate):
        # This prototype never manufactures an absent-key authorization. A new
        # science owner needs its own prospective source/input/bound ledger.
        expected=OLD/'audit_linear_composed_v4_20261018/Independent_Audit.json'
        if Path(certificate).resolve()!=expected.resolve() or not expected.is_file():raise PhysicalCertificateRequired('All recorded physical/source/policy reader must PASS first')
        proof=read(expected)
        if proof['status']!='PASS_PRESERVED_RECEDING_PREFIX_PARTIAL_FULL_GATE_UNKNOWN' or proof['new_model_PF_derivative_factor_solve_calls']!=0:
            raise PhysicalCertificateRequired('Expected independently checked partial evidence only')
        if proof['closed_query_receipts_checked']!=37656 or proof['commits_checked']!=26 or proof['checkpoints_checked']!=25:
            raise PhysicalCertificateRequired('Incomplete recorded evidence coverage')
        lock=read(R/'outputs/receding_linear_composed_reader_preparation_20261018/Independent_Reader_Lock.json')
        assert digest((R/'work/audit_full_receding_linear_composed_v4_20261018.py').read_bytes())==lock['reader_sha256']
        return CertifiedReadOnlyCache(self,digest(expected.read_bytes()))
class CertifiedReadOnlyCache(Mapping):
    """Known paid identities only. An absent key blocks instead of falling into PF."""
    def __init__(self,archive,certificate_sha256):self.archive=archive;self.certificate_sha256=certificate_sha256
    def __len__(self):return len(self.archive.index)
    def __iter__(self):return iter(self.archive.index)
    def __contains__(self,key):
        self.archive.classification(key)
        return True
    def __getitem__(self,key):return self.archive.archived_receipt(key)
    def __deepcopy__(self,memo):
        # Source anchors and archived bytes are immutable references; each
        # __getitem__ returns a fresh caller-owned record, never a shared dict.
        return CertifiedReadOnlyCache(self.archive,self.certificate_sha256)
