"""Independent saved-only implementation of observed parser/normalizer counts."""
import collections,hashlib,json,math,re
from pathlib import Path
R=Path(__file__).resolve().parents[1];D=R/'outputs/original118_raw_action_attribution_v2_20261028';O=D/'independent'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False)
def independent_parse(raw):
    cleaned=raw.replace('```json','').replace('```','').strip()
    try:return json.loads(cleaned),True
    except Exception:
        left,right=cleaned.find('{'),cleaned.rfind('}')
        if left<0 or right<=left:return None,False
        try:return json.loads(cleaned[left:right+1]),True
        except Exception:return None,False
def independent_normalize(obj):
    if isinstance(obj,str):
        try:obj=json.loads(obj)
        except Exception:return None
    if not isinstance(obj,dict):return None
    # Source order of accepted wrappers and aliases is retained explicitly.
    for w in ['proposed_action','action','recommended_action','candidate_action','control_action']:
        inside=obj.get(w)
        if isinstance(inside,dict):
            if 'add_shunts_q_mvar' in inside:obj=inside;break
            for inner in ['proposed_action','action']:
                if isinstance(inside.get(inner),dict) and 'add_shunts_q_mvar' in inside[inner]:obj=inside[inner];break
    payload=obj.get('add_shunts_q_mvar') if 'add_shunts_q_mvar' in obj else None
    if 'add_shunts_q_mvar' not in obj:
        bus=next((obj[k] for k in ['bus','bus_id','BUS_ID','target_bus','target_bus_id'] if obj.get(k)),None)
        q=next((obj[k] for k in ['q_mvar','Q_MVAR','q_MVAr','q','mvar','value','reactive_power_mvar'] if obj.get(k)),None)
        if bus is not None and q is not None:payload={str(bus):q}
    if not isinstance(payload,dict):return None
    for key,v in payload.items():
        try:b=str(key).strip();q=float(v)
        except Exception:continue
        if not b or not math.isfinite(q) or q<=0:continue
        q=max(25.,min(300.,round(q/25.)*25.));return {'add_shunts_q_mvar':{b:float(q)}}
    return None
def main():
    O.mkdir(exist_ok=False);base=read(D/'Results.json');p=read(D/'Protocol.json')
    for f,h in p['source_files'].items():assert sha(R/f)==h
    write(O/'Protocol.json',dict(source_sha256=sha(Path(__file__)),primary_results_sha256=sha(D/'Results.json'),independent_normalizer_implementation=True,
      source_context='Same exact observed records; new descriptive selected-direct repair analysis, no prospective learning claim.',new_model_PF_calls=0))
    total=collections.Counter();rows=[];selected=collections.Counter();warnings=[]
    for i,case in enumerate(base['cases']):
        path=R/case['result_path'];assert sha(path)==case['result_sha256'];result=read(path);proof=read(D/f'case_{i:02d}_Attribution.json')['response_checks'];cursor=0;c=collections.Counter();bydecision={}
        for j,entry in enumerate(result['logs']):
            info=entry['llm_info']
            if info.get('raw') is None:c['non_generation_zone_skips']+=1;continue
            c['zone_decisions_with_generation']+=1;c['reprompted_zone_decisions']+=int(bool(info.get('reprompted')))
            attempts=[('first',info['first_raw'])] if info.get('reprompted') else []
            attempts.append(('second' if info.get('reprompted') else 'first',info['raw']))
            for kind,raw in attempts:
                r=proof[cursor];cursor+=1;assert r['raw_sha256']==hashlib.sha256(raw.encode()).hexdigest() and r['log']==j and r['attempt']==kind
                parsed,ok=independent_parse(raw);action=independent_normalize(parsed);assert action==r['normalized_action'] and ok==r['source_parse_valid']
                valid=False;reason='no_action'
                if action:
                    try:b=int(next(iter(action['add_shunts_q_mvar'])))
                    except Exception:reason='no_bus'
                    else:
                        valid=not info['candidate_buses'] or b in [int(x) for x in info['candidate_buses']]
                        reason='valid' if valid else f'bus_{b}_not_in_candidate_list'
                assert valid==r['candidate_valid'] and reason==r['reason']
                whole=False;strict=False;qchanged=False
                try:
                    x=json.loads(raw);whole=True
                    shape=isinstance(x,dict) and set(x)=={'bus','q_mvar'} and isinstance(x['bus'],str) and re.fullmatch(r'\d+',x['bus']) is not None and type(x['q_mvar']) in [int,float]
                    strict=bool(shape and x['q_mvar'] in [25,50,75,100,125,150,200,250,300])
                    if shape and action:qchanged=float(x['q_mvar'])!=next(iter(action['add_shunts_q_mvar'].values()))
                except Exception:pass
                assert whole==r['whole_response_JSON'] and strict==r['requested_compact_schema_valid'] and qchanged==r['numeric_Q_changed']
                c.update({'all_controller_responses':1,kind+'_responses':1,'whole_response_JSON':int(whole),'requested_compact_schema_valid':int(strict),
                    'source_extractor_parse_valid':int(ok),'source_candidate_semantically_valid_after_normalization':int(valid),kind+'_candidate_valid':int(valid),
                    'numeric_Q_changed_by_normalizer':int(qchanged),'accepted_alternative_or_extracted_format':int(valid and not strict)})
            bydecision[(entry['iteration'],entry['zone'])]=(r,entry)
            if entry.get('verif') is not None:c['direct_candidate_verifier_records']+=1;c['direct_candidate_numerically_accepted']+=int(bool(entry['verif']['accepted']))
        assert cursor==len(proof) and dict(c)==case['counts'];total.update(c)
        committed=collections.Counter(x['source'] for x in result['executed_actions']);assert dict(committed)==case['commit_origins']
        direct=[]
        for action in result['executed_actions']:
            if action['source']!='llm_direct':continue
            raw,log=bydecision[(action['iteration'],action['zone'])]
            assert log['action']==action['action']==raw['normalized_action'] and log['verif']['accepted']
            selected['llm_direct_commits']+=1;selected['direct_commit_with_Q_changed']+=int(raw['numeric_Q_changed']);selected['direct_commit_requested_compact_schema_valid']+=int(raw['requested_compact_schema_valid'])
            direct.append(dict(iteration=action['iteration'],zone=action['zone'],raw_sha256=raw['raw_sha256'],numeric_Q_changed=raw['numeric_Q_changed'],requested_compact_schema_valid=raw['requested_compact_schema_valid']))
        rows.append(dict(case_id=case['case_id'],all_original_counts_exact=True,commit_origins=dict(committed),selected_direct_classification=direct))
    assert dict(total)==base['totals']
    outcome=dict(status='PASS_ALL4_INDEPENDENT_RAW_NORMALIZATION_AND_ATTRIBUTION',rows=rows,totals=dict(total),selected_direct_totals=dict(selected),
      new_model_PF_controller_optimizer_calls=0,scope='Saved descriptive all4development. Initial strict raw schema is different from source postnormalizer membership and actual numerical acceptance. Per-test accepted68 is not committed51. Guided13 and fallback9 are numerical search contributions.',
      cannot_infer='Raw model superiority, causal marginal benefit, generalization, or corrected action causality from these counts alone.')
    write(O/'Independent_Audit.json',outcome);write(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))
    print(json.dumps(dict(status=outcome['status'],totals=dict(total),selected_direct=dict(selected))))
if __name__=='__main__':main()
