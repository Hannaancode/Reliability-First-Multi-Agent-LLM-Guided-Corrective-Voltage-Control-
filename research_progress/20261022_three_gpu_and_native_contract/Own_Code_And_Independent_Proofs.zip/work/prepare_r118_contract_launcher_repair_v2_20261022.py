"""Additive argument-only launcher repair after a zero-science no-op."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
P=R/'outputs/r118_solver_contract_bridge_preparation_20261022'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
def main():
    assert not (R/'outputs/r118_solver_contract_bridge_execution_20261022').exists()
    old=R/'outputs/r118_solver_contract_bridge_coordination_20261022'
    assert (old/'Owner.log').read_text('utf-8').strip()=='PREPARED_ONLY_REQUIRES_EXPLICIT_HUMAN_CONSTRAINT_CLARIFICATION'
    approval=json.loads((P/'Explicit_Human_Clarification.json').read_text('utf-8'))
    assert approval['approved_single_new80_measurement_and_first_verification'] and approval['protocol_sha256']==sha(P/'Protocol.json')
    original=R/'work/coordinate_f118_encoder_owner_20261022.py'
    text=original.read_text('utf-8')
    before="[str(ROOT/s['python']),'-X','utf8',str(source)]"
    after="[str(ROOT/s['python']),'-X','utf8',str(source),*s.get('arguments',[])]"
    assert text.count(before)==1
    new=R/'work/coordinate_single_owner_arguments_v2_20261022.py'
    new.write_text(text.replace(before,after),encoding='utf-8')
    reader=R/'work/audit_r118_solver_contract_bridge_20261022.py'
    oldpath='outputs/r118_solver_contract_bridge_coordination_20261022/End_ACK.json'
    newpath='outputs/r118_solver_contract_bridge_coordination_v2_20261022/End_ACK.json'
    rt=reader.read_text('utf-8');assert rt.count(oldpath)==1
    newreader=R/'work/audit_r118_solver_contract_bridge_v2_20261022.py'
    newreader.write_text(rt.replace(oldpath,newpath),encoding='utf-8')
    owner=json.loads((P/'Owner_Protocol.json').read_text('utf-8'))
    owner['single_owner']['arguments']=['--execute']
    owner['single_owner']['coordination']='outputs/r118_solver_contract_bridge_coordination_v2_20261022'
    put(P/'Owner_Protocol_v2.json',owner)
    ro=json.loads((P/'Reader_Owner_Protocol.json').read_text('utf-8'))
    ro['single_owner']['source']=str(newreader.relative_to(R)).replace('\\','/')
    ro['single_owner']['sha256']=sha(newreader)
    put(P/'Reader_Owner_Protocol_v2.json',ro)
    put(P/'Argument_Only_Mechanical_Repair.json',dict(status='PASS_NO_PRIMARY_OR_READER_SCIENCE_ENTERED_OLD_NOOP_PRESERVED',
        original_scientific_protocol_unchanged=sha(P/'Protocol.json'),human_approval_sha256=sha(P/'Explicit_Human_Clarification.json'),
        launcher_only_change='Pass the explicitly authorized --execute argument; distinct coordination output.',
        reader_only_change='Bind actual new coordinator End_ACK path; all physics/field/KCL checks identical.',
        old_owner_log_sha256=sha(old/'Owner.log'),new_launcher_sha256=sha(new),new_reader_sha256=sha(newreader),
        new_primary_PF_calls=0,new_independent_replay_calls=0,old50calls_repeated=0))
if __name__=='__main__':main()
