# Broader characterization and component study: complete

Completed and independently audited on 8 October 2026, at 10:39 Qatar. Eight historical operating points in four outage families were selected before the first genuine screen outcomes. These are development inputs, not a fresh holdout. The frozen thesis baseline and its two archives remain unchanged.

The full 120-row screen contains 72 preserved CPU controls and 48 newly executed learned numerical rows. All 48 genuine LoRA/base batches, original framework adapter states, source/case/environment identities and actual costs passed the independent audit. There were 192 primary query opportunities and 240 actual generations, including 48 repairs: 332,883 input tokens, 5,814 output tokens and 271.242277 measured generation seconds, zero generation exceptions. GPU inference and local numerical timing are separate measurements. Total local PF across controls and learned evaluation: 6,456 attempts, 6,447 returns and nine retained exceptions. Actual source states and selected-action metrics matched within 1e-10.

| Family | Load | Raw LoRA minus lowest-voltage residual UV, B32 | Bus/Q LoRA minus lowest-voltage residual UV, B32 |
|---|---:|---:|---:|
|Line35 / MG1|1.25|0|0|
|Line35 / MG1|1.50|+7|+8|
|Line84 / MG2|1.25|0|0|
|Line84 / MG2|1.50|+9|+2|
|Line127 / MG3|1.25|0|0|
|Line127 / MG3|1.50|+7|-6|
|Line36 / MG1|1.25|+2|0|
|Line36 / MG1|1.50|+7|+9|

Negative differences favor the model-derived method. Raw LoRA: zero wins, three ties, five losses; mean residual-UV difference +4. The separately predeclared bus/Q component: one win, four ties, three losses; mean difference +1.625. The severe MG3 component retained 37 UV buses versus 43 for the comparator, but its selected bus95/Q300 action reached1.0563398828p.u., exceeding the normal upper band. This is a UV-only signal that does not establish joint-band value, overall superiority or full recovery. Every base-model, enumeration, random, budget, deficit and voltage-band comparison is retained in the original analysis and row files.

All sixteen new component trials finished: 536 actual new PF attempts, zero exceptions, zero new model calls. Their inherited sixteen B32 batches retain the original acquisition costs and are not counted as fresh inference. Selection, reference deltas, hashes and freshly executed physical agreement passed the independent component audit.

The original broader model driver stopped after 36 batches because buses54 and106, both about0.952p.u., swapped the lowest12 membership by roughly3e-16 on Linux versus Windows. Two charged diagnostic PF solves identified the cause. A disclosed continuation executed only the twelve missing batches on the same assignment, enforcing the already frozen CPU candidate scope for that diagnosed tie checked within1e-12. Original36 batch bytes were preserved and distinct actual driver identities audited. Frozen model/physics/voltage limits/query/Qgrid/score/seed/budgets were unchanged. The owned T4 was released at10:34:30 Qatar. Preparation costs are six successful original-case PF solves, one successful initial solve before the assertion, two resume solves, and two separate diagnostic solves. The failed-case PF elapsed duration was not checkpointed; it is explicitly unknown and has not been fabricated.

The local supplement ZIP contains336 verified unique members with CRC and every member hash checked. `Supplement_Package_Manifest.json` records archive SHA2563a101f820410b6e5994eb84274a90f918a933ac3ff26027198e5baeb3dee9ab8 and36,279,898 bytes. Read `Broader_Screen_Completion_Audit.json`, `Broader_Component_Completion_Audit.json`, `Candidate_Tie_Portability_Addendum.json` and `Merged_Genuine_Evidence.json` for exact provenance.

Additional analysis of preserved replies made no model or PF calls: strict B32 raw validity was21/32 for LoRA and22/32 for base. Three LoRA and six base replies used an observed bus voltage as Q, a unit/task-interface issue. All sixteen state/policy pairs had identical raw replies across their three budget acquisitions. Those actual calls remain charged; a future protocol can acquire one genuine batch per state/policy and predeclare its reuse across numerical budgets.

The original ten-step baseline remains complete. These results do not meet the broader thesis goal of demonstrating reliable incremental LLM value. Full learned closed-loop and final FDIA evaluation are still unexecuted. Preparation of a separate guarded bus/Q live interface has begun. A meaningful software contract audit against32 genuine saved prompt hashes found the older preparation helper dropped global UV voltage values by converting its dictionary to a bus-only list. The separately named corrected helper retains the original dictionary and passed all32 recorded prompt hashes; original software sources are preserved. Its bus/Q ordering is AST-identical to the executed component intervention, with existing normal-upper mediation shared across arms. These zero-model/zero-PF readiness checks do not constitute actual full-loop performance.
