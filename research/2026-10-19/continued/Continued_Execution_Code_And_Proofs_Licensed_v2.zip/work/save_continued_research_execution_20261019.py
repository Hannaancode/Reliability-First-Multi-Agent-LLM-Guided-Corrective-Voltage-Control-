"""Organized execution ledger, exact resume, licensed public proofs. No science."""
import hashlib,json,os,zipfile
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from save_fixed_three_progress_20261019 import atomic
from candidate_process_evidence_utils import frozen_checks
from equal_operation_benchmark_v2 import process
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
B=R/'outputs/research_execution_20261019_continued'
SCREEN=R/'outputs/all_thirteen_paid_receipts_policy_screen_20261019'
def main():
    B.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat();source=R/'outputs/third_point_remaining_three_query_acquisition_20261019'
    assert read(source/'Completion.json')['exit_codes']=={'warm':0,'cold_1':0,'cold_2':0,'audit':0}
    a=read(source/'audit/Independent_Audit.json');assert a['status']=='PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
    old=R/'outputs/third_point_four_query_acquisition_20261019';assert read(old/'Preserved_Prefix_State_Proof.json')['actual_primaries']==1
    outcomes=[]
    for base,phases in [(old,('warm',)),(source,('warm','cold_1','cold_2'))]:
        for ph in phases:
            d=read(base/ph/'Result.json')['receipt'];v=d['message']['record']['verdict'];outcomes.append({'row':d['message']['row'],'before':v['before'],'after':v['after'],'accepted':v['accepted'],'replay_delta':d['replay']['maximum_field_delta'],'source':str((base/ph/'Result.json').relative_to(R))})
    assert len(outcomes)==4 and all(x['accepted'] and x['before']['uv_count']==18 and x['after']['uv_count']==15 and x['replay_delta']==0 for x in outcomes)
    n=R/'outputs/second_required_numeric_context_20261019';assert read(n/'Completion.json')['exit_codes']=={'actual':0,'independent_audit':0};numeric=read(n/'independent_audit/Independent_Audit.json');assert numeric['forecasts']==1391
    public=read(R/'outputs/published_benchmark_contract_handoff_20261019/Verified_Source_Findings.json');bridge=read(R/'outputs/pglearn_base_native_ppc_bridge_20261019/Result.json');assert bridge['status']=='PASS_SOURCE_FAITHFUL_PUBLISHED_BASE_NATIVE_INITIALIZATION'
    live=None;c=read(SCREEN/'owner.claim');q=process(c['actual_pid'])
    if q:
        assert q['ParentProcessId']==c['parent_pid'] and 'replay_all_thirteen_paid_receipts_20261019.py' in (q['CommandLine'] or '')
        live={'actual_pid':c['actual_pid'],'parent_pid':c['parent_pid'],'source':'work/replay_all_thirteen_paid_receipts_20261019.py','actual_command':q['CommandLine'],'source_sha256':c['source_sha256'],'exec_session':30257,'fixed_bound_seconds':900,'new_scientific_calls':0}
    summary={'at_utc':at,'status':'THIRD_POINT_ALL4_PHYSICAL_RECEIPTS_VERIFIED_SAVED_POLICY_ANALYSIS_RUNNING' if live else 'THIRD_POINT_ALL4_PHYSICAL_RECEIPTS_VERIFIED_CHECK_CLOSED_ANALYSIS',
        'third_point_outcomes':outcomes,'third_original_four_owner':'TERMINAL_PARTIAL_PERMISSION_SHARING_FAILURE_AFTER_WARM','original_cold_1':'FAILED_BEFORE_ANY_SCIENTIFIC_BODY_NO_RESTART','remaining_three_new_exact_identities':'COMPLETE_INDEPENDENT_PASS','remaining_three_costs':a['costs'],'all_today_new_queries':11,'all_today_PF_attempts_and_returns_including_replays':22,'all_today_PF_exceptions':0,'aggregation_limit':'Alternatives at THREE distinct saved states:17to14,17to14,18to15. Not11 sequential reductions or11 solved cases. One older originalK4 rejected action plus separate old engineering adverse action remain retained. No new actual commits.','second_required_context':numeric,'public_test_prefix_intaken':16,'public_case_json_distinct_base_reference':1,'public_sampled_strict_native_passes':0,'public_base_native_PPC_bridge':bridge,'active_readonly_analysis':live,'timers':[],'GPU_allocations':[],'all6goals':'OPEN','LLM_DSE_full_policy_superiority':'UNACHIEVED','old_four_second_point_last_process_exit':'UNKNOWN_RETAINED','frozen_original_assets':frozen_checks()}
    put(B/'Verified_Execution_Checkpoint.json',summary)
    ledger='''# Continued research execution —19October

All six final goals remain open. This file indexes actual execution and preserves failures; software success is not an LLM/control win.

|Work|Actual result|Code/evidence|
|---|---|---|
|Second missing numerical context|1391 full native forecasts; one derivative, one LU factor, one118-RHS solve; independent equations/menu and exact owner exits passed;0PF/model|`work/second_required_numeric_context_20261019.py`; `outputs/second_required_numeric_context_20261019/`|
|Third18UV point, original4-query owner|One real query safely18→15, one exact charged replay; stopped after Windows sharing error at next claim, before next scientific body. Original partial retained|`work/run_third_point_four_queries_20261019.py`; `outputs/third_point_four_query_acquisition_20261019/`|
|Independent preserved-prefix reader|Actual warm source/native inputs/all118replay/cursor/state/cost verified. Other3 remain UNKNOWN/unexecuted in that old study|`work/audit_third_point_preserved_prefix_20261019.py`|
|Future handoff repair|Four real zero-science process cases passed: split JSON, atomic claim, nonzero exit7, exclusive Windows file-share lock; no old worker/source/settings changed|`work/prospective_query_custody_v3_20261019.py`; `outputs/prospective_query_custody_v3_20261019/`|
|Three genuinely unentered original menu identities|All3 independently passed; each18→15,6PF including3exact charged replays,0exceptions. New exact protocol/owners, not a restart or repeated measured action|`work/run_third_point_remaining_three_20261019.py`; `outputs/third_point_remaining_three_query_acquisition_20261019/`|
|Unchanged policy with all13paid receipts|Read-only support analysis;0newscience. No actual new commit or complete trajectory claim|`work/replay_all_thirteen_paid_receipts_20261019.py`; `outputs/all_thirteen_paid_receipts_policy_screen_20261019/`|
|Published PGLearn118 data|Pinned one85,559,012-byte author shard; fixed first16provider test rows retained. Raw licensed data stay local|`work/intake_pglearn_fixed_test_prefix_20261019.py`|
|Public semantic/physical audit|One repeated solved base reference, not16different reference states. Distinct sampled columns all retain fixed native residual failures; no substitution/filtering/tolerance change. Failed rounding assumption preserved|`work/check_pglearn_fixed16_semantics_native_v2_20261019.py`; `outputs/published_benchmark_contract_handoff_20261019/`|
|Native public initialization bridge|The ONE publisher base reference matches the original ordinary PGLib static network/limits. Initial dispatch/voltage/flows pass the original independent native complex-equation/limits/objective checker at5e-6.0solvercalls. Already0UV: importer reference ONLY|`work/bridge_pglearn_base_to_native_public_ppc_20261019.py`; `outputs/pglearn_base_native_ppc_bridge_20261019/`|
|Published model comparison source|PFDelta118/PFNet/CANOS code and dataset revisions/licensing pinned; prediction-vs-control task mismatch and reported loss-fix caveat recorded. No large PFDelta data/model/training run|`outputs/pfdelta_benchmark_source_review_20261019/`; `outputs/published_benchmark_contract_handoff_20261019/Results_And_Prospective_Benchmark_Contract.md`|

The new physical measurements are alternatives at three saved states, not11solved cases or a sequential9UV reduction. Preserve original literalDFF+DFFALT+unchanged DSE, both individual branches and FULL BOTH costs, all failed/partial/UNKNOWN outcomes, severe-case roster and unused confirmation. Historical/inspected data are development.

Next: finish only the exact live saved-policy support analysis, preserve the next exact unsupported identity/menu/context and source/cost proofs. New measurement requires prospective exact identity/native source/custody/persistence/independent reader/full costs. No automatic GPU, old-owner restart, repeated physics, budget extension or outcome retune. For public performance, build the actual causal serving/import/control-role contract across all declared cases; the single already-zero base is not a chosen hard-case benchmark.
'''
    (B/'Execution_Index.md').write_text(ledger,'utf-8')
    current=R/'outputs/remaining_three_fixed_queries_20261019/verified_completion/Current_Resume_20261019.json';v=read(current);v.update(at_utc=at,status=summary['status'],latest_closed_evidence=str((B/'Verified_Execution_Checkpoint.json').relative_to(R)),active_analysis=live,active_new_numeric_owner=[],waiting_check={'status':'NONE_TIMER_DELETED'},next_steps_in_order=['Finish only exact all13paid-receipt saved-policy analysis; never duplicate/restart or call new science from it.','On terminal verify closure/source/hash-chain/costs and next missing exact identity; preserve UNKNOWN as UNKNOWN.','New physical/numeric identities need a prospective source/causal input/ownership/persistent/cost/reader protocol; never repeat executed identities or extend stopped budgets.','Public one-base faithfulPPC init now certified; sampled16 strict native failures retained, no public model test yet. Follow source benchmark contract and all6stable goals.']);atomic(current,v)
    path=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';v=read(path);v.update(at_utc=at,current_task={'status':summary['status'],'index':str((B/'Execution_Index.md').relative_to(R))},active_owned_jobs=[live] if live else [],timers=[],latest_closed_continuation=str(current.relative_to(R)));atomic(path,v)
    p=R/'outputs/research_tasks_20261014/Tasks.json';v=read(p);v['at_utc']=at;v['tasks'][0]['latest_20261019_third_point']=str((B/'Verified_Execution_Checkpoint.json').relative_to(R));v['tasks'][0]['next']='Finish exact all13paid-receipt support analysis and preserve next unsupported identity; no actual commit/fulltrajectory/LLMclaim yet.';v['tasks'][1]['latest_native_public_initialization']=str((R/'outputs/pglearn_base_native_ppc_bridge_20261019/Result.json').relative_to(R));v['latest_exact_execution_state']=str(current.relative_to(R));atomic(p,v)
    master=R/'RESEARCH_TASKS.md';text=master.read_text('utf-8');lines=text.splitlines();lines[2]=f'Updated {at}. All six final goals remain open; verified subtasks retain their original evidence.';master.write_text('\n'.join(lines)+'\n\nContinued19October: all4alternatives at third18UVstate independently verified18to15, with old interrupted study retainedPARTIAL and3unentered identities acquired once under a separate exact protocol. One source-published base reference now bridges faithfully to original nativePGLibPPC, independent original constraints passed; already-zero reference is not a control win. [Execution/code index](outputs/research_execution_20261019_continued/Execution_Index.md).\n','utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+at+' —Third18UVpoint ALL4fixedmenu physicalreceipts known:18to15/all118replaydelta0; original4ownerPARTIALafter1primary dueWindowsfile-shareclaim error, no scientificentryforcold1; independent warm-prefix auditpassed. Newexact3unenteredidentities COMPLETE/independentPASS6PF6returns0exceptions, source/cold/cursor/registry/RNG/deadline/cost gatespassed, no oldrestart or repeatedphysics. Today11newprimaryqueries/22totalPFincludingreplays0exceptions acrossTHREEsavedstates; NOT11solvedcases or sequentialUVreduction. Native publicPGLearnstaticbase now exactsource/constraint matched tooriginalPublic1PGLib; independentnativePPCcertificatePASS,0newsolvers; already0UV/integrationonly. All13paidreceipts saved-policy analysis maybelive perexactresume. All6goalsOPEN. Fullindex '+str((B/'Execution_Index.md').relative_to(R))+'.\n');f.flush();os.fsync(f.fileno())
    header=f'LATEST CONTINUED EXECUTION {at}\n\nThird18UVpoint ALL4physicalreceipts verified18to15/all118replayexact. OldfourstudyPARTIALafter1query/2PF, sharingerrorbeforecold1science; oldownersENDED. New3unenteredidentities COMPLETE/PASS6PF, allowners/readersENDED. Newfuturecustody4realzero-sciencecasesPASS. Sole readonlyall13receipt analysis '+(str(live['actual_pid'])+'/'+str(live['parent_pid']) if live else 'NOT_LIVE_BY_EXACT_COMMAND')+' source replay_all_thirteen_paid_receipts_20261019.py fixed900sec0newscience. NoGPU/timers. ONEpublishedPGLearnbase matchesoriginalPublic1nativePPC/strictcertPASS0solvercalls; already0UV integrationonly, not16testtargets or controlwin. Read outputs/research_execution_20261019_continued/Execution_Index.md and canonicalresume. All6goalsOPEN; oldunknownlast-exit/adverse/partial/frozenassets/FULLBOTH DSEcosts preserved; no restart/retry/retune/extension.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    selected={}
    for p in (R/'work').glob('*20261019.py'):selected[p.relative_to(R).as_posix()]=p
    folders=[B,R/'outputs/prospective_query_custody_v3_20261019',R/'outputs/second_required_numeric_context_20261019',old,source,R/'outputs/published_benchmark_contract_handoff_20261019',R/'outputs/pfdelta_benchmark_source_review_20261019',R/'outputs/pglearn_base_native_ppc_bridge_20261019',R/'outputs/pglearn_fixed_test_prefix_20261019/native_equation_audit_v2',R/'outputs/pglearn_fixed_test_prefix_20261019/independent_complex_audit_v2']
    withheld=[]
    for root in folders:
        for p in root.rglob('*'):
            if not p.is_file() or p.suffix not in ('.json','.md','.txt','.log') and p.name!='owner.claim':continue
            if p.stat().st_size>512*1024:withheld.append(str(p.relative_to(R)));continue
            selected[p.relative_to(R).as_posix()]=p
    for rel in ('RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json'):selected[rel]=R/rel
    for name,p in list(selected.items()):
        if SECRET_NAME.search(p.name) or any(x.search(p.read_text('utf-8')) for x in SECRET):withheld.append(name);del selected[name]
    (B/'DATA_ATTRIBUTION_AND_LICENSE.txt').write_text((R/'outputs/published_benchmark_contract_handoff_20261019/DATA_ATTRIBUTION_AND_LICENSE.txt').read_text('utf-8'),'utf-8');selected['DATA_ATTRIBUTION_AND_LICENSE.txt']=B/'DATA_ATTRIBUTION_AND_LICENSE.txt'
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in selected.items()};put(B/'Public_Manifest.json',{'status':'PUBLIC_CODE_PROOFS_DIAGNOSTICS_NO_RAW_NET_MODELS_OR_DATA_SHARD_EXPORT','files':desc,'withheld':withheld,'raw_artifacts_retained_local_with_source_hashes':True,'all6goals':'OPEN'})
    archive=B/'Continued_Execution_Code_And_Proofs.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in selected.items():z.write(p,n)
        z.write(B/'Public_Manifest.json','Public_Manifest.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(selected)+1
        for n,d in desc.items():raw=z.read(n);assert len(raw)==d['bytes'] and hashlib.sha256(raw).hexdigest()==d['sha256']
    put(B/'Public_Archive_Audit.json',{'status':'PASS_UNIQUE_CRC_ALL_HASH_SECRET_SCREEN','bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(selected)+1,'withheld':withheld})
    print(json.dumps({'saved':True,'new_18to15_queries':4,'active_analysis':live,'code_proof_archive_bytes':archive.stat().st_size,'all_goals':'OPEN'}))
if __name__=='__main__':main()
