import os,json,hashlib,importlib.metadata as md
from pathlib import Path
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN']='1'
ROOT=Path(__file__).resolve().parents[1];os.environ['HF_HOME']=str(ROOT/'cache/huggingface')
import torch
from huggingface_hub import snapshot_download
p=json.loads((ROOT/'prep/protocol.json').read_text());arm=json.loads((ROOT/'prep/selected_arm.json').read_text())['arm'];d=p['models'][arm];pins=[r.split('==') for r in (ROOT/'work/frozen_dependency_closure.txt').read_text().splitlines()];assert len(pins)==111 and all(md.version(n)==v for n,v in pins);assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
snapshot=Path(snapshot_download(d['repo'],revision=d['revision'],allow_patterns=['model.safetensors','config.json'],token=False));h=hashlib.sha256()
with (snapshot/'model.safetensors').open('rb') as f:
 for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
assert h.hexdigest()==d['public_weight_sha256'] and hashlib.sha256((snapshot/'config.json').read_bytes()).hexdigest()==d['config_sha256']
(ROOT/'outputs/public_size_environment.json').write_text(json.dumps({'gpu':torch.cuda.get_device_name(0),'base_snapshot':str(snapshot),'base_revision':d['revision'],'base_weight_sha256':h.hexdigest(),'config_sha256':d['config_sha256'],'exact_dependency_count':len(pins),'actual_pretrained_forwards':0},indent=2))
