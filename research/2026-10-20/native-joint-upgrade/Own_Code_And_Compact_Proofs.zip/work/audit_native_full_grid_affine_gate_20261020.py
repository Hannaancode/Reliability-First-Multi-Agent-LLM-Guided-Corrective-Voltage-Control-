"""Independent dense complex calculus / primal-dual / units / input audit; zero new solver/model/PF calls."""
import json,hashlib,pickle,os,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/native_full_grid_affine_gate_20261020';PREP=ROOT/'outputs/native_full_grid_affine_preparation_20261020';OUT=ROOT/'outputs/native_full_grid_affine_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));result=json.loads((SRC/'Result.json').read_text(encoding='utf-8'));manifest=json.loads((SRC/'Closed_Manifest.json').read_text(encoding='utf-8'))
    for n,h in {**p['sources'],**p['inputs']}.items():assert sha(ROOT/n)==h
    for f in manifest['files']:assert sha(SRC/f['path'])==f['sha256'] and (SRC/f['path']).stat().st_size==f['bytes']
    previous='0'*64;events=[]
    for line in (SRC/'events.jsonl').read_text(encoding='utf-8').splitlines():
        r=json.loads(line);e=r['event'];assert e['previous']==previous and hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest()==r['sha256'];previous=r['sha256'];events.append(e)
    assert previous==manifest['journal_last_sha256'];rows=[];cap=float(np.float32(.3))
    for pos,r in enumerate(result['all24contexts']):
        assert r['seed']==p['all24contexts'][pos]['seed'] and r['algorithm']==p['all24contexts'][pos]['algorithm'];d=SRC/f'context_{pos:02d}'
        if r['status']!='COMPLETE_AFFINE_ONLY':rows.append({'context':pos,'status':'UNKNOWN_PARTIAL_PRESERVED'});continue
        z=np.load(d/'Model_And_Problem.npz');y=z['Y'];v=z['V'];pq=z['pq'];ii=y@v;norm=v/np.abs(v);dm=np.diag(v)@np.conj(y@np.diag(norm))+np.diag(np.conj(ii))@np.diag(norm);da=1j*np.diag(v)@np.conj(np.diag(ii)-y@np.diag(v));j=np.block([[da[np.ix_(pq,pq)].real,dm[np.ix_(pq,pq)].real],[da[np.ix_(pq,pq)].imag,dm[np.ix_(pq,pq)].imag]]);assert np.allclose(j,z['J'],atol=1e-10,rtol=1e-12) and np.max(np.abs(j@z['response']-z['rhs']))<=1e-9
        rhs=np.zeros((24,3));order={int(k):i for i,k in enumerate(pq)}
        for i,k in enumerate(z['control_ppc']):rhs[12+order[int(k)],i]=1/float(z['baseMVA'])
        assert np.array_equal(rhs,z['rhs']);full=np.zeros((13,3));full[pq]=z['response'][12:];s=full[z['lookup']];assert np.array_equal(s,z['S'])
        with (ROOT/p['all24contexts'][pos]['paid_NET']).open('rb') as f:net=pickle.load(f)
        assert np.array_equal(z['vm'],net.res_bus.vm_pu.to_numpy()) and np.array_equal(z['q0'],net.sgen.q_mvar.to_numpy()[:3])
        aa=[];bb=[]
        for k,value in enumerate(z['vm']):
            for sign,limit in [(1.,1.05),(-1.,-.95)]:row=np.r_[sign*s[k],np.zeros(3),-1.];aa.append(row);bb.append(limit-sign*value)
            if .95<=value<=1.05:
                for sign,limit in [(1.,1.05),(-1.,-.95)]:row=np.r_[sign*s[k],np.zeros(4)];aa.append(row);bb.append(limit-sign*value)
        for i in range(3):
            for sign in [1.,-1.]:row=np.zeros(7);row[i]=sign;row[3+i]=-1;aa.append(row);bb.append(-sign*z['q0'][i])
        aa=np.asarray(aa);bb=np.asarray(bb);cc=np.r_[np.zeros(6),1.];assert np.array_equal(aa,z['A']) and np.array_equal(bb,z['b']) and np.array_equal(cc,z['c']);certs=[];first=None
        for stage in [1,2]:
            sol=np.load(d/f'Stage{stage}_Proof.npz')
            if stage==2:cc=np.r_[np.zeros(3),np.ones(3),0.];aa=np.vstack([aa,np.r_[np.zeros(6),1.]]);bb=np.r_[bb,first[-1]+1e-10]
            assert np.array_equal(aa,sol['A']) and np.array_equal(bb,sol['b']) and np.array_equal(cc,sol['c']);x=sol['x'];dy=sol['ineq_marginals'];dl=sol['lower_marginals'];du=sol['upper_marginals'];lb=np.r_[np.full(3,-cap),np.zeros(4)]
            primal=max(float(np.max(aa@x-bb)),float(np.max(lb-x)),float(np.max(x[:3]-cap)));stationarity=float(np.max(np.abs(cc-aa.T@dy-dl-du)));gap=float(cc@x-(bb@dy+lb@dl+cap*np.sum(du[:3])));assert primal<=1e-7 and stationarity<=1e-7 and abs(gap)<=1e-7 and np.max(dy)<=1e-9 and np.min(dl)>=-1e-9 and np.max(du)<=1e-9 and np.max(np.abs(du[3:]))<=1e-9
            certs.append({'stage':stage,'primal':primal,'stationarity':stationarity,'gap':gap});first=x.copy() if stage==1 else first
        u=np.clip(np.asarray(-x[:3],dtype=np.float32),-.3,.3);assert np.array_equal(u,np.load(d/'UNEXECUTED_Native_u_Mvar.npy'));q=z['q0']-u;pred=z['vm']+s@(q-z['q0']);assert np.array_equal(q,np.asarray(r['proposed_absolute_q'])) and np.array_equal(pred,np.asarray(r['predicted_vm'])) and r['actual_nonlinear_next_state']=='UNKNOWN_UNEXECUTED'
        with (d/'UNEXECUTED_Candidate_NET.pkl').open('rb') as f:candidate=pickle.load(f)
        assert np.array_equal(q,candidate.sgen.q_mvar.to_numpy()[:3]);assert candidate.sgen.drop(columns=['q_mvar']).equals(net.sgen.drop(columns=['q_mvar'])) and np.array_equal(candidate.sgen.q_mvar.to_numpy()[3:],net.sgen.q_mvar.to_numpy()[3:])
        for name in ['bus','line','trafo','load','gen','ext_grid','shunt','switch']:assert net[name].equals(candidate[name])
        rows.append({'context':pos,'status':'PASS_AFFINE_ONLY','seed':r['seed'],'algorithm':r['algorithm'],'current_UV':r['current_UV'],'current_OV':r['current_OV'],'linear_minimax':r['optimal_linear_minimax'],'primal_dual':certs})
    costs=result['costs'];assert sum(e['kind']=='derivative_return' for e in events)==costs['public_derivative_returns'] and sum(e['kind']=='LP_return' for e in events)==costs['LP_returns']
    audit={'status':'PASS_INDEPENDENT_ALL_AVAILABLE_24_CONTEXT_SOURCE_DENSE_DERIVATIVE_RHS_LP_PRIMAL_DUAL_NATIVE_CAP_NORMAL_PROTECTION_AND_UNEXECUTED_CANDIDATE_AUDIT','scientific_status':result['status'],'contexts':rows,'primary_costs':costs,'new_derivative_factor_solve_LP_PF_model_GPU_calls_by_reader':0,'no_nonlinear_feasibility_impossibility_or_LLM_claim':True,'frozen_original_checks':frozen_checks(),'workflow_seconds':time.monotonic()-start};put(OUT/'Independent_Audit.json',audit);put(OUT/'Closed_Manifest.json',{'files':{f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.iterdir() if f.is_file()}});print('INDEPENDENT_ALL24_AFFINE_AUDIT_PASS',sum(r['status']=='PASS_AFFINE_ONLY' for r in rows))
if __name__=='__main__':main()
