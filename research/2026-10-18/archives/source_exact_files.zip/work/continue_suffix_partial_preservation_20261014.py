"""One mechanical after-audit handoff; waits on actual Windows process handles."""
import argparse,ctypes,hashlib,json,os,subprocess,sys,time,traceback
from ctypes import wintypes
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/full_joint_suffix_benchmark_20261014'
OUT=R/'outputs/full_suffix_partial_preservation_handoff_20261014'
SELF=Path(__file__).resolve();SEAL=R/'work/seal_full_suffix_partial_evidence_20261014.py'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):
    with p.open('x',encoding='utf8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def actual(pid):
    cmd=f"Get-CimInstance Win32_Process -Filter 'ProcessId = {int(pid)}' | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    q=subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',cmd],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert q.returncode==0,q.stderr
    return json.loads(q.stdout) if q.stdout.strip() else None
def open_handles():
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
    k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
    k.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)];k.GetProcessTimes.restype=wintypes.BOOL
    k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
    return k
def prepare():
    OUT.mkdir(exist_ok=False)
    assert read(B/'Completion.json')['science_exit']!=0
    targets=[]
    for pid,parent,flag in [(14248,21112,'--reader'),(24100,13832,'--run')]:
        row=actual(pid);assert row and row['ParentProcessId']==parent and 'conditional_full_suffix_prefix_audit_20261014.py' in row['CommandLine'] and flag in row['CommandLine']
        targets.append(row)
    prep=read(B/'Conditional_Archive_Preservation_Preparation.json')
    assert prep['source_sha256']==sha(SEAL) and prep['state']=='PREPARED_COMPILED_ONLY_NOT_EXECUTED'
    put(OUT/'Protocol.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'targets':targets,
      'handoff_source_sha256':sha(SELF),'sealer_source_sha256':sha(SEAL),
      'wait':'Windows handles bound to exact source/parent/command and creation FILETIME; no numerical-PID reuse wait/restart.',
      'activation':'Actual old reader/coordinator handles signaled; ended-chain ACKexit0, actual prefix auditPASS and all original sources absent via sealer gates.',
      'new_PF_model_optimizer_forecast_solve_calls':0,'exclusive_new_archive_output':'outputs/full_joint_suffix_benchmark_20261014/verified_partial_handoff',
      'no_old_reader_scientist_restart_or_budget_extension':True,'all_four_original_scientific_gate':'UNKNOWN'})
    print(json.dumps({'mechanical_handoff_prepared':True,'jobs_started':0}))
def archive_child():
    protocol=read(OUT/'Protocol.json');assert sha(SELF)==protocol['handoff_source_sha256'] and sha(SEAL)==protocol['sealer_source_sha256']
    claim={'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(SELF),'argv':sys.argv}
    put(OUT/'archive_child.claim',claim);begun=time.monotonic()
    while not (OUT/'Archive_Child_ACK.json').exists():
        assert time.monotonic()-begun<90;time.sleep(.2)
    ack=read(OUT/'Archive_Child_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_real_source_command']
    import seal_full_suffix_partial_evidence_20261014 as preserve
    preserve.main()
def handoff():
    protocol=read(OUT/'Protocol.json');assert sha(SELF)==protocol['handoff_source_sha256'] and sha(SEAL)==protocol['sealer_source_sha256']
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(SELF),'protocol_sha256':sha(OUT/'Protocol.json'),'argv':sys.argv})
    begun=time.monotonic();handles=[];k=open_handles();code=1
    try:
        bindings=[]
        for wanted in protocol['targets']:
            row=actual(wanted['ProcessId']);assert row==wanted,'Original bound process disappeared or identity changed; inspect terminal state, never restart'
            h=k.OpenProcess(0x100000|0x1000,False,row['ProcessId']);assert h,ctypes.get_last_error()
            handles.append(h)
            assert actual(row['ProcessId'])==wanted
            created,ended,kernel,user=(wintypes.FILETIME() for _ in range(4))
            assert k.GetProcessTimes(h,ctypes.byref(created),ctypes.byref(ended),ctypes.byref(kernel),ctypes.byref(user))
            bindings.append({'actual_identity':row,'creation_FILETIME':created.dwLowDateTime+(created.dwHighDateTime<<32),'real_OS_handle_bound':True})
        put(OUT/'Actual_Wait_Handle_Bindings.json',{'bindings':bindings,'fresh_exact_ownership_checked':True})
        for h in handles:
            while True:
                # This is an OS wait, not scientific/reader polling or a rerun.
                status=k.WaitForSingleObject(h,60000)
                if status==0:break
                assert status==258,('Actual OS process-handle wait failure',status,ctypes.get_last_error())
        done=read(B/'Partial_Reader_End_ACK.json');assert done['exit_code']==0 and done['actual_reader_chains_ended']
        assert read(B/'partial_audit_v1/Independent_Preserved_Prefix_Audit.json')['status']=='PASS_RECORDED_CLOSED_QUERY_COMMIT_CHECKPOINT_AND_COST_PREFIX_ONLY'
        assert not (B/'verified_partial_handoff').exists()
        with (OUT/'archive_console.log').open('x',encoding='utf8') as log:
            child=subprocess.Popen([sys.executable,'-X','utf8',str(SELF),'--archive-child'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            start=time.monotonic()
            while not (OUT/'archive_child.claim').exists():
                assert child.poll() is None and time.monotonic()-start<90;time.sleep(.2)
            claim=read(OUT/'archive_child.claim');row=actual(claim['actual_pid'])
            assert child.pid==claim['actual_pid'] and row and row['ParentProcessId']==os.getpid() and SELF.name in row['CommandLine'] and '--archive-child' in row['CommandLine']
            put(OUT/'Archive_Child_ACK.json',{'actual_pid':child.pid,'actual_parent_pid':os.getpid(),'fresh_real_source_command':True})
            rc=child.wait();put(OUT/'Archive_Child_End_ACK.json',{'exit_code':rc,'actual_pid':child.pid,'actual_child_handle_ended':True})
            assert rc==0,'Archive writer failed; preserve failure, no automatic retry'
        receipt=read(B/'verified_partial_handoff/Local_Archive_Audit.json')
        assert receipt['CRC_every_member_hash_and_manifest_passed']
        put(OUT/'Result.json',{'status':'PASS_ENDED_ACTUAL_READER_AND_EXCLUSIVE_STREAMING_PRESERVATION','exit_code':0,
          'all_four_original_gate':'UNKNOWN','archive':receipt,'new_PF_model_optimizer_calls':0,
          'handoff_wait_and_preservation_seconds':time.monotonic()-begun});code=0
    except BaseException as exc:
        put(OUT/'Failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),
          'new_PF_model_optimizer_calls':0,'automatic_retry':False});raise
    finally:
        for h in handles:k.CloseHandle(h)
        put(OUT/'Terminal_Exit.json',{'exit_code':code,'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'saved_at_utc':datetime.now(timezone.utc).isoformat(),'automatic_retry':False})
def run():
    assert not (OUT/'owner.claim').exists()
    with (OUT/'handoff_console.log').open('x',encoding='utf8') as log:
        child=subprocess.Popen([sys.executable,'-X','utf8',str(SELF),'--handoff'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        begun=time.monotonic()
        while not (OUT/'Actual_Wait_Handle_Bindings.json').exists():
            assert child.poll() is None and time.monotonic()-begun<90;time.sleep(.2)
        claim=read(OUT/'owner.claim');row=actual(child.pid)
        assert claim['actual_pid']==child.pid and row and row['ParentProcessId']==os.getpid() and SELF.name in row['CommandLine'] and '--handoff' in row['CommandLine']
        put(OUT/'Launcher_ACK.json',{'actual_pid':child.pid,'actual_parent_pid':os.getpid(),'fresh_real_source_command':True})
        rc=child.wait();put(OUT/'Completion.json',{'handoff_exit':rc,'all_owned_handoff_chains_ended':True,'actual_pid':child.pid,'new_PF_model_optimizer_calls':0})
    print(json.dumps({'handoff_exit':rc,'path':str(OUT)}))
if __name__=='__main__':
    p=argparse.ArgumentParser()
    for flag in ['prepare','run','handoff','archive-child']:p.add_argument('--'+flag,action='store_true')
    a=p.parse_args();assert sum(vars(a).values())==1
    if a.prepare:prepare()
    elif a.run:run()
    elif a.handoff:handoff()
    else:archive_child()
