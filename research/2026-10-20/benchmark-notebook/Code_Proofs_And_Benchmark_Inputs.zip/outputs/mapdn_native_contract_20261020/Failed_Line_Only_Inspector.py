"""Decode author table containers as data; no pickle callable/class is imported."""
import hashlib,json,pickletools,math
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'outputs/benchmark_priority_20261020/MAPDN'
OUT=ROOT/'outputs/mapdn_native_contract_20261020'

def data_decode(raw):
    stack=[];memo={};mark=object();dtype_symbol=object()
    def marked():
        i=max(i for i,v in enumerate(stack) if v is mark);values=stack[i+1:];del stack[i:];return values
    for op,arg,pos in pickletools.genops(raw):
        n=op.name
        if n=='PROTO':assert arg==2
        elif n=='EMPTY_DICT':stack.append({})
        elif n=='EMPTY_LIST':stack.append([])
        elif n=='MARK':stack.append(mark)
        elif n in ['BINUNICODE','BININT','BININT1','BININT2','BINFLOAT']:stack.append(arg)
        elif n=='NEWTRUE':stack.append(True)
        elif n=='NEWFALSE':stack.append(False)
        elif n=='NONE':stack.append(None)
        elif n in ['BINPUT','LONG_BINPUT']:memo[arg]=stack[-1]
        elif n in ['BINGET','LONG_BINGET']:stack.append(memo[arg])
        elif n=='APPENDS':v=marked();assert type(stack[-1]) is list;stack[-1].extend(v)
        elif n=='APPEND':v=stack.pop();assert type(stack[-1]) is list;stack[-1].append(v)
        elif n=='SETITEMS':
            v=marked();assert type(stack[-1]) is dict and len(v)%2==0
            for k,x in zip(v[::2],v[1::2]):assert isinstance(k,(str,int,float,tuple));stack[-1][k]=x
        elif n=='SETITEM':v=stack.pop();k=stack.pop();assert type(stack[-1]) is dict;stack[-1][k]=v
        elif n=='TUPLE':stack.append(tuple(marked()))
        elif n=='TUPLE3':v=tuple(stack[-3:]);del stack[-3:];stack.append(v)
        elif n=='GLOBAL':assert arg=='numpy dtype','Unexpected executable global';stack.append(dtype_symbol)
        elif n=='REDUCE':
            args=stack.pop();symbol=stack.pop();assert symbol is dtype_symbol and type(args) is tuple
            assert len(args)==3 and isinstance(args[0],str) and all(type(x) is bool for x in args[1:])
            stack.append({'symbolic_numpy_dtype':args[0],'flags':list(args[1:])})
        elif n=='BUILD':
            state=stack.pop();assert type(stack[-1]) is dict and 'symbolic_numpy_dtype' in stack[-1]
            assert type(state) is tuple;stack[-1]['state']=state
        elif n=='STOP':assert len(stack)==1 and pos==len(raw)-1;return stack[0]
        else:raise ValueError('Unsupported opcode '+n)
    raise ValueError('Missing STOP')

def table(data,name):
    value=data[name];assert isinstance(value,dict) and 'DF' in value
    frame=value['DF'];assert len(set(frame['columns']))==len(frame['columns'])
    assert len(frame['data'])==len(frame['index'])
    assert all(len(row)==len(frame['columns']) for row in frame['data'])
    return [dict(zip(frame['columns'],r),index=i) for i,r in zip(frame['index'],frame['data'])]
def main():
    OUT.mkdir(exist_ok=False)
    protocol={'all_networks':['case33_3min_final','case141_3min_final','case322_3min_final'],'scope':'All pinned static native input tables only, no time-series outcomes, environment step, model, PF or optimizer. Stored results are not summarized or performance-tested.','decoder':'Explicit data-opcode interpreter; numpy dtype represented symbolically, REDUCE/BUILD never invoked as Python functions. Reject every other global/opcode.','fixed_checks':['all bus/line/load/sgen/ext_grid/gen/storage/shunt table shapes','in-service native bus references','active native line connectivity from slack','all native inverter indices and zones','finite static native PV P/Q','source bus limits reported unchanged; environment operational limits remain separate'],'source_intake':'outputs/benchmark_priority_20261020/MAPDN/Static_Network_Intake_Results.json'}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    # Serialization mechanics checks and executable-global rejection, no third-party code.
    import pickle
    simple={'x':[1,True,None,2.5],'nested':{'k':'v'}}
    assert data_decode(pickle.dumps(simple,protocol=2))==simple
    for malicious in [b'\x80\x02cos\nsystem\n.',b'\x80\x02cbuiltins\neval\n.']:
        try:data_decode(malicious)
        except AssertionError:pass
        else:raise AssertionError('Executable global accepted')
    expected=json.loads((SOURCE/'Static_Network_Intake_Results.json').read_text(encoding='utf-8'))['files'];results=[]
    for row in expected:
        p=ROOT/row['local'];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
        data=data_decode(raw);native={k:table(data,k) for k in ['bus','line','load','sgen','ext_grid','gen','storage','shunt']}
        buses={x['index'] for x in native['bus']};assert len(buses)==len(native['bus'])
        violations=[]
        for name in ['line','load','sgen','ext_grid','gen','storage','shunt']:
            for item in native[name]:
                if item.get('in_service',True):
                    for field in ['bus','from_bus','to_bus']:
                        if field in item and item[field] not in buses:violations.append([name,item['index'],field])
        assert not violations
        adjacency={b:set() for b in buses}
        for x in native['line']:
            if x.get('in_service',True):adjacency[x['from_bus']].add(x['to_bus']);adjacency[x['to_bus']].add(x['from_bus'])
        slacks=[x['bus'] for x in native['ext_grid'] if x.get('in_service',True)];seen=set(slacks);todo=list(slacks)
        while todo:
            b=todo.pop()
            for c in adjacency[b]-seen:seen.add(c);todo.append(c)
        assert seen==buses,'Disconnected native line graph; transformer-aware diagnosis needed'
        inverters=[x for x in native['sgen'] if x.get('in_service',True)]
        assert all(math.isfinite(x[k]) for x in inverters for k in ['p_mw','q_mvar'])
        result={'network':p.stem,'input_sha256':row['sha256'],'counts':{k:len(v) for k,v in native.items()},'slack_buses':slacks,'all_bus_references_valid':True,'all_buses_line_connected_to_slack':True,
          'bus_zones':sorted({str(x['zone']) for x in native['bus']}),'bus_nominal_kV':sorted({x['vn_kv'] for x in native['bus']}),'stored_input_bus_min_limits':sorted({x.get('min_vm_pu') for x in native['bus']},key=str),'stored_input_bus_max_limits':sorted({x.get('max_vm_pu') for x in native['bus']},key=str),
          'inverters':[{'index':x['index'],'bus':x['bus'],'name':x.get('name'),'native_p_mw':x['p_mw'],'native_q_mvar':x['q_mvar'],'sn_mva':x.get('sn_mva')} for x in inverters],
          'nonempty_transformer_table':bool(data.get('trafo',{}).get('DF',{}).get('data',[])),'no_numerical_operating_point_feasibility_claim':True}
        results.append(result)
        (OUT/(p.stem+'_native_input_tables.json')).write_text(json.dumps(native,indent=2,allow_nan=True),encoding='utf-8')
    final={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'ALL3_NATIVE_STATIC_TABLE_CONTRACT_CHECKS_PASS','networks':results,'decoder_software_checks':3,'new_model_PF_optimizer_solver_calls':0,'all_time_series_rows_unread':True,'limitations':['Structural input validation only; native equations, operational feasible dispatch, dynamics, action adapter and policy performance still untested.','Static source bus-limit metadata and environment operational limits are different contracts; report both without silently replacing either.']}
    (OUT/'Results.json').write_text(json.dumps(final,indent=2),encoding='utf-8')
    print(json.dumps({'status':final['status'],'counts':[r['counts'] for r in results],'new_science_calls':0}))
if __name__=='__main__':main()
