"""Engineering-only runtime binding repair; old failure and sources retained."""
import sys
from pathlib import Path
import check_graph118_native_campaign_integration_20261028 as original
from graph118_native_campaign_core_20261028 import read,sha,R
O=R/'outputs/graph118_native_campaign_runtime_v2_20261028'
p=read(R/'outputs/graph118_native_campaign_runtime_v2_preparation_20261028/Protocol.json')
assert str(Path(sys.executable).resolve()).lower()==p['python'].lower()
for name,h in p['source_hashes'].items():assert sha(R/name)==h
import pandas,numpy,pandapower
assert [pandas.__version__,numpy.__version__,pandapower.__version__]==p['versions']
assert read(R/'outputs/graph118_native_campaign_integration_20261028/Failure.json')['new_PF_model_calls']==0
original.O=O
original.main()
