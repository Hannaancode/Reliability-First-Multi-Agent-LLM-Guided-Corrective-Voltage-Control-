def run_dff_alt(scenario, base_net, zones, v2):
    """
    Frozen no-LLM fallback-first branch.
    This does not call the LLM. It uses the same existing fallback candidate generator,
    verifier, scoring, action application, and PF execution from the runner.
    """
    scenario_id = scenario.get('scenario_id', scenario.get('id', 'unknown'))
    net = copy.deepcopy(base_net)
    net = v2.v0.apply_scenario_to_net(net, scenario, zones)
    conv, err = v2.v0.run_pf(net)
    if not conv:
        return {'method': 'no_llm_fallback_first', 'scenario_id': scenario_id, 'base_converged': False, 'stop_reason': 'base_fail', 'base_metrics': None, 'final_metrics': None, 'logs': [], 'executed_actions': [], 'counters': Counter()}
    base_metrics = runner.rescue.grid_metrics(net)
    result = {'method': 'no_llm_fallback_first', 'scenario_id': scenario_id, 'base_converged': True, 'base_metrics': base_metrics, 'final_metrics': None, 'logs': [], 'executed_actions': [], 'stop_reason': None, 'counters': Counter()}
    failed_sigs = set()
    for it in range(runner.MAX_ITERATIONS):
        current = runner.rescue.grid_metrics(net)
        print(f"    [No-LLM Iteration {it + 1}] Global UV: {current['uv_count']} | Vmin={current['vmin']:.4f} | Def={current['deficit_sum']:.5f}")
        if current['uv_count'] == 0:
            result['stop_reason'] = 'full_restoration'
            break
        zone_reports = {}
        for zone in sorted(zones.keys()):
            zone_reports[zone] = runner.rescue.extract_zone_state_full(net, zone, zones)
        fallback = runner.fallback_physics_candidates(net=net, zones=zones, zone_reports=zone_reports, llm_actions=[], failed_sigs=failed_sigs)
        result['counters']['fallback_tests'] += len(fallback)
        accepted = [c for c in fallback if c['verif']['accepted']]
        print(f'      🛟 No-LLM fallback tested {len(fallback)} candidates; accepted {len(accepted)}')
        result['logs'].append({'iteration': it + 1, 'source': 'no_llm_fallback_first', 'current_metrics': current, 'fallback_tests': len(fallback), 'accepted_fallback': len(accepted)})
        if not accepted:
            result['stop_reason'] = 'no_accepted_action'
            break
        best = _choose(accepted, it + 1)
        print(f"      ✅ Executing no_llm_fallback | action={best['action']} | score={runner.rescue.score_candidate(best)}")
        runner.rescue.apply_action(net, best['action'])
        conv, err = runner.rescue.r.run_pf(net)
        if not conv:
            result['stop_reason'] = f'execution_pf_failed: {err}'
            break
        post = runner.rescue.grid_metrics(net)
        result['executed_actions'].append({'iteration': it + 1, 'source': 'safety_fallback_physics_refinement', 'zone': best.get('zone'), 'action': best['action'], 'post_metrics': post})
    final_metrics = runner.rescue.grid_metrics(net)
    result['final_metrics'] = final_metrics
    if result['stop_reason'] is None:
        result['stop_reason'] = 'max_iterations_reached'
    result['uv_reduced'] = bool(final_metrics['uv_count'] < base_metrics['uv_count'])
    result['full_restoration'] = bool(final_metrics['uv_count'] == 0)
    result['vmin_improved'] = bool(final_metrics['vmin'] > base_metrics['vmin'] + 1e-09)
    result['deficit_reduced'] = bool(final_metrics['deficit_sum'] < base_metrics['deficit_sum'] - 1e-09)
    return result
