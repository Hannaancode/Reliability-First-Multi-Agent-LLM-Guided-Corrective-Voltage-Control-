"""Software-only boundary tests plus classification of preserved engineering output."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,copy
from inference_numerical_admission_gate_20261029 import check_saved_smoke_probe,adjudicate_existing_probe,fixed_synthetic_probe_spec
R=Path(__file__).resolve().parents[1];O=R/'outputs/inference_numerical_admission_20261029'
def main():
    assert not O.exists();tests=[]
    ok={'raw_text':'B','raw_forward_calls':1,'all_raw_logits_finite':True,'stopped_at_output_cap':False,'cold_input_ids_equal':True,'cold_output_token_ids_equal':True,'cold_weight_identity_equal':True}
    assert check_saved_smoke_probe(ok,'B')['pass'];tests.append('valid_synthetic_contract_passes')
    mutations={'raw_text':'!'*256,'raw_forward_calls':0,'all_raw_logits_finite':None,'stopped_at_output_cap':True,'cold_input_ids_equal':False,'cold_output_token_ids_equal':False,'cold_weight_identity_equal':False}
    for k,v in mutations.items():
        x=copy.deepcopy(ok);x[k]=v;assert not check_saved_smoke_probe(x,'B')['pass'];tests.append(k+'_rejects')
    x=copy.deepcopy(ok);x['all_raw_logits_finite']=False;assert not check_saved_smoke_probe(x,'B')['pass'];tests.append('explicit_nonfinite_rejects')
    existing=[]
    for arm in ['size05','size15','size3']:
        p=R/f'outputs/public_qa_execution_20261029/{arm}/study/Engineering_Warm.json';q=p.with_name('Engineering_Cold.json');a=json.loads(p.read_text());b=json.loads(q.read_text())
        existing.append({'arm':arm,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**adjudicate_existing_probe(a['new_token_ids'],a['new_token_ids']==b['new_token_ids'],None)})
    assert all(x['raw_logits_finite']=='UNKNOWN' and not x['numerical_admission'] for x in existing)
    assert existing[1]['degenerate_single_token_stream'];tests.append('preserved_cold_equality_does_not_establish_finite_logits')
    O.mkdir();spec=fixed_synthetic_probe_spec()
    (O/'Synthetic_Probe_Design.json').write_text(json.dumps(spec,indent=2)+'\n','utf-8')
    report={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS10_SOFTWARE_BOUNDARIES_AND_SAVED_PROBE_CLASSIFICATION','tests':tests,'existing_probes':existing,
        'gate_source_sha256':hashlib.sha256((R/'work/inference_numerical_admission_gate_20261029.py').read_bytes()).hexdigest(),
        'new_model_PF_training_GPU_calls':0,'launch_ready':False,
        'remaining':['Actual raw-logit observer tensor integration and failure-before-continuation tests.','Prospective one-off synthetic engineering source/input/runtime/precision/ownership/budget/preservation/reader contract.','Actual finite/cold gates before any new separately justified scientific method.'],
        'note':'No actual model forward was executed. The forward observer remains unverified with a real tensor/backend. Old450question outcomes are unchanged and must not be rerun as a rescue.'}
    assert len(tests)==10
    (O/'Software_And_Saved_Evidence_Check.json').write_text(json.dumps(report,indent=2)+'\n','utf-8')
    print(json.dumps({'status':report['status'],'new_model_calls':0,'launch_ready':False}))
if __name__=='__main__':main()
