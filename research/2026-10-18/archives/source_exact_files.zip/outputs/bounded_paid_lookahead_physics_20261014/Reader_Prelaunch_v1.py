"""Complete-only independent paid-tree/source/physics/cost replay reader; zero PF."""
import copy,hashlib,json,os,time
from pathlib import Path
import numpy as np
import pandapower as pp
from bounded_paid_lookahead_physics_20261014 import R,B,OLD,CACHE,read,sha,put,pins,canon,load_after,metrics,METHODS,common_accept
from operation_aware_paid_lookahead_v1 import Receipt,plan
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import load_endpoint,build_verifier,action
from project_paid_joint_successor_v1 import project
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible
from joint_admissibility_order_v1 import order_all_current_forecasts
from dynamic_actual_mask_guidance_v1 import current_inputs,identity
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks
from equal_operation_benchmark_v2 import decode_capsule
import full_joint_suffix_benchmark_20261014 as prior

def main():
    p=read(B/'Protocol.json');pins(p);result=read(B/'actual/Result.json');assert result['exit_code']==0
    manifest=read(B/'actual/Closed_Manifest.json');assert manifest['exit_code']==0
    for name,h in manifest['members'].items():assert sha(B/'actual'/name)==h,name
    out=B/'audit';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    prefix='0'*64;intents={};returns={};exceptions={};menus_event=0;PF_seconds=0.
    with (B/'actual/scientific.jsonl').open('rb') as stream,(B/'actual/capsules.bin').open('rb') as pack:
        for line in stream:
            e=json.loads(line);assert e['previous_sha256']==prefix and e['protocol_sha256']==sha(B/'Protocol.json')
            prefix=hashlib.sha256(line.rstrip(b'\n')).hexdigest();d=e['data']
            if e['event']=='PF_intent':assert d['kwargs']==p['solver_kwargs'];intents[d['identity']]=d
            elif e['event']=='PF_return':
                after=decode_capsule(pack,d['after'])['net'];assert prior.fields(after)==d['fields'] if after.converged else d['fields'] is None
                assert bool(after.converged)==d['converged'];returns[d['PF_id']]=d;PF_seconds+=d['seconds']
            elif e['event']=='PF_exception':decode_capsule(pack,d['after']);exceptions[d['PF_id']]=d;PF_seconds+=d['seconds']
            elif e['event']=='menu_declared':menus_event+=1
    costs=result['actual_new_costs']
    assert set(intents)==set(returns)|set(exceptions) and not set(returns)&set(exceptions)
    assert costs['PF_attempts']==len(intents)==costs['PF_returns']+costs['PF_exceptions']
    assert costs['PF_returns']==len(returns) and costs['PF_exceptions']==len(exceptions) and abs(costs['PF_seconds']-PF_seconds)<=1e-9
    assert costs['PF_attempts']<=144 and costs['new_model_calls']==costs['new_optimizer_steps']==0
    def blocked(*a,**k):raise AssertionError('External reader forbids new science')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,blocked)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    entries={e['world']:e for e in read(OLD/'preparation/Protocol.json')['current_endpoints']}
    cache=copy.deepcopy(read(CACHE/'Compatible_Paid_Receipt_Index.json')['cache']);checked=0;replay_count=0;summaries=[];actual_new_query_ids=set()
    with (B/'actual/capsules.bin').open('rb') as pack:
        for bi in range(1,9):
            branch=read(B/'actual'/f'Branch_{bi}.json');world=branch['world'];mode=branch['method']
            original,cursor,_=load_endpoint(entries[world]);domain=build_current_domain(original,cursor,runner=runner,zones=zones)
            nodes={branch['root']:{'net':original,'cursor':domain['expanded_cursor_for_separately_fixed_future_protocol']}}
            messages={(r['parent'],r['aid']):r for r in branch['query_messages']};assert len(messages)==len(branch['query_messages'])
            def ensure(handle):
                node=nodes[handle]
                if 'net' not in node:
                    parent=ensure(node['parent']);target=load_after(node['record']['after_reference'],pack)['net']
                    projected=project(parent['net'],target,parent['cursor'],node['row'],node['record'],runner=runner,zones=zones)
                    node.update(net=target,cursor=projected)
                return node
            def menu(parent,slots,k=None):
                node=ensure(parent);d=build_current_domain(node['net'],node['cursor'],runner=runner,zones=zones);node['cursor']=d['expanded_cursor_for_separately_fixed_future_protocol']
                rows=[r for r in d['all_declared_original9Q_ordinary_and_owned_joint_identities'] if (1 if r['kind']=='ordinary' else 2)<=slots]
                if k is not None:
                    inputs=current_inputs(node['net']);ident=identity(inputs)
                    with np.load(B/'actual/contexts'/(ident+'.npz'),allow_pickle=False) as f:c={key:f[key] for key in f.files}
                    for key in inputs:assert np.array_equal(inputs[key],c[key]),key
                    nr=c['nonref'];pq=c['actual_PQ'];Y=c['Y'];V=c['V'];diagV=np.diag(V);diagI=np.diag(Y@V);norm=np.diag(V/abs(V))
                    assert np.allclose(c['m'],diagV@np.conj(Y@norm)+np.conj(diagI)@norm,atol=1e-8,rtol=1e-12)
                    assert np.allclose(c['a'],1j*diagV@np.conj(diagI-Y@diagV),atol=1e-8,rtol=1e-12)
                    J=np.block([[c['a'].real[np.ix_(nr,nr)],c['m'].real[np.ix_(nr,pq)]],[c['a'].imag[np.ix_(pq,nr)],c['m'].imag[np.ix_(pq,pq)]]])
                    assert np.array_equal(J,c['J']) and np.max(abs(J@c['X']-c['B']))<=1e-8
                    S=np.zeros((118,118));S[pq,:]=c['X'][len(nr):,:];assert np.array_equal(S[c['mapping'],:],c['sensitivity'])
                    before=runner.rescue.grid_metrics(node['net']);guided=[]
                    for r in rows:
                        dv=r['q']*c['sensitivity'][:,r['receiver']]
                        if r['donor_bus'] is not None:dv=dv-r['q']*c['sensitivity'][:,r['donor_bus']]
                        vm=c['current_vm']+dv
                        if not np.isfinite(vm).all() or (vm<=0).any():f={'status':'UNKNOWN_NONPHYSICAL_LINEAR_FORECAST','score':[-999]*5}
                        else:
                            after={'uv_count':int((vm<.95).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum()),'vmin':float(vm.min()),'vmax':float(vm.max())}
                            f={'status':'FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE','after':after,
                                'score':[int(after['uv_count']==0),before['uv_count']-after['uv_count'],before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],-r['q']]}
                        guided.append({**r,'ordering_forecast':f})
                    ordered=order_all_current_forecasts(guided,before,node['cursor'])
                    rows=[{key:r[key] for key in ['kind','receiver','q','donor_index','donor_bus','universe_index']} for r in ordered if resource_eligible(r,node['cursor'])][:k]
                ids=[action_key(r) for r in rows];expected={'parent':parent,'slots':slots,'k':k,'ids':ids}
                assert expected in branch['menus'];node.setdefault('rows',{}).update({action_key(r):r for r in rows})
                return ids
            paidPF=0;paidSeconds=0.;queried=0
            def query(parent,aid):
                nonlocal checked,paidPF,paidSeconds,queried
                node=ensure(parent);row=node['rows'][aid];msg=messages[(parent,aid)];assert msg['row']==row
                record=msg['record'];key=point_key(node['net'],node['cursor'])+'|'+aid
                if 'actual_measured_receipt' in record:
                    measured=record['actual_measured_receipt'];assert key not in cache
                    if measured:
                        actual_new_query_ids.add(measured['PF_id']);intent=intents[measured['PF_id']]
                        _,actuate,_=build_verifier(runner.rescue,node['cursor']);expected=actuate(copy.deepcopy(node['net']),action(row))
                        observed_input=decode_capsule(pack,intent['before'])['net'];assert prior.signature(expected)==prior.signature(observed_input)
                        if measured['outcome']=='RETURNED':
                            target=decode_capsule(pack,measured['after'])['net']
                            def saved_result(test,**kwargs):
                                assert kwargs==p['solver_kwargs'] and prior.signature(test)==prior.signature(observed_input)
                                test.clear();test.update(copy.deepcopy(target));return None
                        else:
                            def saved_result(test,**kwargs):raise RuntimeError('Source-recorded native failure; no new PF')
                        old_backend=pp.runpp;pp.runpp=saved_result
                        try:v=prior.verdict(build_verifier(runner.rescue,node['cursor'])[0](node['net'],action(row)))
                        finally:pp.runpp=old_backend
                        assert v==record['verdict'];assert record['attributed_PF_calls']==1 and record['attributed_solver_seconds']==measured['seconds']
                    cache[key]=copy.deepcopy(record)
                elif key in cache:
                    old=cache[key]
                    for field in ['verdict','original_score','after_reference','attributed_PF_calls','attributed_solver_seconds']:assert old[field]==record[field]
                else:
                    assert not resource_eligible(row,node['cursor']) and record['attributed_PF_calls']==0
                    cache[key]=copy.deepcopy(record)
                expected_score=list(runner.rescue.score_candidate({'action':action(row),'verif':record['verdict']}))
                if record['attributed_PF_calls']:assert expected_score==record['original_score']
                accepted=common_accept(record);successor=parent+'/'+aid
                if accepted:nodes[successor]={'parent':parent,'row':row,'record':record}
                assert msg['successor']==(successor if accepted else None)
                paidPF+=record['attributed_PF_calls'];paidSeconds+=record['attributed_solver_seconds'];checked+=1;queried+=1
                return Receipt(parent,aid,True,accepted,1 if row['kind']=='ordinary' else 2,successor if accepted else None,
                    record['verdict']['after'] if accepted else None,tuple(record['original_score']) if accepted else None,
                    bool(record['attributed_PF_calls'] and record['after_reference'] is None))
            reconstructed=plan(branch['root'],runner.rescue.grid_metrics(original),cursor['remaining_original_device_operation_slots'],
                lambda parent,slots:menu(parent,slots),lambda parent,slots,k:menu(parent,slots,k),query,mode=mode)
            assert reconstructed==branch['plan'] and queried==len(branch['query_messages'])
            assert reconstructed['second_queries']<=16 and reconstructed['operations_limit']<=4
            assert paidPF==branch['attributed_costs']['attributed_query_PF_calls'] and abs(paidSeconds-branch['attributed_costs']['attributed_query_solver_seconds'])<=1e-9
            for replay in branch['selected_path_replays']:
                message=messages[(replay['parent'],replay['aid'])];target=ensure(message['successor'])['net'];m=replay['measured']
                actual=decode_capsule(pack,m['after'])['net'];assert actual.converged
                delta=max(abs(prior.fields(actual)[bus][key]-prior.fields(target)[bus][key]) for bus in prior.fields(target) for key in prior.fields(target)[bus])
                assert delta==replay['field_delta'] and delta<=1e-10 and actual.res_bus.vm_pu.max()<=1.05+1e-8
                replay_count+=1
            summaries.append({'world':world,'method':mode,'endpoint_UV':reconstructed['selected']['measured_leaf']['uv_count'] if reconstructed['selected'] else metrics(original)['uv_count'],
                'operations':reconstructed['selected']['operations'] if reconstructed['selected'] else 0})
    assert costs['new_query_PF_attempts']==len(actual_new_query_ids) and costs['continuous_replay_PF_attempts']==replay_count
    assert len(summaries)==8 and {(r['world'],r['method']) for r in summaries}=={(w,m) for w in p['all_four_worlds'] for m in METHODS}
    wins=losses=0
    for world in p['all_four_worlds']:
        values={r['method']:r['endpoint_UV'] for r in summaries if r['world']==world};wins+=int(values[METHODS[1]]<values[METHODS[0]]);losses+=int(values[METHODS[1]]>values[METHODS[0]])
    gate='PASS' if wins>=2 and losses==0 else 'FAIL'
    assert gate==result['fixed_opportunity_gate'] and wins==result['strict_UV_wins'] and losses==result['UV_losses']
    put(out/'Fresh_Audit_Frozen_Checks.json',frozen_checks());assert read(out/'Fresh_Audit_Frozen_Checks.json')['all_passed']
    put(out/'Independent_Bounded_Paid_Lookahead_Audit.json',{'status':'PASS_ALL8_SOURCE_INPUT_MENU_CAUSAL_CONTEXT_NATIVE_VERIFIER_PATH_FIELDS_RESOURCE_AND_COST_BRANCHES',
        'fixed_opportunity_gate':gate,'strict_UV_wins':wins,'UV_losses':losses,'all8_branches':summaries,
        'query_receipts_checked':checked,'independent_selected_path_replay_fields_checked':replay_count,
        'actual_new_costs':costs,'numerical_costs':result['numerical_costs'],'reader_workflow_seconds':time.perf_counter()-start,
        'new_PF_model_derivative_solve_forecast_calls_in_reader':0,
        'limits':'Conditional4-operation development screen with reused trained-model prefix; not complete episodes, wholeDSE or measured incremental LLM benefit. Feasibility outside queried paths remainsUNKNOWN.'})
    print(json.dumps({'independent_bounded_lookahead_audit':'PASS','fixed_gate':gate,'new_PF_model_calls':0}))
if __name__=='__main__':main()
