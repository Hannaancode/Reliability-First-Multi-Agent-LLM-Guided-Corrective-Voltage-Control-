"""Actual-input software boundary checks; fixture orderings, zero models/PF."""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
from frozen_physics_loader import load_stack,AUDIT
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import original_LOCAL_prior_branches,numerical_only_branches,validate_causal_universe,resource_eligible

R=Path(__file__).resolve().parents[1]
B=R/'outputs/original_local_paid_branch_broker_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def main():
    B.mkdir(exist_ok=False);_,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    checks=[];worlds=[]
    for e in read(OLD/'preparation/Protocol.json')['current_endpoints']:
        net,cursor,_=load_endpoint(e);domain=build_current_domain(net,cursor,runner=runner,zones=zones)
        rows=domain['all_declared_original9Q_ordinary_and_owned_joint_identities'];order=[r['universe_index'] for r in reversed(rows)]
        proposed={z:{'proposed_action':{'add_shunts_q_mvar':{str(buses[0]):25.}}} if buses else None
                  for z,buses in domain['original_LOCAL_allowed_per_zone'].items()}
        call=lambda data,d=domain:original_LOCAL_prior_branches(data,domain=d,ordering=order,
            normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)
        baseline=call(proposed);assert len(baseline['selected_branch_identities'])<=4
        assert all(resource_eligible(r,domain['expanded_cursor_for_separately_fixed_future_protocol']) for r in baseline['selected_branch_identities'])
        checks.append(e['world']+'|atmost4sourcevalidresourceeligiblebranches')
        changed=copy.deepcopy(domain);changed['unqueried_after_labels']={'fakebest':-999};changed['teacher_successors']={'fake':.99}
        got=original_LOCAL_prior_branches(proposed,domain=changed,ordering=order,
            normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)
        assert got==baseline;checks.append(e['world']+'|hiddenadminlabels_do_not_affectbroker')
        zero=copy.deepcopy(domain);zero['expanded_cursor_for_separately_fixed_future_protocol']['remaining_original_device_operation_slots']=0
        assert not original_LOCAL_prior_branches(proposed,domain=zero,ordering=order,
            normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)['selected_branch_identities']
        assert not numerical_only_branches(domain=zero,ordering=order)
        checks.append(e['world']+'|zero_operations_blocks_BOTH_controls')
        null=call({z:None for z in proposed});assert not null['selected_branch_identities']
        checks.append(e['world']+'|nulloutputs_no_numeric_fill_or_fabricatedquery')
        extras={z:{'proposed_action':{'add_shunts_q_mvar':{str(domain['original_LOCAL_allowed_per_zone'][z][0]):175.}}}
                    if domain['original_LOCAL_allowed_per_zone'][z] else None for z in proposed}
        rejected=call(extras);assert not rejected['selected_branch_identities']
        assert all(x['status'] in ('NEW_Q9_NOT_ELIGIBLE_ORIGINAL_PARSER_UNCHANGED','ORIGINAL_NORMALIZER_NULL_OR_INVALID_NO_QUERY') for x in rejected['reports'])
        checks.append(e['world']+'|original175_normalization_not_silently_changed_newQ9rejects')
        bad=copy.deepcopy(rows);bad[0]['actual_after_best_label']=1
        try:validate_causal_universe(bad,order,domain['expanded_cursor_for_separately_fixed_future_protocol'])
        except AssertionError:pass
        else:raise AssertionError('After label was accepted as numerical broker input')
        checks.append(e['world']+'|rowwhitelist_rejects_afterlabels')
        numerical=numerical_only_branches(domain=domain,ordering=order)
        assert len(numerical)==min(4,sum(resource_eligible(r,domain['expanded_cursor_for_separately_fixed_future_protocol']) for r in rows))
        checks.append(e['world']+'|numericalcontrol_has_identical_full_universe_and_resourcefilter')
        before=copy.deepcopy(cursor);assert cursor==before
        worlds.append({'world':e['world'],'fixture_selected':baseline,'fixture_numerical_selected':numerical,
            'ordering':'REVERSED_ID_SOFTWARE_FIXTURE_NOT_SCIENTIFIC_SCORE','real_model_or_physics_calls':0})
    assert len(checks)==28 and len(worlds)==4
    p={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL4_CURRENT_INPUT_BROKER_CAUSAL_SCOPE_BUDGET_UNIT_BOUNDARIES_SOFTWARE_ONLY',
       'checks':checks,'worlds':worlds,'new_model_PF_forecast_derivative_solve_calls':0,
       'source_sha256':{'work/original_local_paid_branch_broker_v1.py':sha(R/'work/original_local_paid_branch_broker_v1.py'),
                        'work/check_original_local_paid_branch_broker_20261014.py':sha(Path(__file__))},
       'model_role':'Original trained mandatoryLOCAL recipient/Q prior only; numericalbroker owns ordinary/donor variant, all legal resources/protection/toolqueries shared bycontrols.',
       'scientific_performance_and_novelty':'NOT_TESTED','actual_causal_numerical_ordering_integration':'NOT_YET_CONNECTED; current lists are labelledfixtures',
       'actual_model_input_token_weights_decoder_inference_inventory_loader_memory_cold_cost':'REQUIRED_BEFORE_ANY_MODEL_LAUNCH',
       'gate':'With fullsame-information/same-action evidence, exhaustive immediateargmax cannot be improved by a mereprior. Need separatelyfixed paidacquisition or supportedhorizon target, roleceiling/economic/support gates, equallyinformedstrongnumerical/trainedcontrols beforeperformance.'}
    put(B/'Verified_Original_LOCAL_Broker_Software_Checkpoint.json',p)
    entry={'event_id':'original_local_paid_branch_broker_software_20261014',
        'method':'Implemented bounded originaltrainedLOCAL recipient/Q prior brokerage through exactlyunchangedparser/zonevalidation, shared causal ordering and commonstock/cap/operation gate; checked28actual-input boundaries overALL4roots with labelledfixtureorderings.',
        'result':'SoftwarePASS; model/numericalcontrols sharefull sourceuniverse/resources. Null/invalid/175/zerooperations explicitly produce noquery, no inventedfill; unqueriedlabels rejected/ignored byinputwhitelists.0model/PF/forecast/derivative/solvecalls; no scientificordering or policyvalue assumed.',
        'improvements':'A concrete original-role acquisition component exists without askingthemodel toinventdonors or silently changinghistoricalformat/units; dataaccess and identicalactuator gates are reviewable forfuture attribution.',
        'limitations':'This is softwareonly. Fixtureordering not actual numerical guidance; no model loaded/generated or realquery/commit. Pureorderingcannotbeatcompleteimmediateargmax. Actualmodelidentity/causalcontext/coldmemory/cost/roleceiling/support/fullphysical controls required; noautomaticGPU or policy launch.',
        'decision':'Keep originalprivateformat-learningachievement, allstoppedpublicscreens and richcontextfailurepreserved. Connect only prospectivelysource-bound numericalguidance aftercurrentphysicsstudy and freeze a meaningful acquisition/horizon/economic gate before anymodel integration.',
        'sources':[str((B/'Verified_Original_LOCAL_Broker_Software_Checkpoint.json').relative_to(R)),
                   'work/original_local_paid_branch_broker_v1.py','work/check_original_local_paid_branch_broker_20261014.py']}
    ep=B/'Research_Progress_Entry.json';put(ep,entry)
    subprocess.run([sys.executable,str(R/'work/append_research_progress.py'),'--entry-json',str(ep)],check=True)
    print(json.dumps({'softwarechecks':len(checks),'actualroots':4,'model_PF_calls':0,'modelrole_ready_to_allocate':False}))

if __name__=='__main__':main()
