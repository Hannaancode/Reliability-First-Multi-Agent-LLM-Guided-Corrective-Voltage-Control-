"""Seal only new evidence; save exact next gates and seven-file licensed compact publication."""
import hashlib,json,shutil,zipfile
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import seal,frozen_checks
ROOT=Path(__file__).resolve().parents[1];HAND=ROOT/'outputs/native_benchmark_execution_handoff_20261020'
def read(rel):return json.loads((ROOT/rel).read_text(encoding='utf-8'))
def write(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    now=datetime.now(timezone.utc).isoformat()
    audit=read('outputs/native_inverter_linear_reference_20261020/independent_audit_v2/Independent_Audit.json')
    result=read('outputs/native_inverter_linear_reference_20261020/Result.json')
    serving=read('outputs/native_inverter_serving_preparation_v3_20261020/Results.json')
    serving_audit=read('outputs/native_inverter_serving_preparation_v3_20261020/independent_audit/Independent_Audit.json')
    assert audit['status'].startswith('PASS_') and audit['actual']['UV']==0 and audit['actual']['OV']==0
    assert serving_audit['status'].startswith('PASS_') and serving_audit['fixed4096_plus384_overflows']==6
    assert read('outputs/native_inverter_reader_metadata_coordination_v2_20261020/Completion.json')['all_owned_actors_ended']
    checkpoint=read('outputs/native_benchmark_execution_handoff_20261020/Checkpoint.json')
    shutil.copyfile(HAND/'Checkpoint.json',HAND/'Checkpoint_before_numerical.json')
    checkpoint['at_utc']=now
    checkpoint['native_numerical_reference']={'status':'COMPLETE_INDEPENDENT_DERIVATIVE_LP_DUAL_AND_PHYSICS_PASS','root_UV':108,'actual_UV':0,'actual_OV':0,'vmin':audit['actual']['vmin'],'vmax':audit['actual']['vmax'],'native_L1_plus_q_cost':audit['actual']['native_L1_plus_q_cost'],'all_numeric_replay_delta':audit['all_numeric_field_delta_max'],'same_native_inverter_caps':True,'primary_workflow_seconds':result['workflow_seconds'],'independent_reader_workflow_seconds':audit['workflow_seconds'],'new_PF_attempts_returns':[2,2],'public_derivatives':1,'LU_factorizations':1,'RHS_solves':38,'LP_solves':1,'root_PF_repeated':False,'original_reader_metadata_failure':'Ended before independentPF; preserved original claim/source/stderr. Additive reader uses physical root.sn_mva, asserts equals cached PPC baseMVA; all old science/checks unchanged. One previously unexecuted independent replay charged.','evidence':'outputs/native_inverter_linear_reference_20261020/independent_audit_v2/Independent_Audit.json','scope':'One source-bound native engineering point, centralized current-model numerical reference; TPA has distributed temporal/seasonal information. No equally informed aggregate method superiority, LLM benefit or unused confirmation claim.'}
    checkpoint['native_LLM_serving_input_gate']={'status':'FULL44_PACKET_SOURCE_TOKEN_UNITS_AUDIT_COMPLETE_FIXED4096_PLUS384_GATE_FAIL','roots':2,'packets':44,'prefix_token_range':serving['prefix_token_range'],'overflow_packets':6,'no_truncation_or_dropped_zones':True,'model_PF_GPU_calls':0,'explicit_new_actuator':'Instantaneous absolute signed native inverter Q, strict exact bus keys/caps or explicit abstain. Original shunt controller unchanged.','evidence':'outputs/native_inverter_serving_preparation_v3_20261020/independent_audit/Independent_Audit.json','prior_software_failures':'v1missing local pandapower before packet; v2Transformers5.5BatchEncoding serialization before completed gate. Both original outputs/source/diagnoses preserved. v3same44complete current inputs extracts explicit integer input_ids; no scientific retry.','serving_model_not_launched':True,'information_limit':'Current-only local interface lacks TPA temporal/global prototype inputs; not yet a full matched benchmark interface.'}
    checkpoint['this_turn_actual_science_totals'].update({'PF_attempts':7,'PF_returns':7,'PF_exceptions':0,'public_derivative_calls':1,'LU_factorizations':1,'RHS_solves':38,'LP_scientific_attempts_returns':[1,1],'pure_mock_software_LP_solves':3})
    checkpoint['scientific_model_GPU_jobs']='NONE; all named new scientific/reader/coordinator chains ended, input preparation and reader also ended'
    checkpoint['next']=[
        'G3/G2 first: freeze a genuine common evaluation role before our model public performance. Native TPA reference and centralized numerical zero are engineering points, not an aggregate comparison. Retain all120author identities and first failed action UNKNOWN.',
        'Native current-only inverter contract has6/44 full-prefix+384 overflows at4096. Stop this fixed4096 interface launch. No trimming/dropped zones. A separately named full-length protocol may use the observed5390maximum total requirement to justify a sufficient context before any model outcome; must recheck actual full-context loader/memory/cold/preservation with all44 retained, not a prompt or performance sweep.',
        'One first-root independent replay is still unexecuted. If those two input packets are used in new actual model engineering, prospectively bind this remaining reader/physics identity and charge it once; never repeat original root solve or failed model attempt.',
        'Bind original private adapter/tokenizer to exact available pinned public base10413c288cb9629acdf60b3e0229f3ba75efe413,537657394byte local checkpoint if a new justified inference protocol needs it; original historical base revision remains unrecovered, so disclose new pinned reproduction identity. No silent claim of exact paper replication.',
        'An LLM contribution hypothesis must explain value beyond the strong numerical zero and its measured costs. Full-known-model point has no UV headroom below zero. Equally informed numerical/architecture/pretraining ablations and genuinely unused confirmation remain required. No idle GPU allocation or automatic retraining.',
        'Publish own code, aggregate proofs, failures/costs/tasks with byte/lease checks. Raw third-party TPA tree/checkpoint(no inspected license), private notebooks/adapter/manuscript/credentials and large raw data stay local.'
    ]
    write(HAND/'Checkpoint.json',checkpoint);write(HAND/'Current_Resume.json',checkpoint)
    report=f'''# Native published-method benchmark execution

Saved {now}. Goal order: G3 published comparisons, G2 public testing, G1 complete UV reduction, G4 scale, G5 LLM superiority, G6 security. All six final goals remain OPEN.

| Fixed native engineering point: 322 buses, second author identity | Before UV | After UV | After OV | Evidence |
| --- | ---: | ---: | ---: | --- |
| Official pretrained TPA CPU compatibility reference |108|77|0|Fresh cold model exact; two primary plus two independent PF returns, every saved numeric replay delta0.|
| Centralized current-Jacobian LP, same native inverter Q limits |108|0|0|One derivative, one LU,38RHS solves, one LP, one new primary plus one independent PF; cached root not solved again. LP primal/dual and all replay fields independently pass.|

The numerical point reaches Vmin0.9657907025/Vmax1.0016155387, within the original voltage band. Its primary workflow10.609s and repaired independent reader9.437s include runtime/setup/solver/I/O; the original failed reader/setup and all preparation/old root costs remain separately paid. No intrinsic speed/whole-method efficiency or aggregate superiority claim. A numerical method with full Ybus/current state and a trained TPA with distributed temporal/seasonal input are different information roles. The new method has no LLM decision; these numbers do not prove LLM value.

The first scheduled author identity remains partial: one rootPF returned66UV and one TPA forward attempt executed a learned projection before a missed hard-coded CUDA ordinal failed. No action returned, no retry, no case dropped. Its preserved-input/source partial audit is complete, independent root physics replay still unexecuted. All120 author identities remain in the intended benchmark roster.

Before expensive LLM execution, two cheap gates now give concrete limits. All16000 original TRAIN rows were checked:12118 nonnull25–150Mvar shunt commands exceed all public native inverter caps, independently verified;3882 null commands remain legal. This is a finite-label unit mismatch, not universal LLM inability. A new explicit instantaneous signed-inverter contract was implemented. All44 first-two-root zonal packets/current fields/caps/token IDs were independently checked, prefix365–5006tokens. Six complete packets exceed4096 with384reserved output tokens. The fixed4096 launch therefore stops before model/GPU calls; no truncation or dropped zones. A separately justified full-length actual loader protocol is required.

Failures are preserved: first CUDA policy partial, zero-science legacy/setup/import failures; original numerical reader metadata lookup failed before any replay and was additively corrected; native packet import and BatchEncoding serialization failures were corrected only in new software output directories. No executed scientific call repeated. This turn actual totals:7PFattempts/7returns/0exceptions;3TPApolicyattempts/2returns;1derivative/1LU/38RHS/1scientificLP;0LLM/optimizer/backward/training/GPUallocations. Three mock LP fixtures and tokenizer/readers are software costs, not physics/learning evidence. All owners ended; no timer.

The next decisive requirement is a justified LLM mechanism and matched evaluation, not another ungrounded scale/format experiment. The known-model numerical zero leaves no UV headroom on this point. Preserve original DFF/DFF-ALT/unchanged DSE both individual branches/FULL BOTH costs on the original plant, all stopped/adverse/partial/UNKNOWN records and frozen assets. Full matched trajectories, full costs, attribution and unused confirmation remain necessary.
'''
    (HAND/'Results_And_Next_Decision.md').write_text(report,encoding='utf-8')
    write(HAND/'Frozen_After.json',frozen_checks())
    tasks_path=ROOT/'outputs/research_tasks_20261014/Tasks.json';tasks=read('outputs/research_tasks_20261014/Tasks.json');tasks['at_utc']=now
    for t in tasks['tasks']:
        if t['checklist_id'] in ['G3','G2']:
            t['status']='TPA77_VS_CENTRALIZED_NUMERICAL0_UV_NATIVE_ENGINEERING_INDEPENDENT_PASS_OUR_LLM_INTERFACE_NOT_READY'
            t['current_result']='Second ordered author322root108UV:publishedTPA77UV/0OV;centralizednative-capcurrent-JacobianLP0UV/0OV independentlyverified. FirstcasepartialretainedUNKNOWN. Not same-information/wholebenchmark/LLMsuperiority. ExplicitnativeLLMunit/parser/full44currentinputgatecomplete:6/44overflow4096+384;fixedinterface launchSTOPPEDbeforemodel.'
            t['next']=checkpoint['next'][0]+' '+checkpoint['next'][1]
            if t['checklist_id']=='G3' and not any(x['id']=='G3.2b' for x in t['subtasks']):
                t['subtasks'].append({'id':'G3.2b','completed':True,'description':'Execute one source-bound native-cap/current-Jacobian LP reference from cached solved state with independent derivative/LP optimality/nonlinear replay; disclose information differences.','evidence':checkpoint['native_numerical_reference']['evidence'],'verified_at_save':now})
    write(tasks_path,tasks)
    md=ROOT/'RESEARCH_TASKS.md';text=md.read_text(encoding='utf-8')
    md.write_text(f'''## Latest verified native numerical milestone — {now}

- [x] G3.2b: one native public322 engineering point108→0UV/0OV with exact native Q caps; derivative/LP primal-dual/full physical replay independently PASS. TPA left77UV on that point. Centralized numerical and distributed temporal-model information differ; no LLM/same-information/aggregate superiority claim.
- [x] All44 first-two-root native LLM current-input/token/unit packets independently checked. Six exceed4096+384, so that fixed interface launch stops; no model/GPU, no cropping or dropped zones.
- [ ] Full comparable public benchmark with our actual LLM/hybrid, strong controls, full costs and unused confirmation.

All six final goals OPEN. Exact continuation: outputs/native_benchmark_execution_handoff_20261020/Current_Resume.json. No owned jobs/GPU/timer.

'''+text,encoding='utf-8')
    header=f'''## Latest native zero-UV numerical engineering — {now}

Fixedsecondauthor322root108to0UV/0OV,current-JacobianLPwithsameTPAnativecaps,oneprimary+oneindependentPF/allfieldsdelta0;analyticderivative/LPprimaldual/ninefrozenPASS. TPAreferenceleft77UV. Informationrolesdiffer;noLLM/fullbenchmark/superiorityclaim. Firstcasepartial66UV/failedactionretainedUNKNOWN,noretry. NativeLLM44currentpackets/76inverterentries/tokenIDsindependentPASS,6completeprefixesoverflow4096+384;thatfixedlaunchSTOPPEDwithouttruncation/model/GPU. Thisturn7PFreturns/3TPAattempts2returns/1derivative1LU38RHS1LP;0LLMtrainingGPU. Originalreader/setup/softwarefailuresretained,allactorsENDED/notimers. All6goalsOPEN,G3/G2first. Exactresume outputs/native_benchmark_execution_handoff_20261020/Current_Resume.json. Noidleallocation,retune,oldrestartoraggregateclaim.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md']:
        p=ROOT/rel;p.write_text(header+p.read_text(encoding='utf-8'),encoding='utf-8')
    with (ROOT/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+report+'\n')
    # Seal new local artifacts only. Reuse prior archive certificates without rehashing old data/model ZIPs.
    prefixes=['tpa_checkpoint_loader_engineering','tpa_native_one_step','tpa_native_second_identity','tpa_native_legacy_import_readiness','tpa_native_wrapper_complete_readiness','original_teacher_native_action_units','native_inverter_linear_reference','native_inverter_reader_metadata','native_inverter_serving_preparation']
    folders=[p for p in (ROOT/'outputs').iterdir() if p.is_dir() and any(p.name.startswith(x) for x in prefixes) and p.name.endswith('20261020')]
    files={}
    for folder in folders:
        for f in folder.rglob('*'):
            if f.is_file() and '__pycache__' not in f.parts:files[f.relative_to(ROOT).as_posix()]=f
    own_sources=[]
    for f in (ROOT/'work').glob('*20261020.py'):
        if any(s in f.name for s in ['tpa_','native_inverter_','original_teacher_native_action_units','native_benchmark_']):own_sources.append(f);files[f.relative_to(ROOT).as_posix()]=f
    for n in ['Checkpoint.json','Results_And_Next_Decision.md','Frozen_After.json']:files['handoff/'+n]=HAND/n
    local=seal(HAND,files,'Native_Benchmark_New_Execution_Evidence.zip')
    pub=HAND/'publication';pub.mkdir(exist_ok=False)
    shutil.copyfile(ROOT/'RESEARCH_TASKS.md',pub/'RESEARCH_TASKS.md');shutil.copyfile(tasks_path,pub/'Tasks.json');shutil.copyfile(HAND/'Checkpoint.json',pub/'Checkpoint.json');shutil.copyfile(HAND/'Results_And_Next_Decision.md',pub/'Execution_Index.md')
    (pub/'DATA_ATTRIBUTION_AND_LICENSE.txt').write_text('TPA-for-AVC (KDD2024) author source commit6de14d2d4a9b907403aec8e35b8f21fb97c199fc: https://github.com/Canyizl/TPA-for-AVC . MAPDN current author commit6895f1f0630b112745a3f681d7685d454407f9cb: https://github.com/Future-Power-Networks/MAPDN . Installed scipy1.16.3/pandapower3.4.0. SciPy HiGHS LP primary documentation https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html . TPA inspected source tree has no LICENSE; raw TPA source/weights are NOT redistributed here. This compact pack contains our integration/verification code and aggregate source/hash/cost/failure proofs only. Original private notebooks/adapter/tokenizer/manuscript, credentials, full datasets/raw scientific tensors/NETs stay local. Not a complete raw backup or benchmark superiority claim.\n',encoding='utf-8')
    compact={f.relative_to(ROOT).as_posix():f for f in own_sources}
    # Only aggregate/new proof JSON and logs. Exclude full packets/observations/weights/tensors/private artifacts.
    allow={'Result.json','Results.json','Independent_Audit.json','Independent_Partial_Audit.json','Failure.json','Preparation_Diagnosis.json','Protocol.json','Execution_Protocol.json','Reader_Metadata_Repair_Protocol.json','Complete_CPU_Device_Port.json','Frozen_Before.json','Frozen_After.json','Local_Archive_Audit.json','Launcher_ACK.json','Completion.json','Input_Hashes.json','LP_Return.json','Legacy_Import_Proof.json','Seasonal_Preparation_Diagnosis.json'}
    for name,f in files.items():
        if f.name in allow and f.suffix=='.json':compact[name]=f
    manifest={n:{'bytes':f.stat().st_size,'sha256':sha(f)} for n,f in compact.items()};write(pub/'Pack_Member_Manifest.json',manifest)
    zpath=pub/'Own_Code_Proofs_Costs_And_Failures.zip'
    with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n,f in compact.items():z.write(f,n)
        z.write(pub/'Pack_Member_Manifest.json','Pack_Member_Manifest.json')
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None and len(z.namelist())==len(compact)+1==len(set(z.namelist()))
        for n,m in manifest.items():data=z.read(n);assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
    write(pub/'Pack_Audit.json',{'at_utc':now,'members':len(compact)+1,'bytes':zpath.stat().st_size,'sha256':sha(zpath),'CRC_every_member_SHA256':'PASS','contents':manifest,'raw_thirdparty_source_weight_private_notebook_model_credentials_exported':False,'local_new_evidence_archive':local})
    paths=[('research/RESEARCH_TASKS.md','RESEARCH_TASKS.md'),('research/Tasks.json','Tasks.json')]+[('research/2026-10-20/native-execution/'+f,f) for f in ['Execution_Index.md','Checkpoint.json','DATA_ATTRIBUTION_AND_LICENSE.txt','Pack_Audit.json','Own_Code_Proofs_Costs_And_Failures.zip']]
    write(pub/'Publication_Plan.json',{'previous_head':'c5db0b880aa81a702b73023267888d4349168db8','base_tree':'790924c04cb89bf3aab9187ab6ac2b4b00b61ef8','repository':'Hannaancode/Reliability-First-Multi-Agent-LLM-Guided-Corrective-Voltage-Control-','branch':'research-progress-20261018','files':[{'path':remote,'local':(pub/name).relative_to(ROOT).as_posix(),'bytes':(pub/name).stat().st_size,'sha256':sha(pub/name)} for remote,name in paths]})
    print(json.dumps({'saved':str(HAND),'local_archive':local,'publication_members':len(compact)+1,'publication_bytes':zpath.stat().st_size,'all6finalgoals':'OPEN','actual_new_PF_returns':7,'GPU_allocations':0}))
if __name__=='__main__':main()
