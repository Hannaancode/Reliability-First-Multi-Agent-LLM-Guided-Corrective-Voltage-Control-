"""Exact author class/function ASTs with headless imports and explicit modern converter binding."""
import ast,copy,hashlib,os,sys,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
AUTHOR=ROOT/'outputs/stable_ddpg_author_intake_20261020/author_reference'
sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
import candidate_process_runtime
import numpy as np
import pandas as pd
import pandapower as pp
import torch
import torch.nn as nn
import torch.nn.functional as F
from pandapower.converter.matpower.from_mpc import from_mpc

class NativePP:
    """Only the import name is rebound; native equations/arguments remain untouched."""
    def __init__(self):self.converter=types.SimpleNamespace(from_mpc=from_mpc);self.runpp=pp.runpp
    def __getattr__(self,name):return getattr(pp,name)

def definitions(path,names,globals_):
    original=ast.parse(path.read_text(encoding='utf-8'))
    nodes=[x for x in original.body if isinstance(x,(ast.ClassDef,ast.FunctionDef)) and x.name in names]
    assert set(x.name for x in nodes)==set(names)
    projected=ast.Module(body=nodes,type_ignores=[])
    assert all(ast.dump(x,include_attributes=False)==ast.dump(next(y for y in original.body if isinstance(y,(ast.ClassDef,ast.FunctionDef)) and y.name==x.name),include_attributes=False) for x in nodes)
    exec(compile(ast.fix_missing_locations(projected),str(path),'exec'),globals_)
    return {n:globals_[n] for n in names},{'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'exact_definition_ASTs':names,'training_test_global_code_imported_or_run':False,'function_or_class_body_changed':False}

def environment():
    proxy=NativePP()
    namespace={'np':np,'LA':np.linalg,'pp':proxy,'pd':pd,'gym':types.SimpleNamespace(Env=object),'copy':copy}
    env,proof=definitions(AUTHOR/'env_single_phase_13bus.py',['IEEE13bus','create_13bus'],namespace)
    # The parent gym.Env supplies no operations used by this author's local constructor/step/reset.
    # Its definition is unchanged and no physics or training behavior is mocked.
    previous=Path.cwd()
    try:os.chdir(AUTHOR);net=env['create_13bus']()
    finally:os.chdir(previous)
    return env['IEEE13bus'](net,np.array([2,7,9])),proxy,proof

def policy_classes():
    ns={'torch':torch,'nn':nn,'F':F,'np':np}
    return definitions(AUTHOR/'safeDDPG.py',['SafePolicyNetwork','PolicyNetwork','LinearPolicy'],ns)

def load_three(env,event=None):
    classes,proof=policy_classes();models={};summary=[]
    for algorithm,name in [('safe-ddpg','SafePolicyNetwork'),('linear','LinearPolicy'),('ddpg','PolicyNetwork')]:
        group=[]
        for agent in range(3):
            model=classes[name](env,1) if algorithm=='linear' else classes[name](env,1,1,100)
            path=AUTHOR/f'checkpoints/single-phase/13bus/{algorithm}/policy_net_checkpoint_a{agent}.pth'
            if event:event('checkpoint_load_attempt',algorithm=algorithm,agent=agent,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            state=torch.load(path,map_location='cpu',weights_only=True);model.load_state_dict(state,strict=True);model.eval()
            if event:event('checkpoint_load_return',algorithm=algorithm,agent=agent,strict=True)
            summary.append({'algorithm':algorithm,'agent':agent,'checkpoint':path.relative_to(AUTHOR).as_posix(),'keys':sorted(state),'tensors':sum(v.numel() for v in state.values()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()});group.append(model)
        models[algorithm]=group
    return models,summary,proof
