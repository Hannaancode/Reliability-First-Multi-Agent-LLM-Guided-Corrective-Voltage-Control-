"""Compile complete audited FIT only. Never fill partials, expose DEV or make model/PF calls."""
import json,pickle,sys,hashlib,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/native_fit_teacher_execution_20261020';OUT=ROOT/'outputs/native_fit_training_inputs_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def numeric(state,np):
    Y=np.zeros((13,13),dtype=complex)
    for i,j,re,im in state['network']['Ybus_pu_sparse_ij_real_imag']:Y[i,j]=complex(re,im)
    values=[float(state['network']['base_mva'])]+Y.real.reshape(-1).tolist()+Y.imag.reshape(-1).tolist()
    for k in ['Vm_pu','Va_degree','net_P_injection_mw','net_Q_injection_mvar']:values+=state['current_measurements'][k]
    values+=state['control']['current_Q_mvar']+[float(state['control']['remaining_operations'])]
    past=state['past_receipts'];assert len(past)<=2;past=[None]*(2-len(past))+past
    for r in past:values+=(r['voltage_magnitudes_pu'] if r else [0.]*13)
    for r in past:values+=(np.asarray(r['controlled_Q_mvar']).reshape(-1).tolist() if r else [0.]*3)
    values += [float(r is not None) for r in past]+state['control']['actuator_bus_ids']+[state['control']['maximum_absolute_increment_mvar']]+state['operating_rule']['whole_grid_voltage_band_pu']
    a=np.asarray(values,dtype=np.float64);assert a.shape==(435,) and np.isfinite(a).all();return a
def main():
    start=time.perf_counter();p=json.loads((SRC/'Result.json').read_text(encoding='utf-8'));audit=ROOT/'outputs/native_fit_teacher_independent_20261020/Independent_Audit.json';a=json.loads(audit.read_text(encoding='utf-8'));assert p['status']=='COMPLETE_DECLARED64_NATIVE_FIT_TEACHER_EPISODES' and a['primary_scientific_status']==p['status'] and a['status'].startswith('PASS_')
    supplement=json.loads((ROOT/'outputs/native_fit_cached_response_supplement_20261020/Independent_Cached_Response_Link_Audit.json').read_text(encoding='utf-8'));assert supplement['status'].startswith('PASS_ADDITIVE_ALL_CACHED')
    assert len(p['all_worlds'])==64 and not p['unentered_seeds'] and [w['seed'] for w in p['all_worlds']]==list(range(508,572)) and all(w['status'].startswith('COMPLETE') for w in p['all_worlds']);OUT.mkdir(exist_ok=False)
    import candidate_process_runtime
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np
    from transformers import AutoTokenizer
    from native_slm_causal_features_20261020 import make_text,check_keys
    tokenizers=[AutoTokenizer.from_pretrained(str(path),local_files_only=True,trust_remote_code=False) for path in [ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1',ROOT/'outputs/native_slm_causal_input_preparation_20261020/public_1_5B_tokenizer_copy']];rows=[];X=[];targets=[];Srows=[];Vrows=[];Qrows=[];weights=[];worlds=[];N=p['teacher_rows'];active=sum(bool(w['steps']) for w in p['all_worlds']);assert N and active
    for world in p['all_worlds']:
        for decision in world['steps']:
            d=ROOT/decision['directory'];model=np.load(d/'Current_Model.npz')
            with (d/'Current_ENV.pkl').open('rb') as f:env=pickle.load(f)
            with (d/'Full_Cursor_RNG_Registry.pkl').open('rb') as f:cursor=pickle.load(f)
            net=env['network'];step=decision['step']-1;past=[r for r in cursor['history'] if r['step']<step];text=make_text(net,model['Y'],2,past,step,100-step);begin=text.index('<|im_start|>user\n')+len('<|im_start|>user\n');end=text.index('\n<|im_end|>',begin);state=json.loads(text[begin:end]);state['control'].pop('own_actor_bus_id');state['control']['decision_scope']='joint_three_native_actuators';check_keys(state);text=text[:begin]+json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False)+text[end:];ids=[t(text,add_special_tokens=False)['input_ids'] for t in tokenizers];assert ids[0]==ids[1] and len(ids[0])<=4096,'No truncation/dropping: contextoverflow blocks this wholetrainingdataset'
            target=np.asarray(decision['committed_teacher_u'],dtype=np.float32);assert target.shape==(3,) and np.isfinite(target).all() and (np.abs(target)<=np.float32(.3)).all();weight=N/(active*len(world['steps']));rows.append({'input_text':text,'input_ids':ids[0],'attention_mask':[1]*len(ids[0]),'tokens':len(ids[0]),'label_not_forwarded':target.tolist(),'world_weight':weight,'metadata_not_forwarded':{'seed':world['seed'],'before_step':step,'decision_sha256':sha(d/'Decision.json'),'current_ENV_sha256':sha(d/'Current_ENV.pkl'),'guarded_teacher_accepted':decision['accepted']}});X.append(numeric(state,np));targets.append(target);Srows.append(model['S']);Vrows.append(model['vm']);Qrows.append(model['q']);weights.append(weight);worlds.append(world['seed'])
    assert len(rows)==N and abs(sum(weights)-N)<1e-7
    (OUT/'All_FIT_Complete_Causal_Inputs_And_Separated_Labels.json').write_text(json.dumps(rows,indent=2,allow_nan=False),encoding='utf-8');np.savez(OUT/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz',X=np.stack(X),target=np.stack(targets),weight=np.asarray(weights),world=np.asarray(worlds),S=np.stack(Srows),vm=np.stack(Vrows),current_Q=np.stack(Qrows))
    report={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL_COMPLETE_AUDITED_NATIVE_FIT_CAUSAL_FULL_PAIRED_TOKEN_INPUTS_SEPARATED_COMMITTED_LABELS_AND_SAME_INFORMATION_NUMERIC_FEATURES','declared_FIT_worlds':64,'active_decision_worlds':active,'root_already_safe_no_actor_call_worlds':64-active,'all_rows':N,'numeric_features':435,'minimum_tokens':min(r['tokens'] for r in rows),'maximum_tokens':max(r['tokens'] for r in rows),'zero_dropped_truncated_or_filled_rows':True,'teacher_guard_rejected_hold_labels':sum(not r['metadata_not_forwarded']['guarded_teacher_accepted'] for r in rows),'all_raw_source_behavior_and_failed_partial_records_retained':True,'equal_active_world_weights':'N/(number_of_active_FIT_worlds*world_decision_count); passivefullysafeFITworldsremainexplicit,noactorcallsrequired','DEV_confirmation_rows':0,'tokenizer_encodings':2*N,'model_PF_derivative_LU_LP_optimizer_GPU_calls':0,'current_dVm_dQ_used_only_for_loss_not_body_or_MLP_forward':True,'independent_teacher_audit_sha256':sha(audit),'all_inputs_sha256':sha(OUT/'All_FIT_Complete_Causal_Inputs_And_Separated_Labels.json'),'numeric_inputs_sha256':sha(OUT/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz'),'workflow_seconds':time.perf_counter()-start,'no_automatic_training_or_superiority':'Actualmodel/source/MLP/control/fullstate/ownership/economic/DEVgate protocol stillrequired.'}
    (OUT/'Readiness.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
if __name__=='__main__':main()
