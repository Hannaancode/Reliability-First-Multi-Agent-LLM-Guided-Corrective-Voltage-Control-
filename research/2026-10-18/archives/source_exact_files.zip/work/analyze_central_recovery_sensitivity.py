"""Supplementary family-level sensitivity to the two fresh-runtime recoveries.

Does not modify the frozen primary analysis or controller, select on outcomes,
or treat load levels/prompts as independent grids.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,statistics
root=Path('outputs');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
if not (root/'central_recovery_provenance.json').exists():
    print('RECOVERY_SENSITIVITY_WAITING_FOR_VERIFIED_INTEGRATION');raise SystemExit(0)
provenance=json.loads((root/'central_recovery_provenance.json').read_text());protocol=json.loads((root/'central_experiment_protocol.json').read_text());lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());expected={Path(n).stem:h for n,h in lock['scenario_file_sha256'].items()}
family=lambda sid:re.search(r'line_(\d+)_(MG\d+)$',sid).group(0)
affected={family(sid) for sid in provenance['recovery_case_ids']};assert len(affected)==2
groups={};paths=list((root/'central_matched_campaign/cases').glob('*.json'));assert {p.stem for p in paths}==set(expected)
for path in paths:
    record=json.loads(path.read_text());assert record['protocol']==protocol and record['scenario_sha256']==expected[path.stem]
    groups.setdefault(family(path.stem),[]).append(record)
assert len(groups)==31 and all(len(rows)==2 for rows in groups.values())
valid={name:rows for name,rows in groups.items() if all(r['paired_terminal_metrics_valid'] for r in rows)}
metrics=['uv_count','deficit_sum','wall_seconds','pf_attempts','llm_calls','input_tokens','output_tokens']
def summarize(group):
    values={m:[] for m in metrics}
    for rows in group.values():
        for metric in metrics:
            deltas=[]
            for r in rows:
                source=r['branches'] if metric in ['uv_count','deficit_sum'] else r['costs']
                def value(branch):return source[branch]['final_metrics'][metric] if metric in ['uv_count','deficit_sum'] else source[branch][metric]
                deltas.append(value('CENTRAL-VF')-value('HG-VF'))
            values[metric].append(statistics.mean(deltas))
    return {'complete_valid_outage_families':len(group),'case_count':2*len(group),'mean_CENTRAL_minus_ZONAL_by_family':{m:statistics.mean(v) if v else None for m,v in values.items()}}
without={name:rows for name,rows in valid.items() if name not in affected}
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'role':'Supplementary fresh-runtime timing sensitivity, not replacement primary analysis','recovery_case_ids':provenance['recovery_case_ids'],'affected_families_removed_at_both_loads':sorted(affected),'selection_rule':'Exclude exactly families containing the two missing outputs recovered on a fresh T4, using recovery provenance only; no outcome selection','all_complete_valid_families':summarize(valid),'excluding_both_recovery_families':summarize(without),'invalid_families_retained_in_primary_ledger':[name for name in groups if name not in valid],'case_source_hashes':{p.stem:sha(p) for p in paths},'scope':'Both branches remain paired within each case, same frozen environment and standard T4; GPU instance and first-resumed PF warmup may differ. Setup/transfer time is outside original per-branch timings. No confidence/equivalence/generalization claim from this descriptive sensitivity.'}
(root/'central_recovery_timing_sensitivity.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='case_source_hashes'},indent=2))
