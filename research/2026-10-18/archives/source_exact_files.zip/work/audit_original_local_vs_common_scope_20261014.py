"""Zero-call measurement of actual original LOCAL/common candidate domains."""
import hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
B = R/'outputs/original_local_common_scope_20261014'
OLD = R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
SERVING = R/'outputs/original_serving_joint_role_20261014'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def put(path, value):
    with path.open('x', encoding='utf8') as file:
        json.dump(value, file, indent=2); file.flush(); os.fsync(file.fileno())

def main():
    B.mkdir(exist_ok=False); protocol = read(OLD/'preparation/Protocol.json')
    cases = read(SERVING/'Actual_Original_Causal_Serving_Cases.json')['cases']
    serving_certificate = read(SERVING/'Independent_Serving_Role_Checkpoint.json')
    for name, h in serving_certificate['source_sha256'].items(): assert sha(R/name) == h
    worlds = []
    for entry in protocol['current_endpoints']:
        endpoint_path = R/entry['endpoint_record']; endpoint = read(endpoint_path)
        common = set(endpoint['native_common_AND_zone_buses']); rows = []
        corresponding = [case for case in cases if case['administrator_world_not_in_forward'] == entry['world']]
        assert len(corresponding) == 4
        local_union = set()
        for case in corresponding:
            allowed = set(case['candidate_buses']); local_union |= allowed
            rows.append({'zone': case['zone'], 'original_LOCAL_allowed_buses': sorted(allowed),
                'outside_common_buses': sorted(allowed-common), 'inside_common_buses': sorted(allowed & common),
                'causal_prompt_sha256': case['mandatory_utf8_sha256']})
        worlds.append({'world': entry['world'], 'common_native_buses': sorted(common),
            'original_all_LOCAL_union': sorted(local_union), 'source_defined_fair_joint_union': sorted(common | local_union),
            'additional_source_allowed_buses': sorted(local_union-common), 'additional_bus_count': len(local_union-common),
            'common_bus_count': len(common), 'matched_union_bus_count': len(common | local_union), 'zones': rows,
            'endpoint_record_sha256': sha(endpoint_path), 'physics_on_additional_buses': 'NOT_MEASURED_BY_THIS_AUDIT'})
    assert [w['additional_bus_count'] for w in worlds] == [17, 7, 11, 17]
    result = {'status': 'PASS_ACTUAL_SOURCE_BOUND_CANDIDATE_DOMAIN_DIFFERENCE_AUDIT',
        'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'worlds': worlds,
        'new_model_PF_optimizer_forecast_derivative_calls': 0,
        'finding': 'Original LOCAL allowed candidates include buses outside the common numerical fallback universe inALL4inspected states.',
        'implication': 'A future model joint policy cannot be fairly attributed against a numeric controller barred from these source-allowed buses. Give both the same source-derived union, or disclose/test the domain difference as a separate actuation/search-domain intervention.',
        'active_full_suffix_study': 'UNCHANGED. Both current no-model suffix arms use the same frozen common domain; that comparison remains valid within its stated scope.',
        'no_new_physical_gain_or_model_value_or_novelty_claim': True,
        'future_measurement_gate': 'Separately prospective exact identity/source/cost/preservation protocol; compare already-executed identity inventories before any genuinely unexecuted query. Never edit running scope, restart old science or select only advantageous buses/worlds.',
        'source_sha256': serving_certificate['source_sha256'],
        'serving_cases_sha256': sha(SERVING/'Actual_Original_Causal_Serving_Cases.json')}
    put(B/'Verified_Source_Domain_Difference.json', result)
    entry = {'event_id': 'original_LOCAL_common_action_scope_difference_verified_20261014',
        'method': 'CompareALL4actual current endpoints common numeric native scope with the actual original four-zone LOCAL allowed candidate lists; use bound original prompt/source cases, zero physics/model calls.',
        'result': 'Original LOCAL permits17/7/11/17additional buses outside the common numeric fallback domain across the four fixed inspected states. All source hashes and exact domain joins passed.',
        'improvements': 'Identified a concrete comparison confound before a model rollout: original LOCAL can expand the proposed action domain. Future attribution controls must have the same source-derived candidate union, not a smaller numeric search scope.',
        'limitations': 'This is actual input/source-domain evidence, not measured benefit on those buses, novel methodology, LLM contribution or unused confirmation. Active two no-model continuation arms already share their frozen domain and remain unchanged.',
        'decision': 'Keep live science immutable. Require the explicit equal-domain control in any future joint model benchmark; separately justify and inventory genuinely unexecuted additional-domain measurements without replaying prior science.',
        'sources': [str((B/'Verified_Source_Domain_Difference.json').relative_to(R)),
            str((SERVING/'Independent_Serving_Role_Checkpoint.json').relative_to(R)), 'work/audit_original_local_vs_common_scope_20261014.py']}
    put(B/'Research_Progress_Entry.json', entry)
    run = subprocess.run([str(R/'work/physics_env/Scripts/python.exe'), '-X', 'utf8', str(R/'work/append_research_progress.py'),
        '--entry-json', str(B/'Research_Progress_Entry.json')], capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    assert run.returncode == 0, run.stderr
    checkpoint_path = R/'outputs/critical_research_reset_20261010/Research_Resume_20261012.json'
    checkpoint = read(checkpoint_path); checkpoint['latest_original_LOCAL_common_scope_difference'] = str((B/'Verified_Source_Domain_Difference.json').relative_to(R))
    checkpoint['future_model_same_information_scope_gate'] = result['implication']
    with checkpoint_path.open('w', encoding='utf8') as file: json.dump(checkpoint, file, indent=2); file.flush(); os.fsync(file.fileno())
    print(json.dumps({'additional_LOCAL_buses': [w['additional_bus_count'] for w in worlds], 'new_scientific_calls': 0,
                      'comparison_confound_verified': True, 'live_scope_unchanged': True}))

if __name__ == '__main__': main()
