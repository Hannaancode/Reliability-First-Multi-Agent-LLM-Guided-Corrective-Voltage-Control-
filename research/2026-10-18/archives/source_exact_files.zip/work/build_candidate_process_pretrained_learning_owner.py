"""Control-only additive adaptation; no allocation or science execution."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
check=(ROOT/'work/candidate_process_remote_environment_check.py').read_text()
assert check.count('copied_body_integration_preparation')==1
(ROOT/'work/candidate_process_learning_environment_check.py').write_text(check.replace('copied_body_integration_preparation','pretrained_learning_preparation'))
source=(ROOT/'work/run_candidate_process_copied_body_colab.py').read_text()
replacements={
 'copied_body_integration_preparation':'pretrained_learning_preparation',
 'copied_body_integration_execution':'pretrained_learning_execution',
 'candidate_process_copied_body_integration_remote.py':'candidate_process_pretrained_learning_remote.py',
 'candidate_process_remote_environment_check.py':'candidate_process_learning_environment_check.py',
 'copied_body_integration_science':'pretrained_learning_science',
 "if event['event']!='optimizer_step_and_checkpoint_preserved':continue":"if event['event']!='epoch_checkpoint_preserved':continue",
 'p.wait(timeout=1200)':'p.wait(timeout=5100)',
 "'bound_seconds':1200":"'bound_seconds':5100",
 'pool.submit(execute,launch,1350)':'pool.submit(execute,launch,5250)',
 'while time.monotonic()-began<1350:':'while time.monotonic()-began<5250:',
 "['all_genuine_integration_gates_passed']":"['completed']",
 "session_name='hiergrid-copied-body-integration'":"session_name='hiergrid-dense-body-learning'",
 "stage='genuine_two_step_copied_body_integration'":"stage='fixed_frozen_and_copied_body_learning'"}
for old,new in replacements.items():assert old in source;source=source.replace(old,new)
ast.parse(source)
tree=ast.parse(source)
launch=next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='launch' for x in n.targets))
ast.parse(launch)
target=ROOT/'work/run_candidate_process_pretrained_learning_colab.py'
with target.open('x') as f:f.write(source)
print('NEW_TWO_ARM_OWNER_ENVIRONMENT_AND_LITERAL_LAUNCH_AST_PARSED')
