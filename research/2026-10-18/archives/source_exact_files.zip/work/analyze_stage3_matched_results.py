"""External, zero-inference/zero-PF evidence and cost audit after exact release."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import copy,hashlib,json,os
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack
from value_candidate_ordering import universe
from value_model_prefix_inputs import scoped_raw_proposals
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/llm_value_stage3_development';REMOTE=OUT/'staged/remote'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2)
def main():
    original_status=read(OUT/'gpu_execution_status.json')
    recovery_path=OUT/'gpu_launch_repair_v2_status.json'
    status=read(recovery_path) if recovery_path.exists() else original_status
    if recovery_path.exists():
        assert status['notebook_hash']==original_status['notebook_hash'] and status['allocation_requests']==0
        assert original_status['remote_stage_error_types']==['SyntaxError']
    assert status['runtime_released'] and status['scientific_driver_exit_code']==0
    assert status['stage']=='all_actual_stage3_artifacts_preserved_external_analysis_pending'
    with (OUT/'external_analysis.claim').open('x') as f:f.write(str(os.getpid()))
    protocol=read(OUT/'protocol.json');manifest=read(REMOTE/'manifest.json')
    for name,item in manifest.items():assert sha(REMOTE/name)==item['sha256'] and (REMOTE/name).stat().st_size==item['bytes']
    for name,digest in {**protocol['source_sha256'],**protocol['frozen_source_sha256']}.items():assert sha(ROOT/name.replace('\\','/'))==digest
    config=read(REMOTE/'config.json');assert config['protocol_sha256']==sha(OUT/'protocol.json') and config['driver_sha256']==protocol['source_sha256']['work/run_stage3_matched_remote.py']
    assert read(OUT/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
    assert config['actual_environment']==read(ROOT/'outputs/remote_frozen_environment.json')
    assert config['base_revision_verified']==read(ROOT/'outputs/matched_campaign_protocol.json')['base_revision']
    assert config['adapter_layers_enabled'] and all(l['enabled'] and not l['merged_adapters'] for l in config['adapter_layers_enabled'])
    assert config['adapter_layers_disabled'] and all(not l['enabled'] and not l['merged_adapters'] for l in config['adapter_layers_disabled'])
    base=pp.from_json(str(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    v2,runner,ref=load_stack();_,zones=v2.v0.load_metadata(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')
    def forbidden(*a,**kw):raise AssertionError('External byte/selection/cost audit must not call PF')
    pp.runpp=forbidden
    expected={c['scenario_id']+'__'+a for c in protocol['scenarios'] for a in protocol['arms']}
    trials={p.stem:read(p) for p in (REMOTE/'trajectories').glob('*.json')};assert trials.keys()==expected
    costs=[];acquisitions={};initial_generation_costs={}
    for path in (REMOTE/'initial_worlds').glob('*.json'):costs.append(read(path)['actual_preparation_costs'])
    for path in (REMOTE/'initial_acquisitions').glob('*.json'):
        acquisition=read(path);costs.append(acquisition['actual_global_costs'])
        if 'batch' in acquisition:
            batch=acquisition['batch'];assert batch['evidence_kind']=='live_model_pending_identity_audit' and acquisition['no_solver_entry_during_inference']
            assert 4<=batch['costs']['generation_entries']<=8
            for key in batch['costs']:assert abs(batch['costs'][key]-acquisition['actual_global_costs']['generation'][key])<1e-5
            digest=hashlib.sha256(json.dumps(batch,sort_keys=True).encode()).hexdigest()
            acquisitions[digest]=batch;initial_generation_costs[(acquisition['scenario_id'],batch['policy'])]=batch['costs']
    table=[];selection_checks=0;raw_scope_checks=0
    def oracle(tested,iteration,alt):
        valid=[t for t in tested if t['verification']['accepted']]
        ranked=sorted(valid,key=lambda t:runner.rescue.score_candidate({'action':t['action'],'verif':t['verification']}),reverse=True)
        distinct=[];seen=set()
        for row in ranked:
            signature=runner.action_signature(row['action'])
            if signature not in seen:distinct.append(row);seen.add(signature)
        return None if not distinct else distinct[1 if alt and iteration==1 and len(distinct)>1 else 0]['action']
    for trial,row in trials.items():
        assert row['trial_id']==trial and row['protocol_sha256']==sha(OUT/'protocol.json')
        case=next(c for c in protocol['scenarios'] if c['scenario_id']==row['scenario_id'])
        assert row['scenario_sha256']==case['sha256'] and row['base_network_preserved'] and row['genuine_new_live_inference_only']
        costs.append(row['actual_incremental_costs']);record=row['record'];metrics=None;actions=None
        inherited=None;policy=None;summary=None
        acquisition_policy={'LoRA_fresh_guarded':'zonal_LoRA_prefix','LoRA_held_initial_guarded':'zonal_LoRA_prefix',
                            'base_fresh_guarded':'zonal_base_prefix'}.get(row['arm'])
        if acquisition_policy is not None:inherited=initial_generation_costs.get((row['scenario_id'],acquisition_policy))
        if row['status']=='complete':
            assert row['failure'] is None and record['status']=='complete' and row['independent_replay']['passed']
            replay=row['independent_replay']['actual_independent_replay_costs']
            for k in ['PF_attempts','PF_returns','PF_exceptions']:assert replay[k]==row['actual_incremental_costs']['PF']['replay'][k]
            if 'original_function_result' in record:
                original=record['original_function_result'];metrics=original['final_metrics'];actions=original['executed_actions'];summary=ref.summarize_result(original)
                for k in ['PF_attempts','PF_returns','PF_exceptions']:assert record['actual_costs'][k]==row['actual_incremental_costs']['PF']['controller'][k]
                for group in original['logs']:
                    candidates=[t for t in record['actual_candidate_verifications'] if t['decision']==group['iteration']]
                    assert len(candidates)==group['fallback_tests']
                    executed=next((a for a in actions if a['iteration']==group['iteration']),None)
                    if executed is not None:
                        assert executed['action']==oracle(candidates,group['iteration'],record['branch']=='DFF-ALT');selection_checks+=1
            else:
                metrics=record['final_metrics'];actions=record['executed_actions'];policy=record['policy']
                budget=record['PF_budget']
                for k,b in [('PF_attempts','attempts'),('PF_returns','returns'),('PF_exceptions','exceptions')]:assert budget[b]==row['actual_incremental_costs']['PF']['controller'][k]
                assert budget['attempts']<=512 and len(record['decisions'])<=25
                for decision in record['decisions']:
                    truth=copy.deepcopy(base);vector=decision['before_vm_pu']
                    truth.res_bus=pd.DataFrame({'vm_pu':[v for v in vector.values()]},index=[int(b) for b in vector])
                    reports={z:runner.rescue.extract_zone_state_full(truth,z,zones) for z in sorted(zones)}
                    buses=runner.rescue.candidate_buses_from_state(truth,zones,reports,[])
                    allowed=universe(buses,runner.Q_SWEEP)
                    assert decision['candidate_universe']==[{'bus':c.bus,'q_mvar':c.q_mvar} for c in allowed]
                    assert decision['actual_candidate_PF_attempts']<=32
                    for candidate in decision['tested']:
                        if candidate['verification']['accepted']:assert candidate['verification']['after']['vmax']<=1.05+1e-8
                    assert decision['selected_action']==oracle(decision['tested'],decision['decision'],policy=='budgeted_DFF_ALT_guarded');selection_checks+=1
                    batch=decision['per_state_proposal_batch']
                    if batch is not None:
                        assert batch['observation_sha256']==decision['observation_sha256']
                        pools={z:[b for b in runner.get_zone_candidate_buses(truth,z,zones,reports[z]) if b in set(buses)] for z in sorted(zones)}
                        assert batch['zone_candidate_pools']==pools
                        if batch['evidence_kind']=='live_model_pending_identity_audit':
                            raw,_=scoped_raw_proposals(batch['query_records'],allowed,pools)
                            assert raw==batch['raw_prefix'] and batch['recovered_query_function_code_unchanged']
                        else:
                            assert batch['evidence_kind']=='cached_live_initial_acquisition' and batch['costs']['generation_entries']==0
                            acquired=acquisitions[batch['initial_acquisition_sha256']]
                            assert batch['query_records']==acquired['query_records']
                            assert batch['inherited_initial_acquisition_costs']==acquired['costs']
                            inherited=acquired['costs']
                            if decision['decision']==1:assert batch['observation_sha256']==acquired['observation_sha256']
                        raw_scope_checks+=1
                summary=ref.summarize_result({'method':row['arm'],'scenario_id':row['scenario_id'],
                    'base_metrics':record['initial_metrics'],'final_metrics':metrics,
                    'executed_actions':[{'source':row['arm'],'action':a} for a in actions]})
        data={'trial_id':trial,'scenario_id':row['scenario_id'],'arm':row['arm'],'status':row['status'],
              'metrics':metrics,'executed_actions':None if actions is None else len(actions),
              'total_committed_support_MVAr':None if actions is None else sum(abs(float(q)) for a in actions for q in (a.get('action',a)).get('add_shunts_q_mvar',{}).values()),
              'strict_UV_zero_and_normal_upper':None if metrics is None else metrics['uv_count']==0 and metrics['vmax']<=1.05+1e-8,
              'actual_incremental_costs':row['actual_incremental_costs'],'inherited_initial_generation_costs':inherited,
              'measured_workflow_wall_including_independent_audit_seconds':row['end_to_end_controller_and_audit_wall_seconds'],
              'summary_for_original_selector':summary,'initial_tokenization_wall_time_separately_available':False}
        table.append(data)
    summary=read(REMOTE/'summary.json')
    for key,value in summary['actual_global_model_costs'].items():assert abs(sum(c['generation'][key] for c in costs)-value)<1e-5,(key,value)
    for phase in summary['actual_global_PF_costs_by_phase']:
        for key,value in summary['actual_global_PF_costs_by_phase'][phase].items():assert abs(sum(c['PF'][phase][key] for c in costs)-value)<1e-5,(phase,key)
    portfolios=[]
    for case in protocol['scenarios']:
        for name,arms in protocol['predeclared_portfolios'].items():
            branches=[next(t for t in table if t['scenario_id']==case['scenario_id'] and t['arm']==arm) for arm in arms]
            valid=all(t['status']=='complete' for t in branches)
            chosen=None
            if valid:chosen=branches[1 if ref.choose_safety_envelope(*[t['summary_for_original_selector'] for t in branches])=='reflection_v2' else 0]
            portfolios.append({'scenario_id':case['scenario_id'],'portfolio':name,'both_branch_statuses':[t['status'] for t in branches],
              'valid':valid,'selected_arm':None if chosen is None else chosen['arm'],'selected_metrics':None if chosen is None else chosen['metrics'],
              'strict_UV_zero_and_normal_upper':None if chosen is None else chosen['strict_UV_zero_and_normal_upper'],
              'full_both_branch_controller_PF_attempts':sum(t['actual_incremental_costs']['PF']['controller']['PF_attempts'] for t in branches),
              'full_both_branch_actual_generations_plus_inherited_acquisition':sum(t['actual_incremental_costs']['generation']['generation_entries']+(0 if t['inherited_initial_generation_costs'] is None else t['inherited_initial_generation_costs']['generation_entries']) for t in branches),
              'full_both_branch_workflow_wall_seconds_excluding_initial_acquisition':sum(t['measured_workflow_wall_including_independent_audit_seconds'] for t in branches),
              'initial_acquisition_and_model_setup_wall_not_fully_separated_no_deployment_latency_superiority_claim':True,
              'original_selector_zero_handling_preserved':True})
    audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_actual_identity_source_manifest_selection_scope_and_cost_arithmetic_gates_passed':True,
      'exact_records':80,'complete_trajectories':sum(t['status']=='complete' for t in table),
      'failed_or_unexecuted_records':sum(t['status']!='complete' for t in table),'actual_selected_action_oracle_checks':selection_checks,
      'actual_raw_or_cached_scope_checks':raw_scope_checks,'actual_new_audit_model_calls':0,'actual_new_audit_PF_calls':0,
      'manifest_members_checked':len(manifest),'actual_global_model_costs':summary['actual_global_model_costs'],
      'actual_global_PF_costs_by_phase':summary['actual_global_PF_costs_by_phase'],
      'normal_band_and_UV_only_not_full_operational_feasibility':True,
      'cost_reporting_limit':'Initial acquisition tokenization wall time not separated by remote driver; report actual generation time and measured per-arm workflow/audit plus shared model load separately. No full deployment latency superiority claim from incomplete timing allocation.',
      'independent_confirmation_available':False,'LLM_superiority_established':False,'scope':protocol['scope']}
    write(OUT/'External_Identity_Action_and_Cost_Audit.json',audit);write(OUT/'Actual_Trajectory_Table.json',table);write(OUT/'Actual_Portfolio_Table.json',portfolios)
    lines=['# Matched full-trajectory development results','',protocol['scope'],'',
      'The primary deterministic comparator is literal original D-SE (DFF plus DFF-ALT with the original selector). All failed outcomes remain in the80-record denominator. This is development evidence, not independent confirmation.','',
      '| Case | Arm | Status | UV | Vmax | Joint voltage success | Controller PF | New generations |',
      '|---|---|---|---:|---:|---|---:|---:|']
    for t in table:
        m=t['metrics'];lines.append('| '+t['scenario_id']+' | '+t['arm']+' | '+t['status']+' | '+('—' if m is None else str(m['uv_count']))+' | '+('—' if m is None else f"{m['vmax']:.9f}")+' | '+str(t['strict_UV_zero_and_normal_upper'])+' | '+str(t['actual_incremental_costs']['PF']['controller']['PF_attempts'])+' | '+str(t['actual_incremental_costs']['generation']['generation_entries'])+' |')
    lines+=['',audit['cost_reporting_limit'],'','A guard-only or search-budget benefit is not attributable LLM value. Interpret fresh-vs-held, base and LLM-off comparisons on every case before designing a further method. No fresh holdout or thesis-superiority claim is made.']
    (OUT/'Results.md').write_text('\n'.join(lines),encoding='utf-8')
    write(OUT/'Analysis_Manifest.json',{name:{'sha256':sha(OUT/name),'bytes':(OUT/name).stat().st_size} for name in ['External_Identity_Action_and_Cost_Audit.json','Actual_Trajectory_Table.json','Actual_Portfolio_Table.json','Results.md']})
    print('STAGE3_EXTERNAL_ZERO_PF_ZERO_MODEL_AUDIT_AND_ACTUAL_RESULTS_SAVED')
if __name__=='__main__':main()
