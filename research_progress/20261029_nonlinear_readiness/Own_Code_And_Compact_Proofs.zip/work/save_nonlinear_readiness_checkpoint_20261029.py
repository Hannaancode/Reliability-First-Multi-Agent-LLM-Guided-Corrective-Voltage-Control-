from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear_research_checkpoint_20261029'
def read(p):return json.loads((R/p).read_text(encoding='utf-8'))
def put(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    primary=read('outputs/nonlinear13_first_proposal_execution_20261029/Result.json')
    audit=read('outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json')
    assert primary['status']=='COMPLETE_FIRST_NUMERICAL_PROPOSAL_ONLY' and audit['status'].startswith('PASS')
    assert read('outputs/nonlinear13_first_proposal_handoff_20261029/Completion.json')['status']=='FIRST_NUMERICAL_PROPOSAL_AND_SAVED_READER_TERMINAL'
    ends=[read(p) for p in ['outputs/nonlinear13_first_proposal_coordination_20261029/End_ACK.json','outputs/nonlinear13_first_proposal_reader_coordination_20261029/End_ACK.json']]
    assert all(x['actual_owned_chain_ended'] and x['exit_code']==0 for x in ends)
    sources=['outputs/research_resumption_20261028/Current_Resume.json','outputs/research_resumption_20261028/Next_Exact_Work_20261029.json','outputs/research_tasks_20261014/Tasks.json']
    for i,p in enumerate(sources):shutil.copy2(R/p,O/f'Previous_{i}_{Path(p).name}')
    resume=read(sources[0]);resume.update(at_utc=now,status='ACTUAL_NEW_NONLINEAR_FIRST_PROPOSAL_INDEPENDENTLY_CLOSED_FULL_COHORT_STILL_OPEN',
      usage_observation='Latest direct usage check87percent consumed/13percent remaining in account10080minute window. No time or reset guarantee.',
      latest_exact_execution_state='outputs/nonlinear_research_checkpoint_20261029/Exact_Resume.json',
      nonlinear_first_proposal=dict(primary='outputs/nonlinear13_first_proposal_execution_20261029/Result.json',independent='outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json',
        status='COMPLETE_ADMITTED_FIRST_NUMERICAL_PROPOSAL_ONLY',actual_optimizer_returns=2,native_SLSQP_calls=18,
        all70_calculation_returns_verified=True,max_algebra_difference=audit['max_algebra_difference'],actual_control_commits=0,
        model_PF_GPU_calls=0,first_seed0_proposal_must_be_reused_not_rerun=True),
      nonlinear_readiness='All500 initial inputbindings independentlyPASS; equations/Jacobians/wrapper/mockpreservation gatesPASS; firstactual2stageproposalPASS. Full receding worker/current-state continuoushistory/cost/clock/cache/replay integration still missing.',
      nonlinear_initial_input_evidence='outputs/nonlinear500_input_binding_independent_20261029/Independent_Audit.json',
      nonlinear_current_state_limits='outputs/nonlinear13_current_state_independent_review_20261029/Independent_Review.json',
      paid_history_registry='outputs/nonlinear500_paid_registry_20261029/Result.json',paid_history_review='outputs/nonlinear500_paid_registry_independent_20261029/Independent_Review.json',
      paid_lookup_source='work/nonlinear500_paid_lookup_v2_20261029.py',
      first_saved_physics_join='outputs/nonlinear13_first_proposal_paid_join_v2_20261029/Result.json',
      first_saved_physics_join_limits='Exact already-paid firstaction,12UVto12UV/0OV,guardPASS,predictionerror2.7034293692551614e-9. No new physics,actualcommit,trajectory or restorationgain.',
      common118_DFF_history='outputs/common118_history_recovery_20261029/Result.json',
      common118_history_limits='All33 DFFselected-action prefixes recovered29commits; internalcandidate rejectionsunknown29states, futurelearnedactorhistoriesunknown. No newlearnedpolicyadmission.',
      current_LLM_readiness='Causal LLM goal remains unachieved. No new model study ready; common118 environment/reward/splits/actor versusqueryhistory/controls/source and loader gates remain.',
      owned_scientific_jobs=[],GPU_assignments=[],waiting_timer=None,new_work_publication='LOCAL_PENDING_NEW_COMPACT_PUBLICATION',
      next_ordered_actions=[
        'Implement the single fixed all500 receding nonlinear controller using unchanged real-testedv3recipe. Reuse paid seed0 step1math and exact physics; do not repeat either. Preserve all500 sourceorder,100rounds,threeactuators/float32cap and originalguard.',
        'Integrate current-state adapter with per-step receipt/before/candidate/commit/guard joins, paid/attempt/math/cost journal reconstruction, owner-authenticated deadline and stop checks, and numeric costs plus explicit UNKNOWN internalfactor counts. Initialinput readiness is not fullpolicy readiness.',
        'Freeze actual owner/fullstate/first independent physicalreader and resourcebound before any new physical campaign. Paidregistry11355keys includes1blocked missingafterNET; any missing key is only a scoped miss, not universal absence/automatic PFpermission.',
        'For G3/G5 common118, use complete DFFactorhistories only for their actual scope. Future learnedpolicy histories must be generated by the actual new actor; never treat numerical candidate queries as actions.',
        'Keep27/35 thesisclosures and all6finalgoalsOPEN. Do not invent two main or30checklist completions. Current thesis and strict/common-tolerance results unchanged.'
      ])
    put(O/'Exact_Resume.json',resume)
    for p in sources[:2]:put(R/p,resume)
    master=read(sources[2]);by={x['checklist_id']:x for x in master['tasks']}
    for goal,sid,text,proof in [
      ('G1','G1.nonlinear500_bound_20261029','Independently bind all500 initial nonlinear inputs; zero physics/optimizer/model calls in binding.','outputs/nonlinear500_input_binding_independent_20261029/Independent_Audit.json'),
      ('G1','G1.first_nonlinear_proposal_20261029','Complete exactly one source-order numerical proposal, two actual fixed optimizer stages, first saved-output audit. No physical outcome or fullpolicy performance claimed.','outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json'),
      ('G3','G3.DFF_actor_history_20261029','Recover29 actual DFFselected actions across33 savedprefixes, distinct from rejected numerical queries. Futurelearnedactorhistory remainsunknown.','outputs/common118_history_recovery_20261029/Result.json')]:
        a=by[goal].setdefault('subtasks',[]);assert not any(x['id']==sid for x in a);a.append(dict(id=sid,completed=True,description=text,evidence=proof,verified_at_save=now))
    assert all(not x['completed'] for x in master['tasks'])
    master.update(updated_at_utc=now,latest_verified_resume='outputs/nonlinear_research_checkpoint_20261029/Exact_Resume.json',current_owned_jobs=[],current_GPU_assignments=[],new_work_publication_status='LOCAL_PENDING_NEW_COMPACT_PUBLICATION')
    put(R/sources[2],master)
    header=f'## First actual nonlinear proposal closed â€” {now}\n\nAll500 initialinput bindings independentlyPASS. One fixed source-orderseed0 proposal completed2actualSLSQPstages/18nativecalls; independent reader checked70savedcalculations, maxdifference7.106e-15. Both owners/coordinator endedexit0.0PF/model/GPU/actualcommits. Exactoldphysicsjoin firstaction12to12UV/0OV,guardPASS; predictionerror2.703e-9 is scoped modelconsistency, not restoration improvement. Full receding500worker/state/history/cost/owner/reader integration remainsopen; NEVER rerun paid firstproposal or oldPF. Paidregistry11355keys/11354reuse/1blocked; scopedhistory only. DFF29selectedactionhistories complete across33prefixes; futurelearnedhistoriesunknown.27/35thesisrequirements; all6finalgoalsOPEN. No ownedjob/GPU/timer. Exactresume:outputs/nonlinear_research_checkpoint_20261029/Exact_Resume.json. Newcompactpublicationpending.\n\n'
    for name in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/name;p.write_text(header+p.read_text(encoding='utf-8'),encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+header+'Before: prepared nonlinear equations but no actualsolver. After: actual source-bound two-stage solver and saved-output replay passed; one exact existing physics join confirms prediction within2.703e-9 but does not reduce12UV afterthisfirstaction. All optimizer/equation/derivative/native-call costs retained; nativeinternalfactor/solve countsUNKNOWN. First data-only join deepcopyfailure retained and fixedadditively beforeanylookup/science. Original264/415-era comparisons not altered; strictnumerical264/common415remain. Userusage13percentatlastcheck; save/resume prevents duplication.\n')
    print(json.dumps(dict(saved=True,actual_optimizer_returns=2,new_PF=0,main_goals_open=6,thesis_complete=27)))
if __name__=='__main__':main()
