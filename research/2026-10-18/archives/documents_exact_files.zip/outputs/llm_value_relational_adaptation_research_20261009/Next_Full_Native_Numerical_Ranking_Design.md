# Strong native ranking prerequisite

This is an implementation and measurement design, not a ready experiment owner, an LLM method, or a claim of novelty. The original literal D-SE portfolio, frozen assets, prior failed branches and all partial costs remain preserved.

The independently audited saved-only inventory found 2,673 reversed quality preferences across 103 OPT states/22 worlds/three families. The old AC prior includes a recorded best action in K4 on74/176 oracle states and misses it on102 states/21 worlds. These are errors of the older prior. The newer source-latched control has not been ranked over the full native action universe; its single-action accuracy could remove this apparent headroom. Existing11,884 preference pairs were already used by the failed relational intervention. They are neither new labels nor independent samples.

## Fixed numerical scope

Use all239 exact OPT inputs/23 worlds and both old-admittance and candidate-admittance derivative variants. Keep187 target states/30,510 measured unique actions,52 unlabelled inputs, original invalid TRAIN view, missing ledgers, out-cap labels and unknown convergence. Do not inspect held outcomes to design or select this control. Input fields are the exact current physical observations plus original Q grid and cumulative support. Scenario/branch IDs and AFTER/targets stay outside the numerical prediction function.

The raw common AND zone union, nine original Q levels, cumulative450MVAr limit, original finite score/tie order and normal-upper1.05+1e-8 mediation are unchanged. There are38,501 native allowed actions per variant, hence77,002 declared prediction records. All216 previously committed state/action pairs match this universe. Reuse431 original preserved finite arm forecasts exactly; retain the one lost original old-Y forecast as UNKNOWN without recreating it. Only76,570 other arm records may require new numerical forecasts. Do not silently rerun the old calls for a tidier table.

Reuse193 existing source-bound currentY/V arrays.46 genuinely missing current states require new current-only converter/matrix derivations;176 of187 target states already have arrays. These new derivations are not new power-flow calls or regenerated missing original assets. All conversions, derivatives, factorizations, RHS solves, equation checks, storage, hashes and failures must be charged. Previously paid physics/AC data are reused with their costs disclosed separately.

## Efficient algebra and readiness

The new prototype caches one old-Y LU factorization per exact current state/generator mask. The capacitive candidate derivative changes one Q/Vm diagonal entry; Sherman–Morrison reuses the factorization. This is standard numerical algebra, not an LLM contribution.24 fabricated equation fixtures agree with direct references within4.28e-15; a singular update is rejected with no fallback. A separate saved-equation audit verified631 same-mask comparisons across215 available cases, with maximum matrix difference6.84e-14 and equation residual1.29e-14. The unavailable original case remains explicitly unknown.

These checks do not establish bit-identical floating-point branch or ranking choices. Before performance, implement strict input/action boundaries, source-locked cache reuse, the single bounded owner, small indexed equation files and an independent result reader. The reader must reconstruct every available mask/update/equation/score and reject altered state, action, scope, mask, solution and cost records. If machine-precision differences cause strict branch disagreement, preserve it as a measured limitation; do not tune a tolerance to force equality.

Freeze the complete driver/reader/protocol/import closure and exact identities before any new forecast. One numerical owner, at most one reader after it ends, no duplicate writers, no retries of completed/partial numerical calls. A prospective wall bound must be justified by actual implementation timing; fabricated fixture time is not a deployment estimate. No GPU allocation is needed for this stage.

## Decision after audited rankings

Report K1/4/8 recorded-best inclusion, all23 world denominators, accepted/rejected/unmeasured shortlist fractions, all preference score ties/reversals, both derivative variants and every failed/unknown record. Recorded best is conditional on measured candidates, not a global optimum over unmeasured choices. The single lost forecast stays in the denominator.

Only remaining errors against the strongest complete native numerical ranking can motivate a separately prospective language-policy correction hypothesis. Any such proposal needs strong same-information numerical preference learning, a frozen-reference/no-internal-update arm, capacity/pretraining controls, fixed initialization/decoder/objective/seed/budget/final checkpoint, full costs and an actual integration gate. Grid physics-feedback DPO and residual policy learning already exist; combining them does not itself establish novelty. Do not automatically train when this numerical study ends.

Saved-label ranking is a development gate. Actual D-SE superiority still requires fresh per-state learned inference, common protection and raw scopes, matched physical trajectories, complete both-branch D-SE and model/preparation/solver/failure costs, independent continuous replay and genuinely unused authorized confirmation. Overall superiority and full security remain unachieved.
