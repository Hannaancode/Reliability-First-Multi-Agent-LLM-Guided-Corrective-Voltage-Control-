"""Index already-paid bounded receipts and forecasts for faithful warm integration.

No scientific calculations/old owners are repeated. New receding runtime will
use the frozen native solver only on genuinely unexecuted point/action pairs.
"""
import copy,hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/receding_warm_dependency_closure_20261015'
OLD=R/'outputs/operation_aware_lookahead_input_cache_20261014'
PAID=R/'outputs/bounded_paid_lookahead_physics_20261014'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    B.mkdir(exist_ok=False);start=time.perf_counter()
    assert read(PAID/'verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json')['fixed_opportunity_gate']=='PASS'
    index=read(OLD/'Compatible_Paid_Receipt_Index.json');cache=copy.deepcopy(index['cache']);intents={};forecasts={};prefix='0'*64
    with (PAID/'actual/scientific.jsonl').open('rb') as stream:
        for line in stream:
            e=json.loads(line);assert e['previous_sha256']==prefix;prefix=hashlib.sha256(line.rstrip(b'\n')).hexdigest()
            if e['event']=='PF_intent' and e['data']['context']['phase']=='NEW_PRIMARY_QUERY':intents[e['data']['identity']]=e['data']
            elif e['event']=='second_causal_context_and_forecasts':
                d=e['data'];ctx=d['context_identity']
                for row in d['rows']:
                    identity={k:row[k] for k in ['kind','receiver','q','donor_index','donor_bus']}
                    aid=hashlib.sha256(canon(identity)).hexdigest();key=ctx+'|'+aid
                    f=row['ordering_forecast']
                    if key in forecasts:assert forecasts[key]==f
                    else:forecasts[key]=f
    new_ids=set()
    for i in range(1,9):
        branch=read(PAID/'actual'/f'Branch_{i}.json')
        for message in branch['query_messages']:
            record=message['record'];measured=record.get('actual_measured_receipt')
            if not measured:continue
            intent=intents[measured['PF_id']];context=intent['context'];key=context['point']+'|'+context['action_key']
            assert message['aid']==context['action_key']
            c=copy.deepcopy(record);ref=c['after_reference']
            if ref:
                assert ref['kind']=='new'
                c['after_reference']={'kind':'external_capsule','base':str(PAID.relative_to(R)),'descriptor':ref['descriptor']}
            c['source_existing_measured_receipt']=c.pop('actual_measured_receipt')
            c['source']='INDEPENDENTLY_VERIFIED_BOUNDED_LOOKAHEAD_20261014'
            if key in cache:
                for field in ['verdict','original_score','after_reference','attributed_PF_calls','attributed_solver_seconds']:
                    assert cache[key][field]==c[field],field
            else:cache[key]=c
            new_ids.add(measured['PF_id'])
    assert new_ids==set(intents) and len(new_ids)==68
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_PAID_RECEIPT_FORECAST_DEPENDENCY_INDEX_REQUIRES_EXTERNAL_AUDIT',
        'cache':cache,'blocked_prior_incomplete_identities':index['blocked_prior_incomplete_identities'],
        'existing_numeric_forecasts':forecasts,'newly_indexed_already_paid_query_ids':sorted(new_ids),
        'source_sha256':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),
            OLD/'Compatible_Paid_Receipt_Index.json',PAID/'actual/scientific.jsonl',
            PAID/'verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json',R/'work/receding_paid_decision_engine_v1.py']},
        'workflow_seconds':time.perf_counter()-start,'new_PF_model_derivative_forecast_solve_calls':0,
        'old_physics_and_numerical_costs_remain_paid_not_free':True}
    put(B/'Paid_Warm_Dependencies.json',result)
    put(B/'Result.json',{'exit_code':0,'cache_entries':len(cache),'already_paid_bounded_query_ids':len(new_ids),
        'existing_forecast_entries':len(forecasts),'new_scientific_calls':0})
    print(json.dumps({'paid_receipt_entries':len(cache),'paid_bounded_queries_indexed':68,'cached_numeric_forecasts':len(forecasts),'new_scientific_calls':0}))
if __name__=='__main__':main()
