"""Credential-safe HTTP failure metadata; never persist headers, URLs or tokens."""
import json, re
from urllib.parse import urlparse, parse_qs


def safe_text(value):
    if not isinstance(value,str):return None
    value=re.sub(r'https?://\S+','[URL]',value)
    value=re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}','[ACCOUNT]',value)
    value=re.sub(r'[A-Za-z0-9_./+=-]{24,}','[IDENTIFIER]',value)
    return value[:500]


def failure_details(exc):
    details={'exception_type':type(exc).__name__}
    request=getattr(exc,'request',None)
    if request is not None:
        details['request_method']=request.method
        parsed=urlparse(request.url)
        details['endpoint_path']=parsed.path
        query=parse_qs(parsed.query)
        details['requested_options']={k:query[k] for k in ['variant','accelerator','shape','authuser'] if k in query}
    response=getattr(exc,'response',None)
    if response is None:return details
    details['http_status']=response.status_code
    details['http_reason']=safe_text(response.reason)
    retry=response.headers.get('Retry-After','')
    if retry.isdigit():details['retry_after_seconds']=int(retry)
    raw=getattr(exc,'response_body',None)
    if raw is None:raw=response.text
    if raw.startswith(")]}'\n"):raw=raw[5:]
    try:body=json.loads(raw)
    except (ValueError,TypeError):
        details['response_format']='non_JSON'
        return details
    details['response_format']=type(body).__name__
    if isinstance(body,dict):
        for key in ['code','status','reason','message','error_description']:
            value=body.get(key)
            if isinstance(value,(int,bool)):details[key]=value
            elif isinstance(value,str):details[key]=safe_text(value)
        error=body.get('error')
        if isinstance(error,str):details['error']=safe_text(error)
        elif isinstance(error,dict):
            details['error']={}
            for key in ['code','status','reason','message']:
                value=error.get(key)
                if isinstance(value,(int,bool)):details['error'][key]=value
                elif isinstance(value,str):details['error'][key]=safe_text(value)
    return details
