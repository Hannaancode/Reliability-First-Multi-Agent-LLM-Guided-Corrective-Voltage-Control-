"""Bound cohort identities, disclosure roles and remaining confirmation gaps."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_cohort_use_20261029'
def read(p):return json.loads((R/p).read_text('utf-8'))
def record(path):
    p=R/path;return {'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def main():
    O.mkdir(exist_ok=False)
    paths={'original4':'outputs/original118_closed_comparison_20261028/Comparison.json',
        'historical137':'outputs/paper137_archived_scope_reconciliation_20261021/Read_Only_Scope_Reconciliation.json',
        'adapted_scale':'outputs/matched_scale_20261011/preparation/protocol.json',
        'public500':'outputs/public13_native_cohort_assembly_20261021/Native_Cohort_Results.json',
        'fresh128_protocol':'outputs/public13_fresh_router_execution_preparation_20261022/Protocol.json',
        'fresh128_decision':'outputs/public13_fresh_router_comparison_20261022/Fixed_Decision.json',
        'qa150_input':'outputs/veragrid_source_admission_20261029/Actual150_Admission.json',
        'qa150_protocol':'outputs/public_qa_execution_preparation_20261029/final/Final_Protocol.json',
        'environment_contracts':'outputs/environment_contracts_20261029/Environment_Contracts.json',
        'existing_chapter7':'outputs/thesis_expanded_20261028/07_Experiments.md'}
    source={k:record(p) for k,p in paths.items()}
    original=read(paths['original4']);ids=[x['case_id'] for x in original['rows']]
    assert len(ids)==len(set(ids))==4 and original['no_iid_confidence_or_unused_confirmation'] is True
    scale=read(paths['adapted_scale']);assert (scale['FIT_worlds'],scale['HELD_worlds'],scale['FIT_pairs'],scale['HELD_pairs'])==(85,24,340,96)
    fresh=read(paths['fresh128_protocol']);assert fresh['seeds']==list(range(1000,1128))
    partial=read(paths['fresh128_decision']);assert partial['status']=='UNKNOWN_TERMINAL_PARTIAL_NO_COMPLETE128_COMPARISON'
    historical=read(paths['historical137']);assert historical['raw_unique_scenario_ids']==137 and historical['new_final137_HGSE_trajectory_raw_join']=='NOT_ESTABLISHED'
    rows=[
        {'cohort':'Four severe federation roots','unit':'physical root and full branch trajectory','count':4,'identities':ids,
         'role':'Repeatedly inspected development; fixed later execution does not remove prior inspection','evidence':'original4','confirmation':'NO'},
        {'cohort':'Matched adapted-scale teacher bank','unit':'world, with dependent paired local observations','count':109,
         'identity_reference':'preparation fit.json and held.json; connected-world split reused from numerical control',
         'partitions':{'FIT_worlds':85,'HELD_worlds':24,'FIT_pairs':340,'HELD_pairs':96,'original_training_rows':16000},
         'role':'Held from this fitted run, but historical teacher development bank; not unused physical confirmation','evidence':'adapted_scale','confirmation':'NO'},
        {'cohort':'Public13 completed native comparison','unit':'initial physical case shared by all arms','count':500,
         'identity_reference':paths['public500'],'role':'Completed benchmark, subsequently inspected for diagnosis and router design','evidence':'public500','confirmation':'NO_FOR_LATER_REDESIGNS'},
        {'cohort':'Public13 fresh128 router campaign','unit':'source-generated seeded initial case','count':128,'seeds':fresh['seeds'],
         'role':'Prospective at original freeze after500development; terminal partial, never a complete128 result',
         'unentered_seeds':partial['unentered_seeds'],'evidence':'fresh128_protocol','decision':'fresh128_decision',
         'confirmation':'INCOMPLETE_NO_FULL_COHORT_CLAIM'},
        {'cohort':'Historical137 identity scaffold','unit':'federation recipe identity','count':137,
         'identity_reference':paths['historical137'],'role':'Earlier-controller development archive; not the later paper trajectory join',
         'absent_from_141_recipe_scaffold':historical['four_FED141_ids_absent_from_archive'],'evidence':'historical137','confirmation':'UNESTABLISHED_FOR_LATER_PAPER_TABLE'},
        {'cohort':'VeraGrid publicQA scale','unit':'question concerning one public circuit','count':150,
         'identity_reference':'All source-order IDs in final three-arm protocol/pack; same150 in each arm',
         'role':'Fixed public transfer benchmark; pretraining overlap unknown; no independent-grid confirmation',
         'evidence':'qa150_input','protocol':'qa150_protocol','confirmation':'NO_UNUSED_CONFIRMATION_CLAIM'}]
    unresolved=[
        {'family':'Paper61 complete-metric development plot and separately retained68 early rows','role':'DEVELOPMENT','missing':'Exact equality and member-by-member binding between the61 plotted cases and68 archived rows is not certified here.'},
        {'family':'Paper final137 trajectory table','role':'MANUSCRIPT_REPORTED','missing':'All137 later DFF/HG-VF/HG-SE raw trajectories and exact source join; earlier137 identities do not substitute.'},
        {'family':'Sealed62 baseline','role':'LOCKED_HISTORICAL_BASELINE','missing':'Locked means preserved; an untouched confirmation designation for a new intervention is not established.'},
        {'family':'Stage3 74of80','role':'TERMINAL_PARTIAL','missing':'Six final identities and full global costs stay unknown; no complete80 inference.'},
        {'family':'239OPT and72held observations and other failed learning banks','role':'INSPECTED_DEVELOPMENT','missing':'State observations and retained preferences are dependent; old held labels cannot be relabelled as unused confirmation.'},
        {'family':'Eight-root paid-receipt opportunity and receding numerical development','role':'FIXED_DEVELOPMENT','missing':'Prospective mechanism rejection is scoped to its frozen test; no all-roster or universal no-headroom conclusion.'},
        {'family':'MAPDN322 one completed engineering point and partial native episode','role':'ENGINEERING_DEVELOPMENT','missing':'Full120-identity schedule and native480step episodes are incomplete; seasonal/all-pool preparation also needs causal accounting.'},
        {'family':'Three PGLib118 source cases and native feasibility attempts','role':'SOURCE_AND_NUMERICAL_ADMISSION','missing':'Source compatibility and failed bounded attempts are not an executed learned-controller benchmark.'},
        {'family':'PowerGridQA4396identifier retrieval records','role':'PUBLISHED_IN_CORPUS_RETRIEVAL','missing':'Identifier-assisted retrieval does not establish unseen-document or identifier-free generalization.'},
        {'family':'RAG500 printedQA, separate50NERC and200adversarial manuscript sets','role':'HISTORICAL_LANGUAGE_EVALUATION','missing':'Runtime index/data revision, overlap and exact adjudication are not all reconstructed; same-named indexedQA recipe does not prove unseen-document transfer.'},
        {'family':'24trial96proposal physical QA/security pilot','role':'DEVELOPMENT_PILOT','missing':'Not the complete adversarial physical campaign or a full security certificate.'}]
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'SOURCE_BOUND_COHORT_USE_REGISTER_WITH_EXPLICIT_IDENTITY_GAPS',
        'source_files':source,'identity_bound_rows':rows,'other_reported_or_development_families':unresolved,
        'T21_completion':'PARTIAL_UNTIL_UNRESOLVED_IDENTITY_BINDINGS_ARE_RESOLVED_OR_SCOPE_APPROVED_AND_THESIS_INTEGRATION_VISUALLY_VERIFIED',
        'new_model_PF_training_calls':0,'no_current_QA_outputs_or_labels_read':True,
        'rules':['Fresh-at-freeze and previously-inspected are time-relative properties; preserve the original status.',
            'A random seed is an identity mechanism, not proof of independence from design or training.',
            'Model size comparisons on shared questions are paired and dependent; question counts are not grid counts.',
            'Partial cohorts retain all missing IDs; no completed-prefix-only headline.',
            'Training/validation/testing names do not establish untouched physical confirmation.']}
    (O/'Cohort_Use_Register.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
    text='''# Development cohorts and confirmation boundaries

The current evidence supports several completed development comparisons, but it does not support a single independent test population spanning all of them. A physical root, a trajectory, a local teacher observation and a question about a fixed circuit are different experimental units. Their counts must remain separate. The source register accompanying this section records six cohorts with explicit identity references and eleven other reported or development families whose membership, execution or confirmation status still needs qualification.

The four severe roots are fed_combined_load_1p5_line_35_MG1, fed_combined_load_1p5_line_36_MG1, fed_combined_load_1p5_line_84_MG2 and fed_combined_load_1p5_line_127_MG3. They were inspected during engineering. Their later complete branch audits improve confidence in the recorded trajectories; they do not make these cases untouched confirmation. The paired UV differences and additional OV cases therefore remain descriptive development findings.

The matched model-scale experiment retains16000 original row multiplicities within109 teacher worlds. Its85 fitting worlds contain340 paired observations, and its24 held worlds contain96. Holding those worlds out of this fitted run answers a limited imitation question. The bank had already been used and inspected during development, so it does not provide an unused physical population for a later superiority claim. A claim based on16000 independent worlds would be incorrect.

The500 public13 cases form a complete shared-root comparison. Their results later informed failure diagnosis and router design. A subsequent fixed router protocol declared seeds1000 through1127 before its new outcomes; this prospective ordering should be preserved in the historical account. However, that128-case campaign ended partial, with seeds1055 through1127 unentered. Prospective design alone cannot supply a complete128-case result. Neither the completed prefix nor a favourable subset may replace the declared denominator.

The historical137 identity scaffold binds earlier controller records to federation recipes. It does not certify the later137 DFF, HG-VF and HG-SE trajectories in the manuscript. Likewise, the paper’s61-case development plot and the separately retained68 early rows are different recorded populations until a full membership join is established. The sealed62 baseline remains preserved, and Stage3 retains its74of80 partial status. A sealed artifact is not automatically an unused test set for every future method.

The VeraGrid experiment uses150 questions about one public circuit, shared by the three fixed model sizes. Its source order, circuit information, prompts and decoding contract are fixed before outcomes. This supports a paired public-transfer comparison. The questions are not150 independent electrical grids, and publication of the material leaves model-pretraining overlap unknown. It also differs from the paper’s retrieval-assisted pipeline because this experiment supplies no retrieval or tools. No current answer or accuracy was inspected when this register was written.

The remaining evidence families retain their own qualifications. The paid-receipt screens and previously inspected OPT/held banks are development. The MAPDN322 observation is a completed engineering point within an incomplete native episode and cohort. PGLib input and feasibility investigations are admission studies. Identifier-assisted PowerGridQA retrieval, historical RAG answering, adversarial language questions and the24trial96proposal physical pilot do not establish the same kind of generalization or security claim.

For a future confirmation study, we must record the final controller and parser, training and selection history, case-construction rule, complete candidate roster, failure treatment, common information and intervention limits, and analysis before the confirmation outcomes become available. We must then preserve every declared case and all model, numerical, preparation and failure costs. This procedure describes the evidence still required; it does not claim that the present unresolved cohorts already satisfy it.

This insert is prepared for Chapter7. The accompanying register explicitly retains unresolved identity joins. T21 remains partial pending those requirements and reviewed integration into the thesis.
'''
    (O/'Chapter7_Development_And_Confirmation_Insert.md').write_text(text,'utf-8')
    print(json.dumps({'status':result['status'],'identity_bound_rows':6,'other_families':11,'T21':'PARTIAL','new_science':0}))
if __name__=='__main__':main()
