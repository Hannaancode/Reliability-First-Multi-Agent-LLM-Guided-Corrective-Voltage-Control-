# Research decision after the fixed relational trial

The completed intervention remains stopped. Its learning and ranking gates failed;
this document neither changes those gates nor authorizes retraining the same method.
The saved-only OPT diagnosis covers both final epoch-5 arms, all 187 measured OPT
states and their 30,390 known candidate labels, with 52 unlabelled OPT inputs retained.
It made zero new model, optimizer, solver or cloud calls. Read
`closed_learning_OPT_mechanism_diagnostic_v2/Summary.json` and its sealed evidence.

The internal arm predicted native acceptance for 315 candidates and correctly
identified only 197 of 12,269 accepted candidates: recall 1.606%. The frozen head
predicted no native acceptance positives. Recorded convergence was positive for
every one of these known in-cap labels; predicting it correctly therefore does not
demonstrate discriminative convergence learning. Other missing/out-of-cap convergence
outcomes remain unknown in the original data and are not imputed.

Across 11,884 native best-versus-other OPT pairs, equal-world state-mean strict
ordering satisfaction was 50.232% internal and 36.189% frozen. Current-grounding
training loss declined from .72435 to .18648 internal, but pairwise training loss
changed only from .64797 to .64218. This describes weak native decision learning
alongside better current-input reconstruction. It does not causally identify loss
interference, prove that a changed threshold/loss would help, or authorize such tuning.
In particular, poor fitting is present on OPT worlds; held generalization is not the
only demonstrated problem. All original selections and adverse results are retained.

## Primary research and transfer limits

| Primary source | Relevant evidence | Consequence here |
|---|---|---|
| [Tan et al., NeurIPS 2024](https://proceedings.neurips.cc/paper_files/paper/2024/file/6ed5bf446f59e2c6646d23058c86424b-Paper-Conference.pdf) | Removing/replacing pretrained LMs often retained numerical forecasting performance in the tested methods. Random/pretraining and small numerical ablations were informative. | A pretrained transformer is not itself an evidence-backed numerical prior. Retain strong numerical and matched-architecture/pretraining controls; their applicability must be measured on this grid task. |
| [AutoTimes, NeurIPS 2024](https://proceedings.neurips.cc/paper_files/paper/2024/file/dcf88cbc8d01ce7309b83d0ebaeb9d29-Paper-Conference.pdf), Tables 6–7 | Autoregressive numerical segment prediction outperformed several LM-free replacements on the reported forecasting tasks; adding LoRA had mixed-size gains. | Sequential next-numerical-token transfer is a more specific mechanism than using a decoder-only LM as an arbitrary classifier. These are forecasting results, not action-conditioned AC recovery or D-SE superiority, and cannot guarantee transfer. |
| [xVal](https://arxiv.org/abs/2310.02989) | Continuous numerical tokenization was evaluated with specially modified models trained from scratch on scientific data. | Numeric tokenization and numerical training distribution matter. It does not establish that a text-pretrained frozen Qwen accepts arbitrary numeric soft tokens with a useful prior. Directly adding xVal-style embeddings is neither demonstrated benefit nor novelty. |
| [TABULA-8B, NeurIPS 2024](https://proceedings.neurips.cc/paper_files/paper/2024/hash/4fd5cfd2e31bebbccfa5ffa354c04bdc-Abstract-Conference.html) | Tabular transfer used a Llama-3 8B model fine-tuned on 2.1 billion rows from 4.2 million tables. | Its numerical-transfer result depends on substantial domain pretraining. Our 23 OPT worlds and 187 labelled states do not reproduce that evidence. The 38,727 candidate labels are clustered measurements, not 38,727 independent grids. Its reported gains do not supply an estimate for our hardware/data. |
| [Jia et al., Daline](https://arxiv.org/abs/2406.17215) | Domain/tool grounding improved correct simulation-code generation on 34 tasks. | Useful power-system assistance is demonstrated on a different endpoint. Coding accuracy cannot substitute for better protected physical actions over full literal D-SE. Moving the thesis goal to tool-use success would not satisfy the requested objective. |

These sources support a falsifiable mechanism question, not a ready winning method
or a 90% success estimate. Internal routing, relational numerical encoding and
classifier/preference supervision have now been genuinely tested here without the
required benefit. Renaming or slightly modifying them is not a new contribution.

## One materially different question worth a data audit

Could a separately trained copy of the LM learn an **action-conditioned numerical
transition**, rather than reconstruct the current input or classify actions directly?
A possible experiment would train a next-electrical-state numerical-token process
and test whether pretraining helps predict the physical response to an explicitly
supplied candidate action. The eventual decision would still require the real
unchanged verifier and common normal-upper protection. No prediction certifies safety.

This is an inference from AutoTimes' mechanism and the present diagnosis. It is not
proof of novelty, benefit, sufficient data, or that autoregression is the cause of our
failure. A no-LM state/action learner, matched random-backbone/control and the exact
current AC linearization must receive the same information and measured targets.
If they explain the benefit, no incremental pretrained-LLM claim is justified.

There is a concrete possible source of genuine targets to inspect: existing committed
prefix records contain solved observations before and after actually executed actions.
That is different from the global-only labels for all other tested candidates. We
have not yet verified a complete joined transition dataset, its coverage or suitability.
Do not assign successor vectors to uncommitted candidates or silently relabel missing
fields. Accepted teacher actions may have narrow, biased coverage and may not teach
the effect of rejected actions or alternative Q values.

The next bounded CPU-only action is an outcome-independent inventory of **all exact
OPT-world committed prefixes** in the already closed guarded collection. Verify
source/scenario hashes, adjacent prefix/action identities, complete native 118-bus
before/after tables, current raw common-and-zone membership and support caps. Deduplicate
exact state/action/successor identities but retain branch/world provenance, zero-action
worlds, failures, unsafe boundaries, unknowns and previously charged collection costs.
Keep the historical held worlds out of target-design measurements. Do not solve again.

Report the actual transition count, world/family/Q/bus coverage, numerical excitation,
duplicate/conflict counts, known missing fields and action-selection bias before deciding
whether the hypothesis has enough support. No automatic learning/GPU launch follows.
If suitable state/action targets or meaningful excitation are absent, stop this proposal
instead of manufacturing rewards or outcomes. If present, a separate precise model,
capacity/pretraining attribution design, resource smoke and prospectively fixed study
must precede performance. No framework or mature transition runner is claimed here.

The ultimate primary comparison remains original D-SE = DFF + DFF-ALT + unchanged
safety-envelope selector, including full costs of both branches and exact zero/missing
handling. Strong AC is a secondary control. Matched fresh per-state protected physical
outcomes, complete preparation/training/inference/solver/failure costs and genuinely
unused confirmation remain required. The frozen original assets and locked 62-case
bank remain unchanged; inspected historical data remain development, not confirmation.
