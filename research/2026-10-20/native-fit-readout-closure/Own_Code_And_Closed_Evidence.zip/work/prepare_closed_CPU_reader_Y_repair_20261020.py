"""Use already independently certified admittance; BFSW does not retain internal Ybus."""
import json,hashlib,ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    oldpath=ROOT/'work/audit_native_closed_CPU_evidence_v2_20261020.py';old=oldpath.read_text(encoding='utf-8')
    new=old.replace("OUT=ROOT/'outputs/native_closed_CPU_evidence_audit_v2_20261020'","OUT=ROOT/'outputs/native_closed_CPU_evidence_audit_v3_20261020'")
    new=new.replace('outputs/native_closed_CPU_evidence_repair_preparation_20261020/Protocol.json','outputs/native_closed_CPU_evidence_Y_repair_preparation_20261020/Protocol.json')
    target="Y=net._ppc['internal']['Ybus'];assert Y.shape==(13,13)"
    replacement="""graph=np.load(ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz')
    assert np.array_equal(net._ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(net._ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and net._ppc['baseMVA']==float(graph['baseMVA'])
    Y=graph['Y'];assert Y.shape==(13,13)"""
    assert old.count(target)==1;new=new.replace(target,replacement)
    oldmain="results={'MLP':partial_mlp(np,torch),'numeric_readouts':readouts(np),'saved_command_KCL':saved_kcl(np)}"
    newmain="""results={}
    for name,call in [('MLP',lambda:partial_mlp(np,torch)),('numeric_readouts',lambda:readouts(np)),('saved_command_KCL',lambda:saved_kcl(np))]:
        results[name]=call();put(OUT/(name+'_Component_Audit.json'),results[name])"""
    assert old.count(oldmain)==1;new=new.replace(oldmain,newmain)
    file=ROOT/'work/audit_native_closed_CPU_evidence_v3_20261020.py';assert not file.exists();file.write_text(new,encoding='utf-8');ast.parse(new)
    prep=ROOT/'outputs/native_closed_CPU_evidence_Y_repair_preparation_20261020';prep.mkdir(exist_ok=False)
    p=json.loads((ROOT/'outputs/native_closed_CPU_evidence_repair_preparation_20261020/Protocol.json').read_text(encoding='utf-8'))
    p['source_and_input_hashes']['work/audit_native_closed_CPU_evidence_v3_20261020.py']=sha(file)
    p['source_and_input_hashes']['outputs/native_closed_CPU_evidence_coordination_v2_20261020/End_ACK.json']=sha(ROOT/'outputs/native_closed_CPU_evidence_coordination_v2_20261020/End_ACK.json')
    graph='outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz'
    p['source_and_input_hashes'][graph]=sha(ROOT/graph)
    p['single_owner'].update(source='work/audit_native_closed_CPU_evidence_v3_20261020.py',sha256=sha(file),output='outputs/native_closed_CPU_evidence_audit_v3_20261020',coordination='outputs/native_closed_CPU_evidence_coordination_v3_20261020')
    p['additional_mechanical_repair']='Actual BFSW saved NET does not retain internalYbus. Use existing independently certified original Y with exact branch/native shunt/baseMVA checks, as all source physics/KCL audits do. No converter, derivative, PF, model or solve. Preserve V1 arithmetic failure and V2 missing-cache failure. Complete prior component proofs now written before following checks.'
    with (prep/'Protocol.json').open('x',encoding='utf-8') as f:json.dump(p,f,indent=2)
    a=[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(old)) if isinstance(n,ast.Assert)]
    b=[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(new)) if isinstance(n,ast.Assert)]
    assert all(node in b for node in a)
    proof={'status':'PASS_ADDITIVE_SAVED_ADMITTANCE_READER_REPAIR_ALL_OLD_ASSERTIONS_RETAINED','new_source_sha256':sha(file),'all_original_asserts_retained':True,'graph_sha256':sha(ROOT/graph),'new_scientific_calls':0}
    with (prep/'Static_Readiness.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
    print('SAVED_VERIFIED_GRAPH_READER_REPAIR_READY_NO_SCIENTIFIC_CHANGES')
if __name__=='__main__':main()
