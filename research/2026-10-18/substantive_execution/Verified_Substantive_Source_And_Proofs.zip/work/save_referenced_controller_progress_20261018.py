"""Save verified scoped physics findings and explicit next research gates."""
import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import frozen_checks,seal
R=Path(__file__).resolve().parents[1];B=R/'outputs/referenced_controller_research_handoff_20261018'
def read(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
def put(p,d):p.write_text(json.dumps(d,indent=2),encoding='utf-8')
def main():
    B.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    audit=read('outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json')
    transport=read('outputs/actual_journal_reference_history_20261018/Results.json')
    factory=read('outputs/referenced_controller_factory_cold_20261018/Results.json')
    assert audit['status'].startswith('PASS_ALL_RECORDED') and transport['status'].startswith('PASS_EXACT') and factory['status']=='PASS'
    decision={'at_utc':now,'status':'SCOPED_ALL26_COMMIT_AUDIT_PASS_ONE_WORLD_TWO_CLOSED_ZERO_UV_SUFFIXES',
        'scientific_scope':'Saved actual physical commitments and closed endpoints after historical trained-LoRA prefix; numerical planning, no fresh LLM inference.',
        'all_recorded_commits_verified':audit['all_recorded_commits_checked'],
        'all_closed_recorded_branches':audit['all_recorded_closed_branches'],
        'all_four_or_full_policy_gate':'UNKNOWN',
        'full_unselected_policy_ranking_and_all_capsules_and_all_checkpoints':'NOT_REAUDITED',
        'new_model_PF_optimizer_derivative_forecast_or_solve_calls':0,
        'factory_checks_passed':sum(factory['cold']['checks'].values()),
        'original_oversize_record_bytes':transport['actual_original_record_bytes'],
        'referenced_record_bytes':transport['new_logical_history_record_bytes'],
        'all_2580_ordered_receipts_exact_in_cold_process':True,
        'future_query_references_rejected_before_checkpoint_save':read('outputs/referenced_controller_factory_cold_20261018/Future_Query_Rejection.json')['rejected_before_save'],
        'capacity_preflight':'outputs/referenced_history_capacity_preflight_20261018/Results.json; v2 wider full-native transport envelope PREPARED ONLY, not actual-data/factory/owner certified.',
        'original_3B_7B_size_only_intervention':'STOPPED; no retry/checkpoint/seed/context/LR/Q/width outcome sweep',
        'no_running_science_or_GPU_job':True,
        'limitations':'One world, two numerical policies, inspected development. Both reach0: no UV superiority over immediate control; breadth used14 added operations versus11. Original full DSE baseline, fresh model attribution, all severe cases, published benchmark and unused confirmation remain unachieved.'}
    put(B/'Verified_Research_Checkpoint.json',decision);put(B/'Frozen_Checks.json',frozen_checks())
    text='''# Verified progress and exact next steps — 18 October 2026

The new linear scoped reader checked ALL26 recorded commits in the partial campaign, not a favorable subset. It independently bound the entire scientific journal to its saved SHA/chain/protocol, all37,682 actual attempt identities/cost arithmetic and the selected paid/native-verifier/action/replay/cursor/cap/stock/guard evidence. All118 recorded replay fields match each selected paid target within1e-10. This does not verify all unselected physical outputs, ranking/forecast calculations or all checkpoint histories.

Both recorded closed suffixes for `fed_combined_load_1p5_line_35_MG1` go from17 residual UV buses to0. Immediate1x16 uses11 additional device operations, breadth4x4 uses14; respectively5 and2 original operations remain. Initial historical trained-LoRA prefix is reused, with old/unknown costs retained. These are the ALL closed branches from the original execution order, not a selected comparison subset. Other cases and partial branches are UNKNOWN. One zero endpoint is real recorded progress, not a fresh LLM contribution or full DSE victory; breadth has no UV advantage in this completed pair and costs3 more device operations.

The actual35,228,332-byte history record now has an exact1,323,285-byte referenced representation. All2,580 queries, order, verdicts, score, capsule references and costs restore exactly in a separate process. Raw scientific journal remains mandatory; this is duplicate-storage reduction, not removal of evidence or a solver/deployment efficiency claim. Reference checkpoints passed17 real saved controller-factory/cold tests; references outside the saved scientific prefix are rejected before save. Initial missing namespace binding and wrong-environment/no-NumPy import failures are retained separately; neither made scientific calls.

## Next work in order

1. Freeze and test the full-native transport envelope before any physics. A source-bounded cheap sizing check shows that4MiB logical records are not certified for the conservative118-bus/9Q/25owned-row plus16-followup namespace. The separate v2 component declares40MiB record/8MiB metadata/1KiB reference/27,628-reference limits below the original chunk store64MiB maximum. This is PREPARED ONLY. Validate actual future input owned-row/schema bounds and integrate v2 with causal complete-state guards, cold factory and reader. No change to physical operation25/cap450/no-refund/solver/score/guard/query budgets.
2. Build a prospectively locked all-attempt identity frontier for old source-compatible evidence (including15 solver exceptions). Before a new primary request, reuse an independently validated exact paid result or block any attempted-but-incomplete identity. Never rerun old primary physics, infer an old missing RNG checkpoint, reset resources or extend an old owner budget. Raw saved PF return is not a free tool or a negative learning label on unknown nonlinear feasibility.
3. Lock a genuinely new development measurement protocol for unexecuted identities, complete/partial reader and ownership/preservation bounds. Keep the same fixed policies and ALL declared cases. Replay/cached transitions and previous training/preparation/failure costs remain charged and separately reported. Any fresh selected continuous physical replay must be an explicitly charged new role. Old scientific/audit owners stay closed; no new campaign is ready yet.
4. Bind original trained LOCAL recipient/Q role and family broker under genuine causal serving input/parser/context/loader/cold-memory/latency gates, with equally informed numerical-only and trained numerical controls. Numerical planning gains and schema/teacher learning cannot be renamed LLM value. Only cross-world physical/economic support can justify decision-aligned learning; no repeat size-only imitation training.
5. All141 federation recipes stay in coverage;118 is the bus count. The primary>=60 initial-UV recipes and all missing73 historical outcomes must remain explicit. No one-world result implies zero UV on all severe cases. Published dataset/method work remains pending faithful, separately justified solver integration; original failed native OPF attempts remain preserved, not rerun.

All six human goals remain active/unachieved. Preserve frozen original model/network/controller/locked62 bank, literal DFF+DFF-ALT+unchangedDSE selector, individual branches and FULL BOTH costs, adverse/partial/UNKNOWN results, strong matched controls and unused confirmation. No GPU allocation, scientific worker or timer follows automatically from these software/audit passes.
'''
    (B/'Results_And_Next_Execution.md').write_text(text,encoding='utf-8')
    marker='REFERENCED CONTROLLER AND ALL26 COMMIT PREFIX VERIFIED 18OCT2026'
    note=f'{marker} {now}\n\nAll26 recorded commits/scientific journal identity and actual cost arithmetic scoped-audited. ALL2 closed numerical suffixes on fed_combined_load_1p5_line_35_MG1 go17UVto0 within original25-operation/cap450/normal-upper tolerance; immediate adds11ops vsbreadth14, so noUVwin over immediate. Other4world/full-policy gateUNKNOWN; nofreshLLM. Actual35.23MB duplicate decision record now1.323MB references;2,580 ordered receipts cold-exact,17 referenced full saved factory checksPASS plus future-receipt rejection. Full-native metadata sizing v2PREPAREDONLY, future-input/source/reader gates pending. No newPF/model/optimizer/forecast/solve, noGPU/timers/oldownerrestart. Read outputs/referenced_controller_research_handoff_20261018/Verified_Research_Checkpoint.json and Results_And_Next_Execution.md.\n\n'
    p=R/'reseacrh progress.txt';old=p.read_text(encoding='utf-8');p.write_text(old+'\n'+note+text,encoding='utf-8')
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_INDEX.md']:
        p=R/rel;p.write_text(note+p.read_text(encoding='utf-8'),encoding='utf-8')
    for rel in ['outputs/critical_research_reset_20261010/Research_Resume_20261012.json','outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json']:
        p=R/rel;d=read(rel);d.update(latest_referenced_controller_checkpoint=str((B/'Verified_Research_Checkpoint.json').relative_to(R)),latest_critical_continuation_plan=str((B/'Results_And_Next_Execution.md').relative_to(R)),latest_verified_research_at_utc=now,owned_science_collector_reader_jobs=[]);put(p,d)
    p=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(str(p.relative_to(R)));t=tasks['tasks'][0];t['status']='ALL26_COMMITTED_TRANSITIONS_AUDITED_ONE_WORLD_TWO_ZERO_UV_SUFFIXES_FULL_FOUR_WORLD_POLICY_UNKNOWN_REFERENCED_FACTORY_PASS';t['done']+='18Octscopedall26commit auditPASS:17to0online35bothnumericalpolicies,11vs14addedops. NoLLMattribution/full4worldgate. Duplicate35.23MBhistory becomes1.323MBexactrefs/2580queries; referencedcontrollercoldfactory17checksPASS/futurequeriesblocked. Conservativefull-nativev2sizingonlyprepared.';t['next']='Read outputs/referenced_controller_research_handoff_20261018/Results_And_Next_Execution.md; full-native capacity/input/source/cold/independent-reader and all-attempt frontier gates before new unexecuted physics. No old restart, no outcome retunes.';tasks['latest_verified_research']=str((B/'Verified_Research_Checkpoint.json').relative_to(R));put(p,tasks)
    # Seal only new source/protocol/results/failure logs, not old multi-GB data.
    files={}
    sources=['receding_paid_chunked_runtime_v3_20261018.py','receding_paid_chunked_runtime_v4_20261018.py','check_chunked_controller_factory_cold_20261018.py','check_chunked_controller_factory_cold_v2_20261018.py','paid_receding_journal_reference_history_v1_20261018.py','paid_receding_journal_reference_history_v2_20261018.py','check_actual_journal_reference_history_20261018.py','paid_receding_referenced_commit_v1_20261018.py','receding_paid_referenced_runtime_v1_20261018.py','check_referenced_controller_factory_cold_20261018.py','audit_all_recorded_receding_commits_20261018.py',Path(__file__).name]
    for name in sources:files['work/'+name]=R/'work'/name
    for folder in ['chunked_controller_factory_cold_20261018','chunked_controller_factory_cold_v2_20261018','actual_journal_reference_history_20261018','referenced_controller_factory_cold_20261018','referenced_history_capacity_preflight_20261018','all_recorded_receding_commits_audit_20261018']:
        root=R/'outputs'/folder
        for path in root.glob('*'):
            if path.is_file() and path.suffix in ['.json','.log']:files[str(path.relative_to(R)).replace('\\','/')]=path
    for name in ['chunked_controller_factory_cold_console_20261018.log','chunked_controller_factory_cold_v2_console_20261018.log','actual_journal_reference_history_console_20261018.log','actual_journal_reference_history_physics_env_console_20261018.log','referenced_controller_factory_cold_console_20261018.log','all_recorded_receding_commits_audit_console_20261018.log']:files['outputs/'+name]=R/'outputs'/name
    for path in B.glob('*'):files[str(path.relative_to(R)).replace('\\','/')]=path
    archive=seal(B,files,'Referenced_Controller_And_Scoped_Physical_Evidence_20261018.zip')
    print(json.dumps({'saved':True,'all26_commit_scope':'PASS','all4_policy_gate':'UNKNOWN','archive':archive}))
if __name__=='__main__':main()
