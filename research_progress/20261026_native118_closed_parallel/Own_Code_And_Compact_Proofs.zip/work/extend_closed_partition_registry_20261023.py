"""Append new closed study records once; independently check only new rows.

Old 3517 independently checked index entries are preserved byte-for-byte as
JSON values. No repeated physics, conversions, model calls or old audit.
"""
from reflection118_remaining_cases_v2_core_20261023 import *
BASE=R/'outputs/reflection118_remaining_cases_preparation_20261023/closed_registry/Closed_Physical_Receipt_Registry.json'
BASE_AUDIT=R/'outputs/reflection118_remaining_cases_preparation_20261023/closed_registry_independent/Independent_Audit.json'

def new_receipts():
    # The original one-off derived receipt predates this study and is absent
    # from the old index. Preserve its independent proof as a dependency.
    d=R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023'
    assert read(d/'Independent_Audit.json')['status'].startswith('PASS_EXACT_ARGUMENTS')
    pairs=[(d/'Mapped_Receipt.json',read(d/'Mapped_Receipt.json'))]
    result=read(PARTITION/'Result.json')
    pairs.extend((PARTITION/n,read(PARTITION/n)) for n in result['call_records'])
    pairs.extend((p,read(p)) for p in sorted((PARTITION/'solver_input_identity').glob('identity_*/Receipt.json')))
    covered=set()
    for path,row in pairs:
        covered.add((path.parent/row['before']['path']).resolve())
        yield dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),
            before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=row['exception'])
    # Any unclosed reservation remains an explicit blocking UNKNOWN.
    paths=list(PARTITION.glob('*/call_*_before.zlib'))+list((PARTITION/'solver_input_identity').glob('identity_*/Target_Before.zlib'))
    for path in sorted(paths):
        if path.resolve() in covered:continue
        raw=path.read_bytes();decoded=zlib.decompress(raw)
        descriptor=dict(path=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),decoded_bytes=len(decoded),decoded_sha256=hashlib.sha256(decoded).hexdigest())
        yield dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),before=descriptor,after=None,kwargs=None,exception='UNCLOSED_PARTITION_RESERVATION_UNKNOWN')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['build','audit'],required=True);mode=ap.parse_args().mode
    require_partition_closed()
    out=TOP/('closed_registry' if mode=='build' else 'closed_registry_independent');out.mkdir(exist_ok=False)
    began=time.monotonic();put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)));wait_ack(out,began)
    np,pp,v2,runner,reflection=setup()
    def forbidden(*a,**k):raise OperationalStop('INCREMENTAL_REGISTRY_FORBIDS_NEW_SCIENCE')
    pp.runpp=forbidden
    old=read(BASE);prior=read(BASE_AUDIT);assert prior['index_sha256']==sha(BASE) and prior['rows_checked']==len(old['rows'])
    anchors={p.relative_to(R).as_posix():sha(p) for p in [BASE,BASE_AUDIT,PARTITION/'Result.json',PARTITION/'Closed_Manifest.json',PARTITION_AUDIT/'Independent_Audit.json',PARTITION_AUDIT/'Closed_Manifest.json',PARTITION_AUDIT/'Exact_Solver_Input_Receipt_Audit.json']}
    index=TOP/'closed_registry/Closed_Physical_Receipt_Registry.json'
    if mode=='build':
        from prior_physical_query_footprints_20261018 import component
        from run_reflection118_chronological_local_20261022 import necessary
        rows=list(old['rows']);seen={x['source'] for x in rows};added=0
        for item in new_receipts():
            assert time.monotonic()-began<1800
            assert item['source'] not in seen;seen.add(item['source'])
            net=saved_net(item['directory'],item['before']);item['resource_key']=component(net)[0]+':'+hashlib.sha256(canonical(necessary(net))).hexdigest()
            item['directory']=item['directory'].relative_to(R).as_posix();rows.append(item);added+=1
        put(index,dict(status='APPEND_ONLY_CLOSED_PARTITION_RECEIPTS_ALL_PRIOR_FAILURES_UNKNOWN_PRESERVED',rows=rows,record_count=len(rows),old_prefix_count=len(old['rows']),new_record_count=added,anchors=anchors,source_sha256=sha(__file__)))
        put(out/'Result.json',dict(status='COMPLETE_NEW_ROWS_REQUIRE_INDEPENDENT_READER',old_rows_reused=len(old['rows']),new_rows=added,new_science_calls=0,workflow_seconds=time.monotonic()-began))
    else:
        from build_and_audit_closed_dff_registry_20261023 import direct_key
        data=read(index);assert data['anchors']==anchors and data['rows'][:len(old['rows'])]==old['rows']
        expected=list(new_receipts());fresh=data['rows'][len(old['rows']):];assert len(fresh)==len(expected)==data['new_record_count']
        for row,item in zip(fresh,expected):
            assert time.monotonic()-began<1800
            item['directory']=item['directory'].relative_to(R).as_posix()
            assert {k:v for k,v in row.items() if k!='resource_key'}==item
            assert sha(R/row['source'])==row['source_sha256']
            assert direct_key(saved_net(R/row['directory'],row['before']))==row['resource_key']
        put(out/'Independent_Audit.json',dict(status='PASS_APPEND_ONLY_NEW_RECORD_IDENTITY_AND_INDEPENDENT_RATIONAL_KEYS',index_sha256=sha(index),old_index_sha256=sha(BASE),old_rows_reused=len(old['rows']),new_rows_checked=len(fresh),total_rows=len(data['rows']),anchors=anchors,new_science_calls=0,workflow_seconds=time.monotonic()-began))
    put(out/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in out.iterdir() if p.is_file()}))
if __name__=='__main__':main()
