"""Independent preallocation source/input/resource/role review; zero model calls."""
import ast
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    protocol = read(P / 'Frozen_Engineering_Protocol.json')
    ready = read(P / 'Launch_Readiness_Audit.json')
    for path, h in ready['source_hashes'].items():
        assert sha(R / path) == h
    inputs = read(P / 'All6_Messages_And_Token_IDs.json')
    assert len(inputs) == 6 and [x['agent'] for x in inputs] == list(range(6))
    assert sorted(set(x['seed'] for x in inputs)) == [0, 1]
    assert all(x['prefix_tokens'] == len(x['token_ids']) and len(x['token_ids']) + 384 <= 4096 for x in inputs)
    contexts = {c['engineering_case']: c for c in read(P / 'All2_Exact_Engineering_Cases.json')}
    for item in inputs:
        body = json.loads(item['messages'][1]['content'].split('CURRENT_OBSERVATION:\n')[1])
        state = contexts[item['engineering_case']]['frame']
        assert body['all13_current_VM_pu'] == dict(zip(map(str, range(13)), state['current_VM']))
        assert body['actual_past_verifier_feedback'] == []
        assert set(body) == {'zone', 'round', 'all13_current_VM_pu', 'local_bus_ids', 'native_zone_controls', 'actual_past_verifier_feedback'}
    worker = ast.parse((R / 'work/run_native13_fullband_lora_remote_20261021.py').read_text(encoding='utf-8'))
    generates = [n for n in ast.walk(worker) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'generate']
    assert len(generates) == 1
    keywords = {k.arg: ast.literal_eval(k.value) for k in generates[0].keywords if k.arg in ['do_sample', 'num_beams', 'max_new_tokens']}
    assert keywords == {'do_sample': False, 'num_beams': 1, 'max_new_tokens': 384}
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ['runpp', 'backward', 'step', 'train'] for n in ast.walk(worker))
    host = (R / 'work/run_native13_fullband_original_adapter_colab_20261021.py').read_text(encoding='utf-8')
    assert host.count('client.assign(') == 1 and "arm='public_0_5B'" in host
    assert "assert not client.list_assignments()" in host
    assert "same_exact_assignment_unavailable" in host and 'all_actual_closed_artifacts_preserved' in host
    assert protocol['science_process_seconds'] == 1200 and protocol['fixed_actual_generations'] == 12
    assert protocol['setup_seconds'] == 1800 and protocol['collector_seconds'] == 1500
    payload = read(P / 'Cloud_Payload_Manifest.json')
    archive = R / payload['archive']
    assert sha(archive) == payload['sha256'] and archive.stat().st_size == payload['bytes']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == payload['members'] == 18
        assert not any('credential' in name.lower() or 'network' in name.lower() or 'train.json' in name.lower() for name in z.namelist())
        manifest = json.loads(z.read('PUBLIC_SIZE_INPUT_MANIFEST.json'))
        for name, item in manifest.items():
            raw = z.read(name)
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_INDEPENDENT_PROSPECTIVE_NEW_ROLE_MODEL_INTERFACE_LAUNCH_REVIEW',
              'objective': 'Functional positive/negative literal native support, not measured policy superiority.',
              'all6_exact_current_prefixes': True, 'one_selected_T4_no_fallback': True,
              'immutable_protocol_sha256': sha(P / 'Frozen_Engineering_Protocol.json'),
              'payload_sha256': payload['sha256'], 'all18_CRC_and_member_hashes': True,
              'zero_model_PF_optimizer_GPU_calls_by_review': True,
              'physical_performance_and_training_still_not_authorized_by_readiness': True}
    with (P / 'Independent_Preallocation_Review.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
