"""A new initial-slot contract gate; no historical controller/model/physics replay."""
import argparse, ast, gzip, hashlib, json, math, os, sys, time, traceback, types
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/initial_reflection_target_compatibility_20261011'
OLD=ROOT/'outputs/critical_research_reset_20261010/original_role_numeric_gate_20261011/execution'
SOURCES={
 'rescue':ROOT/'work/e/audit/phase2g_rescue_runner.py',
 'guided':ROOT/'work/e/audit/phase2g_llm_guided_rescue_runner.py',
 'reflection':ROOT/'work/e/audit/run_reflection_v4_safety_envelope.py',
 'teacher':Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2a_extract_zone_data_corrected.py'),
 'metadata':ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json',
 'campaign':ROOT/'work/run_matched_campaign.py',
 'loader':ROOT/'work/frozen_physics_loader.py',
}
NAMES={
 'rescue':['global_uv_buses','extract_zone_state_full'],
 'guided':['get_zone_candidate_buses','action_bus','validate_action_against_candidates'],
 'reflection':['_safe_bus_q','init_feedback_state','build_compact_feedback_text','severity_stage','build_two_best_prompt_v2'],
}
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text('utf8'))
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,ensure_ascii=False,allow_nan=False);f.flush();os.fsync(f.fileno())
def compact(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def prepare():
 p=OUT/'preparation';p.mkdir(parents=True,exist_ok=False)
 old=read(OLD/'Closed_Manifest.json')
 needed=['FIT_Current_Packets_And_Targets.json.gz','HELD_Current_Packets_And_Targets.json.gz','All_Row_Identities.json']
 protocol={'at_utc':now(),'source_sha256':sha(Path(__file__)),'source_files':{k:{'path':str(v),'sha256':sha(v)} for k,v in SOURCES.items()},
  'old_closed_manifest_sha256':sha(OLD/'Closed_Manifest.json'),'old_input_members':{k:old['members'][k] for k in needed},
  'question':'Are exact existing localteacher proposed_action/null VALUE targets compatible with actual mandatory-global Reflection-v2 INITIAL action requirements?',
  'target_format_scope':'Checks proposed_action VALUE compatibility after deterministic lossless compact bus/Q transcription through the existing nested/compact action parser; does NOT certify unchanged full original assistant target format or generated text',
  'scope':'All109worlds436world-zone observations/16000originalTRAIN identities; join four CURRENT local bus maps only by administrative world group, never teacher summaries/verification/AFTER',
  'coherence':'Four metadata zones with exact own scope, disjoint bus ownership and union0..117; every boundary voltage agrees with joined CURRENT map within1e-10; exact packet repetitions already independently certified',
  'provenance':'Teacher source demonstrates same initial parent snapshot and deepcopy trials, but exact historical execution/augmentation/snapshot lineage remains UNKNOWN. Derived observation is not regenerated original asset or new solved state',
  'actual_functions':NAMES,'definition_loading':'Unchanged function ASTs and literal config ONLY. No full module imports, controller loops, runpp, verify_action, generate, normalizers/repairs, forecasts or tokenization',
  'known_initial_history':'Only first sorted zone has known empty history before new proposal. Later zero-memory zone prompts are explicitly counterfactual compatibility fixtures, never actual deployed calls',
  'no_call':'If global UV=0 actual loop terminates; no model slot. If no candidates caller bypasses; retain no-call identities',
  'target_categories':['NO_LIVE_SLOT_GLOBAL_HEALTHY','NO_LIVE_SLOT_NO_CANDIDATES','MANDATORY_NULL_UNSUPPORTED','TARGET_SCHEMA_OR_Q_UNSUPPORTED','TARGET_BUS_OUTSIDE_CANDIDATES','GRAMMAR_COMPATIBLE_NOT_PHYSICS_CERTIFIED'],
  'fixed_reuse_gate':'Any mandatory-null/bus/Q/schema conflict FAILS direct unmodified reuse of all original localteacher targets for this contract; missing measurements remain UNKNOWN. No target rewriting/dropping/choosing useful worlds. No-go is scoped role compatibility, not measured learning/physical failure',
  'history_support':'Never insert predicted or unseen receipts. Within-iteration and future feedback UNKNOWN; no full-episode/history training support certified',
  'bound_seconds':120,'fits_forwards_PF_optimizer_controller_forecast_tokenizer_cloud_calls':0,'no_automatic_learning_GPU_or_physical_launch':True}
 write(p/'Protocol.json',protocol);print(str(p))

def definitions(name):
 path=SOURCES[name];tree=ast.parse(path.read_text('utf8'));kept=[]
 wanted=set(NAMES[name]);found=set()
 for n in tree.body:
  if isinstance(n,ast.FunctionDef) and n.name in wanted:kept.append(n);found.add(n.name)
  elif isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id.isupper():
   try:ast.literal_eval(n.value)
   except (ValueError,TypeError):continue
   kept.append(n)
 assert found==wanted
 original={n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in wanted}
 selected={n.name:ast.dump(n,include_attributes=False) for n in kept if isinstance(n,ast.FunctionDef)};assert original==selected
 namespace={'json':json,'deque':deque}
 exec(compile(ast.Module(body=kept,type_ignores=[]),str(path),'exec'),namespace)
 return namespace,{'source_sha256':sha(path),'function_ast_sha256':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in original.items()},'full_module_imported':False}

def run():
 protocol=read(OUT/'preparation/Protocol.json');assert sha(Path(__file__))==protocol['source_sha256']
 reader_lock=read(OUT/'preparation/Reader_Source_Lock.json')
 readiness=ROOT/'work/initial_reflection_target_reader_readiness_20261011.json'
 assert sha(ROOT/'work/audit_initial_reflection_target_compatibility_20261011.py')==reader_lock['reader_source_sha256']
 assert sha(readiness)==reader_lock['reader_readiness_sha256']
 assert datetime.fromisoformat(read(readiness)['prepared_at_utc'])<datetime.fromisoformat(now())
 for k,v in SOURCES.items():assert sha(v)==protocol['source_files'][k]['sha256']
 assert sha(OLD/'Closed_Manifest.json')==protocol['old_closed_manifest_sha256']
 for k,v in protocol['old_input_members'].items():assert (OLD/k).stat().st_size==v['bytes'] and sha(OLD/k)==v['sha256']
 out=OUT/'execution';out.mkdir(exist_ok=False);start=time.perf_counter()
 write(out/'owner.claim',{'actual_pid':os.getpid(),'at_utc':now(),'command':sys.argv,'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(OUT/'preparation/Protocol.json')})
 calls={'observed_zone_extract_returns':0,'observed_global_uv_extract_returns':0,'candidate_function_returns':0,'pure_prompt_fixture_returns':0,'faithful_initial_FIRST_ZONE_template_returns':0,'counterfactual_later_empty_history_fixture_returns':0,'new_model_PF_optimizer_controller_forecast_tokenizer_cloud_calls':0}
 try:
  import pandas as pd
  functions={};cert={}
  for name in NAMES:functions[name],cert[name]=definitions(name)
  write(out/'Unchanged_Actual_Function_AST_Certificates.json',cert)
  metadata=read(SOURCES['metadata']);zones={k:[int(b) for b in bs] for k,bs in metadata['zones'].items()};assert set(zones)=={'MG1','MG2','MG3','MG4'}
  global_scope={b for bs in zones.values() for b in bs};assert global_scope==set(range(118)) and sum(map(len,zones.values()))==118
  grouped=defaultdict(dict)
  for member in ['FIT_Current_Packets_And_Targets.json.gz','HELD_Current_Packets_And_Targets.json.gz']:
   with gzip.open(OLD/member,'rt',encoding='utf8') as f:records=json.load(f)
   for record in records:
    w=record['world_sha256'];zone=record['packet']['zone'];assert zone not in grouped[w];grouped[w][zone]=record
  rows=read(OLD/'All_Row_Identities.json');assert len(rows)==16000 and len(grouped)==109
  pair_results=[];world_results=[];fixtures=[];unknown_worlds=[]
  for w,views in sorted(grouped.items()):
   assert time.perf_counter()-start<protocol['bound_seconds']
   if set(views)!=set(zones):unknown_worlds.append({'world_sha256':w,'reason':'missing_or_extra_zone'});continue
   joined={};issues=[]
   for z,r in views.items():
    local=r['packet']['local_measurements'];vm=local.get('bus_voltages')
    if not isinstance(vm,dict) or {int(b) for b in vm}!=set(zones[z]):issues.append(z+':scope');continue
    for b,v in vm.items():
     if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v):issues.append(z+':nonfinite');continue
     assert int(b) not in joined;joined[int(b)]=float(v)
   if set(joined)!=global_scope:issues.append('global_scope')
   for z,r in views.items():
    boundary=r['packet']['local_measurements'].get('boundary_voltages')
    if not isinstance(boundary,dict):issues.append(z+':boundary_missing');continue
    for b,v in boundary.items():
     if isinstance(v,bool) or not isinstance(v,(int,float)) or int(b) not in joined or not math.isfinite(v) or abs(joined[int(b)]-v)>1e-10:issues.append(z+':boundary_mismatch')
   if issues:unknown_worlds.append({'world_sha256':w,'reasons':issues});continue
   net=types.SimpleNamespace(bus=types.SimpleNamespace(index=sorted(global_scope)),res_bus=pd.DataFrame({'vm_pu':[joined[b] for b in sorted(joined)]},index=sorted(joined)))
   uv=functions['rescue']['global_uv_buses'](net);calls['observed_global_uv_extract_returns']+=1
   stage,_=functions['reflection']['severity_stage'](len(uv))
   world_results.append({'world_sha256':w,'joined_current_vm_sha256':hashlib.sha256(compact(joined).encode()).hexdigest(),'initial_global_UV_count':len(uv),'stage':stage,'observed_current_join_complete':True,'historical_snapshot_lineage':'UNKNOWN','FIRST_ZONE':sorted(zones)[0]})
   for slot,z in enumerate(sorted(zones)):
    r=views[z];zs=functions['rescue']['extract_zone_state_full'](net,z,zones);calls['observed_zone_extract_returns']+=1
    cands=functions['guided']['get_zone_candidate_buses'](net,z,zones,zs);calls['candidate_function_returns']+=1
    action=r['action'];bus=None;q=None
    if not uv:category='NO_LIVE_SLOT_GLOBAL_HEALTHY'
    elif not cands:category='NO_LIVE_SLOT_NO_CANDIDATES'
    elif action is None:category='MANDATORY_NULL_UNSUPPORTED'
    else:
     sh=action.get('add_shunts_q_mvar') if isinstance(action,dict) else None
     if not isinstance(sh,dict) or len(sh)!=1:category='TARGET_SCHEMA_OR_Q_UNSUPPORTED'
     else:
      try:bus=int(next(iter(sh)))
      except (TypeError,ValueError):bus=None
      q=next(iter(sh.values()))
      if bus is None or isinstance(q,bool) or not isinstance(q,(int,float)) or not math.isfinite(q) or q not in functions['reflection']['ALLOWED_Q']:category='TARGET_SCHEMA_OR_Q_UNSUPPORTED'
      elif bus not in cands:category='TARGET_BUS_OUTSIDE_CANDIDATES'
      else:category='GRAMMAR_COMPATIBLE_NOT_PHYSICS_CERTIFIED'
    kind='NO_LIVE_CALL' if not uv or not cands else 'INITIAL_FIRST_ZONE_SOURCE_TEMPLATE' if slot==0 else 'COUNTERFACTUAL_EMPTY_HISTORY_LATER_ZONE'
    prompt_sha=None
    if uv and cands:
     mem=functions['reflection']['init_feedback_state']()
     messages=functions['reflection']['build_two_best_prompt_v2']('reflection_v2',zs,uv,cands,[],mem)
     prompt_sha=hashlib.sha256(compact(messages).encode()).hexdigest();calls['pure_prompt_fixture_returns']+=1
     calls['faithful_initial_FIRST_ZONE_template_returns' if slot==0 else 'counterfactual_later_empty_history_fixture_returns']+=1
     fixtures.append({'world_sha256_ADMIN_NOT_FORWARD':w,'zone':z,'kind':kind,'messages':messages,'prompt_sha256':prompt_sha,'teacher_target_NOT_FORWARD':action,'history_status':'EMPTY_INITIAL_SOURCE_TEMPLATE' if slot==0 else 'UNKNOWN_ACTUAL;EMPTY_ONLY_FIXTURE'})
    pair_results.append({'world_sha256':w,'zone':z,'input_sha256':r['input_sha256'],'teacher_action_sha256':r['action_sha256'],'rows':r['multiplicity'],'initial_global_UV_count':len(uv),'candidates':cands,'zone_state':zs,'nominal_teacher_bus':bus,'nominal_teacher_Q':q,'category':category,'prompt_kind':kind,'prompt_sha256':prompt_sha,'historical_snapshot_lineage':'UNKNOWN','teacher_physics_acceptance':'UNKNOWN_INDEPENDENT_CERTIFICATE'})
  categories=Counter(x['category'] for x in pair_results);rowcounts=Counter()
  for x in pair_results:rowcounts[x['category']]+=x['rows']
  conflicts=sum(categories[k] for k in ['MANDATORY_NULL_UNSUPPORTED','TARGET_SCHEMA_OR_Q_UNSUPPORTED','TARGET_BUS_OUTSIDE_CANDIDATES'])
  disposition='DIRECT_UNMODIFIED_TARGET_REUSE_FAIL' if conflicts else 'UNKNOWN_COHEENCE_OR_HISTORY' if unknown_worlds else 'INITIAL_GRAMMAR_COMPATIBLE_FULL_HISTORY_PHYSICS_UNKNOWN'
  first=[x for x in pair_results if x['prompt_kind']=='INITIAL_FIRST_ZONE_SOURCE_TEMPLATE']
  report={'at_utc':now(),'all_original_rows_retained':True,'original_rows':len(rows),'worlds':len(grouped),'observed_worlds_current_join_complete':len(world_results),'unknown_worlds':unknown_worlds,'world_zone_pairs_checked':len(pair_results),'categories_by_pair':dict(categories),'categories_by_original_row':dict(rowcounts),'mandatory_target_conflicts':conflicts,'fixed_gate':disposition,'first_zone_templates':len(first),'first_zone_template_categories':dict(Counter(x['category'] for x in first)),'all_later_actual_history':'UNKNOWN','exact_historical_execution_snapshot_lineage':'UNKNOWN','physical_outcome_and_LLM_advantage':'UNMEASURED','sourceconsistent_currentjoin_not_original_asset_regeneration':True,'no_automatic_learning_or_GPU':True}
  write(out/'All_World_Current_Joins.json',world_results);write(out/'All_Initial_Contract_Compatibility_Records.json',pair_results);write(out/'Results.json',report)
  with gzip.open(out/'Pure_Prompt_Fixtures_NO_MODEL.json.gz','wt',encoding='utf8') as f:json.dump(fixtures,f,ensure_ascii=False,allow_nan=False)
 except BaseException as ex:
  write(out/'Failure.json',{'error':repr(ex),'traceback':traceback.format_exc(),'no_scientific_retry':True});raise
 finally:
  calls['workflow_seconds_before_manifest']=time.perf_counter()-start;write(out/'Actual_Costs.json',calls)
  complete=(out/'Results.json').exists() and not (out/'Failure.json').exists()
  members={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}
  write(out/'Closed_Manifest.json',{'at_utc':now(),'members':members,'complete':complete,'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(OUT/'preparation/Protocol.json')})
  write(out/'status.json',{'state':'ENDED_COMPLETE' if complete else 'ENDED_PARTIAL','actual_pid':os.getpid(),'manifest_closed':True,'at_utc':now()})

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--execute-authorized',action='store_true');a=ap.parse_args();assert a.prepare!=a.execute_authorized
 if a.prepare:prepare()
 else:run()
