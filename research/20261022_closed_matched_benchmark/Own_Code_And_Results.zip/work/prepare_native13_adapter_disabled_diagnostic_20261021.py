"""One prospective adapter-effect diagnostic; not a rescue of failed primary.

Same6prefixes/base/decoder/seed/precision/preservation. Only generation-time
LoRA activation changes. All control outputs are retained, no physical rollout.
"""
import ast
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
OLD = R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'
P = R / 'outputs/native13_adapter_disabled_diagnostic_preparation_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    with Path(p).open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, allow_nan=False)


def script(name, text):
    ast.parse(text)
    with (R / 'work' / name).open('x', encoding='utf-8') as f:
        f.write(text)


def main():
    reference = read(R / 'outputs/native13_fullband_model_terminal_artifact_certification_v2_20261021/Terminal_Artifact_Certification.json')
    assert reference['source_bound_reader_completed_artifacts'] and reference['actual_runtime_released']
    assert reference['fixed_functional_gate'].startswith('FAIL_')
    P.mkdir(exist_ok=False)
    for name in ['All6_Messages_And_Token_IDs.json', 'All2_Exact_Engineering_Cases.json']:
        shutil.copyfile(OLD / name, P / name)
        assert sha(P / name) == sha(OLD / name)
    p = read(OLD / 'Frozen_Engineering_Protocol.json')
    p.update(at_utc=datetime.now(timezone.utc).isoformat(),
        study='POST_FAILURE_PROSPECTIVE_ADAPTER_EFFECT_DIAGNOSTIC_NOT_A_PRIMARY_MODEL_REPLACEMENT',
        scientific_question='On the identical six native prompts, does disabling the original shunt-trained LoRA change literal-command validity? Separate adapter transfer from pinned-base/context behavior before deciding any learning investment.',
        model_treatment='Same pinned0.5B NF4 base and copied private adapter, but adapter DISABLED during every generation and forward. No weight editing, alternate model or prompt/decoder/case selection.',
        interpretation='Post-failure diagnostic, not prespecified primary superiority evidence. Private-adapter6/6invalid primary remains stopped; any control success cannot repair/promote it. No PF or full benchmark from either diagnostic outcome.',
        conditional_physics='NO physical action, training or automatic promotion, regardless of control outputs.',
        stage_stop='Exactly one adapter-disabled control, six primary plus six cold generations. No prompt/model/seed/decoder sweeps or primary-result replacement.',
        original_model_reference='outputs/native13_fullband_original_adapter_engineering_independent_20261021/Independent_Functional_Audit.json')
    put(P / 'Frozen_Engineering_Protocol.json', p)
    worker = (R / 'work/run_native13_fullband_lora_remote_20261021.py').read_text(encoding='utf-8')
    assert worker.count('with torch.inference_mode():sequence=') == 1
    worker = worker.replace('with torch.inference_mode():sequence=',
        'with model.disable_adapter(), torch.inference_mode():\n                assert all(not s.enabled for s in model.get_layer_status())\n                sequence=')
    worker = worker.replace("            costs['pretrained_forward_attempts']+=1;", "            assert all(not s.enabled for s in model.get_layer_status())\n            costs['pretrained_forward_attempts']+=1;")
    worker = worker.replace("'actual_forward_returns':len(new)", "'actual_forward_returns':len(new),'adapter_disabled_during_generation':True")
    worker = worker.replace('COMPLETE_ALL6_ORIGINAL_TRAINED_LORA_PRIMARY_AND_FRESH_MODEL_COLD_FULLBAND_ENGINEERING_OUTPUTS',
                            'COMPLETE_ALL6_ADAPTER_DISABLED_CONTROL_PRIMARY_AND_COLD_OUTPUTS')
    worker = worker.replace("'private_weights_unchanged':True", "'private_weights_unchanged':True,'model_treatment':'ADAPTER_DISABLED_CONTROL_NOT_ORIGINAL_PRIVATE_MODEL'")
    script('run_native13_adapter_disabled_remote_20261021.py', worker)
    guardian = (R / 'work/native13_fullband_lora_guardian_20261021.py').read_text(encoding='utf-8').replace('run_native13_fullband_lora_remote_20261021.py', 'run_native13_adapter_disabled_remote_20261021.py')
    script('native13_adapter_disabled_guardian_20261021.py', guardian)
    host = (R / 'work/run_native13_fullband_original_adapter_colab_20261021.py').read_text(encoding='utf-8')
    host = host.replace('native13_fullband_original_adapter_engineering_preparation_20261021', P.name)
    host = host.replace('native13_fullband_original_adapter_engineering_execution_20261021', 'native13_adapter_disabled_diagnostic_execution_20261021')
    host = host.replace('native13_fullband_lora_guardian_20261021.py', 'native13_adapter_disabled_guardian_20261021.py')
    assert host.count('client.assign(') == 1 and "arm='public_0_5B'" in host
    script('run_native13_adapter_disabled_colab_20261021.py', host)
    reader = (R / 'work/audit_native13_fullband_original_adapter_engineering_20261021.py').read_text(encoding='utf-8')
    reader = reader.replace('native13_fullband_original_adapter_engineering_preparation_20261021', P.name)
    reader = reader.replace('native13_fullband_original_adapter_engineering_execution_20261021', 'native13_adapter_disabled_diagnostic_execution_20261021')
    reader = reader.replace('native13_fullband_original_adapter_engineering_independent_20261021', 'native13_adapter_disabled_diagnostic_independent_20261021')
    reader = reader.replace('run_native13_fullband_original_adapter_colab_20261021.py', 'run_native13_adapter_disabled_colab_20261021.py')
    reader = reader.replace('run_native13_fullband_lora_remote_20261021.py', 'run_native13_adapter_disabled_remote_20261021.py')
    reader = reader.replace('COMPLETE_ALL6_ORIGINAL_TRAINED_LORA_PRIMARY_AND_FRESH_MODEL_COLD_FULLBAND_ENGINEERING_OUTPUTS',
                            'COMPLETE_ALL6_ADAPTER_DISABLED_CONTROL_PRIMARY_AND_COLD_OUTPUTS')
    reader = reader.replace("    from coordinate_native_inverter_linear_reference_20261020 import process", "    import time\n    wait_started=time.monotonic()\n    while not (O / 'Launcher_ACK.json').exists():\n        assert time.monotonic()-wait_started < 60, 'No unacknowledged reader execution'\n        time.sleep(.1)\n    from coordinate_native_inverter_linear_reference_20261020 import process")
    reader = reader.replace("        assert a['token_ids'] == b['token_ids']", "        assert a['adapter_disabled_during_generation'] and b['adapter_disabled_during_generation']\n        assert a['token_ids'] == b['token_ids']")
    reader = reader.replace("'PASS_FUNCTIONAL_SUPPORT_ONLY_NO_AUTOMATIC_PHYSICS' if passed else 'FAIL_FIXED_FULLBAND_ORIGINAL_ADAPTER_INTERFACE_STOP_NO_RETUNING'",
                            "'CONTROL_BASE_NATIVE_SUPPORT_PRESENT_NOT_PRIMARY_RESCUE' if passed else 'CONTROL_BASE_NATIVE_SUPPORT_ABSENT_NOT_UNIVERSAL_INABILITY'")
    reader = reader.replace("             'not_a_full_controller_physics_or_superiority_result': True,", "             'not_a_full_controller_physics_or_superiority_result': True,\n             'model_treatment': 'ADAPTER_DISABLED_CONTROL_NOT_ORIGINAL_PRIVATE_MODEL',\n             'original_private_reference_valid_outputs': 0,\n             'identical_six_input_file_sha256': sha(P / 'All6_Messages_And_Token_IDs.json'),")
    reader = reader.replace("'next': 'If functional gate fails, stop this exact intervention. If it passes, complete/freeze a full physical executor/persistent-state/paid-history/strong-control/independent-reader protocol before any physical campaign. No prompt/decoder/model rescue.'",
        "'next': 'Report the paired diagnostic and preserve the original private-model failed gate. Neither outcome licenses prompt/model rescue, retraining, physical rollout, or LLM superiority.'")
    script('audit_native13_adapter_disabled_diagnostic_20261021.py', reader)
    coordinator = (R / 'work/coordinate_native13_fullband_original_adapter_engineering_20261021.py').read_text(encoding='utf-8')
    coordinator = coordinator.replace('native13_fullband_original_adapter_engineering_preparation_20261021', P.name)
    coordinator = coordinator.replace('native13_fullband_original_adapter_engineering_handoff_20261021', 'native13_adapter_disabled_diagnostic_handoff_20261021')
    script('coordinate_native13_adapter_disabled_diagnostic_20261021.py', coordinator)
    authority = read(OLD / 'Direct_Human_Authority.json')
    authority.update(interpretation='One controlled original-adapter activation diagnostic on identical6causal inputs; no successful-control substitution for failed primary, no prompt changes, model sweep, physics, training or guaranteed win.')
    put(P / 'Direct_Human_Authority.json', authority)
    sources = ['run_native13_adapter_disabled_remote_20261021.py', 'native13_adapter_disabled_guardian_20261021.py',
               'native13_lora_setup_remote_v2_20261020.py', 'native13_lora_environment_check_v2_20261020.py',
               'candidate_process_pretrained_loader_native13_v2_20261020.py', 'public_size_u61_preservation.py',
               'frozen_gpu_requirements.txt', 'frozen_dependency_closure.txt', 'uv_bootstrap_version.txt']
    files = {'work/' + n: R / 'work' / n for n in sources}
    for n, h in p['private_adapter_tokenizer_unchanged'].items():
        f = R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1' / n
        assert sha(f) == h
        files['work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/' + n] = f
    files['prep/protocol.json'] = P / 'Frozen_Engineering_Protocol.json'
    files['prep/All6_Messages_And_Token_IDs.json'] = P / 'All6_Messages_And_Token_IDs.json'
    manifest = {n: {'bytes': f.stat().st_size, 'sha256': sha(f)} for n, f in files.items()}
    archive = P / 'Controlled_Adapter_Disabled_Inputs_Only.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for n, f in files.items():
            z.write(f, n)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for n, item in manifest.items():
            raw = z.read(n)
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    put(P / 'Cloud_Payload_Manifest.json', {'archive': archive.relative_to(R).as_posix(), 'bytes': archive.stat().st_size,
        'sha256': sha(archive), 'members': len(manifest) + 1,
        'human_authority_source': (P / 'Direct_Human_Authority.json').relative_to(R).as_posix(),
        'human_authority_sha256': sha(P / 'Direct_Human_Authority.json')})
    all_sources = sources + ['run_native13_adapter_disabled_colab_20261021.py',
        'coordinate_native13_adapter_disabled_diagnostic_20261021.py', 'audit_native13_adapter_disabled_diagnostic_20261021.py',
        'native13_fullband_hybrid_contract_20261021.py', 'paper_native13_causal_contract_v2_20261021.py',
        'check_native_parser_contract_v3_20261021.py', 'public_size_local_preservation_v2.py',
        'google_account_profile.py', 'coordinate_single_source_bound_owner_20261020.py']
    hashes = {'work/' + n: sha(R / 'work' / n) for n in all_sources}
    for n in ['Frozen_Engineering_Protocol.json', 'All6_Messages_And_Token_IDs.json', 'All2_Exact_Engineering_Cases.json', 'Cloud_Payload_Manifest.json', 'Direct_Human_Authority.json']:
        hashes[(P / n).relative_to(R).as_posix()] = sha(P / n)
    from candidate_process_evidence_utils import frozen_checks
    put(P / 'Launch_Readiness_Audit.json', {'passed': True, 'at_utc': datetime.now(timezone.utc).isoformat(),
        'source_hashes': hashes, 'fixed_single_activation_factor_comparison': True,
        'same6_prefixes_no_retokenization_or_primary_rerun': True,
        'single_original_profile_oneassign_no_account_fallback': True,
        'adapter_disabled_asserted_each_generation_AND_each_forward': True,
        'reader_waits_actual_PID_launcher_ACK_before_analysis': True,
        'same_quantized_model_pins_and_full_hashed_ACK_preservation': True,
        'no_PF_training_or_promotion_of_control_success': True,
        'frozen_original_checks': frozen_checks()})
    for kind, source, output, coord, python, bound in [
        ('Primary', 'run_native13_adapter_disabled_colab_20261021.py', 'native13_adapter_disabled_diagnostic_execution_20261021',
         'native13_adapter_disabled_diagnostic_coordination_20261021', 'colab_access_env', 3900),
        ('Reader', 'audit_native13_adapter_disabled_diagnostic_20261021.py', 'native13_adapter_disabled_diagnostic_independent_20261021',
         'native13_adapter_disabled_diagnostic_reader_coordination_20261021', 'vcsa_module_env', 600)]:
        put(P / (kind + '_Owner_Protocol.json'), {'single_owner': {'source': 'work/' + source, 'sha256': sha(R / 'work' / source),
            'output': 'outputs/' + output, 'coordination': 'outputs/' + coord,
            'python': 'work/' + python + '/Scripts/python.exe', 'bound_seconds': bound}, 'require_ended_claims': []})
    print(json.dumps({'status': 'PREPARED_SINGLE_ADAPTER_ACTIVATION_DIAGNOSTIC_NOT_PRIMARY_RESCUE',
                      'payload_bytes': archive.stat().st_size, 'same6input_sha256': sha(P / 'All6_Messages_And_Token_IDs.json'),
                      'actual_allocation_model_PF_calls_by_preparation': 0}))


if __name__ == '__main__':
    main()
