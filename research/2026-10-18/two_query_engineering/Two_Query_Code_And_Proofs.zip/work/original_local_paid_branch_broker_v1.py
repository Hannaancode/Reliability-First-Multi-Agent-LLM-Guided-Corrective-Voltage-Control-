"""Causal original LOCAL proposal -> bounded paid branch acquisition.

The original trained model chooses only recipient/nominalQ through its existing
mandatory prompt and parser. A common numerical broker chooses a legal ordinary
or owned-donor variant by an already-source-bound causal ordering. No solver,
model, receipt lookup, future label, commitment or launch is implemented here.
"""
import math

Q_GRID=(25.,50.,75.,100.,125.,150.,200.,250.,300.)
ID_KEYS={'kind','receiver','q','donor_index','donor_bus','universe_index'}

def validate_causal_universe(rows,ordering,cursor):
    assert all(set(r)==ID_KEYS for r in rows)
    ids=[r['universe_index'] for r in rows]
    assert len(ids)==len(set(ids)) and len(ordering)==len(ids) and set(ordering)==set(ids)
    assert all(type(i) is int for i in ids+ordering)
    assert cursor['withdrawals_refund_positive_addition_cap'] is False
    stock={r['index']:r for r in cursor['owned_bank_rows']}
    for row in rows:
        assert row['kind'] in ('ordinary','equal_owned_reallocation')
        assert type(row['receiver']) is int and row['receiver'] in cursor['raw_current_receiver_scope']
        assert math.isfinite(row['q']) and row['q'] in Q_GRID
        if row['kind']=='ordinary':assert row['donor_index'] is None and row['donor_bus'] is None
        else:
            assert row['donor_index'] in stock and stock[row['donor_index']]['bus']==row['donor_bus']
            assert row['receiver']!=row['donor_bus']
    return {r['universe_index']:r for r in rows}

def resource_eligible(row,cursor):
    if cursor['positive_addition_lifetime_MVAr'].get(str(row['receiver']),0.)+row['q']>450:return False
    if row['kind']=='ordinary':return cursor['remaining_original_device_operation_slots']>=1
    stock=next(r for r in cursor['owned_bank_rows'] if r['index']==row['donor_index'])
    return cursor['remaining_original_device_operation_slots']>=2 and -stock['q_mvar']>=row['q']

def original_LOCAL_prior_branches(parsed_by_zone,*,domain,ordering,normalize,validate):
    """At most4 original LOCAL priors; cannot fill bad/null/duplicate outputs.

    Only identities and an ordering of those identities enter the common broker.
    Original parser/normalizer/candidate validation are provided unchanged by the
    frozen caller. Reports carry no fictional model inference/performance proof.
    """
    rows=domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
    cursor=domain['expanded_cursor_for_separately_fixed_future_protocol']
    indexed=validate_causal_universe(rows,ordering,cursor)
    assert set(parsed_by_zone)==set(domain['original_LOCAL_allowed_per_zone']) and len(parsed_by_zone)==4
    selected=[];seen=set();reports=[]
    for zone in sorted(parsed_by_zone):
        normalized=normalize(parsed_by_zone[zone])
        if normalized is None:
            reports.append({'zone':zone,'status':'ORIGINAL_NORMALIZER_NULL_OR_INVALID_NO_QUERY'});continue
        valid,reason=validate(normalized,domain['original_LOCAL_allowed_per_zone'][zone])
        if not valid:
            reports.append({'zone':zone,'status':'ORIGINAL_CANDIDATE_REJECT_NO_QUERY','reason':reason});continue
        assert set(normalized)=={'add_shunts_q_mvar'} and len(normalized['add_shunts_q_mvar'])==1
        bus,q=next(iter(normalized['add_shunts_q_mvar'].items()));bus=int(bus);q=float(q)
        if q not in Q_GRID:
            reports.append({'zone':zone,'status':'NEW_Q9_NOT_ELIGIBLE_ORIGINAL_PARSER_UNCHANGED','bus':bus,'q':q});continue
        options=[indexed[i] for i in ordering if indexed[i]['receiver']==bus and indexed[i]['q']==q and resource_eligible(indexed[i],cursor)]
        if not options:
            reports.append({'zone':zone,'status':'NO_LEGAL_BUDGET_STOCK_CAP_VARIANT_NO_QUERY','bus':bus,'q':q});continue
        row=options[0]
        if row['universe_index'] in seen:
            reports.append({'zone':zone,'status':'DUPLICATE_PROPOSAL_NO_EXTRA_QUERY','universe_index':row['universe_index']});continue
        selected.append(dict(row));seen.add(row['universe_index'])
        reports.append({'zone':zone,'status':'CAUSAL_BRANCH_ID_ONLY_REQUIRES_PAID_PHYSICS','universe_index':row['universe_index']})
    assert len(selected)<=4
    return {'selected_branch_identities':selected,'reports':reports,'model_role':'ORIGINAL_LOCAL_RECIPIENT_AND_Q_PRIOR_ONLY',
            'donor_role':'SHARED_CAUSAL_NUMERICAL_ORDERING_NOT_A_LANGUAGE_CHOICE',
            'no_generation_or_physics_performed':True,'no_actual_commit':True}

def numerical_only_branches(*,domain,ordering,budget=4):
    assert type(budget) is int and budget==4
    rows=domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
    cursor=domain['expanded_cursor_for_separately_fixed_future_protocol']
    indexed=validate_causal_universe(rows,ordering,cursor)
    return [dict(indexed[i]) for i in ordering if resource_eligible(indexed[i],cursor)][:budget]
