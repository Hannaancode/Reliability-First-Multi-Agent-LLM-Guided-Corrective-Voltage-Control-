# Current execution allocation

The two Google CLI credential profiles are separate. They do not imply two currently available GPUs. The previous profile is unchanged; the isolated profile owns the verified Tesla T4 used for central model inference. No credential values belong in this report or research exports.

| Resource | Assigned work | Reason |
|---|---|---|
| PC CPU | Existing AC reference campaign, physical replays, statistics, figures, and final packaging | These functions use the frozen CPU numerical implementation. No GPU is allocated for these standalone tasks. |
| Isolated Google CLI / current T4 | Two historical central development cases, then the matched 62-case central/zonal inference campaign if development passes | Actual frozen-model CUDA inference is required by the current implementation. Both paired branches remain in the same campaign with frozen order/RNG controls. Numerical verification uses the runtime's CPU inside this mixed inference workflow. |
| Previous Google CLI | No active assignment while the current T4 can complete the required inference | Avoid duplicate work and unnecessary allocation. Do not divide one paired campaign across concurrent writers or assume an unpublished reset schedule. |
| Completion supervisor | Observe existing CPU and central jobs, perform complete-ledger integration, then verify the final package | It observes the already-running isolated central campaign and cannot allocate a duplicate GPU in this mode. |

The model, network, numerical control settings, and 62-case bank remain unchanged. Completed case/RNG files are downloaded during execution. A failed or interrupted job retains complete checkpoints; missing results are not regenerated or imputed.

[Google's Colab FAQ](https://research.google.com/colaboratory/faq.html) does not publish a fixed 24-hour GPU quota reset. Free sessions can last at most 12 hours depending on availability and usage. The FAQ's advice to wait a day concerns Drive I/O quota, rather than a guaranteed GPU reset. Allocation must be verified by actual assignment and CUDA execution.

Evidence: `isolated_cli_validation.json`, `isolated_gpu_execution_verification.json`, `colab_frozen_restore_status.json`, `next_gpu_stage_status.json`, and `ordered_completion_status.json`. These are execution records, not evidence of a learned-controller performance benefit.
