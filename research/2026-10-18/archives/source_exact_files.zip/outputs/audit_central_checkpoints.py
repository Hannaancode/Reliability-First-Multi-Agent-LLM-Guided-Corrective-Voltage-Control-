from pathlib import Path
import hashlib,json
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack
from physical_replay_audit import replay,save
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json');rows=[]
for p in sorted(Path('outputs/central_matched_campaign/cases').glob('*.json')):
    target=Path('outputs/central_physical_replay/cases')/p.name;sf=ROOT/'bank/scenarios'/p.name;d=json.loads(p.read_text());identity={'case_sha256':sha(p),'scenario_sha256':sha(sf),'physical_audit_source_sha256':sha('work/physical_replay_audit.py'),'wrapper_sha256':sha(__file__)}
    if target.exists() and json.loads(target.read_text())['identity']==identity:r=json.loads(target.read_text())
    else:r={'scenario_id':p.stem,'identity':identity,'platform':'local Windows CPU, discrete boundary roundoff retained separately','branches':{k:replay(json.loads(sf.read_text()),b,base,zones,v2,runner) for k,b in d['branches'].items()}};save(target,r)
    rows.append({'scenario_id':p.stem,'branches':{k:{'status':b['status'],'terminal':b.get('states',[{}])[-1],'continuous_metrics_match_1e10':b.get('continuous_metrics_match_1e10')} for k,b in r['branches'].items()}})
save('outputs/central_physical_replay/summary.json',{'audited_case_count':len(rows),'cases':rows})
print('CENTRAL_PHYSICAL_REPLAY_AUDITED',len(rows))
