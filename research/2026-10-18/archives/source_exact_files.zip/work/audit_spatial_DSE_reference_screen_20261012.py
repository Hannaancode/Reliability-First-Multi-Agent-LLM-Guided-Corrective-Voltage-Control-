"""One closed-reference reader. Saved replies only; public solvers refused.

Re-executes unchanged ORIGINAL whole functions over exact paid returned nets,
checks every native menu/action/mask/score and both-branch selector/costs.
Necessary headroom can STOP; survival never authorizes training or claims value.
"""
import copy
import hashlib
import json
import os
import pickle
import time
from pathlib import Path

import pandapower as pp

from audit_spatial_allocation_inputs_v3_20261011 import signature
from candidate_process_evidence_utils import frozen_checks,seal
from frozen_physics_loader import load_stack,AUDIT
from native_continuation_preservation_v2 import canonical,extended_local_path
from native_postcommit_preservation import measured_bus_fields
from paid_spatial_controller_checkpoint_v1 import validate_chain,process_alive
from paid_spatial_literal_comparator_binding_v1 import bind_literal_controls
from spatial_fixed_native_headroom_bound_v2 import fixed_native_headroom_bound
from trusted_causal_controller_snapshot import SOLVER_ROLES,write_bytes
from value_normal_band_mediation import NormalUpperMediation

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def verify_manifest(folder):
    m=read(folder/'Closed_Manifest.json');assert m['exit_code']==0
    actual={f.relative_to(folder).as_posix() for f in folder.rglob('*') if f.is_file()}
    assert actual==set(m['members'])|{'Closed_Manifest.json'}
    for name,d in m['members'].items():
        f=folder/name;assert f.stat().st_size==d['bytes'] and sha(f)==d['sha256'],name
    assert read(folder/'Completion.json')['exit_code']==0
    assert not process_alive(read(folder/'owner.claim')['actual_pid'])


def saved_source_check(spec,p,ph):
    folder=extended_local_path(BASE/'branches'/spec['job_id']);verify_manifest(folder)
    rows,_=validate_chain((folder/'scientific.jsonl').read_bytes(),ph)
    result=read(folder/'Result.json');cost=result['actual_original_observer_costs']
    assert result['guard']==spec['guard'] and result['branch']==spec['branch'] and result['root']==spec['root']
    intents=[r for r in rows if r['event']=='literal_PF_intent']
    returns=[r for r in rows if r['event']=='literal_PF_return']
    failures=[r for r in rows if r['event']=='literal_PF_exception']
    assert len(intents)==cost['PF_attempts']==len(returns)+len(failures)
    assert len(returns)==cost['PF_returns'] and len(failures)==cost['PF_exceptions']
    assert not any(r['event']=='literal_PF_interrupted_unknown' for r in rows)
    assert abs(sum(r['payload']['seconds'] for r in returns+failures)-cost['pure_solver_seconds'])<1e-8
    menus=[r['payload'] for r in rows if r['event']=='literal_preselection_full_menu']
    candidates=[r['payload'] for r in rows if r['event']=='literal_candidate_return']
    assert len(candidates)==cost['candidate_attempts']==cost['candidate_returns']==result['result']['counters']['fallback_tests']
    assert len(menus)==cost['full_menu_searches']
    paid=[r['payload'] for r in rows if r['event'] in ('literal_PF_return','literal_PF_exception')]
    for r in intents:assert r['payload']['kwargs']==SOLVER_ROLES[r['payload']['role']]
    def capsule(anchor):
        d=folder/anchor['relative'];raw=(d/'trusted_local_net.pkl').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==anchor['payload_sha256'] and sha(d/'Manifest.json')==anchor['manifest_sha256']
        return pickle.loads(raw)['net']
    # Verify every capsule before using any saved state, including exceptions.
    for row in paid:capsule(row['anchors'])
    for row in menus:capsule(row['parent'])
    v2,runner,ref=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    binding=bind_literal_controls(ref,runner,p['source_sha256'])
    zones=read(ROOT/p['metadata_path'])['zones'];cursor=0;ci=0;mi=0;active=None;current=None
    blocked=[];requests=[]
    originals={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph')}
    def refuse(*a,**k):blocked.append(True);raise AssertionError('Read-only audit cannot call physics')
    for n in originals:setattr(pp,n,refuse)
    def reply(net,**kwargs):
        nonlocal cursor,current
        assert cursor<len(paid);row=paid[cursor];intent=intents[cursor]['payload']
        assert kwargs==SOLVER_ROLES[row['role']] and intent['identity']==row['identity']
        if active is None:assert row['role'] in ('initial','commit')
        else:assert row['role']=='trial' and row['anchors'] in active['solver_capsules']
        saved=capsule(row['anchors']);assert signature(net)==signature(saved)
        net.clear();net.update(copy.deepcopy(saved));cursor+=1;requests.append(row['identity'])
        if active is None:current=copy.deepcopy(saved)
        if row in [x['payload'] for x in failures]:raise RuntimeError('Saved genuine PF exception; no new solver')
    pp.runpp=reply
    guard=NormalUpperMediation(runner.rescue,1.05,1e-8) if spec['guard'] is not None else None
    try:
        if guard:guard.__enter__()
        original_verify=runner.rescue.verify_action;original_menu=runner.fallback_physics_candidates
        def verify(net,action):
            nonlocal active,ci
            assert active is None and ci<len(candidates)
            row=candidates[ci];assert canonical(row['action'])==canonical(action)
            assert current is not None and signature(net)==signature(current)
            assert canonical(measured_bus_fields(net))==canonical(measured_bus_fields(current))
            active=row
            try:
                answer=original_verify(net,action);assert canonical(answer)==canonical(row['verification'])
                ci+=1;return answer
            finally:active=None
        def menu(*args,**kwargs):
            nonlocal mi
            assert mi<len(menus);row=menus[mi];net=args[0] if args else kwargs['net'];saved=capsule(row['parent'])
            assert signature(net)==signature(saved) and canonical(measured_bus_fields(net))==canonical(measured_bus_fields(saved))
            answer=original_menu(*args,**kwargs);assert canonical([c['action'] for c in answer])==canonical(row['ordered_menu'])
            mi+=1;return answer
        runner.rescue.verify_action=verify;runner.fallback_physics_candidates=menu
        base=pp.from_json(str(ROOT/p['network_path']))
        answer=binding[spec['branch']](scenario=read(ROOT/spec['scenario_path']),base_net=base,zones=zones,v2=v2)
        assert canonical(answer)==canonical(result['result'])
        assert cursor==len(paid) and ci==len(candidates) and mi==len(menus) and not blocked
    finally:
        if guard:guard.__exit__()
        for n,f in originals.items():setattr(pp,n,f)
    replay=extended_local_path(BASE/'replays'/spec['job_id']);verify_manifest(replay)
    rp=read(replay/'Result.json');rr,_=validate_chain((replay/'scientific.jsonl').read_bytes(),ph)
    rc=rp['charged_replay_costs'];assert rc['attempts']==rc['returns']==1+2*len(result['actual_commit_records']) and rc['exceptions']==0
    assert sum(r['event']=='replay_PF_return' for r in rr)==rc['returns'] and rp['maximum_field_delta']<=1e-10
    assert abs(sum(r['payload']['seconds'] for r in rr if r['event']=='replay_PF_return')-rc['pure_solver_seconds'])<1e-8
    assert canonical(rp['continuous_final_metrics'])==canonical(result['result']['final_metrics'])
    first=[c for c in candidates if c['decision']==1]
    # A failed nonlinear solve is UNKNOWN, and cannot prove no legal first action.
    no_first=bool(first) and not any(c['verification']['accepted'] for c in first) and all(
        c['verification']['converged'] is True or c['verification']['reason']=='q_cap_exceeded' for c in first)
    owners=read(BASE/'Ownership_And_Costs.json')['entries']
    entry=next(x for x in owners if x['job_id']==spec['job_id'])
    for phase in ('branch','replay'):
        assert entry[phase]['exit_code']==0 and not process_alive(entry[phase]['actual_pid'])
    return {'result':result['result'],'summary':binding['summarize'](result['result']),
        'complete_exact_menu_mask_score_source_and_paid_physical_replay':True,
        'full_native_first_menu_no_legal_move_certificate':no_first,
        'actual_costs':{'new_PF_attempts':cost['PF_attempts'],'PF_returns':cost['PF_returns'],'PF_exceptions':cost['PF_exceptions'],
            'pure_solver_seconds':cost['pure_solver_seconds'],'owned_branch_seconds':entry['branch']['owned_seconds'],
            'owned_replay_seconds':entry['replay']['owned_seconds'],'replay_PF':rc['attempts'],'replay_solver_seconds':rc['pure_solver_seconds'],
            'online_observed_original_branch_seconds':result['full_owned_branch_online_seconds_with_observation']},
        'reader_saved_requests':len(requests),'all_attempts_and_exception_costs_retained':True}


def main():
    out=extended_local_path(BASE/'independent_audit');out.mkdir(exist_ok=False)
    start=time.perf_counter();write_bytes(out/'reader.claim',canonical({'actual_pid':os.getpid(),'parent_pid':os.getppid(),'argv':__import__('sys').argv,'new_science':0}))
    p=read(BASE/'preparation/Protocol.json');ph=sha(BASE/'preparation/Protocol.json')
    for n,d in p['source_sha256'].items():assert sha(ROOT/n)==d,n
    ownership=read(BASE/'Ownership_And_Costs.json');assert ownership['all_new_owners_ended_exit0']
    all_results={}
    for spec in p['jobs']:
        if spec.get('reused_prior_science'):
            cert=read(ROOT/p['S1_reuse_certificate']);assert sha(ROOT/p['S1_reuse_certificate'])==p['S1_reuse_certificate_sha256']
            assert cert['status']=='PASS_SOURCE_EQUIVALENCE_FOR_EXISTING_S1_PROTECTED_DFF' and cert['new_actual_PF_model_optimizer_calls']==0
            assert spec['root']=='S1' and spec['branch']=='DFF' and spec['guard']=={'upper':1.05,'tolerance':1e-8}
            assert cert['same_initial_declared_recipe_sha256']==spec['scenario_sha256'] and cert['existing_scientific_seed']==p['seed']
            prior=read(ROOT/p['S1_completion_certificate']);assert sha(ROOT/p['S1_completion_certificate'])==p['S1_completion_certificate_sha256']
            assert prior['all_actual_owners_and_readers_ended']
            result=cert['original_result'];all_results[spec['job_id']]={'result':result,'summary':None,
                'complete_exact_menu_mask_score_source_and_paid_physical_replay':True,'full_native_first_menu_no_legal_move_certificate':False,
                'paid_reuse_with_original_costs_and_failure_provenance':cert['prior_paid_scientific_costs'],
                'exact_single_online_original_branch_latency':'UNKNOWN; original engineering split and costs retained',
                'actual_costs':None,'new_science':0}
        else:all_results[spec['job_id']]=saved_source_check(spec,p,ph)
    _,runner,ref=load_stack();binding=bind_literal_controls(ref,runner,p['source_sha256'])
    portfolios={};bound={}
    for root in p['roots']:
        portfolios[root]={}
        for variant in ('literal','protected'):
            arms={b:all_results[f'{root}_{variant}_{b.replace("-","_")}'] for b in ('DFF','DFF-ALT')}
            summaries={b:binding['summarize'](x['result']) for b,x in arms.items()}
            choice=binding['selector'](summaries['DFF'],summaries['DFF-ALT'])
            selected='DFF-ALT' if choice=='reflection_v2' else 'DFF';assert choice in ('reflection_v2','no_llm_fallback_first')
            costs=[x['actual_costs'] for x in arms.values()]
            full={k:sum(c[k] for c in costs) for k in costs[0]} if all(c is not None for c in costs) else 'UNKNOWN exact online comparability; paid S1 engineering costs retained'
            portfolios[root][variant]={'both_branches':arms,'selected_branch':selected,'terminal_uv':arms[selected]['result']['final_metrics']['uv_count'],
                'unchanged_zero_missing_selector':True,'FULL_BOTH_costs':full,'no_selected_branch_discount':True}
        arms=portfolios[root]['protected']['both_branches']
        initials={x['result']['base_metrics']['uv_count'] for v in portfolios[root].values() for x in v['both_branches'].values()};assert len(initials)==1
        bound[root]={'initial_uv':initials.pop(),'literal_DSE_terminal_uv':portfolios[root]['literal']['terminal_uv'],
            'protected_DSE_terminal_uv':portfolios[root]['protected']['terminal_uv'],
            'independent_complete_source_physics_cost_replay':True,
            'full_native_first_menu_source_scope_and_masks_verified':True,
            'no_admitted_first_action':arms['DFF']['full_native_first_menu_no_legal_move_certificate']}
    decision=fixed_native_headroom_bound(bound)
    write_bytes(out/'All_Branches_And_FULLBOTH_Costs.json',canonical(portfolios));write_bytes(out/'Necessary_Headroom_Bound.json',canonical({'records':bound,'bound':decision}))
    write_bytes(out/'Independent_Audit.json',canonical({'status':'PASS','actual_reader_pid':os.getpid(),'all32_declared_branches':True,
        '31_new_source_and_continuous_physics_replays_one_exact_paid_reuse':True,'new_model_PF_optimizer_calls':0,
        'source_sha256':p['source_sha256'],'reader_seconds_before_archive':time.perf_counter()-start,
        'decision':decision['decision'],'overall_LLM_DSE_superiority':'UNACHIEVED','survival_is_not_sufficient_headroom_or_90percent':True}))
    write_bytes(out/'Fresh_Frozen_Checks.json',canonical(frozen_checks()))
    files={f.relative_to(extended_local_path(BASE)).as_posix():f for f in extended_local_path(BASE).rglob('*') if f.is_file()
        and f.name not in ('coordinator_stdout.log','coordinator_stderr.log','reader_stdout.log','reader_stderr.log','owner_status.json')}
    # Logs still owned by the coordinator are intentionally outside the closed archive.
    seal(out,files,'Verified_Reference_And_Headroom_Evidence.zip')
    write_bytes(out/'Completion.json',canonical({'exit_code':0,'new_science':0,'full_reader_seconds':time.perf_counter()-start}))


if __name__=='__main__':main()
