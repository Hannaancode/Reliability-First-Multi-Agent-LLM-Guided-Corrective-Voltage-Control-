"""Prospective quadratic-residual equation only; no neural predictor/solver.

This additive proposal supersedes the linear-prefactor algebra illustration.
The earlier fixture source and evidence stay immutable. Matching a current
AC-control tangent does not certify the actual nonlinear solver's active set.
"""
import math
from action_transition_contract import compile_current_action,vm_vector

def curvature_forecast(current, current_AC_direction_per_MVAr, predicted_unit_curvature, scale):
    inp=compile_current_action(current)
    if not math.isfinite(scale) or scale<=0:raise ValueError('Fixed positive OPT-only scale required')
    vectors=(current_AC_direction_per_MVAr,predicted_unit_curvature)
    if any(len(v)!=118 or any(type(x) not in (int,float) or not math.isfinite(x) for x in v) for v in vectors):
        raise ValueError('Finite native118-bus current-derived direction and forecast required')
    before=vm_vector(inp['current_physical_observation']['physical_tables']['res_bus'])
    q=inp['candidate_action']['q_abs_mvar']
    result=[v+q*d+(q/300.)**2*scale*r for v,d,r in zip(before,*vectors)]
    if any(not math.isfinite(v) or v<=0 for v in result):raise ValueError('Unphysical forecast; do not clip or claim convergence')
    return result

def local_algebra_certificate():
    # For bounded differentiable h(q), q^2*s*h(q)/300^2 has value and
    # first derivative zero at q=0. The learned implementation must prove
    # this smoothness/finite path before these properties apply to it.
    check=[]
    for current,d,h,s in ((1.,.0001,2.,.01),(.96,-.0002,-3.,.02)):
        f=lambda q:current+q*d+(q/300.)**2*s*h
        assert f(0.)==current
        e=1e-4; derivative=(f(e)-f(-e))/(2*e)
        assert abs(derivative-d)<1e-12
        check.append({'current':current,'analytic_direction':d,'finite_difference_tangent':derivative})
    return {'zero_action_identity':True,'tangent_matches_supplied_analytic_control':True,
        'bounded_smooth_learned_curvature_required_not_yet_implemented':True,
        'two_labelled_scalar_algebra_fixtures':check,
        'not_an_original_solver_derivative_safety_or_learning_certificate':True}
