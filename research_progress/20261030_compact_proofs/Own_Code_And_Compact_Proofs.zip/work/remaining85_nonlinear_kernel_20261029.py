"""Proposal-model kernel only; not a solver or executable controller.

31 variables: theta_PQ[12], magnitude_PQ[12], deltaQ[3], absQ[3], t[1].
All inequalities use g(x)>=0. Angles are radians; deltaQ is native Mvar.
No pandapower, scipy optimizer, model, filesystem, launch, or training import.
Production use requires the separately recorded all500 source-binding gates.
"""
from dataclasses import dataclass, field
import numpy as np

NATIVE_CAP = float(np.float32(.3))
SECOND_STAGE_ALLOWANCE = 1e-10


@dataclass
class NonlinearNative13:
    Y: np.ndarray
    V_current: np.ndarray
    ppc_bus: np.ndarray
    ppc_gen: np.ndarray
    baseMVA: float
    lookup: np.ndarray
    control: np.ndarray
    current_vm: np.ndarray
    current_q: np.ndarray
    control_scaling: np.ndarray
    control_in_service: np.ndarray
    enforce_q_lims: bool
    distributed_slack: bool
    costs: dict = field(default_factory=dict)

    def __post_init__(self):
        for name in ['Y', 'V_current', 'ppc_bus', 'ppc_gen', 'lookup', 'control',
                     'current_vm', 'current_q', 'control_scaling', 'control_in_service']:
            setattr(self, name, np.asarray(getattr(self, name)).copy())
        assert self.Y.shape == (13, 13) and self.V_current.shape == (13,)
        assert self.ppc_bus.shape[0] == 13 and self.ppc_bus.shape[1] >= 18
        assert self.current_vm.shape == (13,) and self.current_q.shape == (3,)
        assert self.control.shape == (3,) and self.lookup.shape == (13,)
        assert np.array_equal(np.sort(self.lookup), np.arange(13))
        assert np.array_equal(self.ppc_bus[:, 0], np.arange(13))
        self.lookup = self.lookup.astype(int)
        self.control = self.control.astype(int)
        assert np.array_equal(self.control, self.lookup[np.array([2, 7, 9])])
        self.pq = np.flatnonzero(self.ppc_bus[:, 1] == 1)
        self.ref = np.flatnonzero(self.ppc_bus[:, 1] == 3)
        assert len(self.pq) == 12 and len(self.ref) == 1
        assert all(i in self.pq for i in self.control)
        assert not self.distributed_slack and not self.enforce_q_lims
        assert self.control_scaling.shape == (3,) and np.array_equal(self.control_scaling, np.ones(3))
        assert self.control_in_service.shape == (3,) and np.all(self.control_in_service)
        # A nonzero ZIP coefficient changes the source equations. Do not silently
        # use the constant-power kernel in that case.
        assert np.all(self.ppc_bus[:, [13, 14, 16, 17]] == 0)
        assert self.baseMVA > 0 and np.isfinite(self.baseMVA)
        for a in [self.Y, self.V_current, self.ppc_bus[:, :18], self.current_vm, self.current_q]:
            assert np.isfinite(a).all()
        self.normal = (self.current_vm >= .95) & (self.current_vm <= 1.05)
        # Match makeSbus: active conventional generators minus PPC demand.
        # Existing sgen injections are already folded into PPC PD/QD.
        self.injection0 = -(self.ppc_bus[:, 2] + 1j * self.ppc_bus[:, 3])
        for row in self.ppc_gen[self.ppc_gen[:, 7] > 0]:
            bus = int(row[0])
            assert row[0] == bus and 0 <= bus < 13
            self.injection0[bus] += row[1] + 1j * row[2]
        self.injection0 /= self.baseMVA

    def _charge(self, name):
        self.costs[name] = self.costs.get(name, 0) + 1

    def split(self, x):
        x = np.asarray(x, dtype=float)
        if x.shape != (31,) or not np.isfinite(x).all():
            raise ValueError('A finite31-vector in the frozen variable order is required')
        return x[:12], x[12:24], x[24:27], x[27:30], float(x[30])

    def voltage(self, x):
        theta, magnitude, _, _, _ = self.split(x)
        V = self.V_current.copy()
        V[self.pq] = magnitude * np.exp(1j * theta)
        return V

    def equality(self, x):
        self._charge('nonlinear_equation_evaluations')
        _, _, dq, _, _ = self.split(x)
        target = self.injection0.copy()
        # Original source sgen deltaQ enters PPC QD with a minus sign,
        # hence enters generation-minus-demand injection with a plus sign.
        target[self.control] += 1j * dq / self.baseMVA
        V = self.voltage(x)
        mismatch = V * np.conj(self.Y @ V) - target
        return np.r_[mismatch[self.pq].real, mismatch[self.pq].imag]

    def inequalities(self, x, first_stage_t=None):
        self._charge('constraint_evaluations')
        _, _, dq, aq, t = self.split(x)
        vm = np.abs(self.voltage(x))[self.lookup]
        # This keeps the old constraints, including strict0.95/1.05 normal
        # constraints. The actual guard still allows1e-8 and checks counts.
        g = np.r_[1.05 + t - vm, vm - .95 + t,
                  1.05 - vm[self.normal], vm[self.normal] - .95,
                  aq - (self.current_q + dq), aq + self.current_q + dq]
        if first_stage_t is not None:
            if not np.isfinite(first_stage_t) or first_stage_t < 0:
                raise ValueError('A valid saved first-stage t is required')
            g = np.r_[g, first_stage_t + SECOND_STAGE_ALLOWANCE - t]
        return g

    def objective(self, x, stage):
        self._charge('objective_evaluations')
        _, _, _, aq, t = self.split(x)
        if stage == 1:
            return t
        if stage == 2:
            return float(np.sum(aq))
        raise ValueError('Only the frozen two stages are supported')

    def bounds(self):
        # No invented absoluteQ cap, voltage-angle box, or tuned trust radius.
        return [(None, None)] * 12 + [(0., None)] * 12 + [(-NATIVE_CAP, NATIVE_CAP)] * 3 + [(0., None)] * 4

    def initial_vector(self):
        x = np.zeros(31)
        x[:12] = np.angle(self.V_current[self.pq])
        x[12:24] = np.abs(self.V_current[self.pq])
        x[27:30] = np.abs(self.current_q)
        x[30] = max(0., .95 - float(self.current_vm.min()), float(self.current_vm.max()) - 1.05)
        return x

    def representable_native_action(self, x):
        self._charge('native_action_conversions')
        _, _, dq, _, _ = self.split(x)
        if np.any(np.abs(dq) > NATIVE_CAP):
            raise ValueError('Outside native increment cap; no posthoc clipping repair')
        u = (-dq).astype(np.float32)
        if not np.isfinite(u).all() or np.any(np.abs(u) > np.float32(.3)):
            raise ValueError('Native action is not admissible')
        next_q = self.current_q - u
        applied_x = np.asarray(x, dtype=float).copy()
        applied_x[24:27] = next_q - self.current_q
        applied_x[27:30] = np.abs(next_q)
        # Returned state variables are not solved again or asserted feasible.
        # Caller must re-check equality/constraints for this representable action
        # and then validate a prospective physical query under its locked protocol.
        return u, next_q, applied_x


def original_guard(before, after):
    normal = (before >= .95) & (before <= 1.05)
    return bool(np.isfinite(after).all() and np.all(after[normal] >= .95 - 1e-8)
                and np.all(after[normal] <= 1.05 + 1e-8)
                and (after < .95).sum() <= (before < .95).sum()
                and (after > 1.05).sum() <= (before > 1.05).sum())
