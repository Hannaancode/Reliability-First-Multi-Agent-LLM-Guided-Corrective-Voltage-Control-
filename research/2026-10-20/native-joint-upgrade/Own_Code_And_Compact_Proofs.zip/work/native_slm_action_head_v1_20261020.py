"""Untrained native actor-head prototype. No model loader, PF, fallback or language-output repair."""
import torch
from torch import nn

class NativeIncrementHead(nn.Module):
    def __init__(self,hidden_size):
        super().__init__();assert type(hidden_size) is int and hidden_size>0
        self.hidden_size=hidden_size;self.linear=nn.Linear(hidden_size,1,dtype=torch.float32)
        nn.init.normal_(self.linear.weight,mean=0,std=0.001);nn.init.zeros_(self.linear.bias)
    def forward(self,causal_hidden,last_q):
        if causal_hidden.ndim!=2 or causal_hidden.shape[1]!=self.hidden_size:raise ValueError('Native hidden shape mismatch')
        if last_q.shape!=(causal_hidden.shape[0],1):raise ValueError('Native Q cursor shape mismatch')
        if not torch.isfinite(causal_hidden).all() or not torch.isfinite(last_q).all():raise ValueError('Nonfinite causal input')
        # Native source's float32 +/-0.3 increment semantics. There is no invented absolute-Q cap.
        u=torch.tanh(self.linear(causal_hidden.float()))*torch.tensor(0.3,dtype=torch.float32,device=causal_hidden.device)
        if not torch.isfinite(u).all():raise ValueError('Nonfinite native output')
        return {'u_mvar':u,'next_q_mvar':last_q.float()-u}

def software_only_checks():
    """Random CPU gradient/cold-state and boundary checks; not pretrained-model or physical evidence."""
    torch.manual_seed(20261020);results=[]
    for width in [896,1536]:
        head=NativeIncrementHead(width);hidden=torch.randn(3,width,requires_grad=True);q=torch.tensor([[0.],[0.6],[-1.]],dtype=torch.float32);a=head(hidden,q)
        assert a['u_mvar'].dtype==torch.float32 and torch.max(torch.abs(a['u_mvar']))<=torch.tensor(0.3) and torch.equal(a['next_q_mvar'],q-a['u_mvar'])
        loss=(a['u_mvar']-torch.tensor([[-.2],[.1],[.25]])).square().sum();loss.backward()
        assert hidden.grad is not None and torch.isfinite(hidden.grad).all() and hidden.grad.abs().sum()>0 and all(p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().sum()>0 for p in head.parameters())
        cold=NativeIncrementHead(width);cold.load_state_dict({k:v.detach().clone() for k,v in head.state_dict().items()},strict=True)
        with torch.no_grad():b=cold(hidden.detach(),q)
        assert all(torch.equal(a[k].detach(),b[k]) for k in a)
        rejected=0
        for h,cursor in [(torch.full((3,width),float('nan')),q),(hidden.detach(),torch.full((3,1),float('inf'))),(hidden.detach(),q.squeeze()),(torch.zeros(3,width-1),q)]:
            try:head(h,cursor)
            except ValueError:rejected+=1
            else:raise AssertionError('Invalid native state was accepted')
        results.append({'hidden_size':width,'finite_native_float32_and_Q_cursor':True,'nonzero_finite_input_and_head_gradients':True,'cold_state_outputs_exact':True,'boundary_rejections':rejected})
    return {'status':'PASS_LABELLED_RANDOM_CPU_NATIVE_HEAD_UNIT_BOUNDARY_GRADIENT_AND_COLD_CHECKS','results':results,'random_CPU_successful_forward_calls':4,'random_CPU_backward_calls':2,'random_CPU_rejected_calls':8,'optimizer_updates':0,'pretrained_LLM_PF_GPU_calls':0,'native_head_trained_or_physical_value_proved':False,'limits':'896/1536softwarewidthchecks do not certify actual0.5B/1.5B loader/context/gradient/memory/optimizerorphysics;realintegrationandperformancegatesremain.'}
