"""Separately identified broader historical screen. Same validated algorithm; eight predeclared cases, four families,120 rows/48 genuine batches. Preserve original first screen; no independent holdout or full recovery claim."""
from pathlib import Path
from types import SimpleNamespace
from collections import deque
import ast, hashlib, json, os
os.environ['USE_TORCH'] = '0'
os.environ['HF_HUB_OFFLINE'] = '1'
from transformers import AutoTokenizer
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/llm_value_broader_development'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = ROOT / 'work/e/audit/run_reflection_v4_safety_envelope.py'
tree = ast.parse(source.read_text(encoding='utf-8'))
names = {'_safe_bus_q', 'init_feedback_state', 'build_compact_feedback_text', 'severity_stage', 'build_two_best_prompt_v2'}
selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(selected) == len(names)
namespace = {'json': json, 'deque': deque, 'ALLOWED_Q': [25, 50, 75, 100, 125, 150, 200, 250, 300]}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(source), 'exec'), namespace)
tokenizer = AutoTokenizer.from_pretrained(str(ROOT / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'), local_files_only=True)
inputs = json.loads((OUT / 'gpu_initial_inputs.json').read_text())
protocol_path = OUT / 'clean_value_development_protocol.json'
protocol = json.loads(protocol_path.read_text())
rows = []
for sid, case in inputs['cases'].items():
    for zone, data in case['proposer_inputs'].items():
        assert data['candidate_buses'] and set(data['candidate_buses']) <= set(case['candidate_universe_buses'])
        messages = namespace['build_two_best_prompt_v2']('reflection_v2', data['zone_state'], data['global_uv'], data['candidate_buses'], [], namespace['init_feedback_state']())
        tokens = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_dict=False)
        assert isinstance(tokens, list) and all((type(t) is int for t in tokens)) and (len(tokens) + 384 <= 4096)
        for budget in protocol['candidate_evaluation_budget_grid']:
            for policy in ['zonal_LoRA_prefix', 'zonal_base_prefix']:
                rows.append({'scenario_id': sid, 'zone': zone, 'policy': policy, 'budget': budget, 'input_tokens': len(tokens), 'prompt_sha256': hashlib.sha256(json.dumps(messages).encode()).hexdigest()})
assert len(rows) == 192
report = {'passed': True, 'actual_primary_prompt_checks': len(rows), 'maximum_primary_tokens': max((r['input_tokens'] for r in rows)), 'reserved_generation': 384, 'context_limit': 4096, 'all_original_observation_fields_preserved': True, 'same_input_for_base_and_LoRA': True, 'model_inference': False, 'driver_sha256': sha(ROOT / 'work/run_broader_value_gpu_proposals.py'), 'protocol_sha256': sha(protocol_path), 'inputs_sha256': sha(OUT / 'gpu_initial_inputs.json'), 'original_prompt_source_sha256': sha(source), 'rows': rows}
(OUT / 'gpu_prompt_preflight.json').write_text(json.dumps(report, indent=2))
print('CLEAN_VALUE_PROMPT_PREFLIGHT_PASSED', len(rows), report['maximum_primary_tokens'])
