def run_planned_phase(self, *, maximum_new_commits=None):
    if maximum_new_commits is not None and (type(maximum_new_commits) is not int or not 1 <= maximum_new_commits <= 25):
        raise ValueError('Positive prospectively fixed phase cursor required')
    phase_stop_cursor = min(25, self.controller['actual_commit_count'] + maximum_new_commits) if maximum_new_commits is not None else 25
    if self.terminal or self.controller['phase'] != 'PRE_SELECTION':
        raise OperationalStop('Ended or pending coordinator cannot restart')
    try:
        while self.controller['remaining_slots'] and self.controller['actual_commit_count'] < phase_stop_cursor:
            self.q.boundary()
            obs = self._check_current()
            if obs['metrics']['uv_count'] == 0:
                return self._finish('full_restoration', obs)
            parent = self.controller['current_handle']
            self.allowed_children.clear()
            if self.mode == 'native_greedy':
                rows = full_menu(parent, self._menu, self._query)
                accepted = [r for r in rows if r.accepted]
                first = max(accepted, key=lambda r: r.native_score).action if accepted else None
                plan = {'status': 'complete_native_menu', 'first': first, 'queries': len(rows), 'mode': self.mode}
            else:
                plan = two_step(parent, obs['metrics'], self.controller['remaining_slots'], self._menu, self._query, mode='greedy' if self.mode == 'greedy_two_step' else self.mode, width=self.width)
            self.q._journal('complete_current_decision', {'parent': parent, 'iteration': self.controller['actual_commit_count'] + 1, 'plan': plan})
            if plan['first'] is None:
                return self._finish('no_admitted_first_action', obs)
            r = self.q.receipts.get((parent, plan['first']))
            if not isinstance(r, Receipt) or r.accepted is not True or (not r.returned):
                raise OperationalStop('Selected action lacks paid admitted current receipt')
            action = copy.deepcopy(self.q.menus[parent][r.action])
            iteration = self.controller['actual_commit_count'] + 1
            self.controller['phase'] = 'COMMIT_INTENT'
            self.q._journal('irreversible_commit_intent', {'parent': parent, 'selected_action_id': r.action, 'trial_successor': r.successor, 'iteration': iteration, 'action': action})
            current = self.commit(parent, r, action, iteration)
            if current not in self.q.handles or current in (parent, r.successor):
                raise OperationalStop('Actual commit requires separately issued measured capsule')
            actual = self.observe(self.q, current)
            trial = self.observe(self.q, r.successor)
            proof = check_commit(trial['fields'], actual['fields'], obs['metrics'], actual['caps'])
            history = self.controller['actual_action_history'] + [{'iteration': iteration, 'parent_handle': parent, 'selected_action_id': r.action, 'trial_successor': r.successor, 'action': action, 'committed_handle': current}]
            self.controller.update(phase='PRE_SELECTION', actual_commit_count=iteration, remaining_slots=25 - iteration, current_handle=current, actual_action_history=history)
            self.allowed_children.clear()
            validate_controller(self.controller, self.q.handles)
            self._check_current()
            self.q._journal('actual_commit_verified', {'iteration': iteration, 'current_handle': current, 'proof': proof})
            anchor = self.checkpoint(self.q, copy.deepcopy(self.controller), f'commit_{iteration:02d}')
            if not isinstance(anchor, dict) or not anchor:
                raise OperationalStop('Complete anchored checkpoint missing')
        if self.controller['remaining_slots'] and self.controller['actual_commit_count'] >= phase_stop_cursor:
            return {'status': 'planned_checkpoint_phase_end', 'controller': copy.deepcopy(self.controller), 'actual_commit_count': self.controller['actual_commit_count'], 'whole_episode_performance': False, 'no_journal_activity_after_final_checkpoint': True}
        obs = self._check_current()
        return self._finish('full_restoration' if obs['metrics']['uv_count'] == 0 else 'max_iterations', obs)
    except BaseException:
        self.terminal = True
        self.q.stopped = True
        raise