"""Freeze one new acquisition only after named independent source gates exist.

No actual optimizer, model, PF or owner is started by preparation. Existing
certified metadata is reused; no completed input/science audit is rerun.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,hashlib,os
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_receding_acquisition_v2_preparation_20261030'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):p=Path(p);return dict(path=p.relative_to(R).as_posix(),sha256=sha(p),bytes=p.stat().st_size)
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def main():
 ap=argparse.ArgumentParser()
 for flag in ('readiness-index','runtime-certificate','failure-diagnosis','previous-terminal-certificate'):
  ap.add_argument('--'+flag,required=True)
 a=ap.parse_args()
 from nonlinear500_isolated_owner_runtime_20261030 import (validate_previous_setup,validate_runtime_spec,
  DEPENDENCY_DIRECTORY,WHEEL_FILE,WHEEL_SHA256,SOURCE_FILE)
 previous=dict(failed_protocol=ref(R/'outputs/nonlinear500_receding_acquisition_preparation_20261030/Protocol.json'),
  independent_failure_diagnosis=ref(R/a.failure_diagnosis),fresh_terminal_absence=ref(R/a.previous_terminal_certificate),
  old_study_never_restarted=True,original_authenticated_chain_end='UNKNOWN_RETAINED_UNCHANGED')
 failed=validate_previous_setup(R,previous)
 runtime_certificate=json.loads((R/a.runtime_certificate).read_text(encoding='utf-8'))
 runtime=dict(directory=DEPENDENCY_DIRECTORY,package='psutil',version='7.2.2',
  official_wheel=ref(R/WHEEL_FILE),actual_runtime_certificate=ref(R/a.runtime_certificate),
  actual_runtime_admission_source=ref(R/'work/check_acquisition_actual_runtime_20261030.py'),
  source_files=runtime_certificate['isolated_dependency_sources'])
 assert runtime['official_wheel']['sha256']==WHEEL_SHA256
 index=json.loads((R/a.readiness_index).read_text(encoding='utf-8'))
 from run_nonlinear500_receding_acquisition_v2_20261030 import REQUIRED_READINESS
 from nonlinear13_preserved_solver_v3_20261029 import RECIPE
 assert set(index['gates'])==REQUIRED_READINESS and index['launch_blockers']==[]
 gates=[]
 for key,row in index['gates'].items():
  assert sha(R/row['path'])==row['sha256']
  gate=json.loads((R/row['path']).read_text(encoding='utf-8'))
  assert gate['status']==row['required_status'] and gate['status'].startswith('PASS')
  gates.append(dict(key=key,**row))
 for rel,digest in index['reviewed_current_sources'].items():assert sha(R/rel)==digest,rel
 cert=R/'outputs/nonlinear500_source_binding_20261029/v2_validated_full_admittance'
 old=json.loads((cert/'Results.json').read_text(encoding='utf-8'))
 assert old['status']=='COMPLETE_ALL500_SOURCE_BINDING_PASS' and [r['seed'] for r in old['rows']]==list(range(500))
 roster=[dict(seed=r['seed'],root=r['exact_root'],input_pack=r['bound_pack']) for r in old['rows']]
 oldfirst=R/'outputs/nonlinear13_first_proposal_preparation_20261029/Protocol.json'
 first=json.loads(oldfirst.read_text(encoding='utf-8'))
 sources=dict(failed['sources'])
 for path,digest in first['sources_and_gates'].items():assert sources[path]==digest,path
 sources.update(json.loads((cert/'Source_Input_Freeze.json').read_text(encoding='utf-8'))['sources'])
 paths=[
  'work/nonlinear13_receding_policy_engine_20261029.py','work/nonlinear13_receding_policy_engine_v2_20261030.py',
  'work/nonlinear13_current_state_20261029.py','work/nonlinear13_current_state_v2_20261030.py',
  'work/nonlinear13_math_receipt_bank_20261030.py','work/nonlinear13_saved_math_reader_20261030.py',
  'work/nonlinear13_acquisition_reader_20261030.py','work/nonlinear13_receding_acquisition_engine_20261030.py',
  'work/nonlinear500_paid_snapshot_v2_20261029.py','work/nonlinear500_paid_lookup_v2_20261029.py',
  'work/remaining85_certified_loader_20261029.py','work/remaining85_source_binder_20261029.py',
  'work/remaining85_source_binder_v2_20261029.py','work/physics_env/Lib/site-packages/pandapower/auxiliary.py',
  'work/physics_env/Lib/site-packages/pandapower/build_bus.py','work/candidate_process_evidence_utils.py',
  'work/run_nonlinear500_receding_acquisition_v2_20261030.py','work/audit_nonlinear500_receding_acquisition_v2_20261030.py',
  'work/coordinate_nonlinear500_receding_acquisition_v2_20261030.py','work/coordinate_acquisition_source_bound_owner_20261030.py',
  'work/coordinate_native_inverter_linear_reference_20261020.py',
  'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py',
  SOURCE_FILE,'work/check_acquisition_actual_runtime_20261030.py']
 paths.extend(runtime['source_files'])
 paths.extend(Path(row['file']).resolve().relative_to(R.resolve()).as_posix() for row in runtime_certificate['imports'].values())
 for path in paths:
  digest=sha(R/path)
  if path in sources:assert digest==sources[path],'Old source changed: '+path
  sources[path]=digest
 for path,digest in sources.items():assert sha(R/path)==digest,path
 validate_runtime_spec(R,runtime,sources,expected_executable=R/'work/physics_env/Scripts/python.exe')
 for path in ('work/run_nonlinear500_receding_acquisition_v2_20261030.py','work/nonlinear13_receding_acquisition_engine_20261030.py',
   'work/nonlinear13_math_receipt_bank_20261030.py','work/nonlinear13_current_state_v2_20261030.py',
   'work/nonlinear13_acquisition_reader_20261030.py','work/audit_nonlinear500_receding_acquisition_v2_20261030.py',
   'work/coordinate_nonlinear500_receding_acquisition_v2_20261030.py','work/coordinate_acquisition_source_bound_owner_20261030.py',
   'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py',SOURCE_FILE):
  assert index['reviewed_current_sources'][path]==sources[path],path
 O.mkdir(exist_ok=False);put(O/'Exact_All500_Root_Roster.json',roster)
 paid=dict(protocol=ref(oldfirst),proposal=ref(R/'outputs/nonlinear13_first_proposal_execution_20261029/Proposal_Result.json'),
  independent_reader=ref(R/'outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json'),
  closed_manifest=ref(R/'outputs/nonlinear13_first_proposal_execution_20261029/Closed_Manifest.json'))
 identity=json.loads((R/'outputs/nonlinear13_current_state_v2_preparation_20261030/Warm_Identity.json').read_text(encoding='utf-8'))
 assert identity['certified_original_context_key']==identity['new_adapter_context_key'] and identity['typed_payload_exact']
 p=dict(status='FROZEN_NEW_NUMERICAL_ACQUISITION_OVER_PAID_PHYSICS',at_utc=datetime.now(timezone.utc).isoformat(),
  campaign_id='nonlinear500_receding_acquisition_v2_20261030',cases=list(range(500)),horizon=100,recipe=RECIPE,rng_seed=20261030,
  physical_kwargs={'algorithm':'bfsw','init':'dc'},score_epsilon=1e-8,
  science_seconds=7200,science_budget_seconds=7200,reader_seconds=7200,process_seconds=7500,
  binary_byte_cap=8*1024**3,protocol_binary_byte_cap=8*1024**3,reader_byte_cap=64*1024**3,
  per_proposal_journal_byte_cap=64*1024**2,journal_byte_cap=64*1024**2,checkpoint_byte_cap=1024**2,
  nonjournal_json_byte_cap=8*1024**2,aggregate_result_json_byte_cap=64*1024**2,
  sources=sources,independent_readiness=gates,readiness_index=ref(R/a.readiness_index),
  previous_failed_setup=previous,isolated_owner_runtime=runtime,
  prospective_difference='Distinct owner paths and isolated pinned psutil admission only; original failed study never restarted.',
  root_roster_ref=ref(O/'Exact_All500_Root_Roster.json'),first_paid_math=paid,
  first_paid_math_context_key=identity['certified_original_context_key'],
  paid_registry_manifest=ref(R/'outputs/nonlinear500_paid_registry_20261029/Frozen_Registry_Manifest.json'),
  independent_reader_source=dict(path='work/nonlinear13_acquisition_reader_20261030.py',sha256=sources['work/nonlinear13_acquisition_reader_20261030.py']),
  new_math_mode='SOURCE_ORDER_RECEDING_FIXED_RECIPE',numerical_acquisition_authorized=True,new_PF_entry_enabled=False,
  intervention='Fixed two-stage native nonlinear AC proposal; same source-order cases, original native guard/action/horizon. Exact verified paid physics only.',
  stop_rules=['No retry of failed/unreturned numerical identity','First missing/blocked exact physical identity leaves path UNKNOWN',
   'Unsafe returned candidate holds state and stops this acquisition path','Original deadline or storage bound stops new work; preserve partial/unentered identities'],
  scientific_claim_limit='Acquisition/returned-prefix evidence only. Missing physics and incomplete trajectories are UNKNOWN; no automatic superiority, full500score, LLM attribution or newPF permission.',
  original_comparators='Unchanged full500 NUM and unmodified published SafeDDPG/linear/DDPG retained; full costs and both strict/common1e-8 endpoints preserved. No new performance comparison on chosen complete prefixes.',
  historical_data='Inspected development, not unused confirmation.',new_model_GPU_training_calls_planned=0)
 put(O/'Protocol.json',p)
 for kind,source,output,coord in [
  ('Primary','work/run_nonlinear500_receding_acquisition_v2_20261030.py','outputs/nonlinear500_receding_acquisition_v2_execution_20261030','outputs/nonlinear500_receding_acquisition_v2_coordination_20261030'),
  ('Reader','work/audit_nonlinear500_receding_acquisition_v2_20261030.py','outputs/nonlinear500_receding_acquisition_v2_independent_20261030','outputs/nonlinear500_receding_acquisition_v2_reader_coordination_20261030')]:
  assert not (R/output).exists() and not (R/coord).exists(),'Existing owner/output forbids entry'
  put(O/(kind+'_Owner_Protocol.json'),dict(single_owner=dict(source=source,sha256=sources[source],output=output,
   coordination=coord,python='work/physics_env/Scripts/python.exe',bound_seconds=7500)))
 put(O/'Frozen_Preparation_Manifest.json',dict(files=[ref(f) for f in sorted(O.iterdir()) if f.is_file()],scientific_calls=0))
 print(json.dumps(dict(status='PROSPECTIVE_PROTOCOL_FROZEN_NO_LAUNCH',cases=500,new_science=0)))
if __name__=='__main__':main()
