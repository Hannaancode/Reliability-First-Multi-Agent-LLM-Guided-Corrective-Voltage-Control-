"""Both official encodings, all16 fixed rows; direct AC equations, ZERO solvers.

Independent real/complex branch expressions and full KCL/bounds/thermal/angle
checks. This is source-data readiness, not our-model performance or optimum.
"""
import copy,hashlib,json,math,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
BASE=R/'outputs/pglearn_fixed_test_prefix_20261019';B=BASE/'native_equation_audit_v2'
TOL=5e-6
def positive(x):return float(max(0.,np.max(np.asarray(x))))
def evaluate(data,primal):
    n,e,g=map(int,[data['N'],data['E'],data['G']]);a=lambda k:np.asarray(data[k],dtype=float);x={k:np.asarray(v,dtype=float) for k,v in primal.items()}
    assert n==118 and e==186 and g==54 and all(np.isfinite(v).all() for v in x.values())
    for k in ('vm','va'):assert x[k].shape==(n,)
    for k in ('pg','qg'):assert x[k].shape==(g,)
    for k in ('pf','qf','pt','qt'):assert x[k].shape==(e,)
    fr=np.asarray(data['bus_fr'],int)-1;to=np.asarray(data['bus_to'],int)-1;assert min(fr.min(),to.min())>=0 and max(fr.max(),to.max())<n
    for name,total in [('bus_gens',g),('bus_loads',int(data['L'])),('bus_arcs_fr',e),('bus_arcs_to',e)]:assert sorted(i for row in data[name] for i in row)==list(range(1,total+1))
    vm=x['vm'];va=x['va'];v=vm*np.exp(1j*va);on=a('branch_status');gon=a('gen_status');delta=va[fr]-va[to];wr=vm[fr]*vm[to]*np.cos(delta);wi=vm[fr]*vm[to]*np.sin(delta)
    real={'pf':on*(a('gff')*vm[fr]**2+a('gft')*wr+a('bft')*wi),'qf':on*(-a('bff')*vm[fr]**2-a('bft')*wr+a('gft')*wi),'pt':on*(a('gtt')*vm[to]**2+a('gtf')*wr-a('btf')*wi),'qt':on*(-a('btt')*vm[to]**2-a('btf')*wr-a('gtf')*wi)}
    sf=on*v[fr]*np.conj((a('gff')+1j*a('bff'))*v[fr]+(a('gft')+1j*a('bft'))*v[to]);st=on*v[to]*np.conj((a('gtt')+1j*a('btt'))*v[to]+(a('gtf')+1j*a('btf'))*v[fr])
    dual=max(float(np.max(abs(real[k]-y))) for k,y in [('pf',sf.real),('qf',sf.imag),('pt',st.real),('qt',st.imag)]);assert dual<1e-9
    pb=[];qb=[]
    for i in range(n):
        gen=np.asarray(data['bus_gens'][i],int)-1;loads=np.asarray(data['bus_loads'][i],int)-1;f=np.asarray(data['bus_arcs_fr'][i],int)-1;t=np.asarray(data['bus_arcs_to'][i],int)-1
        pb.append(np.sum(gon[gen]*x['pg'][gen])-np.sum(on[f]*x['pf'][f])-np.sum(on[t]*x['pt'][t])-a('gs')[i]*vm[i]**2-np.sum(a('pd')[loads]))
        qb.append(np.sum(gon[gen]*x['qg'][gen])-np.sum(on[f]*x['qf'][f])-np.sum(on[t]*x['qt'][t])+a('bs')[i]*vm[i]**2-np.sum(a('qd')[loads]))
    residuals={'active_KCL_pu':float(np.max(abs(np.asarray(pb)))),'reactive_KCL_pu':float(np.max(abs(np.asarray(qb)))),'voltage_lower':positive(a('vmin')-vm),'voltage_upper':positive(vm-a('vmax')),'pg_lower':positive(gon*a('pgmin')-x['pg']),'pg_upper':positive(x['pg']-gon*a('pgmax')),'qg_lower':positive(gon*a('qgmin')-x['qg']),'qg_upper':positive(x['qg']-gon*a('qgmax')),'reference_angle_rad':abs(float(va[int(data['ref_bus'])-1])),'angle_lower_rad':positive(a('dvamin')-on*delta),'angle_upper_rad':positive(on*delta-a('dvamax')),'thermal_from_squared_pu':positive(x['pf']**2+x['qf']**2-a('smax')**2),'thermal_to_squared_pu':positive(x['pt']**2+x['qt']**2-a('smax')**2)}
    for k,y in real.items():residuals['Ohm_'+k+'_pu']=float(np.max(abs(y-x[k])))
    for k in ('pf','qf','pt','qt'):
        residuals[k+'_box']=max(positive(x[k]-on*a('smax')),positive(-on*a('smax')-x[k]))
    return {'all_declared_native_constraints_at_fixed_tolerance':all(v<=TOL for v in residuals.values()),'residuals':residuals,'real_complex_equation_maxdelta':dual,'maximum_native_voltage':float(vm.max()),'source_reference_vm':float(vm[int(data['ref_bus'])-1]),'source_reference_above_original_1p05_guard':bool(vm[int(data['ref_bus'])-1]>1.05+1e-8),'source_reference_below_original_0p95_target':bool(vm[int(data['ref_bus'])-1]<.95),'original_0p95_UV_count':int((vm<.95).sum()),'source_linear_objective':float(np.sum((a('c1')*x['pg']+a('c0'))*gon)),'source_nonzero_quadratic_cost_terms':int(np.count_nonzero(a('c2')))}

def main():
    B.mkdir(exist_ok=False);begun=time.perf_counter();put(B/'Protocol.json',{'status':'FROZEN_BEFORE_NATIVE_RESIDUALS','at_utc':datetime.now(timezone.utc).isoformat(),'all16_indices':list(range(16)),'encodings':['complete_original_case_json_data_and_primal','parquet_float32_inputs_and_primal'],'fixed_tolerance':TOL,'no_status_filter_or_precision_winner_selection':True,'author_formulation_revision':'59938b95c1116f72c3f7763ee0f1eb392dcb7028','generator_revision_for_dataset':'UNKNOWN_NOT_INFERRED_FROM_CURRENT_REPO','source_sha256':sha(__file__),'input_manifest_sha256':sha(BASE/'fixed16/Input_Manifest.json'),'all_new_PF_OPF_LLM_optimizer_derivative_forecast_linear_solve_calls':0,'limits':'Saved-data direct equations/bounds, not independent solver convergence, optimality, original-control actuator compatibility or our-model test.'})
    info=read(BASE/'fixed16/Input_Manifest.json');assert len(info['rows'])==16;rows=[]
    for i,rowmeta in enumerate(info['rows']):
        path=BASE/'fixed16'/f'row_{i:04}.json';assert sha(path)==rowmeta['row_sha256'];row=read(path);raw=json.loads(row['case/json']);data=raw['data'];prim=raw['ACOPF']['primal']
        first=evaluate(data,prim);other=copy.deepcopy(data)
        for k in ('pd','qd','gen_status','branch_status'):other[k]=row['input/'+k]
        second=evaluate(other,{k:row['ACOPF/primal/'+k] for k in prim})
        rows.append({'test_index':i,'provider_status':row['ACOPF/meta/primal_status'],'provider_termination':row['ACOPF/meta/termination_status'],'original_case_json':first,'parquet_columns':second,'config_floating_point_type':raw['config']['floating_point_type']})
    result={'status':'COMPLETE_ALL16_BOTH_ENCODINGS_NATIVE_EQUATION_AUDIT','all16_rows_retained':True,'rows':rows,'json_native_gate_passes':sum(x['original_case_json']['all_declared_native_constraints_at_fixed_tolerance'] for x in rows),'parquet_native_gate_passes':sum(x['parquet_columns']['all_declared_native_constraints_at_fixed_tolerance'] for x in rows),'normal_guard_high_reference_json_rows':[x['test_index'] for x in rows if x['original_case_json']['source_reference_above_original_1p05_guard']],'workflow_seconds':time.perf_counter()-begun,'new_scientific_calls':0,'model_test':'NOT_EXECUTED','role_adaptation':'PENDING. Never clamp source reference voltage or silently drop hard rows. Fixed-reference guard conflicts exclude only that declared serving role, not native network feasibility.'}
    put(B/'Results.json',result);manifest(B);print(json.dumps({k:result[k] for k in ('status','json_native_gate_passes','parquet_native_gate_passes','normal_guard_high_reference_json_rows','new_scientific_calls')}))
if __name__=='__main__':main()
