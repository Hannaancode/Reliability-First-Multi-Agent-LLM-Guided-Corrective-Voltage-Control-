"""Audit-only manifest-race repair. Preserve all original science and failed audit."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
from frozen_physics_loader import load_stack
from value_baseline_gate import require_sealed_baseline
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/actual_DSE_development_reference'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(OUT/'status.json')['stage']=='8_exact_actual_DSE_development_references_complete_pending_independent_audit'
assert read(OUT/'audit_status.json')['stage']=='actual_DSE_reference_audit_failed_preserve_data'
assert not (OUT/'Independent_Completion_Audit.json').exists()
protocol=read(OUT/'protocol.json');manifest=read(OUT/'manifest.json');summary=read(OUT/'summary.json')
expected={'protocol.json','config.json','summary.json'}
expected|={'branches/'+c['scenario_id']+'__'+b+'.json' for c in protocol['scenarios'] for b in ['DFF','DFF-ALT']}
expected|={'portfolios/'+c['scenario_id']+'.json' for c in protocol['scenarios']}
assert len(expected)==27 and set(manifest)==expected|{'audit_status.json'}
for name in expected:
 p=OUT/name;assert sha(p)==manifest[name]['sha256'] and p.stat().st_size==manifest[name]['bytes']
_,_,ref=load_stack();totals={k:0 for k in ['attempts','returns','exceptions']};replay={k:0 for k in totals};quality=[]
assert summary['actual_branches']==16 and summary['actual_portfolios']==8
for case in protocol['scenarios']:
 assert sha(ROOT/case['path'])==case['sha256']
 portfolio=read(OUT/'portfolios'/(case['scenario_id']+'.json'))
 records={b:read(OUT/'branches'/(case['scenario_id']+'__'+b+'.json')) for b in ['DFF','DFF-ALT']}
 assert portfolio['valid']
 for b,row in records.items():
  assert row['scenario_sha256']==case['sha256'] and row['protocol_sha256']==sha(OUT/'protocol.json') and row['base_network_preserved']
  proof=row['independent_committed_state_physical_replay'];assert proof['passed']
  assert proof['actual_committed_actions_replayed']==len(row['result']['executed_actions'])
  assert proof['costs']['attempts']==1+proof['actual_committed_actions_replayed'] and proof['costs']['exceptions']==0
  assert row['actual_controller_costs']['llm_calls']==0
  for k in totals:totals[k]+=row['actual_controller_costs'][k];replay[k]+=proof['costs'][k]
 summaries={b:ref.summarize_result(r['result']) for b,r in records.items()}
 chosen='DFF-ALT' if ref.choose_safety_envelope(summaries['DFF'],summaries['DFF-ALT'])=='reflection_v2' else 'DFF'
 assert portfolio['summaries']==summaries and portfolio['selected_branch']==chosen
 assert portfolio['selected_final_metrics']==records[chosen]['result']['final_metrics']
 for k in totals:assert portfolio['full_two_branch_charged_costs'][k]==sum(r['actual_controller_costs'][k] for r in records.values())
 fm=portfolio['selected_final_metrics'];quality.append({'scenario_id':case['scenario_id'],'valid':True,'selected_branch':chosen,
    'final_metrics':fm,'strict_UV_zero_and_normal_upper_at_diagnostic1e8':fm['uv_count']==0 and fm['vmax']<=1.05+1e-8,
    'portfolio_full_charged_costs':portfolio['full_two_branch_charged_costs']})
assert totals==summary['actual_controller_PF_counts'] and replay==summary['independent_replay_PF_counts']
for name,digest in protocol['frozen_source_sha256'].items():assert sha(ROOT/name.replace('\\','/'))==digest
baseline=require_sealed_baseline(ROOT)
audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_identity_selector_manifest_and_cost_gates_passed':True,
       'actual_primary_comparator':'D-SE, original DFF plus DFF-ALT and selector','exact_branches':16,'exact_portfolios':8,
       'scientific_manifest_members_verified':27,'all_branch_committed_metric_replays_passed_1e10':True,
       'actual_controller_PF_counts':totals,'actual_independent_replay_PF_counts':replay,'quality':quality,
       'manifest_audit_repair':{'original_manifest_sha256':sha(OUT/'manifest.json'),'original_manifest_entries':28,
          'sole_non_scientific_status_file_excluded':'audit_status.json','cause':'Concurrent audit operational status changed after experiment included it in manifest; all27scientific members unchanged',
          'old_manifest_and_failed_audit_preserved':True,'scientific_gate_relaxed':False},
       'new_model_or_PF_calls_by_auditor':0,'original_baseline_seal':baseline,'LLM_superiority_established':False,
       'scope':protocol['scope']}
with (OUT/'Independent_Completion_Audit.json').open('x') as f:json.dump(audit,f,indent=2)
with (OUT/'Verified_Scientific_Manifest.json').open('x') as f:json.dump({name:manifest[name] for name in sorted(expected)},f,indent=2)
print(json.dumps({'exact_DSE_cases':8,'branches':16,'controller_PF':totals,'replay_PF':replay,
                  'UV_clear_cases':sum(r['final_metrics']['uv_count']==0 for r in quality),
                  'joint_UV_and_normal_upper_cases':sum(r['strict_UV_zero_and_normal_upper_at_diagnostic1e8'] for r in quality)},indent=2))
