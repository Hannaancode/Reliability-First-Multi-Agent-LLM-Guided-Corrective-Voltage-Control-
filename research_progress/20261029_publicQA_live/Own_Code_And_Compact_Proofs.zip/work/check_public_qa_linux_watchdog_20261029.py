"""Run once during actual bounded setup, before loading any model."""
from pathlib import Path
import os,subprocess,sys,time
from public_qa_remote_supervisor_20261029 import watchdog_reason,terminate_owned
from public_qa_transfer_20261029 import json_once,sha
def main():
    assert sys.platform=='linux'
    rows=[];limits={'setup_seconds':.3,'science_seconds':20,'call_seconds':.3,'process_seconds':30}
    for case in ['setup','call']:
        began=time.monotonic()
        child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
        events=[] if case=='setup' else [{'kind':'science_start','at_monotonic':began},{'kind':'generation_attempt','at_monotonic':began}]
        while watchdog_reason(events,time.monotonic(),began,limits) is None:time.sleep(.02)
        expected='absolute_setup_bound' if case=='setup' else 'single_call_bound'
        assert watchdog_reason(events,time.monotonic(),began,limits)==expected
        terminate_owned(child);assert child.poll() is not None and not Path('/proc',str(child.pid)).exists()
        rows.append({'case':case,'actual_child_pid':child.pid,'actual_exit_code':child.returncode,'seconds':time.monotonic()-began})
    json_once(Path('Linux_Watchdog_Gate.json'),{'status':'PASS_TWO_ACTUAL_LINUX_CHILD_STOPS','checks':rows,
        'supervisor_sha256':sha(Path('public_qa_remote_supervisor_20261029.py').read_bytes()),'new_model_GPU_PF_calls':0})
if __name__=='__main__':main()
