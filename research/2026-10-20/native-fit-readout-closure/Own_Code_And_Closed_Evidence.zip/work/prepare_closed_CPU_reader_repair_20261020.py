"""Exact-arithmetic saved-output reader repair; preserves original failed source."""
import ast, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    src=ROOT/'work/audit_native_closed_CPU_evidence_20261020.py'
    old=src.read_text(encoding='utf-8')
    new=old.replace("OUT=ROOT/'outputs/native_closed_CPU_evidence_audit_20261020'", "OUT=ROOT/'outputs/native_closed_CPU_evidence_audit_v2_20261020'")
    new=new.replace('outputs/native_closed_CPU_evidence_preparation_20261020/Protocol.json', 'outputs/native_closed_CPU_evidence_repair_preparation_20261020/Protocol.json')
    target="raw=.3*(center@s['alpha'])+ymean;u=np.clip(raw.astype(np.float32),np.float32(-.3),np.float32(.3))"
    replacement="""left=(s['features']-s['mean'])/s['std'];right=s['trainZ'];P=left@right.T/d
        if kernel=='rbf':P=np.exp(-np.maximum(np.sum(left*left,axis=1)[:,None]+np.sum(right*right,axis=1)[None,:]-2*left@right.T,0)/d)
        deployed=P-(P@w/w.sum())[:,None]-s['kernel_mean'][None,:]+s['kernel_grand']
        raw=.3*(deployed@s['alpha'])+ymean;u=np.clip(raw.astype(np.float32),np.float32(-.3),np.float32(.3))"""
    assert old.count(target)==1
    new=new.replace(target,replacement)
    newfile=ROOT/'work/audit_native_closed_CPU_evidence_v2_20261020.py'
    assert not newfile.exists();newfile.write_text(new,encoding='utf-8');ast.parse(new)
    p=json.loads((ROOT/'outputs/native_closed_CPU_evidence_preparation_20261020/Protocol.json').read_text(encoding='utf-8'))
    p['source_and_input_hashes']['work/audit_native_closed_CPU_evidence_v2_20261020.py']=sha(newfile)
    p['source_and_input_hashes']['outputs/native_closed_CPU_evidence_coordination_20261020/End_ACK.json']=sha(ROOT/'outputs/native_closed_CPU_evidence_coordination_20261020/End_ACK.json')
    p['single_owner'].update(source='work/audit_native_closed_CPU_evidence_v2_20261020.py',sha256=sha(newfile),
        output='outputs/native_closed_CPU_evidence_audit_v2_20261020',coordination='outputs/native_closed_CPU_evidence_coordination_v2_20261020')
    p['mechanical_repair']='Original reader reuses trainZ as both dot operands; source deployment reconstructs a distinct input matrix. NumPy symmetric dot arithmetic differs4.16e-16. V2 retains independent training normal equations and reconstructs deployed input separately; strict bitexact raw/native predictions and every other assertion unchanged. All old source/claim/stderr preserved. Zero model/PF/solve/optimizer.'
    prep=ROOT/'outputs/native_closed_CPU_evidence_repair_preparation_20261020'
    with (prep/'Protocol.json').open('x',encoding='utf-8') as f:json.dump(p,f,indent=2)
    diagnosis=json.loads((prep/'Saved_Only_Arithmetic_Diagnosis.json').read_text(encoding='utf-8'))
    assert diagnosis[0]['raw_max_delta']<1e-14 and all(d['deployed_u_exact'] for d in diagnosis)
    # Reader threshold/gate checks are kept; only prediction arithmetic and output/protocol paths changed.
    original_asserts=[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(old)) if isinstance(n,ast.Assert)]
    new_asserts=[ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(new)) if isinstance(n,ast.Assert)]
    assert original_asserts==new_asserts
    proof={'all_original_assert_ASTs_unchanged':True,'original_reader_end_exit':json.loads((ROOT/'outputs/native_closed_CPU_evidence_coordination_20261020/End_ACK.json').read_text())['exit_code'],
           'original_source_sha256':sha(src),'additive_source_sha256':sha(newfile),'new_scientific_calls':0,
           'shell_preparation_parse_failure_and_missing_protocol_launch':'No reader claim or scientific call was created; retained as preparation cost.'}
    with (prep/'Static_Repair_Readiness.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
    print('ADDITIVE_DEPLOYED_ARITHMETIC_READER_READY_STRICT_ASSERTIONS_UNCHANGED')
if __name__=='__main__':main()
