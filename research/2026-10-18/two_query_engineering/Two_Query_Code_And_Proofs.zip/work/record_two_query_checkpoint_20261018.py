"""Compact durable checklist/resume recording; never starts scientific work."""
import json,os
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/exact_two_paid_query_engineering_20261018'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def atomic(p,v):
    q=p.with_name(p.name+'.new');raw=json.dumps(v,indent=2,allow_nan=False).encode()
    with q.open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(q,p)
def main():
    now=datetime.now(timezone.utc).isoformat();ready=read(B/'Readiness.json');p=read(B/'Protocol.json')
    ownership=(B/'warm/Launcher_ACK.json').exists() and (B/'warm/Source_Lock.json').exists()
    completed=(B/'Completion.json').exists();auditpath=B/'audit_source_claim_v2/Independent_Audit.json'
    audit=read(auditpath) if auditpath.exists() else None
    repair=read(B/'reader_source_claim_repair_v2/Completion.json') if (B/'reader_source_claim_repair_v2/Completion.json').exists() else {}
    passed=completed and audit and audit['status']=='PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING' and repair.get('reader_exit_code')==0 and all(v==0 for v in read(B/'Completion.json')['exit_codes'].values())
    stage='COMPLETE_FIXED_TWO_QUERY_ENGINEERING_INDEPENDENT_PASS' if passed else 'TERMINAL_PRESERVE_PARTIAL_OR_FAILURE_NO_SCIENCE_RETRY' if completed else 'RUNNING_FIXED_TWO_QUERY_ENGINEERING'
    files=['RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json']
    backup=B/'progress_before_update'
    if not backup.exists():
        backup.mkdir()
        for rel in files:(backup/Path(rel).name).write_bytes((R/rel).read_bytes())
    task=read(R/files[1]);task['at_utc']=now
    for s in task['tasks'][0]['subtasks']:
        if s['id']=='G1.5' and ownership:s.update(completed=True,evidence='outputs/exact_two_paid_query_engineering_20261018/Readiness.json',verified_at_save=now)
        if s['id']=='G1.6' and passed:s.update(completed=True,evidence='outputs/exact_two_paid_query_engineering_20261018/audit_source_claim_v2/Independent_Audit.json',verified_at_save=now)
    task['tasks'][0]['next']='Freeze the next complete source-exact continuation and independent reader; reuse BOTH exact new receipts without repeating calls. No whole-policy claim from engineering.' if passed else 'Inspect actual fixed two-query result/closed manifests and independent reader; never duplicate or retry scientific owners.'
    task['tasks'][0]['latest_query_engineering']={'at_utc':now,'status':stage,'independent_audit':audit,'not_a_policy_LLM_superiority_test':True}
    atomic(R/files[1],task)
    md=(R/files[0]).read_text('utf-8')
    for n,e in [('G1.5','Readiness.json'),('G1.6','audit_source_claim_v2/Independent_Audit.json')]:
        if (n=='G1.5' and ownership) or (n=='G1.6' and passed):
            lines=md.splitlines();lines=[line.replace('- [ ]','- [x]',1)+f' [Evidence](outputs/exact_two_paid_query_engineering_20261018/{e})' if f'`{n}`' in line and line.startswith('- [ ]') else line for line in lines];md='\n'.join(lines)+'\n'
    md=md.split('Scheduled continuation:')[0].rstrip()+'\n\nLatest continuation: '+now+'. '+stage+'. Start-only timer deleted after the requested21:06Qatar start. No GPU allocated. All six final goals remain open.\n'
    (R/files[0]).write_text(md,'utf-8')
    resume=read(R/files[2]);resume['at_utc']=now;resume['current_task']={'status':stage,'output':str(B.relative_to(R)),'fixed_deadline_utc':p['absolute_deadline_utc'],'independent_audit':audit,'scope':'TWO new physical query identities plus at mostTWO explicitly charged replays; query-only cold preservation; no commits/LLM/GPU/full-policy claim'}
    resume['scheduled_continuation'].update(status='TRIGGERED_AFTER18_06UTC_START_AUTOMATION_DELETED',started_UTC='2026-10-18T18:06:01+00:00')
    resume['timers']='NONE; start-only automation deleted. Do not revive recurring monitors.'
    resume['next_tasks']=[task['tasks'][0]['next'],'Save failures/partial/UNKNOWN/costs and publish closed code/proofs/checklist to existing GitHub branch using current-head lease/byte verification.','Continue all six priorities; no unsupported zero-all, fullDSE or incrementalLLM claim.']
    resume['active_owned_jobs']=[] if completed else [{'coordinator_claim':'outputs/exact_two_paid_query_engineering_20261018/Coordinator_Claim.json','do_not_duplicate':True}]
    atomic(R/files[2],resume)
    note=f'\n\n{now} — Fixed two-query engineering: {stage}. Prelaunch actualNET/native-verifier blocked-kernel paths2; real cold state/history/registry/RNG fixture PASS with0scientificcalls. Fixed2newqueries and atmost2chargedreplays,1200sec absolute whole bound; no original state/operation/cap/protection changes, no commits/model/GPU. '
    if audit:note+='Independent reader: '+json.dumps(audit,separators=(',',':'))
    note+=' All6finalgoalsopen. Exact source/protocol/ownership/cost/failure evidence in outputs/exact_two_paid_query_engineering_20261018. Start-only timer deleted.\n'
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write(note);f.flush();os.fsync(f.fileno())
    header=f'LATEST TWO-QUERY CONTINUATION {now}\n\n{stage}. Read RESEARCH_TASKS.md and current exact resume. '+task['tasks'][0]['next']+' Original frozen assets/all adverse evidence/DFF+DFFALT+unchangedDSE and full both costs preserved; all6finalgoalsopen. NoGPU/timers.\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md']:
        path=R/rel;old=path.read_text('utf-8');path.write_text(header+old,'utf-8')
    print(json.dumps({'recorded':stage,'G1_5':bool(ownership),'G1_6':bool(passed),'all6goalsopen':True}))
if __name__=='__main__':main()
