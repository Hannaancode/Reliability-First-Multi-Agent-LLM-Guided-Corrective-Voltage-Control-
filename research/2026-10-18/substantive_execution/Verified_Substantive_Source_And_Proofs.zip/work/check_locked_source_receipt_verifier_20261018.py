"""OS write exclusion, exact protocol and source-close boundaries; zero science."""
import hashlib,json,time
from pathlib import Path
from full_receding_paid_campaign_20261015 import put
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
R=Path(__file__).resolve().parents[1];B=R/'outputs/locked_source_receipt_verifier_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();f=B/'source_fixture.txt';f.write_text('Exact immutable source fixture\n',encoding='utf-8');h=hashlib.sha256(f.read_bytes()).hexdigest()
    protocol={'source_input_sha256':{str(f.relative_to(R)):h},'runtime_versions':{}};put(B/'Protocol.json',protocol)
    lease=LockedSourceSnapshot(B/'Protocol.json');checks={};lease.verify(protocol)
    try:
        try:f.write_text('changed',encoding='utf-8')
        except PermissionError:checks['source_write_blocked_by_OS']=True
        else:raise AssertionError('Source write was allowed')
        try:f.unlink()
        except PermissionError:checks['source_delete_blocked_by_OS']=True
        else:raise AssertionError('Source delete was allowed')
        try:lease.verify({**protocol,'changed':True})
        except AssertionError:checks['foreign_protocol_rejected']=True
        else:raise AssertionError('Foreign protocol accepted')
        assert hashlib.sha256(f.read_bytes()).hexdigest()==h;checks['source_bytes_unchanged_read_access_remains']=True
    finally:lease.close()
    try:lease.verify(protocol)
    except AssertionError:checks['closed_snapshot_cannot_authorize_certificate']=True
    else:raise AssertionError('Closed snapshot accepted')
    f.write_text('Post-close fixture update\n',encoding='utf-8');checks['explicit_close_releases_fixture_lock']=True
    put(B/'Results.json',{'status':'PASS_WINDOWS_SOURCE_HASH_SNAPSHOT_AND_LIVE_WRITE_EXCLUSION','checks':checks,'new_science':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Software/source lease only, not a physical policy result or authorization to execute a new identity.'})
    print(json.dumps({'source_lease':'PASS','checks':len(checks),'science':0}))
if __name__=='__main__':main()
