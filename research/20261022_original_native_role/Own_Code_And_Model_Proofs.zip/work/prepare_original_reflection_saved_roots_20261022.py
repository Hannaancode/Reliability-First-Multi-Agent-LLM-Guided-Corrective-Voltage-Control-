"""Bind two actual paid native roots to original FIRST_ZONE serving inputs.

Read-only state/prompt preparation. No old PF, model query or archive audit is
repeated. These are the first two actually entered roots of a fixed old study,
not a new two-case performance sample or unused confirmation.
"""
import ast
import hashlib
import json
import os
import pickle
import time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/original_reflection_saved_root_preparation_20261022'
OLD = R / 'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def put(name, value):
    with (P / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush(); os.fsync(f.fileno())


def main():
    P.mkdir(exist_ok=False)
    started = time.perf_counter()
    import candidate_process_runtime
    import sys
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import numpy as np
    import pandapower as pp
    from transformers import AutoTokenizer
    from frozen_physics_loader import load_stack, AUDIT
    from original_reflection_serving_pure_20261022 import initial_messages, original_query, FILES, FUNCTIONS
    forbidden = []
    def refuse(*a, **k):
        forbidden.append(True)
        raise BaseException('No new or replayed physics allowed during saved-root binding')
    for name in ['runpp', 'runopp', 'rundcpp', 'runpp_3ph']:
        if hasattr(pp, name): setattr(pp, name, refuse)
    prior = json.loads((OLD / 'preparation/Protocol.json').read_text('utf-8'))
    old_audit = json.loads((OLD / 'independent_partial_audit_v1/Independent_Audit.json').read_text('utf-8'))
    assert old_audit['status'] == 'PASS_PRESERVED_PREFIX_AND_FOUR_COMPLETED_BRANCHES'
    v2, runner, reflection = load_stack()
    assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    zones = json.loads((R / prior['metadata_path']).read_text('utf-8'))['zones']
    adapter = R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    tokenizer = AutoTokenizer.from_pretrained(str(adapter), local_files_only=True, trust_remote_code=False)
    items, anchors, shapes = [], [], []
    for job in ['L1_literal_DFF', 'L2_literal_DFF']:
        assert time.perf_counter() - started < 180
        spec = next(x for x in prior['jobs'] if x['job_id'] == job)
        folder = OLD / 'branches' / job
        root_event = None
        with (folder / 'scientific.jsonl').open('rb') as f:
            for line in f:
                wrapper = json.loads(line); row = wrapper['row']
                if row['event'] == 'literal_PF_return' and row['payload']['role'] == 'initial':
                    root_event = row
                    break
        assert root_event is not None
        anchor = root_event['payload']['anchors']; cap = folder / anchor['relative']
        assert sha(cap / 'Manifest.json') == anchor['manifest_sha256']
        meta = json.loads((cap / 'Manifest.json').read_text('utf-8'))
        raw = (cap / 'trusted_local_net.pkl').read_bytes()
        assert len(raw) == meta['payload_bytes'] and hashlib.sha256(raw).hexdigest() == anchor['payload_sha256'] == meta['payload_sha256']
        obj = pickle.loads(raw); net = obj['net']
        assert net.converged and len(net.bus) == len(net.res_bus) == 118
        assert np.isfinite(net.res_bus[['vm_pu', 'va_degree', 'p_mw', 'q_mvar']].to_numpy()).all()
        # No repeated scenario application: this is the actually captured state.
        assert sha(R / spec['scenario_path']) == spec['scenario_sha256']
        before = pickle.dumps(net, protocol=5)
        global_uv = runner.rescue.global_uv_buses(net)
        zone = sorted(zones)[0]
        state = runner.rescue.extract_zone_state_full(net, zone, zones)
        candidates = runner.get_zone_candidate_buses(net, zone, zones, state)
        assert global_uv and candidates
        item = {'agent': len(items), 'root': spec['root'], 'job_id': job,
                'scenario_path': spec['scenario_path'], 'scenario_sha256': spec['scenario_sha256'],
                'physical_bus': int(candidates[0]), 'zone': zone, 'zone_state': state,
                'global_uv': global_uv, 'candidate_buses': candidates,
                'source_state_receipt': anchor, 'original_global_metrics': runner.rescue.grid_metrics(net),
                'scope': 'ORIGINAL_FIRST_ZONE_FIRST_ITERATION_ONLY; later-zone feedback not fabricated'}
        messages = initial_messages(item)
        assert messages == reflection.build_two_best_prompt_v2('reflection_v2', state, global_uv, candidates, [], reflection.init_feedback_state())
        encoded = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
        ids = encoded['input_ids'] if hasattr(encoded, 'keys') else encoded
        assert isinstance(ids, list) and all(type(v) is int for v in ids) and len(ids) + 384 <= 4096
        item.update(messages=messages, token_ids=ids, prefix_tokens=len(ids),
                    messages_sha256=hashlib.sha256(json.dumps(messages, sort_keys=True).encode()).hexdigest())
        assert pickle.dumps(net, protocol=5) == before
        # Original valid branch and its conditional error-reprompt branches are
        # checked with labelled strings, not a pretrained model or PF.
        calls = []
        def valid(*args):
            calls.append(args[-1]); return json.dumps({'bus': str(candidates[0]), 'q_mvar': 25})
        action, info = original_query(item, valid)
        assert len(calls) == 1 and calls[0] == messages and info['valid_action'] and not info['reprompted']
        invalid_calls = []
        def invalid(*args):
            invalid_calls.append(args[-1]); return 'INVALID_LABELLED_SOFTWARE_FIXTURE'
        action, info = original_query(item, invalid)
        assert action is None and len(invalid_calls) == 2 and info['reprompted']
        second = tokenizer.apply_chat_template(invalid_calls[1], tokenize=True, add_generation_prompt=True)
        second = second['input_ids'] if hasattr(second, 'keys') else second
        assert len(second) + 384 <= 4096
        anchors.append({'root': spec['root'], 'scenario_sha256': spec['scenario_sha256'],
                        'scenario_path': spec['scenario_path'], 'source_branch': str(folder.relative_to(R)),
                        'receipt': root_event, 'capsule_manifest': meta,
                        'full_actual_root_payload': str((cap / 'trusted_local_net.pkl').relative_to(R)),
                        'payload_sha256': anchor['payload_sha256'], 'four_field_all118_finite': True,
                        'same_actual_captured_NET_before_any_new_LLM_or_action': True,
                        'actual_old_root_PF_seconds_not_free': root_event['payload']['seconds'],
                        'independent_new_root_physics_replay_this_binding': False,
                        'physical_performance_or_fresh_confirmation_claim': False})
        shapes.append({'root': spec['root'], 'prefix_tokens': len(ids), 'labelled_reprompt_tokens': len(second),
                       'original_UV': len(global_uv), 'candidate_buses': candidates})
        items.append(item)
    put('All2_Original_FIRST_ZONE_Inputs.json', items)
    put('Exact_Paid_Root_State_Bindings.json', anchors)
    put('Prompt_And_Reprompt_Software_Checks.json', {
        'status': 'PASS_ORIGINAL_AST_FIRST_ZONE_INPUT_AND_TWO_BRANCH_CALL_STRUCTURE',
        'two_actual_paid_root_states': True, 'no_later_zone_or_future_feedback': True,
        'actual_initial_and_conditional_prompt_lengths': shapes,
        'new_solver_attempts': len(forbidden), 'new_model_PF_converter_derivative_calls': 0})
    certificate = {}
    for kind, names in FUNCTIONS.items():
        path = R / FILES[kind]; tree = ast.parse(path.read_text('utf8'))
        certificate[kind] = {'path': FILES[kind], 'source_sha256': sha(path),
             'functions': {n.name: hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest()
                           for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names}}
    put('Original_Function_AST_Pins.json', certificate)
    put('Preparation_Result.json', {'status': 'PASS_TWO_ACTUAL_SAVED_ROOTS_ORIGINAL_CAUSAL_ROLE_PREPARATION_ONLY',
        'source_sha256': sha(Path(__file__)), 'actual_root_count': 2, 'whole203_federation_root_closure': False,
        'root_selection': 'First two source-order entered roots of the old fixed8development-root study; no model-outcome selection. The other6 are not silently generated or filled.',
        'original_paper137_or_external_benchmark': False, 'new_GPU_model_PF_training_calls': 0,
        'actual_root_input_and_prompt_bindings': shapes, 'elapsed_seconds': time.perf_counter() - started,
        'next': 'Separate source/input/loader/nonrepeat/ownership/preservation/independent-reader freeze before one bounded native-role model study.'})
    print(json.dumps({'status': 'PASS_SAVED_ROOT_AND_ORIGINAL_FIRST_ZONE_INPUT_PREPARATION', 'roots': shapes, 'newscience': 0}))


if __name__ == '__main__':
    main()
