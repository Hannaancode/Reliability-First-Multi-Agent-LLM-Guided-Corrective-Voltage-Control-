"""Isolated import/source/cursor/output gates before any new model performance."""
import candidate_process_runtime
import ast,hashlib,importlib,json,os,sys,tempfile,zipfile
from pathlib import Path
from candidate_process_evidence_utils import ROOT,read,write,sha
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';PREP=P/'learning_preparation'
payload=read(PREP/'Cloud_Payload_Manifest.json');archive=ROOT/payload['archive']
assert archive.stat().st_size==payload['bytes'] and sha(archive)==payload['sha256']
assert not (P/'lm_i').exists() and not (P/'lm_f').exists() and not (P/'lm_handoff').exists() and not (P/'lm_audit').exists()
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    for n,h in payload['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
    with tempfile.TemporaryDirectory(prefix='hg_learning_imports_') as tmp:
        root=Path(tmp);checked=[]
        for n in z.namelist():
            if n.startswith('work/') and n.endswith('.py'):
                (root/n).parent.mkdir(parents=True,exist_ok=True);(root/n).write_bytes(z.read(n))
        sys.path=[str(root/'work')]+[v for v in sys.path if Path(v or '.').resolve()!=ROOT/'work']
        try:
            for f in (root/'work').glob('*.py'):
                if f.stem in {'relational_learning_environment_check','relational_learning_guardian'}:continue
                m=importlib.import_module(f.stem);assert Path(m.__file__).is_relative_to(root);checked.append(f.stem)
        finally:os.chdir(ROOT)
for n,h in read(PREP/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha(ROOT/n)==h
external=['work/audit_relational_learning_results.py','work/continue_relational_learning_joint_audit.py']
for n in external:ast.parse((ROOT/n).read_text())
write(PREP/'External_Reader_Source_Lock.json',{n:sha(ROOT/n) for n in external})
write(PREP/'Final_Isolated_Bundle_and_Reader_Readiness.json',{'passed':True,'actual_only_bundle_imports_checked':checked,
 'all_member_CRC_hashes_source_dependencies_profiles_paths_and_two_arm_AST_launches_passed':True,
 'variable_native_grounding_optimizer_steps_and_delta_chain_fixture_passed':True,
 'joint_reader_preserves_actual_controls_native_score_world_rejection_and_failure_denominators':True,
 'genuine_model_forward_optimizer_PF_allocation_calls_by_readiness':0})
print('FIXED_FULL_LEARNING_BUNDLE_AND_JOINT_READER_READY_ZERO_MODEL_CALLS')
