"""One labelled synthetic unsolved derivative fixture. Never calls a solver."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
import numpy as np
from remaining85_nonlinear_kernel_20261029 import NonlinearNative13
from nonlinear13_analytic_derivatives_20261029 import equality_jacobian,inequality_jacobian,objective_gradient
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear13_derivative_preparation_20261029'
def main():
    O.mkdir(exist_ok=False)
    protocol=dict(label='ONE_NEW_SYNTHETIC_UNSOLVED_ALGEBRA_FIXTURE',seed=20261029,
      finite_difference_step=1e-6,derivative_absolute_error_limit=1e-7,
      no_actual_saved_KCL_replay=True,new_optimizer_PF_model_training_calls=0,
      source_hashes={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ['work/remaining85_nonlinear_kernel_20261029.py','work/nonlinear13_analytic_derivatives_20261029.py',Path(__file__).relative_to(R).as_posix()]})
    (O/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    # Construct a connected complex admittance matrix with no physical solver.
    rng=np.random.default_rng(protocol['seed']);Y=np.zeros((13,13),complex)
    for a,b in [(i,(i+1)%13) for i in range(13)]+[(0,6),(3,9)]:
        y=rng.uniform(.2,1.2)-1j*rng.uniform(1.,3.)
        Y[a,a]+=y;Y[b,b]+=y;Y[a,b]-=y;Y[b,a]-=y
    Y+=np.diag(1j*np.linspace(0.,.02,13))
    bus=np.zeros((13,18));bus[:,0]=np.arange(13);bus[:,1]=1;bus[0,1]=3
    bus[:,2:4]=rng.uniform(.1,1.,(13,2));gen=np.zeros((1,21));gen[0,[0,1,2,7]]=[0,12,5,1]
    vm=np.linspace(.94,1.06,13);V=vm*np.exp(1j*np.linspace(-.12,.08,13))
    m=NonlinearNative13(Y,V,bus,gen,10.,np.arange(13),np.array([2,7,9]),vm,np.array([.1,-.2,.05]),np.ones(3),np.ones(3,bool),False,False)
    x=m.initial_vector();x[24:27]=[.025,-.04,.03];x[27:30]=[.3,.3,.3];x[30]=.08
    h=protocol['finite_difference_step'];results=[]
    funcs=[('AC_equality',m.equality,lambda z:equality_jacobian(m,z)),
      ('inequalities_stage1',m.inequalities,lambda z:inequality_jacobian(m,z)),
      ('inequalities_stage2',lambda z:m.inequalities(z,.08),lambda z:inequality_jacobian(m,z,.08)),
      ('objective1',lambda z:np.atleast_1d(m.objective(z,1)),lambda z:objective_gradient(m,z,1)[None,:]),
      ('objective2',lambda z:np.atleast_1d(m.objective(z,2)),lambda z:objective_gradient(m,z,2)[None,:])]
    for name,f,j in funcs:
        a=j(x);fd=np.empty_like(a)
        for k in range(31):
            xp=x.copy();xm=x.copy();xp[k]+=h;xm[k]-=h;fd[:,k]=(f(xp)-f(xm))/(2*h)
        err=float(np.max(np.abs(a-fd)));assert err<=1e-7,(name,err)
        results.append(dict(name=name,max_abs_error=err,shape=list(a.shape)))
    # Test the untested zero-magnitude one-sided domain boundary explicitly.
    zero=x.copy();zero[12]=0.;plus=zero.copy();plus[12]+=h
    one=(m.inequalities(plus)-m.inequalities(zero))/h
    err=float(np.max(np.abs(one-inequality_jacobian(m,zero)[:,12])));assert err<=1e-7
    results.append(dict(name='zero_magnitude_right_domain_derivative',max_abs_error=err))
    reject=x.copy();reject[12]=-1.
    try:inequality_jacobian(m,reject)
    except ValueError:pass
    else:raise AssertionError('Negative magnitudes must be rejected by domain checker')
    out=dict(status='PASS_LABELLED_SYNTHETIC_DERIVATIVES_NOT_PHYSICAL_PERFORMANCE',at_utc=datetime.now(timezone.utc).isoformat(),
      checks=results,costs=m.costs,new_PF_optimizer_model_calls=0,production_all500_state_binding='PENDING_SEPARATE_GATE',
      independent_review='PENDING',source_hashes=protocol['source_hashes'])
    (O/'Results.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
if __name__=='__main__':main()
