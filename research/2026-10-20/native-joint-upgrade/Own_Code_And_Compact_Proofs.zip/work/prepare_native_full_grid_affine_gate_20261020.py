"""Freeze all24 paid endpoints and fixed numerical opportunity gate; mock LP calls only."""
import json,hashlib,pickle,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_full_grid_affine_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);import stable_ddpg_native_bridge_20261020 as bridge
    from native_full_grid_affine_core_20261020 import problem,second_problem
    from scipy.optimize import linprog
    from candidate_process_evidence_utils import frozen_checks
    np=bridge.np;checks=[]
    # Three-column native control; only column0 active in labelled scalar fixtures.
    for vm,slope,expected_d in [(.9,.4,.125),(1.1,.4,-.125)]:
        c,a,b,bounds=problem([vm],[[slope,0,0]],[0,0,0]);r=linprog(c,A_ub=a,b_ub=b,bounds=bounds,method='highs');assert r.success;c,a,b,bounds=second_problem(c,a,b,bounds,r.x[-1]);r=linprog(c,A_ub=a,b_ub=b,bounds=bounds,method='highs');assert r.success and abs(r.x[0]-expected_d)<1e-8;checks.append({'label':'MOCK_ONLY_native_injection_sign_and_minimum_absolute_Q','vm':vm,'delta':float(r.x[0])})
    c,a,b,bounds=problem([1.04,.9],[[.4,0,0],[.4,0,0]],[0,0,0]);r=linprog(c,A_ub=a,b_ub=b,bounds=bounds,method='highs');assert r.success and abs(r.x[0]-.025)<1e-8 and abs(r.x[-1]-.04)<1e-8;checks.append({'label':'MOCK_ONLY_original_normal_bus_hard_protection','delta':float(r.x[0]),'unfixed_violation':float(r.x[-1])})
    source=ROOT/'outputs/native_action_upgrade_support_20261020';p=json.loads((source/'Result.json').read_text(encoding='utf-8'));audit=json.loads((ROOT/'outputs/native_action_upgrade_support_independent_20261020/Independent_Audit.json').read_text(encoding='utf-8'));assert p['status']=='COMPLETE_DECLARED8_BASELINE_SUPPORT_SCREEN' and audit['status'].startswith('PASS_')
    contexts=[];inputs={};controls=[]
    for case in p['cases']:
        for alg in case['algorithms']:
            e=alg['endpoint'];rec=next(r for r in p['receipts'] if r['status']=='RETURNED' and r['context']=={'seed':case['seed'],'algorithm':alg['algorithm'],'step':e['step']});f=source/'physics'/f"PF{rec['index']:04d}_after.pkl";fields=source/'physics'/f"PF{rec['index']:04d}_fields.npz"
            with f.open('rb') as z:net=pickle.load(z)
            assert np.array_equal(net.res_bus.vm_pu.to_numpy(),np.asarray(e['all13_vm'])) and np.array_equal(net.sgen.q_mvar.to_numpy()[:3],np.asarray(e['absolute_Q_Mvar']).reshape(3));contexts.append({'seed':case['seed'],'algorithm':alg['algorithm'],'paid_NET':f.relative_to(ROOT).as_posix(),'paid_fields':fields.relative_to(ROOT).as_posix(),'paid_source_steps':e['step'],'remaining_original100step_operations':100-e['step']});inputs[f.relative_to(ROOT).as_posix()]=sha(f);inputs[fields.relative_to(ROOT).as_posix()]=sha(fields)
    assert len(contexts)==24 and len({(c['seed'],c['algorithm']) for c in contexts})==24
    graph='outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz';inputs[graph]=sha(ROOT/graph);sources=['work/native_full_grid_affine_core_20261020.py','work/run_native_full_grid_affine_gate_20261020.py','work/audit_native_full_grid_affine_gate_20261020.py'];protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'ALL24completepaidterminalcontextsfromfixed8newdevelopmentrootsx3publishedcontrollers,includingallalreadyrestoredcases. A strongercentralized numericalcontrolopportunity gate,not a subsetchosenforwins.','all24contexts':contexts,'graph':graph,'sources':{n:sha(ROOT/n) for n in sources},'inputs':inputs,'worker_seconds':600,'LP_options':{'time_limit':10.0,'maxiter':10000},'method':'OneexactcurrentanalyticdSbus_dV,24x24LU and3injectionRHS percontext. Fixedlexicographic LP1minimizemaxglobalbandviolationwithhardprotectionofcurrentlynormalbus; LP2minimizeabsoluteQsubjecttoLP1t+1e-10. Eachactuatornativefloat32delta<=0.3,originalabsoluteQnotinvented. Roundintoexactsourcefloat32u/PIcursor,savecandidateUNEXECUTED. No settings/outcome sweeps.','planned_actual_costs_not_completion':{'derivative_calls':24,'LU':24,'RHS':72,'LP':48,'PF_model_GPU':0},'reader':'Independent densecomplexcalculus,RHS/equationproofandLPprimal-dualcertificates;0newderivative/factor/solve/LP/PF/model.','claim_limits':'CentralizedYbus/all13VM differsfrompublishedownlocalVMactor;notLLMbenefitorsameinformationbenchmark. Linearizedinfeasibility/feasibilityisnotnonlinearproof. Candidatephysicsrequiresseparateexactsource/history/ownership/preservation/reader/costprotocol,noautomaticcalls.','mock_software_LP_calls':5,'mock_checks':checks,'frozen_original_checks':frozen_checks()};put(OUT/'Protocol.json',protocol)
    for mode,src,output,coord in [('primary',sources[1],'outputs/native_full_grid_affine_gate_20261020','outputs/native_full_grid_affine_coordination_20261020'),('independent',sources[2],'outputs/native_full_grid_affine_independent_20261020','outputs/native_full_grid_affine_reader_coordination_20261020')]:put(OUT/(mode+'_Owner_Protocol.json'),{'single_owner':{'source':src,'sha256':sha(ROOT/src),'python':'work/vcsa_module_env/Scripts/python.exe','output':output,'coordination':coord,'bound_seconds':650},'require_ended_claims':[] if mode=='primary' else ['outputs/native_full_grid_affine_gate_20261020/owner.claim'],'old_scientific_source_name':'run_native_full_grid_affine_gate_20261020.py'})
    put(OUT/'Readiness.json',{'status':'PASS_ALL24_SOURCE_PAID_NET_FIELDS_NATIVE_UNITS_PROTECTION_MOCK_AND_READER_LOCK','real_derivative_factor_solve_PF_model_calls':0,'software_mock_LP_calls':5,'all24contexts':len(contexts),'current_all_candidates':'UNKNOWN_UNEXECUTED','no_GPU_training_permission':True});print('ALL24_AFFINE_GATE_PREPARED_ZERO_REAL_SCIENCE')
if __name__=='__main__':main()
