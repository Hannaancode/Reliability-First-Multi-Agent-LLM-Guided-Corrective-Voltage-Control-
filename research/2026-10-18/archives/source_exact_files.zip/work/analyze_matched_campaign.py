"""Descriptive paired ledger; does not tune controllers or impute failures."""
from pathlib import Path
import json,csv,hashlib,statistics
def analyze():
 root=Path('outputs');protocol=json.loads((root/'matched_campaign_protocol.json').read_text());protocol_hash=hashlib.sha256((root/'matched_campaign_protocol.json').read_bytes()).hexdigest()
 lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());cases={p.stem:json.loads(p.read_text()) for p in (root/'matched_campaign/cases').glob('*.json')}
 expected={Path(n).stem:h for n,h in lock['scenario_file_sha256'].items()}
 assert set(cases)==set(expected), 'Full locked-bank ledger required'
 rows=[];valid=[]
 for sid in sorted(cases):
  d=cases[sid];assert d['scenario_sha256']==expected[sid] and d['protocol_sha256']==protocol_hash
  row={'scenario_id':sid,'paired_terminal_metrics_valid':d['paired_terminal_metrics_valid']}
  for branch in ['DFF','DFF-ALT','HG-VF']:
   b=d['branches'][branch];row[branch+'_final_uv']=(b.get('final_metrics') or {}).get('uv_count');row[branch+'_exception']=b.get('exception_type')
  if d['paired_terminal_metrics_valid']:
   for label in ['D-SE','HG-SE']:
    p=d['portfolios'][label];row[label+'_chosen_branch']=p['selected_branch'];row[label+'_final_uv']=p['summary']['final_uv'];row[label+'_final_deficit']=p['summary']['final_deficit'];row[label+'_accepted_actions']=p['summary']['accepted_actions']
    row[label+'_added_support_mvar']=sum(abs(float(q)) for a in d['branches'][p['selected_branch']]['executed_actions'] for q in a['action'].get('add_shunts_q_mvar',{}).values())
    for k,v in p['charged_cost'].items():row[label+'_'+k]=v
   row['HG-SE_minus_D-SE_final_uv']=row['HG-SE_final_uv']-row['D-SE_final_uv'];valid.append(row)
  else:row['failure_nonfinite_paths']=';'.join(d.get('nonfinite_value_paths',[]))
  rows.append(row)
 columns=list(dict.fromkeys(k for row in rows for k in row))
 with (root/'matched_campaign_paired_ledger.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
 report={'locked_case_count':62,'downloaded_and_hash_verified':len(cases),'valid_paired_outcomes':len(valid),'invalid_or_failed_scenario_ids':[r['scenario_id'] for r in rows if not r['paired_terminal_metrics_valid']],'HG_SE_lower_final_uv_count':sum(r['HG-SE_minus_D-SE_final_uv']<0 for r in valid),'D_SE_lower_final_uv_count':sum(r['HG-SE_minus_D-SE_final_uv']>0 for r in valid),'equal_final_uv_count':sum(r['HG-SE_minus_D-SE_final_uv']==0 for r in valid),'analysis_scope':'Descriptive observed ledger over valid paired outcomes. Every invalid/failure case remains listed; no zero imputation or claim of superiority over all 62 cases. Inferential analysis and physical validity/effort checks remain separate reviewer work.'}
 for label in ['D-SE','HG-SE']:
  report[label]={'total_final_uv_on_valid_pairs':sum(r[label+'_final_uv'] for r in valid),'mean_charged_wall_seconds':statistics.mean(r[label+'_wall_seconds'] for r in valid) if valid else None,'total_actual_pf_attempts':sum(r[label+'_pf_attempts'] for r in valid),'total_actual_llm_calls':sum(r[label+'_llm_calls'] for r in valid)}
 (root/'matched_campaign_summary.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':print(json.dumps(analyze(),indent=2))
