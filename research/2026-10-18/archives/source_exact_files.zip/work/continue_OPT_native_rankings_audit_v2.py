"""One finite actual-process wait and subsequent sole external reader."""
import ctypes,json,os,subprocess,time,traceback
from ctypes import wintypes
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import ROOT,read,sha,write
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';OUT=P/'nnrank2_handoff';S=P/'nnrank2';A=P/'nnrank2_audit'
def run():
    assert not OUT.exists();OUT.mkdir();stamp=datetime.now(timezone.utc).isoformat()
    write(OUT/'owner.claim',{'pid':os.getpid(),'started_at_utc':stamp,'source_sha256':sha(Path(__file__))})
    def status(v):
        tmp=OUT/'status.tmp';tmp.write_text(json.dumps({'updated_at_utc':datetime.now(timezone.utc).isoformat(),'pid':os.getpid(),**v},indent=2));tmp.replace(OUT/'status.json')
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
    kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
    handle=None
    try:
        limit=time.monotonic()+120
        while not (S/'owner.claim').exists():
            assert time.monotonic()<limit,'Owner did not produce its actual claim';time.sleep(2)
        claim=read(S/'owner.claim');pid=claim['pid']
        assert claim['source_sha256']==sha(ROOT/'work/run_OPT_full_native_affine_rankings_v2.py')
        command=subprocess.run(['powershell','-NoProfile','-Command',f'Get-CimInstance Win32_Process -Filter "ProcessId={pid}" | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress'],capture_output=True,text=True,check=True).stdout.strip()
        assert command,'Owner actual process missing at handoff startup'
        fresh=json.loads(command);assert fresh['ProcessId']==pid and 'run_OPT_full_native_affine_rankings_v2.py' in fresh['CommandLine']
        write(OUT/'Fresh_Actual_Owner_Identity.json',fresh)
        handle=kernel.OpenProcess(0x1000|0x00100000,False,pid);assert handle,'Cannot bind exact owned process handle'
        bound=time.monotonic()+read(P/'native_ranking_preparation_v2/Protocol.json')['owner_bound_seconds']+600
        status({'stage':'waiting_for_exact_actual_numerical_owner','owner_pid':pid})
        while True:
            code=wintypes.DWORD();assert kernel.GetExitCodeProcess(handle,ctypes.byref(code))
            if code.value!=259:break
            assert time.monotonic()<bound,'Owner wait resource bound; never restart the owner'
            time.sleep(30)
        write(OUT/'Actual_Owner_Exit.json',{'actual_pid':pid,'exit_code':code.value,'recorded_at_utc':datetime.now(timezone.utc).isoformat()})
        assert code.value==0,'Numerical owner failed; preserve partials, complete-only handoff cannot silently rerun science'
        assert read(S/'status.json')['stage'] in {'complete_closed_native_numerical_study','terminal_partial_preserved_no_retry'}
        assert (S/'Summary.json').exists() and (S/'Supplement_Manifest.json').exists() and not A.exists()
        status({'stage':'running_sole_external_numerical_reader','owner_pid':pid})
        with (OUT/'reader_stdout.log').open('x',encoding='utf8') as out,(OUT/'reader_stderr.log').open('x',encoding='utf8') as err:
            result=subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(ROOT/'work/audit_OPT_full_native_affine_rankings_v2.py')],cwd=ROOT,stdout=out,stderr=err,timeout=7200)
        assert result.returncode==0,'External reader failed; no duplicate or scientific rerun'
        assert read(A/'Independent_Full_Native_Numerical_Audit.json')['all_available_identity_scope_equation_score_cost_manifest_checks_passed']
        status({'stage':'complete_external_numerical_audit','owner_pid':pid,'reader_exit_code':0})
    except BaseException:
        write(OUT/'Terminal_Handoff_Failure.json',{'traceback':traceback.format_exc(),'no_science_retry':True});status({'stage':'terminal_handoff_failure_preserved'});raise
    finally:
        if handle:kernel.CloseHandle(handle)
if __name__=='__main__':run()
