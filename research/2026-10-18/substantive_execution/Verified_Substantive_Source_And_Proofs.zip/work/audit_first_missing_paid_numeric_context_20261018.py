"""Independent complex derivative/JX=B/forecast equations; no solver calls."""
import hashlib,json,os,time
import numpy as np
from first_missing_paid_numeric_context_20261018 import R,B,read,put,sha,manifest
from dynamic_actual_mask_guidance_v1 import identity
def main():
    started=time.perf_counter();p=read(B/'Protocol.json');assert sha(__file__)==p['reader_sha256']
    for rel,h in p['pins'].items():assert sha(R/rel)==h
    out=B/'independent_audit';out.mkdir(exist_ok=False);put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    actual=B/'actual';m=read(actual/'Closed_Manifest.json')
    for rel,h in m['members'].items():assert sha(actual/rel)==h
    r=read(actual/'Result.json');ident=p['identity']
    with np.load(actual/(ident+'.npz'),allow_pickle=False) as z:c={k:z[k].copy() for k in z.files}
    assert identity(c)==ident;Y=c['Y'];V=c['V'];dv=np.diag(V);di=np.diag(Y@V);norm=np.diag(V/abs(V))
    merr=float(np.max(abs(c['m']-(dv@np.conj(Y@norm)+np.conj(di)@norm))))
    aerr=float(np.max(abs(c['a']-1j*dv@np.conj(di-Y@dv))))
    assert merr<=1e-8 and aerr<=1e-8
    nr=c['nonref'];pq=c['actual_PQ'];J=np.block([[c['a'].real[np.ix_(nr,nr)],c['m'].real[np.ix_(nr,pq)]],[c['a'].imag[np.ix_(pq,nr)],c['m'].imag[np.ix_(pq,pq)]]]);assert np.array_equal(J,c['J'])
    residual=float(np.max(abs(J@c['X']-c['B'])));assert residual<=1e-8
    rhs=np.zeros_like(c['B']);pos={int(k):j for j,k in enumerate(pq)}
    for bus,k in enumerate(c['mapping']):
        if int(k) in pos:rhs[len(nr)+pos[int(k)],bus]=abs(V[k])**2/float(c['baseMVA'])
    assert np.array_equal(rhs,c['B']);S=np.zeros((118,118));S[pq,:]=c['X'][len(nr):,:];S=S[c['mapping'],:];assert np.array_equal(S,c['sensitivity'])
    forecasts=read(actual/'All_Current_Native_Forecasts.json');before=r['before']
    for key,d in forecasts.items():
        row=d['row'];change=S[:,row['receiver']].copy()
        if row['donor_bus'] is not None:change-=S[:,row['donor_bus']]
        vm=c['current_vm']+row['q']*change
        if not np.isfinite(vm).all() or (vm<=0).any():expected={'status':'UNKNOWN_NONPHYSICAL_LINEAR_FORECAST','score':[-999]*5}
        else:
            after={'uv_count':int((vm<.95).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum()),'vmin':float(vm.min()),'vmax':float(vm.max())}
            expected={'status':'FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE','after':after,
                'score':[int(after['uv_count']==0),before['uv_count']-after['uv_count'],before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],-row['q']]}
        assert d['forecast']==expected
    previous='0'*64;events={}
    for raw in (actual/'Journal.jsonl').read_bytes().splitlines():
        d=json.loads(raw);assert d['previous_sha256']==previous;previous=hashlib.sha256(raw).hexdigest();events[d['event']]=events.get(d['event'],0)+1
    assert previous==r['journal_last_sha256'] and events['forecast_attempt']==events['forecast_return']==len(forecasts)
    assert all(events[k]==1 for k in ['public_derivative_attempt','public_derivative_return','LU_factor_attempt','LU_factor_return','LU_solve_attempt','LU_solve_return'])
    from candidate_process_evidence_utils import frozen_checks
    put(out/'Fresh_Frozen_Checks.json',frozen_checks())
    put(out/'Independent_Audit.json',{'status':'PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST',
        'identity':ident,'forecasts':len(forecasts),'m_equation_maxdelta':merr,'a_equation_maxdelta':aerr,'JXminusB_maxresidual':residual,
        'actual_numeric_costs':r['numeric_costs'],'new_nonlinear_PF_model_optimizer_controller_commit_calls':0,'reader_scientific_calls':0,
        'workflow_seconds':time.perf_counter()-started,'limits':'Ordering data only. Nonlinear successor/complete-policy/LLM superiority not measured.'})
    manifest(out);print(json.dumps({'one_missing_context_independent':'PASS','all_forecasts':len(forecasts),'newPF':0}))
if __name__=='__main__':main()
