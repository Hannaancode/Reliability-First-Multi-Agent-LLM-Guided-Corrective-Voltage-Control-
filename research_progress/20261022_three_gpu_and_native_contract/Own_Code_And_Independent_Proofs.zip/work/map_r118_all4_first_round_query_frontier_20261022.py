"""Full source-ordered first-round query map, zero new physics or outcomes.

The author fallback is invoked only to enumerate its exact actions with a
labelled unqueried verifier placeholder. No placeholder is used as a score.
"""
import copy,hashlib,json,pickle,sys,time
from collections import Counter
from pathlib import Path
from reflection118_chronological_core_20261022 import *
O=R/'outputs/r118_all4_first_round_query_frontier_20261022'
def main():
    O.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    from frozen_physics_loader import load_stack,AUDIT
    from run_reflection118_chronological_local_20261022 import History
    def forbidden(*a,**kw):raise BaseException('FRONTIER_ENUMERATION_FORBIDS_PF_MODEL')
    pp.runpp=forbidden;v2,runner,reflection=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    protocol=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json')
    for n,h in protocol['original_serving_sources'].items():assert sha(R/n)==h
    kwargs={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True}
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    assert [r['case_id'] for r in roots]==protocol['case_order']
    zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    history=History();recent=[]
    local=R/'outputs/r118chrono_20261022/local_controller'
    for root in roots:
        for arm in ['reflection_v2','no_llm_fallback_first']:
            d=local/root['case_id']/arm
            if not d.exists():continue
            for record in sorted(d.glob('pf_*.json')):
                rec=read(record)
                if rec['kwargs']==kwargs:recent.append(dict(directory=d,before=decode(d,rec['before']),after_descriptor=rec['after'],source=record.relative_to(R).as_posix(),record_sha256=sha(record)))
    bridge=R/'outputs/r118_solver_contract_bridge_execution_20261022'
    assert read(R/'outputs/r118_solver_contract_bridge_independent_20261022/Independent_Audit.json')['status'].startswith('PASS_FIRST_NEW80')
    rec=read(bridge/'Result.json');recent.append(dict(directory=bridge,before=decode(bridge,rec['before'])['net'],after_descriptor=rec['after'],source=(bridge/'Result.json').relative_to(R).as_posix(),record_sha256=sha(bridge/'Result.json')))
    declared=[];classified=[];exception=None
    try:
        for root in roots:
            net=pickle.loads((R/root['solved_payload']).read_bytes())['net']
            reports={z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
            enumerated=[];original=runner.rescue.verify_action
            def enumerate_only(n,action):
                frames_equal(n,net);enumerated.append(copy.deepcopy(action))
                return {'status':'UNQUERIED_PLACEHOLDER_FOR_ENUMERATION_ONLY','accepted':None}
            runner.rescue.verify_action=enumerate_only
            try:menu=runner.fallback_physics_candidates(net,zones,reports,[],set())
            finally:runner.rescue.verify_action=original
            assert [m['action'] for m in menu]==enumerated
            assert len({json.dumps(a,sort_keys=True) for a in enumerated})==len(enumerated)
            declared.append(dict(case_id=root['case_id'],initial_UV=int((net.res_bus.vm_pu<.95).sum()),actions=enumerated,source_root_sha256=root['payload_sha256']))
            # Save the complete menu before inspecting historical outcomes.
            put(O/(root['case_id']+'_Declared_Menu.json'),declared[-1])
            for i,action in enumerate(enumerated):
                assert time.monotonic()-start<600,'New saved-only frontier bound reached; preserve partial'
                target=copy.deepcopy(net);runner.rescue.apply_action(target,action)
                row=dict(case_id=root['case_id'],source_order=i,action=action,solver_kwargs=kwargs)
                matches=[]
                for old in recent:
                    if not target.shunt.equals(old['before'].shunt):continue
                    try:frames_equal(target,old['before'])
                    except (AssertionError,KeyError,ValueError):continue
                    matches.append(dict(source=old['source'],source_sha256=old['record_sha256'],after_descriptor=old['after_descriptor']))
                if matches:row.update(status='EXACT_CURRENT_PAID80_RETURN_REUSABLE',paid_matches=matches)
                else:
                    try:
                        found,scope=history.find(target,kwargs)
                        row.update(status='EXACT_TRACKED_PAID80_RETURN_REUSABLE' if found is not None else 'NO_MATCH_IN_NAMED_TRACKED_SCOPE_NOT_GLOBAL_ABSENCE',scope=scope)
                    except BaseException as e:row.update(status='PRIOR_INPUT_OR_CONTRACT_COLLISION_UNKNOWN_NO_AUTOMATIC_CALL',reason=str(e))
                classified.append(row)
    except BaseException as e:exception=dict(type=type(e).__name__,message=str(e))
    counts=Counter(r['status'] for r in classified)
    put(O/'All_Classifications.json',dict(declared_menus=declared,classified=classified))
    put(O/'Frontier_Summary.json',dict(status='COMPLETE_SAVED_ONLY_ALL4_FIRST_ROUND_MAP' if exception is None else 'PARTIAL_SAVED_ONLY_MAP_UNKNOWN_REMAINDER',
        case_count=len(declared),declared_queries=sum(len(r['actions']) for r in declared),classified_queries=len(classified),counts=dict(counts),exception=exception,
        exact_original_fallback_actions=True,placeholder_not_a_physics_failure_or_performance_result=True,
        new_PF_model_derivative_optimizer_calls=0,first_round_only_future_states_unknown=True,
        nonrepeat_scope='Named60426 index,9297 additional attempts,738 snapshot references and exact current chronological/native80 bridge returns; no universal historical closure.',
        no_automatic_physics_permission=True,source_sha256=sha(__file__),workflow_seconds=time.monotonic()-start))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(classified=len(classified),counts=dict(counts),exception=exception,new_scientific_calls=0)))
if __name__=='__main__':main()
