"""Persist closed diagnoses, exact live ownership and compact publication."""
import json,hashlib,zipfile
from datetime import datetime,timezone,timedelta
from pathlib import Path
from coordinate_native_inverter_linear_reference_20261020 import process
from public13_fresh_router_engine_20261022 import R,PRIMARY,P,put,sha,read
from prepare_github_research_snapshot_20261018 import SECRET,TEXT
O=R/'outputs/router_live_and_parallel_findings_20261022'
B=R/'outputs/parallel_diagnosis_publication_20261022';S=B/'snapshot'

def mutable(path,v):path.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')

def main():
    O.mkdir(exist_ok=False);S.mkdir(parents=True,exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    publication=read(R/'outputs/closed_benchmark_publication_20261022/Verified_GitHub_Receipt.json');assert publication['status'].startswith('PASS_')
    audit=read(R/'outputs/public13_radial_outer_unentered_v2_independent_20261022/Independent_Audit.json');assert audit['status'].startswith('PASS_') and audit['certified_cases']==0 and audit['unknown_cases']==4
    for stage in ['coordination','reader_coordination']:
        end=read(R/f'outputs/public13_radial_outer_unentered_v2_{stage}_20261022/End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
    diag=read(R/'outputs/public13_saved_numeric_stagnation_20261022/All500_Arithmetic_Diagnosis.json');cross=read(R/'outputs/public13_saved_numeric_stagnation_20261022/Separate_Arithmetic_Crosscheck.json');assert cross['accepted_zero_physical_changes']==diag['all_counts']['accepted_unchanged_Q']==14387
    current=read(R/'outputs/full_system_comparison_20261021/Current_Resume.json');owners={}
    for role,folder,source in [('scientist',PRIMARY,'work/run_public13_fresh_router_20261022.py'),('coordinator',R/'outputs/public13_fresh_router_handoff_20261022','work/coordinate_public13_fresh_router_20261022.py')]:
        claim=read(folder/'owner.claim');actual=process(claim['actual_pid']);parent=process(claim['parent_pid'])
        assert actual and parent and actual['ParentProcessId']==claim['parent_pid'] and Path(source).name in actual['CommandLine'] and claim['source_sha256']==sha(R/source)
        owners[role]=dict(claim=claim,actual_process=actual,parent_process=parent,source=source)
    closed_case_files=len(list((PRIMARY/'cases').glob('seed*/World_Result.json')))
    result=dict(at_utc=now,status='FRESH128_ACTUAL_PRIMARY_LIVE_PARALLEL_DIAGNOSES_CLOSED',owners=owners,exec_session=8529,protocol_sha256=sha(P/'Protocol.json'),fixed_science_seconds=7200,fixed_first_reader_seconds=7200,
        observed_case_files_PROGRESS_ONLY_NOT_VERIFIED_COMPLETION=closed_case_files,current_GPU=None,all6finalgoals='OPEN',
        saved_NUM_diagnosis=dict(all500_complete_source=True,accepted_zero_action_no_physical_change_decisions=14387,near_boundary_100round_failures=151,strict_failure_not_reclassified=True,nonzero_actions_lost_in_Q_accumulation=0,new_scientific_calls=0),
        all4_adverse_feasibility_diagnostic=dict(seeds=[167,236,238,418],actual_new_phase1_LP_attempts=4,actual_new_phase1_LP_returns=4,new_model_PF_derivative_LU_training_calls=0,independent_exact_certificate_checker='PASS',certified_infeasible=0,UNKNOWN=4,no_feasibility_or_impossibility_claim=True,
            original_import_preparation_failure_preserved=True,original_nonatomic_claim_launcher_failure_preserved=True,original_owner_OSexit_UNRECOVERED=True,all4_LP_identities_were_unentered_before_distinct_atomic_launch=True),
        last_verified_GitHub=publication['head'],last_publication_all7_downloaded_bytes=True,new_parallel_diagnosis_publication='PENDING',
        next=['Current sole scientist and coordinator own the new128 stream; never duplicate/restart/source-edit/extend. First reader is exclusively coordinator-owned after realend/exit0/closedmanifest.',
              'All128complete independent source/physical/policy/state/cost gates are required for the frozen comparison; partial remainsUNKNOWN. Do not treat current file counts as completion.',
              'All four adverse feasibility checks are UNKNOWN. Do not retune cuts/solver/Q/band to obtain an impossibility or favorable feasibility result.',
              'Old numerical policy has14,387savedzero-action decisions; old failed primary gate remainsFAILED. No change to its math/guard/rounding/stopping while current study islive.',
              'Original privateLLM0/6newnativeinterface and disabledbase0/6 remain stopped; neither replaces original137paperperformance. No newGPU/training campaign ready.',
              'Finish compact diagnosis publication with lease/bytechecks. If no useful parallel work remains, schedule ONE estimated result check and rearm only for confirmed actual live ownership; delete at terminal. No recurring monitor.'])
    put(O/'Exact_Resume.json',result)
    cp=R/'outputs/full_system_comparison_20261021/Current_Resume.json';current.update(at_utc=now,status=result['status'],latest_resume=(O/'Exact_Resume.json').relative_to(R).as_posix(),current_single_scientific_owner=owners['scientist'],current_sole_coordinator=owners['coordinator'],next_ordered_tasks=result['next'],last_verified_GitHub=publication['head'],latest_closed_parallel_findings=result['all4_adverse_feasibility_diagnostic']);mutable(cp,current)
    tp=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(tp);tasks.update(updated_at_utc=now,latest_resume=cp.relative_to(R).as_posix(),last_verified_GitHub=publication['head'])
    g1=next(v for v in tasks['tasks'] if v['checklist_id']=='G1');g1['subtasks'].append(dict(id='G1.outer4_20261022',completed=True,description='Measure all4unrestoreddevelopment roots with one fixed necessary radial outer LP each and independent exactrationalcertificate checker;0certificates/all4UNKNOWN, no newPF/model.',evidence='outputs/public13_radial_outer_unentered_v2_independent_20261022/Independent_Audit.json',verified_at_save=now))
    g3=next(v for v in tasks['tasks'] if v['checklist_id']=='G3');g3.update(status=result['status'],next=result['next'][0],current_result='Same500NUMgateFAIL; nativeLLMfunctional0/6FAIL. New128actualsix-arm study live; all4adversefeasibilityUNKNOWN. All500closedtrace diagnosis identifies14,387acceptedzero-change decisions; no scores changed.')
    g3['subtasks'].append(dict(id='G3.stagnation500_20261022',completed=True,description='All500savedaction/arithmetic diagnosis plus separate-expression crosscheck:14,387acceptedzero-action/no-physical-change decisions;151near-boundary100round failures remainfailures.',evidence='outputs/public13_saved_numeric_stagnation_20261022/Separate_Arithmetic_Crosscheck.json',verified_at_save=now));mutable(tp,tasks)
    ep=R/'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json';state=read(ep);state.update(updated_at_utc=now,status=result['status'],latest_resume=cp.relative_to(R).as_posix(),last_verified_GitHub=publication['head']);mutable(ep,state)
    header=f'''## Fresh128 live; adverse feasibility remainsUNKNOWN; numerical stagnation identified — {now}

Sole newCPUscientist8288/1232 and coordinator21020/17208 remain fresh exactcommand/source/claimverified; exec8529, fixed7200seconds eachscience/firstreader, immutable sources/settings/8GiB. Observed {closed_case_files}case files are PROGRESSONLY. Coordinator exclusively owns firstreader and locked full128comparison afteractualend. NoGPU/modeltraining or currentwaiting timer.

All500savednumericaltrace diagnosis/crosscheck found14,387acceptedzero-action/no-physical-change decisions and151near-boundary100round failures; all remainfailures, no rounding/stopping rescue. Separate all4adverse necessary-condition diagnostic completed4newLP/0PF/0model and independent exactrationalcheckerPASS:0infeasibilitycertificates/all4UNKNOWN, not feasible or impossible. Old missing-import preparation and original launch-claim JSONrace failed BEFORE anyLP; old claims/source/stderr/OSexitUNKNOWN retained. Distinct unentered-first-LP atomiclaunch had unchangedequation/source/certificateASTs; allitsactorsendedexit0. Neverrepeatthese measurements or tune cuts.

GitHub {publication['head']} passed all7downloadedexactbytes; compact92member771045byte closedbenchmark/model/source/newrouter package published, not a privateweights/NET/rawbackup. Latestexactresume outputs/router_live_and_parallel_findings_20261022/Exact_Resume.json. Newdiagnosispublication pending. All six final goals OPEN; original137paper/frozenassets/literalDSE/FULLBOTH and every adverse/partial/UNKNOWN record staypreserved.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        q=R/rel;q.write_bytes(header.encode('utf-8')+q.read_bytes())
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+header)
    report='''# Parallel closed diagnoses and actual continuation

The fresh128 six-arm routing study is running onCPU with a sole scientist/coordinator and one pinned first reader. Current progress is not performance. No GPU is owned. Previous fixed NUM500 and nativeLLM functional gates remainfailed.

All500 saved NUM traces contain14,387accepted exactlyzero actions with unchanged Q and all13VM. There are151near-boundary failures ending at100rounds;81otherUV-only failures and4OV-only failures remain. No nonzero action was lost byfloat64 Qaccumulation in these traces. This identifies zero-action stagnation; it does not demonstrate a successful repair or LLM role. No original threshold/objective/Q/stopping setting was changed.

A separately prospective failure diagnostic on ALL4roots167/236/238/418 used one phase1necessary radial branch-flow outerLP each. Fixed9x9tangent cuts andexactrationalseparation were frozen before outcomes. Independent coefficient/box/certificate reconstruction PASS, but all4gaps are0: no infeasibility certificate. Feasibility remainsUNKNOWN, and full500denominators are unchanged. No nonlinearPF/model/derivative/LU/training call. Original import/launch failures occurred before anyLP, werepreserved, and the distinct unentered-first-LP run used atomic ownership ACK with identical mathematical ASTs. No scientific attempt repeated.

All six final goals OPEN. No universal impossibility, fullAC/security, novelty, unseen generalization, calibratedwinningconfidence or LLM superiority follows. Only actual full128 independent terminal evidence can assess the current routing test. Exact resume, failed claims and fullcosts are saved.
'''
    (S/'README.md').write_text(report,encoding='utf-8');(S/'Results_And_Next_Execution.md').write_text(header+report,encoding='utf-8')
    (S/'Closed_Diagnoses_And_Live_Resume.json').write_bytes((O/'Exact_Resume.json').read_bytes());(S/'Current_Resume.json').write_bytes(cp.read_bytes());(S/'Task_Progress.json').write_bytes(tp.read_bytes())
    code=['public13_radial_outer_certificate_20261022.py','run_public13_radial_outer_20261022.py','audit_public13_radial_outer_20261022.py','coordinate_public13_radial_outer_20261022.py','prepare_public13_radial_outer_20261022.py','coordinate_atomic_source_owner_20261022.py','prepare_unentered_radial_outer_sources_v2_20261022.py','unentered_public13_radial_outer_v2_20261022.py','run_unentered_public13_radial_outer_v2_20261022.py','audit_unentered_public13_radial_outer_v2_20261022.py','coordinate_unentered_public13_radial_outer_v2_20261022.py','prepare_unentered_public13_radial_outer_v2_20261022.py','analyze_closed_numeric_stagnation_20261022.py','save_router_parallel_findings_20261022.py']
    files=[R/'work'/x for x in code]
    for folder in ['public13_radial_outer_preparation_20261022','public13_radial_outer_preparation_v2_20261022','public13_radial_outer_preparation_v3_20261022','public13_radial_outer_unentered_v2_execution_20261022','public13_radial_outer_unentered_v2_independent_20261022','public13_saved_numeric_stagnation_20261022','router_live_and_parallel_findings_20261022']:
        files += [q for q in (R/'outputs'/folder).iterdir() if q.is_file() and q.suffix in {'.json','.py'}]
    for rel in ['outputs/public13_radial_outer_handoff_20261022/Primary.log','outputs/public13_radial_outer_coordination_20261022/Owner.log','outputs/public13_radial_outer_execution_20261022/owner.claim']:
        files.append(R/rel)
    manifest={}
    for q in sorted(set(files)):
        raw=q.read_bytes()
        if q.suffix in TEXT:assert not any(rule.search(raw.decode('utf-8')) for rule in SECRET)
        manifest[q.relative_to(R).as_posix()]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    pack=S/'Own_Code_And_Results.zip'
    with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in manifest:z.write(R/name,name)
        z.writestr('EXACT_MEMBER_HASHES.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(pack) as z:
        assert z.testzip() is None
        for name,v in manifest.items():raw=z.read(name);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
    put(S/'Evidence_Manifest.json',dict(members=len(manifest)+1,archive_bytes=pack.stat().st_size,archive_sha256=sha(pack),all_CRC_member_hashes_PASS=True,private_weights_NET_checkpoints_thirdparty_source_excluded=True,new_scientific_calls_by_packaging=0))
    put(B/'Local_Upload_Files.json',dict(repository='Hannaancode/Reliability-First-Multi-Agent-LLM-Guided-Corrective-Voltage-Control-',branch='research-progress-20261018',previous_head=publication['head'],previous_tree=publication['tree'],files=[dict(local=q.relative_to(R).as_posix(),path='research/20261022_failure_diagnosis/'+q.name,bytes=q.stat().st_size,sha256=sha(q)) for q in sorted(S.iterdir())]))
    print(json.dumps(dict(saved=True,main_primary_live=True,observed_case_files_PROGRESS_ONLY=closed_case_files,all4_outer_UNKNOWN=True,accepted_no_change=14387,package_bytes=pack.stat().st_size)))

if __name__=='__main__':main()
