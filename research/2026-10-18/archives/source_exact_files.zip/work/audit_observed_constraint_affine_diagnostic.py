"""Independent saved-equation/source reader; zero PF/model/linear solves."""
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
import gzip,json,time,zipfile,hashlib,os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[_key]='1'
import numpy as np
from candidate_process_evidence_utils import ROOT,read,sha,write,seal,frozen_checks
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';S=P/'observed_constraint_affine_diagnostic'
OUT=P/'observed_constraint_affine_external_audit';assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
write(OUT/'owner.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__))})
assert read(S/'status.json')['stage']=='complete_fixed_OPT_oracle_diagnostic'
ep=read(S/'Execution_Protocol.json');proto=read(P/'observed_constraint_affine_preparation/Protocol.json')
assert sha(Path(__file__))==ep['external_reader_source_sha256']
assert sha(ROOT/'work/run_observed_constraint_affine_diagnostic.py')==ep['science_source_sha256']
assert sha(ROOT/'work/observed_constraint_affine_operator.py')==ep['operator_source_sha256']
assert sha(P/'observed_constraint_affine_preparation/Protocol.json')==ep['prospective_protocol_sha256']
manifest=read(S/'Supplement_Manifest.json')
source_paths={'source/science.py':ROOT/'work/run_observed_constraint_affine_diagnostic.py',
              'source/operator.py':ROOT/'work/observed_constraint_affine_operator.py',
              'source/locked_external_reader.py':Path(__file__)}
for name,d in manifest.items():
    path=source_paths.get(name,S/name)
    assert path.stat().st_size==d['bytes'] and sha(path)==d['sha256']
with zipfile.ZipFile(S/'Measured_OPT_Affine_Constraint_Oracle_Diagnostic.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
    for name,d in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==d['sha256']
def rows(path):
    with gzip.open(path,'rt',encoding='utf8') as f:return [json.loads(l) for l in f]
ts={r['transition_id']:r for r in rows(P/'measured_OPT_transition_inventory/Actual_OPT_Transition_Rows.jsonl.gz')}
labs={r['transition_id']:r for r in read(P/'OPT_generator_bound_event_inventory/Actual_Generator_Bound_Records.json')}
old={r['transition_id']:r for r in rows(P/'OPT_transition_AC_vector_measurement/Actual_Transition_Vector_Records.jsonl.gz')}
actual=read(S/'Actual_Transition_Arm_Records.json');summary=read(S/'Summary.json')
assert len(actual)==len({r['transition_id'] for r in actual})==216 and set(ts)=={r['transition_id'] for r in actual}
assert set(ts)==set(proto['all_transition_ids'])
def frame(f):return {i:dict(zip(f['columns'],r)) for i,r in zip(f['index'],f['values'])}
checks=0;equations=0;derivatives=0;world=defaultdict(lambda:defaultdict(list));upper=Counter();maxeq=0.;maxproof=0.
for r in actual:
    tid=r['transition_id'];t=ts[tid];h=t['before_observation_sha256'];obs=t['model_input']['current_physical_observation']
    assert r['before_sha256']==h and r['action']==t['model_input']['candidate_action'] and r['provenance']==t['audit']['source_provenance']
    assert r['teacher_successor_protected']==t['audit']['after_normal_upper']
    state=np.load(S/'states'/(h+'.npz'));arr=np.load(S/'equations'/(tid+'.npz'))
    assert sha(S/'equations'/(tid+'.npz'))==r['array_sha256']
    Y=state['Y'];V=state['V'];mapping=state['mapping'];refs=state['refs'];base=float(state['baseMVA'])
    tables=obs['physical_tables'];bus=frame(tables['res_bus']);gen=frame(tables['gen']);gres=frame(tables['res_gen'])
    current=np.array([bus[i]['vm_pu']*np.exp(1j*np.deg2rad(bus[i]['va_degree'])) for i in range(118)])
    assert np.max(np.abs(V[mapping]-current))<=1e-14
    targettab=frame(t['measured_target']['next_res_bus']);target=np.array([targettab[b]['vm_pu'] for b in range(118)])
    assert np.array_equal(arr['A_vm'],np.array(old[tid]['analytic_next_vm']))
    newY=Y.copy();a=t['model_input']['candidate_action'];k=mapping[a['bus']];newY[k,k]+=1j*a['q_abs_mvar']/base
    labelmaps={s:{m['native_gen_id']:m[s+'_nominal_occupancy'] for m in labs[tid]['generator_measurements']} for s in ('before','after')}
    for arm in ('A','B','C','D'):
        predicted=arr[arm+'_vm'];assert predicted.shape==(118,) and np.isfinite(predicted).all()
        if arm!='A':
            modelY=Y if arm=='C' else newY
            I=modelY@V;vn=V/np.abs(V)
            # Independent dense derivation, not the production dSbus_dV helper.
            m=np.diag(V)@np.conj(modelY@np.diag(vn))+np.diag(np.conj(I))@np.diag(vn)
            an=1j*np.diag(V)@np.conj(np.diag(I)-modelY@np.diag(V));derivatives+=1
            fixed={int(i):0. for i in refs};rhs=V*np.conj(Y@V)-V*np.conj(newY@V)
            chosen=labelmaps['before' if arm=='B' else 'after']
            for gid,g in gen.items():
                pos=mapping[g['bus']];label=chosen[gid]
                if label=='interior':fixed[pos]=g['vm_pu']-abs(V[pos])
                else:rhs[pos]+=1j*(g['min_q_mvar' if label=='near_min' else 'max_q_mvar']-gres[gid]['q_mvar'])/base
            nonref=np.array([i for i in range(118) if i not in refs]);free=np.array([i for i in range(118) if i not in fixed])
            known=np.array(sorted(fixed));kd=np.array([fixed[i] for i in known])
            J=np.block([[an.real[np.ix_(nonref,nonref)],m.real[np.ix_(nonref,free)]],
                        [an.imag[np.ix_(free,nonref)],m.imag[np.ix_(free,free)]]])
            b=np.r_[rhs.real[nonref]-m.real[np.ix_(nonref,known)]@kd,rhs.imag[free]-m.imag[np.ix_(free,known)]@kd]
            err=max(float(np.max(np.abs(J-arr[arm+'_J']))),float(np.max(np.abs(b-arr[arm+'_rhs']))))
            maxproof=max(maxproof,err);assert err<=1e-10
            for name,value in [('nonref',nonref),('free',free),('known',known)]:assert np.array_equal(value,arr[arm+'_'+name])
            assert np.max(np.abs(kd-arr[arm+'_known_delta']))<=1e-14
            x=arr[arm+'_solution'];res=float(np.max(np.abs(J@x-b)));maxeq=max(maxeq,res);assert res<=1e-8
            dv=np.zeros(118);dv[known]=kd;dv[free]=x[len(nonref):]
            assert np.max(np.abs(predicted-(np.abs(V)+dv)[mapping]))<=1e-14;equations+=1
        measured=float(np.mean((predicted-target)**2));over=bool(predicted.max()>1.05+1e-8)
        record=r['arms'][arm];assert abs(record['MSE']-measured)<=1e-16 and record['upper_forecast']==over
        assert abs(record['max_abs_error']-float(np.max(np.abs(predicted-target))))<=1e-14
        world[arm][r['provenance'][0]['world_sha256']].append(measured);upper[arm]+=int(over);checks+=118
rates={arm:{w:float(np.mean(v)) for w,v in groups.items()} for arm,groups in world.items()}
means={a:float(np.mean(list(v.values()))) for a,v in rates.items()}
for a in rates:
    assert rates[a]==summary['world_MSE'][a] and abs(means[a]-summary['arms'][a]['equal_world_MSE'])<=1e-16
    assert upper[a]==summary['arms'][a]['upper_forecasts'] and summary['arms'][a]['finite_forecasts']==216
reduction=1-means['D']/means['B'];better=sum(rates['D'][w]<rates['B'][w] for w in rates['B']);gate=proto['design_support_gate']
g={'all216_finite':True,'MSE_headroom':reduction>=gate['equal_world_MSE_reduction_D_vs_B_at_least'],
 'upper_forecast_headroom':upper['B']-upper['D']>=gate['predicted_upper_forecasts_reduction_at_least'],
 'at_least_two_worlds':better>=gate['strict_MSE_improved_OPT_worlds_at_least']}
assert g==summary['design_gates'] and all(g.values())==summary['design_support_passed']
journal=[json.loads(l) for l in (S/'Actual_Attempt_Return_Journal.jsonl').read_text().splitlines()]
c=Counter(r['event'] for r in journal);cost=summary['actual_costs']
assert c['state_attempt']==c['state_return']==193 and c['arm_attempt']==c['arm_return']==648
assert cost['conversions_attempts']==cost['conversions_returns']==386
assert cost['derivative_attempts']==cost['derivative_returns']==cost['solve_attempts']==cost['solve_returns']==648
assert cost['arm_exceptions']==cost['state_exceptions']==cost['new_PF_model_optimizer_controller_cloud_calls']==0
result={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_identity_source_equation_cost_manifest_gates_passed':True,
 'exact_transition_identities':216,'OPT_worlds':23,'independent_equation_reconstructions':equations,'independent_dense_derivative_evaluations':derivatives,
 'forecast_scalar_checks':checks,'maximum_equation_residual':maxeq,'maximum_source_derivative_system_difference':maxproof,
 'all_arm_equalworld_MSE':means,'all_arm_upper_forecasts':dict(upper),'primary_D_vs_B_MSE_reduction':reduction,
 'strict_improved_OPT_worlds':better,'design_gates':g,'design_support_passed':all(g.values()),'actual_new_science_costs':cost,
 'new_linear_solves_PF_model_optimizer_cloud_calls_by_reader':0,'reader_seconds':time.perf_counter()-start,
 'teacher_oracle_not_inference_LLM_or_DSE_superiority':True,'held_targets_read':0}
write(OUT/'Independent_Actual_Constraint_Oracle_Audit.json',result);write(OUT/'Frozen_Preservation.json',frozen_checks())
text='The prospectively fixed OPT constraint-oracle diagnostic completed and its identity/equation/cost audit passed.\n\n'
text+=f"Measured equal-world MSE A/B/C/D: {means}. Upper forecasts: {dict(upper)}. D-versus-B reduction {reduction:.6%}; {better}/23 worlds improved. Fixed design gates: {g}.\n\n"
text+='AFTER occupancy is teacher information. This is not deployable inference, learned performance, native PF convergence, an unused holdout or D-SE superiority. All earlier stopped branches remain stopped.\n'
(OUT/'Results.md').write_text(text,encoding='utf8')
files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'};files['source/reader.py']=Path(__file__)
archive=seal(OUT,files,'Independently_Verified_OPT_Constraint_Oracle_Diagnostic.zip')
print(json.dumps({'audit':result,'archive':archive}))
