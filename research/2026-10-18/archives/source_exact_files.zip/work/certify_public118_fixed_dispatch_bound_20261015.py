"""Necessary active-power bound for RAW fixed-nonslack public PF, not OPF.

An all-case source diagnosis after import/input inspection. Positive deficits
cannot certify general grid infeasibility or defeat a dispatch-capable method.
"""
import hashlib,json,os,time
from decimal import Decimal
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from intake_public_118_testbeds_20261014 import matrix
R=Path(__file__).resolve().parents[1];B=R/'outputs/public118_raw_fixed_dispatch_bound_20261015'
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    B.mkdir(exist_ok=False);start=time.perf_counter();intake=json.loads((R/'outputs/public_testbed_intake_20261014/Public_Data_Intake_Result.json').read_text())
    put(B/'Scope_And_Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'all3_declared_pinned_files':[r['path'] for r in intake['records']],
        'role':'Post-import diagnosis of previously inspected RAW initial guesses, before any public PF/model/OPF performance.',
        'necessary_condition':'For constant specified nonslack Pg, fixed net active demand, nonnegative active shunt conductances and branch resistance, total generation cannot be less than demand. Replacing ALL reference-bus Pg by their sumPmax gives an optimistic maximum. If even that is below demand, respecting every generatorPmax is impossible in this fixed-dispatch PF role.',
        'limitations':'Unknown when assumptions fail. Does not certify native ACOPF infeasibility, achievable voltages, thermal feasibility or any learned-controller outcome. Dispatch-capable optimization can change nonslack Pg and is outside this bound.',
        'source_sha256':sha(Path(__file__)),'new_PF_OPF_model_converter_derivative_forecast_solve_calls':0})
    records=[]
    for r in intake['records']:
        path=R/r['path'];assert sha(path)==r['sha256'];text=path.read_text('utf-8-sig')
        bus=np.asarray(matrix(text,'bus'));gen=np.asarray(matrix(text,'gen'));branch=np.asarray(matrix(text,'branch'))
        reference=set(int(b) for b in bus[bus[:,1]==3,0]);live=gen[gen[:,7]>0];lines=branch[branch[:,10]>0]
        slack=np.array([int(row[0]) in reference for row in live]);assumptions={
            'exactly_one_published_reference_bus':len(reference)==1,'online_generation_at_reference':bool(slack.any()),
            'all_bus_active_shunt_Gs_nonnegative':bool((bus[:,4]>=0).all()),
            'all_online_branch_series_resistances_nonnegative':bool((lines[:,2]>=0).all()),
            'all_source_numeric_values_finite':bool(np.isfinite(bus).all() and np.isfinite(gen).all() and np.isfinite(branch).all())}
        demand=sum(Decimal(str(v)) for v in bus[:,2]);fixed=sum(Decimal(str(v)) for v in live[~slack,1]);maxslack=sum(Decimal(str(v)) for v in live[slack,8])
        optimistic=fixed+maxslack;shortfall=demand-optimistic
        tolerance=Decimal('0.000001')
        blocked=all(assumptions.values()) and shortfall>tolerance
        records.append({'case':r['path'],'raw_sha256':r['sha256'],'assumptions':assumptions,'reference_bus_ids':sorted(reference),
            'raw_net_demand_MW':str(demand),'fixed_online_nonslack_Pg_MW':str(fixed),
            'maximum_online_reference_Pg_MW':str(maxslack),'optimistic_total_generation_MW':str(optimistic),
            'shortfall_even_before_nonnegative_losses_MW':str(shortfall),'numeric_margin_allowance_MW':str(tolerance),
            'fixed_raw_PF_all_gen_Pmax_compliance':'ANALYTICALLY_EXCLUDED_UNDER_STATED_ROLE' if blocked else 'UNKNOWN_NOT_PHYSICALLY_CERTIFIED',
            'general_ACOPF_or_controller_feasibility':'UNKNOWN_NOT_TESTED'})
    put(B/'Necessary_Condition_Certificate.json',{'status':'COMPLETE_ALL3_SCOPED_ACTIVE_POWER_NECESSARY_CONDITIONS',
        'all3':records,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-start,
        'next':'Freeze and independently verify a common feasible generation-dispatch initialization before public controller benchmarking; do not use a raw slack-overload starting point as model failure or success.',
        'not_a_novelty_or_LLM_superiority_claim':True})
    put(B/'Closed_Manifest.json',{'exit_code':0,'members':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()}})
    print(json.dumps({'all3_fixed_raw_dispatch_bound_closed':True,'excluded_raw_PF_roles':sum(r['fixed_raw_PF_all_gen_Pmax_compliance'].startswith('ANALYTICALLY') for r in records),'new_PF_model_calls':0}))
if __name__=='__main__':main()
