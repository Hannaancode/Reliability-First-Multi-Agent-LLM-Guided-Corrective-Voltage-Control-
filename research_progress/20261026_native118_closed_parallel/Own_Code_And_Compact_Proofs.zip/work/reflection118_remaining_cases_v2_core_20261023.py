"""Future original-model cases with closed partition receipts and paid identity reuse.

Separate source/output namespace; never changes the running DFF study.
"""
from reflection118_remaining_cases_core_20261023 import *
from reflection118_remaining_cases_core_20261023 import run_original as prior_run_original
from reflection118_remaining_cases_core_20261023 import ClosedPaidRegistry as IndexedRegistry
from r118_dff_partition_core_20261023 import Registry as IdentityRegistry
from provider_observer_pause_20261023 import without_nested_observer

TOP=R/'outputs/reflection118_remaining_cases_v2_preparation_20261023'
PARTITION=R/'outputs/r118_dff_partition_continuation_execution_20261023'
PARTITION_AUDIT=R/'outputs/r118_dff_partition_continuation_independent_20261023'

def case_paths():
    ap=argparse.ArgumentParser();ap.add_argument('--case-index',type=int,choices=[1,2,3],required=True)
    index=ap.parse_args().case_index;name=f'case_{index:02d}'
    return index,TOP/name,R/'outputs/reflection118_remaining_cases_v2_execution_20261023'/name

def require_partition_closed():
    from coordinate_native_inverter_linear_reference_20261020 import process
    handoff=R/'outputs/r118_dff_partition_continuation_handoff_20261023'
    completed=read(handoff/'Completion.json')
    assert completed['independent_audit_status']=='PASS_ALL4_COMPLETE_NATIVE_DFF_SOURCE_PHYSICS_COST'
    for name in ['r118_dff_partition_continuation_coordination_20261023','r118_dff_partition_continuation_reader_coordination_20261023']:
        end=read(R/'outputs'/name/'End_ACK.json')
        assert end['exit_code']==0 and end['actual_owned_chain_ended']
        assert process(end['actual_pid']) is None and process(end['launcher_pid']) is None
    claim=read(handoff/'owner.claim')
    assert process(claim['actual_pid']) is None and process(claim['parent_pid']) is None
    assert read(PARTITION/'Result.json')['all4_complete']
    assert read(PARTITION_AUDIT/'Independent_Audit.json')['all4_complete']
    return completed

class ClosedPaidRegistry(IdentityRegistry):
    def __init__(self,index_path,proof_directory):
        # The old index loader checks relevant saved capsules on lookup. The
        # separately audited append-only index avoids re-decoding old history.
        IndexedRegistry.__init__(self,index_path)
        self.proof_directory=proof_directory
        self.preparation_costs=dict(native_input_attempts=0,native_input_returns=0,
            source_result_extractions=0,native_algorithm_invocations=0,
            identity_receipts=0,proof_bytes=0,seconds=0.)

def run_original(v2,runner,reflection,scenario,base,zones,model,physics,first_callback=None,commit_callback=None):
    return prior_run_original(v2,runner,reflection,scenario,base,zones,
        without_nested_observer(model),without_nested_observer(physics),first_callback,commit_callback)
