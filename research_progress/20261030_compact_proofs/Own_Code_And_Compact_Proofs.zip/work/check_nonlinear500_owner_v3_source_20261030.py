"""New v3 source/pure admission checks only; no public helper or scientific entry."""
from pathlib import Path
import ast,copy,hashlib,json,sys,tokenize
R=Path(__file__).resolve().parents[1]
O=R/'outputs/nonlinear500_receding_acquisition_v3_source_preparation_20261030'
sys.path.insert(0,str(R/'work'))
import nonlinear500_isolated_owner_runtime_v3_20261030 as gate
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return dict(path=p.relative_to(R).as_posix(),sha256=sha(p),bytes=p.stat().st_size)
def tree(p):
 with tokenize.open(p) as f:return ast.parse(f.read())
def dump(t):return ast.dump(t,include_attributes=False)
class Paths(ast.NodeTransformer):
 def visit_Constant(self,node):
  if isinstance(node.value,str):node.value=node.value.replace('nonlinear500_receding_acquisition_v3_','nonlinear500_receding_acquisition_v2_').replace('nonlinear500_isolated_owner_runtime_v3_20261030','nonlinear500_isolated_owner_runtime_20261030')
  return node
 def visit_ImportFrom(self,node):
  if node.module=='nonlinear500_isolated_owner_runtime_v3_20261030':node.module='nonlinear500_isolated_owner_runtime_20261030'
  return self.generic_visit(node)
def main():
 previous=dict(failed_protocol=ref(R/gate.V2_PROTOCOL),independent_failure_diagnosis=ref(R/'outputs/nonlinear500_v2_setup_access_failure_20261030/Independent_Diagnosis.json'),
  fresh_terminal_absence=ref(R/'outputs/nonlinear500_v2_setup_access_failure_20261030/Fresh_Terminal_Source_Absence.json'),old_study_never_restarted=True,original_authenticated_chain_end='UNKNOWN_RETAINED_UNCHANGED')
 old=gate.validate_v2_preentry_failure(R,previous)
 certref=ref(R/'outputs/nonlinear500_actual_host_runtime_admission_v2_20261030/Result.json')
 cert=json.loads((R/certref['path']).read_text(encoding='utf-8'))
 host=dict(certificate=certref,admission_source=cert['admission_source'],expected_username=cert['actual_process']['username'])
 sources=dict(old['sources']);sources[host['admission_source']['path']]=host['admission_source']['sha256']
 gate.validate_actual_host_admission(R,host,sources,old)
 checks=['actual_saved_v2_zero_entry_failure_and_separate_absence_accept','actual_saved_HOME_capability_and_all70_source_population_accept']
 bad=copy.deepcopy(host);bad['expected_username']='WRONG_HOST\\HOME'
 try:gate.validate_actual_host_admission(R,bad,sources,old)
 except ValueError:checks.append('wrong_HOST_principal_rejected_without_runtime_import')
 else:raise AssertionError('Wrong HOST identity admitted')
 bad=copy.deepcopy(host);bad['certificate']=ref(R/'outputs/nonlinear500_actual_host_runtime_admission_20261030/Result.json')
 try:gate.validate_actual_host_admission(R,bad,sources,old)
 except ValueError:checks.append('earlier_failed_HOST_capability_cannot_admit')
 else:raise AssertionError('Failed HOST evidence admitted')
 rows=[]
 for rel,digest in old['sources'].items():
  path=R/rel;assert sha(path)==digest,rel
  if path.suffix=='.py':rows.append(dict(path=rel,sha256=digest,ast_sha256=hashlib.sha256(dump(tree(path)).encode()).hexdigest(),source_bytes_equal_frozen_v2=True))
 checks.append('all70_v2_source_pins_unchanged_and_all_python_AST_hashes_recorded')
 for stem in ('run','audit','coordinate'):
  before=tree(R/f'work/{stem}_nonlinear500_receding_acquisition_v2_20261030.py')
  after=Paths().visit(tree(R/f'work/{stem}_nonlinear500_receding_acquisition_v3_20261030.py'))
  assert dump(before)==dump(after),stem
 checks.append('owner_reader_coordinator_AST_identical_except_v3_paths_and_helper_import_name')
 def settings(t):
  assignments=[n for n in ast.walk(t) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='p' and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict']
  assert len(assignments)==1
  return {k.arg:dump(k.value) for k in assignments[0].value.keywords}
 before=settings(tree(R/'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py'))
 after=settings(Paths().visit(tree(R/'work/freeze_nonlinear500_receding_acquisition_v3_20261030.py')))
 assert set(after)-set(before)=={'previous_v2_failed_setup','actual_host_execution_admission','postfreeze_launch_gate'}
 assert all(after[k]==v for k,v in before.items() if k!='prospective_difference')
 checks.append('all_original_scientific_resource_reuse_protocol_settings_AST_identical')
 newpaths=[f'work/{stem}_nonlinear500_receding_acquisition_v3_20261030.py' for stem in ('run','audit','coordinate','freeze')]+[gate.SOURCE_FILE]
 for rel in newpaths:tree(R/rel)
 assert not (R/'outputs/nonlinear500_receding_acquisition_v3_preparation_20261030').exists()
 assert not (R/'outputs/nonlinear500_receding_acquisition_v3_execution_20261030').exists()
 report=dict(status='PASS_NEW_V3_SOURCE_AND_PURE_HOST_BINDING_CHECKS_NO_SCIENCE',checks=checks,
  proposed_sources={rel:sha(R/rel) for rel in newpaths},previous_v2_failed_setup=previous,actual_host_execution_admission=host,
  original_v2_source_count=len(old['sources']),unchanged_python_sources=rows,
  public_runtime_helper_calls=0,psutil_or_scientific_imports=0,owner_launches=0,freeze_calls=0,scientific_calls=0,
  old_NET_NPZ_decodes_and_calculation_fixture_replays=0,
  byte_read_scope='Source custody hashing includes original source-pinned seed0 NPZ bytes; no NPZ decoding, binding, equation or completed fixture replay.',
  remaining_order=['Independent v3 source review','Parent prospective freeze once using retained HOST capability PASS','Parent actual v3 full-helper/all-source preflight under HOME against frozen protocol','Independent frozen protocol/final launch gate','Separate parent first-entry decision'])
 with (O/'Source_And_Host_Binding_Check.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps(dict(status=report['status'],checks=len(checks),unchanged_python_sources=len(rows))))
if __name__=='__main__':main()
