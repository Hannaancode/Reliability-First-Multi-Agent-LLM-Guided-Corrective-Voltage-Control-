"""Saved-only DFF actor-selection history recovery; no scientific runtime imports.

The selected actor action is the post-search `best` applied to the persistent
network. Verifier candidates, cached physical results and preparation calls are
separate evidence-query events. This script never executes controller functions,
unpickles networks, reconstructs candidate outcomes, or imports numerical code.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import ast, hashlib, json, re

R=Path(__file__).resolve().parents[1]
O=R/'outputs/common118_history_recovery_20261029'
E=R/'outputs/r118_dff_partition_continuation_execution_20261023'
VIEW=R/'outputs/common118_masked_contract_20261029/actual_state_check/All_Saved_Views_LOCAL_ONLY.json'
PROTOCOL=R/'outputs/r118_dff_partition_continuation_preparation_20261023/Protocol.json'
REFLECTION=R/'work/e/audit/run_reflection_v4_safety_envelope.py'
RUNNER=R/'work/e/audit/phase2g_llm_guided_rescue_runner.py'
RESCUE=R/'work/e/audit/phase2g_rescue_runner.py'
CORE=R/'work/r118_dff_missing_continuation_core_20261023.py'
EXEC=R/'work/run_r118_dff_partition_continuation_20261023.py'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def rel(p):return p.relative_to(R).as_posix()
def put(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def binding(p):return {'path':rel(p),'sha256':sha(p)}
def fn(path,name):
    text=path.read_text(encoding='utf-8');node=next(n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    return node,{'path':rel(path),'file_sha256':sha(path),'function':name,'start_line':node.lineno,'end_line':node.end_lineno,'ast_sha256':hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()},text.splitlines()[node.lineno-1:node.end_lineno]

def main():
    O.mkdir(parents=True,exist_ok=True)
    views=read(VIEW);protocol=read(PROTOCOL);manifest=read(E/'Closed_Manifest.json')['members']
    assert len(views)==33 and len({(v['case_id'],v['commit']) for v in views})==33
    pinned=[]
    for p in [REFLECTION,RUNNER,RESCUE,CORE,EXEC,R/'work/frozen_physics_loader.py']:
        assert sha(p)==protocol['source_hashes'][rel(p)],rel(p)
        pinned.append(binding(p))
    assert sha(VIEW)==read(VIEW.parent/'Result.json')['raw_state_file_sha256']
    source_proofs=[]
    selected,proof,lines=fn(REFLECTION,'run_one_scenario_no_llm_fallback_first');source_proofs.append(proof)
    sf='\n'.join(lines)
    assert sf.count('best = max(accepted,')==1
    assert sf.index('if not accepted:')<sf.index('best = max(accepted,')<sf.index('runner.rescue.apply_action(net, best["action"])')<sf.index('result["executed_actions"].append(')
    assert 'execution_pf_failed:' in sf and 'no_accepted_action' in sf
    assert 'failed_sigs = set()' in sf and '.add(' not in sf
    for path,name in [(RUNNER,'fallback_physics_candidates'),(RESCUE,'physics_refined_candidates'),(RESCUE,'verify_action'),(CORE,'source_run')]:
        node,pf,src=fn(path,name);source_proofs.append(pf)
        if name in ['fallback_physics_candidates','physics_refined_candidates']:assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='failed_sigs' for n in ast.walk(node))
    # The existing hash-chained event journal is read once; this is event-history
    # extraction, not any replay of old physical calls or old independent audits.
    assert sha(E/'events.jsonl')==manifest['events.jsonl']
    events=defaultdict(list);previous='0'*64;event_kinds=Counter();journal_rows=0
    for lineno,line in enumerate((E/'events.jsonl').open(encoding='utf-8'),1):
        wrapper=json.loads(line);event=wrapper['event']
        assert event['previous']==previous
        assert hashlib.sha256(canonical(event)).hexdigest()==wrapper['sha256']
        previous=wrapper['sha256'];journal_rows+=1;event_kinds[event['kind']]+=1
        events[event['active']['case_id']].append((lineno,event))
    rows=[];cases=[];inputs=[binding(VIEW),binding(PROTOCOL),binding(E/'Closed_Manifest.json'),binding(E/'events.jsonl')]+pinned
    for case in dict.fromkeys(v['case_id'] for v in views):
        d=E/case;result_path=d/'Result.json';order_path=d/'Call_Order.json'
        for path in [result_path,order_path]:assert sha(path)==manifest[path.relative_to(E).as_posix()]
        inputs.extend([binding(result_path),binding(order_path)])
        result=read(result_path);order=read(order_path);acts=result['executed_actions'];logs=result['logs'];k=len(acts)
        assert result['method']=='no_llm_fallback_first' and result['scenario_id']==case
        assert result['base_converged'] and result['stop_reason']=='no_accepted_action'
        assert len(logs)==k+1 and [a['iteration'] for a in acts]==list(range(1,k+1))
        assert [l['iteration'] for l in logs]==list(range(1,k+2))
        assert all(l['accepted_fallback']>0 for l in logs[:-1]) and logs[-1]['accepted_fallback']==0
        assert result['counters']['fallback_tests']==sum(l['fallback_tests'] for l in logs)
        closed=[(line,e) for line,e in events[case] if e['kind']=='NATIVE_CALL_CLOSED']
        reserved={e['identity'] for _,e in events[case] if e['kind']=='NEW_NATIVE_ATTEMPT_RESERVED'}
        commits=[(line,e) for line,e in events[case] if e['kind']=='SOURCE_COMMIT_CHECKPOINT']
        assert [e['record'] for _,e in closed]==order['records']
        assert len(commits)==k and [e['count'] for _,e in commits]==list(range(1,k+1))
        branch_close=[e for _,e in events[case] if e['kind']=='FULL_SOURCE_BRANCH_CLOSED']
        assert len(branch_close)==1 and branch_close[0]['summary']['accepted_actions']==k
        selections=[];stock={b:0. for b in range(118)};cursor_by_commit={0:1}
        for n,a in enumerate(acts,1):
            cp=d/f'commit_{n:02d}.json';assert sha(cp)==manifest[cp.relative_to(E).as_posix()]
            c=read(cp);cursor=c['call_cursor'];cursor_by_commit[n]=cursor
            assert c['capsule']==order['commitments'][n-1]==commits[n-1][1]['descriptor']
            assert c['metrics']==a['post_metrics'] and c['remaining_original_operations']==25-n
            # The tracer runs at the first line after successful append. The
            # immediately preceding closed native call is the selected action's
            # persistent-network execution, not one of the copied-net tests.
            last_line,last=closed[cursor-1]
            assert last_line<commits[n-1][0]
            assert sum(line<commits[n-1][0] for line,_ in closed)==cursor
            exec_path=E/last['record'];assert sha(exec_path)==last['record_sha256']==manifest[last['record']]
            execution=read(exec_path);assert execution['exception'] is None
            payload=a['action']['add_shunts_q_mvar'];assert len(payload)==1
            bus_s,delta=next(iter(payload.items()));bus=int(bus_s);before=stock[bus];stock[bus]+=abs(float(delta));target=stock[bus]
            assert target%25==0 and 0<target<=450
            action_id=1+bus*18+int(target/25)-1
            selections.append({'actor_selection_index':n,'iteration':a['iteration'],'source':'DFF_post_search_best','native_action':a['action'],'absolute_catalog_action':action_id,'bus':bus,'owned_q_before_mvar':before,'owned_q_target_mvar':target,'selection_outcome':'COMMITTED','selected_execution_record':binding(exec_path),'execution_receipt_identity':execution['identity'],'execution_call_provenance':execution['provenance'],'commit_descriptor':binding(cp),'commit_event_line':commits[n-1][0],'execution_event_line':last_line,'logged_source':'Result.json.executed_actions['+str(n-1)+']'})
            inputs.extend([binding(cp),binding(exec_path)])
        for view in [v for v in views if v['case_id']==case]:
            n=view['commit'];cursor=cursor_by_commit[n];prefix=selections[:n]
            attempted=sorted({a['absolute_catalog_action'] for a in prefix})
            assert attempted==view['view']['attempted_absolute_targets']
            state_stock={b:0. for b in range(118)}
            for a in prefix:state_stock[a['bus']]=a['owned_q_target_mvar']
            assert [state_stock[b] for b in view['view']['buses']]==view['view']['owned_q_mvar']
            # Hash the already saved state, but never deserialize or evaluate it.
            assert sha(R/view['source']['path'])==view['source']['sha256']
            current_closed=closed[:cursor];new_count=sum(e['identity'] in reserved for _,e in current_closed)
            numerical_candidate_calls=cursor-1-n
            tested=sum(l['fallback_tests'] for l in logs[:n]);verified=sum(l['accepted_fallback'] for l in logs[:n])
            assert tested>=numerical_candidate_calls
            rows.append({'case_id':case,'commit':n,'saved_state_binding':view['source'],'state_boundary':'After source reset/initial PF and before first search' if n==0 else 'Immediately after successful executed_actions append; before the next search iteration','behavior_actor':'Original DFF no_llm_fallback_first; not a DQN or LLM policy','actor_attempt_history_status':'COMPLETE','actor_rejection_history_status':'COMPLETE','ordered_actor_attempts':prefix,'attempted_absolute_targets':attempted,'actor_rejected_attempts':[],'actor_uncommitted_execution_failures':[],'evidence_for_no_missing_actor_selections':['One source selection/apply site per iteration; unsuccessful copied-network candidates are upstream of selection.','Every positive-selection iteration has one logged executed action and one matching successful persistent execution receipt.','The complete branch terminates no_accepted_action with zero accepted candidates; there is no unrecorded terminal execution failure.'],'paid_evidence_query_history':{'status':'PARTIAL' if n else 'COMPLETE_RESET_BOUNDARY','call_cursor':cursor,'initial_reuse_calls':1,'selected_execution_calls':n,'candidate_physical_query_invocations':numerical_candidate_calls,'new_native_reservations_within_prefix':new_count,'prior_paid_return_or_failure_reuses_within_prefix':cursor-new_count,'candidate_tests_logged':tested,'candidate_verifier_accepted_logged':verified,'candidate_verifier_rejected_logged':tested-verified,'candidate_checks_without_physical_call':tested-numerical_candidate_calls,'note':'Acceptance of an internal search candidate is not actor selection; query reuse is not cost-free evidence.'},'query_rejection_identity_status':'UNKNOWN' if n else 'COMPLETE_EMPTY_AT_RESET','missing_query_fields':[] if n==0 else ['Ordered verifier candidate action IDs/actions for every accepted and rejected internal test are not stored in Result.logs.','Per-candidate verifier outcome/reason and whether rejection preceded a PF call are absent from these logs.','Native-call metadata supplies input/output descriptors and exceptions, but no actor-selection or verifier-verdict field.'],'target_learned_policy_history_status':'UNKNOWN_NOT_EXECUTED','attempt_history_complete_for_this_executed_DFF_behavior':True,'learning_transition_admission':False,'admission_limit':'This source-specific history does not instantiate an unrun unique-action actor, reward, causal transition contract or masked Bellman next-state support. Original DecisionView file remains unchanged.'})
        terminal_query_calls=len(closed)-cursor_by_commit[k]
        cases.append({'case_id':case,'commits':k,'saved_states':k+1,'actor_selected_attempts':k,'actor_rejected_attempts':0,'terminal_actor_attempt':None,'terminal_source_condition':'no_accepted_action; automatic source stop, not logged policy action0','terminal_search_after_last_saved_commit':{'fallback_tests':logs[-1]['fallback_tests'],'accepted_fallback':0,'physical_query_invocations':terminal_query_calls,'excluded_from_last_saved_commit_history':True},'all_closed_query_invocations':len(closed),'result_binding':binding(result_path),'call_order_binding':binding(order_path)})
    assert len(rows)==33 and sum(c['actor_selected_attempts'] for c in cases)==29
    proof={'status':'SOURCE_BOUND_DFF_ACTOR_HISTORY_RECOVERED_QUERY_VERDICTS_PARTIAL','definitions':{'actor_attempt':'An action chosen at the source best-selection site and applied to persistent net for an environment transition.','candidate_evidence_query':'A hypothetical candidate checked on a copied net before selection, or another paid/reused numerical evaluation.','terminal_stop':'Source no_accepted_action stop; not an invented actor action0.'},'source_functions':source_proofs,'pinned_source_hashes_checked':pinned,'event_journal_rows_checked':journal_rows,'event_kind_counts':dict(event_kinds),'event_chain_tip':previous,'scope':'Saved-only source, JSON and byte-hash checks; no controller execution, state unpickling, model/PF/optimizer/training/GPU calls.','logical_gap_resolved':'All33 DFF prefixes have complete original actor-selection/rejection histories under the declared selection-site semantics. The previous blanket incomplete-attempt flag was conservative for these specific DFF prefixes.','logical_gaps_remaining':['A complete rejection identity/reason history for internal numerical search is not present in the inspected bound JSON logs. Aggregate counts exist; they must not be relabelled as actor attempts.','No actual DQN/LLM actor has produced transitions on these common118 states; its attempt history is UNKNOWN, not equal to DFF by assumption.','No reward, termination/admission or next-state-support gate is completed by recovering DFF action history.']}
    put('Recovered_DFF_Actor_Histories.json',rows);put('Source_Binding_Proof.json',proof);put('Case_Summaries.json',cases)
    unique={i['path']:i for i in inputs};put('Input_Bindings.json',list(unique.values()))
    summary={'status':'COMPLETE_SOURCE_BOUND_DFF_ACTOR_HISTORY_ONLY','at_utc':datetime.now(timezone.utc).isoformat(),'saved_states':33,'cases':4,'unique_committed_actor_attempts':29,'actor_history_status_counts':dict(Counter(r['actor_attempt_history_status'] for r in rows)),'internal_query_rejection_identity_status_counts':dict(Counter(r['query_rejection_identity_status'] for r in rows)),'unexecuted_learned_actor_history':'UNKNOWN_FOR_ALL33','source_file_sha256':sha(Path(__file__)),'old_saved_views_modified':False,'new_model_PF_optimizer_training_GPU_calls':0,'no_learning_launch_admission':True,'state_history_artifact':'Recovered_DFF_Actor_Histories.json','proof_artifact':'Source_Binding_Proof.json'}
    put('Result.json',summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
