# Linked preservation result and next actual gate

The additive v3 now permits repeated complete checkpoints after a planned
process handoff. It copies the entire inherited scientific journal prefix
byte-for-byte into a cumulative journal. The two new administrative receiving
events are retained in their original separately anchored segment and joined
to the cumulative chain. No scientific/query row is rebased or re-executed.
Earlier v1/v2 sources, tests and evidence remain unchanged.

A new three-process SOFTWARE fixture passed 17 checks. It verified two
planned handoffs, four full checkpoint boundaries, cumulative mock solver
attempts/returns/exceptions 4/3/1 and five paid receipt reuses with zero repeated
mock calls. The simulated commitment cursor advanced from 1 to 2, retaining
24 then 23 remaining slots and complete action history. Every new mock query
after a handoff used its current committed handle; historical receipts were
only reused, not remeasured. A changed earlier issuing journal was rejected.

The separate reader independently verified all four checkpoints, both linked
prefixes, distinct ended software processes, exact ordered query identities,
source pins, source/control-segment anchors, cumulative costs and unchanged
absolute deadline/limits. Nine original frozen asset checks passed. New
nonlinear PF/model/optimizer/forecast/cloud calls were ZERO. The nets and
commit cursors are explicitly synthetic, not actual physical trajectories.

Verified evidence ZIP: 57 members, 177,989 bytes; SHA256
`ef8f37512338f9738ebadaf507a438088674d1a43d879e10c9a272bfa43fbf5f`.
CRC and every member hash passed. Reuse the certificate without heartbeat
rehashes. Unfinished/terminal/expired states still cannot authorize retries.
Arbitrary crash recovery is not certified by two deliberate planned handoffs.

## Next bounded actual engineering design — not launch-ready

Use the already declared second development input L2, scenario
`spatial_allocation_L2_20261011`, load factor 1.473619. This follows the fixed
input order and does not select a root from outcomes. L1 is already inspected.
L2 is development, not unused confirmation. Do not rerun L1, restart its old
owner, extend its completed 600-second budget or re-export old artifacts.

Before any real call, implement and lock the new worker, launcher and separate
reader plus their actual source/import/input/runtime/claim closure. Bind the
original native GLOBAL menu, zone/common scopes, original Q grid, 450 cap,
score and solver options; common upper protection remains 1.05+1e-8. Proposed
engineering bound is 900 seconds across the new warm/cold/replay ownership
chain, including phase setup/handoff, with a separately fixed storage limit.
These design values become binding only in the source-closed protocol before
any outcomes; they are not an extension of an old study.

1. Warm owner: create only this new root, charge/preserve the initial solve,
   query the complete original first native menu once and preserve every
   accepted/rejected/exception/unknown identity. Select using the original
   native score and stable order; make at most one actual protected commit.
   Preserve exact current state, full causal cursor/history/failed keys, all
   query receipts/attempts/menus, runtime/input/source anchors, RNG, direct and
   query costs. Save/close a complete planned phase. No work follows its final
   checkpoint. If no admitted action or a resource/solver/preservation gate
   stops, retain partial/UNKNOWN evidence and stop; no substitute root/retry.
2. Launcher: verify exact PID/parent/command chain, actual exit0, terminated
   issuer and complete external ACK of checkpoint/closed phase before claiming
   the cold owner. Same original absolute deadline and full cumulative budget;
   no overlap, fallback, new allowance or source edit.
3. Cold owner: hydrate complete coordinator state. Verify saved positive and
   negative receipts using the cache with zero repeated PF. New scientific
   queries use only the actual current commitment state or its newly generated
   hypothetical descendants, never obsolete committed parents. Predetermine a
   causal following-query rule from native order and current cap legality,
   without reading its outcome. Preserve the actual following return/failure
   and another complete checkpoint with all paid identities and costs.
4. Prospectively charged independent continuous physics rebuild: recreate the
   root and the actual committed action from original input/source, then
   verify the declared following trial. Every new replay PF is separately
   counted and timed; it is not a scientific retry or a free result. Compare
   Vm/angle/P/Q at 1e-10 with exact UV memberships, caps, common guard, raw
   scopes, original score and strict decision identities. Keep native/current
   OV counts separately near the boundary. The final mechanical reader makes
   zero model/PF calls and checks every source/case/phase/receipt/cost/manifest.

The worker and reader sources for this actual design are NOT implemented or
frozen yet. Do not launch from this note, software success or idle resources.
Setup/import/checkpoint/journal/transfer/final receipt write/replay/audit/failure
costs need actual owner ledgers; unknown time is not imputed or free. A gate
pass certifies this engineering prefix, not a full receding controller restart
under arbitrary failures, LOCAL actor interface or LLM benefit.

After this gate, complete the actual receding 25-step worker and original
literal DFF + root-only DFF-ALT + unchanged selector comparator, both branches
and FULL BOTH costs. Freeze strong equally informed numerical controls, all
eight development roots, normal-band protection, independent continuous replay,
full economic allowance and missing/failure denominators before performance.
Only a surviving fixed physical opportunity permits a separate language study.
Matched scale and every prior failed intervention remain stopped; validated
LLM superiority and calibrated 90% winning confidence remain unestablished.
