# TRAIN trajectory measurement plan

The negative pretrained pilot changed real weights but produced no incremental policy benefit. Before another learning objective, this collection measures whether the already fixed TRAIN partition contains supported, useful episode outcomes. It does not change the LLM or launch a performance study.

All 31 finite TRAIN worlds are fixed before collection outcomes. Six complete original branches are reused, with new physical observation derivation charged separately. The 56 missing branches use literal full DFF/DFF-ALT functions, original settings, and the unchanged D-SE selector. No favorable cases, smaller search caps, new safety guard or validation cases enter this collection. One invalid TRAIN view stays disclosed.

The observer records actual current tables, all bus voltages, native scopes, accepted/rejected candidate outcomes, action prefixes, terminal states and every cost. Future labels and provenance are outside the input observation. Supported terminal preferences apply only to executed sequences sharing an exact root; unexecuted one-step candidates have no episode outcome. Previously missing observation fields are new derived measurements, never reconstructed original assets.

Before any new search, all six reused state chains must pass independent physical and table reconstruction at1e-10. Each new branch has the same committed-prefix replay and literal score/selection checks. Both branch costs are retained, including failed searches. Bounds are 30 minutes per branch and three hours overall, checked before solver calls; partials/unexecuted cases remain in the denominator and are never automatically rerun.

The predeclared feasibility gate needs at least three nontrivial protected-success worlds across two families, three informative distinct-first-action pairs, and two protected-versus-nonprotected terminal contrasts. This only permits further method design. It cannot certify learning, novelty or superiority. If the dataset lacks this support, the episode-recovery proposal stops; GPU fitting is not triggered.

Prior eight-world references took about23 minutes for19772 controller attempts. This larger collection can include healthy short roots and difficult searches, so that evidence gives a planning range, not a completion guarantee. GPU demand is zero. Independent unused confirmation and strong same-data numerical controls are still required for a later LLM claim.
