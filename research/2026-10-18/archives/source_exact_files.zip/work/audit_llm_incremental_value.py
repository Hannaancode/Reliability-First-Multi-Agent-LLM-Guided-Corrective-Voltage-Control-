"""Read-only saved-trace diagnostics. No model calls, PF solves or retuning."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib,json,math
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/llm_value_development';OUT.mkdir(exist_ok=True)
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
Q=[25,50,75,100,125,150,200,250,300]
def error_class(info):
    if info.get('parse_valid') is False:return 'parse_failure'
    if info.get('valid_action') is False:
        reason=info.get('valid_reason') or 'unspecified_invalid'
        if 'not_in_candidate' in reason:return 'bus_outside_candidate_list'
        return reason
    return 'valid_normalized_proposal'
def trace(branch):
    counts=Counter();gains=defaultdict(lambda:{'uv_reduction':0.,'deficit_reduction':0.})
    before=branch.get('base_metrics') or {}
    for action in branch.get('executed_actions',[]):
        source=action['source'];counts[source]+=1;after=action['post_metrics']
        for metric,label in [('uv_count','uv_reduction'),('deficit_sum','deficit_reduction')]:
            if isinstance(before.get(metric),(int,float)) and isinstance(after.get(metric),(int,float)):
                gains[source][label]+=before[metric]-after[metric]
        before=after
    return {'executed_actions_by_source':dict(counts),'observed_step_progress_by_source':dict(gains),
            'causal_credit_claim':False,'note':'Observed transitions, not within-branch remove-model counterfactuals; refinement is numerical search around proposed buses.'}
main_files=sorted((ROOT/'outputs/matched_campaign/cases').glob('*.json'));assert len(main_files)==62
lock=read(ROOT/'work/e/bank/BANK_LOCK.json');protocol=ROOT/'outputs/matched_campaign_protocol.json'
main_rows=[];selection=Counter();reply_errors=Counter();direct_counts=Counter();valid=0;exact_redundancy=0
for path in main_files:
    data=read(path);assert data['scenario_id']==path.stem and data['scenario_sha256']==lock['scenario_file_sha256'][path.name]
    assert data['protocol_sha256']==sha(protocol)
    branch=data['branches']['HG-VF'];audit=trace(branch)
    direct_counts.update(audit['executed_actions_by_source'])
    for item in branch.get('logs',[]):
        if 'llm_info' in item:reply_errors[error_class(item['llm_info'])]+=1
    row={'scenario_id':path.stem,'case_sha256':sha(path),'paired_terminal_metrics_valid':data['paired_terminal_metrics_valid'],'HG_VF':audit}
    if data['paired_terminal_metrics_valid']:
        valid+=1
        for arm,p in data['portfolios'].items():selection[arm+':'+p['selected_branch']]+=1
        selected=data['portfolios']['HG-SE']['selected_branch'];same=selected=='DFF' and data['portfolios']['HG-SE']['summary']==data['summaries']['DFF']
        exact_redundancy+=same
        row.update(HG_SE_selected_branch=selected,HG_SE_equals_saved_DFF_summary=same,
                   D_SE_selected_branch=data['portfolios']['D-SE']['selected_branch'],
                   HG_minus_D_terminal_UV=data['portfolios']['HG-SE']['summary']['final_uv']-data['portfolios']['D-SE']['summary']['final_uv'])
    main_rows.append(row)
central_rows=[];central_sources=Counter()
for path in sorted((ROOT/'outputs/central_matched_campaign/cases').glob('*.json')):
    data=read(path);assert data['scenario_id']==path.stem and data['scenario_sha256']==lock['scenario_file_sha256'][path.name]
    row={'scenario_id':path.stem,'case_sha256':sha(path),'branches':{}}
    for name,branch in data['branches'].items():
        row['branches'][name]=trace(branch)
        if name=='CENTRAL-VF':central_sources.update(row['branches'][name]['executed_actions_by_source'])
    central_rows.append(row)
pilot_rows=[];arms={}
files=sorted((ROOT/'outputs/security/gpu_development/cases').glob('*.json'));assert len(files)==24
for path in files:
    data=read(path);arm=data['arm'];totals=arms.setdefault(arm,{'proposals':0,'final_errors':Counter(),'first_errors':Counter(),'repairs':0,'accepted':0,'raw_compact_Q_outside_prompt_list':0})
    for proposal in data['proposals']:
        info=proposal.get('llm_info',{});totals['proposals']+=1;totals['final_errors'][error_class(info)]+=1
        first=info.get('first_valid_reason')
        if first:totals['first_errors']['bus_outside_candidate_list' if 'not_in_candidate' in first else first]+=1
        totals['repairs']+=bool(info.get('reprompted'));totals['accepted']+=bool(proposal.get('protected_true_state_verification',{}).get('accepted'))
        parsed=info.get('parsed') or {}
        if isinstance(parsed,dict) and 'q_mvar' in parsed:
            try:totals['raw_compact_Q_outside_prompt_list']+=float(parsed['q_mvar']) not in Q
            except (ValueError,TypeError):totals['raw_compact_Q_outside_prompt_list']+=1
        pilot_rows.append({'trial_id':data['trial_id'],'case_sha256':sha(path),'arm':arm,'zone':proposal['zone'],
                           'final_error_class':error_class(info),'first_valid_reason':first,'repaired':bool(info.get('reprompted')),
                           'accepted':bool(proposal.get('protected_true_state_verification',{}).get('accepted')),
                           'verifier_reason':proposal.get('protected_true_state_verification',{}).get('reason')})
retrieval=read(ROOT/'outputs/security/retrieval_development_check.json')
band_counts={arm:Counter() for arm in ['D-SE','HG-SE']}
for row in main_rows:
    if not row['paired_terminal_metrics_valid']:continue
    name=row['scenario_id']+'.json';saved=read(ROOT/'outputs/matched_campaign/cases'/name)
    physical_path=ROOT/'outputs/physical_replay_audit/cases'/name;physical=read(physical_path)
    assert physical['identity']['saved_case_sha256']==sha(ROOT/'outputs/matched_campaign/cases'/name)
    assert physical['identity']['audit_source_sha256']==sha(ROOT/'work/physical_replay_audit.py')
    for arm in band_counts:
        branch=saved['portfolios'][arm]['selected_branch'];terminal=physical['branches'][branch]['states'][-1]
        voltage=terminal['voltage'];counts=band_counts[arm];counts['valid_selected_trajectories']+=1
        counts['terminal_original_strict_UV_zero']+=voltage['uv_strict']==0
        counts['terminal_soft_upper_band_exceeded_beyond_1e8']+=voltage['maximum']>1.05+1e-8
        counts['terminal_both_normal_bands_met_with_1e8_diagnostic']+=voltage['minimum']>=.95-1e-8 and voltage['maximum']<=1.05+1e-8
        counts['terminal_hard_upper_limit_exceeded_beyond_1e8']+=voltage['maximum']>1.06+1e-8
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'role':'Exploratory diagnosis after outcomes; not independent confirmatory evidence',
        'no_new_inference_or_physical_outcomes':True,'main_cases':len(main_rows),'valid_main_pairs':valid,
        'whole_HG_VF_branch_redundant_for_saved_HG_SE_selection':exact_redundancy,'portfolio_selections':dict(selection),
        'main_executed_HG_VF_actions_by_source':dict(direct_counts),'main_reply_error_counts':dict(reply_errors),
        'central_cases':len(central_rows),'central_executed_actions_by_source':dict(central_sources),
        'saved_physical_terminal_band_diagnostics':band_counts,
        'security_actual_proposals':len(pilot_rows),'security_arms':arms,
        'retrieval_corpus_sha256':retrieval['source_corpus_sha256'],'retrieved_records':[{k:h[k] for k in ['id','question','answer','source_sha256']} for h in retrieval['top_records']],
        'limits':['Action-source participation is not causal evidence of added LLM value.',
                  'Dropping the entire unselected HG-VF branch preserves the observed selected DFF outcome; this is a saved-output deduction, not a fresh within-branch ablation.',
                  'A model-independent proposer/refinement control must actually execute before attributing central improvements to learned search.',
                  'General QA relevance does not establish state-conditioned bus or Q selection quality.',
                  'All62 bank outcomes are already inspected; future use for development is exploratory and cannot be relabelled untouched.'],
        'main_rows':main_rows,'central_rows':central_rows,'security_rows':pilot_rows}
(OUT/'incremental_value_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
lines=['# Actual learned-search diagnosis', '', 'Saved-trace analysis; no new inference or power-flow outcomes.', '',
       f'Main: {valid} valid pairs; HG-SE selected DFF and exactly reproduced its saved summary in {exact_redundancy}.',
       'Portfolio selections: '+json.dumps(dict(selection)),
       'HG-VF executed action sources: '+json.dumps(dict(direct_counts)),
       'CENTRAL-VF executed action sources: '+json.dumps(dict(central_sources)), '',
       'These source counts show participation, not causal incremental value.', '',
       '| Pilot arm | Proposals | Final candidate-list failures | Final parse failures | Repairs | Accepted |',
       '|---|---:|---:|---:|---:|---:|']
for arm,d in sorted(arms.items()):lines.append(f"| {arm} | {d['proposals']} | {d['final_errors']['bus_outside_candidate_list']} | {d['final_errors']['parse_failure']} | {d['repairs']} | {d['accepted']} |")
lines+=['', 'The three retrieved answers explain reactive compensation in general. They do not specify which state-dependent bus or Q to select. This is direct content inspection, not proof of irrelevance or a certified relevance score.', '',
        'Normal-band endpoint diagnostics from original independent replay: '+json.dumps(band_counts)+'. The 1e-8 labels are separate diagnostics, not changes to original strict success thresholds.', '',
        'Next: clean candidate-ordering/interface validation, matched-budget numerical search controls, then frozen-model historical validation. Do not train on or tune against the reviewed bank while claiming it is untouched.', '']
(OUT/'Learned_Search_Diagnosis.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['main_cases','valid_main_pairs','whole_HG_VF_branch_redundant_for_saved_HG_SE_selection','portfolio_selections','main_executed_HG_VF_actions_by_source','central_executed_actions_by_source','security_arms']},indent=2))
