"""Prospective three-arm federation encoder/readout diagnostic, not another SFT.

All old stopped training/foreign-role jobs remain untouched. GPU payloads
contain only already verified current-prefix IDs; labels/splits stay local.
"""
import ast,copy,hashlib,json,os,shutil,zipfile
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
P=R/'outputs/f118_encoder_readout_preparation_20261022'
OLD=R/'outputs/native_frozen_feature_preparation_20261020'
DATA=R/'outputs/matched_scale_20261011/preparation'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text('utf-8'))
def put(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def main():
    P.mkdir(exist_ok=False)
    fit=read(DATA/'fit.json');held=read(DATA/'held.json');rows=fit+held
    assert len(fit)==340 and len(held)==96 and sum(r['multiplicity'] for r in rows)==16000
    assert not {r['world_sha256'] for r in fit}&{r['world_sha256'] for r in held}
    inputs=[];local=[];seen={}
    for i,r in enumerate(rows):
        assert len(r['prefix_ids'])+384<=4096
        key=tuple(r['prefix_ids'])
        if key not in seen:
            seen[key]=len(inputs);inputs.append({'id':seen[key],'input_ids':r['prefix_ids'],'tokens':len(r['prefix_ids'])})
        local.append({**r,'row_id':i,'feature_id':seen[key],'readout_partition':'FIT' if i<len(fit) else 'HELD'})
    assert len(inputs)==432 and max(r['tokens'] for r in inputs)==3278
    assert len({r['id'] for r in inputs})==432
    put(P/'Causal_Inputs_Only.json',inputs);put(P/'Readout_Rows_Local_Only.json',local)
    original=read(OLD/'Protocol.json');protocol=copy.deepcopy(original)
    remote='f118_frozen_encoder_remote_20261022.py';setup='f118_frozen_encoder_setup_20261022.py';guardian='f118_frozen_encoder_guardian_20261022.py'
    text=(R/'work/native_frozen_feature_remote_20261020.py').read_text('utf-8')
    text=text.replace('241','432').replace('2598','3278').replace('482','864').replace('20261020','20261022')
    text=text.replace('same_original1929_FITmultiplicities_preserved_locally','all_original16000_multiplicities_preserved_locally')
    # Current-only prefix tensor is the complete input. No answer tokens or
    # teacher/partition values enter this new frozen representation operator.
    anchor="    assert file_hash(ROOT/'prep/Causal_Inputs_Only.json')==p['causal_inputs_sha256'];"
    assert text.count(anchor)==1
    text=text.replace(anchor,"    assert all(set(v)=={'id','input_ids','tokens'} for v in items)\n"+anchor)
    (R/'work'/remote).write_text(text,'utf-8')
    setuptext=(R/'work/native_frozen_feature_setup_20261020.py').read_text('utf-8')
    # Setup is a standalone uploaded control program; environment checker is
    # present in the frozen input bundle under the already pinned filename.
    (R/'work'/setup).write_text(setuptext,'utf-8')
    g=(R/'work/native_frozen_feature_guardian_20261020.py').read_text('utf-8').replace('native_frozen_feature_remote_20261020.py',remote)
    (R/'work'/guardian).write_text(g,'utf-8')
    files=['work/'+remote,'work/native_frozen_feature_environment_20261020.py','work/'+guardian,
        'work/public_size_u61_preservation.py','work/candidate_process_pretrained_loader.py',
        'work/frozen_dependency_closure.txt','work/frozen_gpu_requirements.txt','work/uv_bootstrap_version.txt']
    validator='validate_f118_encoder_transfer_20261022.py'
    validation=(R/'work/validate_native_feature_transfer_20261020.py').read_text('utf-8').replace('241','432')
    (R/'work'/validator).write_text(validation,'utf-8')
    protocol.update(at_utc=datetime.now(timezone.utc).isoformat(),study_id='f118_frozen_encoder_and_fixed_numerical_readout_20261022',
        human_priority='Latest human asks concrete parallel GPU work and a fair benchmark; this is a separately prospective original118role hybrid feasibility test, not a stopped SFT or old native13allocation restart.',
        mechanism='Use the original trained frozen language body as current-state representation, replace autoregressive command generation with a fixed convex action readout; same public0.5base controls domain-adapter effects, public1.5is a separate capacity/pretraining reference.',
        source_hashes={n:sha(R/n) for n in files},causal_inputs_sha256=sha(P/'Causal_Inputs_Only.json'),
        original_source_pins={f'{DATA.relative_to(R).as_posix()}/{n}':sha(DATA/n) for n in ['fit.json','held.json','protocol.json']},
        actual_current_inputs=432,all_world_current_pairs=436,maximum_complete_prefix_tokens=3278,
        planned_total_body_forwards=2594,all432_primary_and_cold_per_arm=True,
        science_process_seconds=2700,collector_seconds=3000,
        body_label_guard='Only id/current full prefix tokenIDs/length are sent. Labels, raw packets, world IDs, partitions, multiplicities, teacher answers and numerical scores stay local. No generation/PF/gradients/optimizer.',
        role='Original federation LOCAL current-state command target, not native13inverter features. All340FIT/96HELD original distinct world-input records, all16000multiplicities retained.',
        private_training_leakage='Original private adapter may already have trained on all109historical worlds including the24readoutHELDworlds. HELD means readout-fit exclusion only. Private-arm results are descriptive in-sample/historical development, never unused-generalization or equally-trained superiority evidence.',
        historical_base='Original private adapter unchanged on same pinned current public0.5base as control. Exact historical paper base revision remains UNKNOWN.',
        no_automatic_physical_rollout=True,
        readout='Freeze before features: weighted FIT-only standardization, onehot FIT-only action class dictionary; linear and RBF kernel ridge both reported, lambda=.001*sum(FITweights), RBFexp(-squared_distance/feature_width). Primary private0.5linear. No lambda/gamma/kernel/model/checkpoint/seed/output sweep. HELD OOV/invalid actions remain misses.',
        gate='Diagnostic opportunity only: private-linear equal-world accuracy >=.7791666666666667 and >=public0.5linear+.05, better in>=2readoutHELDworlds. Historical/private-training leakage prevents generalization/LLM superiority even on pass. Need separate fresh physical/attribution protocol.',
        numeric_control='Reuse independently complete equal-world ExtraTrees.7291666666666666; fit no old numerical model again. Add fixed linear/RBF numeric current-field control only if source-bound input vectorizer is available, otherwise comparison supportUNKNOWN. No weak comparator substituted.',
        source_selected_profiles_are_independent_arms_not_quota_fallback=True,
        actual_GPU_availability='Must verify exact account/current assignment/eligibility before one NEW allocation for each separate arm. No fallback/replacement after denial. Three profiles do not pool VRAM.',
        old_studies='All old SFT, higher-scale, native13feature allocation attempts and their failures remain terminal/preserved. These are new436federation-prefix frozen-encoder identities, not repeated old13/241inputs.',
        output_readiness='No performance/physical benefit follows from feature extraction. Complete/cold/source/cost/immutability and partial-aware outside reader required before any readout.')
    protocol.pop('all241_primary_and_all241_cold_per_arm',None)
    put(P/'Protocol.json',protocol)
    authority={'direct_human_instruction':'Use three GPUs for useful independent parallel tasks, continue benchmarking and ourLLM contribution; full necessary access/execution and original-profile adapter export authority persists.',
        'prospective_profiles':protocol['profiles'],'private_adapter_only_to_original_profile':True,
        'no_guaranteed_win_replacement_purchase_quota_evasion_or_scientific_retry':True}
    put(P/'Direct_Human_Authority.json',authority)
    # A longer, fixed ownership handshake addresses imports before a claim;
    # it is prospective engineering, not an extension of any old owner budget.
    coordinator=(R/'work/coordinate_atomic_source_owner_20261022.py').read_text('utf-8').replace('time.monotonic()-start<60','time.monotonic()-start<180')
    (R/'work/coordinate_f118_encoder_owner_20261022.py').write_text(coordinator,'utf-8')
    reader=R/'work/audit_f118_frozen_encoder_20261022.py'
    assert reader.is_file(),'Freeze partial-aware independent reader before any GPU owner'
    owners=[]
    for arm in protocol['arms']:
        sub=P/arm;sub.mkdir();shutil.copyfile(P/'Protocol.json',sub/'Production_Protocol.json');shutil.copyfile(P/'Direct_Human_Authority.json',sub/'Direct_Human_Authority.json')
        host=(R/f'work/run_native_feature_{arm}_20261020.py').read_text('utf-8')
        host=host.replace('native_frozen_feature_preparation_20261020','f118_encoder_readout_preparation_20261022').replace('native_frozen_feature_execution_20261020','f118_encoder_readout_execution_20261022')
        host=host.replace('native_frozen_feature_setup_20261020.py',setup).replace('native_frozen_feature_guardian_20261020.py',guardian)
        host=host.replace('validate_native_feature_transfer_20261020.py',validator)
        owner=R/f'work/run_f118_encoder_{arm}_20261022.py';owner.write_text(host,'utf-8');ast.parse(host)
        payload={n:R/n for n in files};payload.update({'prep/protocol.json':P/'Protocol.json','prep/Causal_Inputs_Only.json':P/'Causal_Inputs_Only.json'})
        if arm=='private_0_5B':
            adapter=R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
            payload.update({'prep/private_adapter/'+n:adapter/n for n in ['adapter_config.json','adapter_model.safetensors']})
        manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in payload.items()};archive=sub/'Frozen_Encoder_Inputs.zip'
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
            for n,p in payload.items():z.write(p,n)
            z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json',json.dumps(manifest,indent=2))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
            for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
            assert all('Readout' not in n and 'credential' not in n and 'testbed' not in n for n in z.namelist())
        put(sub/'Cloud_Payload_Manifest.json',{'archive':archive.relative_to(R).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(payload)+1,'human_authority_source':(sub/'Direct_Human_Authority.json').relative_to(R).as_posix(),'human_authority_sha256':sha(sub/'Direct_Human_Authority.json'),'no_credentials_network_or_teacher_labels':True})
        host_hashes={**protocol['source_hashes'],**{p.relative_to(R).as_posix():sha(p) for p in [owner,R/'work'/setup,R/'work'/validator,reader]}}
        put(sub/'Launch_Readiness_Audit.json',{'passed':True,'source_hashes':host_hashes,'all16k_multiplicities_local':True,'no_labels_or_future_inputs_exported':True,'one_selected_profile_no_fallback':True})
        op={'single_owner':{'source':owner.relative_to(R).as_posix(),'sha256':sha(owner),'python':'work/colab_access_env/Scripts/python.exe','output':'outputs/f118_encoder_readout_execution_20261022/'+arm,'coordination':'outputs/f118_encoder_readout_coordination_20261022/'+arm,'bound_seconds':5400}}
        put(sub/'Owner_Protocol.json',op);owners.append(op)
    for n in files+['work/'+setup,'work/coordinate_f118_encoder_owner_20261022.py',str(reader.relative_to(R))]:
        if n.endswith('.py'):ast.parse((R/n).read_text('utf-8'))
    put(P/'Independent_Reader_Lock.json',{'source':reader.relative_to(R).as_posix(),'sha256':sha(reader),'protocol_sha256':sha(P/'Protocol.json'),'only_after_all_owners_and_launcher_chains_terminal':True,'partial_leaves_missing_arm_opportunityUNKNOWN':True})
    put(P/'Input_And_Source_Readiness.json',{'status':'PASS_NEW_FEDERATION_FROZEN_ENCODER_CAUSAL_SOURCE_PACKAGE_AND_SPLIT_GATES',
        'all_unique_GPU_inputs':432,'all_world_current_pairs':436,'FIT':340,'readoutHELD':96,'maximum_tokens':3278,'all16k_multiplicities_retained':True,'private_HELD_not_adapter_holdout':True,
        'independent_profiles':3,'new_GPU_model_PF_optimizer_calls':0,'all_actual_memory_immutable_cold_gates_still_required':True})
    print(json.dumps({'prepared_arms':protocol['arms'],'new_unique_federation_contexts':432,'world_current_pairs':436,'max_tokens':3278,'new_scientific_calls':0,'not_yet_allocated':True}))

if __name__=='__main__':main()
