"""Typed metadata from a fixed local reference map; not an answer truth checker.

Only the application loads the registry using a separately pinned byte hash.
An untrusted caller can request or verify a field, never supply a registry.
The source supports a registered document identifier and URL only. A URL is
not evidence that its target was retrieved, verified or supports an answer.
No network, language model, vector index, or notebook execution occurs here.
"""
from dataclasses import dataclass
import hashlib
import html
import json
import re
from urllib.parse import urlsplit

FIELDS = frozenset({'document_id', 'url', 'page', 'year', 'author', 'equation'})


def _pairs_unique(pairs):
    out = {}
    for k, v in pairs:
        if k in out:
            raise ValueError('duplicate_registry_key')
        out[k] = v
    return out


@dataclass(frozen=True)
class ReferenceRegistry:
    sha256: str
    entries: tuple

    @classmethod
    def from_trusted_bytes(cls, raw, expected_sha256):
        if not isinstance(raw, bytes) or not isinstance(expected_sha256, str):
            raise ValueError('invalid_registry_input_type')
        digest = hashlib.sha256(raw).hexdigest()
        if digest != expected_sha256:
            raise ValueError('source_identity_mismatch')
        data = json.loads(raw.decode('utf-8-sig'), object_pairs_hook=_pairs_unique)
        if not isinstance(data, dict) or not data:
            raise ValueError('empty_or_invalid_registry')
        entries = []
        for key, value in data.items():
            if not isinstance(key, str) or not re.fullmatch(r'LL[0-9]{8}', key):
                raise ValueError('invalid_reference_id')
            if not isinstance(value, str) or not value:
                raise ValueError('invalid_reference_url')
            parsed = urlsplit(value)
            if (parsed.scheme != 'https' or parsed.hostname not in {'nerc.com', 'www.nerc.com'}
                    or parsed.username or parsed.password or parsed.port not in {None, 443}
                    or any(ord(c) < 32 for c in value)):
                raise ValueError('unsupported_reference_url')
            entries.append((key, value))
        return cls(digest, tuple(entries))

    def handle(self, request):
        reject = lambda reason: {'status': 'REJECTED', 'reason': reason}
        if not isinstance(request, dict):
            return reject('invalid_request_schema')
        operation = request.get('operation')
        if not isinstance(operation, str) or operation not in {'lookup', 'verify'}:
            return reject('invalid_operation')
        fields = {'operation', 'document_id', 'field'} | ({'value'} if operation == 'verify' else set())
        if set(request) != fields:
            return reject('invalid_request_schema')
        identifier, field = request['document_id'], request['field']
        if not isinstance(identifier, str) or not isinstance(field, str):
            return reject('invalid_request_types')
        if field not in FIELDS:
            return reject('unsupported_metadata_field')
        known = dict(self.entries)
        if identifier not in known:
            return reject('unknown_document_id')
        base = {'document_id': identifier, 'field': field, 'registry_sha256': self.sha256,
                'provenance_scope': 'LOCAL_REGISTERED_REFERENCE_MAPPING_ONLY',
                'linked_document_retrieved': False, 'answer_truth': 'NOT_ASSESSED',
                'out_of_scope_refusal': 'NOT_ASSESSED'}
        if field not in {'document_id', 'url'}:
            return {**base, 'status': 'NOT_STATED', 'reason': 'field_absent_from_registry'}
        value = identifier if field == 'document_id' else known[identifier]
        if operation == 'verify' and (type(request['value']) is not str or request['value'] != value):
            return {**base, 'status': 'REJECTED', 'reason': 'value_mismatch'}
        return {**base, 'status': 'REGISTERED_METADATA', 'value': value,
                'citation': {'document_id': identifier, 'url': known[identifier]}}

    def render(self, request):
        """No untrusted answer text is rendered or silently supplied with a citation."""
        result = self.handle(request)
        if result['status'] == 'REGISTERED_METADATA':
            c = result['citation']
            view = (f'<span>{html.escape(result["field"])}: {html.escape(result["value"])}</span> '
                    f'<a href="{html.escape(c["url"], quote=True)}">{html.escape(c["document_id"])}</a> '
                    '<small>Registered reference mapping; linked document not checked.</small>')
        elif result['status'] == 'NOT_STATED':
            view = '<span>Requested field is not stated in the registered metadata.</span>'
        else:
            view = '<span>Metadata request rejected.</span>'
        return {'result': result, 'html': view}
