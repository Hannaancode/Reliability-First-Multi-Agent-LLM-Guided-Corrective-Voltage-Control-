"""Local CPU complete-state validation before transfer ACK; zero model/PF calls."""
import sys,json,hashlib
from pathlib import Path
import candidate_process_runtime
import torch,numpy as np
def main():
    file=Path(sys.argv[1]);out=Path(sys.argv[2]);expected_step=int(sys.argv[3]);assert not out.exists()
    value=torch.load(file,map_location='cpu',weights_only=False);t=value['trainables'];assert len(t)==394 and sum(p.numel() for p in t.values())==18469379
    assert list(t)==value['ordered_names'] and len(set(value['ordered_names']))==394
    assert sum('.lora_A.candidate_process_copy.' in n for n in t)==196 and sum('.lora_B.candidate_process_copy.' in n for n in t)==196
    assert t['head.linear.weight'].shape==(3,1536) and t['head.linear.bias'].shape==(3,)
    assert all(p.dtype==torch.float32 and bool(torch.isfinite(p).all()) for p in t.values())
    opt=value['optimizer'];groups=opt['param_groups'];assert len(groups)==1 and groups[0]['params']==list(range(394))
    assert groups[0]['lr']==.0002 and groups[0]['weight_decay']==.01 and groups[0]['betas']==(.9,.999) and groups[0]['eps']==1e-8
    if expected_step:
        assert set(opt['state'])==set(range(394))
        for i,(n,p) in enumerate(t.items()):
            state=opt['state'][i];assert set(state)=={'step','exp_avg','exp_avg_sq'} and int(state['step'].item())==expected_step
            for k in ['exp_avg','exp_avg_sq']:assert state[k].shape==p.shape and state[k].dtype==torch.float32 and bool(torch.isfinite(state[k]).all())
            assert bool((state['exp_avg_sq']>=0).all())
    else:assert not opt['state']
    assert value['cursor']=={'completed_updates':expected_step,'next_update':expected_step+1,'engineering_only':True}
    assert set(value['RNG'])=={'python','numpy','cpu','cuda'} and value['RNG']['cpu'].dtype==torch.uint8 and len(value['RNG']['cuda'])==1
    assert value['RNG']['numpy'][0]=='MT19937' and value['RNG']['numpy'][1].dtype==np.uint32
    assert value['scaler']['scale']>0 and value['scaler']['growth_interval']==2000
    assert len(value['contract']['source_hashes'])>=7 and len(value['contract']['selected_input_sha256'])==64
    h=hashlib.sha256()
    with file.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    out.write_text(json.dumps({'status':'PASS_COMPLETE_CPU_TRAINABLES_ADAMW_SCALER_RNG_CURSOR_SOURCE_CONTRACT','step':expected_step,'trainable_tensors':394,'trainable_parameters':18469379,'checkpoint_bytes':file.stat().st_size,'checkpoint_sha256':h.hexdigest(),'new_model_PF_optimizer_calls':0},indent=2),encoding='utf-8')
if __name__=='__main__':main()
