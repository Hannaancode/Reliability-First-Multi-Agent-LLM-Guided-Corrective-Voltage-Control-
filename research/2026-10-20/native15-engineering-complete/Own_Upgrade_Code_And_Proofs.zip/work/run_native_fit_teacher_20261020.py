"""One fixed FIT64 full-grid numerical teacher data campaign. No SLM training/DEV exposure."""
import os,json,pickle,hashlib,time,copy,random,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_fit_teacher_preparation_20261020';OUT=ROOT/'outputs/native_fit_teacher_execution_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def binary(p,v):
    with Path(p).open('xb') as f:pickle.dump(v,f,protocol=5);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});began=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from native_fit_teacher_math_20261020 import propose
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));deadline=began+p['worker_seconds'];cost={k:0 for k in ['native_conversions','PF_attempts','PF_returns','PF_exceptions','paid_cache_uses','derivative_attempts','derivative_returns','LU_returns','RHS_returns','LP_attempts','LP_returns']};cost['model_GPU_optimizer_calls']=0;rows=[];receipts=[];history_known=set(json.loads((PREP/'Relevant_Prior_Physical_Inputs.json').read_text())['physical_signatures']);cache={};scope={};previous='0'*64;stream=(OUT/'events.jsonl').open('x',encoding='utf-8')
    for rel,h in p['source_and_input_hashes'].items():assert sha(ROOT/rel)==h
    def event(kind,**data):
        nonlocal previous
        v={'kind':kind,'seconds':time.monotonic()-began,'previous':previous,**data};h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest();stream.write(json.dumps({'event':v,'sha256':h})+'\n');stream.flush();os.fsync(stream.fileno());previous=h
    graph=np.load(ROOT/p['graph']);Y=graph['Y'];physics=OUT/'physics';physics.mkdir();env,proxy,_=b.environment();cost['native_conversions']+=1;template=copy.deepcopy(env.__dict__);recipes=np.load(ROOT/p['FIT_recipes']);put(OUT/'Frozen_Before.json',frozen_checks())
    def tracked(net,*args,**kwargs):
        assert time.monotonic()<deadline and not args and kwargs in [{'algorithm':'bfsw'},{'algorithm':'bfsw','init':'dc'}];sig=signature(net);key=(sig,json.dumps(kwargs,sort_keys=True));assert sig not in history_known,'Already paid physicalidentity; never rerun'
        if key in cache:net.update(copy.deepcopy(cache[key]));cost['paid_cache_uses']+=1;return
        assert not any(k[0]==sig for k in cache),'Alreadypaidinput/differentinitializer remainsUNKNOWN';index=cost['PF_attempts'];binary(physics/f'PF{index:05d}_before.pkl',net);record={'index':index,'scope':scope.copy(),'physical_signature':sig,'kwargs':kwargs,'status':'ATTEMPTED'};receipts.append(record);cost['PF_attempts']+=1;event('PF_attempt',**record);t=time.perf_counter()
        try:b.pp.runpp(net,**kwargs)
        except BaseException as e:cost['PF_exceptions']+=1;record.update(status='EXCEPTION',exception=type(e).__name__,seconds=time.perf_counter()-t);event('PF_exception',**record);raise
        cost['PF_returns']+=1;assert net.converged and sig==signature(net);pp=net._ppc;assert np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and pp['baseMVA']==float(graph['baseMVA']);binary(physics/f'PF{index:05d}_after.pkl',net);fields={n:net[n].select_dtypes(include=[np.number]).to_numpy(dtype=float) for n in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};np.savez(physics/f'PF{index:05d}_fields.npz',**fields);record.update(status='RETURNED',after_sha256=sha(physics/f'PF{index:05d}_after.pkl'),seconds=time.perf_counter()-t);cache[key]=copy.deepcopy(net);event('PF_return',**record)
    proxy.runpp=tracked
    def safe(v0,v1):
        normal=(v0>=.95)&(v0<=1.05);return bool(np.isfinite(v1).all() and np.all(v1[normal]>=.95-1e-8) and np.all(v1[normal]<=1.05+1e-8) and (v1<.95).sum()<=(v0<.95).sum() and (v1>1.05).sum()<=(v0>1.05).sum())
    resource_partial=False
    for pos,seed in enumerate(p['FIT_seeds']):
        if time.monotonic()>deadline-20:resource_partial=True;break
        env.__dict__.clear();env.__dict__.update(copy.deepcopy(template));world={'seed':seed,'status':'UNKNOWN','steps':[]};rows.append(world);scope.clear();scope.update(seed=seed,stage='root',step=0)
        try:
            env.reset(seed)
            for k,t,c in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(env.network[t][c].to_numpy(),recipes[k][pos])
            world['root_receipt']=receipts[-1]['index'];history=[]
            for step in range(1,101):
                if time.monotonic()>deadline-20:resource_partial=True;raise TimeoutError('Prospective data resourcebound; never extend')
                vm=env.network.res_bus.vm_pu.to_numpy(copy=True)
                if bool(((vm>=.95)&(vm<=1.05)).all()):world['status']='COMPLETE_RESTORED';break
                d=OUT/f'world{seed}_step{step:03d}';d.mkdir();binary(d/'Current_ENV.pkl',env.__dict__);cursor={'seed':seed,'next_step':step,'remaining_operations':101-step,'last_Q':env.network.sgen.q_mvar.to_numpy()[:3].tolist(),'history':history.copy(),'paid_registry':{k[0]:k[1] for k in cache},'costs':cost.copy(),'absolute_deadline_monotonic':deadline,'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'source_protocol_sha256':sha(PREP/'Protocol.json')};binary(d/'Full_Cursor_RNG_Registry.pkl',cursor);loaded=pickle.loads((d/'Current_ENV.pkl').read_bytes());cold=env.__class__.__new__(env.__class__);cold.__dict__.update(loaded)
                for n in ['bus','line','sgen','load','ext_grid','res_bus']:assert cold.network[n].equals(env.network[n])
                u,S=propose(env.network,Y,d,cost);q0=env.network.sgen.q_mvar.to_numpy(copy=True)[:3];qnext=q0-u;np.save(d/'Native_u.npy',u);assert np.array_equal(cold.network.sgen.q_mvar.to_numpy()[:3]-u,qnext);candidate=copy.deepcopy(cold);scope.clear();scope.update(seed=seed,stage='candidate',step=step);before_calls=cost['PF_attempts'];candidate.step_Preward(qnext.reshape(3,1),u.reshape(3,1));after=candidate.network.res_bus.vm_pu.to_numpy(copy=True);accepted=safe(vm,after);binary(d/'Candidate_ENV_After.pkl',candidate.__dict__)
                result={'step':step,'directory':d.relative_to(ROOT).as_posix(),'current_vm':vm.tolist(),'current_Q':q0.tolist(),'raw_teacher_u':u.tolist(),'accepted':accepted,'committed_teacher_u':u.tolist() if accepted else [0.,0.,0.],'candidate_vm':after.tolist(),'candidate_UV':int((after<.95).sum()),'candidate_OV':int((after>1.05).sum()),'candidate_receipt':receipts[-1]['index'] if cost['PF_attempts']>before_calls else None,'paid_cache_reuse':cost['PF_attempts']==before_calls,'current_NET_sha256':sha(d/'Current_ENV.pkl'),'no_future_label_in_actor_inputs':True};put(d/'Decision.json',result);world['steps'].append(result);event('teacher_decision',seed=seed,step=step,accepted=accepted)
                if not accepted:world['status']='COMPLETE_GUARD_REJECTED_HOLD_STOP';break
                env=candidate;history.append({'step':step,'all13_vm':after.tolist(),'absolute_Q_Mvar':qnext.reshape(3,1).tolist()})
            else:world['status']='COMPLETE_NATIVE100_HORIZON'
            final=env.network.res_bus.vm_pu.to_numpy();world.update(final_UV=int((final<.95).sum()),final_OV=int((final>1.05).sum()),final_vm=final.tolist());world['status']='COMPLETE_RESTORED' if not world['final_UV'] and not world['final_OV'] else world['status']
        except BaseException as e:world.update(failure_type=type(e).__name__,failure=str(e));event('world_partial_or_unknown',seed=seed,type=type(e).__name__)
        if resource_partial:break
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_DECLARED64_NATIVE_FIT_TEACHER_EPISODES' if len(rows)==64 and all(w['status'].startswith('COMPLETE') for w in rows) else 'TERMINAL_PARTIAL_NATIVE_FIT_TEACHER_DATA','all_worlds':rows,'unentered_seeds':p['FIT_seeds'][len(rows):],'receipts':receipts,'actual_costs':cost,'teacher_rows':sum(len(w['steps']) for w in rows),'DEV_and_confirmation_physics_calls':0,'workflow_seconds':time.monotonic()-began,'no_SLMLearning_or_superiority_claim':True};put(OUT/'Result.json',result);put(OUT/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(OUT/'Result.json'));stream.close();put(OUT/'Closed_Manifest.json',{'files':[{'path':p.relative_to(OUT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.rglob('*') if p.is_file()],'journal_last_sha256':previous});print(result['status'],result['teacher_rows'])
if __name__=='__main__':main()
