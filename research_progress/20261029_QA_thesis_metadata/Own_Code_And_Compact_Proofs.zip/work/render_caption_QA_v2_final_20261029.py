from pathlib import Path
from PIL import Image, ImageDraw
from pypdf import PdfReader
import subprocess, json
R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_caption_QA_v2_20261029'
def main():
    pdf=O/'Integrated_Thesis_QA.pdf'; pages=PdfReader(pdf).pages
    count=json.loads((O/'Pagination_Record.json').read_text('utf-8-sig'))['pages']
    assert len(pages)==count==130
    out=O/'render';out.mkdir(exist_ok=True)
    assert not list(out.glob('final-*.png'))
    exe=Path('C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
    subprocess.run([str(exe),'-r','85','-png',str(pdf),str(out/'final')],check=True,timeout=360,creationflags=subprocess.CREATE_NO_WINDOW)
    files=sorted(out.glob('final-*.png'));assert len(files)==count
    for start in range(0,count,24):
        canvas=Image.new('RGB',(1440,6*370),'#cbd0d4');draw=ImageDraw.Draw(canvas)
        for j,f in enumerate(files[start:start+24]):
            im=Image.open(f).convert('RGB');im.thumbnail((340,338));x=(j%4)*360+(360-im.width)//2;y=(j//4)*370+22
            canvas.paste(im,(x,y));draw.text(((j%4)*360+12,(j//4)*370+4),str(start+j+1),fill='black')
        canvas.save(O/f'final-contact-{start+1:03}.jpg',quality=88)
    labels=['7.18 Fixed public','Table 7.12']+[x['kind']+' '+x['number']+' ' for x in json.loads((O/'Integration_Record.json').read_text('utf-8'))['caption_changes']]
    matches={k:[] for k in labels}
    for i,p in enumerate(pages,1):
        text=p.extract_text() or ''
        for k in labels:
            if k in text:matches[k].append(i)
    result={'pages':count,'changed_text_pages':matches,'images':len(files),'renderer':'Hidden Word COM, bundled Poppler85dpi; physical page numbers.'}
    (O/'Final_Rendered_Pages.json').write_text(json.dumps(result,indent=2)+'\n','utf-8')
    print(json.dumps(result))
if __name__=='__main__':main()
