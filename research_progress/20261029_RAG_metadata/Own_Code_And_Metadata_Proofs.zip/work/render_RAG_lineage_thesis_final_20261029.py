from pathlib import Path
from PIL import Image,ImageDraw
from pypdf import PdfReader
import subprocess,json
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_RAG_lineage_20261029'
def main():
    out=O/'render_final';assert not out.exists();out.mkdir()
    pdf=O/'Integrated_Thesis_QA.pdf';pages=PdfReader(pdf).pages
    count=json.loads((O/'Pagination_Record.json').read_text('utf-8-sig'))['pages'];assert len(pages)==count
    exe='C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
    subprocess.run([exe,'-r','85','-png',str(pdf),str(out/'page')],check=True,timeout=360,creationflags=subprocess.CREATE_NO_WINDOW)
    files=sorted(out.glob('page-*.png'));assert len(files)==count
    for start in range(0,count,24):
        c=Image.new('RGB',(1440,2220),'#cbd0d4');draw=ImageDraw.Draw(c)
        for j,f in enumerate(files[start:start+24]):
            im=Image.open(f).convert('RGB');im.thumbnail((340,338));x=j%4*360+(360-im.width)//2;y=j//4*370+22
            c.paste(im,(x,y));draw.text((j%4*360+12,j//4*370+4),str(start+j+1),fill='black')
        c.save(O/f'final-contact-{start+1:03}.jpg',quality=88)
    needles=['2.21 Citation','4.8 Archived','5.10 Source','The manuscript reports stronger','[36] T. Gao','[37] C. Niu']
    matches={n:[] for n in needles}
    for i,p in enumerate(pages,1):
        t=p.extract_text() or ''
        for n in needles:
            if n in t:matches[n].append(i)
    detail=sorted({p+j for a in matches.values() for p in a for j in [-1,0,1,2] if 1<=p+j<=count}|{5,6,7,8})
    for p in detail:
        subprocess.run([exe,'-f',str(p),'-l',str(p),'-r','130','-png','-singlefile',str(pdf),str(out/f'detail-{p:03}')],check=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    result={'pages':count,'matches':matches,'detail_pages':detail,'overview_page_count':len(files),'renderer':'Hidden Word COM + bundled Poppler; all pages and selected details'}
    (O/'Final_Rendered_Pages.json').write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps(result))
if __name__=='__main__':main()
