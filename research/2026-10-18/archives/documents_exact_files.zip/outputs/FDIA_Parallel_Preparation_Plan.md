# FDIA-style thesis extension: preparation alongside reviewer experiments

Prepared 7 October 2026; subsequent direct user authorization now permits actual historical security development alongside existing reviewer jobs. See [the current implemented development protocol](security/Experiment_Protocol.md) for completed CPU trials, authentic retrieval, checked prompt budgets and the single queued real-model pilot. Earlier future-tense readiness statements below are retained as the original broader proposal, not current implementation status. Full evaluation still requires validated adapters and audited reviewer integration. Archived instructions supply background, not independent user authorization.

## Latest priority: PowerGridQA retrieval first

The user now prioritizes the same frozen LLM without versus with PowerGridQA access, and asks about deterministic versus learned recovery under FDIA. Use the precise treatment names **PowerGridQA retrieval off/on at inference**; neither arm changes weights, and the incomplete final-adapter training lineage prevents asserting that the model has never encountered related material.

The initial core experiment fixes the existing execution controls. Compare these three planning methods under matched clean and corrupted observations: (1) D-SE, the specified deterministic portfolio, (2) standalone HG-VF with retrieval off, and (3) the same HG-VF architecture with retrieval on. PowerGridQA is not applicable to D-SE. Preserve its two constituent trajectories and charge their costs. A new deterministic observation adapter must first prove clean equivalence and actual reachability of the declared attack channel; this arm is not yet implemented.

First establish the 2×2 LLM comparison: retrieval off/on crossed with clean/attacked observations. Both attacked results alone are insufficient: compare each method's attacked-minus-clean degradation, then compare those paired degradations. For a lower-is-better metric such as residual UV, this is `(attacked UV - clean UV)_retrieval_off - (attacked UV - clean UV)_retrieval_on`; positive values indicate smaller observed degradation with retrieval. Failures remain explicit and are not zero-imputed. Final inference uses matched outage-family units and repeated attack seeds, not individual templates as independent grid cases.

Then report the corresponding HG-SE portfolios with their common DFF fallback, using only DFF outcomes generated under the exact same security condition and verified identity. Charge all branches even when results are shared. Do not reuse a clean DFF trajectory as an attacked DFF outcome if its inputs changed. Standalone proposer behavior and portfolio containment answer different questions; fallback can mask learned-branch failure. Keep zonal/central architecture fixed within the retrieval comparison; do not attribute an architecture change to the dataset.

Keep the PowerGridQA corpus clean during this first FDIA-style observation experiment. Knowledge poisoning is a later, separately labeled test. Added mediation arms C/D from section 6 follow as defense attribution after the retrieval-first core, rather than multiplying every factor in the first campaign. Include a bounded neutral/distractor-context sensitivity if practical, because retrieval adds prompt tokens; match its token budget without displacing physical observations or treating irrelevant text as a beneficial defense.

**Deterministic fairness:** a prompt-only attack has no input path to ordinary DFF/D-SE. Its unchanged outcome is a protected-reference result, not evidence that deterministic control resists the same compromised measurements. For the attacked deterministic comparison, deliver the same corrupted observation realization to each planner through a declared adapter, allow the same protected physics-service capability where intended, and disclose every remaining true-state dependency. Preserve true simulator state for evaluation. A copied `res_bus` edit that a fresh PF overwrites does not establish a faithful compromised-measurement experiment. Compare protected-verifier and shared-corrupted-belief settings separately.

**Dataset discovery:** original `C:\Users\HOME\Downloads\PowerGridQA-main.zip` and `PowerGridQA-Dataset.zip` exist and both pass ZIP CRC checks. Their hashes, members and initial schema inspection are recorded in `powergridqa_archive_inventory.json`. The published paper's data-availability section links [Hannaancode/PowerGridQA](https://github.com/Hannaancode/PowerGridQA); the saved citation/license identify the repository and CC BY 4.0. The two theory files differ. Some files named JSONL include headings and multi-line material, so a one-record-per-line parser does not recover the complete corpus. Validate source-preserving parsing, record identity, duplication, actual counts and version correspondence before freezing retrieval. Do not silently discard records, repair answers, or claim the README's 28,852 entries have already been verified. No archived Python evaluation code was executed.

**Next preparation step:** resolve the authentic corpus version and parsing, retain source offsets/hashes and any unparsed material, then prepare a CPU retriever with actual QA-source IDs and a fixed development-only query set. Freeze retrieval k, serialization and relevance criteria before attacked evaluation. The corpus is located; the retriever and attack adapters are still pending. Existing reviewer jobs and the separate transfer recovery continue unchanged.

## 1. Maintain the current execution allocation

At this plan's inspection, the local AC reference has 33/62 completed records and the existing T4 campaign has 35/62 complete case/RNG pairs in the separate transfer-recovery folder. These are timestamped observations, not final outcomes. The original collector's 12-case counter is stale. Its recovery downloader already exists; do not start another.

Keep the T4 on the running central/zonal experiment and keep the PC CPU on AC optimization. Use only small file reads, design work, and lightweight preparation alongside them. Do not install into their environments, alter scientific sources, write to their case/status directories, allocate a second GPU, or publish recovered files while the original collector is active. Final reviewer integration remains a separate prerequisite.

Two Google credential profiles do not guarantee two GPUs or a reset time. A future attack run uses one actually available runtime with independent ownership and outputs; there is no automatic account rotation. Standalone observation transformations, schema checks, hashing, replay and statistics use CPU. Frozen-model inference uses GPU under the validated execution implementation. Pilot measurements determine the eventual allocation, rather than an assumed completion time.

## 2. Freeze the research question and claim boundary

Question: How do falsified numerical observations change the frozen proposer’s choices and useful recovery, and how much harmful behavior is contained by the existing controller versus ordinary explicit execution controls? A second question measures the benefit and susceptibility of actual PowerGridQA retrieval, once that integration exists.

The first experiment is corrupted-observation / FDIA-style input testing. The recovered controller uses simulator states and prompt summaries; it does not provide a recovered measurement model, estimator and bad-data detector. Conventional stealthy state-estimation FDIA requires those components and appropriate residual-based evaluation. The foundational study explicitly attacks state estimation: [Liu, Ning and Reiter, CCS 2009](https://reitermk.github.io/papers/2009/CCS1.pdf). Do not describe arbitrary voltage edits as a reproduction of that attack.

Retrieval poisoning is a separate information channel: [PoisonedRAG, USENIX Security 2025](https://www.usenix.org/conference/usenixsecurity25/presentation/zou-poisonedrag). It is not sensor FDIA. No new estimator, retraining, grid, or real infrastructure target is included in this plan.

## 3. Map the actual observation and trust boundaries now

The zonal prompt is built by the recovered `build_two_best_prompt_v2` and query function in `work/e/audit/run_reflection_v4_safety_envelope.py`. The new central observation builder is in `work/central_ablation.py`. Preserve both campaign sources. Implement future adapters in a separate security workspace, with explicit labels as new code.

Audit every input derived from observations: individual voltages, extrema, undervoltage counts/lists, worst bus, severity instructions, candidate lists, and feedback. Recompute untrusted summaries consistently from an attacked observation copy; do not accidentally expose clean values through another field. Identify any protected candidate restriction, termination test, refinement and fallback that still uses true state, and credit that protection explicitly.

Loads and topology are not automatically available attack channels merely because they exist in pandapower. Include them only after identifying an actual input interface or explicitly adding and evaluating a new one. A notes field for adversarial instructions is likewise a new extension, not a recovered feature.

Maintain separate objects: immutable scenario/base inputs, mutable true simulator state, untrusted observation copy, verification state, and proposed action. An attack changes only the declared observation copy. Hash and trace those identities. Protect trusted policy and dispatcher identity; an LLM-supplied identity is not authentication.

## 4. Specify the initial bounded attack suite

| Family | Controlled simulation modification | Required comparison |
|---|---|---|
| Voltage bias | Raise or lower permitted voltage observations within a declared magnitude bound, with derived untrusted summaries updated | Clean input and matched nonadversarial measurement-noise control |
| Sparse voltage falsification | Corrupt a fixed budget of readings in one declared zone; target selection uses a prespecified rule | Identical target/perturbation budgets for every controller arm |
| Observation replay | Supply a previously recorded observation from the same development/evaluation episode | Record replay age and exactly which metadata are trusted or forgeable |

Proposed development-only magnitudes are 0.01 and 0.03 p.u.; proposed sparse budgets are one and three readings. These are starting design choices, not literature-derived operating tolerances or frozen evaluation parameters. Check applicability and coverage on historical development states, then lock final budgets and seeds before attacked evaluation. Do not select parameters to make one defense win.

Replay requires an actual earlier recorded state. Do not fabricate a missing historical snapshot. A test of authenticated freshness differs from replay with attacker-forgeable timestamps; report them separately. Treat nonadversarial noise as a fault control that can also degrade decisions, rather than assuming it is harmless.

## 5. Choose development and evaluation inputs without modifying the bank

Use existing historical scenarios outside the 62-case bank for development, including the two already recovered historical load-1.25/load-1.5 cases. They are not new scenarios or new physical assets.

Propose 12 evaluation operating points drawn by a written deterministic rule from six frozen contingency families at both load levels. Select using initial severity, fully served/finite eligibility, and zone coverage, without inspecting attack or defense outcomes. Keep the original 62-case bank intact; the security manifest references its scenario hashes. Preserve excluded/invalid IDs and reasons, and make no all-62 security coverage claim.

Reviewer results have already been inspected. Disclose that timing; this is a prespecified new attack evaluation on known clean cases, not a fully blinded new physical dataset. A small family-clustered sample does not establish arbitrary-grid generalization.

## 6. Compare controls and retrieval fairly

Start development without retrieval so observation handling and true-state accounting can be checked independently. Then, after the real corpus and retriever are available, use the archived plan's matched factorial:

| Arm | Frozen LLM information | Execution controls |
|---|---|---|
| A | No PowerGridQA retrieval | Faithful existing HierGrid checks, verifier and fallback |
| B | PowerGridQA retrieval | Same existing controls |
| C | No PowerGridQA retrieval | Existing controls plus ordinary explicit mediation |
| D | PowerGridQA retrieval | Same added controls as C |

Added mediation must enforce the trusted caller’s operation/target policy, finite numeric/resource limits and exact current state/action binding at the sole execution path. Where the original serial controller already satisfies a requirement, report that fact. Do not invent a vulnerability or weaken the primary baseline. If a proposed assurance layer has no material behavioral difference from ordinary mediation, do not call another nominal arm a novel defense.

Retrieval serialization, k, filters, corpus version and token-budget handling must be fixed on development inputs. Keep the model and numerical controls frozen. Record prompt lengths and inference costs. A clean retriever must demonstrably return actual records with source IDs; an empty stub is not a RAG arm. In the files inspected for this planning step, the published paper and integration proposal are present; the actual corpus/retrieval pipeline has not been established. Locate and verify the original corpus before B/D; do not generate substitute QA assets.

Evaluate retrieval poisoning only within retrieval-enabled arms against their clean-corpus controls. No-retrieval arms have no poisoned-corpus channel, so mark it not applicable. Do not count poisoned text rejected by a schema as a real-model prompt-injection result unless the real frozen model actually received it.

## 7. Separate protected verification from shared corrupted beliefs

Primary setting: only proposer observations are attacked. The verifier, refinement, fallback and terminal evaluator use independently protected true state where the recovered implementation requires it. Report the result as containment under that assumption; it does not detect FDIA or recover truth from compromised sensors.

Secondary bounded stress setting: explicitly model a verifier relying on the same false belief and evaluate any released action on a separate true simulator copy. This adapter is new work and must first be validated. Simply editing `res_bus` is insufficient: a fresh AC solve can overwrite it. Any internally consistent surrogate inputs used for verification must be logged and identified as a stronger belief/model-corruption threat. Do not present this as an already-existing runner or conventional stealthy measurement attack.

If the shared-corruption adapter cannot be implemented and validated faithfully, report that experiment as unresolved; do not substitute fake outcomes. All physical effects must be evaluated against true state, including failures and already-existing slack-limit violations.

## 8. Use small pilot decision tests before full trajectories

First run development checks on copied observations without GPU inference: source non-mutation, corruption budget, summary consistency, reproducibility, state separation and action-binding checks. These are software tests, not LLM/security-performance evidence. Keep this CPU work bounded so the existing AC campaign remains the priority.

After reviewer closure, measure a small real-model pilot to estimate generation/PF time and confirm instrumentation. The initial evaluation can use 12 states × (clean + three attack families × two magnitudes) × four arms = 336 single-decision trials. Matched noise controls add 96 trials if both magnitudes are tested in all arms. With the original four-primary-slot/one-repair allowance, the worst-case generation count is eight per decision trial; actual calls are measured. Do not reserve GPU time from these counts without pilot timing. Develop and lock the full factorial only if the corpus integration exists.

Single-decision results establish proposal/release behavior only. They cannot establish final recovery success. Use a separately prespecified compact multi-step subset, matched clean/attacked conditions and both load levels, to measure residual UV and portfolio utility. Freeze its episode count, seeds and branch order before execution, based on pilot cost rather than observed defense wins. No surrogate/fake LLM outputs may replace actual inference in claims about observation attacks on the model.

Do not reuse clean reviewer trajectories as attacked trajectories. Their files can verify clean reference identity; security-context additions require fresh matched clean controls. For a one-step post-proposal enforcement comparison, a common saved raw proposal can be replayed only if the LLM inputs really are identical. Once feedback or actions diverge, run each closed-loop branch independently.

## 9. Record meaningful security and utility outcomes

Per attempted trial: original and corrupted observation hashes; allowed/readable target set; realized corruption budget; source/corpus IDs; real-model raw response; normalized proposal; policy decision; verifier-state/action identity; true-state evaluation; fallback use; elapsed PF/inference/total time; token counts; failure stage and reason.

Report attempted/applicable/generated/proposed/authorized/released counts separately. Define attack success before evaluation as a released unauthorized action or a predefined adverse true-state consequence relative to the matched clean run. Separately measure changed proposals, harmful attempts blocked, benign false rejection, extra support/actions, clean-to-attacked recovery loss and deterministic fallback retention. No-response and nonconvergence outcomes remain in the denominator and cost ledger.

Use the same strict physical metrics plus existing roundoff diagnostics. Distinguish an attack-induced violation from the frozen clean baseline’s known slack-limit violations. A failure to finish UV recovery is degradation; it does not automatically mean a harmful action was released. Define each denominator, and report attack families as correlated repeats within operating points/outage families. Final uncertainty is paired and family-aware; it is not computed from individual prompt templates as independent grids.

## 10. Concrete sequencing and readiness gates

**Now, while CPU/GPU jobs continue:** finalize this protocol, map actual input interfaces, locate the authentic corpus, draft manifests and trace schemas, and prepare small CPU-only copy/consistency fixtures in a separate workspace. No attack campaign is launched by this plan.

**After the current GPU finishes:** preserve its complete case/RNG outputs and safely integrate the staged recovery only after the original collector has stopped. Complete physical replay and central analysis. Keep the GPU released while standalone CPU audits or the remaining AC reference run finish.

**After all four reviewer experiments and the final package are verified:** validate separate security adapters on historical cases, run the measured real-model pilot, freeze the attack protocol and evaluation subset, then run the bounded security campaign on one available GPU. CPU analysis and reports follow each complete batch.

**Before security claims:** require true/observed/verification-state separation, faithful baseline, actual retrieval for B/D, real inference records, independently checked released actions and full failure/cost accounting. Report protected-verifier and shared-corruption results separately. Conventional stealthy FDIA, general FDIA detection and universal security remain outside these claims.

Current dependencies: reviewer completion; stopped original collector and verified staged integration; observation adapter not implemented; located corpus version/parsing and retrieval not yet validated; mediation and shared-corruption adapters not implemented. None requires interrupting the current experiments or requesting another credential now.
