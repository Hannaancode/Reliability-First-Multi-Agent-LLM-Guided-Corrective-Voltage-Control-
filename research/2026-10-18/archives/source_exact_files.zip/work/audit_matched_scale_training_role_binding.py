"""FIT-only static/source-label compatibility review; zero new scientific calls."""
import ast
import gzip
import hashlib
import json
import time
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from prepare_matched_scale_20261011 import digest

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'outputs/matched_scale_20261011'
OUT = BASE/'training_role_binding'
assert not OUT.exists(), 'Preserve original review; no duplicate execution'
OUT.mkdir()
began = time.perf_counter()
source = Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2a_extract_zone_data_corrected.py')
data = Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2b_training_inputs.zip')
fitpath = ROOT/'outputs/critical_research_reset_20261010/original_role_numeric_gate_20261011/execution/FIT_Current_Packets_And_Targets.json.gz'
member = 'hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'
sha = lambda b: hashlib.sha256(b).hexdigest()
sourcebytes = source.read_bytes()
with zipfile.ZipFile(data) as z:
    raw = z.read(member)
assert sha(raw) == '7b22162d0abd92ccb64473fcef5bb300ee12416ce22ea6ce03e60fefaa9154eb'
protocol = {
    'declared_at_utc': datetime.now(timezone.utc).isoformat(),
    'questions_fixed_before_counts': [
        'Does the referenced original extractor return all eight richer measurement groups?',
        'Which upper-voltage threshold and score does its teacher policy use?',
        'For the exact340 existing FIT identities/first-row teachers ONLY, how many saved non-null actions have known saved AFTER maximum above unchanged1.05+1e-8? Retain missing AFTER as UNKNOWN.',
    ],
    'source_file_sha256': sha(sourcebytes), 'FIT_file_sha256': sha(fitpath.read_bytes()),
    'raw_TRAIN_member_sha256': sha(raw),
    'no_HELD_predictions_or_results_inspected': True,
    'read_only_reference_source_not_proof_of_historical_execution': True,
    'no_performance_gate_training_source_or_label_changes': True,
    'new_model_PF_optimizer_controller_forecast_solver_converter_calls': 0,
}
(OUT/'Protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf8')
tree = ast.parse(sourcebytes.decode('utf8'))
nodes = {n.name:n for n in tree.body if isinstance(n, ast.FunctionDef)}
assignments = {n.targets[0].id:ast.literal_eval(n.value) for n in tree.body
               if isinstance(n, ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0], ast.Name)
               and n.targets[0].id in {'VMIN','VMAX','SAFE_VMAX','SHUNT_CANDIDATES_MVAR'}}
assert assignments['SAFE_VMAX'] == 1.06
observer = nodes['extract_zone_state']
ret = [n for n in ast.walk(observer) if isinstance(n, ast.Return) and isinstance(n.value, ast.Dict)]
assert len(ret)==1
keys = sorted(k.value for k in ret[0].value.keys)
required = {'bus_voltages','total_load_mw','total_load_mvar','sgen_status','storage_status','gen_status','boundary_voltages','tie_line_flows'}
assert required <= set(keys)
with gzip.open(fitpath, 'rt', encoding='utf8') as f: fit=json.load(f)
assert len(fit)==340
wanted={(r['world_sha256'],r['input_sha256']):r for r in fit}
teachers={}
for index,line in enumerate(raw.decode('utf8').splitlines()):
    r=json.loads(line); current=json.loads(r['messages'][1]['content'])
    packet={'zone':current['zone'],'local_measurements':current['local_measurements']}
    key=(sha(str(current['scenario_id']).encode()),digest(packet))
    if key in wanted and key not in teachers:
        target=json.loads(r['messages'][2]['content'])
        assert packet==wanted[key]['packet'] and target['proposed_action']==wanted[key]['action']
        teachers[key]=(index,target)
assert len(teachers)==340
counts=Counter(); rows=[]
for key,(index,target) in sorted(teachers.items()):
    action=target.get('proposed_action'); v=target.get('verification') or {}
    after=v.get('new_global') or {}
    vmax=after.get('vm_max_pu')
    known=isinstance(vmax,(int,float)) and not isinstance(vmax,bool)
    if action is None: category='NULL_local_action'
    elif not known: category='non_NULL_saved_after_max_UNKNOWN'
    elif vmax > 1.05+1e-8: category='non_NULL_saved_after_exceeds_current_common_upper'
    else: category='non_NULL_saved_after_at_or_below_current_common_upper'
    counts[category]+=1
    counts['verdict_'+str(v.get('verdict'))]+=1
    rows.append({'world_sha256':key[0],'input_sha256':key[1],'first_raw_row_index':index,
                 'category':category,'saved_after_max':vmax,'saved_verdict':v.get('verdict')})
result={
    'completed_at_utc':datetime.now(timezone.utc).isoformat(), 'identity_binding_passed':True,
    'exact_FIT_identities':340,'FIT_worlds':len({k[0] for k in teachers}), 'counts':dict(counts),
    'reference_extractor_has_required_eight_groups':True, 'reference_teacher_constants':assignments,
    'reference_observer_AST_sha256':sha(ast.dump(observer).encode()),
    'reference_teacher_AST_sha256':sha(ast.dump(nodes['generate_corrective_action']).encode()),
    'reference_teacher_score': '(local UV count falls, local minimum-voltage gain, negative capacitive size)',
    'serving_hazards':[
        'Legacy device-name dictionary keys can collide and overwrite devices; idx remains in retained rows.',
        'Reference extractor has missing-result fallbacks and skips unavailable bus voltages; shape alone cannot certify full fresh solved measurements.',
        'Referenced historical script is not certified as exact executed producer of every augmented TRAIN row.',
    ],
    'limitations': 'Saved AFTER summaries are archived labels, not new replay or current-action safety certificates. No inference about missing AFTER, future trajectories, held performance or universal feasibility.',
    'decision': 'Keep paired fixed learning/primary gate unchanged. Require a separately bound actual rich-current observer and original common1.05+1e-8 protection before any physical study. Teacher imitation alone is not D-SE superiority.',
    'new_model_PF_optimizer_controller_forecast_solver_converter_calls':0,
    'HELD_outputs_inspected':0, 'seconds':time.perf_counter()-began,
}
(OUT/'FIT_Label_Upper_Band_Binding.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
(OUT/'Results.json').write_text(json.dumps(result,indent=2),encoding='utf8')
(OUT/'Results.md').write_text(
    'The referenced original extractor supplies all eight rich-current groups, but has missing-result fallbacks and legacy name-key collisions. It must not be imported as a fresh complete observer without explicit solved-result/identity binding.\n\n'
    'Its reference teacher accepts global maximum voltage up to1.06 and prioritizes local minimum-voltage gain. The current common protection remains1.05+1e-8. Exact340 FIT first-row label counts: '+json.dumps(dict(counts))+'. These are saved summaries, not newly verified physical outcomes. Missing AFTER stays UNKNOWN.\n\n'
    'The running paired learning protocol and primary gate remain unchanged. Better teacher-command matching is useful development evidence, but cannot prove protected physical recovery or D-SE superiority. No HELD outputs inspected; zero new model/PF/optimizer/forecast/solver calls.\n',encoding='utf8')
entry={
    'event_id':'matched_scale_FIT_teacher_physical_binding_review_20261011',
    'method':'Static original eight-group observer/teacher review and exact340 FIT first-row saved-label binding; no model or physical reruns.',
    'result':'Exact identity binding PASS. Reference teacher upper1.06 differs from common protection1.05+1e-8. Saved FIT categories: '+json.dumps(dict(counts)),
    'improvements':'Located original richer observation producer and made teacher-versus-protected-control mismatch explicit before any new physical integration.',
    'limitations':result['limitations']+' Original producer execution provenance and fresh complete observer remain unproved. No LLM advantage follows.',
    'decision':result['decision'],
    'sources':['outputs/matched_scale_20261011/training_role_binding/Protocol.json','outputs/matched_scale_20261011/training_role_binding/Results.json','outputs/matched_scale_20261011/training_role_binding/Results.md'],
}
(OUT/'Progress_Entry.json').write_text(json.dumps(entry,indent=2),encoding='utf8')
print(json.dumps(result))
