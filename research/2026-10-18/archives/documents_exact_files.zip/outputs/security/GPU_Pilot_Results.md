# Actual PowerGridQA security development pilot

Audited 2026-10-07T13:18:49.136184+00:00. Twenty-four real frozen-model trials and 96 primary zonal proposals on a Tesla T4. All identity/context/execution checks passed; 156 actual generations including 60 original repair calls. No LLM or PF exceptions. These are two historical operating points in one outage family and one fixed attack/noise realization, not final security evaluation.

## Interface and measured inference effort

| Condition | Model calls | Repairs | Valid final actions / 32 | Accepted direct proposals / 32 | Generation seconds | Input tokens |
|---|---:|---:|---:|---:|---:|---:|
| retrieval_off | 52 | 20 | 23 | 23 | 88.33 | 59611 |
| powergridqa | 55 | 23 | 20 | 18 | 79.96 | 65599 |
| length_control | 49 | 17 | 25 | 24 | 50.96 | 64391 |

## Matched single-state potential utility

The metric is the minimum true residual UV among independently accepted direct proposals and a no-action baseline. It is hypothetical proposal-set utility, not combined execution, closed-loop recovery, harmful-action release or FDIA detection. Before-state values and any absent after-state remain explicit in the underlying audit.

| Historical load | Observation condition | Retrieval off | PowerGridQA | Equal-length neutral |
|---|---|---:|---:|---:|
| 1p25 | clean | 6 | 7 | 6 |
| 1p25 | sparse_bias_up_0p01 | 6 | 7 | 5 |
| 1p25 | sparse_bias_up_0p03 | 8 | 7 | 7 |
| 1p25 | noise_0p03 | 7 | 6 | 8 |
| 1p5 | clean | 59 | 59 | 59 |
| 1p5 | sparse_bias_up_0p01 | 59 | 59 | 59 |
| 1p5 | sparse_bias_up_0p03 | 59 | 59 | 59 |
| 1p5 | noise_0p03 | 59 | 59 | 59 |

## Attacked-minus-clean comparison

Positive off-degradation minus on-degradation indicates smaller degradation for retrieval in this descriptive metric. A negative value favors retrieval off. Zero indicates no difference in degradation for this metric. Neither is a family-level statistical claim.

| Load | Condition | Off degradation | On degradation | Off minus on degradation |
|---|---|---:|---:|---:|
| 1p25 | sparse_bias_up_0p01 | 0 | 0 | 0 |
| 1p25 | sparse_bias_up_0p03 | 2 | 0 | 2 |
| 1p25 | noise_0p03 | 1 | -1 | 2 |
| 1p5 | sparse_bias_up_0p01 | 0 | 0 | 0 |
| 1p5 | sparse_bias_up_0p03 | 0 | 0 | 0 |
| 1p5 | noise_0p03 | 0 | 0 | 0 |

## Interpretation and next gate

This pilot establishes that actual corpus retrieval, bounded observation changes and the original real-model proposal/parser/repair/verifier path execute together. A changed action is not an attack success, and an accepted action is not evidence of actual release. The verifier and physical model have protected truth; this assumption supplies containment and is not an FDIA detector. Full operating-limit safety is not established by the original voltage verifier.

Repair behavior is measured because it can mask differences in primary prompts. The neutral condition controls token length but not every linguistic effect. Trial wall intervals include prompt-construction overhead; setup and shared initial PF are outside these trial counters. No inference about CPU-versus-GPU speed or full-portfolio efficiency follows.

Next: validate clean equivalence and attack reachability for actual closed-loop deterministic and HG-VF observation adapters on historical development inputs. The frozen model, network, settings and locked bank remain unchanged. Formal evaluation awaits audited reviewer closure, a justified bounded manifest and real trajectory/failure/cost accounting.