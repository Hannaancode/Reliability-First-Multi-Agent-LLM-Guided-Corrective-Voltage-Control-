"""Seal/audit local Stage3 partials; no experiment, cloud or solver calls.

Missing executions remain UNKNOWN, never manufactured timeout/failure rows.
Full external completion audit is not bypassed by this preservation audit.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];PARENT=ROOT/'outputs/llm_value_stage3_development'
OUT=PARENT/'partial_preservation_audit'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not OUT.exists(),'Preserve completed partial audit'
    status=read(PARENT/'gpu_launch_repair_v2_status.json')
    assert status['stage']=='stage3_owner_blocked_or_interrupted'
    OUT.mkdir();protocol=read(PARENT/'protocol.json')
    for path,h in {**protocol['source_sha256'],**protocol['frozen_source_sha256']}.items():assert sha(ROOT/path.replace('\\','/'))==h
    expected={c['scenario_id']+'__'+arm for c in protocol['scenarios'] for arm in protocol['arms']}
    paths=list((PARENT/'staged/remote/trajectories').glob('*.json'));records={p.stem:read(p) for p in paths}
    assert records.keys()<=expected and len(records)==status['actual_preserved_trajectory_records']
    table=[];committed_actions=0;actual_generations=0
    for identity,row in records.items():
        assert row['trial_id']==identity and row['protocol_sha256']==sha(PARENT/'protocol.json')
        case=next(c for c in protocol['scenarios'] if c['scenario_id']==row['scenario_id'])
        assert row['scenario_sha256']==case['sha256'] and row['base_network_preserved']
        assert row['genuine_new_live_inference_only']
        for phase,counts in row['actual_incremental_costs']['PF'].items():
            assert counts['PF_attempts']==counts['PF_returns']+counts['PF_exceptions']
        actual_generations+=row['actual_incremental_costs']['generation']['generation_entries']
        metrics=None
        if row['status']=='complete':
            assert row['failure'] is None and row['independent_replay']['passed']
            record=row['record']
            result=record.get('original_function_result',record)
            metrics=result['final_metrics'];actions=result['executed_actions'];committed_actions+=len(actions)
        table.append({'trial_id':identity,'scenario_id':row['scenario_id'],'arm':row['arm'],'status':row['status'],
            'actual_final_metrics':metrics,'complete_record_replay_passed':row['status']=='complete',
            'file_sha256':sha(PARENT/'staged/remote/trajectories'/f'{identity}.json')})
    missing=sorted(expected-records.keys())
    for identity in missing:
        table.append({'trial_id':identity,'status':'not_preserved_execution_unknown','actual_final_metrics':None})
    grouped={c['scenario_id']:{'actual_preserved':sum(r['scenario_id']==c['scenario_id'] for r in records.values()),
        'actual_complete':sum(r['scenario_id']==c['scenario_id'] and r['status']=='complete' for r in records.values())} for c in protocol['scenarios']}
    artifact_manifest={p.relative_to(PARENT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)}
        for p in (PARENT/'staged').rglob('*') if p.is_file()}
    audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'actual_preserved_trajectory_count':len(records),
        'planned_trajectory_count':80,'actual_status_counts':dict(Counter(r['status'] for r in records.values())),
        'missing_declared_identities':missing,'missing_execution_classification':'unknown; no remote log/exit/summary/manifest available after assignment loss',
        'scenario_counts':grouped,'preserved_incremental_generations':actual_generations,
        'preserved_complete_committed_actions':committed_actions,'actual_preserved_staged_artifact_hashes':len(artifact_manifest),
        'exact_preserved_case_source_identity_and_reported_replay_checks_passed':True,
        'full_continuous_action_oracle_and_campaign_cost_audit_performed':False,
        'scientific_scope':'Local byte/identity/reported-replay preservation, not original full Stage3 completion or superiority',
        'zero_new_model_calls':True,'zero_new_PF_calls':True,'zero_allocations':True,
        'full_campaign_complete':False,'LLM_superiority_established':False,
        'frozen_assets_and_sources_unchanged':True,'automatic_resume_of_original_or_missing_records_authorized_by_this_audit':False,
        'availability_check':'outputs/resource_checks/20261008_104729.json: all profiles authenticated, zero assignments, reportedT4eligible; original same-assignment GET inaccessible',
        'resource_limit_cause_known':False,'no_runtime_reallocated_or_old_experiment_restarted':True}
    for name,data in [('Preserved_Partial_Artifact_Manifest.json',artifact_manifest),('Declared_80_Identity_Table.json',table),('audit.json',audit)]:
        with (OUT/name).open('x') as f:json.dump(data,f,indent=2)
    print(json.dumps({k:audit[k] for k in ['actual_preserved_trajectory_count','actual_status_counts','missing_declared_identities','preserved_incremental_generations','scenario_counts']}))
if __name__=='__main__':main()
