"""Independent source-order/finite-input check of the conditional UV-stop bound."""
import ast
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/paper_uv_stop_public13_ceiling_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def main():
    result = read(P / 'Conditional_Source_And_Cohort_Ceiling.json')
    path = R / 'work/e/audit/run_reflection_v4_safety_envelope.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == result['source_sha256']
    tree = ast.parse(path.read_text(encoding='utf-8'))
    for name in ['run_one_scenario_two_best_v2', 'run_one_scenario_no_llm_fallback_first']:
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        loop = next(n for n in function.body if isinstance(n, ast.For))
        guard = loop.body[2]
        assert isinstance(guard, ast.If) and not guard.orelse
        test = guard.test
        assert isinstance(test, ast.Compare) and len(test.ops) == 1 and isinstance(test.ops[0], ast.Eq)
        assert isinstance(test.left, ast.Subscript) and ast.unparse(test.left) == "current['uv_count']"
        assert isinstance(test.comparators[0], ast.Constant) and test.comparators[0].value == 0
        assert len(guard.body) == 2 and isinstance(guard.body[1], ast.Break)
        # No proposal/application/fallback is allowed before this dominating stop.
        calls = [n for statement in loop.body[:2] for n in ast.walk(statement) if isinstance(n, ast.Call)]
        assert [ast.unparse(c.func) for c in calls] == ['runner.rescue.grid_metrics', 'print']
    root_path = R / 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json'
    assert hashlib.sha256(root_path.read_bytes()).hexdigest() == result['source_root_list_sha256']
    roots = read(root_path)['roots']
    possible = [r['seed'] for r in roots if min(r['all13_initial_vm']) < .95
                or all(.95 <= v <= 1.05 for v in r['all13_initial_vm'])]
    barred = [r['seed'] for r in roots if min(r['all13_initial_vm']) >= .95
              and max(r['all13_initial_vm']) > 1.05]
    assert len(possible) == 249 and len(barred) == 251
    assert sorted(possible + barred) == list(range(500)) and not set(possible) & set(barred)
    native = read(R / 'outputs/public13_native_cohort_assembly_20261021/Native_Cohort_Results.json')
    assert all(v['complete'] == 500 and v['full13_band_restored_on_complete'] > len(possible)
               for v in native['methods'].values())
    output = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_INDEPENDENT_EXACT_SOURCE_DOMINATING_UV_STOP_AND_ALL500_CONDITIONAL_BOUND',
              'conditional_upper': len(possible), 'barred_OV_only_inputs': len(barred),
              'all500_input_ids_partitioned': True, 'new_model_PF_optimizer_calls': 0,
              'producer_result_sha256': hashlib.sha256((P / 'Conditional_Source_And_Cohort_Ceiling.json').read_bytes()).hexdigest(),
              'reader_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'not_a_model_output_score_or_universal_impossibility': True}
    with (P / 'Independent_Conditional_Bound_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(output, f, indent=2)
    print(json.dumps(output))


if __name__ == '__main__':
    main()
