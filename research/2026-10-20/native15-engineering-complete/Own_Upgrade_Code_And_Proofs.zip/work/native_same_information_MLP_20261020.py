"""Fixed strong numeric control architecture; same435causalfields, no derivative/teacher feature."""
import torch
from torch import nn
class NativeMLP(nn.Module):
    def __init__(self):
        super().__init__();self.layers=nn.Sequential(nn.Linear(435,256),nn.SiLU(),nn.Linear(256,256),nn.SiLU(),nn.Linear(256,3))
        assert sum(p.numel() for p in self.parameters())==178179
    def forward(self,normalized_current_features):
        if normalized_current_features.ndim!=2 or normalized_current_features.shape[1]!=435 or not torch.isfinite(normalized_current_features).all():raise ValueError('Complete sameinformationcausalfeatures required')
        return torch.tanh(self.layers(normalized_current_features))*torch.tensor(.3,dtype=torch.float32,device=normalized_current_features.device)
