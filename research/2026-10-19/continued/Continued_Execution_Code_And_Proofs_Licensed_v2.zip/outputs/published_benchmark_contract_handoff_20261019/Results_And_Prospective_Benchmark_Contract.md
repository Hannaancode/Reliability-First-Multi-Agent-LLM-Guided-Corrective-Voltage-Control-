# Published benchmark: findings and exact next gates

PGLearn is a published source with an explicit118-bus test split. We downloaded one pinned author shard and extracted ALL first16 test rows in provider order, fixed before labels and with no filtering. Their inspected prefix is development, not unused confirmation. [Official dataset](https://huggingface.co/datasets/PGLearn/PGLearn-Small-118_ieee), [author toolkit](https://github.com/AI4OPT/PGLearn.jl).

The source has two different roles. `case/json` is ONE repeated base snapshot and its reference solutions. `input/*` and `ACOPF/primal/*` describe the different sampled test instances. Two independently implemented AC equation checks verify the ONE base solution. It has zero UV under0.95 and is useful for import integration, not a hard control win. Substituting it for the16 sampled targets would be invalid.

All16 sampled column representations exceed the fixed5e-6 native residual tolerance; their reactive-flow residuals are retained. No rows were dropped and no tolerance was relaxed. The sampled fields are float32, but their mismatch with the static base fields is NOT a rounding-identity proof: those fields concern different operating points. An initial reader making that assumption failed and is preserved. No claim that the publisher's dataset is invalid follows.

No model inference, power flow, OPF, training, optimizer, derivative or forecast call occurred in this intake and direct equation audit. This advances public source/role readiness; it does not complete public model testing or prove superiority.

## G2 next execution

1. Build a source-faithful importer using the ONE base snapshot for engineering only. Preserve all native branch, load, generator, shunt, angle, thermal and voltage constraints, exact index/units, reference and current solution fields. No generator/headroom reset or silent clamping.
2. Bind the sampled rows to their OWN demands, component statuses and targets. Keep all16 indices and strict failures. A separately prospective fixed physical reconstruction/validation protocol may be justified; never silently call a near-feasible sample certified, change tolerance, or select passing cases. No such solver campaign is launched by this document.
3. Freeze the actual current-only LOCAL/model input, legal action/domain/parser and protection contract before inference. Disclose any shunt stock/zone adaptation. Native OPF endpoints are not necessarily corrective-control opportunities. Do not count already-zero reference states as control wins.
4. Actual public model tests require fresh inference, native physical verification, equally informed controls and full costs. G2 remains open until those tests are complete.

## G3 source-backed comparison route

[PFDelta](https://github.com/MOSSLab-MIT/pfdelta) is a relevant published source for118-bus power flow, N/N-1/N-2 and near-infeasible regimes. Its author code and dataset revisions are pinned separately. Raw118 data have NOT been downloaded. Its native tasks predict power-flow solutions; our current model emits control commands. Published PF prediction errors cannot fairly be compared with our UV reduction.

A valid control benchmark must freeze one common physical/action/protection/information/budget setting. A published PFNet/CANOS predictor could be coupled to the SAME numerical action broker and physical verifier, with its inputs, native shunt semantics, normalization, checkpoints and training costs audited first. This would be an explicitly adapted comparison, not an unchanged published-control reproduction. Retain original DFF/DFF-ALT/unchanged DSE and full BOTH costs as primary controls.

The PFDelta authors disclose a March2026 correction to reactive/branch mismatch terms in CANOS-PF training loss. The pinned source is later, but numerical implementation fidelity must still be checked. Author test errors averaged over3seeds must not be equated with a one-run validation log. No baseline training or GPU allocation is launched from source discovery.

All six final goals remain open. No90% winning confidence, scientific novelty or incremental LLM contribution follows from input or software checks.
