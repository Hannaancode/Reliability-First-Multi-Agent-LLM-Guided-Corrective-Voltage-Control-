"""Actual saved-state cache boundary and complete cold registry, zero new science."""
import argparse,copy,hashlib,json,os,pickle,random,subprocess,sys,time
from pathlib import Path
import numpy as np,pandapower as pp
import verified_paid_cache_engine_v1_20261018 as binding
import paid_receding_referenced_commit_v2_20261018 as transport
import paid_receding_commit_and_history_v1 as old
from full_receding_paid_campaign_20261015 import R,read,put
from frozen_physics_loader import load_stack
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
B=R/'outputs/verified_paid_cache_engine_cold_20261018'
KEY='__VERIFIED_ARCHIVED_PAID_USE_REGISTRY_PREFIX__'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fixture_stack():
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');return runner,meta.get('zones',meta)
class Evidence:
    def __init__(self):self.costs={};self.events=[];self.allow=True
    def admit(self):
        if not self.allow:raise TimeoutError('No scientific execution allowed by expired fixture')
    def event(self,name,data):self.events.append((name,data))
def prevent_science():
    calls=[]
    def fail(*a,**k):calls.append(True);raise AssertionError('No new physics/model/forecast/solve in software cold gate')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,fail)
    return calls,fail
def engine(registry,evidence,runner,zones,out):
    return binding.VerifiedPaidDecisionEngine(out=out,evidence=evidence,runner=runner,zones=zones,cache=registry.cache,blocked=set(),contexts={},numeric_cost={},history=None,paid_forecasts={},use_registry=registry)
def cold():
    started=time.perf_counter();p=read(B/'Protocol.json')
    for name,h in p['source_sha256'].items():assert sha(R/name)==h
    calls,fail=prevent_science();request=read(B/'Cold_Request.json')
    state,history=transport.restore_complete(R/request['checkpoint'],request['receipt']);runner,zones=fixture_stack()
    anchor=state['paid_query_registry'][KEY]
    registry=binding.VerifiedPaidUseRegistry(R/anchor['path'],runner=runner,zones=zones,restore_anchor=anchor)
    evidence=Evidence();actual=engine(registry,evidence,runner,zones,B/'UNEXECUTED')
    key=request['primary_key'];row=registry.primary[key]['intent']['context']['candidate'];node={'net':state['net'],'cursor':state['cursor']}
    record=actual.certified_cached_record(node,row,key)
    assert record['receipt_id']=='ARCHIVED_'+binding.digest(key.encode())
    assert evidence.events[-1][0]=='archived_receipt_verified_before_policy_use'
    expected=read(B/'Expected_Record.json')
    assert {k:v for k,v in record.items() if k!='verified_use_reference'}==expected
    assert registry.anchor()['records']==anchor['records']+1
    checks={'exact_complete_saved_NET_cursor_rng_costs_registry':True,'actual_engine_source_bound_callback_after_cold':True,
        'all_old_physics_costs_and_unique_namespaced_receipt_identity_retained':True,
        'durable_new_verified_use_before_cache_record_returned':True}
    evidence.allow=False
    try:actual.certified_cached_record(node,row,key)
    except TimeoutError:checks['expired_admission_blocks_cached_use']=True
    else:raise AssertionError('Expired use accepted')
    # The old saved bound is preserved; this is not a scientific resume.
    original=old.restore(R/p['original_checkpoint']['checkpoint'],p['original_checkpoint']['receipt'])
    assert state['absolute_deadline_utc']==original['absolute_deadline_utc'] and state['costs']==original['costs']
    assert pickle.dumps(state['python_rng'])==pickle.dumps(original['python_rng']) and pickle.dumps(state['numpy_rng'])==pickle.dumps(original['numpy_rng'])
    assert transport.fields(state['net'])==old.fields(original['net'])
    checks['original_expired_bound_and_full_original_costs_not_reset']=True
    registry.close();assert not calls and time.perf_counter()-started<300
    put(B/'Cold_Result.json',{'status':'PASS_REAL_COLD_VERIFIED_CACHE_ENGINE_AND_COMPLETE_SAVED_STATE','checks':checks,'history_records':len(history),'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started})
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    request=read(R/'outputs/referenced_controller_factory_cold_capacity_v2_20261018/Cold_Request.json')
    oldreq=read(R/'outputs/full_receding_paid_campaign_20261015/actual/Result.json')['checkpoint_requests'][0]
    sources=[Path(__file__),Path(binding.__file__),R/'work/certify_archived_receipt_on_use_v1_20261018.py',R/'work/receding_paid_decision_engine_durable_v2.py',R/'work/receding_paid_admitted_referenced_runtime_v1_20261018.py']
    put(B/'Protocol.json',{'role':'PERUSE_VERIFIED_PAID_CACHE_ENGINE_DURABLE_COLD_SOFTWARE','source_sha256':{str(p.relative_to(R)):sha(p) for p in sources},
        'original_checkpoint':oldreq,'parent_bound_seconds':600,'cold_bound_seconds':300,
        'selection':'First original saved checkpoint and its already source-ordered certified primary receipt, plus first canonical warm receipt at original first endpoint; no reward/outcome filter.',
        'original_engine_source_inverse':binding.SOURCE_CERTIFICATE,'no_science_or_owner_launch_permission':True})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    calls,fail=prevent_science();runner,zones=fixture_stack()
    registry=binding.VerifiedPaidUseRegistry(B/'registry',runner=runner,zones=zones)
    # Import already completed exact native saved-result certification; do not
    # repeat that engineering call. The old CPU costs are retained in its ACK.
    original_ack=R/'outputs/archived_receipt_on_use_20261018/Actual_Receipt_ACK.json'
    assert read(R/'outputs/archived_receipt_on_use_20261018/Protocol.json')['source_sha256']==sha(R/'work/certify_archived_receipt_on_use_v1_20261018.py')
    registry.import_existing_ack(original_ack);primary=read(original_ack)['point_action_key']
    state,history=transport.restore_complete(R/request['checkpoint'],request['receipt'])
    assert point_key(state['net'],state['cursor'])==primary.split('|')[0]
    row=registry.primary[primary]['intent']['context']['candidate'];node={'net':state['net'],'cursor':state['cursor']}
    evidence=Evidence();actual=engine(registry,evidence,runner,zones,B/'UNEXECUTED')
    record=actual.certified_cached_record(node,row,primary);checks={'actual_cache_callback_and_fsynced_use_proof':True}
    assert evidence.events[-1][1]['receipt_id']==record['receipt_id'] and record['receipt_id']!=record['source_original_receipt_id']
    assert record['attributed_PF_calls']==read(original_ack)['old_attributed_PF_calls'] and record['attributed_solver_seconds']==read(original_ack)['old_attributed_solver_seconds']
    expected={k:v for k,v in record.items() if k!='verified_use_reference'};put(B/'Expected_Record.json',expected)
    before=registry.anchor()
    try:'not-in-lineage' in registry.cache
    except binding.UnknownLineageIdentity:checks['absent_identity_cannot_fall_into_newPF']=True
    else:raise AssertionError('Absent key treated as unexecuted')
    bad=copy.deepcopy(row);bad['q']+=1
    try:actual.certified_cached_record(node,bad,primary)
    except AssertionError:checks['wrong_causal_action_rejected_before_use']=True
    else:raise AssertionError('Wrong action accepted')
    assert before==registry.anchor()
    entry=read(R/'outputs/full_receding_paid_campaign_20261015/Protocol.json')['endpoints'][0]
    net,cursor,_=load_endpoint(entry);cursor=transport.initialize(net,build_current_domain(net,cursor,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
    point=point_key(net,cursor);warmkey=next(k for k in sorted(registry.archive.warm['cache']) if k.startswith(point+'|'))
    rows=build_current_domain(net,cursor,runner=runner,zones=zones)['all_declared_original9Q_ordinary_and_owned_joint_identities']
    warmrow=next(r for r in rows if action_key(r)==warmkey.split('|')[1])
    warm=actual.certified_cached_record({'net':net,'cursor':cursor},warmrow,warmkey)
    assert warm['attributed_PF_calls']==registry.archive.warm['cache'][warmkey]['attributed_PF_calls'];checks['prior_independent_warm_certificate_bound_and_old_costs_retained']=True
    # Check the actual controller factory is wired to this new engine, without
    # running the scientific decision body, forecast or commit.
    C=binding.runtime_class(registry)
    instance=C(out=B/'UNEXECUTED',protocol={},evidence=evidence,history=None,runner=runner,zones=zones,cache=registry.cache,blocked=set(),contexts={},numeric_cost={},paid_forecasts={},warm_dependency_path=R/'outputs/receding_warm_dependency_closure_20261015/Paid_Warm_Dependencies.json',warm_context_refs=[],source_anchors={},cold_gate=fail)
    assert instance.engine.use_registry is registry;checks['actual_runtime_factory_engine_dependency_bound']=True
    state['paid_query_registry'][KEY]=registry.anchor();state['next_phase']='READONLY_VERIFIED_CACHE_ENGINE_COLD_NO_SCIENCE'
    receipt=transport.save_complete(B/'checkpoint',state,{'source':sha(Path(binding.__file__)),'input':request['receipt']['raw_sha256'],'paid_receipt':registry.anchor()['sha256'],'predecessor':request['receipt']['state_fingerprint']})
    put(B/'Cold_Request.json',{'checkpoint':str((B/'checkpoint').relative_to(R)),'receipt':receipt,'primary_key':primary})
    registry.close();assert not calls
    with (B/'cold_console.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        code=child.wait(timeout=300)
    put(B/'Child_Exit.json',{'child_pid':child.pid,'exit_code':code});assert code==0,'Preserve failed cold output; no automatic retry'
    result=read(B/'Cold_Result.json');assert time.perf_counter()-started<600
    put(B/'Results.json',{'status':'PASS_REAL_VERIFIED_PAID_CACHE_ENGINE_BOUNDARY_AND_COMPLETE_COLD_STATE','checks':checks,'cold':result,
        'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Actual cache-use callback/runtime binding and saved complete-state cold software only; no whole new decision, fresh policy result or missing identity science authorization. Original full policy gate UNKNOWN.'})
    put(B/'Closed_Manifest.json',{'members':{str(x.relative_to(B)):sha(x) for x in B.rglob('*') if x.is_file()},'new_science':0})
    print(json.dumps({'verified_cache_engine_cold':'PASS','parent_checks':len(checks),'cold_checks':len(result['checks']),'new_science':0}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cold',action='store_true');a=p.parse_args();cold() if a.cold else main()
