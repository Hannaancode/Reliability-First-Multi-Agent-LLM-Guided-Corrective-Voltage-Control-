# HierGrid — master research checklist

Updated 2026-10-18T16:08:42.621499+00:00. Human priority order is preserved. **0 of 6 final goals verified complete.**

Checked subtasks mean the stated work and report are complete. A failed experiment remains a failed result. A whole goal is checked and crossed out only when all of its acceptance criteria pass.

Older operational notes are preserved in [the archived task list](outputs/research_tasks_20261014/Task_List_Before_Checklist_20261018.md).

- [ ] **G1. Find an LLM-assisted method aiming for zero UV on all severe federation cases and beat original deterministic DSE safely.**
- [ ] **G2. Find a published physical dataset/test set and test our model on it.**
- [ ] **G3. Compare against relevant published models/systems and benchmark whether ours is better.**
- [ ] **G4. Try higher-parameter small language models and compare each fairly.**
- [ ] **G5. Establish incremental LLM superiority as the long-term main goal, after the preceding tasks.**
- [ ] **G6. Implement and test cybersecurity after the preceding validated control/attribution gates.**

## Progress and next actions

### G1. Find an LLM-assisted method aiming for zero UV on all severe federation cases and beat original deterministic DSE safely.

Two distinct development worlds have observed zero UV from archived trained-LLM prefixes plus numerical control. Line 36: 33 residual UV to zero, using 24/25 operations and passing the upper-voltage guard. Its final complete checkpoint and branch closure are missing; full-policy and all-severe-case results remain UNKNOWN.

- [x] `G1.1` Index all 141 federation recipes; retain 68 historical results and 73 missing results as UNKNOWN. [Evidence](outputs/research_tasks_20261014/All141_Federation_Case_Status.json)
- [x] `G1.2` Verify recorded zero-UV transitions on line 35 within the preserved 26-commit audit. [Evidence](outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json)
- [x] `G1.3` Verify another world, line 36: 33 residual UV to zero; retain the missing closure/checkpoint limitations. [Evidence](outputs/observed_unclosed_zero_state_audit_20261018/Results.json)
- [x] `G1.4` Complete independent physical-component indexing of all 60,426 tracked prior PF inputs; both proposed actions have zero component matches. [Evidence](outputs/prior_physical_query_footprints_20261018/independent_audit/Independent_Audit.json)
- [x] `G1.4a` Check all 3,418 earlier fresh-root observations using two independent shunt-component equations; retain the observed-table scope limitation. [Evidence](outputs/fresh_observed_shunt_scope_20261018/Results.json)
- [x] `G1.4b` Pass exact cold native-input matching and mutation checks on samples from all ten source journals. [Evidence](outputs/strict_saved_native_input_match_v2_20261018/Results.json)
- [x] `G1.5` Finish the relevant-history and execution checks; freeze the exact next query protocol, warm/cold preservation and independent reader. [Evidence](outputs/exact_two_paid_query_engineering_20261018/Readiness.json)
- [x] `G1.6` Execute the justified next query test once; preserve every result, failure and cost, then assess its fixed gate. [Evidence](outputs/exact_two_paid_query_engineering_20261018/audit_source_claim_v2/Independent_Audit.json)
- [ ] `G1.7` Complete matched, protected hybrid/DFF/DFF-ALT/DSE and strong numerical trajectories across the entire declared severe-case roster.
- [ ] `G1.8` Independently confirm zero UV across that roster and the prespecified improvement over deterministic control.

Acceptance: Audit all141 federation recipes and declare the full severe-case roster before new outcomes; missing initial/results stay UNKNOWN. Complete matched protected trajectories for every declared severe case, zeroUV with no weakened safety/actions/operation/resource limits. Show a prespecified improvement over original DFF,DFF-ALT and unchanged DSE, reporting each branch and FULL BOTH-branch plus model/training/preparation/failure costs. Independent source/physical/continuous replay/full-state/cost evidence and unused authorized confirmation.

### G2. Find a published physical dataset/test set and test our model on it.

Three official PGLib 118-bus variants are pinned and audited. All three new SLSQP final points failed the fixed native feasibility threshold. Testing our model on a verified public initialization remains pending.

- [x] `G2.1` Pin and audit the full native inputs and constraints of all three published cases. [Evidence](outputs/public118_native_acopf_reference_20261015/Protocol.json)
- [x] `G2.2` Complete and independently report all three fixed SLSQP trials, including their failed feasibility gates. [Evidence](outputs/public118_slsqp_native_20261018/independent_audit/Independent_Audit.json)
- [ ] `G2.3` Establish a faithful verified public initialization/evaluation contract without rescuing stopped trials by retuning.
- [ ] `G2.4` Test our actual model/hybrid and equally informed controls on every preregistered public test identity.

Acceptance: Preserve dataset license/version/native constraints and disclose any necessary role/actuator adaptation. Use verified common initialization and frozen model/control interface; run every declared identity with independent physics/full costs.

### G3. Compare against relevant published models/systems and benchmark whether ours is better.

The native classical benchmark trials and their failures are recorded. No completed comparison with published systems establishes our superiority.

- [x] `G3.1` Record the source-faithful all3native classical benchmark trial and independent outcomes. [Evidence](outputs/public118_slsqp_native_20261018/independent_audit/Independent_Audit.json)
- [ ] `G3.2` Freeze comparable published-method reproduction/adaptation protocols and strong trained numerical controls.
- [ ] `G3.3` Run matched benchmarks with all outcomes, total costs and independent physical replay.
- [ ] `G3.4` Confirm any superiority claim on genuinely unused authorized cases.

Acceptance: Select relevant reproducible primary-source methods and document fidelity and task differences. Match plant,information,actions,protection,budgets,splits and costs; report all wins/ties/losses/failures. Claim superiority only if frozen comparison and independent unused confirmation support it.

### G4. Try higher-parameter small language models and compare each fairly.

Matched 0.5B/1.5B teacher-action accuracy: 41.6667%/53.125%, with 100% schema validity; numerical control: 72.9167%. The fixed gate failed. The 3B partial-result upper bound is 59.375%; 7B failed its first backward pass with out-of-memory. These fixed interventions remain stopped.

- [x] `G4.1` Complete the matched adapted 0.5B/1.5B comparison and preserve its failed numerical-control gate. [Evidence](outputs/matched_scale_20261011/verified_completion_handoff_20261012/Verified_Matched_Scale_Completion.json)
- [x] `G4.2` Audit the larger-model attempts: preserve the 3B partial result, 7B out-of-memory failure and all unknown outputs. [Evidence](outputs/higher_matched_scale_20261015/partial_evidence_audit_runtime_v2_20261018/Independent_Partial_Audit.json)
- [ ] `G4.3` If justified by a materially different mechanism, freeze and complete a fair higher-model comparison; do not repeat size-only failed imitation.

Acceptance: Use the same serving role,data/context/split,training/final-checkpoint rules and evaluation identities; disclose architecture/FLOP/precision differences. Record complete outcomes and compute/training/failure costs. Partial/OOM stays partial and is never a successful larger-model result.

### G5. Establish incremental LLM superiority as the long-term main goal, after the preceding tasks.

Unachieved. Numerical improvements, format accuracy and larger-model teacher gains do not isolate an incremental LLM contribution.

- [ ] `G5.1` Freeze an evidence-supported causal LLM contribution and complete ablation/attribution protocol.
- [ ] `G5.2` Execute matched fresh-inference physical comparisons with full costs.
- [ ] `G5.3` Independently validate the incremental contribution on unused authorized confirmation.

Acceptance: Fresh per-state LLM inference and matched complete physical outcomes. With/without-LLM ablations under identical information/actions/protection/budgets, plus strong numerical and architecture/pretraining controls. Prespecified improvement after full model/training/preparation/solver/failure costs and independent unused confirmation.

### G6. Implement and test cybersecurity after the preceding validated control/attribution gates.

Deferred until control and attribution gates pass. The earlier 24-trial, 96-proposal QA study remains a development pilot, not full security validation.

- [ ] `G6.1` After control/attribution gates, define attacks,defences,causal access and security acceptance criteria.
- [ ] `G6.2` Run matched attack/defence experiments and independently confirm physical security outcomes.

Acceptance: Freeze a causal threat model and matched attack/defence baselines. Measure full protected physical outcomes, attack/defence costs and independent confirmation; retain all failures.

## Keep this current

- Read this file and the newest runbook/plan headers at every continuation; use the linked exact resume for execution details.
- Preserve these six priorities and stable subtask IDs. Update evidence, results, limitations and the next action after each verified result.
- Update reseacrh progress.txt and the structured task list together. Check a whole goal and strike its title through only after its acceptance criteria pass.
- Keep failed, partial and UNKNOWN results. Do not repeat stopped experiments or change thresholds/budgets/seeds/checkpoints to force a win.
- Preserve original frozen assets and literal DFF + DFF-ALT + unchanged DSE; report both branches and FULL BOTH-branch costs.
- A result-wait timer is only for a confirmed live result that is the sole dependency. Remove it when terminal. Do useful parallel work when available.

[Structured tasks](outputs/research_tasks_20261014/Tasks.json) · [Exact resume](outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json) · [Progress log](reseacrh%20progress.txt)

Latest continuation: 2026-10-18T18:18:28.437507+00:00. TERMINAL_PRESERVE_PARTIAL_OR_FAILURE_NO_SCIENCE_RETRY. Start-only timer deleted after the requested21:06Qatar start. No GPU allocated. All six final goals remain open.

Latest continuation: 2026-10-18T18:20:58.164280+00:00. COMPLETE_FIXED_TWO_QUERY_ENGINEERING_INDEPENDENT_PASS. Start-only timer deleted after the requested21:06Qatar start. No GPU allocated. All six final goals remain open.
