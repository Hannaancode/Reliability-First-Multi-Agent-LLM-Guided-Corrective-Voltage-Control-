"""Fixed weighted kernel readouts, all FIT multiplicities, no physics or model inference."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,time,hashlib
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1]/'work/physics_env/Lib/site-packages'))
import numpy as np
from scipy.linalg import cho_factor,cho_solve
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_stationary_readout_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def predict(saved,features):
    Z=(features-saved['mean'])/saved['std'];train=saved['trainZ'];d=train.shape[1];K=Z@train.T/d
    if str(saved['kernel'])=='rbf':K=np.exp(-np.maximum(np.sum(Z*Z,axis=1)[:,None]+np.sum(train*train,axis=1)[None,:]-2*Z@train.T,0)/d)
    K=K-(K@saved['weight']/saved['weight'].sum())[:,None]-saved['kernel_mean'][None,:]+saved['kernel_grand'];raw=.3*(K@saved['alpha'])+saved['target_mean'];u=np.clip(raw.astype(np.float32),np.float32(-.3),np.float32(.3));return raw,u
def main(representation,owner_source):
    out=ROOT/'outputs/native_stationary_readout_fit_20261020'/(representation+'_v2');out.mkdir(exist_ok=False);put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(owner_source),'representation':representation});start=time.monotonic()
    while not (out/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    p=json.loads((PREP/'Prospective_Readout_Protocol.json').read_text());data=np.load(PREP/'Grouped_Same_Current_Only_Numeric_FIT.npz');target=data['target'].astype(np.float64);w=data['weight'];assert target.shape==(241,3) and (w>0).all() and abs(w.sum()-1929)<1e-7
    if representation=='numeric':features=data['X'];feature_file=PREP/'Grouped_Same_Current_Only_Numeric_FIT.npz'
    else:
        audit=ROOT/'outputs/native_frozen_feature_independent_20261020/Independent_Audit.json';assert json.loads(audit.read_text())['status'].startswith('PASS_ALL3_NATIVE');feature_file=ROOT/'outputs/native_frozen_feature_execution_20261020'/representation/'staged/study/primary_All241_Features.npy';features=np.load(feature_file).astype(np.float64)
    assert features.shape[0]==241 and np.isfinite(features).all();mean=np.average(features,axis=0,weights=w);std=np.maximum(np.sqrt(np.average((features-mean)**2,axis=0,weights=w)),1e-8);Z=(features-mean)/std;target_mean=np.average(target,axis=0,weights=w);sqrtw=np.sqrt(w);lam=.001*w.sum();cost={'Cholesky_attempts':0,'Cholesky_returns':0,'three_RHS_solve_attempts':0,'three_RHS_solve_returns':0,'triangular_RHS_stages':0,'model_GPU_optimizer_PF_calls':0};rows=[]
    for kernel in ['linear','rbf']:
        assert time.monotonic()-start<120;d=Z.shape[1];K=Z@Z.T/d
        if kernel=='rbf':K=np.exp(-np.maximum(np.sum(Z*Z,axis=1)[:,None]+np.sum(Z*Z,axis=1)[None,:]-2*Z@Z.T,0)/d)
        km=K@w/w.sum();grand=float(w@km/w.sum());centered=K-km[:,None]-km[None,:]+grand;A=sqrtw[:,None]*centered*sqrtw[None,:]+lam*np.eye(241);B=sqrtw[:,None]*((target-target_mean)/.3);cost['Cholesky_attempts']+=1;L,lower=cho_factor(A,lower=True,check_finite=True);cost['Cholesky_returns']+=1;cost['three_RHS_solve_attempts']+=1;beta=cho_solve((L,lower),B,check_finite=True);cost['three_RHS_solve_returns']+=1;cost['triangular_RHS_stages']+=6;residual=float(np.max(np.abs(A@beta-B)));assert residual<=1e-8;alpha=sqrtw[:,None]*beta;file=out/(kernel+'_Complete_Readout.npz');np.savez(file,kernel=np.asarray(kernel),mean=mean,std=std,trainZ=Z,weight=w,target_mean=target_mean,kernel_mean=km,kernel_grand=grand,alpha=alpha,beta=beta,lambda_value=lam,features=features,target=target,source_feature_sha256=np.asarray(sha(feature_file)),source_input_sha256=np.asarray(sha(PREP/'Grouped_Same_Current_Only_Numeric_FIT.npz')));state=np.load(file);raw,u=predict(state,features);coldraw,coldu=predict(np.load(file),features);assert np.array_equal(u,coldu) and np.array_equal(raw,coldraw);np.savez(out/(kernel+'_All241_FIT_Predictions.npz'),raw=raw,u=u);mse=float(np.average(np.mean(((u-target)/.3)**2,axis=1),weights=w));rows.append({'kernel':kernel,'FIT_normalized_MSE_descriptive_only':mse,'raw_clipped_elements':int((np.abs(raw)>float(np.float32(.3))).sum()),'head_equation_residual':residual,'complete_state_cold_raw_and_native_u_exact':True,'no_held_or_physical_score':True})
    result={'status':'COMPLETE_ALL_FIXED_LINEAR_AND_RBF_NATIVE_READOUTS_FIT_ONLY_NOT_PERFORMANCE','representation':representation,'input_features':features.shape[1],'all_original_weighted_rows':1929,'unique_current_inputs':241,'original_FIT_worlds':64,'kernels':rows,'actual_costs':cost,'bias':'FITweightedtargetmean;weightedcenteredtrainkernel andtarget,unregularizedbias;standardinterceptnotoutcomeselected','regularization':lam,'all_DEV_confirmation_model_or_physics_calls':0,'workflow_seconds':time.monotonic()-start,'no_selected_winner_or_LLM_superiority':True};put(out/'Results.json',result);put(out/'Closed_Manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}});print(representation,'FIXED_READOUT_FIT_COMPLETE')
