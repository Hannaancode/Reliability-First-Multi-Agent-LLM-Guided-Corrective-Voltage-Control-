"""Evidence-backed thesis source edits, checklist triage and defence brief. No science."""
from pathlib import Path
import datetime, hashlib, json, re, statistics
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_evidence_update_20261028'
def read(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def write(name,obj): (O/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n','utf-8')
def replace_section(text,start,end,replacement):
    assert text.count(start)==1 and text.count(end)==1
    a=text.index(start);b=text.index(end,a)
    return text[:a]+replacement.rstrip()+'\n\n'+text[b:]

def main():
    O.mkdir(exist_ok=False)
    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    c=read('outputs/original118_closed_comparison_20261028/Comparison.json')
    assert c['status']=='ALL4_AUDITED_DESCRIPTIVE_ORIGINAL_NATIVE_COMPARISON'
    rows=c['rows'];dif=[r['UV_difference_HGVF_minus_DFF'] for r in rows]
    paired={'n':4,'differences_HGVF_minus_DFF':dif,'mean':statistics.mean(dif),'median':statistics.median(dif),
      'range':[min(dif),max(dif)],'wins':3,'ties':0,'losses':1,
      'relative_total_residual_UV_reduction_HGVF':25/51,'relative_total_residual_UV_reduction_HGSE':31/51,
      'inference':'Descriptive only. Four predeclared inspected development roots, not a probability sample or unused confirmation. No invented standard errors, IID confidence intervals or seed variance.'}
    write('Paired_Development_Effects.json',paired)
    table='| Root | Initial UV | DFF UV / OV | HG-VF UV / OV | Offline HG-SE UV / OV |\n| --- | ---: | ---: | ---: | ---: |\n'
    for r in rows:
        label=r['case_id'].replace('fed_combined_load_1p5_line_','Line ')
        table+=f"| {label} | {r['initial_UV']} | {r['DFF_UV']} / {r['DFF_OV']} | {r['HGVF_UV']} / {r['HGVF_OV']} | {r['HGSE_UV']} / {r['HGSE_OV']} |\n"
    prose=[
      'All four predeclared severe development roots now have complete, independently checked DFF and original Reflection-v4 HG-VF endpoints. The two earlier interrupted language branches were completed through separately frozen missing-only continuations from their saved pending requests. The original failures and paid prefixes remain in the evidence record; their already returned physics and model responses were not regenerated.',
      'DFF leaves 51 undervoltage buses across the four cases and HG-VF leaves 26, a descriptive reduction of 25 residual violations, or 49.0%. HG-VF improves the UV count in three cases and worsens it in one. Line36MG1 improves from 58 initial UV to one with HG-VF, compared with 15 remaining under DFF. Line127MG3 instead leaves 13 under HG-VF and seven under DFF, so the positive total does not imply improvement on every case.',
      'Strict overvoltage uses Vm > 1.05 p.u., while the unchanged original acceptance guard allows values up to 1.06 p.u. HG-VF adds one strict overvoltage relative to DFF on both Line36MG1 and Line84MG2. Its total of 11 strict overvoltages equals DFF\'s total only because the other two cases each remove one. The predefined test required at least two UV wins, no UV loss and no additional strict OV in any case. It fails. Neither branch restores the whole 0.95–1.05 p.u. band in any of these four cases.',
      'The unchanged offline HG-SE selector retains the HG-VF trajectory in the first three cases and the DFF trajectory in the fourth. Its selected endpoints contain 20 UV and 12 strict OV. The 60.8% reduction in total residual UV relative to DFF is a descriptive result of evaluating and then selecting between both complete branches. The selector does not include an explicit OV tie criterion. It is not a fresh online language decision, and its cost includes both searches.',
      'DFF uses 29 accepted actions across the four cases, while HG-VF uses 73. The latter comprise 51 direct language actions, 13 guided actions and nine fallback actions. These are accepted-action origins, not raw output validity rates or a causal allocation of the voltage improvement. Guided refinement, fallback and numerical verification all contribute to the combined controller. A numerical D-SE comparison and matched information, intervention and query costs remain necessary for an incremental LLM claim.',
      'The two new suffixes record 1,933 primary PF attempts, 1,927 returned solutions and six preserved exceptions. The independent readers replay each new successful input once, with zero maximum difference over the checked fields; the largest KCL residual is approximately 1.14 × 10⁻⁸ p.u. They verify 140 new controller model responses; the remote records also include two separately charged cold-check generations. Old prefixes, training, shared queries, setup and failed work remain separately paid. Overlapping workflow times are not added as a deployment latency estimate.',
      'For the four matched roots, HG-VF minus DFF residual-UV differences are −4, −14, −13 and +6, giving a mean difference of −6.25 and a median of −8.5. These are descriptive development effects. The four roots were already inspected, so no IID confidence interval, repeated-run variance or unused-confirmation claim is attached to this table. The four-case study does not reconstruct the final 137-scenario manuscript cohort or establish an external-method benchmark.'
    ]
    replacement='## 7.8 Four severe roots with independent physics checks\n\n'+prose[0]+'\n\n[[TABLE severe118]]\n\n'+'\n\n'.join(prose[1:])
    source7=R/'outputs/thesis_expanded_20261028/07_Experiments.md'
    old7=source7.read_text('utf-8-sig');(O/'Prior_07_Experiments.md').write_text(old7,'utf-8')
    new7=replace_section(old7,'## 7.8 Four severe roots with independent physics checks','## 7.9 Larger adapted models',replacement)
    extra=('The 16,000 original training rows contain repeated examples grouped into 109 teacher worlds. The later 85-world fitting and 24-world evaluation partition keeps connected worlds together and retains those multiplicities; it does not turn the already inspected teacher bank into a new physical confirmation set. Row count is therefore not the number of independent operating conditions. Exact historical original-SFT preprocessing and the later matched public-model training contract are also distinct.')
    needle='The completed exact action scores are'
    assert new7.count(needle)==1;new7=new7.replace(needle,extra+'\n\n'+needle)
    source7.write_text(new7,'utf-8')
    chapter9=R/'outputs/thesis_expanded_20261028/08_Security_09_Conclusion.md'
    old9=chapter9.read_text('utf-8-sig');(O/'Prior_08_Security_09_Conclusion.md').write_text(old9,'utf-8')
    paras={
     'For RQ2,': 'For RQ2, the manuscript reports favourable answering results, but the historical notebook recovery identifies an in-corpus question–answer retrieval recipe. Its 500 printed question, answer and reference triples are recovered without new inference. The runtime index, model revisions and exact adjudication behind 99% factual correctness remain unresolved, and the 342-case NLI summary belongs to a separate closed-book baseline. A causal retrieval benefit still requires a genuinely matched retrieval-on/off comparison.',
     'For RQ4,': 'For RQ4, the completed four-root comparison reduces total residual UV from 51 with DFF to 26 with original HG-VF, with three wins and one loss. Offline HG-SE selects endpoints with 20 UV after paying both branches. Two HG-VF cases add strict overvoltage, intervention counts differ and the fixed development gate fails. The separate public 500-case numerical study is also adverse on whole-band restoration, with 264 cases restored versus 363 for published DDPG. These findings support scoped UV improvements, not general superiority.',
     'For RQ5,': 'For RQ5, the matched public-model study raises exact teacher-action agreement from 41.6667% at 0.5B to 53.125% at 1.5B, but remains below the 72.9167% numerical reference. The completed original four-root study contains 51 direct, 13 guided and nine fallback accepted actions; these origins do not isolate each component\'s causal effect. Equal-cost numerical envelopes, strong attribution controls and unused physical confirmation remain open.'}
    new9=old9
    for prefix,value in paras.items():
        matches=[p for p in new9.split('\n\n') if p.startswith(prefix)];assert len(matches)==1
        new9=new9.replace(matches[0],value)
    chapter9.write_text(new9,'utf-8')
    # Keep the executable thesis builder's fixed table consistent for the next full build.
    builder=R/'outputs/thesis_expanded_20261028/build_expanded.py';oldb=builder.read_text('utf-8-sig')
    (O/'Prior_build_expanded.py').write_text(oldb,'utf-8')
    assert oldb.count("'UNKNOWN partial'")==2
    newb=oldb.replace("['Line36MG1','58','15/2','UNKNOWN partial']","['Line36MG1','58','15/2','1/3']")
    newb=newb.replace("['Line127MG3','55','7/4','UNKNOWN partial']","['Line127MG3','55','7/4','13/3']")
    newb=newb.replace('Chapter 7 Experiments results and critical analysis','Chapter 7 Experimental results and critical analysis')
    builder.write_text(newb,'utf-8')
    # Consolidated Markdown changes are explicitly source changes, not a rebuilt105-page DOCX.
    allpath=R/'outputs/thesis_expanded_20261028/Expanded_Thesis_Text.md';oldall=allpath.read_text('utf-8-sig')
    (O/'Prior_Expanded_Thesis_Text.md').write_text(oldall,'utf-8')
    newall=replace_section(oldall,'## 7.8 Four severe roots with independent physics checks','## 7.9 Larger adapted models',replacement)
    for prefix,value in paras.items():
        matches=[p for p in newall.split('\n\n') if p.startswith(prefix)];assert len(matches)==1
        newall=newall.replace(matches[0],value)
    newall=newall.replace(needle,extra+'\n\n'+needle)
    allpath.write_text(newall,'utf-8')
    (O/'Severe_Case_Thesis_Update.md').write_text(replacement.replace('[[TABLE severe118]]',table),'utf-8')
    # Six RQs retain the actual thesis wording; evidence is tiered, never promoted from reported to verified.
    questions=re.findall(r'^RQ([1-6]): (.+)$',oldall,re.M);assert len(questions)==6
    answers=[
      ('Published dataset and its documented curation/retrieval analyses; candidate contribution and coauthor expert review retained.',
       'PowerGridQA supplies a structured theory and operations QA resource. This is a dataset contribution, not a voltage-control result.',
       'Exact release/split lineage, the4,396-versus4,696 NERC scope and shared-source leakage remain unresolved.',
       'How do you know the test answers were independent of the source corpus? Explain source grouping and leave unrecovered versions unknown.'),
      ('Historical500 printed RAG triples recovered by two agreeing parsers with zero new inference; manuscript answering and stress figures retained as reported.',
       'The recovered recipe uses public0.5B, top3 retrieval and greedy256-token generation. Its same-named QA indexing is an in-corpus recipe.',
       'The exact99% factual grading, runtime index and revisions are not recovered;342 parsed NLI cases are a separate closed-book baseline.',
       'Does99% demonstrate generalisation or a causal RAG effect? No: those claims need matched ablation and exact labels; do not equate cosine grounding with truth.'),
      ('Original source/parser/LoRA/controller integrations and complete four-root trajectories; matched public0.5B/1.5B output schema100% in the teacher task.',
       'A working structured control interface is established for its specified role. Original HG-VF accepted73 actions:51direct,13guided,9fallback.',
       'These counts are not raw validity rates. The original positive25-Mvar shunt language does not directly transfer to a sub-Mvar bidirectional inverter role.',
       'Were fallback commands counted as model successes? Keep each origin separate and do not use schema compliance as evidence of electrical superiority.'),
      ('All4 original118 matched endpoints independently closed; public13all500numerical/published comparison completed under its own contract.',
       'HG-VF26 versus DFF51 residualUV,3wins1loss. OfflineHG-SE20UV. Public13numerical264/500whole-band versus publishedDDPG363/500.',
       'Two118cases add strictOV and intervention costs differ; no118case achieves whole-band restoration. Published13policies have different native information/stopping.',
       'Can you claim your model beats all methods? No. State the scoped UV gain, failedfixedgate and public adverse result, with fullbothcosts.'),
      ('Matched adapted public0.5B/1.5B final-checkpoint study with complete checkpoints and exact reload outputs; action-origin counts in original118.',
       'Teacher-action agreement improves41.6667% to53.125%, but numeric72.9167% remains stronger. Fixedscalegate fails;3Bpartial and7Bmemoryfailure retained.',
       'Teacher imitation is not a physical control advantage. NumericalDSE, architecture/pretraining controls and unused confirmation remain open.',
       'What improvement is specifically caused by language pretraining? Current evidence does not isolate it; direct proposals and whole-system gains are not that ablation.'),
      ('Manuscript200-case language stress suite, including28impossible-metadata and25out-of-scope requests; later24-trial96-proposal development pilot.',
       'Reported failure rates89.3% for impossible metadata and36% for out-of-scope requests expose concrete weaknesses. Native voltage checks reject specified adverse candidates.',
       'No comprehensive physical cyber-resilience result. A consistent PF solve on corrupted observations is not evidence that the observations are true.',
       'Why is security in the title? Explain the current evaluated scope and either complete the bounded physical study or narrow the final claim with supervisor agreement.')]
    rq=[]
    for (num,q),a in zip(questions,answers):rq.append(dict(id='RQ'+num,question=q,experiment=a[0],finding=a[1],limitation=a[2],examiner_objection_and_response=a[3]))
    write('Research_Question_Evidence_and_Defence.json',{'at_utc':now,'questions':rq,'all_six_research_goals_achieved':False})
    # Nothing is silently removed. Many checklist items share evidence and need no new GPU work.
    checklist=read('outputs/thesis_research_closure_20261028/Tasks.json')
    empirical={'T02','T04','T05','T06','T11','T12','T13','T14'}
    admin={'T01','T29','T34'}
    literature={'T25','T28','T31'}
    recommendations={
      'T01':'Needed for final claim accuracy. Security title remains provisional pending completed evidence or an agreed narrower title.',
      'T02':'A new physical study is needed only for a physical cyber-resilience claim; a clearly bounded language-security scope can be reported now.',
      'T07':'Evidence resolved now. Integrate the complete four-case results into final Word rather than leaving two endpoints unknown.',
      'T14':'A causal retrieval claim needs matched on/off testing; a whole-system historical comparison must be labelled as such.',
      'T22':'Use paired descriptive differences now. Uncertainty must respect the four inspected roots; do not fabricate IID or repeated-seed variance.',
      'T24':'Keep the candidate technical statement and documented coauthor work; confirm only roles that remain provisional.',
      'T29':'Final committee, defence date and personal acknowledgments require actual information, not invented administrative detail.',
      'T34':'Keep the checklist as an internal work product; remove internal instructions only from the final submission copy.'}
    triage=[]
    for t in checklist['tasks']:
        i=t['id'];category='Evidence recovery or justified experiment' if i in empirical else ('Final submission decision' if i in admin else ('Bibliographic/source review' if i in literature else 'Document and evidence integration'))
        triage.append({'id':i,'title':t['title'],'needed':True,'category':category,'requires_GPU_now':False,
          'next':recommendations.get(i,'Retain this requirement. Complete from source-bound evidence where available; do not invent a missing result or run training merely to close a writing item.')})
        if i=='T07':t.update(status='EVIDENCE_COMPLETE_CHAPTER_SOURCE_UPDATED_WORD_INTEGRATION_PENDING',evidence_complete=True)
        if i=='T22':t.update(status='FOUR_ROOT_DESCRIPTIVE_EFFECTS_COMPLETE_BROADER_UNCERTAINTY_OPEN')
        if i in ('T07','T22'):t.setdefault('evidence',[]).append('outputs/thesis_evidence_update_20261028/Severe_Case_Thesis_Update.md' if i=='T07' else 'outputs/thesis_evidence_update_20261028/Paired_Development_Effects.json')
        if i in ('T10','T35'):
            t.update(status='SIX_RQ_EVIDENCE_AND_DEFENCE_BRIEF_PREPARED_VISUAL_REVIEW_PENDING')
            t.setdefault('evidence',[]).append('outputs/thesis_evidence_update_20261028/Research_Question_Evidence_and_Defence.json')
        if i=='T16':
            t.update(status='WORLD_MULTIPLICITY_AND_DEVELOPMENT_SCOPE_CHAPTER_SOURCE_UPDATED_WORD_PENDING')
            t.setdefault('evidence',[]).append('outputs/thesis_expanded_20261028/07_Experiments.md')
        if i in ('T05','T09','T15','T21','T26','T27'):
            t.setdefault('evidence',[]).append('outputs/original118_closed_comparison_20261028/Comparison.json')
            t['new_scoped_progress']='Complete four-root endpoint, origin and source-cost evidence now available; broader requirement remains open.'
        t['work_category']=category
    checklist['updated_utc']=now
    (R/'outputs/thesis_research_closure_20261028/Tasks.json').write_text(json.dumps(checklist,indent=2,ensure_ascii=False)+'\n','utf-8')
    write('All35_Task_Triage.json',{'at_utc':now,'items':triage,'removed_items':[],
      'interpretation':'35 closure requirements are not35 new experiments. Four categories share evidence and can progress without GPU; no final claim is dropped for convenience.'})
    source_paths=['outputs/original118_closed_comparison_20261028/Comparison.json','outputs/original118_closed_comparison_20261028/Full_Cost_Source_Blocks.json',
      'outputs/original118_comparison_completion_20261028/Verified_Completion.json','outputs/rag_evaluation_contract_recovery_20261028/Recovered_Evaluation_Contract.json',
      'outputs/matched_scale_20261011/verified_completion_handoff_20261012/Verified_Matched_Scale_Completion.json',
      'outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json',
      'outputs/thesis_research_closure_20261028/Contribution_And_Verifier_Source_Record.json',
      'outputs/thesis_expanded_20261028/Thesis_Source_and_Claim_Record.json']
    write('Evidence_Index.json',{'at_utc':now,'sources':[{'id':'E'+str(i+1),'path':p,'sha256':sha(p)} for i,p in enumerate(source_paths)],
      'original_105page_DOCX':'UNCHANGED; updated chapter sources and separate defence brief, final full Word integration pending',
      'new_model_PF_training_calls':0})
    # Seven-page readable defence artifact, each page with a clear purpose.
    doc=Document();s=doc.sections[0]
    s.page_width=Mm(210);s.page_height=Mm(297);s.top_margin=s.bottom_margin=Mm(20);s.left_margin=s.right_margin=Mm(23)
    for name in ['Normal','Title','Heading 1','Heading 2']:
        sty=doc.styles[name];sty.font.name='Times New Roman';sty.font.color.rgb=RGBColor(0,0,0)
        sty.font.size=Pt(11 if name=='Normal' else (17 if name=='Title' else 13))
        sty.paragraph_format.space_after=Pt(7);sty.paragraph_format.line_spacing=1.08
    def p(text):doc.add_paragraph(text)
    def heading(text):doc.add_heading(text,1)
    def page(text):doc.add_page_break();heading(text)
    def tbl(heads,data):
        t=doc.add_table(rows=1,cols=len(heads));t.style='Table Grid'
        for j,h in enumerate(heads):t.rows[0].cells[j].text=h
        for values in data:
            for cell,val in zip(t.add_row().cells,values):cell.text=str(val)
        for idx,row in enumerate(t.rows):
            pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
            if idx==0:pr.append(OxmlElement('w:tblHeader'))
            for cell in row.cells:
                for pp in cell.paragraphs:
                    pp.paragraph_format.space_after=Pt(4);pp.paragraph_format.line_spacing=1.0
                    for run in pp.runs:run.font.size=Pt(10.5);run.bold=idx==0
        return t
    doc.add_heading('Verified results and thesis defence evidence',0)
    p('Abdul Hannaan | Master in Computing | 28 October 2026')
    p('The original hybrid controller improves total undervoltage on four severe development cases, but its fixed comparison test fails because one case worsens and two add strict overvoltage. The completed evidence now supports a clear, bounded account of progress and of the research still open.')
    heading('Four matched original federation cases')
    tbl(['Root','Initial UV','DFF UV/OV','HG-VF UV/OV','HG-SE UV/OV'],[[x['case_id'].replace('fed_combined_load_1p5_line_',''),x['initial_UV'],f"{x['DFF_UV']}/{x['DFF_OV']}",f"{x['HGVF_UV']}/{x['HGVF_OV']}",f"{x['HGSE_UV']}/{x['HGSE_OV']}"] for x in rows])
    for text in (prose[1],prose[2],prose[3]):p(text)
    p('Evidence E1–E3. UV means Vm <0.95; strict OV means Vm >1.05. Same predeclared roots and original native controller contract; greater intervention and full search costs are disclosed.')
    page('Action origins costs and interpretation')
    tbl(['Method','Residual UV','Strict OV','Accepted actions'],[['DFF',51,11,29],['HG-VF',26,11,73],['Offline HG-SE',20,12,71]])
    for text in prose[4:]:p(text)
    p('The original method uses a native1.06 upper guard. Numerical replay verifies the fields and equations actually checked; it does not certify all thermal limits, generator capability curves, stability or cybersecurity. Case0\'s earlier supervisor exit remains unknown even though its closed independent evidence is retained. Sources E1–E3 and E7.')
    for start in (0,3):
        page('Research questions '+str(start+1)+' to '+str(start+3))
        for x in rq[start:start+3]:
            doc.add_heading(x['id']+' '+x['question'],2)
            p('Evidence: '+x['experiment'])
            p('Finding and limit: '+x['finding']+' '+x['limitation'])
            p('Likely examiner question: '+x['examiner_objection_and_response'])
    for start,end in [(0,18),(18,35)]:
        page('Thesis closure priorities '+str(start+1)+' to '+str(end))
        p('Every item remains visible. Evidence recovery and writing share many of the same records; none currently justifies an idle GPU allocation. A complete document task does not imply a completed research goal.')
        short={'Evidence recovery or justified experiment':'Evidence gate','Final submission decision':'Final decision','Bibliographic/source review':'Source review','Document and evidence integration':'Integrate evidence'}
        tbl(['ID','Requirement','Work needed'],[[x['id'],x['title'],short[x['category']]] for x in triage[start:end]])
        if start==0:p('T07 now has complete audited endpoints and updated Chapter7 source. T02 needs physical testing only if a physical cyber-resilience claim is retained. T05/T06 remain necessary for the main causal LLM goal.')
        else:p('T22 has complete descriptive four-root effects. The six-RQ defence record answers each question at its actual evidence level. Final committee details and approvals must come from the university or supervisor.')
    page('Evidence map and next work')
    labels=['Four-root original comparison and unchanged gate','Full source-specific cost blocks','Closed suffix audit and ownership checkpoint',
      'Recovered RAG recipe and historical500record contract','Matched0.5B/1.5B complete audited scale result',
      'Public13matched500case numerical and published comparison','Original verifier selector and candidate contribution source record','Published and supplied manuscript identity record']
    for i,label in enumerate(labels):
        p('E'+str(i+1)+'  '+label)
        p(source_paths[i])
    p('The accompanying Evidence_Index.json pins exact source hashes. The four-root comparison is new verified development evidence; the reported137-scenario paper figures and RAG99% claim remain subject to their separate historical reconstruction gaps.')
    p('Next work: integrate these source revisions into the full thesis and check its layout, recover unresolved historical data/evaluation contracts, and finish faithful external118controller admission before a new physical benchmark. New model training needs a separately justified mechanism and prospective gates. No old experiment is restarted to improve an adverse score.')
    for root in (doc.styles.element,doc.element):
        for el in list(root.iter(qn('w:pBdr'))):el.getparent().remove(el)
        for el in root.iter(qn('w:rFonts')):
            for attr in list(el.attrib):
                if attr.endswith('Theme'):del el.attrib[attr]
            for attr in ['ascii','hAnsi','eastAsia','cs']:el.set(qn('w:'+attr),'Times New Roman')
    doc.core_properties.author='Abdul Hannaan';doc.core_properties.title='Verified results and thesis defence evidence'
    doc.save(O/'Verified_Results_and_Thesis_Defence.docx')
    write('Source_Update_Record.json',{'at_utc':now,'status':'SOURCE_EDITS_AND_BRIEF_WRITTEN_VISUAL_REVIEW_PENDING',
      'modified_sources':[str(x.relative_to(R)).replace('\\','/') for x in [source7,chapter9,builder,allpath]],
      'original_full_docx_unchanged':True,'35_tasks_retained':True,'new_science_calls':0})
    print(json.dumps({'T07':'COMPLETE_EVIDENCE_SOURCE_UPDATED','task_triage':len(triage),'RQs':len(rq),'docx':str(O/'Verified_Results_and_Thesis_Defence.docx'),'new_science':0}))

if __name__=='__main__':main()
