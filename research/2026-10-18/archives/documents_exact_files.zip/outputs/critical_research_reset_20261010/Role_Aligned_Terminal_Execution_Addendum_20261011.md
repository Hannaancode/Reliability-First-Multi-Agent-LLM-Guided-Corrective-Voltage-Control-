# Execution addendum: bind the actual task before the next learner

Status: critical design, **not a launch-ready protocol**. This addendum supersedes automatic continuation of the failed acquisition stages and direct transfer of original local/null targets to Reflection-v2. It preserves the original plan, original 0.5B achievements and all adverse results.

## What today's tests changed

The fixed original-role numerical diagnostic reached 72.92% held equal-world exact teacher-action matching, versus nearest-current 65.63% and weighted prior 25%. Its 26 errors were 14 correct-bus/wrong-Q, four wrong-bus, three missed proposals and five unnecessary proposals. That is development imitation evidence, not physical opportunity. The deployed wrapper sweeps Q on a proposed bus, while direct accepted priorities and failed signatures may still affect execution; a Q-error count alone does not certify controller harm.

The new independently checked role diagnostic rejects direct unchanged target reuse for the mandatory-global wrapper: 79 of 104 supported stressed first-zone source templates have null targets. Four of 109 world joins remain UNKNOWN. The original local/null task is legitimate, but it is not the deployed mandatory-global task. Changing to 1.5B while retaining this contradiction is not a coherent capacity test.

The saved trajectory schema supplies current observations, support-cap observables and some committed successors. It does not currently certify later counterfactual continuations with complete process identity. The already measured 23 physical before-observation IDs with multiple committed actions cannot establish 23 useful later forks: they can include the DFF/DFF-ALT root alternatives already evaluated by D-SE. A graph assembled by voltage matching or splicing different histories would invent evidence.

## One candidate mechanism

A **later coordinator commitment policy** might choose between genuinely admissible actions using protected terminal continuation evidence, rather than predicting the exact immediate winner or choosing between D-SE's two already evaluated complete branches. The learning target would concern the result of a safe action sequence. Current receipt scalars, original assistant summaries and labels without successors are insufficient targets.

This remains a hypothesis. Full immediate-menu DFF argmax cannot be improved under the identical immediate objective. A later policy needs actual evidence of nonlinear/cap-dependent terminal opportunity, without temporary violation, non-improving actions or enlarged native scope. Merely moving the old binary root-selector intervention to another fixed step would be an outcome-driven configuration change, not a sufficiently justified new learning method. No such replacement experiment is authorized by this design alone.

## Concrete work and stop rules

1. **Bind one deployment role and causal state.** Specify the coordinator's exact invocation, current physical tables, local/global scopes, original support cap/Q grammar, accumulated support, remaining commitment budget, source ordering, failed signatures and causal feedback. Administrative world/branch IDs, hidden candidate outcomes, AFTER states and terminal labels stay outside the forward. Mark each available field as measured, deterministically derived from a certified prefix, or UNKNOWN. A missing history cannot be replaced by empty history. Name any new wrapper separately; preserve frozen HG-VF and literal D-SE.

2. **Establish support before learning.** Use the existing certified inventory and source schemas as the starting point, without rerunning them. A future new support reader needs a pre-outcome source/input identity lock and an exclusive owner. It must identify exact CURRENT/process nodes, distinguish original first-decision portfolio alternatives from later forks, and require at least two actually accepted outgoing actions with full successor states and complete protected continuations. Equal physical voltage digests alone do not prove identical process state. If essential process or continuation fields are absent, the existing-data training route remains UNKNOWN/not ready; do not compute a fabricated terminal value or classify missing alternatives as losses.

3. **Require a materially justified opportunity test.** If genuinely new continuations are necessary, prepare a separate physical protocol containing an exact outcome-independent world/action list, reuse rules for already measured identities, original solver/action/verifier/source binding, all missing/failure denominators, a fixed resource bound and no scientific retry. Specify the protected terminal estimand, practically useful improvement margin and exact opportunity/stop gates before any new outcome. Independent full-field replay, actual PF attempts/exceptions/latency and preservation are charged. No old budget extension, changing fork depth after outcomes, selected favorable worlds or replay of completed physics. An optimistic sequence opportunity is not deployed policy performance.

4. **Challenge it with stronger numerical alternatives.** A deterministic limited-horizon planner and a trained candidate-conditioned sequence policy must receive the same current/process/returned evidence. Preserve the strongest completed analytic controls where applicable. Charge lookahead, teacher preparation, solver, storage and failures. If the mechanism's gain is supplied by new information, a guard, an action-space change or more search, those benefits cannot be attributed to language pretraining. An absence of meaningful residual/economic opportunity stops the language route before allocation.

5. **Only then implement an adapted-scale test.** Prospectively fix identical role/input/target/mask/decoder, one partition, seed/budget and final checkpoint for requested 0.5B/1.5B comparisons; include strong numerical and architecture/pretraining attribution. Both sizes need real full-context loader, gradients, memory and cold full optimizer/RNG/cursor preservation gates. Any difference in preprocessing, training parameters, FLOPs or precision is disclosed. Original weights and stopped methods are not reused as trained starting checkpoints. Software readiness and teacher matching alone cannot launch a performance study.

6. **Measure the actual goal.** Fresh per-state inference, matched complete protected trajectories, literal DFF and DFF-ALT separately, unchanged D-SE selection and FULL BOTH-branch costs. Report common-protection controls separately; do not quietly replace the primary comparator or credit a safety guard as LLM benefit. Include inference, training, numerical preparation, teacher collection, solver, preservation and failure costs. Only a surviving fixed development effect proceeds to genuinely unused authorized confirmation.

No empirical gate for stages 2–6 is frozen or executed by this addendum. Counts, source checks and model size do not calibrate a 90% chance of a discovery. Do not infer a percentage distance to superiority.

## Focused literature challenge

Baseline bootstrapping and uncertainty-constrained offline policy improvement already exist. Their published guarantees do not automatically transfer to clustered voltage-control trajectories, an incompletely observed process or a neural language policy. The corresponding assumptions and support must be established for the actual task. [Laroche et al., SPIBB (2019)](https://proceedings.mlr.press/v97/laroche19a.html).

A subsequent analysis challenges some Soft-SPIBB guarantees and finds that useful safety bounds can require substantial data. This strengthens the need to distinguish a mathematical claim with verified assumptions from a verbal confidence promise. [Scholl et al., Safe Policy Improvement Approaches and their Limitations (2022)](https://arxiv.org/abs/2208.00724).

Graph-based volt-var policies are also prior art; a published study reports similar asymptotic rewards with slower convergence than vector policies, while examining robustness and readout design. Architectural complexity alone is not a reliable route to improvement. This is a literature result, not a prediction of HierGrid performance. [Lee et al., A Graph Policy Network Approach for Volt-Var Control (2021)](https://arxiv.org/abs/2109.12073).

A coordinator/sequence policy is therefore not novel merely because it uses an LM or preserves a baseline. A contribution would need a specific surviving mechanism and measured incremental benefit under the actual physical, information and cost comparison. Novelty remains unestablished.

## Resume point

Read `initial_reflection_target_compatibility_20261011/Verified_Initial_Contract_Checkpoint.json`, `deployment_role_binding_20261011/Read_Only_Critical_Binding.md`, `Protected_Terminal_Coordinator_Proposal.md` and `Saved_Continuation_Schema_Readiness_Note.md`. Current scientific/readiness owners have ended. No factorized numerical refit, model training, physics campaign or allocation is currently ready. The next preparation task is a complete causal-role/process binding and a decision on whether certified existing evidence can support a later-fork gate at all. Preserve UNKNOWN and record genuinely new work in `reseacrh progress.txt`.
