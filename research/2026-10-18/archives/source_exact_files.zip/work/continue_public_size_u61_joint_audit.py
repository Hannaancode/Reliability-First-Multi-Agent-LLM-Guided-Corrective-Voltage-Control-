"""One handoff binds both actual owners and owns one joint saved-output reader."""
import json,subprocess,time,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'outputs/critical_research_reset_20261010';EX=R/'public_size_u61_execution';OUT=R/'public_size_u61_handoff'
assert not OUT.exists();OUT.mkdir()
(OUT/'owner.claim').write_text(json.dumps({'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()}))
def read(p):return json.loads(p.read_text())
def save(stage,**rest):
    p=OUT/'status.tmp';p.write_text(json.dumps({'stage':stage,'updated_at_utc':datetime.now(timezone.utc).isoformat(),**rest},indent=2));p.replace(OUT/'status.json')
def command(pid):
    r=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert r.returncode==0;return r.stdout.strip()
bound={};save('binding_both_actual_owners')
for arm in ['public_0_5B','public_1_5B']:
    claim=read(EX/arm/'owner.claim');pid=claim['pid'];actual=command(pid)
    if actual:assert 'run_public_size_u61_colab.py' in actual and arm in actual
    else:assert read(EX/arm/'status.json')['finished_at_utc']
    bound[arm]={'pid':pid,'observed_command':actual,'already_ended':not bool(actual)}
(OUT/'Actual_Bound_Owners.json').write_text(json.dumps(bound,indent=2))
save('waiting_for_both_exact_owners',bound_owners=bound)
while True:
    alive=[]
    for arm,b in bound.items():
        actual=command(b['pid'])
        if actual and 'run_public_size_u61_colab.py' in actual and arm in actual:alive.append(arm)
    if not alive:break
    time.sleep(15)
for arm in bound:
    state=read(EX/arm/'status.json');assert state['finished_at_utc']
    if state['runtime_allocated'] and not state['runtime_released']:
        save('ended_attention_needed',arm=arm,reason='Exact runtime closure/release uncertain; no science or reader retry');raise SystemExit(1)
    if state['science_started'] and not state.get('all_actual_closed_artifacts_preserved'):
        save('ended_attention_needed',arm=arm,reason='Actual science evidence not fully preserved; no complete reader or model repeat');raise SystemExit(1)
assert not (R/'public_size_u61_external_audit').exists();save('one_joint_external_reader')
with (OUT/'reader_stdout.log').open('x') as stdout,(OUT/'reader_stderr.log').open('x') as stderr:
    result=subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8','work/audit_public_size_u61_outputs.py'],cwd=ROOT,stdout=stdout,stderr=stderr,timeout=1800,creationflags=subprocess.CREATE_NO_WINDOW)
save('joint_external_audit_ended',reader_exit_code=result.returncode)
raise SystemExit(result.returncode)
