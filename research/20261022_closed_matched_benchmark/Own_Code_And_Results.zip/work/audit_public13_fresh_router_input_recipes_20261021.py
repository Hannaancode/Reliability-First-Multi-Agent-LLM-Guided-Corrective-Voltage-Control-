"""Independent explicit source-reset arithmetic audit; no solver/model calls."""
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/public13_fresh_input_router_preparation_v2_20261021'


def main():
    import numpy as np
    protocol = json.loads((P / 'Prospective_Router_Protocol.json').read_text(encoding='utf-8'))
    recipes = np.load(P / 'All128_Source_Exact_Physical_Recipes.npz')
    assert protocol['seeds'] == list(range(1000, 1128))
    assert set(recipes.files) == {'sgen_p', 'sgen_q', 'load_p', 'load_q'}
    assert hashlib.sha256((P / 'All128_Source_Exact_Physical_Recipes.npz').read_bytes()).hexdigest() == protocol['source_binding']['recipes_sha256']
    for row, seed in enumerate(range(1000, 1128)):
        rng = np.random.RandomState(seed)
        mode = rng.choice([0, 1])
        p, q = np.zeros(12), np.zeros(12)
        if mode == 0:
            p[0] = -.5 * rng.uniform(1, 7)
            p[1] = -.8 * rng.uniform(1, 4)
            p[2] = -.3 * rng.uniform(1, 5)
        else:
            p[0] = rng.uniform(.5, 4)
            p[1] = rng.uniform(0, 4.51)
            p[2] = rng.uniform(0, 5)
            q[3] = .3 * rng.uniform(0, .2)
            p[4] = .5 * rng.uniform(2, 3)
            q[5] = .4 * rng.uniform(0, 10)
            p[10] = rng.uniform(.2, 3)
            p[11] = rng.uniform(0, 1.5)
        assert np.array_equal(p, recipes['sgen_p'][row])
        assert np.array_equal(q, recipes['sgen_q'][row])
        assert np.array_equal(recipes['load_p'][row], np.zeros_like(recipes['load_p'][row]))
        assert np.array_equal(recipes['load_q'][row], np.zeros_like(recipes['load_q'][row]))
    identities = json.loads((P / 'All128_Prospective_Identities.json').read_text(encoding='utf-8'))
    old = json.loads((R / 'outputs/public13_full_cohort_preparation_20261021/Protocol.json').read_text(encoding='utf-8'))
    roots = json.loads((R / 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json').read_text(encoding='utf-8'))['roots']
    prior = set(old['paid_prior_regimes']) | {r['noncontrolled_regime'] for r in roots}
    assert len(identities) == 128 and [r['seed'] for r in identities] == list(range(1000, 1128))
    assert len({r['noncontrolled_regime'] for r in identities}) == 128
    assert not prior & {r['noncontrolled_regime'] for r in identities}
    out = {'at_utc': datetime.now(timezone.utc).isoformat(),
           'status': 'PASS_INDEPENDENT_ALL128_SOURCE_RESET_ARITHMETIC_ID_ORDER_AND_SCOPED_NO_REPEAT_INPUT_AUDIT',
           'all128_exact_arrays': True, 'new128_vs_closed_prior_regime_intersections': 0,
           'actual_new_model_PF_optimizer_derivative_calls': 0,
           'reader_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'original_external_checkpoint_training_seed_overlap': 'UNKNOWN_NOT_CERTIFIED_UNSEEN_BY_PUBLISHED_WEIGHTS',
           'case_interpretation': 'Prospectively selected source-generated physical recipes, previously unexecuted in this closed local research stream. Not a separately published measured dataset or certified external training holdout.',
           'physics_worker_and_reader_launch_admission': 'NOT_READY'}
    with (P / 'Independent_Input_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out))


if __name__ == '__main__':
    main()
