"""Actual cached322root/native-cap/four-agent input checks. Zero new model or PF."""
import json,pickle,copy,hashlib,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=ROOT/'outputs/paper_framework_native_PV_port_20261021';out.mkdir(exist_ok=False);started=time.monotonic()
    import candidate_process_runtime
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np
    from transformers import AutoTokenizer
    from paper_framework_native_PV_port_20261021 import native_contract,request_to_native_Q,native_positive_refinement_menu,messages_for_zone,paper_normalizer
    tpa=ROOT/'outputs/tpa_native_second_identity_engineering_20261020'
    with (tpa/'PF0_before.pkl').open('rb') as f:initial=pickle.load(f)
    with (tpa/'PF1_before.pkl').open('rb') as f:root=pickle.load(f)
    root.sgen['q_mvar']=initial.sgen.q_mvar.to_numpy(copy=True)
    for key in ['bus','line','trafo','sgen','load','ext_grid','gen','shunt','switch']:assert root[key].equals(initial[key])
    fields=np.load(tpa/'PF0_fields.npz')
    for key in fields.files:assert np.array_equal(root[key].select_dtypes(include=[np.number]).to_numpy(dtype=float),fields[key],equal_nan=True)
    model=np.load(ROOT/'outputs/native_inverter_linear_reference_20261020/Linear_Problem.npz');assert np.array_equal(root.sgen.q_mvar.to_numpy(),model['root_q'])
    maxima=np.array(json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text())['native_column_max'])
    caps=.8*np.sqrt((1.2*maxima)**2-root.sgen.p_mw.to_numpy()**2);assert np.array_equal(caps,model['caps'])
    contract=native_contract(root.bus.index.to_numpy(),root.sgen.bus.to_numpy(),model['root_q'],caps,model['Y'])
    assert sorted(b for members in contract['zones'].values() for b in members)==list(root.bus.index)
    assert sorted(b for members in contract['PV_zones'].values() for b in members)==sorted(root.sgen.bus.tolist())
    # All devices exercised; original25Mvar teacher commands remain rejected.
    rejections=0;legal=0
    for index,bus in enumerate(contract['PV_bus_ids']):
        invalid=request_to_native_Q({'bus':str(bus),'q_mvar':25.},contract);assert invalid['valid'] is False and invalid['reason']=='native_cap_exceeded_no_rescale_or_clip';rejections+=1
        amount=float((caps[index]-model['root_q'][index])/2)
        if amount>0:
            action=request_to_native_Q({'bus':str(bus),'q_mvar':amount},contract);assert action['valid'] and np.all(np.abs(action['native_Q'])<=caps+1e-12)
            expected=model['root_q'].copy();expected[index]+=amount;assert np.array_equal(action['native_Q'],expected);legal+=1
    menu=native_positive_refinement_menu(contract);assert len(menu)==38*9
    for row in menu:assert np.isfinite(row['native_absolute_Q_Mvar']).all() and (np.abs(row['native_absolute_Q_Mvar'])<=caps+1e-12).all()
    tokenizer=AutoTokenizer.from_pretrained(str(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'),local_files_only=True,trust_remote_code=False)
    packets=[];states=[('shared322engineering_root',fields['res_bus'][:,0]),('observed_TPA_following_state',np.load(tpa/'PF1_fields.npz')['res_bus'][:,0])]
    for name,vm in states:
        for zone in contract['zones']:
            messages=messages_for_zone(contract,vm,zone);assert messages is not None
            ids=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True)
            assert len(ids)+384<=8192,'This entire full-length port stops before inference; no cropping/dropped zones'
            packets.append({'engineering_current_context_not_forwarded':name,'zone':zone,'messages':messages,'actual_input_ids':ids,
                            'attention_mask':[1]*len(ids),'input_tokens':len(ids),'input_sha256':hashlib.sha256(json.dumps(messages,sort_keys=True).encode()).hexdigest()})
    solved=np.load(ROOT/'outputs/native_inverter_linear_reference_20261020/Candidate_Fields.npz')['res_bus'][:,0]
    assert all(messages_for_zone(contract,solved,z) is None for z in contract['zones'])
    normalize,ast_hash=paper_normalizer();assert normalize({'bus':'52','q_mvar':100})=={'add_shunts_q_mvar':{'52':100.}}
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ACTUAL322_CACHED_ROOT_NATIVE_PV_FOUR_ZONE_SOURCE_PARSER_AND_FULL_TOKEN_PORT_SOFTWARE_ONLY',
            'named_method':'PAPER_FRAMEWORK_NATIVE_PV_PORT_V1_NOT_UNCHANGED_FEDERATION_CONTROLLER',
            'original_weights_and_original_source_modified':False,'native_buses':322,'native_devices':38,
            'all38_legacy25Mvar_requests_rejected_without_rescale_clip_or_fill':rejections,'all38_literal_valid_native_requests':legal,
            'explicitly_new_hardware_normalized_refinement_menu_candidates':len(menu),'menu_rule':'Nine original source Q fractions(25..300)/300 applied to CURRENT native positive headroom; raw model outputs never rescaled.',
            'model_role_limit':'Original positive-support proposer is one-sided; no bidirectional/native-control parity claim. Every port/information/guard/horizon change must be labelled. New full-vector numerical hybrid is a separate method.',
            'deterministic_partition':{'roots':contract['partition_roots'],'all_bus_counts':{z:len(v) for z,v in contract['zones'].items()},'PV_counts':{z:len(v) for z,v in contract['PV_zones'].items()}},
            'complete_current_packets':len(packets),'maximum_input_tokens':max(p['input_tokens'] for p in packets),'new_port_context':8192,'max_new_tokens':384,
            'actual_local_tokenizer_encodings':len(packets),'no_truncation_or_zone_drop':True,'full_actual_model_loader_memory_cold_and_physics':'NOT_EXECUTED_NOT_READY_FROM_SOFTWARE',
            'source_paper_normalizer_AST_sha256':ast_hash,'source_sha256':sha(ROOT/'work/paper_framework_native_PV_port_20261021.py'),
            'new_model_forward_PF_optimizer_derivative_forecast_solve_GPU_calls':0,'workflow_seconds':time.monotonic()-started}
    for name,obj in [('Software_Readiness.json',result),('All8_Full_Current_Packets.json',packets)]:
        with (out/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,allow_nan=False)
    print(json.dumps({k:result[k] for k in ['native_buses','native_devices','maximum_input_tokens','complete_current_packets','new_model_forward_PF_optimizer_derivative_forecast_solve_GPU_calls']}))
if __name__=='__main__':main()
