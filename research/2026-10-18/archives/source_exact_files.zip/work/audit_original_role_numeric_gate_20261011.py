"""Independent closed-run reader: no estimator loading, fitting, or prediction APIs."""
import ctypes, gzip, hashlib, json, math, os, sys, time, traceback, zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import frozen_checks, seal
from public_size_local_preservation_v2 import extended

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/critical_research_reset_20261010/original_role_numeric_gate_20261011'
RAW = Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2b_training_inputs.zip')
MEMBER = 'hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'
RAW_SHA = '7b22162d0abd92ccb64473fcef5bb300ee12416ce22ea6ce03e60fefaa9154eb'
FORBIDDEN = {'scenario_id','scenario_type','severity','world_sha256','branch','messages',
    'assistant','target','label','labels','after','old_global','new_global','proposed_action',
    'verification','selected_trial','state_summary','confidence','candidate_action_for_coordinator'}

def now(): return datetime.now(timezone.utc).isoformat()
def compact(v): return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
def bh(b): return hashlib.sha256(b).hexdigest()
def sha(p): return bh(p.read_bytes())
def read(p): return json.loads(p.read_text(encoding='utf8'))
def write(p,v):
    with p.open('x',encoding='utf8') as stream:
        json.dump(v,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.flush();os.fsync(stream.fileno())
def timestamp(s): return datetime.fromisoformat(s)

def typed(v):
    if v is None: return ['null']
    if isinstance(v,bool): return ['bool',v]
    if isinstance(v,(int,float)):
        assert math.isfinite(v);numerator,denominator=v.as_integer_ratio()
        return ['number',str(numerator),str(denominator)]
    if isinstance(v,str): return ['string',v]
    if isinstance(v,list): return ['list',[typed(x) for x in v]]
    assert isinstance(v,dict)
    return ['object',[[k,typed(v[k])] for k in sorted(v)]]
def identity(v): return bh(compact(typed(v)).encode())

def causal(v):
    if isinstance(v,dict):
        for k,x in v.items():
            assert isinstance(k,str) and k.lower() not in FORBIDDEN;causal(x)
    elif isinstance(v,list):
        for x in v: causal(x)
    elif isinstance(v,float): assert math.isfinite(v)
    else: assert v is None or isinstance(v,(str,int,bool))

def features(v,path=()):
    key=compact(list(path));result={}
    if isinstance(v,dict):
        result['object|'+key]=1.0
        for k in sorted(v): result.update(features(v[k],path+(k,)))
    elif isinstance(v,list):
        result['array|'+key]=float(len(v))
        for i,x in enumerate(v): result.update(features(x,path+(i,)))
    elif v is None: result['null|'+key]=1.0
    elif isinstance(v,bool): result['boolean|'+key]=float(v)
    elif isinstance(v,(int,float)): result['number|'+key]=float(v)
    elif isinstance(v,str): result['string|'+key+'|'+compact(v)]=1.0
    else: raise TypeError(type(v))
    return result

def admissible(a,p):
    if a is None: return True
    if not isinstance(a,dict) or set(a)!={'add_shunts_q_mvar'}: return False
    shunts=a['add_shunts_q_mvar']
    if not isinstance(shunts,dict) or not shunts: return False
    for bus,q in shunts.items():
        if str(bus) not in p['local_measurements']['bus_voltages']: return False
        if isinstance(q,bool) or not isinstance(q,(int,float)) or not math.isfinite(q) or not 0<q<=450: return False
    return sum(shunts.values())<=450

def owner_is_running(pid):
    if os.name=='nt':
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong]
        kernel.OpenProcess.restype=ctypes.c_void_p
        handle=kernel.OpenProcess(0x1000,0,pid)
        if not handle:
            assert ctypes.get_last_error()==87,'Cannot certify production owner ended'
            return False
        try:
            code=ctypes.c_ulong()
            kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
            assert kernel.GetExitCodeProcess(handle,ctypes.byref(code))
            return code.value==259
        finally:
            kernel.CloseHandle.argtypes=[ctypes.c_void_p];kernel.CloseHandle(handle)
    try: os.kill(pid,0);return True
    except ProcessLookupError: return False

def compare(expected,actual,path='root'):
    if isinstance(expected,dict):
        assert isinstance(actual,dict),path
        for k,v in expected.items(): assert k in actual,(path,k);compare(v,actual[k],path+'.'+k)
    elif isinstance(expected,list):
        assert isinstance(actual,list) and len(expected)==len(actual),path
        for i,(a,b) in enumerate(zip(expected,actual)): compare(a,b,path+'['+str(i)+']')
    elif isinstance(expected,float):
        assert isinstance(actual,(int,float)) and math.isfinite(actual) and math.isclose(expected,actual,rel_tol=1e-13,abs_tol=1e-14),path
    else: assert expected==actual,(path,expected,actual)

def independent_metrics(records,decoded,actions):
    byworld=defaultdict(list)
    assert len(records)==len(decoded)
    for r,p in zip(records,decoded): byworld[r['world_sha256']].append((r,p))
    worlds=[]
    for w,items in sorted(byworld.items()):
        non=[(r,p) for r,p in items if r['action'] is not None]
        null=[(r,p) for r,p in items if r['action'] is None]
        hit=sum(r['action_sha256']==p for r,p in items)
        bus=sum(actions[p] is not None and set(actions[p]['add_shunts_q_mvar'])==set(r['action']['add_shunts_q_mvar']) for r,p in non)
        worlds.append({'world_sha256':w,'pairs':len(items),'exact_hits':hit,'exact_fraction':hit/len(items),
            'nonnull_pairs':len(non),'nonnull_hits':sum(r['action_sha256']==p for r,p in non),
            'nonnull_bus_only_hits':bus,'nonnull_predicted_null':sum(actions[p] is None for r,p in non),
            'null_pairs':len(null),'null_hits':sum(r['action_sha256']==p for r,p in null),
            'null_predicted_nonnull':sum(actions[p] is not None for r,p in null),
            'rows':sum(r['multiplicity'] for r,p in items),
            'row_exact_hits':sum(r['multiplicity'] for r,p in items if r['action_sha256']==p)})
    nonw=[w for w in worlds if w['nonnull_pairs']];nullw=[w for w in worlds if w['null_pairs']]
    return {'equal_world_exact_action':sum(w['exact_fraction'] for w in worlds)/len(worlds),
        'pair_exact_hits':sum(w['exact_hits'] for w in worlds),'pairs':len(records),
        'row_exact_fraction':sum(w['row_exact_hits'] for w in worlds)/sum(w['rows'] for w in worlds),
        'rows':sum(w['rows'] for w in worlds),
        'equal_world_nonnull_exact':None if not nonw else sum(w['nonnull_hits']/w['nonnull_pairs'] for w in nonw)/len(nonw),
        'equal_world_nonnull_bus_only_match':None if not nonw else sum(w['nonnull_bus_only_hits']/w['nonnull_pairs'] for w in nonw)/len(nonw),
        'equal_world_null_exact':None if not nullw else sum(w['null_hits']/w['null_pairs'] for w in nullw)/len(nullw),
        'error_worlds':sum(w['exact_hits']<w['pairs'] for w in worlds),
        'nonnull_error_worlds':sum(w['nonnull_hits']<w['nonnull_pairs'] for w in nonw),'worlds':worlds}

def run():
    started=time.perf_counter();prep=extended(BASE/'preparation');execution=extended(BASE/'execution')
    status=read(execution/'status.json');closed=read(execution/'Closed_Manifest.json');owner=read(execution/'owner.claim')
    assert status['state'] in {'ENDED_COMPLETE','ENDED_PARTIAL'} and status['manifest_closed'] is True
    assert status['actual_pid']==owner['actual_pid'] and not owner_is_running(owner['actual_pid'])
    proto=read(prep/'Protocol.json');locks=read(prep/'Source_Lock.json');readerlock=read(prep/'Reader_Source_Lock.json')
    readiness=ROOT/'work/original_role_numeric_reader_readiness_20261011.json'
    ready=read(readiness)
    assert sha(Path(__file__))==readerlock['reader_source_sha256']==ready['reader_source_sha256']
    assert sha(readiness)==readerlock['reader_readiness_sha256']
    assert timestamp(ready['prepared_at_utc'])<timestamp(owner['at_utc'])
    assert timestamp(proto['prepared_at_utc'])<timestamp(owner['at_utc'])<=timestamp(closed['closed_at_utc'])<=timestamp(status['at_utc'])
    production=ROOT/'work/run_original_role_numeric_gate_20261011.py';interface=ROOT/'work/full_current_compact_output_interface_v1.py'
    assert sha(production)==locks['production_source_sha256']==proto['source_sha256']==closed['source_sha256']==owner['source_sha256']
    assert sha(interface)==locks['interface_sha256']
    assert sha(prep/'Protocol.json')==closed['protocol_sha256']==owner['protocol_sha256']
    compare({'production_source_sha256':sha(production),'protocol_sha256':sha(prep/'Protocol.json'),
        'interface_sha256':sha(interface),'evidence_utils_sha256':sha(ROOT/'work/candidate_process_evidence_utils.py'),
        'preservation_utils_sha256':sha(ROOT/'work/public_size_local_preservation_v2.py')},ready)
    assert proto['source_member']==MEMBER and proto['source_member_sha256']==RAW_SHA
    assert proto['fits_per_arm']==1 and proto['hyperparameter_sweeps']==0 and proto['scientific_retries']==0 and proto['bound_seconds']==300
    assert proto['arms']['extra_trees']=={'n_estimators':512,'criterion':'gini','max_depth':None,'min_samples_split':2,'min_samples_leaf':1,'max_features':1.0,'bootstrap':False,'n_jobs':2,'random_state':20261011,'class_weight':None}
    assert set(closed['members'])=={p.name for p in execution.iterdir() if p.is_file()}-{'Closed_Manifest.json','status.json'}
    for name,descriptor in closed['members'].items():
        assert Path(name).name==name and execution.joinpath(name).stat().st_size==descriptor['bytes']
        assert sha(execution/name)==descriptor['sha256'],name
    out=extended(BASE/'independent_audit');out.mkdir(exist_ok=False)
    write(out/'reader.claim',{'actual_pid':os.getpid(),'at_utc':now(),'reader_source_sha256':sha(Path(__file__)),
        'closed_production_manifest_sha256':sha(execution/'Closed_Manifest.json'),'no_estimator_calls':True})
    cost={'new_estimator_fits':0,'new_estimator_prediction_calls':0,'new_pretrained_PF_optimizer_controller_forecast_cloud_calls':0,
        'independent_saved_score_decodes':0,'independent_numeric_analysis_paid':True,'old_archive_rehashes':0}
    report={'gate':'UNKNOWN','all_passed':False};failure=None
    try:
        sys.path.insert(0,str(ROOT/'work/original_role_numeric_dependencies_20261011'))
        import numpy as np
        assert np.__version__=='2.0.2'
        with zipfile.ZipFile(RAW) as archive: raw=archive.read(MEMBER)
        assert bh(raw)==RAW_SHA
        rows=[];pairs={};actions={};worlds=set()
        for i,line in enumerate(raw.decode('utf8').splitlines()):
            original=json.loads(line);users=[m for m in original['messages'] if m['role']=='user']
            assert len(users)==1 and original['messages'][-1]['role']=='assistant'
            observation=json.loads(users[0]['content']);teacher=json.loads(original['messages'][-1]['content'])
            packet={'zone':observation['zone'],'local_measurements':observation['local_measurements']}
            assert isinstance(packet['zone'],str) and isinstance(packet['local_measurements'],dict);causal(packet)
            w=bh(str(observation['scenario_id']).encode());k=identity(packet);a=teacher['proposed_action'];ak=identity(a)
            worlds.add(w);actions[ak]=a;rows.append({'row_index':i,'world_sha256':w,'input_sha256':k,'action_sha256':ak})
            if (w,k) not in pairs: pairs[w,k]={'world_sha256':w,'input_sha256':k,'packet':packet,'action':a,'action_sha256':ak,'multiplicity':0,'coordinator_rows':0}
            assert pairs[w,k]['action_sha256']==ak
            pairs[w,k]['multiplicity']+=1;pairs[w,k]['coordinator_rows']+=bool(teacher.get('requires_coordinator_review',False) or teacher.get('candidate_action_for_coordinator') is not None)
        assert len(rows)==16000 and len(worlds)==109
        adjacency={w:set() for w in worlds};byinput=defaultdict(set);labels=defaultdict(set)
        for (w,k),r in pairs.items(): byinput[k].add(w);labels[k].add(r['action_sha256'])
        for ws in byinput.values():
            for w in ws: adjacency[w].update(ws-{w})
        remaining=set(worlds);components=[]
        while remaining:
            todo=[min(remaining)];component=set()
            while todo:
                w=todo.pop()
                if w in component: continue
                component.add(w);todo.extend(adjacency[w]-component)
            remaining-=component;ws=sorted(component)
            components.append({'component_sha256':bh(compact(ws).encode()),'world_sha256':ws})
        components.sort(key=lambda c:c['component_sha256'])
        heldworlds={w for c in components[:math.ceil(.2*len(components))] for w in c['world_sha256']}
        ordered=[pairs[k] for k in sorted(pairs)];fit=[r for r in ordered if r['world_sha256'] not in heldworlds];held=[r for r in ordered if r['world_sha256'] in heldworlds]
        for r in rows: r['partition']='HELD' if r['world_sha256'] in heldworlds else 'FIT'
        assert fit and held and not ({r['input_sha256'] for r in fit}&{r['input_sha256'] for r in held})
        if (execution/'All_Row_Identities.json').exists(): compare(rows,read(execution/'All_Row_Identities.json'))
        if (execution/'World_Components.json').exists(): compare(components,read(execution/'World_Components.json'))
        terminal_partial=(execution/'Failure.json').exists() or status['state']=='ENDED_PARTIAL'
        if (execution/'Environment.json').exists():
            environment=read(execution/'Environment.json')
            compare({'numpy':'2.0.2','scipy':'1.16.3','sklearn':'1.7.2','joblib':'1.5.2','threadpoolctl':'3.6.0','source_interface_sha256':sha(interface)},environment)
        else: assert terminal_partial
        actualcost=read(execution/'Actual_Costs.json');journal=[json.loads(x) for x in (execution/'journal.jsonl').read_text('utf8').splitlines()]
        assert all(journal[i]['elapsed_seconds']<=journal[i+1]['elapsed_seconds'] for i in range(len(journal)-1))
        assert all(math.isfinite(e['elapsed_seconds']) and e['elapsed_seconds']>=0 for e in journal)
        assert all(timestamp(owner['at_utc'])<=timestamp(e['at_utc'])<=timestamp(closed['closed_at_utc']) for e in journal)
        compare({'new_pretrained_forwards':0,'new_optimizer_PF_controller_forecast_cloud_calls':0},actualcost)
        assert all(not isinstance(v,(int,float)) or (math.isfinite(v) and v>=0) for v in actualcost.values())
        events=Counter(e['event'] for e in journal);assert events['extra_trees_fit_attempt']<=1 and events['extra_trees_fit_return']<=1
        assert actualcost['numeric_estimator_fits']==events['extra_trees_fit_return']
        if terminal_partial:
            report={'gate':'UNKNOWN_OWNER_PARTIAL','all_passed':True,'complete_performance_certified':False,
                'closed_immutable_members_verified':len(closed['members']),'raw_rows':len(rows),'worlds':len(worlds),'no_retry':True}
        else:
            for name,records in [('FIT',fit),('HELD',held)]:
                with gzip.open(execution/(name+'_Current_Packets_And_Targets.json.gz'),'rt',encoding='utf8') as stream: compare(records,json.load(stream))
            fs=[features(r['packet']) for r in fit];hs=[features(r['packet']) for r in held]
            symbols=sorted(set().union(*(set(f) for f in fs)));unknown=sorted(set().union(*(set(h) for h in hs))-set(symbols))
            means=[];scales=[]
            for s in symbols:
                present=np.array([f[s] for f in fs if s in f],dtype=np.float64)
                means.append(float(present.mean()) if s.startswith('number|') else 0.0)
                sd=float(present.std()) if s.startswith('number|') else 1.0;scales.append(max(sd,1e-6))
            def matrix(items):
                x=np.zeros((len(items),2*len(symbols)),dtype=np.float64)
                for j,s in enumerate(symbols):
                    for i,item in enumerate(items):
                        if s in item: x[i,j]=(item[s]-means[j])/scales[j];x[i,len(symbols)+j]=1.0
                return x
            xf=matrix(fs);xh=matrix(hs);classes=sorted({r['action_sha256'] for r in fit}|{identity(None)});actions[identity(None)]=None
            classindex={a:i for i,a in enumerate(classes)};y=np.array([classindex[r['action_sha256']] for r in fit]);wc=Counter(r['world_sha256'] for r in fit);nw=len(worlds-heldworlds)
            weights=np.array([1/(nw*wc[r['world_sha256']]) for r in fit],dtype=np.float64)
            compare({'symbols':symbols,'means':means,'scales':scales,'action_classes':classes,'actions':actions},read(execution/'Encoder.json'))
            arrays=np.load(execution/'Prepared_Numeric_Arrays.npz',allow_pickle=False)
            for name,value in [('FIT',xf),('HELD',xh),('targets',y),('weights',weights)]: assert np.array_equal(value,arrays[name]),name
            assert arrays['FIT'].dtype==arrays['HELD'].dtype==np.dtype('float64') and np.isclose(weights.sum(),1)
            collisions={};contradictions={};keys={}
            for name,x,records in [('fit_f64',xf,fit),('held_f64',xh,held),('fit_tree_f32',xf.astype('float32'),fit),('held_tree_f32',xh.astype('float32'),held)]:
                groups=defaultdict(set);ys=defaultdict(set);keys[name]=[]
                for row,r in zip(x,records):
                    key=bh(row.tobytes());keys[name].append(key);groups[key].add(r['input_sha256']);ys[key].add(r['action_sha256'])
                collisions[name]=sum(len(v)>1 for v in groups.values());contradictions[name]=sum(len(v)>1 for v in ys.values())
            support={'FIT_worlds':nw,'HELD_worlds':len(heldworlds),'components':len(components),'FIT_pairs':len(fit),'HELD_pairs':len(held),
                'HELD_unique_inputs':len({r['input_sha256'] for r in held}),'HELD_nonnull_pairs':sum(r['action'] is not None for r in held),
                'all_rows':len(rows),'all_world_pairs':len(ordered),'all_unique_inputs':len(byinput),'shared_FIT_HELD_inputs':0,
                'shared_FIT_HELD_F32_matrix_inputs':len(set(keys['fit_tree_f32'])&set(keys['held_tree_f32'])),
                'unknown_HELD_encoding_symbols':unknown,'encoding_collisions':collisions,'contradictory_matrix_action_classes':contradictions,
                'FIT_action_classes':len(classes),'HELD_unseen_action_pairs':sum(r['action_sha256'] not in classindex for r in held),
                'conflicting_exact_inputs':sum(len(v)>1 for v in labels.values()),'coordinator_HELD_rows_descriptive_only':sum(r['coordinator_rows'] for r in held)}
            compare(support,read(execution/'Support_And_Partition.json'));results=read(execution/'Results.json');compare(support,results['support'])
            if results['disposition']=='SUPPORT_UNKNOWN_NO_FITS':
                assert unknown or support['conflicting_exact_inputs'] or collisions['fit_f64'] or collisions['held_f64']
                assert actualcost['numeric_estimator_fits']==actualcost['numeric_held_prediction_calls']==actualcost['numeric_fresh_reload_prediction_calls']==0
                report={'gate':'SUPPORT_UNKNOWN_NO_FITS','all_passed':True,'support':support,'complete_performance_certified':False}
            else:
                assert results['disposition']=='COMPLETE' and closed['partial_or_complete']=='COMPLETE'
                compare({'numeric_estimator_fits':1,'numeric_held_prediction_calls':3,'numeric_fresh_reload_prediction_calls':1},actualcost)
                for event in ['extra_trees_fit_attempt','extra_trees_fit_return','fresh_tree_reload_prediction_attempt','fresh_tree_reload_prediction_return','complete_fixed_gate']: assert events[event]==1,event
                assert actualcost['workflow_seconds_before_manifest']<proto['bound_seconds'] and max(e['elapsed_seconds'] for e in journal)<proto['bound_seconds']
                scores=np.load(execution/'HELD_Scores_And_Masks.npz',allow_pickle=False);tree=scores['tree_probabilities'];prior=scores['prior_scores'];dist=scores['nearest_distances'];mask=scores['legal_mask']
                shape=(len(held),len(classes));assert tree.shape==prior.shape==mask.shape==shape and dist.shape==(len(held),len(fit))
                assert mask.dtype==np.dtype('bool') and np.isfinite(tree).all() and (tree>=0).all() and np.allclose(tree.sum(axis=1),1,rtol=0,atol=1e-12)
                assert np.isfinite(dist).all() and (dist>=0).all()
                expectedmask=np.array([[admissible(actions[a],r['packet']) for a in classes] for r in held],dtype=bool)
                assert np.array_equal(mask,expectedmask) and mask[:,classindex[identity(None)]].all()
                expectedprior=np.tile(np.bincount(y,weights=weights,minlength=len(classes)),(len(held),1))
                assert np.array_equal(prior,expectedprior) and np.allclose(prior.sum(axis=1),1,atol=1e-12)
                decoded={name:[classes[int(j)] for j in np.argmax(np.where(mask,value,-np.inf),axis=1)] for name,value in [('extra_trees',tree),('weighted_majority',prior)]}
                decoded['nearest_current']=[]
                for i,r in enumerate(held):
                    order=sorted(range(len(fit)),key=lambda j:(dist[i,j],j));eligible=[j for j in order if admissible(fit[j]['action'],r['packet'])]
                    decoded['nearest_current'].append(identity(None) if not eligible else fit[eligible[0]]['action_sha256'])
                compare(decoded,read(execution/'Predictions.json'));cost['independent_saved_score_decodes']=3
                for name,selected in decoded.items(): assert all(p in classindex and admissible(actions[p],r['packet']) for p,r in zip(selected,held)),name
                reloadrecord=read(execution/'Fresh_Reload_Record.json');fresh=np.load(execution/'Fresh_Reload_Tree_Probabilities.npy',allow_pickle=False);observedclasses=sorted(set(y.tolist()))
                compare({'model_sha256':sha(execution/'Extra_Trees_Final.joblib'),'classes':observedclasses,'fresh_classes':observedclasses,
                    'all_scores_exact':True,'HELD_cases':len(held),'actual_held_reload_prediction_calls':1},reloadrecord)
                assert np.array_equal(fresh,tree[:,observedclasses]) and bh(fresh.tobytes())==reloadrecord['fresh_probabilities_sha256']==reloadrecord['original_probabilities_sha256']
                independent={name:independent_metrics(held,selected,actions) for name,selected in decoded.items()};compare(independent,results['arms'])
                strongest=max(independent,key=lambda name:(independent[name]['equal_world_exact_action'],name));best=independent[strongest]
                supported=len(heldworlds)>=20 and support['HELD_unique_inputs']>=60 and support['HELD_nonnull_pairs']>=20 and not unknown and not support['conflicting_exact_inputs'] and not any(contradictions.values())
                gate=('SUPPORT_UNKNOWN_NO_SCALE_LAUNCH' if not supported else 'STOP_TEACHER_IMITATION_SCALE_PRIORITY_NUMERICAL_CEILING' if best['equal_world_exact_action']>=.95 else 'RESIDUAL_IMITATION_SUPPORT_ONLY_NO_AUTOMATIC_SCALE_LAUNCH' if best['error_worlds']>=5 and best['nonnull_error_worlds']>=3 else 'INSUFFICIENT_CLUSTERED_ERROR_SUPPORT_NO_SCALE_LAUNCH')
                compare({'strongest_control':strongest,'fixed_gate':gate,'all_fresh_tree_scores_exact':True,'no_automatic_model_launch':True,
                    'physical_performance_and_DSE_advantage':'UNMEASURED','coordinator_and_global_required_role_not_learned':True},results)
                report={'gate':gate,'all_passed':True,'support':support,'arms':independent,'strongest_control':strongest,
                    'complete_performance_certified':True,'fresh_reload_record_and_class_scores_verified':True,
                    'numeric_superiority_capacity_and_physical_claims_not_certified':True,'no_automatic_model_launch':True,
                    'saved_NN_distance_provenance_checked_equations_not_reexecuted':True,
                    'cold_reloaded_tree_scores_verified_estimator_equations_not_replayed':True}
        assert not any(name=='torch' or name=='transformers' or name.startswith('sklearn') or name=='joblib' for name in sys.modules)
    except BaseException as error:
        failure=error;report={'gate':'INDEPENDENT_AUDIT_FAIL_NO_RETRY','all_passed':False,'error':repr(error),'traceback':traceback.format_exc()}
    fresh=frozen_checks();assert len(fresh['checks'])==9;write(out/'Fresh_Frozen_Asset_Checks.json',fresh)
    write(out/'Independent_Audit.json',report);cost['workflow_seconds_before_seal']=time.perf_counter()-started;write(out/'Actual_Reader_Costs.json',cost)
    files={p.name:p for p in out.iterdir() if p.is_file()}
    files.update({'sources/reader.py':Path(__file__),'sources/production.py':production,'sources/interface.py':interface,
        'sources/evidence_utils.py':ROOT/'work/candidate_process_evidence_utils.py','sources/reader_readiness.json':readiness})
    for p in prep.iterdir():
        if p.is_file(): files['preparation/'+p.name]=p
    for p in execution.iterdir():
        if p.is_file(): files['execution/'+p.name]=p
    archive=seal(out,files,'Independent_Original_Role_Numeric_Gate.zip')
    write(out/'Actual_Reader_Final_Workflow_Cost.json',{'workflow_seconds_including_checks_seal':time.perf_counter()-started,
        'new_estimator_fit_prediction_PF_calls':0,'old_archive_rehashes':0,'all_reader_numeric_and_IO_cost_paid':True})
    print(compact({'audit':report,'archive':archive,'workflow_seconds':time.perf_counter()-started}))
    if failure is not None: raise RuntimeError('Independent audit failed; retained once, no retry') from failure

if __name__=='__main__': run()
