"""Three real software children: partial JSON, atomic claim, adverse exit. Zero PF."""
import argparse,json,os,sys,time
from datetime import datetime,timezone,timedelta
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from exact_two_paid_query_engineering_20261018 import admit,now,PYTHON
from prospective_query_custody_v2_20261019 import bind
B=R/'outputs/prospective_query_custody_v2_20261019'

def env():return bind({'B':B,'PYTHON':PYTHON,'admit':admit,'now':now},__file__)
def child(mode):
    p=read(B/'Protocol.json');out=B/mode
    if mode=='split':
        out.mkdir(exist_ok=False);payload=json.dumps({'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'source_sha256':sha(__file__),'protocol_sha256':sha(B/'Protocol.json')})
        with (out/'owner.claim').open('x',encoding='utf-8') as f:
            f.write(payload[:len(payload)//2]);f.flush();os.fsync(f.fileno());time.sleep(.4);f.write(payload[len(payload)//2:]);f.flush();os.fsync(f.fileno())
        begun=time.perf_counter()
        while not (out/'Launcher_ACK.json').exists():admit(p);assert time.perf_counter()-begun<60;time.sleep(.025)
        a=read(out/'Launcher_ACK.json');assert a['actual_pid']==os.getpid() and a['actual_parent_pid']==os.getppid()
    else:env()['claim'](out,p)
    code=7 if mode=='adverse' else 0
    put(out/'Result.json',{'status':'LABELLED_SOFTWARE_CHILD','scientific_calls':0,'expected_exit':code});manifest(out);raise SystemExit(code)

def main():
    B.mkdir(exist_ok=False);begun=time.perf_counter()
    p={'status':'FROZEN_BEFORE_SOFTWARE_CHILDREN','absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=240)).isoformat(),'fixed_bound_seconds':240,'source_sha256':{str(Path(__file__).relative_to(R)):sha(__file__),'work/prospective_query_custody_v2_20261019.py':sha(R/'work/prospective_query_custody_v2_20261019.py')},'fixed_cases':['split','atomic','adverse'],'all_scientific_calls':0,'scope':'Software process admission/atomic write/retained handle only; no physical/model success claim.'};put(B/'Protocol.json',p)
    h=env();results={}
    for mode,expected in [('split',0),('atomic',0),('adverse',7)]:
        code=h['launch'](Path(__file__),mode,B/mode,p);assert code==expected
        a=read(B/(mode+'_End_ACK.json'));assert a['exit_code']==expected and a['OS_launcher_exit_code_from_original_retained_handle']
        if mode=='split':assert a['partial_claim_reads']>0
        assert read(B/mode/'Result.json')['scientific_calls']==0;results[mode]=a
    put(B/'Results.json',{'status':'PASS_THREE_REAL_ZERO_SCIENCE_CUSTODY_CASES','cases':results,'workflow_seconds':time.perf_counter()-begun,'new_scientific_calls':0,'old_worker_sources_changed':False,'future_only_adoption_requires_new_prospective_protocol':True});manifest(B);print(json.dumps({'custody_cases':3,'status':'PASS','new_scientific_calls':0}))
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    for mode in ('split','atomic','adverse'):parser.add_argument('--'+mode,action='store_true')
    a=parser.parse_args();found=next((m for m in ('split','atomic','adverse') if getattr(a,m)),None)
    if found:child(found)
    else:main()
