"""Saved exact native arguments plus first independent result extraction."""
from reflection118_chronological_core_20261022 import *

def audit(directory):
    import numpy as np,pandas as pd
    from strict_saved_native_input_match_v2_20261018 import require_same
    from native_solver_input_identity_v3_20261023 import map_paid_return
    from r118_dff_missing_continuation_core_20261023 import saved_net
    maximum=0.;count=0
    for path in sorted(Path(directory).glob('identity_*/Receipt.json')):
        d=path.parent;r=read(path);n=decode(d,r['new_native_arguments']);o=decode(d,r['old_native_arguments'])
        require_same(n['ppci'],o['ppci'],'independent_native_ppci')
        require_same(n['algorithm_options'],o['algorithm_options'],'independent_native_options')
        require_same(n['algorithm_kwargs'],o['algorithm_kwargs'],'independent_native_kwargs')
        assert n['proof']==o['proof'] and n['proof']['algorithm_invocations']==0
        ref=r['reference'];assert sha(R/ref['source'])==ref['source_sha256']
        old_before=saved_net(R/r['reference_directory'],ref['before']);old_after=saved_net(R/r['reference_directory'],ref['after'])
        target=saved_net(d,r['before']);mapped=saved_net(d,r['after'])
        frames_equal(n['net'],target);frames_equal(o['net'],old_before)
        reconstructed=map_paid_return(n,old_after)
        frames_equal(mapped,target);frames_equal(reconstructed,mapped)
        assert np.array_equal(mapped.res_bus.vm_pu.values,old_after.res_bus.vm_pu.values)
        for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
            a=reconstructed[name].select_dtypes(include=[np.number]).to_numpy(float);b=mapped[name].select_dtypes(include=[np.number]).to_numpy(float)
            assert a.shape==b.shape and np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True)
            finite=np.isfinite(a)&np.isfinite(b);maximum=max(maximum,float(np.max(abs(a[finite]-b[finite]),initial=0.)))
        count+=1
    return dict(status='PASS_ALL_EXACT_NATIVE_ARGUMENT_AND_RESULT_MAPPING_RECEIPTS',identity_receipts=count,independent_native_result_extractions=count,new_native_conversion_or_PF_model_calls=0,maximum_reconstructed_field_delta=maximum)
