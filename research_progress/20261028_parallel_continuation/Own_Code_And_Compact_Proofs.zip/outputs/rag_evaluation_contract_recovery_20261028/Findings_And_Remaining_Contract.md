# RAG evaluation evidence recovered from the supplied notebook

The saved cell6 output contains all500 ordered question, generated-answer and reference-answer triples. Two independent text parsers agree on every field. This recovers historical printed evidence without generating an answer or rerunning a metric. It does not recover the original model state or certify the execution independently.

The corresponding recipe uses the public Qwen2.5-0.5B-Instruct model, three retrieved items, greedy generation with a256-token output bound and a seed42 sample. No adapter is loaded in this cell. The exact model revisions, dataset bytes/order and saved FAISS index remain unresolved.

Cell2 indexes the question and answer fields from the same named theory JSONL that cell6 samples for evaluation. This is an in-corpus retrieval recipe, not evidence of generalisation to unseen source documents. The actual saved index must be recovered before making per-case overlap claims. Existing groundedness is an embedding-cosine proxy with threshold0.55 and must remain distinct from factual correctness.

The NLI experiment in cells15/16 is a separate closed-book baseline. Cell18's342-case parsed summary is not a500-case RAG result. The manuscript itself describes this NLI analysis separately. The reported99percent correctness claim still lacks a recovered exact label set, adjudication rule and matched cohort here, so it remains manuscript-reported rather than independently reproduced. This finding does not establish that the reported number is false.

T11 is partially recovered. T13 and T14 still need exact data/source grouping and a genuinely matched retrieval ablation. No third GPU experiment is ready from this evidence alone. The recovered question/answer transcript remains local and is excluded from public code/proof publication.
