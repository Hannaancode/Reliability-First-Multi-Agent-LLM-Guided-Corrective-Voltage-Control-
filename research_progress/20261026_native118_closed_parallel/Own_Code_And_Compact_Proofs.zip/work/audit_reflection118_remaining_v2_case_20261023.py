"""First replay only new physics; actual original model/source/cursor evidence."""
import traceback
from reflection118_remaining_cases_v2_core_20261023 import *

def main():
    index,Pcase,Host=case_paths();O=R/'outputs/reflection118_remaining_cases_v2_independent_20261023'/f'case_{index:02d}';O.mkdir(exist_ok=False)
    began=time.monotonic();put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    wait_ack(O,began);p=read(Pcase/'Frozen_Engineering_Protocol.json')
    end=read(R/'outputs/reflection118_remaining_cases_v2_coordination_20261023'/f'case_{index:02d}'/'End_ACK.json')
    assert end['exit_code']==0 and end['actual_owned_chain_ended']
    status=read(Host/'status.json');assert status['runtime_released'] and status['scientific_process_ended'] and status['all_actual_closed_artifacts_preserved']
    for n,h in read(Pcase/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha(R/n)==h
    np,pp,v2,runner,reflection=setup()
    from transformers import AutoTokenizer
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    from public_size_u61_preservation import journal
    C=Host/'local_controller';S=Host/'staged/study';native=pp.runpp
    for n,h in read(C/'Closed_Manifest.json')['members'].items():assert sha(C/n)==h
    for n,m in read(Host/'remote_closed_descriptor.json')['members'].items():assert (S/n).stat().st_size==m['bytes'] and sha(S/n)==m['sha256']
    remote_events=[]
    for stream in [C/'events.jsonl',S/'events.jsonl']:
        previous='0'*64
        for line in stream.open('rb'):
            x=json.loads(line);assert x['event']['previous']==previous
            previous=hashlib.sha256(canonical(x['event'])).hexdigest();assert previous==x['sha256']
            if stream.parent==S:remote_events.append(x['event'])
    tok=AutoTokenizer.from_pretrained(str(R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'),local_files_only=True,trust_remote_code=False)
    responses=sorted(S.glob('response_*.json'))
    for i,f in enumerate(responses):
        a=read(f);assert a['number']==i and a['request']==read(C/'requests'/f'request_{i:05d}.json')
        encoded=tok.apply_chat_template(a['request']['messages'],tokenize=True,add_generation_prompt=True);ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
        assert ids==a['input_token_ids'] and len(ids)+384<=4096
        assert tok.decode(a['output_token_ids'],skip_special_tokens=True).strip()==a['raw_text']
        assert len(a['output_token_ids'])==a['actual_forward_returns'] and read(C/'responses'/f.name)==a
    for label in ['primary','cold_serving']:
        if (S/f'{label}_Immutable_After.json').exists():assert read(S/f'{label}_Immutable_Before.json')==read(S/f'{label}_Immutable_After.json')
        if (S/f'{label}_Actual_Enabled_Adapter_State.json').exists():
            flags=read(S/f'{label}_Actual_Enabled_Adapter_State.json');assert flags and not any(flags.values())
    if responses:
        a=read(S/'First_Primary_Generation.json');b=read(S/'First_Cold_Generation.json')
        assert a['input_token_ids']==b['input_token_ids'] and a['output_token_ids']==b['output_token_ids']
    remote_record=read(S/'Results.json') if (S/'Results.json').exists() else read(S/'Failure.json')
    remote_costs=remote_record['costs']
    assert sum(e['kind']=='generation_attempt' for e in remote_events)==remote_costs['generation_attempts']
    assert sum(e['kind']=='generation_return' for e in remote_events)==remote_costs['generation_returns']
    assert sum(e['kind']=='pretrained_forward_return' for e in remote_events)==remote_costs['pretrained_forward_returns']
    assert sum(e.get('output_tokens',0) for e in remote_events if e['kind']=='generation_return')==remote_costs['generated_tokens']
    replays=0;maximum=0.;maximum_kcl=0.;complete=False;summary=None;source_calls=source_gens=commits=0
    try:
        binding=read(R/p['bindings'])[index];d=C/binding['case_id']/'reflection_v2'
        calls=read(d/'Call_Order.json')
        for i,rec in enumerate(calls['PF']):
            assert time.monotonic()-began<p['reader_seconds']
            if rec['provenance']['kind']!='NEW_PRIMARY_RETURN':continue
            assert rec['exception'] is None
            before=saved_net(d,rec['before']);after=saved_net(d,rec['after']);net=copy.deepcopy(before)
            journal(O/'replay_journal.jsonl',dict(event='FIRST_NEW_RETURN_REPLAY_RESERVED',PF_record=i,source_record_sha256=sha(d/f'pf_{i:06d}.json')))
            tick=time.perf_counter();native(net,**rec['kwargs']);replays+=1;frames_equal(net,after)
            delta=0.
            for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
                a=net[name].select_dtypes(include=[np.number]).to_numpy(float);b=after[name].select_dtypes(include=[np.number]).to_numpy(float)
                assert a.shape==b.shape and np.array_equal(np.isnan(a),np.isnan(b)) and np.allclose(a,b,rtol=0,atol=1e-10,equal_nan=True)
                finite=np.isfinite(a)&np.isfinite(b);delta=max(delta,float(np.max(abs(a[finite]-b[finite]),initial=0.)))
            q=net._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0];V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]))
            kcl=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
            maximum=max(maximum,delta);maximum_kcl=max(maximum_kcl,kcl)
            proof=dict(PF_record=i,maximum_numeric_field_delta=delta,KCL_pu=kcl,seconds=time.perf_counter()-tick)
            put(O/f'replay_{replays:06d}.json',proof);journal(O/'replay_journal.jsonl',dict(event='FIRST_REPLAY_CLOSED',**proof))
        local=read(C/'Results.json');assert replays==local['costs']['new_PF_returns']
        from audit_solver_input_identity_receipts_20261023 import audit as audit_identities
        identities=audit_identities(C/'solver_input_identity')
        assert identities['identity_receipts']==local['costs']['exact_solver_input_preparation']['identity_receipts']
        put(O/'Exact_Solver_Input_Receipt_Audit.json',identities)
        def physics(net,**kw):
            nonlocal source_calls
            if source_calls==len(calls['PF']):raise PaidBoundary('END_OF_PRESERVED_SOURCE_PREFIX')
            rec=calls['PF'][source_calls];source_calls+=1;assert kw==rec['kwargs'];frames_equal(net,saved_net(d,rec['before']));restore_exact(net,saved_net(d,rec['after']))
            if rec['exception'] is not None:raise RuntimeError(failure_message(rec['exception']))
        def model(messages):
            nonlocal source_gens
            if source_gens==len(calls['generations']):raise PaidBoundary('END_OF_PRESERVED_MODEL_PREFIX')
            rec=calls['generations'][source_gens];source_gens+=1;assert rec['messages']==messages
            assert rec['text']==read(S/f"response_{rec['request']:05d}.json")['raw_text'];return rec['text']
        def on_commit(state):
            nonlocal commits
            commits+=1;desc=read(d/f'commit_cold_then_continuing_{commits:02d}.json');saved=decode(d,desc['descriptor'])
            checkpoint_equal(state,saved['source_frame']);assert source_calls==desc['PF_cursor'] and source_gens==desc['model_cursor']
        random.seed(p['seed']);np.random.seed(p['seed'])
        base=pp.from_json(str(R/p['base_net']));zones=read(R/p['metadata'])['zones']
        try:
            result,_=run_original(v2,runner,reflection,read(R/binding['registration']['recipe']),base,zones,model,physics,commit_callback=on_commit)
            assert (d/'Result.json').exists() and result==read(d/'Result.json') and source_calls==len(calls['PF']) and source_gens==len(calls['generations'])
            assert read(d/'Cold_Continuation_Gate.json')['status'].startswith('PASS_')
            summary=reflection.summarize_result(result);summary['strict_OV']=result['final_metrics']['ov_count']
            complete=status.get('remote_exit_code')==0 and (S/'Results.json').exists() and all((S/f'{label}_Immutable_After.json').exists() for label in ['primary','cold_serving'])
        except PaidBoundary:
            assert not (d/'Result.json').exists()
        transfer=read(Host/'Transfer_Costs.json')
        put(O/'Independent_Audit.json',dict(status='PASS_ONE_COMPLETE_ORIGINAL_REFLECTION_CASE' if complete else 'PASS_PRESERVED_PARTIAL_FULL_CASE_UNKNOWN',case_id=binding['case_id'],complete=complete,summary=summary,actual_model_responses_verified=len(responses),first_new_return_replays=replays,maximum_numeric_field_delta=maximum,maximum_KCL_pu=maximum_kcl,original_continuous_source_PF_calls=source_calls,original_continuous_source_model_calls=source_gens,full_commitments_verified=commits,primary_costs=local['costs'],actual_remote_model_costs=remote_costs,remote_model_workflow_seconds=remote_record['workflow_seconds'],actual_host_transfer_attempts=len(transfer),summed_transfer_attempt_seconds=sum(x['seconds'] for x in transfer),workflow_overlap_and_old_model_training_preparation_costs_not_free=True,new_model_optimizer_training_calls=0,comparison='All4 matchedDFF/HGVF, fullDSE/external/unusedconfirmation still require separate complete assembly and costs.',workflow_seconds=time.monotonic()-began))
        put(O/'Frozen_Original_Checks.json',frozen_checks())
    except BaseException as exc:
        put(O/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),already_executed_first_replays=replays,no_replay_phase_retry=True));raise
    finally:
        pp.runpp=native;put(O/'Closed_Manifest.json',dict(members={f.relative_to(O).as_posix():sha(f) for f in O.rglob('*') if f.is_file()}))

if __name__=='__main__':main()
