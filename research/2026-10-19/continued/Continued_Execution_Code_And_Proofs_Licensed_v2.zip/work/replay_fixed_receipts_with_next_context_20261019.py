"""Same fixed policy with the ONE independently verified new context added.

No new model, PF, derivative, forecast, factor, solve or commit. Missing evidence
still stops UNKNOWN. All old/new receipts, including rejects, stay available.
"""
import ast,copy,json
from pathlib import Path
from types import SimpleNamespace
import replay_unstarted_paid_suffix_numeric_v2_20261018 as original
import verified_paid_cache_engine_v2_20261018 as binding
from replay_paid_suffix_with_fixed_three_20261019 import Registry
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from fixed_three_query_core_20261019 import transform
B=R/'outputs/fixed_receipt_next_context_screen_20261019'
PREP=R/'outputs/fixed_receipt_next_context_screen_preparation_20261019'
NUM=R/'outputs/next_required_numeric_context_20261019'
def main():
    proof=read(NUM/'independent_audit/Independent_Audit.json');assert proof['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
    assert read(NUM/'additive_menu_join_v2/Full_Native_Menu_ACK.json')['status']=='PASS_EXACT_COMPLETE_SOURCE_NATIVE_MENU_NOT_A_FAVORABLE_SUBSET'
    assert read(NUM/'Completion.json')['exit_codes']=={'actual':0,'independent_audit':1}
    assert read(NUM/'menu_join_repair_v2_preparation/Completion.json')['reader_exit_code']==0
    PREP.mkdir(exist_ok=False);files=[Path(__file__),Path(original.__file__),R/'work/replay_paid_suffix_with_fixed_three_20261019.py',NUM/'Protocol.json',NUM/'Completion.json',NUM/'additive_menu_join_v2/Full_Native_Menu_ACK.json',NUM/'menu_join_repair_v2_preparation/Completion.json',NUM/'independent_audit/Independent_Audit.json',NUM/'actual/Closed_Manifest.json']
    p=read(NUM/'Protocol.json');put(PREP/'Protocol.json',{'status':'FROZEN_READONLY_SAME_POLICY_WITH_NEW_REQUIRED_CONTEXT','source_input_sha256':{str(v.relative_to(R)):sha(v) for v in files},'runtime_versions':p['runtime_versions'],
        'fixed_bound_seconds':900,'selection':'Same first declared originally unstarted leg and original native menus/policies. Add exactly one required verified context/full forecast table; no outcome selected variants, partial-menu decision or new scientific calls.'})
    guard=LockedSourceSnapshot(PREP/'Protocol.json')
    try:
        text=Path(original.__file__).read_text('utf-8');n=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main')
        function='\n'.join(text.splitlines()[n.lineno-1:n.end_lineno]);before="contexts[proof['identity']]=c\n    for ref in read(reuse/'All_Existing_Contexts.json'):"
        after="""contexts[proof['identity']]=c
    newroot=R/'outputs/next_required_numeric_context_20261019'
    newproof=read(newroot/'independent_audit/Independent_Audit.json')
    assert newproof['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
    for relative,expected in read(newroot/'actual/Closed_Manifest.json')['members'].items():assert sha(newroot/'actual'/relative)==expected
    for key,value in read(newroot/'actual/All_Current_Native_Forecasts.json').items():
        assert key not in forecasts;forecasts[key]=value['forecast']
    with np.load(newroot/'actual'/(newproof['identity']+'.npz'),allow_pickle=False) as z:newcontext={k:z[k].copy() for k in z.files}
    assert identity(newcontext)==newproof['identity'] and newproof['identity'] not in contexts
    contexts[newproof['identity']]=newcontext
    for ref in read(reuse/'All_Existing_Contexts.json'):"""
        changed=transform(function,[(before,after)]);tree=ast.parse(changed)
        for q in ast.walk(tree):
            if isinstance(q,ast.Constant) and type(q.value) is int and q.value==1800:q.value=900
        env=original.__dict__.copy();proxy=SimpleNamespace(**binding.__dict__);proxy.VerifiedPaidUseRegistry=Registry
        env.update(B=B,binding=proxy,__file__=__file__);exec(compile(ast.fix_missing_locations(tree),str(original.__file__),'exec'),env);env['main']()
    finally:guard.close()
if __name__=='__main__':main()
