"""Real preservation APIs around LABELLED MOCK solver/action callbacks only."""
import copy
import hashlib
import json
import os
import pickle
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pandas as pd

from native_continuation_preservation_v2 import EvidenceJournal, extended_local_path
from native_postcommit_preservation import PreservationStop
from paid_spatial_actual_commit_binding_v1 import ActualCommitBinding
from paid_spatial_actual_controller_checkpoint_v1 import save_actual_controller_checkpoint, read_actual_controller_checkpoint
from paid_spatial_receding_controller_v1 import RecedingController
from paid_spatial_storage_guard_v1 import NativeQueriesV3
from paid_spatial_native_queries_v2 import OperationalStop
from trusted_causal_controller_snapshot import SOLVER_ROLES
from value_normal_band_mediation import NormalUpperMediation

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/critical_research_reset_20261010/spatial_actual_binding_software_20261012'
CHECKS = []


class MockNet(dict):
    __getattr__ = dict.__getitem__


def net():
    return MockNet(converged=False,
        res_bus=pd.DataFrame({'vm_pu': [.9, 1.0], 'va_degree': [0., 0.], 'p_mw': [0., 0.], 'q_mvar': [0., 0.]}),
        shunt=pd.DataFrame(columns=['bus', 'q_mvar', 'name']))


def checked(name, yes):
    assert yes, name
    CHECKS.append({'name': name, 'passed': True})


def refuses(name, fn, kind=(OperationalStop, PreservationStop)):
    try:
        fn()
    except kind:
        checked(name, True)
    else:
        raise AssertionError(name)


class Fixture:
    def __init__(self, name):
        self.directory = extended_local_path(OUT/name)
        self.directory.mkdir(parents=True)
        self.calls = []
        self.behavior = None
        self.action_error = False
        self.pp = SimpleNamespace(runpp=self.solve)
        self.rescue = SimpleNamespace(verify_action=self.verify, apply_action=self.apply,
            grid_metrics=self.metrics, extract_zone_state_full=lambda *args: {},
            candidate_buses_from_state=lambda *args: [0], Q_SWEEP=[25],
            make_action=lambda b, q: {'add_shunts_q_mvar': {str(b): q}},
            score_candidate=lambda c: (c['verif']['before']['deficit_sum']-c['verif']['after']['deficit_sum'],))
        self.runner = SimpleNamespace(rescue=self.rescue,
            action_signature=lambda a: json.dumps(a, sort_keys=True))
        source = 'work/paid_spatial_actual_commit_binding_v1.py'
        self.protocol = {'actual_query_binding_authorized': True, 'actual_commit_binding_authorized': True,
            'scope': 'GLOBAL_ORIGINAL_DFF_MENU',
            'source_sha256': {source: hashlib.sha256((ROOT/source).read_bytes()).hexdigest()},
            'absolute_deadline_utc': (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),
            'new_query_limit': 100, 'payload_byte_limit': 1024*1024,
            'planned_process_handoff_authorized': False}
        self.ph = hashlib.sha256(json.dumps(self.protocol, sort_keys=True).encode()).hexdigest()
        (self.directory/'owner.claim').write_text(json.dumps({'actual_pid': os.getpid(), 'protocol_sha256': self.ph}))
        self.journal = EvidenceJournal(self.directory/'journal.jsonl', self.ph)
        self.guard = NormalUpperMediation(self.rescue)
        self.guard.__enter__()
        self.q = NativeQueriesV3(self.pp, self.runner, {'z': [0, 1]}, self.directory,
            self.journal, self.protocol, self.ph, storage_root=self.directory)
        self.binding = ActualCommitBinding(self.q)

    def solve(self, current, **kwargs):
        self.calls.append(copy.deepcopy(kwargs))
        if self.behavior == 'exception':
            raise RuntimeError('LABELLED MOCK solver failure')
        if self.behavior == 'deadline':
            self.q.deadline = datetime.now(timezone.utc)-timedelta(seconds=1)
        if self.behavior == 'overflow':
            (self.directory/'paid_return_crosses_limit.bin').write_bytes(b'x'*(2*1024*1024))
        current['converged'] = True
        current.res_bus.at[0, 'vm_pu'] = .9+len(current.shunt)*.01
        if self.behavior == 'nonfinite':
            current.res_bus.at[0, 'p_mw'] = float('nan')
        if self.behavior == 'different_field':
            current.res_bus.at[0, 'p_mw'] = 3.

    def apply(self, current, action):
        current.shunt.loc[len(current.shunt)] = [0, -25., 'llm_shunt_mock']
        if self.action_error:
            raise ValueError('LABELLED MOCK action application failure')

    def metrics(self, current):
        vm = current.res_bus.vm_pu
        return {'uv_count': int((vm < .95).sum()), 'deficit_sum': float((.95-vm).clip(lower=0).sum()),
                'vmin': float(vm.min()), 'vmax': float(vm.max())}

    def verify(self, current, action):
        before = self.metrics(current)
        trial = copy.deepcopy(current)
        self.apply(trial, action)
        self.pp.runpp(trial, **SOLVER_ROLES['trial'])
        return {'before': before, 'after': self.metrics(trial), 'accepted': True, 'reason': 'MOCK_ONLY'}

    def initialize(self):
        return self.binding.initial(net(), {'actual_commit_count': 0, 'remaining_slots': 25,
            'actual_action_history': [], 'episode': 'LABELLED_MOCK', 'policy': 'MOCK_ONLY'})

    def paid(self, parent):
        aid = self.q.menu(parent)[0]
        return self.q.query(parent, aid), self.q.menus[parent][aid]

    def close(self):
        self.q.close(); self.journal.close(); self.guard.__exit__()


def run():
    OUT.mkdir(exist_ok=False)
    f = Fixture('happy')
    root = f.initialize()
    r, a = f.paid(root)
    current = f.binding.commit(root, r, a, 1)
    checked('root_trial_commit_distinct_original_options_once_each', f.calls == [SOLVER_ROLES['initial'], SOLVER_ROLES['trial'], SOLVER_ROLES['commit']])
    checked('direct_and_query_PF_costs_separate_no_root_commit_omission',
        f.binding.costs['attempts'] == f.binding.costs['returns'] == 2 and f.q.pf_attempts == f.q.pf_returns == 1)
    checked('actual_commit_has_separate_current_capsule_cursor_history', current not in (root, r.successor) and
            f.q.restore(current)['process']['remaining_slots'] == 24)
    controller = {'phase': 'PRE_SELECTION', 'episode': 'LABELLED_MOCK', 'policy': {'mode': 'native_greedy', 'width': 8},
        'actual_commit_count': 1, 'remaining_slots': 24, 'current_handle': current,
        'actual_action_history': [{'iteration': 1, 'parent_handle': root, 'selected_action_id': r.action,
            'trial_successor': r.successor, 'action': a, 'committed_handle': current}],
        'failed_signatures': [], 'guard': {'upper': 1.05, 'tolerance': 1e-8}, 'perbus_cap': 450,
        'input_sha256': {'MOCK': '0'*64}, 'runtime_identity': {'mock': True}, 'direct_costs': {}}
    c = RecedingController(f.q, controller, commit=f.binding.commit, checkpoint=save_actual_controller_checkpoint,
                           mode='native_greedy')
    f.binding.attach_live_controller_costs(c)
    checked('actual_direct_cost_ledger_live_not_copy_only', c.controller['direct_costs'] is f.binding.costs)
    anchor = save_actual_controller_checkpoint(f.q, c.controller, 'mock_actual_01')
    state, manifest = read_actual_controller_checkpoint(anchor, expected_protocol=f.protocol,
        expected_protocol_sha256=f.ph, expected_controller_identity=c.controller, expected_directory=f.directory)
    checked('full_actual_call_files_and_direct_counts_in_real_checkpoint', len(state['controller']['actual_direct_artifacts']) == 4 and
        state['controller']['direct_costs']['attempts'] == 2 and state['controller']['complete_tree_storage_guard']['scans'] > 0)
    path = f.directory/'actual_calls/commit_01/trusted_local_actual_state.pkl'
    old = path.read_bytes(); path.write_bytes(old+b'tampered')
    refuses('changed_direct_capsule_refused_by_reader', lambda: read_actual_controller_checkpoint(anchor,
        expected_protocol=f.protocol, expected_protocol_sha256=f.ph,
        expected_controller_identity=c.controller, expected_directory=f.directory))
    path.write_bytes(old)
    refuses('obsolete_parent_commit_refused_without_new_PF', lambda: f.binding.commit(root, r, a, 2))
    checked('obsolete_parent_does_not_add_call', len(f.calls) == 3)
    f.close()

    for name in ('exception', 'nonfinite'):
        f = Fixture(name); f.behavior = name
        refuses(name+'_root_stops_without_retry', f.initialize)
        files = list((f.directory/'actual_calls/initial_000').glob('*.pkl'))
        checked(name+'_raw_failed_or_returned_full_state_preserved', len(files) == 1 and files[0].stat().st_size > 0 and len(f.calls) == 1)
        refuses(name+'_old_root_not_restartable', f.initialize)
        f.close()
    for name in ('deadline', 'overflow'):
        f = Fixture(name); f.behavior = name
        root = f.initialize()
        checked(name+'_already_paid_return_preserved_and_issued', root in f.q.handles and f.binding.costs['returns'] == 1)
        refuses(name+'_next_science_refused_no_repeated_solver', lambda: f.paid(root))
        checked(name+'_crossing_return_not_lost_and_no_extra_call', len(f.calls) == 1 and
                (f.directory/'actual_calls/initial_000/trusted_local_actual_state.pkl').is_file())
        f.close()
    f = Fixture('different_commit_field'); root = f.initialize(); r, a = f.paid(root); f.behavior = 'different_field'
    refuses('different_actual_PQ_field_fails_common_commit_check', lambda: f.binding.commit(root, r, a, 1))
    checked('failed_admission_retains_actual_cursor_no_rollback', f.binding.cursor == 1 and
        f.binding.current_handle != root and f.q.stopped and len(f.calls) == 3)
    f.close()
    f = Fixture('action_failure'); root = f.initialize(); r, a = f.paid(root); f.action_error = True
    refuses('action_application_failure_preserved_no_commit_PF', lambda: f.binding.commit(root, r, a, 1))
    checked('action_failure_retains_mutated_pre_PF_state', (f.directory/'actual_calls/commit_01/trusted_local_actual_state.pkl').is_file() and
            f.binding.costs['commit_attempts'] == 0 and len(f.calls) == 2)
    f.close()
    f = Fixture('inflight'); root = f.initialize(); r, a = f.paid(root); f.q.inflight = True
    refuses('simultaneous_query_direct_commit_refused', lambda: f.binding.commit(root, r, a, 1))
    f.q.inflight = False; checked('inflight_refusal_added_zero_PF', len(f.calls) == 2); f.close()
    f = Fixture('intent_io_failure')
    with patch.object(f.journal, 'emit', side_effect=OSError('LABELLED journal failure')):
        refuses('intent_IO_failure_prevents_solver_dispatch', f.initialize)
    checked('failed_intent_is_not_false_PF_attempt', not f.calls and f.binding.costs['attempts'] == 0)
    f.close()
    out = {'checks': CHECKS, 'all_passed': True, 'new_actual_PF_model_optimizer_calls': 0,
        'mock_public_solver_calls_are_software_only': True,
        'scope': 'Real fsynced artifact/journal/hash-checkpoint paths around labelled mock PP/action callbacks; actual physics/cold process/fulltrajectory untested',
        'source_sha256': {n: hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in [
            'work/paid_spatial_actual_commit_binding_v1.py', 'work/paid_spatial_actual_controller_checkpoint_v1.py',
            'work/test_spatial_actual_commit_binding_20261012.py']}}
    with (OUT/'Software_Checks.json').open('x', encoding='utf8') as stream:
        json.dump(out, stream, indent=2, allow_nan=False)
    print(json.dumps({'passed': len(CHECKS), 'new_actual_scientific_calls': 0}))


if __name__ == '__main__':
    run()
