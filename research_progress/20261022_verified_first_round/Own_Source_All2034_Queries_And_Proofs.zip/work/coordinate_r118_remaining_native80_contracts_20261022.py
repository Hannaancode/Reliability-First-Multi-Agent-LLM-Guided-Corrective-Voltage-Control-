"""One prospective primary and one first-return reader; never restart either."""
import os,subprocess,sys,time
from reflection118_chronological_core_20261022 import *
O=R/'outputs/r118_remaining_native80_contracts_handoff_20261022';P=R/'outputs/r118_remaining_native80_contracts_preparation_20261022'
def main():
    O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)));start=time.monotonic()
    assert read(P/'Source_And_Preservation_Readiness.json')['status'].startswith('PASS_PROSPECTIVE')
    for phase,protocol in [('primary','Owner_Protocol.json'),('reader','Reader_Owner_Protocol.json')]:
        with (O/(phase+'.log')).open('x',encoding='utf-8') as log:
            child=subprocess.Popen([sys.executable,'-X','utf8',str(R/'work/coordinate_f118_encoder_owner_20261022.py'),'--protocol',str((P/protocol).relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            put(O/(phase+'_Launcher.json'),dict(pid=child.pid,parent=os.getpid(),protocol_sha256=sha(P/protocol)))
            code=child.wait(timeout=450)
        put(O/(phase+'_End.json'),dict(launcher_pid=child.pid,exit_code=code));assert code==0,'Preserve failure and do not start another reader or repeat science'
    put(O/'Completion.json',dict(status='PRIMARY_AND_FIRST_NEW_RETURN_READER_ENDED',independent_audit='outputs/r118_remaining_native80_contracts_independent_20261022/Independent_Audit.json',workflow_seconds=time.monotonic()-start,whole_trajectory_LLM_superiority='UNKNOWN_UNTESTED'))
if __name__=='__main__':main()
