"""Close a distinct prior single-root PF lineage without repeating any solver.

Compare exact observed physical shunt cardinality on EVERY prior return;
unknown/missing observations block exclusion, not a guessed negative.
"""
import hashlib,json,os,pickle,time,zlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/fresh_root_query_nonoverlap_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    def put(name,data):
        with (B/name).open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    def sha(p):
        with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
    catalog=json.loads((R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json').read_text())
    row=next(x for x in catalog if x['path'].endswith('fresh_paid_receipt_opportunity_preparation_v1/execution/Actual_Observation_Journal.jsonl'))
    targets=[]
    for j in range(2,6):
        path=R/f'outputs/unstarted_paid_suffix_support_screen_20261018/Frontier_{j}.zlib';d=pickle.loads(zlib.decompress(path.read_bytes()))
        targets.append({'frontier':j,'source_path':str(path.relative_to(R)),'sha256':sha(path),'before_physical_shunt_rows':len(d['net'].shunt),
            'candidate_kind':d['row']['kind'],'query_after_physical_shunt_rows':len(d['net'].shunt)+1})
        assert d['row']['kind']=='ordinary'
    put('Protocol.json',{'selection':'ALL4 source-screen eligible physical gaps; all3418 prior fresh-root solver attempts/returns, no outcome-selected prior subset',
        'source_sha256':sha(Path(__file__)),'prior_journal':row,'targets':targets,'bound_seconds':300,'new_scientific_calls':0,
        'criterion':'Every completed prior observation has physical shunt cardinality strictly below each exact target pre-query, and all intents closed. Missing/exception observation prevents exclusion.',
        'scope':'Excludes this prior fresh-root single-action PF lineage ONLY, not all global historical physics or authorization for a new query.'})
    put('owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    pending=None;attempts=closed=0;counts={};h=hashlib.sha256();previous_index=-1
    with (R/row['path']).open('rb') as f:
        for raw in f:
            assert time.perf_counter()-started<300;h.update(raw);e=json.loads(raw);assert e['event_index']>previous_index;previous_index=e['event_index']
            if e['event']=='solver_attempt':
                assert pending is None;pending=(e['identity'],e['phase'],e['arguments']);attempts+=1
            elif e['event']=='solver_closed':
                assert pending==(e['identity'],e['phase'],e['arguments']);pending=None;closed+=1
                assert e['exception'] is None and e['observation'] is not None
                table=e['observation']['physical_tables']['shunt'];n=len(table['index']);assert len(table['values'])==n
                counts[str(n)]=counts.get(str(n),0)+1
    assert pending is None and attempts==closed==3418 and h.hexdigest()==row['sha256']
    maximum=max(map(int,counts));assert all(t['before_physical_shunt_rows']>maximum for t in targets)
    put('Independent_Audit.json',{'status':'PASS_ALL_PRIOR_FRESH_ROOT_RETURNED_PHYSICAL_INPUTS_DISJOINT_FROM_FOUR_TARGET_GAPS',
        'actual_attempts':attempts,'actual_closed_returns':closed,'shunt_cardinality_counts':counts,'maximum_prior_observed_shunt_rows':maximum,
        'target_prequery_shunt_rows':[t['before_physical_shunt_rows'] for t in targets],'actual_prior_journal_sha256':h.hexdigest(),
        'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,'limits':'One distinct historical lineage excluded; full relevant attempt closure and new query source/ownership/cold/reader gates still required. Not a universal never-computed assertion.'})
    put('Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()}})
    print(json.dumps({'fresh_root_lineage_disjoint':'PASS','all_prior_solver_returns':closed,'max_prior_shunts':maximum}))
if __name__=='__main__':main()
