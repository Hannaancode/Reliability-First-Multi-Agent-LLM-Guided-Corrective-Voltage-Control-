"""Independent local artifact audit; zero model forwards, gradients or PF calls.

The remote source contains the actual CUDA/PEFT/hidden/old-weight checks.
This reader verifies that unchanged source, its recorded gates and exact local
artifacts. It does not claim to independently repeat those model checks.
"""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
import hashlib
import json
import math
import os
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/vcsa_development/framework_execution_memory_20261008'
PREP = ROOT / 'outputs/vcsa_development/framework_preparation'
STAGED = OUT / 'staged'
SCIENCE = STAGED / 'vcsa_development/framework_memory_smoke'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = {
    'audited_at_utc': datetime.now(timezone.utc).isoformat(),
    'passed': False, 'scope': 'local recorded-integration and checkpoint artifact audit only',
    'new_model_forwards': 0, 'new_optimizer_steps': 0, 'new_PF_calls': 0,
    'limitations': ['Remote CUDA, PEFT, hidden-equivalence and old-weight gates are source-verified recorded checks, not independently repeated model forwards',
                    'Two integration steps do not establish trained performance, clean attribution or D-SE superiority'],
}
gates = {}
files = {}
try:
    authorization = read(PREP / 'HF_Cloud_Upload_Authorization_20261008.json')
    payload = read(PREP / 'HF_Cloud_Payload_Manifest.json')
    state = read(OUT / 'status.json')
    ownership = read(OUT / 'Owner_End_Inventory_20261008.json')
    assert state.get('finished_at_utc'), 'Wait for owned collector completion'
    assert ownership['owner_claim_pid'] == int((OUT / 'owner.claim').read_text())
    assert not ownership['owner_claim_pid_alive'] and ownership['matching_owner_process_count'] == 0
    gates['owned_collector_ended'] = True
    assert state['allocation_requests'] == 1 and state['expected_account'] == authorization['destination_account']
    assert state['runtime_allocated'] and state['runtime_released'], 'Exact assignment release required'
    gates['selected_single_assignment_released'] = True
    assert state['notebook_hash'] == '28b5114c-0df1-4588-8bad-5174d15c1607'
    gates['owned_assignment_identity'] = True
    assert payload['bytes'] == authorization['bytes'] == 34831836
    assert payload['sha256'] == authorization['sha256'] == sha(ROOT / payload['archive'])
    with zipfile.ZipFile(ROOT / payload['archive']) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names)) == 19
        assert read(PREP / 'Human_Authorized_Resume_Preflight_20261008.json')['passed']
        declared = json.loads(archive.read('VCSA_INPUT_MANIFEST.json'))
        assert declared == payload['members'] and len(declared) == 18
        for name, expected in declared.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == expected
            if name != 'outputs/frozen_input_verification.json':
                assert sha(ROOT / name) == expected
    gates['unchanged_archive_CRC_and_all_member_hashes'] = True
    additive = read(PREP / 'Memory_Source_Only_Payload_Manifest_20261008.json')
    direct = read(PREP / 'Memory_Validation_Direct_Human_Authorization_20261008.json')
    assert direct['destination_account'] == authorization['destination_account']
    assert direct['additional_archive'] == additive
    assert additive['bytes'] == 7682 and sha(ROOT / additive['archive']) == additive['sha256']
    assert state['additive_source_sha256'] == additive['sha256'] and state['approved_private_payload_unchanged']
    with zipfile.ZipFile(ROOT / additive['archive']) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == 4
        assert json.loads(archive.read('MEMORY_SOURCE_MANIFEST.json')) == additive['members']
        for name, expected in additive['members'].items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == expected == sha(ROOT / name)
    assert read(ROOT / 'outputs/vcsa_development/memory_execution_fixture_v2/summary.json')['passed']
    readiness = read(PREP / 'Memory_Validation_Readiness_20261008.json')
    assert sha(ROOT / readiness['new_owner']) == readiness['new_owner_sha256']
    gates['approved_additive_source_CRC_hashes_protocol_and_equivalence_fixture'] = True

    failed = read(ROOT / 'outputs/vcsa_development/framework_execution/status.json')
    assert failed['allocation_requests'] == 0 and not failed['runtime_allocated']
    assert failed['failure_type'] == 'AttributeError' and failed.get('finished_at_utc')
    repair = read(PREP / 'Control_Response_Repair_Provenance_20261008.json')
    assert sha(ROOT / repair['new_single_owner']) == repair['new_single_owner_sha256']
    assert repair['scientific_rerun'] is False
    gates['original_failure_and_control_only_repair_preserved'] = True
    assert read(STAGED / 'vcsa_smoke_exit.json')['exit_code'] == 0
    assert not (SCIENCE / 'failure.json').exists()
    gates['scientific_worker_exit_zero_without_failure_record'] = True
    environment = read(STAGED / 'remote_frozen_environment.json')
    assert environment == read(ROOT / 'outputs/remote_frozen_environment.json')
    assert read(STAGED / 'exact_dependency_check.json') == {'checked_count': 111, 'differences': {}}
    gates['exact_frozen_environment_and_111_dependencies'] = True
    manifest = read(SCIENCE / 'manifest.json')
    expected_scientific = {'step_01.json', 'step_02.json', 'new_modules_step_01.pt', 'new_modules_step_02.pt', 'summary.json'}
    assert set(manifest) == expected_scientific
    assert set(p.name for p in SCIENCE.iterdir()) == expected_scientific | {'manifest.json'}
    for name, info in manifest.items():
        path = SCIENCE / name
        assert path.stat().st_size == info['bytes'] and sha(path) == info['sha256']
        files[name] = info
    gates['exact_scientific_file_set_and_all_manifest_hashes'] = True
    summary = read(SCIENCE / 'summary.json')
    protocol = read(PREP / 'Memory_Smoke_Protocol_20261008.json')
    inputs = read(PREP / 'smoke_inputs.json')
    checks = read(PREP / 'tokenizer_preflight.json')['checks']
    assert summary['source_sha256'] == additive['members']['work/run_vcsa_framework_memory_smoke_remote_20261008.py']
    assert summary['protocol_sha256'] == additive['members']['outputs/vcsa_development/framework_preparation/Memory_Smoke_Protocol_20261008.json']
    assert summary['frozen_environment'] == environment
    gates['scientific_source_protocol_environment_identity'] = True
    required = {'PEFT_disabled_hidden_differs', 'PEFT_restores_enabled_unmerged', 'zero_initialization_preserves_hidden',
                'all_required_new_gradient_paths', 'original_weights_bitwise_unchanged', 'all_original_parameters_frozen',
                'checkpoint_tensors_exact_reload', 'restored_projection_forward_passed', 'no_solver_entry',
                'adapter_files_unchanged', 'two_real_gradient_steps_completed'}
    assert set(summary['gates']) == required
    assert summary['passed'] is True and all(value is True for value in summary['gates'].values())
    gates['all_exact_remote_framework_gates_recorded_pass'] = True
    steps = [read(SCIENCE / f'step_{index:02d}.json') for index in [1, 2]]
    assert summary['steps'] == steps
    assert [step['input_id'] for step in steps] == [row['local_observation_id'] for row in inputs['rows']]
    assert sorted(step['input_id'] for step in steps) == protocol['selected_ids']
    assert all(row['split'] == 'train' for row in inputs['rows'])
    gradient_paths = set()
    for index, step in enumerate(steps, 1):
        assert step['step'] == index
        preflight = next(c for c in checks if c['id'] == step['input_id'])
        assert step['input_tokens'] == preflight['tokens'] and step['input_tokens'] + 384 <= 4096
        assert math.isfinite(step['loss']) and math.isfinite(step['forward_backward_step_seconds']) and step['forward_backward_step_seconds'] > 0
        assert 0 < step['peak_allocated_bytes'] <= step['peak_reserved_bytes']
        assert step['gradient_norms'] and all(math.isfinite(v) and v >= 0 for v in step['gradient_norms'].values())
        for component in ['vcsa_encoder', 'vcsa_heads', 'vcsa_injectors', 'vcsa_B', 'vcsa_router']:
            if any(component in name and value > 0 for name, value in step['gradient_norms'].items()):
                gradient_paths.add(component)
    assert len(gradient_paths) == 5
    gates['exact_TRAIN_views_finite_steps_tokens_and_all_gradient_paths'] = True
    counts = summary['counts']
    assert counts['pretrained_forward_calls'] == 8
    assert counts['input_tokens'] == 6 * steps[0]['input_tokens'] + 2 * steps[1]['input_tokens']
    assert counts['real_gradient_steps'] == 2
    assert counts['new_PF_calls'] == counts['generations'] == counts['scientific_training_campaign_steps'] == 0
    assert math.isfinite(counts['model_load_seconds']) and counts['model_load_seconds'] > 0
    assert math.isfinite(summary['elapsed_seconds']) and summary['elapsed_seconds'] > 0
    assert 'T4' in summary['gpu']
    gates['actual_model_step_token_memory_and_no_solver_cost_arithmetic'] = True
    if os.name == 'nt':
        LIB = Path(r'C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
        guard = os.add_dll_directory(str(LIB)); library = ctypes.WinDLL(str(LIB / 'msvcp140.dll'))
    import torch
    checkpoints = [torch.load(SCIENCE / f'new_modules_step_{index:02d}.pt', map_location='cpu', weights_only=True) for index in [1, 2]]
    assert set(checkpoints[0]) == set(checkpoints[1]) and checkpoints[0]
    for checkpoint in checkpoints:
        assert all('vcsa_' in name and isinstance(tensor, torch.Tensor) and torch.isfinite(tensor).all() for name, tensor in checkpoint.items())
        assert sum(tensor.numel() for tensor in checkpoint.values()) == summary['new_parameter_count']
    changed = [name for name in checkpoints[0] if not torch.equal(checkpoints[0][name], checkpoints[1][name])]
    assert changed, 'No preserved parameter change between genuine steps'
    gates['both_real_checkpoint_tensor_sets_finite_and_second_step_changed_parameters'] = True
    prior = read(ROOT / 'outputs/vcsa_development/framework_execution_control_resume_20261008/Partial_Memory_Failure_Independent_Audit.json')
    assert prior['partial_artifact_integrity_passed'] and prior['actual_completed_optimizer_steps'] == 1
    prior_owner = read(ROOT / 'outputs/vcsa_development/framework_execution_control_resume_20261008/status.json')
    from datetime import datetime as DT
    wall = lambda s: (DT.fromisoformat(s['finished_at_utc']) - DT.fromisoformat(s['started_at_utc'])).total_seconds()
    report['combined_disclosed_integration_costs'] = {
        'prior_GPU_model_forward_attempts': 7, 'prior_GPU_model_forward_returns': 6,
        'prior_GPU_input_tokens': 21439, 'prior_GPU_optimizer_steps': 1,
        'new_GPU_model_forward_attempts': counts['pretrained_forward_calls'],
        'new_GPU_input_tokens': counts['input_tokens'], 'new_GPU_optimizer_steps': 2,
        'combined_GPU_model_forward_attempts': 7 + counts['pretrained_forward_calls'],
        'combined_GPU_model_forward_returns': 6 + counts['pretrained_forward_calls'],
        'combined_GPU_charged_input_tokens': 21439 + counts['input_tokens'],
        'combined_GPU_completed_optimizer_steps': 3,
        'combined_GPU_controller_wall_with_setup_and_transfers_seconds': wall(prior_owner) + wall(state),
        'new_GPU_controller_wall_with_setup_and_transfers_seconds': wall(state),
        'earlier_terminal_local_CPU_model_attempts': 5, 'earlier_CPU_source_proven_returns': 4,
        'earlier_terminal_CPU_seconds': 900.9850000001024,
        'new_audit_model_or_PF_calls': 0,
        'recomputation_cost_rule': 'All checkpoint recomputation occurs within measured forward_backward_step_seconds. Decoder reentry counts were not written by the approved remote source and remain unknown; do not relabel them extra full model forwards or claim FLOP/deployment superiority',
        'scope': 'integration only; all historical label/data/control preparation costs remain separate and must be charged for future efficiency claims',
    }
    gates['prior_genuine_failed_costs_and_CPU_attempt_retained'] = True
    report.update(passed=True, counts=counts, gpu=summary['gpu'], elapsed_seconds=summary['elapsed_seconds'],
                  optimizer_step_seconds=[s['forward_backward_step_seconds'] for s in steps],
                  peak_allocated_bytes=max(s['peak_allocated_bytes'] for s in steps),
                  peak_reserved_bytes=max(s['peak_reserved_bytes'] for s in steps),
                  new_parameter_count=summary['new_parameter_count'],
                  changed_checkpoint_tensor_count=len(changed), remote_recorded_gates=summary['gates'])
except Exception as exc:
    report.update(failure_type=type(exc).__name__, failure_reason=str(exc))
    if (SCIENCE / 'failure.json').exists():
        report['preserved_scientific_failure'] = read(SCIENCE / 'failure.json')
finally:
    report['independent_gates'] = gates
    report['verified_scientific_manifest_members'] = files
    for path in [OUT / 'status.json', OUT / 'Owner_End_Inventory_20261008.json', SCIENCE / 'manifest.json', STAGED / 'vcsa_smoke.log']:
        if path.exists():
            files[str(path.relative_to(OUT))] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    with (OUT / 'Memory_Integration_Independent_Audit_20261008.json').open('x') as file:
        json.dump(report, file, indent=2, allow_nan=False)
    print(json.dumps({k: v for k, v in report.items() if k != 'verified_scientific_manifest_members'}, indent=2))
