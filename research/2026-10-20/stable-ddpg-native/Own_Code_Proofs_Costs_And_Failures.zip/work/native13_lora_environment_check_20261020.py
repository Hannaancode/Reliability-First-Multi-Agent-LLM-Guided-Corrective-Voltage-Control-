"""Exact dependency/public-base input check only; no private model instantiation or forward."""
import os,json,hashlib,importlib.metadata as md
from pathlib import Path
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN']='1';os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
ROOT=Path(__file__).resolve().parents[1];os.environ['HF_HOME']=str(ROOT/'cache/huggingface')
import torch
from huggingface_hub import snapshot_download
p=json.loads((ROOT/'prep/protocol.json').read_text());pins=[line.split('==') for line in (ROOT/'work/frozen_dependency_closure.txt').read_text().splitlines()];diff={n:{'expected':v,'actual':md.version(n)} for n,v in pins if md.version(n)!=v};assert not diff
assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
snapshot=Path(snapshot_download(p['base_for_new_experiment']['repo'],revision=p['base_for_new_experiment']['revision'],allow_patterns=['model.safetensors','config.json'],token=False))
h=hashlib.sha256()
with (snapshot/'model.safetensors').open('rb') as f:
    for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
assert h.hexdigest()==p['base_for_new_experiment']['public_weight_sha256']
report={'gpu':torch.cuda.get_device_name(0),'exact_dependency_count':len(pins),'dependency_differences':diff,'base_revision':p['base_for_new_experiment']['revision'],'base_weight_sha256':h.hexdigest(),'base_snapshot':str(snapshot),'config_sha256':hashlib.sha256((snapshot/'config.json').read_bytes()).hexdigest(),'private_model_loaded':False,'learned_forwards':0,'versions':{n:md.version(n) for n in ['torch','transformers','peft','bitsandbytes','accelerate']}}
(ROOT/'outputs/public_size_environment.json').write_text(json.dumps(report,indent=2));print('NATIVE13_EXACT_ENVIRONMENT_AND_PUBLIC_BASE_PASS')
