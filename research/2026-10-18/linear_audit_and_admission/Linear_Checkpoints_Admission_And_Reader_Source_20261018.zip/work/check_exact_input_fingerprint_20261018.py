"""Actual saved input pairs and adversarial typed equality checks; zero science."""
import copy,hashlib,json,os,time
from pathlib import Path
import numpy as np,pandas as pd
from exact_input_fingerprint_v1_20261018 import signature as fast
from audit_spatial_allocation_inputs_v3_20261011 import signature as original
from joint_reallocation_opportunity_core_v1 import load_endpoint
import paid_receding_commit_and_history_v1 as saved
R=Path(__file__).resolve().parents[1];B=R/'outputs/exact_input_fingerprint_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'EQUALITY_ENCODING_SOFTWARE_GATE_NOT_A_PHYSICAL_OR_POINT_ID_CHANGE',
        'source_sha256':sha(R/'work/exact_input_fingerprint_v1_20261018.py'),'test_sha256':sha(Path(__file__)),
        'actual_inputs':'ALL4 original current endpoints and ALL25 saved complete checkpoint NETs. No outcome filter.',
        'test_bound_seconds':180,'no_model_PF_optimizer_forecast_derivative_solve_calls':True,
        'contract':'Only pairwise equality comparator in additive audit. Original point IDs, source files, model and case hashes are unchanged.'})
    old=R/'outputs/full_receding_paid_campaign_20261015';p=json.loads((old/'Protocol.json').read_text());res=json.loads((old/'actual/Result.json').read_text())
    real=[]
    for entry in p['endpoints']:real.append((entry['world'],load_endpoint(entry)[0]))
    for request in res['checkpoint_requests']:real.append((request['checkpoint'],saved.restore(R/request['checkpoint'],request['receipt'])['net']))
    checks={};timing_original=timing_new=0.;frames=set()
    for name,net in real:
        assert time.perf_counter()-started<180
        other=copy.deepcopy(net)
        t=time.perf_counter();a=original(net);b=original(other);timing_original+=time.perf_counter()-t
        t=time.perf_counter();c=fast(net);d=fast(other);timing_new+=time.perf_counter()-t
        assert a==b and c==d and set(a[1])==set(c[1]);frames.update(a[1]);checks[name]=True
    # The original typed-value equality is the reference predicate, including
    # Python bool/int distinction in object columns and signed floating zero.
    base={'table':pd.DataFrame({'float':np.array([0.,1.,np.nan]),'object':pd.Series([True,None,'x'],dtype=object),'integer':np.array([1,2,3],dtype=np.int64)})}
    pairs=[]
    def pair(label,change):
        other=copy.deepcopy(base);change(other);pairs.append((label,base,other))
    pair('negative_zero',lambda n:n['table'].__setitem__('float',np.array([-0.,1.,np.nan])))
    pair('one_float_bit',lambda n:n['table'].at.__setitem__((1,'float'),np.nextafter(1.,2.)))
    pair('object_bool_to_int',lambda n:n['table'].at.__setitem__((0,'object'),1))
    pair('object_none_to_nan',lambda n:n['table'].at.__setitem__((1,'object'),float('nan')))
    pair('column_order',lambda n:n.__setitem__('table',n['table'][['object','integer','float']]))
    pair('integer_dtype',lambda n:n['table'].__setitem__('integer',n['table']['integer'].astype(np.int32)))
    pair('index_name',lambda n:setattr(n['table'].index,'name','changed'))
    pair('index_class',lambda n:setattr(n['table'],'index',pd.Index([0,1,2],dtype=np.int64)))
    pair('empty_nonresult_table_added',lambda n:n.__setitem__('_empty_template',pd.DataFrame({'x':pd.Series(dtype=float)})))
    pair('result_table_only_excluded_same_as_original',lambda n:n.__setitem__('res_bus',pd.DataFrame({'vm_pu':[.9]})))
    pair('same_typed_nan_different_payload',lambda n:n['table'].at.__setitem__((2,'float'),np.array([0x7ff8000000000011],dtype=np.uint64).view(np.float64)[0]))
    pair('same_copy',lambda n:None)
    for label,a,b in pairs:
        expected=original(a)==original(b);observed=fast(a)==fast(b);assert expected==observed,label;checks[label]=True
    put(B/'Results.json',{'status':'PASS_EXACT_ALL_INPUT_FRAME_EQUALITY_ENCODING','actual_NETs':len(real),'nonresult_frame_names':len(frames),
        'checks':checks,'actual_pair_original_encoding_seconds':timing_original,'actual_pair_new_encoding_seconds':timing_new,
        'workflow_seconds':time.perf_counter()-started,'scientific_calls':0,
        'limits':'Saved NET equality/software timing only, not solver latency/deployment improvement or replacement of original point identities. Mathematical encoding argument still requires source-bound use and fail-closed unsupported types.'})
    print(json.dumps({'exact_input_comparator':'PASS','actual_NETs':len(real),'checks':len(checks),'original_seconds':timing_original,'new_seconds':timing_new,'science':0}))
if __name__=='__main__':main()
