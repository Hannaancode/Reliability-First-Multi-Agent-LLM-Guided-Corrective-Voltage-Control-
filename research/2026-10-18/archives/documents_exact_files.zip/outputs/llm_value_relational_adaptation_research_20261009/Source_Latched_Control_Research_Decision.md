# Source-latched numerical control and research decision

The overall validated incremental LLM contribution and full D-SE superiority objective remains active and unachieved. No GPU study is ready. This decision preserves the prior oracle result and every numerical tradeoff; it does not reinterpret them as LLM success.

The target-consistency audit checked 114,480 source scalars for 22,896 before/after generator records. It found 208 current and 254 successor nominal-bound/voltage pairs inconsistent with the usual complementarity direction, across 15 OPT worlds. This is not an assertion that PF failed or a recovered original hidden-mode history. Two explicitly labelled fabricated-array fixtures on the exact installed pandapower3.4.0 enforcement function proved that bound-constrained generators accumulate and are not released on a voltage crossing. The original source and its settings were preserved. A control based on ordinary release logic would therefore target a different relation from these source outcomes.

A separate prospectively fixed numerical comparison approximated the inspected source logic: all generators initially voltage-controlled, simultaneous strict-Q violations permanently latched, no release, maximum53new bounds plus final closure. Both original- and candidate-admittance derivatives were retained. The compiler used current physical observations/current Y/V and action only. Eight control/input software checks and seven independent equation-reader checks passed before performance. These are software evidence, separately labelled and charged.

## Actual execution and retained failure

The original owner returned four affine solves for the first old-derivative identity, then failed to save arrays because its filename exceeded the Windows path limit. This avoidable storage failure, source, claim, journal and costs remain immutable. The original Vm/J/x arrays were not recovered. No call from that identity was repeated.

An additive storage continuation prospectively enumerated only the 431 genuinely unattempted arm identities and used compact filenames. It completed 1,451 new affine solves, 431 current-state derivative evaluations, zero new PF/model/optimizer/cloud calls and zero new numerical exceptions. Workflow177.698seconds before manifest is separate from the original1.562second failed workflow and from all prior PF/control costs. The recorded solve-wrapper timing includes fsynced return logging; it is not a pure solver or deployment latency measurement.

The separate partial-aware reader verified all431 new forecasts,1,451 equation/mask/update chains,50,858 forecast scalars, full source/input/cost identities, the scientific441-member archive CRC/everyhash and all nine frozen-asset gates. The original complete-only reader was never run on the partial. All216case/432arm denominators remain:431saved forecasts and one original Vm outcome unknown. The old4completed calls remain separately charged. The first53selected nominal masks were recoverable from the actual final journal step; these are not recovery of its missing voltage arrays.

| Numerical variant | Known Vm forecasts | Known upper forecasts | Recorded nominal generator predicates correct |
|---|---:|---:|---:|
| Original-admittance derivative | 215, plus1unknown | 6, plus0or1unknown | 11,422/11,448 |
| Candidate-admittance derivative | 216 | 65 | 11,406/11,448 |

The changed-generator subset was339/363 correct for the original-derivative variant and362/363 for the candidate-derivative variant. These are correlated generator predicates, not independent trials, hidden solver-mode equality, global UV recovery or physical control success.

On the exactly matched215available original-derivative transitions across23worlds, the teacher constraint oracle improved equal-world MSE by only1.1606% (1.2156987670529058e-6 practical versus1.2015897095503896e-6 oracle). This available-pair diagnostic retains and identifies the missing outcome; it is not the full432finite metric. On all216candidate-derivative cases, its oracle was7.8437% worse than the practical numerical method (5.2680563656319e-6 versus4.88489939825955e-6). All variations, costs and adverse outcomes are retained.

## A stop decision that does not invent the missing result

The recorded complete-output measurement status remains UNKNOWN. A separate mathematical bound nevertheless proves that the prospective learning-headroom condition cannot pass for any completion of the missing output. It requires each oracle considered for training to have at least5fewer upper forecasts than EVERY strong control. The original-derivative control has6known crossings and at most1additional missing crossing. OracleC has6crossings, so its largest possible improvement against that control is1. OracleD has65, so its largest possible improvement is-58. Both necessarily fail the required conjunct. Unknown MSE cannot make a conjunction with this false condition pass.

STOP nominal generator-regime LLM training and its conditional rollout on this dataset. This uses the original thresholds; none are lowered or changed. It is not a claim that the incomplete original capture became complete or that a trained LLM has been evaluated. A strong source-guided numerical calculation already captures the useful constraint information for this hypothesis. Prior quadratic-residual, relational, dense copied-body, VCSA and root-selector branches also remain stopped.

## Next research question

Before proposing another internal-model intervention, measure whether the strong physics calculation leaves meaningful **action-selection** errors against the actual recorded native action scores. Voltage MSE and nominal generator classification cannot answer this. A prospective OPT-only candidate-ranking study must reuse every exact existing finite forecast, retain the unavailable original value, account for any new mathematical work, keep raw common-and-zone scopes/original Q grid/caps/score/verifier, and retain failed/unlabelled/invalid outcomes. It must implement and test a real same-information strong numerical ranking comparator before any model training. No mature batched ranking runner or learning protocol is inferred here.

One distinct research hypothesis is to adapt the original language-native action policy from physically measured preference pairs while anchoring its initial behavior to a numerical action prior. This concerns decision-ranking residuals, rather than generator-regime classification, a bounded voltage correction or another seed/learning-rate change. The hypothesis is not implemented, launch-ready or proved novel. Internal weight adaptation must show an incremental effect over the numerical prior, frozen/reference language policy and strong same-information preference learner; generation format alone cannot count. Genuine per-state inference, full training/reference/generation/solver costs, matched protected trajectories versus literal D-SE with both branches, and unused independent confirmation remain mandatory.

Read Native_Preference_Adaptation_Critical_Review.md before defining that method. Existing literature already performs AC-preference fine-tuning for grid actions. Simply applying DPO to shunts or combining it with a verifier is not a novel contribution and supplies no90%success guarantee. The immediate next work is precise OPT-only action-prior/ranking/data feasibility and novelty analysis; no new GPU allocation, training or physical campaign follows automatically.
