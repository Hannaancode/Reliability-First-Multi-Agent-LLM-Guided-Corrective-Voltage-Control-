"""Compact own-code/summary evidence publication, never raw private or author assets."""
import hashlib,json,shutil
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import seal
R=Path(__file__).resolve().parents[1];BASE=R/'outputs/full_system_comparison_20261021';P=BASE/'publication_prefix_recovery'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False)
def main():
    P.mkdir(exist_ok=False);audit=read(R/'outputs/public13_first_partial_validation_v2_20261021/Independent_Audit.json');assert audit['status']=='PASS_FIRST_INDEPENDENT_PRESERVED_PARTIAL_PREFIX_NATIVE_SOURCE_PROJECTION_POLICY_PHYSICS_AND_COST_VALIDATION';end=read(R/'outputs/public13_first_partial_validation_v2_coordination_20261021/End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
    # New descriptive reduction, not re-execution or a chosen evaluation subset.
    rows=[c for c in audit['cases'] if c.get('seed',0)<=161 and c.get('status')=='COMPLETE_NATIVE_EPISODE'];assert len(rows)==483
    methods={}
    for name in ['safe-ddpg','linear','ddpg']:
        group=[c for c in rows if c['algorithm']==name];assert len(group)==161
        methods[name]={'complete_source_ordered_prefix_cases':161,'sum_final_all13_UV':sum(c['endpoint']['UV'] for c in group),'sum_final_all13_OV':sum(c['endpoint']['OV'] for c in group),'all13_fullband_restored_cases':sum(c['endpoint']['full_band_restored'] for c in group),'source3controlled_strict_done_cases':sum(c['endpoint']['native_done'] for c in group),'total_control_actions':sum(c['completed_steps'] for c in group)}
    descriptive={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'DESCRIPTIVE_COMPLETE_EXECUTION_PREFIX_ONLY_NOT_FULL500','fixed_registered_author_cases':500,'same_complete_available_prefix_seeds':[1,161],'methods':methods,'extra_completed_safe_ddpg_seed162_reported_separately_not_added_to_matched_prefix':True,'case0_reused_from_prior_closed_study_not_in_this_prefix_summary':True,'unexecuted_method_case_pairs':1013,'full500_and_HierGrid_superiority':'UNKNOWN_NOT_MEASURED','scope':'All first161 completed cases, not chosen for voltage or method success. Incomplete source-order prefix cannot be generalized to full500. No statistical interval, selected winner, LLM attribution or our-system score.'}
    put(BASE/'Partial_Prefix_Descriptive_Results.json',descriptive)
    summary={k:audit[k] for k in ['status','scientific_status','continuous_policy_steps_verified','full_fields_max_delta','actual_independent_costs','primary_costs_retained','workflow_seconds','primary_actual_final_state_UNRECOVERED','original_primary_cold_policy_checkpoint_complete','source_projection_checked_each_reader_forward']};summary['completed_branch_count']=484;summary['completed_all3_worlds']=161;summary['full500_complete']=False;put(P/'First_Independent_Prefix_Audit_Summary.json',summary)
    shutil.copyfile(BASE/'Current_Resume.json',P/'Current_Resume.json');shutil.copyfile(R/'outputs/public13_terminal_saved_prefix_v2_20261021/Independent_Saved_Output_Audit.json',P/'Saved_Only_Recovery_Audit.json');shutil.copyfile(BASE/'Partial_Prefix_Descriptive_Results.json',P/'Partial_Prefix_Descriptive_Results.json')
    tasks=read(R/'outputs/research_tasks_20261014/Tasks.json');put(P/'Task_Progress.json',{'all6finalgoals':'OPEN','priority_order':tasks['priority_order'],'tasks':[{k:t[k] for k in ['checklist_id','target','status','completed','current_result','subtasks'] if k in t} for t in tasks['tasks']]})
    own_sources=['run_public13_remaining_published_cohort_20261021.py','audit_public13_first_partial_validation_v2_20261021.py','preserve_and_audit_public13_terminal_prefix_20261021.py','preserve_and_audit_public13_terminal_prefix_v2_20261021.py','prepare_saved_prefix_dtype_repair_20261021.py','gate_public13_first_partial_validation_20261021.py','run_public13_missing_only_continuation_20261021.py','audit_public13_missing_only_continuation_20261021.py','public13_complete_policy_state_contract_20261021.py','prepare_public13_missing_only_continuation_20261021.py','prepare_public13_missing_only_reader_20261021.py','refine_public13_unentered_state_storage_20261021.py','check_public13_missing_only_contract_20261021.py','freeze_public13_missing_only_admission_20261021.py','coordinate_public13_missing_only_20261021.py','save_public13_current_execution_checkpoint_20261021.py','prepare_public13_prefix_recovery_publication_20261021.py']
    files={'own_code/'+n:R/'work'/n for n in own_sources}
    for directory,names in [('outputs/public13_missing_only_preparation_20261021',['Protocol.json','Exact_Unentered_Method_Case_Identities.json','Independent_Reader_Lock.json','Admission.json','Software_Readiness_v2.json','Prelaunch_Storage_Refinement.json','Independent_Reader_Static_Proof.json','Worker_Static_Contract_Changes.json']),('outputs/public13_terminal_saved_prefix_v2_20261021',['Source_Normalization_Diagnosis.json','Mechanical_Dtype_Repair_Proof.json']),('outputs/public13_first_partial_validation_v2_20261021',['Source_State_Reproduction_Proof.json','Frozen_After.json']),('outputs/public13_first_partial_validation_preparation_v2_20261021',['Protocol.json','Readiness.json'])]:
        for name in names:files['proofs/'+Path(directory).name+'/'+name]=R/directory/name
    # Explicit allowlist omits all checkpoints, raw NET/pickles, original author
    # code/weights, full journals, physical archives and credential-bearing files.
    archive=seal(P,files,'Own_Code_And_Proofs.zip')
    text='''# External public-cohort prefix recovery and continuation

The source-native external baseline study reached its original1800-second bound, then failed finalization because the published Safe-DDPG policy intentionally normalizes b/c parameters during inference. The failed owner, journal and source were preserved. Its actual final parameter bytes were not saved and remain unrecovered.

An additive saved-only recovery passed with zero new model/PF/solver calls. The separately preplanned FIRST independent stage then replayed all2,787 returned PFs and7,896 policy calls, verifying2,632 continuous decision steps, source-native normalization and full physical fields with maximum delta0.0. That independent stage is explicitly charged; it is not zero-cost repair or new primary performance.

Only the first161 source-order cases have all three methods complete, plus Safe-DDPG case162. Partial-prefix statistics are descriptive, not a chosen successful subset or the full500-case result. No HierGrid full-policy comparison or superiority has been measured by this external-baseline stage.

The new prospectively frozen campaign contains exactly1,013 genuinely unentered method-case pairs: linear/DDPG case162 and all three methods in cases163–499. Completed cases, old physical calls and budgets are not restarted or extended. Nine original policy checkpoints, action/dtype/equations/stopping rules remain unchanged. Full actual source-mutable model/environment/RNG/cursor/receipt state is now saved before and after each new step. Initial carry is independently replay-reconstructed, never called recovered original final bytes. All setup, original failure, preparation, old/new science and independent replay costs remain additive.

The original supplied manuscript reports its137-case HG-SE result193 residual UV versus DFF290, with higher Q/actions and full both-branch costs. This historical reported benefit is preserved; it is not a newly certified public same-cost comparison. The fair original-paper/new-controller/external comparison remains the primary task, and all six final goals remain open.

This directory contains compact own code and summary evidence only. Raw private model weights, full NET/checkpoint/journal/physics archives and third-party code/weights remain local. This publication is not a complete raw backup. Read Current_Resume.json and the live local owner/closed-manifest evidence before continuation. No guaranteed winner, favorable case/threshold/checkpoint selection, scientific retries, weakened comparator, quota evasion or purchase.
'''
    (P/'README.md').write_text(text,encoding='utf-8');put(P/'Publication_Summary.json',{'status':'COMPACT_OWN_CODE_AND_PROOF_SNAPSHOT_READY','archive':archive,'all6goals':'OPEN','new_model_PF_calls_by_publication':0,'remote_path':'research/20261021_public13_prefix_recovery/'})
    seven=['README.md','Current_Resume.json','Saved_Only_Recovery_Audit.json','First_Independent_Prefix_Audit_Summary.json','Partial_Prefix_Descriptive_Results.json','Task_Progress.json','Own_Code_And_Proofs.zip']
    put(P/'Upload_Plan.json',{'files':[{'local':(P/n).relative_to(R).as_posix(),'path':'research/20261021_public13_prefix_recovery/'+n,'bytes':(P/n).stat().st_size,'sha256':hashlib.sha256((P/n).read_bytes()).hexdigest()} for n in seven]})
    print(json.dumps({'descriptive_prefix':methods,'new_archive':archive,'seven_upload_files_ready':True}))
if __name__=='__main__':main()
