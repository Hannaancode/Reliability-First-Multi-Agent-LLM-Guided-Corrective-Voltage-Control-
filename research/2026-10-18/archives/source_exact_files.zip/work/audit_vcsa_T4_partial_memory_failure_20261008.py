"""Audit genuine partial CUDA evidence without any model/solver execution."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes, hashlib, json, math, os, zipfile
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/vcsa_development/framework_execution_control_resume_20261008'
PREP = ROOT / 'outputs/vcsa_development/framework_preparation'
SCI = OUT / 'staged/vcsa_development/framework_smoke'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = read(OUT / 'status.json'); ownership = read(OUT / 'Owner_End_Inventory_20261008.json')
assert state['runtime_allocated'] and state['runtime_released'] and state['allocation_requests'] == 1
assert state['finished_at_utc'] and not ownership['owner_claim_pid_alive'] and ownership['matching_owner_process_count'] == 0
payload = read(PREP / 'HF_Cloud_Payload_Manifest.json')
authorization = read(PREP / 'HF_Cloud_Upload_Authorization_20261008.json')
assert payload['sha256'] == authorization['sha256'] == sha(ROOT / payload['archive'])
assert payload['bytes'] == authorization['bytes'] == 34831836
with zipfile.ZipFile(ROOT / payload['archive']) as archive:
    assert archive.testzip() is None
    for name, digest in payload['members'].items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
        if name != 'outputs/frozen_input_verification.json': assert sha(ROOT / name) == digest
assert read(OUT / 'staged/exact_dependency_check.json') == {'checked_count':111,'differences':{}}
environment = read(OUT / 'staged/remote_frozen_environment.json')
assert environment == read(ROOT / 'outputs/remote_frozen_environment.json')
assert environment['cuda_available'] and environment['gpu'] == 'Tesla T4'
assert read(OUT / 'staged/vcsa_smoke_exit.json')['exit_code'] == 1
failure = read(SCI / 'failure.json'); step = read(SCI / 'step_01.json')
assert failure['type'] == 'OutOfMemoryError' and failure['steps_preserved'] == 1
assert failure['source_sha256'] == payload['members']['work/run_vcsa_framework_smoke_hf_remote.py']
assert set(failure['gates']) == {'PEFT_disabled_hidden_differs','PEFT_restores_enabled_unmerged','zero_initialization_preserves_hidden'}
assert all(value is True for value in failure['gates'].values())
rows = read(PREP / 'smoke_inputs.json')['rows']; preflight = read(PREP / 'tokenizer_preflight.json')['checks']
assert step['step'] == 1 and step['input_id'] == rows[0]['local_observation_id'] and all(row['split'] == 'train' for row in rows)
lengths = [next(c['tokens'] for c in preflight if c['id'] == row['local_observation_id']) for row in rows]
assert step['input_tokens'] == lengths[0] == 2803 and lengths[1] == 3712
assert failure['counts']['pretrained_forward_calls'] == 7
assert failure['counts']['input_tokens'] == 5 * lengths[0] + 2 * lengths[1] == 21439
assert failure['counts']['real_gradient_steps'] == 1
assert failure['counts']['new_PF_calls'] == failure['counts']['generations'] == failure['counts']['scientific_training_campaign_steps'] == 0
assert math.isfinite(step['loss']) and step['forward_backward_step_seconds'] > 0
terms = step['terms']
expected_loss = terms['action'] + .2*terms['preference'] + .2*terms['progress'] + .1*terms['candidate_failure_and_guard'] + .05*terms['last_token_language_retention']
assert abs(step['loss'] - expected_loss) < 1e-6
assert all(math.isfinite(value) and value >= 0 for value in step['gradient_norms'].values())
assert 0 < step['peak_allocated_bytes'] <= step['peak_reserved_bytes']
if os.name == 'nt':
    LIB=Path(r'C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
    guard=os.add_dll_directory(str(LIB)); library=ctypes.WinDLL(str(LIB/'msvcp140.dll'))
import torch
checkpoint = torch.load(SCI / 'new_modules_step_01.pt', map_location='cpu', weights_only=True)
assert checkpoint and all('vcsa_' in name and torch.isfinite(value).all() for name,value in checkpoint.items())
assert sum(value.numel() for value in checkpoint.values()) == 418436
assert any('vcsa_B' in name and bool(value.ne(0).any()) for name,value in checkpoint.items())
assert any('vcsa_injectors' in name and 'output.weight' in name and bool(value.ne(0).any()) for name,value in checkpoint.items())
assert not (SCI / 'summary.json').exists() and not (SCI / 'manifest.json').exists()
files = {str(path.relative_to(OUT)): {'bytes':path.stat().st_size,'sha256':sha(path)} for path in sorted((OUT/'staged').rglob('*')) if path.is_file()}
report = {'audited_at_utc':datetime.now(timezone.utc).isoformat(), 'partial_artifact_integrity_passed':True,
          'two_step_integration_passed':False, 'failure':'CUDA OutOfMemoryError on second 3712-token training forward',
          'actual_gpu':environment['gpu'],'frozen_dependency_count':111,
          'pretrained_forward_attempts':7,'source_proven_forward_returns':6,'charged_input_tokens':21439,
          'actual_completed_optimizer_steps':1,'finite_checkpoint_parameter_count':418436,
          'checkpoint_contains_nonzero_rank_B_and_injector_output':True,
          'first_step_seconds':step['forward_backward_step_seconds'],'first_step_loss':step['loss'],
          'first_step_peak_allocated_bytes':step['peak_allocated_bytes'],'first_step_peak_reserved_bytes':step['peak_reserved_bytes'],
          'recorded_passed_gates':failure['gates'],
          'remaining_gate_values':'UNKNOWN: second-step/router path, end-of-run original-weight equality, checkpoint-second-step reload and post-detach equivalence were not completed',
          'remote_final_manifest_available':False,'partial_local_file_hashes':files,
          'owner_ended_verified':True,'exact_runtime_released_verified':True,
          'new_audit_model_forwards':0,'new_audit_optimizer_steps':0,'new_audit_PF_calls':0,
          'scope':'software/framework evidence only; no trained control or LLM-superiority result'}
with (OUT/'Partial_Memory_Failure_Independent_Audit.json').open('x') as file: json.dump(report,file,indent=2,allow_nan=False)
print(json.dumps({k:v for k,v in report.items() if k!='partial_local_file_hashes'},indent=2))
