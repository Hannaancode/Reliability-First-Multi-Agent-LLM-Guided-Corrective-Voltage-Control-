"""Additive exact FOUR-identity transport; no scientific calls or old-source edits."""
import ast,hashlib,json,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha

def change(text,old,new):
    assert text.count(old)==1,(old,text.count(old))
    return text.replace(old,new)

def main():
    out=R/'outputs/fixed_four_query_source_preparation_20261019';out.mkdir(exist_ok=False)
    cell=read(R/'outputs/next_fixed_physical_cell_20261019/Exact_Next_Cell.json')
    assert len(cell['all_unexecuted_original_menu_queries'])==4
    raw=zlib.decompress((R/cell['current_input']['path']).read_bytes());assert hashlib.sha256(raw).hexdigest()==cell['current_input']['raw_sha256']
    state=pickle.loads(raw)
    state['source_edge']={'source_paid_projection_not_actual_commit':state['source_paid_projection_not_actual_commit'],'frontier':cell['current_input'],'exact_point':cell['point'],'prior_costs':'All parent physical/numerical/preparation/failed analysis costs remain paid, not free online evidence.'}
    inp=R/'outputs/fixed_four_query_input_20261019';inp.mkdir(exist_ok=False)
    with (inp/'Exact_Current_Input.zlib').open('xb') as f:f.write(zlib.compress(pickle.dumps(state,5),6))
    put(inp/'Exact_Candidate_Inputs.json',{'point':cell['point'],'parent':cell['parent'],'exact_new_query_rows':cell['all_unexecuted_original_menu_queries'],'original_frontier':cell['current_input']})
    common=[('fixed_three_query_core_20261019','fixed_four_query_core_20261019'),('run_remaining_three_fixed_queries_20261019','run_fixed_four_queries_20261019'),('audit_remaining_three_fixed_queries_20261019','audit_fixed_four_queries_20261019'),('certify_remaining_three_coverage_20261019','certify_fixed_four_coverage_20261019'),('remaining_three_fixed_queries_20261019','fixed_four_query_acquisition_20261019'),('THREE','FOUR'),('three','four')]
    sources={}
    for oldname,newname in [('fixed_three_query_core_20261019','fixed_four_query_core_20261019'),('run_remaining_three_fixed_queries_20261019','run_fixed_four_queries_20261019'),('audit_remaining_three_fixed_queries_20261019','audit_fixed_four_queries_20261019'),('prepare_remaining_three_fixed_queries_20261019','prepare_fixed_four_queries_20261019')]:
        original=(R/'work'/f'{oldname}.py').read_text('utf-8');text=original
        for a,b in common:text=text.replace(a,b)
        if 'core' in oldname:
            text=change(text,"I=old.I;PYTHON=old.PYTHON;PHASES=('warm','cold_1','cold_2')","I=R/'outputs/fixed_four_query_input_20261019';PYTHON=old.PYTHON;PHASES=('warm','cold_1','cold_2','cold_3')")
            text=change(text,"==len(self.allowed)==3'","==len(self.allowed)==4'")
            text=change(text,"'cold_1_State_ACK.json','Final_State_ACK.json'","'cold_1_State_ACK.json','cold_2_State_ACK.json','Final_State_ACK.json'")
            text=change(text,"keys=old.known_keys();past=read(I/'Exact_Candidate_Inputs.json')\n    return set(keys)|{v['point_action_key'] for v in past['exact_new_query_rows']}","from fixed_three_query_core_20261019 import known_keys as prior_keys\n    past=read(R/'outputs/remaining_three_fixed_queries_20261019/Protocol.json')\n    return set(prior_keys())|{v['point_action_key'] for v in past['exact_new_query_rows']}")
            # The net/cursor are exact original causal input values; only provenance wrapper is additive.
            text=change(text,"env.update(B=B,I=I,__file__=str(entrypoint),Reservations=Reservations,known_keys=known_keys)","env.update(B=B,I=I,__file__=str(entrypoint),Reservations=Reservations,known_keys=known_keys)") if False else text
        elif oldname.startswith('audit_'):
            text=change(text,"for phase in ('warm','cold_1','cold_2'):","for phase in ('warm','cold_1','cold_2','cold_3'):")
            text=change(text,"len(all_messages)==3 and len(replays)==3 and counts['PF_attempts']==6 and counts['PF_returns']==6","len(all_messages)==4 and len(replays)==4 and counts['PF_attempts']==8 and counts['PF_returns']==8")
            text=change(text,";middle=restore_state(read(B/'cold_1_State_ACK.json'))",";middle=restore_state(read(B/'cold_1_State_ACK.json'));middle2=restore_state(read(B/'cold_2_State_ACK.json'))")
            text=change(text,'for state in (warm,middle,final):','for state in (warm,middle,middle2,final):')
            text=change(text,"middle['next_index']==2 and final['next_index']==3 and len(final['paid_query_registry'])==3","middle['next_index']==2 and middle2['next_index']==3 and final['next_index']==4 and len(final['paid_query_registry'])==4")
            text=change(text,'assert len(history)==3','assert len(history)==4')
            text=change(text,"for ph in ('cold_1','cold_2'))","for ph in ('cold_1','cold_2','cold_3'))")
        elif oldname.startswith('prepare_'):
            text=change(text,'assert len(calls)<3','assert len(calls)<4')
            text=change(text,'assert calls==[solver]*3','assert calls==[solver]*4')
            text=change(text,"'exact_query_count':3,'maximum_PF_attempts':6","'exact_query_count':4,'maximum_PF_attempts':8")
            text=text.replace('ALL3','ALL4').replace('all6returns','all8returns').replace('and3chargedreplays','and4chargedreplays').replace('ranks2,3,4','ranks1,2,3,4').replace('Preserve prior rejected rank1 and separate cold engineering action.','Prior cell outcomes remain preserved; this is a distinct exact current point.').replace("'exact_native_stub_inputs':3","'exact_native_stub_inputs':4").replace("'actual_claimed_cold_process_handoffs':2","'actual_claimed_cold_process_handoffs':3").replace("'actual_cold_handoffs':2","'actual_cold_handoffs':3")
        target=R/'work'/f'{newname}.py';ast.parse(text);target.write_text(text,'utf-8')
        sources[str(target.relative_to(R))]={'sha256':sha(target),'original':f'work/{oldname}.py','original_sha256':sha(R/'work'/f'{oldname}.py')}
    put(out/'Source_Preparation.json',{'status':'ADDITIVE_FOUR_SOURCE_PREPARATION_NO_SCIENCE','sources':sources,'new_scientific_calls':0,'all_original_sources_untouched':True,'exact_new_point':cell['point'],'all4_order_fixed':True,'input_sha256':sha(inp/'Exact_Current_Input.zlib')})
    print(json.dumps({'four_sources_prepared':True,'new_scientific_calls':0}))
if __name__=='__main__':main()
