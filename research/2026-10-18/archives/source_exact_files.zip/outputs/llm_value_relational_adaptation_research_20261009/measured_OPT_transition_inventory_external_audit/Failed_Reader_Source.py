"""Independent saved-target/source correspondence reader; no physics/model."""
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import time
import zipfile

ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
S=P/'measured_OPT_transition_inventory'
OUT=P/'measured_OPT_transition_inventory_external_audit'
assert not OUT.exists()
load=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
digest=lambda v:hashlib.sha256(canonical(v).encode()).hexdigest()
def write(name,value):
    with (OUT/name).open('x',encoding='utf8') as f:json.dump(value,f,indent=2,allow_nan=False)
OUT.mkdir();start=time.perf_counter()
write('audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
manifest=load(S/'Closed_Manifest.json')
for name,m in manifest.items():assert (S/name).stat().st_size==m['bytes'] and sha(S/name)==m['sha256']
protocol=load(S/'Protocol.json');summary=load(S/'Summary.json')
assert sha(ROOT/'work/inventory_measured_OPT_transitions.py')==protocol['source_sha256']
worlds=protocol['worlds'];world_by={w['scenario_sha256']:w for w in worlds}
assert len(world_by)==23 and all(w['split']=='optimization' for w in worlds)
assert len(protocol['source_branch_hashes'])==46
data=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3'
denomfile=ROOT/'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/World_and_Invalid_Denominators.json'
assert sha(denomfile)==protocol['world_denominators_sha256']
denom=load(denomfile)
assert world_by=={w['scenario_sha256']:w for w in denom['worlds'] if w['split']=='optimization'}
assert protocol['original_invalid_TRAIN_inputs']==summary['original_invalid_inputs']==denom['original_invalid_TRAIN_inputs']
assert protocol['missing_candidate_ledgers']==summary['missing_candidate_ledgers_retained']==denom['missing_candidate_ledgers']
prior_audit=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3_audit/Independent_Identity_State_Scope_Selection_Cost_Audit.json'
prior=load(prior_audit)
assert prior['all_passed']
records={};expected_provenance=set();zero_action=[];prior_costs=[]
for path,h in protocol['source_branch_hashes'].items():
    file=ROOT/path;assert sha(file)==h
    r=load(file);w=world_by[r['scenario_sha256']];b=r['branch']
    assert h==w['branches'][b]['source_record_sha256']
    assert r['independent_all_field_replay_passed_1e10'] and r['base_network_preserved']
    assert sha(ROOT/'work/e/pack/scenarios/federation'/(r['scenario_id']+'.json'))==w['scenario_sha256']
    observations=r['observations'];actions=r['result']['executed_actions']
    assert len(observations)==len(actions)+1
    if not actions:zero_action.append((r['scenario_sha256'],b))
    for n,step in enumerate(actions):
        assert step['iteration']==n+1
        expected_provenance.add((h,n))
    records[h]=(r,file)
    prior_costs.append({'source_sha256':h,'new_actual_costs':r.get('new_actual_costs'),'recorded_costs':r.get('observer_controller_PF_counts')})
with gzip.open(S/'Actual_OPT_Transition_Rows.jsonl.gz','rt',encoding='utf8') as f:rows=[json.loads(line) for line in f]
assert len(rows)==len({r['transition_id'] for r in rows})
observed_provenance=set();q_states=defaultdict(set);groups=defaultdict(set);valid_worlds=set();families=set()
duplicates=0;valid_count=0;conflicts=defaultdict(set);OVdifferences=0
field_checks=0;deltas=[];all_before_states=set();all_successors=set();bus_counts=Counter()
for row in rows:
    target=row['measured_target']['next_res_bus'];inp=row['model_input'];audit=row['audit']
    assert set(inp)=={'current_physical_observation','current_control_state','original_Q_grid','candidate_action'}
    assert set(row['measured_target'])=={'next_res_bus'}
    assert inp['original_Q_grid']==[25.,50.,75.,100.,125.,150.,200.,250.,300.]
    bus=inp['candidate_action']['bus'];q=inp['candidate_action']['q_abs_mvar']
    assert inp['current_control_state']['original_per_bus_added_support_cap_MVAr']==450.
    assert len(inp['current_control_state']['added_abs_Q_MVAr_by_bus'])==118
    assert set(target['columns'])=={'vm_pu','va_degree','p_mw','q_mvar'} and sorted(target['index'])==list(range(118))
    assert all(len(v)==len(target['columns']) and all(type(a) in (int,float) and math.isfinite(a) for a in v) for v in target['values'])
    for prov in audit['source_provenance']:
        h=prov['source_record_sha256'];n=prov['prefix'];r,file=records[h]
        assert prov['source_record']==str(file.relative_to(ROOT)).replace('\\','/')
        assert prov['world_sha256']==r['scenario_sha256'] and prov['branch']==r['branch']
        assert prov['family']==world_by[r['scenario_sha256']]['family']
        before=r['observations'][n];after=r['observations'][n+1];step=r['result']['executed_actions'][n]
        assert digest(before['input_observation'])==row['before_observation_sha256']==before['observation_sha256']
        assert digest(after['input_observation'])==row['after_observation_sha256']==after['observation_sha256']
        assert inp['current_physical_observation']==before['input_observation']
        assert target==after['input_observation']['physical_tables']['res_bus']
        assert audit['actual_original_action']==after['committed_action']==step['action']
        assert step['action']=={'add_shunts_q_mvar':{str(bus):q}}
        assert digest({'before':row['before_observation_sha256'],'action':step['action'],'after':row['after_observation_sha256']})==row['transition_id']
        assert digest({'before':row['before_observation_sha256'],'action':step['action']})==row['current_action_id']
        assert (h,n) not in observed_provenance;observed_provenance.add((h,n))
        if audit['scope_valid_complete']:
            valid_worlds.add(r['scenario_sha256']);families.add(prov['family'])
            groups[(r['scenario_sha256'],row['before_observation_sha256'])].add(digest(step['action']))
        field_checks+=118*4
    duplicates+=len(audit['source_provenance'])-1
    pools=inp['current_physical_observation']['raw_common_and_zone_pools']
    expected_zones=[z for z,p in pools.items() if bus in p]
    expected_valid=bool(expected_zones) and q in inp['original_Q_grid'] and audit['support_before'][bus]+q<=450.
    assert audit['raw_allowed_zones']==expected_zones and audit['scope_valid_complete']==expected_valid
    assert inp['current_control_state']['added_abs_Q_MVAr_by_bus']==audit['support_before']
    expected_support=list(audit['support_before']);expected_support[bus]+=q
    assert expected_support==audit['support_after']
    if expected_valid:
        valid_count+=1;q_states[q].add(row['before_observation_sha256']);bus_counts[bus]+=1
    conflicts[row['current_action_id']].add(digest(row['measured_target']))
    before=inp['current_physical_observation']['physical_tables']['res_bus']
    bcol=before['columns'].index('vm_pu');tcol=target['columns'].index('vm_pu')
    bmap={i:values[bcol] for i,values in zip(before['index'],before['values'])}
    tmap={i:values[tcol] for i,values in zip(target['index'],target['values'])}
    vm=list(tmap.values());metrics=audit['after_metrics']
    assert abs(metrics['vmin']-min(vm))<=1e-10 and abs(metrics['vmax']-max(vm))<=1e-10
    assert metrics['uv_count']==sum(v<.95 for v in vm) and metrics['ov_count']==sum(v>1.05 for v in vm)
    assert audit['after_normal_upper']==(max(vm)<=1.05+1e-8)
    OVdifferences+=audit['recorded_native_post_OV']!=audit['saved_observation_post_OV']
    delta=[tmap[i]-bmap[i] for i in range(118)]
    deltas.append({'transition_id':row['transition_id'],'max_abs_vm_change':max(map(abs,delta)),
                   'mean_squared_vm_change':sum(v*v for v in delta)/118})
    all_before_states.add(row['before_observation_sha256']);all_successors.add(row['after_observation_sha256'])
assert observed_provenance==expected_provenance
contrast_keys={k for k,v in groups.items() if len(v)>1}
contrast_families={world_by[w]['family'] for w,_ in contrast_keys}
assert len(rows)==summary['unique_transitions'] and valid_count==summary['scope_valid_complete_transitions']
assert len(valid_worlds)==summary['valid_worlds'] and sorted(families)==summary['valid_families']
assert {str(q):len(v) for q,v in sorted(q_states.items())}==summary['Q_distinct_current_state_counts']
assert len(contrast_keys)==summary['same_before_distinct_action_groups'] and sorted(contrast_families)==summary['same_before_contrast_families']
assert duplicates==summary['duplicate_provenance_records'] and OVdifferences==summary['native_vs_saved_OV_differences_retained']
assert all(len(v)==1 for v in conflicts.values()) and not summary['conflicting_targets']
g=protocol['minimum_design_support']
checks={'valid_unique_transitions':valid_count>=g['unique_scope_valid_complete_transitions'],
 'OPT_world_coverage':len(valid_worlds)>=g['distinct_OPT_worlds'],'family_coverage':len(families)>=g['families'],
 'Q_excitation':sum(len(v)>=10 for v in q_states.values())>=g['Q_levels_with_at_least10_distinct_current_states'],
 'same_before_distinct_actions':len(contrast_keys)>=g['exact_same_before_distinct_action_groups'],
 'same_before_contrast_family_coverage':len(contrast_families)>=g['families_with_same_before_distinct_action_groups'],
 'no_conflicting_targets':all(len(v)==1 for v in conflicts.values()),'all_closed_chains_measured':not summary['incomplete_unverified_branches']}
assert checks==summary['minimum_model_design_support_gates'] and all(checks.values())==summary['all_minimum_design_support_passed']
inventory_zip=load(S/'Local_Archive_Audit.json')
# Check the new inventory's actual ZIP, not an old campaign archive.
file=S/'Measured_OPT_Transition_Inventory.zip';assert sha(file)==inventory_zip['sha256']
with zipfile.ZipFile(file) as z:
    assert len(z.namelist())==len(set(z.namelist()))==inventory_zip['unique_members'] and z.testzip() is None
    for n,m in load(S/'Supplement_Manifest.json').items():
        b=z.read(n);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,
 'exact_OPT_worlds':23,'exact_source_branches':46,'actual_committed_records':len(observed_provenance),
 'unique_transitions':len(rows),'valid_transitions':valid_count,'all_118_bus_target_scalar_source_checks':field_checks,
 'distinct_current_states':len(all_before_states),'distinct_successor_states':len(all_successors),
 'same_before_action_contrast_groups':len(contrast_keys),'contrast_families':sorted(contrast_families),
 'zero_action_branches_retained':zero_action,'prior_physical_replay_certificate_sha256':sha(prior_audit),
 'prior_costs_not_free_or_reexecuted':prior_costs,'source_support_manifest_sha256':protocol['support_manifest_sha256'],
 'no_after_or_identity_fields_in_proposed_current_action_input':True,'no_actual_forward_executed':True,
 'minimum_support_gates_independently_recomputed':checks,
 'new_model_optimizer_PF_controller_cloud_calls':0,'held_target_records_read':0,
 'native_saved_OV_differences_disclosed':OVdifferences,
 'protocol_source_duplicate_scope_key_note':'Inventory source has two scope literals; the first selection phrase was overwritten by the raw-scope phrase. Exact23-world list/46 source hashes/OPT-only selection were frozen and independently verified. Original source/protocol preserved; no inventory rerun or retrospective gate change.',
 'teacher_selected_action_bias_and_no_rejected_successor_vectors_remain':True,
 'no_causal_generalization_novelty_DSE_superiority_or_training_claim':True,
 'reader_seconds_before_seal':time.perf_counter()-start}
write('Independent_Transition_Source_and_Target_Audit.json',audit)
write('Actual_Voltage_Change_Excitation.json',{'saved_measured_differences_only':True,'new_model_PF_calls':0,'transitions':deltas})
files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='audit.claim'}
files['source/independent_reader.py']=Path(__file__)
files['original_inventory_protocol.json']=S/'Protocol.json';files['original_inventory_summary.json']=S/'Summary.json'
descriptor={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
write('Supplement_Manifest.json',descriptor)
archive=OUT/'Verified_Measured_OPT_Transition_Audit.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in files.items():z.write(p,n)
    z.write(OUT/'Supplement_Manifest.json','Supplement_Manifest.json')
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files)+1==len(set(z.namelist())) and z.testzip() is None
    for n,m in descriptor.items():
        b=z.read(n);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
write('Local_Archive_Audit.json',{'unique_members':len(files)+1,'bytes':archive.stat().st_size,'sha256':sha(archive),'CRC_and_every_member_hash_passed':True,'local_only':True})
write('status.json',{'stage':'complete_independent_transition_audit','all_passed':True})
print(json.dumps({k:audit[k] for k in ('all_passed','unique_transitions','all_118_bus_target_scalar_source_checks','distinct_current_states','same_before_action_contrast_groups','new_model_optimizer_PF_controller_cloud_calls')},indent=2))
