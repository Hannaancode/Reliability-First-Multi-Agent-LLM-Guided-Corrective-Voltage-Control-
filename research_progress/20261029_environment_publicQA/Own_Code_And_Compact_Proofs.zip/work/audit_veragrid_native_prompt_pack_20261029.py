"""Separate literal reconstruction of all saved prompts; no producer import or inference."""
from pathlib import Path
import hashlib, json
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/veragrid_native_prompt_contract_20261029'
A = R / 'outputs/veragrid_source_admission_20261029'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    target = O / 'Independent_Prompt_Pack_Audit.json'
    assert not target.exists()
    r = json.loads((O / 'Prompt_Pack_Result.json').read_text('utf-8'))
    assert r['prompt_pack_sha256'] == sha(O / 'participant/Native_NoTool_Prompts.json')
    for s in r['source_files']:
        b = (O / 'source' / s['path']).read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == s['git_blob']
        assert sha(O / 'source' / s['path']) == s['sha256']
    c = json.loads((O / 'source/eval_circuit.web.json').read_text('utf-8'))
    lines = ['--- CIRCUIT MODEL (ground truth input to the AC-OPF) ---', 'System base: 100 MVA. Nominal voltage: 20 kV.', '',
             'Generators (cost(P) = a*P_pu^2 + b*P_pu, with P_pu = P_MW/100):']
    for g in c['GENERATORS']:
        lines.append(f"  {g['name']}: bus {g['bus']}, Pmin={g['Pmin']} MW, Pmax={g['Pmax']} MW, a={g['a']}, b={g['b']}, Vset={g.get('vset',1.0)} pu")
    lines += ['', 'Loads:']
    for l in c['LOADS']:
        lines.append(f"  {l['name']}: bus {l['bus']}, P={l['P']} MW, Q={l['Q']} MVAr")
    lines += ['', 'Lines (r, x, b in pu on 100 MVA base):']
    for l in c['LINES']:
        lines.append(f"  {l['name']}: bus {l['from']} -> bus {l['to']}, r={l['r']}, x={l['x']}, b={l['b']}")
    lines += ['', "The generator named 'Slack' is the slack/reference bus. Questions refer to the solved AC optimal power flow (AC-OPF) of this circuit: optimal dispatch, bus voltages, branch flows, losses and costs.", '--- END CIRCUIT MODEL ---']
    context = '\n'.join(lines)
    q = json.loads((A / 'participant/Question_Views.json').read_text('utf-8'))['questions']
    packed = json.loads((O / 'participant/Native_NoTool_Prompts.json').read_text('utf-8'))['questions']
    assert len(q) == len(packed) == 150
    for x, y in zip(q, packed):
        assert set(y) == {'question_id', 'prompt'} and x['question_id'] == y['question_id']
        options = '\n'.join(f'{k}. {v}' for k, v in x['options'])
        block = f"Q{x['question_id']}. {x['question']}\n{options}"
        expected = ('You are a power systems engineer answering a multiple-choice question about the AC optimal power flow (AC-OPF) solution of the circuit below.\n\n' + context + '\n\n' +
                    'STRICT NO-TOOL MODE: answer using ONLY your own knowledge and reasoning. Do NOT call any tools. Do NOT read or write any files. Do NOT search the codebase. Do NOT execute any shell commands.\n\n' + block + '\n\nReply with ONLY the option letter (A, B, C, or D).')
        assert y['prompt'] == expected
    result = {'status': 'PASS_ALL150_EXACT_NATIVE_NO_TOOL_PROMPTS_AND_PINNED_INPUTS', 'records': 150,
              'producer_sha256': sha(R / 'work/build_veragrid_native_prompt_pack_20261029.py'),
              'independent_reader_sha256': sha(Path(__file__)), 'prompt_pack_sha256': r['prompt_pack_sha256'],
              'producer_result_sha256': sha(O / 'Prompt_Pack_Result.json'), 'read_admin_labels': False,
              'producer_imported': False, 'new_model_PF_OPF_training_GPU_calls': 0,
              'limits': 'Prompt/input fidelity only; no actual runtime isolation, tokenizer capacity, model performance or scientific superiority established.'}
    target.write_text(json.dumps(result, indent=2) + '\n', 'utf-8')
    print(json.dumps({'status': result['status'], 'records': 150, 'new_science': 0}))

if __name__ == '__main__':
    main()
