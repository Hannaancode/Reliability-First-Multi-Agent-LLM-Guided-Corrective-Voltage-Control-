"""Actual root states at the real engine boundary; original science entry stubbed."""
import copy,hashlib,json,os,time
from pathlib import Path
import pandapower as pp
import receding_paid_admitted_referenced_runtime_v1_20261018 as binding
from full_receding_paid_campaign_20261015 import read,put
from joint_reallocation_opportunity_core_v1 import load_endpoint
from paid_receding_referenced_commit_v2_20261018 import initialize
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
R=Path(__file__).resolve().parents[1];B=R/'outputs/admitted_referenced_runtime_binding_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'ACTUAL_INPUT_ENGINE_BINDING_SOFTWARE_ONLY','source_sha256':sha(Path(binding.__file__)),'test_sha256':sha(Path(__file__)),
        'all4_source_roots_both_fixed_methods':True,'original_decision_body_stubbed_no_science':True,'bound_seconds':120})
    forbidden=[]
    def no_science(*a,**k):forbidden.append(True);raise AssertionError('Software gate has no science')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,no_science)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    entered=[];checks={}
    original=binding.OriginalEngine.decision
    def stub(self,net,cursor,world,mode,decision):
        assert self.evidence.events[-1][0]=='referenced_input_admission_before_query'
        entered.append((world,mode,decision));return {'software_stub':True}
    binding.OriginalEngine.decision=stub
    class Evidence:
        def __init__(self):self.costs={};self.events=[];self.allow=True;self.admissions=0
        def admit(self):
            self.admissions+=1
            if not self.allow:raise TimeoutError('Fixed owner budget expired')
        def event(self,name,data):self.events.append((name,data))
    try:
        for entry in read(R/'outputs/full_receding_paid_campaign_20261015/Protocol.json')['endpoints']:
            assert time.perf_counter()-started<120
            net,old,_=load_endpoint(entry);cursor=initialize(net,build_current_domain(net,old,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
            evidence=Evidence()
            engine=binding.AdmittedPaidDecisionEngine(out=B/'UNEXECUTED',evidence=evidence,runner=runner,zones=zones,cache={},blocked=set(),contexts={},numeric_cost={},history=None,paid_forecasts={})
            for mode in ['immediate1_followup16','breadth4_followup4']:
                assert engine.decision(net,cursor,entry['world'],mode,0)=={'software_stub':True}
            before=(len(entered),len(evidence.events))
            bad=copy.deepcopy(cursor);bad['original_device_operation_budget']=26
            try:engine.decision(net,bad,entry['world'],'immediate1_followup16',0)
            except ValueError:pass
            else:raise AssertionError('Changed budget entered decision')
            assert before==(len(entered),len(evidence.events));checks[entry['world']+'_invalid_before_engine']=True
            evidence.allow=False
            try:engine.decision(net,cursor,entry['world'],'immediate1_followup16',0)
            except TimeoutError:pass
            else:raise AssertionError('Expired bound entered decision')
            assert before==(len(entered),len(evidence.events));checks[entry['world']+'_expired_before_engine']=True
            assert evidence.costs['input_admission_seconds']>0
    finally:binding.OriginalEngine.decision=original
    assert len(entered)==8 and not forbidden
    assert binding.PaidRecedingRuntime.__init__.__globals__['PaidDecisionEngine'] is binding.AdmittedPaidDecisionEngine
    put(B/'Results.json',{'status':'PASS_ALL4_ROOTS_8_REAL_ENGINE_BOUNDARY_ADMISSIONS_8_PREENTRY_REJECTIONS',
        'checks':checks,'entered_original_decision_stub':entered,'controller_class_dependency_bound':True,
        'source_certificate':binding.SOURCE_CERTIFICATE,'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Preentry boundary/software only. No real query, complete controller trajectory, new owner or performance authorization. Future input states must pass this same gate.'})
    print(json.dumps({'admitted_engine_binding':'PASS','actual_root_method_entries':8,'negative_boundary_checks':8,'science':0}))
if __name__=='__main__':main()
