Unexecuted native forecasts and unrecovered original outputs leave full method rankings UNKNOWN. Available-output K values are descriptive only; conservative full-ranking intervals are reported. No partial result is a negative learning or numerical-method finding. Both derivative variants and every declared action/unknown/failure remain retained. This is current-only affine development ranking, not physical rollout, learned contribution or D-SE superiority. No automatic training follows.

{
  "K4_actual_method_evidence": {
    "old_admittance_derivative": {
      "complete_execution_oracle_states": 98,
      "exact_inclusion_wins": 71,
      "unexecuted_or_unrecovered_inclusion_UNKNOWN_states": 78,
      "equal_world_conservative_lower": 0.4036841945932855,
      "equal_world_conservative_upper": 0.8176540631086087,
      "all23_world_intervals": {
        "0192b760cb410512b8fc5a51b39b2c0c715897d680c59794343af7598a39c3c1": {
          "oracle_states": 9,
          "lower": 0.4444444444444444,
          "upper": 0.8888888888888888
        },
        "08938f18867ba469d32a4a874837b8a20bd00e9125f4dc4105685313914eff8e": {
          "oracle_states": 0,
          "lower": null,
          "upper": null
        },
        "0ac875f9bf14b77d98516a09c8a2cd74959d0b8a7ecd174ba14a03dcbda0c1ff": {
          "oracle_states": 7,
          "lower": 0.5714285714285714,
          "upper": 1.0
        },
        "0c5e587de313667efa553cd43d237fc293c86a50e4245effe934f4050194201c": {
          "oracle_states": 7,
          "lower": 0.42857142857142855,
          "upper": 0.8571428571428571
        },
        "0c903292489a697135b890338352cd533f51bc652a7f2cd3551af227c7438f39": {
          "oracle_states": 7,
          "lower": 0.42857142857142855,
          "upper": 0.8571428571428571
        },
        "14421bdf768a64b608e33e03e5aed8ebf057795860a94ccb9bd65bef2a3a6818": {
          "oracle_states": 7,
          "lower": 0.2857142857142857,
          "upper": 1.0
        },
        "22fed8a2b9ea7450bc09c6ba79d16a8541496abfe920e077c50c86551d379771": {
          "oracle_states": 7,
          "lower": 0.42857142857142855,
          "upper": 0.5714285714285714
        },
        "269f321fe1bf6bed65835ea0cf1370ca7342dccc391a5306fd0d2bdb8b0902ee": {
          "oracle_states": 3,
          "lower": 0.0,
          "upper": 0.6666666666666666
        },
        "35bd1a049f1e7526ae1ff369ba6dc0a45d2e85896ff4cfbe5343aa349c825d7f": {
          "oracle_states": 3,
          "lower": 0.3333333333333333,
          "upper": 0.3333333333333333
        },
        "395b6bc3f42016606d171cd3a3cd107458f5fedb9c9805801eae853381597a7d": {
          "oracle_states": 3,
          "lower": 0.0,
          "upper": 0.6666666666666666
        },
        "3ed6bbe7c3475802628729e5d79c871f527656385ad33663456393a0852f8ad1": {
          "oracle_states": 5,
          "lower": 0.6,
          "upper": 1.0
        },
        "4371fc97643f5c59e61b05d451c2c3227a3fc1c7b94f312412d9ec339da034d7": {
          "oracle_states": 13,
          "lower": 0.23076923076923078,
          "upper": 0.6153846153846154
        },
        "45252e1eb470d9ca19f189e3dddd36c61bfe50dcecd8ec43f2ba67af3968f64f": {
          "oracle_states": 9,
          "lower": 0.3333333333333333,
          "upper": 0.8888888888888888
        },
        "574e84c9bdfe2ab404f954e28b4fde693c84a07abd1a6a8f8f7e6d6ea2ebb8e2": {
          "oracle_states": 13,
          "lower": 0.46153846153846156,
          "upper": 0.9230769230769231
        },
        "63ebd10fc1fc4d601d33a14a73ba0342580bfd1ed15ed78d4acdc359022eb667": {
          "oracle_states": 3,
          "lower": 0.6666666666666666,
          "upper": 1.0
        },
        "6d69f2198f8a4178ccaec2f359623c22f0441e169e780b85bee4b912482e0b3c": {
          "oracle_states": 9,
          "lower": 0.2222222222222222,
          "upper": 0.7777777777777778
        },
        "71c324d3a3f4f278ece90dfe1d98ec64904d53351b7e499ca6b24453f015e334": {
          "oracle_states": 11,
          "lower": 0.6363636363636364,
          "upper": 0.8181818181818182
        },
        "74844d46612bbac0d3c61aedee7fb674851635defe038271247e90e6ce210833": {
          "oracle_states": 21,
          "lower": 0.47619047619047616,
          "upper": 0.8571428571428571
        },
        "7b819c5af188ec8003c322721aa0f3d26389e7862b2af9e6fbf3ff8f2693c3e4": {
          "oracle_states": 3,
          "lower": 0.6666666666666666,
          "upper": 0.6666666666666666
        },
        "8482535482baae9fad33776a3b81d2a88c4251444a9c2621e8b0e11340483694": {
          "oracle_states": 15,
          "lower": 0.4666666666666667,
          "upper": 1.0
        },
        "885a992742ea79fecb3949a14e3fa229ca7398cc7e8dbc4c383b89dff2086dbe": {
          "oracle_states": 3,
          "lower": 0.6666666666666666,
          "upper": 1.0
        },
        "98d45437e1361f9fc57e9f1d949ae68f92f372a5e453df859ac7164cfa526268": {
          "oracle_states": 15,
          "lower": 0.2,
          "upper": 0.9333333333333333
        },
        "99b23cc444e17e8286b3a19641c222891e7dd8c548b102f85487dab2df6d5dc9": {
          "oracle_states": 3,
          "lower": 0.3333333333333333,
          "upper": 0.6666666666666666
        }
      }
    },
    "candidate_admittance_derivative": {
      "complete_execution_oracle_states": 99,
      "exact_inclusion_wins": 54,
      "unexecuted_or_unrecovered_inclusion_UNKNOWN_states": 77,
      "equal_world_conservative_lower": 0.33719411901230084,
      "equal_world_conservative_upper": 0.7461134824771188,
      "all23_world_intervals": {
        "0192b760cb410512b8fc5a51b39b2c0c715897d680c59794343af7598a39c3c1": {
          "oracle_states": 9,
          "lower": 0.1111111111111111,
          "upper": 0.5555555555555556
        },
        "08938f18867ba469d32a4a874837b8a20bd00e9125f4dc4105685313914eff8e": {
          "oracle_states": 0,
          "lower": null,
          "upper": null
        },
        "0ac875f9bf14b77d98516a09c8a2cd74959d0b8a7ecd174ba14a03dcbda0c1ff": {
          "oracle_states": 7,
          "lower": 0.42857142857142855,
          "upper": 0.8571428571428571
        },
        "0c5e587de313667efa553cd43d237fc293c86a50e4245effe934f4050194201c": {
          "oracle_states": 7,
          "lower": 0.42857142857142855,
          "upper": 0.8571428571428571
        },
        "0c903292489a697135b890338352cd533f51bc652a7f2cd3551af227c7438f39": {
          "oracle_states": 7,
          "lower": 0.5714285714285714,
          "upper": 1.0
        },
        "14421bdf768a64b608e33e03e5aed8ebf057795860a94ccb9bd65bef2a3a6818": {
          "oracle_states": 7,
          "lower": 0.2857142857142857,
          "upper": 1.0
        },
        "22fed8a2b9ea7450bc09c6ba79d16a8541496abfe920e077c50c86551d379771": {
          "oracle_states": 7,
          "lower": 0.2857142857142857,
          "upper": 0.42857142857142855
        },
        "269f321fe1bf6bed65835ea0cf1370ca7342dccc391a5306fd0d2bdb8b0902ee": {
          "oracle_states": 3,
          "lower": 0.0,
          "upper": 0.6666666666666666
        },
        "35bd1a049f1e7526ae1ff369ba6dc0a45d2e85896ff4cfbe5343aa349c825d7f": {
          "oracle_states": 3,
          "lower": 0.3333333333333333,
          "upper": 0.3333333333333333
        },
        "395b6bc3f42016606d171cd3a3cd107458f5fedb9c9805801eae853381597a7d": {
          "oracle_states": 3,
          "lower": 0.0,
          "upper": 0.6666666666666666
        },
        "3ed6bbe7c3475802628729e5d79c871f527656385ad33663456393a0852f8ad1": {
          "oracle_states": 5,
          "lower": 0.6,
          "upper": 1.0
        },
        "4371fc97643f5c59e61b05d451c2c3227a3fc1c7b94f312412d9ec339da034d7": {
          "oracle_states": 13,
          "lower": 0.23076923076923078,
          "upper": 0.6153846153846154
        },
        "45252e1eb470d9ca19f189e3dddd36c61bfe50dcecd8ec43f2ba67af3968f64f": {
          "oracle_states": 9,
          "lower": 0.1111111111111111,
          "upper": 0.5555555555555556
        },
        "574e84c9bdfe2ab404f954e28b4fde693c84a07abd1a6a8f8f7e6d6ea2ebb8e2": {
          "oracle_states": 13,
          "lower": 0.38461538461538464,
          "upper": 0.8461538461538461
        },
        "63ebd10fc1fc4d601d33a14a73ba0342580bfd1ed15ed78d4acdc359022eb667": {
          "oracle_states": 3,
          "lower": 0.6666666666666666,
          "upper": 1.0
        },
        "6d69f2198f8a4178ccaec2f359623c22f0441e169e780b85bee4b912482e0b3c": {
          "oracle_states": 9,
          "lower": 0.2222222222222222,
          "upper": 0.7777777777777778
        },
        "71c324d3a3f4f278ece90dfe1d98ec64904d53351b7e499ca6b24453f015e334": {
          "oracle_states": 11,
          "lower": 0.2727272727272727,
          "upper": 0.45454545454545453
        },
        "74844d46612bbac0d3c61aedee7fb674851635defe038271247e90e6ce210833": {
          "oracle_states": 21,
          "lower": 0.2857142857142857,
          "upper": 0.6666666666666666
        },
        "7b819c5af188ec8003c322721aa0f3d26389e7862b2af9e6fbf3ff8f2693c3e4": {
          "oracle_states": 3,
          "lower": 0.6666666666666666,
          "upper": 0.6666666666666666
        },
        "8482535482baae9fad33776a3b81d2a88c4251444a9c2621e8b0e11340483694": {
          "oracle_states": 15,
          "lower": 0.3333333333333333,
          "upper": 0.8666666666666667
        },
        "885a992742ea79fecb3949a14e3fa229ca7398cc7e8dbc4c383b89dff2086dbe": {
          "oracle_states": 3,
          "lower": 0.6666666666666666,
          "upper": 1.0
        },
        "98d45437e1361f9fc57e9f1d949ae68f92f372a5e453df859ac7164cfa526268": {
          "oracle_states": 15,
          "lower": 0.2,
          "upper": 0.9333333333333333
        },
        "99b23cc444e17e8286b3a19641c222891e7dd8c548b102f85487dab2df6d5dc9": {
          "oracle_states": 3,
          "lower": 0.3333333333333333,
          "upper": 0.6666666666666666
        }
      }
    }
  },
  "available_output_preferences_ONLY": {
    "old_admittance_derivative": {
      "counts": {
        "aligned": 5905,
        "reversed": 142,
        "score_tied": 9,
        "unknown": 5828
      },
      "reversed_coverage": {
        "states": 23,
        "worlds": 13,
        "families": [
          "N1_tieline",
          "combined"
        ]
      }
    },
    "candidate_admittance_derivative": {
      "counts": {
        "aligned": 2961,
        "reversed": 2963,
        "score_tied": 222,
        "unknown": 5738
      },
      "reversed_coverage": {
        "states": 45,
        "worlds": 14,
        "families": [
          "N1_tieline",
          "combined"
        ]
      }
    }
  },
  "unknown_counts": {
    "finite_linear_forecast": 43183,
    "nonphysical_linear_forecast_no_outcome_claim": 82,
    "unknown_affine_forecast": 33737
  }
}
