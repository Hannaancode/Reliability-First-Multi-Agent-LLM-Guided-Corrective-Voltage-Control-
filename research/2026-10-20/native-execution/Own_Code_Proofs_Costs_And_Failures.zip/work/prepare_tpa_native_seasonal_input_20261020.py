"""Actual author 24 seasonal inputs, with original public-test exposure disclosed."""
import hashlib,json,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/tpa_native_one_step_preparation_20261020'
def main():
    start=time.monotonic();days=[(2,3),(2,18),(3,5),(3,20),(4,4),(4,19),(5,5),(5,20),(6,5),(6,21),(7,7),(7,23),(8,7),(8,22),(9,8),(9,22),(10,7),(10,23),(11,7),(11,22),(12,6),(12,22),(1,5),(1,19)]
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Exact author get_24jieqi(year=2012) inputs, all24fixedseasonaldays/all480points/all3nativePV/loadP/loadQ means. Preserve native reshape order. No PF or model.','fixed_days':days,'rows_read_per_trace':366*480,'first_engineering_identity':'First author row:2013Jan1/day366/23:06ordinal;past2012conditioning','public120_author_schedule_exposure':'40rowsin2012,40in2013,40in2014. All retained, not unusedconfirmation. 2012conditioning is same-year/future covariate information for some public2012test days; no causaltemporal2012claim.','prior_false_assumption':'Seasonal_Preparation_Diagnosis.json','new_PF_model_calls':0}
    with (OUT/'Seasonal_Input_Protocol_v2.json').open('x',encoding='utf-8') as f:json.dump(protocol,f,indent=2)
    means={}
    with zipfile.ZipFile(ROOT/'outputs/mapdn_author_dataset_preservation_20261020/voltage_control_data.zip') as z:
        for key in ['pv_active','load_active','load_reactive']:
            chunks=[]
            with z.open('voltage_control_data/case322_3min_final/'+key+'.csv') as f:
                for frame in pd.read_csv(f,chunksize=16384,nrows=366*480):
                    a=frame.iloc[:,1:].to_numpy(dtype=np.float64);assert np.isfinite(a).all();chunks.append(a.mean(axis=-1))
            means[key]=np.concatenate(chunks);assert len(means[key])==366*480
    actual=[]
    for month,day in days:
        i=(datetime(2012,month,day)-datetime(2012,1,1)).days*480
        actual.append(np.array([means[k][i:i+480] for k in ['pv_active','load_active','load_reactive']]).reshape(-1,3))
    a=np.array(actual);assert a.shape==(24,480,3) and np.isfinite(a).all();np.savez(OUT/'Exact_Native_Seasonal_Input.npz',jieqi_info=a)
    (OUT/'Seasonal_Input_Result.json').write_text(json.dumps({'status':'ALL24_NATIVE_2012_SEASONAL_INPUTS_PREPARED','shape':list(a.shape),'npz_sha256':hashlib.sha256((OUT/'Exact_Native_Seasonal_Input.npz').read_bytes()).hexdigest(),'native_float64_values_sha256':hashlib.sha256(a.tobytes()).hexdigest(),'source_reshape_order_preserved':True,'all120_year_exposure_disclosed':True,'workflow_seconds':time.monotonic()-start,'new_model_PF_calls':0},indent=2),encoding='utf-8')
    print(json.dumps({'shape':list(a.shape),'seconds':time.monotonic()-start,'calls':0}))
if __name__=='__main__':main()
