"""Prospective missing-only native DFF first-menu measurements, no commits."""
import copy,json,os,pickle,sys,time,traceback
from pathlib import Path
from reflection118_chronological_core_20261022 import *
P=R/'outputs/r118_first_round_missing_only_preparation_20261022';O=R/'outputs/r118_first_round_missing_only_execution_20261022'
def main():
    O.mkdir(exist_ok=False);began=time.monotonic();put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-began<120;time.sleep(.1)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp,numpy as np
    from frozen_physics_loader import load_stack,AUDIT
    from public_size_u61_preservation import journal
    p=read(P/'Protocol.json')
    for n,h in p['source_hashes'].items():assert sha(R/n)==h
    for n,h in p['input_hashes'].items():assert sha(R/n)==h
    _,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    declarations=read(R/p['frontier'])['rows'];assert len(declarations)==2034
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    roots={r['case_id']:pickle.loads((R/r['solved_payload']).read_bytes())['net'] for r in bindings}
    native=pp.runpp;rows=[];binary=0;error=None
    costs=dict(new_PF_attempts=0,new_PF_returns=0,new_PF_exceptions=0,new_PF_seconds=0.,paid_native80_reused=0,known_unknown_skipped=0,new_model_training_optimizer_calls=0,actual_commits=0)
    def progress():
        temp=O/'Status.pending';temp.write_text(json.dumps(dict(closed_records=len(rows),declared=2034,costs=costs,binary_bytes=binary,elapsed_seconds=time.monotonic()-began)),encoding='utf-8');os.replace(temp,O/'Status.json')
    try:
        for i,r in enumerate(declarations):
            if time.monotonic()-began>=p['science_seconds']:break
            record=dict(identity=i,case_id=r['case_id'],source_order=r['source_order'],action=r['action'],solver_kwargs=r['solver_kwargs'])
            if r['status']=='EXACT_CURRENT_PAID80_RETURN_REUSABLE':
                record.update(status='PAID_NATIVE80_REUSE_NO_NEW_PF',paid_matches=r['paid_matches']);costs['paid_native80_reused']+=1
            elif r['status']!='NO_MATCH_IN_NAMED_TRACKED_SCOPE_NOT_GLOBAL_ABSENCE':
                record.update(status='PRIOR_COLLISION_UNKNOWN_NO_CALL',prior_classification=r);costs['known_unknown_skipped']+=1
            else:
                root=roots[r['case_id']];expected=copy.deepcopy(root);runner.rescue.apply_action(expected,r['action']);calls=[]
                def provider(net,**kw):
                    nonlocal binary
                    # Engineering errors must escape the author's Exception catcher.
                    try:
                        assert kw==p['solver_kwargs'] and not calls
                        frames_equal(net,expected)
                        assert time.monotonic()-began<p['science_seconds'] and binary+4*1024**2<=p['binary_bytes']
                        before=capsule(O/f'{i:04d}_before.zlib',net);binary+=before['bytes']
                        restored=decode(O,before);frames_equal(net,restored)
                    except Exception as e:raise BaseException('PREFLIGHT_ENGINEERING_ERROR_NO_PF: '+repr(e)) from e
                    costs['new_PF_attempts']+=1;journal(O/'journal.jsonl',dict(event='NEW_NATIVE80_ATTEMPT_RESERVED',identity=i,before=before,kwargs=kw,protocol_sha256=sha(P/'Protocol.json')))
                    tick=time.perf_counter();exc=None
                    try:native(net,**kw);assert net.converged;costs['new_PF_returns']+=1
                    except Exception as e:exc=dict(type=type(e).__name__,message=str(e));costs['new_PF_exceptions']+=1
                    seconds=time.perf_counter()-tick;costs['new_PF_seconds']+=seconds
                    after=capsule(O/f'{i:04d}_after.zlib',net);binary+=after['bytes']
                    calls.append(dict(before=before,after=after,exception=exc,seconds=seconds))
                    if exc is not None:raise RuntimeError('PRESERVED_NATIVE_EXCEPTION_NO_RETRY: '+str(exc))
                pp.runpp=provider
                try:verification=runner.rescue.verify_action(root,r['action'])
                finally:pp.runpp=native
                assert len(calls)==1,'All frozen first-menu proposals must reach exactly one legal source-native query'
                record.update(status='RETURNED_NEW_NATIVE80_QUERY' if calls[0]['exception'] is None else 'EXCEPTION_UNKNOWN_NO_RETRY',verification=verification,**calls[0])
                if calls[0]['exception'] is None and not (O/'First_Receipt_Persistent_Cold_Gate.json').exists():
                    saved=decode(O,calls[0]['after']);cursor=dict(next_declared_identity=i+1,paid_new_identities=[i],costs=copy.deepcopy(costs),absolute_began_monotonic=began,deadline_monotonic=began+p['science_seconds'],source_protocol_sha256=sha(P/'Protocol.json'))
                    checkpoint=capsule(O/'First_Paid_Receipt_And_Cursor.zlib',dict(before=decode(O,calls[0]['before']),after=saved,cursor=cursor,action=r['action']))
                    cold=decode(O,checkpoint);assert cold['cursor']==cursor
                    def cached(n,**kw):
                        try:assert kw==p['solver_kwargs'];frames_equal(n,cold['before']);restore_exact(n,cold['after'])
                        except Exception as e:raise BaseException('COLD_CACHE_ERROR: '+repr(e)) from e
                    pp.runpp=cached
                    try:coldverification=runner.rescue.verify_action(copy.deepcopy(root),r['action'])
                    finally:pp.runpp=native
                    assert coldverification==verification
                    put(O/'First_Receipt_Persistent_Cold_Gate.json',dict(status='PASS_SERIALIZED_RECEIPT_CURSOR_AND_ORIGINAL_VERIFIER_COLD_REUSE',cursor=cursor,new_PF_model_calls_in_cold=0,not_a_full_controller_process_restart=True))
            put(O/f'record_{i:04d}.json',record);rows.append(record)
            journal(O/'journal.jsonl',dict(event='DECLARED_IDENTITY_CLOSED',identity=i,status=record['status'],record_sha256=sha(O/f'record_{i:04d}.json')))
            progress()
    except BaseException as e:error=dict(type=type(e).__name__,failure=str(e),traceback=traceback.format_exc())
    finally:pp.runpp=native
    put(O/'Result.json',dict(status='COMPLETE_FIXED_FIRST_MENU_WITH_RETAINED_UNKNOWNS' if len(rows)==2034 and error is None else 'TERMINAL_PARTIAL_UNENTERED_UNKNOWN_NO_RETRY',
        declared=2034,closed_records=len(rows),rows=rows,costs=costs,failure=error,unentered_identities=list(range(len(rows),2034)),
        first_round_only_no_controller_endpoint_or_LLM_comparison=True,workflow_seconds=time.monotonic()-began))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
if __name__=='__main__':main()
