"""Local transport only. Never generates a model response or invokes physics."""
import hashlib
import json
import os
import time
import uuid
from pathlib import Path


def publish_once(destination, payload, expected_sha256):
    """Flush before exposing a name; never replace an existing response."""
    destination = Path(destination)
    if hashlib.sha256(payload).hexdigest() != expected_sha256:
        raise ValueError('Payload hash mismatch')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name('.pending_' + uuid.uuid4().hex)
    with temporary.open('xb') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        try:
            os.link(temporary, destination)
        except FileExistsError:
            if destination.read_bytes() != payload:
                raise ValueError('Existing immutable response differs')
    finally:
        temporary.unlink()


def read_response(path, request, expected_sha256, absolute_deadline,
                  *, read_bytes=None, clock=time.monotonic, sleep=time.sleep):
    """Bounded local read retries only; invalid data fails without repair.

    Caller passes the original absolute owner deadline, never a renewed budget.
    expected_sha256 must come from independently retained transport evidence.
    Returned attempts are charged local reads, not repeated model inference.
    """
    path = Path(path)
    read_bytes = read_bytes or path.read_bytes
    attempts = []
    while True:
        if clock() >= absolute_deadline:
            raise TimeoutError('Original absolute transport deadline reached')
        try:
            raw = read_bytes()
            attempts.append('returned')
            break
        except (PermissionError, FileNotFoundError) as exc:
            attempts.append(type(exc).__name__)
            remaining = absolute_deadline - clock()
            if remaining <= 0:
                raise TimeoutError('Original absolute transport deadline reached') from exc
            sleep(min(0.05, remaining))
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError('Response byte hash mismatch')
    value = json.loads(raw)
    if value['request'] != request or value['number'] != request['number']:
        raise ValueError('Response belongs to a different request')
    return value, {'local_read_attempts': attempts, 'bytes': len(raw),
                   'model_PF_calls': 0}
