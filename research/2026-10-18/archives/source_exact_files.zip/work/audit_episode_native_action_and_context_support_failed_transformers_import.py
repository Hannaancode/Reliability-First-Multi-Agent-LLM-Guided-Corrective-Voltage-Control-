"""Actual TRAIN action scope/tokenizer audit; no model load, PF or training."""
import os
os.environ['USE_TORCH']='0';os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
from pathlib import Path
from datetime import datetime,timezone
from collections import deque
import ast,hashlib,json,math,sys
from transformers import AutoTokenizer
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/llm_value_next_method_research_20261008'
DATA=BASE/'train_trajectory_collection_nullable_v2'
OUT=BASE/'episode_native_support_audit'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
assert not OUT.exists(),'Preserve complete/partial support audit'
assert read(BASE/'train_trajectory_canonical_package/Local_Archive_Audit.json')['CRC_and_every_wrapper_and_scientific_member_hash_passed']
protocol=read(DATA/'protocol.json');summary=read(DATA/'summary.json')
assert summary['all62_measurements_verified'] and summary['target_feasibility_gate_passed']
for n,h in protocol['frozen_source_sha256'].items():assert sha(ROOT/n)==h
model_dir=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
proof=read(ROOT/'outputs/frozen_input_verification.json')
for name,h in proof['model_files'].items():assert sha(model_dir/name)==h
source=ROOT/'work/e/audit/run_reflection_v4_safety_envelope.py'
names={'_safe_bus_q','init_feedback_state','build_compact_feedback_text','severity_stage','build_two_best_prompt_v2'}
nodes=[n for n in ast.parse(source.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(nodes)==len(names)
namespace={'json':json,'deque':deque,'ALLOWED_Q':[25,50,75,100,125,150,200,250,300]}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),namespace)
tokenizer=AutoTokenizer.from_pretrained(str(model_dir),local_files_only=True)
assert 'torch' not in sys.modules,'Tokenizer audit must not import Torch or load models'
OUT.mkdir()
with (OUT/'owner.claim').open('x') as f:f.write(str(os.getpid()))
records={};actions=[];contexts=[];episode_rows=[];pair_rows=[]
for world in protocol['worlds']:
    portfolio=read(DATA/'portfolios'/(world['scenario_id']+'.json'))
    for branch in ('DFF','DFF-ALT'):
        record=read(DATA/'branches'/(world['scenario_id']+'__'+branch+'.json'))
        assert record['status']=='complete_verified_measurement';records[(world['scenario_id'],branch)]=record
        observations=record['observations'];executed=record['result']['executed_actions'];branch_actions=[]
        for position,item in enumerate(observations):
            view=item['input_observation'];tables=view['physical_tables']['res_bus'];col=tables['columns'].index('vm_pu')
            global_uv=[str(int(b)) for b,v in zip(tables['index'],tables['values']) if float(v[col])<.95]
            assert len(global_uv)==view['global_metrics']['uv_count']
            for zone in sorted(view['zone_buses']):
                pool=view['raw_common_and_zone_pools'][zone]
                messages=namespace['build_two_best_prompt_v2']('reflection_v2',view['zone_reports'][zone],global_uv,pool,[],namespace['init_feedback_state']())
                ids=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_dict=False)
                assert isinstance(ids,list) and all(type(t)is int for t in ids)
                contexts.append({'scenario_sha256':world['sha256'],'branch':branch,'decision':item['decision'],
                    'observation_sha256':item['observation_sha256'],'zone':zone,'candidate_count':len(pool),
                    'actual_native_primary_prompt_tokens':len(ids),'fits4096_with384reserve':len(ids)+384<=4096,
                    'prompt_sha256':hashlib.sha256(json.dumps(messages,separators=(',',':')).encode()).hexdigest(),
                    'fresh_feedback_contract':'empty failed-action list and init_feedback_state as existing per-state query prototype',
                    'query_eligible_global_UV_and_candidate_pool':bool(global_uv and pool)})
            if position==len(executed):continue
            step=executed[position];assert observations[position+1]['committed_action']==step['action']
            payload=step['action'].get('add_shunts_q_mvar');assert isinstance(payload,dict) and len(payload)==1
            bus=int(next(iter(payload)));q=float(next(iter(payload.values())))
            assert math.isfinite(q) and q in [25,50,75,100,125,150,200,250,300]
            legal=[z for z,pool in view['raw_common_and_zone_pools'].items() if bus in pool]
            owning=[z for z,buses in view['zone_buses'].items() if bus in buses]
            row={'scenario_sha256':world['sha256'],'branch':branch,'iteration':step['iteration'],
                 'before_observation_sha256':item['observation_sha256'],'after_observation_sha256':observations[position+1]['observation_sha256'],
                 'actual_action':step['action'],'raw_bus':bus,'raw_Q_mvar':q,'native_legal_zones':legal,'zone_owners':owning,
                 'strict_native_scope_and_Q_supported':bool(legal),
                 'action_prefix_sha256':hashlib.sha256(json.dumps([a['action'] for a in executed[:position]],sort_keys=True).encode()).hexdigest(),
                 'raw_action_JSON_tokens':len(tokenizer.encode(json.dumps(step['action'],sort_keys=True,separators=(',',':')),add_special_tokens=False)),
                 'training_reply_not_inferred':'Raw action JSON is an inventory only; original two-best generation schema and exact normalized action likelihood still need a separate contract.'}
            actions.append(row);branch_actions.append(row)
        episode_rows.append({'scenario_id':world['scenario_id'],'scenario_sha256':world['sha256'],'branch':branch,
            'actual_committed_actions':len(branch_actions),'all_actions_native_supported':all(a['strict_native_scope_and_Q_supported'] for a in branch_actions),
            'nontrivial_protected_episode':portfolio['nontrivial_protected_episode_by_branch'][branch],
            'normal_terminal_UV_zero':portfolio['nontrivial_protected_terminal_by_branch'][branch],
            'initial_global_UV':record['result']['base_metrics']['uv_count'],'terminal_metrics':record['result']['final_metrics'],
            'full_original_controller_costs':record.get('original_controller_costs',record['new_actual_costs'].get('new_literal_controller'))})
    pair={b:[a for a in actions if a['scenario_sha256']==world['sha256'] and a['branch']==b] for b in ('DFF','DFF-ALT')}
    first={b:rows[0] if rows else None for b,rows in pair.items()}
    shared=sorted(set(first['DFF']['native_legal_zones']) & set(first['DFF-ALT']['native_legal_zones'])) if all(first.values()) else []
    protected=portfolio['nontrivial_protected_episode_by_branch']
    pair_rows.append({'scenario_id':world['scenario_id'],'scenario_sha256':world['sha256'],
        'both_episodes_fully_native_supported':all(a['strict_native_scope_and_Q_supported'] for rows in pair.values() for a in rows),
        'distinct_executed_first_actions':all(first.values()) and first['DFF']['actual_action']!=first['DFF-ALT']['actual_action'],
        'protected_vs_nonprotected_episode':protected['DFF']!=protected['DFF-ALT'],
        'same_root_first_action_shared_legal_zones':shared,
        'naive_single_zone_first_action_preference_has_common_conditioning':bool(shared),
        'DFF_first_action_legal_zones':first['DFF']['native_legal_zones'] if first['DFF'] else [],
        'DFF_ALT_first_action_legal_zones':first['DFF-ALT']['native_legal_zones'] if first['DFF-ALT'] else []})
assert len(records)==62 and len(contexts)==343*4 and len(actions)==281
protected=[e for e in episode_rows if e['nontrivial_protected_episode']]
contrasts=[p for p in pair_rows if p['protected_vs_nonprotected_episode'] and p['distinct_executed_first_actions']]
summary={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'actual_episodes':len(episode_rows),'actual_recorded_action_steps':len(actions),
 'native_supported_action_steps':sum(a['strict_native_scope_and_Q_supported'] for a in actions),
 'actual_primary_prompt_tokenizer_checks':len(contexts),'maximum_native_primary_prompt_tokens':max(c['actual_native_primary_prompt_tokens'] for c in contexts),
 'all_primary_prompts_fit4096_with384reserve':all(c['fits4096_with384reserve'] for c in contexts),
 'protected_nontrivial_episodes':len(protected),'protected_episodes_fully_native_supported':sum(e['all_actions_native_supported'] for e in protected),
 'actual_protected_contrast_pairs':len(contrasts),'protected_contrasts_fully_native_supported':sum(p['both_episodes_fully_native_supported'] for p in contrasts),
 'protected_contrasts_with_shared_legal_first_action_zone':sum(bool(p['same_root_first_action_shared_legal_zones']) for p in contrasts),
 'cross_zone_first_action_contrasts':sum(not bool(p['same_root_first_action_shared_legal_zones']) for p in contrasts),
 'maximum_raw_action_JSON_tokens':max(a['raw_action_JSON_tokens'] for a in actions),
 'scope_issue':'Single-zone DPO cannot silently pair different-zone outputs or use future observations as present context. Global hierarchical likelihood/interface proof is a separate research gate.',
 'new_model_forwards':0,'new_generations':0,'new_optimizer_steps':0,'new_PF_calls':0,'Torch_imported':False,
 'input_protocol_sha256':sha(DATA/'protocol.json'),'original_prompt_source_sha256':sha(source),'source_sha256':sha(Path(__file__)),
 'original_frozen_model_files_preserved':True,'LLM_superiority_established':False}
write(OUT/'Actual_Action_Support.json',actions);write(OUT/'Actual_Native_Prompt_Context_Checks.json',contexts)
write(OUT/'Actual_Episode_Support.json',episode_rows);write(OUT/'Actual_Root_Pair_Conditioning_Audit.json',pair_rows);write(OUT/'summary.json',summary)
members={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.glob('*.json')}
write(OUT/'manifest.json',members)
print(json.dumps(summary,indent=2))
