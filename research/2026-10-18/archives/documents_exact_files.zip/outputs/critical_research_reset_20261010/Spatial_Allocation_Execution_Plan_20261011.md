# Spatial allocation: concrete execution plan, 11 October 2026

**There is no calibrated 90% probability of LLM superiority.** This plan gives a testable mechanism and stop rules. The earlier eight-root same-bus feedback plan failed; it stays stopped. This is a different question about safe spatial commitments and their real descendants. All original assets and adverse evidence remain preserved.

## Why this is the next question

The numerical controller already evaluates its whole immediate menu. An LLM cannot improve the identical exact immediate argmax by predicting it again. Observed residual trajectories were blocked by upper-voltage protection, rather than running out of action slots. The remaining hypothesis is that an earlier, individually safe spatial allocation can leave a better safe action set later. We must measure that effect before training another language policy.

Larger-model testing is already running under its separate, frozen original-role contract. It must finish unchanged. Its teacher-command accuracy, even if better, does not answer this sequence question.

## What is implemented and what remains

The paid two-step search core is implemented in `work/paid_spatial_two_step_search.py`. It supports original-score greedy expansion, a fixed width-eight numerical beam, and exhaustive admitted-first-child expansion. Each mode uses the entire first native menu. Descendants are visible only after their queries return. Missing receipts, wrong parent identities, absent successors and common-upper violations abort with UNKNOWN. No search function commits a state. Eleven labelled synthetic checks passed once; they establish software behavior only.

The additive native-query adapter is implemented in `work/paid_spatial_native_queries.py`. It calls the unchanged original global bus menu, Q grammar, cap, verifier and score under separately labelled common-upper mediation. It saves full returned trial nets, parent/process bindings and per-call receipts, distinguishes explicit verifier rejection from incomplete evidence, and forbids retrying an incomplete attempted identity. Own-issued saved bytes must match their anchors before restoration. The import passed without science. **Actual callback integration, independent audit and commit/receding-episode orchestration have not yet passed. This is not a launch-ready performance owner.**

The separately completed fresh engineering prefix already verifies one real native menu, one protected commit and full-state field/cap restoration: 128 new PF attempts, zero exceptions, exact selected-trial/commit continuous fields. Its 600-second owner ended. Do not extend or restart it. It does not certify a full cold following trajectory or this new planner.

## Fixed design for the numerical opportunity study

Before any new root solve, create an exclusive preparation directory containing exact scenario files, source hashes, network/metadata hashes, effective-input signatures, control definitions, resource limits and a reader source lock. Proposed roots are fixed below; they may not be replaced after a bad result:

| Root | Family | Exact modification rule |
|---|---|---|
| L1 | Load | Scale all loads by 1.387241 |
| L2 | Load | Scale all loads by 1.473619 |
| S1 | Source loss | Zero `p_mw` for every original sgen whose bus belongs to MG1 |
| S2 | Source loss | Zero `p_mw` for every original sgen whose bus belongs to MG3 |
| T1 | Line outage | Open original line indices 101 and 103 |
| T2 | Line outage | Open original line indices 127 and 135 |
| C1 | Combined | Scale all loads by 1.417263; open original line 101 |
| C2 | Combined | Scale all loads by 1.463927; open original line 129 |

These are development roots, not unused confirmation. Sgen indices must be materialized from the frozen original metadata and input tables before outcomes. Every line, zone and source must exist and produce a real input change. Compare both exact recipes and effective non-result input-table signatures with the retained recorded root catalog. If a declared root overlaps or is invalid, report that fact and stop preparation; do not silently choose a substitute. Coverage of the catalog must be stated, not called a universal historical exclusion. The eight roots are a fixed proposal until this input closure is actually saved and independently checked.

Use original trial/commit NR options, positive nine-Q grid, 450 named-shunt per-bus cap, 25 commitments, original source verifier and strict progress. Report original 1.06 behavior separately from common protection at 1.05+1e-8. No temporary violation, non-improving action, hidden successor, enlarged action grammar or free counterfactual is permitted.

Controls must include literal DFF, root-only DFF-ALT and unchanged D-SE selection, each complete with FULL BOTH-branch costs. Add a separately labelled common-protected portfolio, a receding two-step numerical beam of width eight, and exhaustive depth-two numerical search as the stronger horizon control. Exhaustive depth-two is a horizon reference, not an oracle for the entire 25-step episode. A language ranking cannot beat its fully paid exact depth-two maximum under the identical leaf objective; language value would need better paid allocation or a measured longer-episode outcome against equally informed numerical guidance.

The leaf objective is lexicographic minimum UV count, then minimum deficit, then maximum minimum voltage. STOP after an admitted first action is a legal leaf. Exact leaf ties retain original-score expansion order and original menu order. The first selected action is actually committed and independently checked; the second suggestion is never committed without current-state verification. Parent and process identities, not voltage resemblance, govern receipt reuse. Numerical preparation, cached measurements and teacher costs remain paid and disclosed.

Proposed resource registration: one CPU owner, seed 20261011, 28,800 seconds total including setup, 3,600 seconds maximum per declared root, 32 GiB total preserved payloads. Preserve the final already-returned capsule even if it crosses the storage estimate, then refuse further science. No budget extension, automatic replacement root or retry. Per-arm PF, exceptions, runtime, query reuse, storage and reader costs are separate. A timed-out or incomplete comparison is UNKNOWN, not a loss or a pass. These limits become binding only when a complete actual launcher/worker/reader protocol is frozen; this document launches nothing.

The prospective physical opportunity gate is: across all eight roots, at least 0.5 fewer terminal UV buses on equal-root mean versus both the literal D-SE and common-protected portfolio; strict improvement in at least two exact roots; no root-level terminal UV regression or new protection violation; all matched trajectories and continuous full-field replay complete. All healthy, failed and invalid identities remain in the declared accounting; missing outcomes prevent a gate pass.

For a deployable acquisition candidate, require PF-query count and measured online workflow time no greater than 1.5 times FULL BOTH-branch D-SE on the equal-root total, with preparation/training/teacher/failure costs additionally reported. Do not call the expensive exhaustive reference an efficient deployment. No unmeasured average query time or solver speed claim is allowed. A physical opportunity at high cost may justify further design, but fails this deployment allowance and does not automatically authorize a learner.

## When another language experiment is justified

Only a completed surviving mechanism permits a separately frozen language study. Its coordinator input contains measured current physical coordinates, current caps, remaining commitments, certified process state and legitimately paid receipts. World/branch IDs, AFTER states, hidden actions and terminal labels stay outside the forward. Original LOCAL adapters cannot simply be plugged into this GLOBAL coordinator. A later LOCAL interface needs its own common AND zone binding.

Use an outcome-aligned target from complete protected continuations, not teacher text likelihood or reconstruction. Compare deterministic search, a strong same-data trained numerical prior, matched-capacity numerical architecture and pretrained/frozen/random-backbone attribution. All receive identical causal information and charged query allowances. Freeze one partition, one seed, one budget and final checkpoint; pass actual full-context loader/gradient/memory/full optimizer-RNG-cursor preservation before science. No intermediate checkpoint or favorable-world selection.

The final claim still requires fresh per-state model inference, complete matched protected trajectories against original literal D-SE, continuous independent replay, full model/numerical/preparation/training/solver/failure costs and genuinely unused authorized confirmation. A model-size, format, engineering or numerical-search result does not establish language-pretraining benefit or novelty.

## Exact continuation point

1. Finish the existing 1.5B owner and sole matched-scale audit; leave the completed 0.5B arm alone. Use the prepared additive cost reader only after its exact terminal/release/known-failure conditions hold.
2. Materialize and independently close the eight fixed root inputs and catalog coverage, without PF or outcome inspection.
3. Bind the implemented query adapter to real native receipts under one small separately prospective engineering protocol, then implement actual commit/cold continuation and complete episode stop/cost rules. The previous completed engineering budget cannot be extended.
4. Freeze one full numerical opportunity worker and one independent reader, with exact source/input/ownership/resource/preservation gates, before launching the numerical study. No new GPU is needed for these stages.

This is a falsifiable execution plan, not a 90% success promise. A failed fixed gate stops its intervention; it does not prove that every possible LLM method must fail.
