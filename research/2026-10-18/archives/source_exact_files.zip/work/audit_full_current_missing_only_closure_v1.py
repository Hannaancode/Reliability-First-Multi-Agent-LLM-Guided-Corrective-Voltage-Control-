"""Independent decode/join audit of new missing packages; zero encoding/model/PF."""
import gzip
import hashlib
import json
import os
import sys
import time
import zipfile
from pathlib import Path
from datetime import datetime, timezone
from measure_full_current_compact_output_TRAIN_v1 import ROOT, R, RAW_ARCHIVE, MEMBER, EXPECTED_RAW, SMALL, LARGE, AutoTokenizer, digest, ids_hash, extended, read, sha, write, seal

OLD = extended(R / 'full_current_compact_output_TRAIN_readiness_v1')
NEW = extended(R / 'full_current_missing_only_token_closure_v1')
OUT = extended(R / 'full_current_missing_only_external_audit_v1')

def rows(p):
    with gzip.open(p, 'rt', encoding='utf8') as f:
        return [json.loads(s) for s in f]

def main():
    assert not OUT.exists()
    OUT.mkdir(); tick = time.perf_counter()
    write(OUT / 'reader.claim', {'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(), 'at_utc': datetime.now(timezone.utc).isoformat(), 'source_sha256': sha(Path(__file__))})
    assert read(R / 'full_current_compact_output_TRAIN_external_audit_v1/Independent_Full_Current_Compact_Output_Audit.json')['all_passed']
    manifest = read(NEW / 'Supplement_Manifest.json')
    with zipfile.ZipFile(NEW / 'Missing_Only_Current_Contract_Closure.zip') as z:
        assert len(z.namelist()) == len(set(z.namelist())) == len(manifest) + 1 and z.testzip() is None
        for name, m in manifest.items():
            data = z.read(name)
            assert len(data) == m['bytes'] and hashlib.sha256(data).hexdigest() == m['sha256']
            if name == 'sources/missing_only_owner.py': p = ROOT / 'work/close_full_current_missing_token_identities_v1.py'
            elif name == 'sources/interface.py': p = ROOT / 'work/full_current_compact_output_interface_v1.py'
            else: p = NEW / name
            assert sha(p) == m['sha256']
    missing = read(R / 'full_current_compact_output_missing_identity_preparation_v1/Exact_Genuinely_Unexecuted_Encoding_Identities.json')
    expected = {(ti, x['training_pair_sha256']) for x in missing for ti in x['missing_tokenizer_indices']}
    with zipfile.ZipFile(RAW_ARCHIVE) as z: raw = z.read(MEMBER)
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_RAW
    cases = [json.loads(s) for s in raw.decode('utf8').splitlines()]
    prefix = {(x['tokenizer_index'], x['actor_messages_sha256']): x for x in rows(OLD / 'Actual_Encoded_Prefixes.jsonl.gz')}
    full = {(x['tokenizer_index'], x['training_pair_sha256']): x for x in rows(OLD / 'Actual_Encoded_Continuations.jsonl.gz')}
    pn = rows(NEW / 'New_Missing_Prefix_Arrays.jsonl.gz'); fn = rows(NEW / 'New_Missing_Continuation_Arrays.jsonl.gz')
    assert len(pn) == 102 and len(fn) == 1878
    assert {(x['tokenizer_index'], x['training_pair_sha256']) for x in fn} == expected
    assert not expected.intersection(full)
    assert not {(x['tokenizer_index'], x['actor_messages_sha256']) for x in pn}.intersection(prefix)
    for x in pn: prefix[x['tokenizer_index'], x['actor_messages_sha256']] = x
    for x in fn: full[x['tokenizer_index'], x['training_pair_sha256']] = x
    tok = [AutoTokenizer.from_pretrained(str(p), local_files_only=True, trust_remote_code=False) for p in (SMALL, LARGE)]
    assert 'torch' not in sys.modules
    positions = {x['training_pair_sha256']: x['first_TRAIN_row_index'] for x in missing}
    header = ('You are a microgrid zone agent for physics-verified grid operation.\n'
        'Read the complete current local measurements below and return the compact zone-agent JSON schema.\n'
        'Decide whether this zone needs no action, a local voltage-support proposal, or coordinator review.\n'
        'Do not copy the input or explain in prose.\n\nLOCAL_ZONE_STATE:\n')
    supervised_spans = 0
    for f in fn:
        ti = f['tokenizer_index']; case = cases[positions[f['training_pair_sha256']]]
        user = json.loads(case['messages'][1]['content'])
        current = {'zone': user['zone'], 'local_measurements': user['local_measurements']}
        messages = [{'role': 'system', 'content': 'You are a microgrid zone agent. Return only valid JSON. No prose.'},
                    {'role': 'user', 'content': header + json.dumps(current, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))}]
        teacher = json.loads(case['messages'][2]['content'])
        target = {k: teacher.get(k) for k in ('state_summary','fault_detected','zone','min_voltage_pu','max_voltage_pu','n_undervoltage','n_overvoltage','proposed_action')}
        target['requires_coordinator_review'] = teacher.get('requires_coordinator_review', False)
        target['autonomous_local_action_allowed'] = teacher.get('autonomous_local_action_allowed', teacher.get('proposed_action') is not None)
        v = teacher.get('verification', {})
        target['verification'] = {'verdict': v.get('verdict'), 'reason': v.get('reason', '')}
        target['confidence'] = teacher.get('confidence', 'moderate')
        if teacher.get('candidate_action_for_coordinator') is not None: target['candidate_action_for_coordinator'] = teacher['candidate_action_for_coordinator']
        assert digest(messages) == f['actor_messages_sha256'] and digest([messages, target]) == f['training_pair_sha256']
        p = prefix[ti, f['actor_messages_sha256']]
        assert p['current_packet_json'] == current and ids_hash(p['input_ids']) == p['input_ids_sha256']
        pt = tok[ti].apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        assert tok[ti].decode(p['input_ids'], skip_special_tokens=False) == pt
        answer = json.dumps(target, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
        complete = tok[ti].apply_chat_template(messages + [{'role': 'assistant', 'content': answer}], tokenize=False, add_generation_prompt=False) + tok[ti].eos_token
        ids = p['input_ids'] + f['continuation_ids']
        assert tok[ti].decode(ids, skip_special_tokens=False) == complete
        assert ids_hash(ids) == f['full_input_ids_sha256'] and len(ids) == f['full_tokens']
        n = len(p['input_ids'])
        assert f['ignore_prefix_label_count'] == n == f['prefix_tokens']
        assert f['supervised_continuation_tokens'] == len(f['continuation_ids']) and ids[-1] == tok[ti].eos_token_id
        assert set(f['target_field_supervised_spans']) == set(target)
        for key, (lo, hi) in f['target_field_supervised_spans'].items():
            assert n <= lo < hi <= len(ids) and key in tok[ti].decode(ids[lo:hi], skip_special_tokens=False)
            supervised_spans += 1
        assert f['all_unpadded_attention_mask_values'] == 1 and f['no_truncation_packing_padding_or_target_in_generation_prefix']
    oldrows = rows(OLD / 'All16000_Current_Contract_Identity_Records.jsonl.gz')
    closed = rows(NEW / 'Closed_All16000_Identity_Records.jsonl.gz')
    assert len(oldrows) == len(closed) == 16000 and len(prefix) == 864 and len(full) == 8384
    worlds = set(); metric = [{'full_max':0,'prefix_max':0,'continuation_max':0} for _ in range(2)]
    for a, b in zip(oldrows, closed):
        assert all(b[k] == v for k, v in a.items()) and b['closure_status'] == 'complete'
        worlds.add(a['world_sha256_administrative_only'])
        values = [full[ti, a['complete_training_pair_sha256']] for ti in range(2)]
        assert values == b['closure_tokenizer_records'] and values[0]['full_input_ids_sha256'] == values[1]['full_input_ids_sha256']
        for ti, f in enumerate(values):
            assert f['full_tokens'] <= 4096 and f['prefix_tokens'] + 384 <= 4096 and f['supervised_continuation_tokens'] <= 384
            for k, j in [('full_max','full_tokens'),('prefix_max','prefix_tokens'),('continuation_max','supervised_continuation_tokens')]: metric[ti][k] = max(metric[ti][k], f[j])
    assert len(worlds) == 109
    journal = [json.loads(s) for s in (NEW / 'Actual_New_Encoding_Journal.jsonl').read_text(encoding='utf8').splitlines()]
    attempts = [x for x in journal if x['event'] == 'attempt']; returns = [x for x in journal if x['event'] == 'return']
    assert len(attempts) == len(returns) == 1980
    assert [(x['phase'],x['tokenizer_index'],x['key']) for x in attempts] == [(x['phase'],x['tokenizer_index'],x['key']) for x in returns]
    assert len({(x['phase'],x['tokenizer_index'],x['key']) for x in attempts}) == 1980
    assert read(NEW / 'Fresh_Frozen_Asset_Checks.json')['all_passed']
    result = {'all_passed': True, 'all16000_rows_109worlds_retained': True, 'all16000_actual_size_token_IDs_equal': True,
        'new_missing_prefix_arrays':102,'new_missing_continuation_arrays':1878,'new_supervised_field_spans':supervised_spans,
        'exact_old_successful_encodings_never_repeated':True,'new_resource_owner_ended_before_reader':True,
        'original_partial_status_retained':True,'metrics':metric,'all_scope_context_mask_identity_journal_archive_checks_passed':True,
        'gate':'PASS_input_token_span_only','new_encoding_model_PF_optimizer_controller_forecast_solve_cloud_calls':0,
        'actual_reader_seconds_before_seal':time.perf_counter()-tick,'no_learning_or_superiority_claim':True}
    write(OUT / 'Independent_Missing_Only_Closure_Audit.json', result)
    archive = seal(OUT, {'Independent_Missing_Only_Closure_Audit.json':OUT / 'Independent_Missing_Only_Closure_Audit.json','sources/reader.py':Path(__file__)}, 'Independent_Missing_Only_Closure_Audit.zip')
    write(OUT / 'Actual_CPU_Reader_Cost.json', {'workflow_seconds_including_archive':time.perf_counter()-tick,'all_prior_costs_separate_not_free':True})
    print(json.dumps({'pass':True,'gate':result['gate'],'metrics':metric,'archive':archive}))

if __name__ == '__main__': main()
