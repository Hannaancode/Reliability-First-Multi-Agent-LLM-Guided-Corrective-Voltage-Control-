"""Route SDK's initial authorization URL to the browser-controlled login tab."""
from pathlib import Path
import os, sys
from urllib.parse import urlsplit

assert len(sys.argv) == 2
url = sys.argv[1]
parsed = urlsplit(url)
assert parsed.scheme == 'https' and parsed.hostname == 'accounts.google.com'
profile = Path(os.environ['CLOUDSDK_CONFIG']).resolve()
assert profile.name == 'gcloud-hiergrid-sheenah'
target = profile / 'pending_authorization_url.txt'
temporary = target.with_suffix('.tmp')
temporary.write_text(url, encoding='utf-8')
temporary.replace(target)
# No authorization code, access token, refresh token, or user credential passes
# through this helper. The official SDK owns the loopback OAuth callback.
