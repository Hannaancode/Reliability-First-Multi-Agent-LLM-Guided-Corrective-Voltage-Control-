"""Bind ALL144 legal FIRST_ZONE actions to existing native root trial receipts.

No model-output inspection, controller choice, physics or archive re-audit.
Missing receipt identities remain unknown, never scientifically repeated.
"""
import copy
import hashlib
import json
import os
import pickle
import time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'
O = R / 'outputs/original_reflection_first_zone_paid_inventory_20261022'


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text('utf-8'))
def write(name, value):
    with (O / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush(); os.fsync(f.fileno())


def main():
    O.mkdir(exist_ok=False); started = time.perf_counter()
    write('Protocol.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
        'source_sha256': sha(Path(__file__)), 'resource_seconds': 180,
        'scope': 'ALL2saved roots x8native FIRST_ZONE candidate buses x9original Q values, fixed before any inspection of new model outputs',
        'inputs_sha256': sha(P / 'All2_Original_FIRST_ZONE_Inputs.json'),
        'root_bindings_sha256': sha(P / 'Exact_Paid_Root_State_Bindings.json'),
        'new_model_outputs_read': False, 'new_PF_model_converter_derivative_optimizer_calls': 0,
        'gate': 'Exact original root/current-before metrics, actuated non-result physical tables, source kwargs and anchored full saved trial. Missing or inconsistent receipt staysUNKNOWN, never a fresh query permission.',
        'performance_scope': 'Native original one-query paid evidence only; not full episode, external method, common normal-band or LLM superiority.'})
    import numpy as np
    import pandas as pd
    import pandapower as pp
    from frozen_physics_loader import load_stack, AUDIT
    calls = []
    def blocked(*a, **k): calls.append(True); raise BaseException('Physics forbidden during paid inventory')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, blocked)
    _, runner, _ = load_stack()
    assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    inputs = read(P / 'All2_Original_FIRST_ZONE_Inputs.json')
    bindings = {x['root']: x for x in read(P / 'Exact_Paid_Root_State_Bindings.json')}
    rows = []; root_summary = []
    for item in inputs:
        binding = bindings[item['root']]
        rootpath = R / binding['full_actual_root_payload']
        assert sha(rootpath) == binding['payload_sha256']
        root = pickle.loads(rootpath.read_bytes())['net']
        before = runner.rescue.grid_metrics(root)
        assert before == item['original_global_metrics']
        folder = R / binding['source_branch']
        candidates = {}
        # Read only the closed first-decision source prefix. Later decisions
        # and the running model study's outcomes are deliberately not read.
        with (folder / 'scientific.jsonl').open('rb') as f:
            for line in f:
                row = json.loads(line)['row']
                if row['event'] != 'literal_candidate_return': continue
                data = row['payload']
                if data['decision'] > 1: break
                bus, q = next(iter(data['action']['add_shunts_q_mvar'].items()))
                key = (int(bus), float(q))
                assert key not in candidates
                candidates[key] = data
        count = 0
        for bus in item['candidate_buses']:
            for q in [25., 50., 75., 100., 125., 150., 200., 250., 300.]:
                assert time.perf_counter() - started < 180
                record = {'root': item['root'], 'case_source': item['scenario_path'],
                          'root_payload_sha256': binding['payload_sha256'], 'bus': int(bus), 'q_mvar': q,
                          'status': 'UNKNOWN_MISSING_PAID_ROOT_QUERY', 'new_scientific_calls': 0}
                old = candidates.get((int(bus), q))
                if old is None:
                    rows.append(record); continue
                assert old['verification']['before'] == before
                # An original rejected cap/no_action may have no PF capsule.
                if len(old['solver_capsules']) != 1:
                    record.update(status='UNKNOWN_NO_SINGLE_RETURNED_SOLVER_CAPSULE',
                                  original_verification=old['verification'])
                    rows.append(record); continue
                anchor = old['solver_capsules'][0]
                cap = folder / anchor['relative']
                assert sha(cap / 'Manifest.json') == anchor['manifest_sha256']
                meta = read(cap / 'Manifest.json'); savedraw = (cap / 'trusted_local_net.pkl').read_bytes()
                assert len(savedraw) == meta['payload_bytes'] and hashlib.sha256(savedraw).hexdigest() == anchor['payload_sha256'] == meta['payload_sha256']
                saved = pickle.loads(savedraw)['net']
                assert meta['role'] == 'trial' and 'RETURN' in meta['status'].upper()
                actual = copy.deepcopy(root)
                runner.rescue.apply_action(actual, old['action'])
                actual_tables = {k: v for k, v in actual.items() if isinstance(v, pd.DataFrame) and not str(k).startswith('res_')}
                saved_tables = {k: v for k, v in saved.items() if isinstance(v, pd.DataFrame) and not str(k).startswith('res_')}
                assert set(actual_tables) == set(saved_tables)
                assert all(actual_tables[k].equals(saved_tables[k]) for k in actual_tables), (item['root'], bus, q)
                assert saved.converged and len(saved.res_bus) == 118
                assert np.isfinite(saved.res_bus[['vm_pu', 'va_degree', 'p_mw', 'q_mvar']].to_numpy()).all()
                after = runner.rescue.grid_metrics(saved)
                assert after == old['verification']['after'] and old['verification']['converged'] is True
                record.update(status='BOUND_EXACT_EXISTING_NATIVE_ROOT_QUERY',
                    source_event_identity=old['identity'], source_action=old['action'],
                    original_verification=old['verification'], receipt=anchor,
                    saved_payload=str((cap / 'trusted_local_net.pkl').relative_to(R)),
                    all_actuated_physical_input_tables_exact=True, all118_saved_fields_finite=True,
                    current_before_metrics_exact=True, native_after_metrics_exact=True,
                    strict_0_95_1_05_normal_band_restored=after['uv_count'] == after['ov_count'] == 0,
                    normal_upper_tolerance_admissible=after['vmax'] <= 1.05 + 1e-8,
                    prior_native_query_cost_remains_paid=True, independent_new_physics_replay_performed=False)
                rows.append(record); count += 1
        root_summary.append({'root': item['root'], 'declared_actions': 72, 'bound_saved_native_queries': count,
                             'unknown_queries': 72 - count, 'initial_UV': before['uv_count'], 'initial_OV_strict': before['ov_count']})
    assert len(rows) == 144 and not calls
    write('All144_Declared_Native_Query_Bindings.json', rows)
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS_ALL_LEGAL_FIRST_ZONE_IDENTITIES_INDEXED_WITH_UNKNOWN_PRESERVED',
        'all_declared_actions': len(rows), 'bound_exact_existing_receipts': sum(x['status'] == 'BOUND_EXACT_EXISTING_NATIVE_ROOT_QUERY' for x in rows),
        'root_summary': root_summary, 'new_physics_or_model_calls': len(calls),
        'new_model_outputs_read': False, 'original_model_OR_DSE_episode_performance': 'NOT_ASSESSED',
        'scoped_existing_physical_evidence_not_a_new_continuous_independent_replay': True,
        'elapsed_seconds': time.perf_counter() - started}
    write('Result.json', result)
    write('Closed_Manifest.json', {'members': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in O.iterdir() if p.is_file()}})
    print(json.dumps(result))


if __name__ == '__main__': main()
