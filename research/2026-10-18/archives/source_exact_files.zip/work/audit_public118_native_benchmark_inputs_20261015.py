"""Independent raw numeric matrix/identity/angle/objective preservation reader."""
import hashlib,json,os,re,time
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];B=R/'outputs/public118_native_benchmark_input_closure_20261015';O=B/'independent_audit'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    O.mkdir(exist_ok=False);start=time.perf_counter();prepared=json.loads((B/'Native_Benchmark_Input_Readiness.json').read_text());rows=[]
    for rec in prepared['all3']:
        source=R/rec['case'];stored=R/rec['full_native_ppc_path'];assert sha(source)==rec['raw_sha256'] and sha(stored)==rec['full_native_ppc_sha256']
        text='\n'.join(s.partition('%')[0] for s in source.read_text('utf-8-sig').splitlines());expected={}
        for key in ('bus','gen','branch','gencost'):
            body=re.search(r'\bmpc\.'+key+r'\s*=\s*\[(.*?)\]\s*;',text,re.S).group(1)
            expected[key]=np.array([[float(token) for token in row.split()] for row in body.split(';') if row.strip()],dtype=float)
        expected['bus'][:,0]-=1;expected['gen'][:,0]-=1;expected['branch'][:,:2]-=1
        with np.load(stored,allow_pickle=False) as actual:
            for key,value in expected.items():assert np.array_equal(value,actual[key]),key
            base=float(re.search(r'\bmpc\.baseMVA\s*=\s*([^;]+);',text).group(1));assert actual['baseMVA']==base
            assert str(actual['version'])=='2' and set(actual['bus'][:,0])==set(range(118))
            branch=actual['branch'];limited=((branch[:,11]!=0)&(branch[:,11]>-360))|((branch[:,12]!=0)&(branch[:,12]<360))
            assert limited.sum()==rec['branch_angle_difference_constrained_rows']
            rows.append({'case':rec['case'],'all_native_raw_matrices_exact':True,'constraint_angle_rows':int(limited.sum()),'native_generator_bounds_voltage_flow_limits_objective_preserved':True})
    result={'status':'PASS_ALL3_INDEPENDENT_RAW_MATRIX_IDENTITY_NATIVE_CONSTRAINT_OBJECTIVE_PRESERVATION','all3':rows,
        'new_OPF_PF_model_converter_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-start,'source_sha256':sha(Path(__file__)),
        'physical_initialization_solver_success_and_model_benchmark':'NOT_MEASURED'}
    with (O/'Independent_Native_Input_Audit.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'all3_independent_native_inputs':'PASS','new_OPF_PF_model_calls':0}))
if __name__=='__main__':main()
