"""Independent saved numerical-receipt verifier; never calls a solver or plant.

Only numpy and the standard library are imported. New receipt verification does
reconstruct saved algebra/Jacobians, explicitly counted as independent work.
Physical/source/owner custody is a caller obligation, not inferred from math.
"""
from pathlib import Path
from collections import Counter
import base64
import hashlib
import io
import json
import time
import numpy as np

RECIPE = {'method': 'SLSQP', 'scipy_version': '1.16.3', 'maxiter_each_stage': 100,
          'ftol': 1e-10, 'absolute_equality_acceptance': 1e-7,
          'absolute_inequality_acceptance': 1e-10, 'use_analytic_jacobians': True,
          'retry_count': 0, 'second_stage_allowance': 1e-10}
MECHANISM_SOURCES = ['work/nonlinear13_preserved_solver_v3_20261029.py',
    'work/nonlinear13_analytic_derivatives_20261029.py',
    'work/nonlinear13_validated_kernel_v2_20261029.py',
    'work/remaining85_nonlinear_kernel_20261029.py']
CONTEXT_NAMES = ['Y', 'V_current', 'ppc_bus', 'ppc_gen', 'baseMVA', 'lookup',
                 'control', 'current_vm', 'current_q', 'control_scaling', 'control_in_service']
COST_NAMES = {'objective': 'objective_evaluations',
    'objective_gradient': 'analytic_objective_gradient_evaluations',
    'equality': 'nonlinear_equation_evaluations',
    'returned_equality': 'nonlinear_equation_evaluations',
    'inequalities': 'constraint_evaluations', 'returned_inequalities': 'constraint_evaluations',
    'equality_jacobian': 'analytic_equation_jacobian_evaluations',
    'inequality_jacobian': 'analytic_constraint_jacobian_evaluations'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def decode_array(info):
    dtype = np.dtype(info['dtype'])
    require(dtype.kind in 'biufc' and not dtype.hasobject, 'Invalid raw numeric dtype')
    shape = info['shape']
    require(isinstance(shape, list) and all(type(n) is int and n >= 0 for n in shape), 'Invalid raw shape')
    raw = base64.b64decode(info['bytes_base64'], validate=True)
    count = 1
    for n in shape:
        count *= n
    require(count * dtype.itemsize == len(raw), 'Raw numeric byte length mismatch')
    return np.frombuffer(raw, dtype=dtype).reshape(shape)


def _array_equal(a, b):
    return np.array_equal(np.asarray(a), np.asarray(b))


class SavedAlgebra:
    """Independent formulas extracted from the fixed first-reader mathematics."""
    def __init__(self, pack):
        self.p = {k: np.asarray(v).copy() for k, v in pack.items()}
        p = self.p
        require(set(CONTEXT_NAMES + ['enforce_q_lims', 'distributed_slack']) <= p.keys(), 'Incomplete input pack')
        self.Y, self.V = p['Y'], p['V_current']
        b, g = p['ppc_bus'], p['ppc_gen']
        require(self.Y.dtype == np.complex128 and self.Y.shape == (13, 13)
                and self.V.dtype == np.complex128 and self.V.shape == (13,), 'Invalid complex context')
        require(b.ndim == g.ndim == 2 and b.shape[0] == 13 and b.shape[1] >= 18 and g.shape[1] >= 8,
                'Invalid PPC context')
        require(all(np.isfinite(p[k]).all() for k in CONTEXT_NAMES), 'Nonfinite input context')
        self.lookup, self.control = p['lookup'], p['control']
        require(self.lookup.dtype.kind in 'iu' and self.control.dtype.kind in 'iu'
                and self.lookup.shape == (13,) and self.control.shape == (3,)
                and _array_equal(np.sort(self.lookup), np.arange(13))
                and _array_equal(self.control, self.lookup[[2, 7, 9]]), 'Invalid native bus maps')
        self.pq = np.flatnonzero(b[:, 1] == 1)
        ref = np.flatnonzero(b[:, 1] == 3)
        require(len(self.pq) == 12 and len(ref) == 1 and all(k in self.pq for k in self.control), 'Invalid PQ/slack roles')
        require(np.all(b[:, [13, 14, 16, 17]] == 0)
                and p['enforce_q_lims'].shape == p['distributed_slack'].shape == ()
                and not bool(p['enforce_q_lims']) and not bool(p['distributed_slack']), 'Unsupported physics flags')
        require(p['control_scaling'].shape == p['control_in_service'].shape == (3,)
                and np.all(p['control_scaling'] == 1) and np.all(p['control_in_service']), 'Inactive/scaled control')
        self.q, self.vm0 = p['current_q'], p['current_vm']
        require(self.q.shape == (3,) and self.vm0.shape == (13,) and p['baseMVA'].shape == (), 'Invalid current shapes')
        self.base = float(p['baseMVA'])
        require(self.base > 0 and _array_equal(b[:, 0], np.arange(13)), 'Invalid base or bus ordering')
        require(np.all(g[:, 0] == np.rint(g[:, 0])) and np.all((g[:, 0] >= 0) & (g[:, 0] < 13)), 'Invalid gen bus')
        self.normal = (self.vm0 >= .95) & (self.vm0 <= 1.05)
        self.injection = -(b[:, 2] + 1j*b[:, 3])
        for row in g:
            if row[7] > 0:
                self.injection[int(row[0])] += row[1] + 1j*row[2]
        self.injection /= self.base
        self.cost = {'independent_saved_algebra_evaluations': 0, 'independent_saved_jacobian_reconstructions': 0}

    def initial(self):
        x = np.zeros(31)
        x[:12], x[12:24], x[27:30] = np.angle(self.V[self.pq]), np.abs(self.V[self.pq]), np.abs(self.q)
        x[30] = max(0., .95-float(self.vm0.min()), float(self.vm0.max())-1.05)
        return x

    def voltage(self, x):
        x = np.asarray(x)
        require(x.shape == (31,) and np.isfinite(x).all(), 'Invalid saved 31-vector')
        v = self.V.copy()
        v[self.pq] = x[12:24] * np.exp(1j*x[:12])
        return v

    def calc(self, name, x, stage, t1):
        require(name in COST_NAMES and stage in (1, 2), 'Unknown saved calculation or stage')
        self.cost['independent_saved_algebra_evaluations'] += 1
        x = np.asarray(x); v = self.voltage(x); vm = np.abs(v)[self.lookup]
        if name == 'objective':
            return x[30] if stage == 1 else np.sum(x[27:30])
        if name == 'objective_gradient':
            out = np.zeros(31)
            if stage == 1: out[30] = 1
            else: out[27:30] = 1
            return out
        if name == 'inequality_jacobian':
            require(np.all(x[12:24] >= 0), 'Inequality derivative outside nonnegative domain')
            self.cost['independent_saved_jacobian_reconstructions'] += 1
            d = np.zeros((13, 31))
            for native, internal in enumerate(self.lookup):
                w = np.flatnonzero(self.pq == internal)
                if len(w): d[native, 12+int(w[0])] = 1
            a, c = -d.copy(), d.copy(); a[:, 30] = c[:, 30] = 1
            e = np.zeros((3, 31)); e[:, 24:27] = -np.eye(3); e[:, 27:30] = np.eye(3)
            f = e.copy(); f[:, 24:27] = np.eye(3)
            out = np.vstack([a, c, -d[self.normal], d[self.normal], e, f])
            if t1 is not None:
                z = np.zeros((1, 31)); z[0, 30] = -1; out = np.vstack([out, z])
            return out
        if name in ('inequalities', 'returned_inequalities'):
            out = np.r_[1.05+x[30]-vm, vm-.95+x[30], 1.05-vm[self.normal], vm[self.normal]-.95,
                        x[27:30]-self.q-x[24:27], x[27:30]+self.q+x[24:27]]
            return np.r_[out, t1+1e-10-x[30]] if t1 is not None else out
        if name == 'equality_jacobian':
            self.cost['independent_saved_jacobian_reconstructions'] += 1
            current = self.Y @ v; diagv = np.diag(v); unit = v.copy()
            unit[self.pq] = np.exp(1j*x[:12]); ref = np.setdiff1d(np.arange(13), self.pq)
            require(np.all(np.abs(v[ref]) > 0), 'Zero slack voltage')
            unit[ref] = v[ref]/np.abs(v[ref])
            da = 1j*diagv @ np.conj(np.diag(current)-self.Y @ diagv)
            dm = diagv @ np.conj(self.Y @ np.diag(unit)) + np.diag(np.conj(current)) @ np.diag(unit)
            out = np.zeros((24, 31)); ix = np.ix_(self.pq, self.pq)
            out[:12, :12], out[12:, :12] = da[ix].real, da[ix].imag
            out[:12, 12:24], out[12:, 12:24] = dm[ix].real, dm[ix].imag
            for j, k in enumerate(self.control): out[12+int(np.flatnonzero(self.pq == k)[0]), 24+j] = -1/self.base
            return out
        target = self.injection.copy(); target[self.control] += 1j*x[24:27]/self.base
        err = v*np.conj(self.Y @ v)-target
        return np.r_[err[self.pq].real, err[self.pq].imag]

    def checks(self, x, stage, t1):
        x = np.asarray(x); self.voltage(x)
        eq = self.calc('returned_equality', x, stage, t1)
        iq = self.calc('returned_inequalities', x, stage, t1)
        inside = bool(np.all(x[12:24] >= 0) and np.all(np.abs(x[24:27]) <= float(np.float32(.3))) and np.all(x[27:] >= 0))
        out = {'max_abs_equality': float(np.max(np.abs(eq))), 'min_inequality': float(np.min(iq)), 'inside_exact_bounds': inside}
        out['pass'] = inside and out['max_abs_equality'] <= 1e-7 and out['min_inequality'] >= -1e-10
        return out


def verify_saved_math(pack_arrays, journal_bytes, primary_summary, proposal_or_none, *,
                      expected_binding, expected_recipe, absolute_deadline_monotonic):
    """Verify one NEW saved transcript. Caller must pin its actual input/source context.

    Returns complete-admitted, retained-failure or retained-partial disposition.
    No disposition permits a retry; only a complete admitted receipt is reusable.
    """
    require(np.isfinite(absolute_deadline_monotonic) and time.monotonic() < absolute_deadline_monotonic, 'Invalid reader deadline')
    require(expected_recipe == RECIPE, 'Changed recipe')
    start = time.monotonic(); algebra = SavedAlgebra(pack_arrays)
    require(isinstance(journal_bytes, bytes) and (not journal_bytes or journal_bytes.endswith(b'\n'))
            and b'\r\n' not in journal_bytes, 'Journal is not complete literal-LF evidence')
    attempts, ended, raw, plain, checked, stage_t = {}, set(), {}, {}, {}, {}
    counts = Counter(); previous = '0'*64; events = []; native_pending = None
    native_ends = {}; exception_stages = set(); current = 0; previous_time = -float('inf')
    action = None; action_checks = None; action_failed = False; invalid_stage = None; worst = 0.; halted = False
    def same_checks(actual, expected):
        require(set(actual) == set(expected), 'Malformed check summary')
        require(actual['inside_exact_bounds'] is expected['inside_exact_bounds'] and actual['pass'] is expected['pass'], 'Forged feasibility flags')
        for k in ('max_abs_equality', 'min_inequality'):
            require(np.isfinite(actual[k]) and abs(actual[k]-expected[k]) <= 1e-9, 'Forged feasibility scalar')
    for line in journal_bytes.splitlines():
        require(time.monotonic() < absolute_deadline_monotonic, 'Original reader deadline exhausted')
        row = json.loads(line); e = row['event']; kind = e['kind']
        require(e['previous'] == previous and e['seq'] == len(events) and digest(canonical(e)) == row['sha256'], 'Broken journal chain')
        require(np.isfinite(e['monotonic']) and e['monotonic'] >= previous_time, 'Invalid event clock')
        previous_time = e['monotonic']; previous = row['sha256']; events.append(e); counts[kind] += 1
        require(invalid_stage is None and not halted, 'Continued after a terminal numerical result')
        if kind == 'proposal_attempt':
            require(len(events) == 1 and e['recipe'] == expected_recipe and e['source_input_binding'] == expected_binding
                    and _array_equal(e['initial_vector'], algebra.initial()), 'Wrong proposal input/initialization')
        elif kind == 'optimizer_attempt':
            stage = e['stage']; require(stage in (1, 2) and stage not in stage_t and stage == current+1, 'Repeated/out-of-order optimizer stage')
            if stage == 1:
                require(counts['proposal_attempt'] == 1 and e['first_stage_t'] is None and _array_equal(e['x'], algebra.initial()), 'Wrong first stage')
            else:
                require(1 in checked and checked[1]['success'] and checked[1]['checks']['pass']
                        and not (set(attempts)-ended) and native_pending is None, 'Stage2 after failed/incomplete stage1')
                require(e['first_stage_t'] == float(raw[1]['x'][30]) and _array_equal(e['x'], raw[1]['x']), 'Stage2 context changed')
            current = stage; stage_t[stage] = e['first_stage_t']
        elif kind == 'calculation_attempt':
            ident = e['identity']; require(type(ident) is int and ident == len(attempts) and e['stage'] == current
                and current in stage_t and e['name'] in COST_NAMES and current not in exception_stages, 'Invalid calculation identity')
            require((e['name'].startswith('returned_') and current in plain)
                    or (not e['name'].startswith('returned_') and current not in raw), 'Calculation outside its solver/check phase')
            algebra.voltage(e['x']); attempts[ident] = e
        elif kind in ('calculation_return', 'calculation_failure'):
            ident = e['identity']; require(ident in attempts and ident not in ended, 'Unpaired or duplicate calculation terminal')
            ended.add(ident); require(np.isfinite(e['elapsed_seconds']) and e['elapsed_seconds'] >= 0, 'Invalid calculation elapsed time')
            if kind == 'calculation_return':
                a = attempts[ident]; actual = np.asarray(e['result']); expected = np.asarray(algebra.calc(a['name'], a['x'], a['stage'], stage_t[a['stage']]))
                require(actual.shape == expected.shape and np.isfinite(actual).all() and np.allclose(actual, expected, rtol=0, atol=1e-9), 'Saved calculation differs: '+a['name'])
                worst = max(worst, float(np.max(np.abs(actual-expected), initial=0.)))
        elif kind == 'native_solver_call_attempt':
            require(e['stage'] == current and current in stage_t and current not in raw and native_pending is None, 'Invalid native attempt')
            native_pending = current
        elif kind == 'native_solver_call_end':
            require(native_pending == e['stage'] == current and np.isfinite(e['elapsed_seconds']) and e['elapsed_seconds'] >= 0, 'Unpaired native end')
            native_pending = None; native_ends[current] = e
        elif kind == 'major_iteration_return':
            require(e['stage'] == current and current in stage_t and current not in raw, 'Iteration outside active optimizer')
            algebra.voltage(e['x'])
        elif kind == 'optimizer_exception':
            require(e['stage'] == current and current in stage_t and current not in raw and current not in exception_stages, 'Invalid optimizer exception')
            exception_stages.add(current)
        elif kind == 'optimizer_lossless_raw_return':
            stage = e['stage']; require(stage == current and stage in stage_t and stage not in raw and stage not in exception_stages, 'Invalid/duplicate optimizer raw return')
            x, multipliers = decode_array(e['x_bytes']), decode_array(e['multipliers_bytes'])
            raw[stage] = {'event': e, 'x': x, 'multipliers': multipliers}
        elif kind == 'nonfinite_or_invalid_optimizer_return_rejected':
            require(e['stage'] == current and current in raw, 'Rejection without raw bytes')
            z = raw[current]
            require(z['x'].shape != (31,) or z['x'].dtype.kind not in 'fiu' or z['multipliers'].dtype.kind not in 'fiu'
                    or not np.isfinite(z['x']).all() or not np.isfinite(z['multipliers']).all(), 'False invalid-return rejection')
            invalid_stage = current
        elif kind == 'optimizer_raw_return':
            require(e['stage'] == current and current in raw and current not in plain, 'Invalid plain raw return')
            z = raw[current]; require(z['x'].shape == (31,) and z['x'].dtype.kind in 'fiu'
                and z['multipliers'].dtype.kind in 'fiu' and np.isfinite(z['x']).all()
                and np.isfinite(z['multipliers']).all(), 'Invalid optimizer array admitted')
            require(_array_equal(e['x'], z['x']) and _array_equal(e['multipliers'], z['multipliers']), 'Lossless/plain raw mismatch')
            for k in ('success', 'status', 'message', 'nit', 'nfev', 'njev'): require(e[k] == z['event'][k], 'Raw optimizer metadata mismatch')
            plain[current] = e
        elif kind == 'optimizer_return':
            require(e['stage'] == current and current in plain and current not in checked, 'Invalid optimizer checked return')
            for k in ('x', 'multipliers'): require(_array_equal(e[k], plain[current][k]), 'Checked/raw array mismatch')
            for k in ('success', 'status', 'message', 'nit', 'nfev', 'njev'): require(e[k] == plain[current][k], 'Checked/raw metadata mismatch')
            same_checks(e['checks'], algebra.checks(np.asarray(e['x']), current, stage_t[current])); checked[current] = e
            if not e['success'] or not e['checks']['pass']: halted = True
        elif kind == 'representable_action_attempt':
            require(counts[kind] == 1 and set(checked) == {1, 2} and all(x['success'] and x['checks']['pass'] for x in checked.values())
                    and _array_equal(e['x'], raw[2]['x']), 'Action before two admitted stages')
        elif kind == 'representable_action_return':
            require(counts['representable_action_attempt'] == 1 and action is None and not action_failed, 'Unpaired action return')
            x = raw[2]['x']; u = (-x[24:27]).astype(np.float32); q = algebra.q-u
            applied = x.astype(float).copy(); applied[24:27] = q-algebra.q; applied[27:30] = np.abs(q)
            require(np.all(np.abs(x[24:27]) <= float(np.float32(.3))) and _array_equal(e['u'], u)
                    and _array_equal(e['next_q'], q) and _array_equal(e['applied_x'], applied), 'Wrong native representability conversion')
            action = e
        elif kind == 'representable_action_failure':
            require(counts['representable_action_attempt'] == 1 and action is None and not action_failed, 'Unpaired action failure'); action_failed = True
        elif kind == 'representable_action_checks':
            require(action is not None and action_checks is None and _array_equal(e['u'], action['u']) and _array_equal(e['next_q'], action['next_q']), 'Action checks do not bind returned action')
            same_checks(e['checks'], algebra.checks(np.asarray(action['applied_x']), 2, stage_t[2])); action_checks = e; halted = True
        else:
            raise ValueError('Unknown journal event: '+kind)
    require(previous == primary_summary['journal_last_sha256'] and len(events) == primary_summary['journal_events']
            and len(journal_bytes) == primary_summary['journal_bytes'], 'Primary journal summary differs')
    upper, lower = Counter(), Counter()
    for ident, a in attempts.items():
        upper[COST_NAMES[a['name']]] += 1
        if ident in ended: lower[COST_NAMES[a['name']]] += 1
    upper['native_action_conversions'] = counts['representable_action_attempt']
    lower['native_action_conversions'] = counts['representable_action_return']+counts['representable_action_failure']
    actual_costs = primary_summary['kernel_costs']
    for k in set(upper) | set(actual_costs):
        value = actual_costs.get(k, 0)
        require(type(value) is int and lower[k] <= value <= upper[k], 'Kernel cost cannot be reconciled: '+k)
    pending = sorted(set(attempts)-ended)
    optimizer_pending = sorted(set(stage_t)-set(raw)-exception_stages)
    proposal = proposal_or_none
    admitted = False
    if proposal is not None:
        costs = proposal['costs']
        for key, value in {'optimizer_attempts': len(stage_t), 'optimizer_returns': len(raw), 'optimizer_exceptions': len(exception_stages),
            'native_slsqp_calls': counts['native_solver_call_attempt'], 'major_iteration_callbacks': counts['major_iteration_return']}.items():
            require(costs[key] == value, 'Optimizer cost mismatch: '+key)
        require(np.isfinite(costs['native_slsqp_seconds']) and abs(costs['native_slsqp_seconds']-sum(e['elapsed_seconds'] for e in events if e['kind']=='native_solver_call_end')) <= 1e-9, 'Native latency mismatch')
        for key in ('internal_QP_factorizations', 'internal_linear_solves'):
            require(isinstance(costs[key], str) and costs[key].startswith('UNKNOWN'), 'Native hidden cost falsely known')
        require(proposal['kernel_costs'] == actual_costs, 'Proposal kernel costs differ from primary')
        require(len(proposal['stages']) == len(checked), 'Proposal checked stage count differs')
        for stage in proposal['stages']:
            recorded = dict(checked[stage['stage']]); recorded.pop('seq'); recorded.pop('kind'); recorded.pop('previous'); recorded.pop('monotonic')
            require(stage == recorded, 'Proposal stage differs from journal')
        status = proposal['status']
        if status == 'ADMITTED_UNMEASURED_PROPOSAL':
            require(set(checked) == {1, 2} and action_checks is not None and action_checks['checks']['pass'] and not pending
                    and not optimizer_pending and native_pending is None and not primary_summary.get('failure'), 'Incomplete admitted proposal')
            for stage in (1, 2):
                e = checked[stage]; require(e['success'] is True and e['status'] == 0 and e['checks']['pass'], 'Failed stage admitted')
                require(stage in native_ends and native_ends[stage]['state']['mode'] == 0 and native_ends[stage]['state']['iter'] == e['nit'], 'No matching successful native terminal')
            for k in ('u', 'next_q', 'applied_x'): require(_array_equal(proposal[k], action[k]), 'Proposal action differs from journal')
            require(np.asarray(proposal['proposed_vm']).shape == (13,) and np.allclose(
                np.abs(algebra.voltage(proposal['applied_x']))[algebra.lookup], proposal['proposed_vm'], rtol=0, atol=1e-12), 'Proposed VM differs')
            require(proposal['physical_guard'] == 'NOT_EVALUATED_NO_PHYSICAL_CALL', 'Numerical receipt claims physical guard')
            admitted = True
        elif status == 'FIXED_OPTIMIZER_FAILED_NO_RETRY_NO_CANDIDATE':
            require(current in checked and (not checked[current]['success'] or not checked[current]['checks']['pass']) and action is None, 'False fixed failure')
        elif status == 'NONFINITE_OPTIMIZER_RETURN_NO_RETRY': require(invalid_stage is not None, 'Missing lossless nonfinite rejection')
        elif status == 'FLOAT32_PROPOSAL_REJECTED_NO_REPAIR': require(action_checks is not None and not action_checks['checks']['pass'], 'False float32 rejection')
        else: raise ValueError('Unknown proposal disposition')
    partial = bool(pending or optimizer_pending or native_pending is not None or (proposal is None and not exception_stages and not action_failed))
    return {'status': 'PASS_COMPLETE_SAVED_NUMERICAL_PROPOSAL' if admitted else ('PASS_RETAINED_PARTIAL_NO_RETRY' if partial else 'PASS_RETAINED_FAILURE_NO_RETRY'),
        'eligible_for_numeric_reuse': admitted, 'retry_permitted': False, 'physical_validation': False,
        'journal_sha256': digest(journal_bytes), 'journal_last_sha256': previous,
        'calculation_returns_verified': counts['calculation_return'], 'optimizer_returns_preserved': len(raw),
        'max_algebra_difference': worst, 'independent_costs': algebra.cost,
        'event_counts': dict(counts), 'kernel_confirmed_lower': dict(lower), 'kernel_entered_upper': dict(upper),
        'unpaired_calculation_attempts': pending, 'unpaired_optimizer_stages': optimizer_pending,
        'unpaired_native_stage': native_pending, 'native_hidden_costs': 'UNKNOWN_NOT_FREE',
        'workflow_seconds': time.monotonic()-start, 'new_optimizer_PF_model_calls': 0}


def _typed_value(value):
    kind = value['type']
    if kind == 'array':
        return decode_array({'dtype': value['dtype'], 'shape': value['shape'], 'bytes_base64': value['bytes']})
    if kind == 'numpy_scalar': return _typed_value(value['value'])[()]
    if kind in ('float', 'int', 'bool'): return {'float': float, 'int': int, 'bool': bool}[kind](value['value'])
    raise ValueError('Unsupported context scalar representation')


def verify_receipt(root, receipt_ref, *, expected_context_key, expected_sources,
                   absolute_deadline_monotonic, max_bytes=128*1024*1024):
    """Content-bound production wrapper. Owner must supply independently pinned keys.

    source_input_binding.proposal_identity_payload is the exact engine payload:
    state -> typed kernel values, initial_vector -> typed array, recipe, sources.
    The payload preserves scalar-vs-array identity lost in plain NPZ storage.
    """
    root = Path(root).resolve(); used = 0
    require(np.isfinite(absolute_deadline_monotonic), 'Reader deadline must be finite')
    def read(ref):
        nonlocal used
        require(time.monotonic() < absolute_deadline_monotonic, 'Reader deadline exhausted')
        path = (root/ref['path']).resolve(); path.relative_to(root)
        size = path.stat().st_size
        require(type(max_bytes) is int and 0 <= used+size <= max_bytes, 'Reader byte allowance exhausted')
        data = path.read_bytes(); used += len(data)
        require(digest(data) == ref['sha256'], 'Receipt evidence hash mismatch: '+ref['path'])
        return data
    receipt_raw = read(receipt_ref); receipt = json.loads(receipt_raw)
    require(receipt['schema'] == 'NONLINEAR13_MATH_RECEIPT_V1' and receipt['context_key'] == expected_context_key
            and receipt['sources'] == expected_sources, 'Wrong receipt context/source scope')
    require(set(MECHANISM_SOURCES) <= expected_sources.keys(), 'Incomplete mechanism source pin')
    for path, expected in expected_sources.items(): read({'path': path, 'sha256': expected})
    with np.load(io.BytesIO(read(receipt['input_pack'])), allow_pickle=False) as archive:
        pack = {name: archive[name].copy() for name in archive.files}
    binding = receipt['source_input_binding']; payload = binding['proposal_identity_payload']
    claim = json.loads(read(receipt['attempt_claim'])); owner = json.loads(read(receipt['owner_protocol_ref']))
    require(claim['schema'] == receipt['schema'] and claim['context_key'] == expected_context_key
            and binding['context_key'] == expected_context_key and binding['all_required_current_state_checks_passed'] is True,
            'Attempt/binding context differs')
    require(claim['owner_protocol_ref'] == binding['owner_protocol_ref'] == receipt['owner_protocol_ref']
            and claim['input_cursor'] == binding['complete_preproposal_cursor_ref'], 'Owner/cursor reference substitution')
    require(claim['status'] == 'RESERVED_BEFORE_ANY_NEW_NUMERICAL_CALL'
            and type(claim['actual_pid']) is int and type(claim['parent_pid']) is int
            and claim['actual_pid'] > 0 and claim['parent_pid'] > 0, 'Invalid retained attempt claim')
    require(owner['recipe'] == RECIPE and owner['sources'] == expected_sources
            and np.isfinite(owner['absolute_deadline_monotonic'])
            and binding['original_deadline_monotonic'] == owner['absolute_deadline_monotonic'], 'Owner recipe/source/deadline changed')
    read(binding['complete_preproposal_cursor_ref']); read(binding['actual_current_NET'])
    require(digest(canonical(payload)) == expected_context_key and payload['recipe'] == RECIPE
            and payload['mechanism_sources'] == {p: expected_sources[p] for p in MECHANISM_SOURCES}, 'Context identity payload mismatch')
    require(set(payload['state']) == set(CONTEXT_NAMES), 'Context state missing fields')
    for name in CONTEXT_NAMES:
        value = np.asarray(_typed_value(payload['state'][name])); stored = np.asarray(pack[name])
        require(value.dtype == stored.dtype and value.shape == stored.shape and value.tobytes() == stored.tobytes(), 'Pack differs from exact context: '+name)
    initial = np.asarray(_typed_value(payload['initial_vector']))
    require(initial.dtype == np.float64 and initial.shape == (31,)
            and _array_equal(initial, SavedAlgebra(pack).initial()), 'Context initial vector differs')
    journal = read(receipt['journal']); primary = json.loads(read(receipt['primary']))
    require(primary['context_key'] == expected_context_key and receipt['status'] == primary['status'],
            'Primary summary context/status differs from receipt')
    proposal = None if receipt['proposal'] is None else json.loads(read(receipt['proposal']))
    result = verify_saved_math(pack, journal, primary, proposal, expected_binding=binding,
        expected_recipe=RECIPE, absolute_deadline_monotonic=absolute_deadline_monotonic)
    result.update(receipt_sha256=digest(receipt_raw), context_key=expected_context_key,
        input_pack=receipt['input_pack'], source_hashes=expected_sources, evidence_bytes_read=used,
        scope='Saved numerical evidence only; actual owner/current physical state and no-repeat claim must be independently bound by the caller.')
    return result
