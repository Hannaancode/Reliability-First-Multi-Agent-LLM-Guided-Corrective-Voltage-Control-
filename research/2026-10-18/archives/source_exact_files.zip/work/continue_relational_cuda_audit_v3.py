"""Single finite handoff, waits for exact actual owner end; no science retries."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';E=P/'cuda_integration_execution_v3';OUT=P/'cuda_audit_continuation_v3'
assert not OUT.exists();OUT.mkdir();(OUT/'owner.claim').write_text(json.dumps({'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()}))
start=time.monotonic()
def save(stage,**kw):
    f=OUT/'status.tmp';f.write_text(json.dumps({'stage':stage,'updated_at_utc':datetime.now(timezone.utc).isoformat(),**kw},indent=2));f.replace(OUT/'status.json')
try:
    while time.monotonic()-start<5400:
        if not (E/'owner.claim').exists():time.sleep(5);continue
        owner=int((E/'owner.claim').read_text());cmd=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={owner}'; if ($p -and $p.CommandLine -match 'run_relational_cuda_integration_colab_v3.py') {{ 'LIVE' }} else {{ 'ENDED' }}"
        r=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True,timeout=30)
        assert r.returncode==0
        if r.stdout.strip()=='LIVE':save('waiting_exact_GPU_owner',actual_owner_pid=owner);time.sleep(10);continue
        state=json.loads((E/'status.json').read_text());assert state.get('finished_at_utc')
        assert state.get('runtime_released') and state.get('all_actual_artifacts_preserved') and state.get('remote_exit_code')==0,'Terminal partial: complete-only reader blocked'
        assert not (P/'cuda_integration_external_audit_v3').exists()
        save('running_single_closed_engineering_audit')
        with (OUT/'audit_stdout.log').open('x') as stdout,(OUT/'audit_stderr.log').open('x') as stderr:
            result=subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8','work/audit_relational_cuda_integration_v3.py'],stdout=stdout,stderr=stderr,timeout=300,creationflags=subprocess.CREATE_NO_WINDOW)
        assert result.returncode==0;save('complete_single_engineering_handoff');break
    else:raise TimeoutError('Finite owner wait elapsed, no science restart')
except BaseException as e:save('ended_partial_or_audit_failure_preserved',exception=type(e).__name__);raise
