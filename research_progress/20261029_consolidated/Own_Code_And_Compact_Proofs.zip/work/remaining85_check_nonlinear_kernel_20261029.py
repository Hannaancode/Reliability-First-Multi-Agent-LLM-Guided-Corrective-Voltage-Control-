"""ONE unsolved algebra fixture for a NEW adapter, not a KCL/PF replay audit.

AST-extract only pure makeSbus and residual functions from pinned local sources.
No pandapower import, solver, derivative or model call. This does not establish
all500 production readiness or validate an optimized controller.
"""
import ast
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.sparse import csr_matrix
from remaining85_nonlinear_kernel_20261029 import NonlinearNative13, original_guard

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/remaining85_mechanism_review_20261029'
SOURCES = {
    'makeSbus': 'work/physics_env/Lib/site-packages/pandapower/pypower/makeSbus.py',
    'residual': 'work/physics_env/Lib/site-packages/pandapower/pypower/newtonpf.py',
    'injection_sign': 'work/physics_env/Lib/site-packages/pandapower/build_bus.py',
    'native_solver': 'work/physics_env/Lib/site-packages/pandapower/pf/run_bfswpf.py',
    'old_controller': 'work/public13_matched_numeric_engine_20261021.py',
    'old_objective': 'work/native_full_grid_affine_core_20261020.py',
    'kernel': 'work/remaining85_nonlinear_kernel_20261029.py',
}


def sha(p):
    return hashlib.sha256((R / p).read_bytes()).hexdigest()


def extract(path, names, ns):
    t = ast.parse((R / path).read_text(encoding='utf-8'))
    nodes = [n for n in t.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes} == set(names)
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), path, 'exec'), ns)
    return ns


def main():
    graph = 'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz'
    model = 'outputs/public13_matched_numeric_execution_20261021/decisions/seed000_step001/Current_Model.npz'
    with np.load(R / graph, allow_pickle=False) as z:
        g = {k: z[k].copy() for k in z.files}
    with np.load(R / model, allow_pickle=False) as z:
        m = {k: z[k].copy() for k in z.files}
    assert np.array_equal(g['Y'], m['Y']) and np.array_equal(g['V'], m['V'])
    k = NonlinearNative13(g['Y'], m['V'], g['bus'], g['gen'], float(g['baseMVA']),
                          m['lookup'], m['control'], m['vm'], m['q'],
                          np.ones(3), np.ones(3, dtype=bool), False, False)
    x = k.initial_vector()
    # A fixed UNSOLVED algebra point; never a physical forecast/feasibility test.
    x[:12] += np.arange(1, 13) * 1e-4
    x[12:24] *= 1 + np.arange(1, 13) * 1e-5
    x[24:27] = [.125, -.0625, .03125]
    x[27:30] = np.abs(k.current_q + x[24:27])
    x[30] = .2
    ns = {'ones': np.ones, 'find': np.flatnonzero, 'sparse': csr_matrix,
          'PD': 2, 'QD': 3, 'GEN_BUS': 0, 'PG': 1, 'QG': 2, 'GEN_STATUS': 7,
          'CID_P': 13, 'CZD_P': 14, 'CID_Q': 16, 'CZD_Q': 17}
    extract(SOURCES['makeSbus'], ['_get_Sload', '_get_Cg', '_get_Sbus', 'makeSbus'], ns)
    extract(SOURCES['residual'], ['_evaluate_Fx'], ns)
    ns.update(conj=np.conj, r_=np.r_)
    bus = g['bus'].copy()
    bus[k.control, 3] -= x[24:27]
    expected_injection = ns['makeSbus'](k.baseMVA, bus, g['gen'])
    expected = ns['_evaluate_Fx'](csr_matrix(k.Y), k.voltage(x), expected_injection,
                                   k.ref, np.array([], dtype=int), k.pq)
    actual = k.equality(x)
    max_delta = float(np.max(np.abs(actual - expected)))
    assert np.allclose(actual, expected, atol=1e-12, rtol=0)
    assert k.objective(x, 1) == .2 and k.objective(x, 2) == .21875
    g1 = k.inequalities(x)
    g2 = k.inequalities(x, first_stage_t=.2)
    assert len(g1) == 26 + 2 * int(k.normal.sum()) + 6
    assert np.array_equal(g1, g2[:-1]) and abs(g2[-1] - 1e-10) < 1e-16
    u, next_q, applied = k.representable_native_action(x)
    assert u.dtype == np.float32 and np.array_equal(next_q, k.current_q - u)
    assert np.array_equal(applied[24:27], next_q - k.current_q)
    # Literal guard AST equivalence is a source match, not a replay of outcomes.
    old = ast.parse((R / SOURCES['old_controller']).read_text(encoding='utf-8'))
    oldguard = next(n for n in old.body if isinstance(n, ast.FunctionDef) and n.name == 'original_guard')
    new = ast.parse((R / SOURCES['kernel']).read_text(encoding='utf-8'))
    newguard = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == 'original_guard')
    oldguard.body = [n for n in oldguard.body if not isinstance(n, (ast.Import, ast.ImportFrom))]
    assert ast.dump(oldguard, include_attributes=False) == ast.dump(newguard, include_attributes=False)
    result = {
        'status': 'PASS_NEW_KERNEL_SINGLE_UNSOLVED_ALGEBRA_SOURCE_MATCH_NOT_CONTROLLER_READY',
        'source_hashes': {name: {'path': p, 'sha256': sha(p)} for name, p in SOURCES.items()},
        'fixture_input_hashes': {p: sha(p) for p in [graph, model]},
        'fixture': 'First source-order saved seed0 model arrays with fixed unsolved angle/magnitude/deltaQ algebra perturbation; no solved-state KCL repeated.',
        'source_residual_max_absolute_difference': max_delta,
        'new_kernel_costs': k.costs,
        'reference_pure_source_makeSbus_evaluations': 1,
        'reference_pure_source_residual_evaluations': 1,
        'native_sign': 'deltaQ>0 reduces PPC QD and increases reactive injection; q_next=q_current-u with u=-deltaQ.',
        'guard_AST_equivalent_to_frozen_controller': True,
        'stage1_and_stage2_objective_adapter_checks': True,
        'native_float32_action_and_cost_hooks_checked': True,
        'no_PF_derivative_LP_optimizer_model_training_GPU_calls': True,
        'important_missing_production_binding': [
            'Read actual all500 NET/PPC/options and verify sgen scaling/in_service, source bus maps, no enforce_q_lims/distributed_slack, and zero ZIP coefficients. Software fixture assumes these supported flags and does not certify them for all500.',
            'Verify current complex V/res_bus VM correspondence and constant Y/branch/shunt semantics against immutable saved fields without rerunning already completed physics audits.',
            'Independently review residual/sign/objective/float32 conversion and counter hooks; this single source match is not an independent nonlinear-method audit.',
            'Freeze solver implementation/recipe, physical validation, all500 outcomes, source/hash/runtime/state/ownership/journaling/cost limits and independent-reader protocol before any optimizer or performance call. Parent review required first.',
        ],
    }
    with (O / 'New_Kernel_Algebra_Source_Check.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
    print(json.dumps({key: result[key] for key in ['status', 'source_residual_max_absolute_difference', 'new_kernel_costs', 'no_PF_derivative_LP_optimizer_model_training_GPU_calls']}))


if __name__ == '__main__':
    main()
