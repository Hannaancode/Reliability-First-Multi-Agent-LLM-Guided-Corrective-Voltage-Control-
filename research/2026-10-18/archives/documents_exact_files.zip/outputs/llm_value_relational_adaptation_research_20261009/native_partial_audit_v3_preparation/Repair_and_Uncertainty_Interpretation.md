The v2 worker and handoff remain untouched. This additive reader is prepared for a possible resource partial, not launched alongside them.

Compiled current states must equal actual reused matrices and independent equation contexts; they need not equal239 on a timed partial.239 previously prepared current derivatives are still paid and retained. No equation, physical predicate, action score, input scope or source/cost identity check is relaxed.

If one native action was never calculated, it might displace an available top-K action. Therefore an available-output hit or miss is not a measured full-method hit or miss. A conservative inclusion interval[0,1] preserves that uncertainty. With complete execution and no lost original output, the interval is the actual binary inclusion. No recorded admissible oracle gives no ranking target, not a negative result. These are missing-evidence bounds, not statistical confidence intervals.

Only a future ended-owner/ended-handoff inspection can authorize this mechanical analysis repair. Preserve the original failed claim/audit outputs, use a new output directory and perform zero new model/PF/linear solves. Never rerun any completed scientific action or use a partial as a failed/passed learning gate.
