"""Posthoc saved-record diagnostic and reuse inventory; zero solver/model entry."""
from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/llm_value_next_method_research_20261008'
DATA = BASE / 'train_trajectory_collection_nullable_v2'
OLD = ROOT / 'outputs/llm_value_stage3_development'
OUT = BASE / 'episode_utility_and_guarded_reference_inventory'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

assert not OUT.exists(), 'Preserve completed diagnostic, no rerun'
assert read(BASE / 'train_trajectory_canonical_package/Local_Archive_Audit.json')['CRC_and_every_wrapper_and_scientific_member_hash_passed']
manifest = read(DATA / 'manifest.json')
for name, info in manifest.items():
    path = DATA / name
    assert path.stat().st_size == info['bytes'] and sha(path) == info['sha256'], name
protocol = read(DATA / 'protocol.json')
science_audit = read(BASE / 'train_trajectory_collection_nullable_v2_audit/Independent_Identity_State_Scope_Selection_Cost_Audit.json')
assert science_audit['all_closed_member_hashes_and_mechanical_gates_passed']
rescue_path = ROOT / 'work/e/audit/phase2g_rescue_runner.py'
tree = ast.parse(rescue_path.read_text(encoding='utf-8'))
score_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'score_candidate')
scope = {}
exec(compile(ast.Module(body=[score_fn], type_ignores=[]), str(rescue_path), 'exec'), scope)
score = scope['score_candidate']  # isolated exact function; no controller or imports executed
rows = []
for w in protocol['worlds']:
    pair = {b: read(DATA / 'branches' / (w['scenario_id'] + '__' + b + '.json')) for b in ('DFF', 'DFF-ALT')}
    assert all(r['status'] == 'complete_verified_measurement' for r in pair.values())
    roots = {b: r['observations'][0]['observation_sha256'] for b, r in pair.items()}
    assert len(set(roots.values())) == 1
    result = {b: r['result'] for b, r in pair.items()}
    first = {b: r['executed_actions'][0] if r['executed_actions'] else None for b, r in result.items()}
    final = {b: r['final_metrics'] for b, r in result.items()}
    all_normal = {b: all(o['input_observation']['global_metrics']['vmax'] <= 1.05 + 1e-8 for o in r['observations']) for b, r in pair.items()}
    row = {'scenario_id': w['scenario_id'], 'scenario_sha256': w['sha256'], 'family': w['family'],
           'shared_root_sha256': roots['DFF'], 'both_branches_entire_prefix_normal_upper': all(all_normal.values()),
           'normal_prefix_by_branch': all_normal, 'terminal_metrics': final,
           'both_first_actions_present': all(first.values()), 'terminal_UV_differs': final['DFF']['uv_count'] != final['DFF-ALT']['uv_count']}
    if all(first.values()):
        candidates = {b: {'action': first[b]['action'], 'verif': {'accepted': True,
                       'before': result[b]['base_metrics'], 'after': first[b]['post_metrics']}} for b in pair}
        scores = {b: score(c) for b, c in candidates.items()}
        root_normal = {b: first[b]['post_metrics']['vmax'] <= 1.05 + 1e-8 for b in pair}
        admissible = [b for b in pair if root_normal[b]]
        immediate = max(admissible, key=lambda b: scores[b]) if admissible else None
        terminal_UV_preferred = min(pair, key=lambda b: final[b]['uv_count']) if row['terminal_UV_differs'] else None
        row.update(first_actions={b: first[b]['action'] for b in pair}, exact_original_immediate_scores=scores,
                   both_first_actions_normal_upper=all(root_normal.values()),
                   immediate_band_veto_then_literal_score_choice=immediate,
                   terminal_UV_preferred_branch=terminal_UV_preferred,
                   immediate_rule_disagrees_with_lower_terminal_UV=immediate is not None and terminal_UV_preferred is not None and immediate != terminal_UV_preferred,
                   descriptive_rule_not_an_executed_policy=True)
    rows.append(row)

# Individual complete branches may be reused from a terminal partial campaign.
# This inventory checks prior per-record evidence; it does not repair unknown
# campaign totals or claim complete observation tables already existed.
prior_protocol = read(OLD / 'protocol.json')
prior_audit = read(OLD / 'partial_external_analysis_v2/Action_Scope_and_Cost_Audit.json')
assert prior_audit['source_and_case_hashes_verified']
assert prior_audit['reported_continuous_physical_replay_passed_for_all_preserved_complete_records']
prior_worlds = {w['sha256']: w for w in prior_protocol['scenarios']}
inventory = []
for w in protocol['worlds']:
    for b, arm in [('DFF', 'guarded_full_DFF'), ('DFF-ALT', 'guarded_full_DFF_ALT')]:
        path = OLD / 'staged/remote/trajectories' / (w['scenario_id'] + '__' + arm + '.json')
        item = {'scenario_id': w['scenario_id'], 'scenario_sha256': w['sha256'], 'branch': b,
                'expected_arm': arm, 'path': str(path.relative_to(ROOT)).replace('\\', '/'),
                'file_present': path.exists(), 'complete_prior_guarded_reference': False}
        if path.exists():
            x = read(path); r = x['record']; replay = x['independent_replay']; guard = r['shared_normal_upper_mediation']
            checks = {'TRAIN_scenario_exact': x['scenario_sha256'] == w['sha256'] and w['sha256'] in prior_worlds,
                      'prospective_protocol_exact': x['protocol_sha256'] == sha(OLD / 'protocol.json'),
                      'individual_status_complete': x['status'] == r['status'] == 'complete' and x['failure'] is None and r['failure'] is None,
                      'literal_full_uncapped_search': r['full_uncapped_original_search'] is True,
                      'unchanged_existing_guard': guard['upper'] == 1.05 and guard['tolerance'] == 1e-8,
                      'prior_per_bus_continuous_replay_passed': replay['passed'] is True and replay['tolerance'] == 1e-10,
                      'frozen_base_preserved': x['base_network_preserved'] and r['frozen_base_network_preserved'] and replay['base_network_preserved'],
                      'no_model_generations_in_this_branch': r['actual_costs']['generation_entries'] == 0}
            item.update(bytes=path.stat().st_size, sha256=sha(path), checks=checks,
                        complete_prior_guarded_reference=all(checks.values()),
                        prior_controller_costs=r['actual_costs'], prior_replay_costs=replay['actual_independent_replay_costs'],
                        actual_per_bus_states=len(r['actual_solved_states']),
                        original_terminal_metrics=r['original_function_result']['final_metrics'],
                        full_current_training_observation_tables_already_present=False,
                        reuse_requires_new_charged_observation_derivation_and_validation=True,
                        partial_campaign_global_costs_unknown_and_not_zeroed=True)
        inventory.append(item)

summary = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'all_160_original_member_hashes_rechecked': len(manifest) == 160,
           'fixed_TRAIN_worlds': len(rows), 'both_entire_prefixes_normal_upper_worlds': sum(r['both_branches_entire_prefix_normal_upper'] for r in rows),
           'both_entire_prefixes_normal_upper_and_different_terminal_UV': sum(r['both_branches_entire_prefix_normal_upper'] and r['terminal_UV_differs'] for r in rows),
           'both_first_actions_normal_and_different_terminal_UV': sum(r.get('both_first_actions_normal_upper', False) and r['terminal_UV_differs'] for r in rows),
           'both_entire_prefixes_normal_and_terminal_UV_disagrees_with_immediate_literal_score': sum(r['both_branches_entire_prefix_normal_upper'] and r.get('immediate_rule_disagrees_with_lower_terminal_UV', False) for r in rows),
           'prior_guarded_exact_TRAIN_branches_present': sum(r['file_present'] for r in inventory),
           'prior_complete_individually_verified_guarded_TRAIN_branches': sum(r['complete_prior_guarded_reference'] for r in inventory),
           'missing_guarded_TRAIN_branch_references': sum(not r['file_present'] for r in inventory),
           'saved_prior_partial_campaign_is_not_restarted_or_completed': True,
           'no_new_policy_performance_established': True, 'new_model_calls': 0, 'new_PF_calls': 0, 'new_controller_executions': 0,
           'source_sha256': sha(Path(__file__)), 'literal_score_source_sha256': sha(rescue_path)}
OUT.mkdir()
for name, value in [('Actual_All_TRAIN_Root_Utility_Diagnostic.json', rows), ('Prior_Guarded_Reference_Inventory.json', inventory), ('summary.json', summary)]:
    with (OUT / name).open('x', encoding='utf-8') as f: json.dump(value, f, indent=2, allow_nan=False)
with (OUT / 'manifest.json').open('x', encoding='utf-8') as f:
    json.dump({p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in OUT.glob('*.json')}, f, indent=2)
print(json.dumps(summary, indent=2))
