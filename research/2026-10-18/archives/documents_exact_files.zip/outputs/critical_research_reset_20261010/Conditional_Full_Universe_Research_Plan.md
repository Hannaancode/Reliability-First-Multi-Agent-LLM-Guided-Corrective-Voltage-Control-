# Conditional plan for genuine language contribution over D-SE

This plan specifies the next unresolved scientific question. It is not an implemented/trained method or an assertion of novelty/99%success. The human's review-first instruction remains in force. The failed two-shortlist selector stays stopped; this plan does not widen that selector after its failed gate.

## Concrete hypothesis and originality boundary

**Question:** Can a language-native policy use interpretable, current physical evidence to propose useful actions anywhere in the ORIGINAL common/zone action universe, correcting a strong numerical prior while preserving its good decisions, and outperform a comparably trained numerical corrector and a matched architecture without useful pretraining?

The representation, target and inference mechanism are different from the stopped VCSA, dense regression, relational-head and root-branch selector experiments. Original public/base/private weights are preserved; any trainable adapter is a copied research artifact. No prior trained module or favorable old checkpoint initializes the new learner.

Potential contribution, conditional on results: a causal finite-action language-policy correction method for coupled voltage recovery, with explicit numerical-prior preservation, lexicographic preference semantics, physical verification and complete attribution/cost evidence. ARM/DPO/LiPO/SPIBB and grid AC-preference adaptation already cover much of the machinery. The claim must be narrower than inventing residual alignment or physics feedback. Novelty remains a hypothesis to be checked against the final implemented method and literature; no claim follows from naming the combination.

## Stage0 — necessary mechanism and information evidence

Reuse the sealed full native union and existing measured candidate labels. Keep ALL239OPT inputs/23worlds,52unlabelled OPTstates, all31 finite historical worlds overall, retained invalid world/views and the original lost forecast. Do not choose only the46 old-K4 misses. Good prior decisions, rejected actions, zero-oracle worlds and unmeasured actions remain explicitly represented.

Before defining a new representation, inventory EXACT current state/action fields needed to explain the observed ranking discrepancies. The analysis may describe current model disagreement, Q/cap effects, scope and physical-score priorities. It must not infer unrecorded candidate voltage vectors, hidden native PF modes or delayed rewards. AFTER labels are administrative supervision only. An observational association is not proof that a component causes a ranking error.

Require a signed information contract for the full-universe policy: fields visible to the actor, fields available only to deterministic numerical tools, field units/types, missing-value behavior, administrative identities and outcome labels. Use the actual original source query/zone interface where appropriate; do not invent mature observation APIs or assume old paid-receipt binary prompts apply. The currently stopped4193–4517-token projection may not be revised through format sweeps to force a fit. A materially different design needs a physical/information justification before its single context test.

**Stop:** no genuine language-relevant mechanism; required causal fields unavailable; unsupported full-state targets; or a method whose claimed benefit is only a common guard, oracle receipts, larger budget or weaker comparator. This stage is local read-only research, not a model trial. The completed fixed-shortlist gate is negative and cannot be recast as a pass for this stage.

## Stage1 — define the policy, loss and decoder before performance

An admissible candidate formulation is a finite policy over every scope-valid native(bus,Qindex) action, with an explicit abstention/failure outcome. The native nine-Q grid,450MVAr accumulated-support cap, raw common AND zone scope, original score order and labelled1.05+1e-8 normal protection remain unchanged. Every forward uses fresh current data; world/family/branch IDs and measured AFTER/labels are excluded.

For available numerical forecasts, define a strictly positive prior pN over supported actions using a PROSPECTIVELY justified ordinal mapping of the original lexicographic score. Do not pretend UV counts, voltage deficits and MVAr are a uniquely calibrated scalar reward. Preserve ties by the original native order. Unknown/nonphysical forecasts need an explicit administrative treatment; missing outputs cannot be recreated or silently assigned a confident prior. The original lost forecast remains unknown.

A possible correction is qTheta(a|s) proportional to pN(a|s) times exp(ellTheta(a|s)-ellReference(a|s)), where the language likelihood is for the exact canonical action. At identical copied initialization qTheta=pN. This is an initialization identity and established residual-energy machinery, not learned value or physical safety. The finite denominator must be exactly implemented or an approximation must be separately bounded and reported; sampling away difficult actions is not an exact full-universe policy.

Standard DPO relative to pN cancels DeltaN from its pair margin. An absolute-composite preference objective would include DeltaN+DeltaResidual. Its reward/noise/margin interpretation and numerical-prior normalization need a derivation; the earlier algebra fixtures alone do not settle them. Keep correct-prior examples as anchors alongside erroneous ones, with world-based weights. Any reweighting must be fixed using OPT only and retain every world, not select favorable ones. A secondary preservation loss cannot substitute for actual protected performance.

Specify canonical suffix tokenization and length handling, joint action argmax/abstention, decoder scope/cap checks and label eligibility. The current finite dictionary cannot be called an implemented policy until all original actions are represented, exact scores reproduced and unavailable/invalid cases retained. Use no prompt, rank temperature, objective, Q, seed, budget or checkpoint sweep.

**Stop:** undefined finite normalization, reward-unit ambiguity hidden as confidence, label leakage, unsupported action exclusion, or no principled way to supply current evidence within the frozen context contract. No actual model call follows an incomplete mathematical or input specification.

## Stage2 — software and strong numerical falsification

Implement ONE prospectively fixed causal interface and verify exact retained-field roundtrips, original-action coverage, administrative/outcome exclusion, typed missing fields, actual tokenizer length on ALL appropriate states, gradient paths and independent action reader. Keep overflows/failures in denominators. Software fixtures are labelled synthetic; they are not model evidence.

Implement at least a same-information numerical preference corrector using identical decoded causal fields, numerical priors, data/objective/world weights and output universe. Preserve a stronger full-table/graph/physical numerical control. Both native derivative variants, current AC, all completed numerical controls and guarded deterministic search remain reported. Trainable-parameter accounting should be chosen analytically before outcomes; additionally report total/frozen parameters, precision, FLOPs, setup and full runtime. Parameter matching alone is not architecture or pretraining control.

Freeze one seed20261010, one justified optimizer/learning rate/regularizer, five epochs and final epoch5 only for a new bounded numerical pilot. Existing completed controls are REUSED, not retrained. The new objective must be materially specified before this distinct pilot; a renamed failed control is not a new experiment. A20-minute CPU resource ceiling is a planning bound, not a guarantee. Failed/partial outputs are retained with no automatic retry.

If the numerical corrector removes the relevant decision headroom, stop the LLM route on this dataset. If meaningful error remains, report the complete per-world tradeoffs and why a language capability is expected to address that error. A weak MLP or a random-order comparator cannot be used to manufacture a gap. Do not lower a strong numerical control's information, query budget or training support.

## Stage3 — genuine integration, then a fixed language development study

Only after Stages0–2 have complete signed gates, implement a fresh production loader for the actual language-policy formulation. Verify original private/base/quantized objects, exact copied keys, reference restoration, requested trainability masks after PEFT disable/restore, finite gradients and independent cold checkpoint/action reproduction. Tiny random/mocked fixtures remain software only. A two-step genuine engineering test must use the actual new longest context and actual language-output pathway before full training. No PF/controller entry is permitted inside a GPU study.

A copied original LoRA body has8798208 parameters in336F32 tensors; its parameter/gradient/two-Adam storage alone is140771328bytes. This excludes base, activations, masks, logits, runtime and transfer buffers. Old806MB/1.75GB engineering peaks used different soft-position interfaces and do not certify a new full textual context. Measure the real peak, memory restoration and timing.

Cache only actual frozen-reference results with exact context/model/source identity; charge their forwards, tokens and transfers. Record every returned/missing model forward, backward, per-parameter optimizer participation, epoch, raw action/logit score and exact final-model reload. Full optimizer/RNG/cursor checkpoints, journal-prefix proofs and locally verified small transfers must occur at most100steps apart. Preservation ACKs precede further science. A weight-only checkpoint is not an AdamW resume. Runtime loss permits only same-assignment GET preservation, not a hidden rerun or substitute account.

Before performance, bind all state identities, eligibility, learning objective, one seed, fixed budget and final epoch5 into an immutable manifest. The precise number of reference/training/evaluation/reload forwards must be derived from the actual implemented loader and eligibility map, not borrowed from prior studies. All original public/private weights remain frozen and hash-checked.

Minimum comparisons: strong physical prior(s); same-information numerical preference learner; stronger full-table control; no-body-update/reference policy; and an architecture/pretraining control. To separate generic base pretraining from the original domain adapter, a prospective factorial comparison should distinguish pretrained/random base and copied-current/zero adapter initialization where feasible. Those random-model implementations and memory/quantization gates are currently unimplemented. No positive language-pretraining claim is allowed before they actually exist and pass.

For a historical development screen, retain the existing23OPT/eight held-world partition and all missing/invalid cases. The held worlds are already inspected DEVELOPMENT, not confirmation. Primary K4 policy improvement must exceed BOTH the strongest applicable numerical control and the reference by at least5percentagepoints equal-world, improve at least2 measured worlds against each, not increase known-rejected fraction and introduce no new missing/nonfinite actions. Report ALL K1/4/8, scopes, unmeasured/unknowns and costs. A positive screen would justify a fresh physical protocol; it is not D-SE superiority. Failure stops this intervention without minor retunes.

## Stage4 — fresh matched physical development

Freeze a new outcome-independent development world list and source/parent/root identities. Existing nominal1.25/1.50 scenarios must not be mistaken for the locked1.3/1.45 bank. New cases are separately labelled derived research cases; they do not regenerate any missing original assets. Root failures/healthy roots remain in the declared denominator; no success-driven replacement sampling.

Execute literal ORIGINAL DFF and DFF-ALT to their original full settings, then the unchanged choose_safety_envelope. Charge BOTH branches, even when only one is selected. Report branches individually. Also retain an additional common-guard deterministic portfolio and the strongest numerical policy so that normal-band filtering alone cannot become an LLM contribution. Do not cap or weaken the original primary comparator.

Each learned and numerical policy gets the prospectively matched candidate-verification interface and all actual costs. Native forecasts are approximations with nonlinear convergence unknown. Every attempted action requires original physical verification and common normal-band/protection handling. Fresh inference is required at every visited current state; cached training actions are not deployed inference. State/action/source/case hashes bind all observations and queries.

Independently replay every committed trajectory with all per-bus fields/continuous voltages at1e-10, scope/cap/score/native/current-band metrics and missing outcomes. Report protected terminal UV clearance, path-wise upper protection, failures, residual UV/deficit, iterations and full costs. If the original frozen slack/active-power limits remain violated, state that voltage success does not imply full operational feasibility.

The learned policy must improve physical outcomes over literal D-SE AND strong numerical controls, with genuine language/pretraining attribution. A lower query budget, a common guard, a better scalar loss or software success cannot satisfy this gate. If improved quality requires more runtime/compute, report a quality-cost tradeoff; do not call it unqualified computational superiority.

## Stage5 — genuinely unused99%-confidence confirmation

Only after the method and development decision are frozen, generate/obtain a SEPARATE unused authorized confirmation collection with a prospectively fixed distribution, seed, family weights and exact source. Protect it from training, prompt selection, normalization, model selection and exploratory inspection. Every original/learned/numerical policy runs on the exact same root world. A world is the independent sampling unit; states/actions within a trajectory are correlated.

Predeclare protected-world success as the primary binary metric. Use a paired comparison and family-aware reporting under the declared sampling law. Specify the inferential test and simultaneous error budget before looking at confirmation. A conservative four-primary-comparison allocation alpha=.01/4 is a possible design; more comparisons or safety/cost claims require a correspondingly revised complete multiplicity plan BEFORE data. Report effect sizes and99%intervals, not justpvalues. Do not stop when significance first appears.

Choose a fixed sample size from independently justified DEVELOPMENT effect assumptions and a complete power calculation, including the required effect floor, safety and cost gates. The included hypothetical analysis demonstrates how much this may demand; it does not supply effect assumptions. With zero IID unsafe worlds,459 independent worlds are needed for a one-sided99%upper risk bound below1%. It is not a guarantee of zero risk. The currently inspected23/31 worlds are ineligible for this confirmation calculation.

All failures, missing results, invalid actions, unexecuted identities and unsafe outcomes remain in policy denominators. Confirmation failure ends the claim, not a new seed/checkpoint/sample-size sweep. A meaningful result requires exact model/source/physics/cost/manifest evidence. Only then consider the full FDIA campaign and manuscript superiority claims.

## Resources and schedule

| Work | Resource | Present evidence or prospective limit |
|---|---|---|
| Critical review and fixed-pool/statistical necessary analysis | CPU/local files/web | Completed read-only analysis; no model/PF/scientific forecast. |
| Information contract, software, numerical corrector | CPU | Conditional; new20-minute numerical pilot ceiling only after prospective source/data gates. Not currently ready. |
| New language integration | One actual eligible T4 | Conditional bounded engineering, exact payload/identity and one allocation. No current job or resource entitlement assumed. |
| Development/pretraining attribution | One or two independently owned T4s | Conditional. Separate accounts do not pool VRAM. Actual loader timing determines the full forward/optimizer estimate; old25–100minute workflows are references, not a new ETA. |
| Native numerical prior at fresh states | CPU | Existing33736 forecasts took102.83minutes including seal; wrapper-only6.24minutes is not deployment latency. Full information preparation and audit costs must be included. |
| Literal D-SE physical confirmation | CPU plus policy T4 inference | Eight historical portfolios averaged2471.5controllerPF/world;44742new guarded searches took50.36minutes for58branches. These are different workloads, not a universal solver rate. Hundreds of new worlds and multiple policies can require days, not a guaranteed overnight run. |

For scale,459worlds at the eight-case portfolio average would be about1.13million original D-SE PF attempts before learned/numerical/replay costs. This extrapolation is conditional on unlike historical cases and is NOT an actual cost/ETA. Local CPU parallelism may improve throughput only after memory/ownership profiling. CLI profiles expose no reliable remaining free-T4-hours/reset/lifetime estimate; no purchases, account fallback after denial or quota rotation are permitted.

Token use is controlled by one consolidated review, bounded source reading, compact live status only when meaningful, no repeated archive hashing, and one prospectively chosen study at a time. Do not spend GPU time on another head before necessary information/attribution gates. Current experiments remain held under the direct review-first instruction; the99%-winning premise is not established.

## Execution disposition

The fixed two-prior shortlist candidate has FAILED its necessary gate and is stopped. Stages0–1 of a materially different full-universe language method remain research, with information, derivation and novelty unresolved. Stages2–5 are conditional work orders, not mature runners or current experiments. Do not start them from this document alone. The whole superiority goal remains ACTIVE/unachieved; this plan does not narrow it to a convenient saved-label result.
