"""Build exact allowlisted participant payloads; explicitly not launch authorization."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,zipfile
R=Path(__file__).resolve().parents[1];O=R/'outputs/public_qa_execution_preparation_20261029'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def encode(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def put(p,v):p.write_bytes(json.dumps(v,indent=2,ensure_ascii=False).encode()+b'\n')
def main():
    assert not O.exists();O.mkdir()
    sources=['public_qa_inference_worker_v2_20261029.py','public_qa_transfer_20261029.py','public_qa_remote_supervisor_20261029.py',
        'public_qa_remote_setup_20261029.py','run_public_qa_colab_20261029.py','audit_public_qa_scientific_20261029.py',
        'audit_public_qa_worker_20261029.py','coordinate_public_qa_20261029.py','coordinate_native_inverter_linear_reference_20261020.py']
    hashes={}
    for name in sources:
        b=(R/'work'/name).read_bytes();ast.parse(b.decode('utf-8'));hashes['work/'+name]=sha(b)
    software=read(R/'outputs/public_qa_supervision_20261029/software_v2/Result.json')
    host=read(R/'outputs/public_qa_supervision_20261029/host_lifecycle/Result.json')
    for name,h in software['source_sha256'].items():assert sha((R/'work'/name).read_bytes())==h
    assert host['host_sha256']==hashes['work/run_public_qa_colab_20261029.py']
    token=read(R/'outputs/public_qa_scale_design_20261029/token_bounds_v2/Result.json')
    profiles=read(R/'outputs/colab_readonly_snapshot_20261029/Result.json')['profiles']
    mappings=[('size05','original','gcloud'),('size15','ahammedsheen','gcloud-hiergrid-ahammedsheen'),('size3','sheenahammed','gcloud-hiergrid-sheenah')]
    arms=[]
    for model,(arm,profile,credential) in zip(token['models'],mappings):
        folder=O/arm;folder.mkdir();pack=read(R/model['local_pack'])
        assert sha((R/model['local_pack']).read_bytes())==model['pack_sha256']
        assert len(pack['questions'])==150
        assert all(set(q)=={'question_id','rendered_prefix','input_ids','input_tokens'} for q in pack['questions'])
        assignment={'model':model['model'],'revision':model['revision'],'records':150,'seed':20261029,
            'transformers_version':'5.5.0','setup_seconds':1800,'science_seconds':5400,'process_seconds':7800,
            'call_seconds':300,'ack_seconds':180,'preservation_bytes':128*1024*1024,
            'role':'public_native_no_tool_QA','profile':profile,'question_ids':[q['question_id'] for q in pack['questions']]}
        put(folder/'Assignment.json',assignment)
        allowed={name:(R/'work'/name).read_bytes() for name in sources[:4]}
        allowed['dependency_constraints.txt']=(R/'work/frozen_dependency_closure.txt').read_bytes()
        allowed['assignment.json']=encode(assignment);allowed['pack.json']=encode(pack)
        assert set(allowed)==set(sources[:4])|{'dependency_constraints.txt','assignment.json','pack.json'}
        manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in allowed.items()}
        archive=folder/'Participant_Payload_LOCAL_ONLY.zip'
        with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
            for n,b in allowed.items():z.writestr(n,b)
            z.writestr('Manifest.json',encode(manifest))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and set(z.namelist())==set(manifest)|{'Manifest.json'}
            for n,m in manifest.items():assert sha(z.read(n))==m['sha256']
        put(folder/'Payload_Admission.json',{'member_manifest':manifest,'archive_sha256':sha(archive.read_bytes()),
            'participant_only':True,'administrator_labels_reference_solutions_credentials_private_adapters_in_payload':False})
        arms.append({'id':arm,'profile':profile,'credential_directory':credential,
            'account_sha256':next(x['account_sha256'] for x in profiles if x['profile']==profile),
            'assignment':str((folder/'Assignment.json').relative_to(R)).replace('\\','/'),
            'pack':model['local_pack'],'tokenizer_directory':'outputs/public_qa_scale_design_20261029/'+model['model'].split('/')[-1]+'/tokenizer_only',
            'payload':str(archive.relative_to(R)).replace('\\','/'),'payload_sha256':sha(archive.read_bytes()),
            'execution':'outputs/public_qa_execution_20261029/'+arm})
    draft={'at_utc':datetime.now(timezone.utc).isoformat(),'launch_ready':False,'status':'PREPARED_PENDING_FINAL_SOURCE_AND_PARTIAL_READER_GATES',
        'arms':arms,'source_hashes':hashes,'worker_sha256':hashes['work/public_qa_inference_worker_v2_20261029.py'],
        'host_process_seconds':11000,'reader_seconds':600,'coordination':'outputs/public_qa_coordination_20261029',
        'independent_audit':'outputs/public_qa_independent_20261029',
        'primary':'Fixed all150 source-order native-parser exact answers; unavailable responses retained as unknown with full-denominator bounds.',
        'secondary':'Strict single uppercase letter validity/accuracy; latency, generated tokens, memory and all costs.',
        'inference':'Single greedy attempt, max256 newtokens, FP16 eager, no retrieval/tools/privateadapter/training. Identical current information.',
        'engineering':'Two synthetic max256-output generations, warm and true reload, exact output check before test entry; all costs charged.',
        'controls_and_limits':['Three fixed model sizes/public revisions and preassigned own profiles; no denial-driven fallback.',
            'One publicly released circuit with150 dependent questions; no new generalization or voltage-superiority claim.',
            'Original RAG had retrieval; this baseline does not replicate its whole system or serve the private voltage adapter.',
            'No test labels are sent to inference. Reader labels are used only after all fixed primaries terminate.',
            'No outcome-selected prompt, model, decoding, seed, bound or subset changes.'],
        'remaining_before_launch':['Review and test complete/partial/no-entry scientific reader paths, including hard-kill journal tails and exact native scoring.',
            'Close coordinator actual reader ownership and timeout preservation; prove all source hashes after repairs.',
            'Verify actual engineering synthetic prefix plus256 fits4096 and input snapshot weight/tokenizer pins.',
            'Add real Linux child-watchdog exercise during bounded setup before model entry; retain all actual package versions.',
            'Source/input/payload closure and fresh exact local process/profile ownership; then freeze a separate final protocol.']}
    put(O/'Prepared_Protocol.json',draft)
    print(json.dumps({'status':draft['status'],'participant_payloads':3,'actual_model_GPU_PF_calls':0}))
if __name__=='__main__':main()
