"""Data-only, hash-bound public13 loader. No PF/equation/optimizer/model calls.

pandapowerNet is decoded to a dict shim matching its saved ADict state shape;
the pandapower package is never imported. Only certified local evidence is read.
The caller freezes source hashes and supplies the all500 original root manifest.
"""
import hashlib
import io
import pickle
import sys
from pathlib import Path
import numpy as np

from remaining85_nonlinear_kernel_20261029 import NonlinearNative13


class SavedNetwork(dict):
    def __setstate__(self, state):
        if not isinstance(state, tuple) or len(state) != 2 or not isinstance(state[0], dict) or not isinstance(state[1], bool):
            raise ValueError('Unsupported saved ADict state; no inferred repair')
        mapping, allow_invalid_attributes = state
        self.update(mapping)
        self.saved_allow_invalid_attributes = allow_invalid_attributes


class DataUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) == ('pandapower.auxiliary', 'pandapowerNet'):
            return SavedNetwork
        allowed = ('numpy', 'pandas', 'scipy.sparse')
        if module in ('builtins', 'collections', 'datetime', 'copyreg') or any(module == p or module.startswith(p + '.') for p in allowed):
            return super().find_class(module, name)
        raise pickle.UnpicklingError(f'Unsupported serialized global: {module}.{name}')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_bytes(root, relative, expected_hash):
    p = (Path(root) / relative).resolve()
    p.relative_to(Path(root).resolve())
    raw = p.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_hash:
        raise ValueError(f'Input hash mismatch: {relative}')
    return raw


def physical_signature(net):
    import pandas as pd
    h = hashlib.sha256()
    for name in ['bus', 'line', 'trafo', 'sgen', 'gen', 'load', 'ext_grid', 'shunt', 'switch']:
        h.update(name.encode())
        h.update(pd.util.hash_pandas_object(net[name], index=True).to_numpy().tobytes())
    return h.hexdigest()


def bind_entry(root, entry, graph):
    """Return (evidence row, certified kernel-input arrays or None).

    Failure is retained by the caller; it never selects a different root/model.
    No residual, constraint, objective, derivative or solver function is called.
    """
    row = {'seed': entry['seed'], 'status': 'UNKNOWN', 'checks': {}, 'mismatches': [],
           'exact_root': entry['exact_root'], 'saved_model': entry['saved_initial_equation_model']}
    def check(name, passed):
        passed = bool(passed)
        row['checks'][name] = passed
        if not passed:
            row['mismatches'].append(name)
        return passed
    try:
        ref = entry['exact_root']
        raw = checked_bytes(root, ref['path'], ref['sha256'])
        saved = DataUnpickler(io.BytesIO(raw)).load()
        if ref['kind'] == 'NET':
            net = saved
        elif ref['kind'] == 'ENV':
            net = saved['network']
        else:
            raise ValueError('Unrecognized root kind')
        check('saved_network_data_only', isinstance(net, SavedNetwork))
        check('physical_tables_signature', physical_signature(net) == ref['physical_signature'])
        check('saved_root_converged', net['converged'] and net['_ppc']['success'])
        pp, opt = net['_ppc'], net['_options']
        row['saved_options'] = {k: (v.item() if isinstance(v, np.generic) else v)
                                for k, v in opt.items() if isinstance(v, (str, int, float, bool, type(None), np.generic))}
        flags = {'enforce_q_lims': False, 'enforce_p_lims': False, 'distributed_slack': False,
                 'voltage_depend_loads': False, 'tdpf': False, 'consider_line_temperature': False,
                 'ac': True, 'mode': 'pf', 'algorithm': 'bfsw'}
        for name, expected in flags.items():
            check('option_' + name, name in opt and opt[name] == expected)
        bus, gen, branch = np.asarray(pp['bus']), np.asarray(pp['gen']), np.asarray(pp['branch'])
        check('ppc_bus_shape', bus.shape == (13, 18))
        check('ppc_gen_shape', gen.ndim == 2 and gen.shape[1] >= 8)
        check('finite_ppc_bus', np.isfinite(bus).all())
        check('finite_ppc_gen', np.isfinite(gen).all())
        check('baseMVA_graph_exact', pp['baseMVA'] == float(graph['baseMVA']))
        check('static_graph_branch_exact', np.array_equal(branch[:, :13], graph['branch'][:, :13]))
        check('static_graph_bus_shunt_exact', np.array_equal(bus[:, [0, 4, 5]], graph['bus'][:, [0, 4, 5]]))
        check('zero_ZIP_PQ_coefficients', np.all(bus[:, [13, 14, 16, 17]] == 0))
        check('bus_ids_zero_through12', np.array_equal(bus[:, 0], np.arange(13)))
        check('exact12PQ_oneREF_noPV', np.sum(bus[:, 1] == 1) == 12 and np.sum(bus[:, 1] == 3) == 1
              and np.all(np.isin(bus[:, 1], [1, 3])))
        check('reference_bus_is_native0', np.array_equal(np.flatnonzero(bus[:, 1] == 3), [0]))
        check('no_source_FACTS_DC_equipment', all(np.asarray(pp[k]).size == 0 for k in ['svc', 'ssc', 'vsc', 'tcsc', 'bus_dc', 'branch_dc']))
        native_bus_index = net['bus'].index.to_numpy()
        rawlookup = np.asarray(net['_pd2ppc_lookups']['bus'])
        sgen = net['sgen'].iloc[:3]
        sgen_buses = sgen['bus'].to_numpy()
        check('native_bus_index_integral', np.issubdtype(native_bus_index.dtype, np.integer))
        check('raw_lookup_integral', np.issubdtype(rawlookup.dtype, np.integer))
        check('sgen_bus_dtype_integral', np.issubdtype(sgen_buses.dtype, np.integer))
        if row['mismatches'] and not all(row['checks'][k] for k in ['native_bus_index_integral', 'raw_lookup_integral', 'sgen_bus_dtype_integral']):
            row['status'] = 'REJECTED_UNSUPPORTED_SOURCE'
            return row, None
        lookup = rawlookup[native_bus_index]
        control = rawlookup[sgen_buses]
        check('native_bus_order0through12', np.array_equal(native_bus_index, np.arange(13)))
        check('lookup_bijection0through12', lookup.shape == (13,) and np.array_equal(np.sort(lookup), np.arange(13)))
        check('native_sgen_rows0through2', np.array_equal(sgen.index.to_numpy(), np.arange(3)))
        check('native_control_buses2_7_9', np.array_equal(sgen_buses, [2, 7, 9]))
        check('controls_PQ_unique', len(np.unique(control)) == 3 and np.all(bus[control, 1] == 1))
        scaling = sgen['scaling'].to_numpy(dtype=float)
        online = sgen['in_service'].to_numpy(dtype=bool)
        check('control_scaling_exact_one', np.array_equal(scaling, np.ones(3)))
        check('controls_online_and_source_active', np.all(online) and np.all(np.asarray(net['_is_elements']['sgen'])[:3]))
        vm = net['res_bus']['vm_pu'].to_numpy(dtype=float)
        q = sgen['q_mvar'].to_numpy(dtype=float)
        check('current_vm_matches_audited_root', np.array_equal(vm, entry['initial_all13_vm']))
        check('current_q_matches_audited_root', np.array_equal(q, entry['initial_control_Q_Mvar']))
        check('current_vm_matches_PPC_order', np.array_equal(vm, bus[lookup, 7]))
        V = bus[:, 7] * np.exp(1j * np.deg2rad(bus[:, 8]))
        check('complex128_voltage_and_finite', V.dtype == np.complex128 and V.shape == (13,) and np.isfinite(V).all())
        Y = graph['Y'].copy()
        check('graph_complex128_finite_13x13', Y.dtype == np.complex128 and Y.shape == (13, 13) and np.isfinite(Y).all())
        model = entry['saved_initial_equation_model']
        if model is not None:
            mbytes = checked_bytes(root, model['path'], model['sha256'])
            with np.load(io.BytesIO(mbytes), allow_pickle=False) as z:
                for name, actual in [('Y', Y), ('V', V), ('vm', vm), ('q', q), ('lookup', lookup), ('control', control),
                                     ('pq', np.flatnonzero(bus[:, 1] == 1)), ('baseMVA', np.asarray(pp['baseMVA']))]:
                    check('saved_model_exact_' + name, np.array_equal(z[name], actual))
                check('saved_model_voltage_dtype_complex128', z['V'].dtype == np.complex128)
                check('saved_model_mapping_dtypes_integral', np.issubdtype(z['lookup'].dtype, np.integer)
                      and np.issubdtype(z['control'].dtype, np.integer))
        else:
            check('no_model_only_already_inband_root', entry['initial_state_already_in_original_band'])
        row['binding_fields'] = {'lookup': lookup.tolist(), 'control': control.tolist(),
                                 'scaling': scaling.tolist(), 'in_service': online.tolist(),
                                 'bus_dtype': str(bus.dtype), 'gen_dtype': str(gen.dtype),
                                 'V_dtype': str(V.dtype), 'Y_dtype': str(Y.dtype),
                                 'lookup_dtype': str(lookup.dtype), 'control_dtype': str(control.dtype),
                                 'gen_shape': list(gen.shape), 'res_bus_PPC_VM_exact': row['checks']['current_vm_matches_PPC_order'],
                                 'abs_complexV_vs_saved_VM_max_roundoff': float(np.max(np.abs(np.abs(V)[lookup] - vm))),
                                 'saved_internal_Ybus_empty': np.asarray(pp['internal']['Ybus']).size == 0,
                                 'saved_initial_model_available': model is not None}
        if row['mismatches']:
            row['status'] = 'REJECTED_UNSUPPORTED_SOURCE'
            return row, None
        arrays = dict(Y=Y, V_current=V, ppc_bus=bus.copy(), ppc_gen=gen.copy(), baseMVA=np.asarray(pp['baseMVA']),
                      lookup=lookup.copy(), control=control.copy(), current_vm=vm, current_q=q,
                      control_scaling=scaling, control_in_service=online,
                      enforce_q_lims=np.asarray(opt['enforce_q_lims']), distributed_slack=np.asarray(opt['distributed_slack']))
        instance = NonlinearNative13(**arrays)
        check('kernel_constructor_has_zero_evaluation_calls', not instance.costs)
        check('kernel_injection_finite', np.isfinite(instance.injection0).all())
        check('no_pandapower_or_torch_imported', 'pandapower' not in sys.modules and 'torch' not in sys.modules)
        row['status'] = 'BOUND_INPUT_ONLY' if not row['mismatches'] else 'REJECTED_UNSUPPORTED_SOURCE'
        return row, arrays if not row['mismatches'] else None
    except Exception as exc:
        row.update(status='UNKNOWN_BINDING_EXCEPTION', exception_type=type(exc).__name__, exception=str(exc))
        return row, None


def load_bound_kernel(root, pack_reference):
    """Executable hash-checked adapter loader for a subsequently frozen owner.

    This constructs context only; calling any evaluation/optimizer needs the
    still-pending prospective protocol. Input reference includes its exact hash.
    """
    raw = checked_bytes(root, pack_reference['path'], pack_reference['sha256'])
    with np.load(io.BytesIO(raw), allow_pickle=False) as z:
        arrays = {k: z[k].copy() for k in z.files}
    return NonlinearNative13(**arrays)
