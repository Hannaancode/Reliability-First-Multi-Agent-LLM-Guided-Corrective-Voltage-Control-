"""Single CPU continuation owner; waits for sealed original baseline evidence.

No account, Colab, GPU, export or security actions. It runs only the declared
18 numerical controls, then stops. Human-specific upload approvals stay pending.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time
ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
OUT = ROOT / 'outputs/llm_value_development'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    if '--check' in sys.argv:
        stage = read(ROOT / 'outputs/ordered_completion_status.json').get('stage')
        print(json.dumps({'original_supervisor_stage': stage,
                          'local_control_launch_ready': stage == 'all_ten_steps_complete',
                          'runtime_allocation': False, 'held_exports_still_held': True}))
        return
    assert not (OUT / 'CPU_Control_Manifest.json').exists(), 'No duplicate completed CPU controls'
    with (OUT / 'local_continuation.claim').open('x') as f:
        f.write(str(os.getpid()))
    files = ['run_clean_value_cpu_controls.py', 'value_baseline_gate.py',
             'value_candidate_ordering.py', 'value_pf_budget.py']
    state = {'owner_pid': os.getpid(), 'started_at_utc': datetime.now(timezone.utc).isoformat(),
             'stage': 'waiting_for_original_baseline_and_package',
             'planned_CPU_control_trials': 18, 'actual_model_calls': 0,
             'cloud_export_or_allocation_authorized_here': False,
             'protocol_sha256': sha(OUT / 'clean_value_development_protocol.json'),
             'source_sha256': {n: sha(ROOT / 'work' / n) for n in files}}
    def save():
        state['updated_at_utc'] = datetime.now(timezone.utc).isoformat()
        target = OUT / 'local_continuation_status.json'
        temporary = target.with_suffix('.tmp')
        temporary.write_text(json.dumps(state, indent=2))
        temporary.replace(target)
    save()
    print('LOCAL_CONTINUATION_OWNER_WAITING_FOR_ORIGINAL_BASELINE', os.getpid(), flush=True)
    deadline = time.monotonic() + 36 * 3600
    try:
        while time.monotonic() < deadline:
            try:
                ordered = read(ROOT / 'outputs/ordered_completion_status.json')
            except (OSError, json.JSONDecodeError):
                time.sleep(30)
                continue
            if ordered.get('stage') == 'all_ten_steps_complete' and ordered.get('all_ten_steps_complete'):
                break
            state['original_supervisor_stage'] = ordered.get('stage')
            save()
            time.sleep(30)
        else:
            state['stage'] = 'bounded_wait_ended_no_CPU_trials_started'
            save()
            return
        assert sha(OUT / 'clean_value_development_protocol.json') == state['protocol_sha256']
        for name, digest in state['source_sha256'].items():
            assert sha(ROOT / 'work' / name) == digest
        state['stage'] = 'auditing_package_then_running_18_CPU_controls'
        save()
        with (OUT / 'local_cpu_controls.log').open('a', encoding='utf-8') as log:
            result = subprocess.run([str(ROOT / 'work/physics_env/Scripts/python.exe'),
                                     str(ROOT / 'work/run_clean_value_cpu_controls.py')],
                                    stdout=log, stderr=subprocess.STDOUT, cwd=ROOT)
        assert result.returncode == 0, 'CPU control child failed; preserve partial outcomes and owned claim'
        summary = read(OUT / 'cpu_controls/summary.json')
        assert summary['actual_CPU_trials'] == 18 and summary['actual_model_calls'] == 0
        state.update(stage='18_CPU_controls_preserved_learned_inference_waits_for_specific_approval',
                     actual_CPU_control_trials=18, child_returncode=0)
        save()
        print('LOCAL_CONTINUATION_FINISHED_18_CONTROLS_LEARNED_ARMS_PENDING', flush=True)
    except Exception as exc:
        state.update(stage='local_CPU_continuation_failed_preserve_all_outputs',
                     failure_type=type(exc).__name__, failure_note=str(exc)[:250])
        save()
        raise


if __name__ == '__main__':
    main()
