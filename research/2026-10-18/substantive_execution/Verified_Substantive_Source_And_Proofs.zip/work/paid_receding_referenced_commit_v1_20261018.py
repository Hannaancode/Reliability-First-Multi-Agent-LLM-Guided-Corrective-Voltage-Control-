"""Isolated original commit ASTs with causal journal-reference checkpoints."""
import ast,hashlib
from pathlib import Path
import paid_joint_commit_v1 as original
from paid_receding_journal_reference_history_v1_20261018 import ReferencedHistory,verify_reference_history
SOURCE=Path(original.__file__)
functions=[n for n in ast.parse(SOURCE.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)]
MODE='ACTUAL_PAID_PROTECTED_JOURNAL_REFERENCED_RECEDING_V1'
env=original.__dict__.copy();env['MODE']=MODE
exec(compile(ast.Module(body=functions,type_ignores=[]),str(SOURCE),'exec'),env)
for n in functions:globals()[n.name]=env[n.name]
HISTORY_KEY='__COMPLETE_DURABLE_PAID_QUERY_HISTORY_PREFIX__'
DEPENDENCY_KEY='__COMPLETE_SCIENTIFIC_AND_NUMERICAL_DEPENDENCY_PREFIX__'
SOURCE_CERTIFICATE={'original_commit_state_save_restore_ASTs_exact':True,'original_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'only_physical_namespace_change':MODE,'added_guard':'Every referenced query must lie within the exact saved scientific prefix and protocol; full dependency verifier still required.'}

def verify_causal_references(state):
    result=verify_reference_history(state['paid_query_registry'][HISTORY_KEY])
    dep=state['paid_query_registry'][DEPENDENCY_KEY]
    for record in result['records']:
        if record['event']!='complete_paid_receding_decision':continue
        payload=record['payload']
        if payload['scientific_protocol_sha256']!=state['protocol_sha256']:raise ValueError('Foreign scientific protocol in checkpoint')
        for ref in payload['query_references']:
            if Path(ref['journal'])!=Path(dep['scientific_journal_path']):raise ValueError('Reference journal is not the saved dependency journal')
            if ref['offset']+ref['bytes']>dep['scientific_journal_bytes']:raise ValueError('Future query outside saved causal prefix')
    return result

def save_complete(path,state,anchors):
    verify_causal_references(state)
    return save(path,state,anchors)

def restore_complete(path,receipt):
    state=restore(path,receipt);checked=verify_causal_references(state)
    return state,checked['records']
