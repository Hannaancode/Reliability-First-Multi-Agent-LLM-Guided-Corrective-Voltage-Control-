"""Source-bound algebraic first-decision identity; zero physical/model calls.

This does NOT assert physical trajectory equivalence after interruptions,
different returned evidence or timing equality. No running source is changed.
"""
import ast
import hashlib
import json
import os
from datetime import datetime,timezone
from pathlib import Path
from paid_spatial_two_step_search import Receipt,two_step,value
from trusted_causal_controller_snapshot import write_bytes
from native_continuation_preservation_v2 import canonical

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/greedy_two_step_source_identity_20261012'
SOURCES=('work/paid_spatial_two_step_search.py','work/paid_spatial_receding_controller_v1.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False);pins={n:sha(ROOT/n) for n in SOURCES}
    protocol=json.loads((ROOT/'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012/preparation/Protocol.json').read_text('utf8'))
    for n,h in pins.items():assert protocol['source_sha256'][n]==h
    tree=ast.parse((ROOT/SOURCES[0]).read_text('utf8'));fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='two_step')
    assigns={n.targets[0].id:ast.unparse(n.value) for n in ast.walk(fn) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    assert assigns['ordered']=='sorted(accepted, key=lambda r: r.native_score, reverse=True)'
    assert assigns['expanded']=="ordered if mode == 'exhaustive' else ordered[:1 if mode == 'greedy' else width]"
    loop=next(n for n in fn.body if isinstance(n,ast.For));assert ast.unparse(loop.iter)=='expanded'
    append=[n for n in ast.walk(loop) if isinstance(n,ast.Call) and ast.unparse(n.func)=='leaves.append']
    assert len(append)==1 and isinstance(append[0].args[0],ast.Dict)
    fields={ast.literal_eval(k):ast.unparse(v) for k,v in zip(append[0].args[0].keys,append[0].args[0].values)}
    assert fields['first']=='r.action' and assigns['selected']=="max(leaves, key=lambda leaf: value(leaf['measured_leaf']))"
    returns=[n for n in fn.body if isinstance(n,ast.Return)];last=returns[-1]
    assert isinstance(last.value,ast.Dict) and any(k is None and ast.unparse(v)=='selected' for k,v in zip(last.value.keys,last.value.values))
    controller=ast.parse((ROOT/SOURCES[1]).read_text('utf8'));klass=next(n for n in controller.body if isinstance(n,ast.ClassDef) and n.name=='RecedingController')
    run=next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='run')
    r_assign=[n for n in ast.walk(run) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='r']
    assert len(r_assign)==1 and ast.unparse(r_assign[0].value)=="self.q.receipts.get((parent, plan['first']))"
    commits=[n for n in ast.walk(run) if isinstance(n,ast.Call) and ast.unparse(n.func)=='self.commit']
    assert len(commits)==1 and [ast.unparse(n) for n in commits[0].args]==['parent','r','action','iteration']
    assert not any(isinstance(n,ast.Subscript) and ast.unparse(n.value)=='plan' and isinstance(n.slice,ast.Constant) and n.slice.value=='second' for n in ast.walk(run))
    # One labelled symbolic witness: the lower-score first child has the
    # superior second leaf, so beam differs while greedy cannot switch first.
    metrics=lambda uv:{'uv_count':uv,'deficit_sum':uv*.01,'vmin':.94 if uv else .96,'vmax':1.0}
    rows={('root','A'):Receipt('root','A',True,True,'childA',metrics(2),(1.,)),
        ('root','B'):Receipt('root','B',True,True,'childB',metrics(2),(0.,)),
        ('childA','a'):Receipt('childA','a',True,True,'endA',metrics(1),(1.,)),
        ('childB','b'):Receipt('childB','b',True,True,'endB',metrics(0),(1.,))}
    menus={'root':('A','B'),'childA':('a',),'childB':('b',)};queries=[]
    def query(parent,action):queries.append((parent,action));return rows[parent,action]
    greedy=two_step('root',metrics(3),25,menus.__getitem__,query,mode='greedy',width=8)
    beam=two_step('root',metrics(3),25,menus.__getitem__,query,mode='fixed_beam',width=8)
    native=max([rows['root',a] for a in menus['root']],key=lambda r:r.native_score)
    assert greedy['first']==native.action=='A' and beam['first']=='B'
    proof={'status':'PASS_SOURCE_BOUND_FIRST_DECISION_IDENTITY','saved_at_utc':datetime.now(timezone.utc).isoformat(),
        'actual_reader_pid':os.getpid(),'source_sha256':pins,'new_PF_model_optimizer_calls':0,
        'algebra':['Python stable sorted(reverse=True) first element equals max under the same native_score and original menu tie order.',
            "In mode='greedy', expanded is ordered[:1]; the leaves list therefore has exactly one first action whenever accepted is nonempty.",
            'Second-stage metrics can change that sole leaf value or second suggestion, but cannot change its first identity.',
            'RecedingController commits only plan[first], ignores plan[second], and recomputes from actual current on the next iteration.'],
        'scope':'Given the SAME complete returned current/menu/native receipts, greedy_two_step and native_greedy choose the SAME first action. Null/zero-slot/UVzero terminals retain their declared conditions.',
        'complete_trajectory_identity_condition':'Only if all subsequent actual verifier/commit returns and current identities remain matched and both policies finish without resource/evidence interruption. This reader does not measure or certify those new physical returns.',
        'unknown_or_resource_failure_can_abort_extra_lookahead_before_any_proposal':True,
        'greedy_two_step_online_costs_and_actual_unexecuted_trajectories':'UNKNOWN; extra query count is not intrinsic runtime or a deployment speed certificate',
        'labelled_symbolic_witness':{'native_first':native.action,'greedy_first':greedy['first'],'beam_first':beam['first'],'software_query_callbacks':len(queries)},
        'critical_consequence':'Greedy2 cannot supply a materially different first-action mechanism at matched evidence. Retain/report it as a same-choice paid-lookahead control, not an independently promising policy. Fixed beam8/exhaustive2 remain different and unexecuted performance is UNKNOWN.',
        'no_controller_or_current_reference_source_change':True,'no_automatic_model_launch_or_LLM_superiority':True}
    write_bytes(OUT/'Source_Decision_Identity_Certificate.json',canonical(proof))
    text='''Greedy two-step is a decision-equivalent control at matched complete evidence.

The existing source sorts accepted first actions by the original score. Greedy mode expands only the first element. Its leaf list contains only that first action, even if another unexpanded child would have a much better continuation. The receding controller commits plan[first] and does not use plan[second] at the next decision. Therefore lookahead cannot change this policy's first action. This conclusion follows from the pinned source algebra, not from a small empirical sample.

The scope is precise: the same complete returned current state and native first-menu evidence. Missing descendant evidence or a resource stop may interrupt greedy2 when native greedy would still complete. No new physical trajectory, timing equivalence or universal LLM impossibility is claimed. Actual unexecuted costs remain UNKNOWN. A symbolic witness shows that fixed beam can choose a different first action while greedy2 cannot, without any PF or model call.

Retain greedy2 in the control inventory as an extra-lookahead, same-choice control. Do not mistake its future second-stage score for a better executed policy or train a language model to imitate it as a new mechanism. No required control is silently removed. Full source-bound receipt equivalence would be needed to reuse a complete native trajectory rather than rerun its physics; unobserved greedy2 lookahead costs cannot be fabricated.

The current eight-root D-SE references run unchanged. The necessary headroom audit must finish before launching any candidate. If it survives, fixed beam8 and exhaustive2 remain the distinct strong numerical mechanisms. Their complete episode costs must be measured: nominal per-decision9N versus2N is not a universal whole-episode4.5ratio because scopes, caps, accepted/terminal children, cache reuse and episode length vary. The fixed total1.5FULLBOTH allowance remains unchanged.

The protected S1 reference is paid source-equivalent reuse. Its engineering/setup/failure/replay costs are retained, but exact single-owner online DFF latency is UNKNOWN. The existing opportunity gate requires valid complete cost provenance for every arm; a caller must not fill this field with a guessed solver average or cached replay time. Literal D-SE both-branch timing will be freshly measured. Necessary headroom can be decided independently of a timing claim; survival does not mean the full opportunity/economic gate passed.
'''
    write_bytes(OUT/'Critical_Control_And_Cost_Implications.md',text.encode('utf8'))
    event={'event_id':'greedy_two_step_source_decision_identity_20261012',
        'method':'Exact pinned AST/source algebra for greedy_two_step expansion and first-only actual commitment, with one labelled symbolic beam counterexample; no new model/physics.',
        'result':'PASS: at the same complete current/native-menu evidence greedy2 selects exactly the immediate original-score winner. Lookahead cannot change its first action; beam8 can. Actual interrupted trajectories and online costs remainUNKNOWN.',
        'improvements':'Before: greedy2 could be mistaken for another policy-improvement mechanism needing a full expensive campaign. After: its exact decision role is proved; preserve it as a same-choice cost/control and reserve distinct-policy work for beam/exhaustive mechanisms if the fixed headroom gate survives.',
        'limitations':'Conditional first-decision identity is not a new physical trajectory/cost/generalization certificate, universal impossibility theorem or LLM advantage. Unknown descendant evidence may stop greedy2. Full S1 protected one-owner timing remainsUNKNOWN and cannot be imputed for the fixed cost gate.',
        'decision':'Keep current reference sources/settings unchanged. Do not train an LM to imitate greedy2 as a materially new mechanism, drop required controls silently, claim cheaper deployment or automatically launch a candidate. Await independently complete headroom; then use fixed strong controls and honest full-cost provenance.',
        'sources':[OUT.relative_to(ROOT).as_posix()+'/Source_Decision_Identity_Certificate.json',OUT.relative_to(ROOT).as_posix()+'/Critical_Control_And_Cost_Implications.md',*SOURCES]}
    write_bytes(OUT/'Progress_Event.json',canonical(event))
    print(json.dumps({'decision_identity':'PASS','symbolic_callbacks':len(queries),'new_science':0,'progress_entry':str(OUT/'Progress_Event.json')}))


if __name__=='__main__':main()
