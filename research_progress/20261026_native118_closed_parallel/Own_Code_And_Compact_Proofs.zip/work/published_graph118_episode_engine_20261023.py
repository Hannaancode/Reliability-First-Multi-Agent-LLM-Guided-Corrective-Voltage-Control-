"""Named native-actuator GraphAgent episode port; no implicit PF/model calls.

Original author policy AST is used verbatim. This transition port preserves
native actions, raw stopping, float32 observations and static episode graph.
Author reward is deliberately unreported, as in the source success comparison.
"""
import copy,hashlib,pickle,random
from pathlib import Path
import numpy as np
from published_graph118_backend_20261022 import Graph118Env,author_policy

class NativeGraphEpisode:
    def __init__(self,folder,checkpoint):
        self.folder=Path(folder);s=copy.deepcopy(checkpoint)
        self.env=Graph118Env(s['net'],self.folder)
        self.env.gen_obs_data=s['gen_obs_data'];self.env.shunt_status_arr=s['shunt_status']
        Policy,astsha=author_policy(self.folder);assert astsha==s['author_AST_sha256']
        self.agent=Policy(env=self.env,file_str='restored_episode',random=False);vars(self.agent).update(s['agent_fields'])
        self.history=list(s['action_history']);self.count=s['action_count'];self.cap=s['absolute_native_action_cap']
        self.anchors={k:s[k] for k in ['root_anchor','first_paid_receipt','author_AST_sha256','exact_env_source_sha256']}
        self.done=False;self.failed=False;self.last_action=None;self.last_decoded=None;self.pending=None
        assert self.count==len(self.history) and self.cap==2*sum(len(d) for d in self.env.controls.values())+2*self.env.num_shunts
        assert self.env.saw.calls==0
    def next_intent(self):
        assert not self.done and not self.failed and self.count<self.cap and self.pending is None
        action=int(self.agent.get_action(self.history));net,decoded=self.env.apply_only(action)
        self.pending=dict(action=action,decoded=decoded,before=net,prior_count=self.count)
        return copy.deepcopy(self.pending)
    def accept(self,intent,returned,exception=None):
        assert not self.done and intent['prior_count']==self.count
        from reflection118_chronological_core_20261022 import frames_equal
        assert self.pending is not None
        assert all(intent[k]==self.pending[k] for k in ['action','decoded','prior_count'])
        frames_equal(intent['before'],self.pending['before'])
        frames_equal(intent['before'],returned)
        self.pending=None
        self.count+=1;self.history.append(intent['action']);self.last_action=intent['action'];self.last_decoded=intent['decoded']
        self.env.net=copy.deepcopy(returned);self.env.saw.net=self.env.net
        if exception is not None:
            self.failed=True;self.done=True
            return dict(done=True,source_success=False,termination='NATIVE_PF_EXCEPTION',reward='NOT_COMPARED')
        assert self.env.net.converged
        for j,(bus,devices) in enumerate(self.env.controls.items()):
            values=[float(self.env.net[t].at[i,'vm_pu']) for t,i,_ in devices];assert all(x==values[0] for x in values)
            self.env.gen_obs_data.loc[j,'GenVoltSet']=values[0]
        self.env.shunt_status_arr=np.asarray([int(bool(self.env.net.shunt.at[i,'in_service']) and int(self.env.net.shunt.at[i,'step'])==1) for i in self.env.shunts])
        normal=bool(self.env.all_v_in_range)
        # Source env evaluates success before the experiment's no-op override.
        env_done=self.count>=self.cap or normal
        self.done=env_done or intent['action']==self.env.no_op_action
        why='NORMAL_BAND' if normal else 'ACTION_CAP' if self.count>=self.cap else 'AUTHOR_NO_OP' if self.done else 'CONTINUE'
        return dict(done=self.done,source_success=bool(env_done and normal),termination=why,reward='NOT_COMPARED')
    def snapshot(self):
        return dict(net=copy.deepcopy(self.env.net),gen_obs_data=self.env.gen_obs_data.copy(),shunt_status=self.env.shunt_status_arr.copy(),
            agent_fields={k:copy.deepcopy(v) for k,v in vars(self.agent).items() if k!='env'},action_history=list(self.history),action_count=self.count,absolute_native_action_cap=self.cap,
            done=self.done,failed=self.failed,last_action=self.last_action,last_decoded=self.last_decoded,pending=copy.deepcopy(self.pending),python_rng=random.getstate(),numpy_rng=np.random.get_state(),**self.anchors)
    @classmethod
    def restore(cls,folder,state):
        obj=cls(folder,state);obj.done=state.get('done',False);obj.failed=state.get('failed',False);obj.last_action=state.get('last_action');obj.last_decoded=state.get('last_decoded');obj.pending=copy.deepcopy(state.get('pending'))
        if 'python_rng' in state:random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
        return obj
