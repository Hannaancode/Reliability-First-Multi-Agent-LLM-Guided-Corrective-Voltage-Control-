"""ALL4 originally declared conditional followups; no policy/trajectory claim.

The separate hash-ordered engineering action is retained in its own archive;
it was never in this original menu and is not substituted for a menu action.
"""
import json
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from fixed_three_query_core_20261019 import B,PHASES
from equal_operation_benchmark_v2 import process

def main():
    assert read(B/'Completion.json')['exit_codes']=={**{p:0 for p in PHASES},'audit':0}
    audit=read(B/'audit/Independent_Audit.json');assert audit['status']=='PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
    for phase in PHASES:
        claim=read(B/phase/'owner.claim');assert process(claim['actual_pid']) is None and process(claim['actual_parent_pid']) is None
    out=B/'fixed_k4_summary';out.mkdir(exist_ok=False)
    prep=read(R/'outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json')
    first=R/'outputs/exact_two_paid_query_engineering_20261018';assert read(first/'audit_source_claim_v2/Independent_Audit.json')['status'].startswith('PASS_COMPLETE_FIXED_TWO_')
    candidates=[{'root':first,'phase':'warm'}]+[{'root':B,'phase':p} for p in PHASES];rows=[]
    for rank,(ref,declared) in enumerate(zip(candidates,prep['all4_original_order']),1):
        path=ref['root']/ref['phase']/'Result.json';msg=read(path)['receipt']['message'];record=msg['record']
        assert msg['row']==declared['row'] and prep['point']+'|'+msg['aid']==declared['point_action_key']
        rows.append({'fixed_rank':rank,'row':msg['row'],'key':declared['point_action_key'],'verdict':record['verdict'],'original_score':record['original_score'],
            'attributed_primary_PF_calls':record['attributed_PF_calls'],'attributed_primary_solver_seconds':record['attributed_solver_seconds'],
            'result_reference':str(path.relative_to(R)),'result_sha256':sha(path),'new_commit':False})
    accepted=[v for v in rows if v['verdict']['accepted']]
    best=max(accepted,key=lambda v:tuple(v['original_score'])) if accepted else None
    result={'status':'COMPLETE_ALL4_PRE_EXISTING_CONDITIONAL_MENU_RECEIPTS_NOT_WHOLE_POLICY','point':prep['point'],'current_UV':17,
        'all4_fixed_outcomes':rows,'accepted_queries':len(accepted),'conditional_source_score_best':best,
        'safe_query_best_UV':best['verdict']['after']['uv_count'] if best else None,
        'aggregate_paid_primary_PF':sum(v['attributed_primary_PF_calls'] for v in rows),'aggregate_paid_primary_solver_seconds':sum(v['attributed_primary_solver_seconds'] for v in rows),
        'charged_replays':'ALL4 primaries have one independent replay retained in their respective studies; cost is separate and not waived.',
        'no_actual_commit':True,'whole_decision_selection':'NOT_COMPUTED_FROM_ONE_CONDITIONAL_MENU','whole_policy_DSE_LLM_superiority':'NOT_TESTED',
        'non_menu_engineering_action':'Prior cold25MVAr bus0to44 query retained separately, rejected. Not used to replace an original menu member.',
        'new_scientific_calls':0}
    put(out/'All4_Results.json',result)
    lines=['# Original fixedK4 followups — complete saved measurements','',
        '|Rank|Receiver|Donor|MVAr|After UV|After Vmmax|Protected result|','|---:|---:|---:|---:|---:|---:|---|']
    for v in rows:
        row=v['row'];a=v['verdict'].get('after');lines.append(f"|{v['fixed_rank']}|{row['receiver']}|{row['donor_bus']}|{row['q']}|{a['uv_count'] if a else 'UNKNOWN'}|{a['vmax'] if a else 'UNKNOWN'}|{v['verdict']['reason']}|")
    lines+=['','This is a conditional query menu at an observed17UV hypothetical branch. No action was committed and no complete decision or trajectory is certified. All original menu members and costs are retained.']
    (out/'Results.md').write_text('\n'.join(lines)+'\n','utf-8');manifest(out)
    print(json.dumps({'originalK4':'COMPLETE','accepted_queries':len(accepted),'safe_query_best_UV':result['safe_query_best_UV'],'new_science':0}))
if __name__=='__main__':main()
