"""First source-order receipt matching the first saved state; no outcome filter."""
import copy,gzip,hashlib,json,time
from pathlib import Path
from full_receding_paid_campaign_20261015 import R,read,put
from paid_receding_commit_and_history_v1 import restore
from compile_lookahead_paid_input_cache_20261014 import point_key
from frozen_physics_loader import load_stack
import certify_archived_receipt_on_use_v1_20261018 as module
B=R/'outputs/archived_receipt_on_use_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'SOURCE_ORDER_REAL_CAUSAL_RECEIPT_CERTIFICATION_BOUNDARY_SOFTWARE','source_sha256':sha(Path(module.__file__)),'test_sha256':sha(Path(__file__)),
        'selection':'First saved checkpoint, first source-order primary receipt at its exact point; no result or reward selection.',
        'bound_seconds':180,'new_science':0,'not_full_old_policy_or_future_launch_authorization':True})
    base=R/'outputs/primary_input_reference_index_20261018';report=read(base/'Results.json');assert report['status'].startswith('PASS_ALL37656_')
    raw=(base/'All_Primary_Input_References.json.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==report['index_sha256'];index=json.loads(gzip.decompress(raw))
    request=read(R/'outputs/full_receding_paid_campaign_20261015/actual/Result.json')['checkpoint_requests'][0]
    state=restore(R/request['checkpoint'],request['receipt']);point=point_key(state['net'],state['cursor'])
    entry=next(v for k,v in index.items() if k.startswith(point+'|'));row=entry['intent']['context']['candidate']
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    ack=module.certify(state['net'],state['cursor'],row,entry,runner=runner,zones=zones,ack_path=B/'Actual_Receipt_ACK.json')
    assert ack['new_model_PF_derivative_forecast_factor_solve_calls']==0
    checks={'real_causal_saved_verifier_receipt_and_fsynced_ACK':True}
    bad=copy.deepcopy(row);bad['q']+=1
    try:module.certify(state['net'],state['cursor'],bad,entry,runner=runner,zones=zones,ack_path=B/'NEVER_WRITTEN.json')
    except AssertionError:checks['wrong_action_rejected_before_verifier']=True
    else:raise AssertionError('Foreign action accepted')
    bad=copy.deepcopy(entry);bad['intent_reference']['sha256']='0'*64
    try:module.certify(state['net'],state['cursor'],row,bad,runner=runner,zones=zones,ack_path=B/'NEVER_WRITTEN.json')
    except AssertionError:checks['changed_input_reference_rejected_before_verifier']=True
    else:raise AssertionError('Foreign source accepted')
    assert not (B/'NEVER_WRITTEN.json').exists() and time.perf_counter()-started<180
    put(B/'Results.json',{'status':'PASS_ONE_ACTUAL_CAUSAL_RECEIPT_NATIVE_VERIFIER_AND_BOUNDARIES','checks':checks,
        'new_model_PF_optimizer_derivative_forecast_factor_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'One source-ordered software/integration receipt; no policy-performance sample, full receipt cache certificate, new physics owner or future missing-identity execution permission. Future every reused receipt requires the same exact keyed independent ACK.'})
    print(json.dumps({'on_use_receipt_certificate':'PASS','actual_receipts':1,'checks':len(checks),'science':0}))
if __name__=='__main__':main()
