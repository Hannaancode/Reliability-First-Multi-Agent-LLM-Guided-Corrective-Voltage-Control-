"""Conditional descriptive numerical cost analysis; no new scientific calls."""
import hashlib,json,os,time
from pathlib import Path
from durable_opaque_evidence_store_v1 import local_root,process_alive

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
PREP=BASE/'numeric_prefix_cost_preparation'
OUT=BASE/'numeric_prefix_cost_analysis'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()
def put(p,d):
    with local_root(p).open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def best(rows):
    rows=[r for r in rows if r['verif']['accepted']]
    return max(rows,key=lambda r:(tuple(r['original_score']),-r['universe_index'])) if rows else None
def describe(r):
    if r is None:return None
    return {'universe_index':r['universe_index'],'kind':r['kind'],'receiver':r['receiver'],'donor_bus':r['donor_bus'],
        'q':r['q'],'metrics':r['verif']['after'],'original_score':r['original_score']}

def main():
    begun=time.perf_counter();p=read(PREP/'Protocol.json')
    assert p['analysis_source_sha256']==sha(Path(__file__))
    end=read(BASE/'Owner_End_ACK.json');co=read(BASE/'coordinator.claim');rd=read(BASE/'audit/owner.claim')
    for pid in (end['actual_pid'],end['launcher_pid'],co['actual_pid'],rd['actual_pid']):assert not process_alive(pid)
    done=read(BASE/'Coordinator_Completion.json');rend=read(BASE/'Reader_End_ACK.json')
    assert end['returncode']==done['science_exit']==done['reader_exit']==rend['exit_code']==0
    assert not process_alive(rend['launcher_pid'])
    audit=read(BASE/'audit/Independent_Audit.json');assert audit['status']=='PASS_INDEPENDENT_FULL_DECLARED_ONE_MOVE_PHYSICAL_AUDIT'
    assert end['closed_manifest_sha256']==sha(BASE/'actual/Closed_Manifest.json')
    local_root(OUT).mkdir(exist_ok=False)
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    science=read(BASE/'preparation/Protocol.json');ph=sha(BASE/'preparation/Protocol.json');prev='0'*64;records=[];PF={}
    with local_root(BASE/'actual/scientific.jsonl').open('rb') as f:
        for b in f:
            r=json.loads(b);assert r['previous_sha256']==prev and r['protocol_sha256']==ph;prev=hashlib.sha256(b.rstrip(b'\n')).hexdigest()
            if r['event']=='candidate_closed':records.append(r['data'])
            elif r['event'] in ('PF_return','PF_exception'):PF[r['data']['id']]=r['data']['seconds']
    assert len(records)==sum(science['declared_universe_counts'])
    summaries=[]
    for entry in science['current_endpoints']:
        world=[r for r in records if r['world']==entry['world']]
        assert [r['universe_index'] for r in world]==[r['universe_index'] for r in sorted(world,key=lambda r:(tuple(-x for x in r['ordering_forecast']['score']),r['universe_index']))]
        oracle=best(world);ordinary=best([r for r in world if r['kind']=='ordinary'])
        blocks=[]
        for k in p['fixed_all_reported_query_prefix_lengths']:
            prefix=world[:k];chosen=best(prefix)
            rec=[r['measured_receipt'] for r in prefix if r['measured_receipt'] is not None]
            blocks.append({'declared_K':k,'actual_available_prefix_length':len(prefix),'best_known_safe_action':describe(chosen),
                'same_original_score_as_complete_expanded_oracle':chosen is not None and oracle is not None and chosen['original_score']==oracle['original_score'],
                'same_UV_as_complete_expanded_oracle':chosen is not None and oracle is not None and chosen['verif']['after']['uv_count']==oracle['verif']['after']['uv_count'],
                'actual_query_PF_attempts':len(rec),'actual_query_PF_exceptions':sum(r['outcome'].startswith('EXCEPTION') for r in rec),
                'actual_query_PF_seconds_only':sum(PF[r['PF_id']] for r in rec),
                'cap_refusals_without_PF':sum(r['measured_receipt'] is None for r in prefix),
                'hypothetical_fresh_deployment_query_wall_seconds':'UNKNOWN; recorded PF timing excludes all verifier/preparation/IO/model costs'})
        if oracle is None:first_score=first_uv=None
        else:
            first_score=next(i+1 for i,r in enumerate(world) if r['verif']['accepted'] and r['original_score']==oracle['original_score'])
            first_uv=next(i+1 for i,r in enumerate(world) if r['verif']['accepted'] and r['verif']['after']['uv_count']==oracle['verif']['after']['uv_count'])
        summaries.append({'world':entry['world'],'complete_expanded_oracle':describe(oracle),'complete_ordinary_oracle':describe(ordinary),
            'first_ordered_query_matching_full_original_score':first_score,'first_ordered_query_matching_full_UV':first_uv,'all_fixed_K':blocks,
            'oracle_stopping_is_not_an_online_legal_rule':True})
    report={'status':'COMPLETE_DESCRIPTIVE_PAID_NUMERIC_ORDERING_AND_COST_ANALYSIS','original_fixed_physical_gate_unchanged':audit['fixed_gate_decision'],
        'all_fixed_query_budgets_retained_no_selected_budget_or_threshold':True,'world_results':summaries,
        'old_scientific_costs_remain_paid_separate':audit['actual_science_costs'],
        'analysis_new_PF_model_optimizer_forecast_derivative_factor_solve_calls':0,
        'model_economic_allowance':'NOT_ESTABLISHED; no actual new model inference cost or fresh hybrid policy performance. Saved receipts are not free online evidence.',
        'scope':'Inspected development one-move rankings. Descriptive all-K support, no budget tuning, hindsight stopping, full-policy win, LLM benefit, novelty or confirmation.',
        'reader_seconds_before_output':time.perf_counter()-begun}
    put(OUT/'Results.json',report);put(OUT/'Closed_Manifest.json',{'Results.json':sha(OUT/'Results.json'),'owner.claim':sha(OUT/'owner.claim')})
    print(json.dumps({'status':report['status'],'new_science_calls':0,'worlds':len(summaries)}))
if __name__=='__main__':main()
