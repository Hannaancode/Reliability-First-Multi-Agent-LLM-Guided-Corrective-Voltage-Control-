"""Final numerical/cost closure and preservation of the new bounded screen."""
import hashlib,json,os,subprocess,sys,time,zipfile
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/bounded_paid_lookahead_physics_20261014'
OUT=B/'verified_handoff'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def update(p,v):
    temp=p.with_name(p.name+'.lookahead_update.tmp')
    with temp.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(temp,p)
def main():
    command="Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'python' -and $_.CommandLine -match '(bounded_paid_lookahead.*20261014.py|run_bounded_paid_lookahead_pipeline_20261014.py|lookahead_paid_input_cache)' } | Select-Object ProcessId | ConvertTo-Json -Compress"
    assert not subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,check=True).stdout.strip()
    result=read(B/'actual/Result.json');audit=read(B/'audit_cached_receipts_v2/Independent_Bounded_Paid_Lookahead_Audit.json')
    assert result['exit_code']==0 and audit['status'].startswith('PASS_ALL8_') and audit['fixed_opportunity_gate']==result['fixed_opportunity_gate']=='PASS'
    OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat();events=[];prefix='0'*64
    with (B/'actual/scientific.jsonl').open('rb') as f:
        for line in f:
            event=json.loads(line);assert event['previous_sha256']==prefix
            prefix=hashlib.sha256(line.rstrip(b'\n')).hexdigest();events.append(event)
    counters=result['numerical_costs']
    for name,key in [('public_derivative_attempt','public_derivative_attempts'),('public_derivative_return','public_derivative_returns'),
                     ('LU_factor_attempt','LU_factor_attempts'),('LU_factor_return','LU_factor_returns'),
                     ('LU_solve_attempt','LU_solve_attempts'),('LU_solve_return','LU_solve_returns'),('exact_context_reused','exact_context_reuses')]:
        observed=[e for e in events if e['event']=='numeric_'+name]
        assert len(observed)==counters[key],key
    rhs=sum(e['data']['RHS'] for e in events if e['event']=='numeric_LU_solve_return')
    assert rhs==counters['RHS_columns']==1534
    forecast_events=[e for e in events if e['event']=='second_causal_context_and_forecasts']
    assert sum(len(e['data']['rows']) for e in forecast_events)==counters['new_forecasts']==30842
    assert len(forecast_events)==20 and counters['public_derivative_returns']==13 and counters['exact_context_reuses']==7
    for world in read(B/'Protocol.json')['all_four_worlds']:
        branches=[r for r in result['all8_branches'] if r['world']==world]
        assert len(branches)==2 and all(r['attributed_costs']['second_query_count']==16 for r in branches)
    claim=read(B/'audit_cached_receipts_v2/owner.claim')
    put(B/'Cached_Receipt_Reader_End_ACK.json',{'at_utc':now,'exit_code':0,'actual_pid':claim['actual_pid'],
        'actual_parent_pid':claim['actual_parent_pid'],'exact_source_actor_ended':True,'original_failed_reader_and_completion_preserved':True})
    closure={'at_utc':now,'status':'PASS_COMPLETE_BOUNDED_SCREEN_SOURCE_PHYSICS_REPLAY_COST_AND_FROZEN_EVIDENCE',
        'fixed_opportunity_gate':'PASS','strict_UV_wins':2,'UV_losses':0,'all8_branches':result['all8_branches'],
        'actual_new_costs':result['actual_new_costs'],'actual_new_numerical_costs':counters,
        'science_workflow_seconds_before_manifest':result['science_workflow_seconds_before_manifest'],
        'independent_reader_workflow_seconds':audit['reader_workflow_seconds'],
        'logical_query_receipts_checked':audit['query_receipts_checked'],'selected_path_replay_steps':16,
        'numerical_attempt_return_RHS_and_all_forecast_counter_closure':'PASS_SOURCE_BOUND_JOURNAL_ARITHMETIC',
        'nine_original_frozen_checks':read(B/'audit_cached_receipts_v2/Fresh_Audit_Frozen_Checks.json'),
        'owned_scientific_or_reader_jobs':[],'new_LLM_calls_actual_commits_optimizer_steps':0,
        'scope':'All4 inspected residual endpoints from actual old trained-LoRA prefixes, at most4 device operations and16followup queries per method. Matched acquisition comparison, not full originalDSE, zeroUV all cases, actual LLM gain, hardware switchability or novelty.',
        'old_source_failures_and_unknowns':'Original readerv1exit1/source/claim/stderr preserved. Separate cached-receipt analysisrepair inverseexact with all old predicates/gate retained,0newscience. Old suffix/domain/role failures/partial/UNKNOWN stay unchanged.',
        'future_gate':'A separately prospectively frozen full nonlinear receding-policy campaign and genuine original-model causal/economic integration are now justified for preparation, not automatically launched. Same actors/controls/rights/resources/fullcosts/continuousreplay/unusedconfirmation remain necessary.',
        'main_goal':'ACTIVE_UNACHIEVED'}
    assert closure['nine_original_frozen_checks']['all_passed']
    put(OUT/'Verified_Bounded_Lookahead_Checkpoint.json',closure)
    text='''# Verified bounded nonlinear lookahead result

The fixed conditional opportunity gate PASSED: two strict UV wins, two ties, zero UV losses across all four fixed development roots. Every selected path was rebuilt with charged nonlinear PF at both transitions; all118 Vm/angle/P/Q fields matched within1e-10 and every intermediate state met the common upper band. No original study or executed query was restarted.

| Root | Immediate-first1x16 UV | Breadth4x4 UV | Immediate/breadth operations |
|---|---:|---:|---:|
| line35 MG1 |6|6|4/4|
| line36 MG1 |16|16|4/4|
| line84 MG2 |21|16|4/3|
| line127 MG3 |7|5|4/4|

Both methods paid for the same full source-compatible root menu and received a16-query follow-up allowance. Broader search shares that allowance among four first children; the control spends it on the best immediate child. Cached receipts carry original physical costs; they are not free information. Different actual operation counts and all deficit/min/max/cost results remain in the branch files.

Actual new science:68 unique query PF calls plus16 declared path-replay PF calls =84attempts/84returns/0exceptions;13 new derivatives/13 LU factors/13 solves/1534RHS,7 exact paid-context reuses,30842 new ordering forecasts. Science workflow78.238291s before manifest, PF subtotal7.685985s, numerical compilation subtotal2.212017s; independent complete reader60.778784s. Source/field/resource/cost checks and nine original frozen checks pass. Actual root-prefix model/training/preparation/old-physics/data costs and their UNKNOWNs remain separate and payable.

The original reader failed because it mistook an already measured new-study receipt reused later for another first measurement. Its claim/source/fullstderr and terminalexit1 remain preserved. After every original actor ended, an additive reader checked each unique measurement once and required identical measured receipt/cost/verdict/score/reference on reuse. No physics/inference/equation/threshold/world/budget changes or scientific retries occurred. Numerical counters were additionally closed against the source-bound journal.

This is a numerical planning-component gain downstream of old trained-LoRA prefixes. No new LLM inference ran, no complete25-operation episode was executed, and neither whole originalDSE nor incremental LLM superiority has been demonstrated. Line36 and every broader severe case remain unresolved. Paired research shunt moves are nominal-Q endpoint transitions; intermediate hardware switching rights/transients remain unvalidated.

Next: implement a separately fixed complete receding controller with persistent current cursor/stock/lifetime/queries/source/fullcosts/absolute bound and cold restoration before performance; retain the equally capable immediate-first numerical control and originalDFF/DFFALT/unchangedDSE with FULLBOTH costs. Integrate the unchanged actual trainedLOCAL model only with real loader/context/latency/economic/source/paid-receipt support gates and identical numerical information/actions/query budgets. Broader known severe/UNKNOWN federation coverage and published-data tests stay required, not replaced by these four inspected roots. Task5 attribution/unusedconfirmation and Task6 security remain later, unachieved requirements.
'''
    with (OUT/'Results_And_Next_Execution.md').open('x',encoding='utf-8') as f:f.write(text);f.flush();os.fsync(f.fileno())
    # Archive this new closed screen once; do not rehash old multi-GB archives.
    begun=time.perf_counter();members={};archive=OUT/'Bounded_Nonlinear_Lookahead_Evidence.zip'
    paths={p for p in B.rglob('*') if p.is_file() and not p.is_relative_to(OUT)}
    paths.update([OUT/'Verified_Bounded_Lookahead_Checkpoint.json',OUT/'Results_And_Next_Execution.md'])
    code=['operation_aware_paid_lookahead_v1.py','project_paid_joint_successor_v1.py','check_operation_aware_lookahead_20261014.py',
        'compile_lookahead_paid_input_cache_20261014.py','audit_lookahead_paid_input_cache_20261014.py','audit_lookahead_paid_input_cache_trace_v2_20261014.py',
        'prepare_paid_input_reader_trace_repair_v2_20261014.py','bounded_paid_lookahead_physics_20261014.py',
        'audit_bounded_paid_lookahead_physics_20261014.py','audit_bounded_paid_lookahead_cached_receipts_v2_20261014.py',
        'prepare_bounded_cached_receipt_reader_v2_20261014.py','run_bounded_paid_lookahead_pipeline_20261014.py']
    paths.update(R/'work'/name for name in code)
    cachebase=R/'outputs/operation_aware_lookahead_input_cache_20261014'
    paths.update(p for p in cachebase.rglob('*') if p.is_file())
    paths.add(R/'outputs/operation_aware_lookahead_software_20261014/Software_And_Paid_Input_Readiness.json')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True) as z:
        for path in sorted(paths):
            assert time.perf_counter()-begun<300
            name=str(path.relative_to(R)).replace('\\','/');digest=hashlib.sha256();size=0
            with path.open('rb') as source,z.open(name,'w',force_zip64=True) as target:
                while chunk:=source.read(1024*1024):target.write(chunk);digest.update(chunk);size+=len(chunk)
            members[name]={'bytes':size,'sha256':digest.hexdigest()}
    with archive.open('rb+') as f:os.fsync(f.fileno())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        for name,expected in members.items():
            digest=hashlib.sha256();size=0
            with z.open(name) as f:
                while chunk:=f.read(1024*1024):digest.update(chunk);size+=len(chunk)
            assert digest.hexdigest()==expected['sha256'] and size==expected['bytes']
    put(OUT/'Local_Archive_Audit.json',{'status':'PASS_CRC_EVERY_NEW_MEMBER_HASH','archive':str(archive.relative_to(R)),
        'bytes':archive.stat().st_size,'sha256':sha(archive),'members':members,'archive_and_verify_seconds':time.perf_counter()-begun,
        'old_archives_not_rehashed':True})
    entry={'event_id':'bounded_nonlinear_lookahead_all4_verified_opportunity_pass_20261014',
        'method':'Prospectively fixed operation-aware paid nonlinear lookahead: breadth4x4 versus immediate-first1x16, full identical paid root menus, same16-followup allowance and at most4deviceops. All4 source-owned residual endpoints and charged per-transition replay retained.',
        'result':'Independent all8branch source/physics/menu/resource/cost/field auditPASS; fixed gatePASS,2UVwins2ties0losses. UV6vs6,16vs16,21to16 with4to3ops,7to5 with4vs4ops.84newPF84returns0exceptions (68query+16replay),13derivatives13LU13solves1534RHS/7reuses/30842forecasts. No newLLM/optimizer/actualwholeepisode commits.',
        'improvements':'Measured conditional nonlinear planning gains on2/4 roots with equal follow-up allowances; one uses fewer operations.34software/current-stock checks and22653 paid receipt source/cost closures prevent duplicate science and invented successor states.',
        'limitations':'Not all-case zeroUV, fullDSE superiority, LLM attribution, deployment cost/hardware feasibility or novelty. Old trained-model prefixes and costs reused, originalStage3/global/privatebase UNKNOWNs preserved. Initial/mild/federation/public test sets distinct. Original failed reader retained;0science additive analysisrepair corrected reuse accounting without changing outcomes/gates.',
        'decision':'Prepare complete receding nonlinear controller and real originalLOCAL LLM loader/context/economic/support integration under separate prospective fullcost/source/cold/ownership/reader bounds. No automatic GPU/rollout or threshold/world/budget retune. Retain all6 human priorities and full originalDSE BOTH branches/costs, strongsame-info controls and unusedconfirmation.',
        'sources':[str((OUT/'Verified_Bounded_Lookahead_Checkpoint.json').relative_to(R)),str((OUT/'Results_And_Next_Execution.md').relative_to(R)),
            str((OUT/'Local_Archive_Audit.json').relative_to(R)),str((B/'audit_cached_receipts_v2/Independent_Bounded_Paid_Lookahead_Audit.json').relative_to(R)),
            str((B/'Cached_Receipt_Reader_Repair_Certificate.json').relative_to(R))]}
    put(OUT/'Progress_Event.json',entry)
    subprocess.run([sys.executable,str(R/'work/append_research_progress.py'),'--entry-json',str(OUT/'Progress_Event.json')],check=True)
    next_tasks=['Task1: Implement full operation-aware receding nonlinear search with exact persistent paid cursor/registry/stock/lifetime/source/cost/deadline and cold restoration; source-lock one prospective scientist and independent reader before physical outcomes. Original25 bound stays, no old owner/budget extension.',
        'Integrate original trained LOCAL recipient/Q role through current implemented source-bound broker with genuine loader/token/context/finite cold memory/latency/economic gates, supported decision target and equal numerical rights/information/query budgets. Do not claim global planner is language output or automatically allocate GPU from numericPASS.',
        'Broader severe federation coverage remains all141 indexed with73 missing old-log outcomes; four inspected roots are development. Fresh wholeDFF/DFFALT/DSE matched trajectories/fullBOTH costs and protected/control variants plus strong same-information numerical control are necessary.',
        'Tasks2to4: Frozen public physical initialization/serving, native-versus-adapted published-method reproductions, separately justified matched higherSLMs. Old stopped scaled/interface studies remain stopped.',
        'Task5actualLLM attribution/architecture-pretraining/unusedconfirmation and Task6security remain unachieved.']
    header=f'''BOUNDED NONLINEAR LOOKAHEAD ALL4 OPPORTUNITY PASS {now}

Read outputs/bounded_paid_lookahead_physics_20261014/verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json and Results_And_Next_Execution.md. All scientist/coordinator/original+additive readers ended; no owned jobs. Independent all8source/physics/menu/cost/replay/9frozen PASS. Fixed gatePASS2UVwins2ties0losses:6/6,16/16,21to16 with4to3ops,7to5 with4vs4ops. Same16followup allowance/max4ops, full paidrootinformation/costs shared.84newPF84returns0exceptions/68query16replay;13dS13LU13solves1534RHS/7reuses/30842forecasts.0newLLM/optimizer/actualwholeepisode commits. New{len(members)}member archive CRC/everyhashPASS, reusecertificate without rehash. Originalreader failed on treating cachednewreceipt as another physicalmeasurement; source/claim/stderr preserved, additive0science inverseexact cachedreceipt repair independentlypassed unchanged gate/physics/cost checks. This is conditional numeric-planning evidence after oldtrainedLoRAprefix, not fullDSE/LLM/wholeepisode/zeroall/novelty/unusedconfirmation. Next complete recedingcontroller persistentstate/cold/resource/source/owner/reader/fullcost and realoriginalLOCAL serving/economics/support, then separately prospective performance. No autoGPU/rollout/sourceedits/oldrestarts/budgetextensions/outcomeretunes. All6humanpriorities/frozenassets/failedpartialUNKNOWN/strongsameinformationcontrols/FULLBOTHcosts remain. MaingoalACTIVE/unachieved. Saveprogress/resume; quietcadence preserved.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md']:
        path=R/rel;old=path.read_text('utf-8-sig')
        with path.open('w',encoding='utf-8') as f:f.write(header+old);f.flush();os.fsync(f.fileno())
    for rel in ['outputs/critical_research_reset_20261010/Research_Resume_20261012.json','outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json']:
        path=R/rel;data=read(path);data.update({'latest_verified_at_utc':now,'latest_owned_jobs':[],
            'latest_bounded_nonlinear_lookahead_verified':str((OUT/'Verified_Bounded_Lookahead_Checkpoint.json').relative_to(R)),
            'latest_bounded_nonlinear_lookahead_next':str((OUT/'Results_And_Next_Execution.md').relative_to(R)),
            'next_tasks_in_order':next_tasks,'human_pause_active':False,'current_human_pause_active':False})
        update(path,data)
    path=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(path);tasks['at_utc']=now
    tasks['tasks'][0]['status']='BOUNDED_NONLINEAR_LOOKAHEAD_INDEPENDENT_PASS_2WINS_0LOSSES_FULL_POLICY_AND_LLM_PENDING'
    tasks['tasks'][0]['done']+=' Fixed equal16-followup nonlinear screen verified2wins2ties0losses on4roots:21to16 with fewerops,7to5 sameops. No newLLM or fullDSE episode.'
    tasks['tasks'][0]['next']=next_tasks[0]+' '+next_tasks[1];tasks['latest_verified_research']=str((OUT/'Verified_Bounded_Lookahead_Checkpoint.json').relative_to(R));update(path,tasks)
    board=R/'RESEARCH_TASKS.md';body=board.read_text('utf-8').replace('ALL30_CURRENT_GUIDANCE_DIAGNOSTIC_COMPLETE_FIXED_GATE_FAIL_NEXT_NONLINEAR_PLANNING',tasks['tasks'][0]['status'])
    body+='\nLatest positive bounded nonlinear result: outputs/bounded_paid_lookahead_physics_20261014/verified_handoff/Results_And_Next_Execution.md. Full policy and newLLM attribution remain pending.\n'
    with board.open('w',encoding='utf-8') as f:f.write(body);f.flush();os.fsync(f.fileno())
    print(json.dumps({'verified_bounded_nonlinear_pass':True,'wins':2,'losses':0,'archive_members':len(members),'main_goal_unachieved':True}))
if __name__=='__main__':main()
