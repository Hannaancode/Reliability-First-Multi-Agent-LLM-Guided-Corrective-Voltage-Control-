"""Single CPU continuation after genuine model artifacts and exact runtime release.

No allocation, model calls, repeated controls or outcome-driven reruns. Failures
and completed claims remain preserved. Windows owner liveness is checked before
the existing evaluator/analysis may start.
"""
from pathlib import Path
from datetime import datetime,timezone
import ctypes
from ctypes import wintypes
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
OUT=ROOT/'outputs/llm_value_development'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
with (OUT/'clean_analysis_continuation.claim').open('x') as claim:claim.write(str(os.getpid()))
state={'owner_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat(),
       'stage':'waiting_for_actual_model_preservation_and_release','model_calls_by_this_owner':0,
       'completed_controls_rerun':False}
def save():
    state['updated_at_utc']=datetime.now(timezone.utc).isoformat()
    temporary=OUT/'clean_analysis_continuation.tmp';temporary.write_text(json.dumps(state,indent=2));temporary.replace(OUT/'clean_analysis_continuation_status.json')

kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];kernel.GetExitCodeProcess.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
def owner_alive(pid):
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:
        if ctypes.get_last_error()==87:return False
        raise RuntimeError('Cannot verify prior owner liveness; preserve and wait for attention')
    try:
        code=wintypes.DWORD()
        assert kernel.GetExitCodeProcess(handle,ctypes.byref(code))
        return code.value==259
    finally:kernel.CloseHandle(handle)

def audit_actual_batches():
    manifest=read(OUT/'GPU_Staged_Manifest.json')
    for name,item in manifest.items():
        file=OUT/'gpu_staged'/name
        assert sha(file)==item['sha256'] and file.stat().st_size==item['bytes']
    folder=OUT/'gpu_staged/llm_value_development/gpu_proposals'
    config=read(folder/'config.json');summary=read(folder/'summary.json')
    protocol=read(OUT/'clean_value_development_protocol.json')
    assert config['driver_sha256']==sha(ROOT/'work/run_clean_value_gpu_proposals.py')
    assert config['protocol_sha256']==sha(OUT/'clean_value_development_protocol.json')
    expected={c['scenario_id']+'__'+p+'__B'+str(b) for c in protocol['initial_screen_scenarios']
              for p in ['zonal_LoRA_prefix','zonal_base_prefix'] for b in protocol['candidate_evaluation_budget_grid']}
    batches={p.stem:read(p) for p in (folder/'batches').glob('*.json')}
    assert set(batches)==expected and len(batches)==12
    assert summary['actual_batches']==12 and summary['actual_primary_proposals']==48
    totals={k:0 for k in ['llm_calls','llm_exceptions','input_tokens','output_tokens']}
    for batch in batches.values():
        assert batch['identity']==config and batch['true_network_preserved'] and batch['query_function_code_unchanged']
        case=next(c for c in protocol['initial_screen_scenarios'] if c['scenario_id']==batch['scenario_id'])
        assert batch['scenario_sha256']==case['sha256']==sha(ROOT/case['path'])
        assert len(batch['proposals'])==4 and len({x['zone'] for x in batch['proposals']})==4
        layers=batch['adapter_layers_in_intervention']
        assert layers and all(x['enabled']==(batch['policy']=='zonal_LoRA_prefix') and not x['merged_adapters'] for x in layers)
        assert 4<=batch['costs']['llm_calls']<=8 and batch['costs']['llm_exceptions']==0 and batch['costs']['pf_attempts']==0
        for key in totals:totals[key]+=batch['costs'][key]
    for key,value in totals.items():assert value==summary['actual_costs'][key]
    assert read(OUT/'gpu_staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
    assert read(OUT/'gpu_staged/remote_frozen_environment.json')==read(ROOT/'outputs/remote_frozen_environment.json')
    audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'auditor_sha256':sha(Path(__file__)),
           'actual_manifest_members_verified':len(manifest),'exact_twelve_batch_identities_verified':True,
           'actual_primary_proposals':48,'actual_generation_cost_totals':totals,
           'actual_source_case_environment_adapter_and_integrity_gates_passed':True,
           'model_calls_by_auditor':0,'scientific_outcomes_rerun':False,
           'scope':'Initial-state model proposal audit; no closed-loop, superiority or final security completion claim'}
    destination=OUT/'genuine_clean_GPU_artifact_audit.json';assert not destination.exists()
    destination.write_text(json.dumps(audit,indent=2));return audit

save()
try:
    deadline=time.monotonic()+10800
    while time.monotonic()<deadline:
        upstream=read(OUT/'gpu_execution_status.json')
        pid=int((OUT/'gpu_execution.claim').read_text())
        if upstream['runtime_released'] and upstream['actual_batches_preserved']==12 and not owner_alive(pid):break
        if upstream['stage']=='blocked_or_interrupted' and not owner_alive(pid):
            state.update(stage='upstream_stopped_preserve_actual_state',upstream_failure_type=upstream.get('failure_type'));save();sys.exit(1)
        time.sleep(20)
    else:raise RuntimeError('Bounded upstream wait expired; no experiment rerun')
    assert not (OUT/'cpu_screen.claim').exists() and not (OUT/'cpu_screen_summary.json').exists()
    state.update(stage='auditing_actual_twelve_model_batches');save()
    audit=audit_actual_batches()
    state.update(stage='running_twelve_learned_CPU_rows_reusing_eighteen_controls',actual_generation_entries_audited=audit['actual_generation_cost_totals']['llm_calls']);save()
    with (OUT/'clean_analysis_continuation_evaluator.log').open('x') as log:
        subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),'work/evaluate_clean_value_cpu.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
    assert read(OUT/'cpu_screen_summary.json')['actual_trials']==30
    state.update(stage='analyzing_complete_thirty_row_screen');save()
    with (OUT/'clean_analysis_continuation_analysis.log').open('x') as log:
        subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),'work/analyze_clean_value_screen.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
    state.update(stage='genuine_clean_value_screen_complete_pending_report',finished_at_utc=datetime.now(timezone.utc).isoformat());save()
except Exception as exc:
    state.update(stage='CPU_continuation_failed_preserve_actual_outcomes',failure_type=type(exc).__name__);save();raise
