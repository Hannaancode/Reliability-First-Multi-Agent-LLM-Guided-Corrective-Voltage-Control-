"""Independent source/identity/normalization/input boundary audit, zero PF/model."""
from pathlib import Path
import hashlib, json, math, statistics
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/vcsa_development/training_interface'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not (OUT / 'independent_audit.json').exists()
for name, info in read(OUT / 'manifest.json').items():
    assert (OUT / name).stat().st_size == info['bytes'] and sha(OUT / name) == info['sha256']
rows = read(OUT / 'rows.json')
old = ROOT / 'outputs/vcsa_development/candidate_label_pilot'
source = {o['local_observation_id']: o for p in (old / 'worlds').glob('*.json') for o in read(p)['observations']}
assert len(rows) == len(source) == 48 and {r['local_observation_id'] for r in rows} == set(source)
train = [r for r in rows if r['split'] == 'train' and r['training_eligible']]
assert len(train) == 31
normalization = read(OUT / 'normalization.json')
assert normalization['fit_train_local_observation_ids'] == sorted(r['local_observation_id'] for r in train)
features = [f for r in train for f in r['input']['raw_features']]
assert normalization['input_mean'] == [statistics.mean(c) for c in zip(*features)]
assert normalization['input_std'] == [statistics.pstdev(c) or 1.0 for c in zip(*features)]
candidate_checks = 0
for row in rows:
    original = source[row['local_observation_id']]
    assert row['scenario_id'] == original['scenario_id'] and row['split'] == original['split']
    if not row['training_eligible']:
        assert 'input' not in row and row['hard_abstention'] and not row['candidate_labels']
        continue
    inp = row['input']
    assert set(inp) == {'bus_ids', 'zone_ids', 'raw_features', 'features', 'adjacency', 'node_mask', 'allowed_bus_mask', 'messages'}
    assert [b for b, allowed in zip(inp['bus_ids'], inp['allowed_bus_mask']) if allowed] == sorted(original['scope_bus_pool'])
    prompt = json.loads(inp['messages'][1]['content'])
    assert prompt['zone_state'] == original['fresh_local_measurements'] and set(prompt) == {'zone_state', 'candidate_buses', 'Q_values_MVAr'}
    assert row['scenario_id'] not in inp['messages'][1]['content']
    for bus, raw, normalized in zip(inp['bus_ids'], inp['raw_features'], inp['features']):
        vm = original['fresh_local_measurements']['bus_voltages'][str(bus)]
        assert raw[:4] == [vm, max(0., .95-vm), max(0., vm-1.05), float(bus in original['scope_bus_pool'])]
        assert normalized == [(v-m)/d for v, m, d in zip(raw, normalization['input_mean'], normalization['input_std'])]
        assert all(math.isfinite(v) for v in normalized)
    old_labels = {(c['bus'], c['q_mvar']): c for c in original['candidate_rows']}
    assert len(row['candidate_labels']) == len(old_labels)
    for label in row['candidate_labels']:
        old_label = old_labels[(label['bus'], label['q_mvar'])]
        assert label['candidate_PF_attempts_target'] == old_label['actual_candidate_costs']['attempts']
        assert label['guard_admissibility_target'] == float(old_label['normal_guard_admissible'])
        assert label['after_metrics'] == old_label['verification'].get('after')
        candidate_checks += 1
report = {'passed': True, 'exact_views': len(rows), 'candidate_checks': candidate_checks,
          'finite_train_views': 31, 'finite_validation_views': 16, 'invalid_views_retained': 1,
          'local_only_inputs_no_outcome_fields': True, 'train_only_normalization': True,
          'pretrained_model_calls': 0, 'PF_calls': 0, 'audit_source_sha256': sha(Path(__file__))}
(OUT / 'independent_audit.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report))
