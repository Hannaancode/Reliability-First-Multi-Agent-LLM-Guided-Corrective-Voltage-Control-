"""Independent source-template/raw-data check of compact input action collisions."""
import ast
import gzip
import hashlib
import json
import os
import sys
import time
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended

R = ROOT / 'outputs/critical_research_reset_20261010'
DATA = extended(R / 'original_compact_TRAIN_current_input_support')
OUT = extended(R / 'original_compact_TRAIN_current_input_external_audit')
SNAPSHOT = extended(R / 'original_training_notebook_source_snapshot/Original_Account_Phase2A_Download.ipynb')
EXPECTED_NOTEBOOK = '338bdb60b86efab822a0027a2ca57765deb8841470969cab084945c5ec009dfc'
MEMBER = 'hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'


def number_signature(obj):
    # Separate implementation matching the declared exact-numeric canonical convention.
    if type(obj) is bool: return ['bool', obj]
    if obj is None: return ['null']
    if type(obj) in (float, int):
        n, d = obj.as_integer_ratio()
        return ['number', str(n), str(d)]
    if type(obj) is str: return ['string', obj]
    if type(obj) is list: return ['list', list(map(number_signature, obj))]
    assert type(obj) is dict
    return ['object', [[k, number_signature(obj[k])] for k in sorted(obj.keys())]]


def h(obj):
    return hashlib.sha256(json.dumps(number_signature(obj), ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def template_value(node, values):
    # A bounded f-string reader, not Python eval/exec: only literal/current data placeholders.
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.Name): return values[node.id]
    if isinstance(node, ast.Subscript): return template_value(node.value, values)[ast.literal_eval(node.slice)]
    if isinstance(node, ast.Call):
        assert isinstance(node.func, ast.Attribute) and node.func.attr == 'get'
        owner = template_value(node.func.value, values)
        assert type(owner) is dict and len(node.args) == 1 and not node.keywords
        return owner.get(ast.literal_eval(node.args[0]))
    if isinstance(node, ast.JoinedStr):
        result = []
        for part in node.values:
            if isinstance(part, ast.Constant):
                assert type(part.value) is str
                result.append(part.value)
            else:
                assert isinstance(part, ast.FormattedValue) and part.conversion == -1
                spec = '' if part.format_spec is None else template_value(part.format_spec, values)
                result.append(format(template_value(part.value, values), spec))
        return ''.join(result)
    raise AssertionError(f'Unsupported template syntax: {type(node).__name__}')


def differences(a, b, path=''):
    if type(a) is dict and type(b) is dict:
        result = []
        for key in sorted(set(a) | set(b)):
            next_path = path + '/' + key
            if key not in a or key not in b:
                result.append({'path': next_path, 'first_present': key in a, 'second_present': key in b})
            else: result.extend(differences(a[key], b[key], next_path))
        return result
    if number_signature(a) == number_signature(b): return []
    return [{'path': path, 'first': a, 'second': b}]


def run():
    assert not OUT.exists()
    OUT.mkdir(); start = time.perf_counter(); now = datetime.now(timezone.utc).isoformat()
    write(OUT / 'reader.claim', {'actual_pid': os.getpid(), 'command': sys.argv,
        'source_sha256': sha(Path(__file__)), 'at_utc': now})
    manifest = read(DATA / 'Supplement_Manifest.json')
    writer_archive = read(DATA / 'Local_Archive_Audit.json')
    for name, descriptor in manifest.items():
        path = DATA / name
        assert path.stat().st_size == descriptor['bytes'] and sha(path) == descriptor['sha256']
    zipped = DATA / 'Source_Derived_Compact_TRAIN_Support.zip'
    assert zipped.stat().st_size == writer_archive['bytes'] and sha(zipped) == writer_archive['sha256']
    with zipfile.ZipFile(zipped) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist())) == len(manifest) + 1
        assert archive.testzip() is None
        for name, descriptor in manifest.items():
            raw = archive.read(name)
            assert len(raw) == descriptor['bytes'] and hashlib.sha256(raw).hexdigest() == descriptor['sha256']
    protocol = read(DATA / 'Prospective_Source_Derived_TRAIN_Protocol.json')
    assert sha(SNAPSHOT) == EXPECTED_NOTEBOOK
    notebook = read(SNAPSHOT)
    t36 = ast.parse(''.join(notebook['cells'][36]['source']))
    maker = next(n for n in t36.body if isinstance(n, ast.FunctionDef) and n.name == 'make_ultra_compact_user')
    template_a = maker.body[0].value
    t49 = ast.parse(''.join(notebook['cells'][49]['source']).split('\n', 1)[1])
    maker_b = next(n for n in t49.body if isinstance(n, ast.FunctionDef) and n.name == 'make_messages')
    template_b = next(n.value for n in maker_b.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'user' for t in n.targets))
    system = ast.literal_eval(next(n.value for n in maker_b.body if isinstance(n, ast.Assign)
                                  and any(isinstance(t, ast.Name) and t.id == 'system' for t in n.targets)))
    summary_fn = next(n for n in t49.body if isinstance(n, ast.FunctionDef) and n.name == 'build_state_summary')
    assert ast.unparse(summary_fn.body[0].test) == "zstate['n_undervoltage'] > 0"
    assert ast.unparse(summary_fn.body[1].test) == "zstate['n_overvoltage'] > 0"
    summary_templates = [summary_fn.body[0].body[0].value.elts[0],
                         summary_fn.body[1].body[0].value.elts[0], summary_fn.body[2].value.elts[0]]
    with zipfile.ZipFile(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2b_training_inputs.zip') as archive:
        raw = archive.read(MEMBER)
    assert hashlib.sha256(raw).hexdigest() == protocol['TRAIN_member_sha256']
    rows = [json.loads(x) for x in raw.decode('utf8').splitlines()]
    with gzip.open(DATA / 'All16000_Source_Derived_Compact_Identities.jsonl.gz', 'rt', encoding='utf8') as f:
        identities = [json.loads(x) for x in f]
    assert len(rows) == len(identities) == 16000
    groups = {'teacher_derived_compact': defaultdict(Counter), 'measurement_derived_compact': defaultdict(Counter)}
    by_label = {name: defaultdict(dict) for name in groups}
    world_groups = set(); scalar_matches = Counter(); compared = Counter()
    for i, row in enumerate(rows):
        assert time.perf_counter() - start < 120
        user = json.loads(row['messages'][1]['content']); target = json.loads(row['messages'][2]['content'])
        record = identities[i]
        assert record['TRAIN_row_index'] == i
        world = hashlib.sha256(str(user['scenario_id']).encode()).hexdigest()
        assert world == record['world_sha256']; world_groups.add(world)
        action = h(target['proposed_action']); assert action == record['exact_proposed_action_sha256']
        actual_a = template_value(template_a, {'compact': target})
        key_a = h([system, actual_a]); assert key_a == record['source_derived_teacher_compact_prefix_sha256']
        # Independent sorted-value statistics; raw iteration index resolves source worst-bus ties.
        vm = [(int(b), float(v)) for b, v in user['local_measurements']['bus_voltages'].items()]
        ordered = sorted(enumerate(vm), key=lambda item: (item[1][1], item[0]))
        state = {'min_voltage_pu': ordered[0][1][1], 'max_voltage_pu': ordered[-1][1][1],
            'n_undervoltage': len([1 for _, v in vm if v < 0.95]),
            'n_overvoltage': len([1 for _, v in vm if v > 1.05]),
            'worst_bus': ordered[0][1][0], 'total_load_mw': float(user['local_measurements']['total_load_mw'])}
        idx = 0 if state['n_undervoltage'] else 1 if state['n_overvoltage'] else 2
        summary = template_value(summary_templates[idx], {'zone': user['zone'], 'zstate': state})
        actual_b = template_value(template_b, {'zone': user['zone'], 'zstate': state, 'state_summary': summary})
        key_b = h([system, actual_b]); assert key_b == record['measurement_derived_compact_prefix_sha256']
        assert record['measurement_input_status'] == 'KNOWN' and record['unknown_reason'] is None
        values = dict(state, zone=user['zone'])
        checks = {name: number_signature(target[name]) == number_signature(values[name])
                  for name in ('zone', 'min_voltage_pu', 'max_voltage_pu', 'n_undervoltage', 'n_overvoltage')}
        assert checks == record['scalar_fields_exactly_match_archived_measurements']
        scalar_matches.update(name for name, match in checks.items() if match)
        assert (target['state_summary'] == summary) == record['summary_exactly_matches_source_canonical_wording']
        compared['summary_exact_match' if target['state_summary'] == summary else 'summary_wording_different'] += 1
        compared['all_five_scalar_fields_match' if all(checks.values()) else 'some_scalar_field_different'] += 1
        compared['prefix_exact_match' if actual_a == actual_b else 'prefix_different'] += 1
        compared['fault_flag_matches_current_counts' if target['fault_detected'] == bool(state['n_undervoltage'] or state['n_overvoltage']) else 'fault_flag_different'] += 1
        for name, key in [('teacher_derived_compact', key_a), ('measurement_derived_compact', key_b)]:
            groups[name][key][action] += 1
            by_label[name][key].setdefault(action, i)
    result = read(DATA / 'Original_Compact_TRAIN_Current_Input_Support.json')
    assert len(world_groups) == 109 and dict(scalar_matches) == result['scalar_field_matches']
    assert dict(compared) == result['comparison_counts']
    classes = read(DATA / 'Exact_Source_Derived_Compact_Action_Classes.json')
    recomputed = {}
    witnesses = []
    for name, data in groups.items():
        expected_classes = [{'prefix_sha256': key, 'rows': sum(labels.values()), 'target_action_counts': dict(labels)}
                            for key, labels in sorted(data.items())]
        assert classes[name] == expected_classes
        maximum = sum(max(labels.values()) for labels in data.values())
        facts = result['exact_teacher_action_support'][name]
        assert facts['distinct_source_derived_prefixes'] == len(data)
        assert facts['known_rows'] == 16000 and facts['unknown_rows'] == 0
        assert facts['ambiguous_proposed_action_classes'] == sum(len(labels) > 1 for labels in data.values())
        assert facts['rows_in_ambiguous_classes'] == sum(sum(labels.values()) for labels in data.values() if len(labels) > 1)
        assert facts['minimum_exact_action_teacher_errors_on_known_rows'] == 16000 - maximum
        assert facts['all_row_empirical_exact_teacher_match_conservative_range'] == [maximum / 16000] * 2
        recomputed[name] = facts
        for key, labels in sorted(data.items()):
            if len(labels) < 2: continue
            indices = [by_label[name][key][label] for label in sorted(labels)]
            observations = [json.loads(rows[index]['messages'][1]['content']) for index in indices]
            targets = [json.loads(rows[index]['messages'][2]['content']) for index in indices]
            diffs = differences(observations[0]['local_measurements'], observations[1]['local_measurements'])
            assert diffs and h(targets[0]['proposed_action']) != h(targets[1]['proposed_action'])
            witnesses.append({'projection': name, 'exact_input_sha256': key, 'all_collision_rows': sum(labels.values()),
                'TRAIN_row_indices': indices, 'exact_action_labels': [target['proposed_action'] for target in targets],
                'first_two_raw_current_measurement_differences': diffs,
                'selected_only_as_exhaustive_collision_witness_not_a_performance_subset': True})
    write(OUT / 'All_Compact_Action_Collision_Witnesses.json', witnesses)
    verified = {'verified_at_utc': now, 'all_passed': True,
        'all16000_TRAIN_rows_109_worlds_checked': True,
        'source_AST_literal_template_rendering_independent_of_primary_renderer': True,
        'all_proposed_action_hashes_prefixes_current_fields_and_action_classes_checked': True,
        'secondary_complete_compact_target_matching_bound_not_independently_recomputed': True,
        'primary_action_support': recomputed, 'comparison_counts': dict(compared),
        'all_collision_witnesses': len(witnesses),
        'all_collisions_hide_different_raw_current_measurements_and_different_exact_actions': True,
        'raw_load_and_bus_iteration_vs_original_serving_runtime_not_physically_remeasured': True,
        'source_derived_data_not_original_compact_asset_or_physical_replay': True,
        'new_model_PF_optimizer_controller_forecast_solve_cloud_allocation_calls': 0,
        'primary_archive_CRC_all_hashes_independently_verified': writer_archive,
        'reader_analysis_seconds_before_frozen_checks_and_seal': time.perf_counter() - start}
    write(OUT / 'Independent_Compact_TRAIN_Current_Input_Audit.json', verified)
    write(OUT / 'Fresh_Frozen_Asset_Checks.json', frozen_checks())
    files = {p.name: p for p in OUT.iterdir() if p.is_file() and p.name != 'reader.claim'}
    files['sources/external_reader.py'] = Path(__file__)
    own_archive = seal(OUT, files, 'Independent_Compact_Input_Audit.zip')
    write(OUT / 'Actual_Read_Only_Reader_Cost.json', {'reader_workflow_seconds_including_frozen_checks_and_seal': time.perf_counter() - start,
        'all_new_scientific_calls': 0, 'prior_data_and_reader_costs_separate_not_free': True})
    print(json.dumps({'all_passed': True, 'primary_support': recomputed, 'all_collision_witnesses': len(witnesses),
        'first_witness_action_labels': witnesses[0]['exact_action_labels'],
        'first_witness_differing_measurement_paths': [x['path'] for x in witnesses[0]['first_two_raw_current_measurement_differences']],
        'archive': own_archive, 'reader_workflow_seconds': time.perf_counter() - start}))


if __name__ == '__main__':
    run()
