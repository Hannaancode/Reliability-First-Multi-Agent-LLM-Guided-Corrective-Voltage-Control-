"""Post-hoc development analysis of closed expert trajectories, zero science.

Saved-route assembly is NOT an executed new policy: SafeDDPG b/c tensors mutate
in inference, so a future router needs its own exact causal model-state chain.
"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/public13_matched_numeric_comparison_20261021'
O = R / 'outputs/public13_expert_complementarity_development_20261021'


def main():
    path = P / 'Matched_Comparison_And_Fixed_Decision.json'
    data = json.loads(path.read_text(encoding='utf-8'))
    assert data['status'] == 'COMPLETE_SAME500_PHYSICAL_NUMERICAL_VS_PUBLISHED_COMPARISON'
    assert data['fixed_gate'] == 'FAIL_FIXED_NUMERICAL_PRIMARY_SUPERIORITY_GATE_NO_RETUNING'
    rows = data['all500_paired_rows']
    assert [r['seed'] for r in rows] == list(range(500))
    chosen = []
    for r in rows:
        if r['input_stratum'] == 'within_band':
            backend = 'NO_ACTION_INITIAL_FULLBAND'
            result = {'UV': 0, 'OV': 0, 'full13band': True}
        elif r['input_stratum'] == 'UV_only':
            backend = 'PUBLISHED_SAFE_DDPG'
            result = r['native']['safe-ddpg']
        else:
            backend = 'OUR_FROZEN_NUMERICAL'
            result = r['ours']
        published_router = (r['native']['safe-ddpg'] if r['input_stratum'] == 'UV_only' else r['native']['ddpg'])
        source3 = any(x['full13band'] for x in r['native'].values())
        chosen.append({'seed': r['seed'], 'input_stratum': r['input_stratum'],
                       'fixed_input_rule_backend': backend, 'saved_branch_result_NOT_new_policy': result,
                       'published_only_input_router_saved_success': published_router['full13band'],
                       'all3_published_available_trajectory_envelope': source3,
                       'all4_available_trajectory_envelope': source3 or r['ours']['full13band']})
    restored = sum(r['saved_branch_result_NOT_new_policy']['full13band'] for r in chosen)
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'POST_HOC_DEVELOPMENT_SAVED_EXPERT_COMPLEMENTARITY_NOT_EXECUTED_ROUTER_OR_CONFIRMATION',
              'closed_paired_source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'all500_cases': True,
              'input_only_rule': 'Already fullband:stop; UV-only:published SafeDDPG; OV-only OR mixed:unchanged numerical controller. No per-case outcome choice.',
              'saved_route_fullband': restored, 'saved_route_fraction': restored / 500,
              'saved_route_remaining_UV': sum(r['saved_branch_result_NOT_new_policy']['UV'] for r in chosen),
              'saved_route_remaining_OV': sum(r['saved_branch_result_NOT_new_policy']['OV'] for r in chosen),
              'published_only_input_router_saved_fullband': sum(r['published_only_input_router_saved_success'] for r in chosen),
              'all3_published_available_trajectory_envelope_fullband': sum(r['all3_published_available_trajectory_envelope'] for r in chosen),
              'all4_available_trajectory_envelope_fullband': sum(r['all4_available_trajectory_envelope'] for r in chosen),
              'predeclared_input_strata_actual_results': data['input_defined_strata_descriptive'],
              'new_model_PF_derivative_solver_optimizer_calls': 0,
              'not_an_LLM_result': True,
              'not_a_novelty_statistical_confidence_or_unused_confirmation_claim': True,
              'limits': ['Rule proposed after seeing development results. No new primary significance test or winning claim.',
                         'Saved source-native model carry is not the model carry a router would have after skipping episodes. SafeDDPG normalization makes that distinction material.',
                         'Every selected old trajectory is independently verified; that does not certify a new causal router.',
                         'Available-trajectory envelopes require all branch costs and are not free online oracle stopping.',
                         'Raw root/preparation/training/model/failed/independent costs are retained; no efficiency inference from saved reuse.',
                         'Same global initial voltage input must be provided to a published-only input-router control. NUM also uses currentY; no equal-information learning attribution.'],
              'proposed_next_test': {'status': 'NOT_READY_UNTIL_SOURCE_INPUT_NO_REPEAT_PRESERVATION_READER_GATES',
                 'prospective_question': 'Does the fixed initial-violation-class router improve full13band on new source-generated cases relative to every unchanged source policy and a published-only same-input router?',
                 'proposed_source_order_recipe_seeds': [1000, 1127],
                 'proposed_count': 128,
                 'must_prove_unexecuted_exact_physical_identities_before_any_science': True,
                 'all_mixed_already_safe_unsafe_failed_partial_unentered_cases_retained': True,
                 'router_Safe_model_state_separate_from_standalone_baseline': True,
                 'original_numerical_source_LP_guard_horizon_unchanged': True,
                 'source_native_baselines_and_same_information_published_router_required': True,
                 'no_LLM_credit_or_automatic_training_or_security': True},
              'rows': chosen}
    O.mkdir(exist_ok=False)
    with (O / 'Saved_Expert_Complementarity_And_Prospective_Question.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
    text = f'''# Closed expert complementarity: development finding only

The frozen numerical controller restored264/500 all13bus voltage bands, versus363/500 publishedDDPG. Its primary superiority gate FAILED. All232 UV-only cases failed strict fullband under NUM, while247/251 OV-only cases succeeded. PublishedSafeDDPG restored232/232 UV-only cases but13/251 OV-only cases.

A rule using only the initial violation class selects saved successful branches for{restored}/500 cases. This is a post-hoc development assembly, not a measured new policy, ourLLM result, calibrated winning probability or confirmation. The published-only input rule and all3published available-trajectory envelope are explicit stronger controls in the JSON.

The scientific hypothesis is complementary failure modes, not a threshold/LP rescue. The current numerical method and failed private-model interface remain stopped. A new router needs fresh exact physical identities, its OWN source-native SafeDDPG parameter carry, actual continuous episodes, all costs and a locked independent reader. The mutable SafeDDPG b/c behavior prevents calling copied standalone outcomes an executed router.

All six final goals remain open. No new model or physics call was made by this analysis.
'''
    (O / 'Findings_And_Next_Test.md').write_text(text, encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['status', 'saved_route_fullband', 'saved_route_remaining_UV', 'saved_route_remaining_OV', 'published_only_input_router_saved_fullband', 'all3_published_available_trajectory_envelope_fullband', 'all4_available_trajectory_envelope_fullband']}))


if __name__ == '__main__':
    main()
