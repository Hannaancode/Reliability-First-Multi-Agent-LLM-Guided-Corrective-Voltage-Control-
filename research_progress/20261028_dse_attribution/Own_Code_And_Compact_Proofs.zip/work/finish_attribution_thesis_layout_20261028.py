"""Retain initial render; improve paragraph flow and record verified prompt finding."""
from pathlib import Path
import json,hashlib,shutil
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_attribution_and_comparators_20261028';P=O/'Hannaan_Thesis_Attribution_And_Comparators.docx'
A=O/'initial_render';A.mkdir(exist_ok=False)
for n in ['Integrated_Thesis_QA.pdf','Pagination_Record.json','Changed_Pages.json']:shutil.copy2(O/n,A/n)
shutil.copy2(P,A/P.name)
assert json.loads((R/'outputs/original_prompt_candidate_diagnosis_20261028/independent/Independent_Audit.json').read_text())['status'].startswith('PASS_ALL459')
d=Document(P)
for p in d.paragraphs:
 if p.text.startswith('Original DFF and HG-VF completed these four cases'):
  p.text='DFF and HG-VF reached converged endpoints on all four roots but left voltage violations. The external policy changes generator or slack voltage and existing binary shunts under 136 native operations. HierGrid adds shunts under a 450 Mvar per-bus cap and 25 operations. These different controls prevent an equal-resource or general superiority claim. The GraphAgent campaign used no GPU, language inference or training.'
  for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(12)
 if p.text.startswith(tuple('['+str(i)+']' for i in range(31,36))):
  p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_after=Pt(6);p.paragraph_format.keep_together=True
  p.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
 # Add a compact, independent prompt contract observation with the causal limit.
 if p.text.startswith('The saved source reasons contain 120 responses'):
  p.text='The saved rejection reasons include 120 responses naming bus 52 and 102 naming bus 32 outside the current candidate list. A separate audit bound all 459 saved prompts to their source candidate lists. The fixed bus-52 example was outside that list in 231 of 308 first prompts, and 62 responses chose that invalid example bus. All 151 second prompts used an allowed example. This is an observed prompt inconsistency and output association, not proof that the example caused the errors or that replacing it improves voltage control. Actual model input token decoding was not repeated by this saved-message check.'
  for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(12)
for t in d.tables:
 if t.rows[0].cells[0].text in ['Work','Stage or event','Root']:
  # Restrict to new tables by exact distinctive headers.
  h=[c.text for c in t.rows[0].cells]
  if h not in [['Work','Information and decision role','Numerical evidence','Security and admission'],['Stage or event','Count','Denominator'],['Root','Initial UV','Operations','Terminal result']]:continue
  for row in t.rows:
   for j,c in enumerate(row.cells):
    for p in c.paragraphs:p.alignment=WD_ALIGN_PARAGRAPH.CENTER if h[0]=='Stage or event' and j>0 else WD_ALIGN_PARAGRAPH.LEFT
d.save(P)
record={'status':'FINAL_LAYOUT_REPAIR_AWAITING_REPAGINATION_AND_VISUAL_QA','changes':['Remove two-line standalone Graph ending page by concise equivalent paragraph','Keep each new bibliography record together and use compact reference line spacing','Left-align new narrative table cells','Integrate independently verified saved prompt example mismatch with causal limitation'],'new_scientific_calls':0,'initial_render_preserved':True}
(O/'Layout_Repair_Record.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(record['status'])
