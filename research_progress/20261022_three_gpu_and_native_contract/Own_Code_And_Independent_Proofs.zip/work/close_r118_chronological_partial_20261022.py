"""First terminal preservation/decision receipt. No repeated scientific audit."""
import hashlib, json, os, shutil, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R/'work'))
from reflection118_chronological_core_20261022 import sha, read, put
H = R/'outputs/reflection118_chronological_handoff_20261022'
O = H/'verified_terminal_partial'
E = R/'outputs/r118chrono_20261022'
A = R/'outputs/r118chrono_audit_20261022'
P = R/'outputs/reflection118_chronological_preparation_20261022'

def mutable(path, value):
    tmp = path.with_name(path.name+'.terminal.pending')
    with tmp.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)

def main():
    O.mkdir(exist_ok=False); began=time.monotonic(); stamp=datetime.now(timezone.utc).isoformat()
    proc = subprocess.run(['powershell','-NoProfile','-Command',
        "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python' -and $_.CommandLine -match 'reflection118_chronological|audit_reflection118|reflection118_model_service' } | Select-Object ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 3 -Compress"],
        capture_output=True, text=True, timeout=45, check=True)
    live=json.loads(proc.stdout) if proc.stdout.strip() else []
    if isinstance(live,dict):live=[live]
    assert not live, 'Do not close while an exact study/model/reader owner is live'
    host=read(E/'status.json');audit=read(A/'Independent_Audit.json')
    assert host['runtime_released'] and host['scientific_process_ended'] and host['all_actual_closed_artifacts_preserved']
    assert audit['status']=='PASS_PRESERVED_PARTIAL_FULL_COMPARISON_UNKNOWN' and not audit['all4_complete']
    lock=read(P/'Independent_Reader_Lock.json');claim=read(A/'owner.claim')
    assert claim['source_sha256']==lock['sha256']==sha(R/lock['source'])
    # This is the first outside closure of the reader's output manifest. No PF,
    # policy replay, original independent stage or completed archive is repeated.
    reader_manifest=read(A/'Closed_Manifest.json')['members']
    for name,h in reader_manifest.items(): assert sha(A/name)==h
    assert not (A/'Failure.json').exists()
    failure=read(E/'local_controller/Failure.json');model=read(E/'staged/study/Results.json')
    assert failure['costs']['new_PF_returns']==audit['new_independent_PF_replays']==357
    assert failure['costs']['new_PF_attempts']==358 and failure['costs']['new_PF_exceptions']==1
    assert model['served_requests']==audit['actual_model_responses_verified']==110
    summary=audit['complete_branches'][0]
    assert summary['base_uv']==56 and summary['final_uv']==7 and summary['strict_OV']==2
    local_end=read(E/'Local_End_ACK.json');host_end=read(R/'outputs/r118chrono_coordination_20261022/End_ACK.json')
    supervisor=R/'outputs/r118chrono_handoff_20261022'
    supervisor_exit=read(supervisor/'Reader_Owner_Protocol.json.End.json')['exit_code']
    supervisor_log=(supervisor/'Reader_Owner_Protocol.json.log').read_text('utf-8')
    assert supervisor_exit==1 and 'time.monotonic()-start<60' in supervisor_log
    assert not (R/'outputs/r118chrono_reader_coordination_20261022/End_ACK.json').exists()
    diag=read(R/'outputs/r118_saved_solver_contract_diagnosis_v2_20261022/Saved_Contract_Diagnosis.json')
    assert diag['resolved_option_differences']=={'max_iteration':{'old':50,'new':80}}
    assert not diag['old_saved_options_mismatches_with_current_old_resolution']
    provenance={
        'at_utc':stamp,'status':'ACTUAL_TERMINAL_SAVED_PARTIAL_WITH_SUPERVISOR_FAILURE_PRESERVED',
        'fresh_matching_live_python_processes':live,'actual_host_exit':host_end,
        'actual_local_exit':local_end,'reader_claim':claim,'reader_source_pin':lock,
        'original_supervisor_exit_code':supervisor_exit,
        'supervisor_failure':'Claim handshake timed out at60seconds during imports. Original child later closed a PASS audit; supervisor did not retain the actual child exit status.',
        'actual_reader_OS_exit_code':'UNKNOWN_NOT_RETAINED_NO_EXIT0_INFERENCE',
        'actual_reader_output_manifest_members':len(reader_manifest),
        'actual_reader_output_manifest_sha256':sha(A/'Closed_Manifest.json'),
        'first_terminal_manifest_verification':'PASS_ALL_READER_OUTPUT_MEMBERS',
        'original_handoff_completion':'ABSENT_NOT_RETROACTIVELY_MANUFACTURED',
        'no_repeated_science_or_original_reader':True,
        'waiting_automation':{'id':'hiergrid-chronological118-result-check','actual_tool_delete':'deleted'},
        'current_owned_GPU_assignments':0,'host_release_confirmed':True,
        'saved_solver_diagnosis':{
            'file':'outputs/r118_saved_solver_contract_diagnosis_v2_20261022/Saved_Contract_Diagnosis.json',
            'sha256':sha(R/'outputs/r118_saved_solver_contract_diagnosis_v2_20261022/Saved_Contract_Diagnosis.json'),
            'exact_current_and_old_nonresult_inputs':True,'pandapower_version':'3.4.0 both',
            'angle_and_other_resolved_options':'EXACT_MATCH',
            'only_resolved_difference':diag['resolved_option_differences'],
            'old_saved_final_Newton_iterations':4,
            'missing_evidence':'Every earlier generator-Q-limit Newton pass and its convergence/termination history were not retained; final four iterations alone cannot certify equivalence under50versus80.',
            'reuse_gate':'UNKNOWN_NO_CHANGED_CONTRACT_REUSE_OR_REPEATED_PF_AUTHORIZED_BY_THIS_DIAGNOSIS',
            'failed_v1_locator_preserved':'outputs/r118_saved_solver_contract_diagnosis_20261022/Failure.json'},
        'new_PF_model_optimizer_converter_derivative_factor_solve_calls':0,
        'closure_workflow_seconds':time.monotonic()-began}
    put(O/'Terminal_Provenance_And_Solver_Diagnosis.json',provenance)
    facts={
        'at_utc':stamp,'status':'INDEPENDENTLY_VERIFIED_SINGLE_ORIGINAL_TRAINED_EPISODE_FULL_COMPARISON_PARTIAL',
        'all6_final_goals':'OPEN','complete_source_native_episodes':[summary],
        'UV_reduction_count':49,'UV_reduction_fraction':0.875,
        'strict_normal_band_restoration':False,'native_HARD_OV':1.06,
        'final_vmax':1.0595039757073432,
        'complete_branches':1,'planned_branches':8,'unfinished_branches':7,
        'DFF_HGSE_all4_contrasts':'UNKNOWN','external_method_comparison':'NOT_EXECUTED_BY_THIS_STUDY',
        'new_primary_physics_costs':failure['costs'],'primary_model_costs':model['costs'],
        'primary_model_service_workflow_seconds':model['workflow_seconds'],
        'local_controller_workflow_seconds':failure['workflow_seconds'],
        'primary_host_workflow_seconds':host_end['elapsed_seconds'],
        'independent_first_physics_replays':audit['new_independent_PF_replays'],
        'independent_reader_workflow_seconds':audit['workflow_seconds'],
        'max_replay_field_delta':audit['maximum_numeric_field_delta'],
        'max_KCL_pu':audit['maximum_KCL_pu'],
        'causal_original_policy_outputs_exact':audit['all_causal_original_policy_outputs_exact'],
        'prior_input_data_training_preparation_costs':'RETAINED_SEPARATELY_OR_UNKNOWN_NOT_FREE; overlapping host/local/remote workflow times are not summed into intrinsic solver/inference latency.',
        'primary_stop':'Saved same physical input, different50/80 iteration limit; stopped before another PF. DFF already has5new returned candidate solves; no completed DFF episode.',
        'supervision_caveat':'Original reader claim observer failed; actual child output closed PASS. Actual OS child exit code UNKNOWN. See separate provenance receipt.',
        'GPU_assignments':0,'waiting_timers':[],'no_superiority_zero_all_novelty_or_paper_best_claim':True,
        'verified_GitHub_before_this_publication':'cd29945876b2a1a7c56f0261d37539a156376e7e'}
    put(O/'Verified_Terminal_Partial_Checkpoint.json',facts)
    text=f'''# Original Reflection-v4 result and next decision

Verified22October2026: on registered severe118-bus `fed_combined_load_1p5_line_35_MG1`, the actual private trained0.5B original chronological four-zone policy reduced UV **56 -> 7 (87.5%)**. It committed17actions:14direct-language and3guided; no fallback commits. This is one complete actual episode, with exact causal prompt/response/source replay and357 first independent successful physical replays across the partial study (maximum field difference0.0, KCL1.10e-8pu). The unchanged source labels its arm `reflection_v2` inside Reflection-v4.

Two strict overvoltage buses remain (maximum1.0595039757pu); the source's original1.06guard was preserved. It did not restore the0.95-1.05band. Language-generated actions are not proof that language caused improvement over an equally informed numerical control.

The study is TERMINAL PARTIAL: one of eight branches complete. The DFF branch executed five new candidate solves, then stopped before repeating an old identical physical input whose recorded maximum iterations were50 rather than the source's80. All other matched endpoint contrasts and the all-four development gate remain UNKNOWN. No external method was run in this study; no paper-best/fullDSE/superiority/unused-confirmation result follows.

Saved-only source diagnosis: both old and current solver are pandapower3.4.0, angle resolution and every other resolved option match. The old final Newton pass used4iterations. Generator Q-limit enforcement can contain earlier Newton passes whose iteration/convergence histories were not retained. Consequently final4alone is insufficient to certify50/80equivalence. Do not relax the cache gate or repeat that solve to settle uncertainty. The initial diagnosis used the wrong saved capsule and failed its exact-input assertion; its source/failure are preserved, and an additive saved-only locator repair made zero scientific calls.

Costs:358new primary PF attempts,357returns,1exception;357independent first replays. Modelservice:2loads,111generations including1fresh-loader cold generation,2178forward returns/tokens,0training/optimizer calls. Localworkflow3170.703s, remote3256.482s, host3586.718s, independentreader302.219s; these overlap and are not summed as intrinsic latency. All old setup/data/training/failure costs remain separate or UNKNOWN, not free.

The original reader supervisor failed its60second claim handshake during imports. Its child subsequently finished the locked independent audit with PASS and a closed output manifest. The actual OS child exit code was not retained and remains UNKNOWN; the original supervision failure and absent handoff Completion remain preserved. The additive terminal receipt verifies the output manifest and terminal ownership, without rerunning the reader or any physics. T4 released; no owned job or waiting timer remains.

Next substantive work, in order:
1. Seek existing per-Q-limit-pass/source provenance for the blocked paid solve. If unavailable, keep reuse UNKNOWN. A different-contract measurement or continuation needs a separate prospective justification, complete identity/attempt-history/preservation/ownership/first-replay/cost gates; never restart this owner or extend its budget.
2. Continue the compatible published118common-task benchmark design: genuine causal state, identical registered inputs, explicit original-versus-common safety track, same action access/resources, strong trained numerical/DQN/graph controls, frozen TRAIN/VAL/unusedTEST, authentic loader and persistent warm/cold/source/reader gates before a new performance campaign. Absolute-shunt action software alone does not authorize training or a GPU allocation.
3. Finish source-native matched HG-VF/DFF/HGSE endpoints and literal DFF+DFFALT+unchangedDSE/full both-branch costs before claiming a winner. Preserve historical paper137/67cohort distinctions, all failed/unsafe/partial/UNKNOWN records and frozen originals.
'''
    (O/'Results_And_Next_Decision.md').write_text(text,'utf-8')
    sources=[Path(__file__),R/'work/diagnose_r118_saved_solver_contract_20261022.py',
             R/'work/diagnose_r118_saved_solver_contract_v2_20261022.py',R/lock['source'],
             R/'work/run_reflection118_chronological_local_20261022.py',
             R/'work/run_reflection118_model_service_remote_20261022.py']
    put(O/'Source_And_Cost_Index.json',{'sources':{p.relative_to(R).as_posix():sha(p) for p in sources},
        'evidence':{p.relative_to(R).as_posix():sha(p) for p in [A/'Independent_Audit.json',A/'Closed_Manifest.json',
             E/'local_controller/Failure.json',E/'staged/study/Results.json',supervisor/'Reader_Owner_Protocol.json.log']},
        'raw_private_weights_NETs_and_thirdparty_sources':'RETAINED_LOCAL_NOT_PUBLIC_COMPLETE_BACKUP',
        'all_original_failed_sources_claims_and_stderr':'PRESERVED', 'new_scientific_calls_for_terminal_receipt':0})
    public=O/'public_snapshot';public.mkdir()
    for n in ['Terminal_Provenance_And_Solver_Diagnosis.json','Verified_Terminal_Partial_Checkpoint.json',
              'Results_And_Next_Decision.md','Source_And_Cost_Index.json']:
        shutil.copyfile(O/n,public/n)
    shutil.copyfile(A/'Independent_Audit.json',public/'Independent_Audit.json')
    shutil.copyfile(R/'outputs/r118_saved_solver_contract_diagnosis_v2_20261022/Saved_Contract_Diagnosis.json',public/'Saved_Contract_Diagnosis.json')
    shutil.copyfile(R/'work/diagnose_r118_saved_solver_contract_v2_20261022.py',public/'diagnose_r118_saved_solver_contract_v2_20261022.py')
    files=[]
    for p in sorted(public.iterdir()):
        raw=p.read_bytes();files.append({'local':p.relative_to(R).as_posix(),
            'path':'research/20261022_reflection118_verified_partial/'+p.name,
            'bytes':len(raw),'sha256':sha(p),'blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
    put(O/'Publication_Files.json',files)
    for old in ['Current_Resume.json','Latest_Live_And_Parallel_Resume.json']:
        shutil.copyfile(H/old,O/('Previous_'+old))
    resume={'at_utc':stamp,'status':facts['status'],'all6_final_goals':'OPEN',
        'current_GPU_assignments':0,'current_owned_jobs':[], 'timers':[],
        'actual_closed_evidence':O.relative_to(R).as_posix(),
        'verified_single_episode':summary,'matched_all4_gate':'UNKNOWN_PARTIAL',
        'reader_supervision_failure_and_unknown_OS_exit_preserved':True,
        'new_science_not_ready_from_this_closure':True,
        'next':[
            'Recover existing per-Q-limit solver pass provenance or keep changed-limit reuseUNKNOWN; no repeatedPF/old restart.',
            'Specify actual common118published/DQN/graph causal state/training/strong-control/ownership/reader/full-cost protocol; do not launch from software readiness.',
            'Only a separately justified missing-only campaign may complete source-native branch endpoints; original full literalDSE/bothbranch costs, external118and unused confirmation remain required.'],
        'last_verified_GitHub':'cd29945876b2a1a7c56f0261d37539a156376e7e',
        'results':(O/'Results_And_Next_Decision.md').relative_to(R).as_posix()}
    mutable(H/'Current_Resume.json',resume)
    mutable(H/'Latest_Live_And_Parallel_Resume.json',resume)
    tasksfile=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(tasksfile)
    def update(node):
        if isinstance(node,dict):
            if node.get('id')=='G3.F118.6b':
                node.update(completed=False,description='TERMINAL PARTIAL: actual original trained full episode56to7UV/2strictOV,17commits; first357PF/source replayPASS. DFF stopped at different50/80iteration paid contract; all4comparisonUNKNOWN. Supervisor failure/child OS exitUNKNOWN retained; noGPU/timer.',
                    evidence=(O/'Verified_Terminal_Partial_Checkpoint.json').relative_to(R).as_posix())
            for v in node.values():update(v)
        elif isinstance(node,list):
            for v in node:update(v)
    update(tasks);tasks['latest_resume']=(H/'Current_Resume.json').relative_to(R).as_posix();tasks['latest_status_at_utc']=stamp
    tasks['current_owned_jobs']=[];tasks['current_GPU_assignments']=0;tasks['waiting_automations']=[]
    mutable(tasksfile,tasks)
    header=f'''## Verified original trained118episode; matched study TERMINAL PARTIAL — {stamp}

Read outputs/reflection118_chronological_handoff_20261022/Current_Resume.json and verified_terminal_partial/Results_And_Next_Decision.md. One actual unchanged original Reflection-v4 episode56->7UV (87.5%) but2strictOV/max1.059504;17commits14directLLM+3guided.357first independent new-return replays/source outputsPASS, maxdelta0.0/KCL1.10e-8. Other7branch endpoints/all4contrastsUNKNOWN: DFF stopped before old paid same-input50vs80iteration contract. Saved-only diagnosis resolvesangles/otheroptionsidentically but missing earlierQ-limit iteration history prevents automaticreuse. No repeatedphysics.

All actualowners/reader ended; exactT4released/nojobs/noGPU/timerdeleted. Original reader-supervisor60sclaim timeout/exit1 preserved; child independently closedPASS, actualOSchildexitUNKNOWN/oldhandoffCompletionabsent. Additive terminalmanifest receipt0science, no repeatedreader. Sources/costs/onePFexception/allunknown retained. All6finalgoalsOPEN, fullDSE/external118/zero-all/LLMsuperiority/security unachieved. Next: recover existing solver provenance or keepUNKNOWN; separately prospectively specify common118controls/missing-only measurement, no oldrestart/budgetextension/automaticGPU. GitHubprevious cd29945876b2a1a7c56f0261d37539a156376e7e; this compact publication pending.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        path=R/rel;original=path.read_bytes();tmp=path.with_name(path.name+'.terminal.pending')
        with tmp.open('xb') as f:f.write(header.encode('utf-8')+original);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    progress=R/'reseacrh progress.txt'
    with progress.open('a',encoding='utf-8') as f:
        f.write('\n\n'+header+text);f.flush();os.fsync(f.fileno())
    put(O/'Closed_Receipt_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'terminal_receipt':'SAVED','complete_original_episode':'56to7UV/2OV',
        'matched_comparison':'UNKNOWN_PARTIAL','scientific_calls_in_closure':0,'owned_GPU_assignments':0,
        'public_files':len(files),'result':str(O/'Results_And_Next_Decision.md')}))

if __name__=='__main__':main()
