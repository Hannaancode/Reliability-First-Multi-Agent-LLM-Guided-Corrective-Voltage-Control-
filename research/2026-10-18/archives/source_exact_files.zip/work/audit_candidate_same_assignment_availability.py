"""Bounded fresh GET-only ownership check after failed inspection; no POST."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,logging,os,uuid
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from google_account_profile import verify_account
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT);logging.disable(logging.CRITICAL)
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';EX=BASE/'pretrained_learning_trainability_execution_v3'
OUT=BASE/'same_assignment_trainability_availability_audit'
assert not OUT.exists();OUT.mkdir()
state=json.loads((EX/'status.json').read_text());assert state['finished_at_utc'] and state['failure_type']=='FileNotFoundError'
os.environ['HIERGRID_EXPECTED_GOOGLE_ACCOUNT']=state['expected_account']
creds=Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud-hiergrid-sheenah\application_default_credentials.json')
request=Request()
def refresh(*a,**kw):kw.setdefault('timeout',25);return request(*a,**kw)
creds.refresh(refresh);session=AuthorizedSession(creds,refresh_timeout=30)
try:
    actual=verify_account(session);assert actual==state['expected_account']
    client=Client(Prod(),session)
    before=client.list_assignments()
    response=client._get_assignment(uuid.UUID(state['notebook_hash']),variant=Variant.GPU,accelerator=Accelerator.T4)
    after=client.list_assignments()
    report={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'selected_account_authenticated':actual,
      'same_exact_original_notebook':state['notebook_hash'],'old_endpoint':state['endpoint'],
      'fresh_assignments_before':[{'endpoint':a.endpoint,'accelerator':a.accelerator.value} for a in before],
      'fresh_assignments_after':[{'endpoint':a.endpoint,'accelerator':a.accelerator.value} for a in after],
      'GET_response_type':type(response).__name__,'same_assignment_current_endpoint':getattr(response,'endpoint',None),
      'existing_runtime_proxy_available':getattr(response,'runtime_proxy_info',None) is not None,
      'no_new_allocation_POST_upload_kernel_model_PF_execution':True,
      'remaining_hours_quota_reset_or_cause_not_inferred':True}
    (OUT/'Fresh_Actual_Assignment_Audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
finally:session.close()
