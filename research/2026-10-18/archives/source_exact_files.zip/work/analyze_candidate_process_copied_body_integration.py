"""External no-model/PF identity, actual update, reload, physics-boundary reader."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import json,os,torch
from safetensors.torch import load_file
from candidate_process_evidence_utils import ROOT,read,write,sha,seal,frozen_checks
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';EXEC=BASE/'copied_body_integration_execution';PREP=BASE/'copied_body_integration_preparation'
SCI=EXEC/'staged/study';OUT=BASE/'copied_body_integration_external_audit'
status=read(EXEC/'status.json')
assert status['runtime_released'] and status['all_actual_artifacts_preserved'] and status['remote_exit_code']==0
assert not OUT.exists(),'No duplicate reader or partial reader restart'
OUT.mkdir();write(OUT/'owner.claim',{'actual_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__))})
protocol=read(PREP/'protocol.json');payload=read(PREP/'Cloud_Payload_Manifest.json')
assert sha(ROOT/payload['archive'])==payload['sha256'] and (ROOT/payload['archive']).stat().st_size==payload['bytes']
for name,digest in read(PREP/'Program_Input_Manifest.json').items():assert sha(ROOT/name)==digest
assert read(EXEC/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
assert read(EXEC/'staged/remote_frozen_environment.json')==read(PREP/'Expected_Environment.json')
manifest=read(SCI/'Closed_Actual_Manifest.json')
for name,m in manifest.items():assert sha(SCI/name)==m['sha256'] and (SCI/name).stat().st_size==m['bytes']
assert read(SCI/'protocol.json')==protocol
summary=read(SCI/'summary.json');assert summary['all_genuine_integration_gates_passed']
counts=summary['counts'];assert counts['forward_attempts']==counts['forward_returns']==6
assert counts['backward_attempts']==counts['backward_returns']==counts['optimizer_steps']==2
assert counts['soft_embedding_tokens']==237*6 and counts['PF_attempts']==counts['generation_attempts']==0
assert summary['real_named_original_LoRA_copy_trainable_parameters']==8798208 and summary['all_new_trainable_parameters']==9087967
events=[json.loads(line) for line in (SCI/'events.jsonl').read_text().splitlines()]
attempts=[r for r in events if r['event'] in ['forward_attempt','final_forward_attempt','fresh_checkpoint_forward_attempt']]
returns=[r for r in events if r['event'] in ['forward_return','final_forward_return','fresh_checkpoint_forward_return']]
steps=[r for r in events if r['event']=='optimizer_step_and_checkpoint_preserved']
assert len(attempts)==len(returns)==6 and len(steps)==2
ids=[r['observation_id'] for r in protocol['exact_two_optimization_views']]
assert [r['observation_id'] for r in attempts]==[r['observation_id'] for r in returns]==ids*3
assert [r['step'] for r in steps]==[1,2]
for s in steps:assert sha(SCI/s['checkpoint'])==s['sha256']
assert all(a['elapsed_seconds']<=b['elapsed_seconds'] for a,b in zip(events,events[1:]))
old=load_file(str(ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/adapter_model.safetensors'))
common=torch.load(PREP/'Common_Initial_Interface.pt',weights_only=True,map_location='cpu')
checkpoint=torch.load(SCI/'Step2_Actual_Checkpoint.pt',weights_only=True,map_location='cpu')
assert set(checkpoint)=={'common','copied_adapter'} and set(checkpoint['copied_adapter'])==set(old)
assert len(old)==336 and sum(v.numel() for v in old.values())==8798208
assert all(not torch.equal(checkpoint['copied_adapter'][name],value) for name,value in old.items())
assert set(checkpoint['common'])==set(common) and all(not torch.equal(checkpoint['common'][name],value) for name,value in common.items())
for step in [1,2]:
    gradients=read(SCI/f'Step{step}_Actual_Gradient_Records.json')
    assert all(r['finite'] and r['norm']>0 for r in gradients.values())
    assert len([n for n in gradients if '.lora_A.candidate_process_copy.' in n or '.lora_B.candidate_process_copy.' in n])==336
    checkpoint1=torch.load(SCI/f'Step{step}_Actual_Checkpoint.pt',weights_only=True,map_location='cpu')
    assert set(checkpoint1['copied_adapter'])==set(old)
final=torch.load(SCI/'Final_Actual_Scores.pt',weights_only=True,map_location='cpu');replay=torch.load(SCI/'Fresh_Model_Checkpoint_Scores.pt',weights_only=True,map_location='cpu')
assert set(final)==set(replay)==set(ids)
assert all(v.shape==(118,9,7) and bool(torch.isfinite(v).all()) and torch.equal(v,replay[name]) for name,v in final.items())
assert read(SCI/'Frozen_Base_Inventory_Before.json')==read(SCI/'Frozen_Base_Inventory_After.json')
assert read(SCI/'Actual_Load_Record.json')['trainable_body_parameters']==8798208
assert read(SCI/'Fresh_Model_Load_Record.json')['trainable_body_parameters']==0
assert all(v for v in read(SCI/'Actual_Updated_Parameter_Tensors.json').values())
assert summary['frozen_base_buffers_quantization_and_original_private_files_unchanged'] and summary['exact_fresh_checkpoint_scores_both_views']
write(OUT/'Fresh_Frozen_Asset_Audit.json',frozen_checks())
certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'exact_original_copy_tensors_updated':336,'actual_optimizer_steps':2,
 'actual_genuine_pretrained_forwards':6,'actual_backward_calls':2,'actual_soft_positions_processed':1422,
 'exact_two_optimization_ids':ids,'all_trainable_shared_and_body_tensors_nonzero_finite_gradient_and_update_verified':True,
 'all_frozen_parameters_buffers_quantization_and_private_source_files_preserved':True,'actual_fresh_model_scores_exact':True,
 'actual_same_owned_runtime_released':True,'actual_notebook_hash':status['notebook_hash'],
 'science_manifest_sha256':sha(SCI/'Closed_Actual_Manifest.json'),'real_CUDA_load_memory_setup_and_training_costs_retained':True,
 'zero_new_model_optimizer_PF_calls_in_reader':True,'integration_not_LLM_value_performance_or_novelty':True}
write(OUT/'Independent_Actual_Integration_Audit.json',certificate)
write(OUT/'Actual_Compute_and_Result_Summary.json',summary)
(OUT/'Results.md').write_text('''# Actual copied-body integration\n\nThe separately named original LoRA copy passed the two-step T4 engineering integration. All336 original attention/MLP copy tensors and shared-interface tensors received finite nonzero gradients and actually changed. Frozen base parameters/buffers/quantization and original adapter/tokenizer files remained unchanged. Six real pretrained forwards used237 soft positions each; both actual final scores reproduced exactly after loading a fresh base/model and the preserved step2 checkpoint. Exact runtime release and every closed scientific artifact were verified.\n\nThis is genuine internal-weight engineering evidence, not a policy, LLM-superiority or novelty result. Full training, controls/attribution, physical matched trajectories and unused confirmation require separately prospective gates. All actual timing, memory, setup and prior costs remain in the compute summary.\n''')
files={'audit/'+p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'}
for name in manifest:files['science/'+name]=SCI/name
files['science/Closed_Actual_Manifest.json']=SCI/'Closed_Actual_Manifest.json'
for name in ['status.json','remote_output_descriptor.json']:
    files['closed_execution/'+name]=EXEC/name
for name in ['protocol.json','Launch_Readiness_Audit.json','Cloud_Payload_Manifest.json','Direct_Human_Authority_for_Exact_Payload.json']:
    files['preparation/'+name]=PREP/name
for name in ['analyze_candidate_process_copied_body_integration.py','continue_candidate_process_copied_body_audit.py']:
    files['external_reader_sources/'+name]=ROOT/'work'/name
archive=seal(OUT,files,'Copied_Body_Actual_Integration_Evidence.zip')
write(OUT/'status.json',{'stage':'complete_independent_integration_audit','all_passed':True,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'archive':archive})
print(json.dumps({'all_genuine_integration_gates_verified':True,'actual_steps':2,'actual_forwards':6,'archive':archive},indent=2))
