"""Before any allocation: final source/authority/export/context closure for one original-profile T4."""
import ast,hashlib,json,zipfile,shutil
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import frozen_checks
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/original_lora_native13_transfer_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    assert not (ROOT/'outputs/original_lora_native13_transfer_execution_20261020').exists()
    p=json.loads((OUT/'Protocol.json').read_text(encoding='utf-8'));messages=json.loads((OUT/'All3_Messages_And_Token_IDs.json').read_text(encoding='utf-8'));assert all(x['prefix_tokens']==176 for x in messages)
    # Pre-execution design review,not outcome-driven rescue: no actual model/allocation exists.
    # Keep the unexecuted128-token draft and allow the original model's usual384-token format budget.
    remote=ROOT/'work/run_native13_lora_transfer_remote_20261020.py';shutil.copyfile(remote,OUT/'Unexecuted_128token_Remote_Draft.py');s=remote.read_text(encoding='utf-8').replace('len(ids)+128<=512','len(ids)+384<=1024').replace("'max_new_tokens':128","'max_new_tokens':384").replace('max_new_tokens=128','max_new_tokens=384').replace('0<len(new)<=128','0<len(new)<=384');remote.write_text(s,encoding='utf-8');ast.parse(s)
    review={'at_utc':datetime.now(timezone.utc).isoformat(),'reason':'Before allocation/model outputs,avoidconflating theoriginalfull-format-trainedmodel with a128tokenoutputceiling. Keep same3exact176tokenprefixes;usepre-existing384tokenallowanceand1024sourcecontext(560maximum),no cropping. Thedraft128/512protocol/sourceisretainedunexecuted.','same_all3_prompt_token_sequences':True,'actual_model_PF_GPU_calls_before_review':0,'no_more_decoder_prompt_seed_budget_change_after_launch':True};put(OUT/'Preexecution_Format_Budget_Review.json',review)
    p.update(setup_seconds=1800,science_process_seconds=900,collector_seconds=1200,profiles={'public_0_5B':{'account':'abdulhannaan2002@gmail.com'}},fixed_actual_generations=6,maximum_context=1024)
    p['decoder_fixed_before_outputs']['max_new_tokens']=384;p['input_context']='Same3complete176-tokenprefixes plus384reserve fit1024;no truncation. Previous512/128draftunexecuted,preserved. Originalmodeltrainingcontext512isnotclaimedtohavebeenthisnewnativecontract.'
    p['currently_ready_for_actual_model_owner']=True;p['missing_before_model_launch']=[];put(OUT/'protocol.json',p)
    auth={'latest_direct_human_message':'go ahead do them','scope':'Continue the six authorized research tasks,benchmarkingfirst,and prior full necessary access/preparation/execution authority. One bounded original-profile T4 is necessary to test the preserved trained0.5Bquantized privateadapter on3publicnative-state prompts,with3coldreplicas,no training/PF,purchases,fallback orscientificretry. Privateadapter/tokenizer export follows existing directhumanfullnecessary authority. No credentials/network/bank/privateTRAIN labels exported.','actual_requested_outputs':'Strictnative transfer validity/cold outputs/costs;not a guaranteedwin ornewLLMnovelty.'};put(OUT/'Direct_Human_Authority.json',auth)
    sources=['run_original_lora_native13_colab_20261020.py','run_native13_lora_transfer_remote_20261020.py','native13_lora_environment_check_20261020.py','native13_lora_setup_remote_20261020.py','native13_lora_guardian_20261020.py','candidate_process_pretrained_loader.py','public_size_u61_preservation.py','public_size_local_preservation_v2.py','google_account_profile.py','audit_original_lora_native13_outputs_20261020.py','prepare_original_lora_native13_transfer_gate_20261020.py']
    for n in sources:ast.parse((ROOT/'work'/n).read_text(encoding='utf-8'))
    host=(ROOT/'work/run_original_lora_native13_colab_20261020.py').read_text(encoding='utf-8');assert "arm='public_0_5B'" in host and host.count('client.assign(')==1 and 'Launch_Readiness_Audit' in host
    bundle={}
    for n in sources:
        if n not in ['run_original_lora_native13_colab_20261020.py','public_size_local_preservation_v2.py','google_account_profile.py','audit_original_lora_native13_outputs_20261020.py','prepare_original_lora_native13_transfer_gate_20261020.py']:bundle['work/'+n]=ROOT/'work'/n
    for n in ['frozen_gpu_requirements.txt','frozen_dependency_closure.txt','uv_bootstrap_version.txt']:bundle['work/'+n]=ROOT/'work'/n
    for n in p['private_adapter_tokenizer_unchanged']:
        f=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'/n;assert sha(f)==p['private_adapter_tokenizer_unchanged'][n];bundle['work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/'+n]=f
    bundle['prep/protocol.json']=OUT/'protocol.json';bundle['prep/All3_Messages_And_Token_IDs.json']=OUT/'All3_Messages_And_Token_IDs.json'
    manifest={n:{'bytes':f.stat().st_size,'sha256':sha(f)} for n,f in bundle.items()};path=OUT/'Native13_Private_LoRA_Inputs_Only.zip'
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n,f in bundle.items():z.write(f,n)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
        for n,m in manifest.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
    payload={'archive':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path),'members':len(bundle)+1,'human_authority_source':(OUT/'Direct_Human_Authority.json').relative_to(ROOT).as_posix(),'human_authority_sha256':sha(OUT/'Direct_Human_Authority.json'),'private_adapter_tokenizer_authorized':True,'credentials_network_bank_privateTRAINlabels_uploaded':False,'public_base_fetched_by_exact_revision':p['base_for_new_experiment']};put(OUT/'Cloud_Payload_Manifest.json',payload)
    ready={'passed':True,'at_utc':datetime.now(timezone.utc).isoformat(),'all3_complete176token_contexts_and384reserve':True,'no_prompt_or_case_selected_by_model_outcome':True,'private_files_and_public_base_pinned':True,'single_original_profile_oneassign_no_fallback':True,'all_scientific_model_forward_calls_andcold6charged':True,'host_actual_PID_parent_ACK_before_allocation':True,'delta_packages_hash_CRC_localACK_before_more_science':True,'same_assignment_GET_only_preservation_no_scientific_retry':True,'exactrelease_only_after_actualchildended_andallartifactspreserved':True,'independent_reader_frozen_complete_or_partial':True,'source_hashes':{(ROOT/'work'/n).relative_to(ROOT).as_posix():sha(ROOT/'work'/n) for n in sources},'payload_sha256':payload['sha256'],'frozen_original_checks':frozen_checks()};put(OUT/'Launch_Readiness_Audit.json',ready)
    print(json.dumps({'payload_bytes':payload['bytes'],'members':payload['members'],'all3prefix_lengths':[x['prefix_tokens'] for x in messages],'max_generation':384,'one_original_profile_T4':'READY_FOR_FRESH_PROFILE_AND_PROCESS_GATES','GPU_allocations_so_far':0}))
if __name__=='__main__':main()
