# Candidate-process research decision

The stopped VCSA and episode/root-branch proposals remain stopped. This proposal asks a different, measurable question: can a current-state model predict the original verifier's acceptance and global response across the original bus/Q candidate grid, and prioritize useful candidates without spending another exhaustive physical search at every decision?

The evidence supports testing a dense one-step target, not promising superiority. There are 38,727 unique physically measured state/action outcomes in 238 observed states, with 225 states containing both accepted and rejected candidates. Full successor voltage/angle vectors were not saved, so AC-residual supervision, a dynamics model and successful long-horizon rewards cannot be inferred. All 31 previously fixed historical TRAIN worlds and the original invalid input remain in the denominator. These worlds are development data, not unused confirmation.

## Input and measurement boundary

All 311 unique saved current observations round-trip exactly through the typed raw codec. The declared saved tables omit name, geo, geometry, coords and std_type; this is not a complete pandapower network serialization. For this unchanged testbed, 342 actual prefix checks independently prove which appended shunts implement the original added-support cap. The derived current-support vector is available to every comparator and never credited to the LLM. Future live inputs must call the original getter on the actual network rather than infer roles from unproved rows.

The split was fixed before model outcomes: ascending existing world SHA gives 23 optimization and eight development-held worlds, keeping every state's actions in its world. Optimization has 239 current inputs, 187 target states and 30,510 measured actions. Held development has 72 inputs, 51 target states and 8,217 actions. Four missing reused ledgers and 73 unlabelled current states remain explicit. Raw inputs, metadata and targets are separate. Forward inputs exclude world/scenario/branch identifiers and all AFTER metrics.

All 279 missing AFTER outcomes remain unknown. The 219 original pre-PF cap rejections have unreported convergence; no convergence-failure target is invented. The known scope and cap prechecks are common to all arms. Remaining actually reported solver failures contribute only their known acceptance/convergence labels, with no fabricated voltage response.

## Scientific distinction and prior art

[Sobolev Training](https://papers.neurips.cc/paper_files/paper/2017/hash/758a06618c69880a6cee5314ee42d52f-Abstract.html) trains function outputs together with available derivative targets. Here only finite differences between actually measured adjacent Q values exist. Their scaled differences can constrain candidate-response predictions, but are not analytic AC derivatives; this consistency term by itself is not novel.

[Time-LLM](https://arxiv.org/html/2310.01728) motivates reprogramming numerical observations into a pretrained backbone. It does not establish that pretraining adds value on these grid states. The [critical no-LM ablation study](https://arxiv.org/abs/2406.16964) found that simpler replacements often matched or improved the forecasting methods it examined. That finding motivates a strong numerical arm, frozen-backbone/head control and eventual random-backbone or no-LM attribution rather than assuming an LLM benefit.

Physics-aware power-flow/OPF work motivates physically measured targets and verification; its voltage-vector/residual data and large training infrastructure do not exist in this dataset. A future method claim would concern demonstrated incremental pretrained-body value for verified candidate-response prioritization under exact current scope and support limits. Combining known components or naming a new loss is insufficient to establish novelty.

## Fixed first numerical study

Before any new training, implement and verify the compiler, masks, checkpoint reload and all gradient paths. The numerical control receives every declared typed record plus 13 current bus channels and the observed active line/transformer graph. Semantic table/column conditioning and node normalization use optimization inputs only. Raw values remain preserved; FP32 conversion, pooled cells, one graph message step and omitted graph physics are disclosed architectural limitations. Numeric strings, structural records and missing-value tags remain typed inputs.

Capacity is fixed analytically near the original adapter's measured 8,798,208 parameters before outcomes. This is a numerical capacity reference, not complete FLOP/backbone/precision equivalence. Five epochs, one seed, one optimizer specification and only the final checkpoint are allowed. Train on recorded acceptance/convergence/one-step UV-zero masks, standardized measured UV/deficit/vmin/upper-margin gains, and their supported adjacent-Q differences. No monotonicity or unsupported Q interpolation is imposed. All arms in a later attribution study must receive the same objective and information.

Evaluation first reports world-grouped measured-label error and candidate-priority diagnostics at all predeclared K values, with unmeasured predictions retained as unknown. Saved-oracle inclusion is a diagnostic, not a new physical rollout, deployment latency or superiority over D-SE. One-step feasibility does not imply global recovery. No extra PF calls or private export are needed for this numerical measurement study.

## Conditional pretrained intervention

If the numerical data/compiler study completes honestly, a separately frozen internal-body experiment may use the same current-table encoder and 118 bus representations, explicit Q grid and candidate-response head. A compact structured-token interface must be genuinely implemented; the prior binary prompt fit does not certify it. Train an independently named copy of the original LoRA attention/MLP parameters while preserving the original adapter/base files and tensors. One forward should predict all candidates rather than require 38,727 separate long-context calls.

Required gates include an actual two-step CUDA/gradient/memory/checkpoint integration, exact source/environment/input hashes, a shared target/decoder, parameter/FLOP/precision accounting, frozen-LM-head and no-LM controls, all failure and preparation costs, and final-checkpoint-only evaluation. No GPU is allocated solely because it is idle. Training-time and VRAM estimates must come from that genuine new integration, not VCSA timings. Historical profile eligibility is not current availability.

No new learned performance campaign automatically follows software checks. Matched fresh-state trajectories must compare literal D-SE, both original branches and both-branch costs, plus common-guard and strong numerical counterparts. Continuous independent physical replay, full inference/solver/preparation/failure ledgers and genuinely unused authorized confirmation remain necessary. The eight historical development worlds and sealed 62 bank are not silently relabelled fresh holdouts. Positive outcomes, 90% success and thesis completion are not guaranteed.
