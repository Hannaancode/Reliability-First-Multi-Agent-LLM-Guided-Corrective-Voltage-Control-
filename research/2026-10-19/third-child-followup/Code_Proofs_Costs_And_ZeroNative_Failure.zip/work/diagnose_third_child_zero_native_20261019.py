"""Independent closed-evidence diagnosis; no worker, PF or model execution."""
import ast,json
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from equal_operation_benchmark_v2 import process

def main():
    b=R/'outputs/third_child_fixed_four_followup_acquisition_20261019'
    assert read(b/'Completion.json')['exit_codes']=={'warm':1,'audit':0}
    for phase in ['warm','audit']:
        end=read(b/(phase+'_End_ACK.json'))
        assert end['actual_owned_chain_ended'] and process(end['actual_pid']) is None and process(end['launcher_pid']) is None
        assert end['closed_manifest_sha256']==sha(b/phase/'Closed_Manifest.json')
        for rel,h in read(b/phase/'Closed_Manifest.json')['members'].items():assert sha(b/phase/rel)==h
    assert process(15628) is None and process(19344) is None
    failure=read(b/'warm/Failure.json');assert "KeyError: 'source_edge'" in failure['traceback'] and failure['actual_costs_if_available'] is None
    assert not (b/'warm/scientific.jsonl').exists() and not (b/'warm/capsules.bin').exists() and not (b/'reservations').exists()
    assert not any((b/p).exists() for p in ['cold_1','cold_2','cold_3'])
    report=read(b/'audit/Independent_Audit.json')
    assert report['status']=='PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE' and all(v==0 for v in report['counts'].values())
    source=R/'work/exact_two_paid_query_engineering_20261018.py';tree=ast.parse(source.read_text('utf-8'))
    worker=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worker')
    references=[n for n in ast.walk(worker) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='source' and isinstance(n.slice,ast.Constant) and n.slice.value=='source_edge']
    reservation=next(n for n in ast.walk(worker) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='reservations' for t in n.targets) and isinstance(n.value,ast.Call))
    evidence=next(n for n in ast.walk(worker) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='e' for t in n.targets) and isinstance(n.value,ast.Call))
    assert len(references)==1 and references[0].lineno<reservation.lineno<evidence.lineno
    out=R/'outputs/third_child_zero_native_diagnosis_20261019';out.mkdir(exist_ok=False)
    put(out/'Independent_Diagnosis.json',{'status':'PASS_TERMINAL_SOURCE_METADATA_FAILURE_BEFORE_RESERVATION_OR_PF','actual_primary_replay_intents_returns_exceptions':0,'all4_queries_unentered':True,'prior_workers_coordinator_reader_ended':True,'original_failure_sha256':sha(b/'warm/Failure.json'),'original_audit_sha256':sha(b/'audit/Independent_Audit.json'),'source_order_proof':{'source_edge_read_line':references[0].lineno,'reservation_line':reservation.lineno,'evidence_constructor_line':evidence.lineno,'source_sha256':sha(source)},'new_scientific_calls':0,'classification':'Software input-metadata failure, not physical rejection or infeasibility. All4physical outcomes remain UNKNOWN.','next_conditions':'No old worker/protocol/source restart or editing. A distinct prospective input/namespace may add source_edge metadata only after exact NET/cursor/nonmetadata/source/frontier equivalence and actual warm-state construction pass; no scientific call can be repeated.'})
    print(json.dumps({'zero_native':'PASS','all4_outcomes':'UNKNOWN','old_owners':'ENDED'}))

if __name__=='__main__':main()
