"""Freeze one native four-case original-controller study before model outcomes.

The original controller algorithm is not modified. Native/source-fidelity track
and future shared-guard external benchmarks remain explicitly distinct.
"""
import ast, hashlib, json, os, zipfile
from datetime import datetime, timezone
from pathlib import Path
from reflection118_chronological_core_20261022 import R,read,put,sha
P=R/'outputs/reflection118_chronological_preparation_20261022'


def script(name,s):
    ast.parse(s);p=R/'work'/name
    with p.open('x',encoding='utf-8') as f:f.write(s);f.flush();os.fsync(f.fileno())


def main():
    assert not (P/'Frozen_Engineering_Protocol.json').exists()
    assert read(P/'Labelled_Software_Checks.json')['status'].startswith('PASS_')
    assert read(P/'Additional_Coverage_Readiness.json')['status'].startswith('PASS_')
    assert read(R/'outputs/registered_severe_federation_root_binding_20261022/independent_audit/Independent_Audit.json')['status'].startswith('PASS_')
    old=read(R/'outputs/original_reflection_saved_root_preparation_v2_20261022/Frozen_Engineering_Protocol.json')
    host=(R/'work/run_original_reflection_saved_roots_colab_v2_20261022.py').read_text('utf-8')
    for a,b in [('original_reflection_saved_root_preparation_v2_20261022','reflection118_chronological_preparation_20261022'),
                ('original_reflection_saved_root_execution_v2_20261022','r118chrono_20261022'),
                ('original_reflection_saved_roots_guardian_v2_20261022.py','reflection118_model_service_guardian_20261022.py'),
                ('hiergrid-original-reflection-native-role','hiergrid-original-reflection118-chronological')]:
        assert a in host;host=host.replace(a,b)
    host=host.replace('import argparse,ast,base64,hashlib,json,logging,os,time,uuid,zipfile',
                      'import argparse,ast,base64,hashlib,json,logging,os,time,uuid,zipfile,subprocess')
    needle='    save()\n    try:\n        assert ready[\'passed\']'
    bridge='''    local_child=None;sent=set()
    def bridge():
        nonlocal local_child
        study=OUT/'staged/study';local=OUT/'local_controller'
        if local_child is None and (study/'primary_Loader_Proof.json').exists():
            local_log=(OUT/'local_controller.log').open('x',encoding='utf-8')
            local_child=subprocess.Popen([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(ROOT/'work/run_reflection118_chronological_local_20261022.py')],cwd=ROOT,stdout=local_log,stderr=local_log,creationflags=subprocess.CREATE_NO_WINDOW)
            state['local_launcher_pid']=local_child.pid;state['local_started_unix']=time.time();save()
            tick=time.monotonic()
            while not (local/'owner.claim').exists():
                assert local_child.poll() is None and time.monotonic()-tick<60;time.sleep(.1)
            claim=read(local/'owner.claim')
            from coordinate_native_inverter_linear_reference_20261020 import process
            actual=process(claim['actual_pid']);parent=process(claim['parent_pid'])
            assert actual and parent and claim['parent_pid']==local_child.pid==actual['ParentProcessId']
            assert 'run_reflection118_chronological_local_20261022.py' in actual['CommandLine']
            assert claim['source_sha256']==digest((ROOT/'work/run_reflection118_chronological_local_20261022.py').read_bytes())
            preserve(local/'Launcher_ACK.json',json.dumps({'actual_pid':claim['actual_pid'],'parent_pid':claim['parent_pid'],'actual_command':actual['CommandLine'],'fresh_exact_source_PID_parent_command':True},indent=2).encode())
            state['local_actual_pid']=claim['actual_pid'];save()
        if local_child is None:return
        for path in sorted((local/'requests').glob('request_*.json')):
            if path.name not in sent:
                req=read(path);content('PUT','content/hiergrid_execution/outputs/public_size_requests/'+path.name,{'type':'file','format':'text','content':json.dumps(req)})
                sent.add(path.name)
        for path in sorted(study.glob('response_*.json')):
            dest=local/'responses'/path.name
            if not dest.exists():preserve(dest,path.read_bytes())
        if local_child.poll() is not None and not state.get('local_STOP_sent'):
            claim=read(local/'owner.claim')
            from coordinate_native_inverter_linear_reference_20261020 import process
            assert process(claim['actual_pid']) is None and process(local_child.pid) is None
            stop={'local_exit_code':local_child.returncode,'actual_local_owned_chain_ended':True,'local_result_present':(local/'Results.json').exists(),'local_failure_retained':(local/'Failure.json').exists()}
            content('PUT','content/hiergrid_execution/outputs/public_size_requests/STOP.json',{'type':'file','format':'text','content':json.dumps(stop)})
            preserve(OUT/'Local_End_ACK.json',json.dumps(stop,indent=2).encode());state['local_STOP_sent']=True;save()
    save()
    try:
        assert ready['passed']'''
    assert host.count(needle)==1;host=host.replace(needle,bridge)
    assert host.count('            observe()\n')==1
    host=host.replace('            observe()\n','            observe()\n            bridge()\n')
    needle="            assert exit_info['scientific_process_ended'];closed();safe_release=True"
    replacement="""            assert exit_info['scientific_process_ended'];closed()
            if local_child is not None and local_child.poll() is None:
                preserve(OUT/'local_controller/Remote_Ended.json',json.dumps({'remote_actual_process_ended':True}).encode())
                local_child.wait(timeout=330)
                bridge()
            safe_release=True"""
    assert host.count(needle)==1;host=host.replace(needle,replacement)
    # No automatic replacement of a local or remote child on timeout/failure.
    assert host.count('client.assign(')==1
    script('run_reflection118_chronological_colab_20261022.py',host)
    guardian=(R/'work/original_reflection_saved_roots_guardian_v2_20261022.py').read_text('utf-8')
    guardian=guardian.replace('run_original_reflection_saved_roots_remote_v2_20261022.py','run_reflection118_model_service_remote_20261022.py')
    script('reflection118_model_service_guardian_20261022.py',guardian)
    # Keep generated coordination deliberately small; exact ACK supervisor is reused.
    coordinator='''"""One exact native study owner followed by its sole independent reader."""
import json,os,subprocess
from pathlib import Path
from reflection118_chronological_core_20261022 import R,put,sha
P=R/'outputs/reflection118_chronological_preparation_20261022'
O=R/'outputs/r118chrono_handoff_20261022'
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf-8') as f:
   code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_atomic_source_owner_20261022.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),{'exit_code':code});assert code==0,'Preserve all failed/partial evidence; no retry'
 put(O/'Completion.json',{'status':'ACTUAL_STUDY_AND_SOLE_READER_TERMINAL'})
if __name__=='__main__':main()
'''
    script('coordinate_reflection118_chronological_20261022.py',coordinator)
    local_names=['reflection118_chronological_core_20261022.py','run_reflection118_chronological_local_20261022.py',
        'frozen_physics_loader.py','prior_physical_query_footprints_20261018.py','resolve_original_role_input_component_collisions_20261022.py']
    original=dict(old['original_serving_sources'])
    for n in ['work/e/pack/scripts/phase2d_iterative_blackboard_v0.py','work/e/audit/phase2d_iterative_blackboard_v2_deficit_aware.py']:
        original[n]=sha(R/n)
    protocol={
        'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PROSPECTIVE_FIXED_NATIVE_FOUR_REGISTERED_CASE_SYSTEM_STUDY',
        'question':'Complete chronological original Reflection-v4 HG-VF and original no-LLM fallback-first branches on the same four registered severe118 roots. Whole branch outcomes and BOTH costs, no guaranteed win.',
        'case_order':read(R/'outputs/registered_severe_federation_root_binding_20261022/Result.json')['cases'],
        'selection':'All four previously fixed severe1.5-load development roots in source order; not outcome-selected from new model runs. Remaining199registrations unresolved, not a full137or203cohort score.',
        'profiles':old['profiles'],'base_for_new_experiment':old['base_for_new_experiment'],
        'private_adapter_tokenizer_unchanged':old['private_adapter_tokenizer_unchanged'],'original_serving_sources':original,
        'local_source_hashes':{'work/'+n:sha(R/'work'/n) for n in local_names}|original,
        'seed':20261022,'science_process_seconds':9000,'setup_seconds':1800,'collector_seconds':10200,
        'local_controller_seconds':7200,'local_binary_bound_bytes':8*1024**3,'reader_seconds':7200,
        'native_settings':'All original function ASTs;25iterations, original candidate menus,9Qgrid,450cap, original1.06hard guard/score/source-priority/conditional reprompt/unchanged HG-SEselector. Strict0.95/1.05UV/OV separately retained. No normal-band relabelling.',
        'engineering_gate':'At first committed action per branch preserve actual full NET/result/feedback/failed history/RNG/call cursors. Reconstruct original source from initial state using exactly saved primary replies/physics, compare checkpoint before any additional model/PF. No scientific repeat.',
        'model_gate':'Unchanged original trained private LoRA, exact original generate_response AST, actual causal full messages, no truncation,384greedy maximum. Fresh full loader cold first prompt must reproduce exact tokens; immutable quantized/private state inventories. No training/optimizer.',
        'nonrepeat_gate':'Exact root initialization reused. Query frozen60426index,9297additional attempts and738saved snapshots by necessary component+load/outage then exact full frames/kwargs. Known exact return reused; any unresolved matching/failed input stops before new PF. Scoped named histories, not universal history claim.',
        'preservation':'One remote service/one local controller/one host/one coordinator/one reader. Every actual request/response and PF before/return/exception saved; remote chunks locally hash-checked/ACKed. Hard time and binary bounds; no retries/extensions/replacement.',
        'independent_gate':'First replay only newly returned PF identities, all numerical returned table fields1e-10/KCL1e-7; saved original complete source-policy replay. Partial full-cohort comparisons UNKNOWN.',
        'performance_gate':'All8branches source/cost/physics/cold complete, report every win/tie/loss/strictOV. Improvement hypothesis survives only>=2HG-VFUVwinsand0UVloss vsDFF, no additional strictOV. It is development mechanism evidence, not all-method victory.',
        'external_methods':'No native13inverter/322busactor silently transferred. Compatible source-grounded trained common-actuator adaptations remain pending separate protocol. This study is original-system native track, not finished external comparison.',
        'literal_DSE':'DFF-ALT and full literal D-SE are separate primary comparator obligations, not replaced by this two-original-branch reconstruction.',
        'on_failed_measured_gate':'Stop specified intervention; preserve failures/partial/unknown. No Q/guard/prompt/checkpoint/seed/budget outcome rescue.',
        'authority':'Direct human asks restore actual Reflection-v4, compare identical federation118cases and use GPU. Necessary unchanged private weights/causal prompts may be served in own original account. No credentials, NET, training data or locked bank exported.',
        'guaranteed_win':False,'fallback_after_denial':False,'same_profile_single_assignment_only':True}
    put(P/'Frozen_Engineering_Protocol.json',protocol)
    put(P/'Direct_Human_Authority.json',{'direct_requests':['finish comparison then improve our model; run others on118federation','actualReflection-v4 original paper benchmark; use GPUs'],
        'scope':protocol['authority'],'purchases_or_account_rotation':False})
    remote_names=['run_reflection118_model_service_remote_20261022.py','reflection118_model_service_guardian_20261022.py',
        'original_reflection_serving_pure_20261022.py','original_reflection_tokenizer_tensor_view_v2_20261022.py',
        'native13_lora_setup_remote_v2_20261020.py','native13_lora_environment_check_v2_20261020.py',
        'candidate_process_pretrained_loader_native13_v2_20261020.py','public_size_u61_preservation.py',
        'frozen_gpu_requirements.txt','frozen_dependency_closure.txt','uv_bootstrap_version.txt']
    payload={'work/'+n:R/'work'/n for n in remote_names}
    payload.update({n:R/n for n in original})
    adapter=R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for n,h in protocol['private_adapter_tokenizer_unchanged'].items():assert sha(adapter/n)==h;payload[adapter.relative_to(R).as_posix()+'/'+n]=adapter/n
    payload['prep/protocol.json']=P/'Frozen_Engineering_Protocol.json'
    members={n:{'bytes':f.stat().st_size,'sha256':sha(f)} for n,f in payload.items()}
    archive=P/'Private_Adapter_And_Causal_Service.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,f in payload.items():z.write(f,n)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json',json.dumps(members,indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for n,m in members.items():assert len(z.read(n))==m['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
    put(P/'Cloud_Payload_Manifest.json',{'archive':archive.relative_to(R).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive),
        'members':len(members)+1,'human_authority_source':(P/'Direct_Human_Authority.json').relative_to(R).as_posix(),
        'human_authority_sha256':sha(P/'Direct_Human_Authority.json'),'private_adapter_tokenizer_authorized':True,
        'credentials_network_bank_private_TRAIN_labels_uploaded':False})
    for kind,source,out,coord,python,bound in [
        ('Primary','run_reflection118_chronological_colab_20261022.py','r118chrono_20261022','r118chrono_coordination_20261022','work/colab_access_env/Scripts/python.exe',13500),
        ('Reader','audit_reflection118_chronological_20261022.py','r118chrono_audit_20261022','r118chrono_reader_coordination_20261022','work/vcsa_module_env/Scripts/python.exe',7500)]:
        put(P/(kind+'_Owner_Protocol.json'),{'single_owner':{'source':'work/'+source,'sha256':sha(R/'work'/source),'python':python,
            'output':'outputs/'+out,'coordination':'outputs/'+coord,'bound_seconds':bound},'require_ended_claims':[]})
    put(P/'Independent_Reader_Lock.json',{'source':'work/audit_reflection118_chronological_20261022.py',
        'sha256':sha(R/'work/audit_reflection118_chronological_20261022.py'),'first_new_return_replay_only':True,'new_model_calls':0})
    names=local_names+remote_names+['run_reflection118_chronological_colab_20261022.py','coordinate_reflection118_chronological_20261022.py',
        'audit_reflection118_chronological_20261022.py','coordinate_atomic_source_owner_20261022.py','public_size_local_preservation_v2.py',
        'check_reflection118_chronological_software_20261022.py','prepare_reflection118_additional_prior_coverage_v2_20261022.py','freeze_reflection118_chronological_20261022.py']
    hashes={'work/'+n:sha(R/'work'/n) for n in names}|original
    hashes.update({(P/n).relative_to(R).as_posix():sha(P/n) for n in ['Frozen_Engineering_Protocol.json','Additional_Prior_Attempt_References.json','Labelled_Software_Checks.json','Independent_Reader_Lock.json']})
    put(P/'Launch_Readiness_Audit.json',{'passed':True,'status':'FROZEN_ACTUAL_CHRONOLOGICAL_CONTROLLER_STUDY_NOT_A_PERFORMANCE_PASS',
        'source_hashes':hashes,'software_checks':9,'registered_roots':4,'new_model_PF_calls_before_freeze':0,
        'one_assignment_only':True,'partial_gates_UNKNOWN':True})
    print(json.dumps({'frozen':True,'cases':4,'branches':8,'GPU_assignments_started':0,'no_performance_result_yet':True}))


if __name__=='__main__':main()
