"""New snapshot-adapter software checks only, zero NET deserialization/science."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
from nonlinear500_paid_snapshot_20261029 import PaidSnapshot
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_paid_snapshot_preparation_20261029'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def main():
    O.mkdir(exist_ok=False);m=R/'outputs/nonlinear500_paid_registry_20261029/Frozen_Registry_Manifest.json'
    expected=json.loads((R/'outputs/nonlinear13_first_proposal_paid_join_v2_20261029/Exact_Lookup.json').read_text())
    signature,kwargs=expected['key'].split('|',1);kwargs=json.loads(kwargs)
    put(O/'Protocol.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),source_sha256=sha(R/'work/nonlinear500_paid_snapshot_20261029.py'),
       test_source_sha256=sha(__file__),manifest_sha256=sha(m),scope='New immutable snapshot and mutation/deny/miss paths; no scientific audit replay',
       planned_checks=['same saved exact lookup','private return mutation isolation','blocked missing-afterNET','wrong initializer blocks','finite miss gives no newPF permission','metadata loaded once per snapshot']))
    cache=PaidSnapshot(R,sha(m));metadata=cache.costs['metadata_bytes_read'];a=cache.lookup(signature,kwargs);assert a==expected
    a['reuse']['after']['path']='deliberately-mutated-caller-copy'
    assert cache.lookup(signature,kwargs)==expected
    denied=cache.lookup('43b0cf41b2d4e52bde8e4594f4fc284e6d3004d721184c1758fe169d92a138a9',kwargs)
    assert denied['status']=='BLOCKED_PREVIOUSLY_ATTEMPTED_NO_ELIGIBLE_EXACT_KEY' and denied['new_PF_permitted'] is False
    wrong=cache.lookup(signature,{'algorithm':'bfsw','init':'flat'});assert wrong['status'].startswith('BLOCKED_') and wrong['new_PF_permitted'] is False
    absent=cache.lookup('0'*64,kwargs);assert absent['status']=='MISS_IN_FINITE_SCOPED_REGISTRY' and absent['new_PF_permitted'] is False and absent['universal_absence_claim'] is False
    assert cache.costs['metadata_bytes_read']==metadata
    put(O/'Results.json',dict(status='PASS_SIX_NEW_SNAPSHOT_ADAPTER_SOFTWARE_CHECKS',checks_passed=6,
        snapshot_identity=cache.identity,actual_IO_costs=cache.costs,NET_deserializations=0,PF_model_optimizer_calls=0,
        limits='No new history coverage, physics or whole-worker admission. Old metadata/evidence unchanged. Selected payload bytes still verified on every lookup.'))
    print(json.dumps(dict(status='PASS',checks=6,new_science=0)))
if __name__=='__main__':main()
