"""Independent derivative/LP dual/source/cap verification and one charged physical replay."""
import hashlib,json,os,pickle,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/native_inverter_linear_reference_20261020';OUT=SRC/'independent_audit';PREP=ROOT/'outputs/native_inverter_linear_reference_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();costs={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'derivative_factor_solve_LP_model_GPU_calls':0}
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    try:
        import numpy as np
        import pandapower as pp
        from pandapower.pypower.makeSbus import makeSbus
        from candidate_process_evidence_utils import frozen_checks
        p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'))
        for f,h in p['sources'].items():assert sha(ROOT/'work'/f)==h
        for f,h in p['inputs'].items():assert sha(ROOT/f)==h
        manifest=json.loads((SRC/'Closed_Manifest.json').read_text(encoding='utf-8'))
        for f in manifest['files']:assert (SRC/f['path']).stat().st_size==f['bytes'] and sha(SRC/f['path'])==f['sha256']
        prev='0'*64;events=[]
        for line in (SRC/'Journal.jsonl').read_text(encoding='utf-8').splitlines():
            r=json.loads(line);e=r['event'];assert e['previous']==prev;assert hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest()==r['sha256'];prev=r['sha256'];events.append(e)
        assert prev==manifest['journal_last_sha256']
        r=json.loads((SRC/'Result.json').read_text(encoding='utf-8'));z=np.load(SRC/'Linear_Problem.npz');sol=np.load(SRC/'LP_Solution.npz');q=np.load(SRC/'Absolute_Q_Mvar.npy')
        assert r['costs']['public_derivative_returns']==r['costs']['LU_factorizations']==r['costs']['LP_returns']==1 and r['costs']['linear_RHS_solves']==38
        y=z['Y'];v=z['V'];pq=z['pq'];ii=y@v;norm=v/np.abs(v)
        # Separate dense complex-power calculus, no public derivative call or solve.
        dm=np.diag(v)@np.conj(y@np.diag(norm))+np.diag(np.conj(ii))@np.diag(norm)
        da=1j*np.diag(v)@np.conj(np.diag(ii)-y@np.diag(v))
        j=np.block([[da[np.ix_(pq,pq)].real,dm[np.ix_(pq,pq)].real],[da[np.ix_(pq,pq)].imag,dm[np.ix_(pq,pq)].imag]])
        derivative_delta=float(np.max(np.abs(j-z['J'])));assert np.allclose(j,z['J'],rtol=1e-12,atol=1e-10)
        residual=float(np.max(np.abs(j@z['response']-z['rhs'])));assert residual<=1e-9
        full=np.zeros((322,38));full[pq]=z['response'][321:];s=full[z['lookup']];assert np.array_equal(s,z['sensitivity'])
        with (SRC/'Candidate_Before.pkl').open('rb') as f:net=pickle.load(f)
        tpa=ROOT/'outputs/tpa_native_second_identity_engineering_20261020'
        with (tpa/'PF0_before.pkl').open('rb') as f:root=pickle.load(f)
        for name in ['bus','line','trafo','load','ext_grid','gen','shunt','switch']:assert net[name].equals(root[name])
        assert net.sgen.drop(columns=['q_mvar']).equals(root.sgen.drop(columns=['q_mvar']))
        maxima=np.array(json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text(encoding='utf-8'))['native_column_max'])
        caps=.8*np.sqrt((1.2*maxima)**2-root.sgen.p_mw.to_numpy()**2);assert np.array_equal(caps,z['caps']);assert np.array_equal(root.sgen.q_mvar.to_numpy(),z['root_q']);assert np.array_equal(q,net.sgen.q_mvar.to_numpy())
        independent_rhs=np.zeros((642,38));index={int(bus):i for i,bus in enumerate(pq)}
        for col,bus in enumerate(root.sgen.bus):independent_rhs[321+index[int(z['lookup'][int(bus)])],col]=1/root._ppc['baseMVA']
        assert np.array_equal(independent_rhs,z['rhs'])
        base=z['vm']-s@z['root_q'];n=322;m=38
        aa=np.zeros((3*n+2*m,n+2*m));bb=np.r_[1-base,base-1,np.zeros(2*m),1.05-base]
        aa[:n,:m]=s;aa[:n,m:m+n]=-np.eye(n);aa[n:2*n,:m]=-s;aa[n:2*n,m:m+n]=-np.eye(n)
        aa[2*n:2*n+m,:m]=np.eye(m);aa[2*n:2*n+m,m+n:]=-np.eye(m)
        aa[2*n+m:2*n+2*m,:m]=-np.eye(m);aa[2*n+m:2*n+2*m,m+n:]=-np.eye(m);aa[2*n+2*m:,:m]=s
        cc=np.r_[np.zeros(m),np.ones(n)/n,np.full(m,.1/m)]
        assert np.array_equal(aa,z['A']) and np.array_equal(bb,z['b']) and np.array_equal(cc,z['c'])
        xx=sol['x'];dy=sol['ineq_marginals'];dl=sol['lower_marginals'];du=sol['upper_marginals'];lb=np.r_[-caps,np.zeros(n+m)]
        primal=max(float(np.max(aa@xx-bb)),float(np.max(lb-xx)),float(np.max(xx[:m]-caps)))
        stationarity=float(np.max(np.abs(cc-aa.T@dy-dl-du)))
        dual=float(bb@dy+lb@dl+caps@du[:m]);gap=float(cc@xx-dual)
        assert primal<=1e-7 and stationarity<=1e-7 and abs(gap)<=1e-7
        assert np.max(dy)<=1e-10 and np.min(dl)>=-1e-10 and np.max(du)<=1e-10 and np.max(np.abs(du[m:]))<=1e-10
        assert np.array_equal(xx[:m],q) and np.all(np.abs(q)<=caps+1e-10)
        stored=np.load(SRC/'Candidate_Fields.npz');field_delta=0.;kcl=None
        if r['reused_identity'] is None:
            costs['PF_attempts']+=1;t=time.monotonic()
            try:pp.runpp(net)
            except BaseException:costs['PF_exceptions']+=1;raise
            costs['PF_returns']+=1;assert net.converged
            for name in stored.files:
                actual=net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float);expected=stored[name];assert actual.shape==expected.shape and np.allclose(actual,expected,rtol=0,atol=1e-9,equal_nan=True)
                finite=np.isfinite(actual)&np.isfinite(expected)
                if finite.any():field_delta=max(field_delta,float(np.max(np.abs(actual[finite]-expected[finite]))))
            vv=net._ppc['internal']['V'];yy=net._ppc['internal']['Ybus'];ss=makeSbus(net._ppc['baseMVA'],net._ppc['bus'],net._ppc['gen']);kcl=float(np.max(np.abs(vv*np.conj(yy@vv)-ss)));assert kcl<=1e-7
            replay_seconds=time.monotonic()-t
        else:
            old=np.load(tpa/f"PF{r['reused_identity']}_fields.npz")
            assert all(np.array_equal(stored[n],old[n],equal_nan=True) for n in stored.files);replay_seconds=0.
        vm=stored['res_bus'][:,0];uv=int((vm<.95).sum());ov=int((vm>1.05).sum());loss=float(np.abs(vm-1).mean()+.1*np.abs(q).mean())
        assert (uv,ov)==(r['actual']['UV'],r['actual']['OV']) and abs(loss-r['actual']['native_L1_plus_q_cost'])<1e-14
        assert r['actual_upper_protection_pass']==bool(vm.max()<=1.05+1e-8)
        assert sum(e['kind']=='PF_attempt' for e in events)==r['costs']['PF_attempts'] and sum(e['kind']=='PF_return' for e in events)==r['costs']['PF_returns']
        assert time.monotonic()-start<p['reader_bound_seconds']
        put(OUT/'Frozen_After.json',frozen_checks());result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_SOURCE_CACHED_ROOT_NATIVE_CAPS_DERIVATIVE_EQUATIONS_LP_DUAL_AND_FULL_PHYSICS_REPLAY','costs':costs,'source_costs':r['costs'],'derivative_delta':derivative_delta,'linear_residual':residual,'LP_primal_violation':primal,'LP_stationarity_residual':stationarity,'LP_duality_gap':gap,'all_numeric_field_delta_max':field_delta,'KCL_max_pu':kcl,'replay_seconds':replay_seconds,'actual':r['actual'],'total_new_PF_attempts':r['costs']['PF_attempts']+costs['PF_attempts'],'workflow_seconds':time.monotonic()-start,'LLM_or_matched_information_superiority_claim':False}
        put(OUT/'Independent_Audit.json',result);print(json.dumps({'independent':'PASS','actual':r['actual'],'new_PF_total':result['total_new_PF_attempts'],'all_fields_delta':field_delta}))
    except BaseException as e:put(OUT/'Failure.json',{'failure':str(e),'traceback':traceback.format_exc(),'costs':costs});raise
if __name__=='__main__':main()
