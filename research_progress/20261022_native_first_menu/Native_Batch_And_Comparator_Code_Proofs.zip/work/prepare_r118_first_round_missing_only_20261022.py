"""Freeze an outcome-independent, newly unexecuted native baseline batch."""
import ast,copy,json,pickle,sys
from pathlib import Path
from datetime import datetime,timezone
from reflection118_chronological_core_20261022 import *
P=R/'outputs/r118_first_round_missing_only_preparation_20261022'
def main():
    P.mkdir(exist_ok=False)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    from frozen_physics_loader import load_stack,AUDIT
    from run_reflection118_chronological_local_20261022 import necessary
    _,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    f='outputs/r118_all4_first_round_attempt_coverage_20261022/All2034_Classifications_With_Attempt_Capsules.json'
    rows=read(R/f)['rows'];scope=read(R/'outputs/r118_all4_first_round_attempt_coverage_20261022/Current_Attempt_Coverage.json')
    assert len(rows)==2034 and scope['new_unknown_collisions']==0 and scope['current_before_capsules']==404
    assert scope['counts']=={'EXACT_CURRENT_PAID80_RETURN_REUSABLE':42,'NO_MATCH_IN_NAMED_TRACKED_SCOPE_NOT_GLOBAL_ABSENCE':1989,'PRIOR_INPUT_OR_CONTRACT_COLLISION_UNKNOWN_NO_AUTOMATIC_CALL':3}
    old=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json')
    for n,h in old['original_serving_sources'].items():assert sha(R/n)==h
    assert runner.rescue.Q_SWEEP==[25.,50.,75.,100.,125.,150.,200.,250.,300.] and runner.rescue.MAX_ABS_Q_PER_BUS==450. and runner.rescue.HARD_OV==1.06
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    assert [r['case_id'] for r in roots]==old['case_order']
    signatures=[]
    for r in roots:
        assert sha(R/r['solved_payload'])==r['payload_sha256']
        net=pickle.loads((R/r['solved_payload']).read_bytes())['net'];signatures.append(canonical(necessary(net)))
    assert len(set(signatures))==4
    # Actual cached-original-verifier admission, using an already audited return.
    d=R/'outputs/r118chrono_20261022/local_controller'/roots[0]['case_id']/'no_llm_fallback_first'
    paid=read(d/'pf_000001.json');before=decode(d,paid['before']);after=decode(d,paid['after'])
    root=pickle.loads((R/roots[0]['solved_payload']).read_bytes())['net']
    action=rows[0]['action'];expected=copy.deepcopy(root);runner.rescue.apply_action(expected,action);frames_equal(expected,before)
    calls=[]
    def cached(n,**kw):
        try:assert kw==paid['kwargs'];frames_equal(n,before);restore_exact(n,after);calls.append(1)
        except Exception as e:raise BaseException('CACHE_ADMISSION_ERROR: '+repr(e)) from e
    native=pp.runpp;pp.runpp=cached
    try:a=runner.rescue.verify_action(copy.deepcopy(root),action);b=runner.rescue.verify_action(copy.deepcopy(root),action)
    finally:pp.runpp=native
    assert a==b and len(calls)==2
    worker=R/'work/run_r118_first_round_missing_only_20261022.py';reader=R/'work/audit_r118_first_round_missing_only_20261022.py'
    for source in [worker,reader]:ast.parse(source.read_text('utf-8'))
    sources=[worker,reader,Path(__file__),R/'work/frozen_physics_loader.py',R/'work/reflection118_chronological_core_20261022.py']
    pins={p.relative_to(R).as_posix():sha(p) for p in sources};pins.update(old['original_serving_sources'])
    inputs=[f,'outputs/r118_all4_first_round_attempt_coverage_20261022/Current_Attempt_Coverage.json','outputs/r118_all4_first_round_query_frontier_20261022/Frontier_Summary.json','outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json']
    put(P/'Protocol.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='PROSPECTIVE_ALL4_SOURCE_FIRST_ROUND_MISSING_ONLY',frontier=f,
        source_hashes=pins,input_hashes={n:sha(R/n) for n in inputs},solver_kwargs=paid['kwargs'],
        question='Measure only the1989 genuinely unexecuted source-native first-menu identities needed for the original DFF comparison. Reuse42 exact paid80 queries; retain3 unresolved prior-contract identities UNKNOWN without new calls.',
        all4_source_order_no_outcome_selection=True,declared_queries=2034,new_native_queries_max=1989,old_paid_native80_reuses=42,known_contract_unknowns_without_call=3,
        science_seconds=1800,reader_seconds=1800,binary_bytes=768*1024**2,
        persistent_boundary='Per-identity fsynced reservation, before/after NET, failure/result, paid receipts, cursor/deadline/cost/source anchors. First-return serialized warm/cold verifier check makes zero new physics; not a full controller process restart.',
        independent_reader='Frozen before outcomes; first replay only newly returned queries, all numerical fields1e-10/KCL1e-7 and exact original source verifier. No old/failed physics replay.',
        scope='Named60426+9297+738 retained histories and404current primary/failed/unentered before capsules. Scoped closure, not universal knowledge of unretained notebooks.',
        authority='Existing direct human full necessary experiment/comparison authority. New exact unexecuted identities only. The separately approved one-input80bridge is complete and not repeated; all other prior-contract collisions stay unknown.',
        comparisons='Baseline first-round measurement only, no actual model/GPU/commits, no endpoint/DSE/LLM/whole external superiority claim. Both branch/full model/training/preparation/failure costs remain obligations.',
        no_retry_extension_retune_or_automatic_further_round=True))
    for name,source,out,coord in [('Owner_Protocol.json',worker,'r118_first_round_missing_only_execution_20261022','r118_first_round_missing_only_coordination_20261022'),('Reader_Owner_Protocol.json',reader,'r118_first_round_missing_only_independent_20261022','r118_first_round_missing_only_reader_coordination_20261022')]:
        put(P/name,dict(single_owner=dict(source=source.relative_to(R).as_posix(),sha256=sha(source),python='work/vcsa_module_env/Scripts/python.exe',output='outputs/'+out,coordination='outputs/'+coord,bound_seconds=2000)))
    put(P/'Source_And_Preservation_Readiness.json',dict(status='PASS_PROSPECTIVE_FIRST_MENU_NATIVE_SOURCE_INPUT_HISTORY_AND_CACHED_VERIFIER_GATES',
        exact_input_rows=2034,unexecuted_only_new_native_calls_max=1989,known_unknowns_untouched=3,actual_old_return_verifier_warm_cold_equal=True,
        first_sample_legal_source_verifier=a,new_PF_model_calls_in_preparation=0,all_original_function_ASTs_unchanged=True,protocol_sha256=sha(P/'Protocol.json')))
    print(json.dumps(dict(status='FROZEN_READY_MISSING_ONLY_FIRST_MENUS',new_native_calls_max=1989,reuses=42,unknowns=3,new_science_in_preparation=0)))
if __name__=='__main__':main()
