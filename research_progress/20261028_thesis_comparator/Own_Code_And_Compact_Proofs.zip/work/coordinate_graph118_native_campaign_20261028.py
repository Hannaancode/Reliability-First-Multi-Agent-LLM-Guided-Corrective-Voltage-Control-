"""Sole bounded native external baseline owner, then sole first reader."""
import subprocess
from graph118_native_campaign_core_20261028 import *
H=R/'outputs/graph118_native_campaign_handoff_20261028'
def main():
    H.mkdir(exist_ok=False);put(H/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    p=read(P/'Protocol.json');lock=read(P/'Launch_And_Reader_Lock.json');pins(p)
    for n,h in lock['additional_source_hashes'].items():assert sha(R/n)==h,n
    gate=read(R/lock['integration_result']);assert gate['status']=='PASS_ALL4_NEW_CAMPAIGN_PROVIDER_INTEGRATION_NO_PHYSICS'
    assert sha(R/lock['integration_result'])==lock['integration_sha256']
    from coordinate_native_inverter_linear_reference_20261020 import process
    python=Path(lock['python'])
    def launch(source,out,bound):
        assert not out.exists();assert sha(source)==p['source_hashes'][source.relative_to(R).as_posix()]
        for n,h in lock['additional_source_hashes'].items():assert sha(R/n)==h
        began=time.monotonic()
        with (H/(source.stem+'.log')).open('x',encoding='utf-8') as log:
            child=subprocess.Popen([str(python),'-X','utf8',str(source)],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            while not (out/'owner.claim').exists():assert child.poll() is None and time.monotonic()-began<120;time.sleep(.2)
            claim=read(out/'owner.claim');a=process(claim['actual_pid']);parent=process(claim['parent_pid'])
            assert a and parent and a['ParentProcessId']==claim['parent_pid'] and source.name in a['CommandLine']
            assert a['ProcessId']==child.pid or claim['parent_pid']==child.pid
            put(out/'Launcher_ACK.json',dict(actual_pid=a['ProcessId'],parent_pid=a['ParentProcessId'],launcher_pid=child.pid,command=a['CommandLine'],source_sha256=sha(source),fresh_exact_source_PID_parent_command=True,at_utc=datetime.now(timezone.utc).isoformat()))
            try:code=child.wait(timeout=max(1,bound-time.monotonic()+began))
            except subprocess.TimeoutExpired:
                current=process(claim['actual_pid'])
                if current and source.name in current['CommandLine']:
                    subprocess.run(['taskkill.exe','/PID',str(claim['actual_pid']),'/T','/F'],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
                child.wait(timeout=30);raise
        for pid in {claim['actual_pid'],child.pid}:
            current=process(pid);assert current is None or source.name not in current.get('CommandLine','')
        put(out/'End_ACK.json',dict(actual_pid=claim['actual_pid'],parent_pid=claim['parent_pid'],launcher_pid=child.pid,exit_code=code,actual_owned_chain_ended=True,workflow_seconds=time.monotonic()-began))
        return code
    try:
        assert launch(R/'work/run_graph118_native_campaign_20261028.py',E,p['science_seconds']+300)==0
        assert (E/'Result.json').exists() and (E/'Closed_Manifest.json').exists()
        assert launch(R/'work/audit_graph118_native_campaign_20261028.py',A,p['reader_seconds']+300)==0
        audit=read(A/'Independent_Audit.json')
        put(H/'Completion.json',dict(status='PRIMARY_AND_FIRST_READER_TERMINAL',audit_status=audit['status'],all4_complete=audit['all4_complete'],actual_owned_scientist_reader_chains_ended=True,at_utc=datetime.now(timezone.utc).isoformat()))
        print(json.dumps(dict(status='TERMINAL',audit=audit['status'])))
    except BaseException as exc:
        put(H/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),no_automatic_retry=True));raise
if __name__=='__main__':main()
