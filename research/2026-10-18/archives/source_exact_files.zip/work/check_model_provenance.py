from pathlib import Path
import os,json,zipfile
r=Path('work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1')
cfg=json.loads((r/'adapter_config.json').read_text());tok=json.loads((r/'tokenizer_config.json').read_text())
print('base id',cfg.get('base_model_name_or_path'),'revision',cfg.get('revision'))
print('tokenizer provenance',{k:v for k,v in tok.items() if any(s in k.lower() for s in ['path','revision','commit'])})
for p in [Path.home()/'.cache/huggingface/hub',Path(os.getenv('HF_HOME',str(Path.home()/'.cache/huggingface')))/'hub']:
 if p.exists():print('cached snapshots',[(str(d),[s.name for s in (d/'snapshots').iterdir()] if (d/'snapshots').exists() else []) for d in p.glob('*qwen*')])
 else:print('cache not present',str(p))
inv=json.loads(Path('outputs/actual_experiment_inventory.json').read_text())
print('inventory schema',type(inv).__name__,list(inv) if isinstance(inv,dict) else '')
