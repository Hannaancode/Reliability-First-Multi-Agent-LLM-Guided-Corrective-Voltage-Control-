"""Frozen analysis of terminal independent fresh128 evidence; no science calls."""
import json,hashlib,os
from datetime import datetime,timezone
from pathlib import Path
from public13_fresh_router_engine_20261022 import R,P,PRIMARY,READER,read,sha,put,ARMS
O=R/'outputs/public13_fresh_router_comparison_20261022'

def main():
    assert not O.exists()
    for rel in ['outputs/public13_fresh_router_coordination_20261022/End_ACK.json','outputs/public13_fresh_router_reader_coordination_20261022/End_ACK.json']:
        end=read(R/rel);assert end['actual_owned_chain_ended'] and end['exit_code']==0
    p=read(P/'Protocol.json');assert sha(__file__)==p['source_and_input_hashes']['work/compare_public13_fresh_router_20261022.py']
    audit=read(READER/'Independent_Audit.json');assert audit['status'].startswith('PASS_')
    result=read(PRIMARY/'Result.json');O.mkdir()
    if not result['all128_complete'] or not audit['all128_complete']:
        put(O/'Fixed_Decision.json',dict(status='UNKNOWN_TERMINAL_PARTIAL_NO_COMPLETE128_COMPARISON',all6finalgoals='OPEN',primary_status=result['status'],unentered_seeds=result['unentered_seeds']));return
    import numpy as np
    from scipy.stats import binomtest
    values={a:[] for a in ARMS};rows=[];totals={a:dict(cases=128,full13band=0,residualUV=0,residualOV=0,decisions=0,rejections=0) for a in ARMS}
    for pos,w in enumerate(result['worlds']):
        assert w['seed']==1000+pos and w['root_status']=='RETURNED' and len(w['arms'])==6
        case=dict(seed=w['seed'],initial=w['initial'],arms={})
        for branch in w['arms']:
            a=branch['arm'];assert branch['status'].startswith('COMPLETE_');f=branch['final'];vm=np.asarray(branch['final_vm'])
            assert f['full13band']==bool(((vm>=.95)&(vm<=1.05)).all()) and f['UV']==int((vm<.95).sum()) and f['OV']==int((vm>1.05).sum())
            values[a].append(int(f['full13band']));t=totals[a];t['full13band']+=int(f['full13band']);t['residualUV']+=f['UV'];t['residualOV']+=f['OV'];t['decisions']+=len(branch['steps']);t['rejections']+=sum(not s['accepted'] for s in branch['steps'])
            case['arms'][a]=dict(backend=branch['backend'],status=branch['status'],final=f,steps=len(branch['steps']))
        rows.append(case)
    for t in totals.values():t['fraction']=t['full13band']/128
    rng=np.random.default_rng(20261022);index=rng.integers(0,128,size=(10000,128));ours=np.asarray(values['our-router']);tests=[]
    for a in ['safe-ddpg','linear','ddpg','published-router']:
        other=np.asarray(values[a]);delta=ours-other;wins=int((delta==1).sum());losses=int((delta==-1).sum());interval=np.quantile(delta[index].mean(axis=1),[.025,.975]).tolist()
        tests.append(dict(comparator=a,wins=wins,losses=losses,ties=128-wins-losses,rate_difference=float(delta.mean()),fixed_case_bootstrap95_percentile_interval=interval,exact_discordant_p=float(binomtest(wins,wins+losses,.5).pvalue) if wins+losses else 1.))
    order=sorted(range(4),key=lambda i:tests[i]['exact_discordant_p']);running=0.
    for rank,i in enumerate(order):running=max(running,(4-rank)*tests[i]['exact_discordant_p']);tests[i]['Holm_family4_p']=min(1.,running)
    passed=totals['our-router']['fraction']>=.90 and all(t['fixed_case_bootstrap95_percentile_interval'][0]>0 and t['Holm_family4_p']<.05 for t in tests)
    decision=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='PASS_FIXED_FRESH128_ROUTING_SCREEN' if passed else 'FAIL_FIXED_ROUTING_INTERVENTION_STOP_NO_RETUNING',summaries=totals,paired_tests=tests,
        primary_costs=result['costs'],first_independent_costs=audit['actual_independent_costs'],primary_workflow_seconds=result['workflow_seconds'],first_reader_workflow_seconds=audit['workflow_seconds'],
        all128_cases=rows,strict_score_no_near_boundary_reclassification=True,
        statistical_scope='Fixed observed case-root resampling screen. Mutable source normalization state carries across ordered cases; these resampling intervals are not a calibrated probability of winning on new domains or independent training seeds. Prospective local stream is not certified unused by external model training. Separate confirmation and repeated independent batches remain necessary.',
        comparison_scope='Same physical cases, actuators and100-round cap. Global-input router/NUM versus localVM native actors; native baselines unmodified, both named routers have common guard. Three source-native comparators are one publication family. No full AC/thermal/security, LLM increment, model-training attribution or all-literature superiority claim.',
        no_LLM_or_new_training_in_this_method=True,all6finalgoals='OPEN')
    put(O/'Fixed_Decision.json',decision)
    table='\n'.join('|'+a+'|'+str(t['full13band'])+'/128|'+str(t['residualUV'])+'|'+str(t['residualOV'])+'|' for a,t in totals.items())
    text='# Prospective fresh128 routing comparison\n\n'+decision['status']+'\n\n| Controller | All13 band | Residual UV | Residual OV |\n|---|---:|---:|---:|\n'+table+'\n\n'+decision['comparison_scope']+'\n\n'+decision['statistical_scope']+'\n\nAll prior failed/partial/UNKNOWN evidence and costs remain preserved. This numerical/learned-expert composite does not measure our original paper LLM. All six final goals remain open.\n'
    with (O/'Results_And_Next_Decision.md').open('x',encoding='utf-8') as f:f.write(text);f.flush();os.fsync(f.fileno())
    print(decision['status'])

if __name__=='__main__':main()
