"""Charged actual root/commit binding for an exclusive future owner.

No execution on import. Original action application and solver options are
called once. Returned/failed full states are preserved before validation or
propagation. No rollback, retry, cloud/model call or budget renewal.
"""
import copy
import hashlib
import math
import os
import pickle
import random
import time

import numpy as np

from native_continuation_preservation_v2 import canonical
from native_postcommit_preservation import measured_bus_fields, check_commit
from paid_spatial_native_queries_v2 import OperationalStop
from paid_spatial_two_step_search import Receipt
from trusted_causal_controller_snapshot import SOLVER_ROLES, cap_totals, write_bytes


class ActualCommitBinding:
    def __init__(self, q):
        if q.protocol.get('actual_commit_binding_authorized') is not True:
            raise ValueError('Separately prospective actual root/commit protocol required')
        self.q = q
        self.backend = q.pp.runpp
        self.current_handle = None
        self.cursor = 0
        self.initialized = False
        self.costs = {'attempts': 0, 'returns': 0, 'exceptions': 0,
            'initial_attempts': 0, 'commit_attempts': 0, 'pure_solver_seconds': 0.0,
            'direct_preservation_seconds': 0.0, 'direct_payload_bytes': 0,
            'direct_journal_seconds': 0.0}

    def _owned(self):
        q = self.q
        q.boundary()
        if q.inflight or getattr(q.pp, '_paid_spatial_query_owner', None) != q.owner_token or q.pp.runpp != self.backend:
            raise OperationalStop('Unowned/concurrent/changed actual solver binding')

    def _emit(self, event, payload):
        started = time.perf_counter()
        try:
            self.q.journal.emit(event, payload)
        except Exception as exc:
            self.q.stopped = True
            raise OperationalStop('Actual direct journal preservation failed') from exc
        finally:
            self.costs['direct_journal_seconds'] += time.perf_counter()-started

    def _preserve(self, out, net, process, status, exception=None):
        started = time.perf_counter()
        try:
            raw = pickle.dumps({'net': net, 'process': copy.deepcopy(process),
                'python_rng': random.getstate(), 'numpy_rng': np.random.get_state()}, protocol=5)
            # Raw full net first: even nonfinite/partial results must survive.
            write_bytes(out/'trusted_local_actual_state.pkl', raw)
            self.costs['direct_payload_bytes'] += len(raw)
            meta = {'issuer_pid': os.getpid(), 'status': status,
                'payload_sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                'actual_cursor': process['actual_commit_count'],
                'solver_converged_flag': bool(net.get('converged', False)),
                'exception_type': type(exception).__name__ if exception is not None else None,
                'solved_or_admissible_claim': False}
            write_bytes(out/'Raw_State_Manifest.json', canonical(meta))
            return meta
        except Exception as exc:
            self.q.stopped = True
            raise OperationalStop('Actual paid full-state preservation failed; UNKNOWN, no retry') from exc
        finally:
            self.costs['direct_preservation_seconds'] += time.perf_counter()-started

    def _solve(self, net, process, role, identity, action=None):
        self._owned()
        out = self.q.directory/'actual_calls'/identity
        out.mkdir(parents=True, exist_ok=False)
        self._emit('actual_direct_operation_intent', {'identity': identity, 'role': role,
            'action': action, 'kwargs': SOLVER_ROLES[role], 'actual_cursor': process['actual_commit_count']})
        self.q.inflight = True
        try:
            if action is not None:
                try:
                    self.q.runner.rescue.apply_action(net, action)
                except BaseException as exc:
                    meta = self._preserve(out, net, process, 'ACTION_APPLICATION_FAILED_NO_PF', exc)
                    self._emit('actual_action_application_failed', {'identity': identity, 'anchors': meta})
                    raise OperationalStop('Actual action application failed; no rollback/retry') from exc
            try:
                self.q.boundary()
            except BaseException as exc:
                meta = self._preserve(out, net, process, 'PRE_PF_BOUND_STOP_NO_SOLVER_CALL', exc)
                self._emit('actual_pre_PF_bound_stop', {'identity': identity, 'anchors': meta})
                raise
            self._emit('actual_direct_PF_intent', {'identity': identity, 'role': role, 'kwargs': SOLVER_ROLES[role]})
            self.costs['attempts'] += 1
            self.costs[role+'_attempts'] += 1
            begun = time.perf_counter()
            try:
                self.backend(net, **SOLVER_ROLES[role])
            except BaseException as exc:
                elapsed = time.perf_counter()-begun
                self.costs['pure_solver_seconds'] += elapsed
                self.costs['exceptions'] += 1
                meta = self._preserve(out, net, process, 'PF_EXCEPTION_OR_INTERRUPTION_UNKNOWN', exc)
                self._emit('actual_direct_PF_exception', {'identity': identity, 'role': role,
                    'solver_seconds': elapsed, 'anchors': meta})
                raise OperationalStop('Actual PF failure preserved; no scientific retry') from exc
            elapsed = time.perf_counter()-begun
            self.costs['pure_solver_seconds'] += elapsed
            self.costs['returns'] += 1
            meta = self._preserve(out, net, process, 'PF_RETURN_PRESERVED_BEFORE_ADMISSION')
            self._emit('actual_direct_PF_return', {'identity': identity, 'role': role,
                'solver_seconds': elapsed, 'anchors': meta})
            fields = measured_bus_fields(net)
            if not bool(net.get('converged', False)) or not fields or any(
                    not math.isfinite(v) for row in fields.values() for v in row.values()):
                raise OperationalStop('Actual return not finite/converged; raw bytes retained')
            # A paid return is recorded even if it crossed deadline/storage.
            handle = self.q.register(net, process, label='ACTUAL_'+role.upper()+'_RETURN', returned_measurement=True)
            self._emit('actual_direct_capsule_issued', {'identity': identity, 'handle': handle,
                'direct_costs': copy.deepcopy(self.costs)})
            return handle
        except BaseException:
            self.q.stopped = True
            raise
        finally:
            self.q.inflight = False

    def initial(self, net, process):
        if self.initialized or self.current_handle is not None or self.q.handles:
            raise OperationalStop('Root initialization cannot repeat or replace an existing prefix')
        if (process.get('actual_commit_count') != 0 or process.get('remaining_slots') != 25 or
            process.get('actual_action_history') != [] or process.get('uncommitted_depth', 0) != 0 or
            'hypothetical_parent' in process or 'hypothetical_action' in process):
            raise OperationalStop('Fresh actual root process required')
        self.initialized = True  # A failed root never becomes retryable.
        handle = self._solve(net, copy.deepcopy(process), 'initial', 'initial_000')
        self.current_handle = handle
        return handle

    def commit(self, parent, receipt, action, iteration):
        if parent != self.current_handle or type(iteration) is not int or iteration != self.cursor+1 or iteration > 25:
            raise OperationalStop('Obsolete parent, reset cursor or extra commitment refused')
        if (not isinstance(receipt, Receipt) or (receipt.parent, receipt.action) not in self.q.receipts or
            self.q.receipts[(receipt.parent, receipt.action)] != receipt or receipt.parent != parent or
            not receipt.returned or receipt.accepted is not True or
            action != self.q.menus[parent][receipt.action]):
            raise OperationalStop('Commit lacks exact paid current native action receipt')
        saved = self.q.restore(parent)
        p = saved['process']
        if p['actual_commit_count'] != self.cursor or p['remaining_slots'] != 25-self.cursor:
            raise OperationalStop('Actual process/cursor mismatched')
        before = self.q.runner.rescue.grid_metrics(saved['net'])
        next_process = {**copy.deepcopy(p), 'actual_commit_count': iteration,
            'remaining_slots': 25-iteration, 'actual_action_history': p['actual_action_history']+[copy.deepcopy(action)]}
        handle = self._solve(saved['net'], next_process, 'commit', f'commit_{iteration:02d}', action)
        # Publish that the actual operation occurred before postcommit checking;
        # failure is terminal and cannot roll back to a retryable old state.
        self.current_handle, self.cursor = handle, iteration
        try:
            actual = self.q.restore(handle)['net']
            trial = self.q.restore(receipt.successor)['net']
            proof = check_commit(measured_bus_fields(trial), measured_bus_fields(actual), before, cap_totals(actual))
            self._emit('actual_binding_commit_admission', {'iteration': iteration,
                'parent': parent, 'current_handle': handle, 'trial_successor': receipt.successor, 'proof': proof})
        except BaseException:
            self.q.stopped = True
            raise
        return handle

    def attach_live_controller_costs(self, coordinator):
        if coordinator.q is not self.q or coordinator.controller['current_handle'] != self.current_handle:
            raise OperationalStop('Cost ledger attached to a different actual controller')
        coordinator.controller['direct_costs'] = self.costs

    def bind_preserved_current(self, controller):
        """Only AFTER the mandatory source/ended-issuer/closed-phase cold gate."""
        if self.initialized or self.current_handle is not None or not getattr(self.q, '_controller_linked_journal', False):
            raise OperationalStop('Actual binding requires a verified linked preserved handoff')
        expected = set(self.costs)
        inherited = controller['direct_costs']
        if set(inherited) != expected or any(isinstance(v, bool) or not isinstance(v, (int, float)) or
                not math.isfinite(v) or v < 0 for v in inherited.values()):
            raise OperationalStop('Incomplete inherited actual root/commit/failure costs')
        self.costs = copy.deepcopy(inherited)
        self.current_handle = controller['current_handle']
        self.cursor = controller['actual_commit_count']
        self.initialized = True
        p = self.q.restore(self.current_handle)['process']
        if p['actual_commit_count'] != self.cursor or p['remaining_slots'] != 25-self.cursor:
            raise OperationalStop('Inherited actual process/cursor changed')
