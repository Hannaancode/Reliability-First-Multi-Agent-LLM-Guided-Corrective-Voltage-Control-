"""Saved JSON accounting only. Freeze rules first, then join all four fixed roots.

Never import a controller, decode NETs, replay a verifier, or call a model/PF.
Existing raw-action and physical/source audits are references, not rerun work.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse,collections,hashlib,json,time
R=Path(__file__).resolve().parents[1]
O=R/'outputs/original118_component_ledger_20261030'
COMPARISON='outputs/original118_closed_comparison_20261028/Comparison.json'
COSTS='outputs/original118_closed_comparison_20261028/Full_Cost_Source_Blocks.json'
ATTR='outputs/original118_raw_action_attribution_v2_20261028'
DFF='outputs/r118_dff_partition_continuation_execution_20261023'
MAPPING={'llm_direct':'direct_language_proposal_after_source_normalization',
 'llm_guided_refinement':'guided_numerical_refinement',
 'safety_fallback_physics_refinement':'deterministic_fallback'}
def read(path):return json.loads((R/path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256((R/path).read_bytes()).hexdigest()
def ref(path,pointer=None):
 row=dict(path=path,sha256=sha(path),bytes=(R/path).stat().st_size)
 if pointer is not None:row['json_pointer']=pointer
 return row
def put(path,value):
 with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def freeze():
 O.mkdir(exist_ok=False)
 comparison=read(COMPARISON);attr=read(ATTR+'/Results.json')
 assert [x['case_id'] for x in comparison['rows']]==comparison['protocol']['case_order']==[x['case_id'] for x in attr['cases']]
 paths=[COMPARISON,COSTS,'outputs/original118_closed_comparison_20261028/Closed_Manifest.json',ATTR+'/Results.json',ATTR+'/Protocol.json',ATTR+'/Closed_Manifest.json',
  ATTR+'/independent/Independent_Audit.json',ATTR+'/independent/Closed_Manifest.json',DFF+'/Closed_Manifest.json',
  'outputs/r118_dff_partition_continuation_independent_20261023/Independent_Audit.json',
  'work/e/audit/run_reflection_v4_safety_envelope.py','work/e/audit/phase2g_rescue_runner.py',
  'work/e/audit/phase2g_llm_guided_rescue_runner.py','work/analyse_original118_raw_action_attribution_v2_20261028.py',
  'work/audit_original118_raw_attribution_20261028.py','work/assemble_original118_closed_comparison_20261028.py']
 cases=[]
 audits=['outputs/r118chrono_audit_20261022/Independent_Audit.json',
  'outputs/original_missing_suffix_independent_20261028/case_01/Independent_Audit.json',
  'outputs/reflection118_remaining_cases_v2_independent_20261023/case_02/Independent_Audit.json',
  'outputs/original_missing_suffix_independent_20261028/case_03/Independent_Audit.json']
 cost_pointers=[['/old_original_case0_partial_study'],['/new_missing_suffix_cases/0','/old_interrupted_case1'],['/old_original_case2'],['/new_missing_suffix_cases/1','/old_interrupted_case3']]
 for i,(row,origin) in enumerate(zip(comparison['rows'],attr['cases'])):
  cid=row['case_id'];hg=origin['result_path'];dff=DFF+'/'+cid+'/Result.json'
  call_hg=str(Path(hg).parent/'Call_Order.json').replace('\\','/');call_dff=DFF+'/'+cid+'/Call_Order.json'
  paths.extend([hg,dff,call_hg,call_dff,ATTR+f'/case_{i:02d}_Attribution.json',audits[i]])
  if i in (1,3):paths.append(f'outputs/reflection118_remaining_cases_v2_independent_20261023/case_{i:02d}/Independent_Audit.json')
  commits=[DFF+'/'+cid+f'/commit_{j:02d}.json' for j in range(1,row['DFF_actions']+1)];paths.extend(commits)
  cases.append(dict(case_index=i,case_id=cid,root_sha256=comparison['protocol']['root_hashes'][cid],HGVF_result=hg,DFF_result=dff,
   HGVF_call_order=call_hg,DFF_call_order=call_dff,DFF_commit_metadata=commits,HGVF_existing_audit=audits[i],HGVF_cost_pointers=cost_pointers[i]))
 protocol=dict(status='FROZEN_SAVED_ALL4_COMPONENT_LEDGER_RULES_BEFORE_JOINS',at_utc=datetime.now(timezone.utc).isoformat(),
  producer=ref('work/build_original118_component_ledger_20261030.py'),cases=cases,inputs={p:sha(p) for p in dict.fromkeys(paths)},
  existing_evidence='Existing all4 raw/normalized/verifier/commit-origin attribution and independent audit are reused. They do not contain this joined per-commit before/after UV/OV ledger or both-branch selector/cost links.',
  mapping=MAPPING,metrics='Copy strict UV(VM<0.95), OV(VM>1.05) from saved original grid_metrics; native hard guard remains1.06. No tolerance or new arithmetic/physics outcome rule.',
  commit_rule='Exactly every saved executed_actions entry in both complete Result.json branches. Before=base_metrics for first; previous committed post_metrics thereafter. Match direct/DFF log before metrics, DFF commit metadata and final endpoint. Preserve order, adverse deltas and unresolved mismatches.',
  rejection_rule='Copy every direct HGVF log verifier record, including no_action and q_cap pretest rejection; distinguish failed PF, electrical rejection, accepted-selected and accepted-unselected. DFF saved per-iteration tested/accepted totals provide rejection counts only. HGVF guided/fallback per-candidate rejection records absent from Result.logs remain UNKNOWN; never reconstruct by rerunning source.',
  origin_rule='Map only exact saved source strings. Direct can include source normalizer repair; reuse the existing independent selected-direct classification. Guided/fallback are numerical contributions, not raw model outputs.',
  cost_rule='Attach full original branch/call-order/audit and source-specific cost pointers, including old interrupted prefixes and both selector branches. Do not divide shared costs across events, sum overlapping latency, or call missing historical training/setup cost zero. Component/per-commit exact costs remain UNKNOWN when not separately measured.',
  selector_rule='Copy all4 original HG-SE selections from closed Comparison.json. This is offline choice between already completed trajectories, zero additional commits, both branches paid. Do not rerun selector or infer causal advantage.',
  mismatch_rule='Retain every expected case/event and list each mismatch/unknown. Any mismatch blocks a complete accounting claim; no favorable subset.',
  privacy='Raw source results and model responses remain local. Event ledgers are QA_LOCAL_ONLY. Publish only compact aggregates and source hashes/references.',
  scope='T05 partial descriptive execution evidence; no causal counterfactual, equal-cost improvement, generalization, master task or thesis closure.',new_model_PF_controller_optimizer_derivative_calls=0)
 put(O/'Protocol.json',protocol)
 print('FROZEN_SAVED_ONLY_MAPPING_NO_JOINS_YET')
def join():
 began=time.monotonic();p=read(str((O/'Protocol.json').relative_to(R)));assert p['producer']['sha256']==sha(p['producer']['path'])
 for path,digest in p['inputs'].items():assert sha(path)==digest,path
 comparison=read(COMPARISON);attr=read(ATTR+'/Results.json');independent=read(ATTR+'/independent/Independent_Audit.json')
 assert independent['status']=='PASS_ALL4_INDEPENDENT_RAW_NORMALIZATION_AND_ATTRIBUTION'
 assert read('outputs/original118_closed_comparison_20261028/Closed_Manifest.json')['members']['Comparison.json']==sha(COMPARISON)
 assert read(ATTR+'/Closed_Manifest.json')['members']['Results.json']==sha(ATTR+'/Results.json')
 assert read(ATTR+'/independent/Closed_Manifest.json')['members']['Independent_Audit.json']==sha(ATTR+'/independent/Independent_Audit.json')
 private=O/'QA_LOCAL_ONLY';private.mkdir(exist_ok=False)
 commits=[];verifiers=[];dff_rejections=[];selectors=[];errors=[];cost_rows=[];component=collections.defaultdict(collections.Counter);bycase=[]
 def require(condition,label,**context):
  if not condition:errors.append(dict(label=label,**context))
 for case,row,origin,prior in zip(p['cases'],comparison['rows'],attr['cases'],independent['rows']):
  cid=case['case_id'];case_index=case['case_index'];direct_raw={x['iteration']:x for x in prior['selected_direct_classification']}
  require(sha(case['HGVF_result'])==origin['result_sha256'],'HGVF prior origin hash mismatch',case_id=cid)
  require(sha(case['HGVF_call_order'])==origin['call_order_sha256'],'HGVF prior call-order hash mismatch',case_id=cid)
  cost=dict(case_id=cid,full_source_blocks=ref(COSTS),DFF_shared_all4_costs=ref(COSTS,'/DFF_closed_study'),
   HGVF_source_costs=[ref(COSTS,j) for j in case['HGVF_cost_pointers']],
   DFF_existing_audit=ref('outputs/r118_dff_partition_continuation_independent_20261023/Independent_Audit.json'),HGVF_existing_audit=ref(case['HGVF_existing_audit']),
   per_commit_or_component_costs='UNKNOWN_NOT_SEPARATELY_MEASURED; full branch costs retained, no equal-cost or free-reuse claim',
   unknown_historical_costs=['Original training and exact historical base/SFT setup','Shared old root/menu/physics preparation and failed engineering costs not fully recovered','Overlapping remote/local/transfer latency cannot be added as wall-clock runtime'])
  if case_index in (1,3):cost['old_interrupted_prefix_audit']=ref(f'outputs/reflection118_remaining_cases_v2_independent_20261023/case_{case_index:02d}/Independent_Audit.json')
  cost_rows.append(cost);case_events=[]
  for branch in ('HGVF','DFF'):
   source=case[branch+'_result'];d=read(source);calls=case[branch+'_call_order'];before=d['base_metrics'];byiteration={};origin_count=collections.Counter()
   require(d['scenario_id']==cid and d['base_converged'] is True,'Root/solved-base mismatch',case_id=cid,branch=branch)
   for j,a in enumerate(d['executed_actions']):
    origin_count[a['source']]+=1;after=a['post_metrics'];it=a['iteration'];kind=MAPPING.get(a['source'],'UNKNOWN_SOURCE')
    require(kind!='UNKNOWN_SOURCE' and it not in byiteration,'Unknown source or duplicate iteration',case_id=cid,branch=branch,event=j)
    require(it==j+1,'Noncontiguous original commitment order',case_id=cid,branch=branch,event=j)
    event=dict(case_id=cid,branch=branch,commit_index=j,iteration=it,component=kind,source_label=a['source'],zone=a.get('zone'),action=a['action'],
     before=before,after=after,UV_change=after['uv_count']-before['uv_count'],OV_change=after['ov_count']-before['ov_count'],
     UV_reduction=before['uv_count']-after['uv_count'],OV_increased=after['ov_count']>before['ov_count'],
     any_strict_count_adverse=after['uv_count']>before['uv_count'] or after['ov_count']>before['ov_count'],
     result_ref=ref(source,f'/executed_actions/{j}'),before_ref=ref(source,'/base_metrics' if j==0 else f'/executed_actions/{j-1}/post_metrics'),
     full_call_order_ref=ref(calls),cost_lineage_pointer=f'/cases/{case_index}',causal_marginal_effect='UNKNOWN_NO_SAME_STATE_COUNTERFACTUAL',
     selected_candidate_verifier_ref=None)
    if branch=='DFF':
     metadata=case['DFF_commit_metadata'][j];cm=read(metadata)
     require(cm['metrics']==after,'DFF commitment metadata mismatch',case_id=cid,event=j)
     event['commitment_metadata_ref']=ref(metadata);event['saved_physics_call_cursor']=cm['call_cursor']
    elif a['source']=='llm_direct':
     raw=direct_raw.get(it);require(raw is not None and raw['zone']==a['zone'],'Selected direct prior classification mismatch',case_id=cid,event=j)
     event['existing_independent_direct_classification']=raw
    byiteration[it]=event;commits.append(event);case_events.append(event)
    c=component[branch+'/'+kind];c.update(commits=1,UV_reduction=event['UV_reduction'],OV_net_change=event['OV_change'],
     UV_worsening_events=int(event['UV_change']>0),OV_increase_events=int(event['OV_change']>0),any_strict_count_adverse_events=int(event['any_strict_count_adverse']))
    before=after
   require(before==d['final_metrics'],'Final metric chain mismatch',case_id=cid,branch=branch)
   require(len(d['executed_actions'])==row[branch+'_actions'],'Commit total mismatch',case_id=cid,branch=branch)
   require(d['final_metrics']['uv_count']==row[branch+'_UV'] and d['final_metrics']['ov_count']==row[branch+'_OV'],'Final comparison endpoint mismatch',case_id=cid,branch=branch)
   if branch=='HGVF':require(dict(origin_count)==origin['commit_origins'],'Prior component origin totals mismatch',case_id=cid)
   for j,log in enumerate(d['logs']):
    it=log['iteration'];event=byiteration.get(it)
    current=d['base_metrics'] if it==1 else byiteration[it-1]['after'] if it-1 in byiteration else None
    if branch=='DFF':
     require(log['current_metrics']==current,'DFF decision before mismatch',case_id=cid,iteration=it)
     dff_rejections.append(dict(case_id=cid,iteration=it,tested=log['fallback_tests'],accepted=log['accepted_fallback'],
      rejected=log['fallback_tests']-log['accepted_fallback'],committed=event is not None,
      before=current,individual_candidate_reason_and_outcome='UNKNOWN_NOT_IN_SAVED_RESULT_LOG',source_ref=ref(source,f'/logs/{j}')))
     continue
    v=log.get('verif');require(v is not None,'Missing direct verifier record',case_id=cid,iteration=it,log=j)
    if v is None:continue
    require(v['before']==current,'Direct verifier before differs from actual committed state',case_id=cid,iteration=it,log=j)
    selected=bool(event and event['source_label']=='llm_direct' and event['zone']==log['zone'] and event['action']==log['action'])
    if selected:
     require(v['accepted'] is True and v['after']==event['after'],'Selected direct verifier/post metrics mismatch',case_id=cid,iteration=it)
     event['selected_candidate_verifier_ref']=ref(source,f'/logs/{j}/verif')
    status=('accepted_committed' if selected else 'accepted_unselected') if v['accepted'] else 'failed_PF' if v['converged'] is False else 'pretest_rejected' if v['after'] is None else 'electrical_rejected'
    verifiers.append(dict(case_id=cid,iteration=it,zone=log['zone'],status=status,reason=v['reason'],
     action_present=bool(log['action']),accepted=v['accepted'],committed=selected,before=v['before'],candidate_after=v['after'],
     actual_committed_state_changed_by_this_record=False,source_ref=ref(source,f'/logs/{j}/verif'),
     scope='Candidate test only; committed effect appears only in Commit_Ledger. Accepted unselected is not a control action.'))
   for event in byiteration.values():
    if branch=='HGVF' and event['source_label']=='llm_direct':require(event['selected_candidate_verifier_ref'] is not None,'Direct commit lacks exact verifier join',case_id=cid,iteration=event['iteration'])
  selectors.append(dict(case_id=cid,selected_branch='HGVF' if row['HGSE_selected']=='reflection_v2' else 'DFF',original_selected_label=row['HGSE_selected'],
   selected_UV=row['HGSE_UV'],selected_OV=row['HGSE_OV'],selected_actions=row['HGSE_selected_actions'],new_committed_control_events=0,
   alternatives=dict(HGVF=dict(UV=row['HGVF_UV'],OV=row['HGVF_OV']),DFF=dict(UV=row['DFF_UV'],OV=row['DFF_OV'])),
   both_branch_costs_required=True,cost_lineage_pointer=f'/cases/{case_index}',source_ref=ref(COMPARISON,f'/rows/{case_index}'),
   interpretation='Saved offline trajectory selection, not another language-model decision or new control execution.'))
  bycase.append(dict(case_id=cid,commits_by_branch=dict(collections.Counter(e['branch'] for e in case_events)),
   adverse_commits=[dict(branch=e['branch'],commit_index=e['commit_index'],iteration=e['iteration'],component=e['component'],UV_change=e['UV_change'],OV_change=e['OV_change']) for e in case_events if e['any_strict_count_adverse']],
   HGVF_component_origins=origin['commit_origins']))
 put(private/'Commit_Ledger.json',dict(events=commits));put(private/'Verifier_Ledger.json',dict(direct_HGVF_records=verifiers,DFF_per_iteration_counts=dff_rejections))
 put(O/'Cost_Lineage.json',dict(cases=cost_rows,scope='Full source-specific branches/prefixes retained; no fabricated per-component cost allocation.'))
 put(O/'Offline_Selector_Ledger.json',dict(rows=selectors))
 status_counts=collections.Counter(v['status'] for v in verifiers);reasons=collections.Counter(v['reason'] for v in verifiers if not v['accepted'])
 result=dict(status='PASS_SAVED_ALL4_COMMIT_COMPONENT_ACCOUNTING_T05_PARTIAL' if not errors else 'UNKNOWN_RETAINED_ACCOUNTING_MISMATCHES_T05_PARTIAL',
  at_utc=datetime.now(timezone.utc).isoformat(),fixed_cases=[c['case_id'] for c in p['cases']],committed_events=len(commits),
  components={k:dict(v) for k,v in sorted(component.items())},cases=bycase,direct_verifier_status_counts=dict(status_counts),direct_rejection_reasons=dict(reasons),
  DFF_fallback_test_counts=dict(tested=sum(x['tested'] for x in dff_rejections),accepted=sum(x['accepted'] for x in dff_rejections),rejected=sum(x['rejected'] for x in dff_rejections)),
  offline_selector_counts=dict(collections.Counter(x['selected_branch'] for x in selectors)),new_selector_control_events=0,
  errors=errors,unknowns=['HGVF guided/fallback per-candidate rejection details are not in saved Result.logs; do not infer them from commitment origin.',
   'DFF candidate rejection counts are available, but individual candidate reasons/UV/OV are absent from Result.logs.',
   'Per-event/component exact cost allocation is unavailable; full branch/source costs and all old interrupted-prefix costs remain retained.',
   'Same-state no-language, alternate-proposal, no-refinement, no-fallback and no-verifier counterfactual outcomes are unavailable.',
   'Causal LLM advantage, equal-cost superiority and unused confirmation remain unestablished.'],
  existing_raw_attribution_and_independent_audit_reused=True,original_fixed_development_gate=comparison['fixed_development_gate'],
  original_four_case_HGVF_wins_ties_losses=[comparison['HGVF_UV_wins'],comparison['ties'],comparison['losses']],
  inference_limit='Executed-source contribution and observed sequential state change only. Origin labels do not identify marginal causal benefit.',
  task_disposition='T05 partial evidence only; no master task, DOCX or main-goal closure.',
  raw_event_ledgers_local_only=True,old_NET_or_checkpoint_decodes=0,new_model_PF_optimizer_derivative_controller_calls=0,
  existing_verifier_parser_selector_or_audit_replays=0,workflow_seconds=time.monotonic()-began,producer=ref('work/build_original118_component_ledger_20261030.py'),protocol=ref(str((O/'Protocol.json').relative_to(R))))
 put(O/'Results.json',result)
 put(O/'Closed_Manifest.json',dict(files=[ref(f.relative_to(R).as_posix()) for f in O.rglob('*') if f.is_file()],raw_event_ledgers_local_only=True))
 print(json.dumps(dict(status=result['status'],committed_events=len(commits),errors=len(errors),components=result['components'],direct_verifier_status_counts=result['direct_verifier_status_counts'])))
if __name__=='__main__':
 ap=argparse.ArgumentParser();mode=ap.add_mutually_exclusive_group(required=True);mode.add_argument('--freeze',action='store_true');mode.add_argument('--join',action='store_true');args=ap.parse_args()
 freeze() if args.freeze else join()
