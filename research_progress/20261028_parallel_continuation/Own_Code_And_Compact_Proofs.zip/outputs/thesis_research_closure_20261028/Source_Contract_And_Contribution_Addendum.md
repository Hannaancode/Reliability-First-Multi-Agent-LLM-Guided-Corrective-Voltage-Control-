# Thesis contribution and verification addendum

## 3.10 Candidate contribution within the coauthored work

I carried out the main technical work for PowerGridQA, the RAG assistant and HierGrid, including the implementation, experiments and preparation of the research manuscripts. The work developed from a power-system question–answer dataset into a grounded assistant and then a multi-agent voltage-control system. The table separates this technical work from the review and supervision contributed by collaborators.

| Research output | Candidate contribution | Collaborator roles and evidence |
| --- | --- | --- |
| PowerGridQA | Main technical work on dataset construction, implementation, analysis and manuscript preparation, as confirmed by the candidate. | The published paper records source selection and answer review by domain experts, including coauthors. Their review and resolution of ambiguous answers remain acknowledged. |
| RAG assistant | Main technical work on the assistant implementation, experiments and manuscript preparation, as confirmed by the candidate. | A detailed allocation of collaborator roles was not recovered from the supplied manuscript. Do not infer that coauthors made no contribution. |
| HierGrid | Conceptualisation, methodology, software, data curation, formal analysis, investigation, validation, visualisation and writing, as recorded in the supplied CRediT statement. | The draft credits Amith Khandakar and S. M. Muyeen with supervision, methodology, validation, project administration and review/editing. Other provisional entries need confirmation before submission. |
| Later comparison studies | Candidate-led research direction and experimental decisions, with AI-assisted coding, analysis preparation and writing disclosed. | Execution logs identify automated work. These studies should not be described as manually implemented or independently checked by the candidate unless that review is documented. |

This statement describes research responsibility rather than claiming sole authorship of every activity. The HierGrid draft supports the listed technical roles, while the dataset publication specifically describes expert review. The RAG allocation and provisional coauthor entries should be reconciled with the final author-approved statements. No Qatar University requirement for a separate contribution section has been established in this review.

## Offline selection and its exact source behaviour

HG-SE is an offline selection between completed DFF and HG-VF trajectories. Both branches are evaluated before the selector compares their endpoints, so the selected endpoint is not a decision that an online controller could make using future outcomes that it has not yet observed.

The retained choose_safety_envelope function first selects the lower final UV count, then the lower final voltage deficit and finally the smaller accepted-action count. A remaining tie selects DFF. The function does not include a separate final overvoltage comparison. Each branch's original verifier and the reported strict overvoltage results must therefore remain visible.

There is a source detail that affects equal-UV ties: final_deficit is read using an `or 1e99` default. A numerical zero is therefore treated the same way as a missing or false value. Reproducing the historical selector requires preserving that behaviour and reporting it; silently changing it would create a different method.

The selected 911 actions reported for the 137-case HG-SE cohort describe the retained paths. They do not include all work spent producing the two candidate trajectories. A full cost comparison includes both branches' physical queries, model calls, preparation and failures, with shared cached calls identified separately. Historical costs that have not been recovered remain unknown.

The later numerical D-SE comparator is a different construction: DFF plus DFF-ALT with the unchanged selector. It tests whether an alternative numerical trajectory provides the benefit attributed to the language branch. The manuscript's HG-SE result alone does not establish an advantage over this stronger comparator.

## Extent of the original physical verification

This matrix describes the inspected original source functions and their configured solver call. It does not certify every study in the thesis or replace independent trajectory replay. The 0.95–1.05 reporting band and the native 1.06 acceptance guard must be reported together. Source scope is stated explicitly because a numerical verifier can enforce only the conditions actually implemented.

| Condition | Evidence level | What the source does and does not establish |
| --- | --- | --- |
| Power-flow convergence | Explicit acceptance condition | run_pf uses Newton–Raphson, automatic initialisation, voltage angles, enforce_q_lims=True and max_iteration=80. A failed solve rejects the candidate. Convergence is not a complete feasibility certificate. |
| Lower-voltage behaviour | Explicit acceptance condition | UV uses Vm < 0.95. UV count may not increase; total deficit may not increase by more than 1e-9. At least UV count, deficit or minimum voltage must improve under the coded tolerances. |
| Upper-voltage behaviour | Guard and reporting differ | Native acceptance rejects max Vm > 1.06. Strict OV reports Vm > 1.05. An accepted action can therefore retain strict OV, and zero UV does not imply whole-band restoration. |
| Added reactive support | Explicit source resource check | Cumulative support from shunts identified as LLM-added is capped at 450 Mvar per bus. Positive support is applied using the negative-q pandapower shunt convention. This cap is not a complete device capability model. |
| Bus and action admissibility | Distributed across source interfaces | Parser, zone menus, action signatures and source resource state restrict proposals. The verifier function alone is not a complete certificate of every possible packet or device rating. |
| Generator limits | Partial solver setting only | enforce_q_lims=True is configured. verify_action does not independently certify all generator active/reactive limits, slack limits or capability curves at every accepted endpoint. |
| Branch thermal and angle limits | Not an explicit acceptance test here | verify_action contains no separate branch-loading, thermal-rating or angle-difference rejection. A voltage-accepted action must not be called fully AC-feasible on this evidence. |
| Dynamics and cybersecurity | Not evaluated by this verifier | Transient/frequency stability, protection coordination, contingencies and attack resilience are not established by the steady-state voltage acceptance function. |
