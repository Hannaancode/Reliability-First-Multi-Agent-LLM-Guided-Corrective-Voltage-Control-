"""New closed-data necessity audit, not a policy, simulator or training run.

Only OPT targets are analysed. Historical held identities remain denominators.
The maximum-score statement is conditional on an identical evaluated set.
"""
import ast
import copy
import gzip
import hashlib
import json
import math
import os
import time
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks

R = ROOT / 'outputs/critical_research_reset_20261010'
B = ROOT / 'outputs/llm_value_candidate_development_20261009'
C = B / 'input_and_target_contract_nullable_v2'
S = B / 'current_added_support_observables'
OUT = R / 'one_step_oracle_and_query_measurement_audit'
assert not OUT.exists(), 'No duplicate or failed-audit restart'
OUT.mkdir()
start = time.perf_counter()
write(OUT / 'audit.claim', {'actual_pid': os.getpid(), 'source': str(Path(__file__))})
canonical = lambda x: json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False)
digest = lambda x: hashlib.sha256(canonical(x).encode()).hexdigest()
Q = (25., 50., 75., 100., 125., 150., 200., 250., 300.)
controller = ROOT / 'work/e/audit/phase2g_rescue_runner.py'
selector = ROOT / 'work/e/audit/run_reflection_v4_safety_envelope.py'
sources = [C / 'Current_Input_Rows.jsonl.gz', C / 'Measured_Target_Rows.jsonl.gz',
           C / 'World_and_Invalid_Denominators.json', C / 'protocol.json',
           S / 'Current_Control_State_Observables.jsonl.gz', controller, selector,
           ROOT / 'work/dff_alt.py', Path(__file__)]
protocol = {
    'declared_at_utc': datetime.now(timezone.utc).isoformat(),
    'purpose': 'Test one-step oracle domination, grammar-versus-physics and query/episode target coverage before proposing more learning',
    'population': 'All239 OPT inputs/23 previously fixed worlds; analyse all their targets. Retain72 historical-held identities without new held outcome metrics and original invalid denominator.',
    'no_new_policy_or_changed_action_universe': True,
    'normal_upper_guard': {'upper': 1.05, 'tolerance': 1e-8},
    'scope_of_theorem': 'A selector supported on the SAME verified finite candidate set cannot strictly exceed its exact original lexicographic maximum. No assertion about another set, verifier, state, horizon or latency.',
    'missing_candidates_or_successor_vectors_are_unknown': True,
    'no_implicit_scalar_reward_or_synthetic_grid_outcomes': True,
    'source_sha256': {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in sources},
    'new_model_optimizer_PF_controller_derivative_linear_solve_forecast_cloud_calls': 0,
}
write(OUT / 'Prospective_Necessity_Audit.json', protocol)
for folder, names in ((C, ('Current_Input_Rows.jsonl.gz', 'Measured_Target_Rows.jsonl.gz', 'World_and_Invalid_Denominators.json', 'protocol.json')),
                      (S, ('Current_Control_State_Observables.jsonl.gz',))):
    manifest = read(folder / 'manifest.json')
    for n in names:
        assert sha(folder / n) == manifest[n]['sha256']
        assert (folder / n).stat().st_size == manifest[n]['bytes']
prior = read(B / 'input_and_target_contract_operational_v3_audit/Independent_Current_Input_and_Measured_Target_Audit.json')
assert prior['all_current_input_identity_scope_label_boundaries_passed']
assert prior['exact_recorded_original_scores_verified'] == 38727
assert prior['data_manifest_sha256'] == sha(C / 'manifest.json')
matched = read(ROOT / 'outputs/matched_campaign_protocol.json')
matched_sources = {k.replace('\\', '/'): v for k, v in matched['source_sha256'].items()}
for p in (controller, selector):
    assert sha(p) == matched_sources[str(p.relative_to(ROOT)).replace('\\', '/')]
tree = ast.parse(controller.read_text(encoding='utf8'))
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'score_candidate')
ns = {}
exec(compile(ast.Module(body=[copy.deepcopy(fn)], type_ignores=[]), '<original pure score only>', 'exec'), ns)
score = ns['score_candidate']
selection_tree = ast.parse(selector.read_text(encoding='utf8'))
dff = next(n for n in selection_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run_one_scenario_no_llm_fallback_first')
best_assignments = [n for n in ast.walk(dff) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'best' for t in n.targets)]
assert len(best_assignments) == 1
assert ast.unparse(best_assignments[0].value) == 'max(accepted, key=runner.rescue.score_candidate)'

def lines(path):
    with gzip.open(path, 'rt', encoding='utf8') as f:
        for line in f:
            yield json.loads(line)

inputs = {}
for r in lines(sources[0]):
    oid = r['observation_id']
    assert oid not in inputs and set(r['model_input']) == {'current_physical_observation', 'original_Q_grid'}
    assert tuple(r['model_input']['original_Q_grid']) == Q
    assert digest(r['model_input']) == r['model_input_sha256']
    assert digest(r['model_input']['current_physical_observation']) == oid
    inputs[oid] = r
support = {r['observation_id']: r for r in lines(sources[4])}
assert set(support) == set(inputs) and len(inputs) == 311
partition = read(C / 'protocol.json')
opt_worlds = set(partition['optimization_world_sha256'])
held_worlds = set(partition['development_held_world_sha256'])
assert len(opt_worlds) == 23 and len(held_worlds) == 8 and not opt_worlds & held_worlds
assert Counter(r['split'] for r in inputs.values()) == {'optimization': 239, 'development_held': 72}
targets = {}
held_target_ids = []
for r in lines(sources[1]):
    oid = r['observation_id']
    assert oid in inputs and inputs[oid]['world_sha256'] == r['world_sha256'] and inputs[oid]['split'] == r['split']
    if r['split'] == 'development_held':
        held_target_ids.append(oid)
        continue  # No new held target/outcome performance analysis.
    assert oid not in targets and r['world_sha256'] in opt_worlds
    targets[oid] = r
assert len(targets) == 187 and len(held_target_ids) == 51

records, counts = [], Counter()
known_safe_worlds = set()
known_clearance_worlds = set()
for oid, r in sorted(inputs.items()):
    if r['split'] != 'optimization':
        continue
    assert r['world_sha256'] in opt_worlds
    obs = r['model_input']['current_physical_observation']
    added = support[oid]['current_added_support_MVAr_by_bus']
    assert len(added) == 118 and all(type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 450 for v in added)
    pools = obs['raw_common_and_zone_pools']
    buses = set(b for pool in pools.values() for b in pool)
    legal = {(b, j) for b in buses for j, q in enumerate(Q) if added[b] + q <= 450.}
    measured, guarded, original = {}, {}, {}
    finite_after = unknown_after = convergence_unknown = 0
    finite_full_successor_vectors = 0
    for c in targets.get(oid, {}).get('measured_candidates', []):
        t = c['target']
        pair = (t['bus'], t['Q_index'])
        assert pair not in measured and type(pair[0]) is int and type(pair[1]) is int
        assert pair[0] in buses and 0 <= pair[1] < len(Q)
        assert t['q_mvar'] == Q[pair[1]]
        assert t['action'] == {'add_shunts_q_mvar': {str(pair[0]): Q[pair[1]]}}
        v = t['recorded_verifier']
        assert type(v['accepted']) is bool and type(v['original_verifier_accepted']) is bool
        assert t['convergence_reported'] is (type(v['converged']) is bool)
        convergence_unknown += int(v['converged'] is None)
        assert t['not_full_successor_or_episode_reward'] is True
        after = v.get('after')
        finite = type(after) is dict and all(type(after.get(k)) in (int, float) and math.isfinite(after[k])
                                         for k in ('vmin', 'vmax', 'vmean', 'uv_count', 'ov_count', 'deficit_sum'))
        assert bool(t['has_finite_after_global_metrics']) == finite
        finite_after += int(finite)
        unknown_after += int(not finite)
        assert list(score({'action': t['action'], 'verif': v})) == t['recorded_original_score']
        measured[pair] = t
        if pair not in legal:
            counts['known_precheck_cap_rejections'] += 1
            assert not v['accepted'] and not v['original_verifier_accepted']
            continue
        counts['grammar_legal_known_targets'] += 1
        if v['accepted']:
            assert finite and v['original_verifier_accepted'] and v['converged'] is True
            assert after['vmax'] <= 1.05 + 1e-8
            guarded[pair] = tuple(t['recorded_original_score'])
            counts['grammar_legal_known_guarded_accepted'] += 1
        else:
            counts['grammar_legal_known_guarded_rejected'] += 1
        if v['original_verifier_accepted']:
            assert finite and v['converged'] is True
            ov = dict(v, accepted=True)
            original[pair] = score({'action': t['action'], 'verif': ov})
        if finite:
            assert set(after) == {'vmin', 'vmax', 'vmean', 'uv_count', 'ov_count', 'deficit_sum'}
        counts['unique_OPT_measured_targets'] += 1
    legal_measured = set(measured) & legal
    complete = legal_measured == legal
    if complete:
        counts['states_scope_cap_universe_fully_recorded'] += 1
    else:
        counts['states_scope_cap_universe_not_fully_recorded'] += 1
    missing = legal - legal_measured
    original_best = max(original.values(), default=None)
    guarded_best = max(guarded.values(), default=None)
    if guarded_best is not None:
        assert all(x <= guarded_best for x in guarded.values())
        counts['guarded_candidate_domination_comparisons'] += len(guarded)
        counts['states_with_known_guarded_action'] += 1
        known_safe_worlds.add(r['world_sha256'])
    if original_best is not None:
        assert all(x <= original_best for x in original.values())
        counts['original_candidate_domination_comparisons'] += len(original)
        counts['states_with_known_original_action'] += 1
    rejected = sorted(legal_measured - set(guarded))
    mixed = bool(guarded and rejected)
    if mixed:
        counts['states_grammar_allows_both_guarded_accepted_and_rejected'] += 1
    originally_best_pairs = sorted(k for k, val in original.items() if val == original_best)
    all_original_best_guard_rejected = bool(originally_best_pairs) and all(k not in guarded for k in originally_best_pairs)
    if all_original_best_guard_rejected:
        counts['states_all_recorded_original_maximizers_guard_rejected'] += 1
    clears = sorted(k for k in guarded if obs['global_metrics']['uv_count'] > 0 and measured[k]['recorded_verifier']['after']['uv_count'] == 0)
    if clears:
        counts['nontrivial_states_with_known_protected_one_step_UV_clearance'] += 1
        known_clearance_worlds.add(r['world_sha256'])
    witness = None
    if mixed:
        a, b = min(guarded), rejected[0]
        witness = {'accepted_action': list(a), 'rejected_action': list(b),
                   'accepted_score': list(guarded[a]),
                   'rejected_reason': measured[b]['recorded_verifier']['reason'],
                   'both_pass_raw_scope_original_Q_and_450_cap': True,
                   'not_a_new_PF_or_global_impossibility_claim': True}
    records.append({
        'observation_id': oid, 'world_sha256': r['world_sha256'], 'model_input_sha256': r['model_input_sha256'],
        'current_UV': obs['global_metrics']['uv_count'], 'scope_cap_legal_actions': len(legal),
        'measured_targets_including_precheck_failures': len(measured), 'grammar_legal_measured_actions': len(legal_measured),
        'unmeasured_legal_actions_unknown': len(missing), 'scope_cap_universe_fully_recorded': complete,
        'known_guarded_accepted': len(guarded), 'known_original_accepted': len(original),
        'recorded_guarded_maximum': list(guarded_best) if guarded_best is not None else None,
        'recorded_original_maximum': list(original_best) if original_best is not None else None,
        'all_original_maximizers_guard_rejected': all_original_best_guard_rejected,
        'known_nontrivial_protected_clearance_actions': len(clears),
        'finite_after_global_only': finite_after, 'unknown_after': unknown_after, 'unreported_convergence_unknown': convergence_unknown,
        'full_candidate_successor_vectors_in_this_target_file': finite_full_successor_vectors,
        'grammar_safety_counterexample': witness,
        'candidate_sequence_return_or_online_query_history_in_this_target_file': False,
        'missing_literal_failed_signature_history_not_assumed_reconstructed': True,
        'oracle_maximum_is_diagnostic_not_a_free_online_controller': True,
    })

assert len(records) == 239
assert counts['unique_OPT_measured_targets'] + counts['known_precheck_cap_rejections'] == 30510
truth = [Fraction(3, 5), Fraction(2, 5)]
prediction_A = [Fraction(1), Fraction(0)]
prediction_B = [Fraction(49, 100), Fraction(51, 100)]
mse = lambda p: sum((x - y)**2 for x, y in zip(p, truth)) / 2
assert mse(prediction_B) < mse(prediction_A)
assert prediction_A.index(max(prediction_A)) == truth.index(max(truth))
assert prediction_B.index(max(prediction_B)) != truth.index(max(truth))
algebra = {
    'finite_argmax_argument': 'For nonempty finite A and an unchanged lexicographic score F, M=max(F(a):a in A). Every a in A has F(a)<=M. A randomized policy supported on A cannot emit a score strictly above M. Different trajectory outcomes and lower total costs are separate questions.',
    'guard_subset_argument': 'A common deterministic normal-upper guard only removes accepted actions. Any resulting safety gain must also be available to a numerical comparator with that guard; it does not identify learned contribution.',
    'grammar_argument': 'If the same current finite scope/cap grammar admits a known protected action and a known rejected action, grammar membership alone does not certify the saved physical verifier outcome.',
    'exact_synthetic_nonphysical_MSE_witness': {
        'true_utilities': [str(x) for x in truth], 'prediction_A': [str(x) for x in prediction_A],
        'prediction_B': [str(x) for x in prediction_B], 'MSE_A': str(mse(prediction_A)), 'MSE_B': str(mse(prediction_B)),
        'lower_MSE_B_selects_worse_action': True, 'not_grid_measurements_or_new_labels': True,
    },
    'not_proof_every_future_LLM_or_long_horizon_policy_fails': True,
}
write(OUT / 'All239_OPT_Action_And_Target_Records.json', records)
write(OUT / 'Scoped_Mathematical_Arguments.json', algebra)
summary = {
    'completed_at_utc': datetime.now(timezone.utc).isoformat(), 'all_source_input_scope_score_checks_passed': True,
    'OPT_inputs': len(records), 'OPT_worlds': len(opt_worlds), 'OPT_labelled_states': len(targets),
    'held_input_identities_retained_without_new_held_outcome_metrics': len(inputs) - len(records),
    'held_target_identities_retained_without_new_held_outcome_metrics': len(held_target_ids),
    'original_invalid_denominator_source': str(sources[2].relative_to(ROOT)).replace('\\', '/'),
    'counts': dict(counts), 'unmeasured_scope_cap_legal_OPT_actions_unknown': sum(x['unmeasured_legal_actions_unknown'] for x in records),
    'states_with_unknown_after': sum(x['unknown_after'] > 0 for x in records),
    'known_safe_action_worlds': len(known_safe_worlds), 'known_nontrivial_protected_one_step_clearance_worlds': len(known_clearance_worlds),
    'full_candidate_successor_vectors_in_this_target_file': 0,
    'general_maximum_claim_conditional_on_identical_set_score_verifier_state': True,
    'complete_scope_cap_table_not_claimed_exact_literal_DFF_failed_signature_history': True,
    'neither_saved_oracle_nor_guard_or_grammar_is_measured_LLM_value': True,
    'new_model_optimizer_PF_controller_derivative_linear_solve_forecast_cloud_calls': 0,
    'elapsed_analysis_seconds': time.perf_counter() - start,
    'decision': 'Do not justify same-state quality superiority by distilling an already exact immediate argmax. Separate a costed learned search hypothesis from a prospectively measured horizon hypothesis; neither is ready for GPU training from these global-only labels.',
}
write(OUT / 'summary.json', summary)
write(OUT / 'Fresh_Local_Frozen_Asset_Checks.json', frozen_checks())
files = {p.name: p for p in OUT.iterdir() if p.is_file()}
files['source/Audit.py'] = Path(__file__)
audit = seal(OUT, files, 'One_Step_Oracle_And_Target_Necessity.zip')
print(json.dumps({'summary': summary, 'archive': audit}, indent=2))
