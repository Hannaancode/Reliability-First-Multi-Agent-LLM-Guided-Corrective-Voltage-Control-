# Verified equal-operation benchmark

Fixed development gate: **PASS_DEVELOPMENT_EQUAL_OPERATION_OPPORTUNITY**. Three strictUVwins, oneUVtie, zeroUVlosses. Allfourinspecteddevelopmentroots retained.

| State | Complete two-ordinary greedy UV | One joint transfer, two charged operations UV |
|---|---:|---:|
| fed_combined_load_1p5_line_35_MG1 | 10 | 10 |
| fed_combined_load_1p5_line_36_MG1 | 24 | 23 |
| fed_combined_load_1p5_line_84_MG2 | 24 | 23 |
| fed_combined_load_1p5_line_127_MG3 | 12 | 8 |

Fourthroot: all144native secondordinarycandidates closed after completegreedyfirstaction;0accepted (75normal-uppermediated,2caprefused plus other native rejections). JointtwooperationUV8 versus ordinarygreedyUV12. Scoped discrete state/witness, not globalimpossibility.

FirstrootUVties10 but joint minimumvoltage is slightly lower. Retain allmetrics; do not claim universalPareto dominance.

Actual766PFattempts/returns,0exceptions,3declaredindependentreplays;50.48697solverseconds and75.51119preservationseconds nested in218.98599ownedseconds beforeclosure. Originalfirst/joint/reconstruction/training/preparation/failures remain separately paid. This does not prove deploymentlatency improvement.

The originalone-movejoint advantage survives an equal two-operation allowance against completeordinarygreedy. It does not establish whole25-stepDFF/DSEsuperiority, a globaltwo-action optimum, fieldhardwareavailability, novelty or incrementalLLMvalue. Fourinitialstates were alreadyinspecteddevelopment.

Freeze complete-trajectory development benchmark with originalliteralDFF,DFFALT,unchangedDSE/FULLBOTHcosts, equallycapable same-actuation numerical controls and actual jointcursor/persistent query-commit/fullreplay gates. No automatic rollout or novelty/90%claim; unusedconfirmation required.
