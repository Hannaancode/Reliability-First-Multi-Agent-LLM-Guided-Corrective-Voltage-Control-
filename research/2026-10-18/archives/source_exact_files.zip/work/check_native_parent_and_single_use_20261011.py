"""PF-free actual root/later input integration plus labelled consumption control."""
import copy,hashlib,json,os,platform,time
from pathlib import Path
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
import numpy as np,pandas as pd,scipy,pandapower as pp
from frozen_physics_loader import load_stack,AUDIT
from native_historical_parent_provider import materialize_parent,read,sha,extended
from trusted_causal_controller_snapshot import SOLVER_ROLES
from value_normal_band_mediation import NormalUpperMediation
import native_continuation_once as single
ROOT=Path(__file__).resolve().parents[1]
OUT=extended(ROOT/'outputs/critical_research_reset_20261010/native_parent_single_use_integration_20261011')
DATA=ROOT/'outputs/critical_research_reset_20261010/native_cached_contexts_20261011'
NET=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'
META=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
SCOPE=ROOT/'outputs/critical_research_reset_20261010/recovered_native_scope_handoff_20261011/Verified_Scope_And_Resume_Checkpoint.json'
PHYS=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3/protocol.json'
def write(path,v):
 with path.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
 OUT.mkdir(exist_ok=False);start=time.perf_counter();index=read(DATA/'Descriptor_Index.json');physics=read(PHYS)
 world=min(r['world_sha256'] for r in index)
 # Structural root/later source integration fixtures; not a chosen performance subset.
 targets=[next(r for r in index if r['world_sha256']==world and r['branch']=='DFF' and r['after_commit']==k) for k in [0,1]]
 sources=['work/native_historical_parent_provider.py','work/native_continuation_once.py','work/native_continuation_preservation_v2.py','work/native_continuation_preservation.py','work/frozen_physics_loader.py','work/trusted_causal_controller_snapshot.py','work/value_normal_band_mediation.py','work/train_trajectory_measurement_nullable_v2.py']
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'dependency_sha256':{p:sha(ROOT/p) for p in sources},'inputs_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [DATA/'Descriptor_Index.json',SCOPE,PHYS,NET,META]},'exact_structural_targets':targets,'rule':'Lexicographically first OPT world, DFF after0 andafter1; software only, not performance selection','resource_seconds':120,'new_physics_model_optimizer_fit_converter_derivative_forecast_cloud_calls':0,'planned_labelled_stub_execution_callbacks':2,'no_real_native_loop_execution':True,'held8_outcomes_unread':True}
 write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':Path(__file__).name,'protocol_sha256':sha(OUT/'Protocol.json')})
 original_solvers={n:getattr(pp,n) for n in ['runpp','rundcpp','runopp','runpp_3ph'] if hasattr(pp,n)};forbidden=[]
 def forbid(*a,**kw):forbidden.append('solver');raise BaseException('No physics permitted during input/ownership integration')
 for n in original_solvers:setattr(pp,n,forbid)
 rows=[];rejections=[];stub_calls=[]
 try:
  v2,runner,reflection=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
  assert sha(NET)==physics['network_sha256'] and sha(META)==physics['metadata_sha256']
  base=pp.from_json(str(NET));zones={z:[int(b) for b in buses] for z,buses in read(META)['zones'].items()}
  source_pins={a['file']:a['sha256'] for a in AUDIT};deadline=(datetime.now(timezone.utc)+timedelta(seconds=90)).isoformat()
  for row in targets:
   assert time.perf_counter()-start<120,'Bound exceeded; no retry'
   net,prefix,node,certificate=materialize_parent(ROOT,DATA/row['path'],row['sha256'],base,zones,v2,runner,physics,read(SCOPE))
   process={'schema_version':1,'snapshot_id':'INPUT_BINDING_'+str(node['after_commit']),'episode_identity':node['scenario_id'],'phase':'PRE_SELECTION','after_commit':node['after_commit'],'next_iteration':node['after_commit']+1,'remaining_slots':25-node['after_commit'],'continuation_mode':'ORDINARY_DFF','failed_signatures':[],'guard':{'upper':1.05,'tolerance':1e-8},'source_sha256':source_pins,'runtime_identity':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'pandapower':pp.__version__,'execution_kind':'PF_FREE_HISTORICAL_INPUT_RECIPE_INTEGRATION_NOT_NEW_PHYSICS'},'solver_roles':SOLVER_ROLES,'policy_configuration':{'per_bus_named_shunt_cap':450,'q_grid':[25,50,75,100,125,150,200,250,300],'maximum_iterations':25,'candidate_order':'BUS_ASCENDING_THEN_Q_GRID','selection':'ORIGINAL_LEXICOGRAPHIC_FIRST_EXACT_TIE'},'zone_configuration':{'zones':zones,'order':sorted(zones)},'cost_counters':{'PF_attempts':0,'PF_returns':0,'PF_exceptions':0},'absolute_deadline_utc':deadline,'execution_authorized':False}
   original_verify=runner.rescue.verify_action
   with NormalUpperMediation(runner.rescue,1.05,1e-8) as mediation:
    execute,control=single.prepare_once(reflection,runner,net,process,prefix,sha(Path(reflection.__file__)))
    try:execute()
    except ValueError as exc:assert 'exclusive owner' in str(exc);rejections.append({'fixture':node['after_commit'],'unowned_before_execute':True})
    else:raise AssertionError('Unowned actual handle executed')
    assert mediation.events==[]
   assert runner.rescue.verify_action==original_verify
   rows.append({'exact_target':row,'parent_certificate':certificate,'actual_single_use_preparation_certificate':control,'no_native_loop_or_PF_executed':True,'normal_band_context_installed_and_restored_no_verify_calls':True})
  try:materialize_parent(ROOT,DATA/targets[0]['path'],'0'*64,base,zones,v2,runner,physics,read(SCOPE))
  except ValueError as exc:assert 'descriptor pin' in str(exc);rejections.append({'wrong_external_pin_before_recipe':True})
  else:raise AssertionError('Wrong descriptor accepted')
  # Only the newly implemented handle-consumption logic, with expressly fake
  # execution callbacks. No native simulator/policy call is made by these stubs.
  old_prepare=single.prepare_continuation;stub_runner=SimpleNamespace()
  try:
   for kind in ['returned_stub','failed_stub']:
    def fake_prepare(*args,**kwargs):
     def callback():
      stub_calls.append(kind)
      if kind=='failed_stub':raise RuntimeError('LABELLED_CONTROL_FAILURE_NOT_SCIENCE')
      return 'LABELLED_CONTROL_RETURN_NOT_SCIENCE'
     return callback,{'stub':True}
    single.prepare_continuation=fake_prepare
    execute,cert=single.prepare_once(None,stub_runner)
    try:execute()
    except ValueError:pass
    else:raise AssertionError('Unowned fake handle ran')
    stub_runner._native_preservation_owner=os.getpid()
    try:answer=execute()
    except RuntimeError as exc:assert kind=='failed_stub' and 'LABELLED_CONTROL_FAILURE' in str(exc)
    else:assert kind=='returned_stub' and answer=='LABELLED_CONTROL_RETURN_NOT_SCIENCE'
    before=len(stub_calls)
    try:execute()
    except ValueError as exc:assert 'already consumed' in str(exc)
    else:raise AssertionError('Consumed handle ran twice')
    assert len(stub_calls)==before;del stub_runner._native_preservation_owner
  finally:single.prepare_continuation=old_prepare
  assert len(stub_calls)==2 and not forbidden
  assert sha(NET)==physics['network_sha256'] and sha(META)==physics['metadata_sha256']
  results={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_root_and_later_parent_preparations':2,'network_decodes':1,'pure_scenario_recipe_applications':2,'pure_action_recipe_applications':1,'actual_native_loop_executions':0,'labelled_stub_callbacks':stub_calls,'rejections':rejections,'consumed_return_and_exception_handles_blocked_second_call':True,'new_PF_model_optimizer_fit_converter_derivative_forecast_cloud_calls':0,'workflow_seconds_before_report_manifest':time.perf_counter()-start,'current_runtime_execution_equivalence_UNTESTED':True,'physics_sequence_learning_performance_UNTESTED':True,'no_scientific_owner_or_campaign_ready':True,'integration_rows':rows,'source_AST_audit':AUDIT}
  write(OUT/'Results.json',results);write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.relative_to(OUT).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
  print(json.dumps({k:v for k,v in results.items() if k not in ['integration_rows','source_AST_audit','rejections']}))
 finally:
  for n,value in original_solvers.items():setattr(pp,n,value)
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'state':'TERMINAL_INPUT_INTEGRATION_PARTIAL_NO_AUTOMATIC_RETRY','exception':type(exc).__name__,'message':str(exc),'actual_pid':os.getpid(),'new_scientific_calls':0})
  raise
