"""Complete operation-aware receding control; caller owns real paid science.

Only the first selected move is committed. Observed state then replaces the
lookahead hypothesis and the policy replans within its original operation bound.
No model, solver, checkpoint writer or launch is hidden in this module.
"""
import copy
from operation_aware_paid_lookahead_v1 import metrics_value,MissingEvidence

METHODS=('immediate1_followup16','breadth4_followup4')

def run(net,cursor,*,mode,observe,search,commit,checkpoint,event,admit):
    if mode not in METHODS:raise ValueError('Prospectively fixed controller required')
    if cursor['original_device_operation_budget']!=25:raise ValueError('Original bound must stay25')
    initial_cursor=copy.deepcopy(cursor);initial=observe(net);metrics_value(initial)
    records=[];reason=None
    while True:
        admit();before=observe(net);metrics_value(before)
        if before['uv_count']==0:reason='full_UV_restoration';break
        if cursor['remaining_original_device_operation_slots']==0:reason='original_operation_bound_exhausted';break
        event('receding_decision_started',{'mode':mode,'decision':len(records),'before':before,
            'remaining_original_operations':cursor['remaining_original_device_operation_slots']})
        proposed=search(net,cursor,mode)
        if proposed['status']=='complete_declared_menu_no_safe_first':
            if proposed['selected'] is not None:raise MissingEvidence('Contradictory no-safe-action result')
            reason='complete_current_native_menu_no_protected_accepted_action';break
        if proposed['status']!='complete_declared_bounded_horizon' or proposed['selected'] is None:
            raise MissingEvidence('Incomplete search is not a terminal or negative result')
        chosen=proposed['selected'];before_slots=cursor['remaining_original_device_operation_slots']
        # Callback must use the paid FIRST receipt, never directly substitute a
        # later hypothetical leaf for the next committed current state.
        net,next_cursor,record=commit(net,cursor,proposed)
        debit=record['device_operations_debited']
        if debit not in (1,2) or next_cursor['remaining_original_device_operation_slots']!=before_slots-debit:
            raise MissingEvidence('One first move must debit exactly its real device operations')
        if record['first_action_id']!=chosen['first'] or record['paid_successor_id']!=chosen['first_successor']:
            raise MissingEvidence('First commitment/successor identity mismatch')
        after=observe(net);metrics_value(after)
        if after['vmax']>1.05+1e-8:raise MissingEvidence('Committed upper-band violation')
        if (after['uv_count']>before['uv_count'] or after['deficit_sum']>before['deficit_sum']+1e-9 or
            not (after['uv_count']<before['uv_count'] or after['deficit_sum']<before['deficit_sum']-1e-9 or after['vmin']>before['vmin']+1e-9)):
            raise MissingEvidence('Original native UV/deficit/minimum improvement guard')
        cursor=next_cursor;records.append(record)
        checkpoint(net,cursor,{'mode':mode,'decision':len(records),'phase':'REPLAN_FROM_ACTUAL_COMMITTED_FIRST_SUCCESSOR',
            'lookahead_second_is_not_automatically_committed':True})
    final=observe(net)
    result={'mode':mode,'initial_metrics':initial,'final_metrics':final,'stop_reason':reason,
        'new_device_operations':initial_cursor['remaining_original_device_operation_slots']-cursor['remaining_original_device_operation_slots'],
        'remaining_original_operations':cursor['remaining_original_device_operation_slots'],'commits':records,
        'whole_original_DSE_or_incremental_LLM_attribution':'NOT_ESTABLISHED_BY_THIS_COMPONENT'}
    event('receding_controller_closed',result)
    return net,cursor,result
