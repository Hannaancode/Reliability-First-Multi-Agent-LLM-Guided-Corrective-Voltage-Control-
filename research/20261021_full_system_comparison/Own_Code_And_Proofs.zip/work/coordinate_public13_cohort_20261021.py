"""Sole sequential primary/reader handoff; no restart or budget extension."""
import json,os,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
from run_public13_remaining_published_cohort_20261021 import put,sha
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/public13_full_cohort_preparation_20261021';OUT=ROOT/'outputs/public13_full_cohort_handoff_20261021'
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()});p=json.loads((PREP/'Protocol.json').read_text())
    for n,h in p['source_and_input_hashes'].items():assert sha(ROOT/n)==h
    for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
        with (OUT/(name+'.log')).open('x',encoding='utf-8') as log:
            code=subprocess.call([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(ROOT/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str((PREP/name).relative_to(ROOT))],cwd=ROOT,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        put(OUT/(name+'.End.json'),{'exit_code':code,'at_utc':datetime.now(timezone.utc).isoformat()});assert code==0,'Preserve terminal failure; no automatic scientific or reader retry'
    put(OUT/'Completion.json',{'status':'PRIMARY_AND_SOLE_INDEPENDENT_READER_ENDED','at_utc':datetime.now(timezone.utc).isoformat()})
if __name__=='__main__':main()
