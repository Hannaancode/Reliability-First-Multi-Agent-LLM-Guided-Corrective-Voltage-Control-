"""Single external saved-artifact reader; zero model/PF/controller reruns."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import collections,json,math,os,subprocess
import torch
torch.set_num_threads(2)
from candidate_process_evidence_utils import ROOT,read,sha,write,frozen_checks,seal
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';DATA=BASE/'numerical_process_pilot';OUT=BASE/'numerical_process_pilot_audit'
assert not OUT.exists(),'No duplicate reader or outcome reanalysis';OUT.mkdir()
with (OUT/'audit.claim').open('x',encoding='utf-8') as f:json.dump({'owner_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()},f)
pid=read(DATA/'owner.claim')['owner_pid']
inventory=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
assert not inventory.stdout.strip(),'Reader waits for actual scientific owner end'
summary=read(DATA/'summary.json');protocol=read(DATA/'protocol.json');assert summary['all_declared_training_identity_checkpoint_cost_gates_passed']
for n,m in read(DATA/'manifest.json').items():assert sha(DATA/n)==m['sha256'] and (DATA/n).stat().st_size==m['bytes']
for n,h in protocol['source_hashes'].items():assert sha(ROOT/n)==h
cache=BASE/'tensor_readiness_v2';assert sha(cache/'manifest.json')==protocol['cache_manifest_sha256']
inputs=read(cache/'Input_Index.json');target_index=read(cache/'Target_Index.json');byid={r['observation_id']:r for r in inputs}
events=[json.loads(s) for s in (DATA/'Actual_Event_Journal.jsonl').read_text(encoding='utf-8').splitlines()]
attempts=[e for e in events if e['event']=='forward_attempt'];returns=[e for e in events if e['event']=='forward_return']
steps=[e for e in events if e['event']=='optimizer_return'];backwards=[e for e in events if e['event']=='backward_attempt']
assert len(attempts)==len(returns)==1868 and len(steps)==len(backwards)==935
assert [e['call'] for e in attempts]==[e['call'] for e in returns]==list(range(1,1869))
assert [(e['observation_id'],e['phase']) for e in attempts]==[(e['observation_id'],e['phase']) for e in returns]
train=sorted((r for r in target_index if r['split']=='optimization'),key=lambda r:r['observation_id'])
assert [e['step'] for e in steps]==list(range(1,936))
for epoch in range(1,6):
    expected=[r['observation_id'] for r in train]
    assert [e['observation_id'] for e in steps if e['epoch']==epoch]==expected
    assert [e['observation_id'] for e in attempts if e['phase']=='training_epoch_'+str(epoch)]==expected
    assert [e['observation_id'] for e in backwards if e['epoch']==epoch]==expected
    for e in steps:
        assert math.isfinite(e['loss']) and math.isfinite(e['gradient_norm'])
for e in backwards:
    meta=byid[e['observation_id']];assert e['world_weight']==187/(protocol['active_optimization_worlds_with_labels']*protocol['optimization_world_target_counts'][meta['world_sha256']])
assert not any(e['event'] in ('forward_exception','terminal_failure') for e in events)
stats=summary['counts'];assert stats['numerical_forward_attempts']==stats['numerical_forward_returns']==1868
assert stats['backward_calls']==stats['optimizer_steps']==935 and stats['forward_exceptions']==stats['optimizer_exceptions']==0
assert stats['typed_record_inputs']==sum(byid[e['observation_id']]['typed_records'] for e in attempts)
assert stats['value_utf8_input_bytes']==sum(byid[e['observation_id']]['value_utf8_bytes'] for e in attempts)
assert stats['pretrained_calls']==stats['PF_calls']==stats['controller_calls']==stats['cloud_calls']==0
saved={phase:torch.load(DATA/(phase+'_scores.pt'),weights_only=True) for phase in ('untrained','final_epoch5','fresh_checkpoint_reload')}
allids=set(byid);assert len(allids)==311
for phase,scores in saved.items():
    assert set(scores)==allids
    assert [e['observation_id'] for e in attempts if e['phase']==phase]==sorted(allids)
    assert all(p.shape==(118,9,7) and bool(torch.isfinite(p).all()) for p in scores.values())
assert all(torch.equal(saved['final_epoch5'][i],saved['fresh_checkpoint_reload'][i]) for i in allids)
assert read(DATA/'final_epoch5_records.json')==read(DATA/'fresh_checkpoint_reload_records.json')
checkpoint=torch.load(DATA/'Final_Epoch5_Checkpoint.pt',weights_only=True)
assert sum(t.numel() for t in checkpoint.values())==protocol['model_parameters']==8797814
normal=read(cache/'Target_Normalization.json');world_errors={};classification={};coverage={};priority_counts={}
for phase in ('untrained','final_epoch5'):
    worlds={};class_worlds={};priority_worlds={};records={r['observation_id']:r for r in read(DATA/(phase+'_records.json')) if 'observation_id' in r}
    assert set(records)==allids
    for row in target_index:
        ident=row['observation_id'];world=row['world_sha256'];split=row['split'];target=torch.load(cache/row['tensor_path'],weights_only=True);p=saved[phase][ident]
        finite=target['regression_mask'];mse=float(((p[...,3:]-target['regression'])[finite]**2).mean())
        worlds.setdefault((split,world),[]).append(mse)
        mask=target['classification_mask'];brier=float(((torch.sigmoid(p[...,:3])-target['classification'])[mask]**2).mean())
        class_worlds.setdefault((split,world),[]).append(brier)
        diag=records[ident]['recorded_label_priority_diagnostic'];entry=priority_worlds.setdefault((split,world),[]);entry.append(diag)
        for k in (1,4,8):
            v=diag['model_priority'][str(k)]
            assert v['known_measured']+v['unmeasured_unknown']==v['actual_available_predictions']
            assert 0<=v['known_accepted']<=v['known_measured']
    result={};bresult={};dresult={}
    for split in ('optimization','development_held'):
        means=[sum(v)/len(v) for (s,w),v in worlds.items() if s==split];result[split]={'equal_world_standardized_gain_MSE':sum(means)/len(means),'actual_worlds_with_measured_targets':len(means),'actual_states':sum(len(v) for (s,w),v in worlds.items() if s==split)}
        means=[sum(v)/len(v) for (s,w),v in class_worlds.items() if s==split];bresult[split]=sum(means)/len(means)
        dresult[split]={}
        for arm in ('model_priority','current_lowestVm_then_Q_secondary'):
            dresult[split][arm]={}
            for k in (1,4,8):
                rates=[];tot={'oracle_supported_states':0,'recorded_best_score_included_states':0,'unmeasured_predictions_unknown':0,'known_predicted_candidates':0}
                for (s,w),ds in priority_worlds.items():
                    if s!=split:continue
                    supported=[d[arm][str(k)] for d in ds if d['known_admissible_oracle_exists']]
                    if supported:rates.append(sum(v['recorded_best_score_included'] for v in supported)/len(supported))
                    tot['oracle_supported_states']+=len(supported);tot['recorded_best_score_included_states']+=sum(v['recorded_best_score_included'] for v in supported)
                    tot['unmeasured_predictions_unknown']+=sum(d[arm][str(k)]['unmeasured_unknown'] for d in ds)
                    tot['known_predicted_candidates']+=sum(d[arm][str(k)]['known_measured'] for d in ds)
                tot['equal_world_recorded_oracle_inclusion']=sum(rates)/len(rates) if rates else None
                dresult[split][arm][str(k)]=tot
    world_errors[phase]=result;classification[phase]=bresult;priority_counts[phase]=dresult
certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_hash_identity_journal_cost_checkpoint_gates_passed':True,
 'exact_current_input_identities':311,'exact_target_identities':238,'exact_optimizer_steps':935,'exact_forward_attempts_and_returns':1868,
 'all311_fresh_reloaded_scores_identical':True,'actual_parameter_count':8797814,'final_epoch5_only_verified':True,
 'invalid_and_unlabelled_denominators_retained':True,'data_is_grouped_historical_development':True,
 'zero_new_model_optimizer_PF_controller_cloud_calls_in_reader':True,'superiority_not_established':True,
 'closed_manifest_sha256':sha(DATA/'manifest.json'),'reader_source_sha256':sha(Path(__file__))}
results={'world_grouped_gain_errors':world_errors,'world_grouped_masked_classification_Brier':classification,
 'recorded_candidate_priority_diagnostics':priority_counts,'actual_compute':summary,
 'all_predeclared_K_values_retained':True,'unmeasured_predictions_not_labelled_success_or_failure':True,
 'not_a_DSE_rollout_or_LLM_contribution_result':True}
write(OUT/'Independent_Identity_Checkpoint_and_Cost_Audit.json',certificate);write(OUT/'Actual_Measured_Learning_Results.json',results)
write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
held0=world_errors['untrained']['development_held']['equal_world_standardized_gain_MSE'];held1=world_errors['final_epoch5']['development_held']['equal_world_standardized_gain_MSE']
text=f'''# Numerical candidate-process results

The independently verified numerical learner completed 935 CPU AdamW steps and 1,868 actual numerical forwards. All 311 final predictions reproduced exactly after a fresh checkpoint reload. The model has 8,797,814 parameters, 394 fewer than the original adapter reference. Zero pretrained/model-generation, controller, PF or cloud calls occurred.

On the eight historical held-development world groups, equal-world standardized measured-gain MSE changed from {held0:.6f} before training to {held1:.6f} at the fixed final epoch. Full per-world denominators, classification Brier and all K=1/4/8 recorded-oracle inclusion diagnostics are retained in Actual_Measured_Learning_Results.json. Unknown unmeasured candidate predictions remain unknown. One original invalid input, 73 unlabelled current states and four missing reused ledgers stay explicit.

This is numerical learning/data evidence, not a physical policy rollout, LLM contribution or superiority over literal D-SE. The raw current inputs, known support-cap rule and all targets must be common to later arms. An independently justified pretrained-body test and its attribution controls still require a separate prospective protocol and real integration. No parameter, Q, prompt, budget, seed or checkpoint sweep is authorized by these findings.
'''
(OUT/'Results.md').write_text(text,encoding='utf-8')
files={}
for p in DATA.iterdir():
    if p.is_file() and p.name not in {'status.json','owner.claim'}:files['closed_science/'+p.name]=p
for p in OUT.iterdir():
    if p.is_file() and p.name!='audit.claim':files[p.name]=p
for n in protocol['source_hashes']:files['sources/'+n]=(ROOT/n)
files['sources/work/'+Path(__file__).name]=Path(__file__)
files['tensor_external_audit.json']=BASE/'tensor_external_audit/Independent_Tensor_and_Target_Audit.json'
files['data_contract_archive_audit.json']=BASE/'data_contract_evidence/Local_Archive_Audit.json'
local=seal(OUT,files,'Numerical_Candidate_Process_Supplement.zip')
write(OUT/'manifest.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file() and p.name not in {'audit.claim','manifest.json'}})
print(json.dumps({'held_gain_MSE_before':held0,'held_gain_MSE_after':held1,'archive':local,'not_LLM_or_DSE_superiority':True},indent=2))
