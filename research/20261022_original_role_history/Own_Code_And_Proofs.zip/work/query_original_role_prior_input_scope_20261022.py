"""Read-only reuse of a closed PF-input component index for ALL45 new targets.

An exact rational physical component mismatch can exclude an indexed input.
A match or an unindexed lineage is UNKNOWN. This is not PF execution authority.
"""
import copy, gzip, hashlib, json, os, pickle, sys, time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_prior_input_scope_20261022'
P = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'
H = R / 'outputs/original_reflection_native_role_handoff_20261022'
I = R / 'outputs/prior_physical_query_footprints_20261018'

def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (O / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())

def main():
    O.mkdir(exist_ok=False); started = time.perf_counter()
    targets = H / 'Exact45_Missing_Paid_Action_Identities_NOT_Execution_Authority.json'
    indexpath = I / 'actual/Physical_Component_Input_References.json.gz'
    reader = R / 'work/audit_original_role_prior_input_scope_20261022.py'
    pins = [Path(__file__), reader, targets, P / 'Exact_Paid_Root_State_Bindings.json',
            I / 'actual/Closed_Manifest.json', I / 'actual/Result.json',
            I / 'independent_audit/Independent_Audit.json',
            R / 'work/prior_physical_query_footprints_20261018.py']
    write('Protocol.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
        'selection': 'ALL45 missing FIRST_ZONE identities; no selection from model proposals or physical outcomes',
        'fixed_seconds': 300, 'pins': {str(p.relative_to(R)): sha(p) for p in pins},
        'index': str(indexpath.relative_to(R)),
        'criterion': 'Exact binary-rational per-bus active shunt P/Q admittance including step and voltage ratio; zero matches excludes these60426 indexed attempts only',
        'matching_component_disposition': 'UNKNOWN_PENDING_FULL_INPUT_COMPARISON',
        'remaining_scope': 'Additional reference/fresh-root/later histories not closed by this query; no universal never-executed proof or new PF authority',
        'new_scientific_calls': 0})
    write('owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(Path(__file__))})
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    calls = []
    def forbidden(*a, **k): calls.append(True); raise BaseException('No physics in input-scope query')
    for name in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, name): setattr(pp, name, forbidden)
    from frozen_physics_loader import load_stack, AUDIT
    from prior_physical_query_footprints_20261018 import component
    _, runner, _ = load_stack()
    assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    old = read(I / 'actual/Result.json'); cert = read(I / 'independent_audit/Independent_Audit.json')
    assert old['status'] == 'COMPLETE_ALL_TRACKED_INPUT_COMPONENTS'
    assert cert['status'] == 'PASS_ALL60426_TRACKED_PF_INPUT_COMPONENT_REFERENCES_AND_INDEPENDENT_ARITHMETIC'
    assert old['actual_intents_decoded'] == cert['decoded_inputs'] == 60426
    assert sha(indexpath) == read(I / 'actual/Closed_Manifest.json')['members'][indexpath.name]
    index = json.loads(gzip.decompress(indexpath.read_bytes()))
    assert len(index) == cert['unique_components'] == 58516
    assert sum(len(v) for v in index.values()) == 60426
    roots = {}
    for b in read(P / 'Exact_Paid_Root_State_Bindings.json'):
        path = R / b['full_actual_root_payload']; assert sha(path) == b['payload_sha256']
        roots[b['root']] = pickle.loads(path.read_bytes())['net']
    rows = []
    for item in read(targets):
        assert time.perf_counter() - started < 300
        net = copy.deepcopy(roots[item['root']])
        runner.rescue.apply_action(net, {'add_shunts_q_mvar': {str(item['bus']): item['q_mvar']}})
        key, values = component(net)
        refs = index.get(key, [])
        rows.append({**item, 'physical_component_sha256': key,
            'perbus_exact_rational_P_Q_shunt_admittance': values,
            'matching_indexed_attempt_count': len(refs), 'matching_indexed_attempts': refs,
            'indexed_scope_disposition': 'EXCLUDED_ALL60426_INDEXED_INPUTS' if not refs else 'UNKNOWN_COMPONENT_MATCH'})
    assert len(rows) == len({(r['root'], r['bus'], r['q_mvar']) for r in rows}) == 45 and not calls
    write('All45_Indexed_Scope_Query.json', rows)
    result = {'status': 'COMPLETE_SCOPED_INDEX_QUERY_ONLY', 'declared_targets': 45,
        'old_independently_closed_attempts': 60426, 'new_decoded_old_PF_capsules': 0,
        'targets_excluded_in_this_index': sum(r['matching_indexed_attempt_count'] == 0 for r in rows),
        'targets_with_component_matches_UNKNOWN': sum(r['matching_indexed_attempt_count'] != 0 for r in rows),
        'index_sha256': sha(indexpath), 'new_scientific_calls': len(calls),
        'not_universal_historical_closure_or_new_PF_permission': True,
        'workflow_seconds': time.perf_counter() - started}
    write('Result.json', result)
    write('Closed_Manifest.json', {'members': {p.name: sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps(result))

if __name__ == '__main__': main()
