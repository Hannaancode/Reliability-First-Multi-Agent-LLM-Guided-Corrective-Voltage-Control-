# Execution and reporting checklist

## Before final-bank evaluation

- [ ] Environment type, current working directory and file-access boundaries established.
- [ ] Supported authentication path identified; real signed-in Colab status verified if execution starts.
- [ ] Latest notebook and exact frozen pack obtained; frozen originals retained.
- [ ] Model/base/tokenizer, source and dependency hashes/versions recorded.
- [ ] Frozen network, zones, shunt model, sign convention, eligible buses and reachable Q support audited.
- [ ] Actual locked bank counted at 62 and hashes recomputed; no regenerated substitute.
- [ ] Training/final-bank physical overlap and contingency families assessed.
- [ ] Pilot13 awareness and any tuning effects documented.
- [ ] Nominal95–105 and hard106 thresholds correctly distinguished.
- [ ] Actual Q normalization and allowed action list reconciled before test outcomes.
- [ ] Candidate ranking, verifier/progress gates, stable tie order and selector documented.
- [ ] DFF-ALT implemented only for first iteration and validated on development cases.
- [ ] Separate identical initial state copies for each trajectory verified.
- [ ] D-SE/HG-SE selectors identical and missing/failed branches explicitly handled.
- [ ] Protocol, source hashes, primary endpoints and statistical methods frozen.

## Suggested per-scenario result schema (adapt to actual code)

These are desired fields, not a claim that an existing runner already emits them:

`scenario_id`, `scenario_hash`, `contingency_family`, `pilot_observed`, `method`, `source_hash`, `model_hash`, `config_hash`, `dependency_manifest_hash`, `initial_pf_converged`, `initial_uv`, `initial_vmin`, `initial_deficit`, `final_pf_converged`, `final_uv`, `final_vmin`, `final_vmax`, `final_deficit`, `full_restoration`, `nominal_ov_count`, `hard_ov_count`, `total_abs_q_mvar`, `accepted_actions`, `pf_solves_total`, `pf_solves_failed`, `deterministic_candidates`, `llm_calls`, `prompt_tokens`, `completion_tokens`, `truncation_count`, `parse_failures`, `invalid_proposals`, `fallback_actions`, `runtime_s`, `first_candidate`, `alt_first_candidate`, `alternative_unavailable`, `alternative_unavailable_reason`, `selected_branch`, `failure_reason`.

Retain actions, verifier decisions, branch terminal ordering and timings in event logs. Do not count rejected proposals as executed actions. Full restoration must use the frozen definition, not a new post-hoc criterion. Separate allocated support and aggregate commanded support from delivered voltage-dependent reactive injection.

## Before claims and manuscript revision

- [ ] All62 scenario/method results or declared failures accounted for; no result-dependent exclusions.
- [ ] HG-SE vs D-SE paired primary effect and CI, wins/ties/losses, distribution and cost reported.
- [ ] Pilot13 and remaining49 sensitivity interpretation provided where appropriate.
- [ ] Contingency-family dependence assessed; no inflated sample size from buses/augmentation.
- [ ] Central/zonal proposal opportunities and context/truncation audited.
- [ ] OPF control mapping and relaxation explicit, returned candidate PF-rechecked.
- [ ] OPF solver failure separated from physical infeasibility.
- [ ] Null/adverse results retained, not hidden or used to change frozen DFF-ALT.
- [ ] Tables/plots traceable to saved results; historical and new campaigns separated.
- [ ] Model improvements, security results and live-grid readiness not asserted without evidence.
- [ ] Per-run resume checkpoints and final exported files exist before releasing created runtime.

## Security campaign, later

- [ ] RAG integration clean behavior established before attack tests.
- [ ] A/B/C/D matrix uses same frozen weights and matched physical conditions.
- [ ] Published corpus immutable; poisoning uses experimental copy.
- [ ] Threat control surfaces and protected/verifier state assumptions explicit.
- [ ] Observation corruption, classical state-estimation FDIA, knowledge poisoning and prompt injection distinguished.
- [ ] Actual LLM attack interactions used for prompt-injection claims.
- [ ] No invented attack-rate denominator for absent no-RAG channel.
- [ ] True-grid evaluator independent of online corrupted-view condition.
- [ ] Existing HierGrid and conventional complete mediation strong baselines included.
- [ ] Utility degradation, benign rejection and cost included alongside containment.
