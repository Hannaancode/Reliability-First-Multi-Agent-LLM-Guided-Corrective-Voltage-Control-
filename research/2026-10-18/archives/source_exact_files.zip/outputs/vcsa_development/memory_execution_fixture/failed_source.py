"""Tiny RANDOM Qwen software equivalence test, zero pretrained or PF calls."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes, hashlib, json, os, time
LIB = Path(r'C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
if os.name == 'nt':
    guard=os.add_dll_directory(str(LIB)); library=ctypes.WinDLL(str(LIB/'msvcp140.dll'))
import torch
from transformers import Qwen2Config, Qwen2ForCausalLM
from vcsa_modules_v2 import VCSAPrototype
from vcsa_pilot_objective import tensors, objective
from vcsa_memory_execution import MemoryExecution
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/vcsa_development/memory_execution_fixture'
assert not OUT.exists(), 'Preserve this declared software fixture, no repeat'
OUT.mkdir(); started=time.perf_counter(); torch.set_num_threads(2)
checks={}; counts={'tiny_random_model_forwards':0,'tiny_random_optimizer_steps':0,'genuine_pretrained_model_forwards':0,'PF_calls':0}
def create():
    torch.manual_seed(20261008)
    model=Qwen2ForCausalLM(Qwen2Config(vocab_size=97,hidden_size=32,intermediate_size=64,num_hidden_layers=3,
        num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=128,attention_dropout=0.))
    model.eval(); original=[(name,p.detach().clone()) for name,p in model.named_parameters()]
    module=VCSAPrototype(model,layer_indices=(0,2))
    return model,module,original
normalization={'progress_mean':[0.,0.,0.],'progress_std':[1.,1.,1.]}
row={'hard_abstention':False,'positive_action_target':{'bus_position':0,'q_index':0},
     'input':{'features':[[.01*(i+j+1) for j in range(7)] for i in range(3)],'bus_ids':[0,1,2],
       'zone_ids':[0,0,0],'adjacency':[[1.,1.,0.],[1.,1.,1.],[0.,1.,1.]],'node_mask':[True]*3,
       'allowed_bus_mask':[True,True,False]},
     'candidate_labels':[{'bus_position':b,'q_index':q,'continuous_progress':[.1,.2,.3],
       'PF_failure_target':0,'guard_admissibility_target':1,'after_metrics':{'uv_count':1+b+q,'deficit_sum':.1*(b+q)}}
        for b in [0,1] for q in range(9)]}
data=tensors(row,normalization,'cpu')
literal_model,literal,original=create(); optimized_model,optimized,original2=create()
assert all(torch.equal(p,q) for p,q in zip(literal.parameters(),optimized.parameters()))
checks['identical_random_initial_weights']=True
execution=MemoryExecution(optimized_model)
assert not optimized_model.training and not any(layer.training for layer in optimized_model.model.layers)
checks['eval_and_dropout_mode_preserved']=True
opt1=torch.optim.SGD([p for _,p in literal.new_parameters()],lr=.001)
opt2=torch.optim.SGD([p for _,p in optimized.new_parameters()],lr=.001)
losses=[]; maximum_gradient_error=0.; observed_paths=set(); stored_bytes={}
try:
    for step,length in enumerate([37,61],1):
        ids=(torch.arange(length)[None,:]%96+1).long(); mask=torch.ones_like(ids)
        references=[]
        for model in [literal_model,optimized_model]:
            with torch.no_grad():
                output=model(input_ids=ids,attention_mask=mask,output_hidden_states=True,use_cache=False)
                counts['tiny_random_model_forwards']+=1
                references.append((output.logits[:,-1,:].detach(),output.hidden_states[-1].detach()))
        torch.testing.assert_close(references[0][0],references[1][0],rtol=2e-5,atol=2e-6)
        torch.testing.assert_close(references[0][1],references[1][1],rtol=0,atol=0)
        results=[]; gradients=[]
        for label,model,module,optimizer,reference in [
            ('literal',literal_model,literal,opt1,references[0][0]),
            ('memory',optimized_model,optimized,opt2,references[1][0])]:
            saved=[]
            def pack(tensor): saved.append(tensor.numel()*tensor.element_size()); return tensor
            optimizer.zero_grad(set_to_none=True)
            with torch.autograd.graph.saved_tensors_hooks(pack,lambda tensor:tensor), module.condition(
                data['features'],data['bus_ids'],data['zone_ids'],data['adjacency'],data['node_mask']):
                output=module(ids,mask,data['allowed_bus_mask'],include_language_logits=True)
                counts['tiny_random_model_forwards']+=1
                loss,terms=objective(output,row,normalization,reference_last_logits=reference,language_logits=output['language_logits'][:,-1,:])
                assert torch.isfinite(loss)
                result={k:v.detach().clone() for k,v in output.items() if isinstance(v,torch.Tensor) and k!='language_logits'}
                result['loss']=loss.detach().clone()
                loss.backward()
                gradient={n:None if p.grad is None else p.grad.detach().clone() for n,p in module.new_parameters()}
                assert all(torch.isfinite(v).all() for v in gradient.values() if v is not None)
                torch.nn.utils.clip_grad_norm_([p for _,p in module.new_parameters()],1.)
                optimizer.step(); counts['tiny_random_optimizer_steps']+=1
                results.append(result); gradients.append(gradient)
                stored_bytes[f'{label}_step_{step}']=sum(saved)
                if label=='memory':
                    for path in ['vcsa_encoder','vcsa_heads','vcsa_injectors','vcsa_B','vcsa_router']:
                        if any(path in n and v is not None and bool(v.ne(0).any()) for n,v in gradient.items()):observed_paths.add(path)
        assert set(results[0])==set(results[1])
        for key in results[0]:torch.testing.assert_close(results[0][key],results[1][key],rtol=2e-5,atol=2e-6,equal_nan=True)
        assert set(gradients[0])==set(gradients[1])
        for name in gradients[0]:
            g1,g2=gradients[0][name],gradients[1][name]
            assert (g1 is None)==(g2 is None)
            if g1 is not None:
                torch.testing.assert_close(g1,g2,rtol=2e-5,atol=2e-6)
                maximum_gradient_error=max(maximum_gradient_error,float((g1-g2).abs().max()))
        for p,q in zip(literal.parameters(),optimized.parameters()):torch.testing.assert_close(p,q,rtol=2e-5,atol=2e-6)
        losses.append([float(results[0]['loss']),float(results[1]['loss'])])
        checks[f'step_{step}_output_loss_all_gradients_and_updated_weights_agree']=True
    assert len(observed_paths)==5 and execution.checkpoint_requests>0
    checks['recomputed_backward_reaches_all_five_new_gradient_paths']=True
    assert all(stored_bytes[f'memory_step_{i}']<stored_bytes[f'literal_step_{i}'] for i in [1,2])
    checks['fewer_saved_tensor_bytes_in_both_fixture_forwards']=True
finally:
    execution.close(); literal.close(); optimized.close()
for (name,old),(name2,old2) in zip(original,original2):
    assert name==name2 and torch.equal(dict(literal_model.named_parameters())[name],old)
    assert torch.equal(dict(optimized_model.named_parameters())[name2],old2)
checks['all_original_random_weights_unchanged']=True
ids=(torch.arange(37)[None,:]%96+1).long()
with torch.no_grad():
    a=literal_model(input_ids=ids).logits; b=optimized_model(input_ids=ids).logits
    counts['tiny_random_model_forwards']+=2
    assert torch.equal(a,b) and b.shape[1]==37
checks['owned_model_and_layer_forward_restoration_exact']=True
# The execution wrapper also restores after an exception; no model call here.
before=optimized_model.forward
try:
    with MemoryExecution(optimized_model):raise RuntimeError('explicit fabricated failure')
except RuntimeError:pass
assert optimized_model.forward==before
checks['exception_restoration']=True
report={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'passed':all(checks.values()),'checks':checks,
        'counts':counts,'losses':losses,'maximum_gradient_absolute_error':maximum_gradient_error,
        'saved_tensor_byte_sums':stored_bytes,'checkpoint_requests':execution.checkpoint_requests,
        'decoder_invocations_including_recomputation':execution.decoder_invocations,
        'elapsed_seconds':time.perf_counter()-started,
        'scope':'Tiny random Qwen/fabricated observations/tokens, software equivalence only; not pretrained, actual CUDA memory or superiority evidence',
        'saved_bytes_limit':'Sums of tensors intercepted by saved-tensor hooks can count shared storage repeatedly; not GPU peak memory',
        'agreement_tolerance':{'rtol':2e-5,'atol':2e-6},
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'memory_execution_source_sha256':hashlib.sha256((ROOT/'work/vcsa_memory_execution.py').read_bytes()).hexdigest()}
(OUT/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False))
print(json.dumps(report,indent=2))
