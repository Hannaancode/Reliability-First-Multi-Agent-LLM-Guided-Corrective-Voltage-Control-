"""Persist all280static components for new target checks; never a PF permit.

Unlike the earlier two-target summary this retains reusable component refs,
and checks the THREE new fixed-policy targets. Static AFTER scope stays clear.
"""
import gzip,hashlib,json,time
from types import SimpleNamespace
import pandas as pd
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
B=R/'outputs/fresh_static_component_index_20261018'
def main():
    B.mkdir(exist_ok=False);begun=time.perf_counter();prior=read(R/'outputs/fresh_root_query_nonoverlap_20261018/Independent_Audit.json')
    targets=read(R/'outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json')['all_remaining_ordered_identities']
    path=R/'outputs/critical_research_reset_20261010/fresh_paid_receipt_opportunity_preparation_v1/execution/Actual_Observation_Journal.jsonl'
    put(B/'Protocol.json',{'source_sha256':sha(__file__),'prior_journal_sha256':prior['actual_prior_journal_sha256'],'target_exact_keys':[t['point_action_key'] for t in targets],
        'target_component_hashes':[t['physical_component_sha256'] for t in targets],'producer_equation_sha256':sha(R/'work/prior_physical_query_footprints_20261018.py'),
        'independent_equation_sha256':sha(R/'work/audit_prior_physical_query_footprints_20261018.py'),'fixed_analysis_bound_seconds':180,
        'scope':'All3418staticAFTER observations only; not full nativeBEFORE reconstruction, unlogged histories or a scientific launch gate. Zero solver/model calls.'})
    pending=None;whole=hashlib.sha256();index={};n=0
    with path.open('rb') as f:
        for raw in f:
            assert time.perf_counter()-begun<180;whole.update(raw);e=json.loads(raw)
            if e['event']=='solver_attempt':assert pending is None;pending=(e['identity'],e['phase'],e['arguments'])
            elif e['event']=='solver_closed':
                assert pending==(e['identity'],e['phase'],e['arguments']) and e['exception'] is None;pending=None;t=e['observation']['physical_tables']
                def frame(v):return pd.DataFrame(v['values'],index=v['index'],columns=v['columns'])
                net=SimpleNamespace(bus=frame(t['bus']),shunt=frame(t['shunt']));h,_=component(net);assert independent_component(net)==h
                index.setdefault(h,[]).append({'identity':e['identity'],'phase':e['phase'],'line_sha256':hashlib.sha256(raw).hexdigest()});n+=1
    assert pending is None and n==3418 and len(index)==280 and whole.hexdigest()==prior['actual_prior_journal_sha256']
    with gzip.open(B/'All_Static_Component_References.json.gz','xb') as f:f.write(json.dumps(index,sort_keys=True,separators=(',',':')).encode())
    put(B/'Results.json',{'status':'PASS_ALL3418_DUAL_EQUATIONS_280_REUSABLE_STATIC_COMPONENT_REFS_NEW_TARGETS','observations':n,'unique_components':len(index),
        'target_component_matches':{t['point_action_key']:len(index.get(t['physical_component_sha256'],[])) for t in targets},
        'index_sha256':sha(B/'All_Static_Component_References.json.gz'),'prior_journal_sha256':whole.hexdigest(),'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-begun,
        'limits':'Static observed shunt scope only. Source/verifier/persistent state/ownership/reader/protocol must separately gate any new call. No automatic PF authority or performance claim.'})
    manifest(B);print(json.dumps({'static_index':'PASS','new_target_matches':[len(index.get(t['physical_component_sha256'],[])) for t in targets],'new_science':0}))
if __name__=='__main__':main()
