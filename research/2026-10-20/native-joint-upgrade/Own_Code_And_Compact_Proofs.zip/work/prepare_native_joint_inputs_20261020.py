"""One complete global state per3actuator decision, all24 contexts, actual0.5/1.5 paired tokens."""
import json,hashlib,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_slm_joint_input_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();import candidate_process_runtime
    import torch,numpy as np
    from transformers import AutoTokenizer
    from native_slm_joint_head_20261020 import NativeJointHead
    from native_slm_causal_features_20261020 import check_keys
    paths=[ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1',ROOT/'outputs/native_slm_causal_input_preparation_20261020/public_1_5B_tokenizer_copy'];tokenizers=[AutoTokenizer.from_pretrained(str(p),local_files_only=True,trust_remote_code=False) for p in paths];original=json.loads((ROOT/'outputs/native_slm_causal_input_preparation_20261020/All72_Causal_Text_And_Actual_Token_IDs.json').read_text(encoding='utf-8'));rows=[]
    for record in original:
        if record['agent_index']!=0:continue
        text=record['input_text'];mark='<|im_start|>user\n';start_json=text.index(mark)+len(mark);end_json=text.index('\n<|im_end|>',start_json);state=json.loads(text[start_json:end_json]);assert state['control'].pop('own_actor_bus_id')==2;state['control']['decision_scope']='joint_three_native_actuators';check_keys(state);text=text[:start_json]+json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False)+text[end_json:];ids=[t(text,add_special_tokens=False)['input_ids'] for t in tokenizers];assert ids[0]==ids[1] and len(ids[0])<=4096
        pos=record['context_index'];z=np.load(ROOT/f'outputs/native_full_grid_affine_gate_20261020/context_{pos:02d}/Model_And_Problem.npz');assert np.array_equal(z['q0'],np.asarray(state['control']['current_Q_mvar']))
        rows.append({'context_index':pos,'input_text':text,'input_ids':ids[0],'attention_mask':[1]*len(ids[0]),'tokens':len(ids[0]),'current_NET_sha256':record['current_NET_sha256'],'loss_current_fields_not_forwarded':{'vm':z['vm'].tolist(),'dVm_dQ':z['S'].tolist(),'current_Q':z['q0'].tolist(),'source_affine_model_sha256':sha(ROOT/f'outputs/native_full_grid_affine_gate_20261020/context_{pos:02d}/Model_And_Problem.npz')},'metadata_not_forwarded':record['metadata_not_forwarded']})
    assert len(rows)==24 and sorted(r['context_index'] for r in rows)==list(range(24));selected=max(rows,key=lambda r:(r['tokens'],-r['context_index']));torch.manual_seed(20261020);checks=[]
    for width in [896,1536]:
        h=NativeJointHead(width);x=torch.randn(1,width,requires_grad=True);q=torch.tensor([[.1,-.2,.3]]);a=h(x,q);loss=(a['u_mvar']-torch.tensor([[.1,-.15,.2]])).square().sum();loss.backward();assert x.grad is not None and x.grad.abs().sum()>0 and all(p.grad is not None and p.grad.abs().sum()>0 and torch.isfinite(p.grad).all() for p in h.parameters());assert a['u_mvar'].dtype==torch.float32 and a['u_mvar'].abs().max()<=torch.tensor(.3) and torch.equal(q-a['u_mvar'],a['next_q_mvar']);cold=NativeJointHead(width);cold.load_state_dict(h.state_dict(),strict=True)
        with torch.no_grad():b=cold(x.detach(),q)
        assert all(torch.equal(a[k].detach(),b[k]) for k in a);checks.append({'width':width,'native_coupled_shape_float32_units_bound_and_nonzero_gradients':True,'cold_outputs_exact':True})
    for name,value in [('All24_Joint_Causal_Inputs.json',rows),('Selected_Longest_Engineering_Context.json',selected)]:
        with (OUT/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)
    r={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL24_COMPLETE_JOINT_CAUSAL_CONTEXTS_ACTUAL_PAIRED_TOKEN_IDS_AND_NATIVE_HEAD_SOFTWARE','actual_contexts':24,'minimum_tokens':min(r['tokens'] for r in rows),'maximum_tokens':selected['tokens'],'selected_longest_context_index':selected['context_index'],'selection_rule':'Maximum complete input length,thenascendingcontextindex,beforeanynativeSLMforward. All24featuresretained.','fixed_body_context':4096,'text_generation_tokens':0,'same_full_information_as_centralized_numeric_reference':True,'centralized_variant_not_original_local_paper_controller':True,'single_body_for_three_coupled_actuators':'Oneglobalcontextandnative3vectorheadavoidrepeatingtheentirecircuit3times;notspooledVRAMandnoinformationloss. Strongnumeric/MLPcontrolsgetthesamecausalfields.','all_future_outcome_labels_and_source_IDs_outside_forward':True,'software_random_CPU_forward_backward_calls':[4,2],'software_checks':checks,'actual_pretrained_LLM_PF_GPU_optimizer_calls':0,'engineering_context_sha256':sha(OUT/'Selected_Longest_Engineering_Context.json'),'all_inputs_sha256':sha(OUT/'All24_Joint_Causal_Inputs.json'),'joint_head_source_sha256':sha(ROOT/'work/native_slm_joint_head_20261020.py'),'native_model_training_or_benchmark_benefit':False,'workflow_seconds':time.monotonic()-start}
    with (OUT/'Readiness.json').open('x',encoding='utf-8') as f:json.dump(r,f,indent=2)
    print(json.dumps(r))
if __name__=='__main__':main()
