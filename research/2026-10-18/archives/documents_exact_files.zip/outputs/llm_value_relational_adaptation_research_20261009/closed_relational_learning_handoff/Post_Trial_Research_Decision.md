The fixed relational internal intervention is STOPPED on this dataset.

Both genuine arms completed all declared calls and passed independent identity,
full-checkpoint, gradient-participation, frozen-weight, action, cost and transfer
audits. This is a valid measured negative development result, not a resource
failure or an unanswered permission gate. Both exact runtimes were released.

Held equal-world K4 was 4.8335% internal, 0.7519% matched frozen head, and
38.5965% strongest current AC control. The 4.0816-point head improvement misses
the declared five-point gate and occurs in only one better exact world. Internal
known-rejected selection fraction was 61.2745%, versus 43.1373% frozen head and
27.4510% AC. All fixed gates except identity completeness failed. Keep all K,
world, unknown and adverse records; do not select a different decoder, checkpoint,
world subset, threshold, Q grid, loss weight, seed, budget or learning rate.

Even optimization-world K4 is only 5.7065% internal and 4.5455% frozen head.
The measurements therefore do not support attributing the failure solely to
held-world generalization. They do not isolate the causal role of any component.
No additional models, training, physics or cloud calls were made for this decision.

There is no justified physical rollout or fresh model campaign ready from this
result. Further research must establish a materially different, evidence-backed
LLM-specific mechanism and information advantage over strong numerical methods
before a new prospective protocol. Saved diagnosis may explain the failed fixed
decision, but may not be used to retune this stopped intervention for a win.

The actual primary comparator remains literal D-SE: original DFF plus DFF-ALT
and the unchanged safety-envelope selector, with both branches' full costs.
AC is a strong development control, not a replacement primary comparator.
Fresh matched protected physical outcomes, complete deployment/training costs,
pretraining attribution and genuinely unused confirmation remain unachieved.
Original frozen assets, sealed baseline and every prior adverse result remain
preserved. Overall validated-superiority and full-security goals remain unachieved.
