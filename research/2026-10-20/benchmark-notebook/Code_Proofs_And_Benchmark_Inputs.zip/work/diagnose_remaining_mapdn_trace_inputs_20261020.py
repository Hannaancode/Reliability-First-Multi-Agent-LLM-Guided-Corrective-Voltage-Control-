"""Complete only three unclosed322 trace inventories; retain timestamp anomalies."""
import hashlib,json,os,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'outputs/mapdn_full_trace_inventory_20261020'
OUT=ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020';BASE=ROOT/'outputs/mapdn_native_contract_v2_20261020'
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();bound=600
    old=json.loads((OLD/'Failure.json').read_text(encoding='utf-8'));assert len(old['closed_files'])==6
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixed_bound_seconds':bound,'scope':'All3unclosed322native input files only; retain all rows/columns/numeric values, timestamp reversals/duplicates/gaps. No modification/interpolation/cropping/deduplication. Reuse all6closed33/141input inventories with old costs. Original regularity assertion failure preserved; do not declare regularityPASS. No physics/model/optimizer/allocation.','old_failure':str(OLD/'Failure.json')}
    put(OUT/'Protocol.json',protocol);put(OUT/'owner.claim',protocol);rows=[]
    try:
        with zipfile.ZipFile(ROOT/'outputs/mapdn_author_dataset_preservation_20261020/voltage_control_data.zip') as z,(OUT/'Events.jsonl').open('x',encoding='utf-8') as events:
            for family in ['load_active','load_reactive','pv_active']:
                name='voltage_control_data/case322_3min_final/'+family+'.csv';header=json.loads((BASE/'timeseries_headers'/('case322_3min_final__'+family+'.json')).read_text(encoding='utf-8'))
                columns=header['header'];count=0;first=last=None;minima=maxima=None;bad=[];negative=0;t0=time.monotonic()
                with z.open(name) as f:
                    for c in pd.read_csv(f,chunksize=16384,dtype={k:np.float64 for k in columns[1:]}):
                        assert time.monotonic()-start<bound and list(c.columns)==columns
                        times=pd.to_datetime(c.iloc[:,0],format='%Y-%m-%d %H:%M:%S',errors='raise').to_numpy(dtype='datetime64[s]')
                        if first is None:first=times[0]
                        elif times[0]-last!=np.timedelta64(180,'s'):bad.append({'before_row':count-1,'after_row':count,'before':str(last),'after':str(times[0]),'delta_seconds':int((times[0]-last)/np.timedelta64(1,'s'))})
                        for i in np.flatnonzero(np.diff(times)!=np.timedelta64(180,'s')):
                            bad.append({'before_row':count+int(i),'after_row':count+int(i)+1,'before':str(times[i]),'after':str(times[i+1]),'delta_seconds':int((times[i+1]-times[i])/np.timedelta64(1,'s'))})
                        vals=c.iloc[:,1:].to_numpy(dtype=np.float64);assert np.isfinite(vals).all()
                        mi=vals.min(axis=0);ma=vals.max(axis=0);minima=mi if minima is None else np.minimum(minima,mi);maxima=ma if maxima is None else np.maximum(maxima,ma)
                        negative+=int((vals<0).sum());count+=len(c);last=times[-1]
                        events.write(json.dumps({'entry':name,'rows_checked':count,'elapsed_seconds':time.monotonic()-start})+'\n');events.flush()
                r={'entry':name,'rows':count,'columns':len(columns)-1,'first_timestamp':str(first),'last_timestamp':str(last),'timestamp_anomalies':bad,'all_timestamps_regular_180_seconds':not bad,'all_numeric_fields_finite':True,'negative_input_values':negative,'native_column_min':minima.tolist(),'native_column_max':maxima.tolist(),'parse_seconds':time.monotonic()-t0,'source_rows_changed':0,'no_policy_or_physics_output':True}
                rows.append(r);put(OUT/(family+'.json'),r)
        combined=old['closed_files']+rows
        put(OUT/'Results.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'FULL_INPUT_INVENTORY_COMPLETE_NATIVE_TIMESTAMP_IRREGULARITY_RETAINED','all9files':combined,'native_regular_all9_chronology_gate':'FAIL','all9_numeric_values_finite':True,'total_numeric_values_checked':sum(r['rows']*r['columns'] for r in combined),'new_workflow_seconds':time.monotonic()-start,'prior_workflow_seconds':old['workflow_seconds'],'new_PF_model_optimizer_GPU_calls':0,'next':'Determine documented prefix/history role and predeclare native positional versus chronological split semantics; no silent deduplication or selected network exclusion.'})
        print(json.dumps({'status':'COMPLETE_WITH_SOURCE_TIMESTAMP_IRREGULARITY','322_rows':[r['rows'] for r in rows],'anomalies':[r['timestamp_anomalies'] for r in rows],'seconds':time.monotonic()-start}))
    except BaseException as e:
        put(OUT/'Failure.json',{'status':'PARTIAL_DIAGNOSTIC','failure_type':type(e).__name__,'failure':str(e)[:300],'closed_files':rows,'new_science_calls':0});raise
if __name__=='__main__':main()
