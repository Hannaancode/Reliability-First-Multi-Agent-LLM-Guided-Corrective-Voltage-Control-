"""Fixed original evidence anchors BEFORE constructing an OPT administrator.

The first software suite exercised causal boundaries on actual unchanged data.
This additive wrapper also refuses a replaced data+manifest pair. Original
interface/adapter sources and their sealed software evidence stay unchanged.
"""
import hashlib
from pathlib import Path
from saved_query_receipt_interface import ReceiptContractError

EXPECTED_ORIGINAL_EVIDENCE = {
    'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/manifest.json': '5c864dd215fc061ead5e2db7a5a71c03b4ca5b4931983190dd21aa1a93c74ad3',
    'outputs/llm_value_candidate_development_20261009/current_added_support_observables/manifest.json': '00e38d2e32ffe207e21001a191c372ae3a4e7f7486e0ac279dfa6a3d5ecd2afc',
    'outputs/critical_research_reset_20261010/actual_query_and_continuation_receipt_inventory_v3/All216_Actual_Action_Linked_Successor_Records.json': '10ff0e8a496f2956287a129f6321510f3e5371e399e8e2c3f0e436491f7b024e',
    'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz': 'c59325ada166e0d699724c4b2351a26fb63563d7b5973a1ea25ee81fc13594c3',
    'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz': '9e2463c9e7cc37271231215d0d4545ef05837fdfb2a24a03320da4203c032e35',
    'outputs/llm_value_candidate_development_20261009/current_added_support_observables/Current_Control_State_Observables.jsonl.gz': '7b1ff3cad389406f824dda74a0a147a9661485e686079bfa0adbd230e3d6633d',
    'outputs/llm_value_candidate_development_20261009/input_and_target_contract_operational_v3_audit/Independent_Current_Input_and_Measured_Target_Audit.json': 'f2fb9058050a5c778d4fd61ecdb11d8dee6923a5238ceceea9099dad59c6fa1f',
    'work/saved_query_receipt_dataset.py': '102777cf0618e27aafde3884f4339b2a83c74a806e27fb591d48be9fd19421e0',
    'work/saved_query_receipt_interface.py': 'cf624e8b8276673f8bc1372a36c709bd3f064821b2578ff6fc47e9a1785834e5',
}


def verify_original_evidence(root):
    root = Path(root)
    for name, expected in EXPECTED_ORIGINAL_EVIDENCE.items():
        p = root / name
        if not p.is_file():
            raise ReceiptContractError('Required original evidence anchor missing: ' + name)
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        if actual != expected:
            raise ReceiptContractError('Changed original evidence anchor: ' + name)
    return dict(EXPECTED_ORIGINAL_EVIDENCE)


def open_anchored_OPT_administrator(root):
    verified = verify_original_evidence(root)
    from saved_query_receipt_dataset import OPTReceiptAdministrator
    data = OPTReceiptAdministrator(root)
    data.fixed_original_evidence_sha256 = verified
    return data
