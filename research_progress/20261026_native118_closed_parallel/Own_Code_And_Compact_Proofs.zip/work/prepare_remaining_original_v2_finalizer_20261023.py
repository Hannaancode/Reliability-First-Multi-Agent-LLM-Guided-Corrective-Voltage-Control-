"""Generate the new finalizer, preserving every original draft and live source."""
from prepare_remaining_original_v2_pipeline_20261023 import *

def main():
    src=(R/'work/finalize_reflection118_three_case_gates_20261023.py').read_text('utf-8')
    src=rewrite(src)
    src=src.replace('build_and_audit_closed_dff_registry_20261023.py','extend_closed_partition_registry_20261023.py')
    src=src.replace('check_remaining_reflection118_new_integration_20261023.py','check_remaining_original_v2_integration_20261023.py')
    src=src.replace('run_reflection118_remaining_colab_20261023.py','run_reflection118_remaining_v2_colab_20261023.py')
    src=src.replace('audit_reflection118_remaining_case_20261023.py','audit_reflection118_remaining_v2_case_20261023.py')
    src=src.replace('coordinate_reflection118_remaining_cases_20261023.py','coordinate_reflection118_remaining_v2_cases_20261023.py')
    src=src.replace('finalize_reflection118_three_case_gates_20261023.py','finalize_reflection118_three_case_v2_gates_20261023.py')
    src=src.replace("    assert read(R/'outputs/r118_dff_partition_continuation_handoff_20261023/Completion.json')['independent_audit_status'].startswith('PASS_')",'    require_partition_closed()')
    src=src.replace("sha(E/'Result.json')","sha(PARTITION/'Result.json')").replace("sha(A/'Independent_Audit.json')","sha(PARTITION_AUDIT/'Independent_Audit.json')")
    needle='    pins={}\n'
    assert needle in src
    src=src.replace(needle,"    # Pin all inherited source dependencies from the independently closed DFF study.\n    pins=dict(read(R/'outputs/r118_dff_partition_continuation_preparation_20261023/Protocol.json')['source_hashes'])\n    source_names += ['reflection118_remaining_cases_core_20261023.py','r118_dff_partition_core_20261023.py','provider_observer_pause_20261023.py','native_solver_input_identity_v3_20261023.py','native_solver_input_identity_20261023.py','audit_solver_input_identity_receipts_20261023.py','build_and_audit_closed_dff_registry_20261023.py']\n")
    needle='    checks=frozen_checks();'
    assert needle in src
    extra="""    # Exact case/output/source bindings are locked before ANY new model call.
    analysis=R/'outputs/original118_matched_analysis_preparation_20261023/Protocol.json'
    lock=TOP/'Matched_Analysis_Exact_Bindings.json'
    put(lock,dict(status='LOCKED_BEFORE_ALL3_UNENTERED_MODEL_CASES',analysis_protocol_sha256=sha(analysis),
        old_case0='outputs/r118chrono_20261022',old_case0_audit='outputs/r118chrono_audit_20261022/Independent_Audit.json',
        new_cases=[dict(case_index=i,protocol=(TOP/f'case_{i:02d}'/'Frozen_Engineering_Protocol.json').relative_to(R).as_posix(),protocol_sha256=sha(TOP/f'case_{i:02d}'/'Frozen_Engineering_Protocol.json'),output=f'outputs/reflection118_remaining_cases_v2_execution_20261023/case_{i:02d}',audit=f'outputs/reflection118_remaining_cases_v2_independent_20261023/case_{i:02d}') for i in [1,2,3]],
        native_DFF_result_sha256=sha(PARTITION/'Result.json'),native_DFF_independent_sha256=sha(PARTITION_AUDIT/'Independent_Audit.json'),no_output_or_checkpoint_selection=True))
    for i in [1,2,3]:
        ready=TOP/f'case_{i:02d}'/'Launch_Readiness_Audit.json';value=read(ready)
        value['source_hashes'][lock.relative_to(R).as_posix()]=sha(lock)
        value['source_hashes'][analysis.relative_to(R).as_posix()]=sha(analysis)
        replace_json(ready,value)
"""
    src=src.replace(needle,extra+needle)
    save('finalize_reflection118_three_case_v2_gates_20261023.py',src)
    print(json.dumps(dict(status='NEW_FINALIZER_PREPARED_NOT_EXECUTED',allocation=False)))
if __name__=='__main__':main()
