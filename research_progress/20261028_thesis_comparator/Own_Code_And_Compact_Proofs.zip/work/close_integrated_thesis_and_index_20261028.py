"""Close the visually reviewed working thesis and create a bounded evidence index.

Reads saved evidence only. Does not execute models, controllers or scientific audits.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, zipfile, re, html, os, xml.etree.ElementTree as ET
from docx import Document
from pypdf import PdfReader

R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_integrated_evidence_20261028'
P=O/'Hannaan_Thesis_Integrated_Evidence.docx'
original=R/'outputs/thesis_expanded_20261028/Hannaan_Thesis_Expanded_Review.docx'
qa=O/'Final_Visual_And_Evidence_QA.json'
assert not qa.exists(), 'Closed document must not be silently re-certified.'
def read(p): return json.loads((R/p).read_text('utf-8-sig'))
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(original)=='cb8536d768fd25a0be02a65594341630c9030d7c5bcc7accc8a139ddcbd54dba'
def media(p):
    with zipfile.ZipFile(p) as z:
        return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/'))
def used_media(p):
    with zipfile.ZipFile(p) as z:
        rels=ET.fromstring(z.read('word/_rels/document.xml.rels'))
        targets={x.attrib['Id']:x.attrib['Target'] for x in rels}
        tree=ET.fromstring(z.read('word/document.xml'))
        ids=[x.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed']
             for x in tree.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}blip')]
        return Counter(hashlib.sha256(z.read('word/'+targets[i])).hexdigest() for i in ids)
assert used_media(original)==used_media(P)
assert sum(used_media(P).values())==22
assert not (media(P)-media(original)), 'Word must not modify any retained image bytes.'
d=Document(P)
tables=d.tables
assert len(tables)==12
figs=[f['caption'] for f in read('outputs/thesis_expanded_20261028/Figure_and_Table_Register.json')['figures']]
with zipfile.ZipFile(P) as z:
    tree=ET.fromstring(z.read('word/document.xml'))
    w='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    xml_paragraphs=[''.join(x.text or '' for x in p.iter(w+'t')) for p in tree.iter(w+'p')]
assert all(c in xml_paragraphs for c in figs), 'Word content-control figure captions must remain intact.'
captions=[p.text for p in d.paragraphs if re.match(r'^Table \d+\.\d+ ',p.text) and '\t' not in p.text]
refs=[p.text for p in d.paragraphs if re.match(r'^\[\d+\]',p.text)]
assert len(figs)==22 and len(captions)==12 and len(refs)==30
assert not any('\ufffd' in p.text for p in d.paragraphs)
comparison=read('outputs/original118_closed_comparison_20261028/Comparison.json')
for row,e in zip(tables[8].rows[1:],comparison['rows']):
    got=[c.text for c in row.cells]
    want=[e['case_id'].replace('fed_combined_load_1p5_line_',''),str(e['initial_UV']),
          f"{e['DFF_UV']}/{e['DFF_OV']}",f"{e['HGVF_UV']}/{e['HGVF_OV']}",f"{e['HGSE_UV']}/{e['HGSE_OV']}"]
    assert got==want,(got,want)
public=read('outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json')['summaries']
for row,key in zip(tables[10].rows[1:],['safe-ddpg','linear','ddpg','our_numerical']):
    e=public[key]
    if key=='our_numerical': nums=[e['full13band'],e['sum_residual_UV'],e['sum_residual_OV']]
    else: nums=[e['full13_band_restored_on_complete'],e['sum_UV_on_complete'],e['sum_OV_on_complete']]
    assert [c.text for c in row.cells[1:]]==[str(nums[0])+'/500',str(nums[1]),str(nums[2])]
pdf=PdfReader(O/'Integrated_Thesis_QA.pdf')
assert len(pdf.pages)==109
pagination=read('outputs/thesis_integrated_evidence_20261028/Pagination_Record.json')
assert pagination['pages']==109 and pagination['list_entries']==47
norm=lambda s: re.sub(r'\s+','',s).lower()
for e in pagination['map']:
    page=pdf.pages[e['physical_page']-1].extract_text() or ''
    assert norm(e['label']) in norm(page),e
abstract_i=next(i for i,p in enumerate(d.paragraphs) if p.text.strip()=='ABSTRACT')
abstract=[]
for p in d.paragraphs[abstract_i+1:]:
    if p.text.strip()=='ACKNOWLEDGMENTS': break
    if p.text.strip(): abstract.append(p.text)
abstract_words=len(' '.join(abstract).split())
assert abstract_words==134,abstract_words
now=datetime.now(timezone.utc).isoformat()
reviewed=[3,5,6,7,37,38,66,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,94,95,96,99,100,101]
record={'at_utc':now,'status':'PASS_WORKING_DRAFT_LAYOUT_AND_LISTED_EVIDENCE_CHECKS',
    'docx_sha256':sha(P),'pdf_sha256':sha(O/'Integrated_Thesis_QA.pdf'),'pages':109,
    'original_docx_unchanged':True,'all_22_used_figure_bytes_preserved':True,
    'media_package_change':'Word save removes9 unused template media entries and renumbers22 retained images; all22 used image bytes and their multiplicities match original.',
    'figures':22,'tables':12,'references':30,'abstract_words':abstract_words,'page_bound_list_entries':47,
    'numeric_checks':['All four Table7.5 rows exactly match closed Comparison.json','All four Table7.7 rows exactly match closed public500 result'],
    'visual_review':{'all_109_pages_contact_sheet_review':True,'full_size_before_after_changed_pages':reviewed,
      'final_layout_repairs_full_size_pages':[7,38,85],'unchanged_full_size_spot_checks':[39,88],
      'method':'Own hidden Word instance exported PDF; bundled Poppler rendered PNGs. Full changed pages inspected. No clipped or overlapping content found.',
      'renderer_limitation':'Canonical render_docx unavailable because soffice executable is absent; original attempt and Word/Poppler fallback retained.'},
    'limitations':['Working draft, not final QU submission','Thirty-five item checklist and all six research goals are not all complete',
      'Final137 raw cohort and RAG99% exact adjudication remain unresolved','Coauthor allocations and administrative front matter require confirmation',
      'No scientific result or model/physics/training call generated by document work'],
    'new_scientific_calls':0}
dump(qa,record)
integration=read('outputs/thesis_integrated_evidence_20261028/Integration_Record.json')
integration.update(status='COMPLETE_WORKING_DRAFT_VISUALLY_VERIFIED',tables=12,pages=109,qa=str(qa.relative_to(R)).replace('\\','/'),updated_utc=now)
dump(O/'Integration_Record.json',integration)
for name in ['Final_Layout_Repairs.json','RQ_Table_And_Terminology_Record.json']:
    v=read('outputs/thesis_integrated_evidence_20261028/'+name);v['status']='FINAL_RENDER_VISUALLY_VERIFIED';dump(O/name,v)

# Source maps retain unknown components instead of presenting a manuscript as raw evidence.
E=read('outputs/thesis_evidence_update_20261028/Evidence_Index.json')['sources']
ep={e['id']:e['path'] for e in E}
anchors='outputs/thesis_research_closure_20261028/Contribution_And_Verifier_Source_Record.json'
paper='outputs/thesis_expanded_20261028/Thesis_Source_and_Claim_Record.json'
table_specs=[
 ('2.1','LITERATURE_ROLE_SUMMARY',[paper],'Literature references; no common-experiment performance is claimed. Closest-method/source update remains open.'),
 ('3.1','CANDIDATE_CONFIRMED_AND_DOCUMENTED_COLLABORATOR_ROLES',[anchors,paper],'Detailed RAG and provisional coauthor allocations are unresolved.'),
 ('6.1','METRIC_AND_SCOPE_DEFINITION',[anchors,ep['E1']],'Definitions are not a complete AC or dynamic-security certificate.'),
 ('6.2','STATIC_EXECUTED_SOURCE_CONTRACT',[anchors],'Source functions and hashes are anchored; untested operational conditions remain untested.'),
 ('7.1','MIXED_EVIDENCE_SCOPE_ROSTER',[paper,ep['E1'],ep['E4'],ep['E5'],ep['E6']],'Distinct plants, cohorts and status must not be pooled.'),
 ('7.2','MANUSCRIPT_REPORTED_WITH_PARTIAL_HISTORICAL_RECOVERY',[paper,ep['E4']],'Exact99% factual grading, runtime index and revisions unrecovered; no full regeneration link asserted.'),
 ('7.3','MANUSCRIPT_REPORTED_LANGUAGE_STRESS',[paper],'Original adjudication/runtime identity not fully certified; physical security is not established.'),
 ('7.4','SUPPLIED_MANUSCRIPT_REPORTED_FINAL137',[paper],'Complete later137 raw/source/output join unrecovered; old835/656/545 archive is not substituted.'),
 ('7.5','INDEPENDENTLY_CLOSED_FOUR_DEVELOPMENT_ROOTS',[ep['E1'],ep['E2'],ep['E3'],'outputs/original118_analysis_binding_20261028/Prepared_Analysis_Lock.json','work/assemble_original118_closed_comparison_20261028.py'],'Four inspected development roots; fixedgateFAIL, fullboth costs, historical base/SFT and case0oldOSexit uncertainties retained.'),
 ('7.6','MATCHED_SCALE_VERIFIED_AND_ADVERSE_ATTEMPTS_RETAINED',[ep['E5']],'Teacher agreement is not physical control;3Bpartial7BOOM remain separate adverse resource outcomes.'),
 ('7.7','INDEPENDENTLY_COMPLETE_SAME500_PUBLIC_STARTS',[ep['E6']],'Native information/stopping differences disclosed; fixed numerical gateFAIL, no LLM or full AC claim.'),
 ('9.1','SYNTHESIS_OF_SCOPED_COMPLETED_AND_UNKNOWN_EVIDENCE',[ep['E1'],ep['E4'],ep['E5'],ep['E6'],anchors,paper],'An explicit negative or incomplete research answer is not an achieved research goal.'),
]
sources={}
for e in E: sources[e['path']]={'sha256':e['sha256'],'hash_origin':'Existing saved evidence index; no archive rehash'}
navigation=[]
for number,status,paths,limitation in table_specs:
    links=[]
    for path in paths:
        f=R/path;assert f.is_file(),path
        if path not in sources: sources[path]={'sha256':sha(f),'hash_origin':'Small current source/record hashed for navigation'}
        links.append({'path':path,**sources[path]})
    caption=next(c for c in captions if c.startswith('Table '+number+' '))
    navigation.append({'table':number,'caption':caption,'status':status,'records':links,
                       'code_data_model_config_verification_binding':'Follow source/protocol/manifest links within the listed audited record where available; unresolved components are not invented.',
                       'limitation':limitation})
register=read('outputs/thesis_expanded_20261028/Figure_and_Table_Register.json')
source_images=read('outputs/thesis_expanded_20261028/Figure_Source_Index.json')+read('outputs/thesis_expanded_20261028/RAG_Figure_Index.json')
figure_records=[]
for f in register['figures']:
    m=next(x for x in source_images if Path(x['file'].replace('\\','/')).name==f['image'])
    figure_records.append({'caption':f['caption'],'image':m['file'].replace('\\','/'),'paper':m['source'],
                           'physical_pdf_page':m['page'],'status':'AUTHOR_PAPER_REPRODUCTION_NOT_NEW_EXPERIMENT'})
assert len(figure_records)==22
index={'at_utc':now,'status':'NAVIGATION_COMPLETE_UNDERLYING_REPRODUCIBILITY_GAPS_EXPLICIT','tables':navigation,'figures':figure_records,
       'source_paper_hashes':read(paper)['source_inventory'],'qa_record':str(qa.relative_to(R)).replace('\\','/'),
       'scientific_calls':0,'not_full_raw_backup':True}
dump(O/'Thesis_Evidence_Navigation.json',index)
def link(path,label=None):
    f=Path(path)
    if not f.is_absolute(): f=R/f
    url=os.path.relpath(f,O).replace('\\','/')
    return '<a href="'+html.escape(url,quote=True)+'">'+html.escape(label or path)+'</a>'
parts=['<!doctype html><html lang="en"><meta charset="utf-8"><title>Thesis evidence index</title>',
       '<style>body{max-width:1050px;margin:40px auto;font:17px/1.5 system-ui;padding:0 24px;color:#17212b}section{border-top:1px solid #ccd5de;padding:14px 0}a{color:#075b9b}small{color:#4e5862}code{font-size:12px;overflow-wrap:anywhere}</style>',
       '<h1>Thesis evidence index</h1><p>28 October 2026 · 109-page working draft · 12 tables · 22 reproduced figures.</p>',
       '<p>This index distinguishes independently checked results, manuscript reports and missing evidence. It does not turn unresolved provenance into verified results.</p>',
       '<p>'+link(P,'Word draft')+' · '+link(O/'Integrated_Thesis_QA.pdf','Reviewed PDF')+' · '+link(qa,'Document QA')+'</p>']
for t in navigation:
    parts+=['<section><h2>'+html.escape(t['caption'])+'</h2><small>'+html.escape(t['status'])+'</small><p>'+html.escape(t['limitation'])+'</p><ul>']
    for e in t['records']: parts+=['<li>'+link(e['path'])+'<br><code>SHA256 '+e['sha256']+'</code></li>']
    parts+=['</ul></section>']
parts+=['<h2>Reproduced figures</h2>']
for f in figure_records: parts+=['<section><b>'+html.escape(f['caption'])+'</b><p>'+link(f['image'],'Extracted figure')+' · '+link(f['paper'],'Source paper')+' · PDF page '+str(f['physical_pdf_page'])+'</p></section>']
parts+=['</html>']
(O/'Evidence_Index.html').write_text('\n'.join(parts),encoding='utf-8')
print(json.dumps({'qa':record['status'],'pages':109,'table_index':len(navigation),'figure_index':len(figure_records),'new_science':0}))
