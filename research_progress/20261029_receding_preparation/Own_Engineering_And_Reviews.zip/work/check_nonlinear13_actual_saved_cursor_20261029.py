"""First actual returned-NET current-state warm/cold integration, saved-only.

This derives a one-decision saved policy prefix from already paid mathematics
and already audited physics. No optimizer, PF, model or new actual commitment.
It does not authorize a whole-policy campaign or certify arbitrary restart.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, io, json, os, pickle, random, subprocess, sys, time
import numpy as np
from remaining85_certified_loader_20261029 import load_certified_case
from remaining85_source_binder_v2_20261029 import DataUnpickler, physical_signature
from nonlinear13_current_state_20261029 import pack_current_state, load_current_state, SCHEMA, SOURCE_FILE, AUXILIARY_SOURCE, PQ_SOURCE

R=Path(__file__).resolve().parents[1]
O=R/'outputs/nonlinear13_actual_saved_cursor_20261029'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def ref(p, **extra):
    p=Path(p); raw=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(),sha256=sha(raw),bytes=len(raw),**extra)
def put(p,value):
    raw=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
    with Path(p).open('xb') as f: f.write(raw);f.flush();os.fsync(f.fileno())
    return ref(p)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def shape_hash(v):
    if isinstance(v,np.ndarray): return dict(array_dtype=v.dtype.str,shape=list(v.shape),bytes_sha256=sha(v.tobytes()))
    if isinstance(v,np.generic): return shape_hash(np.asarray(v))
    if isinstance(v,dict): return {str(k):shape_hash(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)): return dict(sequence_type=type(v).__name__,items=[shape_hash(x) for x in v])
    return v
def snapshot(kernel,cursor):
    fields={name:shape_hash(value) for name,value in vars(kernel).items()}
    return dict(kernel=fields,cursor=shape_hash(cursor))

def cold():
    before=time.perf_counter(); p=read(O/'Protocol.json')
    for relative,digest in p['sources'].items(): assert sha((R/relative).read_bytes())==digest
    kernel,cursor=load_current_state(R,read(O/'Checkpoint_Reference.json'))
    actual=snapshot(kernel,cursor); expected=read(O/'Warm_Snapshot.json')
    assert actual==expected, 'Cold field/type/dtype/shape/arraybytes state differs'
    assert not kernel.costs
    put(O/'Cold_Result.json',dict(status='PASS_EXACT_REAL_RETURNED_STATE_COLD_BINDING',elapsed_seconds=time.perf_counter()-before,
        every_kernel_and_cursor_field_type_shape_bytes_equal=True,scientific_calls=0,actual_new_control_commits=0))

def main():
    begin=time.perf_counter(); O.mkdir(exist_ok=False)
    paths=[SOURCE_FILE,AUXILIARY_SOURCE,PQ_SOURCE,'work/remaining85_certified_loader_20261029.py',
           'work/remaining85_source_binder_v2_20261029.py','work/nonlinear13_validated_kernel_v2_20261029.py',
           Path(__file__).relative_to(R).as_posix()]
    evidence=[
      'outputs/nonlinear13_first_proposal_execution_20261029/Proposal_Result.json',
      'outputs/nonlinear13_first_proposal_execution_20261029/Result.json',
      'outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json',
      'outputs/nonlinear13_first_proposal_paid_join_v2_20261029/Result.json',
      'outputs/nonlinear13_first_proposal_paid_join_v2_20261029/Exact_Lookup.json',
      'outputs/nonlinear500_paid_registry_independent_20261029/Repair_And_First_Reuse_Review.json']
    deadline=time.monotonic()+60
    protocol=dict(at_utc=datetime.now(timezone.utc).isoformat(),scope='First real saved-NET cursor integration; zero new science and no live-policy performance',
      selected_identity='Fixed seed0 next_step2 from the already verified first proposal and exact paid returned physics',
      sources={p:sha((R/p).read_bytes()) for p in paths}, evidence=[ref(R/p) for p in evidence],
      owner=dict(pid=os.getpid(),parent=os.getppid(),command=sys.argv),absolute_deadline_monotonic=deadline,
      clock_domain='LOCAL_WINDOWS_SAVED_ONLY_FIXTURE_'+str(os.getpid()),science_calls_authorized=0,
      fresh_child_timeout_seconds=45,old_deadlines_not_extended=True)
    protocol_ref=put(O/'Protocol.json',protocol)
    initial,binding=load_certified_case(R,0)
    proposal=read(R/evidence[0]); result=read(R/evidence[3]); lookup=read(R/evidence[4])
    assert proposal['status']=='ADMITTED_UNMEASURED_PROPOSAL' and result['original_guard'] is True
    assert lookup['status']=='VERIFIED_EXACT_PAID_REUSE'
    r=lookup['reuse']['after']; assert sha((R/r['path']).read_bytes())==r['sha256']
    saved=DataUnpickler(io.BytesIO((R/r['path']).read_bytes())).load()
    q=saved['sgen'].q_mvar.to_numpy()[:3].copy(); vm=saved['res_bus'].vm_pu.to_numpy().copy()
    u=np.asarray(proposal['u'],dtype=np.float32); assert np.array_equal(initial.current_q-u,q)
    assert np.array_equal(vm,np.asarray(result['after_vm']))
    signature=physical_signature(saved); assert signature==result['physical_signature']
    paid=dict(status='RETURNED',after=r['path'],after_sha256=r['sha256'],physical_signature=signature,
      kwargs={'algorithm':'bfsw','init':'dc'},origin='DERIVED_ALIAS_OF_PREVIOUSLY_AUDITED_RETURN_NOT_NEW_PHYSICS',
      prior_lookup=ref(R/evidence[4]),prior_independent_certificate=ref(R/lookup['reuse']['independent_certificate']))
    receipt_ref=put(O/'Derived_Paid_Receipt.json',paid); paid['record_ref']=receipt_ref
    cost_ref=put(O/'Full_Cost_Lineage.json',dict(current_new_PF=0,current_new_optimizer=0,current_new_model=0,
      actual_new_commits=0,derived_saved_decisions=1,prior_actual_math=ref(R/evidence[1]),
      prior_math_journal=ref(R/'outputs/nonlinear13_first_proposal_execution_20261029/calculations.jsonl'),
      prior_physics_and_replay=ref(R/lookup['reuse']['independent_certificate']),
      unknown_costs={'prior_native_linear_factorization_counts':'UNKNOWN','prior_selected_physics_individual_latency':'UNKNOWN'},
      interpretation='All prior calculation/PF/replay/preparation costs retained by source reference; not counted free or converted to zero.'))
    journals={}
    for name,event in [('Attempt','Reuse exact closed seed0 mathematics and exact returned physics'),
                       ('Physical','Old returned receipt alias only; no call'),('Math','Old completed proposal alias only; no optimizer')]:
        journals[name]=put(O/(name+'_Reference.json'),dict(event=event,evidence=[ref(R/evidence[0]),receipt_ref],new_science=0))
    cursor=dict(schema=SCHEMA,evidence_scope='ACTUAL_SOLVED_RECEIPT',seed=0,next_step=2,remaining_original_horizon=99,
      original_horizon=100,stop_status=None,root_NET=binding['root'],current_NET=dict(r,kind='NET'),current_physical_signature=signature,
      current_Q=q,current_vm=vm,history=[dict(step=1,accepted=True,before_Q=initial.current_q.copy(),native_u=u,
        candidate_Q=q.copy(),committed_Q=q.copy(),candidate_receipt_ref=receipt_ref,before_vm=initial.vm.copy() if hasattr(initial,'vm') else None,
        interpretation='Derived saved-policy decision, not fresh actual deployment commitment')],paid_receipt=paid,
      source_lock=protocol['sources'],absolute_deadline_monotonic=deadline,original_deadline_monotonic=deadline,
      clock_domain=protocol['clock_domain'],owner_protocol_ref=protocol_ref,
      rng_state={'python':random.getstate(),'numpy':np.random.get_state(),'torch':None,'cuda':None,'solver':None},
      solver_state_ref=ref(R/evidence[0]),costs={'new_PF':0,'new_optimizer':0,'new_model':0,'actual_new_commits':0,'derived_saved_decisions':1},
      unknown_costs={'native_internal_factorizations':'UNKNOWN','prior_individual_PF_latency':'UNKNOWN'},cost_journal_ref=cost_ref,
      historical_paid_index_ref=ref(R/'outputs/nonlinear500_paid_registry_20261029/Frozen_Registry_Manifest.json'),
      attempt_journal_ref=journals['Attempt'],math_journal_ref=journals['Math'],physical_journal_ref=journals['Physical'],
      physical_kwargs={'algorithm':'bfsw','init':'dc'},actual_new_control_commits=0,
      derivation_scope='SAVED_POLICY_PREFIX_ONLY_NOT_NEW_MATCHED_TRAJECTORY')
    kernel,checkpoint_ref=pack_current_state(R,0,cursor['current_NET'],cursor,(O/'Complete_Cursor.pkl').relative_to(R).as_posix())
    put(O/'Checkpoint_Reference.json',checkpoint_ref); put(O/'Warm_Snapshot.json',snapshot(kernel,cursor))
    assert not kernel.costs and time.monotonic()<deadline
    p=subprocess.run([sys.executable,str(Path(__file__)),'--cold'],capture_output=True,text=True,encoding='utf-8',timeout=45)
    (O/'Cold_stdout.txt').write_text(p.stdout,encoding='utf-8');(O/'Cold_stderr.txt').write_text(p.stderr,encoding='utf-8')
    assert p.returncode==0,p.stderr
    put(O/'Result.json',dict(status='PASS_FIRST_REAL_SAVED_CURRENT_STATE_WARM_COLD_INTEGRATION',
      at_utc=datetime.now(timezone.utc).isoformat(),workflow_seconds=time.perf_counter()-begin,child_exit=p.returncode,
      seed=0,next_step=2,saved_physical_signature=signature,new_PF_optimizer_model_calls=0,actual_new_control_commits=0,
      limits=['One derived saved-policy prefix only, no full worker/trajectory/restart certificate.',
      'Worker C1-C4 semantic journals, owner clock, history and per-step cost enforcement still require actual integration.']))
    put(O/'Closed_Manifest.json',dict(files=[ref(p) for p in sorted(O.iterdir()) if p.is_file()]))
    print(json.dumps(dict(status='PASS_FIRST_REAL_SAVED_CURRENT_STATE_WARM_COLD_INTEGRATION',new_science=0)))

if __name__=='__main__':
    if sys.argv[1:]==['--cold']: cold()
    elif not sys.argv[1:]:
        try:main()
        except Exception as exc:
            if O.exists() and not (O/'Failure.json').exists():put(O/'Failure.json',dict(type=type(exc).__name__,message=str(exc),new_science=0))
            raise
    else:raise SystemExit('Unsupported command')
