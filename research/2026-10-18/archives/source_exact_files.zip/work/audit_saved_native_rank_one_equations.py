"""Saved current-equation algebra audit, zero derivatives or solves."""
import gzip,json,os,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';S=P/'sla_remaining'
OUT=P/'native_factor_cache_saved_equation_audit';assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
sources=[S/'Actual_All_Transition_Records.json',P/'measured_OPT_transition_inventory/Actual_OPT_Transition_Rows.jsonl.gz',
 P/'native_factor_cache_software_readiness/Software_Readiness.json',P/'sla_remaining_audit/Independent_Source_Latched_Affine_Audit.json',
 ROOT/'work/source_latched_native_factor_cache.py',Path(__file__)]
protocol={'declared_at_utc':datetime.now(timezone.utc).isoformat(),'saved_only':True,
 'all216_declared_transition_identities':'Original full OPT set; one lost original old-Y equation remains unknown and is never rerun.',
 'test':'For every old/candidate saved step pair having the same exact53-gen mask, compare J/rhs to current-native one-diagonal Q/Vm perturbation, and verify both saved solutions against its algebra.',
 'tolerances':{'matrix_and_rhs':1e-10,'saved_solution_equation_residual':1e-8},
 'new_linear_solve_derivative_conversion_PF_model_optimizer_cloud_calls':0,
 'source_hashes':{str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in sources}}
write(OUT/'Protocol.json',protocol);write(OUT/'audit.claim',{'pid':os.getpid()})
with gzip.open(sources[1],'rt',encoding='utf8') as f:ts={r['transition_id']:r for r in map(json.loads,f)}
records=read(sources[0]);assert len(records)==len(ts)==216
assert read(sources[2])['all_software_checks_passed'] and read(sources[3])['all_source_input_equation_mask_update_cost_manifest_gates_passed']
checks=[];unknown=[];matched=0;maxJ=maxB=maxres=0.;cached_steps=0
def frame(f):return {i:dict(zip(f['columns'],r)) for i,r in zip(f['index'],f['values'])}
for r in records:
 t=ts[r['transition_id']];obs=t['model_input']['current_physical_observation'];a=t['model_input']['candidate_action']
 assert r['before_sha256']==t['before_observation_sha256'] and r['action']==a
 arms=r['arms'];old=arms['old_admittance_derivative'];new=arms['candidate_admittance_derivative']
 if old['status']=='UNKNOWN_original_arrays_lost_no_repeat':
  assert r['transition_id']=='00b5b400e0eed0f17600d34db76cc3222798ed0125240a565adaf0f23eda9085'
  unknown.append({'transition_id':r['transition_id'],'arm':'old_admittance_derivative','reason':'Original equation bytes unavailable; no repeat or imputation'});continue
 for item in (old,new):assert sha(S/item['equation_file'])==item['array_sha256']
 with np.load(P/'observed_constraint_affine_diagnostic/states'/(r['before_sha256']+'.npz')) as z:
  V=z['V'];mapping=z['mapping'];refs=set(z['refs']);base=float(z['baseMVA'])
 gen=frame(obs['physical_tables']['gen']);k=int(mapping[a['bus']]);alpha=-2*a['q_abs_mvar']*abs(V[k])/base
 def maskkey(step):return tuple(sorted((int(i),s) for i,s in step['mask'].items()))
 nsteps={maskkey(step):step for step in new['steps']};local=0
 with np.load(S/old['equation_file']) as zo,np.load(S/new['equation_file']) as zn:
  for os_ in old['steps']:
   key=maskkey(os_)
   if key not in nsteps:continue
   ns=nsteps[key];oi,ni=os_['step'],ns['step']
   J0,b0,x0=(zo[f's{oi:02d}_{n}'] for n in ('J','rhs','x'))
   J1,b1,x1=(zn[f's{ni:02d}_{n}'] for n in ('J','rhs','x'))
   fixed=refs|{int(mapping[gen[i]['bus']]) for i,s in key if s=='interior'}
   free=[p for p in range(118) if p not in fixed];nr=[p for p in range(118) if p not in refs]
   E=np.zeros_like(J0);pos=None
   if k in free:pos=len(nr)+free.index(k);E[pos,pos]=alpha
   diff=float(np.max(np.abs(J1-J0-E)));bdiff=float(np.max(np.abs(b1-b0)))
   residual=max(float(np.max(np.abs(J0@x0-b0))),float(np.max(np.abs((J0+E)@x1-b1))))
   assert diff<=1e-10 and bdiff<=1e-10 and residual<=1e-8
   relation=float(np.max(np.abs(J0@(x1-x0)+E@x1-(b1-b0))));assert relation<=1e-8
   checks.append({'transition_id':r['transition_id'],'old_step':oi,'candidate_step':ni,'native_action':a,
    'rank_one_position':pos,'alpha':alpha,'max_matrix_difference':diff,'max_rhs_difference':bdiff,'max_residual':residual,'solution_difference_identity_residual':relation})
   matched+=1;local+=1;maxJ=max(maxJ,diff);maxB=max(maxB,bdiff);maxres=max(maxres,residual)
  assert local>=1 # All-interior first steps must match for every available case.
 cached_steps+=len(old['steps'])+len(new['steps'])
assert len(unknown)==1 and len({c['transition_id'] for c in checks})==215
result={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'all_saved_algebra_checks_passed':True,
 'declared_transitions':216,'available_checked_transitions':215,'retained_unknown_original_equation_identity':unknown,
 'exact_same_mask_pair_checks':matched,'available_saved_step_records':cached_steps,
 'max_rank_one_matrix_difference':maxJ,'max_rhs_difference':maxB,'max_saved_equation_residual':maxres,
 'new_linear_solve_derivative_conversion_PF_model_optimizer_cloud_calls':0,'audit_seconds':time.perf_counter()-start,
 'actual_full_native_ranking_or_LLM_performance_calls':0,'production_control_not_yet_ready':True,
 'limitations':['Tolerance-bounded equation equivalence is not bit-identical floating-point branch/ranking equality.',
 'Native full-ranking runner/input-scope/cache-reuse/resource gates and an independent reader remain necessary before a new control study.',
 'No original lost solution was reconstructed; old science is not repeated.']}
write(OUT/'Actual_Saved_Rank_One_Equation_Checks.json',checks);write(OUT/'Independent_Saved_Rank_One_Compatibility_Audit.json',result)
files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='audit.claim'};files['source/auditor.py']=Path(__file__)
archive=seal(OUT,files,'Saved_Native_Rank_One_Equation_Audit.zip');write(OUT/'status.json',{'stage':'complete_saved_equation_algebra_audit'})
print(json.dumps({'audit':result,'archive':archive}))
