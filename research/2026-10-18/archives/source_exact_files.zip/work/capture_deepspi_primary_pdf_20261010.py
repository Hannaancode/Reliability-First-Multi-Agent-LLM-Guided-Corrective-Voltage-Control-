"""Retrieve one public proceedings source; no research data or model calls."""
import hashlib, json, os, urllib.request
from datetime import datetime, timezone
from pathlib import Path
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/deepspi_proceedings_source'
OUT.mkdir(parents=True,exist_ok=False)
URL='https://proceedings.iclr.cc/paper_files/paper/2026/file/0212b0dff7b4aa3bd8b8cc4ce24fd384-Paper-Conference.pdf'
record={'requested_at_utc':datetime.now(timezone.utc).isoformat(),'url':URL,'scope':'One public source retrieval and text extraction; not performance science'}
try:
    request=urllib.request.Request(URL,headers={'User-Agent':'HierGrid research source review'})
    with urllib.request.urlopen(request,timeout=40) as response:
        raw=response.read()
        record['resolved_url']=response.geturl()
    assert raw.startswith(b'%PDF-')
    path=OUT/'DeepSPI_ICLR2026.pdf'
    path.write_bytes(raw)
    reader=PdfReader(path)
    pages=[p.extract_text() or '' for p in reader.pages]
    text='\n'.join(f'\n[PDF PAGE {i+1}]\n'+p for i,p in enumerate(pages))
    (OUT/'DeepSPI_ICLR2026_extracted.txt').write_text(text,encoding='utf-8')
    record.update(status='PUBLIC_PDF_RETRIEVED',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),pages=len(pages),
                  text_sha256=hashlib.sha256(text.encode()).hexdigest(),source_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
except Exception as error:
    record.update(status='SOURCE_RETRIEVAL_OR_EXTRACTION_FAILED',error_type=type(error).__name__,error=str(error),no_automatic_retry=True)
with (OUT/'Source_Retrieval.json').open('x',encoding='utf-8') as handle:
    json.dump(record,handle,indent=2);handle.write('\n');handle.flush();os.fsync(handle.fileno())
print(json.dumps(record))
