"""Bind the actual single owner and launch one saved-output reader after release."""
import json,subprocess,time,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'outputs/critical_research_reset_20261010'
EX=R/'public_size_execution';OUT=R/'public_size_audit_continuation'
assert not OUT.exists();OUT.mkdir()
(OUT/'owner.claim').write_text(json.dumps({'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()}))
def save(stage,**rest):(OUT/'status.json').write_text(json.dumps({'stage':stage,'updated_at_utc':datetime.now(timezone.utc).isoformat(),**rest},indent=2))
save('binding_actual_owner')
owner=json.loads((EX/'owner.claim').read_text());pid=owner['pid']
def command():
    result=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],
       capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0;return result.stdout.strip()
actual=command();assert actual and 'run_public_size_screen_colab_20261010.py' in actual
(OUT/'Actual_Bound_Owner.json').write_text(json.dumps({'pid':pid,'observed_command':actual},indent=2))
save('waiting_for_exact_owner',bound_pid=pid)
while True:
    actual=command()
    if not actual or 'run_public_size_screen_colab_20261010.py' not in actual:break
    time.sleep(15)
status=json.loads((EX/'status.json').read_text())
if not status.get('runtime_released') or not status.get('all_actual_closed_artifacts_preserved'):
    save('ended_without_readable_released_science',reason='Preserve actual partials; no complete reader or science retry');raise SystemExit(1)
assert not (R/'public_size_external_audit').exists()
save('one_external_reader')
with (OUT/'reader_stdout.log').open('x') as out,(OUT/'reader_stderr.log').open('x') as err:
    result=subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8','work/audit_public_size_screen_20261010.py'],
      cwd=ROOT,stdout=out,stderr=err,timeout=1200,creationflags=subprocess.CREATE_NO_WINDOW)
save('external_audit_ended',reader_exit_code=result.returncode)
raise SystemExit(result.returncode)
