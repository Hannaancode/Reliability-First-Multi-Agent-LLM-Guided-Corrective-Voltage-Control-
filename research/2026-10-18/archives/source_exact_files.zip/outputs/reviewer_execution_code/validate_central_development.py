"""Historical prompt/parser/control-loop checks; no model-inference claim."""
import copy,json,hashlib,sys
from pathlib import Path
import pandapower as pp
from tokenizers import Tokenizer
from frozen_physics_loader import ROOT,load_stack
from central_ablation import global_observation,fit_prompt,build_central_runner
from physical_replay_audit import save
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True)
class OfflineTokenizer:
    def __init__(self):self.t=Tokenizer.from_file(str(ROOT/'pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/tokenizer.json'))
    def apply_chat_template(self,msgs,tokenize=True,add_generation_prompt=True):
        # Exact simple system/user branch of this saved Qwen Jinja template.
        text=''.join('<|im_start|>'+m['role']+'\n'+m['content']+'<|im_end|>\n' for m in msgs)
        if add_generation_prompt:text+='<|im_start|>assistant\n'
        return self.t.encode(text,add_special_tokens=False).ids
def main():
    v2,runner,ref=load_stack();tokenizer=OfflineTokenizer();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
    rows=[];locked={p.stem for p in (ROOT/'bank/scenarios').glob('*.json')}
    for sid in ['fed_combined_load_1p25_line_101_MG1','fed_combined_load_1p5_line_101_MG1']:
        assert sid not in locked;net=copy.deepcopy(base);v2.v0.apply_scenario_to_net(net,json.loads((ROOT/'pack/scenarios/federation'/f'{sid}.json').read_text()),zones);assert v2.v0.run_pf(net)[0]
        observation,candidates=global_observation(net,zones,runner);feedback=ref.init_feedback_state();_,_,fit=fit_prompt(tokenizer,net,zones,runner,ref,feedback,[],'MG1')
        assert len(observation['bus_voltage_pu'])==len(net.bus) and set(observation['zones'])==set(zones)
        assert candidates==sorted({b for z in zones for b in runner.get_zone_candidate_buses(net,z,zones,runner.rescue.extract_zone_state_full(net,z,zones))})
        # Exercise repair and parser through the actual cloned function globals.
        run=build_central_runner(ref,runner);clone=next(c.cell_contents for c in run.__closure__ if callable(c.cell_contents) and hasattr(c.cell_contents,'__code__') and c.cell_contents.__code__ is ref.run_one_scenario_two_best_v2.__code__)
        query=clone.__globals__['get_llm_action_required_two_best_v2'];original=runner.base_runner.generate_response;responses=iter(['bad JSON',json.dumps({'bus':str(candidates[0]),'q_mvar':100})]);calls=[]
        def fake(model,tok,msgs):calls.append(len(tok.apply_chat_template(msgs)));return next(responses)
        runner.base_runner.generate_response=fake
        try:
            action,info=query(None,tokenizer,net,'MG1',zones,{},runner.rescue.global_uv_buses(net),[],feedback,'reflection_v2')
        finally:runner.base_runner.generate_response=original
        assert info['reprompted'] and info['valid_action'] and action and len(calls)==2 and all(n+384<=4096 for n in calls)
        repair_input_tokens=calls[1]
        # Later slots must not repeat a prior structurally valid proposal bus.
        assert len(candidates)>1
        prior_bus=str(candidates[0]);next_bus=str(candidates[1])
        responses=iter([json.dumps({'bus':prior_bus,'q_mvar':100}),json.dumps({'bus':next_bus,'q_mvar':100})]);calls=[]
        runner.base_runner.generate_response=fake
        try:
            later,diversity=query(None,tokenizer,net,'MG2',zones,{},runner.rescue.global_uv_buses(net),[],feedback,'reflection_v2')
        finally:runner.base_runner.generate_response=original
        assert diversity['reprompted'] and diversity['valid_action'] and str(runner.action_bus(later))==next_bus
        assert prior_bus in diversity['previous_proposal_buses'] and prior_bus not in {str(b) for b in diversity['candidate_buses']}
        assert len(calls)==2
        responses=iter([json.dumps({'bus':prior_bus,'q_mvar':100})]);calls=[]
        runner.base_runner.generate_response=fake
        try:
            reset,reset_info=query(None,tokenizer,net,'MG1',zones,{},runner.rescue.global_uv_buses(net),[],feedback,'reflection_v2')
        finally:runner.base_runner.generate_response=original
        assert reset_info['valid_action'] and reset_info['previous_proposal_buses']==[] and str(runner.action_bus(reset))==prior_bus
        row={'scenario_id':sid,'outside_locked_bank':True,'all_bus_voltage_observations_present':True,'all_four_zonal_summaries_present':True,'candidate_pool_exact_union':True,'primary_prompt':fit,'repair_input_tokens':repair_input_tokens,'malformed_then_valid_reply_test_passed':True,'control_loop_code_object_identical':clone.__code__ is ref.run_one_scenario_two_best_v2.__code__,'model_inference_executed':False}
        row.update(later_slot_duplicate_bus_rejected_and_repaired=True,exclusion_reset_each_iteration=True)
        rows.append(row);print('CENTRAL_DEVELOPMENT_CHECK',sid,'input_tokens',fit['input_tokens'],'diversity_and_reset_passed',flush=True)
    save('outputs/central_ablation_development_checks.json',{'implementation_sha256':hashlib.sha256(Path('work/central_ablation.py').read_bytes()).hexdigest(),'status':'CPU historical structural/prompt/parser checks passed; GPU historical inference still required before freezing or locked-bank execution','cases':rows})
if __name__=='__main__':main()
