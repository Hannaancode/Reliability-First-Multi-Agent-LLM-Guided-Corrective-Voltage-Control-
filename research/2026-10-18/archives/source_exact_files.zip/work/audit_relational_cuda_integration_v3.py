"""External CLOSED engineering artifacts reader; zero new model/PF calls."""
import candidate_process_runtime
import json,os,time,torch,subprocess
from collections import Counter
from datetime import datetime,timezone
from candidate_process_evidence_utils import ROOT,read,write,sha,seal,frozen_checks
from relational_complete_active_state import verify,tree_exact
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';PREP=P/'cuda_integration_preparation_v3'
E=P/'cuda_integration_execution_v3';S=E/'staged/study';OUT=P/'cuda_integration_external_audit_v3'
assert not OUT.exists();OUT.mkdir();write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
start=time.perf_counter();state=read(E/'status.json');owner=int((E/'owner.claim').read_text())
command=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={owner}'; if ($p -and $p.CommandLine -match 'run_relational_cuda_integration_colab_v3.py') {{ 'LIVE' }} else {{ 'ENDED' }}"
found=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,timeout=30)
assert found.returncode==0 and found.stdout.strip()=='ENDED'
assert state['runtime_released'] and state['all_actual_artifacts_preserved'] and state['remote_exit_code']==0 and state['finished_at_utc']
assert state['expected_account']=='ahammedsheen@gmail.com' and state['allocation_requests']==1
proto=read(PREP/'protocol.json');protocol_sha=sha(PREP/'protocol.json');env=read(PREP/'Expected_Environment.json')
assert read(E/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
assert read(E/'staged/remote_frozen_environment.json')==env
for n,h in read(PREP/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha(ROOT/n)==h
descriptor=read(E/'remote_output_descriptor.json');assert read(E/'staged/pilot_exit.json')['exit_code']==0
assert len(descriptor['members'])==len(set(descriptor['members']))
for n,v in descriptor['members'].items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
for n,v in read(S/'Closed_Actual_Manifest.json').items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
assert read(S/'protocol.json')==proto
events=[json.loads(l) for l in (S/'events.jsonl').read_text().splitlines()]
assert events[-1]['event']=='science_complete';summary=read(S/'summary.json');counts=summary['counts']
assert summary['all_actual_engineering_gates_passed'] and summary['actual_preservation_ACKs']==8
assert counts['forward_attempts']==counts['forward_returns']==18 and counts['backward_attempts']==counts['backward_returns']==6
assert counts['actual_optimizer_returns_including_engineering_resume_branch']==6 and counts['PF_attempts']==counts['generation_attempts']==0
assert Counter(e['event'] for e in events)['forward_attempt']==Counter(e['event'] for e in events)['forward_return']==18
assert len([e for e in events if e['event']=='optimizer_return'])==6
returns=[e for e in events if e['event']=='forward_return']
assert sum(e['soft_positions'] for e in returns)==counts['soft_positions']
assert sum(e['typed_cells'] for e in returns)==counts['typed_cells'] and sum(e['value_UTF8_bytes'] for e in returns)==counts['value_UTF8_bytes']
certificates={}
for arm in proto['arms']:
    ee=[e for e in events if e['arm']==arm]
    assert len([e for e in ee if e['event']=='forward_return'])==9
    assert Counter(e['branch'] for e in ee if e['event']=='optimizer_return')=={'continuous':2,'cold_engineering_replica':1}
    rows=proto['two_OPT_engineering_views'];by={r['observation_id']:r for r in rows}
    for e in ee:
        if e['event']=='backward_return':
            d=e['loss_terms'];expected=(d['classification']+d['native_pairwise_rank']+d['current_grounding'])*by[e['observation_id']]['world_weight']
            assert abs(e['loss']-expected)<=1e-5*max(1.,abs(expected))
            assert all(v['finite'] for v in e['gradient_tensors'].values())
    assert all(v>0 for v in read(S/arm/'Second_Step_Nonzero_Gradient_Paths.json').values())
    ck=[]
    for name,steps in [('Step1_Complete_Active_State.pt',1),('Step2_Complete_Active_State.pt',2),('Cold_Resumed_Step2_Complete_State.pt',2)]:
        t=torch.load(S/arm/name,weights_only=False)
        contract={'protocol_sha256':protocol_sha,'arm':arm,'common_initialization_sha256':proto['common_initialization_sha256'],
          'base_sha256':env['base_weight_sha256'],'two_observation_ids':[r['observation_id'] for r in rows]}
        assert verify(t,contract,steps) and len(t['rng']['torch_CUDA'])==1
        assert sum(p.numel() for p in t['active_parameters'].values())==proto['new_active_parameters'][arm]
        assert len(t['optimizer_group_names'])==(2 if arm=='internal_residual' else 1);ck.append(t)
    assert tree_exact(ck[1],ck[2])
    first=torch.load(S/arm/'Zero_Path_Actual_Predictions.pt',weights_only=True)
    assert tree_exact(first['original_function'],first['new_zero_function'])
    a=torch.load(S/arm/'Continuous_Final_Predictions.pt',weights_only=True);b=torch.load(S/arm/'Cold_Resumed_Final_Predictions.pt',weights_only=True)
    assert set(a)==set(b)==set(by) and tree_exact(a,b)
    for r in rows:
        assert a[r['observation_id']]['prediction'].shape==(118,9,3) and bool(torch.isfinite(a[r['observation_id']]['prediction']).all())
    load=read(S/arm/'Actual_Load_Certificate.json');cold=read(S/arm/'Cold_Resume_Load_Certificate.json')
    for l in (load,cold):
        assert l['actual_new_active_parameters']==proto['new_active_parameters'][arm] and l['private_tensors_before_attachment']==336
        assert l['body_loader']['four_bit_base'] and l['body_loader']['source_tensor_values_identical']
        assert l['old_tensor_object_registry']['all_quantization_objects_preserved']>0
    assert len(load['separate_new_qkv_sites'])==(72 if arm=='internal_residual' else 0)
    assert all(v is True for k,v in read(S/arm/'Actual_Arm_Gates.json').items() if isinstance(v,bool))
    certificates[arm]={'nine_actual_model_forwards_three_actual_AdamW_returns':True,
      'all_new_second_step_gradient_paths_nonzero':True,'actual_zero_path_bit_exact':True,
      'full_cold_optimizer_RNG_cursor_parameter_state_exact':True,'two_fresh_final_prediction_arrays_exact':True,
      'quantized_original_private_base_object_and_value_preservation_actual_gates':True}
actual={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'certificates':certificates,
 'actual_18forwards_6optimizer_returns_8ACKs':True,'exact_third_T4_release_observed':state['runtime_released'],
 'all_111_environment_source_case_common_context_mask_identity_gates':True,
 'actual_CUDA_memory':{k:v for k,v in summary.items() if k.startswith('CUDA_')},
 'actual_scientific_workflow_seconds_including_nested_preservation':summary['actual_science_workflow_seconds_including_preservation'],
 'new_model_forward_optimizer_PF_cloud_calls_by_reader':0,'no_policy_learning_superiority_novelty_or_confirmation_claim':True,
 'actual_reader_seconds_before_seal':time.perf_counter()-start}
write(OUT/'Independent_Actual_CUDA_Integration_Audit.json',actual);write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
(OUT/'Results.md').write_text('The separately fixed engineering test passed:18 actual model forwards and6 charged optimizer returns, including two cold-step replicas. Both arms preserve original private/base/quantized tensors, exercise every new path, and reproduce complete AdamW/RNG/cursor state and final scores after a genuinely cold CUDA model load. The exact third-account runtime was released after eight verified preservation ACKs and all closed artifacts. This is engineering evidence, not measured action-quality improvement, D-SE superiority or novelty. A separate prospective model learning manifest and resource estimate based on this measured full-context smoke remain required. Historical development and all adverse controls remain retained.\n',encoding='utf8')
files={'science/'+n:S/n for n in descriptor['members']}
for f in OUT.iterdir():
    if f.is_file() and f.name!='audit.claim':files['audit/'+f.name]=f
files['protocol.json']=PREP/'protocol.json';files['actual_owned_runtime_status.json']=E/'status.json'
files['source/audit.py']=ROOT/'work/audit_relational_cuda_integration.py'
seal(OUT,files,'Verified_Actual_Relational_CUDA_Engineering.zip')
write(OUT/'status.json',{'stage':'complete_external_actual_engineering_audit','all_passed':True})
print(json.dumps(actual,indent=2))
