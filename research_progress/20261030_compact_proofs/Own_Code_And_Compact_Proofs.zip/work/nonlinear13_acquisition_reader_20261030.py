"""Saved acquisition evidence reader. No optimizer, PF, model or campaign entry.

New mathematical journals are verified once per context by the independent
saved-math reader. Historical calculation journals are never opened. Physical
evidence is decoded data only; no producer engine replay is called.
"""
from pathlib import Path
from collections import Counter
import base64
import io
import json
import time
import numpy as np
from nonlinear13_saved_math_reader_20261030 import verify_receipt, RECIPE, canonical, digest, require, CONTEXT_NAMES, MECHANISM_SOURCES
from remaining85_source_binder_v2_20261029 import DataUnpickler, physical_signature


def same(a, b):
    return np.array_equal(np.asarray(a), np.asarray(b))


def metrics(vm):
    vm = np.asarray(vm)
    require(vm.shape == (13,) and np.isfinite(vm).all(), 'Invalid actual13 VM')
    return dict(UV=int(np.sum(vm < .95)), OV=int(np.sum(vm > 1.05)),
        strict_fullband=bool(np.all((vm >= .95) & (vm <= 1.05))),
        common_epsilon_fullband=bool(np.all((vm >= .95-1e-8) & (vm <= 1.05+1e-8))))


def actual_guard(before, after):
    a, b = np.asarray(before), np.asarray(after); metrics(a); metrics(b)
    normal = (a >= .95) & (a <= 1.05)
    return bool(np.all(b[normal] >= .95-1e-8) and np.all(b[normal] <= 1.05+1e-8)
        and np.sum(b < .95) <= np.sum(a < .95) and np.sum(b > 1.05) <= np.sum(a > 1.05))


def parse_journal(raw, summary):
    require(not raw or raw.endswith(b'\n'), 'Incomplete policy journal tail')
    previous = '0'*64; events = []
    for line in raw.splitlines():
        row = json.loads(line); e = row['event']
        require(e['seq'] == len(events) and e['previous'] == previous
            and digest(canonical(e)) == row['sha256'], 'Policy hash/sequence mismatch')
        previous = row['sha256']; events.append(e)
    require(summary['journal_bytes'] == len(raw) and summary['journal_events'] == len(events)
        and summary['journal_last_sha256'] == previous, 'Policy/result journal summary differs')
    return events


def mathematical_costs(proposal, primary, journal_raw=b''):
    numeric = {}
    unknown = {'numerical.optimizer.internal_QP_factorizations':'UNKNOWN_INSIDE_PINNED_NATIVE_LIBRARY_NOT_FREE',
        'numerical.optimizer.internal_linear_solves':'UNKNOWN_INSIDE_PINNED_NATIVE_LIBRARY_NOT_FREE'}
    if proposal is not None:
        for key, value in proposal['costs'].items():
            target = numeric if type(value) in (int, float) else unknown
            target['numerical.optimizer.'+key] = value
    else:
        count = Counter(); seconds = 0.; malformed = False
        for line in journal_raw.splitlines():
            try: event = json.loads(line)['event']
            except (ValueError, KeyError): malformed = True; break
            count[event['kind']] += 1
            if event['kind'] == 'native_solver_call_end': seconds += event['elapsed_seconds']
        for kind, name in [('optimizer_attempt','optimizer_attempts'),('optimizer_lossless_raw_return','optimizer_returns'),
                ('optimizer_exception','optimizer_exceptions'),('native_solver_call_attempt','native_slsqp_calls'),
                ('major_iteration_return','major_iteration_callbacks')]:
            numeric['numerical.observed_durable.'+name] = count[kind]
        numeric['numerical.observed_durable.native_slsqp_seconds'] = seconds
        unknown['numerical.complete_failed_optimizer_totals'] = 'UNKNOWN: no complete proposal; durable observed counts only, no scientific retry'
        if malformed: unknown['numerical.partial_journal_tail'] = 'UNKNOWN: malformed/unclosed tail retained; no complete cost claim'
    for key, value in primary['kernel_costs'].items(): numeric['numerical.kernel.'+key] = value
    for key in ('workflow_seconds', 'journal_bytes', 'journal_events'): numeric['numerical.'+key] = primary[key]
    return numeric, unknown


def audit_events(events, result, evidence):
    """Pure state machine. evidence supplies independently checked saved records.

    Production uses SavedEvidence below; synthetic checks use explicit new
    stubs. This core alone does not establish source/owner/physical provenance.
    """
    committed, math, attempts, paid, terminals, rejected = {}, {}, {}, {}, {}, set()
    reservations = set(); attempt_states = {}; mechanical_notices = {}; mechanical_started = False
    steps = Counter(); numeric = Counter(); unknown = {}; lineage = {}; new_refs = {}
    allowed_other = {'paid_metadata_loaded', 'paid_lookup_io', 'paid_provenance_io',
        'physics_lookup', 'cursor_preserved', 'preproposal_preserved', 'numerical_bank_constructed'}
    for e in events:
        kind = e['kind']; key = e.get('context_key')
        if kind in ('outstanding_cost_receipt_notice','mechanical_closure_notice'):
            mechanical_started = True
            require(not e['numeric_cost'] and not e['unknown_cost'], 'Mechanical closure fabricated numerical costs')
            if kind == 'outstanding_cost_receipt_notice':
                require(key not in mechanical_notices, 'Duplicate mechanical receipt notice')
                mechanical_notices[key] = e['receipt_ref']
            continue
        require(not mechanical_started, 'Normal action/event followed irreversible mechanical closure')
        for name, value in e['numeric_cost'].items():
            require(type(value) in (int, float) and np.isfinite(value) and value >= 0, 'Invalid numeric event cost')
            numeric[name] += value
        for name, value in e['unknown_cost'].items():
            require(isinstance(value, str) and value.startswith('UNKNOWN') and unknown.get(name, value) == value, 'Unknown cost was changed/zeroed')
            unknown[name] = value
        if kind == 'case_entered':
            seed = e['seed']; require(type(seed) is int and 0 <= seed < 500 and seed not in committed, 'Duplicate/unregistered case')
            require(not committed or seed > max(committed), 'Non-source-order entry')
            evidence.root(e)
            committed[seed] = dict(NET=e['root'], Q=e['initial_Q'], vm=e['initial_vm'])
        elif kind == 'math_import':
            require(key not in math and key not in attempts, 'Duplicate historical math import')
            math[key] = evidence.historical(e)
        elif kind == 'math_attempt':
            require(key not in math and key not in attempts and e['seed'] in committed
                and e['step'] == steps[e['seed']]+1 and e['seed'] not in terminals,
                'Duplicate/unowned numerical attempt')
            require(key in reservations, 'Numerical attempt without frozen preservation reservation')
            require(e['numeric_cost'] == {'new_numerical_proposals_attempted': 1}, 'Attempt cost mismatch')
            attempts[key] = e
            attempt_states[key] = dict(committed[e['seed']])
        elif kind in ('math_return', 'math_failure'):
            require(key in attempts and key not in new_refs and key not in math, 'Unpaired/duplicate numerical terminal')
            if e.get('numerical_receipt_ref') is None:
                require(kind == 'math_failure' and e['status'] == 'FAILED_OR_UNCLOSED_NO_RETRY'
                    and e['numeric_cost'] == {} and e['unknown_cost'] == {'numerical.unclosed_attempt_costs':
                    'UNKNOWN: bank raised before closed receipt; global claim retained, no retry'}, 'Unclosed entry relabeled as a complete receipt')
                evidence.unclosed(e, attempts[key]); new_refs[key] = None; continue
            entry = evidence.new_math(e, attempts[key], committed[attempts[key]['seed']])
            new_refs[key] = e.get('numerical_receipt_ref')
            expected_numeric, expected_unknown = mathematical_costs(entry['proposal'], entry['primary'], entry.get('journal_raw',b''))
            require(e['numeric_cost'] == expected_numeric and e['unknown_cost'] == expected_unknown, 'New numerical costs differ from saved primary')
            require(e['independent_verification'] == 'PENDING_FIRST_READER', 'Primary claimed its own independent PASS')
            if entry['audit']['eligible_for_numeric_reuse']:
                require(kind == 'math_return', 'Admitted return mislabeled as failure'); math[key] = entry
            else:
                require(kind == 'math_failure', 'Failed/partial result admitted to cache')
        elif kind == 'math_reuse':
            require(key in math and e['proposal_ref'] == math[key]['proposal_ref']
                and e['numeric_cost'] == {'complete_proposal_reuses': 1}, 'Unreturned or substituted numerical reuse')
            if key in new_refs:
                require(e.get('numerical_receipt_ref') == new_refs[key]
                    and e.get('independent_verification') == 'PENDING_FIRST_READER', 'Pending owner reuse lost receipt/status')
        elif kind == 'physics_paid_return':
            require(key in math and e['proposal_ref'] == math[key]['proposal_ref']
                and e['lookup_status'] == 'VERIFIED_EXACT_PAID_REUSE'
                and e['numeric_cost'] == {'paid_physics_reuses': 1}, 'Unadmitted physics/math join')
            evidence.physical(e, math[key]); paid[e['seq']] = e
        elif kind == 'decision':
            seed, step = e['seed'], e['step']
            require(seed in committed and seed not in terminals and seed not in rejected
                and step == steps[seed]+1 and 1 <= step <= 100, 'Decision continuation/order invalid')
            before = committed[seed]; p = paid[e['physical_event']]
            require(e['before_NET'] == before['NET'] and same(e['before_Q'], before['Q'])
                and same(e['before_vm'], before['vm']), 'Committed state substituted')
            require(p['seed'] == seed and p['step'] == step and p['context_key'] == key
                and e['math_ref'] == p['proposal_ref'] == math[key]['proposal_ref']
                and e['candidate_receipt_ref'] == p['receipt_ref'], 'Decision cross-context receipt')
            require(e['candidate_NET'] == p['after_NET'] and e['candidate_signature'] == p['candidate_signature']
                and same(e['candidate_Q'], p['candidate_Q']) and same(e['candidate_vm'], p['candidate_vm'])
                and e['proposal'] == p['proposal'], 'Candidate evidence substituted')
            u = np.asarray(e['native_u'], dtype=np.float32)
            require(u.shape == (3,) and np.isfinite(u).all() and np.all(np.abs(u) <= np.float32(.3))
                and base64.b64encode(u.tobytes()).decode() == e['native_u_float32_bytes']
                and same(u, math[key]['proposal']['u']), 'Native action bits/proposal mismatch')
            q = np.asarray(before['Q'])-u
            require(same(q, e['candidate_Q']) and same(q, math[key]['proposal']['next_q']), 'Native candidate Q mismatch')
            accepted = actual_guard(before['vm'], e['candidate_vm'])
            require(type(e['accepted']) is bool and e['accepted'] == accepted, 'Original guard changed')
            final = dict(NET=e['candidate_NET'] if accepted else before['NET'],
                Q=e['candidate_Q'] if accepted else before['Q'], vm=e['candidate_vm'] if accepted else before['vm'])
            require(e['committed_NET'] == final['NET'] and same(e['committed_Q'], final['Q'])
                and same(e['committed_vm'], final['vm']), 'Guarded commit differs')
            require(e['numeric_cost'] == {'control_decisions':1,'accepted_commits':int(accepted),'rejected_candidates':int(not accepted)}, 'Decision costs changed')
            evidence.transition(e, before)
            committed[seed] = final; steps[seed] = step
            if not accepted: rejected.add(seed)
        elif kind == 'episode_terminal':
            seed = e['seed']; require(seed in committed and seed not in terminals, 'Duplicate/unentered terminal')
            c = committed[seed]
            require(e['final_NET'] == c['NET'] and same(e['final_Q'], c['Q']) and same(e['final_vm'], c['vm'])
                and e['steps'] == steps[seed], 'Terminal does not preserve authoritative state')
            m = metrics(c['vm']); status = e['status']
            if status == 'COMPLETE_STRICT_BAND': require(m['strict_fullband'], 'False strict-band completion')
            elif status == 'COMPLETE_ORIGINAL100_HORIZON': require(steps[seed] == 100, 'False horizon completion')
            elif status == 'COMPLETE_GUARD_HOLD_STOP': require(seed in rejected, 'False guard stop')
            else: require(status.startswith('UNKNOWN'), 'Unrecognized terminal')
            terminals[seed] = e
        elif kind == 'paid_cost_lineage':
            identity = e['identity']; require(identity not in lineage or lineage[identity] == e['evidence'], 'Changed historical cost lineage')
            evidence.lineage(e['evidence']); lineage[identity] = e['evidence']
        elif kind in ('preservation_budget_reserved','preservation_budget_checked','preservation_step_budget_checked'):
            if kind == 'preservation_budget_reserved':
                require(key not in reservations and key not in attempts, 'Duplicate/late preservation reservation')
                reservations.add(key)
            elif kind == 'preservation_budget_checked': require(key in attempts, 'Budget check without an entered proposal')
            else: require(e['seed'] in committed and e['step'] == steps[e['seed']]+1, 'Budget scan outside current step')
            evidence.budget(e)
        else:
            require(kind in allowed_other, 'Unknown policy event: '+kind)
    require(dict(numeric) == result['numeric_costs'] and unknown == result['unknown_costs']
        and lineage == result['retained_paid_costs_by_receipt'], 'Result cost totals/lineage differ')
    rows = result['cases']; require([r['seed'] for r in rows] == list(range(500)), 'Missing/reordered all500 roster')
    unknown_cases = []; band = 0
    for row in rows:
        seed = row['seed']; require(row['new_physical_calls'] == 0, 'Acquisition claimed new physics')
        if seed not in committed:
            require(row['status'].startswith('UNKNOWN') and row['steps'] == 0
                and not row.get('entered', False), 'Unentered case credited')
            if 'final_NET' in row: evidence.unentered(row)
        else:
            c = committed[seed]
            require(row['final_NET'] == c['NET'] and same(row['final_Q'], c['Q']) and same(row['final_vm'], c['vm'])
                and row['steps'] == steps[seed] and row['endpoint'] == metrics(c['vm']), 'Final result state/metric differs')
            if seed in terminals:
                require(row['status'] == terminals[seed]['status'] or row['status'].startswith('UNKNOWN_TERMINAL_'), 'Result/terminal status differs')
            else: require(row['status'].startswith('UNKNOWN'), 'Missing terminal credited complete')
        if row['status'].startswith('UNKNOWN'): unknown_cases.append(seed)
        elif row['status'] == 'COMPLETE_STRICT_BAND': band += 1
    declared = result['unique_new_numerical_receipt_refs']
    outstanding = result.get('outstanding_cost_receipts', {})
    recovered_numeric = Counter(); recovered_unknown = {}; recovered = {}
    for key, item in outstanding.items():
        require(key in attempts and key not in new_refs and key not in math
            and item['context_key'] == key and item['seed'] == attempts[key]['seed']
            and item['step'] == attempts[key]['step']
            and item['status'] in ('UNJOURNALED_AFTER_DEADLINE_OR_PRESERVATION_FAILURE','UNJOURNALED_UNVALIDATED_RECEIPT')
            and result['cost_accounting_complete'] is False, 'Unadmitted outstanding receipt')
        require(result['cases'][item['seed']]['status'].startswith('UNKNOWN'), 'Outstanding work credited complete')
        evidence_row = evidence.outstanding(item, attempts[key], attempt_states[key])
        n, u = mathematical_costs(evidence_row['proposal'], evidence_row['primary'], evidence_row.get('journal_raw', b''))
        if item['status'] == 'UNJOURNALED_AFTER_DEADLINE_OR_PRESERVATION_FAILURE':
            require(n == item['reported_numeric_cost'] and u == item['reported_unknown_cost'], 'Outstanding cost differs from actual saved return')
        else:
            require(item['reported_numeric_cost'] == {} and item['reported_unknown_cost']['new_receipt_costs'].startswith('UNKNOWN'), 'Unvalidated receipt fabricated primary costs')
        recovered_numeric.update(n)
        for name, value in u.items():
            require(recovered_unknown.get(name,value) == value, 'Conflicting outstanding unknown cost')
            recovered_unknown[name] = value
        recovered[key] = item['receipt_ref']
    require(declared == ({k:v for k,v in new_refs.items() if v is not None} | recovered), 'New receipt roster differs from events/retained mechanical closure')
    require(all(key in recovered and ref == recovered[key] for key,ref in mechanical_notices.items()), 'Mechanical notice references absent/changed receipt')
    pending = set(attempts)-{k for k,v in new_refs.items() if v is not None}
    declared_pending = result.get('outstanding_math_attempts', {})
    require(set(declared_pending) == pending, 'Unclosed attempt inventory differs from committed events')
    for key, item in declared_pending.items():
        a = attempts[key]
        require(all(item[n] == a[n] for n in ('context_key','seed','step','preproposal_checkpoint_ref'))
            and item['status'] == 'UNKNOWN_UNCLOSED_MATH_ATTEMPT_COSTS_NO_RETRY'
            and result['cost_accounting_complete'] is False, 'Unclosed numerical attempt was relabeled complete')
    require(result.get('stage','ACQUISITION_NOT_FULL_POLICY') == 'ACQUISITION_NOT_FULL_POLICY'
        and result['scope'] == 'NUMERICAL_ACQUISITION_OVER_EXACT_PAID_PHYSICS_NOT_FULL_POLICY_SCORE'
        and result['full_policy_score_available'] is False and result['new_PF_entry_enabled'] is False, 'Acquisition relabeled as a full policy study')
    return dict(status='PASS_VALID_PARTIAL_ACQUISITION_EVIDENCE' if unknown_cases else 'PASS_ACQUISITION_EVIDENCE_ONLY',
        roster_count=500, entered_cases=len(committed), terminal_cases=len(terminals), unknown_cases=unknown_cases,
        strict_band_complete_cases=band, unique_new_math_receipts=len(declared),
        unreturned_numerical_contexts=sorted(pending-set(recovered)), complete_policy_claim_permitted=False,
        outstanding_cost_receipts_verified_once=recovered, recovered_unjournaled_numeric_costs=dict(recovered_numeric),
        recovered_unjournaled_unknown_costs=recovered_unknown,
        new_physical_calls=0, mathematical_contexts_verified_once=True)


class SavedEvidence:
    def __init__(self, root, protocol, protocol_ref, deadline, max_bytes):
        self.root_path = Path(root).resolve(); self.protocol = protocol; self.protocol_ref = protocol_ref
        self.deadline = deadline; self.max_bytes = max_bytes; self.used = 0
        self.cache, self.networks, self.new_audits = {}, {}, {}
        self.costs = Counter(); self.roster = None
        self.paid_registry = None; self.paid_bindings = None

    def read(self, ref):
        require(time.monotonic() < self.deadline, 'Outer reader original deadline exhausted')
        path = (self.root_path/ref['path']).resolve(); path.relative_to(self.root_path)
        key = (str(path), ref['sha256'])
        if key not in self.cache:
            require(self.used+path.stat().st_size <= self.max_bytes, 'Outer reader byte cap exhausted')
            raw = path.read_bytes(); self.used += len(raw)
            require(digest(raw) == ref['sha256'], 'Changed saved evidence: '+ref['path'])
            # Bound memory independently of the larger total-read allowance.
            # Large receipt/journal bytes are processed, then released.
            if len(raw) <= 256*1024:
                if len(self.cache) >= 256: self.cache.pop(next(iter(self.cache)))
                self.cache[key] = raw
            return raw
        return self.cache[key]

    def json(self, ref): return json.loads(self.read(ref))

    def net(self, ref):
        key = (ref['path'], ref['sha256'])
        if key not in self.networks:
            require(ref.get('kind') in ('NET', 'ENV'), 'Unknown NET container')
            saved = DataUnpickler(io.BytesIO(self.read(ref))).load()
            net = saved['network'] if ref['kind'] == 'ENV' else saved
            require(bool(net['converged']) and bool(net['_ppc']['success']), 'Unsolved physical result')
            if len(self.networks) >= 32: self.networks.pop(next(iter(self.networks)))
            self.networks[key] = net; self.costs['saved_NET_deserializations'] += 1
        return self.networks[key]

    def root(self, event):
        if self.roster is None:
            self.roster = self.json(self.protocol['root_roster_ref'])
            require([r['seed'] for r in self.roster] == list(range(500)), 'Unpinned original population')
        require(event['root'] == self.roster[event['seed']]['root'], 'Original root substituted')
        net = self.net(event['root']); receipt = self.json(event['root_receipt_ref'])
        require(receipt['status'] == 'RETURNED' and receipt['new_physics'] is False
            and receipt['kwargs'] == {'algorithm':'bfsw'} and receipt['after'] == event['root']['path']
            and receipt['after_sha256'] == event['root']['sha256']
            and physical_signature(net) == receipt['physical_signature'] == event['root']['physical_signature'], 'Root receipt differs')
        require(same(net['sgen'].q_mvar.to_numpy()[:3], event['initial_Q'])
            and same(net['res_bus'].vm_pu.to_numpy(), event['initial_vm']), 'Root arrays changed')
        reuse = self.exact_paid(receipt['provenance']['lookup_ref'], event['root']['physical_signature'], {'algorithm':'bfsw'})
        actual = self.net(dict(reuse['after'],kind='NET'))
        require(same(actual['_ppc']['bus'], net['_ppc']['bus']) and same(actual['_ppc']['gen'], net['_ppc']['gen'])
            and same(actual['res_bus'].vm_pu.to_numpy(), net['res_bus'].vm_pu.to_numpy()), 'Root paid alias solution changed')
        self.lineage(receipt['provenance']['cost_lineage'])

    def unentered(self, row):
        if self.roster is None:
            self.roster = self.json(self.protocol['root_roster_ref'])
            require([r['seed'] for r in self.roster] == list(range(500)), 'Invalid original population')
        require(row['final_NET'] == self.roster[row['seed']]['root'], 'Unentered retained state is not its original root')
        net = self.net(row['final_NET'])
        require(same(row['final_Q'], net['sgen'].q_mvar.to_numpy()[:3])
            and same(row['final_vm'], net['res_bus'].vm_pu.to_numpy()), 'Unentered root state changed')

    def budget(self, event):
        name = 'reservation_ref' if event['kind'] == 'preservation_budget_reserved' else 'evidence_ref'
        require(event.get(name) is not None, 'Budget event lacks content-bound evidence')
        data = self.json(event[name])
        require(data['numeric_cost'] == event['numeric_cost'], 'Budget evidence/cost differs')
        if name == 'reservation_ref': require(data['context_key'] == event['context_key'], 'Budget reservation context differs')

    def historical(self, event):
        refs = self.protocol['first_paid_math']
        require(event['proposal_ref'] == refs['proposal'] and event['independent_reader_ref'] == refs['independent_reader'], 'Unpinned historical import')
        proposal, audit, oldp = self.json(refs['proposal']), self.json(refs['independent_reader']), self.json(refs['protocol'])
        require(proposal['status'] == 'ADMITTED_UNMEASURED_PROPOSAL'
            and audit['status'] == 'PASS_FIRST_SAVED_NUMERICAL_PROPOSAL_AND_COST_EVIDENCE' and oldp['recipe'] == RECIPE,
            'Historical proposal not independently admitted')
        for source, expected in oldp['sources_and_gates'].items():
            if source in self.protocol['sources']:
                require(self.protocol['sources'][source] == expected, 'Historical shared source/runtime changed')
        require(event['context_key'] == self.protocol['first_paid_math_context_key'], 'Historical exact context changed')
        if self.roster is None: self.roster = self.json(self.protocol['root_roster_ref'])
        require(oldp['input_pack'] == self.roster[0]['input_pack'] and oldp['input_root'] == self.roster[0]['root'], 'Historical initial root/pack changed')
        with np.load(io.BytesIO(self.read(oldp['input_pack'])), allow_pickle=False) as z:
            state = {name:z[name].copy() for name in CONTEXT_NAMES}
        state['lookup'] = state['lookup'].astype(int); state['control'] = state['control'].astype(int)
        def typed_array(a):
            return dict(type='array', dtype=a.dtype.str, shape=list(a.shape), bytes=base64.b64encode(a.tobytes()).decode())
        pq = np.flatnonzero(state['ppc_bus'][:,1] == 1); initial = np.zeros(31)
        initial[:12] = np.angle(state['V_current'][pq]); initial[12:24] = np.abs(state['V_current'][pq])
        initial[27:30] = np.abs(state['current_q'])
        initial[30] = max(0.,.95-float(state['current_vm'].min()),float(state['current_vm'].max())-1.05)
        payload = dict(state={n:typed_array(a) for n,a in state.items()}, initial_vector=typed_array(initial),
            recipe=RECIPE, mechanism_sources={p:self.protocol['sources'][p] for p in MECHANISM_SOURCES})
        require(digest(canonical(payload)) == event['context_key'], 'Historical typed initial context is not the paid identity')
        self.costs['historical_initialization_context_reconstructions'] += 1
        closed = self.json(refs['closed_manifest'])
        require({r['path']:r['sha256'] for r in closed['files']}['Proposal_Result.json'] == refs['proposal']['sha256'], 'Historical proposal not closed')
        return dict(proposal=proposal, proposal_ref=event['proposal_ref'], audit=audit)

    def unclosed(self, event, attempt):
        require(event['preproposal_checkpoint_ref'] == attempt['preproposal_checkpoint_ref'], 'Unclosed attempt cursor changed')
        if event.get('attempt_claim_ref') is not None:
            claim = self.json(event['attempt_claim_ref'])
            require(claim['context_key'] == event['context_key'] and claim['owner_protocol_ref'] == self.protocol_ref
                and claim['input_cursor'] == attempt['preproposal_checkpoint_ref'], 'Unclosed claim context changed')

    def new_math(self, event, attempt, state):
        key = event['context_key']; require(key not in self.new_audits, 'Numerical journal would be verified twice')
        require(event.get('preproposal_checkpoint_ref') == attempt['preproposal_checkpoint_ref'], 'New math cursor edge changed')
        receipt_ref = event['numerical_receipt_ref']; receipt = self.json(receipt_ref)
        binding = receipt['source_input_binding']
        require(binding['complete_preproposal_cursor_ref'] == attempt['preproposal_checkpoint_ref']
            and binding['seed'] == attempt['seed'] and binding['step'] == attempt['step']
            and binding['actual_current_NET'] == state['NET'] and receipt['owner_protocol_ref'] == self.protocol_ref,
            'New math current state/owner changed')
        require(receipt['primary'] == event['primary_ref'] and receipt['proposal'] == event.get('proposal_ref'), 'Numerical terminal references changed')
        with np.load(io.BytesIO(self.read(receipt['input_pack'])), allow_pickle=False) as z:
            pack = {n:z[n].copy() for n in z.files}
        current = self.net(state['NET'])
        require(same(pack['current_q'], current['sgen'].q_mvar.to_numpy()[:3])
            and same(pack['current_vm'], current['res_bus'].vm_pu.to_numpy())
            and same(pack['ppc_bus'], current['_ppc']['bus']) and same(pack['ppc_gen'], current['_ppc']['gen'])
            and float(pack['baseMVA']) == current['_ppc']['baseMVA'], 'New math pack differs from actual current NET/PPC')
        root_pack_ref = self.roster[attempt['seed']]['input_pack']
        with np.load(io.BytesIO(self.read(root_pack_ref)), allow_pickle=False) as z:
            for name in ('Y','lookup','control','control_scaling','control_in_service','enforce_q_lims','distributed_slack'):
                require(same(pack[name], z[name]), 'Static kernel context changed: '+name)
            if attempt['step'] == 1 and state['NET'] == self.roster[attempt['seed']]['root']:
                require(same(pack['V_current'], z['V_current']), 'Initial exact voltage representation changed')
            else:
                bus = current['_ppc']['bus']; v = bus[:,7]*np.exp(1j*np.deg2rad(bus[:,8]))
                require(same(pack['V_current'], v), 'Current complex voltage differs from PPC')
        primary = self.json(receipt['primary']); journal_raw = self.read(receipt['journal'])
        require(receipt['context_key'] == primary['context_key'] == key and receipt['sources'] == self.protocol['sources'], 'New receipt source/context changed')
        claim = self.json(receipt['attempt_claim'])
        require(claim['context_key'] == key and claim['owner_protocol_ref'] == self.protocol_ref
            and claim['input_cursor'] == attempt['preproposal_checkpoint_ref'], 'New attempt claim differs')
        broken_tail = primary.get('journal_committed_bytes',len(journal_raw)) != len(journal_raw)
        if broken_tail:
            require(event['kind'] == 'math_failure' and primary['failure'] is not None, 'Broken journal presented as admitted')
            audit = {'status':'UNKNOWN_RETAINED_UNCLOSED_JOURNAL_NOT_VERIFIED','eligible_for_numeric_reuse':False,
                'retry_permitted':False,'independent_costs':{},'evidence_bytes_read':0,
                'scope':'Actual complete byte payload preserved; acknowledged-prefix/tail inconsistency quarantined, no mathematical result admitted.'}
        else:
            audit = verify_receipt(self.root_path, receipt_ref, expected_context_key=key,
                expected_sources=self.protocol['sources'], absolute_deadline_monotonic=self.deadline,
                max_bytes=max(0,self.max_bytes-self.used))
            self.used += audit['evidence_bytes_read']; self.costs.update(audit['independent_costs'])
        self.new_audits[key] = audit
        proposal = None if receipt['proposal'] is None else self.json(receipt['proposal'])
        return dict(proposal=proposal, primary=primary, journal_raw=journal_raw, audit=audit, proposal_ref=receipt['proposal'])

    def outstanding(self, item, attempt, state):
        receipt = self.json(item['receipt_ref'])
        require('primary_ref' not in item or receipt['primary'] == item['primary_ref'], 'Outstanding primary reference changed')
        event = dict(kind='math_failure', context_key=item['context_key'], numerical_receipt_ref=item['receipt_ref'],
            primary_ref=receipt['primary'], proposal_ref=receipt['proposal'],
            preproposal_checkpoint_ref=item['preproposal_checkpoint_ref'])
        # Independently read its first-ever calculation transcript once, but
        # never admit the result into the reusable or physical decision cache.
        return self.new_math(event, attempt, state)

    def lineage(self, value):
        refs = value['references']
        for ref in (refs.values() if isinstance(refs,dict) else refs): self.read(ref)
        if 'originals' not in value:
            require(refs == self.protocol['first_paid_math'], 'Unpinned prior numerical costs')
            p, a = self.json(refs['proposal']), self.json(refs['independent_reader'])
            numeric, unknown = {}, {}
            for group in ('costs','kernel_costs'):
                for name, cost in p[group].items():
                    (numeric if type(cost) in (int,float) else unknown)[group+'.'+name] = cost
            numeric['independent_reader.workflow_seconds'] = a['workflow_seconds']
            require(value['numeric'] == numeric and value['unknown'] == unknown, 'Retained old numerical costs changed')
            return
        # Recompute only original receipt metadata timers. Never evaluate the
        # historical power flow or rerun its scientific validation.
        self.load_paid_catalogue()
        entry = self.paid_registry['entries'].get(value['identity'])
        require(value['manifest_ref'] == self.protocol['paid_registry_manifest'] and entry is not None
            and value['reuse'] == entry['reuse']
            and [o['registry_provenance'] for o in value['originals']] == entry['provenance'], 'Historical cost provenance differs from frozen paid registry')
        numeric = {}; seen = set()
        for original in value['originals']:
            item = original['registry_provenance']; source = original['source_ref']; raw = self.read(source)
            path = item.get('original_source') or item.get('source')
            require(source['path'] == path and source['sha256'] == self.paid_bindings[path]['sha256'], 'Historical timer source changed')
            row = None
            if 'original_pointer' in item:
                row = json.loads(raw)
                for token in item['original_pointer'].strip('/').split('/'):
                    token = token.replace('~1','/').replace('~0','~')
                    row = row[int(token)] if isinstance(row,list) else row[token]
                require(original['original_receipt'] == row and row['status'] == 'RETURNED', 'Original returned receipt changed')
            elif 'line' in item:
                records = [json.loads(line) for line in raw.splitlines() if line.strip()]
                attempted = records[item['line']-1]
                require(original['original_attempt_event'] == attempted and attempted['sha256'] == item['event_sha256'], 'Original physical attempt changed')
                e = attempted['event']
                found = [r for r in records[item['line']:] if r['event'].get('kind') == 'PF_return'
                    and all(r['event'].get(k) == e.get(k) for k in ('number','label','kwargs','physical_input_sha256'))]
                require(len(found) <= 1, 'Ambiguous physical return')
                if found:
                    require(original['original_return_event'] == found[0], 'Original physical return changed'); row = found[0]['event']
                else:
                    require('original_return_event' not in original and 'original_primary_return_seconds' in value['unknown'], 'Missing primary return hidden')
            elif 'audited_historical_entry' in original:
                indexed = json.loads(raw)['returned_exact_initializer_entries'][item['mapping_key']]
                require(indexed == original['audited_historical_entry'], 'Original audited index changed')
            if row is not None and 'seconds' in row:
                identity = path+'|'+str(item.get('original_pointer',item.get('line')))
                if identity not in seen:
                    require(type(row['seconds']) in (int,float) and np.isfinite(row['seconds']) and row['seconds'] >= 0, 'Invalid old primary timer')
                    numeric[identity+'.seconds'] = row['seconds']; seen.add(identity)
        require(value['numeric'] == numeric and 'full_historical_physical_setup_and_reader_costs' in value['unknown'], 'Historical physical costs changed/unknown scope omitted')

    def physical(self, event, math):
        receipt = self.json(event['receipt_ref']); net = self.net(event['after_NET'])
        require(receipt['status'] == 'RETURNED' and receipt['new_physics'] is False
            and receipt['kwargs'] == {'algorithm':'bfsw','init':'dc'}
            and receipt['after'] == event['after_NET']['path'] and receipt['after_sha256'] == event['after_NET']['sha256']
            and receipt['context_key'] == event['context_key'] and receipt['proposal_ref'] == event['proposal_ref']
            and receipt['physical_signature'] == event['candidate_signature'] == physical_signature(net), 'Physical receipt identity changed')
        require(same(event['candidate_Q'], net['sgen'].q_mvar.to_numpy()[:3])
            and same(event['candidate_vm'], net['res_bus'].vm_pu.to_numpy())
            and same(event['proposal']['u'], math['proposal']['u'])
            and same(event['proposal']['next_q'], math['proposal']['next_q']), 'Physical arrays/proposal changed')
        reuse = self.exact_paid(receipt['provenance']['lookup_ref'], event['candidate_signature'], {'algorithm':'bfsw','init':'dc'})
        require(reuse == receipt['provenance']['reuse'], 'Exact paid lookup changed')
        require(event['after_NET']['path'] == reuse['after']['path']
            and event['after_NET']['sha256'] == reuse['after']['sha256'], 'Selected paid after-NET differs from committed candidate')
        self.lineage(receipt['provenance']['cost_lineage'])

    def load_paid_catalogue(self):
        manifest_ref = self.protocol['paid_registry_manifest']
        if self.paid_registry is None:
            manifest = self.json(manifest_ref); directory = Path(manifest_ref['path']).parent
            self.paid_registry = self.json({'path':(directory/'Paid_Physical_Registry.json').as_posix(), 'sha256':manifest['Paid_Physical_Registry.json']['sha256']})
            self.paid_bindings = self.json({'path':(directory/'Source_Bindings.json').as_posix(), 'sha256':manifest['Source_Bindings.json']['sha256']})

    def exact_paid(self, lookup_ref, signature, kwargs):
        manifest_ref = self.protocol['paid_registry_manifest']; self.load_paid_catalogue()
        lookup = self.json(lookup_ref); key = signature+'|'+json.dumps(kwargs,sort_keys=True)
        entry = self.paid_registry['entries'].get(key)
        require(entry is not None and entry['status'] == 'REUSABLE_AUDITED_EXACT_KEY' and entry['reuse'] is not None
            and lookup['status'] == 'VERIFIED_EXACT_PAID_REUSE' and lookup['key'] == key
            and lookup['reuse'] == entry['reuse'] and lookup['new_PF_permitted'] is False
            and lookup['source_manifest_sha256'] == manifest_ref['sha256'], 'Physical lookup lacks exact frozen registry membership')
        reuse = lookup['reuse']
        for name in ('after','fields'): self.read(reuse[name])
        certpath = reuse['independent_certificate']; cert = self.json({'path':certpath,'sha256':self.paid_bindings[certpath]['sha256']})
        require(cert['status'].startswith('PASS'), 'Paid physics certificate is not PASS')
        return reuse

    def transition(self, event, before):
        a, b = self.net(before['NET']), self.net(event['candidate_NET'])
        import pandas as pd
        def names(net): return {k for k,v in net.items() if isinstance(v,pd.DataFrame) and not k.startswith(('res_','_'))}
        require(names(a) == names(b), 'Physical table set changed')
        for name in names(a):
            candidate = a[name]
            if name == 'sgen':
                candidate = candidate.copy(deep=True); candidate.loc[candidate.index[:3],'q_mvar'] = event['candidate_Q']
            require(candidate.equals(b[name]), 'Noncontrolled physical table changed: '+name)


def verify_acquisition(root, refs, *, expected_protocol_ref, absolute_deadline_monotonic, max_bytes=1024*1024*1024):
    """Verify a saved, ended acquisition. No actual execution is authorized."""
    require(np.isfinite(absolute_deadline_monotonic) and time.monotonic() < absolute_deadline_monotonic, 'Invalid reader allowance')
    require(type(max_bytes) is int and max_bytes > 0, 'Invalid fixed reader byte allowance')
    require(refs['protocol'] == expected_protocol_ref, 'Wrong caller protocol pin')
    placeholder = SavedEvidence(root, {}, expected_protocol_ref, absolute_deadline_monotonic, max_bytes)
    protocol = placeholder.json(refs['protocol']); placeholder.protocol = protocol; ev = placeholder
    require(protocol['cases'] == list(range(500)) and protocol['horizon'] == 100 and protocol['recipe'] == RECIPE
        and protocol['new_PF_entry_enabled'] is False, 'Changed population/recipe/physical permission')
    for path, sha in protocol['sources'].items(): ev.read({'path':path,'sha256':sha})
    ack, end = ev.json(refs['owner_ack']), ev.json(refs['owner_end'])
    require(ack['protocol_sha256'] == expected_protocol_ref['sha256'] and ack['fresh_exact_source_PID_parent_command'] is True
        and end['actual_owned_chain_ended'] is True and end['actual_pid'] == ack['actual_pid'], 'Unclosed/unowned primary evidence')
    result = ev.json(refs['result']); journal = ev.read(refs['journal']); closed = ev.json(refs['closed_manifest'])
    manifest_directory = Path(refs['closed_manifest']['path']).parent
    manifest_files = {r['path']:r for r in closed['files']}
    for name in ('result','journal'):
        rel = Path(refs[name]['path']).relative_to(manifest_directory).as_posix()
        require(manifest_files[rel]['sha256'] == refs[name]['sha256'], 'Primary journal/result not closed')
    events = parse_journal(journal, result); answer = audit_events(events, result, ev)
    answer.update(protocol_ref=expected_protocol_ref, primary_result_ref=refs['result'],
        independent_costs=dict(ev.costs), evidence_bytes_read=ev.used,
        unique_new_math_audits=ev.new_audits, actual_new_optimizer_PF_model_calls=0,
        historical_calculation_journal_reads=0,
        limits='Source/owner/reference and saved-outcome evidence only. Acquisition cannot be relabeled as a full policy score; no new physics or retry is authorized.')
    return answer
