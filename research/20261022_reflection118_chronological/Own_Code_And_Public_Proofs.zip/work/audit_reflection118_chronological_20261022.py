"""Sole first replay and causal source reader, complete or preserved partial.

New returned PF inputs get exactly one charged independent solve. Old returns,
failed attempts and model generations are never executed again by this reader.
"""
import copy, hashlib, json, os, pickle, random, sys, time, traceback
from reflection118_chronological_core_20261022 import *
P=R/'outputs/reflection118_chronological_preparation_20261022'
E=R/'outputs/r118chrono_20261022'
O=R/'outputs/r118chrono_audit_20261022'


def chain(path):
    previous='0'*64;rows=[]
    for raw in path.open('rb'):
        e=json.loads(raw);assert e['event']['previous']==previous
        previous=hashlib.sha256(canonical(e['event'])).hexdigest();assert previous==e['sha256'];rows.append(e['event'])
    return rows


def main():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np, pandas as pd, pandapower as pp
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    from frozen_physics_loader import load_stack,AUDIT
    from transformers import AutoTokenizer
    O.mkdir(exist_ok=False);began=time.monotonic()
    put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    p=read(P/'Frozen_Engineering_Protocol.json');assert sha(__file__)==read(P/'Independent_Reader_Lock.json')['sha256']
    host=read(E/'status.json');assert host['runtime_released'] and host['scientific_process_ended'] and host['all_actual_closed_artifacts_preserved']
    end=read(R/'outputs/r118chrono_coordination_20261022/End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    for n,h in read(P/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha(R/n)==h
    C=E/'local_controller';assert (C/'Local_Controller_Ended.json').exists()
    for n,h in read(C/'Closed_Manifest.json')['members'].items():assert sha(C/n)==h
    S=E/'staged/study';desc=read(E/'remote_closed_descriptor.json')
    for n,rec in desc['members'].items():assert (S/n).stat().st_size==rec['bytes'] and sha(S/n)==rec['sha256']
    model_events=chain(S/'events.jsonl');local_events=chain(C/'events.jsonl')
    tok=AutoTokenizer.from_pretrained(str(R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'),local_files_only=True,trust_remote_code=False)
    replies=sorted(S.glob('response_*.json'))
    for i,path in enumerate(replies):
        ans=read(path);assert ans['number']==i and ans['request']==read(C/'requests'/f'request_{i:05d}.json')
        encoded=tok.apply_chat_template(ans['request']['messages'],tokenize=True,add_generation_prompt=True)
        ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
        assert ids==ans['input_token_ids'] and len(ids)+384<=4096
        assert tok.decode(ans['output_token_ids'],skip_special_tokens=True).strip()==ans['raw_text']
        assert len(ans['output_token_ids'])==ans['actual_forward_returns']
        assert read(C/'responses'/path.name)==ans
    for label in ['primary','cold_serving']:
        if (S/f'{label}_Immutable_After.json').exists():assert read(S/f'{label}_Immutable_Before.json')==read(S/f'{label}_Immutable_After.json')
        if (S/f'{label}_Actual_Enabled_Adapter_State.json').exists():
            flags=read(S/f'{label}_Actual_Enabled_Adapter_State.json');assert flags and not any(flags.values())
    if replies:
        a=read(S/'First_Primary_Generation.json');b=read(S/'First_Cold_Generation.json')
        assert a['input_token_ids']==b['input_token_ids'] and a['output_token_ids']==b['output_token_ids']
    native=pp.runpp;new_replays=0;maximum=0.;maximum_kcl=0.;branch_results=[]
    v2,runner,reflection=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    try:
        for row in roots:
            for arm in ['reflection_v2','no_llm_fallback_first']:
                d=C/row['case_id']/arm
                if not d.exists():continue
                for recpath in sorted(d.glob('pf_*.json')):
                    assert time.monotonic()-began<p['reader_seconds']
                    rec=read(recpath);before=decode(d,rec['before']);after=decode(d,rec['after']);frames_equal(before,after)
                    if rec['provenance']['kind']!='NEW_PRIMARY_RETURN':continue
                    # A fixed first replay of this newly returned identity only.
                    intent=copy.deepcopy(before);tick=time.perf_counter();native(intent,**rec['kwargs']);new_replays+=1
                    frames_equal(intent,after);assert intent.converged and after.converged
                    diffs={}
                    for table in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
                        a=intent[table].select_dtypes(include=[np.number]).to_numpy(float)
                        b=after[table].select_dtypes(include=[np.number]).to_numpy(float)
                        assert a.shape==b.shape and np.array_equal(np.isnan(a),np.isnan(b))
                        assert np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True),table
                        mask=np.isfinite(a)&np.isfinite(b);delta=float(np.max(np.abs(a[mask]-b[mask]),initial=0.))
                        diffs[table]=delta;maximum=max(maximum,delta)
                    q=intent._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0]
                    V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]))
                    kcl=float(np.max(np.abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
                    maximum_kcl=max(maximum_kcl,kcl)
                    put(O/f'replay_{new_replays:06d}.json',{'primary_record':recpath.relative_to(C).as_posix(),
                        'seconds':time.perf_counter()-tick,'maximum_all_numeric_table_deltas':diffs,'KCL_pu':kcl})
                if not (d/'Result.json').exists():continue
                calls=read(d/'Call_Order.json');pi=gi=0
                def model(messages):
                    nonlocal gi
                    rec=calls['generations'][gi];gi+=1;assert rec['messages']==messages
                    assert read(S/f'response_{rec["request"]:05d}.json')['raw_text']==rec['text'];return rec['text']
                def physics(net,**kw):
                    nonlocal pi
                    rec=calls['PF'][pi];pi+=1;assert kw==rec['kwargs'];frames_equal(net,decode(d,rec['before']));restore_exact(net,decode(d,rec['after']))
                random.seed(p['seed']);np.random.seed(p['seed'])
                result,_=controller(v2,runner,reflection,read(R/row['registration']['recipe']),base,zones,model,physics,arm)
                assert result==read(d/'Result.json') and pi==len(calls['PF']) and gi==len(calls['generations'])
                assert read(d/'Cold_Continuation_Gate.json')['status'].startswith('PASS_')
                summary=reflection.summarize_result(result);summary['strict_OV']=result['final_metrics']['ov_count'];branch_results.append(summary)
        complete=len(branch_results)==8 and (C/'Results.json').exists()
        pairs=[];gate='UNKNOWN_PARTIAL'
        if complete:
            for r in roots:
                llm=next(s for s in branch_results if s['scenario_id']==r['case_id'] and s['method']=='reflection_v2')
                num=next(s for s in branch_results if s['scenario_id']==r['case_id'] and s['method']=='no_llm_fallback_first')
                pairs.append({'case_id':r['case_id'],'DFF_UV':num['final_uv'],'HG_VF_UV':llm['final_uv'],
                    'DFF_OV':num['strict_OV'],'HG_VF_OV':llm['strict_OV'],
                    'unchanged_HGSE_selector_choice':reflection.choose_safety_envelope(num,llm)})
            survived=sum(x['HG_VF_UV']<x['DFF_UV'] for x in pairs)>=2 and all(x['HG_VF_UV']<=x['DFF_UV'] and x['HG_VF_OV']<=x['DFF_OV'] for x in pairs)
            gate='PASS_LIMITED_DEVELOPMENT_NATIVE_INTERVENTION' if survived else 'FAIL_STOP_FIXED_INTERVENTION_NO_OUTCOME_RETUNE'
        result={'status':'PASS_COMPLETE_FOUR_NATIVE_BRANCH_PAIRS' if complete else 'PASS_PRESERVED_PARTIAL_FULL_COMPARISON_UNKNOWN',
            'complete_branches':branch_results,'all4_complete':complete,'missing_branches':8-len(branch_results),
            'new_independent_PF_replays':new_replays,'maximum_numeric_field_delta':maximum,'maximum_KCL_pu':maximum_kcl,
            'all_causal_original_policy_outputs_exact':True,'actual_model_responses_verified':len(replies),
            'paired_all4_native_rows':pairs,'fixed_development_gate':gate,
            'new_model_optimizer_training_calls':0,'native_guard':'Original1.06; strict1.05 OV separately retained.',
            'external_methods_and_full_DSE_and_unused_confirmation':'NOT_ESTABLISHED_BY_THIS_NATIVE_SYSTEM_STUDY',
            'workflow_seconds':time.monotonic()-began}
        put(O/'Independent_Audit.json',result);print(json.dumps(result))
    except BaseException as e:
        put(O/'Failure.json',{'type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),
            'already_executed_independent_PF_replays':new_replays,'workflow_seconds':time.monotonic()-began});raise
    finally:put(O/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in O.iterdir() if x.is_file()}})


if __name__=='__main__':main()
