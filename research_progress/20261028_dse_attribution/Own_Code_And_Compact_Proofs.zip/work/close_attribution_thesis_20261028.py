"""Close the reviewed document and update checklist from verified evidence only."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,re,zipfile,hashlib,html,os
from docx import Document
from pypdf import PdfReader
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_attribution_and_comparators_20261028'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def media(p):
 with zipfile.ZipFile(p) as z:return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/'))
def main():
 qa=O/'Final_Visual_And_Evidence_QA.json';assert not qa.exists()
 base=R/'outputs/thesis_integrated_evidence_20261028/Hannaan_Thesis_Integrated_Evidence.docx';p=O/'Hannaan_Thesis_Attribution_And_Comparators.docx';d=Document(p);old=Document(base)
 assert sh(base)==rd('outputs/thesis_integrated_evidence_20261028/Final_Visual_And_Evidence_QA.json')['docx_sha256']
 oldtables=[[[c.text for c in r.cells] for r in t.rows] for t in old.tables];newtables=[[[c.text for c in r.cells] for r in t.rows] for t in d.tables]
 assert len(oldtables)==12 and len(newtables)==15 and all(x in newtables for x in oldtables)
 assert media(base)==media(p) and sum(media(p).values())==22
 ref=[x.text for x in d.paragraphs if re.match(r'^\[\d+\]',x.text)];assert len(ref)==35
 assert ref[:30]==[x.text for x in old.paragraphs if re.match(r'^\[\d+\]',x.text)]
 attr=next(t for t in newtables if t[0]==['Stage or event','Count','Denominator'])
 assert [int(row[1]) for row in attr[1:]]==[308,151,458,413,37,192,68,51,9,13,9]
 graph=next(t for t in newtables if t[0]==['Root','Initial UV','Operations','Terminal result']);assert [int(x[2]) for x in graph[1:]]==[19,21,21,21]
 assert all('unknown' in row[3] for row in graph[1:])
 pdf=PdfReader(O/'Integrated_Thesis_QA.pdf');pagination=rd('outputs/thesis_attribution_and_comparators_20261028/Pagination_Record.json');assert len(pdf.pages)==113==pagination['pages'] and pagination['list_entries']==50
 norm=lambda s:re.sub(r'\s+','',s).lower()
 for entry in pagination['map']:assert norm(entry['label']) in norm(pdf.pages[entry['physical_page']-1].extract_text() or ''),entry
 sparse={i+1 for i,x in enumerate(pdf.pages) if i>=8 and len((x.extract_text() or '').split())<=20}
 assert sparse=={45,46,47},sparse
 for n,caption in [(45,'Figure 4.4'),(46,'Figure 4.5'),(47,'Figure 4.6')]:assert caption in (pdf.pages[n-1].extract_text() or '')
 now=datetime.now(timezone.utc).isoformat()
 record={'at_utc':now,'status':'PASS_WORKING_DRAFT_LAYOUT_AND_LISTED_EVIDENCE_CHECKS','docx_sha256':sh(p),'pdf_sha256':sh(O/'Integrated_Thesis_QA.pdf'),'pages':113,'tables':15,'figures':22,'references':35,'page_bound_index_entries':50,'original109_unchanged':True,'all_original12_table_values_unchanged':True,'all22_used_media_bytes_unchanged':True,'new_scientific_calls':0,'visual_review':{'initial115_pages_all_contact_review':True,'initial_full_size_changed_pages':[30,31,72,73,74,90,91],'final_full_size_review':[5,6,7,31,73,74,91,113],'intermediate_reference_and_orphan_reviews':[92,113,114],'repairs':'Three new tables left aligned; bibliographic records kept together; one-word Graph ending page removed by concise same-evidence paragraph. Final113 pages retain unchanged content/figures with repagination.','renderer':'Canonical render_docx failed because soffice.exe absent; hidden Word PDF export and bundled Poppler fallback, logs retained.'},'limitations':['Working thesis, not final university submission','All6research goals remain open','Focused five recent records, not all published models','Raw counts and prompt mismatch are descriptive, not proof of physical improvement','External Graph has different actions and budgets; failed final endpoints unknown']}
 put(qa,record)
 # Full source export in document order, so no later prose repair is lost.
 chunks=[]
 for e in d.element.body:
  if e.tag.endswith('}p'):
   from docx.text.paragraph import Paragraph
   q=Paragraph(e,d);chunks.append(('## ' if q.style.name.startswith('Heading') else '')+q.text)
  elif e.tag.endswith('}tbl'):
   from docx.table import Table
   t=Table(e,d);rows=[[c.text.replace('\n',' / ') for c in x.cells] for x in t.rows]
   chunks.append('\n'.join(['| '+' | '.join(rows[0])+' |','| '+' | '.join(['---']*len(rows[0]))+' |']+['| '+' | '.join(x)+' |' for x in rows[1:]]))
 (O/'Thesis_Text_And_Tables.md').write_text('\n\n'.join(chunks)+'\n',encoding='utf-8')
 index=rd('outputs/thesis_integrated_evidence_20261028/Thesis_Evidence_Navigation.json');index.update(at_utc=now,qa_record=qa.relative_to(R).as_posix(),current_docx=p.relative_to(R).as_posix(),pages=113)
 paths=[('2.2','FOCUSED_PRIMARY_SOURCE_REVIEW',['outputs/closest_llm_control_review_20261028/Review_And_Admission.md','outputs/closest_llm_control_review_20261028/Pinned_Repository_Metadata.json'],'Five recent records; no unavailable method counted beaten.'),('6.3','INDEPENDENT_SAVED_ALL4_ACTION_ATTRIBUTION',['outputs/original118_raw_action_attribution_v2_20261028/Results.json','outputs/original118_raw_action_attribution_v2_20261028/independent/Independent_Audit.json','outputs/original_prompt_candidate_diagnosis_20261028/independent/Independent_Audit.json'],'Four inspected development roots; repaired and numerical-origin actions separate, no causal effect.'),('7.8','INDEPENDENT_CLOSED_NATIVE_EXTERNAL_EPISODES',['outputs/graph118_native_comparison_completion_20261028/Verified_Completion.json','outputs/graph118_native_context_comparison_rng_v2_20261028/Comparison.json'],'Different actuator and budget; all four failed final solves remain unknown endpoints.')]
 for number,status,sources,limit in paths:
  caption=next(q.text for q in d.paragraphs if q.style.name=='Caption' and q.text.startswith('Table '+number+' '))
  index['tables'].append({'table':number,'caption':caption,'status':status,'records':[{'path':s,'sha256':sh(R/s)} for s in sources],'limitation':limit})
 put(O/'Thesis_Evidence_Navigation.json',index)
 parts=['<!doctype html><meta charset="utf-8"><title>Thesis evidence index</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.5 system-ui;color:#18232c}section{border-top:1px solid #ccd5de;padding:15px 0}small{overflow-wrap:anywhere}</style><h1>Thesis evidence index</h1><p>113-page reviewed working draft · 15 tables · 22 figures · 35 references</p>']
 def link(s,label):return '<a href="'+html.escape(os.path.relpath(R/s,O).replace('\\','/'),quote=True)+'">'+html.escape(label)+'</a>'
 parts.append('<p>'+link(p.relative_to(R).as_posix(),'Current Word draft')+' · '+link(qa.relative_to(R).as_posix(),'Document QA')+'</p>')
 for t in sorted(index['tables'],key=lambda t:tuple(int(x) for x in t['table'].split('.'))):
  parts.append('<section><h2>'+html.escape(t['caption'])+'</h2><p>'+html.escape(t['limitation'])+'</p><ul>')
  for x in t['records']:parts.append('<li>'+link(x['path'],x['path'])+'</li>')
  parts.append('</ul></section>')
 parts.append('<p>'+link('outputs/thesis_integrated_evidence_20261028/Evidence_Index.html','Original figure source navigation')+'</p>')
 (O/'Evidence_Index.html').write_text('\n'.join(parts),encoding='utf-8')
 for name in ['Integration_Record.json','Layout_Repair_Record.json']:
  x=rd('outputs/thesis_attribution_and_comparators_20261028/'+name);x.update(status='COMPLETE_WORKING_DRAFT_VISUALLY_VERIFIED',pages=113,qa=qa.relative_to(R).as_posix());put(O/name,x)
 tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json')
 for x in tasks['tasks']:
  if x['id'] in ['T15','T25','T31']:
   x.update(status='COMPLETE_DOCUMENTATION_REQUIREMENT_IN_REVIEWED_WORKING_THESIS',completed_utc=now,limitation='Scoped documentation requirement complete; all six research goals and causal/general superiority remain open.')
   x['evidence']+=['outputs/thesis_attribution_and_comparators_20261028/Final_Visual_And_Evidence_QA.json']
 tasks['updated_utc']=now;tasks['completed_requirement_count']=sum(x['status'].startswith('COMPLETE') for x in tasks['tasks']);assert tasks['completed_requirement_count']==11;put(R/'outputs/thesis_research_closure_20261028/Tasks.json',tasks)
 resume=rd('outputs/research_resumption_20261028/Current_Resume.json');resume.update(at_utc=now,thesis_integration=qa.relative_to(R).as_posix(),thesis_evidence_index='outputs/thesis_attribution_and_comparators_20261028/Evidence_Index.html',thesis_closed_requirements=11,thesis_revision_pending=None,raw_prompt_example_diagnosis='outputs/original_prompt_candidate_diagnosis_20261028/independent/Independent_Audit.json',actual_saved_context_bounds='outputs/original_saved_context_bounds_20261028/Actual_Saved_Context_Bounds.json');resume['next']=['Publish compact new attribution/prompt/thesis proofs with fresh lease and downloaded-byte checks.','Admit the unchanged literal numerical D-SE reference on all4severe roots through saved exact source/history/state/cost gates, without repeating old PF or modifying comparator.','Further external trained118/publicQA benchmarks require actual compatible interfaces and resources; no idleGPU.','A candidate-example contradiction is diagnosed, not a proven physical improvement or authority for a prompt sweep.','Remaining later137rawjoin,RAGadjudication/fullcost/control/security requirements stay open.'];put(R/'outputs/research_resumption_20261028/Current_Resume.json',resume)
 head='## Original action attribution and thesis update verified — '+now+'\n\nAll4 saved original responses independently checked:459responses,413strictcompact outputs,192candidate-valid after normalization,51direct commits including9Qcorrections,13guided and9fallback numerical actions. Saved prompts contain231/308 first examples outside the permitted bus list;62responses choose that invalid example. This is a diagnosed interface inconsistency, not measured benefit from a repair. All459preserved inputs fit2683tokens maximum plus384 within4096; no new model/PF/training. Reviewed thesis113pages/15tables/22figures/35references,11of35documentation requirements complete. All6researchgoals OPEN. All experiment actors ended;0GPU/timers. Read currentresume and currentthesisQA. Oldfailed/partial/cost/frozen evidence preserved; no reruns/retunes or assumedGPUreset.\n\n'
 for name in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md']:
  f=R/name;f.write_text(head+f.read_text('utf-8-sig'),encoding='utf-8')
 with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+' | Saved prompt diagnosis independently PASS onall459responses;231/308firstprompt examplesoutsidecandidate list,62outputschoosethatbus. No causal/physical effect inferred. Modelreceiptinputsmax2683tokens+384fit4096. New113-page reviewedthesis integrates closest5records,raw/normalized/verified/committed actioncounts and nativeGraph comparison,15tables22figures35refs. T15/T25/T31 documentation closed;11/35closed24remain.0newscience/GPU in this saved analysis/documentwork.\n')
 print(json.dumps({'pages':113,'requirements_complete':11,'new_science':0}))
if __name__=='__main__':main()
