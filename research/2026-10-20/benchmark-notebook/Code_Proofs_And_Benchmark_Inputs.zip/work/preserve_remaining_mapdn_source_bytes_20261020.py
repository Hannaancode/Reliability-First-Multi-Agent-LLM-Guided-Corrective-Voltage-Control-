"""Additive GET-only transfer preservation after original writer ended; zero science."""
import hashlib,json,os,time,urllib.request,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT/'outputs/mapdn_author_dataset_full_20261020'
BASE=ROOT/'outputs/benchmark_priority_20261020/MAPDN';OUT=ROOT/'outputs/mapdn_author_dataset_preservation_20261020'
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    start=time.monotonic();OUT.mkdir(exist_ok=False);bound=600
    meta=json.loads((BASE/'Archive_Directory_Access.json').read_text(encoding='utf-8'))
    failure=json.loads((OLD/'Failure.json').read_text(encoding='utf-8'));assert failure['stage']=='TERMINAL_PARTIAL_OR_FAILED' and failure['failure_type']=='PermissionError'
    source=OLD/'voltage_control_data.zip.partial';length=source.stat().st_size
    assert length==failure['received_bytes']<meta['archive_size']
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'operation':'GET_ONLY_REMAINING_BYTE_PRESERVATION','original_owner_and_parent_confirmed_ended':True,'original_failure_preserved':str(OLD/'Failure.json'),'old_prefix_bytes':length,'new_range':[length,meta['archive_size']-1],'network_requests_max':1,'fixed_bound_seconds':bound,'new_model_PF_optimizer_GPU_calls':0,'no_scientific_retry_or_original_budget_extension':True,'status_preservation':'append-only fsynced events; original mutable-status replacement failure avoided'}
    put(OUT/'Protocol.json',protocol);put(OUT/'owner.claim',protocol);h=hashlib.sha256();total=0
    try:
        with (OUT/'voltage_control_data.zip.partial').open('xb') as dest,(OUT/'Events.jsonl').open('x',encoding='utf-8') as events:
            with source.open('rb') as old:
                for line in (OLD/'Transfer_Journal.jsonl').read_text(encoding='utf-8').splitlines():
                    r=json.loads(line);raw=old.read(r['chunk_bytes']);assert hashlib.sha256(raw).hexdigest()==r['chunk_sha256']
                    total+=len(raw);assert total==r['end_offset'];dest.write(raw);h.update(raw)
                assert not old.read(1) and total==length
            request=urllib.request.Request(meta['source_url']+'?preserve_exact_remaining='+str(length),headers={'User-Agent':'HierGrid-GET-only-preservation','Range':f'bytes={length}-{meta["archive_size"]-1}','Accept-Encoding':'identity'})
            with urllib.request.urlopen(request,timeout=45) as response:
                assert response.status==206 and response.headers['Content-Range']==f'bytes {length}-{meta["archive_size"]-1}/{meta["archive_size"]}'
                while True:
                    assert time.monotonic()-start<bound
                    raw=response.read(8*1024*1024)
                    if not raw:break
                    dest.write(raw);h.update(raw);total+=len(raw);assert total<=meta['archive_size']
                    events.write(json.dumps({'end_offset':total,'chunk_bytes':len(raw),'chunk_sha256':hashlib.sha256(raw).hexdigest(),'elapsed_seconds':time.monotonic()-start})+'\n');events.flush();os.fsync(events.fileno())
            dest.flush();os.fsync(dest.fileno())
        assert total==meta['archive_size'] and h.hexdigest()==meta['archive_lfs_sha256']
        path=OUT/'voltage_control_data.zip.partial';final=OUT/'voltage_control_data.zip';path.rename(final)
        entries=json.loads((BASE/'All_Author_Archive_Entries.json').read_text(encoding='utf-8'))['entries']
        with zipfile.ZipFile(final) as z:
            assert z.namelist()==[e['path'] for e in entries]
            for zi,e in zip(z.infolist(),entries):
                assert zi.file_size==e['uncompressed_bytes'] and zi.compress_size==e['compressed_bytes'] and f'{zi.CRC:08x}'==e['CRC32']
                with z.open(zi) as f:
                    while f.read(8*1024*1024):assert time.monotonic()-start<bound
        result={**protocol,'status':'COMPLETE_EXPECTED_FULL_SHA256_AND_ALL16_CRC_PASS','complete_bytes':total,'new_transferred_bytes':total-length,'sha256':h.hexdigest(),'all16_entry_CRCs_pass':True,'workflow_seconds':time.monotonic()-start,'time_series_values_parsed':False}
        put(OUT/'Result.json',result);print(json.dumps({k:result[k] for k in ['status','complete_bytes','new_transferred_bytes','workflow_seconds']}))
    except BaseException as exc:
        put(OUT/'Failure.json',{**protocol,'status':'PRESERVATION_FAILED','failure_type':type(exc).__name__,'failure':str(exc)[:400],'bytes_preserved':total,'workflow_seconds':time.monotonic()-start});raise
if __name__=='__main__':main()
