"""Saved-only independent check of exact solver arguments and mapped outputs."""
import ast,inspect
from r118_dff_missing_continuation_core_20261023 import *
S=R/'outputs/r118_exact_shunt_partition_receipt_v2_20261023'
O=R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023'

def main():
    O.mkdir(exist_ok=False);began=time.monotonic()
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    np,pp,v2,runner,reflection=setup()
    from strict_saved_native_input_match_v2_20261018 import require_same
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    import pandas as pd,pandapower.powerflow as pf
    protocol=read(S/'Protocol.json');result=read(S/'Result.json');assert result['status'].startswith('PASS_EXACT_NATIVE')
    for n,h in read(S/'Closed_Manifest.json')['members'].items():assert sha(S/n)==h
    packet=decode(S,result['mapped_receipt'])
    require_same(packet['new_native_arguments']['ppci'],packet['old_native_arguments']['ppci'])
    require_same(packet['new_native_arguments']['algorithm_options'],packet['old_native_arguments']['algorithm_options'])
    require_same(packet['new_native_arguments']['algorithm_kwargs'],packet['old_native_arguments']['algorithm_kwargs'])
    target=net_value(pickle.loads(zlib.decompress((R/protocol['target']).read_bytes())))
    reference=read(R/protocol['reference']);before=saved_net((R/protocol['reference']).parent,reference['before']);after=saved_net((R/protocol['reference']).parent,reference['after'])
    frames_equal(packet['new_input'],target);frames_equal(packet['old_input'],before);frames_equal(packet['mapped_after'],target)
    pd.testing.assert_frame_equal(packet['paid_after'].res_bus,after.res_bus,check_exact=True)
    mapped=packet['mapped_after'];assert np.array_equal(mapped.res_bus.vm_pu.values,after.res_bus.vm_pu.values) and np.array_equal(mapped.res_bus.va_degree.values,after.res_bus.va_degree.values)
    text=inspect.getsource(pf._powerflow);body=ast.parse(text).body[0].body
    cut=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='_run_pf_algorithm')
    prefix=ast.Module(body=body[:cut],type_ignores=[])
    assert hashlib.sha256(ast.dump(prefix,include_attributes=False).encode()).hexdigest()==result['source_preparation_proof']['exact_original_prefix_AST_sha256']
    assert hashlib.sha256(text.encode()).hexdigest()==result['source_preparation_proof']['native_powerflow_source_sha256']
    # The reference was already independently solved; reuse that evidence.
    dependencies=[]
    for f in A.glob('replay_*.json'):
        x=read(f)
        if x['primary_record']==(R/protocol['reference']).relative_to(E).as_posix():dependencies.append(x)
    assert len(dependencies)==1 and dependencies[0]['maximum_numeric_field_delta']==0.
    q=mapped._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0];V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]))
    residual=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert residual<=1e-7
    # Original per-element capacitive shunt source equation, including step
    # and voltage-base ratio, independently checked on the new row layout.
    expected=mapped.shunt.q_mvar.to_numpy(float)*mapped.shunt.step.to_numpy(float)*(mapped.res_bus.vm_pu.loc[mapped.shunt.bus].to_numpy(float)*mapped.bus.vn_kv.loc[mapped.shunt.bus].to_numpy(float)/mapped.shunt.vn_kv.to_numpy(float))**2
    assert np.allclose(expected,mapped.res_shunt.q_mvar.to_numpy(float),atol=1e-10,rtol=0)
    put(O/'Derived_Target_Before.json',dict(type='DERIVED_RECEIPT_NOT_NEW_MEASURED_PF',source_proof=S.relative_to(R).as_posix()))
    b=capsule(O/'Mapped_Target_Before.zlib',packet['new_input']);a=capsule(O/'Mapped_Target_After.zlib',mapped)
    put(O/'Mapped_Receipt.json',dict(receipt_type='DERIVED_FROM_EXACT_SOLVER_ARGUMENT_IDENTITY_NOT_NEW_PF_MEASUREMENT',before=b,after=a,kwargs=protocol['kwargs'],exception=None,proof=(O/'Independent_Audit.json').relative_to(R).as_posix()))
    put(O/'Independent_Audit.json',dict(status='PASS_EXACT_ARGUMENTS_NATIVE_SOURCE_PREFIX_PAID_RETURN_DEPENDENCY_AND_NEW_ROW_RESULTS',source_result_sha256=sha(S/'Result.json'),source_protocol_sha256=sha(S/'Protocol.json'),reference_independent_first_replay=dependencies[0],exact_solver_ppci_options_kwargs=True,exact_voltage_bytes=True,new_row_shunt_equation=True,KCL_pu=residual,new_model_PF_converter_derivative_optimizer_calls=0,
        preserved_failed_pure_preparation_cost=1,successful_source_preparation_calls=2,source_native_result_extractions=1,new_physical_measurement=False,scope='Single fixed125+25versus150partition. A future generalized adapter must prove exact solver argument equality afresh at every reuse; equal aggregate alone is insufficient.',workflow_seconds=time.monotonic()-began))
    put(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))
    print(json.dumps(dict(status='PASS_SINGLE_EXACT_PARTITION_RECEIPT_IDENTITY',new_nonlinear_or_model_calls=0)))

if __name__=='__main__':main()
