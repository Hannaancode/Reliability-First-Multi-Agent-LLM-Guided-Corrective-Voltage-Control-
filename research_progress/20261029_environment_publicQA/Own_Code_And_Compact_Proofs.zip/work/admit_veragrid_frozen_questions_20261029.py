"""Mechanical full-cohort intake. Never emit question values or labels to stdout."""
from pathlib import Path
from dataclasses import asdict
from datetime import datetime,timezone
from copy import deepcopy
import hashlib,json,sys
from veragrid_label_hidden_interface_20261029 import make_all_views
R=Path(__file__).resolve().parents[1];O=R/'outputs/veragrid_source_admission_20261029'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    out=O/'Actual150_Admission.json';assert not out.exists()
    p=O/'Dataset_Intake_Protocol.json';protocol=json.loads(p.read_text('utf-8'))
    raw=(O/'administrator/mcq_questions.web.json').read_bytes()
    assert len(raw)==protocol['question_bytes']
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==protocol['question_git_blob_sha1']
    d=json.loads(raw);records=d['questions'];views=make_all_views(records,protocol['expected_count'])
    # No row is dropped, reordered by outcome or made dependent on correctness.
    assert [v.question_id for v in views]==[r['id'] for r in records]
    altered=deepcopy(records)
    fields=set()
    for r in altered:
        for key in r:
            if key not in ('id','question','options'):
                fields.add(key);r[key]={'POISONED_ADMIN_FIELD':key}
    assert views==make_all_views(altered,len(records))
    participant=O/'participant';participant.mkdir(exist_ok=False)
    payload=json.dumps({'questions':[asdict(v) for v in views]},indent=2,ensure_ascii=False).encode('utf-8')+b'\n'
    with (participant/'Question_Views.json').open('xb') as f:f.write(payload)
    assert all(set(asdict(v))=={'question_id','question','options'} for v in views)
    record={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL150_FROZEN_INPUT_AND_FIELD_BOUNDARY_ONLY','protocol_sha256':sha(p.read_bytes()),'raw_question_git_blob_sha1':blob,'raw_question_sha256':sha(raw),'question_count':len(views),'unique_ids':len(set(v.question_id for v in views)),'source_order_preserved':True,'records_dropped':0,'label_metadata_mutation_invariance':True,'excluded_record_fields':sorted(fields),'excluded_top_level_fields':sorted(set(d)-{'questions'}),'participant_payload_sha256':sha(payload),'participant_fields':['question_id','question','options'],'administrator_reference_values_printed':False,'model_PF_OPF_training_GPU_calls':0,'schema_only_not_model_readiness':True,'no_unused_confirmation_claim':'Publicly released questions; author model pretraining overlap unknown. The assistant has inspected schema only, not actual question/option/label values. This does not establish model novelty or guarantee no contamination.','limitation':'Same-machine directories are packaging boundaries, not a process sandbox. An actual inference worker must receive a separately checked allowlisted payload with no administrator filesystem access.'}
    out.write_text(json.dumps(record,indent=2)+'\n','utf-8')
    print(json.dumps({k:record[k] for k in ['status','question_count','records_dropped','label_metadata_mutation_invariance','model_PF_OPF_training_GPU_calls']}))
if __name__=='__main__':main()
