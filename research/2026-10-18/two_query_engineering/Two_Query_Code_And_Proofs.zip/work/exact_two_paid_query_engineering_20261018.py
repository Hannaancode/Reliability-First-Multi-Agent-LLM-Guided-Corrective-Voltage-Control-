"""Exactly two prospective query identities with a real cold-process handoff.

No deployment commit, controller restart, LLM call, ranking sweep or policy
performance claim. Each returned converged primary gets ONE charged replay.
"""
import os
for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[variable]='1'
import argparse,ast,copy,hashlib,json,pickle,random,subprocess,sys,time,traceback,zlib
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandapower as pp
import full_joint_suffix_benchmark_20261014 as original
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from exact_new_query_reservations_v1_20261018 import Reservations
from strict_saved_native_input_match_v2_20261018 import require_same
from paid_joint_commit_v1 import fields
from paid_receding_chunked_history_v2_20261018 import History,verify_history
from reopen_exact_chunked_history_v1_20261018 import reopen_latest_history
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from equal_operation_benchmark_v2 import process,decode_capsule
from candidate_process_evidence_utils import frozen_checks
B=R/'outputs/exact_two_paid_query_engineering_20261018'
I=R/'outputs/next_exact_paid_query_preparation_20261018'
PYTHON=R/'work/physics_env/Scripts/python.exe'

def now():return datetime.now(timezone.utc).isoformat()
def admit(p):assert datetime.now(timezone.utc)<datetime.fromisoformat(p['absolute_deadline_utc']),'Fixed absolute bound; no extension'
def input_state():return pickle.loads(zlib.decompress((I/'Exact_Current_Input.zlib').read_bytes()))
def known_keys():
    import gzip
    return json.loads(gzip.decompress((R/'outputs/paid_lineage_frontier_20261018/All_Lineage_Attempt_Keys.json.gz').read_bytes()))
def evidence_class():
    tree=ast.parse(Path(original.__file__).read_text('utf-8'));node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Evidence')
    env=original.__dict__.copy();env['B']=B
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(original.__file__),'exec'),env)
    return env['Evidence']
def file_anchor(path):return {'path':str(path.relative_to(R)),'bytes':path.stat().st_size,'sha256':sha(path)}
def verify_file(a):
    p=R/a['path'];assert p.stat().st_size==a['bytes'] and sha(p)==a['sha256'];return p
def save_state(path,state):
    raw=pickle.dumps(state,protocol=5);assert len(raw)<8*1024**2;encoded=zlib.compress(raw,6)
    with path.open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
    return {**file_anchor(path),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw)}
def restore_state(receipt):
    path=verify_file(receipt);raw=zlib.decompress(path.read_bytes());assert len(raw)==receipt['raw_bytes'] and hashlib.sha256(raw).hexdigest()==receipt['raw_sha256'];return pickle.loads(raw)
def claim(out,p):
    out.mkdir(exist_ok=False);put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'source_sha256':sha(__file__),'protocol_sha256':sha(B/'Protocol.json')})
    started=time.perf_counter()
    while not (out/'Launcher_ACK.json').exists():admit(p);assert time.perf_counter()-started<60;time.sleep(.1)
    a=read(out/'Launcher_ACK.json');assert a['actual_pid']==os.getpid() and a['actual_parent_pid']==os.getppid() and a['fresh_exact_PID_parent_command']
def launch(source,mode,out,p):
    admit(p)
    with (B/(out.name+'_console.log')).open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(PYTHON),'-X','utf8',str(source),'--'+mode],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        started=time.perf_counter()
        while not (out/'owner.claim').exists():assert child.poll() is None and time.perf_counter()-started<60;time.sleep(.1)
        c=read(out/'owner.claim');real=process(c['actual_pid']);assert real and real['ParentProcessId']==child.pid and source.name in real['CommandLine'] and '--'+mode in real['CommandLine']
        assert c['source_sha256']==sha(source) and c['protocol_sha256']==sha(B/'Protocol.json')
        put(out/'Launcher_ACK.json',{'actual_pid':c['actual_pid'],'actual_parent_pid':child.pid,'actual_command':real['CommandLine'],'fresh_exact_PID_parent_command':True,'at_utc':now()})
        # A timeout never grants a second launch or scientific retry.
        remaining=max(1,(datetime.fromisoformat(p['absolute_deadline_utc'])-datetime.now(timezone.utc)).total_seconds()+30)
        code=child.wait(timeout=remaining)
    assert process(c['actual_pid']) is None and process(child.pid) is None
    put(B/(out.name+'_End_ACK.json'),{'actual_pid':c['actual_pid'],'launcher_pid':child.pid,'exit_code':code,'closed_manifest_sha256':sha(out/'Closed_Manifest.json'),'actual_owned_chain_ended':True})
    return code

def execute_one(index,state,p,reservations,history,evidence,runner):
    item=p['exact_new_query_rows'][index];net=state['net'];cursor=state['cursor'];point=point_key(net,cursor)
    assert point==p['point'] and state['paid_query_registry'].get(item['point_action_key']) is None
    original_copy=copy.deepcopy(net);cursor_copy=copy.deepcopy(cursor)
    key=reservations.reserve(net,cursor,item['row'],role=item['role']);evidence.context={'phase':'NEW_PRIMARY_QUERY','point':point,'action_key':action_key(item['row']),'role':item['role']}
    backend=pp.runpp;actual=evidence.actual_backend
    def authorized_backend(candidate,**kwargs):
        assert evidence.context['phase']=='NEW_PRIMARY_QUERY' and evidence.context['action_key']==action_key(item['row'])
        reservations.start(key,PF_id=evidence.serial,solver_kwargs=kwargs)
        return actual(candidate,**kwargs)
    evidence.actual_backend=authorized_backend;pp.runpp=evidence.solve
    try:raw=build_verifier(runner.rescue,cursor)[0](net,action(item['row']))
    finally:pp.runpp=backend;evidence.actual_backend=actual
    measured=evidence.last
    v=original.verdict(raw);record={'candidate':item['row'],'verdict':v,'original_score':list(runner.rescue.score_candidate({'action':action(item['row']),'verif':v})),
        'receipt_id':f'exact_two_query_{index+1}','actual_measured_receipt':measured,'attributed_PF_calls':int(measured is not None),
        'attributed_solver_seconds':measured['seconds'] if measured else 0.,'after_reference':{'kind':'new','descriptor':measured['after']} if measured and measured['outcome']=='RETURNED' else None}
    if measured is not None:reservations.closed(key,measured)
    require_same(net,original_copy);assert cursor==cursor_copy
    message={'parent':p['parent_handle'],'aid':action_key(item['row']),'row':item['row'],'record':record,
        'successor':p['parent_handle']+'/'+action_key(item['row']) if v['accepted'] else None}
    evidence.event('fixed_primary_query_closed',message)
    replay=None
    if measured and measured['outcome']=='RETURNED' and measured['converged']:
        _,actuate,_=build_verifier(runner.rescue,cursor);candidate=actuate(copy.deepcopy(net),action(item['row']))
        evidence.context={'phase':'CONTINUOUS_SELECTED_COMMIT_REPLAY','role':'CHARGED_QUERY_REPLAY_NOT_A_COMMIT','primary_PF_id':measured['PF_id'],'point':point,'action_key':action_key(item['row'])}
        try:
            evidence.solve(candidate,**p['solver_kwargs']);replay=copy.deepcopy(evidence.last)
            assert replay['outcome']=='RETURNED' and replay['converged']
            delta=max(abs(replay['fields'][b][k]-measured['fields'][b][k]) for b in measured['fields'] for k in measured['fields'][b])
            assert delta<=p['field_tolerance'];replay['maximum_field_delta']=delta
        except BaseException:
            # The one attempted replay is preserved; never retry it.
            evidence.event('charged_replay_failed_no_retry',{'last':evidence.last,'traceback':traceback.format_exc()});raise
        evidence.event('charged_query_replay_closed',{'primary_PF_id':measured['PF_id'],'receipt':replay})
    receipt={'message':message,'replay':replay,'phase':index,'point_action_key':key}
    state['paid_query_registry'][key]=receipt;history.append('exact_fixed_query_closed',receipt);state['next_index']=index+1
    require_same(net,original_copy);assert cursor==cursor_copy
    return receipt

def worker(mode):
    p=read(B/'Protocol.json');out=B/mode;claim(out,p);start=time.perf_counter();e=None;snapshot=None;reservations=history=None;code=1
    try:
        snapshot=LockedSourceSnapshot(B/'Protocol.json');snapshot.verify(p);assert read(B/'Readiness.json')['status']=='PASS_FIXED_TWO_QUERY_PRELAUNCH_ZERO_SCIENCE'
        admit(p);_,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
        if mode=='warm':
            random.seed(p['seed']);np.random.seed(p['seed']);source=input_state();state={'mode':'SAVED_PAID_BRANCH_QUERY_ENGINEERING','net':source['net'],'cursor':source['cursor'],
                'source_edge':source['source_edge'],'paid_query_registry':{},'next_index':0,'absolute_deadline_utc':p['absolute_deadline_utc'],'protocol_sha256':sha(B/'Protocol.json'),
                'prior_source_costs':'References retained in input/source edge; not free online tools or new original deployment commits.'}
            reservations=Reservations(B/'reservations',protocol=p,coverage=read(B/'Attempt_Coverage_Certificate.json'),known_attempt_keys=known_keys(),runner=runner,zones=zones)
            history=History(B/'query_history',source_anchor=sha(B/'Protocol.json'),input_anchor=p['input_state_sha256'],max_bytes=8*1024**2)
            put(out/'Frozen_Before.json',frozen_checks());put(out/'Source_Lock.json',snapshot.anchor())
        else:
            state=restore_state(read(B/'Warm_State_ACK.json'));assert state['next_index']==1 and state['absolute_deadline_utc']==p['absolute_deadline_utc'] and state['protocol_sha256']==sha(B/'Protocol.json')
            for a in state['closed_prefix_files']:verify_file(a)
            source=input_state();require_same(state['net'],source['net']);assert state['cursor']==source['cursor']
            reservations=Reservations(B/'reservations',protocol=p,coverage=read(B/'Attempt_Coverage_Certificate.json'),known_attempt_keys=known_keys(),runner=runner,zones=zones,restore_anchor=state['reservation_anchor'])
            assert reservations.states[p['exact_new_query_rows'][0]['point_action_key']]['closed'] is not None
            assert p['exact_new_query_rows'][1]['point_action_key'] not in reservations.states
            records=verify_history(state['history_anchor']);assert len(records)==1 and records[0]['payload']==state['paid_query_registry'][p['exact_new_query_rows'][0]['point_action_key']]
            history=reopen_latest_history(state['history_anchor']);random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
            assert pickle.dumps(random.getstate(),protocol=5)==pickle.dumps(state['python_rng'],protocol=5)
            assert pickle.dumps(np.random.get_state(),protocol=5)==pickle.dumps(state['numpy_rng'],protocol=5)
            put(out/'Cold_Restore_Proof.json',{'status':'PASS_EXACT_LATEST_QUERY_ONLY_STATE_HISTORY_REGISTRY_NET_CURSOR_RNG_COSTS_SOURCE_AND_ORIGINAL_NEW_DEADLINE','warm_costs':state['cumulative_costs'],'no_new_science_before_restore':True,'not_full_controller_restart':True})
        e=evidence_class()(p,out)
        if mode=='cold':e.serial=state['last_PF_id'];e.costs=copy.deepcopy(state['cumulative_costs'])
        receipt=execute_one(state['next_index'],state,p,reservations,history,e,runner)
        state.update(reservation_anchor=reservations.anchor(),history_anchor=history.anchor(),cumulative_costs=copy.deepcopy(e.costs),last_PF_id=e.serial,
            python_rng=random.getstate(),numpy_rng=np.random.get_state())
        # Close all append streams before a cold process may reopen them.
        e.close();e=None;reservations.close();reservations=None;history.close();history=None
        state['closed_prefix_files']=[file_anchor(out/'scientific.jsonl'),file_anchor(out/'capsules.bin')]
        if mode=='cold':state['closed_prefix_files']+=restore_state(read(B/'Warm_State_ACK.json'))['closed_prefix_files']
        ack=save_state(out/'Complete_Query_State.zlib',state);put(B/('Warm_State_ACK.json' if mode=='warm' else 'Final_State_ACK.json'),ack)
        complete=receipt['message']['record']['actual_measured_receipt'] is not None and receipt['replay'] is not None
        put(out/'Result.json',{'status':'COMPLETE_FIXED_PHASE_WITH_QUERY_ONLY_STATE' if complete else 'PARTIAL_FIXED_PHASE_NO_SCIENCE_RETRY','phase':mode,'receipt':receipt,'cumulative_costs':state['cumulative_costs'],
            'query_only_no_commit':True,'workflow_seconds':time.perf_counter()-start,'full_policy_LLM_superiority':'NOT_TESTED','state_ack':ack})
        code=0
    except BaseException:
        put(out/'Failure.json',{'traceback':traceback.format_exc(),'no_retry':True,'at_utc':now(),'actual_costs_if_available':e.costs if e else None})
    finally:
        if e:e.close()
        if reservations:reservations.close()
        if history:history.close()
        if snapshot:snapshot.close()
        manifest(out)
    raise SystemExit(code)

def coordinator():
    p=read(B/'Protocol.json');put(B/'Coordinator_Claim.json',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'protocol_sha256':sha(B/'Protocol.json'),'started_utc':now()})
    codes={}
    try:
        assert not any((B/m).exists() for m in ('warm','cold','audit'))
        for m in ('warm','cold'):
            codes[m]=launch(Path(__file__),m,B/m,p)
            if codes[m]!=0:break
        # Reader handles partial evidence, but never runs beside scientific owners.
        codes['audit']=launch(R/p['independent_reader_source'],'reader',B/'audit',p)
    finally:put(B/'Completion.json',{'at_utc':now(),'exit_codes':codes,'no_retries':True,'no_model_GPU_calls':True})

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--coordinator',action='store_true');a.add_argument('--warm',action='store_true');a.add_argument('--cold',action='store_true');args=a.parse_args()
    if args.coordinator:coordinator()
    elif args.warm:worker('warm')
    elif args.cold:worker('cold')
