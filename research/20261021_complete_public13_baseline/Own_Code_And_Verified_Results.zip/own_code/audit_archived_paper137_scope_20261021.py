"""Read-only historical CSV identity reconciliation, not a fresh physical audit."""
import csv,io,zipfile,json,hashlib
from decimal import Decimal
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];O=R/'outputs/paper137_archived_scope_reconciliation_20261021'
ROOT=Path('C:/Users/HOME/Desktop/multi agentic llm  power systesm')
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False,allow_nan=False)
def main():
    path=ROOT/'phase2g_stats_corrected_min_cases.zip';manifest=[]
    with zipfile.ZipFile(path) as z:
        def table(name):
            matches=[n for n in z.namelist() if n.endswith('/'+name)];assert len(matches)==1
            n=matches[0];raw=z.read(n);meta=z.getinfo(n);rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));manifest.append({'archive':str(path),'member':n,'bytes':len(raw),'member_CRC':meta.CRC,'member_sha256':hashlib.sha256(raw).hexdigest(),'rows':len(rows),'columns':list(rows[0]) if rows else []});return rows
        comparison=table('comparison_with_reconstructed_router.csv');long=table('full137_deterministic_long_per_scenario.csv');partial=table('selected_phase2g_per_scenario.csv')
    assert len(comparison)==137 and len({r['scenario_id'] for r in comparison})==137 and len(long)==411
    ids={r['scenario_id'] for r in comparison};registration=json.loads((R/'outputs/full_system_comparison_20261021/All203_Existing_Federation_Input_Cases.json').read_text());known={r['case_id']:r for r in registration if r['cohort']=='FED141_DEVELOPMENT'};assert len(known)==141 and ids<=set(known)
    def total(column):return str(sum(Decimal(r[column]) for r in comparison))
    assert total('v2b_base_uv')==total('v2r_base_uv')=='2715.0'
    assert all(Decimal(r['v2b_base_uv'])==Decimal(r['v2r_base_uv']) and Decimal(r['base_uv_diff'])==0 for r in comparison)
    for method in {r['method'] for r in long}:
        group=[r for r in long if r['method']==method];assert len(group)==137 and {r['scenario_id'] for r in group}==ids
    O.mkdir(exist_ok=False)
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_READ_ONLY_HISTORICAL137_IDENTITY_AND_REPORTED_BASE_COUNT_RECONCILIATION_ONLY','raw_unique_scenario_ids':137,'all137_bind_existing_FED141_recipe_IDs':True,'reported_paper_base_UV':2715,'archived_raw_base_UV_v2b':total('v2b_base_uv'),'archived_raw_base_UV_v2r':total('v2r_base_uv'),'all_base_UV_counts_pairwise_equal':True,'four_FED141_ids_absent_from_archive':sorted(set(known)-ids),'absence_reason':'Paper describes141generated/138sanity-converged/137replay-aligned; these four raw missing IDs are not by themselves a newly verified convergence/failed-join classification.','historical_earlier_methods_as_labeled':{'v2b_final_UV':total('v2b_final_uv'),'v2r_final_UV':total('v2r_final_uv'),'reconstructed_router_final_UV':total('router_final_uv')},'these_are_NOT_later_paper_DFF_HG_VF_HG_SE_labels':True,'separate_early_Phase2G_available_rows':len(partial),'early_rows_distinct_ids':len({r['scenario_id'] for r in partial}),'new_final137_HGSE_trajectory_raw_join':'NOT_ESTABLISHED','paper_later_DFF_HG_VF_HG_SE_reported_290_291_193_preserved_not_replaced':True,'full137_physical_NET_initializer_model_controller_source_and_trajectory_join':'UNKNOWN_NOT_CERTIFIED_BY_SCENARIO_NAMES_OR_MATCHING_COUNTS','archive_full_CRC_or_allhash_repeated':False,'raw_sources_modified_or_exported':False,'new_model_PF_solver_optimizer_GPU_calls':0,'all6goals':'OPEN','member_receipts':manifest,'joined_recipe_IDs':[{'scenario_id':i,'recipe':known[i]['recipe'],'recipe_sha256':known[i]['recipe_sha256']} for i in sorted(ids)]}
    put(O/'Read_Only_Scope_Reconciliation.json',result)
    note='''# Historical paper cohort reconciliation

An archived raw comparison table contains137 distinct scenario IDs, all present in the existing141 federation recipes. Its two recorded initial UV columns agree case by case and each sum to2,715, matching the supplied paper’s stated primary population.

This recovers a concrete historical cohort identity scaffold. The earlier method columns are explicitly v2b, v2r and a reconstructed router; their835,656 and545 residualUV totals must not be relabeled as the later DFF/HG-VF/HG-SE paper rows290/291/193. The accompanying early Phase2G table has68 rows. The complete later137-case HG-SE action/trajectory data remain unjoined.

Matching case IDs and counts does not certify the exact solved physical roots, initializer, source/weights, all physical trajectories, costs, or the later paper’s result. Four generated recipe IDs are absent from this archive; their individual convergence/exclusion reasons remain unverified. No sources were changed, no original study was rerun, and no new model, PF or optimizer was called.
'''
    (O/'Findings_And_Remaining_Join.md').write_text(note,encoding='utf-8');print(json.dumps({k:result[k] for k in ['status','raw_unique_scenario_ids','all137_bind_existing_FED141_recipe_IDs','archived_raw_base_UV_v2b','separate_early_Phase2G_available_rows','new_final137_HGSE_trajectory_raw_join']}))
if __name__=='__main__':main()
