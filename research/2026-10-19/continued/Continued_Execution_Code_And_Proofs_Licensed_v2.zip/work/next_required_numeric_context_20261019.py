"""One genuinely missing current-mask numeric context, no model/PF calls.

Old producer function AST is unchanged. Claim writes gain an actual-entrypoint
PID/source/parent ACK before numerical work; no old owner is restarted.
"""
import argparse,ast,copy,hashlib,importlib.metadata,json,os,pickle,time,traceback,zlib
from datetime import datetime,timezone,timedelta
from pathlib import Path
import first_missing_paid_numeric_context_20261018 as original
from public118_slsqp_native_20261018 import R,read,put,sha
from fixed_three_query_core_20261019 import helpers
from prepare_exact_two_paid_query_engineering_20261018 import local_closure
from equal_operation_benchmark_v2 import process
B=R/'outputs/next_required_numeric_context_20261019'
SCREEN=R/'outputs/unstarted_paid_suffix_with_fixed_three_20261019'

def claim_writer(entrypoint):
    def write(path,value):
        if Path(path).name=='owner.claim':
            value={**value,'actual_parent_pid':os.getppid(),'source_sha256':sha(entrypoint),'protocol_sha256':sha(B/'Protocol.json')}
        put(path,value)
        if Path(path).name=='owner.claim':
            begun=time.perf_counter()
            while not (Path(path).parent/'Launcher_ACK.json').exists():assert time.perf_counter()-begun<60;time.sleep(.1)
            ack=read(Path(path).parent/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_PID_parent_command']
    return write

def prepare():
    from dynamic_actual_mask_guidance_v1 import current_inputs,identity
    B.mkdir(exist_ok=False);begun=time.perf_counter();claim=read(SCREEN/'owner.claim');assert process(claim['actual_pid']) is None and process(claim['parent_pid']) is None
    leg=read(SCREEN/'Leg_1.json');assert leg['status']=='UNKNOWN_MissingPaidNumericalContext';ref=leg['frontier_input'];encoded=(SCREEN/ref['path']).read_bytes()
    assert hashlib.sha256(encoded).hexdigest()==ref['encoded_sha256'];raw=zlib.decompress(encoded);assert hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];state=pickle.loads(raw)
    ident=identity(current_inputs(state['net']));assert ident==leg['missing_identity']
    reuse=R/'outputs/full_paid_numeric_reuse_separate_roles_v2_20261018';refs=read(reuse/'All_Existing_Contexts.json');assert ident not in {v['identity'] for v in refs}
    extra=R/'outputs/first_missing_paid_numeric_context_20261018';audit=read(extra/'independent_audit/Independent_Audit.json');assert audit['status'].startswith('PASS_SINGLE_EXACT_') and ident!=audit['identity']
    catalog=read(R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json');relevant=[v for v in catalog if any('derivative_attempt' in k for k in v['events'])];assert len(relevant)==3
    coverage=[]
    for v in relevant:
        whole=hashlib.sha256();tail=b'';hits=0;needle=ident.encode()
        with (R/v['path']).open('rb') as f:
            while block:=f.read(1024**2):
                whole.update(block);joined=tail+block;hits+=joined.count(needle);tail=joined[-(len(needle)-1):]
        assert whole.hexdigest()==v['sha256'] and hits==0
        coverage.append({'path':v['path'],'sha256':v['sha256'],'identity_mentions':0})
    put(B/'Attempt_Coverage.json',{'status':'PASS_NEW_REQUIRED_CAUSAL_NUMERIC_ROLE_IN_CLOSED_DEPENDENCY_SET','identity':ident,'old_complete_contexts':len(refs),
        'separately_added_old_context_excluded':audit['identity'],'catalogued_derivative_journals':coverage,
        'new_three_query_proof':sha(R/'outputs/remaining_three_fixed_queries_20261019/audit/Independent_Audit.json'),
        'role_limits':'Current public compile role only, not a universal never-computed-mathematics theorem. Recent physical Newton internals were paid within PF; not represented as free new public contexts.',
        'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-begun})
    producer=Path(__file__);reader=R/'work/audit_next_required_numeric_context_20261019.py'
    files=local_closure([producer,reader]);files += [SCREEN/'Results.json',SCREEN/'Leg_1.json',SCREEN/ref['path'],reuse/'All_Existing_Contexts.json',
        extra/'independent_audit/Independent_Audit.json',B/'Attempt_Coverage.json']
    files=sorted(set(files));pins={str(v.relative_to(R)):sha(v) for v in files}
    put(B/'Protocol.json',{'status':'FROZEN_BEFORE_ONE_NEW_REQUIRED_NUMERIC_CONTEXT','identity':ident,'input_frontier':str((SCREEN/ref['path']).relative_to(R)),'raw_sha256':ref['raw_sha256'],
        'absolute_deadline_utc':(datetime.now(timezone.utc)+timedelta(seconds=600)).isoformat(),'bound_seconds':120,'reader_bound_seconds':120,
        'allowed':'ONE unchanged compile_current:1dSbus_dV,1LUfactor,1LUsolve118RHS, original forecasts once for ALL full native menu rows; no PF/model/optimizer/controller commit.',
        'selection':'First required context of the original fixed policy after all3pre-existing K4 queries measured, not an outcome-selected new mask/Q/objective/seed.',
        'pins':pins,'source_input_sha256':pins,'runtime_versions':{n:importlib.metadata.version(n) for n in ('numpy','scipy','pandas','pandapower')},
        'reader_sha256':sha(reader),'reader_source':str(reader.relative_to(R)),
        'source_certificate':'Producer worker FunctionDef AST exact; only injected put service binds owner source/realPID/parent and waits actual launcherACK before numeric work. No old source edit or scientific retry.',
        'limits':'Numerical ordering, not nonlinear safety, a trajectory or LLM/DSE advantage. No extra context, retry or old budget extension.'})
    print(json.dumps({'new_numeric_context':'PREPARED','identity':ident,'science':0}))

def worker():
    from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
    guard=LockedSourceSnapshot(B/'Protocol.json')
    try:
        node=next(n for n in ast.parse(Path(original.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='worker')
        env=original.__dict__.copy();env.update(B=B,__file__=__file__,put=claim_writer(__file__))
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(original.__file__),'exec'),env);env['worker']()
    finally:guard.close()

def coordinator():
    p=read(B/'Protocol.json');h=helpers(__file__);h['B']=B
    # Rebind the unchanged launcher into this isolated numeric output namespace.
    source=Path(original.__file__).parents[0]/'exact_two_paid_query_engineering_20261018.py'
    n=next(n for n in ast.parse(source.read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='launch')
    exec(compile(ast.Module(body=[n],type_ignores=[]),str(source),'exec'),h)
    codes={}
    try:
        codes['actual']=h['launch'](Path(__file__),'worker',B/'actual',p)
        if codes['actual']==0:codes['independent_audit']=h['launch'](R/p['reader_source'],'reader',B/'independent_audit',p)
    finally:put(B/'Completion.json',{'exit_codes':codes,'no_science_retry':True,'new_PF_model_calls':0})
    print(json.dumps({'required_numeric_context_exit_codes':codes}))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--worker',action='store_true');a.add_argument('--coordinator',action='store_true');args=a.parse_args()
    if args.prepare:prepare()
    elif args.worker:worker()
    else:coordinator()
