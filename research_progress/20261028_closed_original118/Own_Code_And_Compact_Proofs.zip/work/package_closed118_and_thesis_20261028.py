"""Allowlisted publication of own code, derived comparison and compact evidence."""
from pathlib import Path
import datetime,hashlib,json,zipfile
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
R=Path(__file__).resolve().parents[1];O=R/'outputs/closed118_and_thesis_publication_20261028'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def main():
    O.mkdir(exist_ok=False)
    sources=['work/'+x for x in ['assemble_original118_closed_comparison_20261028.py',
      'close_original118_comparison_record_20261028.py','advance_thesis_evidence_closure_20261028.py',
      'refine_thesis_defence_layout_20261028.py','clarify_external118_sgen_contract_20261028.py',
      'clarify_external118_sgen_contract_v2_20261028.py','clarify_external118_sgen_contract_v3_20261028.py',
      'package_closed118_and_thesis_20261028.py']]
    proofs=['outputs/original118_analysis_binding_20261028/Prepared_Analysis_Lock.json',
      'outputs/original118_comparison_completion_20261028/Verified_Completion.json',
      'outputs/thesis_evidence_update_20261028/Paired_Development_Effects.json',
      'outputs/thesis_evidence_update_20261028/Research_Question_Evidence_and_Defence.json',
      'outputs/thesis_evidence_update_20261028/All35_Task_Triage.json',
      'outputs/thesis_evidence_update_20261028/Evidence_Index.json',
      'outputs/thesis_evidence_update_20261028/Source_Update_Record.json',
      'outputs/thesis_evidence_update_20261028/Visual_QA.json',
      'outputs/thesis_evidence_update_20261028/Severe_Case_Thesis_Update.md',
      'outputs/external118_device_contract_clarification_v3_20261028/Corrected_Admission_Summary.json',
      'outputs/external118_device_contract_clarification_20261028/Failure.json',
      'outputs/external118_device_contract_clarification_v2_20261028/Failure.json']
    for i in (1,3):proofs.append(f'outputs/original_missing_suffix_independent_20261028/case_{i:02d}/Independent_Audit.json')
    rows=[]
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for relative in sources+proofs:
            raw=(R/relative).read_bytes();text=raw.decode('utf-8-sig')
            assert not SECRET_NAME.search(Path(relative).name) and not any(x.search(text) for x in SECRET),relative
            z.writestr(relative,raw);rows.append({'path':relative,'bytes':len(raw),'sha256':digest(raw)})
    with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip') as z:
        assert z.testzip() is None
        assert all(digest(z.read(x['path']))==x['sha256'] for x in rows)
    index={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':rows,'CRC_and_member_hashes':'PASS',
      'exclusions':'Private weights, NETs, raw device records, model responses, raw QA transcripts, third-party sources, active-account/runtime details and large scientific checkpoints are not published. This is not a complete raw backup.'}
    (O/'Artifact_Index.json').write_text(json.dumps(index,indent=2)+'\n','utf-8')
    copies={'Comparison.json':'outputs/original118_closed_comparison_20261028/Comparison.json',
      'Comparison.csv':'outputs/original118_closed_comparison_20261028/Comparison.csv',
      'Verified_Results_and_Thesis_Defence.docx':'outputs/thesis_evidence_update_20261028/Verified_Results_and_Thesis_Defence.docx',
      'Tasks.json':'outputs/research_tasks_20261014/Tasks.json',
      'Thesis_Closure_Tasks.json':'outputs/thesis_research_closure_20261028/Tasks.json'}
    for target,relative in copies.items():(O/target).write_bytes((R/relative).read_bytes())
    results=(R/'outputs/original118_closed_comparison_20261028/Results.md').read_text('utf-8')
    results+='''
The complete four-root totals are DFF51UV/11OV, originalHG-VF26UV/11OV and offlineHG-SE20UV/12OV. HG-VF uses73accepted actions versus29forDFF; its51direct/13guided/9fallback action origins do not isolate a causal language-pretraining benefit. The development gate fails and is not retuned.

Both missing-only suffixes and their independent readers ended successfully; exactT4runtimes were released and the waiting timer deleted. The suffixes retain1933newprimaryPFattempts/1927returns/6exceptions,1927firstreplays,140controllerresponses plus2coldgenerations. Historicalprefix/shared/training/preparation/failurecosts remain separate and paid.

Thesis progress: missing-endpoint evidence resolved, Chapter7/9sources updated, four-root descriptive effect sizes recorded, all35closureitems triaged and a seven-page six-RQ defencebrief visually reviewed. The original105pageWordfile remains unchanged pending full integration. Allsixfinalresearchgoals remainopen.

External118scope correction: each actualroot contains4pv-labelled and4diesel-labelled staticgenerators. Earlierdevice-absence text was wrong. Ratings andP/Qbounds are missing and authorcontinuousinvertercontrols still differ fromourpositive-shunt role. This source correction is not performance, a trainedcomparator or an allocation gate. Bothzero-science setupfailures are preserved.

Compact owncode/proofs exclude private rawassets and are not a full backup.
'''
    (O/'Results.md').write_text(results,'utf-8')
    state=json.loads((R/'outputs/research_resumption_20261028/Current_Resume.json').read_text('utf-8'))
    public={k:state[k] for k in ['at_utc','priority_order','all_six_final_goals','gpu_assignments','waiting_check','new_status','fixed_gate','unresolved','next','parallel_completed','gpu_quota_policy']}
    public['raw_backup_complete']=False
    (O/'Current_Resume.json').write_text(json.dumps(public,indent=2,ensure_ascii=False)+'\n','utf-8')
    mapping=[]
    for p in sorted(O.iterdir()):
        if p.is_file():
            raw=p.read_bytes();mapping.append({'local':p.relative_to(R).as_posix(),'path':'research_progress/20261028_closed_original118/'+p.name,
              'bytes':len(raw),'sha256':digest(raw),'blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
    (O/'Publication_Map.json').write_text(json.dumps(mapping,indent=2)+'\n','utf-8')
    print(json.dumps({'files':len(mapping),'members':len(rows),'archive_bytes':(O/'Own_Code_And_Compact_Proofs.zip').stat().st_size}))

if __name__=='__main__':main()
