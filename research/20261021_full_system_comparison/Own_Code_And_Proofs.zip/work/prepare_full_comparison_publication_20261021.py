"""Own code/proof snapshots only; no private weights, NETs or third-party sources."""
import hashlib,json,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/full_system_comparison_20261021/publication'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    sources=['prepare_full_system_comparison_20261021.py','close_public_comparison_cohorts_20261021.py','common_case_comparison_contract_20261021.py','audit_full_system_comparison_registration_20261021.py','paper_framework_native_PV_port_20261021.py','check_paper_framework_native_PV_port_20261021.py','check_native_parser_contract_v2_20261021.py','check_native_parser_contract_v3_20261021.py','run_public13_remaining_published_cohort_20261021.py','audit_public13_remaining_published_cohort_20261021.py','coordinate_public13_cohort_20261021.py','prepare_public13_remaining_cohort_20261021.py','save_full_comparison_progress_20261021.py','record_provided_paper_primary_cohort_20261021.py','prepare_full_comparison_publication_20261021.py']
    files=[ROOT/'work'/n for n in sources]
    names=['Original_Paper_System_Source_Map.json','All203_Existing_Federation_Input_Cases.json','Public_Case_Tracks.json','Controller_Identity_And_Readiness.json','Protocol.json','Unchanged_Paper_To_Public_Actuator_Eligibility.json','All120_TPA_Source_Ordered_Rows.json','All500_Public13_Source_Input_Identities.json','Public_Cohort_Closure.json','Independent_Registration_Audit.json','Provided_Paper_Primary_Cohort_Correction.json']
    files +=[ROOT/'outputs/full_system_comparison_20261021'/n for n in names]
    files +=[ROOT/'outputs/public13_full_cohort_preparation_20261021'/n for n in ['Protocol.json','Readiness.json','Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']]
    files +=[ROOT/'outputs/paper_framework_native_PV_port_v3_20261021/Software_Readiness.json']
    manifest={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Own code and compact source/case/software/protocol proofs; external native baseline live. No raw-binary backup or complete benchmark/superiority claim.','files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
    with zipfile.ZipFile(OUT/'Own_Code_And_Proofs.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,p.relative_to(ROOT).as_posix())
        z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(OUT/'Own_Code_And_Proofs.zip') as z:
        assert z.testzip() is None and len(z.namelist())==len(files)+1
        for item in manifest['files']:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
    (OUT/'README.md').write_text((ROOT/'outputs/full_system_comparison_20261021/Execution_And_Comparison_Status.md').read_text(encoding='utf-8')+'\nIMPORTANT CORRECTION: Supplied main manuscript uses137primary cases, DFF290/HG-VF291/HG-SE193 residualUV;20better/117equal/0worse selected vs singleDFF. Older25-case main-paper references above are superseded. See Provided_Paper_Primary_Cohort_Correction.json in proofpack. These are reported historical results, not new independently audited external superiority.\n',encoding='utf-8')
    for src,name in [('outputs/full_system_comparison_20261021/Current_Resume.json','Current_Resume.json'),('outputs/full_system_comparison_20261021/Independent_Registration_Audit.json','Independent_Registration_Audit.json'),('outputs/full_system_comparison_20261021/Provided_Paper_Primary_Cohort_Correction.json','Provided_Paper_Primary_Cohort_Correction.json'),('outputs/research_tasks_20261014/Tasks.json','Task_Progress.json')]:
        (OUT/name).write_bytes((ROOT/src).read_bytes())
    (OUT/'Preparation_Manifest.json').write_text(json.dumps({**manifest,'archive_bytes':(OUT/'Own_Code_And_Proofs.zip').stat().st_size,'archive_sha256':sha(OUT/'Own_Code_And_Proofs.zip'),'archive_members':len(files)+1},indent=2),encoding='utf-8')
    candidates=['README.md','Current_Resume.json','Independent_Registration_Audit.json','Provided_Paper_Primary_Cohort_Correction.json','Task_Progress.json','Preparation_Manifest.json','Own_Code_And_Proofs.zip']
    expected={'previous_head':'aa497cda7d20ddb0e0730a340ffc5db0bcec4697','files':[{'local':(OUT/n).relative_to(ROOT).as_posix(),'path':'research/20261021_full_system_comparison/'+n,'bytes':(OUT/n).stat().st_size,'sha256':sha(OUT/n)} for n in candidates]}
    (OUT/'Local_Publication_Files.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
    print(json.dumps({'files':len(candidates),'proof_archive_bytes':(OUT/'Own_Code_And_Proofs.zip').stat().st_size,'members':len(files)+1}))
if __name__=='__main__':main()
