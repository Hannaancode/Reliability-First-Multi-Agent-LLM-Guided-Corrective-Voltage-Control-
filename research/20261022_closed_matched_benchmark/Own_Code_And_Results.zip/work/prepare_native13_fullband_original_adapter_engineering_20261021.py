"""Prospective bounded model-interface experiment, not a physics benchmark.

The new bidirectional/full-band role follows a source-proved UV-stop mismatch.
The original u_mvar transfer study stays stopped. No private weights change.
"""
import ast
import copy
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'
OLD = R / 'outputs/original_lora_native13_transfer_preparation_v2_20261020'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    with Path(p).open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, allow_nan=False)


def main():
    P.mkdir(exist_ok=False)
    import candidate_process_runtime
    import sys
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import native13_fullband_hybrid_contract_20261021 as core
    from transformers import AutoTokenizer
    import numpy as np

    proof_dir = R / 'outputs/paper_uv_stop_public13_ceiling_20261021'
    ceiling = read(proof_dir / 'Conditional_Source_And_Cohort_Ceiling.json')
    proof = read(proof_dir / 'Independent_Conditional_Bound_Audit.json')
    assert proof['status'].startswith('PASS_') and proof['producer_result_sha256'] == sha(proof_dir / 'Conditional_Source_And_Cohort_Ceiling.json')
    prior = read(R / 'outputs/paper_native13_causal_contract_v3_20261021/All500_Physical_Role_Contracts.json')
    contract = prior[0]['contract']
    roots = read(R / 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json')['roots']
    uv = next(r for r in roots if min(r['all13_initial_vm']) < .95)
    ov = next(r for r in roots if min(r['all13_initial_vm']) >= .95 and max(r['all13_initial_vm']) > 1.05)
    selected = [('first_source_order_UV', uv), ('first_source_order_OV', ov)]
    adapter = R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    tokenizer = AutoTokenizer.from_pretrained(str(adapter), local_files_only=True, trust_remote_code=False)
    packets = []
    cases = []
    for kind, root in selected:
        state = core.frame(contract, root['all13_initial_vm'], root['initial_control_Q'], 0)
        cases.append({'engineering_case': kind, 'seed': root['seed'], 'contract': contract,
                      'frame': state, 'exact_paid_root': root})
        for zone in contract['zones']:
            messages = core.messages(contract, state, zone)
            if messages is None:
                continue
            encoded = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
            ids = encoded['input_ids'] if hasattr(encoded, 'keys') else encoded
            assert isinstance(ids, list) and all(type(v) is int for v in ids)
            assert len(ids) + 384 <= 4096
            packets.append({'agent': len(packets), 'engineering_case': kind,
                            'seed': root['seed'], 'zone': zone,
                            'physical_bus': contract['allowed'][zone][0],
                            'messages': messages, 'token_ids': ids, 'prefix_tokens': len(ids)})
    assert len(packets) == 6 and {p['engineering_case'] for p in packets} == {k for k, r in selected}
    tests = []
    state = cases[0]['frame']
    zone = next(z for z in contract['allowed'] if 2 in contract['allowed'][z])
    for amount in [.0001, .1, core.STEP_CAP, -.0001, -.1, -core.STEP_CAP]:
        admitted = core.admit({'bus': '2', 'q_mvar': amount}, contract, state, zone)
        assert admitted['status'] == 'LEGAL_PROPOSAL_NOT_PHYSICALLY_VERIFIED'
        assert np.sign(admitted['actual_delta_Q_Mvar']) == np.sign(amount)
        tests.append('literal_signed_support_' + str(amount))
    for label, value in [('malformed', '{'), ('extra_field', {'bus': '2', 'q_mvar': .1, 'teacher': 0}),
                         ('foreign_zone', {'bus': '7', 'q_mvar': .1}),
                         ('old25Mvar', {'bus': '2', 'q_mvar': 25}),
                         ('nonfinite', {'bus': '2', 'q_mvar': float('nan')}),
                         ('zero', {'bus': '2', 'q_mvar': 0}),
                         ('underflow', {'bus': '2', 'q_mvar': 1e-100})]:
        assert core.admit(value, contract, state, zone)['status'] == 'INVALID'
        tests.append(label)
    assert core.admit('null', contract, state, zone)['status'] == 'ABSTAIN'
    tests.append('null_is_abstention_never_filled')
    assert core.messages(contract, core.frame(contract, [1.] * 13, [0.] * 3, 0), zone) is None
    assert core.messages(contract, cases[1]['frame'], zone) is not None
    tests += ['fullband_stop', 'OV_only_does_not_stop']
    rejected = {'round': 0, 'zone': zone, 'bus': 2, 'actual_delta_Q_Mvar': -.1,
                'accepted': False, 'reason': 'normal_band_guard', 'receipt_sha256': 'a' * 64}
    assert core.frame(contract, state['current_VM'], [0.] * 3, 1, [rejected])['anchored_past_feedback'] == [rejected]
    for label, row in [('future_feedback', dict(rejected, round=1)), ('hidden_successor', dict(rejected, final_UV=0))]:
        try:
            core.frame(contract, state['current_VM'], [0.] * 3, 1, [row])
        except ValueError:
            tests.append(label)
        else:
            raise AssertionError(label)
    guard, guard_ast = core.unchanged_common_guard()
    assert not guard(np.ones(13), np.array([1.06] + [1.] * 12))
    assert not guard(np.ones(13), np.array([.94] + [1.] * 12))
    tests += ['normal_upper_guard_unchanged', 'normal_lower_guard_unchanged']
    put(P / 'All6_Messages_And_Token_IDs.json', packets)
    put(P / 'All2_Exact_Engineering_Cases.json', cases)
    protocol = copy.deepcopy(read(OLD / 'Production_Protocol.json'))
    protocol.update(at_utc=datetime.now(timezone.utc).isoformat(),
        study='NATIVE13_FULLBAND_ORIGINAL_ADAPTER_BOUNDED_INTERFACE_ENGINEERING_V1',
        scientific_question='Can the frozen original trained0.5B adapter express literal positive and negative native-Mvar requests under an explicitly new full-band hybrid contract? This is a finite functional gate, not proof of physical improvement.',
        selected_inputs={'rule': 'First UV-start and first OV-only start in the existing source order, all3active zone roles each. No output-selected roots.', 'seeds': [r['seed'] for k, r in selected]},
        new_role_not_silent_rescaling='Exact compact bus/q_mvar signed literal increments under native float32 capability; invalid/old25Mvar/absent outputs never filled, clipped, signed or repaired.',
        information='Complete current13VM, own currentQ/native limits/topology-only role, actual anchored past feedback only. Initial engineering has no prior feedback. No result/teacher/successor in prompt.',
        setup_seconds=1800, science_process_seconds=1200, collector_seconds=1500,
        fixed_actual_generations=12, maximum_context=4096,
        planned_model_generation_attempts={'primary': 6, 'fresh_model_cold_replays': 6},
        decoder_fixed_before_outputs={'do_sample': False, 'num_beams': 1, 'max_new_tokens': 384, 'seed': 20261021, 'no_output_repair_retry_or_prompt_sweep': True},
        functional_gate={'all6_primary_and6cold_preserved': True, 'all6cold_token_sequences_exact': True,
                         'all6_outputs_strict_JSON_compact_or_null': True,
                         'at_least_one_legal_nonzero_positive_in_UV_context': True,
                         'at_least_one_legal_nonzero_negative_in_OV_context': True,
                         'does_not_require_measured_UV_or_OV_improvement': True},
        conditional_physics='NO PF call or physical launch from this engineering study, including when functional gate passes. Full source-bound executor/paid history/persistent state/independent reader/strong controls/prospective physical protocol still required.',
        input_context='All6actual initial prefixes plus384 fit4096, no truncation. Original512training context and current positive-only SFT domain remain disclosed. Full feedback-context/process integration is not certified by this initial gate.',
        material_mechanism='Both-direction capability and full13band termination/selection, preserving direct/guided/fallback source priority and unchanged common protection. Motivated by exact UV-stop ceiling249/500 below all3published policies; no numerical outcome/epsilon/LP/horizon retune.',
        strong_controls_before_performance=['All3unmodified external native policies on same500roots', 'Current frozen numerical run and all costs, regardless of fixed-gate outcome', 'Separately fixed same-information noLLM proposal/acquisition controller with same paid query opportunity and protection', 'Architecture/pretraining controls before any LLM-attribution claim'],
        stage_stop='Functional failure stops this exact prompt/interface/decoder; no rescue prompt/Q/seed/model retunes or automatic higher model/physics launch.',
        old_stopped_native_u_mvar_transfer='Remains stopped; this named compact signed/full-band role is a different intervention, not repaired old outputs.',
        currently_ready_for_actual_model_owner=False,
        missing_before_model_launch=['Freeze actual owner/guardian/reader/source/input/loader/base/adapter/preservation locks and independent launch audit'])
    protocol.pop('preinference_loader_repair', None)
    put(P / 'Production_Protocol.json', protocol)
    put(P / 'Software_And_Method_Readiness.json', {'status': 'PASS_BIDIRECTIONAL_FULLBAND_METHOD_CAUSAL_INPUT_AND_BOUNDARY_SOFTWARE_ONLY',
          'boundary_checks': tests, 'guard_AST_sha256': guard_ast,
          'source_sha256': sha(R / 'work/native13_fullband_hybrid_contract_20261021.py'),
          'conditional_UV_stop_bound_proof': proof, 'prefix_tokens': [p['prefix_tokens'] for p in packets],
          'new_model_PF_training_GPU_calls': 0,
          'no_automatic_physics_or_training_readiness': True})
    print(json.dumps({'prepared_inputs': len(packets), 'seeds': [r['seed'] for k, r in selected],
                      'prefix_tokens': [p['prefix_tokens'] for p in packets], 'labelled_software_checks': len(tests), 'new_science': 0}))


if __name__ == '__main__':
    main()
