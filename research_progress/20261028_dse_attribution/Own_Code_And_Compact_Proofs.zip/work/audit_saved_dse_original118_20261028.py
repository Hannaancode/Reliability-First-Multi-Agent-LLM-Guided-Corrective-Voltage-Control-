"""Independent saved-file reader; no import of producer, controller, PF or model code."""
from pathlib import Path
import datetime, hashlib, json, os
R=Path(__file__).resolve().parents[1]
P=R/'outputs/original118_saved_dse_reconciliation_20261028'
O=P/'independent'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n','utf-8')
def main():
    assert not O.exists()
    joined=read(P/'Comparison.json')
    old=R/'outputs/actual_DSE_development_reference'
    current=read(R/'outputs/original118_closed_comparison_20261028/Comparison.json')
    bindings=read(P/'Input_And_Source_Bindings.json')
    for relative,digest in bindings.items():assert sha(R/relative)==digest,relative
    for name,digest in read(P/'Closed_Manifest.json')['members'].items():assert sha(P/name)==digest,name
    assert joined['new_scientific_calls']==0
    assert [x['case_id'] for x in joined['rows']]==current['protocol']['case_order']
    counts={'HGVF':{'wins':0,'ties':0,'losses':0,'extra_OV':[]},'HGSE':{'wins':0,'ties':0,'losses':0,'extra_OV':[]}}
    all_actions=0;controller={k:0 for k in ('attempts','returns','exceptions','llm_calls')};replay={k:0 for k in ('attempts','returns','exceptions')}
    for r in joined['rows']:
        cid=r['case_id']; b={a:read(old/f'branches/{cid}__{a}.json') for a in ['DFF','DFF-ALT']}
        latest=read(R/f'outputs/r118_dff_partition_continuation_execution_20261023/{cid}/Result.json')
        assert b['DFF']['result']==latest
        all_actions+=len(latest['executed_actions'])
        p=read(old/f'portfolios/{cid}.json');m=b[p['selected_branch']]['result']['final_metrics']
        assert m==p['selected_final_metrics']
        assert (r['numerical_DSE_UV'],r['numerical_DSE_OV'])==(m['uv_count'],m['ov_count'])
        original=next(x for x in current['rows'] if x['case_id']==cid)
        for key,value in original.items():assert r[key]==value
        for a in b.values():
            c=a['actual_controller_costs'];q=a['independent_committed_state_physical_replay'];assert q['passed']
            for k in controller:controller[k]+=c[k]
            for k in replay:replay[k]+=q['costs'][k]
            assert q['actual_committed_actions_replayed']==len(a['result']['executed_actions'])
        for system in counts:
            delta=r[system+'_UV']-m['uv_count']
            counts[system]['wins' if delta<0 else 'losses' if delta>0 else 'ties']+=1
            if r[system+'_OV']>m['ov_count']:counts[system]['extra_OV'].append(cid)
    for system in counts:
        assert {k:counts[system][k] for k in ['wins','ties','losses']}==joined[system+'_vs_DSE_UV']
    for key,total in joined['totals'].items():assert total==sum(r[key] for r in joined['rows'])
    assert controller['attempts']==controller['returns']+controller['exceptions']
    assert controller['llm_calls']==0 and replay['attempts']==replay['returns']+replay['exceptions']
    O.mkdir()
    write('owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'status':'PASS_ALL4_SAVED_SOURCE_RECIPE_FULL_DFF_OUTPUT_AND_COST_JOIN',
      'all4_fixed_roots':True,'complete_DFF_result_objects_exact':4,'exact_DFF_actions':all_actions,
      'endpoint_totals':joined['totals'],'descriptive_contrasts':counts,
      'historical_DSE_all4_full_both_controller_costs':controller,
      'historical_separate_committed_replay_costs':replay,
      'new_model_PF_optimizer_derivative_replay_calls':0,
      'audit_scope':'Saved JSON/source hashes and arithmetic only. Reuses the old initial/committed metric replay certificate, not a new physical certification or equal native-input/cold/KCL audit for ALT.',
      'historical_ALT_candidate_fullfield_or_ppci_identity':'UNKNOWN',
      'no_loss_and_no_additional_OV_satisfied':False,'all_six_final_goals':'OPEN'}
    write('Independent_Audit.json',result)
    write('Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'status':result['status'],'contrasts':counts,'old_both_costs':controller}))
if __name__=='__main__':main()
