"""Additive terminal binding coverage; no training/model/physics calls.

The original closed reader checked source/phase/costs. This separate certificate
also binds the current input/target bytes, actual initial shared tensors and
all fixed schema buffers/full RNG payloads. Original evidence is not rewritten.
"""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import json,time,torch
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';D=P/'transition_OPT_tensor_preparation'
S=P/'transition_CPU_pilot';A=P/'transition_CPU_pilot_external_audit';OUT=P/'transition_CPU_terminal_binding_audit'
assert read(P/'transition_CPU_audit_handoff/status.json')['stage']=='complete_single_external_audit_handoff'
assert read(A/'Independent_Actual_OPT_Control_Audit.json')['all_identity_checkpoint_cost_gates_passed']
assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
proto=read(P/'transition_CPU_pilot_preparation/Prospective_CPU_Pilot_Protocol.json')
assert sha(D/'Supplement_Manifest.json')==proto['input_manifest_sha256']
assert sha(D/'Input_Index.json')==proto['input_index_sha256'] and sha(D/'Target_Index.json')==proto['target_index_sha256']
checked=0
for name,m in read(D/'Supplement_Manifest.json').items():
    if name.startswith('source/'):
        assert sha(ROOT/'work/prepare_action_transition_numerical_inputs.py')==m['sha256']
    else:assert sha(D/name)==m['sha256'] and (D/name).stat().st_size==m['bytes']
    checked+=1
commonpath=P/'transition_numerical_software_resource_readiness/Fixed_New_Common_Initialization.pt'
assert sha(commonpath)==proto['common_initialization_sha256']
common=torch.load(commonpath,weights_only=True);emb=torch.load(D/'Fixed_Native_Schema_Embeddings.pt',weights_only=True)
assert torch.equal(common['fixed_schema_embeddings'],emb)
arms={}
for arm in proto['arms']:
    initial=torch.load(S/arm/'Initial_Model_State.pt',weights_only=True)
    assert all(torch.equal(initial['frontend.'+n],v) for n,v in common.items())
    registry=read(S/arm/'Actual_Parameter_Registry.json')
    assert registry['active_parameters']==proto['actual_active_parameters'][arm]
    for epoch in range(1,6):
        checkpoint=torch.load(S/arm/f'Complete_Epoch{epoch}_State.pt',weights_only=False)
        assert torch.equal(checkpoint['model']['frontend.fixed_schema_embeddings'],emb)
        rng=checkpoint['RNG'];assert set(rng)=={'python','numpy','torch_CPU','torch_CUDA'}
        assert rng['torch_CPU'].dtype==torch.uint8 and rng['torch_CPU'].numel()>0 and rng['torch_CUDA']==[]
        assert rng['python'][0]==3 and len(rng['python'][1])==625
        assert rng['numpy']['kind']=='MT19937' and rng['numpy']['keys'].shape==(624,)
        assert 0<=rng['numpy']['position']<=624 and rng['numpy']['has_gauss'] in (0,1)
    final=checkpoint['model'];changed=[n for n in registry['active'] if not torch.equal(initial[n],final[n])]
    assert len(changed)==len(registry['active'])
    arms[arm]={'initial_shared_tensors_exact':len(common),'all_active_parameter_tensors_changed':len(changed),
        'all5fixed_schema_buffers_exact':True,'all5complete_Python_NumPy_Torch_RNG_payloads_verified':True,
        'actual_active_capacity_matches_frozen_protocol':True}
result={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_additive_binding_checks_passed':True,
    'actual_input_manifest_members_revalidated':checked,'original_proto_index_target_initialization_hashes_passed':True,
    'arms':arms,'original_negative_10percent_gate_unchanged':True,
    'new_model_optimizer_PF_controller_cloud_calls':0,'actual_reader_seconds':time.perf_counter()-started}
write(OUT/'Terminal_Input_Init_Buffer_RNG_Binding_Audit.json',result)
seal(OUT,{'Terminal_Input_Init_Buffer_RNG_Binding_Audit.json':OUT/'Terminal_Input_Init_Buffer_RNG_Binding_Audit.json',
    'source/reader.py':Path(__file__)},'Verified_Transition_CPU_Terminal_Bindings.zip')
print(json.dumps(result,indent=2))
