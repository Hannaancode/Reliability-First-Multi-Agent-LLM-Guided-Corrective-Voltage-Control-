"""Post-release external source/identity/journal/action/cost audit; no model/PF."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,os,zipfile
import psutil
from vcsa_pilot_result_audit_v4 import audit_variant_with_checkpoint
ROOT=Path(__file__).resolve().parents[1]
EXEC=ROOT/'outputs/vcsa_development/pretrained_pilot_execution'
PREP=ROOT/'outputs/vcsa_development/pretrained_pilot_preparation'
DATA=ROOT/'outputs/vcsa_development/full_pilot_preparation'
SCI=EXEC/'staged/study';OUT=ROOT/'outputs/vcsa_development/pretrained_pilot_analysis'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state=read(EXEC/'status.json')
assert state['finished_at_utc'] and state['runtime_released'] and state['all_actual_artifacts_preserved']
assert state['remote_exit_code']==0 and read(EXEC/'staged/pilot_exit.json')['exit_code']==0
pid=int((EXEC/'owner.claim').read_text())
if psutil.pid_exists(pid):
 process=psutil.Process(pid)
 assert not any('run_vcsa_pretrained_pilot_colab_20261008.py' in arg for arg in process.cmdline()),'Wait for actual owner end'
assert not OUT.exists();OUT.mkdir();(OUT/'analysis.claim').write_text(str(os.getpid()))
payload=read(PREP/'Pretrained_Pilot_Cloud_Payload_Manifest_20261008.json')
assert sha(ROOT/payload['archive'])==payload['sha256']
descriptor=read(EXEC/'remote_output_descriptor.json');assert sha(EXEC/'preserved_remote_outputs.zip')==descriptor['sha256']
with zipfile.ZipFile(EXEC/'preserved_remote_outputs.zip') as bundle:
 assert bundle.testzip() is None and len(bundle.namelist())==len(set(bundle.namelist()))
 assert set(bundle.namelist())==set(descriptor['members'])
 for name,info in descriptor['members'].items():
  p=SCI/name;assert p.stat().st_size==info['bytes'] and sha(p)==info['sha256']
for name,info in read(SCI/'manifest.json').items():assert (SCI/name).stat().st_size==info['bytes'] and sha(SCI/name)==info['sha256']
assert read(EXEC/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
environment=read(EXEC/'staged/remote_frozen_environment.json')
assert environment==read(ROOT/'outputs/remote_frozen_environment.json')
summary=read(SCI/'summary.json');assert summary['completed'] and summary['completed_variants']==['frozen_LM_heads','VCSA_full']
assert summary['gpu']=='Tesla T4' and summary['PF_calls']==summary['generations']==0
assert summary['source_sha256']==payload['members']['work/vcsa_pretrained_pilot_remote_20261008.py']
assert summary['protocol_sha256']==payload['members']['outputs/vcsa_development/pretrained_pilot_preparation/Pretrained_Pilot_Protocol_20261008.json']
assert summary['frozen_environment']==environment
loads=summary['all_model_loads'];assert len(loads)==4
assert all(load['pretrained_model_loaded'] and load['four_bit_base_verified'] and load['PEFT_disabled_restored_enabled_unmerged']
 and load['original_adapter_tokenizer_files_unchanged'] and load['context_preflight']['actual_tokenized_views']==47
 and load['context_preflight']['token_ids_all_match_frozen_preflight'] for load in loads)
assert all(load['base_weight_sha256']==environment['base_weight_sha256'] for load in loads)
assert read(SCI/'Genuine_Study_Identity.json')['exact_owned_runtime_released'] is False
identity={'verified_at_utc':datetime.now(timezone.utc).isoformat(),'pretrained_model_loaded':True,
 'actual_CUDA_T4_verified':True,'all_frozen_weight_source_gates_passed':True,'exact_owned_runtime_released':True,
 'actual_base_weight_sha256':environment['base_weight_sha256'],'owned_notebook_hash':state['notebook_hash'],
 'owned_endpoint':state['endpoint'],'all_original_remote_files_immutable':True,
 'proof_sources':['terminal local owned status/exact assignment release','exact preserved output archive and all member hashes',
  'original input/source/protocol manifest','exact111 environment and four actual fresh load records'],
 'scope':'External identity/release certificate; does not overwrite initial remote identity or establish physical/trajectory/confirmation superiority'}
identity_path=OUT/'Genuine_Study_Identity.json';identity_path.write_text(json.dumps(identity,indent=2))
tokens={r['id']:r['tokens'] for r in read(DATA/'Serialization_Audit.json')['checks']}
rows={r['local_observation_id']:r for r in read(DATA/'rows.json')}
reports={};paired={};journals={}
for variant in ['frozen_LM_heads','VCSA_full']:
 report,per_id=audit_variant_with_checkpoint(SCI/variant,DATA,SCI/(variant+'_checkpoint_replay'),expected_tokens=tokens,identity_path=identity_path)
 assert report['costs']['forward_returns']==280
 assert report['costs']['input_tokens']+report['additional_checkpoint_replay_costs']['input_tokens']==read(PREP/'Pretrained_Pilot_Protocol_20261008.json')['expected_charged_input_tokens_per_arm']
 assert read(SCI/variant/'summary.json')['trainable_parameters']==read(PREP/'Pretrained_Pilot_Protocol_20261008.json')['expected_trainable_parameters'][variant]
 for stage,attempts,steps in [('training',280,155),('checkpoint_replay',47,0)]:
  events=[json.loads(line) for line in (SCI/(variant+'_'+stage+'_events.jsonl')).read_text().splitlines()]
  assert [e['event_index'] for e in events]==list(range(1,len(events)+1))
  assert all(e['variant']==variant and e['stage']==stage for e in events)
  assert [e['call'] for e in events if e['event']=='forward_attempt']==list(range(1,attempts+1))
  assert [e['call'] for e in events if e['event']=='forward_return']==list(range(1,attempts+1))
  assert not any(e['event']=='forward_exception' for e in events)
  assert [e['step'] for e in events if e['event']=='optimizer_step_completed']==list(range(1,steps+1))
  for event in events:
   if event['event'].startswith('forward_'):assert event['id'] in tokens and event['input_tokens']==tokens[event['id']]
  if stage=='training':assert [e['epoch'] for e in events if e['event']=='epoch_checkpoint_preserved']==[1,2,3,4,5]
  journals[variant+'_'+stage]={'events':len(events),'attempts':attempts,'returns':attempts,'steps':steps}
 reports[variant]=report
 for record in read(SCI/variant/'final_rows.json'):paired[(variant,record['id'])]=record
for control in ['state_only_pilot','common_information_control_pilot']:
 folder=ROOT/'outputs/vcsa_development'/control
 for name,info in read(folder/'manifest.json').items():assert (folder/name).stat().st_size==info['bytes'] and sha(folder/name)==info['sha256']
 records=read(folder/'final_rows.json');assert len(records)==len({r['id'] for r in records})==48
 for record in records:paired[(control,record['id'])]=record
comparisons={};table=[]
policies=['state_only_pilot','common_information_control_pilot','frozen_LM_heads','VCSA_full']
for identity,row in sorted(rows.items()):
 for policy in policies:
  record=paired[(policy,identity)]
  if not row['training_eligible']:
   assert record['hard_abstained'];table.append({'id':identity,'policy':policy,'split':row['split'],'invalid_retained':True});continue
  action=record['action'];label=next(l for l in row['candidate_labels'] if l['bus']==action['bus'] and l['q_mvar']==action['q_mvar'])
  assert row['input']['allowed_bus_mask'][action['bus_position']] and row['input']['bus_ids'][action['bus_position']]==action['bus']
  assert record['label_after_metrics']==label['after_metrics']
  guard=record.get('admissible_in_existing_table',record.get('measured_label_guard_admissible'))
  assert bool(guard)==bool(label['guard_admissibility_target'])
  after=label['after_metrics'];table.append({'id':identity,'scenario_id':row['scenario_id'],'policy':policy,'split':row['split'],
   'action':action,'measured_guard_admissible':bool(guard),'selected_PF_failure':bool(label['PF_failure_target']),
   'residualUV':None if after is None else after['uv_count'],'residual_deficit':None if after is None else after['deficit_sum'],
   'scope':'existing measured candidate table correspondence; selected physical replay not newly performed'})
for comparator in policies[:-1]:
 stats={'UVwins':0,'UVties':0,'UVlosses':0,'unavailable_pairs':0,'paired_finite_validation_views':16,'admissible_changed_actions':0}
 lookup={(r['policy'],r['id']):r for r in table}
 for identity,row in rows.items():
  if row['split']!='validation' or not row['training_eligible']:continue
  a=lookup[('VCSA_full',identity)];b=lookup[(comparator,identity)]
  stats['admissible_changed_actions']+=int(a['measured_guard_admissible'] and a['action']!=b['action'])
  if a['residualUV'] is None or b['residualUV'] is None:stats['unavailable_pairs']+=1;continue
  delta=a['residualUV']-b['residualUV'];stats['UVwins' if delta<0 else 'UVties' if delta==0 else 'UVlosses']+=1
 comparisons[comparator]=stats
(OUT/'Actual_Four_Policy_One_State_Table.json').write_text(json.dumps(table,indent=2,allow_nan=False))
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'passed':True,'variant_reports':reports,
 'actual_journal_counts':journals,'validation_descriptive_VCSA_vs_controls':comparisons,
 'all_controls_retained_without_rerun':True,'invalid_view_in_all_four_denominators':True,
 'actual_new_model_training_steps':310,'actual_new_model_forwards':654,'new_analysis_model_or_PF_calls':0,
 'genuine_one_state_learning_evidence':True,'full_DSE_superiority':False,'unused_confirmation':False,
 'selected_physical_replay_done':False,'prior_integration_and_label_costs_separate_required':True,
 'limits':['Historical views correlated by physical world; no confirmatory CI','Information/capacity/backbone/inductive-bias/precision differences remain',
  'Unavailable PF outcomes retained as failures/unknowns, never dropped to claim positive sign','No full trajectory or certified-optimum/operational-feasibility claim']}
(OUT/'Independent_Source_Action_Journal_Cost_Audit.json').write_text(json.dumps(report,indent=2,allow_nan=False))
(OUT/'manifest.json').write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file() and p.name!='analysis.claim'},indent=2))
print(json.dumps({'passed':True,'actual_optimizer_steps':310,'actual_model_forwards':654,'descriptive_validation':comparisons,'DSE_superiority':False},indent=2))
