# Common-information numerical control: completed development evidence

This necessary comparator study used a prospectively fixed architecture, seed, five epochs, 155 AdamW steps and final epoch5 checkpoint. No pretrained model, GPU, cloud upload or outcome-driven width/seed/optimizer search was used. Original controls and the approval-pending smoke archive remain unchanged.

## Input and capacity checks

All 47 finite observations retained all 10,741 original scalar fields, including local tie flows and generator/DER/storage quantities. Types, strings, arrays and containers round-trip exactly. The 48th invalid input remained in the denominator without fabricated values. An independent audit checked 8,117 numeric transforms and 36 input-only training normalization groups. All current typed field patterns are supported. The old graph, seven features and exact candidate masks remain unchanged.

The numerical control consumes typed paths/strings through an unpretrained byte/record encoder, all observed numeric fields through a float32 input path, and the preserved graph/state encoder. It shares the bus/Q and physical heads. Width304 was selected analytically before performance outcomes to match VCSA-full's 418,436 new parameters: the control has 418,448, a difference of12 (0.00287%). This controls available measurements and trainable parameter count, not inductive bias, frozen pretrained capacity, precision, FLOPs or latency. Raw source values are lossless; the neural numeric conversion is float32 and is disclosed. No equivalence of learned representations is claimed.

Eleven software checks passed, including action masks, actual influence of previously omitted tie/gen quantities, finite gradients and unsupported-input rejection. The first software gradient fixture omitted the bus-score head from its fabricated scalar loss; that failed fixture/source was preserved and its test coverage was repaired before the scientific protocol/training. No scientific trial was rerun.

## Actual one-state results

| Validation diagnostic | Before training | Final fixed checkpoint |
|---|---:|---:|
| Finite views | 16 | 16 |
| Preferred action matches | 0 | 8 |
| Guard-admissible actions | 4 | 16 |
| Mean residual UV in physical tables | 26.375 | 28.0625 |
| Strict UV zero and normal upper | 0 | 0 |

The increased UV residual while learning guard admissibility is a retained tradeoff. Train preferred matches were13/31 and admissible actions29/31. The completed earlier seven-feature control had10/16 validation preferred matches and16/16 admissible actions. Compared with that control, the common-information control has **0 UV wins,13 ties and3 losses**, mean UV delta+2.625. Keep both controls. Do not replace the better earlier control, select a favorable checkpoint or retrain this architecture.

Actual work: 155 optimizer steps,296 numerical forwards (47 initial evaluation,155 optimizer,47 final evaluation,47 separate checkpoint reload),0 exceptions;77,074 typed record inputs and3,273,025 byte-encoder input bytes. Training20.0453s; total study24.9406s; sampled process peak RSS345,591,808bytes. No LM token/generation or GPU-hour claim arises from these measurements. The independent18-member/source/identity/action/candidate/cost audit verified96 output rows,6,066 candidate prediction records and all47 reloaded final actions. The invalid input remained retained.

## Physical validation with exact reuse

Forty-four final actions were identical to the previously independently replayed control under exactly matching source/scenario/data identities. Their original reports were reused. Only three actions changed; all three received fresh original-verifier and independent applied-action solves. Including three initial-world solves, this added **9 actual PF attempts with0exceptions** in4.4326s. The prior139-PF study remains separately charged and preserved; it was not rerun or declared free.

An independent read-only audit covers all47 final selected states, their118 bus voltages, action/scope/source identities and original physical metrics within1e-10. All16 validation actions are admissible; no one-step global UV clearance occurs. Finite saved generator/line bounds are snapshot diagnostics, not certified full operational feasibility. This is numerical-control development evidence, not an LLM or full-DSE result.

## Remaining execution gate

The genuine VCSA T4 integration and model training remain unexecuted. The same specific private34,831,836-byte upload/destination approval question is pending after automatic review rejection. Local safe input/control/provenance/physical preparation is now complete; no control or physics owner remains live. The terminal15-minute CPU pretrained attempt is not restarted.

After the direct response, inspect fresh ownership/profile identity, the unchanged archive and allocation, then run one genuine T4 integration smoke. Only successful real framework/gradient/memory/old-weight/checkpoint/preservation/release evidence can gate a separately sealed pretrained pilot. VCSA must be compared with both numerical controls and the actual literal D-SE portfolio over prospective matched trajectories/full costs. Unused independent confirmation remains required; no superiority has been established.
