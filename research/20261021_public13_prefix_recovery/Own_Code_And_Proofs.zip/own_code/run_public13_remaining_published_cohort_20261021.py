"""Remaining author test cases, all three frozen native policies. No HierGrid score."""
import copy,hashlib,json,os,pickle,random,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/public13_full_cohort_preparation_20261021';OUT=ROOT/'outputs/public13_remaining_published_cohort_20261021'
_PRESERVED_BINARY_BYTES=0
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def binary(p,x):
    global _PRESERVED_BINARY_BYTES
    raw=pickle.dumps(x,protocol=5)
    if _PRESERVED_BINARY_BYTES+len(raw)>4*1024**3:raise TimeoutError('Fixed4GiB scientific binary preservation budget; no extension')
    with Path(p).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    _PRESERVED_BINARY_BYTES+=len(raw)
def regime(net):
    import pandas as pd
    h=hashlib.sha256()
    for n in ['bus','line','trafo','sgen','gen','load','ext_grid','shunt','switch']:
        tab=net[n].copy()
        if n=='sgen':tab.loc[tab.index[:3],'q_mvar']=0.
        h.update(n.encode());h.update(pd.util.hash_pandas_object(tab,index=True).to_numpy().tobytes())
    return h.hexdigest()
def metrics(vm):return {'UV':int((vm<.95).sum()),'OV':int((vm>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'full_band_restored':bool(((vm>=.95)&(vm<=1.05)).all())}
def main():
    OUT.mkdir(exist_ok=False);began=time.monotonic();put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));deadline=began+p['science_seconds'];ack=json.loads((OUT/'Launcher_ACK.json').read_text());assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    for n,h in p['source_and_input_hashes'].items():assert sha(ROOT/n)==h
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    from pandapower.pypower.makeSbus import makeSbus
    np=b.np;torch=b.torch;torch.set_num_threads(1);torch.manual_seed(20261021);random.seed(20261021)
    costs={k:0 for k in ['native_conversion_returns','checkpoint_load_attempts','checkpoint_load_returns','agent_forward_attempts','agent_forward_returns','PF_attempts','PF_returns','PF_exceptions','paid_exact_cache_uses']};costs['LLM_GPU_optimizer_training_calls']=0
    previous='0'*64;stream=(OUT/'events.jsonl').open('x',encoding='utf-8');receipts=[];worlds=[];cache={};attempted={};context={};current_receipt=None
    def event(kind,**data):
        nonlocal previous
        v={'kind':kind,'seconds':time.monotonic()-began,'previous':previous,**data};h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();stream.write(json.dumps({'event':v,'sha256':h},separators=(',',':'))+'\n');stream.flush();os.fsync(stream.fileno());previous=h
    def bound():
        if time.monotonic()>deadline-15:raise TimeoutError('Original prospective resource bound; no extension or retry')
    def tracked(net,*args,**kwargs):
        nonlocal current_receipt
        bound();assert not args and kwargs in [{'algorithm':'bfsw'},{'algorithm':'bfsw','init':'dc'}];sig=signature(net);key=(sig,json.dumps(kwargs,sort_keys=True))
        assert regime(net)==p['remaining_regimes'][str(context['seed'])], 'Exact non-controlled physical regime changed'
        assert regime(net) not in p['paid_prior_regimes'],'Previously entered source input; never repeat science'
        if key in cache:
            item=cache[key];net.update(copy.deepcopy(item['net']));current_receipt=item['index'];costs['paid_exact_cache_uses']+=1;event('paid_exact_PF_reuse',index=current_receipt,physical_signature=sig,context=context.copy());return
        if key in attempted:raise RuntimeError('Previously attempted failed or incompletely preserved input remains UNKNOWN; no repeated PF')
        if any(k[0]==sig for k in attempted):raise RuntimeError('Paid input under distinct initializer UNKNOWN; do not repeat')
        index=costs['PF_attempts'];d=OUT/'physics';before=d/f'PF{index:06d}_before.pkl';binary(before,net);row={'index':index,'physical_signature':sig,'kwargs':kwargs,'context':context.copy(),'status':'ATTEMPTED','before_sha256':sha(before)};receipts.append(row);attempted[key]=index;current_receipt=index;costs['PF_attempts']+=1;event('PF_attempt',**row);start=time.perf_counter()
        try:b.pp.runpp(net,**kwargs)
        except BaseException as exc:
            costs['PF_exceptions']+=1;row.update(status='EXCEPTION',failure_type=type(exc).__name__,seconds=time.perf_counter()-start);event('PF_exception',**row);raise
        costs['PF_returns']+=1;assert net.converged and sig==signature(net);ppc=net._ppc;assert np.array_equal(ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and ppc['baseMVA']==float(graph['baseMVA'])
        v=ppc['bus'][:,7]*np.exp(1j*np.deg2rad(ppc['bus'][:,8]));s=makeSbus(ppc['baseMVA'],ppc['bus'],ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert kcl<=1e-7
        after=d/f'PF{index:06d}_after.pkl';binary(after,net);fields=d/f'PF{index:06d}_fields.npz';np.savez(fields,**{n:net[n].select_dtypes(include=[np.number]).to_numpy(float) for n in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']});row.update(status='RETURNED',after_sha256=sha(after),fields_sha256=sha(fields),KCL_max_pu=kcl,seconds=time.perf_counter()-start);cache[key]={'index':index,'net':copy.deepcopy(net)};event('PF_return',**row)
    partial=False
    try:
        put(OUT/'Frozen_Before.json',frozen_checks());(OUT/'physics').mkdir();env,proxy,proof=b.environment();costs['native_conversion_returns']+=1;template=copy.deepcopy(env.__dict__);graph=np.load(ROOT/p['graph']);recipes=np.load(ROOT/p['recipes']);proxy.runpp=tracked
        def load_event(kind,**data):
            if kind=='checkpoint_load_attempt':costs['checkpoint_load_attempts']+=1
            if kind=='checkpoint_load_return':costs['checkpoint_load_returns']+=1
            event(kind,**data)
        models,loads,_=b.load_three(env,load_event);put(OUT/'Actual_Checkpoint_Loads.json',loads)
        def parameters():return {f'{a}::{i}::{n}':v.detach().cpu().numpy().copy() for a,g in models.items() for i,m in enumerate(g) for n,v in m.state_dict().items()}
        immutable=parameters();np.savez(OUT/'All9_Immutable_Parameters_Before.npz',**immutable)
        for seed in p['remaining_author_seeds']:
            try:bound()
            except TimeoutError:partial=True;break
            d=OUT/f'seed{seed:03d}';d.mkdir();world={'seed':seed,'root_status':'UNKNOWN','algorithms':[]};worlds.append(world);context.clear();context.update(seed=seed,algorithm='root',step=0)
            try:
                env.__dict__.clear();env.__dict__.update(copy.deepcopy(template));env.reset(seed)
                for n,tab,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(env.network[tab][col].to_numpy(),recipes[n][seed])
                root=copy.deepcopy(env.__dict__);binary(d/'Root_Complete_ENV.pkl',root);world.update(root_status='RETURNED',root_receipt=current_receipt,root_physical_signature=signature(env.network),root_metrics=metrics(env.network.res_bus.vm_pu.to_numpy()),root_ENV_sha256=sha(d/'Root_Complete_ENV.pkl'))
            except BaseException as exc:
                world.update(failure_type=type(exc).__name__,failure=str(exc));event('root_unknown',seed=seed,failure_type=type(exc).__name__)
                if isinstance(exc,TimeoutError):partial=True;break
                continue
            for algorithm in p['algorithms']:
                branch={'algorithm':algorithm,'status':'UNKNOWN','steps':[]};world['algorithms'].append(branch);env.__dict__.clear();env.__dict__.update(copy.deepcopy(root));last=np.zeros((3,1));state=env.state.copy();context.update(algorithm=algorithm)
                try:
                    for step in range(1,101):
                        bound();context['step']=step;sd=d/f'{algorithm}_{step:03d}';sd.mkdir();packet={'seed':seed,'algorithm':algorithm,'next_step':step,'remaining_source_horizon':101-step,'environment':copy.deepcopy(env.__dict__),'last_Q':last.copy(),'state':state.copy(),'history':branch['steps'].copy(),'paid_registry':{k[0]:{'kwargs':k[1],'receipt':v['index']} for k,v in cache.items()},'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'absolute_deadline_monotonic':deadline,'costs':costs.copy(),'protocol_sha256':sha(PREP/'Protocol.json')};binary(sd/'Full_Cursor.pkl',packet)
                        loaded=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());assert loaded['remaining_source_horizon']==101-step and loaded['absolute_deadline_monotonic']==deadline and np.array_equal(loaded['state'],state);cold=env.__class__.__new__(env.__class__);cold.__dict__.update(loaded['environment']);assert signature(cold.network)==signature(env.network);raw=[]
                        for i,m in enumerate(models[algorithm]):
                            costs['agent_forward_attempts']+=1;event('agent_forward_attempt',agent=i,**context);t=time.perf_counter()
                            with torch.no_grad():a=m.get_action(np.asarray([loaded['state'][i]]))
                            costs['agent_forward_returns']+=1;assert a.shape==(1,) and np.isfinite(a).all();raw.append(a.copy());event('agent_forward_return',agent=i,seconds=time.perf_counter()-t,**context)
                        raw=np.asarray(raw);action=last-np.clip(raw,-.3,.3);before_sig=signature(cold.network);state,reward,_,done=cold.step_Preward(action,last-action);env=cold;vm=env.network.res_bus.vm_pu.to_numpy(copy=True);row={'step':step,'before_physical_signature':before_sig,'controlled_vm_before':loaded['state'].tolist(),'raw_policy':raw.tolist(),'last_Q_Mvar':last.tolist(),'absolute_Q_Mvar':action.tolist(),'controlled_vm_after':state.tolist(),'all13_vm_after':vm.tolist(),'native_done':bool(done),'reward':float(reward),'PF_receipt':current_receipt,'cursor_sha256':sha(sd/'Full_Cursor.pkl'),**metrics(vm)};put(sd/'Decision.json',row);branch['steps'].append(row);last=action.copy();event('native_policy_step',**context,UV=row['UV'],OV=row['OV'],done=bool(done));put(d/f'{algorithm}_Progress_{step:03d}.json',{'last_completed_step':step,'receipt':current_receipt})
                        if done:break
                    branch.update(status='COMPLETE_NATIVE_EPISODE',endpoint=branch['steps'][-1],terminal='SOURCE_CONTROLLED_DONE' if done else 'SOURCE100_STEP_LIMIT');event('native_episode_complete',seed=seed,algorithm=algorithm,steps=step,**metrics(vm))
                except BaseException as exc:
                    branch.update(failure_type=type(exc).__name__,failure=str(exc));event('episode_unknown',seed=seed,algorithm=algorithm,type=type(exc).__name__)
                    if isinstance(exc,TimeoutError):partial=True;break
            put(d/'World_Result.json',world)
            # Do not retain solved NETs indefinitely. Registry keeps all exact input
            # keys within this seed; noncontrolled regime is unique across seeds.
            cache.clear();attempted.clear()
            if partial:break
        final_parameters=parameters();assert all(np.array_equal(v,final_parameters[n]) for n,v in immutable.items());np.savez(OUT/'All9_Immutable_Parameters_After.npz',**final_parameters)
        complete=not partial and len(worlds)==499 and all(w['root_status']=='RETURNED' and len(w['algorithms'])==3 and all(a['status']=='COMPLETE_NATIVE_EPISODE' for a in w['algorithms']) for w in worlds)
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_ALL499_REMAINING_AUTHOR_CASES_ALL3_NATIVE_POLICIES' if complete else 'TERMINAL_PARTIAL_REMAINING_AUTHOR_COHORT','worlds':worlds,'unentered_seeds':p['remaining_author_seeds'][len(worlds):],'receipts':receipts,'costs':costs,'workflow_seconds':time.monotonic()-began,'original_seed0_evidence_reused_not_rerun':p['seed0_closed_evidence'],'our_full_model_new_model_or_superiority_result':'UNKNOWN_NOT_MEASURED_BY_EXTERNAL_BASELINE_STAGE','native_vs_common':'Source-native3controlled strict done and original100steps; full13 UV/OV reported. Native policies have no added HierGrid guard; common-wrapper/adapted rows are separate, not silently equated.'};put(OUT/'Result.json',result);put(OUT/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(OUT/'Result.json'));stream.close();put(OUT/'Closed_Manifest.json',{'files':[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()],'journal_last_sha256':previous});print(result['status'])
    except BaseException as exc:
        put(OUT/'Failure.json',{'type':type(exc).__name__,'failure':str(exc),'traceback':traceback.format_exc(),'costs':costs,'worlds':worlds,'receipts':receipts,'workflow_seconds':time.monotonic()-began});stream.close();raise
if __name__=='__main__':main()
