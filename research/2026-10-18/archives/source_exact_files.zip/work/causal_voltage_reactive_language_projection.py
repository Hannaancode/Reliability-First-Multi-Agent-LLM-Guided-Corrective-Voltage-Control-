"""Explicit partial current-state view; not a lossless full-table claim."""
import json, math, copy
from candidate_predictor_input_contract import validate_observation, Q_GRID

SYSTEM=("Current grid state for a shunt proposal. V lists voltage_pu by bus ID0..117. "
        "G rows:[generator_id,bus_id,current_Q_MVAr,limit_pair_id,voltage_command_id]. "
        "L lists [min_Q_MVAr,max_Q_MVAr]; C lists generator voltage commands_pu. "
        "R rows:[reference_id,bus_id,voltage_command_pu]. A lists added shunt [bus_id,MVAr] differing from default0.0. "
        "P gives raw common-and-zone legal bus lists; Q gives original Q_MVAr by Q_index. M gives current global metrics. "
        "Return exactly null to abstain or one JSON object with integer bus and Q_index; "
        "bus must occur in P and total added support at that bus must stay<=450MVAr. No explanation.")

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def finite(v):
    assert type(v) in (int,float) and math.isfinite(v)
    return v
def frame(f):return {i:dict(zip(f['columns'],row)) for i,row in zip(f['index'],f['values'])}

def project(model_input,added):
    assert set(model_input)=={'current_physical_observation','original_Q_grid'} and model_input['original_Q_grid']==list(Q_GRID)
    obs=model_input['current_physical_observation'];validate_observation(obs)
    assert type(added) is list and len(added)==118 and all(type(x) in (int,float) and math.isfinite(x) and 0<=x<=450 for x in added)
    tables=obs['physical_tables'];b=frame(tables['res_bus']);g=frame(tables['gen']);q=frame(tables['res_gen']);r=frame(tables['ext_grid'])
    assert set(b)==set(range(118)) and set(g)==set(q) and len(g)==53
    assert all(v['in_service'] is True and v['reactive_capability_curve'] is False for v in g.values())
    return {'current_bus_voltage_pu':[finite(b[i]['vm_pu']) for i in range(118)],
            'current_generators':[[i,int(g[i]['bus']),finite(q[i]['q_mvar']),finite(g[i]['min_q_mvar']),finite(g[i]['max_q_mvar']),finite(g[i]['vm_pu'])] for i in sorted(g)],
            'current_references':[[i,int(r[i]['bus']),finite(r[i]['vm_pu'])] for i in sorted(r)],
            'current_added_support_MVAr_by_bus':copy.deepcopy(added),
            'raw_common_and_zone_pools':copy.deepcopy(obs['raw_common_and_zone_pools']),
            'current_global_metrics':copy.deepcopy(obs['global_metrics']),'original_Q_grid':list(Q_GRID)}

def encode(selected):
    limits=[];commands=[];li={};ci={};gen=[]
    for gid,bus,q0,lo,hi,cmd in selected['current_generators']:
        lk=canonical([lo,hi]);ck=canonical(cmd)
        if lk not in li:li[lk]=len(limits);limits.append([lo,hi])
        if ck not in ci:ci[ck]=len(commands);commands.append(cmd)
        gen.append([gid,bus,q0,li[lk],ci[ck]])
    return {'V':copy.deepcopy(selected['current_bus_voltage_pu']),'G':gen,'L':limits,'C':commands,
            'R':copy.deepcopy(selected['current_references']),
            'A':[[i,x] for i,x in enumerate(selected['current_added_support_MVAr_by_bus']) if canonical(x)!=canonical(0.)],
            'P':copy.deepcopy(selected['raw_common_and_zone_pools']),'M':copy.deepcopy(selected['current_global_metrics']),
            'Q':copy.deepcopy(selected['original_Q_grid'])}

def decode(encoded):
    assert set(encoded)=={'V','G','L','C','R','A','P','M','Q'} and len(encoded['V'])==118
    added=[0.]*118;seen=set()
    for b,q in encoded['A']:
        assert type(b) is int and 0<=b<118 and b not in seen and finite(q)>=0;seen.add(b);added[b]=q
    return {'current_bus_voltage_pu':copy.deepcopy(encoded['V']),
            'current_generators':[[gid,bus,q0,*encoded['L'][li],encoded['C'][ci]] for gid,bus,q0,li,ci in encoded['G']],
            'current_references':copy.deepcopy(encoded['R']),'current_added_support_MVAr_by_bus':added,
            'raw_common_and_zone_pools':copy.deepcopy(encoded['P']),'current_global_metrics':copy.deepcopy(encoded['M']),
            'original_Q_grid':copy.deepcopy(encoded['Q'])}

def compile_context(model_input,added):
    selected=project(model_input,added);encoded=encode(selected);restored=decode(encoded)
    assert restored==selected
    for name in selected:
        assert canonical(restored[name])==canonical(selected[name]),name
    return {'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':canonical(encoded)}],
            'selected_same_information_input':selected,'encoded':encoded,'no_rounding_or_truncation':True,
            'partial_projection_not_full_table_information':True,
            'omitted_from_language_view':['bus_voltage_angles','line_load_transformer_impedance_tables','active_power_tables','other_full_table_fields'],
            'full_table_physics_prior_and_stronger_numerical_controls_remain_required':True}

def parse_command(text,selected):
    value=json.loads(text)
    if value is None:return None
    assert type(value) is dict and set(value)=={'bus','Q_index'}
    bus,j=value['bus'],value['Q_index'];assert type(bus) is int and type(j) is int and 0<=bus<118 and 0<=j<9
    assert bus in {b for pool in selected['raw_common_and_zone_pools'].values() for b in pool}
    assert selected['current_added_support_MVAr_by_bus'][bus]+selected['original_Q_grid'][j]<=450.
    return {'bus':bus,'q_abs_mvar':selected['original_Q_grid'][j]}
