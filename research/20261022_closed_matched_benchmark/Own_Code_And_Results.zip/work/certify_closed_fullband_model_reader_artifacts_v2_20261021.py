"""Additive saved-only terminal certification; no repeated model/audit phase.

The original launcher PID-ACK assertion and missing reader OS exit code remain
failures/UNKNOWN. Closed source-bound reader artifacts are assessed separately.
"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'
E = R / 'outputs/native13_fullband_original_adapter_engineering_execution_20261021'
A = R / 'outputs/native13_fullband_original_adapter_engineering_independent_20261021'
H = R / 'outputs/native13_fullband_original_adapter_engineering_handoff_20261021'
O = R / 'outputs/native13_fullband_model_terminal_artifact_certification_v2_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    from coordinate_native_inverter_linear_reference_20261020 import process
    for directory, source in [(E, 'run_native13_fullband_original_adapter_colab_20261021.py'),
                              (A, 'audit_native13_fullband_original_adapter_engineering_20261021.py'),
                              (H, 'coordinate_native13_fullband_original_adapter_engineering_20261021.py')]:
        claim = read(directory / 'owner.claim')
        actual = process(claim['actual_pid'])
        assert not actual or source not in (actual.get('CommandLine') or '')
        assert claim['source_sha256'] == sha(R / 'work' / source)
    primary_end = read(R / 'outputs/native13_fullband_original_adapter_engineering_coordination_20261021/End_ACK.json')
    assert primary_end['actual_owned_chain_ended'] and primary_end['exit_code'] == 0
    status = read(E / 'status.json')
    assert status['runtime_released'] and status['all_actual_closed_artifacts_preserved'] and status['scientific_process_ended'] and status['remote_exit_code'] == 0
    manifest = read(A / 'Closed_Manifest.json')
    assert set(manifest) == {'owner.claim', 'Independent_Functional_Audit.json', 'Frozen_After.json'}
    for n, item in manifest.items():
        assert (A / n).stat().st_size == item['bytes'] and sha(A / n) == item['sha256']
    lock = read(P / 'Independent_Reader_Lock.json')
    assert sha(R / lock['source']) == lock['sha256'] == read(A / 'owner.claim')['source_sha256']
    before = read(P / 'Launch_Readiness_Audit.json')['frozen_original_checks']
    after = read(A / 'Frozen_After.json')
    assert before['checks'] == after['checks'] and before['all_passed'] and after['all_passed']
    assert len(before['checks']) == 9 and all(before['checks'].values())
    independent = read(A / 'Independent_Functional_Audit.json')
    assert independent['status'].startswith('PASS_INDEPENDENT_')
    assert independent['fixed_functional_gate'] == 'FAIL_FIXED_FULLBAND_ORIGINAL_ADAPTER_INTERFACE_STOP_NO_RETUNING'
    assert independent['actual_model_costs']['generation_returns'] == 12
    owner_log = R / 'outputs/native13_fullband_original_adapter_engineering_reader_coordination_20261021/Owner.log'
    printed = json.loads(owner_log.read_text(encoding='utf-8').strip())
    assert all(printed[k] == independent[k] for k in printed)
    original_failure = H / 'Reader_Owner_Protocol.json.log'
    assert 'AssertionError' in original_failure.read_text(encoding='utf-8')
    assert read(H / 'Reader_Owner_Protocol.json.End.json')['exit_code'] == 1
    O.mkdir(exist_ok=False)
    record = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_ADDITIVE_SAVED_ONLY_SOURCE_BOUND_READER_COMPLETION_ARTIFACT_CERTIFICATION',
              'all_original_model_reader_coordinator_actors_ended': True,
              'primary_actual_OS_exit': 0, 'actual_runtime_released': True,
              'original_coordinator_reader_launcher_stage_exit': 1,
              'original_reader_OS_exit_code': 'UNRECOVERED_UNKNOWN_NEVER_REPLACED_WITH_ZERO',
              'original_launcher_assertion': 'Preserved. Source-bound reader emitted full audit, frozen proof, closed manifest and success footer before PID ACK could be certified. Fast-exit observation race is an inference, not a recovered OS trace.',
              'source_bound_reader_completed_artifacts': True,
              'independent_audit_sha256': sha(A / 'Independent_Functional_Audit.json'),
              'original_failure_log_sha256': sha(original_failure),
              'fixed_functional_gate': independent['fixed_functional_gate'],
              'actual_model_costs_reused_not_reexecuted': independent['actual_model_costs'],
              'strict_legal_or_null_primary_outputs': 0,
              'actual_new_model_PF_optimizer_or_repeated_independent_phase_calls': 0,
              'decision': 'STOP this fixed native full-band interface and its conditional physical rollout. Preserve all12 outputs. Do not repair generated placeholders, switch prompts/models/decoders, or claim original-paper model performance on federation.',
              'all9_before_and_after_frozen_checks_exact_and_PASS': True,
              'distinct_frozen_audit_timestamps_retained': [before['audited_at_utc'], after['audited_at_utc']],
              'original_saved_only_metadata_assertion_failure_retained': 'outputs/native13_fullband_model_terminal_artifact_certification_preparation_failure_20261021/Failure.json',
              'all6finalgoals': 'OPEN'}
    with (O / 'Terminal_Artifact_Certification.json').open('x', encoding='utf-8') as f:
        json.dump(record, f, indent=2)
    print(json.dumps({k: record[k] for k in ['status', 'original_reader_OS_exit_code', 'fixed_functional_gate', 'actual_new_model_PF_optimizer_or_repeated_independent_phase_calls']}))


if __name__ == '__main__':
    main()
