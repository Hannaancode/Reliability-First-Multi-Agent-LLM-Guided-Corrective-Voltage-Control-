"""New full-observed-table/graph numerical process prototype; no LLM/solver.

Every saved typed record reaches the cell encoder. Pooling, FP32 conditioning
and one graph message step are architectural choices, not lossless state claims.
Capacity width follows the measured original adapter parameter count only.
"""
import torch
from torch import nn
from vcsa_common_information_control import ByteEncoder
from vcsa_modules_v2 import StateEncoder

class TableGraphProcessControl(nn.Module):
    def __init__(self,semantic_types,*,target_parameters=8798208):
        super().__init__()
        self.field=nn.Embedding(semantic_types,32)
        self.text=ByteEncoder()
        self.cells=nn.Sequential(nn.Linear(76,64),nn.Tanh(),nn.Linear(64,64),nn.LayerNorm(64),nn.Tanh())
        self.graph=StateEncoder(13,64,118)
        self.process=nn.Sequential(nn.Linear(960,64),nn.Tanh(),nn.Linear(64,9*7))
        fixed=sum(p.numel() for p in self.parameters())
        self.capacity_width=min(range(1,16385),key=lambda h:(abs(fixed+1025*h+896-target_parameters),h))
        self.global_query=nn.Sequential(nn.Linear(128,self.capacity_width),nn.Tanh(),nn.Linear(self.capacity_width,896))
        self.actual_parameters=sum(p.numel() for p in self.parameters())
        self.target_parameters=target_parameters
        assert abs(self.actual_parameters-target_parameters)/target_parameters<.001
    def encode(self,x):
        assert set(x)=={'field_ids','kind','numeric','coordinates','value_bytes','node_features','adjacency','zone_ids','allowed_actions'}
        device=next(self.parameters()).device
        field=x['field_ids'].to(device);kind=x['kind'].to(device);numeric=x['numeric'].to(device);coordinates=x['coordinates'].to(device)
        assert field.shape[0]==kind.shape[0]==numeric.shape[0]==coordinates.shape[0]==len(x['value_bytes'])
        # Empty strings have exactly zero features/gradients in ByteEncoder.
        # Avoid evaluating thousands of empty padded sequences; keep all cells.
        present=[i for i,s in enumerate(x['value_bytes']) if s]
        value=self.field.weight.new_zeros((len(x['value_bytes']),32))
        if present:
            encoded=self.text([x['value_bytes'][i] for i in present],device)
            value=value.index_copy(0,torch.tensor(present,device=device),encoded)
        cells=self.cells(torch.cat([self.field(field),value,kind,numeric,coordinates],-1))
        global_cells=cells.mean(0,keepdim=True)
        features=x['node_features'].to(device)[None]
        assert features.shape==(1,118,13) and bool(torch.isfinite(features).all())
        nodes=self.graph(features,torch.arange(118,device=device)[None],x['zone_ids'].to(device)[None],
                         x['adjacency'].to(device)[None],torch.ones(1,118,dtype=torch.bool,device=device))
        global_query=self.global_query(torch.cat([global_cells,nodes.mean(1)],-1))
        return nodes,global_query
    def forward(self,x):
        nodes,query=self.encode(x)
        result=self.process(torch.cat([nodes,query[:,None,:].expand(-1,118,-1)],-1)).reshape(118,9,7)
        assert bool(torch.isfinite(result).all())
        return result

def process_objective(prediction,target):
    """Actual measured labels only. No new reward, missing-successor imputation.

    Channels: accepted, converged, one-step UVzero, then four measured gains.
    Finite adjacent-Q differences are supported samples, not AC Jacobians.
    """
    assert prediction.shape==(118,9,7)
    classification=[]
    for channel in range(3):
        mask=target['classification_mask'][...,channel]
        if bool(mask.any()):
            classification.append(nn.functional.binary_cross_entropy_with_logits(prediction[...,channel][mask],target['classification'][...,channel][mask]))
    finite=target['regression_mask']
    assert classification and bool(finite.any())
    regression=nn.functional.mse_loss(prediction[...,3:][finite],target['regression'][finite])
    pairs=finite[:,:-1]&finite[:,1:]
    factor=prediction.new_tensor([1.,1.,1.,1.,1.,.5,.5,.5])[None,:,None]
    if bool(pairs.any()):
        actual=(target['regression'][:,1:]-target['regression'][:,:-1])*factor
        forecast=(prediction[:,1:,3:]-prediction[:,:-1,3:])*factor
        contrast=nn.functional.mse_loss(forecast[pairs],actual[pairs])
    else:contrast=prediction.sum()*0.
    class_loss=torch.stack(classification).mean()
    total=class_loss+regression+contrast
    return total,{'classification':float(class_loss.detach()),'measured_global_gain':float(regression.detach()),
                  'measured_adjacent_Q_response':float(contrast.detach()),'supported_Q_pairs':int(pairs.sum())}
