"""Sole sequential reference coordinator, exact fresh ACKs and one reader.

Never starts an old owner or retries a scientific/reader process. A partial
stops further launch; all remaining identities are explicitly unexecuted.
"""
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime,timedelta,timezone
from pathlib import Path

from native_continuation_preservation_v2 import canonical,extended_local_path
from paid_spatial_controller_checkpoint_v1 import process_alive
from paid_spatial_storage_guard_v1 import EvidenceStorageGuard
from trusted_causal_controller_snapshot import write_bytes

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def inventory():
    query="Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','pythonw.exe') -and $_.CommandLine -and ($_.CommandLine -match 'launch_spatial_DSE_reference_screen_20261012.py|run_spatial_DSE_reference_screen_20261012.py|run_spatial_DSE_reference_replay_20261012.py|audit_spatial_DSE_reference_screen_20261012.py') } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    r=subprocess.run(['powershell','-NoProfile','-Command',query],capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
    assert r.returncode==0;v=json.loads(r.stdout) if r.stdout.strip() else [];return v if isinstance(v,list) else [v]


def status(value):
    tmp=BASE/'owner_status.tmp';write_bytes(tmp,canonical(value));tmp.replace(BASE/'owner_status.json')


def main():
    p=read(BASE/'preparation/Protocol.json');ph=sha(BASE/'preparation/Protocol.json')
    assert read(BASE/'preparation/Readiness.json')['status']=='PASS_PRE_OUTCOME'
    assert not (BASE/'coordinator.claim').exists()
    assert all(r['ProcessId'] in (os.getpid(),os.getppid()) for r in inventory())
    for n,d in p['source_sha256'].items():assert sha(ROOT/n)==d,n
    claim={'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'protocol_sha256':ph,'source_sha256':sha(Path(__file__))}
    write_bytes(BASE/'coordinator.claim',canonical(claim));(BASE/'Job_Launches').mkdir(exist_ok=False)
    start=time.perf_counter();deadline=datetime.now(timezone.utc)+timedelta(seconds=p['total_science_resource_seconds'])
    storage=EvidenceStorageGuard(extended_local_path(BASE),p['total_storage_bytes']);entries=[]
    state={'actual_pid':os.getpid(),'stage':'sequential_references','absolute_deadline_utc':deadline.isoformat(),
        'current':None,'finished_jobs':[],'paid_reuse_jobs':[s['job_id'] for s in p['jobs'] if s.get('reused_prior_science')]}
    status(state)
    try:
        for spec in p['jobs']:
            if spec.get('reused_prior_science'):continue
            assert datetime.now(timezone.utc)<deadline;storage.admit()
            job=spec['job_id'];root_limit=deadline
            # Four prospective branches per root share the fixed root bound.
            existing=[e for e in entries if e['root']==spec['root']]
            if existing:root_limit=datetime.fromisoformat(existing[0]['root_absolute_deadline_utc'])
            else:root_limit=min(deadline,datetime.now(timezone.utc)+timedelta(seconds=p['per_root_seconds']))
            branch_deadline=min(root_limit,datetime.now(timezone.utc)+timedelta(seconds=p['per_branch_with_replay_seconds']))
            write_bytes(BASE/'Job_Launches'/(job+'.json'),canonical({'job_id':job,'absolute_branch_deadline_utc':branch_deadline.isoformat(),
                'root_absolute_deadline_utc':root_limit.isoformat(),'original_total_deadline_utc':deadline.isoformat(),'no_extension':True}))
            entry={'job_id':job,'root':spec['root'],'root_absolute_deadline_utc':root_limit.isoformat()}
            for phase,script in [('branch','run_spatial_DSE_reference_screen_20261012.py'),('replay','run_spatial_DSE_reference_replay_20261012.py')]:
                assert datetime.now(timezone.utc)<branch_deadline;storage.admit()
                folder=extended_local_path(BASE/('branches' if phase=='branch' else 'replays')/job);assert not folder.exists()
                cmd=[str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(ROOT/'work'/script),'--job',job]
                began=time.perf_counter()
                with (BASE/(job+'_'+phase+'_stdout.log')).open('x',encoding='utf8') as so,(BASE/(job+'_'+phase+'_stderr.log')).open('x',encoding='utf8') as se:
                    child=subprocess.Popen(cmd,cwd=ROOT,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
                    state['current']={'job_id':job,'phase':phase,'launcher_pid':child.pid,'command':cmd};status(state)
                    while not (folder/'owner.claim').exists() and child.poll() is None:
                        assert datetime.now(timezone.utc)<branch_deadline;time.sleep(.2)
                    assert (folder/'owner.claim').exists() and child.poll() is None
                    actual=read(folder/'owner.claim');rows=[r for r in inventory() if r['ProcessId']==actual['actual_pid']]
                    assert len(rows)==1 and rows[0]['ParentProcessId']==actual['actual_parent_pid'] and actual['actual_parent_pid'] in (child.pid,os.getpid())
                    assert script in rows[0]['CommandLine'] and '--job '+job in rows[0]['CommandLine']
                    assert actual['protocol_sha256']==ph and actual['source_sha256']==p['source_sha256']['work/'+script]
                    tmp=folder/'Launcher_ACK.tmp';write_bytes(tmp,canonical({**actual,'exact_PID_parent_command_verified':True,
                        'fresh_CIM_identity':rows[0],'absolute_branch_deadline_utc':branch_deadline.isoformat()}));tmp.replace(folder/'Launcher_ACK.json')
                    state['current']['actual_pid']=actual['actual_pid'];status(state)
                    code=child.wait()
                entry[phase]={'actual_pid':actual['actual_pid'],'actual_parent_pid':actual['actual_parent_pid'],'launcher_pid':child.pid,
                    'exit_code':code,'owned_seconds':time.perf_counter()-began,'command':cmd}
                write_bytes(BASE/(job+'_'+phase+'_Owner_Ended.json'),canonical(entry[phase]))
                assert not process_alive(actual['actual_pid']) and not process_alive(child.pid)
                assert code==0 and read(folder/'Closed_Manifest.json')['exit_code']==0
            entries.append(entry);state['finished_jobs'].append(job);state['current']=None;status(state)
            write_bytes(BASE/'Ownership_And_Costs.json',canonical({'entries':entries,'all_new_owners_ended_exit0':False}))
        write_bytes(BASE/'Ownership_And_Costs.json',canonical({'entries':entries,'all_new_owners_ended_exit0':True,
            'science_coordinator_seconds':time.perf_counter()-start,'complete_global_storage_scan_costs':{'scans':storage.scans,'seconds':storage.scan_seconds},
            'all_missing_and_preparation_failure_costs_separate_not_free':True,'absolute_deadline_utc':deadline.isoformat()}))
        state['stage']='sole_zero_science_external_reader';status(state)
        with (BASE/'reader_stdout.log').open('x',encoding='utf8') as so,(BASE/'reader_stderr.log').open('x',encoding='utf8') as se:
            began=time.perf_counter();reader=subprocess.Popen([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',
                str(ROOT/'work/audit_spatial_DSE_reference_screen_20261012.py')],cwd=ROOT,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
            write_bytes(BASE/'Reader_Launch.json',canonical({'launcher_pid':reader.pid,'sole_reader':True}));code=reader.wait()
        write_bytes(BASE/'Reader_Ended.json',canonical({'launcher_pid':reader.pid,'exit_code':code,'owned_seconds':time.perf_counter()-began}));assert code==0
        state.update(stage='complete_independent_reference_audit',exit_code=0,headroom=read(BASE/'independent_audit/Necessary_Headroom_Bound.json')['bound']['decision'])
    except BaseException as exc:
        state.update(stage='terminal_partial_or_reader_failure_no_retry',exit_code=1,failure_type=type(exc).__name__,message=str(exc),
            'unexecuted_jobs':[s['job_id'] for s in p['jobs'] if not s.get('reused_prior_science') and s['job_id'] not in state['finished_jobs']],
            'all_learning_opportunity_gates':'UNKNOWN')
        write_bytes(BASE/'Coordinator_Failure.json',canonical(state))
    finally:status(state)
    if state['exit_code']:raise SystemExit(1)


if __name__=='__main__':main()
