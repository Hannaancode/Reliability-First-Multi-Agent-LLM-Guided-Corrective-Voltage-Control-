"""Original AST-only FIRST_ZONE serving path, without physics or auto-execution.

Current fields and candidates must be bound by the local saved-root producer.
Only the original source's first call and conditional error reprompt run here.
"""
import ast
import json
from collections import deque
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    'base': 'work/e/audit/phase2g_multiagent_llm_runner.py',
    'rescue': 'work/e/audit/phase2g_rescue_runner.py',
    'runner': 'work/e/audit/phase2g_llm_guided_rescue_runner.py',
    'reflection': 'work/e/audit/run_reflection_v4_safety_envelope.py',
}
FUNCTIONS = {
    'base': ['generate_response', 'extract_json'],
    'rescue': ['normalize_action'],
    'runner': ['action_bus', 'validate_action_against_candidates'],
    'reflection': ['_safe_bus_q', 'init_feedback_state', 'build_compact_feedback_text',
                   'severity_stage', 'build_two_best_prompt_v2',
                   'normalize_compact_or_nested_action', 'get_llm_action_required_two_best_v2'],
}


def definitions(kind, links=None):
    path = ROOT / FILES[kind]
    tree = ast.parse(path.read_text(encoding='utf-8'))
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in FUNCTIONS[kind]]
    assert {n.name for n in nodes} == set(FUNCTIONS[kind])
    env = {'json': json, 'deque': deque, 'MAX_NEW_TOKENS': 384,
           'ALLOWED_Q': [25, 50, 75, 100, 125, 150, 200, 250, 300], **(links or {})}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), env)
    return env


def original_query(item, generate, *, torch_module=None, model=None, tokenizer=None):
    base = definitions('base', {'torch': torch_module})
    rescue = SimpleNamespace(**definitions('rescue'))
    runner_env = definitions('runner')
    runner = SimpleNamespace(**runner_env)
    runner.rescue = rescue
    runner.base_runner = SimpleNamespace(**base)
    # The actual factory computed this exact current-root candidate list using
    # the unchanged native helper. This sealed adapter does not search or expand.
    runner.get_zone_candidate_buses = lambda *_: list(item['candidate_buses'])
    runner.base_runner.generate_response = generate
    ref = definitions('reflection', {'runner': runner})
    return ref['get_llm_action_required_two_best_v2'](
        model, tokenizer, None, item['zone'], None, item['zone_state'],
        item['global_uv'], [], ref['init_feedback_state'](), 'reflection_v2')


def initial_messages(item):
    ref = definitions('reflection')
    return ref['build_two_best_prompt_v2']('reflection_v2', item['zone_state'],
                item['global_uv'], item['candidate_buses'], [], ref['init_feedback_state']())
