"""Frozen first-only native checkpoint/observation/actuator engineering, CPU."""
import hashlib,json,os,pickle,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/tpa_native_one_step_preparation_20261020';OUT=ROOT/'outputs/tpa_native_one_step_engineering_v3_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();protocol=json.loads((ROOT/'outputs/tpa_native_one_step_preparation_v3_20261020/Execution_Protocol.json').read_text(encoding='utf-8'))
    assert sha(Path(__file__))==protocol['sources'][Path(__file__).name]
    for name,h in protocol['sources'].items():assert sha(ROOT/'work'/name)==h
    assert json.loads((ROOT/'outputs/tpa_checkpoint_loader_engineering_v3_20261020/Result.json').read_text(encoding='utf-8'))['status']=='PASS_CPU_SAFE_LOAD_STRICT_AUTHOR_STATE_AND_HEADLESS_IMPORT'
    claim={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(ROOT/'outputs/tpa_native_one_step_preparation_v3_20261020/Execution_Protocol.json')};put(OUT/'owner.claim',claim)
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    costs={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'policy_attempts':0,'policy_returns':0,'checkpoint_loads':0,'optimizer_backward_training_LLM_GPU_calls':0};journal=(OUT/'Journal.jsonl').open('x',encoding='utf-8');prev='0'*64
    def event(kind,**fields):
        nonlocal prev
        row={'kind':kind,'elapsed_seconds':time.monotonic()-start,'previous':prev,**fields};raw=json.dumps(row,sort_keys=True,separators=(',',':'));prev=hashlib.sha256(raw.encode()).hexdigest();journal.write(json.dumps({'event':row,'sha256':prev})+'\n');journal.flush();os.fsync(journal.fileno());assert time.monotonic()-start<protocol['worker_bound_seconds']
    try:
        from candidate_process_evidence_utils import frozen_checks
        put(OUT/'Frozen_Before.json',frozen_checks())
        import tpa_native_runtime_binding_20261020 as runtime
        b=runtime.bridge;np=b.np;torch=b.torch;pd=b.pd
        import pandapower as pp
        import copy
        from types import SimpleNamespace
        from pandapower.pypower.makeSbus import makeSbus
        from utilities.util import prep_obs,translate_action
        torch.set_num_threads(1);torch.manual_seed(53);np.random.seed(53)
        args,native=runtime.prepare_args();cls,astproof=b.headless_environment_class();env=cls.__new__(cls)
        config=b.yaml.safe_load((b.AUTHOR/'args/env_args/var_voltage_control.yaml').read_text(encoding='utf-8'))['env_args'];config.update(mode='distributed',episode_limit=480,action_scale=.8,action_bias=0.,q_weight=.1)
        env.args=SimpleNamespace(**config);env.action_space=SimpleNamespace(low=-.8,high=.8);env.episode_limit=480;env.tp=100;env.time_dims=3;env.history=1;env.state_space=config['state_space'];env.n_agents=38;env.n_actions=1;env.steps=1;env.sum_rewards=0.;env.start_idx=100
        env.voltage_loss_type='l1';env.voltage_weight=1.;env.q_weight=.1;env.line_weight=None;env.total_voltage_weight=None;env.independ_reward=False;env.v_upper=1.05;env.v_lower=.95
        window=np.load(PREP/'Exact_Native_Window.npz');wm=json.loads((PREP/'Input_Window_Manifest.json').read_text(encoding='utf-8'));assert sha(PREP/'Exact_Native_Window.npz')==wm['NPZ_sha256']
        data={}
        for row in wm['files']:
            key=Path(row['entry']).stem;arr=window[key];assert hashlib.sha256(arr.tobytes()).hexdigest()==row['values_sha256']
            data[key]=pd.DataFrame(arr,index=pd.to_datetime(row['timestamps']),columns=row['columns'][1:])
        env.pv_data=data['pv_active'];env.active_demand_data=data['load_active'];env.reactive_demand_data=data['load_reactive']
        env.pv_histories=window['pv_active'][100:];env.active_demand_histories=window['load_active'][100:];env.reactive_demand_histories=window['load_reactive'][100:]
        maxima=json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text(encoding='utf-8'))['native_column_max'];env.p_max=np.array(maxima);env.factor=1.2;env.s_max=1.2*env.p_max
        source=ROOT/'outputs/benchmark_priority_20261020/MAPDN/static_network_objects/case322_3min_final.p';event('native_NET_conversion_attempt',source_sha256=sha(source));
        from tpa_native_legacy_import_20261020 import import_native
        net,legacy_proof=import_native(pp,source);put(OUT/'Legacy_Import_Proof.json',legacy_proof);event('native_NET_conversion_return',pandapower_version=pp.__version__)
        env.base_powergrid=copy.deepcopy(net);env.powergrid=copy.deepcopy(net);env.pv_index=net.sgen['bus'].sort_index().to_numpy(copy=True);env.region=np.append(np.unique(net.bus['zone'].to_numpy(copy=True)),'all')
        env._set_demand_and_pv(add_noise=False);random_fraction=env.get_action();env.powergrid.sgen['q_mvar']=env._clip_reactive_power(random_fraction,env.powergrid.sgen['p_mw']);np.save(OUT/'Initial_Fractions.npy',random_fraction)
        original_runpp=pp.runpp;captures=[]
        def tracked(net,*a,**kw):
            index=costs['PF_attempts'];assert index<2 and not a and not kw,'Only exact two native default primary PF calls'
            before=OUT/f'PF{index}_before.pkl'
            with before.open('xb') as f:pickle.dump(net,f,protocol=5)
            costs['PF_attempts']+=1;event('PF_attempt',number=index,before_sha256=sha(before));t=time.monotonic()
            try:result=original_runpp(net)
            except BaseException as e:costs['PF_exceptions']+=1;event('PF_exception',number=index,exception=type(e).__name__,seconds=time.monotonic()-t);raise
            costs['PF_returns']+=1;assert net.converged
            fields={}
            for table in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']:
                fields[table]=net[table].select_dtypes(include=[np.number]).to_numpy(dtype=np.float64)
            v=net._ppc['internal']['V'];y=net._ppc['internal']['Ybus'];s=makeSbus(net._ppc['baseMVA'],net._ppc['bus'],net._ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(y@v)-s)));assert kcl<=1e-7
            np.savez(OUT/f'PF{index}_fields.npz',**fields);vm=net.res_bus.vm_pu.to_numpy(copy=True);assert np.isfinite(vm).all()
            capture={'number':index,'UV':int(np.sum(vm<.95)),'OV':int(np.sum(vm>1.05)),'vmin':float(vm.min()),'vmax':float(vm.max()),'KCL_max_pu':kcl,'seconds':time.monotonic()-t,'fields_sha256':sha(OUT/f'PF{index}_fields.npz')};captures.append(capture);event('PF_return',**capture);return result
        pp.runpp=tracked
        pp.runpp(env.powergrid)
        root_vm=env.powergrid.res_bus.vm_pu.to_numpy(copy=True);observation=env.get_obs();assert np.array_equal(root_vm,env.powergrid.res_bus.vm_pu.to_numpy(copy=True))
        env._cal_mask();env._cal_adj_matrix()
        assert np.array_equal(args.obs_bus_num,env.get_obs_bus_num()) and np.array_equal(args.agent2region,env.get_agent2region()) and np.array_equal(args.agent_index_in_obs,env.get_agent_index_in_obs())
        assert all(np.array_equal(a,c) for a,c in zip(args.region_adj,env.get_region_adj()))
        obs=prep_obs(observation['agents_obs']).contiguous().view(1,38,args.obs_size);history=prep_obs(observation['time_obs']).contiguous().view(38,100,3);month=observation['month']
        assert torch.isfinite(obs).all() and torch.isfinite(history).all();np.savez(OUT/'Causal_Native_Observation.npz',obs=obs.numpy(),history=history.numpy(),month=month)
        def policy_application(model,label):
            module_calls={'encoder':0,'policy_head':0};handles=[]
            for name,module in [('encoder',model.encoder),('policy_head',model.policy_dicts[0])]:
                def hook(_m,_i,_o,key=name):module_calls[key]+=1
                handles.append(module.register_forward_hook(hook))
            costs['policy_attempts']+=1;event('policy_attempt',identity=label);t=time.monotonic()
            with torch.no_grad():action,_,_,_,hidden=model.get_actions(obs,history,month,status='test',exploration=False,actions_avail=torch.tensor(env.get_avail_actions()),target=False,last_hid=model.policy_dicts[0].init_hidden())
            for h in handles:h.remove()
            costs['policy_returns']+=1;assert module_calls=={'encoder':1,'policy_head':1};assert torch.isfinite(action).all()
            event('policy_return',identity=label,module_calls=module_calls,seconds=time.monotonic()-t);return action.detach().clone()
        event('checkpoint_load_attempt',identity='primary');model,state=b.load_policy(args);costs['checkpoint_loads']+=1;event('checkpoint_load_return',identity='primary',strict_state=True)
        action=policy_application(model,'primary');np.save(OUT/'Native_Raw_Action.npy',action.numpy());_,fractions=translate_action(args,action,env)
        assert fractions.shape==(38,) and np.isfinite(fractions).all() and np.max(np.abs(fractions))<=.8+1e-7;np.save(OUT/'Native_Scaled_Fractions.npy',fractions)
        del model,state;torch.manual_seed(159);event('checkpoint_load_attempt',identity='fresh_cold');cold,_=b.load_policy(args);costs['checkpoint_loads']+=1;event('checkpoint_load_return',identity='fresh_cold',strict_state=True)
        replay=policy_application(cold,'fresh_cold');np.save(OUT/'Native_Cold_Raw_Action.npy',replay.numpy());assert torch.equal(action,replay),'Cold model policy output not exact'
        expected_q=np.sqrt(env.s_max**2-env.powergrid.sgen.p_mw.to_numpy()**2)*fractions
        assert env._take_action(fractions);assert np.array_equal(expected_q,env.powergrid.sgen.q_mvar.to_numpy())
        pp.runpp=original_runpp
        assert costs['PF_attempts']==costs['PF_returns']==2 and costs['policy_attempts']==costs['policy_returns']==2
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PRIMARY_NATIVE_ONE_STEP_ENGINEERING_COMPLETE_AWAITING_INDEPENDENT_REPLAY','identity':protocol['identity'],'costs':costs,'native_observation_shape':list(obs.shape),'native_history_shape':list(history.shape),'cold_policy_exact':True,'headless_AST_proof':astproof,'PF':captures,'workflow_seconds':time.monotonic()-start,'native_runtime':'CPU PyTorch2.10/pandapower3.4 compatibility port, not byte-identical historical CUDA reproduction','benchmark_or_LLM_superiority_claim':False}
        put(OUT/'Frozen_After.json',frozen_checks());put(OUT/'Result.json',result);event('closed',result_sha256=sha(OUT/'Result.json'))
        journal.close();files=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()];put(OUT/'Closed_Manifest.json',{'files':files,'journal_last_sha256':prev,'costs':costs})
        print(json.dumps({'status':result['status'],'costs':costs,'engineering_UV':[x['UV'] for x in captures],'engineering_OV':[x['OV'] for x in captures]}))
    except BaseException as e:
        put(OUT/'Failure.json',{'failure_type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'costs':costs,'workflow_seconds':time.monotonic()-start});journal.close();raise
if __name__=='__main__':main()
