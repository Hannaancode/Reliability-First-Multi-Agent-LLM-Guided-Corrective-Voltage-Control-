"""Source-bound operator admission, with labelled synthetic NumPy semantics only."""
from pathlib import Path
from datetime import datetime, timezone
from types import SimpleNamespace
import ast, hashlib, json, time
import numpy as np

R=Path(__file__).resolve().parents[1]
O=R/'outputs/common118_external_bellman_contract_20261029'
A=R/'outputs/published_voltage_source_intake_20261022/blthayer__drl-powerworld'
U=R/'outputs/common118_external_bellman_source_20261029'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    started=time.perf_counter(); O.mkdir(exist_ok=False)
    files={'author_dqn':A/'source/experiments/dqn_mod.py','author_train':A/'source/experiments/train.py',
           'requirements':A/'source/requirements.txt','constants':A/'source/experiments/constants.py',
           'upstream_dqn':U/'dqn.py','upstream_graph':U/'build_graph.py',
           'upstream_pin':U/'Upstream_Pin.json','author_pin':A/'Pinned_Commit.json'}
    text={k:p.read_text(encoding='utf-8') for k,p in files.items()}
    author=ast.parse(text['author_dqn']); cls=next(n for n in author.body if isinstance(n,ast.ClassDef) and n.name=='DQNUniqueActions')
    assert [ast.unparse(n) for n in cls.bases]==['DQN']
    assert not any(isinstance(n,ast.FunctionDef) and n.name=='setup_model' for n in cls.body)
    calls=[n for n in ast.walk(cls) if isinstance(n,ast.Call)]
    replay=[n for n in calls if ast.unparse(n.func)=='self.replay_buffer.add']
    assert len(replay)==1 and [ast.unparse(n) for n in replay[0].args]==['obs','action','rew','new_obs','float(done)']
    trainers=[n for n in calls if ast.unparse(n.func)=='self._train_step']
    assert len(trainers)==3
    assert all([ast.unparse(x) for x in n.args[:7]]==['obses_t','actions','rewards','obses_tp1','obses_tp1','dones','weights'] for n in trainers)
    assert 'action_arr[np.argmin(np.isin(action_arr, action_list))]' in text['author_dqn']
    assert 'action_list.append(action)' in text['author_dqn']
    patches=[n for n in ast.walk(ast.parse(text['author_train'])) if isinstance(n,ast.Call) and ast.unparse(n.func)=='patch']
    targets=[ast.literal_eval(n.args[0]) for n in patches]
    assert targets==['stable_baselines.deepq.build_graph.build_act']
    assert 'stable-baselines == 2.9.0' in text['requirements']
    assert 'double_q=True' in text['constants']
    dqn=ast.parse(text['upstream_dqn'])
    setup=next(n for n in ast.walk(dqn) if isinstance(n,ast.FunctionDef) and n.name=='setup_model')
    builds=[n for n in ast.walk(setup) if isinstance(n,ast.Call) and ast.unparse(n.func)=='build_train']
    assert len(builds)==1 and {k.arg:ast.unparse(k.value) for k in builds[0].keywords}['double_q']=='self.double_q'
    graph=ast.parse(text['upstream_graph'])
    branch=next(n for n in ast.walk(graph) if isinstance(n,ast.If) and ast.unparse(n.test)=='double_q' and any(isinstance(x,ast.Assign) and ast.unparse(x.targets[0])=='q_tp1_best_using_online_net' for x in n.body))
    assigns={ast.unparse(n.targets[0]):n for n in ast.walk(graph) if isinstance(n,ast.Assign) and len(n.targets)==1}
    op=[branch,assigns['q_tp1_best_masked'],assigns['q_t_selected_target']]
    names={n.id for x in op for n in ast.walk(x) if isinstance(n,ast.Name)}
    assert not names.intersection({'action_list','action_mask','legal_actions','next_action_mask'})
    module=ast.fix_missing_locations(ast.Module(body=op,type_ignores=[]))
    extracted=ast.unparse(module); (O/'Extracted_Upstream_Formula.txt').write_text(extracted,encoding='utf-8')
    class TensorShim:
        argmax=staticmethod(np.argmax);reduce_sum=staticmethod(np.sum);reduce_max=staticmethod(np.max)
        @staticmethod
        def one_hot(indices,n): return np.eye(n,dtype=np.float64)[indices]
    rows=[]
    for label,online,target,legal,done,double in [
        ('excluded_high_value_next_action',[2,1000,3],[50,10000,7],[True,False,True],0,True),
        ('all_actions_legal',[2,1000,3],[50,10000,7],[True,True,True],0,True),
        ('terminal_transition',[2,1000,3],[50,10000,7],[True,False,True],1,True),
        ('non_double_q_branch',[2,1000,3],[50,10000,7],[True,False,True],0,False),
    ]:
        env=dict(tf=TensorShim,double_q=double,double_q_values=np.array([online],dtype=float),target_policy=SimpleNamespace(q_values=np.array([target],dtype=float)),n_actions=3,done_mask_ph=np.array([done],dtype=float),rew_t_ph=np.array([1.]),gamma=.5)
        exec(compile(module,'<exact-source-formula-with-numpy-shim>','exec'),env)
        selected=int(np.argmax(np.where(legal,online,-np.inf))) if double else int(np.argmax(np.where(legal,target,-np.inf)))
        masked=1+.5*(1-done)*target[selected]
        rows.append(dict(label=label,online=online,target=target,legal=legal,done=done,double_q=double,reward=1,gamma=.5,source_formula=float(env['q_t_selected_target'][0]),history_aware_formula=float(masked)))
    assert [x['source_formula'] for x in rows]==[5001,5001,1,5001]
    assert [x['history_aware_formula'] for x in rows]==[4.5,5001,1,26]
    out=dict(status='SOURCE_CONTRACT_PROOF_AND_FOUR_LABELLED_FORMULA_CHECKS_COMPLETE',at_utc=datetime.now(timezone.utc).isoformat(),
      sources={k:dict(path=p.relative_to(R).as_posix(),sha256=sha(p)) for k,p in files.items()},
      inheritance='Author DQNUniqueActions inherits upstream setup_model; author training patches build_act only.',
      replay_arguments=[ast.unparse(n) for n in replay[0].args],training_call_lines=[n.lineno for n in trainers],
      operator_lines=[x.lineno for x in op],operator_ast_sha256=hashlib.sha256(ast.dump(module).encode()).hexdigest(),
      source_filter='History filters behavior selection; no history mask is supplied to the inherited Bellman operator.',
      checks=rows,execution_scope='Only extracted arithmetic AST under a small NumPy shim; no TensorFlow, author model, environment, PF, training, or GPU execution.',
      native_performance_effect='UNKNOWN; source-contract difference is not measured degradation, a universal bug, or a new contribution by itself.',
      next_decision='A common-task study must distinguish a faithful inherited-target port from a separately named action-masked target control. Include both when scientifically justified; do not silently repair or weaken a published comparator.',
      causal_state_gate='Full current attempt/rejection history and future-action support are still required. The 33 saved current states do not provide full attempt histories.',
      new_model_PF_optimizer_derivative_calls=0,workflow_seconds=time.perf_counter()-started)
    (O/'Source_Contract_Proof.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(dict(status=out['status'],checks=len(rows),new_science=0)))
if __name__=='__main__': main()
