"""Fixed all500/100-round receding-policy integration, PREPARATION ONLY.

New optimizer and PF entry are HARD DISABLED. Existing exact first-proposal
mathematics and independently verified physical receipts can be reused by a
future frozen owner. No main starts a campaign. Ordinary SLSQP callbacks are
charged computations; deduplication is at complete proposal-context level only.
"""
from pathlib import Path
import base64
import copy
import hashlib
import io
import json
import os
import random
import socket
import sys
import time
import numpy as np

from remaining85_certified_loader_20261029 import load_certified_case
from remaining85_source_binder_v2_20261029 import DataUnpickler, physical_signature
from nonlinear13_current_state_20261029 import pack_current_state, load_current_state, SCHEMA, AUXILIARY_SOURCE, PQ_SOURCE
from nonlinear500_paid_snapshot_v2_20261029 import PaidSnapshot
from nonlinear13_preserved_solver_v3_20261029 import RECIPE
from remaining85_nonlinear_kernel_20261029 import original_guard

ENGINE_SOURCE = 'work/nonlinear13_receding_policy_engine_v2_20261030.py'
NEW_OPTIMIZER_ENTRY_ENABLED = False
NEW_PF_ENTRY_ENABLED = False
PHYSICAL_KWARGS = {'algorithm': 'bfsw', 'init': 'dc'}
MECHANISM_SOURCES = [
    'work/nonlinear13_preserved_solver_v3_20261029.py',
    'work/nonlinear13_analytic_derivatives_20261029.py',
    'work/nonlinear13_validated_kernel_v2_20261029.py',
    'work/remaining85_nonlinear_kernel_20261029.py',
]


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def typed(value):
    """Exact type/container/array fingerprint; bool/int/float never collapse."""
    if isinstance(value, np.ndarray):
        need(not value.dtype.hasobject, 'Object array cannot be numeric state')
        return {'type': 'array', 'dtype': value.dtype.str, 'shape': list(value.shape),
                'bytes': base64.b64encode(np.ascontiguousarray(value).tobytes()).decode()}
    if isinstance(value, np.generic):
        return {'type': 'numpy_scalar', 'value': typed(np.asarray(value))}
    if isinstance(value, dict):
        return {'type': 'dict', 'items': [[typed(k), typed(v)] for k, v in value.items()]}
    if isinstance(value, (list, tuple)):
        return {'type': type(value).__name__, 'items': [typed(v) for v in value]}
    return {'type': type(value).__name__, 'value': value}


def serial(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), default=serial, allow_nan=False).encode()


def read_ref(root, reference):
    p = (Path(root)/reference['path']).resolve()
    p.relative_to(Path(root).resolve())
    raw = p.read_bytes()
    if 'prefix_bytes' in reference:
        n = reference['prefix_bytes']
        need(type(n) is int and 0 <= n <= len(raw), 'Invalid frozen prefix')
        raw = raw[:n]
    need(sha(raw) == reference['sha256'], 'Changed referenced evidence: '+reference['path'])
    return raw


def net_from_ref(root, reference):
    need(reference.get('kind') in ('NET', 'ENV'), 'Unspecified network container')
    saved = DataUnpickler(io.BytesIO(read_ref(root, reference))).load()
    return saved['network'] if reference.get('kind') == 'ENV' else saved


def safe_candidate(net, before_q, u):
    """The data-shim NET is not deepcopyable. Copy its mapping and Q table only."""
    candidate = dict(net)
    candidate['sgen'] = net['sgen'].copy(deep=True)
    need(np.array_equal(net['sgen'].q_mvar.to_numpy()[:3], before_q), 'Before NET/Q mismatch')
    candidate['sgen'].loc[candidate['sgen'].index[:3], 'q_mvar'] = np.asarray(before_q)-np.asarray(u, dtype=np.float32)
    return candidate


def same_physical_tables(a, b):
    import pandas as pd
    def names(net):
        return {k for k, v in net.items() if isinstance(v, pd.DataFrame) and not k.startswith(('res_', '_'))}
    need(names(a) == names(b), 'Paid NET physical table set changed')
    need(all(a[k].equals(b[k]) for k in names(a)), 'Paid NET changed noncontrolled plant')


def validate_owner_times(protocol, ack, now):
    values = [protocol['absolute_deadline_monotonic'], protocol['original_deadline_monotonic'],
              ack['absolute_deadline_monotonic'], ack['original_deadline_monotonic'],
              ack['owner_started_monotonic'], now]
    need(all(type(v) is float and np.isfinite(v) for v in values), 'Nonfinite/untyped owner clock')
    need(len(set(values[:4])) == 1, 'Original deadline changed or unauthenticated')
    need(0 <= values[4] <= now < values[0], 'Expired/invalid owner clock')
    return values[0]


class PostCommitPreservationError(RuntimeError):
    """An already journaled decision remains authoritative even without a cursor."""
    def __init__(self, state, paid, history, stage, cause):
        super().__init__('UNKNOWN_POST_COMMIT_PRESERVATION_'+stage+': '+str(cause))
        self.state = copy.deepcopy(state)
        self.paid = copy.deepcopy(paid)
        self.history = copy.deepcopy(history)
        self.stage = stage
        self.cause = repr(cause)


def clock_domain():
    import psutil
    return {'host': socket.gethostname(), 'boot_time_unix': psutil.boot_time(),
            'monotonic_implementation': time.get_clock_info('monotonic').implementation}


class OwnerGate:
    """Fresh supervisor ACK must bind actual process, sources and original clock."""
    def __init__(self, root, protocol_ref, ack_ref):
        self.root = Path(root).resolve()
        self.protocol_ref = protocol_ref
        self.protocol = json.loads(read_ref(root, protocol_ref))
        self.ack = json.loads(read_ref(root, ack_ref))
        p, a = self.protocol, self.ack
        need(p['cases'] == list(range(500)) and p['horizon'] == 100 and p['recipe'] == RECIPE, 'Changed population/horizon/recipe')
        need(p['physical_kwargs'] == PHYSICAL_KWARGS and p['score_epsilon'] == 1e-8, 'Changed fixed role/scoring')
        need(a['protocol_sha256'] == protocol_ref['sha256'] and a['campaign_id'] == p['campaign_id'], 'ACK protocol identity mismatch')
        need(a['actual_pid'] == os.getpid() and a['actual_parent_pid'] == os.getppid()
             and a['actual_argv'] == sys.argv and a['fresh_exact_source_PID_parent_command'] is True, 'Unowned process')
        need(p['clock_domain'] == a['clock_domain'] == clock_domain(), 'Wrong host/boot/monotonic clock')
        self.deadline = validate_owner_times(p, a, time.monotonic())
        required_sources = MECHANISM_SOURCES + [ENGINE_SOURCE, 'work/nonlinear13_current_state_20261029.py',
            'work/nonlinear500_paid_snapshot_v2_20261029.py', 'work/remaining85_certified_loader_20261029.py',
            'work/remaining85_source_binder_v2_20261029.py', AUXILIARY_SOURCE, PQ_SOURCE]
        need(set(required_sources) <= p['sources'].keys(), 'Engine dependencies absent from source lock')
        for path, digest in p['sources'].items():
            read_ref(root, {'path': path, 'sha256': digest})
        self.check()

    def check(self, cursor=None):
        need(clock_domain() == self.protocol['clock_domain'], 'Owner clock domain changed')
        if time.monotonic() >= self.deadline:
            raise TimeoutError('Original authenticated deadline exhausted; no renewal')
        if cursor is not None:
            need(cursor['owner_protocol_ref'] == self.protocol_ref, 'Cursor belongs to another owner protocol')
            need(cursor['absolute_deadline_monotonic'] == cursor['original_deadline_monotonic'] == self.deadline, 'Cursor deadline altered')
            need(cursor['clock_domain'] == canonical(self.protocol['clock_domain']).decode(), 'Cursor clock differs from owner')
            need(cursor['next_step'] <= 100 and cursor['stop_status'] is None, 'Terminal/horizon cursor cannot propose')


class CostLedger:
    def __init__(self):
        self.numeric = {}
        self.unknown = {}
        self.retained_by_receipt = {}

    def add(self, numeric, unknown=None):
        for key, value in numeric.items():
            need(type(value) in (int, float) and np.isfinite(value) and value >= 0, 'Nonnumeric/negative cost')
            self.numeric[key] = self.numeric.get(key, 0) + value
        for key, value in (unknown or {}).items():
            need(isinstance(value, str) and value.startswith('UNKNOWN'), 'Unknown cost must remain explicit')
            if key in self.unknown:
                need(self.unknown[key] == value, 'Conflicting unknown cost descriptions')
            self.unknown[key] = value

    def retain(self, identity, evidence):
        if identity in self.retained_by_receipt:
            need(self.retained_by_receipt[identity] == evidence, 'Paid cost lineage changed')
        else:
            self.retained_by_receipt[identity] = evidence


class EventJournal:
    def __init__(self, root, path, owner):
        self.root, self.path, self.owner = Path(root), Path(path), owner
        self.stream = self.path.open('xb')
        self.previous, self.rows, self.bytes = '0'*64, [], 0
        self.costs = CostLedger()

    def event(self, kind, numeric=None, unknown=None, **data):
        self.owner.check()
        event = dict(seq=len(self.rows), kind=kind, previous=self.previous,
                     numeric_cost=numeric or {}, unknown_cost=unknown or {}, **data)
        raw = canonical(event)
        digest = sha(raw)
        line = canonical({'event': event, 'sha256': digest}) + b'\n'
        need(self.bytes + len(line) <= self.owner.protocol['journal_byte_cap'], 'Original journal capacity exhausted')
        self.stream.write(line); self.stream.flush(); os.fsync(self.stream.fileno())
        self.costs.add(event['numeric_cost'], event['unknown_cost'])
        self.bytes += len(line); self.previous = digest; self.rows.append(event)
        return event['seq']

    def reference(self):
        self.stream.flush()
        return {'path': self.path.relative_to(self.root).as_posix(), 'prefix_bytes': self.bytes,
                'sha256': sha(self.path.read_bytes()[:self.bytes])}

    def close(self):
        self.stream.close()


class PaidProvenance:
    """Read-only original receipt and cost lineage. No reconstruction of physics.

    Snapshot v2 deliberately keeps metadata private. This additional metadata
    read is charged explicitly; it cannot silently be called a free cache hit.
    Original sources are cached only after their frozen hashes are verified.
    """
    def __init__(self, root, manifest_ref):
        self.root, self.manifest_ref = Path(root), manifest_ref
        self.costs = {'metadata_bytes_read': 0, 'evidence_bytes_read': 0}
        self.cache = {}
        raw = read_ref(root, manifest_ref); self.costs['metadata_bytes_read'] += len(raw)
        manifest = json.loads(raw)
        directory = Path(manifest_ref['path']).parent
        def metadata(name):
            raw = read_ref(root, {'path': (directory/name).as_posix(), 'sha256': manifest[name]['sha256']})
            self.costs['metadata_bytes_read'] += len(raw)
            return json.loads(raw)
        self.registry = metadata('Paid_Physical_Registry.json')
        self.bindings = metadata('Source_Bindings.json')

    def source(self, path):
        need(path in self.bindings, 'Original receipt/cost source lacks frozen binding: '+path)
        reference = {'path': path, 'sha256': self.bindings[path]['sha256']}
        if path not in self.cache:
            raw = read_ref(self.root, reference)
            self.costs['evidence_bytes_read'] += len(raw)
            self.cache[path] = raw
        return self.cache[path], reference

    def evidence(self, signature, kwargs, reuse):
        key = signature+'|'+json.dumps(kwargs, sort_keys=True)
        entry = self.registry['entries'].get(key)
        need(entry and entry['reuse'] == reuse and entry['status'] == 'REUSABLE_AUDITED_EXACT_KEY', 'Unbound physical provenance')
        numeric, unknown, originals, references = {}, {}, [], {}
        cert = reuse['independent_certificate']; _, references[cert] = self.source(cert)
        seen_costs = set()
        for item in entry['provenance']:
            path = item.get('original_source') or item.get('source')
            raw, ref = self.source(path); references[path] = ref
            preserved = {'registry_provenance': copy.deepcopy(item), 'source_ref': ref}
            row = None
            if 'original_pointer' in item:
                row = json.loads(raw)
                for token in item['original_pointer'].strip('/').split('/'):
                    token = token.replace('~1', '/').replace('~0', '~')
                    row = row[int(token)] if isinstance(row, list) else row[token]
                need(row['status'] == item['original_status'] == 'RETURNED', 'Original root/physics status changed')
                need(row['physical_signature'] == signature and row['kwargs'] == kwargs
                     and row['after_sha256'] == reuse['after']['sha256'], 'Original receipt identity changed')
                preserved['original_receipt'] = row
            elif 'line' in item:
                rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
                attempt = rows[item['line']-1]
                need(attempt['sha256'] == item['event_sha256'], 'Original attempt event changed')
                event = attempt['event']
                need(event['kwargs'] == kwargs and event['kind'] == 'PF_attempt', 'Original attempt initializer changed')
                returns = [r for r in rows[item['line']:] if r['event'].get('kind') == 'PF_return'
                           and r['event'].get('number') == event.get('number')
                           and r['event'].get('label') == event.get('label')
                           and r['event'].get('kwargs') == kwargs
                           and r['event'].get('physical_input_sha256') == event.get('physical_input_sha256')]
                need(len(returns) <= 1, 'Ambiguous original returned physical receipt')
                if returns:
                    row = returns[0]['event']; preserved['original_return_event'] = returns[0]
                else:
                    need(item.get('status') == 'ATTEMPTED_WITHOUT_PRIMARY_RETURN_EVENT'
                         and item.get('independent_recovery_certificate'), 'Missing original return lacks independent recovery')
                    unknown['original_primary_return_seconds'] = 'UNKNOWN: original primary return absent; recovered receipt is not a new call'
                preserved['original_attempt_event'] = attempt
            elif item.get('original_status') == 'ATTEMPTED_WITHOUT_PRIMARY_RETURN_EVENT':
                need(item.get('recovery') and item.get('independent_certificate'), 'Unverified missing primary return')
                preserved['original_status'] = item['original_status']
            else:
                # Historical index is itself preserved and checked, never recast
                # as an original primary receipt or numeric cost measurement.
                index = json.loads(raw)
                mapping = index.get('returned_exact_initializer_entries', {})
                if item.get('mapping_key') in mapping:
                    old = mapping[item['mapping_key']]
                    need(old['physical_signature'] == signature and old['kwargs'] == kwargs
                         and old['after_sha256'] == reuse['after']['sha256'], 'Historical paid index identity changed')
                    preserved['audited_historical_entry'] = old
                else:
                    unknown['unparsed_original_receipt'] = 'UNKNOWN: no supported original primary receipt selector; reference retained'
            if row is not None and 'seconds' in row:
                cost_id = path+'|'+str(item.get('original_pointer', item.get('line')))
                if cost_id not in seen_costs:
                    value = row['seconds']
                    need(type(value) in (int, float) and np.isfinite(value) and value >= 0, 'Invalid historical physical timer')
                    numeric[cost_id+'.seconds'] = value; seen_costs.add(cost_id)
            originals.append(preserved)
        need(originals, 'No original paid provenance')
        if not numeric:
            unknown['primary_physical_seconds'] = 'UNKNOWN: no source-bound numeric primary timer found'
        unknown['full_historical_physical_setup_and_reader_costs'] = 'UNKNOWN: complete original setup/internal/replay totals not reconstructed; all source/certificate refs retained; timer zero is not free'
        return {'identity': key, 'manifest_ref': self.manifest_ref, 'reuse': reuse,
                'originals': originals, 'references': list(references.values()),
                'numeric': numeric, 'unknown': unknown}


def counter_delta(before, after, prefix):
    need(set(before) <= set(after), 'Cost counter disappeared')
    delta = {}
    for key, value in after.items():
        need(type(value) is int and value >= before.get(key, 0), 'IO cost counter went backwards')
        delta[prefix+key] = value-before.get(key, 0)
    return delta


def proposal_identity(model, sources):
    names = ['Y', 'V_current', 'ppc_bus', 'ppc_gen', 'baseMVA', 'lookup', 'control',
             'current_vm', 'current_q', 'control_scaling', 'control_in_service']
    state = {name: typed(getattr(model, name)) for name in names}
    return sha(canonical({'state': state, 'initial_vector': typed(model.initial_vector()),
                          'recipe': RECIPE, 'mechanism_sources': {p: sources[p] for p in MECHANISM_SOURCES}}))


def endpoint(vm):
    vm = np.asarray(vm)
    return {'UV': int(np.sum(vm < .95)), 'OV': int(np.sum(vm > 1.05)),
            'strict_fullband': bool(np.all((vm >= .95) & (vm <= 1.05))),
            'common_epsilon_fullband': bool(np.all((vm >= .95-1e-8) & (vm <= 1.05+1e-8)))}


def verify_decision(before_q, before_vm, proposal, candidate_q, candidate_vm):
    """C1: join actual native action, returned Q/VM, unchanged guard and commit."""
    u = np.asarray(proposal['u'], dtype=np.float32)
    need(u.shape == (3,) and np.isfinite(u).all() and np.all(np.abs(u) <= np.float32(.3)), 'Invalid native action')
    expected = np.asarray(before_q) - u
    need(np.array_equal(expected, candidate_q) and np.array_equal(proposal['next_q'], candidate_q), 'Proposal/receipt Q mismatch')
    need(np.asarray(candidate_vm).shape == (13,) and np.isfinite(candidate_vm).all(), 'Invalid returned voltage')
    accepted = original_guard(np.asarray(before_vm), np.asarray(candidate_vm))
    return u, accepted, expected if accepted else np.asarray(before_q).copy(), np.asarray(candidate_vm if accepted else before_vm).copy()


def verify_paid_event(root, paid):
    """Rebind actual receipt bytes and NET arrays; never evaluates equations."""
    receipt = json.loads(read_ref(root, paid['receipt_ref']))
    need(receipt['status'] == 'RETURNED' and receipt['new_physics'] is False, 'Unverified physical receipt')
    need(receipt['after'] == paid['after_NET']['path'] and receipt['after_sha256'] == paid['after_NET']['sha256']
         and receipt['physical_signature'] == paid['candidate_signature'] and receipt['kwargs'] == PHYSICAL_KWARGS,
         'Paid receipt fields differ from event')
    need(receipt['context_key'] == paid['context_key'] and receipt['proposal_ref'] == paid['proposal_ref'], 'Receipt math identity changed')
    actual = net_from_ref(root, paid['after_NET'])
    need(physical_signature(actual) == paid['candidate_signature'], 'Paid candidate signature changed')
    need(np.array_equal(actual['sgen'].q_mvar.to_numpy()[:3], paid['candidate_Q'])
         and np.array_equal(actual['res_bus'].vm_pu.to_numpy(), paid['candidate_vm']), 'Paid candidate arrays changed')
    proposal = json.loads(read_ref(root, paid['proposal_ref']))
    need(np.array_equal(proposal['u'], paid['proposal']['u']) and np.array_equal(proposal['next_q'], paid['proposal']['next_q']), 'Saved proposal differs from paid context')
    for ref in receipt['provenance']['cost_lineage']['references']:
        read_ref(root, ref)


def verify_root_event(root, event):
    receipt = json.loads(read_ref(root, event['root_receipt_ref']))
    ref = event['root']; net = net_from_ref(root, ref)
    need(receipt['status'] == 'RETURNED' and receipt['new_physics'] is False
         and receipt['kwargs'] == {'algorithm': 'bfsw'}, 'Original root initializer/status changed')
    need(receipt['after'] == ref['path'] and receipt['after_sha256'] == ref['sha256']
         and physical_signature(net) == receipt['physical_signature'] == ref['physical_signature'], 'Root artifact substituted')
    need(np.array_equal(net['sgen'].q_mvar.to_numpy()[:3], event['initial_Q'])
         and np.array_equal(net['res_bus'].vm_pu.to_numpy(), event['initial_vm']), 'Root endpoint substituted')
    for evidence_ref in receipt['provenance']['cost_lineage']['references']:
        read_ref(root, evidence_ref)


def replay_semantics(events, root=None, *, synthetic=False):
    """C2: semantic replay of proposal/physical joins, costs and terminal steps.

    Receipt hash/NET/guard checks happen on admission; independent reader must
    repeat those evidence joins. This replay rejects invalid event ordering and
    cost/cache claims, rather than treating a hash chain as a semantic proof.
    """
    need(root is not None or synthetic, 'Actual semantic replay requires saved evidence root')
    ledger, pending, returned, physics, decisions, terminals = CostLedger(), set(), {}, {}, {}, set()
    committed, rejected = {}, set()
    for e in events:
        kind = e['kind']; key = e.get('context_key')
        if kind == 'case_entered':
            need(e['seed'] not in committed, 'Root was entered twice')
            if not synthetic:
                verify_root_event(root, e)
            committed[e['seed']] = (e['root'], e['initial_Q'], e['initial_vm'])
        elif kind == 'math_attempt':
            need(key not in pending and key not in returned, 'Repeated attempted math identity')
            pending.add(key)
        elif kind == 'math_return':
            need(key in pending, 'Math return without attempt')
            pending.remove(key); returned[key] = e['proposal_ref']
        elif kind == 'math_import':
            need(key not in pending and key not in returned and e['independent_reader_ref'], 'Invalid paid math import')
            returned[key] = e['proposal_ref']
        elif kind == 'math_reuse':
            need(key in returned and e['proposal_ref'] == returned[key]
                 and e['numeric_cost'] == {'complete_proposal_reuses': 1}, 'Unreturned/free/substituted math reuse')
        elif kind == 'physics_paid_return':
            need(e['context_key'] in returned and e['lookup_status'] == 'VERIFIED_EXACT_PAID_REUSE'
                 and e['numeric_cost'] == {'paid_physics_reuses': 1}, 'Unverified/free physics reuse')
            need(e['proposal_ref'] == returned[key], 'Physical event uses another mathematical proposal')
            if not synthetic:
                verify_paid_event(root, e)
            physics[e['seq']] = e
        elif kind == 'decision':
            case = e['seed']; step = e['step']
            need(case in committed and case not in terminals and case not in rejected
                 and step == decisions.get(case, 0)+1, 'Invalid decision order/continuation')
            previous_ref, previous_q, previous_vm = committed[case]
            need(e['before_NET'] == previous_ref and np.array_equal(e['before_Q'], previous_q)
                 and np.array_equal(e['before_vm'], previous_vm), 'Previous committed state was substituted')
            paid = physics[e['physical_event']]
            need(paid['seed'] == case and paid['step'] == step and paid['receipt_ref'] == e['candidate_receipt_ref']
                 and paid['context_key'] == key and e['math_ref'] == returned[key] == paid['proposal_ref'], 'Receipt/decision/math cross-join')
            need(e['candidate_NET'] == paid['after_NET'] and e['candidate_signature'] == paid['candidate_signature']
                 and np.array_equal(e['candidate_Q'], paid['candidate_Q']) and np.array_equal(e['candidate_vm'], paid['candidate_vm'])
                 and e['proposal'] == paid['proposal'], 'Candidate fields substituted after physical return')
            u, accepted, q, vm = verify_decision(e['before_Q'], e['before_vm'], e['proposal'], e['candidate_Q'], e['candidate_vm'])
            need(accepted == e['accepted'] and np.array_equal(q, e['committed_Q']) and np.array_equal(vm, e['committed_vm']), 'Guard/commit evidence differs')
            need(e['committed_NET'] == (paid['after_NET'] if accepted else e['before_NET']), 'Committed NET was not guarded candidate/hold')
            need(e['numeric_cost'] == {'control_decisions': 1, 'accepted_commits': int(accepted), 'rejected_candidates': int(not accepted)}, 'Decision costs mismatch')
            decisions[case] = step
            committed[case] = (e['committed_NET'], e['committed_Q'], e['committed_vm'])
            if not accepted: rejected.add(case)
        elif kind == 'episode_terminal':
            case = e['seed']
            need(case in committed and case not in terminals, 'Unentered/duplicate episode terminal')
            ref, q, vm = committed[case]
            need(e['final_NET'] == ref and np.array_equal(e['final_Q'], q) and np.array_equal(e['final_vm'], vm)
                 and e['steps'] == decisions.get(case, 0), 'Terminal endpoint differs from authoritative committed chain')
            metrics = endpoint(e['final_vm'])
            if e['status'] == 'COMPLETE_STRICT_BAND': need(metrics['strict_fullband'], 'False band terminal')
            elif e['status'] == 'COMPLETE_ORIGINAL100_HORIZON': need(decisions.get(e['seed'], 0) == 100, 'False horizon terminal')
            elif e['status'] == 'COMPLETE_GUARD_HOLD_STOP': need(case in rejected, 'False guard terminal')
            else: need(e['status'].startswith('UNKNOWN'), 'Unrecognized terminal status')
            terminals.add(e['seed'])
        elif kind == 'paid_cost_lineage':
            ledger.retain(e['identity'], e['evidence'])
        ledger.add(e['numeric_cost'], e['unknown_cost'])
    return ledger


class RecedingEngine:
    def __init__(self, root, output_directory, owner):
        self.root, self.owner = Path(root).resolve(), owner
        self.out = (self.root/output_directory).resolve(); self.out.relative_to(self.root)
        self.out.mkdir(exist_ok=False)
        self.journal = EventJournal(self.root, self.out/'policy.jsonl', owner)
        self.paid_snapshot = PaidSnapshot(self.root, owner.protocol['paid_registry_manifest']['sha256'])
        self.provenance = PaidProvenance(self.root, owner.protocol['paid_registry_manifest'])
        self.journal.event('paid_metadata_loaded', counter_delta({}, self.paid_snapshot.costs, 'snapshot.')
                           | counter_delta({}, self.provenance.costs, 'provenance.'))
        self.math, self.attempted_math = {}, set()
        self.results = []

    def put(self, name, value):
        p = self.out/name
        with p.open('xb') as f:
            raw = canonical(value); f.write(raw); f.flush(); os.fsync(f.fileno())
        return {'path': p.relative_to(self.root).as_posix(), 'sha256': sha(raw), 'bytes': len(raw)}

    def import_first_paid_math(self):
        """Mandatory exact seed0step1 receipt reuse; never repeat its optimizer."""
        refs = self.owner.protocol['first_paid_math']
        p = json.loads(read_ref(self.root, refs['protocol']))
        result = json.loads(read_ref(self.root, refs['proposal']))
        audit = json.loads(read_ref(self.root, refs['independent_reader']))
        closed = json.loads(read_ref(self.root, refs['closed_manifest']))
        closed_files = {r['path']: r['sha256'] for r in closed['files']}
        need(closed_files['Proposal_Result.json'] == refs['proposal']['sha256'], 'First math is not closed')
        need(p['seed'] == 0 and p['recipe'] == RECIPE and result['status'] == 'ADMITTED_UNMEASURED_PROPOSAL'
             and audit['status'] == 'PASS_FIRST_SAVED_NUMERICAL_PROPOSAL_AND_COST_EVIDENCE', 'Unadmitted first math')
        for path in MECHANISM_SOURCES:
            need(p['sources_and_gates'][path] == self.owner.protocol['sources'][path], 'First math mechanism changed')
        model, binding = load_certified_case(self.root, 0)
        need(binding['pack'] == p['input_pack'] and binding['root'] == p['input_root'], 'First math input changed')
        key = proposal_identity(model, self.owner.protocol['sources'])
        self.math[key] = {'proposal': result, 'proposal_ref': refs['proposal'], 'reader_ref': refs['independent_reader']}
        retained_numeric, retained_unknown = {}, {}
        for group in ['costs', 'kernel_costs']:
            for name, value in result[group].items():
                target = retained_numeric if type(value) in (int, float) else retained_unknown
                target[group+'.'+name] = value
        retained_numeric['independent_reader.workflow_seconds'] = audit['workflow_seconds']
        self.retain_cost(refs['proposal']['sha256'],
            {'references': refs, 'numeric': retained_numeric, 'unknown': retained_unknown})
        self.journal.event('math_import', context_key=key, proposal_ref=refs['proposal'], independent_reader_ref=refs['independent_reader'])

    def resolve_math(self, model, seed, step):
        key = proposal_identity(model, self.owner.protocol['sources'])
        if key in self.math:
            row = self.math[key]
            self.journal.event('math_reuse', {'complete_proposal_reuses': 1}, context_key=key, seed=seed, step=step, proposal_ref=row['proposal_ref'])
            return key, row
        if key in self.attempted_math:
            raise RuntimeError('UNKNOWN_PRIOR_UNRETURNED_MATH_NO_RETRY')
        if not NEW_OPTIMIZER_ENTRY_ENABLED:
            raise RuntimeError('UNKNOWN_NEW_OPTIMIZER_ENTRY_DISABLED')
        # Deliberately unreachable in this frozen preparation version. A newly
        # reviewed source version must enable entry under a complete protocol.
        raise RuntimeError('FULL_NEW_MATH_OWNER_READER_PROTOCOL_NOT_IMPLEMENTED')

    def retain_cost(self, identity, evidence):
        if identity not in self.journal.costs.retained_by_receipt:
            self.journal.event('paid_cost_lineage', identity=identity, evidence=evidence)
        self.journal.costs.retain(identity, evidence)

    def paid_lookup(self, signature, kwargs, seed, step, context):
        before = self.paid_snapshot.costs
        try:
            result = self.paid_snapshot.lookup(signature, kwargs)
        finally:
            # Lookup failures still consume their observed bytes/call count.
            self.journal.event('paid_lookup_io', counter_delta(before, self.paid_snapshot.costs, 'snapshot.'),
                               seed=seed, step=step, context_key=context)
        return result

    def physical_lineage(self, signature, kwargs, reuse):
        before = self.provenance.costs.copy()
        try:
            evidence = self.provenance.evidence(signature, kwargs, reuse)
        finally:
            self.journal.event('paid_provenance_io', counter_delta(before, self.provenance.costs, 'provenance.'))
        self.retain_cost('physics:'+evidence['identity'], evidence)
        return evidence

    def normalized_receipt(self, name, after_ref, signature, provenance, kwargs, **joins):
        row = {'status': 'RETURNED', 'after': after_ref['path'], 'after_sha256': after_ref['sha256'],
               'physical_signature': signature, 'kwargs': kwargs, 'provenance': provenance,
               'new_physics': False, **joins}
        reference = self.put(name, row)
        return dict(row, record_ref=reference)

    def bind_initial_root(self, seed, model, binding):
        """Consume actual root bytes and exact original initializer/provenance."""
        root_ref = binding['root']; net = net_from_ref(self.root, root_ref)
        sig = physical_signature(net)
        q = net['sgen'].q_mvar.to_numpy()[:3].copy(); vm = net['res_bus'].vm_pu.to_numpy(copy=True)
        need(sig == root_ref['physical_signature'] and np.array_equal(q, model.current_q)
             and np.array_equal(vm, model.current_vm), 'Actual root differs from frozen bound input')
        need(bool(net['converged']) and bool(net['_ppc']['success']), 'Root is not a solved returned artifact')
        need(np.array_equal(net['_ppc']['bus'], model.ppc_bus)
             and np.array_equal(net['_ppc']['gen'], model.ppc_gen), 'Root PPC differs from bound initial model')
        kwargs = {'algorithm': 'bfsw'}  # Exact original root role; never relabel as prospective dc.
        result = self.paid_lookup(sig, kwargs, seed, 0, None)
        need(result['status'] == 'VERIFIED_EXACT_PAID_REUSE', 'UNKNOWN_ROOT_HAS_NO_AUDITED_ORIGINAL_RECEIPT')
        after = dict(result['reuse']['after'], kind='NET')
        paid_net = net_from_ref(self.root, after)
        same_physical_tables(net, paid_net)
        need(physical_signature(paid_net) == sig
             and np.array_equal(paid_net['res_bus'].vm_pu.to_numpy(), vm)
             and np.array_equal(paid_net['_ppc']['bus'], net['_ppc']['bus'])
             and np.array_equal(paid_net['_ppc']['gen'], net['_ppc']['gen']), 'Root alias differs from original paid NET')
        lineage = self.physical_lineage(sig, kwargs, result['reuse'])
        lookup_ref = self.put(f'seed{seed:03d}_Root_Lookup.json', result)
        paid = self.normalized_receipt(f'seed{seed:03d}_Audited_Root.json', root_ref, sig,
            {'type': 'AUDITED_INITIAL_ROOT_WITH_ORIGINAL_RECEIPT', 'binding': binding,
             'original_returned_NET': after, 'lookup_ref': lookup_ref, 'reuse': result['reuse'], 'cost_lineage': lineage}, kwargs)
        return {'NET': root_ref, 'signature': sig, 'Q': q, 'vm': vm}, paid

    def prepare_preproposal_checkpoint(self, seed, model, binding, state, history, paid):
        """Preserve a complete decision boundary before any future math admission.

        Does not invoke a receipt bank, optimizer, model or physical solver.
        A future owner must wire and independently review the new-math path.
        """
        c = self.cursor(seed, binding, state, history, paid, None)
        self.owner.check(c)
        kernel, ref = pack_current_state(self.root, seed, state['NET'], c,
            (self.out/f'seed{seed:03d}_step{len(history)+1:03d}_Preproposal.pkl').relative_to(self.root).as_posix())
        cold_kernel, cold = load_current_state(self.root, ref)
        need(typed(cold) == typed(c) and typed(vars(cold_kernel)) == typed(vars(kernel)), 'Preproposal cold state/type mismatch')
        need(proposal_identity(model, self.owner.protocol['sources']) == proposal_identity(kernel, self.owner.protocol['sources']), 'Preproposal model context changed')
        self.journal.event('preproposal_preserved', {'preproposal_packs': 1, 'preproposal_cold_loads': 1},
                           seed=seed, step=len(history)+1, checkpoint=ref)
        return ref

    def cursor(self, seed, binding, state, history, paid, stop):
        reference = self.journal.reference()
        c = dict(schema=SCHEMA, evidence_scope='ACTUAL_SOLVED_RECEIPT', seed=seed,
                 next_step=len(history)+1, remaining_original_horizon=100-len(history), original_horizon=100,
                 stop_status=stop, root_NET=binding['root'], current_NET=state['NET'],
                 current_physical_signature=state['signature'], current_Q=state['Q'], current_vm=state['vm'],
                 history=history, paid_receipt=paid, source_lock=self.owner.protocol['sources'],
                 absolute_deadline_monotonic=self.owner.deadline, original_deadline_monotonic=self.owner.deadline,
                 clock_domain=canonical(self.owner.protocol['clock_domain']).decode(), owner_protocol_ref=self.owner.protocol_ref,
                 rng_state={'python': random.getstate(), 'numpy': np.random.get_state(), 'torch': None, 'cuda': None, 'solver': None},
                 solver_state_ref=None, costs=self.journal.costs.numeric or {'new_PF': 0},
                 unknown_costs=self.journal.costs.unknown.copy(), cost_journal_ref=reference,
                 historical_paid_index_ref=self.owner.protocol['paid_registry_manifest'],
                 attempt_journal_ref=reference, math_journal_ref=reference, physical_journal_ref=reference,
                 physical_kwargs=PHYSICAL_KWARGS)
        return c

    def step(self, seed, step, model, state, history, binding, paid):
        self.owner.check(self.cursor(seed, binding, state, history, paid, None))
        context, math = self.resolve_math(model, seed, step)
        proposal = math['proposal']; u = np.asarray(proposal['u'], dtype=np.float32)
        candidate = safe_candidate(net_from_ref(self.root, state['NET']), state['Q'], u)
        q = state['Q']-u
        sig = physical_signature(candidate)
        result = self.paid_lookup(sig, PHYSICAL_KWARGS, seed, step, context)
        lookup_ref = self.put(f'seed{seed:03d}_step{step:03d}_Lookup.json', result)
        self.journal.event('physics_lookup', seed=seed, step=step, context_key=context, candidate_signature=sig,
                           key=result['key'], lookup_status=result['status'], lookup_ref=lookup_ref)
        if result['status'] != 'VERIFIED_EXACT_PAID_REUSE':
            # MISS is finite registry coverage, never a new-PF permit.
            raise RuntimeError('UNKNOWN_PHYSICS_'+result['status']+'_NEW_PF_DISABLED')
        after_ref = dict(result['reuse']['after'], kind='NET')
        actual = net_from_ref(self.root, after_ref)
        need(physical_signature(actual) == sig, 'Paid returned physical identity differs')
        # Verify every physical DataFrame, not only the historical9-table digest.
        same_physical_tables(candidate, actual)
        aq = actual['sgen'].q_mvar.to_numpy()[:3].copy(); av = actual['res_bus'].vm_pu.to_numpy(copy=True)
        u, accepted, committed_q, committed_vm = verify_decision(state['Q'], state['vm'], proposal, aq, av)
        lineage = self.physical_lineage(sig, PHYSICAL_KWARGS, result['reuse'])
        paid_candidate = self.normalized_receipt(f'seed{seed:03d}_step{step:03d}_Paid_Join.json', after_ref, sig,
            {'lookup_ref': lookup_ref, 'reuse': result['reuse'], 'cost_lineage': lineage}, PHYSICAL_KWARGS,
            context_key=context, proposal_ref=math['proposal_ref'])
        pevent = self.journal.event('physics_paid_return', {'paid_physics_reuses': 1}, seed=seed, step=step,
            context_key=context, key=result['key'], lookup_status=result['status'], after_NET=after_ref,
            receipt_ref=paid_candidate['record_ref'], candidate_signature=sig, proposal_ref=math['proposal_ref'],
            candidate_Q=aq, candidate_vm=av, proposal={'u': u.tolist(), 'next_q': q.tolist()})
        committed_ref = after_ref if accepted else state['NET']
        decision = dict(seed=seed, step=step, context_key=context, math_ref=math['proposal_ref'], physical_event=pevent,
            before_NET=state['NET'], before_signature=state['signature'], before_Q=state['Q'].copy(), before_vm=state['vm'].copy(),
            native_u=u, native_u_float32_bytes=base64.b64encode(u.tobytes()).decode(), proposal={'u': u.tolist(), 'next_q': q.tolist()},
            candidate_NET=after_ref, candidate_receipt_ref=paid_candidate['record_ref'], candidate_signature=sig,
            candidate_Q=aq, candidate_vm=av, accepted=accepted, committed_NET=committed_ref,
            committed_Q=committed_q, committed_vm=committed_vm)
        self.journal.event('decision', {'control_decisions': 1, 'accepted_commits': int(accepted), 'rejected_candidates': int(not accepted)}, **decision)
        next_state = {'NET': committed_ref, 'signature': sig if accepted else state['signature'], 'Q': committed_q, 'vm': committed_vm}
        current_paid = paid_candidate if accepted else paid
        history.append(decision)
        stop = None if accepted else 'ORIGINAL_GUARD_HOLD_STOP'
        if accepted and endpoint(committed_vm)['strict_fullband']: stop = 'BAND_COMPLETE'
        if accepted and step == 100 and stop is None: stop = 'ORIGINAL_HORIZON'
        kernel = self.preserve_committed(seed, step, binding, next_state, history, current_paid, stop)
        return kernel, next_state, current_paid, stop

    def preserve_committed(self, seed, step, binding, state, history, paid, stop):
        stage = 'cursor_build'
        try:
            c = self.cursor(seed, binding, state, history, paid, stop)
            stage = 'pack_current_state'
            kernel, cp = pack_current_state(self.root, seed, state['NET'], c,
                (self.out/f'seed{seed:03d}_step{step:03d}_Cursor.pkl').relative_to(self.root).as_posix())
            stage = 'cold_load'
            cold_kernel, cold = load_current_state(self.root, cp)
            stage = 'cold_equality'
            need(typed(cold) == typed(c) and typed(vars(cold_kernel)) == typed(vars(kernel)), 'Cold state/type mismatch')
            stage = 'cursor_preserved_event'
            self.journal.event('cursor_preserved', {'cursor_packs': 1, 'cursor_cold_loads': 1}, seed=seed, step=step, checkpoint=cp)
            return kernel
        except Exception as exc:
            # History/decision has already committed. The caller must adopt
            # these fields and stop UNKNOWN; retry/rollback is forbidden.
            raise PostCommitPreservationError(state, paid, history, stage, exc) from exc

    def run_paid_only(self):
        """Fixed entire population. Missing science remains UNKNOWN, never pruned."""
        self.import_first_paid_math()
        for seed in range(500):
            history = []; state = None; status = 'UNKNOWN_NOT_ENTERED'; failure = None; entered = False
            try:
                self.owner.check()
                model, binding = load_certified_case(self.root, seed)
                state, paid = self.bind_initial_root(seed, model, binding)
                self.journal.event('case_entered', seed=seed, root=binding['root'], initial_Q=state['Q'], initial_vm=state['vm'], root_receipt_ref=paid['record_ref'])
                entered = True
                for step in range(1, 101):
                    if endpoint(state['vm'])['strict_fullband']:
                        status = 'COMPLETE_STRICT_BAND'; break
                    model, state, paid, stop = self.step(seed, step, model, state, history, binding, paid)
                    if stop:
                        status = {'BAND_COMPLETE': 'COMPLETE_STRICT_BAND', 'ORIGINAL_GUARD_HOLD_STOP': 'COMPLETE_GUARD_HOLD_STOP',
                                  'ORIGINAL_HORIZON': 'COMPLETE_ORIGINAL100_HORIZON'}[stop]
                        break
                else: status = 'COMPLETE_ORIGINAL100_HORIZON'
            except PostCommitPreservationError as exc:
                state, paid, history = exc.state, exc.paid, exc.history
                status = 'UNKNOWN_POST_COMMIT_PRESERVATION'; failure = str(exc)
            except Exception as exc:
                status = 'UNKNOWN_'+type(exc).__name__
                failure = str(exc)
            self.results.append(self.finalize_episode(seed, status, state, history, entered, failure))
        replayed = replay_semantics(self.journal.rows, self.root)
        need(replayed.numeric == self.journal.costs.numeric and replayed.unknown == self.journal.costs.unknown, 'Journal/cost semantic mismatch')
        need(replayed.retained_by_receipt == self.journal.costs.retained_by_receipt, 'Paid cost lineage replay mismatch')
        result = {'scope': 'PAID_ONLY_PREPARATION_ENGINE_NOT_A_FULL_NEW_CAMPAIGN', 'cases': self.results,
                  'numeric_costs': self.journal.costs.numeric, 'unknown_costs': self.journal.costs.unknown,
                  'retained_paid_costs_by_receipt': self.journal.costs.retained_by_receipt,
                  'new_optimizer_entry_enabled': False, 'new_PF_entry_enabled': False,
                  'unknown_cases_never_count_as_restored': True}
        self.put('Result.json', result); self.journal.close()
        return result

    def finalize_episode(self, seed, status, state, history, entered, failure):
        """An expired/failed terminal write cannot become a COMPLETE result."""
        row = {'seed': seed, 'status': status, 'steps': len(history), 'new_physical_calls': 0}
        if state is not None:
            row.update(final_NET=state['NET'], final_vm=state['vm'].tolist(), final_Q=state['Q'].tolist(),
                       endpoint=endpoint(state['vm']))
            if entered:
                if time.monotonic() >= self.owner.deadline:
                    row['status'] = 'UNKNOWN_TERMINAL_DEADLINE'
                    row['missing_terminal_reason'] = 'Original deadline expired before terminal event; authoritative state retained, no renewal'
                else:
                    try:
                        self.journal.event('episode_terminal', seed=seed, status=status, final_NET=state['NET'],
                                           final_Q=state['Q'], final_vm=state['vm'], steps=len(history))
                    except Exception as exc:
                        row['status'] = 'UNKNOWN_TERMINAL_PRESERVATION'
                        row['terminal_preservation_failure'] = repr(exc)
        if row['status'].startswith('UNKNOWN'):
            row['failure'] = failure or row.get('missing_terminal_reason', row.get('terminal_preservation_failure', 'Unentered'))
        return row


if __name__ == '__main__':
    raise SystemExit('Preparation module only. No CLI launch, optimizer or PF entry is enabled.')
