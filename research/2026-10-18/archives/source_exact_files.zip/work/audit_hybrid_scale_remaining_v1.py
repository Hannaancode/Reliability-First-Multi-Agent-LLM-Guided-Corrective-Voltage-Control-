"""One external complete/partial evidence audit; zero model/physics/solve."""
import ast,collections,hashlib,json,os,time
from pathlib import Path
import numpy as np
from durable_opaque_evidence_store_v1 import process_alive
from causal_recipient_seed_order_v1 import order
from joint_admissibility_order_v1 import KEYS
R=Path(__file__).resolve().parents[1];B=R/'outputs/hybrid_scale_remaining_20261012';X=B/'execution';S=X/'staged/study';O=B/'audit'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):
    with p.open('x',encoding='utf8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def original_function(file,name):
    n=next(n for n in ast.parse(file.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name)
    g={'json':json};exec(compile(ast.Module(body=[n],type_ignores=[]),str(file),'exec'),g);return g[name]
def best(rows):
    safe=[r for r in rows if r['verif']['accepted']]
    return max(safe,key=lambda r:(tuple(r['original_score']),-r['universe_index'])) if safe else None
def main():
    begun=time.perf_counter();status=read(X/'status.json');claim=read(X/'owner.claim');launcher=read(B/'Launcher.json')
    assert all(not process_alive(p) for p in [claim['pid'],launcher['launcher_pid']])
    assert status['scientific_process_ended'] and status['runtime_released'] and status['all_actual_closed_artifacts_preserved']
    O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'source_sha256':sha(Path(__file__))})
    manifest=read(S/'Closed_Manifest.json')
    for n,m in manifest.items():assert (S/n).stat().st_size==m['bytes'] and sha(S/n)==m['sha256']
    p=read(B/'preparation/protocol.json');identity=read(S/'scientific_identity.json');assert identity['protocol_sha256']==sha(B/'preparation/protocol.json')
    for n,h in p['remote_source_hashes'].items():assert sha(R/n)==h
    e=[json.loads(l) for l in (S/'events.jsonl').read_text().splitlines()];attempts=[x for x in e if x['kind']=='forward_attempt'];returns=[x for x in e if x['kind']=='forward_return']
    assert len({(x['arm'],x['sequence']) for x in attempts})==len(attempts)
    for x in returns:
        assert (x['arm'],x['sequence']) in {(a['arm'],a['sequence']) for a in attempts}
        f=S/x['logits_file'];assert sha(f)==x['logits_sha256']
        with np.load(f,allow_pickle=False) as z:
            a=z['logits'];assert np.isfinite(a).all() and a.shape==(x['vocab_size'],) and int(np.argmax(a))==x['greedy_argmax_token_id']
    final=read(S/'Final_Status.json');complete=final['complete']
    report={'state':'PASS_PRESERVED_EVIDENCE_COMPLETE_PANEL' if complete else 'PASS_PRESERVED_EVIDENCE_TERMINAL_PARTIAL','science_final':final,'actual_forward_attempts':len(attempts),'actual_forward_returns':len(returns),'all_saved_logits_finite_hashes_raw_argmax_passed':True,'new_model_PF_solver_optimizer_calls':0,'partial_unexecuted_missing_results':'UNKNOWN, never negative/pass learning','old_private_partial_separate':'outputs/hybrid_scale_screen_20261012/partial_audit/Independent_Preserved_Prefix_Audit.json'}
    cases=read(R/'outputs/hybrid_scale_screen_20261012/preparation/Causal_Prompt_Cases.json');cm={c['case_id']:c for c in cases}
    extract=original_function(R/'work/e/audit/phase2g_multiagent_llm_runner.py','extract_json');normalize=original_function(R/'work/e/audit/phase2g_rescue_runner.py','normalize_action')
    opportunity=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012';oldp=read(opportunity/'preparation/Protocol.json');physical=[];PF={}
    for line in (opportunity/'actual/scientific.jsonl').read_text().splitlines():
        row=json.loads(line)
        if row['event']=='candidate_closed':physical.append(row['data'])
        elif row['event'] in ('PF_return','PF_exception'):PF[row['data']['id']]=row['data']['seconds']
    assert len(physical)==4001
    allarms=[]
    for arm in final['arms']:
        name=arm['arm'];ar={'arm':name,'actual_state':arm,'world_results':[]}
        if arm['state']!='COMPLETE_FROZEN_INFERENCE_SCREEN':allarms.append(ar);continue
        fg=read(S/name/'Final_Gates.json');assert fg['all16_proposals_returned'] and fg['all_weights_unchanged'] and fg['cold_longest_logits_and_sequence_exact']
        responses=[read(f) for f in sorted((S/name/'responses').glob('*.json'))];assert len(responses)==16 and {r['case_id'] for r in responses}==set(cm)
        for r in responses:
            closure=read(R/'outputs/hybrid_scale_screen_20261012/preparation/token_closure_v6'/(name+'_Token_Closure.json'))
            assert r['prompt_ids']==next(x['input_ids'] for x in closure['full16_prefixes'] if x['case_id']==r['case_id'])
            fr=[x for x in returns if x['arm']==name and x['phase']=='proposal' and x['observation_id']==r['case_id']]
            assert r['generated_ids']==[x['greedy_argmax_token_id'] for x in fr]
            gates=[x for x in e if x['kind']=='actual_greedy_processor_gate' and x['arm']==name and x['case_id']==r['case_id'] and x['phase']=='proposal']
            assert len(gates)==1 and not gates[0]['processors'] and gates[0]['effective_generation_config']['repetition_penalty']==1.0
        for entry in oldp['current_endpoints']:
            world=entry['world'];endpoint=read(R/entry['endpoint_record']);cursor={**endpoint['cursor'],'raw_current_receiver_scope':endpoint['native_common_AND_zone_buses']}
            records=sorted([r for r in physical if r['world']==world],key=lambda r:r['universe_index']);lookup={r['universe_index']:r for r in records};causal=[{k:r[k] for k in KEYS} for r in records];oracle=best(records);assert oracle
            before=records[0]['verif']['before']
            seeds=[];commands=[];modelsecs=0
            for r in responses:
                c=cm[r['case_id']]
                if c['administrator_world']!=world:continue
                obj,jsonok,err=extract(r['raw_text']);a=normalize(obj);modelsecs+=r['seconds_includes_instrumentation'];commands.append({'case_id':r['case_id'],'zone':c['zone'],'original_JSON_parser_pass':jsonok,'original_normalized_action':a,'raw_text_retained':True})
                if a:
                    bus,q=next(iter(a['add_shunts_q_mvar'].items()))
                    try:seeds.append({'bus':int(bus),'q':float(q)})
                    except ValueError:pass
            controls=[]
            for mode in ('objective','admissibility'):
                for label,seed in [('numerical_only',[]),('LLM_recipient_seed_plus_same_numerical',seeds)]:
                    ordered,valid=order(causal,before,cursor,seed,mode);chosen=[lookup[r['universe_index']] for r in ordered];assert len(chosen)==len(records)
                    Ks=[]
                    for K in [1,4,16,64,256]:
                        head=chosen[:K];v=best(head);receipts=[r['measured_receipt'] for r in head if r['measured_receipt'] is not None]
                        Ks.append({'K':K,'known_best_UV':v['verif']['after']['uv_count'] if v else None,'full_oracle_score_inclusion':v is not None and v['original_score']==oracle['original_score'],'paid_previous_PF_count':len(receipts),'paid_previous_PF_seconds_only':sum(PF[r['PF_id']] for r in receipts)})
                    controls.append({'mode':mode,'method':label,'all_identities_kept':len(chosen),'valid_seed_buses':valid,'first_full_original_score_match':next(i+1 for i,r in enumerate(chosen) if r['verif']['accepted'] and r['original_score']==oracle['original_score']),'all_fixed_K':Ks})
            ar['world_results'].append({'world':world,'all_four_zone_commands':commands,'actual_four_zone_model_generation_seconds_instrumented':modelsecs,'all_controls':controls})
        allarms.append(ar)
    put(O/'Independent_Audit.json',report);put(O/'All_Arm_Results.json',{'arms':allarms,'interpretation':'Paid saved-receipt inspected development only. Retain both controls/allK/allworlds. No online oracle stop, free tools, selectedK, model/DSE superiority, policy latency/novelty/99percent or unused confirmation claim. Prior failures/setup/physics/data/ordering costs separate, notfree.'})
    put(O/'Closed_Manifest.json',{f.name:sha(f) for f in O.iterdir() if f.is_file()})
    print(json.dumps({'status':report['state'],'forward_returns':len(returns),'audited_arms':len(allarms),'model_PF_calls':0}))
if __name__=='__main__':main()
