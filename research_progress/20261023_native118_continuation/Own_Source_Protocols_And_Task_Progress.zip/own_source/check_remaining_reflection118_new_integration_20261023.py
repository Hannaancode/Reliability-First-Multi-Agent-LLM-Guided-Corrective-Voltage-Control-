"""Actual first-model boundary and new registry fixtures, zero science."""
from reflection118_remaining_cases_core_20261023 import *

def main():
    O=R/'outputs/reflection118_remaining_cases_preparation_20261023/integration';O.mkdir(exist_ok=False)
    np,pp,v2,runner,reflection=setup()
    from transformers import AutoTokenizer
    def forbidden(*a,**k):raise OperationalStop('SOFTWARE_CHECK_FORBIDS_NEW_MODEL_OR_PF')
    pp.runpp=forbidden
    tok=AutoTokenizer.from_pretrained(str(R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'),local_files_only=True,trust_remote_code=False)
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'));zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones'];rows=[]
    old=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json')
    for index in [1,2,3]:
        b=bindings[index];root=net_value(pickle.loads((R/b['solved_payload']).read_bytes()));messages=[]
        for label in ['warm','cold']:
            initial=[];captured=[]
            def physics(net,**kwargs):
                assert not initial and kwargs==b['solver_kwargs'];restore_exact(net,root);initial.append(True)
            def model(value):captured.append(copy.deepcopy(value));raise PaidBoundary('BEFORE_FIRST_ACTUAL_MODEL_APPLICATION')
            random.seed(old['seed']);np.random.seed(old['seed'])
            try:run_original(v2,runner,reflection,read(R/b['registration']['recipe']),base,zones,model,physics)
            except PaidBoundary:pass
            else:raise AssertionError('Unchanged original source must request its real initial causal prompt')
            assert len(initial)==len(captured)==1;messages.append(captured[0])
        assert messages[0]==messages[1]
        encoded=tok.apply_chat_template(messages[0],tokenize=True,add_generation_prompt=True);ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
        assert len(ids)+384<=4096
        put(O/f'case_{index:02d}_First_Actual_Source_Messages.json',dict(case_id=b['case_id'],messages=messages[0],input_token_ids=ids,actual_model_calls=0,initial_paid_PF_reuses=2,source_warm_cold_exact=True))
        rows.append(dict(case_index=index,case_id=b['case_id'],first_causal_context_tokens=len(ids),full_context_not_truncated=True,source_first_request_warm_cold_exact=True))
    # Actual successful and failed native receipts exercise the new lazy path.
    d=R/'outputs/r118_first_round_missing_only_execution_20261022';records=read(d/'Result.json')['rows']
    chosen=[next(r for r in records if r.get('before') and r.get('exception') is None),next(r for r in records if r.get('before') and r.get('exception') is not None)]
    from prior_physical_query_footprints_20261018 import component
    from run_reflection118_chronological_local_20261022 import necessary
    table=[]
    for row in chosen:
        net=saved_net(d,row['before']);key=component(net)[0]+':'+hashlib.sha256(canonical(necessary(net))).hexdigest();source=d/f"record_{row['identity']:04d}.json"
        table.append(dict(resource_key=key,directory=d.relative_to(R).as_posix(),source=source.relative_to(R).as_posix(),source_sha256=sha(source),before=row['before'],after=row['after'],kwargs=row['solver_kwargs'],exception=row['exception']))
    put(O/'Fixture_Lazy_Registry.json',dict(rows=table));reg=ClosedPaidRegistry(O/'Fixture_Lazy_Registry.json')
    checks=[]
    for row in chosen:
        net=saved_net(d,row['before']);after,exc,provenance=reg.lookup(net,row['solver_kwargs']);assert after is not None
        assert (exc is None)==(row['exception'] is None);frames_equal(after,saved_net(d,row['after']))
        checks.append(dict(identity=row['identity'],saved_return_or_exception_exact=True,not_reexecuted=True,kind=provenance['kind']))
    put(O/'New_Integration_Readiness.json',dict(status='PASS_NEW_ALL3_ACTUAL_CAUSAL_FIRST_REQUEST_AND_LAZY_REGISTRY_SAVED_RECEIPT_GATES',cases=rows,actual_lazy_return_and_failure_fixture=checks,new_model_PF_optimizer_training_allocations=0,allocation_readiness=False,remaining='Bind and independently check complete actual DFF closed receipt index, source/input pins, payload and owners after its original actors end.'))
    print(json.dumps(dict(all3_new_source_contexts='PASS',actual_lazy_success_failure_checks='PASS',new_scientific_calls=0)))

if __name__=='__main__':main()
