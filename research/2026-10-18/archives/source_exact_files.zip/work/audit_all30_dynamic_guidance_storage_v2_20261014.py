"""Independent saved-matrix arithmetic/causal-input audit; no scientific callbacks."""
import hashlib,json,os,time
from pathlib import Path
import numpy as np
from measure_all30_dynamic_guidance_storage_v2_20261014 import B,MASK,OLD,read,put,pins,checkpoint,load_endpoint,identity,current_inputs,sha

def main():
    p=pins();result=read(B/'actual/Result.json');assert result['exit_code']==0
    out=B/'audit';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'reader_source_sha256':sha(Path(__file__))})
    for name,digest in read(B/'actual/Closed_Manifest.json')['members'].items():assert sha(B/'actual'/name)==digest
    prefix='0'*64;events=[]
    for line in (B/'actual/scientific.jsonl').read_bytes().splitlines():
        record=json.loads(line);digest=record.pop('hash');assert record['previous']==prefix and record['protocol_sha256']==sha(B/'Protocol.json')
        assert hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==digest
        prefix=digest;events.append(record)
    assert prefix==result['final_journal_prefix']
    roots={};contexts={};prior={};summaries=[];new_compiled=set()
    for i,e in enumerate(read(OLD/'preparation/Protocol.json')['current_endpoints'],1):
        net,_,_=load_endpoint(e)
        with np.load(MASK/'actual'/f'W{i}_Actual_Final_Mask_Context.npz',allow_pickle=False) as f:c={k:f[k] for k in f.files}
        roots[e['world']]=(net,c);contexts[identity(c)]=c
    for i in p['all_closed_transition_ids']:
        assert time.perf_counter()-start<p['resource_bound_seconds']
        saved=read(B/'actual'/f'T{i}.json');after=checkpoint(i);world=after['cursor']['world'];method=after['next_phase']['method']
        before=prior.get((world,method));net=roots[world][0] if before is None else before['net'];raw=current_inputs(net)
        assert saved['world']==world and saved['method']==method and saved['before_checkpoint']==(None if before is None else before['_id'])
        ident=identity(raw);assert saved['before_context']==ident
        with np.load(B/'actual'/(ident+'.npz'),allow_pickle=False) as f:c={k:f[k] for k in f.files}
        for key in raw:assert np.array_equal(raw[key],c[key]),key
        Y=c['Y'];V=c['V'];diagV=np.diag(V);diagI=np.diag(Y@V);norm=np.diag(V/np.abs(V))
        # Closed-form saved derivative checks, no public dSbus_dV invocation.
        m=diagV@np.conj(Y@norm)+np.conj(diagI)@norm
        a=1j*diagV@np.conj(diagI-Y@diagV)
        assert np.allclose(m,c['m'],atol=1e-8,rtol=1e-12) and np.allclose(a,c['a'],atol=1e-8,rtol=1e-12)
        nr=c['nonref'];pq=c['actual_PQ']
        J=np.block([[c['a'].real[np.ix_(nr,nr)],c['m'].real[np.ix_(nr,pq)]],
                    [c['a'].imag[np.ix_(pq,nr)],c['m'].imag[np.ix_(pq,pq)]]])
        assert np.array_equal(J,c['J']) and np.max(np.abs(J@c['X']-c['B']))<=1e-8
        rhs=np.zeros_like(c['B']);positions={int(k):j for j,k in enumerate(pq)}
        for bus,k in enumerate(c['mapping']):
            if int(k) in positions:rhs[len(nr)+positions[int(k)],bus]=abs(V[k])**2/float(c['baseMVA'])
        assert np.array_equal(rhs,c['B'])
        S=np.zeros((118,118));S[pq,:]=c['X'][len(nr):,:]
        assert np.array_equal(S[c['mapping'],:],c['sensitivity'])
        if ident not in contexts:new_compiled.add(ident);contexts[ident]=c
        row=after['cursor']['committed_transitions'][-1]['candidate'];assert row==saved['action']
        delta=np.zeros(118);delta[row['receiver']]+=row['q']
        if row['donor_bus'] is not None:delta[row['donor_bus']]-=row['q']
        dynamic=raw['current_vm']+c['sensitivity']@delta;fixed=raw['current_vm']+roots[world][1]['sensitivity']@delta
        observed=after['net'].res_bus.loc[range(118),'vm_pu'].to_numpy()
        assert np.array_equal(dynamic,saved['dynamic_prediction']) and np.array_equal(fixed,saved['fixed_prediction'])
        assert np.array_equal(observed,saved['observed_after'])
        summary={k:saved[k] for k in ['checkpoint','world','method','before_checkpoint','before_context']}
        for name,array in [('dynamic',dynamic),('fixed',fixed)]:
            summary[name+'_MAE']=float(np.abs(array-observed).mean());summary[name+'_max_error']=float(np.abs(array-observed).max());summary[name+'_UV']=int((array<.95).sum())
        summary['observed_UV']=int((observed<.95).sum());summaries.append(summary);after['_id']=i;prior[(world,method)]=after
    assert summaries==result['all30_rows']
    perworld={w:{arm:float(np.mean([r[arm+'_MAE'] for r in summaries if r['world']==w])) for arm in ['dynamic','fixed']} for w in sorted({r['world'] for r in summaries})}
    d=float(np.mean([r['dynamic'] for r in perworld.values()]));f=float(np.mean([r['fixed'] for r in perworld.values()]))
    dm=sum(r['dynamic_UV']!=r['observed_UV'] for r in summaries);fm=sum(r['fixed_UV']!=r['observed_UV'] for r in summaries)
    gate='PASS' if d<=.5*f and dm<=fm else 'FAIL'
    assert gate==result['diagnostic_gate'] and d==result['equal_world_MAE_dynamic'] and f==result['equal_world_MAE_fixed']
    costs=result['new_costs'];n=len(new_compiled)
    assert all(costs[k]==n for k in ['public_derivative_attempts','public_derivative_returns','LU_factor_attempts','LU_factor_returns','LU_solve_attempts','LU_solve_returns'])
    assert costs['RHS_columns']==118*n and costs['exact_context_reuses']==30-n and result['new_forecast_returns']==60
    for kind in ['public_derivative_attempt','public_derivative_return','LU_factor_attempt','LU_factor_return','LU_solve_attempt','LU_solve_return']:
        assert len([e for e in events if e['event']==kind])==n
    assert len([e for e in events if e['event']=='paired_predictions_returned'])==30
    put(out/'Independent_All30_Dynamic_Guidance_Audit.json',{'status':'PASS_ALL30_CAUSAL_BEFORE_INPUTS_DERIVATIVE_EQUATIONS_MASKS_RHS_RESIDUALS_PREDICTIONS_COSTS_AND_FIXED_GATE',
        'diagnostic_gate':gate,'equal_world_MAE_dynamic':d,'equal_world_MAE_fixed':f,
        'dynamic_UV_mismatches':dm,'fixed_UV_mismatches':fm,'all_observed_worlds':perworld,
        'new_unique_contexts':n,'new_scientific_function_calls_in_reader':0,'reader_workflow_seconds':time.perf_counter()-start,
        'limits':'Saved-action development diagnostic. Three observed worlds, fourth no closed transition evidence. No new physical policy/LLM result or automatic rollout.'})
    print(json.dumps({'independent_all30_audit':'PASS','diagnostic_gate':gate,'new_model_PF_derivative_solve_callbacks':0}))
if __name__=='__main__':main()
