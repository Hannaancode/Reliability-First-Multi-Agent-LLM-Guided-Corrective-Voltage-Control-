"""Validate new independent decision reader on all eight audited paid fixtures."""
import copy,json,os,time
import pandapower as pp
from audit_full_receding_paid_campaign_cached_state_v2_20261015 import (R,read,put,sha,audit_decision,forbidden)
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from paid_receding_commit_and_history_v1 import initialize
B=R/'outputs/full_receding_cached_reader_v2_fixture_checks_20261015'
P=R/'outputs/bounded_paid_lookahead_physics_20261014'
C=R/'outputs/operation_aware_lookahead_input_cache_20261014'
O=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(R/'work/audit_full_receding_paid_campaign_cached_state_v2_20261015.py')})
    for n in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,n,forbidden)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    intents={};returns={};exceptions={}
    with (P/'actual/scientific.jsonl').open('rb') as stream:
        for line in stream:
            e=json.loads(line);d=e['data']
            if e['event']=='PF_intent':intents[d['identity']]=d
            elif e['event']=='PF_return':returns[d['PF_id']]=d
            elif e['event']=='PF_exception':exceptions[d['PF_id']]=d
    cache=copy.deepcopy(read(C/'Compatible_Paid_Receipt_Index.json')['cache']);records=[];count=0
    entries={e['world']:e for e in read(O/'preparation/Protocol.json')['current_endpoints']}
    with (P/'actual/capsules.bin').open('rb') as pack:
        for i in range(1,9):
            branch=read(P/'actual'/f'Branch_{i}.json');net,old,_=load_endpoint(entries[branch['world']])
            cursor=initialize(net,build_current_domain(net,old,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
            def admit():assert time.perf_counter()-started<300,'Fixed software reader check bound'
            reconstructed,_,_,checked=audit_decision(branch,net,cursor,actual=P/'actual',cache=cache,intents=intents,
                returns=returns,exceptions=exceptions,pack=pack,p=read(P/'Protocol.json'),runner=runner,zones=zones,admit=admit)
            assert reconstructed==branch['plan'];count+=checked
            records.append({'world':branch['world'],'method':branch['method'],'actual_saved_decision_exact':True,'checked_receipts':checked})
    assert count==12872
    put(B/'Result.json',{'status':'PASS_NEW_INDEPENDENT_DECISION_READER_ALL8_ALREADY_AUDITED_FIXTURES','all8':records,
        'query_receipts_checked':count,'new_PF_model_derivative_factor_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'reader_source_sha256':sha(R/'work/audit_full_receding_paid_campaign_cached_state_v2_20261015.py'),
        'scope':'New reader validation on old observed fixtures, not another scientific result or full runtime performance.'})
    print(json.dumps({'new_reader_all8_paid_fixtures':'PASS','checked_receipts':count,'new_PF_model_calls':0}))
if __name__=='__main__':main()
