"""External exact numerical-learning/checkpoint/journal/metric/cost audit.

Does not run neural forwards, models, optimizers, solver, PF or cloud calls.
"""
import candidate_process_runtime
import gzip,json,os,subprocess,time,torch
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT,read,sha,write,seal,frozen_checks
from relational_control_learning_metrics import saved_native_diagnostic,aggregate_rows
from native_decision_preference_objective import native_decision_order
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';C=P/'current_relational_tensor_cache_v2';S=P/'cpu_control_execution';PREP=P/'cpu_control_preparation';OUT=P/'cpu_control_external_audit'
assert not OUT.exists();OUT.mkdir();write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
start=time.perf_counter();proto=read(PREP/'Prospective_CPU_Control_Protocol.json');protocol_sha=sha(PREP/'Prospective_CPU_Control_Protocol.json')
assert read(S/'status.json')['stage']=='complete_two_controls_closed'
owner=read(S/'owner.claim')['pid'];cmd=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={owner}'; if ($p -and $p.CommandLine -match 'run_relational_cpu_controls.py') {{ 'OWNED_LIVE' }} else {{ 'OWNER_ENDED' }}"
observed=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True,timeout=30)
assert observed.returncode==0 and observed.stdout.strip()=='OWNER_ENDED','Actual owner must end before external reader'
write(OUT/'Fresh_Owner_End_Observation.json',{'actual_owner_pid':owner,'exact_science_command_no_longer_live':True,'observed_at_utc':datetime.now(timezone.utc).isoformat()})
for n,h in proto['source_sha256'].items():assert sha(ROOT/n)==h,n
manifest=read(S/'Closed_Scientific_Manifest.json')
assert set(manifest)=={str(p.relative_to(S)).replace('\\','/') for p in S.rglob('*') if p.is_file() and p.name not in {'owner.claim','status.json','Closed_Scientific_Manifest.json'}}
for n,v in manifest.items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
assert sha(C/'Closed_Scientific_Manifest.json')==proto['cache_manifest_sha256']
inputs=read(C/'Input_Index.json');input_by={r['observation_id']:r for r in inputs};targets={r['observation_id']:r for r in read(C/'Target_Index.json')}
opt=sorted((r for r in inputs if r['split']=='optimization'),key=lambda r:r['observation_id']);wc=Counter(r['world_sha256'] for r in opt)
with gzip.open(ROOT/'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz','rt',encoding='utf8') as f:raw={r['observation_id']:r for r in map(json.loads,f)}
assert len(inputs)==311 and len(targets)==238 and len(opt)==239 and len(wc)==23
events=[json.loads(line) for line in (S/'Actual_Learning_Journal.jsonl').read_text().splitlines()];assert events[-1]['event']=='scientific_process_closed'
common=torch.load(S/'Exact_Common_Initialization.pt',weights_only=True);all_results={};all_rows={};cert={};fresh_pairs=0
for arm in proto['arms']:
    costs=read(S/arm/'Actual_Closed_Arm_Costs.json');ev=[e for e in events if e['arm']==arm]
    returns=[e for e in ev if e['event']=='forward_return'];attempts=[e for e in ev if e['event']=='forward_attempt']
    assert len(returns)==len(attempts)==costs['forward_returns']==costs['forward_attempts']==2128
    timing={'input_load_seconds':('input_loaded','seconds'),'target_load_seconds':('target_loaded','seconds'),
            'forward_seconds':('forward_return','forward_seconds'),'reconstruction_forward_seconds':('forward_return','reconstruction_forward_seconds'),
            'backward_clip_seconds':('backward_return','backward_finitecheck_clip_seconds'),'optimizer_seconds':('optimizer_return','optimizer_seconds'),
            'checkpoint_seconds':('epoch_checkpoint','checkpoint_write_seconds')}
    for key,(event,field) in timing.items():
        actual=sum(e[field] for e in ev if e['event']==event);assert abs(actual-costs[key])<=1e-9*max(1.,abs(actual)),key
    assert costs['typed_cells']==sum(e['typed_cells'] for e in returns)
    assert costs['value_UTF8_bytes']==sum(e['value_UTF8_bytes'] for e in returns)
    assert costs['current_row_positions']==sum(e['current_positions'] for e in returns)
    expected_phases=proto['planned_phase_forward_counts']
    assert Counter(e['phase'] for e in returns)==expected_phases==costs['phase_forward_returns']
    for phase in ('untrained','final','reload'):
        ids=[e['observation_id'] for e in returns if e['phase']==phase]
        assert len(ids)==len(set(ids))==311 and set(ids)==set(input_by)
    training=[e for e in ev if e['event']=='optimizer_return'];backward=[e for e in ev if e['event']=='backward_return']
    assert len(training)==len(backward)==costs['optimizer_steps']==costs['backward_returns']==1195
    assert len([e for e in ev if e['event']=='optimizer_attempt'])==len([e for e in ev if e['event']=='backward_attempt'])==1195
    updates=Counter()
    for i,(e,b) in enumerate(zip(training,backward)):
        r=opt[i%239];assert e['observation_id']==b['observation_id']==r['observation_id'] and e['epoch']==i//239+1 and e['offset']==i%239 and e['completed_steps']==i+1
        assert e['world_weight']==239/(23*wc[r['world_sha256']])
        updates.update(b['gradient_parameter_names'])
        expected=e['loss_terms']['current_grounding']
        if e['loss_terms']['native_supervision']:expected+=e['loss_terms']['classification']+e['loss_terms']['native_pairwise_rank']
        assert abs(e['weighted_loss']-expected*e['world_weight'])<=1e-5*max(1.,abs(e['weighted_loss']))
    registry=read(S/arm/'Actual_Parameter_Registry.json');assert set(updates)==set(registry['active'])
    assert registry['active_parameters']==sum(__import__('math').prod(v) for v in registry['active'].values())
    assert abs(registry['active_parameters']-1107364)/1107364<.01
    checkpoint_events=[e for e in ev if e['event']=='epoch_checkpoint'];assert len(checkpoint_events)==5
    for epoch,e in enumerate(checkpoint_events,1):
        path=S/arm/f'epoch_{epoch}_complete_state.pt';assert sha(path)==e['sha256']
        ck=torch.load(path,weights_only=False)
        assert ck['contract']=={'protocol_sha256':protocol_sha,'arm':arm,'common_initialization_sha256':sha(S/'Exact_Common_Initialization.pt'),'cache_manifest_sha256':proto['cache_manifest_sha256']}
        assert ck['cursor']=={'completed_optimizer_steps':epoch*239,'next_epoch':epoch+1,'next_offset':0}
        assert ck['optimizer_parameter_names']==list(registry['active'])
        expected_updates=Counter()
        for b in backward[:epoch*239]:expected_updates.update(b['gradient_parameter_names'])
        assert ck['parameter_gradient_steps']==dict(expected_updates)
        group=ck['optimizer']['param_groups'];assert len(group)==1 and group[0]['lr']==.001 and group[0]['weight_decay']==.01
        slots=ck['optimizer']['state'];assert len(slots)==len(registry['active'])
        for n,j in zip(ck['optimizer_parameter_names'],group[0]['params']):
            moment=slots[j];assert int(moment['step'])==expected_updates[n] and moment['exp_avg'].shape==moment['exp_avg_sq'].shape==torch.Size(registry['active'][n])
            assert bool(torch.isfinite(moment['exp_avg']).all()) and bool(torch.isfinite(moment['exp_avg_sq']).all())
        assert set(ck['rng'])=={'python','numpy','torch_CPU','torch_CUDA'} and ck['rng']['torch_CUDA']==[]
        for n in registry['frozen']:
            assert n.startswith(('interface.to_body.','interface.body_norm.')) and torch.equal(ck['model'][n],common[n.removeprefix('interface.')])
    rows=[];phase_results={}
    for phase in ('untrained','final','reload'):
        phase_rows=[]
        for r in inputs:
            ident=r['observation_id'];package=torch.load(S/arm/phase/(ident+'.pt'),weights_only=True)
            pred=package['prediction'];num=package['current_numeric_reconstruction'];assert package['source_input_sha256']==r['source_current_input_sha256']
            assert pred.shape==(118,9,3) and bool(torch.isfinite(pred).all()) and num.shape==(r['cells'],) and bool(torch.isfinite(num).all())
            inp=torch.load(C/r['path'],weights_only=False);allowed=torch.tensor(inp['model_input']['allowed_actions'],dtype=torch.bool)
            known=torch.tensor(inp['current_input_reconstruction_mask'],dtype=torch.bool);actual=torch.tensor(inp['model_input']['numeric'])[:,0]
            item={k:r[k] for k in ('observation_id','world_sha256','split')};item['current_grounding_MSE']=float(((num[known]-actual[known])**2).mean())
            if ident in raw:
                item['diagnostic']=saved_native_diagnostic(pred,allowed,raw[ident])
                t=torch.load(C/targets[ident]['path'],weights_only=True)
                for j,key in ((0,'accepted_Brier'),(1,'convergence_Brier')):
                    mask=t['classification_mask'][...,j];item[key]=float(((torch.sigmoid(pred[...,j][mask])-t['classification'][...,j][mask])**2).mean()) if bool(mask.any()) else None
            else:
                order=native_decision_order(pred,allowed)
                item['unlabelled_selection']={str(k):{'selected':len(order[:k]),'all_outcomes_unknown':True,
                    'selected_actions':[list(v) for v in order[:k]]} for k in (1,4,8)}
            phase_rows.append(item)
            if phase=='reload':
                final=torch.load(S/arm/'final'/(ident+'.pt'),weights_only=True)
                assert torch.equal(final['prediction'],pred) and torch.equal(final['current_numeric_reconstruction'],num);fresh_pairs+=1
        phase_results[phase]=aggregate_rows(phase_rows)
        if phase=='final':rows=phase_rows
    assert phase_results['final']==phase_results['reload']
    held=phase_results['final']['development_held'];assert held['declared_input_states']==72 and held['worlds']==8 and held['measured_target_states']==51 and held['unlabelled_states']==21 and held['topK']['4']['recorded_oracle_states']==49
    assert held['recorded_oracle_worlds']==7
    all_results[arm]=phase_results;all_rows[arm]=rows
    cert[arm]={'all2128_exact_phase_identities':True,'all1195_ordered_worldweighted_optimizer_steps':True,
       'all5_AdamW_RNG_gradient_participation_checkpoints':True,'all311_fresh_prediction_and_grounding_reload_pairs_exact':True,
       'active_parameters':registry['active_parameters'],'actual_costs':costs}
summary=read(S/'Actual_Completed_Control_Summary.json');assert sum(c['optimizer_steps'] for c in summary['actual_counts'].values())==2390
assert sum(c['forward_returns'] for c in summary['actual_counts'].values())==4256
assert fresh_pairs==622
best=max(.38596491228070173,*[all_results[a]['final']['development_held']['topK']['4']['equal_world_best_inclusion'] for a in proto['arms']])
gate={'strongest_preserved_AC_or_new_numerical_equalworld_top4':best,'predeclared_LLM_margin':.05,
 'minimum_required_new_LLM_top4':best+.05,'control_ceiling_unattainable_stop':best>.95,
 'genuine_LLM_internal_and_physical_gates_not_measured':True,
 'next_decision':'STOP proposal on dataset: fixed5point margin impossible' if best>.95 else 'Numerical bar established; separately gated genuine CUDA integration/model manifest may be prepared',
 'no_physical_DSE_superiority_unused_confirmation_or_novelty_claim':True}
write(OUT/'Actual_All_Control_Results.json',all_results);write(OUT/'All622_Final_Actual_State_Diagnostics.json',all_rows)
write(OUT/'Prospective_Next_Decision.json',gate)
audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'actual_control_certificates':cert,
 'actual_total_numerical_optimizer_steps':2390,'actual_total_numerical_forwards':4256,'actual_fresh_reload_pairs':622,
 'no_neural_model_optimizer_PF_controller_cloud_calls_by_auditor':0,'actual_reader_seconds':time.perf_counter()-start,
 'old_failed_nominal_capacity_readiness_preserved_actual_active_capacity_verified':True,'no_confirmation_or_physical_performance_claim':True}
write(OUT/'Independent_Numerical_Learning_Audit.json',audit);write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
text='The two numerical controls completed and passed the external exact identity/checkpoint/cost audit. These are historical saved-label development diagnostics, not physical recovery or LLM value.\n\n'
for a in proto['arms']:
    held=all_results[a]['final']['development_held'];text+=f"{a}: held equal-world top4={held['topK']['4']['equal_world_best_inclusion']:.9f}; pooled best inclusion={held['topK']['4']['pooled_hits']}/49; current-input grounding MSE={held['current_grounding_MSE']['equal_world_mean']:.9f}.\n\n"
text+=f"Strongest numerical/AC top4={best:.9f}; predeclared required new LLM top4={best+.05:.9f}. All failures/unknowns/73unlabelled/originalinvalid/missing ledgers and allK1/4/8 retained. Seven labelled held worlds are inspected development, not unused confirmation. Exact622 final/reload pairs passed; 2390optimizersteps/4256forwards. No new pretrained/PF/cloud calls.\n"
(OUT/'Results.md').write_text(text,encoding='utf8')
files={}
for n in manifest:files['science/'+n]=S/n
files['science/Closed_Scientific_Manifest.json']=S/'Closed_Scientific_Manifest.json'
for n in proto['source_sha256']:files['source/'+n.split('/')[-1]]=ROOT/n
for f in OUT.iterdir():
    if f.is_file() and f.name!='audit.claim':files['external/'+f.name]=f
files['protocol.json']=PREP/'Prospective_CPU_Control_Protocol.json'
files['active_capacity_wiring_fixture.json']=P/'active_control_wiring_software/Actual_Active_Gradient_and_Capacity_Check.json'
archive=seal(OUT,files,'Verified_Relational_Numerical_Control_Study.zip')
write(OUT/'status.json',{'stage':'complete_independent_numerical_controls_audit','all_passed':True})
print(json.dumps({'completed':True,'gate':gate,'archive':archive},indent=2))
