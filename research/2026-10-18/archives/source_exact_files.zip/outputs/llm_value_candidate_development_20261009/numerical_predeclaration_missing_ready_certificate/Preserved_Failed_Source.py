"""Freeze a single new numerical study before any optimizer call."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import collections,json
import torch,psutil
from candidate_process_evidence_utils import ROOT,read,sha,write,frozen_checks
from candidate_process_numerical_predictor import TableGraphProcessControl
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';CACHE=BASE/'tensor_readiness_v2';OUT=BASE/'numerical_process_pilot'
assert not OUT.exists();OUT.mkdir()
assert read(BASE/'tensor_external_audit/Independent_Tensor_and_Target_Audit.json')['all_passed']
readiness=read(BASE/'numerical_software_readiness_v2/Readiness.json');assert readiness['all_passed']
for n,m in read(CACHE/'manifest.json').items():assert sha(CACHE/n)==m['sha256'] and (CACHE/n).stat().st_size==m['bytes']
normal=read(BASE/'input_and_target_contract_nullable_v2/Input_Normalization.json')
torch.manual_seed(20261009);model=TableGraphProcessControl(len(normal['typed_semantic_schema']))
index=read(CACHE/'Target_Index.json');train=sorted((r for r in index if r['split']=='optimization'),key=lambda r:r['observation_id'])
counts=collections.Counter(r['world_sha256'] for r in train);assert len(train)==187
protocol={'declared_at_utc':datetime.now(timezone.utc).isoformat(),'study':'one separately declared full-table numerical candidate-response learner',
 'scientific_scope':'historical grouped one-step label/process prediction; no learned rollout or LLM superiority',
 'seed':20261009,'epochs':5,'optimizer':'AdamW','learning_rate':.001,'weight_decay':.01,'gradient_clip':1.,
 'CPU_threads':2,'max_scientific_wall_seconds':1200,'training_states':187,'training_optimizer_steps':935,
 'training_order':'ascending exact observation SHA each epoch; no shuffle/outcome-dependent selection',
 'per_step_world_weight':'187/(active_optimization_worlds * number_of_target_states_in_this_world)',
 'optimization_world_target_counts':dict(sorted(counts.items())),'active_optimization_worlds_with_labels':len(counts),
 'all_declared_finite_worlds':31,'declared_optimization_worlds':23,'declared_held_development_worlds':8,
 'all_inputs_per_evaluation_phase':311,'untrained_final_fresh_reload_phases':3,'expected_actual_numerical_forwards':1868,
 'original_invalid_input_retained_no_forward':1,'four_missing_candidate_ledgers_retained':4,
 'objective':'equal sum masked classification BCE mean, standardized finite measured-global gain MSE, supported adjacent-Q scaled difference MSE; original masks fixed',
 'Q_difference_factor_25_over_delta_Q':[1,1,1,1,1,.5,.5,.5],
 'no_analytic_AC_derivative_or_monotonicity_claim':True,'checkpoint':'final epoch5 only, no checkpoint selection or repeats',
 'known_prePF_scope_and_450_cap_shared_not_trained':True,
 'priority':'predicted accepted>=.5 AND converged>=.5 AND upper_margin>=0; then UVzero>=.5, UVgain, deficitgain, vmingain, smaller Q, smaller busID',
 'predeclared_diagnostics_K':[1,4,8],'unmeasured_top_candidates':'unknown, never assigned failure or success',
 'primary_learning_measure':'equal-world mean held-development standardized gain MSE; report untrained and final plus all losses/masks',
 'secondary':'same recorded-label oracle inclusion and raw lowestVm/Q ordering; no DSE superiority claim',
 'future_method_design_gate':'complete identities/checkpoint/costs and finite real gradients only; results inform a separately prospective next decision, no automatic GPU launch',
 'model_parameters':model.actual_parameters,'reference_original_adapter_parameters':8798208,'capacity_width':model.capacity_width,
 'capacity_difference':model.actual_parameters-8798208,'frozen_backbone_FLOPs_precision_architecture_not_matched':True,
 'data_manifest_sha256':sha(BASE/'input_and_target_contract_nullable_v2/manifest.json'),
 'cache_manifest_sha256':sha(CACHE/'manifest.json'),'readiness_sha256':sha(BASE/'numerical_software_readiness_v2/Readiness.json'),
 'independent_tensor_audit_sha256':sha(BASE/'tensor_external_audit/Independent_Tensor_and_Target_Audit.json'),
 'new_private_cloud_export_PF_controller_pretrained_calls':0,'no_grid_superiority_guarantee':True,
 'available_memory_at_declaration_bytes':psutil.virtual_memory().available,
 'prior_random_fixture_costs_remain_separate':{'new_random_forwards':3,'new_random_backwards':1,'optimizer_steps':0},
 'source_hashes':{('work/'+n):sha(ROOT/'work'/n) for n in ('candidate_process_runtime.py','candidate_process_numerical_predictor.py',
 'candidate_process_tensor_inputs.py','candidate_process_diagnostics.py','candidate_process_evidence_utils.py','run_candidate_process_numerical_pilot.py',
 'prepare_candidate_process_numerical_pilot.py','vcsa_common_information_control.py','vcsa_modules_v2.py','candidate_predictor_input_contract.py')}}
write(OUT/'protocol.json',protocol);write(OUT/'Fresh_Frozen_Preservation_Before.json',frozen_checks())
print(json.dumps({'declared_at_utc':protocol['declared_at_utc'],'model_parameters':model.actual_parameters,
 'actual_training_steps_planned':935,'actual_numerical_forwards_planned':1868,'active_optimization_worlds':len(counts),
 'max_scientific_wall_seconds':1200,'expected_training_seconds_from_new_random_step_only':935*(readiness['random_forward_seconds']+readiness['random_backward_seconds']),
 'not_a_GPUTiming_or_completion_guarantee':True},indent=2))
