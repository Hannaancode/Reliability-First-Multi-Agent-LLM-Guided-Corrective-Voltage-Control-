# Controller preservation: verified software scope and next execution

The new additive controller checkpoint retains the actual commitment cursor,
chronological commitment ledger, current state handle, failed signatures,
ordered native menus, all paid receipts and attempted identities, full local
state/failed-call artifact anchors, Python/NumPy RNG, runtime/input/source
identities, query/PF/storage/preservation costs and the original absolute
deadline. Read-only inspection first verifies externally supplied payload and
manifest hashes. Matching a self-authored manifest does not establish trust.

Two distinct software processes tested cold restoration on explicitly
synthetic three-bus tables. The warm process made two labelled mock solver
calls, one return and one exception. The cold process reused both receipts
without a solver call, then made one mock call for a different, previously
unexecuted action identity. The commitment cursor is a simulated one-step
cursor, not evidence of an actual physical commitment or trajectory. A
constructed unfinished-attempt fixture remained UNKNOWN and could not bind.

The first v1 source and its passed 23-check fixture are retained. Its planned
handoff checked owner termination but did not close the issuing journal. This
was caught before any real execution. The additive v2 makes a separately
externally anchored closed-phase receipt mandatory: the final issuing journal
must be the exact saved prefix plus the checkpoint-completion event, and no
query, registry or known cost change may follow that checkpoint. It also
inherits the issuing owner's final known checkpoint-preservation costs. The
old source and evidence were not overwritten or relabeled.

The v2 software gate passed 26 checks. A separate read-only reader verified
the source pins, ended distinct owners, both complete hash chains, controller
and receipt identities, the two cache reuses, the distinct new query, inherited
deadline/costs, explicit constructed UNKNOWN fixture and nine original frozen
asset checks. No real nonlinear PF, pretrained model, optimizer, forecast or
cloud call occurred. Archive: 32 members, 97,163 bytes,
SHA256 `fabffb9e01368b8a100a2335e76c2505fb604e4a0df5e4da0dbec1dbefdd8262`;
CRC and every member hash passed. Reuse the certificate, not repeated rehashes.

## Limits that still block a performance launch

- v1/v2 support one prospectively planned process handoff. After binding, a
  second controller checkpoint is explicitly refused. Linked multi-segment
  journals and repeated safe checkpoint boundaries are not implemented.
- No real full numerical coordinator process has yet been restored. Earlier
  L1 engineering restored a network and made cold following queries within
  its original owner; it did not test this new process-state handoff.
- Input/source/runtime and native scope/Q/cap/score/guard/field identities need
  a separately frozen real engineering protocol and external physical reader.
- Initial/commit costs live in the supplied controller ledger. The future
  owner must charge every such real call and validate that ledger. Synthetic
  direct-call counters here are zero, not an estimate of physical costs.
- Final cost-receipt writes, independent reader, process setup/transfer and
  full owned walltime require separate accounting. The snapshot's measured
  interval has an explicit boundary; unknown costs are not treated as free.
- This is a GLOBAL numerical coordinator. It does not certify the original
  LOCAL language interface, prove a useful two-step opportunity, demonstrate
  LLM superiority, establish novelty or calibrate a 90% success probability.

## Exact ordered continuation

1. Add linked multi-segment journal/cost preservation and repeated checkpoint
   validation without changing the frozen v1/v2 sources. Use labelled software
   fixtures first; retain all failed/UNKNOWN evidence. Never reset an absolute
   deadline, attempted identity registry or paid query/solver/storage counter.
2. Prepare one new, prospectively fixed real full-controller cold-process
   engineering protocol using an already declared development input, not the
   completed L1 owner or its budget. Fix source/input hashes, original native
   solver options, raw common AND zone scopes, original Q grid and 450 cap,
   unchanged score, common upper 1.05+1e-8, exact PID/parent/command handoff
   claims, full states/RNG/cursors, absolute total bound and independent reader
   before physics. A planned phase transition is distinct from restarting a
   terminal scientific study. Cache verification makes zero repeated queries;
   only prospectively listed unexecuted identities may generate new queries.
3. Implement the complete receding 25-step worker and unchanged original DFF,
   root-only DFF-ALT and selector portfolio. Preserve both branches separately
   and FULL BOTH costs, including literal zero/missing behavior. Freeze strong
   equally informed numerical controls and all eight development denominators,
   full economic allowance, failures, persistent ownership and independent
   continuous replay before any performance outcomes. Do not select width,
   roots, seed, Q, target or threshold from the inspected L1 prefix.
4. Only a surviving fixed physical/numerical opportunity can justify a separate
   causal language-learning study. Final claims still require fresh inference,
   matched protected full trajectories, full training/preparation/model/solver/
   failure costs, architecture/pretraining attribution and unused confirmation.

No new scientific or GPU owner is ready. The matched adapted scale gate and
all earlier failed methods remain stopped. Overall validated incremental LLM
advantage over original literal D-SE remains unachieved.
