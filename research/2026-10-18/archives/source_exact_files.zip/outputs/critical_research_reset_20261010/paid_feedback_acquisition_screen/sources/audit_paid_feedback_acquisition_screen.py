"""External saved trace/causality/score reader. No physics or model calls.

Query order is replayed with the frozen pure policy (software re-evaluation,
not an independent implementation of interpolation). Original scores/oracles,
denominators and gate arithmetic are independently derived here.
"""
import ast, copy, hashlib, json, os, time, zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended
from saved_query_receipt_anchored_dataset import open_anchored_OPT_administrator
from saved_query_receipt_dataset import digest
from paid_feedback_acquisition_inputs import load_priors
from paid_feedback_acquisition_control import ARMS, choose_query

S=extended(ROOT/'outputs/critical_research_reset_20261010/paid_feedback_acquisition_screen')
OUT=extended(ROOT/'outputs/critical_research_reset_20261010/paid_feedback_acquisition_audit')


def run():
    assert not OUT.exists(), 'Never duplicate/restart an external reader'
    summary=read(S/'Actual_Costs_And_Closure.json'); protocol=read(S/'Protocol.json')
    assert read(S/'status.json')['stage']==summary['scientific_status']
    OUT.mkdir(); started=time.perf_counter(); write(OUT/'audit.claim',{'actual_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__))})
    manifest=read(S/'Supplement_Manifest.json')
    with zipfile.ZipFile(S/'Saved_Replay.zip') as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
        for n,d in manifest.items():
            raw=z.read(n); assert len(raw)==d['bytes'] and hashlib.sha256(raw).hexdigest()==d['sha256'] and sha(S/n)==d['sha256']
    for n,h in {**protocol['source_sha256'],**protocol['prior_data_sha256'],**protocol['original_evidence_sha256']}.items(): assert sha(ROOT/n)==h,n
    assert sha(S/'Protocol.json')==summary['protocol_sha256']
    data=open_anchored_OPT_administrator(ROOT); reader_cost=Counter(); priors=load_priors(ROOT,data.inputs,reader_cost)
    # Execute ONLY the original pure score function, not its physical imports.
    path=ROOT/'work/e/audit/phase2g_rescue_runner.py'; tree=ast.parse(path.read_text(encoding='utf8'))
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='score_candidate')
    namespace={}; exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),namespace)
    score=namespace['score_candidate']; records=read(S/'All239_FourPolicy_Cases.json'); assert len(records)==956
    expected={(oid,arm) for oid in data.inputs for arm in ARMS}; assert {(r['observation_id'],r['arm']) for r in records}==expected
    indices=read(S/'Actual_Input_Identities.json'); assert len(indices)==239 and {r['observation_id'] for r in indices}==set(data.inputs)
    for r in indices: assert r['actor_priors_sha256']==digest(priors[r['observation_id']]) and r['model_input_sha256']==data.inputs[r['observation_id']]['model_input_sha256']
    results=[]; actual_queries=0; unsafe=0; source_lookup_calls=0; replay_cost=Counter()
    for r in records:
        oid=r['observation_id']; inp=data.inputs[oid]; assert r['world_sha256']==inp['world_sha256']
        legal={(p['bus'],p['Q_index']) for p in priors[oid]['old_admittance_derivative']}; grid=inp['model_input']['original_Q_grid']
        assert all({(p['bus'],p['Q_index']) for p in priors[oid][v]}==legal for v in priors[oid])
        accepted={a:v for a,v in data.receipts[oid].items() if a in legal and v.get('accepted') is True and v.get('converged') is True}
        measured={a:tuple(score({'verif':v,'action':{'add_shunts_q_mvar':{str(a[0]):grid[a[1]]}}})) for a,v in accepted.items()}
        best=max(measured.values(),default=None); oracle={a for a,v in measured.items() if v==best}
        complete=legal.issubset(data.receipts[oid]); session=data.session(oid,max_requests=9); view=session.actor_view(); queried=[]
        for item in r.get('queries',[]):
            request=item['request']; pair=request['bus'],request['Q_index']; assert pair in legal and pair not in queried
            assert choose_query(view,priors[oid],r['arm'],replay_cost)==request
            response=session.query(request); assert response==item['response']; queried.append(pair); view=session.actor_view(); actual_queries+=1
        if r['status']=='complete_saved_one_state_replay':
            assert len(queried)==min(8,len(legal))
            eligible={a:measured[a] for a in queried if a in measured}
            selected=max(eligible,key=lambda a:(*eligible[a],-a[0],-a[1])) if eligible else None
            actual=tuple(r['selection'][k] for k in ('bus','Q_index')) if r['selection'] else None
            assert actual==selected and (actual is None or actual in queried)
            terminal=session.commit(r['selection']) if actual else session.abstain()
            assert {k:v for k,v in terminal.items() if k!='next_current_state'}==r['terminal_operation']
            assert terminal['status'] in ('saved_commitment_eligible_no_live_physics','explicit_abstention_no_live_physics')
            unsafe+=int(actual is not None and actual not in accepted)
        else: actual=None
        source_lookup_calls+=session.administrator_ledger()['saved_receipt_lookup_calls']
        prefix={}
        for k in (1,4,8):
            qq=queried[:k]; enough=len(qq)==min(k,len(legal)) and r['status']=='complete_saved_one_state_replay'
            hit=bool(set(qq)&oracle) if oracle and complete and enough else None
            prefix[str(k)]={'recorded_best_inclusion':hit,'known_accepted':sum(a in accepted for a in qq),
                'known_rejected':sum(a in data.receipts[oid] and a not in accepted for a in qq),'UNKNOWN_unmeasured':sum(a not in data.receipts[oid] for a in qq)}
        results.append({'observation_id':oid,'world_sha256':r['world_sha256'],'arm':r['arm'],'oracle_exists':bool(oracle),
            'all_legal_receipts_known':complete,'all_input_optimal_or_abstain_bounds':([int(actual in oracle),int(actual in oracle)] if oracle else [int(actual is None),int(actual is None)]) if complete and r['status']=='complete_saved_one_state_replay' else [0,1],
            'K':prefix,'protected_zero_UV_selection':bool(actual in measured and measured[actual][0]==1), 'actual_query_count':len(queried)})
    journal=[json.loads(line) for line in (S/'Actual_Saved_Replay_Journal.jsonl').read_text(encoding='utf8').splitlines()]; counts=Counter(x['event'] for x in journal)
    assert [x['event_index'] for x in journal]==list(range(1,len(journal)+1))
    assert counts['case_closed']==956 and counts['saved_query_attempt']==counts['saved_query_return']==actual_queries==summary['costs']['saved_query_attempts']==summary['costs']['saved_query_returns']
    assert counts['policy_attempt']==counts['policy_return']==actual_queries==summary['costs']['policy_attempts']==summary['costs']['policy_returns']
    assert replay_cost['candidate_priority_evaluations']==summary['costs']['candidate_priority_evaluations']
    assert replay_cost['interpolated_metric_estimates']==summary['costs']['interpolated_metric_estimates']
    assert counts['case_closed']==len(records) and len(journal)==summary['costs']['journal_events']
    case_events={(e['observation_id'],e['arm']):e['case'] for e in journal if e['event']=='case_closed'}
    assert case_events=={(r['observation_id'],r['arm']):r for r in records}
    for column in ('saved_API_events','saved_receipt_lookups','saved_successor_lookups'):
        field='actual_saved_API_events' if column=='saved_API_events' else column
        assert sum(r.get(field,0) for r in records)==summary['costs'].get(column,0)
    # Full trace binding, including actual causal input digest BEFORE each query.
    events={(x['observation_id'],x['arm'],x['query_index'],x['event']):x for x in journal if 'query_index' in x}
    assert len(events)==4*actual_queries
    for r in records:
        oid=r['observation_id']; session=data.session(oid,max_requests=9)
        for qi,item in enumerate(r.get('queries',[])):
            key=oid,r['arm'],qi
            assert events[(*key,'policy_attempt')]['actor_view_sha256']==digest(session.actor_view())
            assert events[(*key,'policy_attempt')]['actor_priors_sha256']==digest(priors[oid])
            assert events[(*key,'policy_return')]['command']==events[(*key,'saved_query_attempt')]['command']==item['request']
            assert events[(*key,'saved_query_return')]['response']==item['response']; session.query(item['request'])
    worlds=sorted({r['world_sha256'] for r in data.inputs.values()}); assert len(worlds)==23 and unsafe==0
    aggregate={}
    for arm in ARMS:
        aa=[r for r in results if r['arm']==arm]; byworld={}
        for world in worlds:
            ww=[r for r in aa if r['world_sha256']==world]; oo=[r for r in ww if r['oracle_exists']]
            byworld[world]={'all_inputs':len(ww),'oracle_states':len(oo),'missing_label_states':sum(not r['all_legal_receipts_known'] for r in ww),
                'K8_lower':sum(r['K']['8']['recorded_best_inclusion'] is True for r in oo)/len(oo) if oo else None,
                'K8_upper':sum(r['K']['8']['recorded_best_inclusion'] is not False for r in oo)/len(oo) if oo else None,
                'all_input_lower':sum(r['all_input_optimal_or_abstain_bounds'][0] for r in ww)/len(ww),
                'all_input_upper':sum(r['all_input_optimal_or_abstain_bounds'][1] for r in ww)/len(ww)}
        relevant=[v for v in byworld.values() if v['oracle_states']]
        aggregate[arm]={'K8_equal_world_lower':sum(v['K8_lower'] for v in relevant)/len(relevant),'K8_equal_world_upper':sum(v['K8_upper'] for v in relevant)/len(relevant),
            'recorded_oracle_states':sum(v['oracle_states'] for v in byworld.values()),'K8_known_hits':sum(r['K']['8']['recorded_best_inclusion'] is True for r in aa),
            'all_input_equal_world_bounds':[sum(v['all_input_lower'] for v in byworld.values())/23,sum(v['all_input_upper'] for v in byworld.values())/23],
            'query_outcomes':{n:sum(r['K']['8'][n] for r in aa) for n in ('known_accepted','known_rejected','UNKNOWN_unmeasured')},'all23_world_denominators':byworld}
        assert len(aa)==239 and sum(v['missing_label_states'] for v in byworld.values())==52 and aggregate[arm]['recorded_oracle_states']==176
    strongest=max(aggregate[a]['K8_equal_world_lower'] for a in ARMS)
    feedback_gates={}
    for a in ('old_feedback','candidate_feedback'):
        differences={b:aggregate[a]['K8_equal_world_lower']-aggregate[b]['K8_equal_world_upper'] for b in ('old_static','candidate_static')}
        positive={b:sum(aggregate[a]['all23_world_denominators'][w]['K8_lower'] is not None and aggregate[a]['all23_world_denominators'][w]['K8_lower']>aggregate[b]['all23_world_denominators'][w]['K8_upper'] for w in worlds) for b in differences}
        feedback_gates[a]={'conservative_equal_world_deltas':differences,'strictly_positive_worlds':positive,
            'passed':all(d>=.05 for d in differences.values()) and all(n>=3 for n in positive.values()) and unsafe==0}
    decision={'fixed_K8_headroom_upper':1-strongest,'five_point_headroom_possible':1-strongest>=.05,'numerical_feedback_mechanism_gate':feedback_gates,
        'economic_gate':'UNKNOWN_per_query_physical_and_new_LLM_costs_unmeasured','LLM_method_gate':'NOT_ESTABLISHED_no_language_or_trained_acquisition_control',
        'automatic_GPU_training_or_physical_launch':False,'not_a_universal_failure_or99percent_success_proof':True,
        'decision':'Proceed only to further justified mechanism/strong-trained-control design if support warrants it; do not launch an LLM from saved-replay counts or headroom alone.'}
    proof={'all_passed':True,'exact_cases':956,'all239_inputs_23_worlds_72_held_blocked':True,'actual_saved_query_trace_checks':actual_queries,
        'unsafe_or_unqueried_commits':unsafe,'original_pure_score_source_sha256':sha(path),'all_original_frozen_preserved':True,
        'query_order_uses_frozen_policy_not_independently_implemented_interpolation':True,
        'new_reader_model_PF_optimizer_native_forecast_linear_solve_calls':0,'reader_policy_priority_and_metric_arithmetic':dict(replay_cost),
        'reader_seconds_before_seal':time.perf_counter()-started,'source_lookup_software_calls':source_lookup_calls}
    write(OUT/'Independent_Causal_Trace_and_Score_Audit.json',proof); write(OUT/'All_State_Results.json',results)
    write(OUT/'All_Arm_Results.json',aggregate); write(OUT/'Prospective_Gate_Decision.json',decision); write(OUT/'Fresh_Frozen_Asset_Checks.json',frozen_checks())
    (OUT/'Results.md').write_text('Saved-only numerical acquisition screen; all historic OPT inputs retained. No new physical episode or LLM value demonstrated. Candidate residual estimates and reader policy re-evaluation are actual charged numerical arithmetic. All original labels, native forecast/preparation and failure costs remain separate and paid. Conditional oracle metrics and all-input missing-evidence bounds are development evidence, not unused confirmation or statistical confidence intervals.\n\n'+json.dumps({'K8':{a:{k:v for k,v in m.items() if k!='all23_world_denominators'} for a,m in aggregate.items()},'gates':decision,'actual_screen_costs':summary,'reader':proof},indent=2)+'\n',encoding='utf8')
    files={f.name:f for f in OUT.iterdir() if f.is_file() and f.name!='audit.claim'}; files['sources/reader.py']=Path(__file__)
    archive=seal(OUT,files,'External_Audit.zip'); write(OUT/'status.json',{'stage':'complete_external_saved_trace_audit'})
    print(json.dumps({'audit':proof,'K8':{a:m['K8_equal_world_lower'] for a,m in aggregate.items()},'gates':decision,'archive':archive}))

if __name__=='__main__': run()
