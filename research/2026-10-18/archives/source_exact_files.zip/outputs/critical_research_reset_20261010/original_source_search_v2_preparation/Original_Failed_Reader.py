"""Read-only source/report search; never executes archived code or pickle."""
import hashlib
import json
import os
import re
import time
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended

DESKTOP=Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm')
OUT=extended(ROOT/'outputs/critical_research_reset_20261010/original_training_source_search')
PATTERN=re.compile(r'SFTTrainer|train_on_responses_only|max_seq_length|max_length|packing|dataset_text_field|formatting_func|DataCollator|response_template|gradient_accumulation_steps|zone_agent_shared_lora_qwen05b_ultra_v1',re.I)
SOURCE_EXTENSIONS={'.py','.ipynb','.md','.txt'}
LIMIT_BYTES=2*1024*1024

def content_text(name,raw):
    if name.lower().endswith('.ipynb'):
        notebook=json.loads(raw)
        return '\n'.join(''.join(cell.get('source',[])) for cell in notebook.get('cells',[]))
    return raw.decode('utf8',errors='replace')

def run():
    assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
    write(OUT/'search.claim',{'actual_pid':os.getpid(),'source_sha256':sha(Path(__file__)),'at_utc':datetime.now(timezone.utc).isoformat()})
    files=sorted(p for p in DESKTOP.iterdir() if p.is_file() and p.suffix.lower() in SOURCE_EXTENSIONS|{'.zip','.docx'})
    protocol={'declared_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'All supplied Desktop ZIP central directories, code/notebook/text members and Word report text',
        'declared_original_file_names':[p.name for p in files],'member_limit_bytes':LIMIT_BYTES,'total_code_text_read_limit_bytes':64*1024*1024,
        'resource_bound_seconds':60,'archives_and_documents_read_only':True,'no_archived_code_pickle_notebook_execution':True,
        'candidate_text_not_proof_of_actual_training_run':True,'unknown_unread_members_retained':True,
        'no_model_PF_optimizer_forecast_controller_cloud_calls':True}
    write(OUT/'Prospective_Source_Search_Protocol.json',protocol)
    rows=[];matches=[];total_bytes=0;counts={'archive_central_directories':0,'read_source_or_report_members':0,'matched_members':0}
    for path in files:
        if time.perf_counter()-started>60:
            rows.append({'source':path.name,'status':'UNKNOWN_unexecuted_resource_bound'});continue
        if path.suffix.lower() in {'.zip','.docx'}:
            with zipfile.ZipFile(path) as archive:
                infos=archive.infolist();counts['archive_central_directories']+=1
                central=[(i.filename,i.file_size,i.CRC) for i in infos]
                rows.append({'source':path.name,'status':'central_directory_read','bytes':path.stat().st_size,
                    'member_count':len(infos),'central_name_size_CRC_sha256':hashlib.sha256(json.dumps(central,separators=(',',':')).encode()).hexdigest(),
                    'full_archive_hash_not_recomputed':True})
                if path.suffix.lower()=='.docx':
                    infos=[i for i in infos if i.filename=='word/document.xml']
                else:infos=[i for i in infos if Path(i.filename).suffix.lower() in SOURCE_EXTENSIONS and not i.is_dir()]
                for info in infos:
                    key=path.name+'::'+info.filename
                    if info.file_size>LIMIT_BYTES or total_bytes+info.file_size>64*1024*1024 or time.perf_counter()-started>60:
                        rows.append({'source':key,'status':'UNKNOWN_unread_resource_limit','bytes':info.file_size});continue
                    raw=archive.read(info);total_bytes+=len(raw)
                    if path.suffix.lower()=='.docx':
                        tree=ET.fromstring(raw);ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                        text='\n'.join(''.join(p.itertext()) for p in tree.findall('.//w:p',ns))
                    else:text=content_text(info.filename,raw)
                    inspect(key,raw,text,rows,matches,counts)
        else:
            if path.stat().st_size>LIMIT_BYTES or total_bytes+path.stat().st_size>64*1024*1024:
                rows.append({'source':path.name,'status':'UNKNOWN_unread_resource_limit','bytes':path.stat().st_size});continue
            raw=path.read_bytes();total_bytes+=len(raw);inspect(path.name,raw,content_text(path.name,raw),rows,matches,counts)
    write(OUT/'All_Declared_Files_And_Source_Member_Statuses.json',rows)
    write(OUT/'Training_And_Loader_Source_Matches.json',matches)
    summary={'at_utc':datetime.now(timezone.utc).isoformat(),'counts':counts,'actual_source_or_report_bytes_read':total_bytes,
        'unread_unknown_records':sum(r['status'].startswith('UNKNOWN') for r in rows),
        'workflow_seconds_before_frozen_checks_and_seal':time.perf_counter()-started,
        'original_training_script_execution_identity_not_inferred_from_keyword_matches':True,
        'inference_loader_max_seq_length_not_assumed_training_or_actual_truncation':True,
        'new_model_PF_optimizer_forecast_controller_cloud_calls':0,'automatic_GPU_or_training_launch':False}
    write(OUT/'Source_Search_Summary.json',summary);write(OUT/'Fresh_Frozen_Asset_Checks.json',frozen_checks())
    members={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='search.claim'};members['sources/reader.py']=Path(__file__)
    print(json.dumps({'summary':summary,'archive':seal(OUT,members,'Source_Search.zip')}))

def inspect(key,raw,text,rows,matches,counts):
    lines=text.splitlines();indices=[n for n,line in enumerate(lines) if PATTERN.search(line)]
    counts['read_source_or_report_members']+=1
    rows.append({'source':key,'status':'read_only_scanned','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'matched_lines':len(indices)})
    if indices:
        counts['matched_members']+=1
        matches.append({'source':key,'sha256':hashlib.sha256(raw).hexdigest(),
            'line_number_convention':'Extracted notebook cell source / XML paragraph text / decoded file text; not necessarily original document page',
            'matches':[{'line':i+1,'text':lines[i],'context':lines[max(0,i-2):min(len(lines),i+3)]} for i in indices]})

if __name__=='__main__':run()
