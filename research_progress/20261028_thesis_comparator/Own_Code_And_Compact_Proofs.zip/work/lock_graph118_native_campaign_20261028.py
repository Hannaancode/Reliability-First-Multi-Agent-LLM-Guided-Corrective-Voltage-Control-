"""Final source and runtime admission; no scientific call or allocation."""
from graph118_native_campaign_core_20261028 import *
def main():
    p=read(P/'Protocol.json');pins(p)
    integration='outputs/graph118_native_campaign_runtime_v2_20261028/Result.json';gate=read(R/integration)
    assert gate['status']=='PASS_ALL4_NEW_CAMPAIGN_PROVIDER_INTEGRATION_NO_PHYSICS' and gate['new_PF_model_calls']==0
    for n,h in gate['source_hashes'].items():
        if n not in ['work/run_graph118_native_campaign_20261028.py','work/audit_graph118_native_campaign_20261028.py']:assert sha(R/n)==h
    assert not E.exists() and not A.exists()
    additional=['work/coordinate_graph118_native_campaign_20261028.py','work/coordinate_native_inverter_linear_reference_20261020.py',
                'work/native_solver_input_identity_20261023.py','work/candidate_process_runtime.py','work/lock_graph118_native_campaign_20261028.py']
    put(P/'Launch_And_Reader_Lock.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_ALL4_NATIVE_CAMPAIGN_READY_AFTER_EXACT_OWNER_ABSENCE',
        python=str((R/'work/physics_env/Scripts/python.exe').resolve()),versions={'pandas':'2.3.3','numpy':'2.0.2','pandapower':'3.4.0','networkx':'3.6.1'},
        additional_source_hashes={n:sha(R/n) for n in additional},integration_result=integration,integration_sha256=sha(R/integration),
        protocol_sha256=sha(P/'Protocol.json'),review='Same policy/actuator/guard/cap/source paths. Preserved preflight failure used documentation pandas3.0.1; established science runtime2.3.3 passes. Preflight-only pending-state amendment preserves the partial audit instead of asserting completion. No new outcomes inspected.',
        original_engineering_failure='outputs/graph118_native_campaign_integration_20261028/Failure.json',
        engineering_costs=gate['costs'],new_science_before_launch=0,reader_first_replays_only_new_returns=True,
        native_track_not_equal_actuator_budget_or_causal_LLM_claim=True))
    print('FROZEN_READY_REQUIRES_FRESH_ACTUAL_OWNER_CHECK')
if __name__=='__main__':main()
