"""Joint external exact phase/checkpoint/action/cost audit; no model/PF calls."""
import candidate_process_runtime
import gzip,json,os,subprocess,time,torch
from collections import Counter
from datetime import datetime,timezone
from candidate_process_evidence_utils import ROOT,read,write,sha,seal,frozen_checks
from relational_learning_full_state import verify
from relational_control_learning_metrics import aggregate_rows,saved_native_diagnostic
from native_decision_preference_objective import native_decision_order
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';PREP=P/'learning_preparation';OUT=P/'lm_audit';C=P/'current_relational_tensor_cache_v2'
assert not OUT.exists();OUT.mkdir();write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()});start=time.perf_counter();torch.set_num_threads(2)
proto=read(PREP/'protocol.json');protocol_sha=sha(PREP/'protocol.json');index=read(PREP/'Input_Index.json');by={r['observation_id']:r for r in index}
opt=[r for r in index if r['split']=='optimization'];targets={r['observation_id']:r for r in read(PREP/'Target_Index.json')}
assert len(index)==311 and len(opt)==239
for n,h in read(PREP/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha(ROOT/n)==h
for r in index:assert sha(PREP/r['input_file'])==r['sha256']
for r in targets.values():assert sha(PREP/r['target_file'])==r['sha256']
with gzip.open(ROOT/'outputs/llm_value_candidate_development_20261009/input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz','rt',encoding='utf8') as f:raw={r['observation_id']:r for r in map(json.loads,f)}
all_results={};certificates={};allrows={};sources={};total_pairs=0
for arm in proto['arms']:
    E=P/('lm_i' if arm=='internal_residual' else 'lm_f');S=E/'staged/study';sources[arm]=(E,S)
    state=read(E/'status.json');owner=int((E/'owner.claim').read_text())
    command=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={owner}'; if ($p -and $p.CommandLine -match 'run_relational_learning_colab.py') {{ 'LIVE' }} else {{ 'ENDED' }}"
    seen=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,timeout=30);assert seen.stdout.strip()=='ENDED'
    assert state['arm']==arm and state['expected_account']==proto['profiles'][arm]['account']
    assert state['runtime_released'] and state['all_actual_artifacts_preserved'] and state['remote_exit_code']==0 and state['allocation_requests']==1
    assert read(E/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}} and read(E/'staged/remote_frozen_environment.json')==read(PREP/'Expected_Environment.json')
    descriptor=read(E/'remote_output_descriptor.json')
    for n,v in descriptor['members'].items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
    for n,v in read(S/'Closed_Actual_Manifest.json').items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
    assert read(S/'protocol.json')==proto
    events=[json.loads(v) for v in (S/'events.jsonl').read_text().splitlines()];assert events[-1]['event']=='arm_science_complete'
    summary=read(S/'summary.json');counts=summary['actual_counts']
    assert counts['forward_attempts']==counts['forward_returns']==2128 and counts['forward_exceptions']==0
    assert counts['backward_attempts']==counts['backward_returns']==counts['optimizer_attempts']==counts['optimizer_returns']==1195
    assert counts['native_supervised_steps']==935 and counts['grounding_only_steps']==260 and counts['PF_attempts']==counts['generation_attempts']==0
    assert counts['phase_forward_returns']==proto['expected_phase_forward_counts']
    returns=[e for e in events if e['event']=='forward_return'];attempts=[e for e in events if e['event']=='forward_attempt'];assert len(returns)==len(attempts)==2128
    for phase in ('untrained','final','reload'):
        assert [e['observation_id'] for e in returns if e['phase']==phase]==[r['observation_id'] for r in index]
    assert [e['observation_id'] for e in returns if e['phase']=='train']==[r['observation_id'] for r in opt]*5
    costs={'input_load_and_hash_seconds':('input_loaded','seconds'),'target_load_and_hash_seconds':('target_loaded_outside_forward','seconds'),
      'forward_and_reconstruction_seconds':('forward_return','seconds'),'backward_finite_clip_seconds':('backward_return','seconds'),
      'optimizer_seconds':('optimizer_return','seconds'),'checkpoint_write_seconds':('complete_checkpoint_closed','seconds'),
      'preservation_ACK_wait_seconds':('package_acknowledged','seconds')}
    for field,(event,key) in costs.items():
        actual=sum(e[key] for e in events if e['event']==event);assert abs(actual-counts[field])<=1e-9*max(1.,abs(actual)),field
    for field,key in [('soft_positions','soft_positions'),('typed_cells','typed_cells'),('value_UTF8_bytes','value_UTF8_bytes')]:assert counts[field]==sum(e[key] for e in returns)
    training=[e for e in events if e['event']=='optimizer_return'];backwards=[e for e in events if e['event']=='backward_return']
    assert len(training)==len(backwards)==1195;update_counts=Counter()
    for i,(e,b) in enumerate(zip(training,backwards)):
        r=opt[i%239];assert e['observation_id']==b['observation_id']==r['observation_id'] and e['world_sha256']==r['world_sha256']
        assert e['epoch']==b['epoch']==i//239+1 and e['offset']==b['offset']==i%239 and e['steps']==i+1 and e['world_weight']==r['world_weight']
        d=e['loss_terms'];expected=d['current_grounding']
        assert d['native_supervision']==(r['observation_id'] in targets)
        if d['native_supervision']:expected+=d['classification']+d['native_pairwise_rank']
        assert abs(e['weighted_loss']-expected*r['world_weight'])<=1e-5*max(1.,abs(e['weighted_loss']))
        update_counts.update(b['gradient_parameter_names'])
    registry=read(S/'Active_Parameter_Registry.json');assert set(registry)==set(update_counts) and sum(__import__('math').prod(v) for v in registry.values())==proto['active_parameters'][arm]
    assert read(S/'Final_Gradient_Participation.json')==dict(update_counts)
    contract={'study_id':proto['study_id'],'protocol_sha256':protocol_sha,'arm':arm,'cache_manifest_sha256':proto['cache_manifest_sha256'],'common_initialization_sha256':proto['common_initialization_sha256']}
    checkpoints=[e for e in events if e['event']=='complete_checkpoint_closed'];assert [e['steps'] for e in checkpoints]==proto['expected_checkpoint_steps']
    for steps in [0]+proto['expected_checkpoint_steps']:
        f=S/'checkpoints'/f's{steps:04d}.pt';ck=torch.load(f,weights_only=False);assert verify(ck,contract,steps) and len(ck['rng']['torch_CUDA'])==1
        expected_updates=Counter(n for b in backwards[:steps] for n in b['gradient_parameter_names'])
        assert ck['parameter_gradient_steps']=={n:expected_updates[n] for n in registry}
        assert sum(ck['optimizer_group_names'],[])==list(registry)
        if steps:
            assert sha(f)==next(e['sha256'] for e in checkpoints if e['steps']==steps)
        assert sum(t.numel() for t in ck['active_parameters'].values())==proto['active_parameters'][arm]
    acknowledgements=read(E/'Preservation_Acknowledgement_Ledger.json');assert len(acknowledgements)==summary['actual_ACK_packages']==38
    prefix=b''
    for num,ack in enumerate(acknowledgements):
        package=E/'packages'/f'package_{num:03d}';d=read(package/'descriptor.json')
        assert d['number']==num and d['journal_offset']==len(prefix) and read(package/'CPU_Full_State_Verification.json')['all_passed']
        import zipfile,hashlib
        with zipfile.ZipFile(package/'artifact_package.zip') as z:delta=z.read('journal_delta.jsonl')
        assert hashlib.sha256(prefix).hexdigest()==d['journal_previous_sha256'];prefix+=delta
        assert hashlib.sha256(prefix).hexdigest()==d['journal_prefix_sha256'] and len(prefix)==d['journal_prefix_bytes']
        assert ack['archive_sha256']==d['archive_sha256'] and ack['journal_prefix_sha256']==d['journal_prefix_sha256']
    assert (S/'events.jsonl').read_bytes().startswith(prefix)
    results={};final_rows=[]
    for phase in ('untrained','final','reload'):
        packages={}
        for f in sorted((S/phase).glob('p*.pt')):
            batch=torch.load(f,weights_only=True);assert not set(batch).intersection(packages);packages.update(batch)
        assert set(packages)==set(by) and len(packages)==311;rows=[]
        if phase=='reload':
            final={}
            for f in (S/'final').glob('p*.pt'):final.update(torch.load(f,weights_only=True))
        for r in index:
            ident=r['observation_id'];v=packages[ident];pred=v['prediction'];num=v['current_numeric_reconstruction']
            assert v['source_current_input_sha256']==r['source_current_input_sha256'] and pred.shape==(118,9,3) and num.shape==(r['cells'],)
            assert bool(torch.isfinite(pred).all()) and bool(torch.isfinite(num).all())
            inp=torch.load(PREP/r['input_file'],weights_only=False);allowed=torch.tensor(inp['model_input']['allowed_actions'],dtype=torch.bool)
            mask=torch.tensor(inp['current_input_reconstruction_mask'],dtype=torch.bool);actual=torch.tensor(inp['model_input']['numeric'],dtype=torch.float32)[:,0]
            item={k:r[k] for k in ('observation_id','world_sha256','split')};item['current_grounding_MSE']=float(((num[mask]-actual[mask])**2).mean())
            if ident in raw:
                item['diagnostic']=saved_native_diagnostic(pred,allowed,raw[ident]);target=torch.load(PREP/targets[ident]['target_file'],weights_only=True)
                for j,key in [(0,'accepted_Brier'),(1,'convergence_Brier')]:
                    m=target['classification_mask'][...,j];item[key]=float(((torch.sigmoid(pred[...,j][m])-target['classification'][...,j][m])**2).mean()) if bool(m.any()) else None
            else:item['unlabelled_selection']={str(k):{'selected':len(native_decision_order(pred,allowed)[:k]),'all_outcomes_unknown':True} for k in (1,4,8)}
            if phase=='reload':
                assert torch.equal(final[ident]['prediction'],pred) and torch.equal(final[ident]['current_numeric_reconstruction'],num);total_pairs+=1
            rows.append(item)
        results[phase]=aggregate_rows(rows)
        if phase=='final':final_rows=rows
    assert results['final']==results['reload'];all_results[arm]=results;allrows[arm]=final_rows
    for file in ('Initial_Load_Certificate.json','Fresh_Model_Load_Certificate.json'):
        l=read(S/file);assert l['actual_new_active_parameters']==proto['active_parameters'][arm] and l['private_tensors_before_attachment']==336
        assert l['old_tensor_object_registry']['all_quantization_objects_preserved']>0 and l['body_loader']['four_bit_base']
    assert summary['old_tensor_values_objects_masks_quantization_preserved']
    certificates[arm]={'all2128exact_phase_returns1195ordered_worldweighted_steps':True,'all17complete_zero_plus_training_checkpoints':True,
      'gradient_participation_moments_and_delta_hash_ACK_chain_verified':True,'all311final_fresh_scores_and_reconstruction_exact':True,
      'all_frozen_private_quantization_framework_gates_passed':True,'all_source_cost_identity_denominator_and_selection_gates_passed':True,
      'actual_counts':counts,'science_seconds_including_nested_preservation':summary['actual_science_workflow_seconds'],
      'owned_runtime_seconds':(datetime.fromisoformat(state['finished_at_utc'])-datetime.fromisoformat(state['started_at_utc'])).total_seconds(),
      'memory':{k:v for k,v in summary.items() if k.startswith('CUDA_')}}
assert total_pairs==622
controls=read(PREP/'Prospective_Strong_Control_Reference.json');best_name=max(controls,key=lambda n:controls[n]['development_held']['topK']['4']['equal_world_best_inclusion']);strong=controls[best_name]['development_held']['topK']['4']
i=all_results['internal_residual']['final']['development_held']['topK']['4'];f=all_results['frozen_capacity_head']['final']['development_held']['topK']['4']
assert set(i['world_rates'])==set(f['world_rates'])==set(strong['world_rates']) and i['recorded_oracle_states']==f['recorded_oracle_states']==49
positives_f=sum(i['world_rates'][w]>f['world_rates'][w] for w in i['world_rates']);positives_s=sum(i['world_rates'][w]>strong['world_rates'][w] for w in i['world_rates'])
gates={'margin_above_frozen_head':i['equal_world_best_inclusion']-f['equal_world_best_inclusion']>=.05,
 'margin_above_strongest_control':i['equal_world_best_inclusion']-strong['equal_world_best_inclusion']>=.05,
 'positive_two_worlds_against_frozen_head':positives_f>=2,'positive_two_worlds_against_strongest_control':positives_s>=2,
 'no_increased_known_rejected_fraction_vs_both':i['known_rejected_fraction']<=min(f['known_rejected_fraction'],strong['known_rejected_fraction']),
 'no_new_missing_nonfinite_identity':True}
decision={'all_fixed_development_gates_passed':all(gates.values()),'gates':gates,'internal_primary_top4':i,'frozen_head_primary_top4':f,
 'strongest_control_name':best_name,'strongest_control_primary_top4':strong,
 'decision':'Separately justify fresh physical and pretraining attribution plan' if all(gates.values()) else 'STOP this intervention/dataset: fixed incremental gate failed; no minor retunes/retraining/rollout',
 'historical_development_not_unused_confirmation':True,'no_novelty_DSE_superiority_fullsecurity_or_goal_achievement_claim':True}
write(OUT/'Actual_All_Arm_Results.json',all_results);write(OUT/'All622_Final_State_Diagnostics.json',allrows);write(OUT/'Fixed_Prospective_Gate_Decision.json',decision)
audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'actual_arm_certificates':certificates,'actual_optimizer_steps_total':2390,
 'actual_pretrained_forwards_total':4256,'actual_fresh_reload_pairs':622,'all_profiles_exact_release_before_audit':True,
 'new_model_optimizer_PF_cloud_calls_by_reader':0,'actual_reader_seconds_before_seal':time.perf_counter()-start}
write(OUT/'Independent_Actual_Learning_Audit.json',audit);write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
text=f"The two fixed pretrained arms completed and passed the source/identity/framework/full checkpoint/gradient-participation/cost/action audit.2390 actual optimizer steps,4256 real model forwards,622 exact fresh prediction/reconstruction replay pairs. Original private/base tensors preserved; both exact runtimes released.\n\nHeld equal-world top4: internal {i['equal_world_best_inclusion']:.9f}, matched frozen head {f['equal_world_best_inclusion']:.9f}, strongest {best_name} control {strong['equal_world_best_inclusion']:.9f}. Fixed development decision: {decision['decision']}. All K1/4/8/world/pool/rejection/unknown/failure/cost outcomes retained. No physical rollout, unused confirmation, novelty or D-SE superiority claim. Historical development, not a fresh holdout.\n"
(OUT/'Results.md').write_text(text,encoding='utf8')
files={}
for arm,(E,S) in sources.items():
    for n in read(E/'remote_output_descriptor.json')['members']:files[arm+'/science/'+n]=S/n
    files[arm+'/actual_owner_status.json']=E/'status.json';files[arm+'/preservation_ACKs.json']=E/'Preservation_Acknowledgement_Ledger.json'
for file in OUT.iterdir():
    if file.is_file() and file.name!='audit.claim':files['audit/'+file.name]=file
files['protocol.json']=PREP/'protocol.json';files['source/audit.py']=ROOT/'work/audit_relational_learning_results.py'
files['strong_controls_reference.json']=PREP/'Prospective_Strong_Control_Reference.json';files['prior_costs.json']=PREP/'Prior_Physical_Data_and_Numerical_Cost_References.json'
seal(OUT,files,'Verified_Relational_Two_Arm_Learning.zip');write(OUT/'status.json',{'stage':'complete_joint_learning_audit','all_passed':True})
print(json.dumps({'audit_passed':True,'decision':decision},indent=2))
