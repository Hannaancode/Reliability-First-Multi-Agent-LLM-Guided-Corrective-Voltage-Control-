"""Direct exact typed input equality; never a point-ID/hash replacement."""
import numpy as np,pandas as pd
from audit_spatial_allocation_inputs_v3_20261011 import typed

def same_inputs(a,b):
    ka={k for k,v in a.items() if isinstance(v,pd.DataFrame) and not k.startswith('res_')}
    kb={k for k,v in b.items() if isinstance(v,pd.DataFrame) and not k.startswith('res_')}
    if ka!=kb:return False
    for name in ka:
        x,y=a[name],b[name]
        if x.shape!=y.shape:return False
        if type(x.index).__name__!=type(y.index).__name__ or str(x.index.dtype)!=str(y.index.dtype):return False
        if type(x.columns).__name__!=type(y.columns).__name__:return False
        for left,right in [(list(x.index.names),list(y.index.names)),(list(x.index),list(y.index)),
                           (list(x.columns.names),list(y.columns.names)),(list(x.columns),list(y.columns))]:
            if typed(left)!=typed(right):return False
        if [str(d) for d in x.dtypes]!=[str(d) for d in y.dtypes]:return False
        for (_,left),(_,right) in zip(x.items(),y.items()):
            u=left.to_numpy();v=right.to_numpy()
            numeric=(u.dtype.kind in 'biu' and u.dtype.itemsize<=8) or (u.dtype.kind=='f' and u.dtype.itemsize in (2,4,8))
            if numeric and u.dtype==v.dtype:
                if u.dtype.kind=='f':
                    if not np.array_equal(u,v,equal_nan=True):return False
                    zero=u==0
                    if not np.array_equal(np.signbit(u[zero]),np.signbit(v[zero])):return False
                elif not np.array_equal(u,v):return False
            elif [typed(value) for value in u]!=[typed(value) for value in v]:return False
    return True

def assert_same_inputs(a,b):
    if not same_inputs(a,b):raise AssertionError('Exact non-result input tables differ')
