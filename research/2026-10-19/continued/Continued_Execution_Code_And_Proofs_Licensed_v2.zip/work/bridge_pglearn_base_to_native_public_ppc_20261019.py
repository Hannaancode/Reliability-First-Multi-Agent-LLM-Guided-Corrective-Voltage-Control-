"""One publisher base reference -> source-matched PPC, NO PF/OPF/solver.

Reject native parameter changes. Not a sampled-test substitution, hard-case
control win, optimum certificate or a restart of either old solver trial.
"""
import hashlib,json,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from audit_public118_native_acopf_reference_20261015 import certify
B=R/'outputs/pglearn_base_native_ppc_bridge_20261019'
RAW=R/'outputs/public118_native_benchmark_input_closure_20261015/Public1_Full_Native_PPC_Input.npz'
CASE=R/'outputs/pglearn_fixed_test_prefix_20261019/fixed16/row_0000.json'
def main():
    B.mkdir(exist_ok=False);start=time.perf_counter();put(B/'Protocol.json',{'status':'FROZEN_BEFORE_STRUCTURAL_MATCH_OR_NEW_IMPORT_OUTCOME','source_sha256':sha(__file__),'native_ppc_sha256':sha(RAW),'source_case_json_container_sha256':sha(CASE),'role':'ONE static author base case engineering reference. Never use this base solution for16 different test inputs.','selection':'Source case namepglib_opf_case118_ieee binds the original ordinary Public1 input; api/sad source names are different and not applicable, not excluded by outcomes.','physical_parameter_match_tolerance':1e-10,'native_feasibility_tolerance':5e-6,'new_PF_OPF_model_optimizer_derivative_forecast_solve_calls':0,'no_native_constraint_or_generator_setpoint_clamping':True})
    row=read(CASE);source=json.loads(row['case/json']);d=source['data'];p=source['ACOPF']['primal'];assert d['case']=='pglib_opf_case118_ieee'
    with np.load(RAW,allow_pickle=False) as z:native={k:z[k].copy() for k in z.files}
    bus=native['bus'];gen=native['gen'];br=native['branch'];base=float(native['baseMVA']);checks={}
    def same(name,a,b):
        a=np.asarray(a);b=np.asarray(b);checks[name]={'same_shape':a.shape==b.shape,'maximum_delta':float(np.max(abs(a-b))) if a.shape==b.shape else None};return a.shape==b.shape and np.max(abs(a-b))<=1e-10
    checks_ok=[];checks_ok.append(same('baseMVA',base,d['base_mva']));checks_ok.append(same('voltage_min',bus[:,12],d['vmin']));checks_ok.append(same('voltage_max',bus[:,11],d['vmax']));checks_ok.append(same('shunt_G',bus[:,4]/base,d['gs']));checks_ok.append(same('shunt_B',bus[:,5]/base,d['bs']))
    pd=np.array([sum(d['pd'][j-1] for j in indices) for indices in d['bus_loads']]);qd=np.array([sum(d['qd'][j-1] for j in indices) for indices in d['bus_loads']]);checks_ok.extend([same('base_load_P',bus[:,2]/base,pd),same('base_load_Q',bus[:,3]/base,qd)])
    assert np.array_equal(bus[:,0],np.arange(118)) and len(set(gen[:,0]))==len(gen)==54
    source_gen_bus={j-1:i for i,indices in enumerate(d['bus_gens']) for j in indices};mapping=[next(j for j,b in source_gen_bus.items() if b==int(v)) for v in gen[:,0]]
    for key,col in [('pgmin',9),('pgmax',8),('qgmin',4),('qgmax',3)]:checks_ok.append(same(key,gen[:,col]/base,np.asarray(d[key])[mapping]))
    checks_ok.append(same('gen_status',gen[:,7],np.asarray(d['gen_status'])[mapping]))
    y=1/(br[:,2]+1j*br[:,3]);tap=np.where(br[:,8]==0,1,br[:,8])*np.exp(1j*np.deg2rad(br[:,9]));ch=1j*br[:,4]/2
    ff=(y+ch)/abs(tap)**2;ft=-y/np.conj(tap);tf=-y/tap;tt=y+ch
    raw_sig=np.column_stack([br[:,:2],ff.real,ff.imag,ft.real,ft.imag,tf.real,tf.imag,tt.real,tt.imag,br[:,5]/base,np.deg2rad(br[:,11]),np.deg2rad(br[:,12]),br[:,10]])
    src_sig=np.column_stack([np.asarray(d['bus_fr'])-1,np.asarray(d['bus_to'])-1,d['gff'],d['bff'],d['gft'],d['bft'],d['gtf'],d['btf'],d['gtt'],d['btt'],d['smax'],d['dvamin'],d['dvamax'],d['branch_status']])
    used=set();line_map=[];ambiguities=[]
    for i,a in enumerate(raw_sig):
        matches=[j for j,b in enumerate(src_sig) if j not in used and np.max(abs(a-b))<=1e-10]
        if not matches:checks_ok.append(False);checks['unmatched_raw_branch']=i;break
        if len(matches)>1:ambiguities.append({'raw_branch':i,'identical_remaining_source_aliases':matches})
        pick=min(matches);line_map.append(pick);used.add(pick)
    checks_ok.append(len(line_map)==186 and len(used)==186)
    put(B/'Structural_Match.json',{'checks':checks,'all_native_static_inputs_match':bool(all(checks_ok)),'generator_map':mapping,'branch_map':line_map,'identical_parallel_aliases':ambiguities,'alias_limit':'A deterministic order of exactly equivalent branches is allowed for this all-on engineering reference; contingency/native branch-ID mapping must not be inferred from an ambiguous alias.'})
    if not all(checks_ok):
        put(B/'Result.json',{'status':'STOP_STATIC_SOURCE_CONTRACT_MISMATCH_NO_IMPORT_OR_SOLVER','source_parameter_checks':checks,'new_scientific_calls':0});manifest(B);print('Native source mismatch retained; no import/solver or parameter repair');return
    b=np.pad(bus,((0,0),(0,4)));g=np.pad(gen,((0,0),(0,11)));l=np.pad(br,((0,0),(0,13)))
    b[:,7]=p['vm'];b[:,8]=np.rad2deg(p['va']);g[:,1]=np.asarray(p['pg'])[mapping]*base;g[:,2]=np.asarray(p['qg'])[mapping]*base;g[:,5]=b[g[:,0].astype(int),7]
    for column,key in [(13,'pf'),(14,'qf'),(15,'pt'),(16,'qt')]:l[:,column]=np.asarray(p[key])[line_map]*base
    outcome=certify(native,b,g,l,float(source['ACOPF']['meta']['primal_objective_value']),5e-6)
    put(B/'Native_Certificate.json',outcome)
    if outcome['all_native_constraints_and_saved_fields_pass']:
        with (B/'Initialized_Native_PPC.npz').open('xb') as f:np.savez_compressed(f,**{**native,'bus':b,'gen':g,'branch':l})
    put(B/'Result.json',{'status':'PASS_SOURCE_FAITHFUL_PUBLISHED_BASE_NATIVE_INITIALIZATION' if outcome['all_native_constraints_and_saved_fields_pass'] else 'STOP_NATIVE_REFERENCE_GATE_FAILED_NO_TUNING','certificate':outcome,'workflow_seconds':time.perf_counter()-start,'new_PF_OPF_model_optimizer_derivative_forecast_solve_calls':0,'sample_test_rows_certified_by_this_bridge':0,'role':'One source-published zeroUV base integration reference, no hard-case/model/DSE win or global optimum.'});manifest(B);print(json.dumps({'native_bridge':outcome['all_native_constraints_and_saved_fields_pass'],'native_violations':outcome['maximum_violations'],'UV':outcome['buses_below_original_0_95'],'model_test':False,'new_scientific_calls':0}))
if __name__=='__main__':main()
