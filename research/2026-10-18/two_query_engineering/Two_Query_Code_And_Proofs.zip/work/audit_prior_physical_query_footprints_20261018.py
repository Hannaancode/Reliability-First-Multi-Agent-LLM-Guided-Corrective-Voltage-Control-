"""Independent ALL-input component arithmetic; never executes PF or a model."""
import gzip,hashlib,json,os,time
from fractions import Fraction
from prior_physical_query_footprints_20261018 import R,B,read,put,sha,manifest,decode,canonical
def independent_component(net):
    # Separate column extraction and per-bus reduction, no producer fingerprint.
    sh=net.shunt;bybus={}
    for index in sh.index:
        b=int(sh.at[index,'bus'])
        if not bool(sh.at[index,'in_service']) or not bool(net.bus.at[b,'in_service']):continue
        if 'step_dependency_table' in sh:assert not bool(sh.at[index,'step_dependency_table'])
        v=Fraction(*float(net.bus.at[b,'vn_kv']).as_integer_ratio());rated=Fraction(*float(sh.at[index,'vn_kv']).as_integer_ratio())
        step=Fraction(*float(sh.at[index,'step']).as_integer_ratio());factor=v*v*step/(rated*rated)
        bybus.setdefault(b,[]).append((Fraction(*float(sh.at[index,'p_mw']).as_integer_ratio())*factor,Fraction(*float(sh.at[index,'q_mvar']).as_integer_ratio())*factor))
    rows=[]
    for b in sorted(bybus):
        ps=sum((x[0] for x in bybus[b]),Fraction());qs=sum((x[1] for x in bybus[b]),Fraction())
        if ps or qs:rows.append([b,[ps.numerator,ps.denominator],[qs.numerator,qs.denominator]])
    return hashlib.sha256(canonical(rows)).hexdigest()
def main():
    p=read(B/'Protocol.json');assert sha(__file__)==p['independent_reader_sha256'];out=B/'independent_audit';out.mkdir(exist_ok=False);started=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    for rel,h in p['pins'].items():assert sha(R/rel)==h
    for rel,h in read(B/'actual/Closed_Manifest.json')['members'].items():assert sha(B/'actual'/rel)==h
    result=read(B/'actual/Result.json')
    if result['status']!='COMPLETE_ALL_TRACKED_INPUT_COMPONENTS':
        put(out/'Independent_Audit.json',{'status':'PARTIAL_RETAINED_NO_COMPLETE_ABSENCE_CLAIM','producer':result,'scientific_calls':0});manifest(out);return
    index=json.loads(gzip.decompress((B/'actual/Physical_Component_Input_References.json.gz').read_bytes()));seen=0;covered=set()
    for source in p['sources']:
        with (R/source['path']).open('rb') as f:
            for line in f:
                assert time.perf_counter()-started<p['reader_bound_seconds'],'Independent fixed analysis bound; no extension'
                e=json.loads(line)
                if e['event']!='PF_intent':continue
                d=e['data'];key=independent_component(decode((R/source['path']).parent,d['before']));linehash=hashlib.sha256(line).hexdigest()
                assert any(r['journal']==source['path'] and r['intent_line_sha256']==linehash and r['before']==d['before'] for r in index[key]);covered.add((source['path'],linehash));seen+=1
    assert seen==60426==sum(len(v) for v in index.values()) and len(covered)==seen
    hits={t['point_action_key']:len(index.get(t['physical_component_sha256'],[])) for t in p['targets']}
    put(out/'Independent_Audit.json',{'status':'PASS_ALL60426_TRACKED_PF_INPUT_COMPONENT_REFERENCES_AND_INDEPENDENT_ARITHMETIC',
        'decoded_inputs':seen,'unique_components':len(index),'target_component_match_counts':hits,'scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'new_query_gate':'Only zero matching tracked components excludes those60426inputs. Matches remainUNKNOWN; broader historical/fresh-root scope and persistent owner/reader gates remain. This is not automatic PF authority.'})
    manifest(out);print(json.dumps({'independent_physical_component_index':'PASS','inputs':seen,'target_matches':hits}))
if __name__=='__main__':main()
