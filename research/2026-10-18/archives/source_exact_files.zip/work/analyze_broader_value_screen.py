"""Separately identified broader historical screen. Same validated algorithm; eight predeclared cases, four families,120 rows/48 genuine batches. Preserve original first screen; no independent holdout or full recovery claim."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
from value_baseline_gate import require_sealed_baseline
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/llm_value_broader_development'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    summary = read(OUT / 'cpu_screen_summary.json')
    assert summary['actual_trials'] == 120 and summary['actual_GPU_calls'] >= 192
    assert summary['protocol_sha256'] == sha(OUT / 'clean_value_development_protocol.json')
    assert summary['evaluator_source_sha256'] == sha(ROOT / 'work/evaluate_broader_value_cpu.py')
    assert summary['raw_model_scope_validation_source_sha256'] == sha(ROOT / 'work/value_model_prefix_inputs.py')
    baseline = require_sealed_baseline(ROOT)
    assert summary['sealed_original_baseline'] == baseline
    protocol = read(OUT / 'clean_value_development_protocol.json')
    cases = {c['scenario_id']: c for c in protocol['initial_screen_scenarios']}
    expected = {sid + '__' + policy + '__B' + str(b) for sid in cases for policy in protocol['first_screen_policies'] for b in protocol['candidate_evaluation_budget_grid']}
    paths = {p.stem: p for p in (OUT / 'cpu_screen_cases').glob('*.json')}
    assert set(paths) == expected
    records = {key: read(path) for key, path in paths.items()}
    for key, row in records.items():
        assert row['scenario_sha256'] == cases[row['scenario_id']]['sha256']
        assert row['true_state_preserved'] and row['candidate_PF_counts']['attempts'] <= row['budget']
        assert row['execution_PF_counts']['attempts'] <= 1
        assert row['tested_candidate_count'] == len(row['tested']) <= row['budget']
        if row['policy'].startswith('zonal_'):
            assert 4 <= row['model_costs']['llm_calls'] <= 8 and row['model_costs']['llm_exceptions'] == 0
            assert len(row['raw_zone_scope_audit']) == 4
        else:
            assert row['model_costs']['llm_calls'] == 0
    comparisons = []
    for sid in sorted(cases):
        for b in protocol['candidate_evaluation_budget_grid']:
            for policy in ['zonal_LoRA_prefix', 'zonal_base_prefix']:
                learned = records[sid + '__' + policy + '__B' + str(b)]
                for control in ['lowest_voltage', 'frozen_enumeration', 'seeded_random']:
                    fixed = records[sid + '__' + control + '__B' + str(b)]
                    before = learned['initial_metrics']
                    assert all((abs(float(before[k]) - float(fixed['initial_metrics'][k])) <= 1e-10 for k in before))
                    lm, dm = (learned['executed_after_metrics'], fixed['executed_after_metrics'])
                    comparisons.append({'scenario_id': sid, 'budget': b, 'learned_policy': policy, 'control_policy': control, 'primary_development_comparison': b == 32 and policy == 'zonal_LoRA_prefix' and (control == 'lowest_voltage'), 'residual_UV_learned_minus_control': lm['uv_count'] - dm['uv_count'], 'deficit_learned_minus_control': lm['deficit_sum'] - dm['deficit_sum'], 'Vmin_learned_minus_control': lm['vmin'] - dm['vmin'], 'learned_normal_upper_band_exceeded_at_1e_minus8': lm['vmax'] > 1.05 + 1e-08, 'control_normal_upper_band_exceeded_at_1e_minus8': dm['vmax'] > 1.05 + 1e-08, 'extra_actual_generation_seconds': learned['model_costs']['generation_seconds'], 'input_tokens': learned['model_costs']['input_tokens'], 'output_tokens': learned['model_costs']['output_tokens'], 'numerical_attempts_learned': learned['candidate_PF_counts']['attempts'] + learned['execution_PF_counts']['attempts'], 'numerical_attempts_control': fixed['candidate_PF_counts']['attempts'] + fixed['execution_PF_counts']['attempts'], 'same_hardware_end_to_end_speed_claim': False})
    assert len(comparisons) == 144
    adapter = []
    for sid in sorted(cases):
        for b in protocol['candidate_evaluation_budget_grid']:
            tuned = records[sid + '__zonal_LoRA_prefix__B' + str(b)]
            untuned = records[sid + '__zonal_base_prefix__B' + str(b)]
            adapter.append({'scenario_id': sid, 'budget': b, 'residual_UV_LoRA_minus_base': tuned['executed_after_metrics']['uv_count'] - untuned['executed_after_metrics']['uv_count'], 'deficit_LoRA_minus_base': tuned['executed_after_metrics']['deficit_sum'] - untuned['executed_after_metrics']['deficit_sum']})
    primary = [r for r in comparisons if r['primary_development_comparison']]
    assert len(primary) == 8
    result = {'analyzed_at_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Complete historical one-state development screen; eight points, four physical families. No family CI or confirmatory superiority claim.', 'actual_trials': 120, 'actual_GPU_calls': summary['actual_GPU_calls'], 'primary_budget': 32, 'primary_control': 'lowest_voltage', 'primary_comparison_declared_in_analysis_plan_before_model_execution': True, 'protocol_sha256': sha(OUT / 'clean_value_development_protocol.json'), 'analysis_plan_sha256': sha(OUT / 'Clean_Value_Analysis_Plan.md'), 'analyzer_sha256': sha(__file__), 'input_row_sha256': {k: sha(p) for k, p in paths.items()}, 'comparisons': comparisons, 'LoRA_vs_base': adapter, 'primary_residual_UV_deltas': [r['residual_UV_learned_minus_control'] for r in primary], 'both_primary_points_have_strict_UV_improvement': all((r['residual_UV_learned_minus_control'] < 0 for r in primary)), 'development_signal_only': True, 'LLM_superiority_confirmed': False, 'numerical_costs_all_actual_local_stages': summary['actual_local_PF_counts_all_executed_stages'], 'inference_and_local_numerical_time_must_be_reported_separately': True}
    target = OUT / 'clean_value_screen_analysis.json'
    assert not target.exists(), 'Keep actual earlier analysis; do not retune after outcomes'
    target.write_text(json.dumps(result, indent=8))
    print('COMPLETE_CLEAN_SCREEN_DESCRIPTIVE_ANALYSIS', result['primary_residual_UV_deltas'], flush=True)
if __name__ == '__main__':
    main()
