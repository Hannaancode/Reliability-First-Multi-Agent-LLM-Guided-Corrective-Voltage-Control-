"""Fixed causal recipient proposals and real memory fit; no learning/physics."""
import gc,hashlib,importlib.metadata as md,json,math,os,shutil,signal,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
os.environ.update(HF_HOME=str(ROOT/'cache'),HF_HUB_DISABLE_IMPLICIT_TOKEN='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false')
import numpy as np
import torch
from huggingface_hub import snapshot_download
from transformers import AutoModelForCausalLM,AutoTokenizer,BitsAndBytesConfig,GenerationConfig
from peft import PeftModel
from public_size_preservation import atomic_json,journal,file_hash,Publisher
from public_size_forward_observer import ForwardObserver
P=ROOT/'prep';protocol=json.loads((P/'protocol.json').read_text());cases=json.loads((P/'cases.json').read_text())
S=ROOT/'outputs/hybrid_scale_science';S.mkdir(exist_ok=False);(S/'events.jsonl').touch();began=time.monotonic()
status={'stage':'starting','complete':False,'actual_generation_attempts':0,'actual_generation_returns':0,'engineering_forward_returns':0,'arms':[]}
publisher=Publisher(S,ROOT/'outputs/hybrid_scale_transfer')
def event(kind,**d):journal(S/'events.jsonl',{'kind':kind,'time_unix':time.time(),**d})
def ack(label):
    result=publisher.publish(label,wait_seconds=180);event('preservation_ack',**result);atomic_json(S/'progress.json',status)
def timeout(*unused):raise TimeoutError('Original fixed science bound, no restart')
remaining=min(protocol['science_seconds'],int(protocol['shared_original_science_absolute_deadline_unix']-time.time()))
assert remaining>0,'Original absolute science allowance exhausted before any call'
signal.signal(signal.SIGALRM,timeout);signal.alarm(remaining)
def hashes(model):
    result={}
    for n,t in model.state_dict().items():
        v=t.detach().cpu().contiguous();raw=v.reshape(-1).view(torch.uint8).numpy()
        result[n]={'shape':list(v.shape),'dtype':str(v.dtype),'sha256':hashlib.sha256(memoryview(raw)).hexdigest()}
    return result
def load(snapshot,arm):
    started=time.perf_counter();event('load_attempt',arm=arm['arm'])
    kw={'local_files_only':True,'trust_remote_code':False,'device_map':{'':'cuda:0'},'dtype':torch.float16,'attn_implementation':'sdpa'}
    if not arm['prequantized']:kw['quantization_config']=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16)
    model=AutoModelForCausalLM.from_pretrained(snapshot,**kw)
    if arm['private_adapter']:
        model=PeftModel.from_pretrained(model,str(P/'private_adapter'),is_trainable=False)
    model.eval();model.requires_grad_(False)
    assert model.is_loaded_in_4bit and all(p.device.type=='cuda' and not p.requires_grad for p in model.parameters())
    if arm['private_adapter']:
        a=[p for n,p in model.named_parameters() if 'lora_' in n];assert len(a)==336 and sum(p.numel() for p in a)==8798208
    event('load_return',arm=arm['arm'],seconds=time.perf_counter()-started)
    return model
def actual_ids(tok,c,closure):
    ids=tok.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False)
    expected=next(r['input_ids'] for r in closure['full16_prefixes'] if r['case_id']==c['case_id'])
    assert ids==expected and len(ids)+384<=4096
    return torch.tensor([ids],device='cuda',dtype=torch.long)
def prefill(model,obs,tok,c,closure,phase):
    ids=actual_ids(tok,c,closure);obs.set_phase(phase,c['case_id']);event('engineering_forward_attempt',arm=arm['arm'],case_id=c['case_id'],phase=phase)
    target=model.get_base_model() if arm['private_adapter'] else model
    with torch.inference_mode():o=target(input_ids=ids,attention_mask=torch.ones_like(ids),use_cache=True,logits_to_keep=1)
    logits=o.logits[0,-1].detach().cpu().numpy().copy();assert np.isfinite(logits).all() and len(obs.rows)==1
    status['engineering_forward_returns']+=1;event('engineering_forward_return',arm=arm['arm'],case_id=c['case_id'],phase=phase)
    del o,ids;gc.collect();torch.cuda.empty_cache();return logits
def generate(model,obs,tok,c,closure,phase):
    obs.set_phase(phase,c['case_id']);ids=actual_ids(tok,c,closure);prompt=ids[0].cpu().tolist();started=time.perf_counter()
    status['actual_generation_attempts']+=1;event('generation_attempt',arm=arm['arm'],case_id=c['case_id'],phase=phase)
    config=GenerationConfig(max_new_tokens=384,do_sample=False,use_cache=True,pad_token_id=tok.pad_token_id,eos_token_id=tok.eos_token_id,return_dict_in_generate=True)
    original_processors=model._get_logits_processor
    effective=[]
    def observed_processors(*args,**kwargs):
        result=original_processors(*args,**kwargs)
        gc=kwargs.get('generation_config',args[0] if args else None)
        names=[type(x).__name__ for x in result]
        event('actual_greedy_processor_gate',arm=arm['arm'],case_id=c['case_id'],phase=phase,processors=names,effective_generation_config={k:getattr(gc,k) for k in ('do_sample','max_new_tokens','min_new_tokens','min_length','repetition_penalty','no_repeat_ngram_size','eos_token_id','pad_token_id','use_cache')})
        assert all(type(x).__name__=='MinLengthLogitsProcessor' and x.min_length<=len(prompt) for x in result),'Only source-proven identity processor at every growing full prefix is permitted; never modify logits or retry'
        effective.append({k:getattr(gc,k) for k in ('do_sample','max_new_tokens','min_new_tokens','min_length','repetition_penalty','no_repeat_ngram_size','eos_token_id','pad_token_id','use_cache')});return result
    model._get_logits_processor=observed_processors
    try:
        with torch.inference_mode():o=model.generate(input_ids=ids,attention_mask=torch.ones_like(ids),generation_config=config,logits_to_keep=1,
            repetition_penalty=1.0,no_repeat_ngram_size=0,min_length=0,min_new_tokens=0,do_sample=False,max_new_tokens=384)
    finally:model._get_logits_processor=original_processors
    torch.cuda.synchronize();seq=o.sequences[0].cpu().tolist();new=seq[len(prompt):]

    record={'arm':arm['arm'],'case_id':c['case_id'],'phase':phase,'actual_effective_generation_configs':effective,'prompt_ids':prompt,'generated_ids':new,'raw_text':tok.decode(new,skip_special_tokens=True),'full_text':tok.decode(new,skip_special_tokens=False),'forward_sequences':[r['sequence'] for r in obs.rows],'seconds_includes_instrumentation':time.perf_counter()-started,'input_UTF8_bytes':len(json.dumps(c['messages'],ensure_ascii=False).encode())}
    out=S/arm['arm']/('responses' if phase=='proposal' else 'cold')/(c['case_id']+'.json');out.parent.mkdir(parents=True,exist_ok=True);atomic_json(out,record)
    assert seq[:len(prompt)]==prompt and 0<len(new)<=384 and len(obs.rows)==len(new)
    assert new==[r['greedy_argmax_token_id'] for r in obs.rows]
    status['actual_generation_returns']+=1;event('generation_return',arm=arm['arm'],case_id=c['case_id'],phase=phase,response_sha256=file_hash(out),generated_tokens=len(new))
    del o,ids;gc.collect();torch.cuda.empty_cache();return record
code=0
try:
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
    versions={n:md.version(n) for n in protocol['framework_versions']};assert versions==protocol['framework_versions']
    for n,h in protocol['remote_source_hashes'].items():assert file_hash(ROOT/n)==h
    assert len(cases)==16 and len({c['case_id'] for c in cases})==16
    atomic_json(S/'scientific_identity.json',{'protocol_sha256':file_hash(P/'protocol.json'),'cases_sha256':file_hash(P/'cases.json'),'source_hashes':protocol['remote_source_hashes'],'versions':versions,'device':torch.cuda.get_device_name(0),'total_VRAM_bytes':torch.cuda.get_device_properties(0).total_memory,'role_and_confounds':protocol['role_and_confounds']})
    ack('initial_identity')
    for arm in protocol['models']:
        name=arm['arm'];status['stage']='download_and_load_'+name;atomic_json(S/'progress.json',status)
        info={'arm':name,'attempted':False,'policy_performance':'UNKNOWN'};folder=S/name;folder.mkdir(exist_ok=True)
        free,total=torch.cuda.mem_get_info();memavailable=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
        diskfree=shutil.disk_usage(ROOT).free
        if arm['conditional_fit'] and (free<arm['minimum_free_VRAM_bytes'] or memavailable<arm['minimum_free_RAM_bytes'] or diskfree<arm['minimum_free_disk_bytes']):
            info.update(state='NOT_ATTEMPTED_RESOURCE_PREFLIGHT',free_VRAM_bytes=free,available_RAM_bytes=memavailable);atomic_json(folder/'Fit_Status.json',info);status['arms'].append(info);ack(name+'_conditional_not_attempted');continue
        model=None;root=None;cold=None;obs=None
        try:
            event('download_attempt',arm=name,repo=arm['repo'],revision=arm['revision']);download_started=time.perf_counter()
            snapshot=Path(snapshot_download(arm['repo'],revision=arm['revision'],allow_patterns=list(arm['files']),max_workers=4))
            source={}
            for n,e in arm['files'].items():
                path=snapshot/n;assert path.stat().st_size==e['bytes'];h=file_hash(path)
                if e.get('lfs_sha256'):assert h==e['lfs_sha256']
                elif e.get('git_blob_id'):
                    raw=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\x00'+raw).hexdigest()==e['git_blob_id']
                source[n]={'bytes':path.stat().st_size,'sha256':h}
            event('download_return',arm=name,seconds=time.perf_counter()-download_started)
            atomic_json(folder/'Public_Source_Proof.json',{'repo':arm['repo'],'revision':arm['revision'],'files':source})
            tok=AutoTokenizer.from_pretrained(str(P/'private_adapter' if arm['private_adapter'] else P/'tokenizers'/name),local_files_only=True,trust_remote_code=False)
            closure=json.loads((P/'tokens'/(name+'_Token_Closure.json')).read_text());gatecase=max(cases,key=lambda c:next(r['prefix_tokens'] for r in closure['full16_prefixes'] if r['case_id']==c['case_id']))
            torch.manual_seed(protocol['seed']);torch.cuda.manual_seed_all(protocol['seed']);torch.cuda.reset_peak_memory_stats()
            info['attempted']=True;model=load(snapshot,arm);before=hashes(model)
            root=model.get_base_model() if arm['private_adapter'] else model;obs=ForwardObserver(root,torch,S,name)
            if name in protocol['reused_engineering']:
                reuse=protocol['reused_engineering'][name]
                assert before==json.loads((P/reuse['initial_weights']).read_text())
                with np.load(P/reuse['longest_logits'],allow_pickle=False) as z:initial=z['logits'].copy()
                event('earlier_full_context_gate_reused_not_repeated',arm=name,original_anchor=reuse)
                info['initial_prefill_reused_from_prior_exact_source_weights']=True
            else:initial=prefill(model,obs,tok,gatecase,closure,'capacity_initial_prefill')
            info.update(state='ACTUAL_FULL_CONTEXT_CUDA_FIT_PASS',longest_prefix_tokens=closure['longest_prefix_tokens'],peak_allocated_bytes=torch.cuda.max_memory_allocated(),peak_reserved_bytes=torch.cuda.max_memory_reserved(),all_parameters_frozen=True)
            atomic_json(folder/'Fit_Status.json',info);atomic_json(folder/'Initial_Weights.json',before);ack(name+'_actual_fit')
            longest_record=None
            for c in cases:
                r=generate(model,obs,tok,c,closure,'proposal')
                if c['case_id']==gatecase['case_id']:longest_record=r
                ack(name+'_'+c['case_id'][:12])
            after=hashes(model);assert before==after;obs.close();obs=None;root=None;model=None;gc.collect();torch.cuda.empty_cache()
            cold=load(snapshot,arm);assert hashes(cold)==before;root=cold.get_base_model() if arm['private_adapter'] else cold
            obs=ForwardObserver(root,torch,S,name+'_cold');reproduced=prefill(cold,obs,tok,gatecase,closure,'capacity_cold_prefill');assert np.array_equal(initial,reproduced)
            cold_record=generate(cold,obs,tok,gatecase,closure,'cold_exact_sequence');assert cold_record['generated_ids']==longest_record['generated_ids'];assert hashes(cold)==before
            atomic_json(folder/'Final_Gates.json',{'all16_proposals_returned':True,'all_weights_unchanged':True,'cold_longest_logits_and_sequence_exact':True,'fresh_sequence_count':1,'all16_cold_sequences_not_measured':True,'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_reserved_bytes':torch.cuda.max_memory_reserved(),'after_weights':after})
            info.update(state='COMPLETE_FROZEN_INFERENCE_SCREEN',policy_performance='REQUIRES_EXTERNAL_SAVED_PHYSICAL_DIAGNOSTIC; NOT_FULL_POLICY')
            obs.close();obs=None;root=None;cold=None;gc.collect();torch.cuda.empty_cache();ack(name+'_complete')
        except torch.cuda.OutOfMemoryError:
            info.update(state='TERMINAL_ARM_RESOURCE_FAILURE_NO_RETRY',failure_type='CUDA_OutOfMemoryError');event('arm_exception',arm=name,type='CUDA_OutOfMemoryError')
            if obs:obs.close();obs=None
            root=None;cold=None;model=None
            gc.collect();torch.cuda.empty_cache();atomic_json(folder/'Fit_Failure.json',info);ack(name+'_resource_failure')
        status['arms'].append(info)
    status.update(stage='closed_all_prospective_arms',complete=all(a['state'] in ('COMPLETE_FROZEN_INFERENCE_SCREEN','NOT_ATTEMPTED_RESOURCE_PREFLIGHT','TERMINAL_ARM_RESOURCE_FAILURE_NO_RETRY') for a in status['arms']))
except BaseException as e:
    code=1;status.update(stage='terminal_partial_or_failed',failure_type=type(e).__name__);event('terminal_exception',type=type(e).__name__);(S/'Failure_Traceback.txt').write_text(traceback.format_exc())
finally:
    signal.alarm(0);status.update(science_workflow_seconds=time.monotonic()-began,optimizer_steps=0,PF_calls=0,no_scientific_retry=True)
    atomic_json(S/'Final_Status.json',status)
    atomic_json(S/'Closed_Manifest.json',{p.relative_to(S).as_posix():{'bytes':p.stat().st_size,'sha256':file_hash(p)} for p in S.rglob('*') if p.is_file() and p.name!='progress.json' and not p.name.endswith('.tmp')})
sys.exit(code)
