"""Read-only selected-prefix physical/state audit; not a full policy rerun."""
import hashlib,json,os,pickle,time,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from equal_operation_benchmark_v2 import decode_capsule
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from strict_saved_native_input_match_v2_20261018 import require_same
from dynamic_actual_mask_guidance_v1 import current_inputs,identity
B=R/'outputs/closed_thirteen_support_prefix_audit_20261019'
SCREEN=R/'outputs/all_thirteen_paid_receipts_policy_screen_20261019'

def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    p={'source_sha256':sha(__file__),'input_closed_manifest_sha256':sha(SCREEN/'Closed_Manifest.json'),'fixed_scope':'All two selected saved prefix transitions, native physical input of second, metrics, operation accounting and exact UNKNOWN frontier. No claim independent policy-selection proof/full trajectory.','new_scientific_calls':0}
    put(B/'Protocol.json',p);put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    for rel,h in read(SCREEN/'Closed_Manifest.json')['members'].items():assert sha(SCREEN/rel)==h
    result=read(SCREEN/'Results.json');leg=read(SCREEN/'Leg_1.json');assert result['legs']==[leg] and result['new_model_PF_optimizer_derivative_forecast_solve_calls']==0
    assert leg['status']=='UNKNOWN_MissingPaidNumericalContext' and len(leg['projection_trace'])==2
    _,runner,_=load_stack();nodes=[];metrics=[]
    for step in leg['projection_trace']:
        ref=step['after_reference'];base=R/ref['base']
        with (base/ref['descriptor']['path']).open('rb') as f:d=decode_capsule(f,ref['descriptor'])
        net=d['net'];actual=runner.rescue.grid_metrics(net)
        for k,v in step['metrics'].items():assert abs(actual[k]-v)<=1e-12,(k,actual[k],v)
        assert actual['vmax']<=1.05+1e-8 and actual['ov_count']==0
        nodes.append(net);metrics.append(actual)
    step=leg['projection_trace'][1];row=step['row']
    # Cursor affects protection/cap/stock legality; native input transformation
    # itself is the original verifier closure. Recover its source-bound cursor
    # from the first selected suffix trace checkpoint when available. We do not
    # invent a cursor from metrics or claim legality beyond already-paid sources.
    assert row['kind']=='equal_owned_reallocation' and row['donor_bus']!=row['receiver']
    delta=nodes[1].shunt.q_mvar-nodes[0].shunt.q_mvar
    # Shunt rows can differ structurally, so exact native action check is bound
    # to the archived before/after source audit; selected Vm/angle/P/Q fields are
    # independently hashed and decoded here, not independently solved again.
    assert leg['projection_trace'][0]['remaining_operations']-2==step['remaining_operations']==leg['remaining_original_operations']
    assert leg['latest_supported_metrics']==step['metrics'] and [m['uv_count'] for m in metrics]==[23,16]
    ref=leg['frontier_input'];encoded=(SCREEN/ref['path']).read_bytes();assert hashlib.sha256(encoded).hexdigest()==ref['encoded_sha256']
    raw=zlib.decompress(encoded);assert hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];frontier=pickle.loads(raw)
    ident=identity(current_inputs(frontier['net']));assert ident==leg['missing_identity']
    from candidate_process_evidence_utils import frozen_checks
    put(B/'Fresh_Frozen_Checks.json',frozen_checks())
    put(B/'Independent_Selected_Prefix_Audit.json',{'status':'PASS_SAVED_SELECTED_METRICS_HASHES_BUDGET_AND_UNKNOWN_CONTEXT_IDENTITY','UV_trace':[33,23,16],
       'selected_after_metrics':metrics,'remaining_original_operations':15,'missing_identity':ident,'frontier_raw_sha256':ref['raw_sha256'],
       'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
       'limitations':'Selected prefix/hash/metrics/accounting audit only. Original source receipts/policy-use verification remain separately paid evidence. No independent new solves, actual commits, full policy-selection rerun, complete protected trajectory or LLM/DSE superiority.'})
    manifest(B);print(json.dumps({'selected_prefix':'PASS','UV_trace':[33,23,16],'newPF':0}))

if __name__=='__main__':main()
