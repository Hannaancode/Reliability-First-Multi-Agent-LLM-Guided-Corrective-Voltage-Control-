# Transfer instructions

This is a portable file handover; it does not connect two chat sessions or transfer account credentials.

## Local Codex / IDE / desktop local workspace

Download and extract the ZIP into a dedicated HierGrid project folder. Open that folder in Codex. Keep reference_assets unchanged and place the latest actual frozen assets in a separate input folder. Paste FIRST_PROMPT.txt as the first task. Read START_HERE.md as the authoritative handover; actual code and measured results remain authoritative about implementation. Complete Google CLI authentication directly in the local terminal using its current supported flow. Linux/macOS are documented CLI platforms; Windows requires an appropriate Linux environment for this CLI workflow. Verify installed WSL distributions rather than assuming blank `wsl --status` proves success.

## Codex opened in a browser tab

First ask that session to identify its actual execution environment. A cloud workspace is separate from the user's PC and this chat. It does not automatically acquire local Google CLI credentials. If the interface supports attachments, provide START_HERE.md (or paste its text) and the ZIP; otherwise put the non-secret handover files into a dedicated private project repository and select that repository as the environment. Do not put credentials, session metadata or tokens in the repository. The current task authorizes preparing files, not automatically publishing them to GitHub. The provided package contains manuscripts; choose repository visibility deliberately rather than making them public by default.

If selecting a cloud environment, let Codex audit authentication and networking before allocating a runtime. Installing the Colab CLI is not enough. Do not send authorization codes to the conversation. If no supported secure handoff exists, use local CLI/agent control or user-run Colab execution instead and retain cloud Codex for source editing. A cloud agent may still prepare all reviewer code and analyze uploaded results.

## Missing user assets, first request

1. Latest `reflection.ipynb` (Colab File > Download > Download .ipynb).
2. Exact `phase2g_ITER25_resume_pack_*` ZIP/folder.
3. Locked62 scenario bank, `LOCKED_BANK.json`, `reports/scenario_manifest.json`, scenario JSONs and pilot/current logs.

Large model assets can stay in the selected Colab/Drive workspace if the authenticated execution environment can reach them. Do not request broad account access when selected file transfer is enough. Do not rerun training or regenerate scenarios to replace missing assets.

## Returning progress to the original conversation

Return the asset audit, actual diffs, logs, summary CSV/JSON, plots and statistical outputs here by upload or an explicitly accessible repository. A new Codex session does not automatically send its filesystem back to the original chat. Keep one source of truth for frozen config, scenario IDs and protocol.
