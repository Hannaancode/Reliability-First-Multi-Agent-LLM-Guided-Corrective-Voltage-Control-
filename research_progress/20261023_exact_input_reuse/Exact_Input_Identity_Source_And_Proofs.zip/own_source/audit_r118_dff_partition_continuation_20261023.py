"""One first-new-return replay followed by saved-only original-policy audit."""
import traceback
from r118_dff_partition_core_20261023 import *

def main():
    A.mkdir(exist_ok=False);began=time.monotonic()
    put(A/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    wait_ack(A,began);p=read(P/'Protocol.json');validate_pins(p)
    end=read(R/'outputs/r118_dff_partition_continuation_coordination_20261023/End_ACK.json')
    assert end['exit_code']==0 and end['actual_owned_chain_ended']
    for name,digest in read(E/'Closed_Manifest.json')['members'].items():assert sha(E/name)==digest,name
    result=read(E/'Result.json')
    np,pp,v2,runner,reflection=setup()
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    from public_size_u61_preservation import journal
    native=pp.runpp;replays=0;attempts=0;maximum=0.;maximum_kcl=0.;branch_results=[];failure=None
    records=[(E/name,read(E/name)) for name in result['call_records']]
    try:
        previous='0'*64;events=[]
        for line in (E/'events.jsonl').open('rb'):
            row=json.loads(line);assert row['event']['previous']==previous
            previous=hashlib.sha256(canonical(row['event'])).hexdigest();assert previous==row['sha256'];events.append(row['event'])
        reserved={e['identity']:e for e in events if e['kind']=='NEW_NATIVE_ATTEMPT_RESERVED'}
        assert len(reserved)==result['costs']['new_PF_attempts']
        for path,row in records:
            assert time.monotonic()-began<p['reader_seconds']
            if row['provenance']['kind']!='NEW_NATIVE_ATTEMPT':continue
            assert row['identity'] in reserved and row['kwargs']==p['solver_kwargs']
            assert reserved[row['identity']]['before']==row['before']
            attempts+=1
            if row['exception'] is not None:continue
            before=saved_net(path.parent,row['before']);after=saved_net(path.parent,row['after'])
            net=copy.deepcopy(before);journal(A/'replay_journal.jsonl',dict(event='FIRST_NEW_RETURN_REPLAY_RESERVED',primary_record=path.relative_to(E).as_posix(),source_sha256=sha(path)))
            tick=time.perf_counter();native(net,**row['kwargs']);replays+=1
            frames_equal(net,after);assert net.converged and after.converged
            delta=0.
            for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
                a=net[name].select_dtypes(include=[np.number]).to_numpy(float);b=after[name].select_dtypes(include=[np.number]).to_numpy(float)
                assert a.shape==b.shape and np.array_equal(np.isnan(a),np.isnan(b)) and np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True),name
                finite=np.isfinite(a)&np.isfinite(b);delta=max(delta,float(np.max(abs(a[finite]-b[finite]),initial=0.)))
            q=net._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0]
            V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]));kcl=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
            maximum=max(maximum,delta);maximum_kcl=max(maximum_kcl,kcl)
            proof=dict(primary_record=path.relative_to(E).as_posix(),primary_record_sha256=sha(path),maximum_numeric_field_delta=delta,KCL_pu=kcl,seconds=time.perf_counter()-tick)
            put(A/f'replay_{replays:06d}.json',proof);journal(A/'replay_journal.jsonl',dict(event='FIRST_REPLAY_CLOSED',**proof))
            if replays%100==0:
                tmp=A/'Status.pending';tmp.write_text(json.dumps(dict(first_new_return_replays=replays,phase='FIRST_PHYSICS_REPLAY',elapsed_seconds=time.monotonic()-began)),encoding='utf-8');os.replace(tmp,A/'Status.json')
        assert attempts==result['costs']['new_PF_attempts'] and replays==result['costs']['new_PF_returns']
        from audit_solver_input_identity_receipts_20261023 import audit as identity_audit
        identity_proof=identity_audit(E/'solver_input_identity');put(A/'Exact_Solver_Input_Receipt_Audit.json',identity_proof)
        assert identity_proof['identity_receipts']==result['costs']['exact_solver_input_preparation']['identity_receipts']
        # All further policy checks use preserved physical receipts only.
        base=pp.from_json(str(R/p['base_net']));zones=read(R/p['metadata'])['zones']
        for binding in read(R/p['bindings']):
            case=binding['case_id'];directory=E/case
            if not directory.exists():continue
            seq=[(f,r) for f,r in records if r['case_id']==case];cursor=0;commits=0
            saved_first=pickle.loads(zlib.decompress((R/p['first_commit_cursors']/(case+'_cold.zlib')).read_bytes()))
            random.seed(p['seed']);np.random.seed(p['seed'])
            def cached(net,**kwargs):
                nonlocal cursor
                if cursor==len(seq):raise PaidBoundary('END_OF_PRESERVED_PREFIX_UNKNOWN_REMAINDER')
                path,row=seq[cursor];cursor+=1;assert kwargs==row['kwargs']
                frames_equal(net,saved_net(path.parent,row['before']));restore_exact(net,saved_net(path.parent,row['after']))
                if row['exception'] is not None:raise RuntimeError(failure_message(row['exception']))
            def on_commit(state):
                nonlocal commits
                commits+=1
                if commits==1:checkpoint_equal(state,saved_first)
                desc=read(directory/f'commit_{commits:02d}.json');checkpoint=decode(directory,desc['capsule'])
                checkpoint_equal(state,checkpoint['source_frame']);assert cursor==checkpoint['call_cursor']==desc['call_cursor']
                assert desc['remaining_original_operations']==25-commits
            complete=(directory/'Result.json').exists()
            try:
                cold_result=source_run(v2,runner,reflection,read(R/binding['registration']['recipe']),base,zones,cached,on_commit)
                assert complete and cursor==len(seq) and cold_result==read(directory/'Result.json')
                summary=reflection.summarize_result(cold_result);summary['case_id']=case;summary['strict_final_OV']=cold_result['final_metrics']['ov_count'];branch_results.append(summary)
            except PaidBoundary:
                assert not complete and cursor==len(seq)
            put(A/(case+'_Continuous_Policy_Audit.json'),dict(status='PASS_COMPLETE_ORIGINAL_SOURCE' if complete else 'PASS_EXACT_PRESERVED_PREFIX_UNKNOWN_REMAINDER',records=cursor,commitments=commits,first_commit_equals_saved_original_cursor=commits>0,new_PF_model_calls_in_source_audit=0))
        assert len(branch_results)==len(result['summaries'])
        complete=len(branch_results)==4 and result['all4_complete']
        put(A/'Independent_Audit.json',dict(status='PASS_ALL4_COMPLETE_NATIVE_DFF_SOURCE_PHYSICS_COST' if complete else 'PASS_PRESERVED_PARTIAL_FULL_COMPARISON_UNKNOWN',all4_complete=complete,summaries=branch_results,first_new_return_replays=replays,maximum_numeric_field_delta=maximum,maximum_KCL_pu=maximum_kcl,old_failed_physics_replays=0,new_model_optimizer_training_derivative_calls=0,primary_costs=result['costs'],causal_continuous_original_source_and_checkpoint_checks=True,comparison='Native1.06 original guard; strict0.95/1.05 separately reported. Not fullDSE/external/LLM superiority or unused confirmation.',workflow_seconds=time.monotonic()-began))
        checks=frozen_checks();put(A/'Frozen_Original_Checks.json',checks)
    except BaseException as exc:
        failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),already_executed_first_replays=replays,no_scientific_phase_retry_permitted=True)
        put(A/'Failure.json',failure)
        raise
    finally:
        pp.runpp=native
        put(A/'Closed_Manifest.json',dict(members={f.relative_to(A).as_posix():sha(f) for f in A.rglob('*') if f.is_file()}))

if __name__=='__main__':main()
