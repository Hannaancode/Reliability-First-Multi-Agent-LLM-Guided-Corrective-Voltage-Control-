"""Additive Windows ZIP-name verification repair. No analysis/science repeated."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/critical_research_reset_20261010'
assert not (OUT / 'Local_Archive_Audit.json').exists()
manifest_path = OUT / 'Review_Evidence_Manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))['members']
archive = OUT / 'Critical_Review_and_Decision_Evidence.zip'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = z.namelist()
    expected = {rel.replace('\\', '/') for rel in manifest}
    expected.add(str(manifest_path.relative_to(ROOT)).replace('\\', '/'))
    assert len(names) == len(set(names)) == len(expected) and set(names) == expected
    for rel, entry in manifest.items():
        payload = z.read(rel.replace('\\', '/'))
        assert len(payload) == entry['bytes']
        assert hashlib.sha256(payload).hexdigest() == entry['sha256']
        assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == entry['sha256']
    assert z.read(str(manifest_path.relative_to(ROOT)).replace('\\', '/')) == manifest_path.read_bytes()
audit = {
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'archive': str(archive.relative_to(ROOT)), 'unique_members': len(names),
    'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'CRC_and_every_member_hash_passed': True, 'local_only': True, 'private_export': False,
    'original_seal_source_and_archive_preserved': True,
    'mechanical_repair': 'ZIP converts Windows backslashes to slashes; normalize lookup names only. Manifest paths and all payloads unchanged.',
    'original_failure': 'Original verifier KeyError on a Windows-path member after archive creation; CRC and unique-count had passed.',
    'additive_verifier_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'repeated_read_only_analysis_or_scientific_calls': 0,
}
with (OUT / 'Local_Archive_Audit.json').open('x', encoding='utf-8') as f:
    json.dump(audit, f, indent=2); f.write('\n')
print(json.dumps(audit))
