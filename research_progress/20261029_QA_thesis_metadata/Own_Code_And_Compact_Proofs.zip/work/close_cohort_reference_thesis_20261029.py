"""Close only the reviewed documentation requirements; no scientific execution."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, html, json, os, re, zipfile
from docx import Document
from docx.text.paragraph import Paragraph
from docx.table import Table
from pypdf import PdfReader

R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_cohorts_references_20261029'
B=R/'outputs/thesis_environment_contracts_20261029'
def rd(p): return json.loads((R/p).read_text('utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    p=R/p; tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8');tmp.replace(p)
def media(p):
    with zipfile.ZipFile(p) as z:
        return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/'))
def claims(doc):
    ps=doc.paragraphs
    def section(a,b):
        start=next(i for i,p in enumerate(ps) if p.text==a)
        end=next(i for i,p in enumerate(ps) if i>start and p.text==b)
        return '\n'.join(p.text for p in ps[start:end])
    return section('Chapter 3 Research contributions and their evidence','Chapter 4 PowerGridQA as the Dataset Foundation')+'\n'+section('Chapter 9 Discussion conclusions and future research','Appendix A Experimental provenance and reproducibility guide')
def main():
    assert not (O/'Final_Visual_And_Evidence_QA.json').exists()
    base=B/'Hannaan_Thesis_Environment_Contracts.docx';path=O/'Hannaan_Thesis_Cohorts_And_References.docx';pdfpath=O/'Integrated_Thesis_QA.pdf'
    old,new=Document(base),Document(path)
    assert sha(base)==rd((B/'Final_Visual_And_Evidence_QA.json').relative_to(R))['docx_sha256']
    tables=lambda d:[[[c.text for c in row.cells] for row in t.rows] for t in d.tables]
    assert tables(old)==tables(new) and len(new.tables)==18
    assert media(base)==media(path) and sum(media(path).values())==22
    norm=lambda x:re.sub(r'\t\d+$','',x)
    body=lambda d:Counter(norm(p.text) for p in d.paragraphs if not re.match(r'^\[\d+\]',p.text))
    assert not (body(old)-body(new)),list((body(old)-body(new)).items())[:4]
    refs=rd('outputs/thesis_bibliography_review_20261029/Verified_Reference_Register.json')
    assert refs['status']=='PASS_ALL35_REFERENCE_IDENTITIES_AND_EXPLICIT_SOURCE_STATUS'
    assert [p.text for p in new.paragraphs if re.match(r'^\[\d+\]',p.text)]==[r['normalized'] for r in refs['references']]
    assert len(refs['references'])==35
    method=rd('outputs/thesis_method_versions_20261029/Method_Version_Register.json')
    assert method['status']=='PASS_DOCUMENTATION_SOURCE_FUNCTION_AND_PROTOCOL_BINDINGS' and len(method['methods'])==10
    claim=rd('outputs/thesis_contribution_claim_review_20261029/Contribution_Claim_Review.json')
    assert hashlib.sha256(claims(new).encode()).hexdigest()==claim['chapters_sha256']
    assert claims(new)==claims(old) and len(claim['claims'])==6
    for binding in claim['source_bindings'].values(): assert sha(R/binding['path'])==binding['sha256']
    pdf=PdfReader(pdfpath);pagination=rd((O/'Pagination_Record.json').relative_to(R))
    assert len(pdf.pages)==pagination['pages']==128
    assert pagination['list_entries']==len(pagination['map'])==53
    compact=lambda x:re.sub(r'\s+','',x).lower()
    for item in pagination['map']:
        assert compact(item['label']) in compact(pdf.pages[item['physical_page']-1].extract_text() or ''),item
    assert len(list((O/'render').glob('verified-*.png')))==128
    unchanged_detail=[]
    for p in [75,76]:
        assert sha(O/f'render/verified-{p:03}.png')==sha(O/f'render/final-{p:03}.png')
        unchanged_detail.append(p)
    now=datetime.now(timezone.utc).isoformat();qarel=(O/'Final_Visual_And_Evidence_QA.json').relative_to(R).as_posix()
    review={'status':'PASS_LISTED_VISUAL_REVIEWS_AND_MECHANICAL_PRESERVATION',
        'pdf_sha256':sha(pdfpath),'initial_all_page_contact_review':list(range(1,129)),
        'final_contact_ranges':[[97,120],[121,128]],'final_detailed_pages':[5,7,102,103,117,125,127,128],
        'earlier_detail_pages_with_identical_final_image_hash':unchanged_detail,
        'observations':'New source paragraphs and appendices are readable. Redundant new closing paragraph removed to eliminate two-line body orphan. References have consistent hanging indentation and spacing. Final reference35 occupies its own closing page. All53 index entries resolve to final PDF pages.',
        'scope':'All-page overview plus listed changed/detail pages, not a fresh full-size review of every old page.',
        'preserved_layout_records':['Layout_Repair_Record.json','Layout_Repair_Record_v2.json'],
        'repaired_transient':'First removal script assertion expected a longer old paragraph and failed before document save; corrected actual wording then removed only the new redundant paragraph. Original text and scientific evidence unchanged.'}
    put((O/'Visual_Review_Record.json').relative_to(R),review)
    evidence=['outputs/thesis_method_versions_20261029/Method_Version_Register.json','outputs/thesis_contribution_claim_review_20261029/Contribution_Claim_Review.json','outputs/thesis_bibliography_review_20261029/Verified_Reference_Register.json','outputs/thesis_cohort_use_20261029/Cohort_Use_Register.json']
    qa={'at_utc':now,'status':'PASS_WORKING_DRAFT_LAYOUT_AND_LISTED_EVIDENCE_CHECKS','pages':128,'tables':18,'figures':22,'references':35,'page_bound_index_entries':53,
        'docx_sha256':sha(path),'pdf_sha256':sha(pdfpath),'original121_unchanged':True,'all18_prior_tables_unchanged':True,'all22_media_bytes_unchanged':True,
        'all_prior_nonreference_paragraphs_preserved_with_multiplicity_except_index_page_numbers':True,'all35_references_match_primary_metadata_register':True,
        'contribution_chapters_unchanged_and_bound_to_review':True,'evidence':[{'path':p,'sha256':sha(R/p)} for p in evidence],'visual_review':review,
        'new_model_PF_training_calls':0,'limitations':['Working draft, not final university submission.','T20 records historical SFT gaps rather than inventing exact recovery.','T21 unresolved memberships remain PARTIAL.','No causal LLM advantage or final research goal is established by documentation closure.']}
    put(qarel,qa)
    chunks=[]
    for e in new.element.body:
        if e.tag.endswith('}p'):
            p=Paragraph(e,new);chunks.append(('## ' if p.style.name.startswith('Heading') else '')+p.text)
        elif e.tag.endswith('}tbl'):
            t=Table(e,new);values=[[c.text.replace('\n',' / ') for c in row.cells] for row in t.rows]
            chunks.append('\n'.join(['| '+' | '.join(values[0])+' |','| '+' | '.join(['---']*len(values[0]))+' |']+['| '+' | '.join(v)+' |' for v in values[1:]]))
    (O/'Thesis_Text_And_Tables.md').write_text('\n\n'.join(chunks)+'\n','utf-8')
    index=rd((B/'Thesis_Evidence_Navigation.json').relative_to(R));index.update(at_utc=now,qa_record=qarel,current_docx=path.relative_to(R).as_posix(),pages=128,additional_registers=qa['evidence'])
    put((O/'Thesis_Evidence_Navigation.json').relative_to(R),index)
    def link(p,label):return '<a href="'+html.escape(os.path.relpath(R/p,O).replace('\\','/'),quote=True)+'">'+html.escape(label)+'</a>'
    parts=['<!doctype html><meta charset="utf-8"><title>Thesis evidence index</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.5 system-ui}section{border-top:1px solid #ddd;padding:12px 0}</style><h1>Thesis evidence index</h1>','<p>128 pages;18 tables;22 figures;35 references. Working draft; all six research goals open.</p>',link(path.relative_to(R),'Current Word draft')]
    for record in qa['evidence']:parts.append('<p>'+link(record['path'],record['path'])+'</p>')
    for table in index['tables']:
        parts.append('<section><h2>'+html.escape(table['caption'])+'</h2><p>'+html.escape(table['limitation'])+'</p><ul>')
        parts.extend('<li>'+link(v['path'],v['path'])+'</li>' for v in table['records']);parts.append('</ul></section>')
    parts.append(link('outputs/thesis_integrated_evidence_20261028/Evidence_Index.html','Original figure source index'))
    (O/'Evidence_Index.html').write_text('\n'.join(parts),'utf-8')
    tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json')
    for tid,ev,limit in [('T20',evidence[0],'Executed source/functions, model identities, settings and wrappers documented; historical SFT gaps remain explicit.'),('T26',evidence[1],'Six contribution evidence classes separately supported in unchanged Chapters3 and9; no novelty or final superiority certification.'),('T28',evidence[2],'All35 bibliography entries normalized;32public primary metadata,2unconfirmed supplied manuscripts,1pinnedsoftware. Cited preprints are identified versions, not a claim of no later publication.')]:
        t=next(t for t in tasks['tasks'] if t['id']==tid);assert t['status']=='OPEN'
        t.update(status='COMPLETE_SCOPED_DOCUMENTATION_REQUIREMENT_IN_REVIEWED_WORKING_THESIS',completed_utc=now,evidence=[ev,qarel],limitation=limit)
    t=next(t for t in tasks['tasks'] if t['id']=='T21');t['new_scoped_progress']='Six bound cohorts and eleven further families integrated into reviewed7.17; historical membership joins remain unresolved.';t['evidence'].append(qarel)
    t=next(t for t in tasks['tasks'] if t['id']=='T32');t.update(status='PARTIAL',evidence=['outputs/thesis_caption_scope_20261029/Caption_Clarifications.json'],new_scoped_progress='29caption clarification drafts prepared; review and integration still pending.')
    t=next(t for t in tasks['tasks'] if t['id']=='T33');t.update(status='PARTIAL_KNOWN_LAYOUT_AND_REFERENCE_FORMATTING_COMPLETE_FINAL_TERMINOLOGY_REVIEW_OPEN');t['evidence'].append(qarel)
    tasks['completed_requirement_count']=sum(t['status'].startswith('COMPLETE') for t in tasks['tasks']);assert tasks['completed_requirement_count']==17
    tasks['updated_utc']=now;put('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    for rel in ['outputs/research_resumption_20261028/Current_Resume.json','outputs/public_qa_scale_design_20261029/Exact_Resume.json']:
        x=rd(rel);x.update(at_utc=now,thesis_closed_requirements=17,thesis_requirements_complete=17,thesis_integration=qarel,thesis_evidence_index=(O/'Evidence_Index.html').relative_to(R).as_posix());put(rel,x)
    x=rd('outputs/research_tasks_20261014/Tasks.json');x.update(updated_at_utc=now,thesis_documentation_requirements_complete=17,latest_verified_thesis=qarel);put('outputs/research_tasks_20261014/Tasks.json',x)
    integration=rd((O/'Integration_Record.json').relative_to(R));integration.update(status='COMPLETE_WORKING_DRAFT_VISUALLY_VERIFIED',pages=128,qa=qarel,new_sections=['6.16','7.17','A.10','A.11'],T20='COMPLETE_SCOPED',T26='COMPLETE_SCOPED',T28='COMPLETE_SCOPED',T21='PARTIAL_IDENTITY_GAPS_RETAINED');put((O/'Integration_Record.json').relative_to(R),integration)
    msg='17/35 thesis requirements now complete: T20 executed method bindings, T26 evidence-specific contribution claims and T28 reference/source status. Reviewed128pages/18tables/22figures/35references/53page-bound index entries; old121page copy and all original tables/images/nonreference body retained. T21 historical memberships and T32 caption integration remain partial. Documentation only, zero newscience; all6research goals OPEN. Three fixed publicQA primaries and saved reader now ended; detailed verified completion/cost diagnosis is next, no restart or retuning.'
    header='## Three further thesis requirements closed — '+now+'\n\n'+msg+'\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text(header+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+msg+'\n')
    print(json.dumps({'status':qa['status'],'pages':128,'thesis_complete':17,'new_science':0}))
if __name__=='__main__':main()
