"""Compose CLOSED relevant-lineage certificates; no repeated archive scan or PF.

This is a narrowly scoped execution prerequisite, not universal historical
closure or evidence that either new action is useful.
"""
import copy,gzip,hashlib,json,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
B=R/'outputs/exact_two_paid_query_engineering_20261018'
I=R/'outputs/next_exact_paid_query_preparation_20261018'

def certify():
    data=read(I/'Exact_Candidate_Inputs.json');state=pickle.loads(zlib.decompress((I/'Exact_Current_Input.zlib').read_bytes()))
    a=read(R/'outputs/paid_lineage_frontier_20261018/audit/Independent_Frontier_Audit.json')
    assert a['status']=='PASS_ALL_LINEAGE_ATTEMPT_KEYS_AND_EXACT_SOURCE_RECEIPT_REFERENCES' and a['keys']==60377 and a['new_primary_missing_receipt_BLOCKED']==0
    path=R/'outputs/paid_lineage_frontier_20261018/All_Lineage_Attempt_Keys.json.gz';raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==read(path.parent/'Results.json')['frontier_sha256'];keys=json.loads(gzip.decompress(raw))
    assert len(keys)==60377
    f=R/'outputs/prior_physical_query_footprints_20261018';physical=read(f/'independent_audit/Independent_Audit.json');prior=read(f/'Protocol.json')
    assert physical['status']=='PASS_ALL60426_TRACKED_PF_INPUT_COMPONENT_REFERENCES_AND_INDEPENDENT_ARITHMETIC'
    assert physical['decoded_inputs']==60426 and read(f/'Completion.json')['reader_exit_code']==0
    observed=read(R/'outputs/fresh_observed_shunt_scope_20261018/Results.json')
    assert observed['status']=='PASS_ALL3418_STATIC_OBSERVED_SHUNT_COMPONENTS_DUAL_EQUATIONS_AND_SOURCE_HASH' and observed['closed_observations']==3418
    _,runner,_=load_stack();_,actuate,cert=build_verifier(runner.rescue,state['cursor']);assert cert['reverse_AST_exact']
    assert point_key(state['net'],state['cursor'])==data['point'] and runner.rescue.grid_metrics(state['net'])==data['observed_current_metrics']
    targets={t['point_action_key']:t for t in prior['targets']};checked=[]
    for item in data['exact_new_query_rows']:
        key=data['point']+'|'+action_key(item['row']);assert key==item['point_action_key'] and key not in keys
        native=actuate(copy.deepcopy(state['net']),action(item['row']));h,values=component(native)
        assert independent_component(native)==h==targets[key]['physical_component_sha256']
        assert values==targets[key]['perbus_exact_rational_P_Q_shunt_admittance']
        assert physical['target_component_match_counts'][key]==observed['target_match_counts'][key]==0
        checked.append({'key':key,'physical_component_sha256':h,'tracked_BEFORE_component_matches':0,'observed_static_component_matches':0})
    files=[I/'Exact_Candidate_Inputs.json',I/'Exact_Current_Input.zlib',path,
        f/'Protocol.json',f/'Completion.json',f/'independent_audit/Independent_Audit.json',
        R/'outputs/paid_lineage_frontier_20261018/audit/Independent_Frontier_Audit.json',
        R/'outputs/fresh_observed_shunt_scope_20261018/Results.json']
    result={'status':'PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE','exact_candidate_keys':[r['point_action_key'] for r in data['exact_new_query_rows']],
        'input_preparation_sha256':sha(I/'Exact_Candidate_Inputs.json'),'reader_source_sha256':sha(__file__),
        'closed_tracked_PF_BEFORE_inputs':60426,'closed_lineage_keys':60377,'static_observed_fresh_root_tables':3418,
        'checked_targets':checked,'evidence_sha256':{str(x.relative_to(R)):sha(x) for x in files},
        'limits':'Tracked native four-root/controller lineage only. Fresh-root evidence is static AFTER shunt tables, not reconstructed full BEFORE NETs. Unlogged historical calls are not universally certified. No old verdict/score or raw PF result is reused by this test.',
        'authority':'Composition of completed scoped evidence plus a separately frozen TWO-identity engineering protocol under direct necessary-work authority. Absence alone never launches science.',
        'native_verifier_certificate':cert,'new_scientific_calls':0}
    put(B/'Attempt_Coverage_Certificate.json',result);return result

if __name__=='__main__':print(json.dumps({'coverage':certify()['status'],'new_science':0}))
