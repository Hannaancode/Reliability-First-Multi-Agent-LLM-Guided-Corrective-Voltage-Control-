"""Input-admission repair for the unexecuted nonlinear proposal kernel.

Original equations, objectives, bounds and native guard are inherited without
changes. The original preparation source and its single fixture remain retained.
This module does not run an optimizer or power flow.
"""
import numpy as np
from remaining85_nonlinear_kernel_20261029 import NonlinearNative13,original_guard

class ValidatedNonlinearNative13(NonlinearNative13):
    def __post_init__(self):
        # Preserve phase updates even if a valid caller supplied an initially
        # real voltage vector. A real copy would silently discard imaginary V.
        self.V_current=np.asarray(self.V_current,dtype=np.complex128).copy()
        self.Y=np.asarray(self.Y,dtype=np.complex128).copy()
        for name,shape in [('lookup',(13,)),('control',(3,))]:
            value=np.asarray(getattr(self,name))
            if value.shape!=shape or not np.issubdtype(value.dtype,np.number) or np.iscomplexobj(value):
                raise ValueError(name+' must be an exact integer-valued native bus map')
            if not np.isfinite(value).all() or not np.array_equal(value,np.rint(value)):
                raise ValueError(name+' cannot be rounded or truncated')
        gen=np.asarray(self.ppc_gen)
        if gen.ndim!=2 or gen.shape[1]<8 or not np.issubdtype(gen.dtype,np.number) or np.iscomplexobj(gen):
            raise ValueError('Malformed conventional-generator table')
        if not np.isfinite(gen[:,[0,1,2,7]]).all():
            raise ValueError('Nonfinite generator bus, P, Q or service state')
        if not np.array_equal(gen[:,0],np.rint(gen[:,0])) or np.any(gen[:,0]<0) or np.any(gen[:,0]>=13):
            raise ValueError('Invalid conventional-generator bus')
        super().__post_init__()
