# Matched normal-upper mediation: useful protection, incomplete recovery

Completed8 October2026 at05:14Qatar. The hypothesis, six identities, common intervention,25/32/512 controller limits, seed, primary endpoint and no-retuning rule were frozen before the new guarded runs. Four boundary/exception/duplicate-wrapper/nonfinite software checks passed before physical execution. Six original unguarded references were reused without rerun. The final9-file JSON manifest and all declared source hashes were independently checked.

|Load factor|Ordering|Reference final UV|Guard final UV|Reference upper-band excess beyond1e-8|Guard upper-band excess beyond1e-8|Reference/guard joint success|
|---|---|---:|---:|---|---|---|
|1.25|Enumeration|4|4|Yes|No|No/No|
|1.25|Lowest voltage|0|0|No|No|Yes/Yes|
|1.25|Seeded random|0|0|No|No|Yes/Yes|
|1.50|Enumeration|41|37|Yes|No|No/No|
|1.50|Lowest voltage|1|3|Yes|No|No/No|
|1.50|Seeded random|0|3|Yes|No|No/No|

Joint success means strict UVzero andvmax<=1.05+1e-8. Normal upper-band excess fell from4/6 to0/6 at the explicitly declared tolerance; joint success stayed2/6. Strict UV clearance fell3/6 to2/6. This result is a recovery/protection tradeoff, not a universal improvement or full operating-feasibility claim. Original strictOV counts retain floating-point threshold crossings and were not rewritten.

The guard rejected139 candidates that the original verifier admitted. New guarded controllerPF1,421, including zero solver exceptions;45 separately charged independent replay solves also had zero exceptions. Every actual decision-state/candidate reconstruction and committed action matched independent physical replay within1e-10. Original initial cases/networks/controller sources/Qgrid/scoring and prior result files were preserved. Actual model calls remainzero.

The earlier exhaustive endpoint diagnostic showed useful original-admissible actions outside all three failed bounded searches, but their unsafe terminal states could not return to the normal upper band with any original-admissible one-step action in the examined universe. The matched guard now shows that preventing entry to those paths is useful protection but is insufficient for joint recovery under this search. Together these experiments identify coverage and admissibility/trajectory planning as separate design problems.

Decision: retain this common guard and its losses as a prospective study; do not sweep tolerance/Q/budgets or rerun for a positive count. The next substantive CPU method, if implemented, needs a declared common candidate-coverage/planning mechanism and strong no-model controls, with normal admissibility held fixed. Its learned comparator still requires genuine frozen LoRA/base inference. Two known historical points, one family and one random seed support descriptive development only; no CI, model superiority or final security claim.
