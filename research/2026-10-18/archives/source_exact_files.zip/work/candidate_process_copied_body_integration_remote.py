"""Single prospective genuine two-step integration, not a performance pilot."""
from pathlib import Path
from datetime import datetime,timezone
import gc,hashlib,json,os,time,traceback
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
os.environ.update(HF_HOME=str(ROOT/'cache/huggingface'),HF_HUB_OFFLINE='1',HF_HUB_DISABLE_IMPLICIT_TOKEN='1',HF_HUB_DISABLE_TELEMETRY='1',CUBLAS_WORKSPACE_CONFIG=':4096:8')
import torch,pandapower as pp
from huggingface_hub import snapshot_download
from peft import get_peft_model_state_dict,set_peft_model_state_dict
from candidate_process_pretrained_loader import load_isolated_body,preservation_inventory,ADAPTER_NAME,tensor_digest
from candidate_process_body_intervention_query_v2 import SharedCurrentProcessInterface,PretrainedCurrentProcessPrototype
from candidate_process_numerical_predictor import process_objective
from vcsa_memory_execution import MemoryExecution

PREP=ROOT/'outputs/llm_value_candidate_development_20261009/copied_body_integration_preparation'
OUT=ROOT/'outputs/llm_value_candidate_development_20261009/copied_body_integration_science'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False)
def main():
    assert not OUT.exists(),'No scientific restart or duplicate'
    OUT.mkdir(parents=True);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
    started=time.perf_counter();counts={'forward_attempts':0,'forward_returns':0,'forward_exceptions':0,'backward_attempts':0,'backward_returns':0,'optimizer_steps':0,'PF_attempts':0,'generation_attempts':0,'soft_embedding_tokens':0,'typed_record_inputs':0,'value_utf8_input_bytes':0}
    journal=(OUT/'events.jsonl').open('x');model=wrapper=memory=None
    def event(kind,**kw):
        journal.write(json.dumps({'event':kind,'elapsed_seconds':time.perf_counter()-started,**kw},allow_nan=False)+'\n');journal.flush();os.fsync(journal.fileno())
        tmp=OUT/'progress.tmp';tmp.write_text(json.dumps({'stage':kind,'counts':counts,'elapsed_seconds':time.perf_counter()-started}));tmp.replace(OUT/'progress.json')
    def blocked_PF(*args,**kw):counts['PF_attempts']+=1;raise AssertionError('No numerical solver entry during integration')
    pp.runpp=blocked_PF
    import pandapower.powerflow
    pandapower.powerflow._powerflow=blocked_PF
    try:
        protocol=read(PREP/'protocol.json');program=read(PREP/'Program_Input_Manifest.json')
        for name,digest in program.items():assert sha(ROOT/name)==digest
        assert read(ROOT/'outputs/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
        environment=read(ROOT/'outputs/remote_frozen_environment.json');assert environment==read(PREP/'Expected_Environment.json')
        assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
        torch.manual_seed(protocol['seed']);torch.use_deterministic_algorithms(True)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
        torch.backends.cuda.enable_flash_sdp(False);torch.backends.cuda.enable_mem_efficient_sdp(False);torch.backends.cuda.enable_math_sdp(True)
        proof=read(ROOT/'outputs/frozen_input_verification.json');adapter=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
        assert all(sha(adapter/n)==h for n,h in proof['model_files'].items())
        original_files={n:sha(adapter/n) for n in proof['model_files']}
        cfg=read(adapter/'adapter_config.json')
        snapshot=Path(snapshot_download(cfg['base_model_name_or_path'],revision=environment['base_revision_verified'],local_files_only=True))
        assert sha(snapshot/'model.safetensors')==environment['base_weight_sha256']
        rows=protocol['exact_two_optimization_views'];assert len(rows)==2 and all(r['split']=='optimization' for r in rows)
        inputs={r['observation_id']:torch.load(PREP/r['input_file'],weights_only=True) for r in rows}
        targets={r['observation_id']:torch.load(PREP/r['target_file'],weights_only=True) for r in rows}
        common=torch.load(PREP/'Common_Initial_Interface.pt',weights_only=True)
        assert sha(PREP/'Common_Initial_Interface.pt')==protocol['common_initial_interface_sha256']
        write(OUT/'protocol.json',protocol);write(OUT/'Initial_Identity.json',{'actual_CUDA_T4':True,'exact_owned_runtime_released':False,'pretrained_body_loaded_yet':False,'base_revision':environment['base_revision_verified'],'base_file_sha256':environment['base_weight_sha256']})
        tick=time.perf_counter();model,load=load_isolated_body(snapshot,adapter,train_body=True)
        load['measured_remote_load_workflow_seconds']=time.perf_counter()-tick;write(OUT/'Actual_Load_Record.json',load)
        def blocked_generation(*args,**kw):counts['generation_attempts']+=1;raise AssertionError('No language generation in process integration')
        model.generate=blocked_generation
        interface=SharedCurrentProcessInterface(protocol['semantic_types']).cuda();interface.load_state_dict(common)
        assert sum(p.numel() for p in interface.parameters())==289759
        wrapper=PretrainedCurrentProcessPrototype(interface,model);wrapper.train()
        trainable={n:p for n,p in wrapper.named_parameters() if p.requires_grad}
        assert sum(p.numel() for p in trainable.values())==9087967
        initial_trainable={n:p.detach().cpu().clone() for n,p in trainable.items()}
        before=preservation_inventory(model);write(OUT/'Frozen_Base_Inventory_Before.json',before)
        optimizer=torch.optim.AdamW(trainable.values(),lr=protocol['integration_learning_rate'],weight_decay=.01)
        torch.cuda.reset_peak_memory_stats();memory=MemoryExecution(model)
        step_records=[]
        for number,row in enumerate(rows,1):
            assert time.perf_counter()-started<protocol['science_bound_seconds']
            ident=row['observation_id'];x=inputs[ident];target={n:v.cuda() for n,v in targets[ident].items()}
            optimizer.zero_grad(set_to_none=True)
            counts['forward_attempts']+=1;counts['soft_embedding_tokens']+=237
            counts['typed_record_inputs']+=len(x['field_ids']);counts['value_utf8_input_bytes']+=sum(map(len,x['value_bytes']))
            event('forward_attempt',step=number,observation_id=ident);tick=time.perf_counter()
            try:score=wrapper(x)
            except BaseException:counts['forward_exceptions']+=1;raise
            torch.cuda.synchronize();forward_seconds=time.perf_counter()-tick;counts['forward_returns']+=1
            loss,parts=process_objective(score,target);event('forward_return',step=number,observation_id=ident,loss=float(loss.detach()),seconds=forward_seconds,parts=parts)
            counts['backward_attempts']+=1;tick=time.perf_counter();loss.backward();torch.cuda.synchronize();backward_seconds=time.perf_counter()-tick;counts['backward_returns']+=1
            gradients={n:{'finite':p.grad is not None and bool(torch.isfinite(p.grad).all()),'norm':float(p.grad.norm()) if p.grad is not None else None} for n,p in trainable.items()}
            assert all(g['finite'] and g['norm']>0 for g in gradients.values()),'Every intended parameter path needs a finite nonzero actual gradient'
            write(OUT/f'Step{number}_Actual_Gradient_Records.json',gradients)
            norm=torch.nn.utils.clip_grad_norm_(trainable.values(),1.,error_if_nonfinite=True)
            tick=time.perf_counter();optimizer.step();torch.cuda.synchronize();optimizer_seconds=time.perf_counter()-tick;counts['optimizer_steps']+=1
            checkpoint={'common':interface.state_dict(),'copied_adapter':get_peft_model_state_dict(model,adapter_name=ADAPTER_NAME,save_embedding_layers=False)}
            checkpoint_path=OUT/f'Step{number}_Actual_Checkpoint.pt';torch.save(checkpoint,checkpoint_path)
            event('optimizer_step_and_checkpoint_preserved',step=number,observation_id=ident,checkpoint=checkpoint_path.name,sha256=sha(checkpoint_path),backward_seconds=backward_seconds,optimizer_seconds=optimizer_seconds)
            step_records.append({'step':number,'observation_id':ident,'forward_seconds':forward_seconds,'backward_seconds':backward_seconds,'optimizer_seconds':optimizer_seconds,'loss':float(loss.detach()),'gradient_clip_norm':float(norm),'actual_gradient_tensors':len(gradients)})
        changed={n:not torch.equal(initial_trainable[n],p.detach().cpu()) for n,p in trainable.items()}
        assert all(changed.values()),'Every intended parameter tensor must actually update'
        write(OUT/'Actual_Updated_Parameter_Tensors.json',changed)
        write(OUT/'Actual_Step_Timing_and_Loss.json',step_records)
        assert preservation_inventory(model)==before and all(sha(adapter/n)==h for n,h in original_files.items())
        write(OUT/'Frozen_Base_Inventory_After.json',preservation_inventory(model))
        # Reversible execution remains live through actual backward recomputation.
        decoder_counts={'actual_decoder_invocations':memory.decoder_invocations,'actual_checkpoint_requests':memory.checkpoint_requests}
        wrapper.eval();final_scores={}
        with torch.no_grad():
            for row in rows:
                ident=row['observation_id'];counts['forward_attempts']+=1;counts['soft_embedding_tokens']+=237
                counts['typed_record_inputs']+=len(inputs[ident]['field_ids']);counts['value_utf8_input_bytes']+=sum(map(len,inputs[ident]['value_bytes']))
                event('final_forward_attempt',observation_id=ident)
                final_scores[ident]=wrapper(inputs[ident]).cpu();torch.cuda.synchronize();counts['forward_returns']+=1;event('final_forward_return',observation_id=ident)
        torch.save(final_scores,OUT/'Final_Actual_Scores.pt')
        memory.close();memory=None;assert all(s.enabled for s in model.get_layer_status())
        peak={'allocated_bytes':torch.cuda.max_memory_allocated(),'reserved_bytes':torch.cuda.max_memory_reserved()}
        del optimizer,wrapper,interface,model,trainable,initial_trainable,checkpoint,score,loss,target
        model=wrapper=None;gc.collect();torch.cuda.empty_cache()
        fresh,load2=load_isolated_body(snapshot,adapter,train_body=False)
        write(OUT/'Fresh_Model_Load_Record.json',load2)
        checkpoint=torch.load(OUT/'Step2_Actual_Checkpoint.pt',weights_only=True)
        result=set_peft_model_state_dict(fresh,checkpoint['copied_adapter'],adapter_name=ADAPTER_NAME)
        actual=get_peft_model_state_dict(fresh,adapter_name=ADAPTER_NAME,save_embedding_layers=False)
        assert set(actual)==set(checkpoint['copied_adapter']) and all(torch.equal(v.cpu(),checkpoint['copied_adapter'][n].cpu()) for n,v in actual.items())
        shared=SharedCurrentProcessInterface(protocol['semantic_types']).cuda();shared.load_state_dict(checkpoint['common'])
        reloaded=PretrainedCurrentProcessPrototype(shared,fresh);reloaded.eval();replay={}
        with torch.no_grad():
            for row in rows:
                ident=row['observation_id'];counts['forward_attempts']+=1;counts['soft_embedding_tokens']+=237
                counts['typed_record_inputs']+=len(inputs[ident]['field_ids']);counts['value_utf8_input_bytes']+=sum(map(len,inputs[ident]['value_bytes']))
                event('fresh_checkpoint_forward_attempt',observation_id=ident)
                replay[ident]=reloaded(inputs[ident]).cpu();torch.cuda.synchronize();counts['forward_returns']+=1;event('fresh_checkpoint_forward_return',observation_id=ident)
        torch.save(replay,OUT/'Fresh_Model_Checkpoint_Scores.pt')
        assert all(torch.equal(final_scores[i],replay[i]) for i in final_scores),'No approximate checkpoint identity substituted'
        assert preservation_inventory(fresh)==before and all(sha(adapter/n)==h for n,h in original_files.items())
        assert sha(snapshot/'model.safetensors')==environment['base_weight_sha256']
        assert counts['optimizer_steps']==2 and counts['forward_attempts']==counts['forward_returns']==6 and counts['backward_returns']==2 and counts['PF_attempts']==counts['generation_attempts']==0
        summary={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'all_genuine_integration_gates_passed':True,'counts':counts,
            'real_named_original_LoRA_copy_trainable_parameters':8798208,'all336_copy_tensors_received_nonzero_finite_gradients_and_updated':True,
            'shared_trainable_parameters':289759,'all_new_trainable_parameters':9087967,'exact_fresh_checkpoint_scores_both_views':True,
            'frozen_base_buffers_quantization_and_original_private_files_unchanged':True,'CUDA_peak_memory':peak,'training_decoder_execution':decoder_counts,
            'actual_total_scientific_workflow_seconds':time.perf_counter()-started,'actual_context_soft_tokens_per_forward':237,
            'engineering_integration_not_policy_or_LLM_superiority':True}
        write(OUT/'summary.json',summary);event('science_complete',summary=summary)
    except BaseException as exc:
        event('terminal_failure',exception=type(exc).__name__,counts=counts)
        write(OUT/'Terminal_Failure.json',{'exception':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'counts':counts,'actual_elapsed_seconds':time.perf_counter()-started,'no_scientific_restart':True})
        raise
    finally:
        if memory is not None:memory.close()
        journal.close()
        files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file() and p.name not in {'owner.claim','progress.json'}}
        write(OUT/'Closed_Actual_Manifest.json',files)
if __name__=='__main__':main()
