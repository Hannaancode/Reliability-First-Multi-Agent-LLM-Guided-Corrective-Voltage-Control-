"""Sole saved-output functional reader, no model/PF/optimizer calls."""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'
E = R / 'outputs/native13_fullband_original_adapter_engineering_execution_20261021'
O = R / 'outputs/native13_fullband_original_adapter_engineering_independent_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    with Path(p).open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())


def main():
    O.mkdir(exist_ok=False)
    put(O / 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(),
                           'source_sha256': sha(Path(__file__)),
                           'at_utc': datetime.now(timezone.utc).isoformat()})
    from coordinate_native_inverter_linear_reference_20261020 import process
    claim = read(E / 'owner.claim')
    live = process(claim['actual_pid'])
    assert not live or 'run_native13_fullband_original_adapter_colab_20261021.py' not in (live.get('CommandLine') or '')
    state = read(E / 'status.json')
    assert state['runtime_released'] and state['all_actual_closed_artifacts_preserved']
    assert state['scientific_process_ended'] and state['remote_exit_code'] == 0
    protocol = read(P / 'Production_Protocol.json')
    ready = read(P / 'Launch_Readiness_Audit.json')
    for n, h in ready['source_hashes'].items():
        assert sha(R / n) == h
    study = E / 'staged/study'
    descriptor = read(E / 'remote_closed_descriptor.json')
    for name, record in descriptor['members'].items():
        path = study / name
        assert path.stat().st_size == record['bytes'] and sha(path) == record['sha256']
    remote_claim = read(study / 'owner.claim')
    assert remote_claim['source_sha256'] == sha(R / 'work/run_native13_fullband_lora_remote_20261021.py')
    result = read(study / 'Results.json')
    assert result['status'] == 'COMPLETE_ALL6_ORIGINAL_TRAINED_LORA_PRIMARY_AND_FRESH_MODEL_COLD_FULLBAND_ENGINEERING_OUTPUTS'
    assert result['cold_all6_token_sequences_exact'] and result['private_weights_unchanged']
    costs = result['actual_costs']
    assert costs['model_load_attempts'] == costs['model_load_returns'] == 2
    assert costs['generation_attempts'] == costs['generation_returns'] == 12
    assert costs['PF_optimizer_backward_training_calls'] == 0
    inputs = read(P / 'All6_Messages_And_Token_IDs.json')
    contexts = {c['engineering_case']: c for c in read(P / 'All2_Exact_Engineering_Cases.json')}
    import native13_fullband_hybrid_contract_20261021 as core
    outputs = []
    generated = 0
    for item in inputs:
        a = read(study / f'primary_Agent_{item["agent"]}.json')
        b = read(study / f'cold_Agent_{item["agent"]}.json')
        assert a['token_ids'] == b['token_ids'] and a['prefix_token_count'] == b['prefix_token_count'] == len(item['token_ids'])
        assert 0 < len(a['token_ids']) <= 384
        assert a['actual_forward_returns'] == b['actual_forward_returns'] == len(a['token_ids'])
        assert a['physical_bus'] == b['physical_bus'] == item['physical_bus']
        generated += len(a['token_ids']) + len(b['token_ids'])
        context = contexts[item['engineering_case']]
        parsed = core.admit(a['raw_text'], context['contract'], context['frame'], item['zone'])
        outputs.append({'agent': item['agent'], 'seed': item['seed'], 'zone': item['zone'],
                        'engineering_case': item['engineering_case'], 'raw_text': a['raw_text'],
                        'admission': parsed, 'primary_and_cold_tokens_exact': True})
    assert costs['pretrained_forward_attempts'] == costs['pretrained_forward_returns'] == generated == costs['generated_token_count']
    for replica in ['primary', 'cold']:
        loader = read(study / f'{replica}_Loader_Proof.json')
        assert loader['four_bit_base'] and loader['source_tensor_values_identical'] and loader['enabled_disabled_restored_unmerged']
        assert loader['trainable_body_parameters'] == 0
        assert read(study / f'{replica}_Immutable_Values_Before.json') == read(study / f'{replica}_Immutable_Values_After.json')
        memory = read(study / f'{replica}_Memory_And_Source_Proof.json')
        assert memory['all_base_private_quantized_values_and_buffers_unchanged'] and memory['private_input_hashes_unchanged']
        assert memory['peak_allocated_bytes'] <= 12 * 1024 ** 3
    strict = sum(r['admission']['status'] != 'INVALID' for r in outputs)
    positive = any(r['engineering_case'] == 'first_source_order_UV' and r['admission']['status'] == 'LEGAL_PROPOSAL_NOT_PHYSICALLY_VERIFIED'
                   and r['admission']['actual_delta_Q_Mvar'] > 0 for r in outputs)
    negative = any(r['engineering_case'] == 'first_source_order_OV' and r['admission']['status'] == 'LEGAL_PROPOSAL_NOT_PHYSICALLY_VERIFIED'
                   and r['admission']['actual_delta_Q_Mvar'] < 0 for r in outputs)
    passed = strict == 6 and positive and negative
    audit = {'at_utc': datetime.now(timezone.utc).isoformat(),
             'status': 'PASS_INDEPENDENT_MODEL_SOURCE_COLD_TOKEN_MASK_COUNT_IMMUTABILITY_AND_FUNCTIONAL_GATE_AUDIT',
             'fixed_functional_gate': 'PASS_FUNCTIONAL_SUPPORT_ONLY_NO_AUTOMATIC_PHYSICS' if passed else 'FAIL_FIXED_FULLBAND_ORIGINAL_ADAPTER_INTERFACE_STOP_NO_RETUNING',
             'strict_JSON_or_null': strict, 'total_primary_inputs': 6,
             'legal_positive_in_UV_context': positive, 'legal_negative_in_OV_context': negative,
             'all12_actual_outputs_retained': True, 'actual_model_costs': costs,
             'all6_fresh_model_sequences_exact': True, 'outputs': outputs,
             'new_PF_training_optimizer_GPU_allocations_by_reader': 0,
             'not_a_full_controller_physics_or_superiority_result': True,
             'next': 'If functional gate fails, stop this exact intervention. If it passes, complete/freeze a full physical executor/persistent-state/paid-history/strong-control/independent-reader protocol before any physical campaign. No prompt/decoder/model rescue.'}
    put(O / 'Independent_Functional_Audit.json', audit)
    from candidate_process_evidence_utils import frozen_checks
    put(O / 'Frozen_After.json', frozen_checks())
    put(O / 'Closed_Manifest.json', {p.relative_to(O).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                                    for p in O.iterdir() if p.is_file()})
    print(json.dumps({k: audit[k] for k in ['status', 'fixed_functional_gate', 'strict_JSON_or_null', 'legal_positive_in_UV_context', 'legal_negative_in_OV_context']}))


if __name__ == '__main__':
    main()
