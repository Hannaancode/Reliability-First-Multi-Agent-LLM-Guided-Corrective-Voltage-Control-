"""Prospective eight NEW development roots, native full baseline episodes and explicit charged replay."""
import json,hashlib,pickle,time,os,copy,random
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_action_upgrade_preparation_20261020'
PRIMARY=ROOT/'outputs/native_action_upgrade_support_20261020';READER=ROOT/'outputs/native_action_upgrade_support_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def binary(p,v):
    with Path(p).open('xb') as f:pickle.dump(v,f,protocol=5);f.flush();os.fsync(f.fileno())
def signature(net):
    import pandas as pd
    h=hashlib.sha256()
    for n in ['bus','line','trafo','sgen','gen','load','ext_grid','shunt','switch']:
        h.update(n.encode());h.update(pd.util.hash_pandas_object(net[n],index=True).to_numpy().tobytes())
    return h.hexdigest()
def run(mode):
    out=PRIMARY if mode=='primary' else READER;out.mkdir(exist_ok=False)
    put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(ROOT/('work/run_native_upgrade_support_20261020.py' if mode=='primary' else 'work/audit_native_upgrade_support_20261020.py')),'mode':mode,'at_utc':datetime.now(timezone.utc).isoformat()})
    began=time.monotonic()
    while not (out/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from candidate_process_evidence_utils import frozen_checks
    from pandapower.pypower.makeSbus import makeSbus
    np=b.np;torch=b.torch;start=time.monotonic();p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));deadline=start+p['worker_seconds'];costs={k:0 for k in ['native_network_conversions','checkpoint_loads','agent_forward_attempts','agent_forward_returns','cold_agent_forward_attempts','cold_agent_forward_returns','PF_requests','PF_attempts','PF_returns','PF_exceptions','paid_exact_cache_uses','saved_failed_queries_not_replayed','KCL_checks']};costs['LLM_training_optimizer_backward_calls']=0
    for n,h in p['sources'].items():assert sha(ROOT/n)==h
    for n,h in p['inputs'].items():assert sha(ROOT/n)==h
    put(out/'Frozen_Before.json',frozen_checks());events=out/'events.jsonl';stream=events.open('x',encoding='utf-8');previous='0'*64
    def event(kind,**data):
        nonlocal previous
        assert time.monotonic()<deadline;v={'kind':kind,'seconds':time.monotonic()-start,'previous':previous,**data};h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();stream.write(json.dumps({'event':v,'sha256':h},separators=(',',':'))+'\n');stream.flush();os.fsync(stream.fileno());previous=h
    cache={};known_kw={};receipts=[];context={};cases=[];all_steps=[];old_returns={};old_failures={}
    if mode=='independent':
        old=json.loads((PRIMARY/'Result.json').read_text(encoding='utf-8'));old_returns={(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True)):r for r in old['receipts'] if r['status']=='RETURNED'};old_failures={(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True)):r for r in old['receipts'] if r['status']=='EXCEPTION'}
        for f in json.loads((PRIMARY/'Closed_Manifest.json').read_text(encoding='utf-8'))['files']:assert sha(PRIMARY/f['path'])==f['sha256']
    graph=np.load(ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz')
    env,proxy,proof=b.environment();costs['native_network_conversions']+=1;base_env=copy.deepcopy(env.__dict__);recipes=np.load(PREP/'All8_New_Source_Physical_Inputs.npz');physics=out/'physics';physics.mkdir();checkpoints=out/'checkpoints';checkpoints.mkdir()
    def tracked(net,*args,**kwargs):
        assert not args and kwargs in [{'algorithm':'bfsw'},{'algorithm':'bfsw','init':'dc'}];costs['PF_requests']+=1;sig=signature(net);kw=json.dumps(kwargs,sort_keys=True);key=(sig,kw)
        if key in cache:net.update(copy.deepcopy(cache[key]));costs['paid_exact_cache_uses']+=1;event('exact_paid_same_initializer_cache',physical_signature=sig,kwargs=kwargs,**context);return
        if sig in known_kw and known_kw[sig]!=kw:raise RuntimeError('Previously paid physical input with different initializer remains UNKNOWN; no silent solver substitution')
        if mode=='independent' and key in old_failures:costs['saved_failed_queries_not_replayed']+=1;raise RuntimeError('Saved scientific exception retained without another solver attempt')
        if mode=='independent':assert key in old_returns,'Independent source produced an unentered identity'
        index=costs['PF_attempts'];before=physics/f'PF{index:04d}_before.pkl';binary(before,net);record={'index':index,'context':copy.deepcopy(context),'physical_signature':sig,'kwargs':kwargs,'status':'ATTEMPTED','before_sha256':sha(before)};receipts.append(record);costs['PF_attempts']+=1;event('PF_attempt',**record);t=time.monotonic()
        try:b.pp.runpp(net,**kwargs)
        except BaseException as exc:costs['PF_exceptions']+=1;record.update(status='EXCEPTION',exception=type(exc).__name__,seconds=time.monotonic()-t);event('PF_exception',**record);raise
        costs['PF_returns']+=1;assert net.converged and signature(net)==sig;after=physics/f'PF{index:04d}_after.pkl';binary(after,net)
        pp=net._ppc;assert np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and pp['baseMVA']==float(graph['baseMVA'])
        v=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));s=makeSbus(pp['baseMVA'],pp['bus'],pp['gen']);residual=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert residual<=1e-7;costs['KCL_checks']+=1
        fields={n:net[n].select_dtypes(include=[np.number]).to_numpy(dtype=float) for n in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};path=physics/f'PF{index:04d}_fields.npz';np.savez(path,**fields)
        if mode=='independent':
            saved=np.load(PRIMARY/'physics'/f"PF{old_returns[key]['index']:04d}_fields.npz");assert set(saved.files)==set(fields) and all(np.allclose(fields[n],saved[n],atol=1e-10,rtol=0,equal_nan=True) for n in fields)
        record.update(status='RETURNED',after_sha256=sha(after),fields_sha256=sha(path),KCL_pu=residual,seconds=time.monotonic()-t);known_kw[sig]=kw;cache[key]=copy.deepcopy(net);event('PF_return',**record)
    proxy.runpp=tracked
    def parameters(group):return {f'{i}::{n}':v.detach().cpu().numpy().copy() for i,m in enumerate(group) for n,v in m.state_dict().items()}
    def forward(group,state,cold=False):
        result=[];prefix='cold_agent_forward' if cold else 'agent_forward'
        for i,m in enumerate(group):
            costs[prefix+'_attempts']+=1;event(prefix+'_attempt',agent=i,**context)
            with torch.no_grad():a=m.get_action(np.asarray([state[i]]))
            costs[prefix+'_returns']+=1;assert a.shape==(1,) and np.isfinite(a).all();result.append(a.copy());event(prefix+'_return',agent=i,**context)
        return np.asarray(result)
    try:
        for pos,seed in enumerate(p['all8_development_seeds']):
            env.__dict__.update(copy.deepcopy(base_env));context.clear();context.update(seed=seed,algorithm='root',step=0);case={'seed':seed,'root':'UNKNOWN','algorithms':[]};cases.append(case)
            try:state=env.reset(seed)
            except BaseException as exc:case['failure']=str(exc);event('root_failed_or_unknown',seed=seed,type=type(exc).__name__);continue
            assert isinstance(state,np.ndarray) and state.shape==(3,)
            for k,table,column in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(env.network[table][column].to_numpy(),recipes[k][pos])
            root=copy.deepcopy(env.__dict__);rootvm=env.network.res_bus.vm_pu.to_numpy(copy=True);case.update(root='RETURNED',root_UV=int((rootvm<.95).sum()),root_OV=int((rootvm>1.05).sum()));binary(checkpoints/f'seed{seed}_root_full_env.pkl',root)
            models,_,_=b.load_three(env);costs['checkpoint_loads']+=9;torch.manual_seed(20261020);cold_models=None
            if mode=='primary':cold_models,_,_=b.load_three(env);costs['checkpoint_loads']+=9
            for algorithm in p['algorithms']:
                env.__dict__.update(copy.deepcopy(root));state=env.state.copy();last=np.zeros((3,1));history=[];row={'algorithm':algorithm,'status':'UNKNOWN'};case['algorithms'].append(row);context.clear();context.update(seed=seed,algorithm=algorithm,step=0)
                try:
                    for step in range(1,101):
                        context['step']=step;packet={'seed':seed,'algorithm':algorithm,'completed_steps':step-1,'remaining_original_horizon':101-step,'environment':copy.deepcopy(env.__dict__),'state':state.copy(),'last_Q':last.copy(),'model_parameters':parameters(models[algorithm]),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'python_rng':random.getstate(),'history':history.copy(),'costs':costs.copy(),'absolute_deadline_monotonic':deadline,'protocol_sha256':sha(PREP/'Protocol.json')};cp=checkpoints/f'seed{seed}_{algorithm}_{step-1:03d}.pkl';binary(cp,packet);event('full_state_local_hash_ACK',checkpoint=cp.name,sha256=sha(cp),**context)
                        raw=forward(models[algorithm],state)
                        if mode=='primary' and step==1:
                            loaded=pickle.loads(cp.read_bytes());cold_env=env.__class__.__new__(env.__class__);cold_env.__dict__.update(copy.deepcopy(loaded['environment']));assert loaded['remaining_original_horizon']==100 and loaded['absolute_deadline_monotonic']==deadline and np.array_equal(loaded['last_Q'],last)
                            for m in cold_models[algorithm]:m.env=cold_env
                            for n in ['bus','line','sgen','load','gen','ext_grid','shunt','switch','res_bus']:assert cold_env.network[n].equals(env.network[n])
                            observed=forward(cold_models[algorithm],loaded['state'],cold=True);assert np.array_equal(raw,observed) and np.array_equal(loaded['last_Q']-np.clip(observed,-.3,.3),last-np.clip(raw,-.3,.3)) and all(np.array_equal(v,parameters(cold_models[algorithm])[n]) for n,v in parameters(models[algorithm]).items());event('persisted_fresh_object_first_action_exact',**context)
                        action=last-np.clip(raw,-.3,.3);before_state=state.copy();nextstate,reward,_,done=env.step_Preward(action,last-action);vm=env.network.res_bus.vm_pu.to_numpy(copy=True);qcost=float(np.sum(action**2));state=nextstate.copy();last=action.copy();stepdata={'seed':seed,'algorithm':algorithm,'step':step,'previous_controlled_vm':before_state.tolist(),'raw_policy':raw.tolist(),'absolute_Q_Mvar':action.tolist(),'next_controlled_vm':state.tolist(),'all13_vm':vm.tolist(),'UV':int((vm<.95).sum()),'OV':int((vm>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'native_done':bool(done),'reward':float(reward),'Q_squared':qcost};all_steps.append(stepdata);history.append(stepdata);put(out/f'seed{seed}_{algorithm}_{step:03d}.json',stepdata)
                        if done:break
                    row.update(status='COMPLETE',endpoint=history[-1],cumulative_Q_squared=sum(s['Q_squared'] for s in history),all_bus_restored=bool(np.all(vm>=.95)&np.all(vm<=1.05)));event('branch_complete',seed=seed,algorithm=algorithm,steps=step,UV=row['endpoint']['UV'],OV=row['endpoint']['OV'])
                except BaseException as exc:row.update(failure=str(exc),failure_type=type(exc).__name__,completed_steps=len(history));event('branch_partial_or_unknown',**context,type=type(exc).__name__)
        complete=len(cases)==8 and all(c['root']=='RETURNED' and len(c['algorithms'])==3 and all(a['status']=='COMPLETE' for a in c['algorithms']) for c in cases)
        # A finite baseline endpoint floor,not an impossibility theorem or a learned-model score.
        every_restored=complete and all(a['all_bus_restored'] for c in cases for a in c['algorithms']);gate='NO_ENDPOINT_UV_HEADROOM_VERSUS_ALL3_ON_THESE8_ROOTS' if every_restored else 'RESIDUAL_HEADROOM_REQUIRES_STRONGER_NUMERICAL_CONTROL_AND_INFORMATION_ECONOMIC_GATES' if complete else 'UNKNOWN_PARTIAL_EVIDENCE'
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_DECLARED8_BASELINE_SUPPORT_SCREEN' if complete else 'TERMINAL_PARTIAL_DECLARED8_SUPPORT_SCREEN','mode':mode,'cases':cases,'all_steps':all_steps,'receipts':receipts,'costs':costs,'fixed_UV_opportunity_screen':gate,'training_or_GPU_permission':False,'no_LLM_superiority_or_global_bound_claim':True,'workflow_seconds':time.monotonic()-start,'cold_scope':'Fresh-objectfirst-action/fullcursorproof,notOSprocessrestart. Independentreaderfreshlyreexecutesreturnedphysical/modelidentities;failedscienceattemptsnotrepeated.'};put(out/'Result.json',result);put(out/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(out/'Result.json'));stream.close();put(out/'Closed_Manifest.json',{'files':[{'path':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in out.rglob('*') if f.is_file()],'journal_last_sha256':previous});return result
    except BaseException as exc:
        put(out/'Failure.json',{'type':type(exc).__name__,'failure':str(exc),'costs':costs,'cases':cases,'receipts':receipts,'seconds':time.monotonic()-start});stream.close();raise
