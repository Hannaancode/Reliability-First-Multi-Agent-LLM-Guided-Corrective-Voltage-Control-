"""Independent exact four-input/native-menu/closed-history scope certificate, zero PF."""
import copy,gzip,hashlib,json,pickle,zlib
from pathlib import Path
from third_point_four_query_core_20261019 import B,I,helpers,known_keys
from public118_slsqp_native_20261018 import R,read,put,sha
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from frozen_physics_loader import load_stack
from equal_operation_benchmark_v2 import decode_capsule
from strict_saved_native_input_match_v2_20261018 import require_same
INPUT=I/'Exact_Candidate_Inputs.json'

def certify():
    cellpath=R/'outputs/third_point_four_source_preparation_20261019/Exact_Current_Cell.json';cell=read(cellpath)
    state=helpers(__file__)['input_state']();enc=(R/cell['current_input']['path']).read_bytes();raw=zlib.decompress(enc)
    assert hashlib.sha256(enc).hexdigest()==cell['current_input']['encoded_sha256'] and hashlib.sha256(raw).hexdigest()==cell['current_input']['raw_sha256']
    source=pickle.loads(raw);require_same(state['net'],source['net']);assert state['cursor']==source['cursor']
    _,runner,_=load_stack();assert runner.rescue.grid_metrics(state['net'])==cell['current_metrics'] and cell['current_metrics']['uv_count']==18
    assert point_key(state['net'],state['cursor'])==cell['point'] and state['cursor']['remaining_original_device_operation_slots']==15
    _,actuate,native=build_verifier(runner.rescue,state['cursor']);assert native==cell['native_verifier_certificate'] and native['reverse_AST_exact']
    base=R/'outputs/prior_physical_query_footprints_20261018';audit=read(base/'independent_audit/Independent_Audit.json');assert audit['decoded_inputs']==60426 and audit['status'].startswith('PASS_ALL60426_')
    idx=base/'actual/Physical_Component_Input_References.json.gz';expected=read(base/'actual/Closed_Manifest.json')['members'][idx.name];expected=expected['sha256'] if isinstance(expected,dict) else expected
    assert sha(idx)==expected;index=json.loads(gzip.decompress(idx.read_bytes()))
    static=R/'outputs/fresh_static_component_index_20261018';sr=read(static/'Results.json');assert sr['observations']==3418 and sr['unique_components']==280 and sha(static/'All_Static_Component_References.json.gz')==sr['index_sha256']
    observed=json.loads(gzip.decompress((static/'All_Static_Component_References.json.gz').read_bytes()))
    prior=read(R/'outputs/fixed_four_query_acquisition_20261019/custody_repair/Completion.json');assert prior['original_physical_evidence_checks_completed'] and prior['original_overall_complete_gate']=='UNKNOWN_LAST_PROCESS_EXIT'
    recent=[];files=[INPUT,cellpath,R/cell['current_input']['path'],base/'independent_audit/Independent_Audit.json',base/'actual/Closed_Manifest.json',static/'Results.json',static/'All_Static_Component_References.json.gz',I/'Exact_Current_Input.zlib']
    for folder,phases,auditrel,status in [('exact_two_paid_query_engineering_20261018',('warm','cold'),'audit_source_claim_v2/Independent_Audit.json','PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING'),('remaining_three_fixed_queries_20261019',('warm','cold_1','cold_2'),'audit/Independent_Audit.json','PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'),('fixed_four_query_acquisition_20261019',('warm','cold_1','cold_2','cold_3'),'audit/Independent_Audit.json','PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE')]:
        root=R/'outputs'/folder;assert read(root/auditrel)['status']==status;files+=[root/auditrel,root/'Protocol.json']
        for phase in phases:
            d=root/phase;closed=read(d/'Closed_Manifest.json')
            for name in ('scientific.jsonl','capsules.bin'):assert sha(d/name)==closed['members'][name]
            with (d/'capsules.bin').open('rb') as pack:
                for line in (d/'scientific.jsonl').read_bytes().splitlines():
                    e=json.loads(line)
                    if e['event']=='PF_intent':
                        net=decode_capsule(pack,e['data']['before'])['net'];h,_=component(net);assert independent_component(net)==h;recent.append(h)
            files+=[d/'Closed_Manifest.json',d/'scientific.jsonl']
    assert len(recent)==18;keys=known_keys();rows=read(INPUT)['exact_new_query_rows'];targets=[]
    assert rows==cell['all4_pre_physics_menu']==cell['all_unexecuted_original_menu_queries']
    for v in rows:
        key=cell['point']+'|'+action_key(v['row']);assert key==v['point_action_key'] and key not in keys
        net=actuate(copy.deepcopy(state['net']),action(v['row']));h,values=component(net);assert h==independent_component(net)==v['component_sha256'] and values==v['perbus_rational_component']
        assert not index.get(h) and not observed.get(h) and h not in recent
        targets.append({'row':v['row'],'point_action_key':key,'role':'ORIGINAL_K4_RANK_'+str(v['fixed_rank']),'component_sha256':h,'tracked_component_matches':0,'static_component_matches':0,'recent18_input_component_matches':0})
    assert len(targets)==4
    result={'status':'PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE','exact_candidate_keys':[x['point_action_key'] for x in targets],'input_preparation_sha256':sha(INPUT),'reader_source_sha256':sha(__file__),'exact_rows':targets,'native_verifier_certificate':native,'evidence_sha256':{str(p.relative_to(R)):sha(p) for p in files},'scope':'60426 trackedBEFORE,3418staticAFTER and10recentBEFORE. Necessary component equations checked independently; not universal missing history or execution permission alone.','selection':'ALL4 original fixed numerical menu identities at exact NEW causal point, ordered before any query result; no width/Q/threshold/seed/prompt changes.','new_scientific_calls':0}
    put(B/'Attempt_Coverage_Certificate.json',result);return result
if __name__=='__main__':print(json.dumps({'coverage':certify()['status'],'science':0}))
