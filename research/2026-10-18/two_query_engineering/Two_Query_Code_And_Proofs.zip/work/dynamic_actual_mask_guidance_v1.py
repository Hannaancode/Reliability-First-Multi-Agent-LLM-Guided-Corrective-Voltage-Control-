"""Causal current-state guidance; never reads successors or measured action labels."""
import hashlib,time
import numpy as np
from scipy.linalg import lu_factor,lu_solve
from pandapower.pypower.dSbus_dV import dSbus_dV

def current_inputs(net):
    case=net['_ppc'];inner=case['internal'];mapping=np.asarray(net['_pd2ppc_lookups']['bus'],dtype=int)
    Y=inner['Ybus'].toarray();V=np.asarray(inner['V'])
    ref=np.asarray(inner['ref'],dtype=int);pv=np.asarray(inner['pv'],dtype=int);pq=np.asarray(inner['pq'],dtype=int)
    assert net.converged and Y.shape==(118,118) and V.shape==(118,) and set(mapping)==set(range(118))
    assert len(ref)==1 and len(ref)+len(pv)+len(pq)==len(set(ref)|set(pv)|set(pq))==118
    assert inner['J'].shape==(len(pv)+2*len(pq),)*2
    vm=net.res_bus.loc[range(118),'vm_pu'].to_numpy();va=net.res_bus.loc[range(118),'va_degree'].to_numpy()
    assert np.max(np.abs(V[mapping]-vm*np.exp(1j*np.deg2rad(va))))<=1e-14
    return dict(Y=Y,V=V,mapping=mapping,actual_ref=ref,actual_PV=pv,actual_PQ=pq,
                nonref=np.asarray(sorted(set(pv)|set(pq)),dtype=int),current_vm=vm,baseMVA=np.asarray(float(case['baseMVA'])))

def identity(c):
    digest=hashlib.sha256()
    for key in ['Y','V','mapping','actual_ref','actual_PV','actual_PQ','baseMVA']:
        a=np.ascontiguousarray(c[key]);digest.update(key.encode());digest.update(str(a.dtype).encode())
        digest.update(str(a.shape).encode());digest.update(a.tobytes())
    return digest.hexdigest()

def compile_current(net,cache,cost,event=lambda *a:None):
    c=current_inputs(net);ident=identity(c)
    if ident in cache:
        prior=cache[ident]
        assert np.array_equal(prior['current_vm'],c['current_vm'])
        cost['exact_context_reuses']+=1;event('exact_context_reused',{'context':ident})
        return prior,ident
    started=time.perf_counter();cost['public_derivative_attempts']+=1;event('public_derivative_attempt',{'context':ident})
    m,a=dSbus_dV(net['_ppc']['internal']['Ybus'],c['V']);cost['public_derivative_returns']+=1;event('public_derivative_return',{'context':ident})
    m,a=m.toarray(),a.toarray();nr=c['nonref'];pq=c['actual_PQ'];V=c['V']
    J=np.block([[a.real[np.ix_(nr,nr)],m.real[np.ix_(nr,pq)]],
                [a.imag[np.ix_(pq,nr)],m.imag[np.ix_(pq,pq)]]])
    B=np.zeros((len(J),118));pos={int(k):j for j,k in enumerate(pq)}
    for bus,k in enumerate(c['mapping']):
        if int(k) in pos:B[len(nr)+pos[int(k)],bus]=abs(V[k])**2/float(c['baseMVA'])
    cost['LU_factor_attempts']+=1;event('LU_factor_attempt',{'context':ident})
    factor=lu_factor(J,check_finite=True);cost['LU_factor_returns']+=1;event('LU_factor_return',{'context':ident})
    cost['LU_solve_attempts']+=1;event('LU_solve_attempt',{'context':ident,'RHS':118});X=lu_solve(factor,B,check_finite=True)
    cost['LU_solve_returns']+=1;cost['RHS_columns']+=118;event('LU_solve_return',{'context':ident,'RHS':118})
    assert np.isfinite(X).all() and np.max(np.abs(J@X-B))<=1e-8
    S=np.zeros((118,118));S[pq,:]=X[len(nr):,:];S=S[c['mapping'],:]
    c.update(m=m,a=a,J=J,B=B,X=X,sensitivity=S)
    cost['compile_seconds']+=time.perf_counter()-started;cache[ident]=c
    return c,ident
