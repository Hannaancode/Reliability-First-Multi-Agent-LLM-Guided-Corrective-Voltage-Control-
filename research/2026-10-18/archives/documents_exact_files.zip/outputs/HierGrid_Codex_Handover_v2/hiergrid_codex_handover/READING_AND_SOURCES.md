# Primary-source reading and implementation references

Checked/retrieved in the preparing conversation through 6 October 2026. Some entries were available only as abstracts/metadata, so do not claim every full paper was critically read. Recheck current software documentation against the frozen installed version. The current handover's main evidence is the supplied manuscripts, source files, actual protocol and logs once obtained.

## Immediate reviewer experiments

- Leyton-Brown, Nudelman, Andrew, McFadden, Shoham (2003), A Portfolio Approach to Algorithm Selection, IJCAI. https://www.ijcai.org/Proceedings/03/Papers/268.pdf — why a stronger portfolio result does not alone establish value of a learned branch beyond deterministic diversity.
- GridAgent, Zhang, Saber, Youssef, Kundur, arXiv:2508.05702v3. https://arxiv.org/abs/2508.05702v3 — adjacent grid agent orchestration; compare actual tools, benchmarks and claims.
- PGLib-OPF, Babaeinejadsarookolaee et al., A Power Grid Library for Benchmarking AC Optimal Power Flow Algorithms, arXiv:1908.02788. https://arxiv.org/abs/1908.02788 — benchmark data, formulation and reproducibility.
- DeepOPF-V, Huang, Pan, Chen, Low (2021), arXiv:2103.11793. https://arxiv.org/abs/2103.11793 — adjacent learned OPF/feasibility work; do not conflate it with LLM controllers.
- ProOPF, Shen et al., ICML2026. https://proceedings.mlr.press/v306/shen26h.html — modern learned optimization comparator background; optional rather than mandatory reviewer implementation.
- Agarwal et al. (2021), Deep Reinforcement Learning at the Edge of the Statistical Precipice. https://arxiv.org/abs/2108.13264 — effect sizes and uncertainty; adapt to paired/correlated physical scenarios.
- Pandapower runopp: https://pandapower.readthedocs.io/en/latest/opf/pypower_run.html
- Pandapower OPF formulation: https://pandapower.readthedocs.io/en/latest/opf/formulation.html
- Pandapower shunt behavior: https://pandapower.readthedocs.io/en/latest/elements/shunt.html — voltage-dependent device semantics; a constant-Q substitute is a modeling change.

## Security extension: highest relevance

- Liu, Ning, Reiter (CCS2009), False Data Injection Attacks against State Estimation in Electric Power Grids. DOI10.1145/1653662.1653666. https://reitermk.github.io/papers/2009/CCS1.pdf — coherent measurement attacks and residual-detector assumptions; arbitrary prompt-field edits are not automatically stealthy FDIA.
- Zou, Geng, Wang, Jia (USENIX Security2025), PoisonedRAG. https://www.usenix.org/conference/usenixsecurity25/presentation/zou-poisonedrag ; PDF https://www.usenix.org/system/files/usenixsecurity25-zou-poisonedrag.pdf — retrieved-knowledge poisoning; conditional attack rates, not universal security percentages.
- Shi, He, Wang, Li, Wu, Guo, Song, Progent, arXiv:2504.11703v3. https://arxiv.org/abs/2504.11703v3 ; full text https://arxiv.org/html/2504.11703v3 — programmable privileges and policy enforcement already exist, including multi-agent considerations.
- Debenedetti et al., Defeating Prompt Injections by Design (CaMeL), arXiv:2503.18813v2. https://arxiv.org/abs/2503.18813v2 — trust separation; do not invent bibliography authors from memory.
- Costa et al., Securing AI Agents with Information-Flow Control (Fides), arXiv:2505.23643v2. https://arxiv.org/abs/2505.23643v2 — information-flow enforcement and limits of generic-gate novelty.
- Debenedetti et al., AgentDojo, arXiv:2406.13352v3. https://arxiv.org/abs/2406.13352v3 — realistic agent attacks and utility evaluation.
- Md Fazley Rafy, TwinGridShield, arXiv:2608.15391 (August2026). https://arxiv.org/abs/2608.15391 — important adjacent grid digital-twin assurance preprint. Preparing review relied on retrieved primary abstract; full text retrieval failed. Verify manuscript before reproducing detailed claims. Distinguish surrogate proposals, actual LLM interactions and model-mismatch results.
- Zhao, Sedghi, Bohnet, Schuurmans, Nazi (ICLR2025), Improving Large Language Model Planning with Action Sequence Similarity (GRASE-DC). https://proceedings.iclr.cc/paper_files/paper/2025/hash/b18c6549c77411d92e645027a25838a8-Abstract-Conference.html — planning exemplars and external validators are established neighboring mechanisms.

## Supervisor-domain alignment

- Khan and Han (2002), Composing Security-Aware Software, IEEE Software19(1):34–41. DOI10.1109/52.976939. https://research.monash.edu/en/publications/composing-security-aware-software/ — metadata retrieved; do not claim full-text conclusions from metadata alone.
- Nhlabatsi, Khan, Hong, Kim, Fernandez, Fetais, Quantifying Satisfaction of Security Requirements of Cloud Software Systems, IEEE TCC11(1):426–444,2023 (early access2021). DOI10.1109/TCC.2021.3097770. https://research-repository.uwa.edu.au/en/publications/quantifying-satisfaction-of-security-requirements-of-cloud-softwa/ — retrieved abstract supports requirement satisfaction/assurance alignment.
- QU software engineering research: https://home.qu.edu.qa/en-us/Colleges/engineering/academics/computer/research/Pages/software_engineering.aspx — institutional context, not a guarantee of supervisor approval.

## Published dataset and simulation/defense scope

- Hannaan et al., A Structured Question–Answer Dataset for Large Language Models in Power System Dynamics and Operations, IEEE Access14:8391–8407,2026, DOI10.1109/ACCESS.2026.3652625. Supplied PDF included. Corpus repository: https://github.com/Hannaancode/PowerGridQA.git . Record/version counts need checking against exact corpus; paper counts should not substitute for an inventory. Do not edit published status or claim dataset security benefit without controlled new tests.
- UW IEEE118 archive: https://labs.ece.uw.edu/pstca/pf118/pg_tca118bus.htm — AEP December1962 origin and approximate original voltage/branch ratings.
- Texas A&M IEEE118 benchmark: https://electricgrids.engr.tamu.edu/electric-grid-test-cases/ieee-118-bus-system/
- NLR ADMS testbed: https://www.nlr.gov/grid/adms-test-bed — examples of simulation/hardware-in-loop validation; future work, not field deployment evidence for HierGrid.
- QU MSc Computing: https://www.qu.edu.qa/en-us/Colleges/engineering/graduate/Pages/master-computing.aspx — interdisciplinary computing context, not approval probability.
- QU examiner evaluation: https://www.qu.edu.qa/SiteImages/static_file/qu/colleges/engineering/documents/Examiners-Evaluation.pdf — research execution, critical literature, results and conclusions.
- QU CENG Graduate Studies Booklet August2025: https://home.qu.edu.qa/en-us/Colleges/engineering/research/graduatestudies/Documents/CENG%20Graduate%20Studies%20Booklet.pdf — proposal/examiner process; do not confuse PhD comprehensive examination sections with MSc thesis rules.

## Colab / Codex operational sources

- Google announcement June5,2026: https://developers.googleblog.com/introducing-the-google-colab-cli/
- Official Google CLI: https://github.com/googlecolab/google-colab-cli
- Published package: https://pypi.org/project/google-colab-cli/ — version0.7.4 retrieved; Python>=3.12.
- Authentication design: https://github.com/googlecolab/google-colab-cli/blob/main/docs/04_automation_and_utility.md — remote OAuth code flow; compare current installed help/source against stale defaults in documentation.
- Official Codex CLI: https://learn.chatgpt.com/docs/codex/cli — local file/tool access.
- Official cloud Codex: https://learn.chatgpt.com/docs/cloud — separate task workspaces, repositories and service/network access. A browser tab is not automatically local execution or authenticated Google access.
- Microsoft WSL commands: https://learn.microsoft.com/en-us/windows/wsl/basic-commands — diagnose actual installed distributions.

Older draft reports in the user's history contained incorrect bibliography details for some agent-security works. Use verified primary sources rather than copying those older citations. The two packaged current plans were revised with corrected source identities, but manuscript-level bibliographic verification remains required.
