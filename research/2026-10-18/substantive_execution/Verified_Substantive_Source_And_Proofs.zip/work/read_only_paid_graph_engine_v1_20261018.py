"""Source-identical paid planning with no native-science escape path.

Exact resource-cap/stock rejections need no old PF receipt. Missing eligible
receipts remain UNKNOWN. Never convert unavailable physical evidence to a
negative result, and never run a solver to fill a saved graph.
"""
import ast,copy
from collections.abc import MutableMapping
from pathlib import Path
import receding_paid_decision_engine_durable_v2 as original
from original_local_paid_branch_broker_v1 import resource_eligible
from lazy_paid_lineage_receipts_v1_20261018 import UnknownLineageIdentity
class MissingPaidReceipt(UnknownLineageIdentity):pass
class ResourceOnlyOverlay(MutableMapping):
    def __init__(self,registry):self.registry=registry;self.resource={};self.pending={}
    def __getitem__(self,key):
        if key in self.resource:return copy.deepcopy(self.resource[key])
        return self.registry.archive.archived_receipt(key)
    def __setitem__(self,key,record):
        assert key in self.pending and key not in self.registry.archive.index and key not in self.resource
        node,row=self.pending.pop(key)
        assert not resource_eligible(row,node['cursor']) and record['candidate']==row
        assert record['attributed_PF_calls']==0 and record['after_reference'] is None and record['attributed_solver_seconds']==0
        assert record['verdict']=={'accepted':False,'reason':'exact_resource_cap_or_stock_rejection_noPF','after':None}
        self.resource[key]=copy.deepcopy(record)
    def __delitem__(self,key):raise TypeError('Observed/resource evidence cannot be deleted')
    def __iter__(self):return iter(set(self.registry.archive.index)|set(self.resource))
    def __len__(self):return len(self.registry.archive.index)+len(self.resource)
text=Path(original.__file__).read_text('utf-8')
changes=[('record = copy.deepcopy(cache[key])','record = self.certified_cached_record(node, row, key)'),
    ('if key in cache:', 'if self.known_receipt_or_exact_resource_reject(node, row, key):')]
changed=text
for before,after in changes:assert changed.count(before)==1;changed=changed.replace(before,after)
inverse=changed
for before,after in reversed(changes):assert inverse.count(after)==1;inverse=inverse.replace(after,before)
assert inverse==text
node=next(n for n in ast.parse(changed).body if isinstance(n,ast.ClassDef) and n.name=='PaidDecisionEngine')
env=original.__dict__.copy();exec(compile(ast.Module(body=[node],type_ignores=[]),str(Path(__file__)),'exec'),env)
SourceEngine=env[node.name]
class ReadOnlyPaidGraphEngine(SourceEngine):
    def __init__(self,*,use_registry,**kwargs):
        self.use_registry=use_registry;self.observed_cache=ResourceOnlyOverlay(use_registry)
        kwargs['cache']=self.observed_cache;super().__init__(**kwargs)
    def known_receipt_or_exact_resource_reject(self,node,row,key):
        if key in self.use_registry.archive.index or key in self.observed_cache.resource:return True
        if not resource_eligible(row,node['cursor']):self.observed_cache.pending[key]=(node,row);return False
        raise MissingPaidReceipt(key)
    def certified_cached_record(self,node,row,key):
        self.evidence.admit()
        if key in self.observed_cache.resource:return self.observed_cache[key]
        record=self.use_registry.lookup(node,row,key)
        self.evidence.costs.setdefault('archived_receipt_verification_CPU_seconds',0.)
        self.evidence.costs['archived_receipt_verification_CPU_seconds']+=record['verified_use_reference']['actual_verification_CPU_seconds']
        return record
SOURCE_CERTIFICATE={'exact_inverse_source_transform':True,'edits':changes,
    'source_native_resource_predicate_and_noPF_record_unchanged':True,
    'all_menu_Q_cost_mask_scope_guard_forecast_policy_and_first_only_choices_unchanged':True,
    'only_eligible_missing_receipts_stop_UNKNOWN':True,'no_native_scientific_permission_supplied':True,
    'offline_observed_projection_not_actual_commit':True}
