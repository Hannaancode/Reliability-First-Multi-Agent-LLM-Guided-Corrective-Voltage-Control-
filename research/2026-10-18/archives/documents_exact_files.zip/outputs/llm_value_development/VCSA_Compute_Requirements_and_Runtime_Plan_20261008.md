> Latest 2026-10-08T13:17:18.872540+00:00: VCSA has139 genuine no-LLM control replay PF calls and5 started/4 source-proven returned local pretrained CPU forwards; zero preserved real optimizer completions/checkpoints. CPU attempt terminal; no owned jobs. v3 decoder/checkpoint software20 checks passed (192 records/94 reloaded actions), not learned evidence. Exact34,831,836-byte Sheena T4 upload approval remains pending. Read outputs/vcsa_development/post_CPU_integration_readiness/Verified_Readiness_Checkpoint.md and Attribution_Gates_and_Execution_Order.md. Original baseline unchanged; superiority unachieved. Older zero-pretrained/CPU-running/oldCPU-upload headers below are historical.

> Latest 2026-10-08T11:29:08.762565+00:00: local module v1/v2 and data/control audits complete;155 state-only CPU steps, zero new VCSA pretrained calls. Exact34,831,836-byte HF/PEFT T4 smoke payload awaits direct specific upload approval after automatic review rejection. Old CPU-only upload/DLL blocks are obsolete. Read outputs/vcsa_development/Ready_Implementation_Checkpoint.md and latest_execution_status.json. Stage3 is partial74/80, six CPU records and original global costs unknown. Superiority unachieved.

> Execution update: T0 and bounded candidate labels completed/audited; source-only module-fixture approval pending; Stage3 incomplete74/80 after originalruntime loss. Read outputs/vcsa_development/latest_execution_status.json and T1_Labeling_Addendum.md. Older estimates/status/zero-historical-overlap text below are superseded. Training not started and no end-to-end completion ETA established.

# VCSA compute requirements and execution schedule

**Prepared:** 2026-10-08  
**Purpose:** make the proposed VCSA model-level experiment executable with the local CPU and two authenticated Colab profiles, while preserving the active Stage3 study and the frozen baseline.

## Decision in one paragraph

The plan is feasible as a staged programme, but a full physical relabel of all 16,000 training records is not feasible inside one or two Colab sessions if each record requires a fresh deterministic search. The first execution must therefore be a CPU-only provenance and deduplication audit that counts unique physical states and discovers whether candidate outcomes are already present. Only a bounded 32–64-state label pilot is allowed before committing to broader labels. One T4 is sufficient for the first architecture smoke test and a bounded training pilot; two T4s would shorten the two-model comparison, but a fourth account is unnecessary and does not remove the CPU replay bottleneck.

## Current capacity and ownership

| Resource | Current state | Use in this plan | Constraint |
|---|---|---|---|
| Local CPU | 6 logical CPUs; 16.98 GB physical RAM, 5.34 GB available at measurement | T0/T1 audits, hashing, deduplication, label pilot, replay and independent audit | Start with 3 solver workers; increase only after memory and exception rates are stable. Six workers is an upper practical limit, not the default. Recheck before a parallel replay. |
| Original Colab profile (`abdulhannaan2002@gmail.com`) | One T4 assignment is active for the original Stage3 matched study, owner PID 17368 | Finish Stage3 only | No VCSA allocation, upload, inference or writer may compete with it. |
| Isolated Colab profile (`sheenahammed@gmail.com`) | Authenticated; prior T4 access was verified, but no VCSA assignment is currently owned | First VCSA smoke/training run after a fresh eligibility and ownership check | One owner, one assignment, one output directory. |
| Third profile (`ahammedsheen@gmail.com`) | Authenticated and previously reported T4 eligibility; no allocation or inference | Optional contingency only | Do not add it merely to increase apparent capacity or rotate after a denial. |
| Fourth profile | Not configured for this plan | Not required | More profiles do not increase CPU throughput or guarantee a T4. |

At plan preparation the Stage3 snapshot had 39 of 80 planned records, with 45 minutes 49 seconds between launch and that snapshot. The live status then advanced to 40 locally preserved records and 41 remotely saved records, so a one-record transfer lag is being preserved rather than hidden. The observed rate is about 70.5 seconds per saved record; a straight extrapolation gives roughly 94 minutes for all 80 and roughly 48 minutes for the remaining 41. This is a progress estimate, not a completion promise, because arms and transfer times are not uniform.

## Measured workload facts

These values come from completed local manifests and are not projections:

* The first clean screen used 63 real generations in 75.3486 seconds (about 1.20 seconds per generation).
* The broader screen used 240 real generations in 271.242277 seconds (about 1.13 seconds per generation).
* The clean screen required 1,614 local PF evaluations and zero exceptions; the broader screen required 6,456 PF evaluations and retained nine exceptions.
* The literal D-SE development reference used 19,772 controller PF attempts, 27 retained exceptions and 113 independent replay PF attempts. Individual full two-branch portfolio rows took about 59–270 seconds, depending on operating point.
* The training archive contains 16,000 train, 2,000 validation and 2,000 test JSONL records (about 141 MB total), from 109/13/15 physical scenarios. The archive contains prompts and replies, not the VCSA physical counterfactual table.

The implication is clear: generation time is not the limiting resource. Deterministic replay and label construction are.

## Why a naïve full-label run is not acceptable

If every one of the 16,000 training records were treated as a new physical state and required even one 60–270 second full-search branch, the serial upper bound would be about 11–50 days. With the observed six logical CPUs, six fully useful workers would still require roughly 1.8–8.4 days, before I/O and solver failures. This is an upper bound, not a forecast: repeated states, stored action chains and candidate results may reduce it substantially. The first audit must discover that reduction. No full-label job may start until the unique-state count and cached-outcome coverage are written to a manifest.

## Execution gates and resource schedule

### Gate 0 — finish and seal the active Stage3 study

1. Let owner PID 17368 finish on the original assignment.
2. Preserve every actual partial, failure and unexecuted identity; release the exact assignment only after the remote process and collector are both stopped.
3. Run the prepared Stage3 analysis once, after its identity and manifest gates pass. Do not use its outcomes as VCSA training labels.

**Expected time:** the last measured Stage3 rate suggests up to about 50 minutes for the remaining records, but the saved status is authoritative.

### Gate 1 — CPU-only T0 audit and deduplication (first action after Stage3)

Run a read-only audit over the three JSONL splits and the split map. It must:

1. verify archive and split hashes, record counts and zero locked-bank/historical overlap;
2. canonicalize the physical state, candidate scope and scenario ID into a state hash;
3. count unique physical states per split and per scenario;
4. detect stored candidate outcomes, action chains and PF/solver fields;
5. estimate missing replay work from the measured 59–270 second branch range;
6. write a new immutable audit manifest without changing the archive.

**Stop condition:** if state identity is ambiguous, or candidate outcomes are absent and the estimated full replay exceeds the available CPU window, do not launch a broad label job. Keep only the bounded pilot.

**Expected time:** 15–45 minutes for hashing, parsing and counts, depending on local I/O.

### Gate 2 — bounded physical-label pilot (CPU)

Select 32 train states and 16 validation states using the already frozen scenario split and a hash-based rule. For each state, evaluate the recorded action plus the predeclared D-SE/candidate negatives with the unchanged verifier. Preserve successes, failures, PF exceptions, full costs and source hashes.

The pilot measures:

* unique-state replay time;
* PF attempts per state and exception rate;
* percentage of candidate outcomes already available;
* admissible novel-action availability;
* disk growth and safe parallel worker count.

Do not expand beyond 64 train states until this pilot is independently audited. If the pilot has no admissible alternatives, VCSA cannot be justified as an improvement method and training stops.

**Expected time:** unknown before Gate 1. Use the measured 59–270 seconds per full branch only as a bound; a cached or deduplicated state may be much faster. The pilot is deliberately sized so it can be stopped without wasting a runtime window.

### Gate 3 — VCSA implementation and T4 smoke test

After the label pilot and module tests pass, allocate one fresh T4 (prefer the isolated profile; never interrupt Stage3). The smoke test must load the frozen Qwen base/tokenizer, current adapter and the new VCSA namespace, then verify memory, adapter enable/disable isolation, tensor shapes, candidate masks, serialization consistency and the no-solver-during-generation rule.

**Expected time:** 10–15 minutes on one T4. This is a software gate, not scientific evidence.

### Gate 4 — fixed training pilot

Train only two predeclared variants first:

1. **Static-SFT:** factorized action/process heads without state-conditioned rank routing.
2. **VCSA-Full:** state fusion, adaptive rank groups, physical preference/process losses and abstention.

Base and current-LoRA are frozen reference rows; the full seven-variant ablation matrix is deferred until the novel-action gate is passed. Use the same label manifest, seed, optimizer, context limit, rank and stopping rule for both variants. Save checkpoints incrementally and record actual tokens, steps, wall time, GPU memory and failures.

**Estimate, to be measured by the first pilot:** 45–90 minutes per variant for a bounded pilot on a T4; roughly 1.5–3 hours sequentially on one T4. A full training run may take 1–3 hours per variant, but this is not a measured fact and must not be promised until the pilot reports throughput. A second independently owned T4 can run the two variants in parallel, subject to fresh allocation and separate output claims.

### Gate 5 — CPU development replay and novel-action gate

Run Static-SFT and VCSA-Full on validation/development states only. Every changed action is replayed independently with the unchanged verifier. Count valid proposals, admissible novel actions, protected endpoint, residual deficit, full cost, PF exceptions, support calibration, fallback rows and all timing components.

**Stop condition:** zero selected-action changes, zero admissible novel actions, or universal rejection of changed actions. In that case report imitation/negative evidence and do not launch DAgger, broader training or a superiority campaign.

**Expected time:** determined by the Gate 2 throughput measurement. The T4 generation portion should be minutes to tens of minutes; CPU physical replay remains the controlling term.

### Gate 6 — confirmation only if the novel-action gate passes

Freeze an unused confirmation manifest and run D-SE, Base, Current-LoRA, Static-SFT and VCSA-Full on identical worlds. Use one T4 for model calls and local CPU for replay. A second T4 may reduce wall time only if it has an independent owner and separate staging. The model receives credit only for a changed, physically admissible action that improves the protected endpoint without a full-cost or safety regression. Fallback rows are D-SE rows.

## Practical time budget

| Work package | Best-case | Conservative planning bound | Dominant resource |
|---|---:|---:|---|
| Remaining Stage3 | ~48 min | up to the existing 90-min remote deadline | Existing original T4 |
| T0 audit/dedup | 15 min | 45 min | Local CPU/I/O |
| 32–64-state label pilot | cache-dependent | 1–4 h until measured | Local CPU/PF |
| VCSA smoke | 10 min | 15 min | One T4 |
| Two-variant training pilot | 45–90 min parallel | 1.5–3 h sequential | One or two T4s |
| Development replay | cache-dependent | measure from Gate 2 | Local CPU/PF |
| Confirmation | only after novel-action gate | not scheduled yet | T4 generation + CPU/PF |

The user-reported Colab lifetime estimates of about 110 minutes (original) and 130 minutes (Sheena) are estimates, not quotas. They are enough for a smoke test and a bounded training pilot, but not a reason to start a broad label or confirmation campaign. Checkpointing is mandatory.

## Recommended use of two CLI profiles

* Keep the original profile dedicated to Stage3 until its exact assignment is released and audited.
* Use the isolated profile for the first VCSA smoke/training owner after a fresh GET-only identity, eligibility and assignment check.
* If both are genuinely free after Stage3, run Static-SFT and VCSA-Full in parallel only with separate claims, manifests, staging directories and process ownership. Never share a runtime or writer.
* Do not add the third or fourth profile now. Add one only if the user explicitly requests it for a separately justified owner after the two-profile plan is saturated. Do not rotate profiles after a denial.

## What will make this feasible

1. Deduplicate physical states before replay.
2. Reuse stored candidate outcomes when their source/state hashes match exactly.
3. Run only a bounded label pilot before any full table.
4. Keep CPU PF replay and GPU generation separate so a T4 is not idle while CPU labels are prepared.
5. Train two variants first; defer ablations until the novel-action gate.
6. Checkpoint every bounded block and preserve partials; never rerun inference because of transfer failure.
7. Use the exact D-SE comparator and full costs; no threshold, prompt, Q-grid, seed or case selection changes to chase a win.

## Readiness conclusion

The compute plan is feasible for a first scientifically meaningful VCSA test with one active T4 plus local CPU. It is not feasible to promise a complete 16,000-state physical relabel, seven-model ablation and confirmation campaign inside one short Colab window. The next concrete execution step is the CPU-only T0 audit and unique-state/cached-label measurement after Stage3 releases its assignment. The LLM superiority hypothesis remains open; compute is sufficient to test it honestly, not to guarantee its outcome.

## Token and compute discipline for execution

The continuation will use the following controls so the research budget is spent on evidence rather than repeated supervision:

1. **One control owner per stage.** Every stage has one claim file, one process owner and one output directory. No duplicate worker, downloader, allocator or analyst is started.
2. **Streaming local audits.** JSONL files are read once, line by line, and reduced to hashes/counts. Full logs are not repeatedly loaded into the conversation; only status deltas, errors and final manifests are inspected.
3. **Bounded polling.** The monitor reads compact status files at meaningful transitions. It does not repeatedly reread unchanged logs, and it stays quiet while a healthy owner is progressing.
4. **GPU windows are reserved for model work.** CPU hashing, deduplication, replay and archive checks run before or alongside a GPU owner so T4 time is not spent waiting on local preparation.
5. **Checkpointed GPU blocks.** Smoke, training and inference are split into bounded blocks with incremental manifests. A transfer failure preserves the partial block and never causes silent inference reruns.
6. **Three CPU workers first.** The machine has six logical CPUs but only about 5.34 GB free RAM at measurement. Start with three solver workers and increase only after memory and exception rates are stable.
7. **No outcome-chasing.** The D-SE comparator, candidate scope, thresholds, budgets, seeds and case-selection rule are frozen before each stage. A failed novel-action gate ends that branch rather than triggering small unregistered tweaks.
8. **Early scientific stop gates.** If labels are ambiguous, replay cost is excessive, VCSA emits no admissible novel actions, or changed actions are universally rejected, stop and preserve the negative result.
9. **Separate evidence ledgers.** Model-generation time, model-load time, solver/PF time, repair time, transfer time and full monetary/compute cost are recorded separately. Fallback rows receive D-SE credit, never LLM credit.
10. **Minimal account use.** Keep the original profile on Stage3 until release, then use the isolated profile for VCSA. A third or fourth profile is added only for a separately justified parallel owner; profiles are never rotated to evade a denial.
