"""Independent native affine step and literal-latching reader, zero solves."""
import json,gzip,time,os,zipfile,hashlib
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import numpy as np
from candidate_process_evidence_utils import ROOT,read,sha,write,seal,frozen_checks
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
def frame(f):return {i:dict(zip(f['columns'],r)) for i,r in zip(f['index'],f['values'])}
def reader_context(saved,tables,action,candidate):
    V=saved['V'];Y=saved['Y'];mapping=saved['mapping'];base=float(saved['baseMVA']);refs=saved['refs']
    newY=Y.copy();k=mapping[action['bus']];newY[k,k]+=1j*action['q_abs_mvar']/base
    y=newY if candidate else Y;I=y@V;vn=V/np.abs(V)
    m=np.diag(V)@np.conj(y@np.diag(vn))+np.diag(np.conj(I))@np.diag(vn)
    a=1j*np.diag(V)@np.conj(np.diag(I)-y@np.diag(V))
    return {'V':V,'Y':Y,'newY':newY,'mapping':mapping,'base':base,'refs':refs,'m':m,'a':a,
            'gen':frame(tables['gen']),'gres':frame(tables['res_gen']),'deltaS':V*np.conj(newY@V)-V*np.conj(Y@V)}
def reconstruct(c,mask):
    fixed={int(i):0. for i in c['refs']};rhs=-c['deltaS'].copy();vm=np.abs(c['V'])
    for gid,g in c['gen'].items():
        k=c['mapping'][g['bus']];label=mask[gid]
        if label=='interior':fixed[k]=g['vm_pu']-vm[k]
        else:rhs[k]+=1j*((g['min_q_mvar'] if label=='near_min' else g['max_q_mvar'])-c['gres'][gid]['q_mvar'])/c['base']
    nr=np.array([i for i in range(118) if i not in c['refs']]);free=np.array([i for i in range(118) if i not in fixed])
    known=np.array(sorted(fixed));kd=np.array([fixed[i] for i in known]);m=c['m'];a=c['a']
    J=np.block([[a.real[np.ix_(nr,nr)],m.real[np.ix_(nr,free)]],[a.imag[np.ix_(free,nr)],m.imag[np.ix_(free,free)]]])
    b=np.r_[rhs.real[nr]-m.real[np.ix_(nr,known)]@kd,rhs.imag[free]-m.imag[np.ix_(free,known)]@kd]
    return J,b,nr,free,known,kd
def verify_saved_step(c,record,arrays):
    mask={int(i):s for i,s in record['mask'].items()};J,b,nr,free,known,kd=reconstruct(c,mask)
    assert np.max(np.abs(J-arrays['J']))<=1e-10 and np.max(np.abs(b-arrays['rhs']))<=1e-10
    x=arrays['x'];res=float(np.max(np.abs(J@x-b)));assert res<=1e-8
    dm=np.zeros(118);dm[known]=kd;dm[free]=x[len(nr):];da=np.zeros(118);da[nr]=x[:len(nr)]
    assert np.max(np.abs(dm-arrays['dvm']))<=1e-14 and np.max(np.abs(da-arrays['dva']))<=1e-14
    predicted=(np.abs(c['V'])+dm)[c['mapping']];assert np.max(np.abs(predicted-arrays['vm']))<=1e-14
    qdelta=(c['deltaS']+c['a']@da+c['m']@dm).imag*c['base']
    qg={i:c['gres'][i]['q_mvar']+float(qdelta[c['mapping'][g['bus']]]) for i,g in c['gen'].items()}
    actualq={int(i):v for i,v in record['qgen'].items()};assert max(abs(qg[i]-actualq[i]) for i in qg)<=1e-8
    updates={i:('near_max' if qg[i]>g['max_q_mvar'] else 'near_min') for i,g in c['gen'].items()
             if mask[i]=='interior' and (qg[i]>g['max_q_mvar'] or qg[i]<g['min_q_mvar'])}
    # Strict branch comparisons must agree; no tolerance-based relabelling.
    assert updates=={int(i):v for i,v in record['updates'].items()}
    assert record['bound_count']==sum(v!='interior' for v in mask.values())
    return res,predicted,updates

def run():
    OUT=P/'source_latched_affine_external_audit';S=P/'source_latched_affine_control';PRE=P/'source_latched_affine_preparation'
    assert not OUT.exists();OUT.mkdir();start=time.perf_counter();write(OUT/'owner.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__))})
    assert read(S/'status.json')['stage']=='complete_source_latched_affine_control'
    ep=read(S/'Execution_Protocol.json');proto=read(PRE/'Protocol.json')
    for name,h in ep['sources'].items():assert sha(ROOT/name)==h
    assert sha(Path(__file__))==ep['sources']['work/audit_source_latched_affine_control.py']
    assert sha(PRE/'Protocol.json')==ep['prospective_protocol_sha256']
    for name,d in read(S/'Input_Reuse_Lock.json').items():assert (ROOT/name).stat().st_size==d['bytes'] and sha(ROOT/name)==d['sha256']
    manifest=read(S/'Supplement_Manifest.json');external=ep['external_scientific_files']
    for name,d in manifest.items():
        path=ROOT/external[name] if name in external else S/name
        assert path.stat().st_size==d['bytes'] and sha(path)==d['sha256']
    with zipfile.ZipFile(S/'Measured_Source_Latched_Affine_Control.zip') as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
        for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d['sha256']
    with gzip.open(P/'measured_OPT_transition_inventory/Actual_OPT_Transition_Rows.jsonl.gz','rt',encoding='utf8') as f:ts={t['transition_id']:t for t in map(json.loads,f)}
    actual=read(S/'Actual_All_Transition_Records.json');summary=read(S/'Summary.json')
    labs={r['transition_id']:r for r in read(P/'OPT_generator_bound_event_inventory/Actual_Generator_Bound_Records.json')}
    assert len(actual)==len({r['transition_id'] for r in actual})==216 and set(ts)=={r['transition_id'] for r in actual}==set(proto['transition_ids'])
    worlds=defaultdict(lambda:defaultdict(list));upper=Counter();steps=0;maxres=0.;scalarchecks=0;confusions=defaultdict(Counter);changed=defaultdict(Counter);stable=defaultdict(Counter)
    for r in actual:
        t=ts[r['transition_id']];h=t['before_observation_sha256'];tables=t['model_input']['current_physical_observation']['physical_tables'];a=t['model_input']['candidate_action']
        assert r['before_sha256']==h and r['action']==a and r['provenance']==t['audit']['source_provenance']
        with np.load(P/'observed_constraint_affine_diagnostic/states'/(h+'.npz')) as z:saved={k:z[k] for k in z.files}
        targetframe=frame(t['measured_target']['next_res_bus']);target=np.array([targetframe[b]['vm_pu'] for b in range(118)])
        for arm,candidate in [('old_admittance_derivative',False),('candidate_admittance_derivative',True)]:
            item=r['arms'][arm];c=reader_context(saved,tables,a,candidate);mask={i:'interior' for i in c['gen']};previous=-1
            assert item['status'].startswith('finite_'),'Incomplete forecasts cannot enter complete-headroom audit'
            with np.load(S/'equations'/(r['transition_id']+'_'+arm+'.npz')) as z:
                for k,record in enumerate(item['steps']):
                    assert record['step']==k and {int(i):v for i,v in record['mask'].items()}==mask and record['bound_count']>previous
                    previous=record['bound_count'];arrays={n:z[f's{k:02d}_{n}'] for n in ('J','rhs','x','vm','dvm','dva')}
                    res,pred,updates=verify_saved_step(c,record,arrays);maxres=max(maxres,res);steps+=1
                    if k+1==len(item['steps']):assert not updates
                    else:assert updates
                    mask.update(updates)
                assert mask=={int(i):v for i,v in item['mask'].items()} and len(item['steps'])<=54
            mse=float(np.mean((pred-target)**2));over=bool(pred.max()>1.05+1e-8);assert abs(item['MSE']-mse)<=1e-16 and item['upper_forecast']==over
            assert abs(item['max_abs_error']-float(np.max(np.abs(pred-target))))<=1e-14
            worlds[arm][r['provenance'][0]['world_sha256']].append(mse);upper[arm]+=int(over);scalarchecks+=118
            for m in labs[r['transition_id']]['generator_measurements']:
                i=m['native_gen_id'];truth=m['after_nominal_occupancy'];inferred=mask[i]
                confusions[arm][truth+'->'+inferred]+=1
                (changed if m['before_nominal_occupancy']!=truth else stable)[arm]['correct' if inferred==truth else 'wrong']+=1
    rates={arm:{w:float(np.mean(v)) for w,v in groups.items()} for arm,groups in worlds.items()}
    for arm in rates:
        assert rates[arm]==summary['world_MSE'][arm] and abs(float(np.mean(list(rates[arm].values())))-summary['arms'][arm]['equal_world_MSE'])<=1e-16
        assert upper[arm]==summary['arms'][arm]['upper_forecasts']
        assert dict(confusions[arm])==summary['arms'][arm]['nominal_target_confusion']
        assert dict(changed[arm])==summary['arms'][arm]['measured_changed_gen_accuracy'] and dict(stable[arm])==summary['arms'][arm]['measured_stable_gen_accuracy']
    oracle=read(P/'observed_constraint_affine_diagnostic/Summary.json');heads={}
    baselines={'A':oracle['world_MSE']['A'],**rates};overheads={'A':oracle['arms']['A']['upper_forecasts'],**dict(upper)};threshold=proto['headroom_thresholds']
    for oa in ('C','D'):
        heads[oa]={}
        for b,v in baselines.items():
            reduction=1-oracle['arms'][oa]['equal_world_MSE']/float(np.mean(list(v.values())))
            improved=sum(oracle['world_MSE'][oa][w]<v[w] for w in v);difference=overheads[b]-oracle['arms'][oa]['upper_forecasts']
            heads[oa][b]={'MSE_reduction':reduction,'strict_improved_worlds':improved,'upper_forecast_reduction':difference,
              'passed':reduction>=threshold['relative_MSE_reduction'] and improved>=threshold['strict_improved_worlds'] and difference>=threshold['upper_count_reduction']}
    assert heads==summary['oracle_headroom_against_all_strong_controls']
    journal=[json.loads(l) for l in (S/'Actual_Journal.jsonl').read_text().splitlines()];counter=Counter(e['event'] for e in journal)
    cost=summary['actual_costs'];assert counter['arm_attempt']==counter['arm_closed']==432
    assert cost['compile_attempts']==cost['compile_returns']==cost['derivative_evaluations']==432
    assert cost['solve_attempts']==cost['solve_returns']==steps and cost['new_PF_model_optimizer_controller_cloud_calls']==cost['exceptions']==0
    result={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_source_input_equation_mask_update_cost_manifest_gates_passed':True,
      'exact_OPT_transitions':216,'OPT_worlds':23,'all432_arm_forecasts':True,'independent_saved_step_reconstructions':steps,
      'independent_dense_derivative_evaluations':432,'forecast_scalar_checks':scalarchecks,'max_equation_residual':maxres,
      'all_arm_results':summary['arms'],'oracle_headroom_against_all_strong_controls':heads,
      'further_target_design_headroom_passed':any(all(v['passed'] for v in b.values()) for b in heads.values()),
      'new_solves_PF_model_optimizer_cloud_calls_by_reader':0,'reader_seconds':time.perf_counter()-start,
      'no_nonlinear_PF_convergence_solver_hidden_mode_LLMincrementalvalue_DSE_or_confirmation_claim':True}
    write(OUT/'Independent_Source_Latched_Affine_Audit.json',result);write(OUT/'Frozen_Preservation.json',frozen_checks())
    (OUT/'Results.md').write_text('All216 OPT cases and both numerical variants were independently audited.\n\n'+json.dumps(result['all_arm_results'],indent=2)+'\n\nAll oracle and practical outcomes, costs, mismatches and failure denominators are retained. This is saved-state affine development evidence, not physical rollout, hidden-mode equality, LLM contribution or D-SE superiority.\n',encoding='utf8')
    files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'};files['source/reader.py']=Path(__file__)
    archive=seal(OUT,files,'Independent_Source_Latched_Affine_Control_Audit.zip')
    print(json.dumps({'audit':result,'archive':archive}))
if __name__=='__main__':run()
