"""Independent scope/cost/source closure of the new paid-input index, zero PF."""
import copy,hashlib,json,os,time
import numpy as np
import pandapower as pp
from compile_lookahead_paid_input_cache_20261014 import R,B,PH,FULL,OLD,TWO,read,sha,canon,put,load_ref
import full_joint_suffix_benchmark_20261014 as prior
from equal_operation_benchmark_v2 import decode_capsule,initial_data
from joint_reallocation_opportunity_core_v1 import load_endpoint
from frozen_physics_loader import load_stack
from shared_original_serving_action_domain_v1 import build_current_domain

def independent_point(net,cursor):
    temporary=copy.deepcopy(cursor);temporary['raw_current_receiver_scope']=[]
    inner=net['_ppc']['internal']
    return hashlib.sha256(canon({'physical_case_and_resource_identity':prior.state_key(net,temporary),
        'actual_native_ref':np.asarray(inner['ref'],dtype=int).tolist(),
        'actual_native_PV':np.asarray(inner['pv'],dtype=int).tolist(),
        'actual_native_PQ':np.asarray(inner['pq'],dtype=int).tolist()})).hexdigest()
def main():
    result=read(B/'Result.json');assert result['exit_code']==0
    out=B/'audit';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'reader_sha256':sha(__import__('pathlib').Path(__file__))})
    for name,h in result['source_hashes'].items():assert sha(R/name)==h,name
    def blocked(*a,**k):raise AssertionError('Paid input reader cannot repeat scientific calls')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,blocked)
    index=read(B/'Compatible_Paid_Receipt_Index.json');cache=index['cache'];expected={};aliases={};roots={};oldfn=prior.state_key
    def traced(net,cursor):
        oldkey=oldfn(net,cursor);aliases[oldkey]=independent_point(net,cursor);return oldkey
    # Capture old context keys without changing their values or launching owners.
    prior.state_key=traced
    try:old,legacy,original_roots,_=prior.legacy_cache()
    finally:prior.state_key=oldfn
    for (oldkey,ak),r in legacy.items():expected[aliases[oldkey]+'|'+ak]={'raw':r,'base':FULL,'hash':hashlib.sha256(canon(r)).hexdigest()}
    _,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    for e in old['current_endpoints']:
        net,cursor,_=load_endpoint(e);domain=build_current_domain(net,cursor,runner=runner,zones=zones)
        point=independent_point(net,domain['expanded_cursor_for_separately_fixed_future_protocol']);roots[e['world']]=(point,domain)
        assert point==aliases[oldfn(*original_roots[e['world']][:2])]
    for x in read(PH/'actual/Actual_New_Action_Records.json')['records']:
        receipt=x['measured_receipt'];raw={'candidate':x['candidate'],'verdict':x['verdict'],'original_score':x['original_score'],
            'after_reference':{'kind':'new','descriptor':receipt['after']} if receipt['outcome']=='RETURNED' else None,
            'receipt_id':'SHARED_ROOT_NEW_'+str(receipt['PF_id']),'attributed_PF_calls':1,'attributed_solver_seconds':receipt['seconds']}
        expected[roots[x['world']][0]+'|'+prior.action_key(x['candidate'])]={'raw':raw,'base':PH,'hash':hashlib.sha256(canon(x)).hexdigest()}
    receipt_refs={r['raw']['receipt_id']:r for r in expected.values()};active=None;active_key=None;pending={};previous='0'*64;events=0
    with (FULL/'actual/scientific.jsonl').open('rb') as stream,(FULL/'actual/capsules.bin').open('rb') as pack:
        for line in stream:
            assert time.perf_counter()-start<180
            e=json.loads(line);assert e['previous_sha256']==previous;previous=hashlib.sha256(line.rstrip(b'\n')).hexdigest();events+=1
            d=e['data'];kind=e['event']
            if kind=='branch_initialized':
                net=decode_capsule(pack,d['initial_capsule'])['net'];c=d['current_cursor'];active=independent_point(net,c);active_key=oldfn(net,c)
            elif kind=='PF_intent' and d['context'].get('phase')=='NEW_PRIMARY_QUERY':
                assert d['context']['state_key']==active_key
                pending[active+'|'+prior.action_key(d['context']['candidate'])]=previous
            elif kind in ('paid_query_reused','new_candidate_closed'):
                assert d['state_key']==active_key
                key=active+'|'+d['action_key'];item={'raw':d['record'],'base':FULL,'hash':previous}
                if key in expected:
                    assert expected[key]['raw']['verdict']==item['raw']['verdict'] and expected[key]['raw']['original_score']==item['raw']['original_score']
                else:expected[key]=item
                receipt_refs[d['record']['receipt_id']]=item;pending.pop(key,None)
            elif kind=='actual_commit':
                reference=receipt_refs[d['record']['selected_receipt_id']];raw=reference['raw'];ref=raw['after_reference']
                if ref['kind']=='new':
                    with (reference['base']/'actual/capsules.bin').open('rb') as f:net=decode_capsule(f,ref['descriptor'])['net']
                else:net=prior.load_after(ref,None)['net']
                c=d['record']['following_cursor'];active=independent_point(net,c);active_key=oldfn(net,c)
    assert set(cache)==set(expected) and set(index['blocked_prior_incomplete_identities'])==set(pending)
    checked=0;PFcosts=0;solver_seconds=0.
    for key,item in expected.items():
        saved=cache[key];raw=item['raw']
        for field in ['candidate','verdict','original_score','attributed_PF_calls','attributed_solver_seconds']:
            assert saved[field]==raw[field],(key,field)
        assert saved['source_event_or_record_sha256']==item['hash']
        if saved['after_reference'] is None:assert raw['after_reference'] is None
        else:
            ref=raw['after_reference'];stored=saved['after_reference']
            if ref['kind']=='new':assert stored=={'kind':'external_capsule','base':str(item['base'].relative_to(R)),'descriptor':ref['descriptor']}
            elif ref['kind'] in ('old','two'):
                base=OLD if ref['kind']=='old' else TWO
                assert stored=={'kind':'external_capsule','base':str(base.relative_to(R)),'descriptor':ref['descriptor']}
            else:assert ref['kind']=='engineering' and stored=={'kind':'legacy_engineering_container','reference':ref}
        assert saved['attributed_PF_calls'] in (0,1) and saved['attributed_solver_seconds']>=0
        PFcosts+=saved['attributed_PF_calls'];solver_seconds+=saved['attributed_solver_seconds'];checked+=1
    root_checked=0
    for world,(point,domain) in roots.items():
        rows=domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
        assert len(rows)==index['all_four_root_cache_counts'][world]
        for row in rows:
            saved=cache[point+'|'+prior.action_key(row)]
            assert all(saved['candidate'][key]==row[key] for key in ['kind','receiver','q','donor_index','donor_bus'])
            root_checked+=1
    assert root_checked==6372 and checked==result['cache_entries'] and events==index['source_events_read']
    put(out/'Independent_Compatible_Paid_Input_Audit.json',{'status':'PASS_ALL_SOURCE_RECEIPTS_CONTEXT_ALIAS_COST_POINTER_AND_ALL6372_ROOT_IDENTITIES',
        'checked_cache_entries':checked,'root_identities':root_checked,'blocked_uncertain_prior_ids':len(pending),
        'unique_indexed_paid_PF_calls':PFcosts,'indexed_paid_solver_seconds':solver_seconds,
        'new_model_PF_derivative_forecast_solve_calls':0,'reader_workflow_seconds':time.perf_counter()-start,
        'scope_rule':'Physically/source-compatible reuse only after current raw-scope/stock/cap/operation legality. Per-policy reused costs are attributed, not free.',
        'limits':'Input closure only, no new planner/LLM/wholeDSE outcome; original terminal partial remains partial.'})
    print(json.dumps({'independent_paid_input_audit':'PASS','cache_entries':checked,'root_identities':root_checked,'new_PF_model_calls':0}))
if __name__=='__main__':main()
