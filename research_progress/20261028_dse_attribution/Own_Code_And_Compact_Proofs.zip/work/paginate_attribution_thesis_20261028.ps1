$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$taskOut = Join-Path $taskRoot 'outputs/thesis_attribution_and_comparators_20261028'
$taskDoc = Join-Path $taskOut 'Hannaan_Thesis_Attribution_And_Comparators.docx'
$taskWord = $null
$taskDocument = $null
try {
    $taskWord = New-Object -ComObject Word.Application
    $taskWord.Visible = $false
    $taskWord.DisplayAlerts = 0
    $taskDocument = $taskWord.Documents.Open($taskDoc, $false, $false)
    $taskDocument.Repaginate()
    $taskBody = $null
    for ($i = 1; $i -le $taskDocument.Paragraphs.Count; $i++) {
        $p = $taskDocument.Paragraphs.Item($i)
        if ($p.Range.Text.Trim() -eq 'Chapter 1 Introduction') {
            $taskBody = $p.Range.Start
            break
        }
    }
    if ($null -eq $taskBody) { throw 'Body anchor missing' }
    $taskMap = @()
    # The thesis uses manually formatted contents and caption lists.
    # Search only the body, never an earlier list occurrence.
    for ($i = 1; $i -le $taskDocument.Paragraphs.Count; $i++) {
        $p = $taskDocument.Paragraphs.Item($i)
        if ($p.Range.Start -ge $taskBody) { break }
        $txt = $p.Range.Text.TrimEnd([char]13, [char]7)
        if ($txt -notmatch "`t[0-9]+$") { continue }
        $label = $txt.Substring(0, $txt.LastIndexOf("`t"))
        $search = $taskDocument.Range($taskBody, $taskDocument.Content.End)
        $search.Find.ClearFormatting()
        $search.Find.Text = $label
        $search.Find.Forward = $true
        $search.Find.Wrap = 0
        $search.Find.MatchWildcards = $false
        if (-not $search.Find.Execute()) { throw "Contents label absent: $label" }
        if ($label -eq 'References') {
            $exactHeading = $null
            for ($j = 1; $j -le $taskDocument.Paragraphs.Count; $j++) {
                $candidate = $taskDocument.Paragraphs.Item($j)
                if ($candidate.Range.Start -ge $taskBody -and $candidate.Range.Text.Trim() -eq 'References') {
                    $exactHeading = $candidate.Range.Duplicate
                    break
                }
            }
            if ($null -eq $exactHeading) { throw 'Exact References heading missing' }
            $search = $exactHeading
        }
        $page = [int]$search.Information(1)
        if ($page -lt 1) { throw "Invalid body page: $label" }
        $physical = [int]$search.Information(3)
        $number = $p.Range.Duplicate
        $number.Start = $p.Range.Start + $txt.LastIndexOf("`t") + 1
        $number.End = $p.Range.Start + $txt.Length
        $number.Text = [string]$page
        $taskMap += [ordered]@{ label=$label; logical_page=$page; physical_page=$physical }
    }
    $taskDocument.Repaginate()
    foreach ($entry in $taskMap) {
        if ($entry.label -eq 'References') { continue }
        $search = $taskDocument.Range($taskBody, $taskDocument.Content.End)
        $search.Find.Text = $entry.label
        $search.Find.Wrap = 0
        if (-not $search.Find.Execute()) { throw 'Label vanished' }
        if ([int]$search.Information(1) -ne $entry.logical_page) { throw 'Pagination changed after index update' }
    }
    $taskDocument.Save()
    $pdf = Join-Path $taskOut 'Integrated_Thesis_QA.pdf'
    $taskDocument.ExportAsFixedFormat($pdf, 17)
    $record = [ordered]@{
        status='PAGINATED_AND_PDF_EXPORTED_AWAITING_VISUAL_QA'
        pages=[int]$taskDocument.ComputeStatistics(2)
        list_entries=$taskMap.Count
        map=$taskMap
    }
    $record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskOut 'Pagination_Record.json') -Encoding UTF8
    Write-Output ([pscustomobject]$record | Select-Object status,pages,list_entries | ConvertTo-Json -Compress)
}
finally {
    if ($null -ne $taskDocument) { $taskDocument.Close(0) }
    if ($null -ne $taskWord) { $taskWord.Quit() }
}

