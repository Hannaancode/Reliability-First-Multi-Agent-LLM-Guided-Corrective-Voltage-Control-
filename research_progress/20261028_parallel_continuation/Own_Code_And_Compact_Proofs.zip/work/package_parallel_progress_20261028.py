"""Allowlisted own code and compact proofs; excludes private raw data and models."""
from pathlib import Path
import datetime,hashlib,json,zipfile
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
R=Path(__file__).resolve().parents[1];O=R/'outputs/parallel_progress_publication_20261028';O.mkdir(exist_ok=False)
code=['check_response_transport_20261028.py','immutable_response_transport_20261028.py','reconstruct_interrupted_frontiers_20261028.py',
 'extend_original_case_registry_20261028.py','check_pending_source_state_20261028.py','original_case_missing_suffix_20261028.py',
 'check_missing_suffix_integration_20261028.py','original_missing_suffix_core_20261028.py','run_original_missing_suffix_local_20261028.py',
 'run_original_missing_suffix_colab_20261028.py','audit_original_missing_suffix_20261028.py','freeze_original_missing_suffix_20261028.py',
 'coordinate_original_missing_suffix_20261028.py','write_thesis_closure_addendum_20261028.py','recover_rag_evaluation_contract_20261028.py',
 'assemble_original118_closed_comparison_20261028.py','record_parallel_progress_20261028.py','package_parallel_progress_20261028.py']
proofs=['outputs/missing_suffix_integration_20261028/Results.json',
 'outputs/original118_analysis_binding_20261028/Prepared_Analysis_Lock.json',
 'outputs/thesis_research_closure_20261028/Contribution_And_Verifier_Source_Record.json',
 'outputs/thesis_research_closure_20261028/Source_Contract_And_Contribution_Addendum.md',
 'outputs/thesis_research_closure_20261028/Insert_Visual_QA.json',
 'outputs/rag_evaluation_contract_recovery_20261028/Recovered_Evaluation_Contract.json',
 'outputs/rag_evaluation_contract_recovery_20261028/Findings_And_Remaining_Contract.md']
for i in (1,3):
 proofs += [f'outputs/original_missing_suffix_preparation_20261028/case_{i:02d}/Frozen_Engineering_Protocol.json',f'outputs/original_missing_suffix_preparation_20261028/case_{i:02d}/Launch_Readiness_Audit.json']
rows=[]
with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for relative in ['work/'+x for x in code]+proofs:
  p=R/relative;raw=p.read_bytes();text=raw.decode('utf-8-sig')
  assert not SECRET_NAME.search(p.name) and not any(s.search(text) for s in SECRET),relative
  z.writestr(relative,raw);rows.append({'path':relative,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(O/'Own_Code_And_Compact_Proofs.zip') as z:
 assert z.testzip() is None
 for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
manifest={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'members':rows,'archive_crc_and_all_member_hashes':'PASS',
 'excluded':'Private adapters/weights, NETs, checkpoints, raw notebook sources and500QAtranscript, credentials, live endpoint payloads. This is not a complete raw backup.',
 'scope':'Source/readiness and documentation snapshot, not a completed performance result.'}
(O/'Artifact_Index.json').write_text(json.dumps(manifest,indent=2)+'\n','utf-8')
snapshot=json.loads((R/'outputs/research_resumption_20261028/Current_Resume.json').read_text('utf-8-sig'))
# Publish status and continuation without account/runtime endpoint fields.
public={'at_utc':snapshot['at_utc'],'all_six_final_goals':'OPEN','priority_order':snapshot['priority_order'],
 'parallel_completed':snapshot['parallel_completed'],'next':snapshot['next'],
 'case_status':[{'case':x['case_index'],'owner_live_at_snapshot':x['actual_matching_owner_live'],'audit_status':x['audit_status']} for x in snapshot['scientific_jobs']],
 'performance':'Pending independent closure; no new benchmark superiority claimed','raw_backup_complete':False}
(O/'Current_Resume.json').write_text(json.dumps(public,indent=2)+'\n','utf-8')
(O/'Tasks.json').write_bytes((R/'outputs/research_tasks_20261014/Tasks.json').read_bytes())
(O/'Thesis_Closure_Tasks.json').write_bytes((R/'outputs/thesis_research_closure_20261028/Tasks.json').read_bytes())
(O/'Results.md').write_text('''# Parallel original controller continuation and thesis evidence

Two fixed-profile T4 continuations were launched for the two interrupted original Reflection-v4 cases after exact saved-state, attempt-history and source gates. They reuse old responses and physical records. One has released its T4 at this snapshot; the other is live. The sole coordinator owns the independent first-new-return readers. Endpoints are not presented as audited results here.

The thesis contribution statement, offline HG-SE distinction and original verifier scope are source-bound and visually reviewed. Final integration into the105-page thesis remains pending. The candidate confirmed the main technical work; documented coauthor review and supervision are retained.

All500 historical RAG printed question/answer/reference records were recovered without inference. The recipe uses an in-corpus QA index. Exact runtime data/index/revisions and the separate99percent factual adjudication contract remain unknown; the baseline NLI study is kept distinct.

The four-case descriptive comparison assembler implements the previously frozen23October metrics and refuses live or partial inputs. All six final goals remain open. No guaranteed winner, equal-cost LLM advantage or external-method superiority follows from this snapshot. The compact archive excludes private raw scientific assets and is not a complete backup.
''','utf-8')
remote=[]
for p in sorted(O.iterdir()):
 if p.is_file():
  raw=p.read_bytes();remote.append({'local':p.relative_to(R).as_posix(),'path':'research_progress/20261028_parallel_continuation/'+p.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
(O/'Publication_Map.json').write_text(json.dumps(remote,indent=2)+'\n','utf-8')
print(json.dumps({'files':len(remote),'members':len(rows),'archive_bytes':(O/'Own_Code_And_Compact_Proofs.zip').stat().st_size}))
