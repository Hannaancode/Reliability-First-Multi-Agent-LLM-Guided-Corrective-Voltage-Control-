"""One isolated, fixed-version framework installation; no scientific retry."""
from pathlib import Path
import json, os, signal, subprocess, sys, time
from public_qa_transfer_20261029 import json_once, read

def main():
    root=Path(__file__).resolve().parent;os.chdir(root);began=time.monotonic();child=None;code=1;failure=None
    with (root/'setup.log').open('xb') as log:
        def run(command):
            nonlocal child
            remaining=1750-(time.monotonic()-began);assert remaining>0
            child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try: result=child.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10);raise
            assert result==0, 'Pinned dependency setup failed'
        try:
            run([sys.executable,'check_public_qa_linux_watchdog_20261029.py'])
            run([sys.executable,'-m','pip','install','--disable-pip-version-check','uv==0.12.23'])
            run([sys.executable,'-m','uv','python','install','3.12.14'])
            run([sys.executable,'-m','uv','venv','--python','3.12.14','env'])
            run([sys.executable,'-m','uv','pip','install','--python','env/bin/python',
                '--extra-index-url','https://download.pytorch.org/whl/cu128','--index-strategy','unsafe-best-match',
                '--constraint','dependency_constraints.txt','torch==2.10.0+cu128','transformers==5.5.0',
                'tokenizers==0.22.2','safetensors==0.7.0','numpy==2.0.2','huggingface_hub==1.11.0'])
            run(['env/bin/python','-c',"import torch,transformers,tokenizers,numpy,importlib.metadata,json; from pathlib import Path; assert torch.cuda.is_available() and 'T4' in torch.cuda.get_device_name(0); assert transformers.__version__=='5.5.0'; Path('environment.json').write_text(json.dumps({'packages':{d.metadata['Name']:d.version for d in importlib.metadata.distributions()},'torch':torch.__version__,'transformers':transformers.__version__,'cuda':torch.version.cuda,'device':torch.cuda.get_device_name(0),'device_total_bytes':torch.cuda.get_device_properties(0).total_memory}))"])
            code=0
        except BaseException as error: failure=type(error).__name__
    json_once(root/'Setup_End.json',{'setup_process_work_ended':True,'exit_code':code,'failure_type':failure,
        'elapsed_seconds':time.monotonic()-began,'last_child_pid':None if child is None else child.pid})
    return code
if __name__=='__main__':sys.exit(main())
