"""Independent saved admission-state diagnosis; no physics/model/solver calls."""
import ast,hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/next_ordinary_query_zero_native_diagnosis_20261019'
OLD=R/'outputs/next_ordinary_query_acquisition_20261019'

def main():
    B.mkdir(exist_ok=False);start=time.perf_counter();p=read(OLD/'Protocol.json');done=read(OLD/'Completion.json');assert done['exit_codes']=={'warm':0,'audit':1}
    for phase in ['warm','audit']:
        ack=read(OLD/(phase+'_End_ACK.json'));assert ack['actual_owned_chain_ended'] and sha(OLD/phase/'Closed_Manifest.json')==ack['closed_manifest_sha256']
        for rel,h in read(OLD/phase/'Closed_Manifest.json')['members'].items():assert sha(OLD/phase/rel)==h
    actual=read(OLD/'warm/Result.json');assert actual['receipt']['message']['record']['actual_measured_receipt'] is None and actual['receipt']['replay'] is None
    assert all(actual['cumulative_costs'][k]==0 for k in ['PF_attempts','PF_returns','PF_exceptions','new_query_PF_attempts','continuous_replay_PF_attempts','new_model_calls','new_optimizer_steps','new_derivative_forecast_linear_solve_calls'])
    events=[json.loads(line) for line in (OLD/'warm/scientific.jsonl').read_bytes().splitlines()];assert [e['event'] for e in events]==['fixed_primary_query_closed']
    assert (OLD/'warm/capsules.bin').stat().st_size==0
    reservations=[json.loads(line) for line in (OLD/'reservations/events.jsonl').read_bytes().splitlines()];assert len(reservations)==1 and reservations[0]['event']=='reserved_exact_identity_before_physics'
    key=actual['receipt']['point_action_key'];assert reservations[0]['data']['point_action_key']==key
    # Exact source-bound admission predicate: failure before any intent/backend.
    source=R/'work/full_joint_suffix_benchmark_20261014.py';tree=ast.parse(source.read_text('utf-8'));cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Evidence');admit=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='admit')
    env={'datetime':datetime,'timezone':timezone};exec(compile(ast.Module(body=[admit],type_ignores=[]),str(source),'exec'),env)
    class EmptyPack:
        def tell(self):return 0
    from types import SimpleNamespace
    # Use original deadline at an instant within that original interval: only
    # demonstrate the pure byte inequality, without reviving the old owner.
    assert p['maximum_storage_bytes']==64*1024**2
    old_condition=(0+64*1024**2 < p['maximum_storage_bytes']);assert old_condition is False
    future_condition=(0+64*1024**2 < 256*1024**2);assert future_condition is True
    put(B/'Independent_Diagnosis.json',{'status':'PASS_SOURCE_BOUND_ZERO_NATIVE_ENTRY_STORAGE_ADMISSION_FAILURE','old_exit_codes':done['exit_codes'],'exact_reserved_key':key,'native_PF_attempts_returns_exceptions':0,
       'solver_exception_observed':False,'old_pf_failed_label':'UNKNOWN_SOFTWARE_ADMISSION_FAILURE_NOT_MEASURED_PHYSICAL_NONCONVERGENCE','old_reservation_events':1,'old_native_intent_events':0,'old_capsule_bytes':0,
       'old_admission_byte_expression':'0+64MiB <64MiB is false','source_sha256':sha(source),'source_admit_AST':ast.dump(admit,include_attributes=False),
       'future_setup_repair':'Separate prospective protocol/output/owner for the unentered primary only, with256MiBpreservation cap and actual admission fixture; unchanged action/solver/verifier/objective/safety. Never restart old owner or alter old bound, data, source, reservation or failed reader.',
       'no_new_execution_permission_from_this_diagnosis_alone':True,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-start})
    manifest(B);print(json.dumps({'diagnosis':'PASS_ZERO_NATIVE_ENTRY','newPF':0}))

if __name__=='__main__':main()
