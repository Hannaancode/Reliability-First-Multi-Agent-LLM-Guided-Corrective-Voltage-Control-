"""Targeted publication path exclusions only; no old suite or scientific execution."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import re

O = Path(__file__).resolve().parent
p = O / 'Prepare_Compact_Publication.py'
old = (O / 'Prepare_Compact_Publication_Before_Versioned_Exclusions.py').read_bytes()
current = p.read_bytes()
assert hashlib.sha256(old).hexdigest() == 'a295e057df4db479e5802b0f2910f4c9d987686a4628e641a9bcd6be871bf92e'
replacements = [
    (b"'isolated_owner_dependencies_20261030'}", b"'isolated_owner_dependencies_20261030','owner_runtime_dependencies_20261030'}"),
    (b'(?:_v2)?', b'(?:_v[0-9]+)?'),
]
expected = old
for before, after in replacements:
    assert expected.count(before) == 1
    expected = expected.replace(before, after)
assert current == expected, 'The only permitted byte changes are the two declared exclusion extensions'
spec = importlib.util.spec_from_file_location('packer_path_exclusion_checks_only', p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
cases = [
    ('outputs/nonlinear500_receding_acquisition_v3_execution_20261030/Result.json', 'Live scientific output directories are prohibited'),
    ('outputs/nonlinear500_receding_acquisition_v30_execution_20261030/Result.json', 'Live scientific output directories are prohibited'),
    ('work/owner_runtime_dependencies_20261030/probe.py', 'Dependency/alias path prohibited'),
    ('work/OWNER_RUNTIME_DEPENDENCIES_20261030/probe.py', 'Dependency/alias path prohibited'),
    ('work/nonlinear500_isolated_owner_runtime_v3_20261030.py', None),
    ('outputs/nonlinear500_receding_acquisition_v3_preparation_20261030/Protocol.json', None),
]
tests = []
for path, wanted in cases:
    error = None
    try:
        m.safe_source(path)
    except ValueError as e:
        error = str(e)
    tests.append({'path': path, 'expected_error': wanted, 'actual_error': error, 'PASS': error == wanted})
a = json.loads((O / 'Publication_Allowlist.json').read_text(encoding='utf-8'))
bad = [e['path'] for e in a['entries'] if any(
    part.lower() in {'owner_runtime_dependencies_20261030', 'isolated_owner_dependencies_20261030'}
    or '_execution_' in part.lower() or part.lower() == 'execution'
    for part in PurePosixPath(e['path']).parts[:-1])]
checks = {'only_two_declared_byte_replacements': current == expected,
          'all_six_targeted_cases_PASS': all(t['PASS'] for t in tests),
          'no_execution_or_owner_runtime_dependency_directory_allowlisted': not bad,
          'no_final_pack_files_created': all(not (O / n).exists() for n in m.FINAL_NAMES)}
assert all(checks.values()), (checks, tests, bad)
record = {'status': 'PASS_TARGETED_PUBLICATION_EXCLUSION_EXTENSION_ONLY',
          'at_utc': datetime.now(timezone.utc).isoformat(),
          'old_packer_sha256': hashlib.sha256(old).hexdigest(),
          'new_packer_sha256': hashlib.sha256(current).hexdigest(),
          'delta': [{'before': x.decode(), 'after': y.decode()} for x, y in replacements],
          'checks': checks, 'tests': tests, 'forbidden_allowlisted_paths': bad,
          'checks_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'old19_test_suite_rerun': False, 'scientific_calls': 0,
          'execution_or_dependency_payloads_read': False,
          'scope': 'Only safe_source path predicates called, including real-path metadata resolution; no scientific directory content read and no selected source methods executed.',
          'original_source_preserved': 'Prepare_Compact_Publication_Before_Versioned_Exclusions.py',
          'authorization': 'Parent explicitly requested numbered-version execution and actual owner-runtime dependency exclusions; all other bytes unchanged.'}
with (O / 'Exclusion_Change_Record.json').open('x', encoding='utf-8') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps({'status': record['status'], 'new_packer_sha256': record['new_packer_sha256'], 'targeted_checks': len(tests), 'forbidden_allowlisted_paths': bad}))
