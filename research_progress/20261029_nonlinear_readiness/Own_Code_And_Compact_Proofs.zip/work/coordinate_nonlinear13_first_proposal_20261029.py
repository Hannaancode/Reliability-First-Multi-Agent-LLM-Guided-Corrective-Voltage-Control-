"""One new proposal owner followed by one saved-only first reader, no retries."""
from pathlib import Path
from datetime import datetime,timezone
import os,json,subprocess,hashlib
R=Path(__file__).resolve().parents[1];P=R/'outputs/nonlinear13_first_proposal_preparation_20261029';O=R/'outputs/nonlinear13_first_proposal_handoff_20261029'
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
        with (O/(name+'.log')).open('x',encoding='utf-8') as log:
            code=subprocess.call([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        put(O/(name+'.End.json'),dict(exit_code=code,at_utc=datetime.now(timezone.utc).isoformat()));assert code==0,'No old-owner or reader retry'
    put(O/'Completion.json',dict(status='FIRST_NUMERICAL_PROPOSAL_AND_SAVED_READER_TERMINAL',at_utc=datetime.now(timezone.utc).isoformat()));print('FIRST_NUMERICAL_PROPOSAL_AND_READER_CLOSED')
if __name__=='__main__':main()
