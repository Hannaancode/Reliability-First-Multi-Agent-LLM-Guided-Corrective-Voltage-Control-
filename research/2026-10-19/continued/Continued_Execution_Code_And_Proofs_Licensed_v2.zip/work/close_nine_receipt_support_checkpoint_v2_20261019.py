"""Close exact saved-policy support evidence; persist next context and costs."""
import hashlib,json,os,pickle,zlib,subprocess
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from save_fixed_three_progress_20261019 import atomic
from equal_operation_benchmark_v2 import process
S=R/'outputs/fixed_nine_preserved_receipts_screen_v3_20261019'
B=R/'outputs/fixed_nine_support_handoff_v2_20261019'
def main():
    B.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat();c=read(S/'owner.claim')
    # The original exec returned exit0 and its closed manifest predates any
    # reused PID. PID equality alone cannot identify an ended owner.
    for pid in (c['actual_pid'],c['parent_pid']):
        query=f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | Select-Object ProcessId,Name,@{{Name='CreatedUtc';Expression={{$_.CreationDate.ToUniversalTime().ToString('o')}}}},CommandLine | ConvertTo-Json -Compress"
        q=subprocess.run(['powershell','-NoProfile','-Command',query],capture_output=True,text=True);assert q.returncode==0
        if q.stdout.strip():
            current=json.loads(q.stdout);created=datetime.fromisoformat(current['CreatedUtc']);closed=datetime.fromtimestamp((S/'Closed_Manifest.json').stat().st_mtime,timezone.utc)
            assert created>closed,'Matching older process remains unclassified; no ended-owner assertion'
            put(B/f'PID_Reuse_{pid}.json',{'new_process':current,'prior_closed_utc':closed.isoformat(),'strictly_new_process_after_original_closure':True})
    d=read(S/'Results.json');leg=read(S/'Leg_1.json');assert d['new_model_PF_optimizer_derivative_forecast_solve_calls']==0 and leg['status']=='UNKNOWN_MissingPaidNumericalContext'
    for rel,h in read(S/'Closed_Manifest.json')['members'].items():assert sha(S/rel)==h
    prev='0'*64;events={}
    for raw in (S/'scientific.jsonl').read_bytes().splitlines():
        e=json.loads(raw);assert e['previous_sha256']==prev;prev=hashlib.sha256(raw).hexdigest();events[e['event']]=events.get(e['event'],0)+1
    assert not any(k in events for k in ('PF_intent','PF_return','PF_exception'))
    reuse={p.name:sum(1 for _ in p.open('rb')) for p in (S/'verified_uses').glob('*.jsonl')};assert reuse['new_four_receipt_uses.jsonl']==4 and reuse['new_three_receipt_uses.jsonl']==3
    ref=leg['frontier_input'];enc=(S/ref['path']).read_bytes();raw=zlib.decompress(enc);assert hashlib.sha256(enc).hexdigest()==ref['encoded_sha256'] and hashlib.sha256(raw).hexdigest()==ref['raw_sha256']
    state=pickle.loads(raw)
    numeric=R/'outputs/second_required_numeric_context_20261019';active=[]
    if (numeric/'actual/owner.claim').exists():
        q=read(numeric/'actual/owner.claim');actual=process(q['actual_pid'])
        if actual:
            assert actual['ParentProcessId']==q['actual_parent_pid'] and 'second_required_numeric_context_20261019.py' in actual['CommandLine']
            active=[{'actual_pid':q['actual_pid'],'parent_pid':q['actual_parent_pid'],'source':'work/second_required_numeric_context_20261019.py','command':actual['CommandLine'],'input_identity':leg['missing_identity'],'scope':'ONE new numeric context/full original menu;0PF/LLM','exec_session':81439}]
    data={'at_utc':at,'status':'CLOSED_SAVED_POLICY_PREFIX_EXACT_NEXT_REQUIRED_NUMERIC_CONTEXT','all_previous_readonly_owners_ended':True,'source_result':str((S/'Results.json').relative_to(R)),'source_manifest_sha256':sha(S/'Closed_Manifest.json'),'journal_last_sha256':prev,'reuse_ledger_records':reuse,'numeric_reused':d['numeric_costs'],'workflow_seconds':d['workflow_seconds'],'nested_verification_and_preservation_seconds':d['actual_CPU_verification_preservation_costs'],'next_identity':leg['missing_identity'],'next_exact_frontier':ref,'next_cursor_remaining_ops':state['cursor']['remaining_original_device_operation_slots'],'full_four_world_gate':'UNKNOWN','new_scientific_calls_in_analysis':0,'four_query_original_lifecycle_gate':'UNKNOWN_LAST_CHILD_EXIT','active_new_numerical_owner':active,'timer':'DELETED_TERMINAL','all6goals':'OPEN','constraints':'All9receipts available; actualuses include4new+3prior+1old2registryreceipt. Unusedseparateengineeringreceipt remains retained. Noactualcommit or newprotectedcompletepolicy/LLM/DSEclaim.'}
    put(B/'Verified_Closed_Support_Checkpoint.json',data)
    (B/'Next_Execution.md').write_text('# Exact continuation\n\nThe unchanged policy reused all four new receipts and stops at the next genuinely missing numerical context. Its source-bound table is being produced once under a new fixed protocol. Require actual source/native-mask/derivative/JX/forecast/all-menu/complete-cost audit and ended-owner evidence before reuse. Keep the prior lifecycle gate UNKNOWN.\n\n1. Finish the exact sole numeric owner and reader; never duplicate/restart.\n2. Verify all original equations and full native menu. Preserve any failure without repeating scientific calls.\n3. Extend only the saved-data policy analysis with this full paid table. Keep zero new PF/model/optimizer calls and preserve next unsupported identity as UNKNOWN.\n4. Any later new physical measurement needs a new exact prospective causal-input/menu/source/custody/preservation/reader/cost protocol; no automatic launch or fixed-policy changes.\n','utf-8')
    current=R/'outputs/remaining_three_fixed_queries_20261019/verified_completion/Current_Resume_20261019.json';v=read(current);v.update(at_utc=at,status=data['status'],latest_closed_evidence=str((B/'Verified_Closed_Support_Checkpoint.json').relative_to(R)),active_analysis=None,active_new_numeric_owner=active,waiting_check={'automation_id':'hiergrid-fixed-receipt-analysis-result-check','status':'DELETED_TERMINAL'},next_steps_in_order=(B/'Next_Execution.md').read_text('utf-8').splitlines()[4:]);atomic(current,v)
    p=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';v=read(p);v.update(at_utc=at,current_task={'status':data['status'],'evidence':str((B/'Verified_Closed_Support_Checkpoint.json').relative_to(R))},active_owned_jobs=active,timers=[],latest_closed_continuation=str(current.relative_to(R)));atomic(p,v)
    p=R/'outputs/research_tasks_20261014/Tasks.json';v=read(p);v['at_utc']=at;v['tasks'][0]['next']='Follow outputs/fixed_nine_support_handoff_20261019/Next_Execution.md; one genuinely missing numerical context, not new physics or a policy win.';v['latest_exact_execution_state']=str(current.relative_to(R));atomic(p,v)
    header=f'LATEST CLOSED SUPPORT AND NEW CONTEXT {at}\n\nAllninepaidreceipts retained; readonlyscreenCLOSED426.1349sec,3contexts4290paidforecasts reused,0newscience. Exactnextcontextae3254ce10a37732dc01af771f52c2eafae49db50f643e434f67b53a0eadcdf5. PreviousanalysisownersENDED/timerDELETED. Newsource second_required_numeric_context_20261019.py only1dS/1LUfactor/1solve118RHS/fullnativeforecasttable,0PF/model; inspectfreshactualowner/reader under outputs/second_required_numeric_context_20261019, exec81439. Read outputs/fixed_nine_support_handoff_20261019/Next_Execution.md and canonicalresume. Newfuturecustody3actualzero-sciencecasesPASS inclpartialJSON/atomicclaim/realexit7; no oldsource/liveedit. FourquerylifecycleUNKNOWNretained, all6goalsOPEN/frozenassets/fullbothDSEcosts preserved.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write('\n\n'+at+' —All-nine saved-policy screenCLOSED426.1349031sec,0newscience,3exactcontextreuses4290paidforecasts,4new+3prior+1earlierengineeringreceiptuses plus1517historicaluses. Next exact required contextae3254... UNKNOWN until paid once and independentlychecked. Timerdeletedatterminal. Futureonlylauncher atomicclaims/partialJSONboundedwait/retainedhandle cases3PASS (normal0,splitJSON0,adverse7); realexit7preservednotconverted0;0scientificcalls and no oldlive/sourceedits. Exact next checkpoint '+str((B/'Verified_Closed_Support_Checkpoint.json').relative_to(R))+'.\n');f.flush();os.fsync(f.fileno())
    manifest(B);print(json.dumps({'closed_support_verified':True,'new_next_identity':leg['missing_identity'],'timer':'DELETED','active_numeric':active}))
if __name__=='__main__':main()
