"""Additive pending two-bus actuation; it neither solves nor commits a network."""
import copy
import math

Q_GRID=(25.,50.,75.,100.,125.,150.,200.,250.,300.)

def prepare_equal_reallocation(current, cursor, *, donor_index, receiver_bus, q_mvar, add_positive):
    """Only source-owned added support; lifetime additions are never refunded.

    A returned network is UNEXECUTED. Its old result tables are stale and must
    not enter a model observation, a paid receipt or a committed cursor.
    Future actual solver/verification/preservation/commit gates are external.
    """
    if not bool(current.converged):raise ValueError('Need an actually solved current state')
    if type(donor_index) is not int or type(receiver_bus) is not int:raise ValueError('Exact integer identifiers required')
    q=float(q_mvar)
    if not math.isfinite(q) or q not in Q_GRID:raise ValueError('Original discrete Q grid required')
    candidates=[r for r in cursor['owned_bank_rows'] if r['index']==donor_index]
    if len(candidates)!=1:raise ValueError('Never withdraw from a base or unowned bank')
    owned=candidates[0];row=current.shunt.loc[donor_index];donor=int(row.bus)
    if receiver_bus not in current.bus.index or receiver_bus==donor:raise ValueError('Two distinct existing buses required')
    scope=cursor.get('raw_current_receiver_scope')
    if not isinstance(scope,list) or any(type(b) is not int for b in scope) or len(scope)!=len(set(scope)) or receiver_bus not in scope:
        raise ValueError('Recipient must be in the externally bound raw current scope')
    if int(owned['bus'])!=donor or float(row.q_mvar)!=owned['q_mvar'] or str(row['name'])!=owned['name']:
        raise ValueError('Owned row has changed since measured receipt')
    if float(row.q_mvar)>-q or float(row.p_mw)!=0 or float(row.step)!=1 or not bool(row.in_service):
        raise ValueError('Cannot withdraw more source-owned capacitive support than exists')
    if bool(row.get('step_dependency_table',False)):raise ValueError('Unsupported nonlinear bank characteristic')
    if cursor['withdrawals_refund_positive_addition_cap'] is not False:raise ValueError('Withdrawal never refunds cap')
    history=cursor['positive_addition_lifetime_MVAr']
    if any(not math.isfinite(float(v)) or not 0<=float(v)<=450 for v in history.values()):raise ValueError('Invalid original lifetime cap ledger')
    if float(history.get(str(receiver_bus),0))+q>450:raise ValueError('Original cumulative positive cap exceeded')
    if cursor['remaining_original_device_operation_slots']<2:raise ValueError('Charge both device operations')
    before=current.shunt.copy(deep=True);target=copy.deepcopy(current)
    target.shunt.at[donor_index,'q_mvar']=float(row.q_mvar)+q
    add_positive(target,{'add_shunts_q_mvar':{str(receiver_bus):q}})
    introduced=[int(i) for i in target.shunt.index if i not in before.index]
    if len(introduced)!=1:raise ValueError('Exactly one new owned receiving bank required')
    recipient=target.shunt.loc[introduced[0]]
    if int(recipient.bus)!=receiver_bus or float(recipient.q_mvar)!=-q or float(recipient.p_mw)!=0 or float(recipient.step)!=1:
        raise ValueError('Receiving bank does not match frozen positive actuator')
    expected=before.copy(deep=True);expected.at[donor_index,'q_mvar']=float(row.q_mvar)+q
    if not target.shunt.loc[before.index].equals(expected):raise ValueError('Another installed bank changed')
    if not current.shunt.equals(before):raise ValueError('Original current state was mutated')
    target.converged=False
    return {'candidate_net':target,'pending_action':{'withdraw_owned_bank_index':donor_index,'donor_bus':donor,
        'receiver_bus':receiver_bus,'withdraw_MVAr':q,'add_MVAr':q,'new_bank_index':introduced[0]},
        'device_operations_to_charge':2,'pending_receiver_lifetime_additions_MVAr':float(history.get(str(receiver_bus),0))+q,
        'donor_lifetime_additions_unchanged':float(history[str(donor)]),
        'current_cursor_is_not_updated':True,'post_action_bus_fields':None,
        'status':'UNEXECUTED_CANDIDATE_WITH_STALE_RESULT_TABLES',
        'future_execution_or_commit_authorized':False,'switchability_assumption':'DISCRETE25_MVAR_RESEARCH_BLOCKS_NOT_FIELD_HARDWARE_CERTIFICATION'}
