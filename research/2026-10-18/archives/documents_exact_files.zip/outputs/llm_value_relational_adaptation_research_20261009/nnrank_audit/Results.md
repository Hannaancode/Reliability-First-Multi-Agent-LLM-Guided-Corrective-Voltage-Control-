Both derivative variants and every declared action/unknown/failure remain retained. This is current-only affine development ranking, not physical rollout, learned contribution or D-SE superiority. No automatic training follows.

{
  "K4": {
    "old_admittance_derivative": {
      "recorded_best_included": 175,
      "oracle_states": 176,
      "equal_world_inclusion": 0.9949494949494949,
      "all23_worlds": {
        "0192b760cb410512b8fc5a51b39b2c0c715897d680c59794343af7598a39c3c1": {
          "all_inputs": 11,
          "oracle_states": 9,
          "included": 9,
          "rate": 1.0
        },
        "08938f18867ba469d32a4a874837b8a20bd00e9125f4dc4105685313914eff8e": {
          "all_inputs": 19,
          "oracle_states": 0,
          "included": 0,
          "rate": null
        },
        "0ac875f9bf14b77d98516a09c8a2cd74959d0b8a7ecd174ba14a03dcbda0c1ff": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "0c5e587de313667efa553cd43d237fc293c86a50e4245effe934f4050194201c": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "0c903292489a697135b890338352cd533f51bc652a7f2cd3551af227c7438f39": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "14421bdf768a64b608e33e03e5aed8ebf057795860a94ccb9bd65bef2a3a6818": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "22fed8a2b9ea7450bc09c6ba79d16a8541496abfe920e077c50c86551d379771": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "269f321fe1bf6bed65835ea0cf1370ca7342dccc391a5306fd0d2bdb8b0902ee": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "35bd1a049f1e7526ae1ff369ba6dc0a45d2e85896ff4cfbe5343aa349c825d7f": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "395b6bc3f42016606d171cd3a3cd107458f5fedb9c9805801eae853381597a7d": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "3ed6bbe7c3475802628729e5d79c871f527656385ad33663456393a0852f8ad1": {
          "all_inputs": 7,
          "oracle_states": 5,
          "included": 5,
          "rate": 1.0
        },
        "4371fc97643f5c59e61b05d451c2c3227a3fc1c7b94f312412d9ec339da034d7": {
          "all_inputs": 15,
          "oracle_states": 13,
          "included": 13,
          "rate": 1.0
        },
        "45252e1eb470d9ca19f189e3dddd36c61bfe50dcecd8ec43f2ba67af3968f64f": {
          "all_inputs": 11,
          "oracle_states": 9,
          "included": 8,
          "rate": 0.8888888888888888
        },
        "574e84c9bdfe2ab404f954e28b4fde693c84a07abd1a6a8f8f7e6d6ea2ebb8e2": {
          "all_inputs": 15,
          "oracle_states": 13,
          "included": 13,
          "rate": 1.0
        },
        "63ebd10fc1fc4d601d33a14a73ba0342580bfd1ed15ed78d4acdc359022eb667": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "6d69f2198f8a4178ccaec2f359623c22f0441e169e780b85bee4b912482e0b3c": {
          "all_inputs": 11,
          "oracle_states": 9,
          "included": 9,
          "rate": 1.0
        },
        "71c324d3a3f4f278ece90dfe1d98ec64904d53351b7e499ca6b24453f015e334": {
          "all_inputs": 13,
          "oracle_states": 11,
          "included": 11,
          "rate": 1.0
        },
        "74844d46612bbac0d3c61aedee7fb674851635defe038271247e90e6ce210833": {
          "all_inputs": 23,
          "oracle_states": 21,
          "included": 21,
          "rate": 1.0
        },
        "7b819c5af188ec8003c322721aa0f3d26389e7862b2af9e6fbf3ff8f2693c3e4": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "8482535482baae9fad33776a3b81d2a88c4251444a9c2621e8b0e11340483694": {
          "all_inputs": 17,
          "oracle_states": 15,
          "included": 15,
          "rate": 1.0
        },
        "885a992742ea79fecb3949a14e3fa229ca7398cc7e8dbc4c383b89dff2086dbe": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "98d45437e1361f9fc57e9f1d949ae68f92f372a5e453df859ac7164cfa526268": {
          "all_inputs": 17,
          "oracle_states": 15,
          "included": 15,
          "rate": 1.0
        },
        "99b23cc444e17e8286b3a19641c222891e7dd8c548b102f85487dab2df6d5dc9": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        }
      },
      "shortlist_totals": {
        "known_accepted": 197,
        "known_rejected": 0,
        "unknown_unmeasured": 18,
        "unavailable_slots": 741
      }
    },
    "candidate_admittance_derivative": {
      "recorded_best_included": 176,
      "oracle_states": 176,
      "equal_world_inclusion": 1.0,
      "all23_worlds": {
        "0192b760cb410512b8fc5a51b39b2c0c715897d680c59794343af7598a39c3c1": {
          "all_inputs": 11,
          "oracle_states": 9,
          "included": 9,
          "rate": 1.0
        },
        "08938f18867ba469d32a4a874837b8a20bd00e9125f4dc4105685313914eff8e": {
          "all_inputs": 19,
          "oracle_states": 0,
          "included": 0,
          "rate": null
        },
        "0ac875f9bf14b77d98516a09c8a2cd74959d0b8a7ecd174ba14a03dcbda0c1ff": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "0c5e587de313667efa553cd43d237fc293c86a50e4245effe934f4050194201c": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "0c903292489a697135b890338352cd533f51bc652a7f2cd3551af227c7438f39": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "14421bdf768a64b608e33e03e5aed8ebf057795860a94ccb9bd65bef2a3a6818": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "22fed8a2b9ea7450bc09c6ba79d16a8541496abfe920e077c50c86551d379771": {
          "all_inputs": 9,
          "oracle_states": 7,
          "included": 7,
          "rate": 1.0
        },
        "269f321fe1bf6bed65835ea0cf1370ca7342dccc391a5306fd0d2bdb8b0902ee": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "35bd1a049f1e7526ae1ff369ba6dc0a45d2e85896ff4cfbe5343aa349c825d7f": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "395b6bc3f42016606d171cd3a3cd107458f5fedb9c9805801eae853381597a7d": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "3ed6bbe7c3475802628729e5d79c871f527656385ad33663456393a0852f8ad1": {
          "all_inputs": 7,
          "oracle_states": 5,
          "included": 5,
          "rate": 1.0
        },
        "4371fc97643f5c59e61b05d451c2c3227a3fc1c7b94f312412d9ec339da034d7": {
          "all_inputs": 15,
          "oracle_states": 13,
          "included": 13,
          "rate": 1.0
        },
        "45252e1eb470d9ca19f189e3dddd36c61bfe50dcecd8ec43f2ba67af3968f64f": {
          "all_inputs": 11,
          "oracle_states": 9,
          "included": 9,
          "rate": 1.0
        },
        "574e84c9bdfe2ab404f954e28b4fde693c84a07abd1a6a8f8f7e6d6ea2ebb8e2": {
          "all_inputs": 15,
          "oracle_states": 13,
          "included": 13,
          "rate": 1.0
        },
        "63ebd10fc1fc4d601d33a14a73ba0342580bfd1ed15ed78d4acdc359022eb667": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "6d69f2198f8a4178ccaec2f359623c22f0441e169e780b85bee4b912482e0b3c": {
          "all_inputs": 11,
          "oracle_states": 9,
          "included": 9,
          "rate": 1.0
        },
        "71c324d3a3f4f278ece90dfe1d98ec64904d53351b7e499ca6b24453f015e334": {
          "all_inputs": 13,
          "oracle_states": 11,
          "included": 11,
          "rate": 1.0
        },
        "74844d46612bbac0d3c61aedee7fb674851635defe038271247e90e6ce210833": {
          "all_inputs": 23,
          "oracle_states": 21,
          "included": 21,
          "rate": 1.0
        },
        "7b819c5af188ec8003c322721aa0f3d26389e7862b2af9e6fbf3ff8f2693c3e4": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "8482535482baae9fad33776a3b81d2a88c4251444a9c2621e8b0e11340483694": {
          "all_inputs": 17,
          "oracle_states": 15,
          "included": 15,
          "rate": 1.0
        },
        "885a992742ea79fecb3949a14e3fa229ca7398cc7e8dbc4c383b89dff2086dbe": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        },
        "98d45437e1361f9fc57e9f1d949ae68f92f372a5e453df859ac7164cfa526268": {
          "all_inputs": 17,
          "oracle_states": 15,
          "included": 15,
          "rate": 1.0
        },
        "99b23cc444e17e8286b3a19641c222891e7dd8c548b102f85487dab2df6d5dc9": {
          "all_inputs": 5,
          "oracle_states": 3,
          "included": 3,
          "rate": 1.0
        }
      },
      "shortlist_totals": {
        "known_accepted": 198,
        "known_rejected": 0,
        "unknown_unmeasured": 18,
        "unavailable_slots": 740
      }
    }
  },
  "preference_relations": {
    "old_admittance_derivative": {
      "counts": {
        "unknown": 11863,
        "aligned": 18,
        "reversed": 3
      },
      "reversed_coverage": {
        "states": 3,
        "worlds": 3,
        "families": [
          "N1_tieline",
          "combined"
        ]
      }
    },
    "candidate_admittance_derivative": {
      "counts": {
        "unknown": 11862,
        "reversed": 4,
        "score_tied": 7,
        "aligned": 11
      },
      "reversed_coverage": {
        "states": 4,
        "worlds": 4,
        "families": [
          "N1_tieline",
          "combined"
        ]
      }
    }
  },
  "unknown_counts": {
    "unknown_affine_forecast": 76571,
    "finite_linear_forecast": 431
  }
}
