# What the actual receipts permit us to test

10 October2026. This continues the critical review with a complete, independently checked inventory of saved evidence. No new model, optimizer, physics, controller, forecast, derivative, linear-solve or cloud call occurred. Original science, adverse results, frozen assets and the literal D-SE comparator remain unchanged.

## Available information

All31 fixed historical worlds and62 branch identities are retained. New outcome/receipt coverage analysis uses only23 OPT worlds/46 branches; held-world outcomes receive no new performance analysis. Of those46 branches,44 retain ordered search ledgers and two reused branches do not. The complete historical dataset still retains four missing ledgers overall; these are not newly recovered by this inventory.

The OPT sources contain209 search-context occurrences and35,208 candidate-receipt occurrences. Exact identity deduplication gives30,510 measured state/action receipts, including120 pre-PF cap rejections. Actual source order is available; all209 recorded failed-signature histories are empty. This does not mean a deployed controller can omit history for all future states. The receipt contains the real verifier result and global BEFORE/AFTER metrics. The original data-generation and physics costs remain paid, even when a local replay returns an already saved receipt.

There are216 exact committed transitions with full recorded next-bus vectors and corresponding saved successor observation snapshots. These are linked by original before-state hash, actual committed action and after-state hash—not guessed by matching global voltage metrics. Of the30,510 recorded candidate queries,198 have one of those exact committed successors;30,312 do not. The other18 committed edges originate in states without a saved candidate ledger. There are23 exact before-states with more than one committed alternative. This is the existing DFF/DFF-ALT coverage, not a new positive horizon result. The stopped branch-selector target gate stays failed.

Source-order histories can be reconstructed as receipt prefixes. Their timestamps and per-candidate solve counts/times cannot. The journals have event indices and scientific identities, without timestamps; candidate records have no timing fields. Do not assign average time to each receipt and label it measured latency.

## Timing is partly known, at a different level

The original guarded collection does record2348.751694seconds inside its runpp measurement wrapper for44,742 new controller PF attempts, including64 exceptions. Their aggregate average is0.052495456seconds per attempt. This is an actual aggregate instrumented cost, not a measurement of each verify_action query: a query may involve several PF calls, cheap prechecks or exceptions. Branch wall time, observation-capture time and full replay costs are separately retained. Reused old controller costs remain separate from new measurement/replay costs.

Thus the earlier blanket concern that no physical timing exists should be narrowed: aggregate physical timing exists; per-query timing does not. Neither this average nor the previous model's full-context response timing predicts an unimplemented acquisition actor's cost. A changed input/role needs its own actual timing before a deployment-efficiency claim. Numerical preprocessing, teacher collection, training, verification, failure, transfer and preservation cannot be omitted from the accounting.

## A useful next implementation, before any performance trial

Implement a **saved-receipt replay interface** as software only. Its purpose is to verify causal information boundaries for a possible paid-query method, not to simulate a new physical result or promise better outcomes.

The session starts from one exact current observation, its current accumulated support and originalQgrid. It exposes raw common AND zone action scope and the unchanged450MVAr cap. World, family, branch, scenario IDs, all future query receipts, full target tables, terminal outcomes and held labels stay in a separate administrator. Current coordinate IDs needed to identify actual devices remain legitimate physical inputs.

The actor can issue a typed(bus,Qindex) query, abstain, or nominate a previously queried action for diagnostic eligibility. Each query is checked against the original scope/Q/cap. A saved known receipt is returned only after that query. An unmeasured action returns explicit UNKNOWN; unknown convergence is never turned into failure or success. Repeated queries must have an explicit cache/cost policy shared with controls. Every request, return, invalid request, missing outcome and cache hit is journaled. Query counts are known; new PF count and latency remain UNKNOWN in this offline interface. A known rejected or unknown action cannot be labelled an eligible saved commitment. No action is applied to a network by this software.

A successor can be exposed only for an exact, already recorded committed edge. Otherwise, advancing the physical state is unsupported. No guessed next vector or alternative-action episode reward is generated. Returning an offline receipt is not a free solver query in a future comparison. Original collection costs remain attached as preparation costs; actual future calls need their own incremental ledgers.

Necessary software checks should use actual fixed saved cases: no receipts before the first query; unchanged actor view when unqueried target values or administrative IDs are altered; exact receipt equality after the corresponding query; strict schema/scope/cap rejection; rejection of a saved unsafe/unknown commitment; proper missing-receipt and missing-successor handling; held-group isolation. These are information and correctness checks, not performance tests or100% confidence in a scientific win.

This dictionary-level software view is not yet a language prompt. The old raw-current text is too long, and a history can grow beyond a model's context. A future fixed actor representation must declare which current/process/receipt fields it retains or omits, justify those omissions and supply identical information to a numerical selector. Stronger full-table/graph/physical controls remain. Do not edit the stopped1.5B prompt or strip its fences retrospectively.

## What a prospective experiment would still need

The materially different hypothesis is an online model selecting useful physical evidence, then responding to paid feedback. An existing immediate exact argmax cannot be beaten on its same evaluated set. Potential benefits are instead a measured cost/outcome trade-off or a genuinely better later trajectory, with the original D-SE and both branches reported individually. Neither benefit is established by this interface or its saved-label oracle.

Before model training, freeze one scientific objective, causal process summary, finite query/commit/abstention policy, budget, seed and final checkpoint. Do not use hindsight knowledge of which unseen query is best as an online stopping criterion. Query order, free cached receipts, a smaller comparison budget and the common voltage guard cannot substitute for learned value. Require deterministic acquisition rules and a strong trained numerical selector with the same information, query access and accounting, plus an architecture/pretraining control for the eventual model claim.

A later actual physical study needs prospectively selected genuinely unexecuted identities, per-query attempt/return/exception/cost instrumentation and full state/ownership/preservation gates. It must not repeat an old scientific call to fill missing timing, regenerate locked assets or silently extend a stopped study. If no valid new measurement protocol or meaningful cost/quality hypothesis can be justified, stop the proposed campaign. A complete alternative-action horizon study also needs measured protected continuations; this file does not authorize inventing their rewards.

No new training or physical campaign is launch-ready. Novelty,99%winning confidence, universal failure and superiority remain unproved. The overall objective remains active: fresh matched protected trajectories, full D-SE/model/numerical/training/preparation/failure costs, strong controls, continuous independent replay and genuinely unused confirmation are still required.

## Evidence and actual new work

`actual_query_and_continuation_receipt_inventory_v3/summary.json` records17.6608seconds of saved-data inventory; the separate reader records5.0027seconds. New scientific calls are zero. The inventory ZIP has10 unique members/1,820,768bytes and passes CRC/every-member hashes; the reader ZIP has four members/2962bytes and passes. Nine local frozen-asset checks passed. Two earlier inventory software errors occurred before the branch-analysis loop—parent-manifest self-membership and an incorrect defaultdict factory. Their original source/claims/declarations and zero-science failures are retained; the additive repair did not rerun physics or models. The reader validates all209 ordered contexts/35,208 receipt hashes and216 real action-linked successors, preserving missing evidence.
