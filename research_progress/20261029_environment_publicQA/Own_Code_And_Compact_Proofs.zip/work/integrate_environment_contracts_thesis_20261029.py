"""Integrate the checked experimental contracts without changing earlier evidence."""
from pathlib import Path
from copy import deepcopy
import json,hashlib
from docx import Document
from docx.shared import Pt,Mm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_environment_contracts_20261029'
BASE=R/'outputs/thesis_dse_and_public_diagnosis_20261028/Hannaan_Thesis_DSE_And_Public_Diagnosis.docx'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists()
    evidence=R/'outputs/environment_contracts_20261029/Environment_Contracts.json'
    check=json.loads((evidence.parent/'Source_And_Arithmetic_Check.json').read_text('utf-8'))
    assert check['status'].startswith('PASS') and check['matrix_sha256']==sha(evidence)
    d=Document(BASE)
    anchor=next(p._p for p in d.paragraphs if p.text=='Chapter 6 Multi-agent voltage control and physical verification')
    def para(text,style='Normal'):
        p=d.add_paragraph(text,style);anchor.addprevious(p._p)
        p.paragraph_format.space_after=Pt(6);p.paragraph_format.widow_control=True
        for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(12 if style=='Normal' else 11 if style=='Caption' else 14)
        return p
    para('The demonstrations in this chapter use a different intervention from the federation controller. The reported IEEE 14-bus and 118-bus examples reduce demand by 10%, whereas the original federation experiments add reactive shunts under a fixed controller. Their quoted initial minimum voltages already exceed 0.95 p.u. They therefore demonstrate a change in voltage margin, rather than removal of the severe undervoltage counts studied later. Section 7.16 records the separate plant, action, solver and stopping contracts, including the unresolved binding between the demonstration figures and the supplied solver source.')
    anchor=next(p._p for p in d.paragraphs if p.text=='Chapter 7 Experimental results and critical analysis')
    para('The exact original reactive menu is 25, 50, 75, 100, 125, 150, 200, 250 and 300 Mvar. It is not a uniformly spaced 25-Mvar grid throughout this range. The 450-Mvar rescue limit is applied per bus to additions named llm_shunt; it is not a total system budget or a limit on every pre-existing shunt. The original initial-state and action power-flow functions also differ: their iteration limits are 50 and 80, respectively. These distinctions are retained in the source inventory and in any reuse of previously paid results.')
    anchor=next(p._p for p in d.paragraphs if p.text=='Chapter 8 Cybersecurity scope existing stress tests and evaluation design')
    para('7.16 Experimental environments and the meaning of a fair comparison','Heading 2')
    para('A shared bus count does not establish a shared control problem. A meaningful comparison must identify the physical initial state, permitted equipment changes, information available to each controller, numerical transition, protection rules and stopping condition. Table 7.11 separates the experiments used in this thesis. It also distinguishes complete cohort results from individual demonstrations and integration checks. All outcomes remain attached to their original scope; a success in one row does not replace an adverse result in another.')
    caption='Table 7.11 Experimental environments and comparison scope'
    cp=para(caption,'Caption');cp.paragraph_format.keep_with_next=True
    headers=['Environment','Permitted intervention','Evaluated scope']
    rows=[['RAG IEEE14 and IEEE118','Reported demand multiplier 0.9; historical guard overrides unknown','Manuscript margin demonstrations; exact execution binding unresolved'],
          ['Federation118 original','Positive added shunts; original discrete menu and per-bus cap','Four inspected severe roots; original25-operation controller'],
          ['Federation118 GraphAgent','Generator/slack voltage and existing binary shunts','Same four roots; source-native136-operation horizon'],
          ['Public13 published and NUM','Bidirectional Q at three native sgen devices; step cap0.3','All500 common roots;100-round horizon; different information/guards'],
          ['MAPDN322 TPA and numerical','Signed absolute Q at38PV inverters; native capability bounds','One completed action on one ordered identity; full cohort unexecuted']]
    table=d.add_table(rows=1,cols=3);table.autofit=False;widths=[36,55,55]
    for col,w in zip(table.columns,widths):col.width=Mm(w)
    for c,t in zip(table.rows[0].cells,headers):c.text=t
    for row in rows:
        for c,t in zip(table.add_row().cells,row):c.text=t
    borders=OxmlElement('w:tblBorders')
    for side in ('top','left','bottom','right','insideH','insideV'):
        e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    table._tbl.tblPr.append(borders)
    for i,row in enumerate(table.rows):
        pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if i==0:pr.append(OxmlElement('w:tblHeader'))
        for cell,w in zip(row.cells,widths):
            cell.width=Mm(w)
            for p in cell.paragraphs:
                p.paragraph_format.line_spacing=1;p.paragraph_format.space_after=Pt(4)
                for rr in p.runs:rr.font.name='Times New Roman';rr.font.size=Pt(10.5);rr.bold=i==0
    anchor.addprevious(table._tbl)
    previous=next(p for p in d.paragraphs if p.text.startswith('Table 7.10 ') and '\t' in p.text)
    e=deepcopy(previous._p);q=Paragraph(e,previous._parent);q.text=caption+'\t0';previous._p.addnext(e)
    para('7.16.1 RAG demonstrations and the supplied tool implementation','Heading 3')
    para('The RAG manuscript describes balanced IEEE 14-bus and 118-bus demonstrations with a 10% reduction in demand. Its IEEE 14-bus caption reports a minimum voltage increase from 0.982 to 0.986 p.u., a difference of 0.004 p.u. The body instead describes a margin increase of approximately 0.04 p.u. That discrepancy is retained as an unresolved manuscript inconsistency. The IEEE 118-bus example reports 0.966 to 0.971 p.u. These minima imply no initial voltage below 0.95 p.u. in the described states. They cannot be interpreted as the severe federation cases with 55–58 undervoltage buses.')
    para('The supplied pf_assist.py provides useful implementation evidence, but its presence does not prove that a particular saved figure used that exact revision. Its default request selects dc_ac. The implementation first attempts a DC initialization and then follows a bounded sequence of Newton–Raphson and fast-decoupled AC attempts, with different initialization methods and iteration limits. Its final fallback uses a different tolerance. Consequently, the manuscript description of a Newton–Raphson solver is insufficient to reconstruct the actual attempted sequence or its cost.')
    para('The supplied request enables an internal guard by default. The configured voltage limits are 0.95 and 1.061 p.u.; the request passes these limits to the guard. Default guard settings include up to12 loops, 15-Mvar shunt steps, a150-Mvar cap parameter, a1.03-p.u. slack target and a500-Mvar generator-Q widening parameter. The source also supports outages, taps, shunts and dispatch edits. These options describe the implementation, not confirmed settings for the historical plots. The exact figure request, runtime revision, network snapshots, guard overrides and complete solve sequence remain unbound. No additional intervention is assumed to have occurred merely because its code exists.')
    para('7.16.2 The original and external federation control roles','Heading 3')
    para('The four recent federation roots apply load scaling of1.5 and the registered outages of lines35,36,84 and127. Original DFF and HG-VF use the same four hashed inputs and retain the original25-operation budget, discrete positive shunt actions and native1.06-p.u. guard. Reporting still counts UV below0.95 and OV above1.05. A native accepted state can therefore contain a strict reporting violation. The source and paid-result records preserve the distinction between the50-iteration initial solver and the80-iteration action solver.')
    para('GraphAgent starts from those same physical roots, but controls generator/slack voltage and existing binary shunts with a native136-operation horizon. Its port uses an explicit80-iteration Newton–Raphson transition. It is an external author comparison algorithm, not the publication’s trained DQN. All four native episodes ended in solver nonconvergence, leaving their final UV and OV unknown. The original controllers retain converged endpoints with remaining violations. This comparison documents behaviour on common starts, while different equipment permissions, information, horizons and backend adaptation prevent an equal-resource or general learning-superiority claim.')
    para('7.16.3 The public 13-bus benchmark','Heading 3')
    para('The public 13-bus study uses all500 common initial networks and three controllable inverter-Q entries at buses2,7 and9. Published policies update the preceding action using a float32-clipped increment of magnitude0.3. The source transition is BFSW with DC initialization. The source step_Preward stops when only the three controlled-bus voltages satisfy the strict open interval0.95<VM<1.05, or when the100-round horizon is exhausted. The shared reported endpoint instead requires all13 buses within the closed interval0.95≤VM≤1.05. These are different predicates and are evaluated separately.')
    para('The numerical controller uses the same plant, actuators, starts and horizon, but obtains full-grid voltages and current admittance information. The published actors each use one local voltage. The numerical method also applies a distinct normal-bus and count-regression guard and stops after its first rejected action. Common-guard replay adapters remain descriptive sensitivity analyses; they do not replace the original published methods. The adverse264-versus363 whole-band comparison therefore remains visible, with information and protection differences disclosed. The original federation language parser is not directly compatible with the sub-Mvar, bidirectional inverter role, so these numerical scores are not scores for the original paper model.')
    para('7.16.4 The single 322-bus engineering comparison','Heading 3')
    para('The MAPDN example uses the second ordered author identity on20January2013, with38PV inverters and an initial108UV/0OV. Both actions use native signed fractions between−0.8 and0.8 multiplied by the inverter reactive capability. Capability depends on present active power and an apparent-power bound derived from1.2 times the native all-pool column maximum. The transition retains the native default pp.runpp call on the documented compatibility runtime. This must not be silently equated with the explicit solver contracts of the other studies.')
    para('One measured TPA action leaves77UV/0OV; one current-Jacobian numerical action leaves0UV/0OV. The numerical method has the full current admittance and operating point, whereas TPA uses distributed current, historical and seasonal inputs. The native480-step episode and full120-identity schedule were not completed. The first ordered identity remains partial after a runtime failure, and its costs remain part of the record. This is an independently checked one-step engineering result with unequal information, not a full benchmark or an LLM contribution. The seasonal and all-pool preprocessing also prevents an automatic claim of strictly causal unused confirmation.')
    para('7.16.5 Evidence boundaries for later comparisons','Heading 3')
    para('The environment inventory binds21 saved source or result files by hash and records exact functions and line locations for Python sources. A separate saved-only check verifies18 source, constant and arithmetic conditions. This check makes no new power-flow, model, derivative, training or GPU calls. It establishes the documented contract, not new controller performance. The machine-readable inventory and its check accompany Table7.11 in the evidence index.')
    para('The four severe roots, the500-case public cohort and the single322-bus identity have been inspected during development. They remain useful for replication, diagnosis and transparent comparison, but cannot become untouched confirmation after their outcomes have informed design. A future matched study must separately freeze its cohort, permitted inputs, actuator mapping, stopping rules, protection, costs and analysis before outcomes. Full performance claims must retain failed and unknown cases and both branches of any retrospective selection system.')
    O.mkdir();out=O/'Hannaan_Thesis_Environment_Contracts.docx';d.save(out)
    (O/'Integration_Record.json').write_text(json.dumps({'status':'CREATED_AWAITING_RENDER_AND_VISUAL_QA','base':str(BASE.relative_to(R)),'base_sha256':sha(BASE),'docx_sha256_before_pagination':sha(out),'sources':[str(evidence.relative_to(R)),str((evidence.parent/'Source_And_Arithmetic_Check.json').relative_to(R))],'new_sections':['7.16'],'new_table':'7.11','tables':len(d.tables),'new_science':0},indent=2)+'\n','utf-8')
    print(json.dumps({'docx':str(out),'tables':len(d.tables),'new_science':0}))
if __name__=='__main__':main()
