"""Describe every audited first-menu query; never turn prefixes into episodes."""
import copy,csv,json,pickle,sys
from collections import Counter
from pathlib import Path
from reflection118_chronological_core_20261022 import *
E=R/'outputs/r118_first_round_missing_only_execution_20261022';A=R/'outputs/r118_first_round_missing_only_independent_20261022';O=R/'outputs/r118_first_round_missing_only_report_v2_20261022'
def main():
    assert read(R/'outputs/r118_first_round_missing_only_handoff_20261022/Completion.json')['status']=='PRIMARY_AND_FIRST_NEW_RETURN_READER_ENDED'
    audit=read(A/'Independent_Audit.json');assert audit['status'].startswith('PASS_PRESERVED_NEW_FIRST_MENU')
    assert sha(__file__)==read(R/'outputs/r118_remaining_native80_contracts_preparation_20261022/Analysis_Lock_V2.json')['sha256']
    O.mkdir(exist_ok=False)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    from frozen_physics_loader import load_stack
    _,runner,_=load_stack();native=pp.runpp
    result=read(E/'Result.json');decl=read(R/'outputs/r118_all4_first_round_attempt_coverage_20261022/All2034_Classifications_With_Attempt_Capsules.json')['rows']
    C=R/'outputs/r118_remaining_native80_contracts_execution_20261022'
    assert read(R/'outputs/r118_remaining_native80_contracts_handoff_20261022/Completion.json')['status']=='PRIMARY_AND_FIRST_NEW_RETURN_READER_ENDED'
    ca=read(R/'outputs/r118_remaining_native80_contracts_independent_20261022/Independent_Audit.json')
    cr=read(C/'Results.json');cp=read(R/'outputs/r118_remaining_native80_contracts_preparation_20261022/Protocol.json')
    assert ca['first_independent_PF_replays']==3 and ca['maximum_numeric_field_delta']==0. and len(cr['rows'])==3
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    nets={r['case_id']:pickle.loads((R/r['solved_payload']).read_bytes())['net'] for r in roots};records={r['identity']:r for r in result['rows']};allrows=[];verifications={}
    for j,(target,contract) in enumerate(zip(cp['targets'],cr['rows'])):
        i=target['original_declared_identity'];assert records[i]['status']=='PRIOR_COLLISION_UNKNOWN_NO_CALL'
        assert contract['case_id']==decl[i]['case_id'] and contract['action']==decl[i]['action'] and contract['exception'] is None
        source=C/f'query_{j:02d}.json'
        records[i]=dict(records[i],status='RETURNED_NEW_NATIVE80_CONTRACT_ADDENDUM',paid_matches=[dict(source=source.relative_to(R).as_posix(),source_sha256=sha(source))])
    for i,d in enumerate(decl):
        rec=records.get(i);v=None
        if rec is None:status='UNENTERED_UNKNOWN'
        else:
            status=rec['status']
            if status in ['PAID_NATIVE80_REUSE_NO_NEW_PF','RETURNED_NEW_NATIVE80_CONTRACT_ADDENDUM']:
                old=rec['paid_matches'][0];path=R/old['source'];assert sha(path)==old['source_sha256']
                source=read(path);value=decode(path.parent,source['after']);after=value['net'] if isinstance(value,dict) and 'net' in value else value
                before=copy.deepcopy(nets[d['case_id']]);runner.rescue.apply_action(before,d['action'])
                def cached(n,**kw):
                    try:assert kw==d['solver_kwargs'];frames_equal(n,before);restore_exact(n,after)
                    except Exception as e:raise BaseException('SAVED_ANALYSIS_ERROR: '+repr(e)) from e
                pp.runpp=cached
                try:v=runner.rescue.verify_action(copy.deepcopy(nets[d['case_id']]),d['action'])
                finally:pp.runpp=native
            elif status in ['RETURNED_NEW_NATIVE80_QUERY','EXCEPTION_UNKNOWN_NO_RETRY']:v=rec['verification']
        if v is not None:verifications[i]=v
        b,q=next(iter(d['action']['add_shunts_q_mvar'].items()));af=(v or {}).get('after') or {}
        allrows.append(dict(identity=i,case_id=d['case_id'],source_order=d['source_order'],bus=b,Q_Mvar=q,status=status,accepted=(v or {}).get('accepted'),reason=(v or {}).get('reason','UNKNOWN'),
            after_UV=af.get('uv_count'),after_OV=af.get('ov_count'),after_Vmin=af.get('vmin'),after_Vmax=af.get('vmax'),after_deficit=af.get('deficit_sum')))
    summaries=[]
    for root in roots:
        rr=[r for r in allrows if r['case_id']==root['case_id']];unknown=[r for r in rr if r['status'] in ['PRIOR_COLLISION_UNKNOWN_NO_CALL','UNENTERED_UNKNOWN']]
        accepted=[r for r in rr if r['accepted'] is True]
        best=None
        if accepted:
            selected=max(accepted,key=lambda r:runner.rescue.score_candidate(dict(action=decl[r['identity']]['action'],verif=verifications[r['identity']])))
            best=selected
        complete=not unknown and len(rr)==sum(1 for d in decl if d['case_id']==root['case_id'])
        summaries.append(dict(case_id=root['case_id'],initial_UV=int((nets[root['case_id']].res_bus.vm_pu<.95).sum()),declared=len(rr),status_counts=dict(Counter(r['status'] for r in rr)),
            accepted_known_queries=len(accepted),first_round_source_choice_status='EXACT_FROM_COMPLETE_FIXED_MENU' if complete else 'UNKNOWN_MISSING_EVIDENCE_DO_NOT_SELECT_AVAILABLE_ONLY',
            best_available_only_descriptive=best,missing_exact_queries=len(unknown),
            whole_controller_episode_endpoint='NOT_EXECUTED_BY_THIS_BATCH',no_comparison_to17step_LLM_episode=True))
    with (O/'All2034_Queries.csv').open('x',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
    put(O/'Case_Summaries.json',dict(status='ALL_FIXED_FIRST_MENU_QUERIES_REPORTED_WITH_UNKNOWNS',cases=summaries,primary_costs=dict(original_missing_only_batch=result['costs'],new_contract_addendum=cr['costs']),first_independent_replays=audit['first_independent_PF_replays']+ca['first_independent_PF_replays'],
        maximum_field_delta=max(audit['maximum_field_delta'],ca['maximum_numeric_field_delta']),maximum_KCL_pu=max(audit['maximum_KCL_pu'],ca['maximum_KCL_pu']),new_PF_model_training_calls_in_analysis=0,
        source_policy_score='Unchanged original score_candidate; source-order tie handling; no new threshold/Q/menu/guard.',
        full_DSE_LLM_external_superiority='UNACHIEVED_NOT_TESTED_BY_A_FIRST_MENU',all6_goals='OPEN'))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(status='ALL_FIRST_MENU_OUTCOMES_REPORTED',cases=len(summaries),queries=len(allrows),new_scientific_calls=0)))
if __name__=='__main__':main()
