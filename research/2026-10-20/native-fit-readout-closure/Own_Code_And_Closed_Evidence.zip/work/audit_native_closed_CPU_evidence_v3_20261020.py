"""Additive saved-evidence audit: partial MLP, complete fixed readouts, saved KCL.

No training, module forward, factorization, linear solve or physical solver is called.
Original completed/failed workers and complete-only readers are left untouched.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import json, hashlib, time, math, random, subprocess, sys, pickle
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/native_closed_CPU_evidence_audit_v3_20261020'
MLP=ROOT/'outputs/native_same_information_MLP_FIT_20261020'
READOUT=ROOT/'outputs/native_stationary_readout_fit_20261020/numeric_v2'
INPUT=ROOT/'outputs/native_fit_training_inputs_20261020'
PREP=ROOT/'outputs/native_stationary_readout_preparation_20261020'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def put(path,obj):
    with Path(path).open('x',encoding='utf-8') as f:
        json.dump(obj,f,indent=2,ensure_ascii=False,allow_nan=False);f.flush();os.fsync(f.fileno())

def terminal_and_sources():
    relatives=[
        'outputs/native_same_information_MLP_coordination_20261020/End_ACK.json',
        'outputs/native_stationary_readout_coordination_20261020/numeric_v2/End_ACK.json',
        'outputs/native15_saved_command_physics_coordination_20261020/End_ACK.json',
    ]
    # Reader-coordinator naming is read from its actual recorded output directory.
    more=list((ROOT/'outputs').glob('*native15*independent*coordination*/End_ACK.json'))
    for rel in relatives: assert read(ROOT/rel)['actual_owned_chain_ended']
    names=['run_native_same_information_MLP_FIT_20261020.py',
           'run_native_numeric_stationary_readout_v2_20261020.py',
           'run_native15_saved_command_physics_20261020.py',
           'audit_native15_saved_command_physics_20261020.py',
           'audit_native_same_information_MLP_FIT_20261020.py']
    for path in more: assert read(path)['actual_owned_chain_ended']
    command="Get-CimInstance Win32_Process -Filter \"Name LIKE 'python%'\" | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    result=subprocess.run(['powershell.exe','-NoProfile','-Command',command],capture_output=True,text=True,check=True,timeout=45)
    values=json.loads(result.stdout or '[]');values=values if isinstance(values,list) else [values]
    assert not [v for v in values if any(name in (v.get('CommandLine') or '') for name in names)],'Old exact scientific/reader command still live'
    for rel in ['outputs/native_same_information_MLP_preparation_20261020/Protocol.json',
                'outputs/native15_saved_command_physics_preparation_20261020/Protocol.json']:
        for source,h in read(ROOT/rel)['source_and_input_hashes'].items(): assert sha(ROOT/source)==h
    return {'fresh_CIM_exact_source_commands_absent':names,'old_End_ACKs_ended':True,
            'original_source_and_input_hashes_unchanged':True,'old_complete_only_MLP_reader_not_run':True}

def partial_mlp(np,torch):
    failure=read(MLP/'Failure.json');cost=failure['actual_costs'];N=1929;batch_count=math.ceil(N/32)
    assert failure['failure']=='FixedMLPbound;noextension/retry/checkpointselection'
    assert all(cost[k]==5442 for k in ['forward_attempts','forward_returns','backward_attempts','backward_returns','optimizer_attempts','optimizer_returns'])
    assert cost['pretrained_LLM_PF_GPU_calls']==0 and not (MLP/'Results.json').exists() and not (MLP/'final500_complete.pt').exists()
    prev='0'*64;counts={k:0 for k in ['forward_attempt','forward_return','backward_attempt','backward_return','optimizer_attempt','optimizer_return']};acks=[];updates={};phase=0;last_elapsed=-1
    order=['forward_attempt','forward_return','backward_attempt','backward_return','optimizer_attempt','optimizer_return']
    for line in (MLP/'events.jsonl').read_text(encoding='utf-8').splitlines():
        row=json.loads(line);e=row['event'];assert e['previous']==prev
        prev=hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert row['sha256']==prev
        assert e['elapsed_seconds']>=last_elapsed;last_elapsed=e['elapsed_seconds']
        k=e['kind']
        if k=='full_state_local_ACK':
            assert phase==0 and e['update']==counts['optimizer_return']
            assert e['update']==0 or e['update']%100==0
            assert sha(MLP/e['checkpoint'])==e['sha256'];acks.append(e)
        else:
            assert k==order[phase];phase=(phase+1)%6;counts[k]+=1
            if k=='optimizer_return':
                u=counts[k];assert e['update']==u and e['finite_gradient_tensors']==6 and math.isfinite(e['loss'])
                assert e['epoch']==(u-1)//batch_count+1 and e['batch']==(u-1)%batch_count;updates[u]=e
            else:
                assert e['number']==counts[k]
                if k.startswith('forward'): assert e['phase']=='FIT'
    assert phase==0 and set(counts.values())=={5442}
    assert [a['update'] for a in acks]==[0]+list(range(100,5401,100)) and len(acks)==55
    data=np.load(INPUT/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz')
    w=data['weight'];mu=np.average(data['X'],axis=0,weights=w);sd=np.maximum(np.sqrt(np.average((data['X']-mu)**2,axis=0,weights=w)),1e-8)
    expected_shapes={'layers.0.weight':(256,435),'layers.0.bias':(256,),
                     'layers.2.weight':(256,256),'layers.2.bias':(256,),
                     'layers.4.weight':(3,256),'layers.4.bias':(3,)}
    generator=torch.Generator(device='cpu');epoch_generated=0;proofs=[]
    for ack in acks:
        state=torch.load(MLP/ack['checkpoint'],map_location='cpu',weights_only=False);u=ack['update']
        assert state['contract']['input_sha256']==sha(INPUT/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz')
        assert state['contract']['source_sha256']==sha(ROOT/'work/run_native_same_information_MLP_FIT_20261020.py')
        assert state['contract']['architecture_sha256']==sha(ROOT/'work/native_same_information_MLP_20261020.py')
        assert state['contract']['seed']==20261020 and state['contract']['all500epochs_finalonly']
        assert state['cursor']==({'completed_updates':0,'epoch':0,'next_batch':0} if u==0 else
                                {'completed_updates':u,'epoch':updates[u]['epoch'],'next_batch':updates[u]['batch']+1})
        assert np.array_equal(mu,state['normalization']['mean']) and np.array_equal(sd,state['normalization']['std'])
        assert set(state['model'])==set(expected_shapes)
        for key,tensor in state['model'].items(): assert tuple(tensor.shape)==expected_shapes[key] and tensor.dtype==torch.float32 and torch.isfinite(tensor).all()
        assert sum(t.numel() for t in state['model'].values())==178179
        opt=state['optimizer'];assert len(opt['param_groups'])==1
        group=opt['param_groups'][0];assert group['lr']==.001 and group['weight_decay']==.01 and len(group['params'])==6
        assert len(opt['state'])==(0 if u==0 else 6)
        for ident,(key,tensor) in zip(group['params'],state['model'].items()):
            if u:
                m=opt['state'][ident];assert int(m['step'])==u
                for name in ['exp_avg','exp_avg_sq']: assert m[name].shape==tensor.shape and torch.isfinite(m[name]).all()
                assert (m['exp_avg_sq']>=0).all()
        assert all(state['actual_costs'][key]==u for key in ['forward_returns','backward_returns','optimizer_returns'])
        py=random.Random();py.setstate(state['RNG']['python']);assert py.getstate()==state['RNG']['python']
        nr=np.random.RandomState();nr.set_state(state['RNG']['numpy']);ns=nr.get_state();assert ns[0]==state['RNG']['numpy'][0] and np.array_equal(ns[1],state['RNG']['numpy'][1]) and ns[2:]==state['RNG']['numpy'][2:]
        if u==0: generator.set_state(state['RNG']['torch'])
        else:
            while epoch_generated<updates[u]['epoch']: torch.randperm(N,generator=generator);epoch_generated+=1
        assert torch.equal(generator.get_state(),state['RNG']['torch'])
        proofs.append({'update':u,'checkpoint':ack['checkpoint'],'sha256':ack['sha256'],'all6_moments_and_complete_cursor_RNG_valid':True})
    assert not list(MLP.glob('*.tmp'))
    manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in MLP.iterdir() if p.is_file()}
    put(OUT/'Preserved_Partial_MLP_File_Manifest.json',manifest);put(OUT/'All55_Partial_MLP_State_Proofs.json',proofs)
    return {'status':'PASS_SAVED_PARTIAL_MLP_COST_STATE_PRESERVATION_ONLY','actual_costs':cost,
            'required_final_updates':500*batch_count,'actual_updates':5442,'full_saved_states':55,
            'last_saved_update':5400,'unrecovered_final_update_weights':42,'unknown_final500_performance':True,
            'no_model_instantiation_forward_backward_optimizer_or_performance_selection':True,
            'checkpoint_RNG_matches_exact_source_randperm_epoch_consumption':True,
            'training_batch_membership_not_explicitly_journaled':'Source/cursor/RNG bound only; no invented per-sample update replay.'}

def readouts(np):
    manifest=read(READOUT/'Closed_Manifest.json')
    for name,entry in manifest['files'].items(): assert (READOUT/name).stat().st_size==entry['bytes'] and sha(READOUT/name)==entry['sha256']
    z=np.load(PREP/'Grouped_Same_Current_Only_Numeric_FIT.npz');X=z['X'];target=z['target'];w=z['weight'];n,d=X.shape
    assert (n,d)==(241,400) and target.shape==(241,3) and (w>0).all() and abs(w.sum()-1929)<1e-7
    mean=np.average(X,axis=0,weights=w);sd=np.maximum(np.sqrt(np.average((X-mean)**2,axis=0,weights=w)),1e-8);Z=(X-mean)/sd;ymean=np.average(target,axis=0,weights=w);lam=.001*w.sum();proofs=[]
    for kernel in ['linear','rbf']:
        s=np.load(READOUT/(kernel+'_Complete_Readout.npz'));p=np.load(READOUT/(kernel+'_All241_FIT_Predictions.npz'))
        for k,value in [('mean',mean),('std',sd),('trainZ',Z),('weight',w),('target_mean',ymean),('features',X),('target',target)]: assert np.array_equal(s[k],value),k
        assert str(s['kernel'])==kernel and float(s['lambda_value'])==lam
        assert str(s['source_feature_sha256'])==str(s['source_input_sha256'])==sha(PREP/'Grouped_Same_Current_Only_Numeric_FIT.npz')
        dot=Z@Z.T/d
        K=dot if kernel=='linear' else np.exp(-np.maximum(np.sum(Z*Z,axis=1)[:,None]+np.sum(Z*Z,axis=1)[None,:]-2*Z@Z.T,0)/d)
        km=K@w/w.sum();grand=w@km/w.sum();center=K-km[:,None]-km[None,:]+grand
        assert np.array_equal(s['kernel_mean'],km) and float(s['kernel_grand'])==float(grand)
        root=np.sqrt(w);A=root[:,None]*center*root[None,:]+lam*np.eye(n);B=root[:,None]*(target-ymean)/.3
        residual=float(np.max(np.abs(A@s['beta']-B)));assert residual<=1e-8
        assert np.array_equal(s['alpha'],root[:,None]*s['beta'])
        left=(s['features']-s['mean'])/s['std'];right=s['trainZ'];P=left@right.T/d
        if kernel=='rbf':P=np.exp(-np.maximum(np.sum(left*left,axis=1)[:,None]+np.sum(right*right,axis=1)[None,:]-2*left@right.T,0)/d)
        deployed=P-(P@w/w.sum())[:,None]-s['kernel_mean'][None,:]+s['kernel_grand']
        raw=.3*(deployed@s['alpha'])+ymean;u=np.clip(raw.astype(np.float32),np.float32(-.3),np.float32(.3))
        assert np.array_equal(raw,p['raw']) and np.array_equal(u,p['u'])
        assert np.isfinite(raw).all() and np.isfinite(u).all() and u.dtype==np.float32
        # An altered coefficient must fail the normal-equation evidence gate.
        corrupt=s['beta'].copy();corrupt[0,0]+=.01;bad=float(np.max(np.abs(A@corrupt-B)));assert bad>1e-8
        proofs.append({'kernel':kernel,'weighted_centered_normal_equation_max_residual':residual,
                       'all241_saved_raw_native_predictions_exact':True,'corrupted_coefficient_rejected':True,
                       'FIT_normalized_MSE_descriptive_only':float(np.average(np.mean(((u-target)/.3)**2,axis=1),weights=w))})
    result=read(READOUT/'Results.json');assert result['actual_costs']['Cholesky_returns']==result['actual_costs']['three_RHS_solve_returns']==2
    return {'status':'PASS_BOTH_FIXED_NUMERIC_READOUT_SAVED_EQUATIONS_PREDICTIONS_FIT_ONLY','kernels':proofs,
            'source_manifest_and_input_hashes_pass':True,'original_fit_costs':result['actual_costs'],
            'reader_kernel_reconstructions':2,'reader_saved_prediction_equation_reconstructions':2,
            'reader_factorization_solve_model_optimizer_PF_calls':0,'DEV_confirmation_physical_benchmark':'UNKNOWN_UNEXECUTED',
            'no_selected_kernel_lambda_or_winner':True}

def saved_kcl(np):
    primary=ROOT/'outputs/native15_saved_command_physics_20261020';reader=ROOT/'outputs/native15_saved_command_physics_independent_20261020'
    assert read(reader/'Result.json')['status'].startswith('PASS_INDEPENDENT_NATIVE15')
    with (primary/'Actual_Native_Query_Before.pkl').open('rb') as f: net=pickle.load(f)
    fields=np.load(primary/'Actual_All_Fields.npz');cols=list(net.res_bus.select_dtypes(include=[np.number]).columns)
    assert fields['res_bus'].shape==(13,len(cols))
    get=lambda name:fields['res_bus'][:,cols.index(name)]
    lookup=net._pd2ppc_lookups['bus'][net.bus.index.to_numpy()];assert sorted(lookup.tolist())==list(range(13))
    v=np.zeros(13,dtype=np.complex128);v[lookup]=get('vm_pu')*np.exp(1j*np.deg2rad(get('va_degree')))
    graph=np.load(ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz')
    assert np.array_equal(net._ppc['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(net._ppc['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and net._ppc['baseMVA']==float(graph['baseMVA'])
    Y=graph['Y'];assert Y.shape==(13,13)
    expected=np.zeros(13,dtype=np.complex128);expected[lookup]=-(get('p_mw')+1j*get('q_mvar'))/net._ppc['baseMVA']
    residual=v*np.conj(Y@v)-expected;maximum=float(np.max(np.abs(residual)))
    assert np.isfinite(residual).all() and maximum<=1e-7
    result=read(primary/'Result.json');assert result['candidate_OV']==2 and result['guard_accepted'] is False and result['actual_commits']==0
    return {'status':'PASS_SAVED_NATIVE15_REJECTED_COMMAND_ALL13_BUS_KCL','max_complex_pu_KCL_residual':maximum,
            'source':'Original saved native query NET cached admittance plus actual after-result fields; no converter or derivative.',
            'actual_new_PF_model_optimizer_solve_derivative_calls':0,'candidate_UV_OV':[0,2],
            'guard':'REJECTED','commits':0,'not_benchmark_or_LLM_benefit':True}

def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    p=read(ROOT/'outputs/native_closed_CPU_evidence_Y_repair_preparation_20261020/Protocol.json')
    for rel,h in p['source_and_input_hashes'].items(): assert sha(ROOT/rel)==h
    ownership=terminal_and_sources();put(OUT/'Fresh_Terminal_Source_Proof.json',ownership)
    import candidate_process_runtime
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np, torch
    torch.set_num_threads(2)
    results={}
    for name,call in [('MLP',lambda:partial_mlp(np,torch)),('numeric_readouts',lambda:readouts(np)),('saved_command_KCL',lambda:saved_kcl(np))]:
        results[name]=call();put(OUT/(name+'_Component_Audit.json'),results[name])
    from candidate_process_evidence_utils import frozen_checks
    result={'at_utc':datetime.now(timezone.utc).isoformat(),
            'status':'PASS_ADDITIVE_CLOSED_CPU_EVIDENCE_PARTIAL_STATE_FIXED_READOUT_SAVED_KCL_ONLY',
            'results':results,'all9_original_frozen_checks':frozen_checks(),
            'new_module_forward_backward_optimizer_PF_derivative_factor_solve_calls':0,
            'no_old_owner_restart_no_checkpoint_selection_no_missing_result_fill':True,
            'workflow_seconds':time.monotonic()-start}
    put(OUT/'Independent_Audit.json',result)
    put(OUT/'Closed_Manifest.json',{'files':{f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.iterdir() if f.is_file()}})
    print('ADDITIVE_SAVED_CPU_EVIDENCE_INDEPENDENT_PASS_NO_NEW_SCIENCE')

if __name__=='__main__': main()
