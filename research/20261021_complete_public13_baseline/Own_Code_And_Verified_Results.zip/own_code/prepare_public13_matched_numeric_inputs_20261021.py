"""Bind all500 audited public roots and relevant paid attempts; no new science."""
import json,pickle,hashlib,time
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];O=R/'outputs/public13_matched_numeric_preparation_20261021'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)
def main():
    O.mkdir(exist_ok=False);began=time.monotonic()
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from run_public13_remaining_published_cohort_20261021 import regime
    np=b.np;cohort=read(R/'outputs/public13_native_cohort_assembly_20261021/Native_Cohort_Results.json');assert cohort['status']=='COMPLETE_SOURCE_NATIVE_ALL500_THREE_METHOD_INPUT_CASE_COHORT'
    old=read(R/'outputs/public13_remaining_published_cohort_20261021/Failure.json');new=read(R/'outputs/public13_missing_only_execution_20261021/Result.json');roots={};oldworld={w['seed']:w for w in old['worlds']};newworld={w['seed']:w for w in new['worlds']};p=read(R/'outputs/public13_full_cohort_preparation_20261021/Protocol.json');recipes=np.load(R/p['recipes']);graph=np.load(R/p['graph'])
    for seed in range(500):
        if seed==0:path=R/'outputs/stable_ddpg_native_engineering_20261020/PF0_after.pkl';kind='NET'
        else:
            primary='outputs/public13_remaining_published_cohort_20261021' if seed<=162 else 'outputs/public13_missing_only_execution_20261021';path=R/primary/f'seed{seed:03d}/Root_Complete_ENV.pkl';kind='ENV'
        raw=path.read_bytes();value=pickle.loads(raw);net=value['network'] if kind=='ENV' else value
        if seed:assert sha(path)==(oldworld[seed] if seed<=162 else newworld[seed])['root_ENV_sha256']
        for name,tab,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(net[tab][col].to_numpy(),recipes[name][seed])
        pp=net._ppc;assert np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and net.converged and np.array_equal(net.sgen.bus.to_numpy()[:3],[2,7,9])
        roots[seed]={'seed':seed,'path':path.relative_to(R).as_posix(),'kind':kind,'sha256':hashlib.sha256(raw).hexdigest(),'physical_signature':signature(net),'noncontrolled_regime':regime(net),'all13_initial_vm':net.res_bus.vm_pu.to_numpy().tolist(),'initial_control_Q':net.sgen.q_mvar.to_numpy()[:3].tolist()}
    assert len({v['noncontrolled_regime'] for v in roots.values()})==500
    rootreg={v['noncontrolled_regime'] for v in roots.values()};paid={};attempted=set();before_seen=0
    def add(sig,kwargs,after,fields,certificate,after_sha=None):
        key=sig+'|'+json.dumps(kwargs,sort_keys=True);row={'physical_signature':sig,'kwargs':kwargs,'after':Path(after).relative_to(R).as_posix(),'after_sha256':after_sha or sha(after),'fields':Path(fields).relative_to(R).as_posix(),'fields_sha256':sha(fields),'independent_certificate':certificate};attempted.add(sig)
        if key not in paid:paid[key]=row
    for directory,document,certificate in [('public13_remaining_published_cohort_20261021',old,'outputs/public13_first_partial_validation_v2_20261021/Independent_Audit.json'),('public13_missing_only_execution_20261021',new,'outputs/public13_missing_only_independent_20261021/Independent_Audit.json')]:
        for row in document['receipts']:
            if row.get('origin')=='ORIGINAL_PAID_PREFIX':continue
            attempted.add(row['physical_signature'])
            if row['status']=='RETURNED':
                index=row['index'];d=R/'outputs'/directory/'physics';add(row['physical_signature'],row['kwargs'],d/f'PF{index:06d}_after.pkl',d/f'PF{index:06d}_fields.npz',certificate,row['after_sha256'])
    # Old case0 sources use a different hash-table order. Canonicalize from the
    # actual saved input NET rather than assuming those digest namespaces match.
    d=R/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020';cert=d/'independent_audit/Independent_Audit.json';assert cert.exists()
    for index in range(4):
        before=pickle.loads((d/f'PF{index}_before.pkl').read_bytes());after=pickle.loads((d/f'PF{index}_after.pkl').read_bytes());assert signature(before)==signature(after)
        add(signature(before),{'algorithm':'bfsw'} if index==0 else {'algorithm':'bfsw','init':'dc'},d/f'PF{index}_after.pkl',d/f'PF{index}_fields.npz',cert.relative_to(R).as_posix())
    d=R/'outputs/stable_ddpg_native_episode_20261020';episode=read(d/'Result.json')
    for pos,row in enumerate(episode['receipts']):
        assert row['reference']==f'newPF{pos:03d}';before=pickle.loads((d/'physics'/f'PF{pos:03d}_before.pkl').read_bytes());after=pickle.loads((d/'physics'/f'PF{pos:03d}_after.pkl').read_bytes());assert signature(before)==signature(after)
        add(signature(before),row['kwargs'],d/'physics'/f'PF{pos:03d}_after.pkl',d/'physics'/f'PF{pos:03d}_fields.npz','outputs/stable_ddpg_native_episode_20261020/independent_audit/Independent_Audit.json')
    # Include every relevant recorded prior attempt, successful or not. Other
    # old FIT/development regimes are excluded by physical-table identity, not
    # by outcomes. No old unknown identity is silently declared unexecuted.
    for scope in p['paid_history_scope']:
        directory=R/'outputs'/scope
        if not directory.exists():continue
        for f in directory.rglob('*before.pkl'):
            value=pickle.loads(f.read_bytes());net=value['network'] if isinstance(value,dict) and 'network' in value else value
            if not hasattr(net,'bus') or len(net.bus)!=13:continue
            before_seen+=1
            if regime(net) in rootreg:attempted.add(signature(net))
    put(O/'All500_Audited_Exact_Roots.json',{'roots':list(roots.values()),'count':500,'registered_source_order':True,'roots_reused_not_recomputed':True,'all_old_cases_development_not_unused_confirmation':True})
    put(O/'Historical_Paid_Physical_Index.json',{'returned_exact_initializer_entries':paid,'all_relevant_attempted_signatures':sorted(attempted),'prior_scope_names':p['paid_history_scope'],'prior_before_files_scoped':before_seen,'new_converter_PF_model_derivative_factor_LP_calls':0,'namespace':'Canonical native_upgrade_support_engine.signature; older case0 digests were explicitly recomputed from actual input tables','old_paid_costs_not_free':True})
    put(O/'Input_Readiness.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL500_SOURCE_RECIPE_ROOT_GRAPH_AND_RELEVANT_PAID_ATTEMPT_BINDING_ONLY','root_count':500,'distinct_noncontrolled_regimes':500,'returned_exact_initializer_cache_entries':len(paid),'relevant_attempted_signatures':len(attempted),'old_prior_before_files_checked':before_seen,'new_model_PF_converter_derivative_factor_solve_optimizer_calls':0,'preparation_seconds':time.monotonic()-began,'full_policy_performance_or_launch_admission':'NOT_READY_UNTIL_FROZEN_WORKER_READER_PROTOCOL_GATES'})
    print(json.dumps({'roots':500,'paid_entries':len(paid),'prior_before_files':before_seen,'new_science':0}))
if __name__=='__main__':main()
