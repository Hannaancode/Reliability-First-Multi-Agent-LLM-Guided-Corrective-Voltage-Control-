"""Whole source-derived first decision with new registry and referenced history.

No scientific body is stubbed. Every solver/derivative/factor/solve/new-voltage
forecast is blocked; all required already-paid evidence must be available.
This is integration of a changed data path, not another performance trial.
"""
import copy,gzip,hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone,timedelta
import numpy as np,pandapower as pp
import verified_paid_cache_engine_v2_20261018 as binding
from paid_receding_journal_reference_history_v2_20261018 import ReferencedHistory,ReceiptJournalIndex,verify_reference_history
import paid_receding_referenced_commit_v2_20261018 as transport
from full_receding_paid_campaign_20261015 import R,B as OLD,read,put,sha,METHODS
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from dynamic_actual_mask_guidance_v1 import identity
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
B=R/'outputs/verified_complete_cached_decision_20261018'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def normalize(value,old,new):
    if isinstance(value,str):return value.replace(old,new)
    if isinstance(value,list):return [normalize(v,old,new) for v in value]
    if isinstance(value,dict):return {k:normalize(v,old,new) for k,v in value.items()}
    return value
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    p=read(OLD/'Protocol.json');scope=read(R/'outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json')
    initialized={(e['world'],e['method']) for e in scope['initialized_branches']}
    entry,mode=next((e,m) for e in p['endpoints'] for m in METHODS if (e['world'],m) not in initialized)
    sources=OLD.parent/'bounded_paid_lookahead_physics_20261014'
    reference=next(read(sources/'actual'/f'Branch_{i}.json') for i in range(1,9) if (read(sources/'actual'/f'Branch_{i}.json')['world'],read(sources/'actual'/f'Branch_{i}.json')['method'])==(entry['world'],mode))
    protocol={'role':'COMPLETE_REAL_SOURCE_DECISION_NEW_VERIFIED_CACHE_REFERENCED_PATH_SOFTWARE_ONLY','source_sha256':sha(Path(__file__)),
        'source_binding_sha256':sha(Path(binding.__file__)),'bound_seconds':900,'selection':'First original uninitialized branch; compare complete fixed decision against its previously independently verified bounded source. No reward/outcome filter.',
        'world':entry['world'],'method':mode,'all_new_scientific_calls_blocked':True,'not_new_policy_performance_or_science_authorization':True}
    put(B/'Protocol.json',protocol);phash=sha(B/'Protocol.json')
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    forbidden=[]
    def no_science(*a,**k):forbidden.append(True);raise AssertionError('Unavailable paid input: cannot execute new science in software integration')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,no_science)
    import dynamic_actual_mask_guidance_v1 as numeric
    numeric.dSbus_dV=numeric.lu_factor=numeric.lu_solve=no_science
    binding.SourceEngine.decision.__globals__['forecast']=no_science
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    reuse=R/'outputs/full_paid_numeric_reuse_separate_roles_v2_20261018';record=read(reuse/'Results.json')
    raw=(reuse/'All_Existing_Complete_Forecasts.json.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==record['forecast_index_sha256'];forecasts=json.loads(gzip.decompress(raw))
    contexts={}
    for ref in read(reuse/'All_Existing_Contexts.json'):
        assert sha(R/ref['path'])==ref['sha256']
        with np.load(R/ref['path'],allow_pickle=False) as z:c={k:z[k].copy() for k in z.files}
        assert identity(c)==ref['identity'];contexts[ref['identity']]=c
    class Evidence:
        def __init__(self):
            self.costs={'preservation_seconds':0.};self.previous='0'*64;self.journal=(B/'scientific.jsonl').open('xb');self.pack=(B/'capsules.bin').open('x+b')
            self.index=ReceiptJournalIndex(B/'scientific.jsonl',protocol_sha256=phash)
        def admit(self):
            if time.perf_counter()-started>=900:raise TimeoutError('Fixed software integration bound, no extension')
        def event(self,name,data):
            t=time.perf_counter();offset=self.journal.tell();raw=canon({'event':name,'data':data,'protocol_sha256':phash,'previous_sha256':self.previous})+b'\n'
            self.journal.write(raw);self.journal.flush();os.fsync(self.journal.fileno());self.previous=hashlib.sha256(raw[:-1]).hexdigest()
            if name=='every_query_receipt_closed_before_more_science':self.index.observe_closed_durable_query(offset,raw)
            self.costs['preservation_seconds']+=time.perf_counter()-t
    evidence=Evidence();registry=binding.VerifiedPaidUseRegistry(B/'verified_uses',runner=runner,zones=zones)
    history=ReferencedHistory(B/'history',source_anchor=sha(Path(binding.__file__)),input_anchor=phash,max_bytes=128*1024**2,query_index=evidence.index)
    net,cursor,_=load_endpoint(entry);cursor=transport.initialize(net,build_current_domain(net,cursor,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
    numeric_cost={'public_derivative_attempts':0,'public_derivative_returns':0,'LU_factor_attempts':0,'LU_factor_returns':0,'LU_solve_attempts':0,'LU_solve_returns':0,
        'RHS_columns':0,'compile_seconds':0.,'exact_context_reuses':0,'exact_paid_forecast_reuses':0,'new_forecasts':0}
    (B/'contexts').mkdir()
    actual=binding.VerifiedPaidDecisionEngine(out=B,evidence=evidence,runner=runner,zones=zones,cache=registry.cache,blocked=set(),contexts=contexts,numeric_cost=numeric_cost,
        history=history,paid_forecasts=forecasts,use_registry=registry)
    report=actual.decision(net,cursor,entry['world'],mode,0)
    assert report['plan']==normalize(reference['plan'],reference['root'],report['root'])
    assert report['menus']==normalize(reference['menus'],reference['root'],report['root'])
    assert len(report['query_messages'])==len(reference['query_messages'])
    for a,b in zip(report['query_messages'],reference['query_messages']):
        assert a['aid']==b['aid'] and a['row']==b['row'] and a['parent']==normalize(b['parent'],reference['root'],report['root'])
        for key in ['verdict','original_score','attributed_PF_calls','attributed_solver_seconds']:assert a['record'][key]==b['record'][key],key
    checked=verify_reference_history(history.anchor());assert checked['all_referenced_queries_exact']==len(report['query_messages'])
    chosen=report['plan']['selected'];message=next(m for m in report['query_messages'] if m['parent']==report['root'] and m['aid']==chosen['first'])
    target=report['resolve_paid_state'](message['successor']);point=point_key(target['net'],target['cursor'])
    eligible=[r for r in build_current_domain(target['net'],target['cursor'],runner=runner,zones=zones)['all_declared_original9Q_ordinary_and_owned_joint_identities'] if binding.admitted.admit_input is not None and __import__('original_local_paid_branch_broker_v1').resource_eligible(r,target['cursor'])]
    candidates=[r for r in sorted(eligible,key=action_key) if point+'|'+action_key(r) not in registry.archive.index]
    assert all(numeric_cost[k]==0 for k in ['public_derivative_attempts','LU_factor_attempts','LU_solve_attempts','new_forecasts']) and not forbidden
    put(B/'Selected_Paid_Input_For_Prospective_Engineering.json',{'world':entry['world'],'method':mode,'source_entry':entry,'selected_row':message['row'],
        'selected_record':message['record'],'selected_paid_state_point':point,'projected_cursor_NOT_ACTUAL_COMMIT':target['cursor'],'source_initial_cursor':cursor,
        'source_initial_point':point_key(net,cursor),'current_after_first_metrics':runner.rescue.grid_metrics(target['net']),
        'candidate_following_rows':candidates[:2],'candidate_following_keys':[point+'|'+action_key(r) for r in candidates[:2]],
        'global_unexecuted_or_new_science_permission':'NOT_ESTABLISHED_BY_THIS_SOFTWARE_GATE'})
    history.close();registry.close();evidence.journal.close();evidence.pack.close()
    put(B/'Results.json',{'status':'PASS_COMPLETE_FIXED_CACHED_DECISION_VERIFIED_ENGINE_REFERENCED_HISTORY','world':entry['world'],'method':mode,
        'all_ordered_query_receipts':len(report['query_messages']),'full_original_plan_menus_metrics_scores_and_attributed_costs_exact':True,
        'history_referenced_queries_exact':checked['all_referenced_queries_exact'],'numeric_costs':numeric_cost,'actual_reading_verification_preservation_costs':evidence.costs,
        'new_model_PF_optimizer_derivative_factor_solve_voltage_forecast_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Complete changed-cache-path integration on one previously measured fixed decision. Not new performance, full trajectory, LLM effect, global new-identity closure or native engineering launch permission.'})
    put(B/'Closed_Manifest.json',{'members':{str(x.relative_to(B)):sha(x) for x in B.rglob('*') if x.is_file()},'new_science':0})
    print(json.dumps({'whole_verified_cached_decision':'PASS','receipts':len(report['query_messages']),'new_science':0}))
if __name__=='__main__':main()
