"""One fixed linear/RBF readout per representation, no model/PF or sweep."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['OMP_NUM_THREADS']='2'
import argparse,hashlib,json,sys,time
from collections import defaultdict
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/f118_encoder_readout_preparation_20261022'
sys.path.insert(0,str(R/'work'))
from run_original_role_numeric_gate_20261011 import typed_features,legal,identity
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np
    from scipy.linalg import cho_factor,cho_solve
    ap=argparse.ArgumentParser();ap.add_argument('--numeric-only',action='store_true');args=ap.parse_args()
    O=R/('outputs/f118_fixed_numeric_readouts_20261022' if args.numeric_only else 'outputs/f118_fixed_encoder_readouts_20261022')
    O.mkdir(exist_ok=False);start=time.monotonic();put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    lock=read(P/'Fixed_Readout_Protocol.json');assert lock['readout_source_sha256']==sha(__file__)
    rows=read(P/'Readout_Rows_Local_Only.json');assert len(rows)==436
    fit=[r for r in rows if r['readout_partition']=='FIT'];held=[r for r in rows if r['readout_partition']=='HELD']
    assert len(fit)==340 and len(held)==96
    action_map={identity(r['action']):r['action'] for r in fit};action_map[identity(None)]=None;classes=sorted(action_map)
    weights=np.asarray([r['weight'] for r in fit],np.float64);sqrtw=np.sqrt(weights)
    y=np.zeros((340,len(classes)),np.float64)
    for i,r in enumerate(fit):y[i,classes.index(identity(r['action']))]=1
    original=R/'outputs/critical_research_reset_20261010/original_role_numeric_gate_20261011/execution'
    encoder=read(original/'Encoder.json');assert sha(original/'Encoder.json')==lock['numeric_encoder_sha256']
    symbols=encoder['symbols'];index={s:i for i,s in enumerate(symbols)}
    def numeric(records):
        x=np.zeros((len(records),len(symbols)*2),np.float64)
        for i,r in enumerate(records):
            v=typed_features(r['packet']);assert not set(v)-set(symbols)
            for k,value in v.items():
                j=index[k];x[i,j]=(value-encoder['means'][j])/encoder['scales'][j];x[i,len(symbols)+j]=1
        return x
    if args.numeric_only:representations={'same_current_numeric':(numeric(fit),numeric(held))}
    else:
        a=read(R/'outputs/f118_encoder_readout_independent_20261022/Independent_Audit.json');assert a['all3_complete'] and a['readout_allowed']
        representations={}
        for arm in read(P/'Protocol.json')['arms']:
            path=R/'outputs/f118_encoder_readout_execution_20261022'/arm/'staged/study/primary_All432_Features.npy'
            full=np.load(path);assert full.shape[0]==432
            representations[arm]=(full[[r['feature_id'] for r in fit]].astype(np.float64),full[[r['feature_id'] for r in held]].astype(np.float64))
    results={};allpred=[]
    for name,(xf,xh) in representations.items():
        mean=np.average(xf,axis=0,weights=weights);sd=np.sqrt(np.average((xf-mean)**2,axis=0,weights=weights));sd=np.maximum(sd,1e-6)
        zf=(xf-mean)/sd;zh=(xh-mean)/sd;d=zf.shape[1];np.savez(O/(name+'_source.npz'),xf=xf,xh=xh,mean=mean,sd=sd,weights=weights,y=y)
        fitdot=zf@zf.T/d;helddot=zh@zf.T/d
        for kernel in ['linear','rbf']:
            tick=time.perf_counter()
            if kernel=='linear':K=fitdot;KH=helddot
            else:
                df=np.maximum(0,np.sum(zf*zf,axis=1)[:,None]/d+np.sum(zf*zf,axis=1)[None,:]/d-2*fitdot)
                dh=np.maximum(0,np.sum(zh*zh,axis=1)[:,None]/d+np.sum(zf*zf,axis=1)[None,:]/d-2*helddot)
                K=np.exp(-df);KH=np.exp(-dh)
            lam=.001*float(weights.sum());A=sqrtw[:,None]*K*sqrtw[None,:]+lam*np.eye(340)
            rhs=sqrtw[:,None]*y;chol=cho_factor(A,lower=True,check_finite=True);alpha=cho_solve(chol,rhs)
            residual=float(np.max(np.abs(A@alpha-rhs)));assert residual<=1e-8
            scores=KH@(sqrtw[:,None]*alpha);pred=[];worlds=defaultdict(list)
            for i,r in enumerate(held):
                allowed=np.asarray([legal(action_map[c],r['packet']) for c in classes]);assert allowed.any()
                q=int(np.argmax(np.where(allowed,scores[i],-np.inf)));code=classes[q];hit=code==identity(r['action'])
                worlds[r['world_sha256']].append(int(hit));pred.append(code)
                allpred.append({'representation':name,'kernel':kernel,'id':r['id'],'world_sha256':r['world_sha256'],'prediction':action_map[code],'target':r['action'],'exact':bool(hit),'legal':legal(action_map[code],r['packet']),'target_unseen_in_FIT':identity(r['action']) not in classes})
            key=name+'_'+kernel
            np.savez(O/(key+'_fit.npz'),A=A,rhs=rhs,alpha=alpha,lower_cholesky=np.tril(chol[0]),scores=scores)
            results[key]={'equal_world_exact_action':float(np.mean([np.mean(h) for h in worlds.values()])),
                'pairs':96,'exact_hits':sum(map(sum,worlds.values())),'all_legal':True,'FIT_classes':len(classes),
                'HELD_unseen_action_pairs':sum(identity(r['action']) not in classes for r in held),
                'factorizations':1,'RHS_solves':len(classes),'max_fit_equation_residual':residual,'fixed_lambda':lam,
                'world_scores':{w:float(np.mean(h)) for w,h in worlds.items()},'workflow_seconds':time.perf_counter()-tick}
    if args.numeric_only:
        best=max(.7291666666666666,max(x['equal_world_exact_action'] for x in results.values()))
        opportunity='STOP_THIS_FIXED_TEACHER_READOUT_PRIORITY_LESS_THAN_5PP_CEILING' if best>.95 else 'ENCODER_DIAGNOSTIC_OPPORTUNITY_ONLY_NOT_WIN_OR_PHYSICAL_PERMISSION'
        result={'status':'COMPLETE_FIXED_TWO_NUMERIC_READOUT_CONTROLS','results':results,'existing_ExtraTrees_reference':.7291666666666666,'best_numeric':best,'fixed_5pp_headroom_gate':opportunity,'GPU_diagnostic_admitted_by_headroom_only':best<=.95}
    else:
        numeric_result=read(R/'outputs/f118_fixed_numeric_readouts_20261022/Results.json');primary=results['private_0_5B_linear'];base=results['public_0_5B_linear']
        threshold=max(numeric_result['best_numeric'],base['equal_world_exact_action'])+.05
        wins=sum(primary['world_scores'][w]>base['world_scores'][w] for w in primary['world_scores'])
        survived=primary['equal_world_exact_action']>=threshold and wins>=2
        result={'status':'COMPLETE_FIXED_SIX_ENCODER_READOUTS_HISTORICAL_DEVELOPMENT_ONLY','results':results,
            'private_primary_gate':'PASS_DIAGNOSTIC_ONLY_NOT_GENERALIZATION' if survived else 'FAIL_STOP_FIXED_ENCODER_READOUT_INTERVENTION',
            'threshold_from_strongest_numeric_and_same_base':threshold,'strict_private_world_wins_vs_base':wins,
            'private_HELD_training_overlap':'Possibleall109worlds; not a private-adapter heldout test.',
            'physical_LLM_superiority_novelty_and_unused_confirmation':'UNACHIEVED_NOT_TESTED_BY_THIS_READOUT'}
    result.update(new_model_PF_generation_optimizer_calls=0,workflow_seconds=time.monotonic()-start)
    put(O/'Predictions.json',allpred);put(O/'Results.json',result)
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'status':result['status'],'scores':{k:v['equal_world_exact_action'] for k,v in results.items()},'opportunity':result.get('fixed_5pp_headroom_gate',result.get('private_primary_gate'))}))
if __name__=='__main__':main()
