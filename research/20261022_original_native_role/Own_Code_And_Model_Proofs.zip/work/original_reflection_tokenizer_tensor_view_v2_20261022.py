"""Container compatibility only for the unchanged historical generate function.

Modern transformers returns BatchEncoding for return_tensors='pt'. The original
source expects the input-ID Tensor. No token, prompt, mask or policy is changed.
"""
class TensorTemplateView:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __getattr__(self, name):
        return getattr(self.tokenizer, name)

    def apply_chat_template(self, *args, **kwargs):
        value = self.tokenizer.apply_chat_template(*args, **kwargs)
        if kwargs.get('return_tensors') != 'pt' or not hasattr(value, 'keys'):
            return value
        import torch
        ids = value['input_ids']
        assert isinstance(ids, torch.Tensor) and ids.ndim == 2 and ids.shape[0] == 1
        if 'attention_mask' in value:
            assert torch.equal(value['attention_mask'], torch.ones_like(ids))
        return ids
