"""Scoped recipient-role ceiling on completed development data; no model/PF.

This reads no live model outputs and changes no source, ordering or study gate.
"""
import hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
from durable_opaque_evidence_store_v1 import local_root,process_alive
from causal_recipient_seed_order_v1 import order
from joint_admissibility_order_v1 import KEYS
R=Path(__file__).resolve().parents[1]
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
OUT=R/'outputs/critical_research_reset_20261010/causal_recipient_role_ceiling_20261012'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()
def put(path,value):
    with local_root(path).open('x',encoding='utf8') as file:json.dump(value,file,indent=2,allow_nan=False);file.flush();os.fsync(file.fileno())
def main():
    begun=time.perf_counter();v=read(OLD/'verified_handoff/Verified_Physical_Opportunity_Checkpoint.json')
    assert v['fixed_gate']=='PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY' and all(not process_alive(x) for x in v['all_exact_owner_coordinator_reader_chains_ended'])
    local_root(OUT).mkdir(exist_ok=False)
    protocol={'scope':'POSTHOC_DEVELOPMENT_SCOPED_THEORETICAL_RECIPIENT_SEED_CEILING_NOT_PERFORMANCE',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':{name:sha(R/name) for name in ['work/analyze_causal_seed_role_ceiling_v1.py','work/causal_recipient_seed_order_v1.py','work/joint_admissibility_order_v1.py']},
        'inputs':{name:sha(OLD/name) for name in ['preparation/Protocol.json','actual/Closed_Manifest.json','audit/Independent_Audit.json']},
        'all_K':[1,4,16,64,256],'all_four_roots_retained':True,'live_model_outputs_read':0,
        'theorem':'For a target oracle candidate, its own valid recipient group alone gives its earliest possible rank. Adding other seeded recipients can only keep or increase rank: ordering preserves numeric rank within the same admission class, and seeded groups only add preceding candidates. A target in the rejected-prediction class cannot pass any predicted-admitted candidate. Min over all physical score-tied target candidates and empty seeds is therefore the exact optimistic ceiling for up to four recipient groups.',
        'limits':'Only this frozen group-promotion role on these inspected current inputs. Not a general impossibility theorem, fresh statistical test, online oracle stopping rule, policy benefit or LLM quality claim.',
        'new_model_PF_optimizer_derivative_forecast_solve_calls':0}
    put(OUT/'Protocol.json',protocol);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid()})
    manifest=read(OLD/'actual/Closed_Manifest.json');assert manifest['members']['scientific.jsonl']['sha256']==sha(OLD/'actual/scientific.jsonl')
    records=[]
    for line in local_root(OLD/'actual/scientific.jsonl').read_text('utf8').splitlines():
        event=json.loads(line)
        if event['event']=='candidate_closed':records.append(event['data'])
    assert len(records)==4001;p=read(OLD/'preparation/Protocol.json');results=[]
    for entry in p['current_endpoints']:
        endpoint=read(R/entry['endpoint_record']);cursor={**endpoint['cursor'],'raw_current_receiver_scope':endpoint['native_common_AND_zone_buses']}
        rows=[r for r in records if r['world']==entry['world']];before=rows[0]['verif']['before']
        causal=[{k:r[k] for k in KEYS} for r in rows];lookup={r['universe_index']:r for r in rows}
        safe=[r for r in rows if r['verif']['accepted']];best_score=max(tuple(r['original_score']) for r in safe)
        targets={r['universe_index'] for r in safe if tuple(r['original_score'])==best_score}
        possible_buses=[b for b in cursor['raw_current_receiver_scope'] if cursor['positive_addition_lifetime_MVAr'].get(str(b),0)+25<=450]
        per_mode=[]
        for mode in ('objective','admissibility'):
            baseline,_=order(causal,before,cursor,[],mode)
            rank0=next(i+1 for i,r in enumerate(baseline) if r['universe_index'] in targets)
            single=[]
            for bus in possible_buses:
                ordered,valid=order(causal,before,cursor,[{'bus':bus,'q':25.}],mode)
                assert valid==[bus] and {r['universe_index'] for r in ordered}==set(lookup)
                rank=next(i+1 for i,r in enumerate(ordered) if r['universe_index'] in targets)
                single.append({'recipient':bus,'first_full_oracle_score_rank':rank})
            rank_bound=min([rank0]+[r['first_full_oracle_score_rank'] for r in single])
            # Concrete multi-group checks support the structural theorem; these
            # are not a subset selected to estimate model performance.
            for target in targets:
                bus=lookup[target]['receiver'];own,_=order(causal,before,cursor,[{'bus':bus,'q':25.}],mode)
                own_rank=next(i for i,r in enumerate(own) if r['universe_index']==target)
                extras=[b for b in possible_buses if b!=bus][:3]
                multi,_=order(causal,before,cursor,[{'bus':b,'q':25.} for b in [bus]+extras],mode)
                assert next(i for i,r in enumerate(multi) if r['universe_index']==target)>=own_rank
            per_mode.append({'mode':mode,'baseline_first_full_score_rank':rank0,'optimistic_best_possible_rank_with_at_most_four_groups':rank_bound,
                'all_single_group_possibilities':single,
                'all_K':[{'K':k,'baseline_full_score_inclusion':rank0<=k,'any_model_can_possibly_include_full_score':rank_bound<=k,
                          'scoped_impossible_for_this_role_on_this_root':rank_bound>k} for k in protocol['all_K']]})
        results.append({'world':entry['world'],'all_candidates':len(rows),'oracle_score_tied_candidate_ids':sorted(targets),'modes':per_mode})
    put(OUT/'Results.json',{'scope':protocol['scope'],'all_world_results':results,'new_scientific_calls':0,
        'live_model_outputs_read':0,'workflow_seconds':time.perf_counter()-begun,'theorem':protocol['theorem'],'limitations':protocol['limits']})
    print(json.dumps({'scoped_ceiling_complete':True,'new_model_PF_calls':0,'worlds':[{'world':w['world'],'ranks':[[m['mode'],m['baseline_first_full_score_rank'],m['optimistic_best_possible_rank_with_at_most_four_groups']] for m in w['modes']]} for w in results]}))
if __name__=='__main__':main()
