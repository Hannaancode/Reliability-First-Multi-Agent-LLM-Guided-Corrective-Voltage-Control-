# Confirmed-result figure captions

1. **Paired residual UV.** Comparison uses 60 finite paired outcomes from the frozen 62-case bank. Two disconnected-load cases remain invalid in the denominator and failure ledger. Counts reflect the original strict 0.95 threshold, not a new tolerance.
2. **Charged planning cost.** Each portfolio is charged for DFF plus its own second branch, including discarded trajectories and failed/invalid-case attempts. Storage reuse does not make DFF free. Wall times are the observed branch times on the campaign hardware; fixed branch order and runtime restoration limit general timing claims. Individual PF and generation durations were not separately recorded in this main run.
3. **Branches and portfolios.** Successful UV clearance means finite terminal metrics with zero original residual UV; it does not establish every operating constraint is satisfied. Independent audit found declared slack-limit violations in every locked case. Original raw OV counts and diagnostic boundary tolerance remain separately recorded.

Source: `main_campaign_detailed_audit.json`, the frozen matched protocol, per-case records, and the independent physical audit. These figures contain no central or full AC-reference conclusions.
