"""Repair only new prose spacing, heading breaks and table alignment."""
from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
import re,json
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_environment_contracts_20261029'
def main():
    path=O/'Hannaan_Thesis_Environment_Contracts.docx'
    d=Document(path);old=Document(R/'outputs/thesis_dse_and_public_diagnosis_20261028/Hannaan_Thesis_DSE_And_Public_Diagnosis.docx')
    known={re.sub(r'\t\d+$','',p.text) for p in old.paragraphs};changed=[]
    def spacing(s):
        s=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',s)
        s=s.replace('between−','between −').replace('0.95<VM<1.05','0.95 < VM < 1.05').replace('0.95≤VM≤1.05','0.95 ≤ VM ≤ 1.05')
        return s
    for p in d.paragraphs:
        if re.sub(r'\t\d+$','',p.text) in known:continue
        for run in p.runs:run.text=spacing(run.text)
        if p.style.name.startswith('Heading'):p.paragraph_format.keep_with_next=True
        changed.append(p.text)
    t=next(t for t in d.tables if t.cell(0,0).text=='Environment' and t.cell(0,1).text=='Permitted intervention')
    for i,row in enumerate(t.rows):
        for cell in row.cells:
            for p in cell.paragraphs:
                p.alignment=WD_ALIGN_PARAGRAPH.LEFT
                p.paragraph_format.keep_with_next=i<len(t.rows)-1
                for run in p.runs:run.text=spacing(run.text)
    d.save(path)
    (O/'Layout_Repair_Record.json').write_text(json.dumps({'new_paragraphs_touched':len(changed),'original_paragraphs_untouched':True,'changes':'Readable number/unit spacing; left-aligned new table kept together; new subheadings kept with following paragraph. No evidence or numerical threshold changed.'},indent=2)+'\n','utf-8')
if __name__=='__main__':main()
