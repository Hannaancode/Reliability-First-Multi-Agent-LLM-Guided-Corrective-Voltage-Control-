"""Separate residual attention updates. Existing modules/weights stay frozen.

This is software, not a production four-bit/PEFT loader. Explicit conditioning
must remain active through backward and checkpoint recomputation.
"""
import contextlib,weakref
import torch
from torch import nn

class ResidualLinear(nn.Module):
    def __init__(self,original,controller,site,in_features,out_features,rank):
        super().__init__();self.original=original;self.site=site;self.rank=rank
        self.controller=weakref.ref(controller)
        for p in original.parameters():p.requires_grad_(False)
        self.A=nn.Parameter(torch.empty(rank,in_features,dtype=torch.float32));nn.init.kaiming_uniform_(self.A,a=5**.5)
        self.B=nn.Parameter(torch.zeros(out_features,rank,dtype=torch.float32))
    def forward(self,x):
        owner=self.controller();assert owner is not None and owner.active is not None,'Explicit current-state context required through backward'
        result=self.original(x);gate=owner.active[self.site]
        delta=nn.functional.linear(nn.functional.linear(x.float(),self.A)*gate,self.B)
        return result+delta.to(result.dtype)

class CurrentConditionedResidualController(nn.Module):
    def __init__(self,state_width,sites,rank=8):
        super().__init__();self.sites=sites;self.rank=rank;self.active=None
        self.router=nn.Linear(state_width,sites*rank)
        nn.init.zeros_(self.router.weight);nn.init.zeros_(self.router.bias)
    @contextlib.contextmanager
    def condition(self,current_state,*,enabled=True):
        assert self.active is None,'Nested/concurrent contexts prohibited'
        assert current_state.ndim==1 and bool(torch.isfinite(current_state).all())
        self.active=(2*torch.sigmoid(self.router(current_state.float()))).reshape(self.sites,self.rank)
        if not enabled:self.active=self.active*0.
        try:yield
        finally:self.active=None
    def attach_qkv(self,model,*,expected_layers):
        sites=[]
        for name,module in list(model.named_modules()):
            if name.split('.')[-1] in {'q_proj','k_proj','v_proj'}:sites.append((name,module))
        assert len(sites)==self.sites==expected_layers*3
        assert {n.rsplit('.',1)[0] for n,_ in sites}.__len__()==expected_layers
        details=[]
        for j,(name,module) in enumerate(sites):
            parent_name,attribute=name.rsplit('.',1);parent=model.get_submodule(parent_name)
            in_size=module.in_features;out_size=module.out_features
            new=ResidualLinear(module,self,j,in_size,out_size,self.rank).to(next(model.parameters()).device)
            setattr(parent,attribute,new)
            details.append({'name':name,'in_features':in_size,'out_features':out_size,
                            'rank':self.rank,'new_parameters':self.rank*(in_size+out_size)})
        return details
    def enforce_original_freeze(self,model):
        # PEFT disable/restore can reactivate the existing adapter gradients.
        # Reapply explicit ownership after any such framework operation.
        selected={id(p) for m in model.modules() if isinstance(m,ResidualLinear) for p in (m.A,m.B)}
        for p in model.parameters():p.requires_grad_(id(p) in selected)
        actual=[p for p in model.parameters() if p.requires_grad]
        assert len(actual)==2*self.sites
        return sum(p.numel() for p in actual)
