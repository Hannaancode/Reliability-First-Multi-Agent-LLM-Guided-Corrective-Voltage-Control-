"""Check the new admission boundary on actual registered inputs; zero science."""
import csv
import hashlib
import json
import os
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from federation_benchmark_admission_20261022 import Task, Method, Outcome, admit, assess_pair, cohort_gate, Incomparable

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/federation_matched_benchmark_20261022'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def put(name, value):
    with (O / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())


def main():
    O.mkdir(exist_ok=False)
    cases_path = R / 'outputs/full_system_comparison_20261021/All203_Existing_Federation_Input_Cases.json'
    cases = json.loads(cases_path.read_text())
    assert len(cases) == len({c['case_id'] for c in cases}) == 203
    # The earlier complete registration deliberately records PENDING solved
    # roots. Correct behavior is to reject every one for performance today.
    blocked = []
    for c in cases:
        assert c['shared_initial_physical_state_digest'].startswith('PENDING')
        p = R / c['recipe']
        assert sha(p) == c['recipe_sha256']
        try:
            Task('0' * 64, c['shared_initial_physical_state_digest'], '1' * 64,
                 '2' * 64, '3' * 64, '4' * 64).validate()
        except Incomparable as e:
            blocked.append({'case_id': c['case_id'], 'recipe_sha256': c['recipe_sha256'],
                            'data_role': c['data_role'], 'reason': str(e)})
        else:
            raise AssertionError('Pending raw physical root wrongly admitted')
    assert len(blocked) == 203
    checks = []

    def ok(label, fn, expected):
        assert fn() == expected, label
        checks.append(label)

    def reject(label, fn):
        try:
            fn()
        except Incomparable:
            checks.append(label)
        else:
            raise AssertionError(label)

    # Explicit labelled synthetic fixtures; these are NOT measured plant states.
    t = Task(*[str(i) * 64 for i in range(6)])
    m = Method('fixture', 'named-test', t, '6' * 64, '7' * 64, True, True, t.plant_sha256, False, False, True)
    ok('complete synthetic registration is software-only', lambda: admit(t, m)['performance_execution_admitted'], False)
    reject('foreign13bus checkpoint cannot be native federation', lambda: admit(t, replace(m, source_plant_sha256='8' * 64)))
    ok('explicit retrained port remains registration-only', lambda: admit(t, replace(m, source_plant_sha256='8' * 64, named_retraining_or_port=True))['registration_only'], True)
    for field in ['plant_sha256', 'root_sha256', 'solver_contract_sha256', 'actuator_contract_sha256',
                  'observation_contract_sha256', 'protection_contract_sha256']:
        reject('reject changed ' + field, lambda field=field: admit(t, replace(m, task=replace(t, **{field: '9' * 64}))))
    reject('reject missing trained weights', lambda: admit(t, replace(m, checkpoint_sha256=None)))
    reject('reject no actual loader', lambda: admit(t, replace(m, actual_loaded=False)))
    reject('reject successor teacher exposure', lambda: admit(t, replace(m, teacher_or_test_leak=True)))
    reject('reject unverified cold cursor', lambda: admit(t, replace(m, cold_cursor_verified=False)))
    a = Outcome('synthetic', 'HG-SE', t, 'COMPLETE', 0, 0, True, True, ('DFF', 'HG-VF'), 'HG-SE')
    b = Outcome('synthetic', 'D-SE', t, 'COMPLETE', 1, 0, True, True, ('DFF', 'DFF-ALT'), 'D-SE')
    ok('safe zero UV primary comparison', lambda: assess_pair(a, b), 'LEFT_RESTORATION_WIN')
    ok('UV cleared with OV is not restoration', lambda: assess_pair(replace(a, residual_ov=2), b), 'NEITHER_RESTORED_REPORT_UV_OV_SEPARATELY')
    ok('partial evidence stays unknown', lambda: assess_pair(replace(a, status='PARTIAL'), b), 'UNKNOWN')
    ok('missing count stays unknown', lambda: assess_pair(replace(a, residual_uv=None), b), 'UNKNOWN')
    ok('missing cost stays unknown', lambda: assess_pair(replace(a, costs_complete=False), b), 'UNKNOWN')
    reject('HGSE must charge both branches', lambda: assess_pair(replace(a, charged_branches=('HG-VF',)), b))
    reject('DSE must charge both branches', lambda: assess_pair(a, replace(b, charged_branches=('DFF',))))
    reject('same seed different solved state rejected', lambda: assess_pair(a, replace(b, task=replace(t, root_sha256='a' * 64))))
    reject('Boolean zero not accepted', lambda: assess_pair(replace(a, residual_uv=False), b))
    ok('missing case never a selected complete cohort', lambda: cohort_gate(['synthetic', 'unentered'], [a]), 'UNKNOWN_INCOMPLETE_COHORT')
    reject('duplicate outcome cases rejected', lambda: cohort_gate(['synthetic'], [a, a]))
    ok('complete fixture is not superiority', lambda: cohort_gate(['synthetic'], [a]), 'COMPLETE_REQUIRED_EVIDENCE_PRESENT_NOT_A_SUPERIORITY_CLAIM')
    manifest = {str(p.relative_to(R)): sha(p) for p in [Path(__file__), R / 'work/federation_benchmark_admission_20261022.py', cases_path]}
    put('Actual203_Pending_Root_Rejections.json', blocked)
    put('Software_Admission_Readiness.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS_FAIL_CLOSED_COMMON_CASE_ADMISSION_SOFTWARE_ONLY', 'actual_recipes': 203,
        'actual_recipe_hashes_verified': 203, 'pending_raw_roots_rejected_before_execution': len(blocked),
        'labelled_synthetic_boundary_checks': checks, 'source_sha256': manifest,
        'performance_ready': False, 'new_model_PF_training_solver_GPU_calls': 0,
        'not_a_claim_all203_raw_roots_are_absent_everywhere': True,
        'next': 'Recover exact existing paid solved-root/cursor receipts and bind sources. Complete source-compatible external adaptations/actual model loader/cold persistent-state/independent-reader gates before one prospective campaign.'})
    print(json.dumps({'status': 'PASS_SOFTWARE_ADMISSION_ONLY', 'actual203blocked': len(blocked), 'labelled_boundary_checks': len(checks), 'new_science': 0}))


if __name__ == '__main__':
    main()
