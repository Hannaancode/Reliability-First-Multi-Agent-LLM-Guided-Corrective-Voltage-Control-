"""PF-free new reconstruction/readset gate. All held branch files stay unread.

Rebuild only physical inputs by original pure scenario/action primitives, then
compare saved native CURRENT vectors/metrics. No root solve, trial, conversion,
candidate search, derivative, model or fit. Never fabricate native voltages.
"""
import copy,hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone
import numpy as np,pandas as pd,pandapower as pp
from frozen_physics_loader import load_stack,AUDIT
from train_trajectory_measurement_nullable_v2 import safe,digest,EXCLUDED_COLUMNS
from trusted_causal_controller_snapshot import cap_totals
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/OPT_native_current_recipe_20261011'
PRIOR=ROOT/'outputs/critical_research_reset_20261010/later_fork_process_support_20261011/preparation/Protocol.json'
RAW=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3/protocol.json'
NET=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json';META=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
def read(p):return json.loads(p.read_text('utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(safe(v),f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def frame_payload(frame):
 columns=[c for c in frame.columns if c not in EXCLUDED_COLUMNS]
 return safe({'columns':[str(c) for c in columns],'index':frame.index.tolist(),'values':frame[columns].values.tolist()})
def main():
 OUT.mkdir(exist_ok=False);started=time.perf_counter();prior=read(PRIOR);raw=read(RAW)
 assert len(prior['latched_OPT_branches'])==46 and len(prior['optimization_world_sha256'])==23 and len(prior['declared_held_world_sha256_NOT_READ'])==8
 assert sha(NET)==raw['network_sha256'] and sha(META)==raw['metadata_sha256']
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'question':'Can original input recipes and saved exact native CURRENT support a cold native entry without repeating an old root PF?','resource_seconds':180,'source_sha256':sha(Path(__file__)),'source_dependency_sha256':{p:sha(ROOT/p) for p in ['work/frozen_physics_loader.py','work/train_trajectory_measurement_nullable_v2.py','work/trusted_causal_controller_snapshot.py']},'input_sha256':{'prior_support_protocol':sha(PRIOR),'raw_protocol':sha(RAW),'network':sha(NET),'metadata':sha(META)},'all31_declared_worlds_retained':[{'scenario_id':w['scenario_id'],'sha256':w['sha256']} for w in raw['worlds']],'retained_invalid_TRAIN_observation_ids':raw.get('retained_invalid_TRAIN_observation_ids',[]),'OPT23_only_branch_files':prior['latched_OPT_branches'],'held8_branch_files_NOT_READ':prior['declared_held_world_sha256_NOT_READ'],'scope':'PHYSICAL_INPUT_TABLES_EXACT_PLUS_ACTUAL_NATIVE_VOLTAGE_METRICS; NOT_FULL_OLD_CACHE_OR_RESULT_RESTORATION','fixed_gate':'EXACT_FIELDS_NATIVE_VECTOR_AND_SOURCE_SCOPE_OR_UNKNOWN; NO_AUTOMATIC_PHYSICS_TRAINING','planned_new_PF_model_converter_derivative_forecast_fit_cloud_calls':0,'allowance':'One network decode; original pure scenario application once per OPT world and pure action assembly once per saved committed edge. These are reconstruction operations, not new physics episodes.'}
 write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':'check_OPT_native_current_recipe_20261011.py','protocol_sha256':sha(OUT/'Protocol.json')})
 originals={k:getattr(pp,k) for k in ['runpp','rundcpp','runopp','runpp_3ph'] if hasattr(pp,k)};forbidden=[]
 def forbidden_solve(*a,**kw):forbidden.append('solver');raise BaseException('Forbidden solver entry during reconstruction')
 for key in originals:setattr(pp,key,forbidden_solve)
 counts={'network_decode':0,'scenario_recipe_applications':0,'action_recipe_applications':0,'branch_files_read':0,'current_vectors_restored_for_comparison':0,'pure_source_metric_evaluations':0,'pure_source_scope_evaluations':0}
 rows=[];identities=[]
 try:
  v2,runner,reflection=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
  base=pp.from_json(str(NET));counts['network_decode']+=1;zones={k:[int(b) for b in v] for k,v in read(META)['zones'].items()};assert not base.get('user_pf_options',{})
  worldmap={w['sha256']:w for w in raw['worlds']};cases={}
  for info in prior['latched_OPT_branches']:
   assert time.perf_counter()-started<180,'Resource bound; do not extend or rerun'
   path=ROOT/info['path'];assert sha(path)==info['sha256'];branch=read(path);counts['branch_files_read']+=1
   world=worldmap[info['world_sha256']];identities.append({'branch':info['branch'],'world_sha256':info['world_sha256'],'path':info['path'],'sha256':info['sha256']})
   assert branch['scenario_sha256']==info['world_sha256'] and branch['scenario_id']==world['scenario_id'] and branch['branch']==info['branch']
   if info['world_sha256'] not in cases:
    sp=ROOT/world['path'];assert sha(sp)==world['sha256'];scenario=read(sp)
    cases[info['world_sha256']]=v2.v0.apply_scenario_to_net(copy.deepcopy(base),scenario,zones);counts['scenario_recipe_applications']+=1
   net=copy.deepcopy(cases[info['world_sha256']]);initial_cap=cap_totals(net)
   observations=branch.get('observations') or [];actions=branch['result']['executed_actions'];native={s['decision']:s for s in branch.get('actual_partial_solved_states',[])}
   assert [o['decision'] for o in observations]==list(range(len(observations))) and len(observations)==len(actions)+1
   for index,o in enumerate(observations):
    assert time.perf_counter()-started<180,'Resource bound; do not extend or rerun'
    if index:
     a=actions[index-1];assert a['iteration']==index and o['committed_action']==a['action']
     runner.rescue.apply_action(net,a['action']);counts['action_recipe_applications']+=1
    obs=o['input_observation'];assert digest(obs)==o['observation_sha256']
    mismatched=[]
    for table,expected in obs['physical_tables'].items():
     if table.startswith('res_'):continue
     if table not in net or frame_payload(net[table])!=expected:mismatched.append(table)
    # Network-only input types absent from observation are unchanged originals.
    omitted_nonempty_inputs=[table for table in ['dcline','motor','asymmetric_load','asymmetric_sgen','storage','ward','xward','svc','ssc','tcsc','vsc','line_dc','bus_dc','source_dc'] if table in net and len(net[table])]
    n=native.get(index);reason=[]
    if mismatched:reason.append('PHYSICAL_INPUT_MISMATCH:'+','.join(mismatched))
    if omitted_nonempty_inputs:reason.append('UNOBSERVED_NONEMPTY_INPUTS:'+','.join(omitted_nonempty_inputs))
    exact_metrics=False;exact_scope=False;native_vector_sha=None;counts_native=False
    if n is None:reason.append('MISSING_ACTUAL_NATIVE_VECTOR_NOT_REPLACED_BY_REPLAY')
    else:
     expected_action=None if index==0 else actions[index-1]['action'];assert n['action']==expected_action
     vector=n['vm_pu'];assert set(vector)=={str(int(b)) for b in net.bus.index} and all(np.isfinite(float(v)) for v in vector.values())
     current=copy.deepcopy(net);current.res_bus=pd.DataFrame({'vm_pu':[float(vector[str(int(b))]) for b in net.bus.index]},index=net.bus.index)
     counts['current_vectors_restored_for_comparison']+=1;actual=runner.rescue.grid_metrics(current);counts['pure_source_metric_evaluations']+=1
     exact_metrics=actual==n['metrics'];native_vector_sha=digest(vector);counts_native=int(actual['uv_count'])
     reports={z:runner.rescue.extract_zone_state_full(current,z,zones) for z in sorted(zones)}
     common=runner.rescue.candidate_buses_from_state(current,zones,reports,[])
     zonal={z:runner.get_zone_candidate_buses(current,z,zones,reports[z]) for z in sorted(zones)};counts['pure_source_scope_evaluations']+=1
     exact_scope=common==obs['literal_fallback_bus_pool'] and safe(zonal)==obs['raw_zonal_bus_pools'] and safe({z:[b for b in common if b in zonal[z]] for z in zonal})==obs['raw_common_and_zone_pools']
     if not exact_metrics:reason.append('NATIVE_METRIC_ARITHMETIC_NOT_EXACT')
     if not exact_scope:reason.append('RAW_SCOPE_REPLAY_NATIVE_DISAGREEMENT')
    derived_cap=copy.deepcopy(initial_cap)
    for action in actions[:index]:
     for bus,q in action['action']['add_shunts_q_mvar'].items():derived_cap[str(int(bus))]=derived_cap.get(str(int(bus)),0.)+abs(float(q))
    assert cap_totals(net)==derived_cap
    row={'world_sha256':info['world_sha256'],'scenario_id':world['scenario_id'],'branch':info['branch'],'after_commit':index,'observation_sha256':o['observation_sha256'],'recipe_physical_inputs_exact':not mismatched,'unobserved_nonempty_inputs':omitted_nonempty_inputs,'actual_native_vector_present':n is not None,'native_metric_exact':exact_metrics,'native_scope_exact':exact_scope,'native_vector_sha256':native_vector_sha,'named_shunt_cap_totals':derived_cap,'source_remaining_slots':max(25-index,0),'entry_field_gate':'EXACT_INPUT_AND_NATIVE_CURRENT_READSET' if not reason else 'UNKNOWN','unknown_reasons':reason,'healthy_native_CURRENT':counts_native==0 if n else None,'not_a_new_physical_trajectory':True,'not_actual_full_snapshot_resume_certificate':True}
    rows.append(row)
 finally:
  for key,value in originals.items():setattr(pp,key,value)
 assert not forbidden and counts['branch_files_read']==46 and len(cases)==23 and len(identities)==46
 summary={'all31_world_ids_retained':True,'OPT_worlds_examined':23,'held_worlds_outcomes_unread':8,'OPT_branch_inputs_examined':46,'current_occurrences_retained':len(rows),'entry_readset_exact_count':sum(r['entry_field_gate']=='EXACT_INPUT_AND_NATIVE_CURRENT_READSET' for r in rows),'unknown_count':sum(r['entry_field_gate']=='UNKNOWN' for r in rows),'unknown_reason_counts':{reason:sum(reason in r['unknown_reasons'] for r in rows) for reason in sorted({x for r in rows for x in r['unknown_reasons']})},'all_cap_accounting_exact':True,'new_PF_converter_model_optimizer_fit_forecast_derivative_cloud_calls':0,'actual_pure_data_operations':counts,'source_closure':AUDIT,'workflow_seconds_before_report_manifest':time.perf_counter()-started,'physical_or_LLM_advantage':'UNMEASURED','no_automatic_performance_launch':True,'whole_historical_pipeline_actual_resume':'NOT_CERTIFIED; readset reconstruction only'}
 write(OUT/'All_Current_Readset_Records.json',rows);write(OUT/'Branch_Input_Identities.json',identities);write(OUT/'Results.json',summary)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
 print(json.dumps({k:v for k,v in summary.items() if k not in ['source_closure','actual_pure_data_operations']}))
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'exception':type(exc).__name__,'message':str(exc),'state':'TERMINAL_PF_FREE_RECIPE_PARTIAL_NO_AUTOMATIC_RETRY','new_actual_scientific_calls':0})
  raise
