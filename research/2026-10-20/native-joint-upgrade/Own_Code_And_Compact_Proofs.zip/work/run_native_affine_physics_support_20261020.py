"""ALL24 fixed affine proposals, one native PF if genuinely unexecuted; typed guards, no model or actual commit."""
import json,hashlib,pickle,time,os,copy
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_affine_physics_preparation_20261020';OUT=ROOT/'outputs/native_affine_physics_support_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def binary(p,v):
    with p.open('xb') as f:pickle.dump(v,f,protocol=5);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from pandapower.pypower.makeSbus import makeSbus
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'));costs={k:0 for k in ['PF_attempts','PF_returns','PF_exceptions','exact_paid_reuses','different_initializer_unknown']};costs['model_derivative_factor_LP_GPU_training_actual_commit_calls']=0
    for n,h in {**p['sources'],**p['inputs']}.items():assert sha(ROOT/n)==h
    put(OUT/'Frozen_Before.json',frozen_checks());graph=np.load(ROOT/p['graph']);history=json.loads((PREP/'Relevant_Paid_Inputs.json').read_text(encoding='utf-8'));exact={(r['signature'],json.dumps(r['kwargs'],sort_keys=True)):r for r in history['all114_returned_queries']};known={r['signature'] for r in history['all114_returned_queries']};rows=[];events=(OUT/'events.jsonl').open('x',encoding='utf-8');previous='0'*64
    def event(kind,**data):
        nonlocal previous
        assert time.monotonic()-start<p['worker_seconds'];v={'kind':kind,'elapsed_seconds':time.monotonic()-start,'previous':previous,**data};h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest();events.write(json.dumps({'event':v,'sha256':h})+'\n');events.flush();os.fsync(events.fileno());previous=h
    try:
        for i,ctx in enumerate(p['all24contexts']):
            directory=OUT/f'context_{i:02d}';directory.mkdir();row={'context':i,'seed':ctx['seed'],'algorithm':ctx['algorithm'],'status':'UNKNOWN'};rows.append(row)
            try:
                with (ROOT/ctx['original_NET']).open('rb') as f:original=pickle.load(f)
                with (ROOT/ctx['candidate_NET']).open('rb') as f:net=pickle.load(f)
                before_vm=original.res_bus.vm_pu.to_numpy(copy=True);before_uv=int((before_vm<.95).sum());before_ov=int((before_vm>1.05).sum());sig=signature(net);kwargs={'algorithm':'bfsw','init':'dc'};key=(sig,json.dumps(kwargs,sort_keys=True));binary(directory/'Candidate_Before.pkl',net);row.update(before_UV=before_uv,before_OV=before_ov,physical_signature=sig,kwargs=kwargs)
                if key in exact:
                    source=exact[key];costs['exact_paid_reuses']+=1
                    with (ROOT/source['after_NET']).open('rb') as f:net=pickle.load(f)
                    row.update(paid_reuse=source);event('exact_paid_native_identity_reused',context=i,signature=sig)
                elif sig in known:
                    costs['different_initializer_unknown']+=1;row['unknown_reason']='Exactphysicalinputpreviouslypaidwithdifferentinitializer;noanotherPForsilentcache';put(directory/'Result.json',row);continue
                else:
                    costs['PF_attempts']+=1;event('PF_attempt',context=i,before_sha256=sha(directory/'Candidate_Before.pkl'),signature=sig,kwargs=kwargs);t=time.monotonic()
                    try:b.pp.runpp(net,**kwargs)
                    except BaseException as exc:costs['PF_exceptions']+=1;row.update(status='UNKNOWN_SCIENTIFIC_EXCEPTION',failure_type=type(exc).__name__);event('PF_exception',context=i,type=type(exc).__name__,seconds=time.monotonic()-t);put(directory/'Result.json',row);continue
                    costs['PF_returns']+=1;row['paid_reuse']=None;event('PF_return',context=i,seconds=time.monotonic()-t)
                assert net.converged and signature(net)==sig;pp=net._ppc;assert np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]]) and pp['baseMVA']==float(graph['baseMVA']);v=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));s=makeSbus(pp['baseMVA'],pp['bus'],pp['gen']);kcl=float(np.max(np.abs(v*np.conj(graph['Y']@v)-s)));assert kcl<=1e-7
                binary(directory/'Candidate_After.pkl',net);fields={n:net[n].select_dtypes(include=[np.number]).to_numpy(dtype=float) for n in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};np.savez(directory/'Fields.npz',**fields);vm=net.res_bus.vm_pu.to_numpy(copy=True);assert np.isfinite(vm).all();uv=int((vm<.95).sum());ov=int((vm>1.05).sum());protected=(before_vm>=.95)&(before_vm<=1.05);guard=bool(np.all(vm[protected]>=.95-1e-8)&np.all(vm[protected]<=1.05+1e-8));accepted=guard and uv<=before_uv and ov<=before_ov
                row.update(status='RETURNED_REUSED' if row['paid_reuse'] else 'RETURNED_NEW',actual_vm=vm.tolist(),after_UV=uv,after_OV=ov,vmin=float(vm.min()),vmax=float(vm.max()),normal_band_guard=guard,no_new_UV_OV=bool(uv<=before_uv and ov<=before_ov),typed_proposal_accepted=bool(accepted),actual_commit=False,all13_restored_if_accepted=bool(accepted and uv==ov==0),effective_UV=uv if accepted else before_uv,effective_OV=ov if accepted else before_ov,KCL_pu=kcl,absolute_native_Q=net.sgen.q_mvar.to_numpy()[:3].tolist());put(directory/'Result.json',row)
                if row['paid_reuse'] is None:exact[key]={'signature':sig,'kwargs':kwargs,'after_NET':(directory/'Candidate_After.pkl').relative_to(ROOT).as_posix(),'reference':'NEW_CURRENT_STUDY_PAID_ONCE'};known.add(sig)
            except BaseException as exc:row.update(status='UNKNOWN_ANALYSIS_OR_PRESERVATION_FAILURE',failure_type=type(exc).__name__,failure=str(exc));put(directory/'Failure.json',row)
        complete=all(r['status'] in ['RETURNED_NEW','RETURNED_REUSED'] for r in rows);improved_worlds=sorted({r['seed'] for r in rows if r.get('typed_proposal_accepted') and r['before_UV']+r['before_OV']>r['effective_UV']+r['effective_OV']});gate='LIMITED_NATIVE_PHYSICAL_OPPORTUNITY_SUPPORT_ONLY' if complete and len(improved_worlds)>=2 else 'FAILED_FIXED_SINGLE_STEP_OPPORTUNITY_SCREEN' if complete else 'UNKNOWN_PARTIAL_PHYSICAL_EVIDENCE'
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_DECLARED24_SINGLE_CANDIDATE_PHYSICAL_SUPPORT' if complete else 'TERMINAL_PARTIAL_DECLARED24_PHYSICAL_SUPPORT','all24contexts':rows,'costs':costs,'improved_development_worlds':improved_worlds,'fixed_gate':gate,'not_matched_trajectory_or_model_superiority':'Extraone-stepcentralizednumericalinterventionfrompublishedterminalstates,not source-nativebaselineorwholepolicy/LLMwin. All24statesretained;otheractorcontinuationsnotmeasured. Strongmatchedcommon-goalcontrols/fullcost/actualnativetraining/unusedconfirmationremain.','workflow_seconds':time.monotonic()-start,'no_automatic_training_or_physics_retry':True};put(OUT/'Result.json',result);put(OUT/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(OUT/'Result.json'));events.close();put(OUT/'Closed_Manifest.json',{'files':[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()],'journal_last_sha256':previous});print(result['status'],gate,costs)
    except BaseException as exc:put(OUT/'Failure.json',{'type':type(exc).__name__,'failure':str(exc),'costs':costs,'rows':rows});events.close();raise
if __name__=='__main__':main()
