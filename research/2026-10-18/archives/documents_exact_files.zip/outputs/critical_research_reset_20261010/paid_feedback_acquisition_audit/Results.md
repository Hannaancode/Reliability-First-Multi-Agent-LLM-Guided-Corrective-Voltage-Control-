Saved-only numerical acquisition screen; all historic OPT inputs retained. No new physical episode or LLM value demonstrated. Candidate residual estimates and reader policy re-evaluation are actual charged numerical arithmetic. All original labels, native forecast/preparation and failure costs remain separate and paid. Conditional oracle metrics and all-input missing-evidence bounds are development evidence, not unused confirmation or statistical confidence intervals.

{
  "K8": {
    "old_static": {
      "K8_equal_world_lower": 0.36658493022129385,
      "K8_equal_world_upper": 0.9363162090434817,
      "recorded_oracle_states": 176,
      "K8_known_hits": 62,
      "all_input_equal_world_bounds": [
        0.2793710730995285,
        0.9530856037472294
      ],
      "query_outcomes": {
        "known_accepted": 465,
        "known_rejected": 191,
        "UNKNOWN_unmeasured": 192
      }
    },
    "candidate_static": {
      "K8_equal_world_lower": 0.34203372385190567,
      "K8_equal_world_upper": 0.9117650026740935,
      "recorded_oracle_states": 176,
      "K8_known_hits": 54,
      "all_input_equal_world_bounds": [
        0.25857212829302234,
        0.9322866589407232
      ],
      "query_outcomes": {
        "known_accepted": 526,
        "known_rejected": 130,
        "UNKNOWN_unmeasured": 192
      }
    },
    "old_feedback": {
      "K8_equal_world_lower": 0.28389993844539296,
      "K8_equal_world_upper": 0.853631217267581,
      "recorded_oracle_states": 176,
      "K8_known_hits": 48,
      "all_input_equal_world_bounds": [
        0.22080462503013376,
        0.8945191556778347
      ],
      "query_outcomes": {
        "known_accepted": 430,
        "known_rejected": 226,
        "UNKNOWN_unmeasured": 192
      }
    },
    "candidate_feedback": {
      "K8_equal_world_lower": 0.35502073683891866,
      "K8_equal_world_upper": 0.9247520156611067,
      "recorded_oracle_states": 176,
      "K8_known_hits": 54,
      "all_input_equal_world_bounds": [
        0.2653774212986934,
        0.9390919519463943
      ],
      "query_outcomes": {
        "known_accepted": 521,
        "known_rejected": 135,
        "UNKNOWN_unmeasured": 186
      }
    }
  },
  "gates": {
    "fixed_K8_headroom_upper": 0.6334150697787062,
    "five_point_headroom_possible": true,
    "numerical_feedback_mechanism_gate": {
      "old_feedback": {
        "conservative_equal_world_deltas": {
          "old_static": -0.6524162705980887,
          "candidate_static": -0.6278650642287006
        },
        "strictly_positive_worlds": {
          "old_static": 0,
          "candidate_static": 0
        },
        "passed": false
      },
      "candidate_feedback": {
        "conservative_equal_world_deltas": {
          "old_static": -0.581295472204563,
          "candidate_static": -0.5567442658351749
        },
        "strictly_positive_worlds": {
          "old_static": 0,
          "candidate_static": 0
        },
        "passed": false
      }
    },
    "economic_gate": "UNKNOWN_per_query_physical_and_new_LLM_costs_unmeasured",
    "LLM_method_gate": "NOT_ESTABLISHED_no_language_or_trained_acquisition_control",
    "automatic_GPU_training_or_physical_launch": false,
    "not_a_universal_failure_or99percent_success_proof": true,
    "decision": "Proceed only to further justified mechanism/strong-trained-control design if support warrants it; do not launch an LLM from saved-replay counts or headroom alone."
  },
  "actual_screen_costs": {
    "closed_at_utc": "2026-10-10T08:49:41.824271+00:00",
    "scientific_status": "terminal_partial_saved_replay",
    "all239_input_identities_four_policies_retained": true,
    "costs": {
      "journal_events": 15347,
      "prior_record_files_read": 341,
      "prior_native_arm_records": 77002,
      "unavailable_prior_records": 178,
      "policy_attempts": 3386,
      "candidate_priority_evaluations": 492775,
      "policy_returns": 3386,
      "saved_query_attempts": 3386,
      "saved_query_returns": 3386,
      "saved_API_events": 3809,
      "saved_receipt_lookups": 3386,
      "saved_successor_lookups": 282,
      "interpolated_metric_estimates": 83000
    },
    "workflow_seconds_before_final_checks_seal": 639.9672982001211,
    "actual_new_pretrained_model_optimizer_nonlinear_PF_native_affine_forecast_linear_solve_controller_cloud_calls": 0,
    "residual_metric_estimate_and_priority_arithmetic_charged": true,
    "deployment_query_cost_and_latency": null,
    "old_labels_forecasts_and_preparation_still_paid": true,
    "historical_OPT_development_not_confirmation": true,
    "no_held_performance_or_automatic_LLM_launch": true,
    "protocol_sha256": "f1099209b6e5142f93672d11ce874e4050f69ce04aafb11ee71a8866f7332d60"
  },
  "reader": {
    "all_passed": true,
    "exact_cases": 956,
    "all239_inputs_23_worlds_72_held_blocked": true,
    "actual_saved_query_trace_checks": 3386,
    "unsafe_or_unqueried_commits": 0,
    "original_pure_score_source_sha256": "6e2f33faf63c3e6d314680455f478e63102f6361453b43c9a454022a832b84ed",
    "all_original_frozen_preserved": true,
    "query_order_uses_frozen_policy_not_independently_implemented_interpolation": true,
    "new_reader_model_PF_optimizer_native_forecast_linear_solve_calls": 0,
    "reader_policy_priority_and_metric_arithmetic": {
      "candidate_priority_evaluations": 492775,
      "interpolated_metric_estimates": 83000
    },
    "reader_seconds_before_seal": 273.99565269984305,
    "source_lookup_software_calls": 3386
  }
}
