"""Independent full-network complex-admittance check, all16 encodings retained."""
import json,time,copy,hashlib
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
BASE=R/'outputs/pglearn_fixed_test_prefix_20261019';B=BASE/'independent_complex_audit_v2';TOL=5e-6
def check(data,p):
    n=int(data['N']);e=int(data['E']);assert (n,e,int(data['G']))==(118,186,54)
    a=lambda k:np.asarray(data[k],float);v=np.asarray(p['vm'])*np.exp(1j*np.asarray(p['va']));fr=np.asarray(data['bus_fr'],int)-1;to=np.asarray(data['bus_to'],int)-1;s=a('branch_status')
    ff=s*(a('gff')+1j*a('bff'));ft=s*(a('gft')+1j*a('bft'));tf=s*(a('gtf')+1j*a('btf'));tt=s*(a('gtt')+1j*a('btt'))
    Y=np.diag(a('gs')+1j*a('bs'));np.add.at(Y,(fr,fr),ff);np.add.at(Y,(fr,to),ft);np.add.at(Y,(to,fr),tf);np.add.at(Y,(to,to),tt)
    gen=np.zeros(n,complex);load=np.zeros(n,complex)
    for bus in range(n):
        for idx in data['bus_gens'][bus]:gen[bus]+=a('gen_status')[idx-1]*(p['pg'][idx-1]+1j*p['qg'][idx-1])
        for idx in data['bus_loads'][bus]:load[bus]+=data['pd'][idx-1]+1j*data['qd'][idx-1]
    mismatch=gen-load-v*np.conj(Y@v);sf=v[fr]*np.conj(ff*v[fr]+ft*v[to]);st=v[to]*np.conj(tf*v[fr]+tt*v[to])
    residual={'nodal_active_pu':float(np.max(abs(mismatch.real))),'nodal_reactive_pu':float(np.max(abs(mismatch.imag))),'complex_from_flow_pu':float(np.max(abs(sf-(np.asarray(p['pf'])+1j*np.asarray(p['qf']))))),'complex_to_flow_pu':float(np.max(abs(st-(np.asarray(p['pt'])+1j*np.asarray(p['qt'])))))}
    positive=lambda x:float(np.maximum(np.asarray(x),0).max());vm=np.asarray(p['vm']);va=np.asarray(p['va']);gs=a('gen_status')
    for q in ('pg','qg'):
        residual[q+'_lower']=positive(gs*a(q+'min')-p[q]);residual[q+'_upper']=positive(np.asarray(p[q])-gs*a(q+'max'))
    residual.update(vm_lower=positive(a('vmin')-vm),vm_upper=positive(vm-a('vmax')),angle_lower=positive(a('dvamin')-s*(va[fr]-va[to])),angle_upper=positive(s*(va[fr]-va[to])-a('dvamax')),thermal_from_squared=positive(np.asarray(p['pf'])**2+np.asarray(p['qf'])**2-a('smax')**2),thermal_to_squared=positive(np.asarray(p['pt'])**2+np.asarray(p['qt'])**2-a('smax')**2),slack_angle=abs(float(va[int(data['ref_bus'])-1])))
    return {'all_constraints_pass':all(v<=TOL for v in residual.values()),'residuals':residual}
def main():
    B.mkdir(exist_ok=False);start=time.perf_counter();put(B/'Protocol.json',{'status':'FROZEN_SEPARATE_COMPLEX_NETWORK_READER','created_utc':datetime.now(timezone.utc).isoformat(),'all16_indices':list(range(16)),'tolerance':TOL,'source_sha256':sha(__file__),'old_math_reader_sha256':sha(R/'work/audit_pglearn_fixed16_native_equations_v2_20261019.py'),'old_results_sha256':sha(BASE/'native_equation_audit_v2/Results.json'),'input_manifest_sha256':sha(BASE/'fixed16/Input_Manifest.json'),'new_PF_model_optimizer_solver_calls':0,'claims':'All-source-data native feasibility only; not global optimality or our-model control performance.'})
    result=[];info=read(BASE/'fixed16/Input_Manifest.json');old=read(BASE/'native_equation_audit_v2/Results.json')
    for i,meta in enumerate(info['rows']):
        path=BASE/'fixed16'/f'row_{i:04}.json';assert sha(path)==meta['row_sha256'];row=read(path);raw=json.loads(row['case/json']);data=raw['data'];p=raw['ACOPF']['primal'];reference=check(data,p)
        assert reference['all_constraints_pass']==old['rows'][i]['original_case_json']['all_declared_native_constraints_at_fixed_tolerance']
        sampled=copy.deepcopy(data)
        for k in ('pd','qd','gen_status','branch_status'):sampled[k]=row['input/'+k]
        sample=check(sampled,{k:row['ACOPF/primal/'+k] for k in p})
        same=all(np.array_equal(np.asarray(v,dtype=np.float32),np.asarray(row['ACOPF/primal/'+k],dtype=np.float32)) for k,v in p.items())
        result.append({'index':i,'static_base_case_json':reference,'sampled_test_columns':sample,'case_json_sha256':hashlib.sha256(row['case/json'].encode()).hexdigest(),'provider_input_seed':row['input/seed'],'provider_AC_seed':row['ACOPF/meta/seed'],'sample_exactly_rounding_of_base':same,'role':'Static base-case reference JSON and distinct sampled input/solution columns; never substitute base labels for test-row labels.'})
    assert len(result)==16;put(B/'Independent_Audit.json',{'status':'PASS_ALL16_SEMANTIC_SEPARATION_BASE_REFERENCE_VS_SAMPLED_TEST_ROWS','unique_base_reference_count':len({x['case_json_sha256'] for x in result}),'base_reference_feasible':all(x['static_base_case_json']['all_constraints_pass'] for x in result),'sampled_test_rows_strict_native_pass_count':sum(x['sampled_test_columns']['all_constraints_pass'] for x in result),'rows':result,'tolerance':TOL,'prior_float32_native_pass_count_retained':old['parquet_native_gate_passes'],'new_PF_OPF_LLM_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-start,'model_test':'NOT_EXECUTED','readiness_limit':'Original control/parser/actuator/public loader/native reference/protection/zone adaptation still needs prospective fidelity; no public LLM/DSE superiority follows.'});manifest(B);print(json.dumps({'provider_test_rows_intaken':16,'distinct_base_reference_count':len({x['case_json_sha256'] for x in result}),'base_reference_feasible':True,'sampled_test_native_passes':sum(x['sampled_test_columns']['all_constraints_pass'] for x in result),'new_scientific_calls':0}))
if __name__=='__main__':main()
