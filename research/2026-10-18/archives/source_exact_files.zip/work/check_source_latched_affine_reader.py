"""Synthetic saved-step reader/alteration rejection; no performance calls."""
from pathlib import Path
import gzip,json,time
import numpy as np
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
import audit_source_latched_affine_control as reader
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';OUT=P/'source_latched_affine_reader_readiness'
assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
with gzip.open(P/'measured_OPT_transition_inventory/Actual_OPT_Transition_Rows.jsonl.gz','rt',encoding='utf8') as f:ts=sorted([json.loads(l) for l in f],key=lambda r:r['transition_id'])
t=ts[0];h=t['before_observation_sha256'];tables=t['model_input']['current_physical_observation']['physical_tables']
with np.load(P/'observed_constraint_affine_diagnostic/states'/(h+'.npz')) as z:saved={k:z[k] for k in z.files}
c=reader.reader_context(saved,tables,{'bus':t['model_input']['candidate_action']['bus'],'q_abs_mvar':0.},False)
labs=read(P/'OPT_generator_bound_event_inventory/Actual_Generator_Bound_Records.json');r=next(r for r in labs if r['transition_id']==t['transition_id'])
mask={m['native_gen_id']:m['before_nominal_occupancy'] for m in r['generator_measurements']}
J,b,nr,free,known,kd=reader.reconstruct(c,mask);x=np.zeros(len(b));dm=np.zeros(118);dm[known]=kd;da=np.zeros(118)
qdelta=(c['deltaS']+c['m']@dm).imag*c['base'];qg={i:c['gres'][i]['q_mvar']+float(qdelta[c['mapping'][g['bus']]]) for i,g in c['gen'].items()}
updates={i:('near_max' if qg[i]>g['max_q_mvar'] else 'near_min') for i,g in c['gen'].items() if mask[i]=='interior' and (qg[i]>g['max_q_mvar'] or qg[i]<g['min_q_mvar'])}
record={'mask':mask,'qgen':qg,'updates':updates,'bound_count':sum(v!='interior' for v in mask.values())}
arrays={'J':J,'rhs':b,'x':x,'vm':(np.abs(c['V'])+dm)[c['mapping']],'dvm':dm,'dva':da}
reader.verify_saved_step(c,record,arrays);checks=['source_current_zero_step_roundtrip']
for name in ('J','rhs','x','vm'):
    bad={k:v.copy() for k,v in arrays.items()};bad[name].flat[0]+=.123
    try:reader.verify_saved_step(c,record,bad)
    except AssertionError:checks.append('altered_'+name+'_rejected')
    else:raise AssertionError('Bad reader accepted '+name)
bad=dict(record);bad['qgen']=dict(qg);bad['qgen'][next(iter(qg))]+=.123
try:reader.verify_saved_step(c,bad,arrays)
except AssertionError:checks.append('altered_qgen_rejected')
else:raise AssertionError('Bad Q accepted')
bad=dict(record);bad['updates']={next(iter(mask)):'near_max'}
try:reader.verify_saved_step(c,bad,arrays)
except AssertionError:checks.append('altered_update_rejected')
else:raise AssertionError('Bad update accepted')
proof={'all7_saved_step_reader_checks_passed':len(checks)==7,'checks':checks,'reader_source_sha256':sha(Path(reader.__file__)),
 'actual_new_dense_derivative_evaluations':1,'actual_new_linear_solves_PF_model_optimizer_cloud_calls':0,
 'synthetic_zero_step_not_numerical_task_or_learned_performance':True,'elapsed_seconds':time.perf_counter()-start}
write(OUT/'External_Reader_Readiness.json',proof);files={'External_Reader_Readiness.json':OUT/'External_Reader_Readiness.json',
 'source/readiness.py':Path(__file__),'source/reader.py':Path(reader.__file__)}
archive=seal(OUT,files,'Source_Latched_Independent_Reader_Readiness.zip');print(json.dumps({'readiness':proof,'archive':archive}))
