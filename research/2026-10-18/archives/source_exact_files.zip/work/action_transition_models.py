"""NEW current/action/AC-response numerical controls and shared frontend.

No pretrained contextual body, PF, cloud API, targets or audit identifiers are
accepted here. The fixed schema buffer is a separately charged public lookup.
All numerical projections participate in forward; capacity is chosen analytically.
"""
import torch
from torch import nn
from vcsa_common_information_control import ByteEncoder
from relational_decision_interface import EXPECTED_INPUTS
from candidate_predictor_input_contract import Q_GRID

EXPECTED={'row_input','candidate_bus','q_abs_mvar','AC_direction_per_MVAr'}
LORA_R4_PARAMETERS=2199552

class TransitionFrontend(nn.Module):
    def __init__(self,schema_embeddings,tables,hidden=896):
        super().__init__();assert schema_embeddings.ndim==2 and schema_embeddings.shape[1]==896
        self.hidden=hidden
        self.register_buffer('fixed_schema_embeddings',schema_embeddings.detach().float().clone())
        self.field=nn.Linear(896,24);self.text=ByteEncoder()
        self.cell=nn.Sequential(nn.Linear(66,64),nn.Tanh(),nn.Linear(64,64),nn.LayerNorm(64))
        self.table=nn.Embedding(tables+1,16);self.role=nn.Embedding(3,8);self.bus=nn.Embedding(119,16)
        self.row=nn.Sequential(nn.Linear(123,128),nn.Tanh(),nn.LayerNorm(128))
        self.action=nn.Sequential(nn.Linear(130,128),nn.Tanh(),nn.LayerNorm(128))
        self.AC_direction=nn.Linear(1,128,bias=False)
        self.to_body=nn.Linear(128,hidden);self.body_norm=nn.LayerNorm(hidden)
        self.output=nn.Sequential(nn.Linear(hidden,64),nn.Tanh(),nn.Linear(64,1))

    def encode(self,x):
        if set(x)!=EXPECTED:raise ValueError('Current/action/analytic fields only; targets and audit IDs forbidden')
        a=x['row_input']
        if set(a)!=EXPECTED_INPUTS:raise ValueError('Exact lossless current compiler fields')
        b=x['candidate_bus'];q=x['q_abs_mvar'];grid=a['original_Q_grid']
        if tuple(grid)!=Q_GRID or type(b) is not int or not 0<=b<118 or q not in grid:raise ValueError('Native candidate/original Q')
        if not a['allowed_actions'][b][grid.index(q)]:raise ValueError('Raw common AND zone scope/cap')
        dev=next(self.parameters()).device
        tensor=lambda k,dtype:torch.as_tensor(a[k],device=dev,dtype=dtype)
        ids=tensor('field_ids',torch.long);num=tensor('numeric',torch.float32)
        kinds=nn.functional.one_hot(tensor('kind_ids',torch.long),7).float()
        text=num.new_zeros((len(ids),32));present=[i for i,v in enumerate(a['value_bytes']) if v]
        if present:text=text.index_copy(0,torch.tensor(present,device=dev),self.text([a['value_bytes'][i] for i in present],dev))
        fields=self.field(self.fixed_schema_embeddings[ids])
        cells=self.cell(torch.cat([fields,text,kinds,num],-1));n=len(a['token_roles'])
        slots=tensor('cell_token_ids',torch.long);counts=torch.bincount(slots,minlength=n).float()[:,None]
        if not bool((counts>0).all()):raise ValueError('Every current row must retain its typed cells')
        pooled=cells.new_zeros((n,64)).index_add(0,slots,cells)/counts
        ends=tensor('token_bus_ends',torch.long)+1
        if not bool(((0<=ends)&(ends<=118)).all()):raise ValueError('Native endpoints')
        row=self.row(torch.cat([pooled,self.table(tensor('token_table_ids',torch.long)),
            self.role(tensor('token_roles',torch.long)),self.bus(ends).flatten(1),tensor('token_coordinates',torch.float32)],-1))
        query=tensor('query_token_ids',torch.long)
        if query.shape!=(118,) or len(set(a['query_token_ids']))!=118:raise ValueError('118 actual current bus rows')
        qvalue=row.new_tensor([q/300.,(q/300.)**2])
        action=self.action(torch.cat([row[query[b]],qvalue],-1))
        direction=torch.as_tensor(x['AC_direction_per_MVAr'],device=dev,dtype=torch.float32)
        if direction.shape!=(118,) or not bool(torch.isfinite(direction).all()):raise ValueError('Current-derived118-bus AC direction')
        # Action and analytic response condition all successor-query inputs
        # BEFORE the contextual body. Current-prefix rows are action independent.
        successor_queries=row[query]+action[None]+self.AC_direction((300.*direction)[:,None])
        combined=torch.cat([row,action[None],successor_queries],0)
        tokens=self.body_norm(self.to_body(combined))
        if tokens.shape[0]+384>4096 or not bool(torch.isfinite(tokens).all()):raise ValueError('Full context/no truncation')
        output_ends=torch.cat([tensor('token_bus_ends',torch.long),torch.tensor([[b,-1]],device=dev),
            torch.stack([torch.arange(118,device=dev),torch.full((118,),-1,device=dev)],-1)],0)
        active=torch.cat([tensor('token_edge_active',torch.bool),torch.zeros(119,dtype=torch.bool,device=dev)])
        return tokens,output_ends,active

    def decode(self,body_query_states):
        if body_query_states.shape!=(118,self.hidden):raise ValueError('Exact native118-bus body output')
        out=self.output(body_query_states.float())[:,0]
        if not bool(torch.isfinite(out).all()):raise ValueError('Finite curvature coefficients')
        return out

class TransitionGraphControl(nn.Module):
    def __init__(self,frontend,target=LORA_R4_PARAMETERS):
        super().__init__();self.frontend=frontend;h=frontend.hidden
        self.width=min(range(1,4097),key=lambda w:(abs(4*w*w+(2*h+8)*w+h+1-target),w))
        w=self.width;self.rows=nn.Linear(h,w)
        self.message=nn.ModuleList([nn.Sequential(nn.Linear(2*w,w),nn.Tanh(),nn.LayerNorm(w)) for _ in range(2)])
        self.edge_gate=nn.Linear(w,1);self.to_body=nn.Linear(w,h)
        self.body_parameters=sum(p.numel() for n,p in self.named_parameters() if not n.startswith('frontend.'))
        assert self.body_parameters==4*w*w+(2*h+8)*w+h+1
        assert abs(self.body_parameters-target)/target<.01
    def forward(self,x):
        tokens,ends,edge_active=self.frontend.encode(x);r=self.rows(tokens);w=self.width
        states=r.new_zeros((118,w));count=r.new_zeros((118,1));adj=r.new_zeros((118,118))
        for k in range(2):
            valid=ends[:,k]>=0;ids=ends[valid,k]
            states=states.index_add(0,ids,r[valid]);count=count.index_add(0,ids,r.new_ones((int(valid.sum()),1)))
        edge=(ends[:,0]>=0)&(ends[:,1]>=0)&edge_active;indices=ends[edge]
        weights=torch.sigmoid(self.edge_gate(r[edge]))[:,0]
        if len(indices):
            flat=adj.flatten().index_add(0,indices[:,0]*118+indices[:,1],weights)
            adj=flat.index_add(0,indices[:,1]*118+indices[:,0],weights).reshape(118,118)
        adj=adj+torch.eye(118,device=r.device);adj=adj/adj.sum(-1,keepdim=True)
        states=states/count.clamp_min(1.)+r[(ends<0).all(-1)].mean(0,keepdim=True)
        for layer in self.message:states=states+layer(torch.cat([states,adj@states],-1))
        return self.frontend.decode(self.to_body(states+r[-118:]))

class TransitionAttentionControl(nn.Module):
    def __init__(self,frontend,target=LORA_R4_PARAMETERS):
        super().__init__();self.frontend=frontend;h=128;out=frontend.hidden
        self.down=nn.Linear(out,h)
        fixed=(out+1)*h+2*(4*h*h+9*h)+(h+1)*out
        self.ff_width=min(range(1,8193),key=lambda w:(abs(fixed+2*(2*h+1)*w-target),w))
        layer=nn.TransformerEncoderLayer(h,nhead=4,dim_feedforward=self.ff_width,dropout=0.,batch_first=True,norm_first=True)
        self.attention=nn.TransformerEncoder(layer,num_layers=2,enable_nested_tensor=False)
        self.to_body=nn.Linear(h,out)
        self.body_parameters=sum(p.numel() for n,p in self.named_parameters() if not n.startswith('frontend.'))
        assert self.body_parameters==fixed+2*(2*h+1)*self.ff_width
        assert abs(self.body_parameters-target)/target<.01
    def forward(self,x):
        tokens,_,_=self.frontend.encode(x)
        states=self.attention(self.down(tokens)[None])[0,-118:]
        return self.frontend.decode(self.to_body(states))

def make_frontend(embeddings,tables):
    torch.manual_seed(20261009)
    return TransitionFrontend(embeddings,tables,896)

def make_control(arm,embeddings,tables,common):
    frontend=make_frontend(embeddings,tables);frontend.load_state_dict(common)
    torch.manual_seed(20261009)
    cls={'graph':TransitionGraphControl,'row_attention':TransitionAttentionControl}[arm]
    return cls(frontend)
