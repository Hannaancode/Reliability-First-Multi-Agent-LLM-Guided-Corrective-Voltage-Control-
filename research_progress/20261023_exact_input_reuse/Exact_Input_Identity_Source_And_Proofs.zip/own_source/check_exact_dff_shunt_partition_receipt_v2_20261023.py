"""One prospectively fixed two-conversion receipt-identity check, zero solve."""
import inspect,traceback
from datetime import datetime,timezone
from r118_dff_missing_continuation_core_20261023 import *
O=R/'outputs/r118_exact_shunt_partition_receipt_v2_20261023'

def main():
    O.mkdir(exist_ok=False);began=time.monotonic()
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    np,pp,v2,runner,reflection=setup()
    from coordinate_native_inverter_linear_reference_20261020 import process
    for d in ['r118_dff_missing_continuation_coordination_20261023','r118_dff_missing_continuation_reader_coordination_20261023']:
        end=read(R/'outputs'/d/'End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended'] and process(end['actual_pid']) is None
    audit=read(A/'Independent_Audit.json');assert audit['status'].startswith('PASS_') and audit['first_new_return_replays']==612
    d=E/'fed_combined_load_1p5_line_35_MG1';target=d/'call_001120_before.zlib';source=d/'call_000935.json';row=read(source)
    new=net_value(pickle.loads(zlib.decompress(target.read_bytes())));old=saved_net(d,row['before']);paid=saved_net(d,row['after'])
    helper=R/'work/native_solver_input_identity_v2_20261023.py'
    put(O/'Protocol.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_EXACT_ONE_PARTITION_COLLISION_SOURCE_INPUT_PROOF',
        question='Does 125+25Mvar atbus52 produce byte-identical deterministic solver arguments to the already independently checked150Mvar input, with all other native input tables unchanged?',
        target=target.relative_to(R).as_posix(),target_sha256=sha(target),reference=source.relative_to(R).as_posix(),reference_sha256=sha(source),kwargs=row['kwargs'],
        source_hashes={Path(__file__).relative_to(R).as_posix():sha(__file__),helper.relative_to(R).as_posix():sha(helper)},
        native_input_preparation_calls_planned=2,native_result_extractions_planned=1,actual_new_nonlinear_PF_algorithm_calls_allowed=0,new_model_derivative_optimizer_training_calls_allowed=0,
        fixed_gate='Every ppci field/type/array byte, solver option and kwargs EXACTLY equal; exact unchanged original prefix AST; map source result on the new bookkeeping with unchanged VM/VA bytes and native per-element extraction. Any difference leaves UNKNOWN; no epsilon solver-input relaxation.',
        bound_seconds=180,not_a_new_measured_PF_return_or_trajectory=True,no_automatic_further_science_or_allocation=True))
    costs=dict(native_input_preparations=0,native_result_extractions=0,new_nonlinear_algorithm_invocations=0,new_model_optimizer_derivative_calls=0)
    def forbidden(*a,**k):raise OperationalStop('NO_NONLINEAR_SOLVER_OR_MODEL_ALLOWED')
    import pandapower.powerflow as pf
    native_algorithm=pf._run_pf_algorithm;pf._run_pf_algorithm=forbidden
    try:
        # Non-shunt input tables must match; the controller's resource/name
        # bookkeeping stays on the target NET and is never replaced.
        import pandas as pd
        for key,value in new.items():
            if isinstance(value,pd.DataFrame) and key!='shunt' and not str(key).startswith('res_'):
                pd.testing.assert_frame_equal(value,old[key],check_exact=True)
        from native_solver_input_identity_v2_20261023 import native_input_prefix,assert_solver_input_identity,map_paid_return
        costs['native_input_preparations']+=1;newargs=native_input_prefix(copy.deepcopy(new),row['kwargs'])
        costs['native_input_preparations']+=1;oldargs=native_input_prefix(copy.deepcopy(old),row['kwargs'])
        assert_solver_input_identity(newargs,oldargs)
        bad=copy.deepcopy(newargs);bad['ppci']['bus'][0,2]+=.001
        try:assert_solver_input_identity(bad,oldargs)
        except Exception:negative_rejected=True
        else:raise AssertionError('Changed solver input must fail exact identity')
        mapped=map_paid_return(newargs,paid);costs['native_result_extractions']+=1;frames_equal(mapped,new)
        assert np.array_equal(mapped.res_bus.vm_pu.to_numpy(),paid.res_bus.vm_pu.to_numpy())
        assert np.array_equal(mapped.res_bus.va_degree.to_numpy(),paid.res_bus.va_degree.to_numpy())
        delta=0.
        for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid']:
            a=mapped[name].select_dtypes(include=[np.number]).to_numpy(float);b=paid[name].select_dtypes(include=[np.number]).to_numpy(float)
            assert a.shape==b.shape and np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True)
            finite=np.isfinite(a)&np.isfinite(b);delta=max(delta,float(np.max(abs(a[finite]-b[finite]),initial=0.)))
        packet=capsule(O/'Input_Identity_And_Mapped_Receipt.zlib',dict(new_input=new,old_input=old,new_native_arguments=newargs,old_native_arguments=oldargs,paid_after=paid,mapped_after=mapped))
        cold=decode(O,packet);assert_solver_input_identity(cold['new_native_arguments'],cold['old_native_arguments']);frames_equal(cold['mapped_after'],new)
        put(O/'Result.json',dict(status='PASS_EXACT_NATIVE_SOLVER_INPUT_IDENTITY_AND_SOURCE_RESULT_PARTITION_MAPPING',costs=costs,full_solver_input_types_values_and_array_bytes_exact=True,negative_changed_solver_input_rejected=negative_rejected,voltage_magnitude_and_angle_bytes_unchanged=True,maximum_other_nonshunt_result_field_delta=delta,old_new_shunt_row_counts=[len(old.shunt),len(new.shunt)],source_preparation_proof=newargs['proof'],mapped_receipt=packet,new_physical_measurement=False,not_full_controller_or_LLM_superiority=True,workflow_seconds=time.monotonic()-began))
    except BaseException as exc:
        put(O/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),costs=costs,no_NEW_nonlinear_or_model_calls=True));raise
    finally:
        pf._run_pf_algorithm=native_algorithm;put(O/'Closed_Manifest.json',dict(members={f.name:sha(f) for f in O.iterdir() if f.is_file()}))

if __name__=='__main__':main()
