"""Source-pinned executable SOFTWARE witnesses; zero actual solver/model calls.

Reuses the earlier static solver/sign/cap findings. Newly checks the deployed
normalizer and transition admission that constrain preparatory/joint proposals.
No fixture supplies a physical counterfactual or a future reward.
"""
import ast
import copy
import hashlib
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

from paid_spatial_two_step_search import Receipt, two_step

ROOT = Path(__file__).resolve().parents[1]
RESET = ROOT / 'outputs/critical_research_reset_20261010'
OUT = RESET / 'deployed_action_transition_contract_20261012'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    with (OUT / name).open('x', encoding='utf8') as f:
        json.dump(value, f, indent=2); f.flush(); os.fsync(f.fileno())

def main():
    OUT.mkdir(exist_ok=False)
    files = ['work/e/audit/phase2g_rescue_runner.py', 'work/value_normal_band_mediation.py',
             'work/paid_spatial_two_step_search.py']
    prior = json.loads((RESET / 'spatial_DSE_reference_screen_20261012/preparation/Protocol.json').read_text('utf8'))
    pins = {p: sha(ROOT / p) for p in files}
    assert all(prior['source_sha256'][p] == h for p, h in pins.items())
    write('Protocol.json', {
        'declared_at_utc': datetime.now(timezone.utc).isoformat(), 'source_sha256': pins,
        'scope': 'Executable source-contract/software witnesses only; original source unchanged.',
        'questions': ['Does normalization retain a joint multi-bus payload?',
                      'Can the deployed parser/actuator retain signed inductive control?',
                      'Can a safe voltage-upper-margin preparation lacking immediate UV/deficit/vmin improvement be admitted?',
                      'Does existing two-step search expand a first action rejected by this admission?'],
        'fixtures_are_synthetic_not_measured_physics': True, 'new_model_PF_optimizer_calls': 0,
        'earlier_static_sign_cap_solver_semantics_reused': 'sequence_screen_native_semantics_20261011/Results.json'
    })
    source = (ROOT / files[0]).read_text('utf8'); tree = ast.parse(source)
    names = {'normalize_action', 'apply_action', 'verify_action', 'make_action'}
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert len(nodes) == len(names)
    mock = {'create_shunt': [], 'PF_callback': 0}
    def create_shunt(net, **kwargs):
        mock['create_shunt'].append(copy.deepcopy(kwargs))
        net['mock_actuations'].append(copy.deepcopy(kwargs))
    def run_pf(net):
        mock['PF_callback'] += 1
        net['metrics'] = copy.deepcopy(net['synthetic_after'])
        return True, None
    env = {'copy': copy, 'pp': SimpleNamespace(create_shunt=create_shunt),
           'r': SimpleNamespace(run_pf=run_pf), 'HARD_OV': 1.06, 'MAX_ABS_Q_PER_BUS': 450.,
           'grid_metrics': lambda n: copy.deepcopy(n['metrics']),
           'llm_q_abs_at_bus': lambda n, b: n.get('synthetic_existing_abs_Q', {}).get(b, 0.)}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), files[0], 'exec'), env)
    checks = []
    normalized = env['normalize_action']({'add_shunts_q_mvar': {'52': 100., '57': 125.}})
    assert normalized == {'add_shunts_q_mvar': {'52': 100.}}
    checks.append('joint_two_bus_payload_is_reduced_to_first_positive_entry')
    assert env['normalize_action']({'add_shunts_q_mvar': {'57': 125., '52': 100.}}) == {'add_shunts_q_mvar': {'57': 125.}}
    checks.append('insertion_order_selects_retained_bus_not_joint_control')
    assert env['normalize_action']({'add_shunts_q_mvar': {'52': -100.}}) is None
    checks.append('negative_command_rejected_by_deployed_normalizer')
    for q in (100., -100.):
        n = {'mock_actuations': []}; env['apply_action'](n, {'add_shunts_q_mvar': {'52': q}})
        assert n['mock_actuations'][0]['q_mvar'] == -100.
    checks.append('direct_actuator_abs_also_prevents_signed_inductive_command')
    assert env['make_action'](52, -100.) == {'add_shunts_q_mvar': {'52': 100.}}
    checks.append('native_make_action_uses_positive_support_magnitude')
    before = {'uv_count': 2, 'deficit_sum': .02, 'vmin': .94, 'vmax': 1.049}
    action = {'add_shunts_q_mvar': {'52': 100.}}
    def fixture(after, existing=0.):
        return {'metrics': copy.deepcopy(before), 'synthetic_after': after,
                'synthetic_existing_abs_Q': {52: existing}, 'mock_actuations': []}
    neutral_after = dict(before, vmax=1.045)
    neutral = env['verify_action'](fixture(neutral_after), action)
    assert neutral['accepted'] is False and neutral['reason'] == 'no_improvement'
    checks.append('safe_lower_vmax_without_immediate_objective_gain_is_rejected')
    deficit = env['verify_action'](fixture(dict(before, deficit_sum=.019)), action)
    assert deficit['accepted'] is True
    checks.append('same_UV_with_strict_deficit_improvement_can_be_accepted')
    minimum = env['verify_action'](fixture(dict(before, vmin=.941)), action)
    assert minimum['accepted'] is True
    checks.append('same_UV_and_deficit_with_strict_vmin_improvement_can_be_accepted')
    tradeoff = env['verify_action'](fixture(dict(before, uv_count=1, deficit_sum=.021)), action)
    assert tradeoff['accepted'] is False and 'deficit_increased' in tradeoff['reason']
    checks.append('UV_improvement_does_not_override_deficit_nonincrease')
    unsafe = env['verify_action'](fixture(dict(before, uv_count=1, deficit_sum=.01, vmax=1.08)), action)
    assert unsafe['accepted'] is False and 'hard_overvoltage' in unsafe['reason']
    checks.append('improvement_does_not_override_original_hard_upper')
    count = mock['PF_callback']
    cap = env['verify_action'](fixture(neutral_after, existing=400.), action)
    assert cap['reason'] == 'q_cap_exceeded' and mock['PF_callback'] == count
    checks.append('450_cumulative_absolute_cap_rejection_precedes_mock_solver')
    mediation = ast.parse((ROOT / files[1]).read_text('utf8'))
    cls = next(n for n in mediation.body if isinstance(n, ast.ClassDef) and n.name == 'NormalUpperMediation')
    med_env = {'math': math}
    exec(compile(ast.Module(body=[cls], type_ignores=[]), files[1], 'exec'), med_env)
    rescue = SimpleNamespace(verify_action=env['verify_action'])
    with med_env['NormalUpperMediation'](rescue):
        mediated = rescue.verify_action(fixture(neutral_after), action)
    assert mediated['normal_upper_mediation']['band_admissible'] is True and mediated['accepted'] is False
    checks.append('common_upper_mediation_does_not_relax_no_improvement')
    requests = []
    def menu(parent):
        assert parent == 'LABELLED_SOFTWARE_ROOT'
        return ('LABELLED_NEUTRAL_ACTION',)
    def query(parent, identity):
        requests.append((parent, identity))
        assert parent == 'LABELLED_SOFTWARE_ROOT'
        return Receipt(parent, identity, True, neutral['accepted'], None, neutral['after'], None)
    plan = two_step('LABELLED_SOFTWARE_ROOT', before, 25, menu, query, mode='exhaustive')
    assert plan['status'] == 'no_admitted_first_action' and len(requests) == 1
    checks.append('existing_exhaustive_two_step_does_not_expand_rejected_preparation')
    write('Source_Contract_Certificate.json', {
        'status': 'PASS_SOURCE_BOUND_SOFTWARE_CONTRACT', 'checks': checks,
        'mock_actuation_callbacks': len(mock['create_shunt']), 'mock_PF_callbacks': mock['PF_callback'],
        'new_actual_PF_model_optimizer_calls': 0, 'actual_counterfactual_physics_observed': False,
        'normalized_two_bus_fixture': normalized, 'safe_neutral_fixture_result': neutral,
        'source_sha256': pins,
        'conclusions': [
            'The deployed normalized LOCAL command retains at most one positive bus support entry.',
            'Negative support input is not a deployed signed reactive actuator; parser rejects it and apply_action takes abs.',
            'Safe lower-vmax preparation without immediate UV/deficit/vmin gain is rejected; mediation does not reopen it.',
            'Current two-step planners inherit per-step native admission and cannot cross that neutral plateau.',
            'This does not prove a useful physical preparatory/joint path exists, or that current spatial sequences cannot improve.'
        ],
        'limitations': ['Synthetic metric/state callbacks, not measured physical episodes.',
                        'No negative result or superiority claim for any new action grammar.',
                        'Original baseline/parser/guard/source and all adverse/partial evidence unchanged.']
    })
    print(json.dumps({'checks': len(checks), 'status': 'PASS_SOURCE_BOUND_SOFTWARE_CONTRACT', 'actual_science': 0}))

if __name__ == '__main__':
    main()
