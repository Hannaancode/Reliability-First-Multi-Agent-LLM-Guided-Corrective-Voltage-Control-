"""New actual-data reference accounting/cold-preservation checks; zero science."""
import argparse, copy, hashlib, json, os, pickle, struct, subprocess, sys, time, zlib
from pathlib import Path
import numpy as np
import pandapower as pp
from durable_opaque_evidence_store_v1 import local_root, process_alive
from frozen_physics_loader import load_stack, AUDIT
from joint_reallocation_opportunity_core_v1 import load_endpoint, build_verifier
from joint_cursor_reference_v2 import initialize, validate, advance_reference, shunt_digest, save_reference, restore_reference, MODE
from lossless_evidence_byte_codec_v1 import canonical

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
OUT=ROOT/'outputs/critical_research_reset_20261010/joint_cursor_reference_v2_20261012'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()

def put(p,d):
    with local_root(p).open('xb') as f:f.write(canonical(d));f.flush();os.fsync(f.fileno())

def blocked(*a,**k):raise RuntimeError('Zero new model/PF/optimizer/forecast/solve in reference software checks')

for name in ('runpp','rundcpp','runopp','rundcopp'):
    if hasattr(pp,name):setattr(pp,name,blocked)

def signature(state):
    net=state['net']
    # Exact typed tabular values, not cross-process pickle serialization identity.
    tables={}
    for key,value in sorted(net.items()):
        if hasattr(value,'columns'):
            tables[key]={'axes':[list(map(str,value.index)),list(map(str,value.columns))],
                         'dtypes':list(map(str,value.dtypes)),
                         'values_sha256':hashlib.sha256(__import__('pandas').util.hash_pandas_object(value,index=True).values.tobytes()).hexdigest()}
    rng=state['numpy_rng']
    return {'cursor':state['cursor'],'registry':state['paid_query_registry'],'costs':state['costs'],
            'absolute_bound_utc':state['absolute_bound_utc'],'tables':tables,
            'converged':bool(net.converged),'python_rng':hashlib.sha256(pickle.dumps(state['python_rng'])).hexdigest(),
            'numpy_rng':[rng[0],rng[1].dtype.str,list(rng[1].shape),hashlib.sha256(rng[1].tobytes()).hexdigest(),*rng[2:]]}

def cold(path, receipt, output):
    state=restore_reference(path,read(receipt));put(output,signature(state))

def main():
    begun=time.perf_counter();verified=read(OLD/'verified_handoff/Verified_Physical_Opportunity_Checkpoint.json')
    assert verified['fixed_gate']=='PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY'
    assert all(not process_alive(p) for p in verified['all_exact_owner_coordinator_reader_chains_ended'])
    local_root(OUT).mkdir(exist_ok=False)
    source_names=['work/joint_cursor_reference_v2.py','work/check_joint_cursor_reference_v2.py',
        'work/lossless_evidence_byte_codec_v1.py','work/durable_opaque_evidence_store_v1.py',
        'work/owned_bank_joint_reallocation_v1.py','work/joint_reallocation_opportunity_core_v1.py']
    protocol={'scope':MODE,'frozen_at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        'source_sha256':{n:sha(ROOT/n) for n in source_names},
        'original_manifest_sha256':sha(OLD/'actual/Closed_Manifest.json'),
        'case_rule':'First accepted universe_index per original root and action kind. SOFTWARE accounting only, no policy evaluation.',
        'new_model_PF_optimizer_forecast_solve_calls':0,'new_physical_commits':0,
        'next_scope':'Original externally bound root scope retained for this accounting-only reference; following-state native scope/integration NOT certified.',
        'actual_scientific_resume_authorized':False}
    put(OUT/'Protocol.json',protocol);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    m=read(OLD/'actual/Closed_Manifest.json');assert m['members']['scientific.jsonl']['sha256']==sha(OLD/'actual/scientific.jsonl')
    events=[json.loads(b) for b in local_root(OLD/'actual/scientific.jsonl').read_bytes().splitlines()]
    candidates=[e['data'] for e in events if e['event']=='candidate_closed'];p=read(OLD/'preparation/Protocol.json')
    _,runner,_=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    pack=local_root(OLD/'actual/capsules.bin').open('rb')
    def capsule(d):
        pack.seek(d['record_offset']);n=struct.unpack('<Q',pack.read(8))[0];hb=pack.read(n)
        assert n==d['header_bytes'] and hashlib.sha256(hb).hexdigest()==d['header_sha256']
        header=json.loads(hb);assert all(d[k]==v for k,v in header.items()) and pack.tell()==d['encoded_offset']
        encoded=pack.read(d['encoded_bytes']);assert hashlib.sha256(encoded).hexdigest()==d['encoded_sha256']
        dec=zlib.decompressobj();raw=dec.decompress(encoded,d['raw_bytes']+1)
        assert dec.eof and not dec.unused_data and not dec.unconsumed_tail and len(raw)==d['raw_bytes'] and hashlib.sha256(raw).hexdigest()==d['raw_sha256']
        return pickle.loads(raw)
    checks=[];receipts=[]
    def rejection(label,callback):
        try:callback()
        except (ValueError,KeyError):checks.append({'check':label,'result':'PASS_REJECTED'})
        else:raise AssertionError('Invalid reference accepted: '+label)
    for w,entry in enumerate(p['current_endpoints']):
        before,original,_=load_endpoint(entry);cursor=initialize(before,original)
        _,actuate,_=build_verifier(runner.rescue,original)
        for kind in ('ordinary','equal_owned_reallocation'):
            row=min((r for r in candidates if r['world']==entry['world'] and r['kind']==kind and r['verif']['accepted']),key=lambda r:r['universe_index'])
            assert row['actually_committed'] is False
            solved=capsule(row['measured_receipt']['after']);after=solved['net']
            expected=actuate(copy.deepcopy(before),row['action']);assert after.shunt.equals(expected.shunt)
            rid=f"{entry['world']}:{row['measured_receipt']['PF_id']}";next_cursor=advance_reference(before,after,cursor,row,
                receipt_id=rid,expected_after_shunt_sha256=shunt_digest(expected),next_raw_scope=cursor['raw_current_receiver_scope'])
            assert next_cursor['remaining_original_device_operation_slots']==cursor['remaining_original_device_operation_slots']-row['device_operations_if_committed']
            assert next_cursor['new_physical_commits']==0 and not next_cursor['scientific_resume_authorized']
            if kind=='equal_owned_reallocation':assert next_cursor['positive_addition_lifetime_MVAr'][str(row['donor_bus'])]==cursor['positive_addition_lifetime_MVAr'][str(row['donor_bus'])]
            state={'net':after,'cursor':next_cursor,'paid_query_registry':{rid:row['measured_receipt']},
                'python_rng':solved['python_rng'],'numpy_rng':solved['numpy_rng'],
                'costs':{'inherited_scientific_costs':read(OLD/'actual/Result.json')['actual_costs'],'new_scientific_calls':0},
                'absolute_bound_utc':p['absolute_deadline_utc']}
            name=f'W{w+1}_{kind}';path=OUT/name
            ack=save_reference(path,state,anchors={'source':protocol['source_sha256'],'input':protocol['original_manifest_sha256'],
                'paid_receipt':row['measured_receipt']['after'],'predecessor':sha(ROOT/entry['endpoint_record'])})
            put(OUT/(name+'_External_Receipt.json'),ack)
            restored=restore_reference(path,ack);assert signature(restored)==signature(state)
            cp=subprocess.run([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold',str(path),
                str(OUT/(name+'_External_Receipt.json')),str(OUT/(name+'_Cold.json'))],capture_output=True,text=True,timeout=120)
            assert cp.returncode==0,cp.stderr;assert read(OUT/(name+'_Cold.json'))==json.loads(canonical(signature(state)))
            checks.append({'check':name+'_exact_cold_complete_reference','result':'PASS','receipt_id':rid,
                'operations':row['device_operations_if_committed'],'source_query_not_commit':True})
            receipts.append({'path':str(path.relative_to(ROOT)),**ack})
            bad=copy.deepcopy(next_cursor);bad['remaining_original_device_operation_slots']+=1
            rejection(name+'_operation_refund',lambda:validate(after,bad))
            bad=copy.deepcopy(next_cursor);bad['positive_addition_lifetime_MVAr'][str(row['receiver'])]-=row['q']
            rejection(name+'_positive_cap_refund',lambda:validate(after,bad))
            bad=copy.deepcopy(next_cursor);bad['scientific_resume_authorized']=True
            rejection(name+'_reference_as_science',lambda:validate(after,bad))
            bad=copy.deepcopy(ack);bad['raw_sha256']='0'*64
            rejection(name+'_wrong_external_anchor',lambda:restore_reference(path,bad))
            rejection(name+'_wrong_actuation',lambda:advance_reference(before,after,cursor,row,receipt_id=rid,
                expected_after_shunt_sha256='0'*64,next_raw_scope=cursor['raw_current_receiver_scope']))
    pack.close()
    result={'state':'PASS_COMPLETE_SAVED_REFERENCE_ACCOUNTING_AND_COLD_PROCESS_SOFTWARE_ONLY',
        'checks':checks,'checks_passed':len(checks),'exact_cold_processes':len(receipts),'receipts':receipts,
        'new_scientific_calls':0,'actual_new_physical_commits':0,'scientific_resume_authorized':False,
        'software_workflow_seconds':time.perf_counter()-begun,
        'limitations':['No actual commitment or following transition was executed. Old queries remain queries.',
            'Following native scope, full numerical/model trajectory, live ownership/bound admission and independent replay remain required.',
            'Preserved old absolute bound is expired; restoring a reference does not extend or revive any study.']}
    put(OUT/'Results.json',result);print(json.dumps({k:result[k] for k in ('state','checks_passed','exact_cold_processes','new_scientific_calls','software_workflow_seconds')}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--cold',nargs=3);args=parser.parse_args()
    if args.cold:cold(*args.cold)
    else:main()
