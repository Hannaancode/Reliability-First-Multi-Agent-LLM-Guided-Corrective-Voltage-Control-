"""Sole handoff: waits for actual owner and launcher, one external reader."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
from durable_opaque_evidence_store_v1 import process_alive
R=Path(__file__).resolve().parents[1];B=R/'outputs/hl8_20261012';H=B/'handoff';H.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(d):
    with (H/'status.tmp').open('w') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
    (H/'status.tmp').replace(H/'status.json')
identity=read(B/'execution/owner.claim');launcher=read(B/'Launcher.json');lock=read(B/'Analysis_Source_Lock.json')
(H/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'science_actual_pid':identity['pid'],'science_launcher_pid':launcher['launcher_pid'],'source_sha256':sha(Path(__file__))}))
status={'stage':'waiting_for_exact_owned_process_and_release','scientific_actual_pid':identity['pid'],'scientific_launcher_pid':launcher['launcher_pid'],'reader_launched':False};save(status)
while process_alive(identity['pid']) or process_alive(launcher['launcher_pid']):time.sleep(20)
try:
    s=read(B/'execution/status.json');assert s['scientific_process_ended'] and s['runtime_released'] and s['all_actual_closed_artifacts_preserved']
    for n,h in lock['sources'].items():assert sha(R/n)==h
    assert not (B/'audit').exists(),'Never duplicate a reader claim'
    with (H/'reader_console.log').open('xb') as f:
        reader=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(R/'work/audit_hybrid_larger_remaining_v4.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        status.update(stage='one_external_zero_science_reader',reader_launched=True,reader_launcher_pid=reader.pid);save(status);code=reader.wait(timeout=1800)
    status.update(stage='external_audit_ended',reader_exit_code=code)
except BaseException as e:status.update(stage='handoff_terminal_failure_preserved_no_retry',failure_type=type(e).__name__)
save(status)
