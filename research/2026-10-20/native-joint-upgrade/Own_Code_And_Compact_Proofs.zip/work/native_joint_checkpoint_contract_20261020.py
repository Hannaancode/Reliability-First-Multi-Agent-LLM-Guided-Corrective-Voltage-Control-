"""Explicit full engineering checkpoint contract; no model or optimizer execution."""
import random
import numpy as np
import torch
def selected(model,head):
    result={'body.'+n:p for n,p in model.named_parameters() if p.requires_grad}
    result.update({'head.'+n:p for n,p in head.named_parameters()})
    assert len(result)==394 and sum(p.numel() for p in result.values())==18469379
    assert all(p.dtype==torch.float32 for p in result.values())
    return result
def cpu(value):
    if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:cpu(v) for k,v in value.items()}
    if isinstance(value,list):return [cpu(v) for v in value]
    if isinstance(value,tuple):return tuple(cpu(v) for v in value)
    return value
def rng():return {'python':random.getstate(),'numpy':np.random.get_state(),'cpu':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all()}
def save(path,model,head,opt,scaler,step,contract):
    active=selected(model,head)
    value={'trainables':{n:cpu(p) for n,p in active.items()},'ordered_names':list(active),'optimizer':cpu(opt.state_dict()),'scaler':scaler.state_dict(),'RNG':rng(),'cursor':{'completed_updates':step,'next_update':step+1,'engineering_only':True},'contract':contract}
    torch.save(value,path);return value
def assert_same(a,b):
    if isinstance(a,torch.Tensor):assert isinstance(b,torch.Tensor) and a.dtype==b.dtype and a.shape==b.shape and torch.equal(a.cpu(),b.cpu())
    elif isinstance(a,np.ndarray):assert isinstance(b,np.ndarray) and np.array_equal(a,b)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a:assert_same(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert type(a)==type(b) and len(a)==len(b)
        for x,y in zip(a,b):assert_same(x,y)
    else:assert a==b
def restore(value,model,head,opt,scaler,contract):
    assert value['contract']==contract
    active=selected(model,head);assert list(active)==value['ordered_names']
    with torch.no_grad():
        for n,p in active.items():p.copy_(value['trainables'][n].to(p.device));assert torch.equal(p.detach().cpu(),value['trainables'][n])
    opt.load_state_dict(value['optimizer']);scaler.load_state_dict(value['scaler'])
    assert_same(cpu(opt.state_dict()),value['optimizer']);assert_same(scaler.state_dict(),value['scaler'])
    random.setstate(value['RNG']['python']);np.random.set_state(value['RNG']['numpy']);torch.set_rng_state(value['RNG']['cpu']);torch.cuda.set_rng_state_all(value['RNG']['cuda'])
    assert_same(rng(),value['RNG']);assert value['cursor']=={'completed_updates':2,'next_update':3,'engineering_only':True}
    return {'all394_trainables_and_18469379_parameters_exact':True,'all_AdamW_moments_and_steps_exact':True,'scaler_and_Python_numpy_CPU_CUDA_RNG_exact':True,'complete_cursor_exact':True}
