"""One prospective bounded MOCK control-flow study. Actual nonlinear PF=0.

Native controller/candidate/verifier/score ASTs execute with a labelled mock
runpp. Generated voltages are fixture values, never measured physical targets.
"""
import copy,hashlib,json,os,time,platform,subprocess
from pathlib import Path
from datetime import datetime,timezone,timedelta
from collections import Counter
import numpy as np,pandas as pd,scipy,pandapower as pp
from frozen_physics_loader import load_stack,AUDIT
from trusted_causal_controller_snapshot import SOLVER_ROLES,cap_totals,restore
from native_continuation_preservation import EvidenceJournal,NativePreservation,prepare_continuation,canonical,PreservationStop,ResourceStop
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/native_continuation_software_20261011'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
 OUT.mkdir(exist_ok=False);started=time.perf_counter();deadline=datetime.now(timezone.utc)+timedelta(seconds=180)
 sources=['work/native_continuation_preservation.py','work/check_native_continuation_software_20261011.py','work/trusted_causal_controller_snapshot.py','work/frozen_physics_loader.py','work/dff_alt.py','work/value_normal_band_mediation.py','work/train_trajectory_measurement_nullable_v2.py']
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'LABELLED_MOCK_CONTROL_FLOW_ONLY_NOT_SOLVED_HIERGRID_STATES','resource_seconds':180,'source_sha256':{s:sha(ROOT/s) for s in sources},'cases':['root_DFF','root_ALT','later_ALT_lineage_ordinary_only','iteration25_restore_keeps_native_max_reason','healthy_no_search','no_accepted_action','all_trial_exceptions','commit_exception_preserves_mutated_net'],'negative_inputs':['missing_prefix_action','wrong_last_metrics','wrong_episode','wrong_prefix_cost','changed_Q_grid','unowned_execute','duplicate_recorder','expired_deadline','wrong_solver_options','journal_failure'],'new_nonlinear_PF_pretrained_model_optimizer_fit_forecast_cloud_calls':0,'no_automatic_physical_or_training_launch':True}
 write(OUT/'Protocol.json',protocol);protocol_sha=sha(OUT/'Protocol.json');write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':protocol_sha,'command':'check_native_continuation_software_20261011.py'})
 v2,runner,reflection=load_stack();assert len(AUDIT)==6 and all(a['all_function_asts_unchanged'] for a in AUDIT)
 write(OUT/'Native_Source_Closure.json',AUDIT)
 real_runpp=pp.runpp;mock_entries=[];holder={};rows=[];rejections=[]
 def mock_runpp(net,**options):
  if datetime.now(timezone.utc)>=deadline:raise ResourceStop('Fixed software fixture deadline')
  rec=holder['rec'];case=holder['case'];role='trial' if rec.active is not None else 'commit'
  mock_entries.append({'case':case,'role':role,'options':options})
  if case=='all_trial_exceptions' or (case=='commit_exception_preserves_mutated_net' and role=='commit'):
   net.converged=False;raise RuntimeError('LABELLED_MOCK_NUMERICAL_FAILURE_NOT_REAL_PF')
  counts=cap_totals(net);values=[float(b)+counts.get(str(i),0)/10000 for i,b in enumerate(net['_fixture_base_vm'])]
  net.res_bus.loc[:,'vm_pu']=values;net.converged=True;net['_options']=options.copy();net['_ppc']={'FIXTURE_CACHE_NOT_REAL_PF':True,'complex':np.array(values,dtype=np.complex128)+1j}
  return None
 pp.runpp=mock_runpp
 try:
  for case in protocol['cases']:
   assert time.perf_counter()-started<180
   net=pp.create_empty_network()
   for _ in range(4):pp.create_bus(net,vn_kv=110)
   values=[.92,.94,1.,1.01];k=0;mode='ROOT_DFF_ALT' if case=='root_ALT' else 'ORDINARY_DFF'
   if case=='healthy_no_search':values=[.96,.97,1.,1.01]
   if case=='iteration25_restore_keeps_native_max_reason':values=[.92,.96,1.,1.01];k=24
   if case=='later_ALT_lineage_ordinary_only':k=1
   net['_fixture_base_vm']=values.copy()
   for i in range(k):runner.rescue.apply_action(net,runner.rescue.make_action(2+i%2,25))
   if case=='no_accepted_action':
    for b in [0,1]:pp.create_shunt(net,b,q_mvar=-450,name='llm_shunt_fixture_cap',in_service=False)
   # Values are explicitly fabricated software CURRENT, not solver results.
   net.res_bus=pd.DataFrame({'vm_pu':values.copy(),'va_degree':[0.]*4,'p_mw':[0.]*4,'q_mvar':[0.]*4},index=net.bus.index)
   net.converged=True;net['_options']={'fixture_only':True};net['_ppc']={'FIXTURE_NOT_PHYSICS':True}
   zones={'MG1':[0,1],'MG2':[2,3]};episode='MOCK_ONLY_'+case;metrics=runner.rescue.grid_metrics(net)
   prefix={'method':'dff_alt' if 'ALT' in case else 'no_llm_fallback_first','scenario_id':episode,'base_converged':True,'base_metrics':metrics.copy(),'final_metrics':None,'logs':[{'iteration':i+1,'fallback_tests':0} for i in range(k)],'executed_actions':[{'iteration':i+1,'source':'MOCK_UNOBSERVED_PREFIX','action':runner.rescue.make_action(2+i%2,25),'post_metrics':metrics.copy()} for i in range(k)],'stop_reason':None,'counters':Counter()}
   process={'schema_version':1,'snapshot_id':'MOCK_'+case,'episode_identity':episode,'phase':'PRE_SELECTION','after_commit':k,'next_iteration':k+1,'remaining_slots':25-k,'continuation_mode':mode,'failed_signatures':[],'guard':None,'source_sha256':{str(Path(a['file']).resolve()):a['sha256'] for a in AUDIT},'runtime_identity':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'pandapower':pp.__version__,'execution_kind':'LABELLED_MOCK_NOT_PHYSICS'},'solver_roles':SOLVER_ROLES,'policy_configuration':{'per_bus_named_shunt_cap':450,'q_grid':[25,50,75,100,125,150,200,250,300],'maximum_iterations':25,'candidate_order':'BUS_ASCENDING_THEN_Q_GRID','selection':'ORIGINAL_LEXICOGRAPHIC_FIRST_EXACT_TIE'},'zone_configuration':{'zones':zones,'order':sorted(zones)},'cost_counters':{'PF_attempts':0,'PF_returns':0,'PF_exceptions':0},'absolute_deadline_utc':deadline.isoformat(),'execution_authorized':False}
   execute,certificate=prepare_continuation(reflection,runner,net,process,prefix,sha(Path(reflection.__file__)))
   try:execute()
   except ValueError:rejections.append({'case':case,'reason':'unowned_execute'})
   else:raise AssertionError('Unowned native execution accepted')
   directory=OUT/case;directory.mkdir();write(directory/'owner.claim',{'actual_pid':os.getpid(),'protocol_sha256':protocol_sha,'measurement_kind':'SOFTWARE_MOCK_ONLY'})
   journal=EvidenceJournal(directory/'journal.jsonl',protocol_sha)
   try:
    with NativePreservation(pp,runner,zones,process,directory,journal) as rec:
     holder.update(rec=rec,case=case)
     try:
      with NativePreservation(pp,runner,zones,process,directory,journal):pass
     except ValueError:rejections.append({'case':case,'reason':'duplicate_recorder'})
     else:raise AssertionError('Duplicate observer accepted')
     result=execute()
     actual=copy.deepcopy(rec.costs)
   finally:journal.close()
   assert pp.runpp is mock_runpp and not hasattr(runner,'_native_preservation_owner')
   assert actual['PF_attempts']==actual['PF_returns']+actual['PF_exceptions']
   assert len([e for e in mock_entries if e['case']==case])==actual['PF_attempts']
   if case=='root_DFF':assert result['full_restoration'] and result['executed_actions'][0]['action']==runner.rescue.make_action(0,300)
   if case=='root_ALT':assert result['full_restoration'] and result['dff_alt_decisions'][0]['reason']=='second_ranked_distinct' and all(d['reason']=='ordinary_dff' for d in result['dff_alt_decisions'][1:])
   if case=='later_ALT_lineage_ordinary_only':assert result['executed_actions'][1]['iteration']==2 and result['executed_actions'][1]['action']==runner.rescue.make_action(0,300) and 'dff_alt_decisions' not in result
   if case=='iteration25_restore_keeps_native_max_reason':assert result['full_restoration'] and result['stop_reason']=='max_iterations_reached' and len(result['executed_actions'])==25
   if case=='healthy_no_search':assert actual['PF_attempts']==actual['candidate_attempts']==0 and result['stop_reason']=='full_restoration'
   if case in ['no_accepted_action','all_trial_exceptions']:assert result['stop_reason']=='no_accepted_action' and result['executed_actions']==[]
   if case=='all_trial_exceptions':assert actual['PF_exceptions']==actual['PF_attempts'] and actual['PF_returns']==0
   if case=='commit_exception_preserves_mutated_net':assert result['stop_reason'].startswith('execution_pf_failed:') and len(result['executed_actions'])==0 and len(net.shunt)==1 and actual['PF_exceptions']==1
   # Verify saved journal chain and every individual net/manifest anchor.
   previous=protocol_sha;entries=[]
   for seq,line in enumerate((directory/'journal.jsonl').read_bytes().splitlines()):
    item=json.loads(line);assert item['row']['sequence']==seq and item['row']['previous_sha256']==previous and hashlib.sha256(canonical(item['row'])).hexdigest()==item['sha256'];previous=item['sha256'];entries.append(item['row'])
    event=item['row']['event'];payload=item['row']['payload']
    if event in ['native_PF_return','native_PF_exception']:
     pin=payload.get('snapshot',payload.get('failed_state_snapshot'));sub=directory/pin['relative_directory'];assert sha(sub/'trusted_local_net.pkl')==pin['payload_sha256'] and sha(sub/'manifest.json')==pin['manifest_sha256']
    if event=='native_preselection_snapshot':
     sub=directory/payload['process']['snapshot_id'];assert sha(sub/'trusted_local_snapshot.pkl')==payload['anchors']['payload_sha256'] and sha(sub/'manifest.json')==payload['anchors']['manifest_sha256'] and sha(sub/'native_prefix_result.json')==payload['prefix_sha256']
   assert len([e for e in entries if e['event']=='native_candidate_return'])==actual['candidate_returns']
   assert len([e for e in entries if e['event']=='native_PF_return'])==actual['PF_returns'] and len([e for e in entries if e['event']=='native_PF_exception'])==actual['PF_exceptions']
   write(directory/'Actual_Mock_Result.json',{'scope':'MOCK_NOT_PHYSICS','result':dict(result,counters=dict(result['counters'])),'control_flow_certificate':certificate,'simulated_call_costs':actual,'actual_nonlinear_PF_model_optimizer_fit_forecast_cloud_calls':0,'journal_entries_verified':len(entries),'journal_last_hash':previous})
   rows.append({'case':case,'control_flow_passed':True,'stop_reason':result['stop_reason'],'simulated_counts':actual})
  # One verified newly generated MOCK after-commit capsule, not old physics.
  parent=OUT/'root_DFF';chain=[json.loads(line)['row'] for line in (parent/'journal.jsonl').read_bytes().splitlines()]
  entry=next(e['payload'] for e in chain if e['event']=='native_preselection_snapshot' and e['payload']['process']['after_commit']==1)
  sub=parent/entry['process']['snapshot_id'];pins=entry['anchors']
  current=restore(sub,expected_payload_sha256=pins['payload_sha256'],expected_manifest_sha256=pins['manifest_sha256'],expected_runtime_identity=entry['process']['runtime_identity'],expected_source_sha256=entry['process']['source_sha256'])
  net=current['net'];process=current['process'];prefix=json.loads((sub/'native_prefix_result.json').read_bytes())
  assert prepare_continuation(reflection,runner,net,process,prefix,sha(Path(reflection.__file__)))
  wrong_metrics=copy.deepcopy(prefix);wrong_metrics['executed_actions'][-1]['post_metrics']['vmin']+=.001
  for reason,bad in [('missing_prefix_action',{**prefix,'executed_actions':[]}),('wrong_last_metrics',wrong_metrics),('wrong_episode',{**prefix,'scenario_id':'OTHER'}),('wrong_prefix_cost',{**prefix,'counters':{'fallback_tests':1}})]:
   try:prepare_continuation(reflection,runner,net,process,bad,sha(Path(reflection.__file__)))
   except ValueError:rejections.append({'case':'negative_boundary','reason':reason})
   else:raise AssertionError(reason+' accepted')
  original_Q=runner.rescue.Q_SWEEP;runner.rescue.Q_SWEEP=[1]
  try:
   try:prepare_continuation(reflection,runner,net,process,prefix,sha(Path(reflection.__file__)))
   except ValueError:rejections.append({'case':'negative_boundary','reason':'changed_Q_grid'})
   else:raise AssertionError('Changed Q accepted')
  finally:runner.rescue.Q_SWEEP=original_Q
  try:prepare_continuation(reflection,runner,net,{**process,'absolute_deadline_utc':'2000-01-01T00:00:00+00:00'},prefix,sha(Path(reflection.__file__)))
  except ValueError:rejections.append({'case':'negative_boundary','reason':'expired_deadline'})
  else:raise AssertionError('Expired deadline accepted')
  directory=OUT/'negative_before_solver';directory.mkdir();write(directory/'owner.claim',{'actual_pid':os.getpid(),'protocol_sha256':protocol_sha,'measurement_kind':'SOFTWARE_MOCK_ONLY'})
  journal=EvidenceJournal(directory/'journal.jsonl',protocol_sha);count_before=len(mock_entries)
  try:
   with NativePreservation(pp,runner,process['zone_configuration']['zones'],process,directory,journal) as rec:
    rec.decision=process
    try:rec.solve(net,algorithm='WRONG')
    except PreservationStop:rejections.append({'case':'negative_boundary','reason':'wrong_solver_options'})
    else:raise AssertionError('Changed solver entered')
    def fail_journal(*args):raise OSError('LABELLED_MOCK_STORAGE_FAILURE')
    journal.emit=fail_journal
    try:rec.solve(net,**SOLVER_ROLES['commit'])
    except PreservationStop:rejections.append({'case':'negative_boundary','reason':'journal_failure'})
    else:raise AssertionError('Unpreserved solver entered')
    assert rec.costs['PF_attempts']==0 and len(mock_entries)==count_before
  finally:journal.close()
 finally:pp.runpp=real_runpp
 assert pp.runpp is real_runpp
 report={'all_eight_native_tail_control_flow_cases_passed':True,'cases':rows,'known_rejections':rejections,'total_mock_PP_entries':len(mock_entries),'actual_nonlinear_PF_model_optimizer_fit_forecast_cloud_calls':0,'actual_solved_HierGrid_resume_equivalence':'UNTESTED','physical_sequence_opportunity_and_LLM_value':'UNMEASURED','source_AST_tail_preservation_and_fixture_persistence':'PASSED_SOFTWARE_ONLY','workflow_seconds_before_report_and_manifest':time.perf_counter()-started,'owner_pid':os.getpid(),'no_ready_performance_GPU_campaign':True}
 write(OUT/'Software_Readiness.json',report)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.relative_to(OUT).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.rglob('*') if p.is_file()}})
 print(json.dumps({k:v for k,v in report.items() if k not in ['cases','known_rejections']}))
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'exception':type(exc).__name__,'message':str(exc),'state':'TERMINAL_SOFTWARE_PARTIAL_NO_AUTOMATIC_RETRY','actual_new_scientific_calls':0})
  raise
