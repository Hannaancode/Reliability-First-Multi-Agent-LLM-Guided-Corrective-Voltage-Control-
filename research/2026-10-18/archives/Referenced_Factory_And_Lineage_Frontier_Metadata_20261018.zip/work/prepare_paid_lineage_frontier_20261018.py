"""Complete attempt frontier for the inspected lineage; no execution permission.

Recorded closed receipt is not independent certification of every unselected
physical outcome. A future consumer must validate its saved source result or
block it, never repeat primary physics. Other case histories are out of scope.
"""
import gzip,hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];B=R/'outputs/paid_lineage_frontier_20261018'
OLD=R/'outputs/full_receding_paid_campaign_20261015';W=R/'outputs/receding_warm_dependency_closure_20261015/Paid_Warm_Dependencies.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def canon(d):return json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
def put(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    manifest=read(OLD/'actual/Closed_Manifest.json');sourceaudit=R/'outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json'
    assert read(sourceaudit)['status'].startswith('PASS_ALL_RECORDED')
    put(B/'Protocol.json',{'role':'SOURCE_COMPATIBLE_ALL_ATTEMPT_DEDUPLICATION_FRONTIER_FOR_INSPECTED_FOUR_ROOT_LINEAGE',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'preparation_bound_seconds':300,'source_sha256':sha(Path(__file__)),
        'journal_sha256':manifest['members']['scientific.jsonl']['sha256'],'warm_dependency_sha256':sha(W),'scoped_audit_sha256':sha(sourceaudit),
        'selection':'All old warm cache/blocked keys and every new primary attempt in the entire terminal partial journal; no success/world/outcome filtering.',
        'classifications':'RECORDED_CLOSED_RECEIPT_REQUIRES_INDEPENDENT_SOURCE_RESULT_CHECK; PRIOR_ATTEMPT_NO_CLOSED_RECEIPT_BLOCK_REEXECUTION; warm paid receipt; previously incomplete blocked.',
        'unknown_rule':'Outside index means only NOT_IN_THIS_LINEAGE_INDEX, never permission to execute or proof globally unexecuted. New root/history scopes require separate closure.',
        'scientific_calls':0,'does_not_resume_old_study_or_certify_full_policy':True})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    warm=read(W);entries={k:{'classification':'WARM_PAID_RECEIPT_RETAIN_OLD_COSTS','receipt_id':v['receipt_id'],'warm_key':k} for k,v in warm['cache'].items()}
    for key in warm['blocked_prior_incomplete_identities']:
        assert key not in entries;entries[key]={'classification':'PRIOR_INCOMPLETE_BLOCK_REEXECUTION'}
    previous='0'*64;full=hashlib.sha256();intents={};closed={};receipt_pids=set();primary_keys={};returns=exceptions=0;bytes_read=0
    journal=OLD/'actual/scientific.jsonl';protocol=sha(OLD/'Protocol.json')
    with journal.open('rb') as stream:
        while line:=stream.readline():
            assert time.perf_counter()-started<300,'Fixed preparation bound; no extension'
            offset=bytes_read;bytes_read+=len(line);full.update(line);e=json.loads(line)
            assert e['previous_sha256']==previous and e['protocol_sha256']==protocol
            previous=digest(line.rstrip(b'\n'));d=e['data'];name=e['event']
            if name=='PF_intent':
                pid=d['identity'];assert pid not in intents;intents[pid]=d
                if d['context']['phase']=='NEW_PRIMARY_QUERY':
                    c=d['context'];key=c['point']+'|'+c['action_key'];assert key not in entries and key not in primary_keys
                    primary_keys[key]=pid
                    entries[key]={'classification':'PRIOR_ATTEMPT_NO_CLOSED_RECEIPT_BLOCK_REEXECUTION','PF_id':pid}
            elif name in ('PF_return','PF_exception'):
                pid=d['PF_id'];assert pid in intents and pid not in closed
                outcome='RETURNED' if name=='PF_return' else 'EXCEPTION_OPERATIONAL_REJECT_FEASIBILITY_UNKNOWN'
                closed[pid]={'data_sha256':digest(canon(d)),'outcome':outcome}
                if name=='PF_return':returns+=1
                else:exceptions+=1
            elif name=='every_query_receipt_closed_before_more_science' and d['record'].get('actual_measured_receipt'):
                m=d['record']['actual_measured_receipt'];pid=m['PF_id'];assert digest(canon(m))==closed[pid]['data_sha256']
                c=intents[pid]['context'];key=c['point']+'|'+c['action_key'];assert d['aid']==c['action_key'] and primary_keys[key]==pid
                row={k:d['row'][k] for k in ['kind','receiver','q','donor_index','donor_bus']};assert digest(canon(row))==d['aid']
                descriptor={'classification':'RECORDED_CLOSED_RECEIPT_REQUIRES_INDEPENDENT_SOURCE_RESULT_CHECK',
                    'PF_id':pid,'outcome':closed[pid]['outcome'],'receipt_id':d['record']['receipt_id'],
                    'journal_offset':offset,'journal_bytes':len(line),'journal_line_sha256':digest(line),
                    'PF_close_data_sha256':closed[pid]['data_sha256']}
                if pid in receipt_pids:
                    assert entries[key]['PF_id']==pid and entries[key]['receipt_id']==descriptor['receipt_id']
                else:entries[key]=descriptor;receipt_pids.add(pid)
    assert full.hexdigest()==manifest['members']['scientific.jsonl']['sha256'] and bytes_read==manifest['members']['scientific.jsonl']['bytes']
    result=read(OLD/'actual/Result.json');cost=result['actual_new_costs']
    assert len(intents)==cost['PF_attempts'] and len(closed)==cost['PF_returns']+cost['PF_exceptions']
    assert returns==cost['PF_returns'] and exceptions==cost['PF_exceptions'] and len(primary_keys)==cost['new_query_PF_attempts']
    with gzip.open(B/'All_Lineage_Attempt_Keys.json.gz','wt',encoding='utf-8') as f:json.dump(entries,f,separators=(',',':'))
    summary={'status':'COMPLETE_SOURCE_AND_IDENTITY_FRONTIER_REQUIRES_READER','all_keys':len(entries),'warm_paid':len(warm['cache']),
        'old_blocked':len(warm['blocked_prior_incomplete_identities']),'new_primary_attempts':len(primary_keys),
        'new_primary_with_closed_receipts':len(receipt_pids),'new_primary_without_closed_receipt_BLOCKED':len(primary_keys)-len(receipt_pids),
        'all_actual_attempts_including_replay':len(intents),'recorded_exceptions':exceptions,
        'journal_sha256':full.hexdigest(),'frontier_sha256':sha(B/'All_Lineage_Attempt_Keys.json.gz'),
        'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'scope':'Only this source-compatible lineage, not all141 initial cases; every old cost/adverse/unknown outcome retained. No launch authorization, physical-candidate certification or winning gate.'}
    put(B/'Results.json',summary);put(B/'Closed_Manifest.json',{'members':{str(p.relative_to(B)):sha(p) for p in B.iterdir() if p.is_file()},'new_science':0})
    print(json.dumps(summary))
if __name__=='__main__':main()
