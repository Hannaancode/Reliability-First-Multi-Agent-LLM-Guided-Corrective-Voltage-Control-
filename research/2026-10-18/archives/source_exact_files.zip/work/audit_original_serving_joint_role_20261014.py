"""Original prompt/parser/units and current-only proposal binding; zero models/PF."""
import copy, hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import frozen_checks
from frozen_physics_loader import load_stack, AUDIT
from joint_reallocation_opportunity_core_v1 import load_endpoint, Q_GRID

R = Path(__file__).resolve().parents[1]
B = R/'outputs/original_serving_joint_role_20261014'
OLD = R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
canon = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def put(path, value):
    with path.open('x', encoding='utf8') as file:
        json.dump(value, file, indent=2, allow_nan=False); file.flush(); os.fsync(file.fileno())

def main():
    B.mkdir(exist_ok=False); _, runner, reflection = load_stack()
    assert all(r['all_function_asts_unchanged'] for r in AUDIT)
    meta = json.loads((R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json').read_text('utf8'))
    zones = meta.get('zones', meta); proto = json.loads((OLD/'preparation/Protocol.json').read_text('utf8'))
    cases = []; checks = []; invalid = []
    for entry in proto['current_endpoints']:
        net, cursor, _ = load_endpoint(entry)
        global_uv = runner.rescue.global_uv_buses(net)
        for zone in sorted(zones):
            current = runner.rescue.extract_zone_state_full(net, zone, zones)
            candidates = runner.get_zone_candidate_buses(net, zone, zones, current)
            feedback = reflection.init_feedback_state()
            # Both ACTUAL original contracts are retained as references. They
            # must not be confused with the public7B generic smoke prompt.
            mandatory = runner.build_mandatory_llm_prompt(current, global_uv, candidates, [])
            reflected = reflection.build_two_best_prompt_v2('reflection_v2', current, global_uv, candidates, [], feedback)
            assert 'q_mvar' in mandatory[-1]['content'] and '"52": 100' in mandatory[-1]['content']
            assert json.loads(canon(current)) == current
            # The administrator carries world/teacher/query labels. The real
            # builders receive ONLY current physical view and explicit paid
            # feedback; mutate those hidden labels without changing a view.
            admin = {'world': entry['world'], 'unqueried_labels': {'fake_best': 999},
                     'future_successor': 'UNKNOWN', 'current': copy.deepcopy(current)}
            changed = copy.deepcopy(admin); changed.update(world='different_world',
                unqueried_labels={'fake_best': -999}, future_successor={'fake_vm': .99})
            again = runner.build_mandatory_llm_prompt(changed['current'], global_uv, candidates, [])
            assert again == mandatory
            checks.append(entry['world']+'|'+zone+'|hidden_admin_not_forward_input')
            cases.append({'administrator_world_not_in_forward': entry['world'], 'zone': zone,
                'actual_current_view': current, 'global_current_UV': global_uv, 'candidate_buses': candidates,
                'original_mandatory_messages': mandatory, 'original_reflection_v2_messages': reflected,
                'mandatory_utf8_sha256': hashlib.sha256(canon(mandatory)).hexdigest(),
                'reflection_utf8_sha256': hashlib.sha256(canon(reflected)).hexdigest(),
                'original_prefix_slots_not_reset': cursor['remaining_original_device_operation_slots']})
            if not candidates: continue
            bus = int(candidates[0])
            for q in Q_GRID:
                raw = json.dumps({'proposed_action': {'add_shunts_q_mvar': {str(bus): q}}, 'confidence': .5, 'reason': 'software_control'})
                parsed, valid, error = runner.base_runner.extract_json(raw); assert valid and error is None
                normalized = runner.rescue.normalize_action(parsed)
                assert normalized == {'add_shunts_q_mvar': {str(bus): q}}
                accepted, _ = runner.validate_action_against_candidates(normalized, candidates); assert accepted
            checks.append(entry['world']+'|'+zone+'|all9_positive_original_grid_parse_normalize_units')
            for q in (-25., 0.):
                parsed, valid, _ = runner.base_runner.extract_json(json.dumps({'proposed_action': {'add_shunts_q_mvar': {str(bus): q}}}))
                assert valid and runner.rescue.normalize_action(parsed) is None
            outside = next(b for b in range(118) if b not in candidates)
            accepted, _ = runner.validate_action_against_candidates({'add_shunts_q_mvar': {str(outside): 25.}}, candidates)
            assert not accepted; checks.append(entry['world']+'|'+zone+'|negative_zero_outside_rejected')
            # The ACTUAL historical normalizer accepts additional25-spaced
            # magnitudes; retain this fact. The NEW joint9grid gate must reject
            # them explicitly, never silently rewrite the original parser.
            extra = runner.rescue.normalize_action({'proposed_action': {'add_shunts_q_mvar': {str(bus): 175.}}})
            assert extra == {'add_shunts_q_mvar': {str(bus): 175.}}
            assert 175. not in Q_GRID
            invalid.append({'world': entry['world'], 'zone': zone, 'original_normalized_175_legal_to_old_parser': extra,
                            'new_joint9grid_eligibility': False, 'old_parser_unchanged': True})
    assert len(cases) == 16
    put(B/'Actual_Original_Causal_Serving_Cases.json', {'cases': cases,
        'queries_models_optimizers_newPF': 0, 'messages_are_not_actual_model_performance': True})
    put(B/'Original_Parser_And_New_Action_Grid_Differences.json', {'rows': invalid,
        'public7B_negative_primary_results_never_repaired': True})
    put(B/'Independent_Serving_Role_Checkpoint.json', {'status': 'PASS_ACTUAL_ORIGINAL_SOURCE_CURRENT_VIEW_PROMPT_PARSE_UNIT_SOFTWARE_BINDING',
        'checks': checks, 'case_count': len(cases), 'source_sha256': {str(Path(a['file']).relative_to(R)): a['sha256'] for a in AUDIT},
        'private_adapter_config_sha256': sha(R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/adapter_config.json'),
        'frozen_nine': frozen_checks(), 'model_forward_generation_optimizer_PF_calls': 0,
        'actual_model_loader_context_token_mask_memory_cost_and_cold_output_checks': 'NOT_YET_EXECUTED',
        'model_joint_donor_or_process_learning': 'NOT_IMPLEMENTED_OR_PROVED',
        'next_method_requirement': 'Specify a causal policy that actually changes decisions/acquisition; complete same-action exhaustive greedy already fixes its immediate argmax, so recipient ordering alone cannot establish decision benefit.',
        'no_novelty_or_winning_probability_claim': True})
    entry = {'event_id': 'original_private_serving_joint_role_source_binding_20261014',
        'method': 'Bind both actual original mandatory/reflection_v2 contracts, original parser/normalizer and16current-only views fromALL4roots, with positive-unit and hidden-administrator controls.',
        'result': 'Software/source checks PASS; all9positiveQ values accepted exactly, negative/zero/out-of-candidate controls rejected. Original normalizer also accepts175; NEWjoint9grid must explicitly reject it without changing original parser. Zero model/PF/optimizer calls.',
        'improvements': 'Correct original trained-model contract is now concrete and causal for future integration; preserve command-format training rather than confusing it with the failed public7B generic prompt.',
        'limitations': 'No model loaded, no measured token/context/memory/coldgeneration or physical policy value. Full exhaustive immediate-argmax role remains a ceiling; simple recipient ordering does not add decision benefit.',
        'decision': 'Keep actual CPUfullsuffix science immutable. FutureLLM protocol needs decision/acquisition role, same-actuation numerical control and actual loader/serving/economic gates before launch.',
        'sources': [str((B/'Independent_Serving_Role_Checkpoint.json').relative_to(R)), str((B/'Actual_Original_Causal_Serving_Cases.json').relative_to(R)),
                    str((B/'Original_Parser_And_New_Action_Grid_Differences.json').relative_to(R)), 'work/audit_original_serving_joint_role_20261014.py']}
    put(B/'Research_Progress_Entry.json', entry)
    done = subprocess.run([str(R/'work/physics_env/Scripts/python.exe'), '-X', 'utf8', str(R/'work/append_research_progress.py'),
        '--entry-json', str(B/'Research_Progress_Entry.json')], capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    assert done.returncode == 0, done.stderr
    print(json.dumps({'case_count': len(cases), 'checks': len(checks), 'status': 'PASS_SOURCE_SOFTWARE_ONLY', 'model_PF_optimizer_calls': 0}))

if __name__ == '__main__': main()
