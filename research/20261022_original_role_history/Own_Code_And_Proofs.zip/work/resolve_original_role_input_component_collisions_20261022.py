"""Resolve ALL scoped shunt collisions using preserved physical load inputs.

Distinct nominal bus active-load inputs prove the full PF inputs differ.
No matching shunt alone is called an executed query; no solve is repeated.
"""
import hashlib, json, os, pickle, sys, time
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_input_collision_resolution_20261022'
H = R / 'outputs/original_role_additional_history_scope_v2_20261022'
Q = R / 'outputs/original_role_prior_input_scope_20261022'
P = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'

def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def key(x): return hashlib.sha256(canonical(x)).hexdigest()
def write(folder, name, value):
    with (folder / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())

def runtime():
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandas as pd
    import pandapower as pp
    def forbidden(*a, **k): raise BaseException('No physics/model call in collision resolution')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, forbidden)
    return pd

def load_component(bus, load):
    values = {}
    for _, row in load.iterrows():
        b = int(row['bus'])
        if not bool(row['in_service']) or not bool(bus.at[b, 'in_service']): continue
        val = Fraction(float(row['p_mw'])) * Fraction(float(row['scaling']))
        values[b] = values.get(b, Fraction(0)) + val
    return [[b, [v.numerator, v.denominator]] for b, v in sorted(values.items()) if v]

def roots():
    result = {}
    for row in read(P / 'Exact_Paid_Root_State_Bindings.json'):
        p = R / row['full_actual_root_payload']; assert sha(p) == row['payload_sha256']
        net = pickle.loads(p.read_bytes())['net']
        result[row['root']] = load_component(net.bus, net.load)
    return result

def produce():
    O.mkdir(exist_ok=False); started = time.perf_counter(); pd = runtime()
    assert read(H / 'independent_audit/Independent_Audit.json')['status'].startswith('PASS_ALL_NAMED9297')
    hres = read(H / 'Result.json'); targets = read(Q / 'All45_Indexed_Scope_Query.json'); targetload = roots()
    write(O, 'Protocol.json', {'at_utc': datetime.now(timezone.utc).isoformat(), 'source_sha256': sha(Path(__file__)),
        'fixed_producer_seconds': 600, 'fixed_reader_seconds': 600,
        'selection': 'ALL36 source references matching ALL18colliding target shunt components; remaining27targets excluded from all9297namedattempts without load filtering',
        'prior_independent_audit_sha256': sha(H / 'independent_audit/Independent_Audit.json'),
        'prior_result_sha256': sha(H / 'Result.json'), 'target_source_sha256': sha(Q / 'All45_Indexed_Scope_Query.json'),
        'criterion': 'Different exact per-bus nominal active load (p_mw*scaling, active loads/buses) implies different full physical inputs. Matching load remainsUNKNOWN; never repeat science to resolve it.',
        'limits': 'Named lineages only, native solver source preserves load nominal/scaling/in_service fields. No universal absence, root reexecution, physical replay, or PF permission.', 'new_scientific_calls': 0})
    write(O, 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(Path(__file__))})
    refs = [r for rows in hres['matching_refs'].values() for r in rows]
    assert len(refs) == 36
    records = []
    for ref in refs:
        if 'anchor' not in ref: continue
        folder = (R / ref['journal']).parent / ref['anchor']['relative']
        assert sha(folder / 'Manifest.json') == ref['anchor']['manifest_sha256']
        payload = (folder / 'trusted_local_net.pkl').read_bytes()
        assert hashlib.sha256(payload).hexdigest() == ref['anchor']['payload_sha256']
        net = pickle.loads(payload)['net']; load = load_component(net.bus, net.load)
        records.append({**ref, 'load_component': load, 'input_source_kind': 'ANCHORED_NATIVE_CAPSULE'})
    wanted = {}
    for ref in refs:
        if 'anchor' in ref: continue
        wanted.setdefault(ref['journal'], {}).setdefault(canonical(ref['identity']).decode(), []).append(ref)
    from close_original_role_additional_histories_v2_20261022 import observation_component
    oldsource = read(H / 'Protocol.json')['sources']
    for rel, ids in wanted.items():
        path = R / rel; digest = hashlib.sha256()
        with path.open('rb') as f:
            while True:
                offset = f.tell(); raw = f.readline()
                if not raw: break
                digest.update(raw); e = json.loads(raw)
                if e['event'] != 'solver_closed': continue
                k = canonical(e['identity']).decode(); remaining = ids.get(k)
                if not remaining: continue
                t = e['observation']['physical_tables']; component = observation_component(t)
                matches = [r for r in remaining if r['component_sha256'] == component]
                if not matches: continue
                ref = matches[0]; remaining.remove(ref)
                bus = pd.DataFrame(t['bus']['values'], index=t['bus']['index'], columns=t['bus']['columns'])
                load = pd.DataFrame(t['load']['values'], index=t['load']['index'], columns=t['load']['columns'])
                records.append({**ref, 'input_source_kind': 'ANCHORED_OBSERVATION_LINE',
                    'line_offset': offset, 'line_bytes': len(raw), 'line_sha256': hashlib.sha256(raw).hexdigest(),
                    'load_component': load_component(bus, load)})
                assert time.perf_counter() - started < 600
        assert digest.hexdigest() == oldsource[rel] and not any(ids.values())
    assert len(records) == 36
    decisions = []
    for target in targets:
        matches = [r for r in records if r['component_sha256'] == target['physical_component_sha256']]
        pair = []
        for r in matches:
            a = dict((b, v) for b, v in targetload[target['root']]); b = dict((b, v) for b, v in r['load_component'])
            diff = [bus for bus in sorted(set(a) | set(b)) if a.get(bus, [0, 1]) != b.get(bus, [0, 1])]
            pair.append({'source_reference': {k: v for k, v in r.items() if k != 'load_component'},
                'different_nominal_load_input': bool(diff),
                'first_differing_bus': diff[0] if diff else None,
                'target_exact_nominal_P_MW': a.get(diff[0], [0, 1]) if diff else None,
                'prior_exact_nominal_P_MW': b.get(diff[0], [0, 1]) if diff else None})
        decisions.append({'root': target['root'], 'bus': target['bus'], 'q_mvar': target['q_mvar'],
            'shunt_matches': len(pair), 'source_checks': pair,
            'disposition': 'EXCLUDED_ALL9297_NAMED_INPUTS' if all(x['different_nominal_load_input'] for x in pair) else 'UNKNOWN_LOAD_AND_SHUNT_MATCH'})
    write(O, 'All36_Colliding_Input_References.json', records)
    write(O, 'All45_Named_Scope_Decisions.json', decisions)
    result = {'status': 'COMPLETE_ALL36_COLLISION_LOAD_CHECKS', 'all_targets': 45, 'checked_colliding_refs': 36,
        'excluded_in_named9297_scope': sum(x['disposition'] == 'EXCLUDED_ALL9297_NAMED_INPUTS' for x in decisions),
        'remaining_load_shunt_matches_UNKNOWN': sum(x['disposition'] != 'EXCLUDED_ALL9297_NAMED_INPUTS' for x in decisions),
        'new_scientific_calls': 0, 'not_global_historical_closure_or_PF_permission': True, 'workflow_seconds': time.perf_counter() - started}
    write(O, 'Result.json', result)
    write(O, 'Closed_Manifest.json', {'members': {p.name: sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps(result))

def audit():
    A = O / 'independent_audit'; A.mkdir(exist_ok=False); started = time.perf_counter(); pd = runtime()
    p = read(O / 'Protocol.json'); assert sha(Path(__file__)) == p['source_sha256']
    assert sha(H / 'independent_audit/Independent_Audit.json') == p['prior_independent_audit_sha256']
    assert all(sha(O / rel) == h for rel, h in read(O / 'Closed_Manifest.json')['members'].items())
    records = read(O / 'All36_Colliding_Input_References.json'); decisions = read(O / 'All45_Named_Scope_Decisions.json')
    assert len(records) == 36 and len(decisions) == 45
    def independently_sum(bus, load):
        totals = {}
        for i in load.index:
            b = int(load.loc[i, 'bus'])
            if not bool(load.loc[i, 'in_service']) or not bool(bus.loc[b, 'in_service']): continue
            numerator = Fraction.from_float(float(load.loc[i, 'p_mw']))
            value = numerator * Fraction.from_float(float(load.loc[i, 'scaling']))
            totals[b] = totals.get(b, Fraction()) + value
        return [[b, [v.numerator, v.denominator]] for b, v in sorted(totals.items()) if v]
    for r in records:
        assert time.perf_counter() - started < 600
        if r['input_source_kind'] == 'ANCHORED_NATIVE_CAPSULE':
            path = (R / r['journal']).parent / r['anchor']['relative'] / 'trusted_local_net.pkl'
            payload = path.read_bytes(); assert hashlib.sha256(payload).hexdigest() == r['anchor']['payload_sha256']
            net = pickle.loads(payload)['net']; bus, load = net.bus, net.load
        else:
            with (R / r['journal']).open('rb') as f: f.seek(r['line_offset']); raw = f.read(r['line_bytes'])
            assert hashlib.sha256(raw).hexdigest() == r['line_sha256']
            e = json.loads(raw); assert e['event'] == 'solver_closed' and e['identity'] == r['identity']
            t = e['observation']['physical_tables']
            bus = pd.DataFrame(t['bus']['values'], index=t['bus']['index'], columns=t['bus']['columns'])
            load = pd.DataFrame(t['load']['values'], index=t['load']['index'], columns=t['load']['columns'])
        assert independently_sum(bus, load) == r['load_component']
    source = read(Q / 'All45_Indexed_Scope_Query.json')
    targetloads = roots()
    assert [(x['root'], x['bus'], x['q_mvar']) for x in source] == [(x['root'], x['bus'], x['q_mvar']) for x in decisions]
    checks = 0
    for t, d in zip(source, decisions):
        rs = [r for r in records if r['component_sha256'] == t['physical_component_sha256']]
        assert len(rs) == d['shunt_matches'] == len(d['source_checks'])
        for r, witness in zip(rs, d['source_checks']):
            a = dict(targetloads[t['root']]); b = dict(r['load_component']); i = witness['first_differing_bus']
            assert a.get(i, [0, 1]) == witness['target_exact_nominal_P_MW']
            assert b.get(i, [0, 1]) == witness['prior_exact_nominal_P_MW']
            assert a.get(i, [0, 1]) != b.get(i, [0, 1]) and witness['different_nominal_load_input']; checks += 1
        assert d['disposition'] == 'EXCLUDED_ALL9297_NAMED_INPUTS'
    assert checks == 36
    result = {'status': 'PASS_ALL36_SOURCE_BOUND_LOAD_COLLISION_EXCLUSIONS_ALL45_NAMED_SCOPE',
        'all_targets': 45, 'source_bound_load_witnesses': 36, 'new_scientific_calls': 0,
        'not_universal_history_closure_or_PF_authority': True, 'workflow_seconds': time.perf_counter() - started}
    write(A, 'Independent_Audit.json', result)
    write(A, 'Closed_Manifest.json', {'members': {'Independent_Audit.json': sha(A / 'Independent_Audit.json')}})
    print(json.dumps(result))

if __name__ == '__main__': audit() if '--reader' in sys.argv else produce()
