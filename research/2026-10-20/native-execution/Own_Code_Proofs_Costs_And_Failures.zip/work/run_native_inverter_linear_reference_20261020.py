"""One new current-Jacobian/native-cap LP and one previously unexecuted PF identity."""
import hashlib,json,os,pickle,time,traceback
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
PREP=ROOT/'outputs/native_inverter_linear_reference_preparation_20261020'
OUT=ROOT/'outputs/native_inverter_linear_reference_20261020'
TPA=ROOT/'outputs/tpa_native_second_identity_engineering_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();p=json.loads((PREP/'Protocol.json').read_text(encoding='utf-8'))
    for f,h in p['sources'].items():assert sha(ROOT/'work'/f)==h
    for f,h in p['inputs'].items():assert sha(ROOT/f)==h
    put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'protocol_sha256':sha(PREP/'Protocol.json'),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    ack=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    costs={'public_derivative_attempts':0,'public_derivative_returns':0,'LU_factorizations':0,'linear_RHS_solves':0,'LP_attempts':0,'LP_returns':0,'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'model_optimizer_GPU_calls':0,'reused_PF_identities':0}
    journal=(OUT/'Journal.jsonl').open('x',encoding='utf-8');prev='0'*64
    def event(kind,**data):
        nonlocal prev
        r={'kind':kind,'elapsed_seconds':time.monotonic()-start,'previous':prev,**data};h=hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':')).encode()).hexdigest();journal.write(json.dumps({'event':r,'sha256':h})+'\n');journal.flush();os.fsync(journal.fileno());prev=h
        assert time.monotonic()-start<p['worker_bound_seconds']
    try:
        import numpy as np
        import pandapower as pp
        from scipy.sparse import bmat,csc_matrix
        from scipy.sparse.linalg import splu
        from scipy.optimize import linprog
        from pandapower.pypower.dSbus_dV import dSbus_dV
        from pandapower.pypower.makeSbus import makeSbus
        from native_inverter_linear_reference_core_20261020 import problem,metric
        from candidate_process_evidence_utils import frozen_checks
        put(OUT/'Frozen_Before.json',frozen_checks())
        with (TPA/'PF0_before.pkl').open('rb') as f:root=pickle.load(f)
        with (TPA/'PF1_before.pkl').open('rb') as f:net=pickle.load(f)
        # PF1-before contains the solved root internal state, followed only by Q assignment.
        net.sgen['q_mvar']=root.sgen.q_mvar.to_numpy(copy=True)
        for name in ['bus','line','trafo','sgen','load','ext_grid','gen','shunt','switch']:
            assert net[name].equals(root[name]),name
        fields=np.load(TPA/'PF0_fields.npz')
        for name in fields.files:assert np.array_equal(net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float),fields[name],equal_nan=True),name
        vm=net.res_bus.vm_pu.to_numpy(copy=True);q0=net.sgen.q_mvar.to_numpy(copy=True);it=net._ppc['internal'];v=it['V'];y=it['Ybus'];pq=it['pq'];lookup=net._pd2ppc_lookups['bus']
        assert len(it['pv'])==0 and len(pq)==321 and len(vm)==322 and len(q0)==38
        assert np.max(np.abs(vm-np.abs(v)[lookup[net.bus.index.to_numpy()]]))<1e-14
        sbus=makeSbus(net._ppc['baseMVA'],net._ppc['bus'],net._ppc['gen']);kcl=float(np.max(np.abs(v*np.conj(y@v)-sbus)));assert kcl<=1e-7
        maxima=np.array(json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text(encoding='utf-8'))['native_column_max'])
        caps=.8*np.sqrt((1.2*maxima)**2-net.sgen.p_mw.to_numpy()**2);assert np.all(np.abs(q0)<=caps+1e-14)
        event('root_cached_identity_verified',no_root_PF_rerun=True,KCL_max_pu=kcl)
        costs['public_derivative_attempts']+=1;event('dSbus_dV_attempt');t=time.monotonic();dvm,dva=dSbus_dV(y,v);costs['public_derivative_returns']+=1;event('dSbus_dV_return',seconds=time.monotonic()-t)
        j=bmat([[dva[pq,:][:,pq].real,dvm[pq,:][:,pq].real],[dva[pq,:][:,pq].imag,dvm[pq,:][:,pq].imag]],format='csc')
        rhs=np.zeros((642,38));order={int(bus):i for i,bus in enumerate(pq)}
        for col,bus in enumerate(net.sgen.bus):rhs[321+order[int(lookup[int(bus)])],col]=1/net._ppc['baseMVA']
        event('LU_factorization_attempt');t=time.monotonic();factor=splu(j);costs['LU_factorizations']+=1;event('LU_factorization_return',seconds=time.monotonic()-t)
        event('linear_38RHS_solve_attempt');t=time.monotonic();x=factor.solve(rhs);costs['linear_RHS_solves']+=38;event('linear_38RHS_solve_return',seconds=time.monotonic()-t)
        residual=float(np.max(np.abs(j@x-rhs)));assert residual<=1e-9
        full=np.zeros((322,38));full[pq]=x[321:];s=full[lookup[net.bus.index.to_numpy()]]
        c,a,b,bounds=problem(vm,s,q0,caps)
        np.savez(OUT/'Linear_Problem.npz',vm=vm,root_q=q0,caps=caps,sensitivity=s,J=j.toarray(),rhs=rhs,response=x,c=c,A=a,b=b,pq=pq,lookup=lookup,Y=y.toarray(),V=v)
        costs['LP_attempts']+=1;event('LP_attempt',options=p['LP_options']);t=time.monotonic();sol=linprog(c,A_ub=a,b_ub=b,bounds=bounds,method='highs',options=p['LP_options']);costs['LP_returns']+=1
        put(OUT/'LP_Return.json',{'success':bool(sol.success),'status':int(sol.status),'message':str(sol.message),'nit':int(sol.nit),'seconds':time.monotonic()-t});event('LP_return',success=bool(sol.success),status=int(sol.status),seconds=time.monotonic()-t)
        assert sol.success,'Fixed LP failed; preserve partial, no solver/settings retry'
        np.savez(OUT/'LP_Solution.npz',x=sol.x,ineq_marginals=sol.ineqlin.marginals,lower_marginals=sol.lower.marginals,upper_marginals=sol.upper.marginals)
        q=sol.x[:38].copy();assert np.isfinite(q).all() and np.all(np.abs(q)<=caps+1e-10)
        assert np.max(a@sol.x-b)<=1e-7
        predicted=vm+s@(q-q0);net.sgen['q_mvar']=q;np.save(OUT/'Absolute_Q_Mvar.npy',q)
        # Exact previously evaluated Q identities are reused, never physically remeasured.
        matching=None
        for f in ['PF0_before.pkl','PF1_before.pkl']:
            with (TPA/f).open('rb') as stream:prior=pickle.load(stream)
            if all(net[t].equals(prior[t]) for t in ['bus','line','trafo','sgen','load','ext_grid','gen','shunt','switch']):matching=int(f[2])
        with (OUT/'Candidate_Before.pkl').open('xb') as f:pickle.dump(net,f,protocol=5)
        if matching is not None:
            costs['reused_PF_identities']+=1;event('exact_old_PF_identity_reused',source_number=matching)
            stored=np.load(TPA/f'PF{matching}_fields.npz');actual_vm=stored['res_bus'][:,0];actual_q=q
            np.savez(OUT/'Candidate_Fields.npz',**{n:stored[n] for n in stored.files})
            nonlinear_kcl=None
        else:
            costs['PF_attempts']+=1;event('PF_attempt',before_sha256=sha(OUT/'Candidate_Before.pkl'));t=time.monotonic()
            try:pp.runpp(net)
            except BaseException as e:costs['PF_exceptions']+=1;event('PF_exception',type=type(e).__name__,seconds=time.monotonic()-t);raise
            costs['PF_returns']+=1;assert net.converged
            fv=net._ppc['internal']['V'];fy=net._ppc['internal']['Ybus'];fs=makeSbus(net._ppc['baseMVA'],net._ppc['bus'],net._ppc['gen']);nonlinear_kcl=float(np.max(np.abs(fv*np.conj(fy@fv)-fs)));assert nonlinear_kcl<=1e-7
            np.savez(OUT/'Candidate_Fields.npz',**{name:net[name].select_dtypes(include=[np.number]).to_numpy(dtype=float) for name in fields.files})
            actual_vm=net.res_bus.vm_pu.to_numpy(copy=True);actual_q=net.sgen.q_mvar.to_numpy(copy=True);event('PF_return',seconds=time.monotonic()-t,KCL_max_pu=nonlinear_kcl)
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_AWAITING_INDEPENDENT_REPLAY','identity':p['identity'],'costs':costs,'root':metric(vm,q0),'linear_prediction':metric(predicted,q),'actual':metric(actual_vm,actual_q),'actual_upper_protection_pass':bool(np.max(actual_vm)<=1.05+1e-8),'linear_equation_residual':residual,'nonlinear_KCL_max_pu':nonlinear_kcl,'workflow_seconds':time.monotonic()-start,'method':'Centralized current-Jacobian LP, native L1 mean deviation plus .1mean|Q|, same native inverter caps; one solve/final action only. No relinearization or outcome-driven retry.','information_difference':'Full current Ybus/solved operating point available to numerical reference; TPA uses distributed current/history/seasonal embeddings. Not equally informed model-superiority evidence.','our_LLM_or_benchmark_superiority_claim':False,'reused_identity':matching}
        put(OUT/'Frozen_After.json',frozen_checks());put(OUT/'Result.json',result);event('closed',result_sha256=sha(OUT/'Result.json'));journal.close()
        put(OUT/'Closed_Manifest.json',{'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.iterdir() if f.is_file()],'journal_last_sha256':prev,'costs':costs})
        print(json.dumps({'status':result['status'],'root_UV':result['root']['UV'],'actual':result['actual'],'costs':costs}))
    except BaseException as e:put(OUT/'Failure.json',{'exception':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'costs':costs,'workflow_seconds':time.monotonic()-start});journal.close();raise
if __name__=='__main__':main()
