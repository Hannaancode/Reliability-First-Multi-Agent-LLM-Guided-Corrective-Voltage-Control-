"""Additional closed-artifact audit; no model/optimizer/solver execution."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math, os, subprocess, zipfile
import torch

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/llm_value_candidate_development_20261009'
PREP = BASE / 'reliable_replication_preparation_v2'
EX = BASE / 'reliable_replication_execution_control_v3'
SCI = EX / 'staged/study'
OUT = BASE / 'reliable_replication_cost_and_preservation_audit'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def write(name, value):
    with (OUT / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)

def absent(pid):
    cmd = f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {int(pid)}'; if ($p) {{$p.CommandLine}}"
    r = subprocess.run(['powershell', '-NoProfile', '-Command', cmd],
                       capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    assert r.returncode == 0 and not r.stdout.strip(), 'Owned writer must end before this audit'

def main():
    status = read(EX / 'status.json')
    assert status['runtime_released'] and status['all_actual_artifacts_preserved']
    assert status['remote_exit_code'] == 0
    absent(int((EX / 'owner.claim').read_text()))
    absent(read(BASE / 'reliable_replication_audit_continuation_control_v3/owner.claim')['actual_pid'])
    primary = BASE / 'reliable_replication_external_audit'
    assert read(BASE / 'reliable_replication_verified_scientific_package/status.json')['stage'] == 'complete_verified_scientific_audit_and_control_only_seal'
    absent(read(primary / 'owner.claim')['actual_pid'])
    assert not OUT.exists(), 'No duplicate audit or overwrite'
    OUT.mkdir()
    write('owner.claim', {'pid': os.getpid(), 'source_sha256': sha(Path(__file__)),
                         'started_at_utc': datetime.now(timezone.utc).isoformat()})
    torch.set_num_threads(2)
    protocol = read(PREP / 'protocol.json')
    events_raw = (SCI / 'events.jsonl').read_bytes()
    events = [json.loads(line) for line in events_raw.splitlines()]
    assert events_raw.endswith(b'\n')
    assert all(a['elapsed_seconds'] <= b['elapsed_seconds'] for a, b in zip(events, events[1:]))
    ledger = read(EX / 'Preservation_Acknowledgement_Ledger.json')
    published = [e for e in events if e['event'] == 'preservation_package_requested']
    acknowledged = [e for e in events if e['event'] == 'preservation_acknowledged']
    assert [e['package'] for e in published] == [e['package'] for e in acknowledged] == list(range(18))
    assert [e['number'] for e in ledger] == list(range(18))
    package_rows = []
    phase_order = ['untrained_and_initial_identity', 'first25_complete_state'] + ['epoch_complete_state'] * 5 + ['final_scores', 'fresh_reload_and_closed_arm']
    for number, (request, ack_event, ack) in enumerate(zip(published, acknowledged, ledger)):
        arm = protocol['arms'][number // 9]
        folder = EX / 'packages' / f'package_{number:03d}'
        d = read(folder / 'descriptor.json')
        certificate = read(folder / 'CPU_Full_State_Verification.json')
        assert certificate['all_passed'] and certificate['actual_model_optimizer_PF_calls'] == 0
        assert ack == read(folder / 'Sent_Verified_Acknowledgement.json')
        assert ack['identity'] == d['identity'] and ack['number'] == d['number'] == number
        assert ack['identity']['arm'] == request['arm'] == ack_event['arm'] == arm
        assert d['identity']['phase'] == request['phase'] == phase_order[number % 9]
        assert d['identity']['protocol_sha256'] == sha(PREP / 'protocol.json')
        assert d['identity']['program_manifest_sha256'] == sha(PREP / 'Program_Input_Manifest.json')
        archive = folder / 'artifact_package.zip'
        assert sha(archive) == d['archive_sha256'] == ack['archive_sha256'] == ack_event['archive_sha256']
        assert archive.stat().st_size == d['archive_bytes']
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
            assert set(z.namelist()) == set(d['members']) | {'journal_prefix.jsonl'}
            for name, m in d['members'].items():
                raw = z.read(name)
                assert len(raw) == m['bytes'] and hashlib.sha256(raw).hexdigest() == m['sha256']
                assert sha(SCI / name) == m['sha256']
            prefix = z.read('journal_prefix.jsonl')
        assert events_raw.startswith(prefix) and prefix.endswith(b'\n')
        assert len(prefix) == d['journal_prefix_bytes']
        assert hashlib.sha256(prefix).hexdigest() == d['journal_prefix_sha256'] == ack['journal_prefix_sha256'] == ack_event['journal_prefix_sha256']
        assert json.loads(prefix.splitlines()[-1]) == request
        assert ack['all_files_and_full_state_verified_locally']
        total = ack_event['elapsed_seconds'] - request['elapsed_seconds']
        assert 0 <= ack_event['wait_seconds'] <= total + 1e-6
        package_rows.append({'number': number, 'arm': arm, 'phase': request['phase'],
            'archive_bytes': d['archive_bytes'], 'archive_sha256': d['archive_sha256'],
            'publication_transfer_verification_and_ack_wall_seconds': total,
            'remote_ack_wait_seconds': ack_event['wait_seconds'],
            'complete_checkpoint_records': certificate['checkpoint_states']})
    summary = read(SCI / 'summary.json')
    close = [e for e in events if e['event'] == 'science_complete']
    assert len(close) == 1 and close[0]['summary'] == summary
    def near(a, b):
        assert math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-7), (a, b)
    near(sum(e['wait_seconds'] for e in acknowledged), summary['actual_remote_ack_wait_seconds'])
    arms = {}
    for arm in protocol['arms']:
        es = [e for e in events if e['arm'] == arm]
        counts = summary['arms'][arm]
        fa = [e for e in es if e['event'] == 'forward_attempt']
        fr = [e for e in es if e['event'] == 'forward_return']
        ba = [e for e in es if e['event'] == 'backward_attempt']
        br = [e for e in es if e['event'] == 'backward_return']
        oa = [e for e in es if e['event'] == 'optimizer_attempt']
        ore = [e for e in es if e['event'] == 'optimizer_return']
        assert len(fa) == len(fr) == counts['forward_returns'] == 1868
        assert len(ba) == len(br) == len(oa) == len(ore) == counts['optimizer_steps'] == 935
        for attempt, returned in zip(fa, fr):
            assert (attempt['call'], attempt['phase'], attempt['observation_id']) == (returned['call'], returned['phase'], returned['observation_id'])
            assert returned['seconds'] >= 0 and returned['elapsed_seconds'] - attempt['elapsed_seconds'] >= returned['seconds'] - 1e-6
        for attempt, returned in zip(ba, br):
            assert (attempt['epoch'], attempt['observation_id']) == (returned['epoch'], returned['observation_id'])
            assert returned['actual_gradient_tensors'] == (365 if arm == 'copied_original_LoRA_body' else 29)
            assert returned['elapsed_seconds'] >= attempt['elapsed_seconds']
        assert [e['step'] for e in oa] == [e['step'] for e in ore] == list(range(1, 936))
        evaluation = [e for e in es if e['event'] == 'evaluation_closed']
        assert [e['phase'] for e in evaluation] == ['untrained', 'final_epoch5', 'fresh_model_checkpoint_reload']
        near(sum(e['seconds'] for e in evaluation), counts['evaluation_and_reload_seconds'])
        epoch_events = [e for e in es if e['event'] == 'epoch_checkpoint_preserved']
        assert len(epoch_events) == 5
        p = [r for r in package_rows if r['arm'] == arm]
        training_p = [r for r in p if r['phase'] in ['first25_complete_state', 'epoch_complete_state']]
        assert sum(r['publication_transfer_verification_and_ack_wall_seconds'] for r in training_p) <= counts['training_workflow_seconds']
        loads = [r for r in read(SCI / 'Actual_Model_Load_Records.json') if r['arm'] == arm]
        assert len(loads) == 2 and all(r['model_load_seconds'] >= 0 for r in loads)
        arms[arm] = {'actual_optimizer_steps': len(ore), 'actual_forward_returns': len(fr),
            'measured_forward_seconds': sum(e['seconds'] for e in fr),
            'backward_and_clip_event_interval_seconds': sum(b['elapsed_seconds'] - a['elapsed_seconds'] for a, b in zip(ba, br)),
            'optimizer_event_interval_seconds': sum(b['elapsed_seconds'] - a['elapsed_seconds'] for a, b in zip(oa, ore)),
            'model_load_seconds': sum(r['model_load_seconds'] for r in loads),
            'evaluation_workflow_seconds': counts['evaluation_and_reload_seconds'],
            'training_workflow_including_preservation_seconds': counts['training_workflow_seconds'],
            'training_package_publication_transfer_verification_ack_seconds': sum(r['publication_transfer_verification_and_ack_wall_seconds'] for r in training_p),
            'recorded_epoch_checkpoint_write_seconds': sum(e['seconds'] for e in epoch_events),
            'all_preservation_package_bytes': sum(r['archive_bytes'] for r in p)}
    owned_wall = (datetime.fromisoformat(status['finished_at_utc']) - datetime.fromisoformat(status['started_at_utc'])).total_seconds()
    assert owned_wall >= summary['actual_total_science_workflow_seconds'] > 0
    cost = {'arms': arms, 'actual_owned_local_workflow_wall_seconds': owned_wall,
        'actual_remote_science_workflow_seconds': summary['actual_total_science_workflow_seconds'],
        'actual_remote_ack_wait_seconds': summary['actual_remote_ack_wait_seconds'],
        'all_package_workflow_seconds': sum(r['publication_transfer_verification_and_ack_wall_seconds'] for r in package_rows),
        'nested_scopes_must_not_be_added_as_independent_totals': True,
        'component_limits': ['Setup/allocation/final transfer/release included in total owned workflow, not separately timed.',
            'CPU package verification and network transfer included in publication-to-ack wall, not independently timed.',
            'First25 checkpoint write not separately timed; epoch writes separately timed.',
            'These are training/engineering costs, not deployment latency or D-SE physical performance.',
            'Old partial attempts and completed CPU controls remain separate costs, not free or rerun.']}
    write('Actual_Timing_Scope_and_Cost_Arithmetic.json', cost)
    write('All18_Preservation_Package_Proofs.json', package_rows)
    write('Independent_Preservation_and_Timing_Audit.json', {'all_passed': True,
        'actual_packages': 18, 'all_archive_members_prefixes_and_acks_independently_verified': True,
        'actual_forwards': 3736, 'actual_optimizer_returns': 1870,
        'zero_new_model_optimizer_PF_calls': True, 'unknown_time_components_disclosed': True,
        'no_superiority_or_cold_CUDA_resume_claim': True,
        'protocol_sha256': sha(PREP / 'protocol.json'),
        'primary_gate_decision_sha256': sha(primary / 'Prospective_Gate_Decision.json'),
        'source_sha256': sha(Path(__file__)), 'audited_at_utc': datetime.now(timezone.utc).isoformat()})
    write('status.json', {'stage': 'complete', 'all_passed': True})
    print(json.dumps(cost, indent=2))

if __name__ == '__main__':
    main()
