"""Own one inference child, enforce absolute bounds, preserve before terminal ACK."""
from pathlib import Path
import argparse, json, os, signal, subprocess, sys, time
from public_qa_transfer_20261029 import read, json_once, publish_packet, sha

def terminate_owned(child):
    assert child.poll() is None
    assert os.getpgid(child.pid) == child.pid
    os.killpg(child.pid, signal.SIGTERM)
    try: child.wait(timeout=5)
    except subprocess.TimeoutExpired: os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=10)

def watchdog_reason(events, now, began, limits):
    if now - began >= limits['process_seconds']: return 'absolute_process_bound'
    science = next((x['at_monotonic'] for x in events if x['kind'] == 'science_start'), None)
    if science is None and now - began >= limits['setup_seconds']: return 'absolute_setup_bound'
    if science is not None and now - science >= limits['science_seconds']: return 'absolute_science_bound'
    pending = None
    for x in events:
        if x['kind'] in ('generation_attempt', 'engineering_warm_attempt', 'engineering_cold_attempt'): pending = x
        elif x['kind'] in ('generation_return', 'engineering_warm_return', 'engineering_cold_return', 'failure_preserved'): pending = None
    if pending is not None and now - pending['at_monotonic'] >= limits['call_seconds']: return 'single_call_bound'
    return None

def main():
    p = argparse.ArgumentParser(); p.add_argument('--root', required=True); a = p.parse_args()
    root = Path(a.root).resolve(); os.chdir(root)
    configuration = read(root / 'assignment.json'); transfer = root / 'transfer'; transfer.mkdir(exist_ok=False)
    output = root / 'study'; began = time.monotonic()
    json_once(root / 'supervisor.claim', {'pid': os.getpid(), 'parent_pid': os.getppid(),
        'command': sys.argv, 'source_sha256': sha(Path(__file__).read_bytes()), 'started_monotonic': began})
    child = None; reason = None; count = 0
    try:
        with (root / 'worker.log').open('xb') as log:
            child = subprocess.Popen([sys.executable, '-u', 'public_qa_inference_worker_v2_20261029.py',
                '--assignment', 'assignment.json', '--pack', 'pack.json', '--output', 'study'],
                cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            json_once(root / 'child_launch.json', {'pid': child.pid, 'parent_pid': os.getpid(), 'command': child.args})
            while child.poll() is None:
                events = []
                if (output / 'journal.jsonl').exists():
                    for line in (output / 'journal.jsonl').read_bytes().splitlines():
                        try: events.append(json.loads(line))
                        except json.JSONDecodeError: break  # an in-progress append is not a terminal event
                reason = watchdog_reason(events, time.monotonic(), began, configuration)
                if sum(p.stat().st_size for p in output.glob('*') if p.is_file()) > configuration['preservation_bytes']:
                    reason = 'fixed_preservation_bound'
                if reason:
                    terminate_owned(child)
                    break
                request = transfer / f'request_{count:03d}.json'
                if request.exists():
                    assert read(request)['number'] == count
                    publish_packet(output, transfer, count); count += 1
                time.sleep(.1)
            child.wait()
    except BaseException as error:
        reason = reason or 'supervisor_failure_' + type(error).__name__
        if child is not None and child.poll() is None:
            terminate_owned(child)
        json_once(root / 'Supervisor_Failure.json', {'type': type(error).__name__, 'cause': reason})
    assert child is None or child.poll() is not None
    output.mkdir(exist_ok=True)
    # The scientific worker's manifests remain untouched, even after interruption.
    descriptor = publish_packet(output, transfer, count, True, None if child is None else child.returncode, reason)
    json_once(root / 'Remote_End.json', {'actual_child_ended': True, 'child_pid': None if child is None else child.pid,
        'exit_code': None if child is None else child.returncode, 'stop_cause': reason, 'last_packet': count,
        'terminal_packet_sha256': descriptor['sha256'], 'elapsed_seconds': time.monotonic() - began})

if __name__ == '__main__': main()
