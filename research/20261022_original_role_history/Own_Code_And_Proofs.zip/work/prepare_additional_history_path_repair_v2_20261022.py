"""Additive Windows path reader repair; no scientific call or old owner restart."""
from pathlib import Path
import hashlib, json
from datetime import datetime, timezone
R = Path(__file__).resolve().parents[1]
old = R / 'work/close_original_role_additional_histories_20261022.py'
s = old.read_text('utf-8')
s = s.replace('outputs/original_role_additional_history_scope_20261022', 'outputs/original_role_additional_history_scope_v2_20261022')
s = s.replace('work/audit_original_role_additional_histories_20261022.py', 'work/audit_original_role_additional_histories_v2_20261022.py')
s = s.replace('from prior_physical_query_footprints_20261018 import component',
              'from prior_physical_query_footprints_20261018 import component\n    from native_continuation_preservation_v2 import extended_local_path')
needle = "rawparent = (ENG / 'states' / q['parent'] / 'trusted_local_state.pkl').read_bytes()"
assert s.count(needle) == 1
s = s.replace(needle, "rawparent = extended_local_path(ENG / 'states' / q['parent'] / 'trusted_local_state.pkl').read_bytes()")
s = s.replace('refs.append(ref)', "refs.append(ref)\n        if total % 100 == 0:\n            (O / 'Progress.json').write_text(json.dumps({'named_inputs_read': total, 'elapsed_seconds': time.perf_counter() - started}), encoding='utf-8')")
new = R / 'work/close_original_role_additional_histories_v2_20261022.py'
assert not new.exists(); new.write_text(s, 'utf-8')
a = (R / 'work/audit_original_role_additional_histories_20261022.py').read_text('utf-8')
a = a.replace('outputs/original_role_additional_history_scope_20261022', 'outputs/original_role_additional_history_scope_v2_20261022')
a = a.replace('work/close_original_role_additional_histories_20261022.py', 'work/close_original_role_additional_histories_v2_20261022.py')
ar = R / 'work/audit_original_role_additional_histories_v2_20261022.py'
assert not ar.exists(); ar.write_text(a, 'utf-8')
out = R / 'outputs/original_role_additional_history_scope_20261022'
failure = {'at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'TERMINAL_PARTIAL_READ_ONLY_ANALYSIS_FAILURE_PRESERVED',
    'actual_pid': 28532, 'parent_pid': 8716, 'exec_session': 6223, 'exit_code': 1,
    'original_source_sha256': hashlib.sha256(old.read_bytes()).hexdigest(),
    'exception_type': 'FileNotFoundError', 'original_source_line': 102,
    'cause_independently_observed': 'Native engineering saved capsule path exactly260characters; ordinary Windows path reports absent, extended path exists374373bytes.',
    'original_scope_completed_result': 'UNKNOWN_NO_CLOSED_RESULT', 'new_scientific_calls': 0,
    'scientific_retries': 0, 'original_claim_and_protocol_retained': True,
    'additive_repair': 'New source/outputv2, same ALL45targets/math/scope, extended path read only. All original actors ended; no science rerun.'}
(out / 'Preserved_Terminal_Failure.json').write_text(json.dumps(failure, indent=2), 'utf-8')
print(json.dumps({'additive_read_only_v2_prepared': True, 'new_scientific_calls': 0}))
