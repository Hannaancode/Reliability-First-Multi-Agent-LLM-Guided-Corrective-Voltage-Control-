"""Only freeze after actual first prefix replay terminates; no scientific calls."""
import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
from coordinate_native_inverter_linear_reference_20261020 import process
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_missing_only_preparation_20261021';PREFIX=R/'outputs/public13_first_partial_validation_v2_20261021'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)
def main():
    audit=json.loads((PREFIX/'Independent_Audit.json').read_text());assert audit['status']=='PASS_FIRST_INDEPENDENT_PRESERVED_PARTIAL_PREFIX_NATIVE_SOURCE_PROJECTION_POLICY_PHYSICS_AND_COST_VALIDATION'
    end=json.loads((R/'outputs/public13_first_partial_validation_v2_coordination_20261021/End_ACK.json').read_text());assert end['actual_owned_chain_ended'] and end['exit_code']==0
    assert audit['actual_independent_costs']['PF_returns']==2787 and audit['actual_independent_costs']['agent_forward_returns']==7896 and audit['full_fields_max_delta']<=1e-10
    for rel,filename in [('outputs/public13_first_partial_validation_v2_20261021','audit_public13_first_partial_validation_v2_20261021.py'),('outputs/public13_terminal_saved_prefix_v2_20261021','preserve_and_audit_public13_terminal_prefix_v2_20261021.py'),('outputs/public13_remaining_published_cohort_20261021','run_public13_remaining_published_cohort_20261021.py'),('outputs/public13_full_cohort_handoff_20261021','coordinate_public13_cohort_20261021.py')]:
        claim=json.loads((R/rel/'owner.claim').read_text());live=process(claim['actual_pid']);assert not live or filename not in (live.get('CommandLine') or '')
    proof=json.loads((P/'Software_Readiness_v2.json').read_text());assert proof['status']=='PASS_LABELED_SOFTWARE_AND_SOURCE_CONTRACT_ONLY' and len(proof['checks'])==11
    worker='work/run_public13_missing_only_continuation_20261021.py';reader='work/audit_public13_missing_only_continuation_20261021.py';helper='work/public13_complete_policy_state_contract_20261021.py';handoff='work/coordinate_public13_missing_only_20261021.py'
    assert proof['worker_sha256']==sha(R/worker) and proof['reader_sha256']==sha(R/reader) and proof['state_helper_sha256']==sha(R/helper)
    for rel in ['outputs/public13_missing_only_execution_20261021','outputs/public13_missing_only_coordination_20261021','outputs/public13_missing_only_independent_20261021','outputs/public13_missing_only_handoff_20261021']:assert not (R/rel).exists()
    protocol=json.loads((P/'Protocol_Draft.json').read_text());protocol.update(at_utc=datetime.now(timezone.utc).isoformat(),status='PROSPECTIVE_FROZEN_1013_GENUINELY_UNENTERED_EXTERNAL_METHOD_CASES_WITH_VALIDATED_RECONSTRUCTED_CARRY')
    protocol['source_and_input_hashes'].update({n:sha(R/n) for n in [worker,reader,helper,handoff,'outputs/public13_missing_only_preparation_20261021/Software_Readiness_v2.json','outputs/public13_missing_only_preparation_20261021/Prelaunch_Storage_Refinement.json','outputs/public13_first_partial_validation_v2_20261021/Independent_Audit.json','outputs/public13_first_partial_validation_v2_20261021/Closed_Manifest.json','outputs/public13_first_partial_validation_v2_20261021/Independent_Replayed_Final_Source_State.npz','outputs/public13_first_partial_validation_v2_20261021/Source_State_Reproduction_Proof.json']})
    put(P/'Protocol.json',protocol);put(P/'Independent_Reader_Lock.json',{'reader':reader,'reader_sha256':sha(R/reader),'protocol_sha256':sha(P/'Protocol.json'),'independent_stage':'First only for NEW returned physical and policy identities; prefix only reused, never replayed again','all_previous_primary_preparation_failure_and_reader_costs_retained':True})
    for role,source,out,coord in [('Primary',worker,'outputs/public13_missing_only_execution_20261021','outputs/public13_missing_only_coordination_20261021'),('Reader',reader,'outputs/public13_missing_only_independent_20261021','outputs/public13_missing_only_reader_coordination_20261021')]:
        put(P/(role+'_Owner_Protocol.json'),{'single_owner':{'source':source,'sha256':sha(R/source),'output':out,'coordination':coord,'python':'work/vcsa_module_env/Scripts/python.exe','bound_seconds':7300}})
    put(P/'Admission.json',{'status':'PASS_FIRST_READER_TERMINAL_EXACT_SOURCE_STATE_SOFTWARE_OWNERSHIP_AND_UNENTERED_ID_GATES','new_identity_count':1013,'old_cases_not_repeated':True,'new_pretrained_PF_calls_by_freeze':0,'full_original_final_parameter_snapshot':'UNRECOVERED; independent reconstructed carry explicitly distinct','all6goals':'OPEN','execution_performance_or_superiority':'UNKNOWN'})
    print('ADMISSION_PASS_READY_FOR_ONE_NEW_UNENTERED_IDENTITY_OWNER_NO_SCIENCE_STARTED_BY_GATE')
if __name__=='__main__':main()
