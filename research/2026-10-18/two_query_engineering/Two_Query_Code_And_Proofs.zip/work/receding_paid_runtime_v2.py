"""Full first-move receding runtime, paid replay and durable dependency cursor.

No launcher or model is included. A prospectively fixed owner must provide the
actual bounded Evidence, exact inputs, cold-process gate and independent reader.
"""
import copy,hashlib,json,os,random,time
from pathlib import Path
import numpy as np
import pandapower as pp
from receding_paid_lookahead_controller_native_v2 import run as control
from receding_paid_decision_engine_durable_v2 import PaidDecisionEngine
from paid_receding_commit_and_history_v1 import (HISTORY_KEY,fields,fingerprint,commit_paid,save_complete,restore_complete)
from bounded_paid_lookahead_physics_20261014 import load_after,build_current_domain
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from dynamic_actual_mask_guidance_v1 import identity
from compile_lookahead_paid_input_cache_20261014 import point_key
R=Path(__file__).resolve().parents[1]
DEPENDENCY_KEY='__COMPLETE_SCIENTIFIC_AND_NUMERICAL_DEPENDENCY_PREFIX__'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while block:=f.read(1024**2):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text('utf-8-sig'))
def put(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def restore_dependency_prefix(state,*,warm_dependencies,source_anchors):
    """Restore only the saved paid prefix, never future suffixes or new science."""
    dep=state['paid_query_registry'][DEPENDENCY_KEY]
    assert dep['source_anchors']==source_anchors
    assert sha(R/dep['warm_dependency_path'])==dep['warm_dependency_sha256']
    cache=copy.deepcopy(warm_dependencies['cache']);forecasts=copy.deepcopy(warm_dependencies['existing_numeric_forecasts'])
    prefix='0'*64;intents={};returns={};exceptions={};bytes_read=0;closed=0
    with (R/dep['scientific_journal_path']).open('rb') as stream:
        while bytes_read<dep['scientific_journal_bytes']:
            line=stream.readline();assert line and bytes_read+len(line)<=dep['scientific_journal_bytes']
            event=json.loads(line);assert event['previous_sha256']==prefix and event['protocol_sha256']==state['protocol_sha256']
            prefix=hashlib.sha256(line.rstrip(b'\n')).hexdigest();bytes_read+=len(line);d=event['data']
            if event['event']=='PF_intent':
                assert d['identity'] not in intents;intents[d['identity']]=d
                assert d['before']['encoded_offset']+d['before']['encoded_bytes']<=dep['capsules_bytes']
            elif event['event'] in ('PF_return','PF_exception'):
                pid=d['PF_id'];assert pid in intents and pid not in returns and pid not in exceptions
                assert d['after']['encoded_offset']+d['after']['encoded_bytes']<=dep['capsules_bytes']
                (returns if event['event']=='PF_return' else exceptions)[pid]=d
            elif event['event']=='every_query_receipt_closed_before_more_science':
                rec=d['record'];m=rec.get('actual_measured_receipt')
                if m:
                    assert m==(returns if m['outcome']=='RETURNED' else exceptions)[m['PF_id']]
                    context=intents[m['PF_id']]['context'];assert context['phase']=='NEW_PRIMARY_QUERY'
                    assert context['action_key']==d['aid']
                    key=context['point']+'|'+d['aid']
                    if key in cache:
                        for k in ('verdict','original_score','after_reference','attributed_PF_calls','attributed_solver_seconds','actual_measured_receipt'):
                            assert cache[key].get(k)==rec.get(k),k
                    else:cache[key]=copy.deepcopy(rec)
                    closed+=1
            elif event['event']=='second_causal_context_and_forecasts':
                for row in d['rows']:
                    from compile_lookahead_paid_input_cache_20261014 import action_key
                    key=d['context_identity']+'|'+action_key(row)
                    if key in forecasts:assert forecasts[key]==row['ordering_forecast']
                    forecasts[key]=copy.deepcopy(row['ordering_forecast'])
    assert prefix==dep['last_scientific_event_sha256'] and bytes_read==dep['scientific_journal_bytes']
    assert set(intents)==set(returns)|set(exceptions) and not set(returns)&set(exceptions)
    assert len(intents)==state['costs']['actual_scientific']['PF_attempts']
    assert closed==dep['closed_new_receipt_occurrences']
    contexts={}
    for entry in dep['warm_numeric_contexts']+dep['current_numeric_contexts']:
        path=R/entry['path'];assert sha(path)==entry['sha256']
        with np.load(path,allow_pickle=False) as arrays:c={k:arrays[k].copy() for k in arrays.files}
        assert identity(c)==entry['identity'];contexts[entry['identity']]=c
    return {'cache':cache,'paid_forecasts':forecasts,'contexts':contexts,
        'closed_intent_ids':sorted(intents),'new_scientific_calls':0,
        'saved_prefix_only':True,'original_absolute_deadline_utc':state['absolute_deadline_utc']}

class PaidRecedingRuntime:
    def __init__(self,*,out,protocol,evidence,history,runner,zones,cache,blocked,contexts,
                 numeric_cost,paid_forecasts,warm_dependency_path,warm_context_refs,source_anchors,cold_gate):
        self.out=Path(out);self.p=protocol;self.evidence=evidence;self.history=history
        self.runner=runner;self.zones=zones;self.numeric_cost=numeric_cost
        self.warm_path=Path(warm_dependency_path);self.source_anchors=source_anchors
        self.warm_context_refs=copy.deepcopy(warm_context_refs)
        self.cold_gate=cold_gate;self.cold_complete=False;self.checkpoints=[];self.checkpoint_serial=0
        self.registry={};self.current=None;self.decision=None;self.report=None
        self.closed_new_receipt_occurrences=0;self.previous_checkpoint='0'*64
        self.engine=PaidDecisionEngine(out=self.out,evidence=evidence,runner=runner,zones=zones,cache=cache,
            blocked=blocked,contexts=contexts,numeric_cost=numeric_cost,history=history,paid_forecasts=paid_forecasts)
    def run_branch(self,net,cursor,*,world,mode):
        self.current={'world':world,'method':mode};self.decision=0
        def search(actual,c,bound_mode):
            self.evidence.admit()
            report=self.engine.decision(actual,c,world,bound_mode,self.decision)
            self.report=report
            # Durability is already complete before a first action can commit.
            self.closed_new_receipt_occurrences+=sum(bool(m['record'].get('actual_measured_receipt')) for m in report['query_messages'])
            return report['plan']
        def commit(actual,c,proposal):
            report=self.report;chosen=proposal['selected'];root=report['root']
            message=next(m for m in report['query_messages'] if m['parent']==root and m['aid']==chosen['first'])
            assert message['successor']==chosen['first_successor']
            row=message['row'];paid=message['record'];target=report['resolve_paid_state'](message['successor'])['net']
            assert paid['verdict']['accepted'] and target.converged
            _,actuate,_=build_verifier(self.runner.rescue,c)
            replay=actuate(copy.deepcopy(actual),action(row))
            self.evidence.context={**self.current,'decision':self.decision,'phase':'CONTINUOUS_SELECTED_COMMIT_REPLAY',
                'candidate':row,'selected_receipt_id':paid['receipt_id']}
            pp.runpp(replay,**self.p['solver_kwargs'])
            assert replay.converged and replay.res_bus.vm_pu.max()<=1.05+1e-8
            f=fields(target);observed=fields(replay)
            delta=max(abs(f[b][k]-observed[b][k]) for b in f for k in f[b]);assert delta<=1e-10
            receipt={'receipt_id':paid['receipt_id'],'accepted':True,'converged':True,'fields':f,
                'before_fingerprint':fingerprint(actual,c)}
            following_scope=build_current_domain(target,c,runner=self.runner,zones=self.zones)['shared_raw_receivers_for_BOTH_controls']
            commit_id=f'{world}|{mode}|{self.decision}'
            following=commit_paid(actual,target,c,row,receipt,commit_id=commit_id,actuate=actuate,next_scope=following_scope)
            self.registry[paid['receipt_id']]=copy.deepcopy(paid)
            record={'commit_id':commit_id,'first_action_id':chosen['first'],'paid_successor_id':chosen['first_successor'],
                'candidate':row,'device_operations_debited':1 if row['kind']=='ordinary' else 2,
                'paid_receipt_id':paid['receipt_id'],'replay_field_delta':delta,'replay_receipt':copy.deepcopy(self.evidence.last),
                'following_cursor':following,'hypothetical_second_not_committed':True}
            self.history.append('actual_receding_first_commit',record)
            self.evidence.event('actual_receding_first_commit',{**self.current,'decision':self.decision,'record':record})
            self.decision+=1;return target,following,record
        def checkpoint(actual,c,phase):
            self.checkpoint_serial+=1;path=self.out/'checkpoints'/str(self.checkpoint_serial)
            context_refs=[{'identity':ident,'path':str((self.out/'contexts'/(ident+'.npz')).relative_to(R)),
                'sha256':sha(self.out/'contexts'/(ident+'.npz'))} for ident in sorted(self.engine.saved_contexts)]
            dependency={'source_anchors':self.source_anchors,'warm_dependency_path':str(self.warm_path.relative_to(R)),
                'warm_dependency_sha256':self.p['warm_dependency_sha256'],
                'scientific_journal_path':str((self.out/'scientific.jsonl').relative_to(R)),
                'scientific_journal_bytes':self.evidence.journal.tell(),'last_scientific_event_sha256':self.evidence.previous,
                'capsules_bytes':self.evidence.pack.tell(),'warm_numeric_contexts':self.warm_context_refs,'current_numeric_contexts':context_refs,
                'closed_new_receipt_occurrences':self.closed_new_receipt_occurrences}
            self.registry[DEPENDENCY_KEY]=dependency;self.registry[HISTORY_KEY]=self.history.anchor()
            state={'net':actual,'cursor':c,'paid_query_registry':copy.deepcopy(self.registry),
                'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),
                'costs':{'actual_scientific':copy.deepcopy(self.evidence.costs),'numeric':copy.deepcopy(self.numeric_cost)},
                'absolute_deadline_utc':self.p['absolute_deadline_utc'],'protocol_sha256':self.p['protocol_sha256'],
                'next_phase':{**self.current,**phase}}
            anchors={'source':self.p['runtime_source_sha256'],'input':self.p['warm_dependency_sha256'],
                'paid_receipt':self.registry[HISTORY_KEY]['sha256'],'predecessor':self.previous_checkpoint}
            receipt=save_complete(path,state,anchors);warm,_=restore_complete(path,receipt)
            assert fingerprint(warm['net'],warm['cursor'])==fingerprint(actual,c)
            request={'checkpoint':str(path.relative_to(R)),'receipt':receipt,'expected_point_key':point_key(actual,c),
                'source_anchors':self.source_anchors,'original_deadline_utc':self.p['absolute_deadline_utc']}
            self.checkpoints.append(request);self.previous_checkpoint=receipt['state_fingerprint']
            # A real separately owned cold process must reconstruct the exact
            # complete receipt/context/forecast/cursor prefix before more work.
            if not self.cold_complete:
                result=self.cold_gate(request)
                assert result['status']=='PASS_COLD_COMPLETE_RECEDING_PREFIX' and result['new_scientific_calls']==0
                self.cold_complete=True
            self.evidence.event('complete_receding_checkpoint_ACK',request)
        return control(net,cursor,mode=mode,observe=self.runner.rescue.grid_metrics,
            search=search,commit=commit,checkpoint=checkpoint,event=self.evidence.event,admit=self.evidence.admit)
