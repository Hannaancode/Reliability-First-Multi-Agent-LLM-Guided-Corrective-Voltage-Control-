"""Saved-root/source-only correction of the external inverter admission record.

No native function, action application, solver, trained model or environment reset
is called. Network objects are read from already certified saved payloads.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,math,pickle,time
R=Path(__file__).resolve().parents[1];O=R/'outputs/common118_DER_admission_correction_20261029'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not O.exists();start=time.perf_counter()
    oldrel='outputs/published_voltage_common118_design_20261022/Source_Contract_And_Execution_Decision.json';old=rd(oldrel)
    roots=rd('outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    source=R/old['source_evidence']['PV_device']['path'];assert sha(source)==old['source_evidence']['PV_device']['sha256']
    text=source.read_text('utf-8');assert 'pv_converter_oversize: int = 1.1' in text and "self.dataset.get_item(idx)['sgen']['max_p_mw']" in text
    records=[]
    for x in roots:
        p=R/x['solved_payload'];n=pickle.loads(p.read_bytes())['net']
        s=n.sgen;pv=s[s['type'].str.lower()=='pv'];diesel=s[s['type'].str.lower()=='diesel']
        assert len(n.bus)==118 and len(s)==8 and len(pv)==4 and len(diesel)==4
        def clean(v):
            if isinstance(v,float) and not math.isfinite(v):return None
            return v.item() if hasattr(v,'item') else v
        rows=[{k:clean(v) for k,v in row.items()} for row in s[['name','bus','type','p_mw','q_mvar','sn_mva','in_service']].to_dict('records')]
        records.append({'case_id':x['case_id'],'saved_payload':x['solved_payload'],'saved_payload_sha256':sha(p),
            'buses':len(n.bus),'sgen_total':len(s),'PV_named_rows':len(pv),'diesel_named_rows':len(diesel),
            'PV_buses':[int(v) for v in pv.bus],'all_sgen_ratings_unknown':bool(s.sn_mva.isna().all()),
            'explicit_Q_limit_columns_present':[k for k in ['min_q_mvar','max_q_mvar'] if k in s.columns],
            'saved_device_rows':rows})
    assert all(x['all_sgen_ratings_unknown'] and not x['explicit_Q_limit_columns_present'] for x in records)
    O.mkdir()
    report={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL4_SAVED_DEVICE_ROLE_RECONCILIATION_NO_NATIVE_CALLS',
        'previous_report':{'path':oldrel,'sha256':sha(R/oldrel),'preserved_unchanged':True},
        'corrections':['Previous actual_root_devices field static_PV_sgens=8 counted all static generators, including four diesel rows. Correct count is8total,4PV,4diesel.','Previous prose saying there are no staticPVdevices is false for these saved roots. The controlled roots contain four PV-tagged static generators.'],
        'rows':records,'source_scope':{'path':str(source.relative_to(R)),'sha256':sha(source),'native_requirements':'RRL ScenarioManager derives apparent-power ratings from dataset maximum active power times declared oversizing1.1; it requires a source-compatible profile and PQ area. Its default controls all static generators unless explicit indices are supplied.'},
        'admission_decision':'PV-device presence is established. A faithful inverter control role remains NOT_READY because saved sn_mva ratings and Qlimits are absent and dataset-based maxima/PQcapability are not bound. Diesel rows must not be silently treated asPV. Added positive shunts and inverter P/Q actions still differ.',
        'next_required':['Bind actual fourPVindices by device identity, not all8static rows.','Recover or separately justify immutable device ratings and native time-series maxima/PQcapability; do not invent ratings from current p_mw.','Declare whether experiment preserves originalshunts or changes to a common inverter role, and give all adapted methods equal permissions.','Before training freeze observation/reward/episode/split/action/cost and complete state preservation, then actual integration and independent reader; no source-only launch.'],
        'new_PF_OPF_model_derivative_solve_training_GPU_calls':0,'workflow_seconds':time.perf_counter()-start}
    (O/'Corrected_Source_Admission.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n','utf-8')
    (O/'Decision.md').write_text('# Corrected external controller admission\n\nThe four saved federation roots each contain four PV-labelled and four diesel-labelled static generators. The earlier report incorrectly counted all eight as PV and also stated that none existed. Both statements are superseded by this source-bound correction; the original report is retained.\n\nThis removes a false device-absence objection, but does not make the published residual-SAC inverter controller executable on our original task. All eight apparent-power ratings are missing, explicit reactive limits are absent, and the published environment derives ratings from its own dataset maxima. We cannot manufacture those profiles or assign inverter capabilities to diesel rows. The original method adds positive shunts; native inverter P/Q control remains a different resource permission.\n\nNext work is an explicit common-actuator/observation/cost contract or a separately justified native inverter study with real capability data. No model, action application, power flow, training or GPU allocation occurred here.\n','utf-8')
    print(json.dumps({'status':report['status'],'roots':4,'PV_per_root':4,'diesel_per_root':4,'ready_for_training':False,'new_science':0}))
if __name__=='__main__':main()
