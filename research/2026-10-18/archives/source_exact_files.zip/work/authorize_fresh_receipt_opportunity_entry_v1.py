"""Freeze the authorized execution decision and runtime before new physics."""
import importlib.metadata
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from run_fresh_paid_receipt_opportunity_v1 import source_gate
from prepare_fresh_paid_receipt_opportunity_v1 import ROOT, OUT, sha, write

assert not (OUT / 'execution').exists()
assert not (OUT / 'Execution_Decision_And_Environment.json').exists()
protocol = json.loads((OUT / 'Protocol.json').read_text(encoding='utf8'))
source_gate(protocol)
ready = json.loads((OUT / 'Software_Readiness.json').read_text(encoding='utf8'))
identities = json.loads((OUT / 'Physical_Identity_Nonoverlap.json').read_text(encoding='utf8'))
assert ready['all_passed'] and identities['eight_distinct_fresh_physical_identities']
expected = {'pandapower':'3.4.0','numpy':'2.0.2','pandas':'2.3.3','scipy':'1.16.3','numba':'0.60.0'}
actual = {k: importlib.metadata.version(k) for k in expected}
assert actual == expected
decision = {'at_utc':datetime.now(timezone.utc).isoformat(),'human_authority':'Direct full necessary access/execution and priority-critical-experiment request on10October; original notebooks references only.',
    'prospective_protocol_sha256':sha(OUT / 'Protocol.json'), 'actual_cpu_environment':actual,
    'python':sys.version,'executable':sys.executable,'authorizing_control_pid':os.getpid(),
    'actual_root_action_Jacobian_integration':'UNTESTED; first fresh root is an explicitly charged real physical/current/Jacobian gate before candidate queries; failure stops further entry.',
    'justification':'Eight genuinely NEW outcome-independent development roots, no overlap with203 existing physical identities; measure paid query opportunity before any costly language training.',
    'decision':'Execute the single frozen bounded new CPU measurement with internal first-root gate. No old calls/owners restarted, no GPU/cloud/model/controller/commits.',
    'source_and_software_gates_passed':True,'static_readiness_is_not_physical_readiness_or_superiority':True,
    'budget':'600sec measurement ENTRY including owner dependencyloading; fixed separately charged new observation replay and closure. No science retry/extension.',
    'source_sha256':sha(Path(__file__))}
write(OUT / 'Execution_Decision_And_Environment.json',decision)
print(json.dumps({'authorized_ready_entry':True,'actual_integration':'first_fresh_root_gate','protocol_sha256':decision['prospective_protocol_sha256']}))
