"""Isolated byte codec; no pickle loading, scientific call or live integration.

Future callers must keep independently anchored manifests, exclusive durable
ownership, full costs, resource admission and cold restoration. This codec
alone does not supply those gates or authorize an experiment.
"""
import hashlib
import json
import zlib


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def limits(max_raw_bytes, max_encoded_bytes):
    if any(type(v) is not int or v <= 0 for v in (max_raw_bytes, max_encoded_bytes)):
        raise ValueError('Separate prospectively declared positive byte bounds required')


def encode(raw, *, anchors, max_raw_bytes, max_encoded_bytes):
    limits(max_raw_bytes, max_encoded_bytes)
    if type(raw) is not bytes or len(raw) > max_raw_bytes:
        raise ValueError('Complete byte payload exceeds raw bound or is not bytes')
    if not isinstance(anchors, dict) or not anchors:
        raise ValueError('Explicit owner/input/source/receipt anchors required from caller')
    # Deep JSON-copy: mutable caller values cannot alter the returned binding.
    copied = json.loads(canonical(anchors))
    encoded = zlib.compress(raw, level=6)
    if len(encoded) > max_encoded_bytes:
        raise ValueError('Encoded payload exceeds separate bound; no truncation')
    manifest = {'schema': 1, 'codec': 'zlib', 'level': 6, 'anchors': copied,
                'raw_bytes': len(raw), 'raw_sha256': digest(raw),
                'encoded_bytes': len(encoded), 'encoded_sha256': digest(encoded),
                'zlib_runtime': zlib.ZLIB_RUNTIME_VERSION}
    return encoded, manifest


def decode(encoded, manifest, *, expected_manifest_sha256, expected_raw_sha256,
           max_raw_bytes, max_encoded_bytes):
    """Both expected hashes must come from an independent trusted receipt.

Never derive expected hashes from the supplied manifest. Output remains opaque
bytes; the existing separately gated trusted-local restore owns deserialization.
"""
    limits(max_raw_bytes, max_encoded_bytes)
    keys = {'schema', 'codec', 'level', 'anchors', 'raw_bytes', 'raw_sha256',
            'encoded_bytes', 'encoded_sha256', 'zlib_runtime'}
    if not isinstance(manifest, dict) or set(manifest) != keys:
        raise ValueError('Exact codec manifest required')
    if digest(canonical(manifest)) != expected_manifest_sha256:
        raise ValueError('Independent manifest anchor mismatch')
    if manifest['schema'] != 1 or manifest['codec'] != 'zlib' or manifest['level'] != 6:
        raise ValueError('Changed codec contract')
    if type(encoded) is not bytes or len(encoded) > max_encoded_bytes:
        raise ValueError('Encoded bound/type violation')
    n = manifest['raw_bytes']
    if type(n) is not int or not 0 <= n <= max_raw_bytes:
        raise ValueError('Raw size bound violation')
    if (manifest['encoded_bytes'] != len(encoded) or
            manifest['encoded_sha256'] != digest(encoded) or
            manifest['raw_sha256'] != expected_raw_sha256):
        raise ValueError('Independent raw or encoded identity mismatch')
    decoder = zlib.decompressobj()
    try:
        # One byte beyond the declared raw size detects excess output without
        # allowing a self-described compression bomb to allocate unbounded data.
        raw = decoder.decompress(encoded, n + 1)
    except zlib.error as exc:
        raise ValueError('Corrupt compressed stream') from exc
    if (len(raw) != n or not decoder.eof or decoder.unused_data or
            decoder.unconsumed_tail or digest(raw) != expected_raw_sha256):
        raise ValueError('Truncated, trailing, oversized or wrong decoded payload')
    return raw
