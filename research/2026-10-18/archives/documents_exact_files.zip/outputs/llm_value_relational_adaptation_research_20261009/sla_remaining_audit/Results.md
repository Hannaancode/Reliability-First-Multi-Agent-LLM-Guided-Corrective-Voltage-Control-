All216 declared OPT cases were retained;431 finite new arm outputs independently audited and1 original unavailable prediction remains UNKNOWN. Original4 returned solves were not repeated. The all432finite headroom gate remains UNKNOWN.

{
  "old_admittance_derivative": {
    "equal_world_MSE": null,
    "finite_forecasts": 215,
    "unknown_forecasts": 1,
    "upper_forecasts": 6,
    "affine_steps": 718,
    "max_steps_per_case": 5,
    "nominal_target_confusion": {
      "near_max->UNKNOWN": 21,
      "interior->UNKNOWN": 30,
      "near_min->UNKNOWN": 2,
      "interior->interior": 7430,
      "near_min->near_min": 879,
      "near_max->near_max": 3060,
      "near_min->interior": 8,
      "interior->near_max": 16,
      "interior->near_min": 2
    },
    "measured_changed_gen_accuracy": {
      "wrong": 27,
      "correct": 336
    },
    "measured_stable_gen_accuracy": {
      "wrong": 52,
      "correct": 11033
    }
  },
  "candidate_admittance_derivative": {
    "equal_world_MSE": 4.88489939825955e-06,
    "finite_forecasts": 216,
    "unknown_forecasts": 0,
    "upper_forecasts": 65,
    "affine_steps": 733,
    "max_steps_per_case": 5,
    "nominal_target_confusion": {
      "near_max->near_max": 3048,
      "interior->interior": 7469,
      "near_min->near_min": 889,
      "near_max->interior": 22,
      "interior->near_min": 9,
      "near_max->near_min": 11
    },
    "measured_changed_gen_accuracy": {
      "correct": 362,
      "wrong": 1
    },
    "measured_stable_gen_accuracy": {
      "correct": 11044,
      "wrong": 41
    }
  }
}

All oracle and practical outcomes, costs, mismatches and failure denominators are retained. This is saved-state affine development evidence, not physical rollout, hidden-mode equality, LLM contribution or D-SE superiority.
