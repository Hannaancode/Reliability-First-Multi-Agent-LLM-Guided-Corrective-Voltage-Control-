"""Additive bounded no-model handoff adaptation; never launches science."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'work/continue_candidate_process_copied_body_audit.py').read_text()
replacements={
 'copied_body_integration_audit_continuation':'pretrained_learning_audit_continuation',
 'copied_body_integration_execution':'pretrained_learning_execution',
 'run_candidate_process_copied_body_colab.py':'run_candidate_process_pretrained_learning_colab_chunked_v2.py',
 'time.monotonic()-began<4200':'time.monotonic()-began<9000',
 'copied_body_integration_external_audit':'pretrained_learning_external_audit',
 'analyze_candidate_process_copied_body_integration.py':'analyze_candidate_process_pretrained_learning.py',
 'complete_independent_genuine_integration_evidence':'complete_independent_pretrained_learning_evidence'}
for old,new in replacements.items():assert old in source;source=source.replace(old,new)
ast.parse(source);ast.parse((ROOT/'work/analyze_candidate_process_pretrained_learning.py').read_text())
target=ROOT/'work/continue_candidate_process_pretrained_learning_audit.py'
with target.open('x') as file:file.write(source)
print('SINGLE_EXTERNAL_READER_AND_FINITE_HANDOFF_AST_PARSED')
