"""Independent stored-evidence audit; zero model/PF/optimizer/forecast calls."""
import hashlib,json,os,pickle,subprocess,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
import math
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/native_fresh_engineering_20261011'
PREP=BASE/'preparation_v2';DATA=BASE/'execution';OUT=BASE/'independent_audit'
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')
def write(name,v):
 with (OUT/name).open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
 assert not OUT.exists(),'No duplicate/restart external reader'
 state=read(DATA/'status.json');owner=read(DATA/'owner.claim');launch=read(BASE/'Actual_Launch.json')
 assert state['exit_code']==0 and state['stage']=='engineering_complete_pending_independent_audit'
 ids=[owner['actual_pid'],launch['launcher_pid']]
 cmd='Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -in '+','.join(map(str,ids))+' } | Select-Object -ExpandProperty ProcessId'
 p=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True,timeout=30)
 assert p.returncode==0 and not p.stdout.strip(),'Owner/launcher still live; no reader alongside owner'
 OUT.mkdir();began=time.perf_counter()
 write('owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'command':str(Path(__file__)),
                     'source_sha256':sha(Path(__file__)),'engineering_owner_and_launcher_ended':ids})
 proto=read(PREP/'Protocol.json');anchor=sha(PREP/'Protocol.json')
 assert anchor==owner['protocol_sha256']==launch['protocol_sha256']
 for name,h in proto['source_sha256'].items():assert sha(ROOT/name)==h,name
 manifest=read(DATA/'Closed_Manifest.json');assert manifest['engineering_success']
 for name,member in manifest['all_actual_members'].items():
  path=DATA/name;assert path.stat().st_size==member['bytes'] and sha(path)==member['sha256'],name
 def journal(name):
  previous=anchor;events=[]
  for sequence,line in enumerate((DATA/name).read_text('utf8').splitlines()):
   item=json.loads(line);row=item['row']
   assert row['sequence']==sequence and row['previous_sha256']==previous
   assert hashlib.sha256(canon(row)).hexdigest()==item['sha256']
   previous=item['sha256'];events.append(row)
  return events
 initial=journal('Initial_PF_Journal.jsonl');events=journal('Native_Journal.jsonl')
 def count(rows,event):return sum(r['event']==event for r in rows)
 result=read(DATA/'Actual_Engineering_Result.json');assert result['engineering_gate_passed']
 costs=result['native_costs'];assert count(initial,'initial_PF_attempt')==1 and count(initial,'initial_PF_return')==1 and count(initial,'initial_PF_exception')==0
 assert count(events,'native_PF_entry_intent')==costs['PF_attempts']
 assert count(events,'native_PF_return')==costs['PF_returns'] and count(events,'native_PF_exception')==costs['PF_exceptions']
 assert costs['PF_attempts']==costs['PF_returns']+costs['PF_exceptions']
 assert count(events,'native_candidate_attempt')==costs['candidate_attempts'] and count(events,'native_candidate_return')==costs['candidate_returns']
 searches=[r['payload'] for r in events if r['event']=='native_search_return'];assert len(searches)==1
 ordered=searches[0]['ordered_candidates'];scores=[]
 for candidate in ordered:
  v=candidate['verif'];action=candidate['action'];assert set(action)=={'add_shunts_q_mvar'} and len(action['add_shunts_q_mvar'])==1
  q=next(iter(action['add_shunts_q_mvar'].values()));assert q in [25,50,75,100,125,150,200,250,300]
  if not v['accepted']:score=(-999,)*5
  else:
   a,b=v['after'],v['before'];assert a['vmax']<=1.05+1e-8
   score=(int(a['uv_count']==0),b['uv_count']-a['uv_count'],b['deficit_sum']-a['deficit_sum'],a['vmin']-b['vmin'],-abs(q))
  scores.append(score)
 assert [list(s) for s in scores]==searches[0]['exact_native_scores']
 accepted=[i for i,c in enumerate(ordered) if c['verif']['accepted']];assert accepted
 chosen=max(accepted,key=lambda i:scores[i])
 assert result['actual_prefix']['executed_actions'][0]['action']==ordered[chosen]['action']
 commits=[r['payload'] for r in events if r['event']=='actual_postcommit_admission'];assert len(commits)==1
 assert commits[0]['action']==ordered[chosen]['action'] and len(result['actual_prefix']['executed_actions'])==1
 for r in events:
  if r['event']=='native_PF_entry_intent':
   k=r['payload']['effective_kwargs'];assert k=={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True}
 # Load only verified local owner artifacts through manifest and issued anchors.
 def local_pickle(path,expected):
  assert sha(path)==expected and manifest['all_actual_members'][path.relative_to(DATA).as_posix()]['sha256']==expected
  return pickle.loads(path.read_bytes())
 cp=commits[0]['selected_trial_anchors'];trial=local_pickle(DATA/cp['relative_directory']/'trusted_local_net.pkl',cp['payload_sha256'])['net']
 after=result['after_one_anchors'];actual=local_pickle(DATA/'FRESH_ENGINEERING_AFTER_ONE/trusted_local_snapshot.pkl',after['payload_sha256'])
 frame=actual['net'].res_bus;tf=trial.res_bus
 assert list(frame.index)==list(tf.index) and bool(actual['net'].converged)
 maximum=0.
 for i in frame.index:
  for f in ['vm_pu','va_degree','p_mw','q_mvar']:
   a,b=float(frame.at[i,f]),float(tf.at[i,f]);assert math.isfinite(a) and math.isfinite(b)
   maximum=max(maximum,abs(a-b));assert abs(a-b)<=1e-10
 assert set(frame.index[frame.vm_pu<.95])==set(tf.index[tf.vm_pu<.95])
 assert max(frame.vm_pu)<=1.05+1e-8
 caps={}
 for _,r in actual['net'].shunt.iterrows():
  if str(r['name']).startswith('llm_shunt'):caps[int(r['bus'])]=caps.get(int(r['bus']),0.)+abs(float(r['q_mvar']))
 assert all(q<=450 for q in caps.values())
 source_cert=read(DATA/'Actual_Continuation_Source_Certificate.json')
 assert source_cert['root_scenario_or_root_PF_not_in_compiled_body'] and source_cert['native_selection_preserved']
 assert actual['process']['after_commit']==1 and actual['process']['remaining_slots']==24
 assert result['cold_measured_fields_and_caps_exact'] and result['cold_following_solver_execution']=='NOT PERFORMED'
 archive=BASE/'Scientific_Engineering_Evidence.zip'
 assert not archive.exists()
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
  for path in sorted(DATA.rglob('*')):
   if path.is_file():z.write(path,path.relative_to(DATA).as_posix())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for name,m in manifest['all_actual_members'].items():
   b=z.read(name);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
 certificate={'passed':True,'kind':'ONE_FRESH_NATIVE_ENGINEERING_PREFIX_NOT_POLICY_BENEFIT',
  'source_input_cost_hash_chain_selector_and_commit_checks':True,'actual_initial_PF':1,'actual_native_PF':costs,
  'actual_candidate_receipts':len(ordered),'actual_commits':1,'continuous_trial_commit_maximum_delta':maximum,
  'exact_UV_memberships':True,'raw_OV_counts_separately_retained':True,
  'cold_saved_fields_exact_no_second_continuation_solve':True,'full_cold_native_trajectory_equivalence':'UNTESTED',
  'controller_scope':'Original global native DFF menu. Future LOCAL model raw common AND zone binding remains a separate requirement.',
  'new_reader_PF_model_optimizer_forecast_solver_calls':0,'original_owner_and_launcher_ended':ids,
  'archive':{'members':len(z.namelist()),'bytes':archive.stat().st_size,'sha256':sha(archive),'CRC_every_member_hash_passed':True},
  'audit_seconds':time.perf_counter()-began,'LLM_or_sequence_performance':'UNTESTED'}
 write('Independent_Engineering_Audit.json',certificate)
 print(json.dumps(certificate),flush=True)
if __name__=='__main__':main()
