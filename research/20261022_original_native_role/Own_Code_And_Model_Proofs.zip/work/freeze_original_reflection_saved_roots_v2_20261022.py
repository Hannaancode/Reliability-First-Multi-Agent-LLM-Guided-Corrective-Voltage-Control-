"""Freeze one necessary original-role model integration study, not UV testing."""
import ast
import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'


def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def put(p, value):
    with p.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush(); os.fsync(f.fileno())


def script(name, text):
    ast.parse(text)
    with (R / 'work' / name).open('x', encoding='utf-8') as f:
        f.write(text); f.flush(); os.fsync(f.fileno())


def main():
    preparation = read(P / 'Preparation_Result.json')
    assert preparation['status'] == 'PASS_TWO_ACTUAL_SAVED_ROOTS_ORIGINAL_CAUSAL_ROLE_PREPARATION_ONLY'
    assert sha(R / 'work/prepare_original_reflection_saved_roots_20261022.py') == preparation['source_sha256']
    checks = read(P / 'Prompt_And_Reprompt_Software_Checks.json')
    assert checks['new_solver_attempts'] == 0
    old = read(R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021/Frozen_Engineering_Protocol.json')
    original = read(P / 'Original_Function_AST_Pins.json')
    for rec in original.values(): assert sha(R / rec['path']) == rec['source_sha256']
    entry = read(R / 'outputs/critical_research_reset_20261010/spatial_allocation_input_preparation_v2_20261011/Input_Closure.json')
    for root in ['L1', 'L2']:
        row = next(x for x in entry['fixed_roots'] if x['root'] == root)
        assert not row['recorded_effective_input_overlaps'] and not row['invalid']
    # Host and transfer implementation are previously integrated. New output
    # and exact source names separate this study from every stopped old study.
    host = (R / 'work/run_native13_fullband_original_adapter_colab_20261021.py').read_text('utf-8')
    host = host.replace('native13_fullband_original_adapter_engineering_preparation_20261021', 'original_reflection_saved_root_preparation_v2_20261022')
    host = host.replace('native13_fullband_original_adapter_engineering_execution_20261021', 'original_reflection_saved_root_execution_v2_20261022')
    host = host.replace('native13_fullband_lora_guardian_20261021.py', 'original_reflection_saved_roots_guardian_v2_20261022.py')
    host = host.replace('hiergrid-public-size-screen', 'hiergrid-original-reflection-native-role')
    assert host.count('client.assign(') == 1 and "arm='public_0_5B'" in host
    script('run_original_reflection_saved_roots_colab_v2_20261022.py', host)
    guardian = (R / 'work/native13_fullband_lora_guardian_20261021.py').read_text('utf-8')
    guardian = guardian.replace('run_native13_fullband_lora_remote_20261021.py', 'run_original_reflection_saved_roots_remote_v2_20261022.py')
    script('original_reflection_saved_roots_guardian_v2_20261022.py', guardian)
    coordinator = '''"""One original-role model owner followed by its only zero-model reader."""
import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
P=R/'outputs/original_reflection_saved_root_preparation_v2_20261022'
O=R/'outputs/original_reflection_saved_root_handoff_v2_20261022'
def put(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
 O.mkdir(exist_ok=False)
 put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'at_utc':datetime.now(timezone.utc).isoformat()})
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf8') as f:
   code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_atomic_source_owner_20261022.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),{'exit_code':code,'at_utc':datetime.now(timezone.utc).isoformat()})
  assert code==0,'Preserve all partial/failure; no model/allocation/reader retry'
 put(O/'Completion.json',{'status':'ORIGINAL_NATIVE_ROLE_MODEL_AND_SOLE_READER_TERMINAL','at_utc':datetime.now(timezone.utc).isoformat()})
if __name__=='__main__':main()
'''
    script('coordinate_original_reflection_saved_roots_v2_20261022.py', coordinator)
    authority = {
        'direct_human_requests': ['Get actual reflection v4 and benchmark it on federation cases; use GPUs for faster work.', 'continue with the work'],
        'scope': 'One separately specified original native-role inference/actual-loader/cold gate on two existing paid states before full benchmark. No new PF or training; no restart of failed13bus transfer/scale study.',
        'private_adapter_and_tokenizer_export': 'Necessary unchanged private model for the requested own-model test under existing full authority; no credentials, NET, bank or training labels exported.',
        'source_current_measurements_export': 'Only the two current FIRST_ZONE causal model inputs, native source and hashes; no unqueried labels or future outcomes.',
        'guaranteed_win': False}
    put(P / 'Direct_Human_Authority.json', authority)
    protocol = {
        'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'FROZEN_BEFORE_FIRST_NEW_NATIVE_ROLE_MODEL_QUERY',
        'container_compatibility': 'Unchanged original generate_response AST receives exact input_ids Tensor via explicit modern BatchEncoding view; no prompt/token/mask/generation/policy change. Prior unlaunched v1 block preserved.',
        'container_preflight_sha256': sha(P / 'Tokenizer_Container_Compatibility.json'),
        'question': 'Does the existing original trained LoRA execute its unchanged original FIRST_ZONE query path on source-order paid federation roots L1/L2, and how does the same disabled-adapter base behave?',
        'scope': 'Model-interface integration only; two source-order historical development states, no UV-reduction, external-benchmark or learning-superiority score.',
        'profiles': {'public_0_5B': old['profiles']['public_0_5B']},
        'base_for_new_experiment': old['base_for_new_experiment'],
        'private_adapter_tokenizer_unchanged': old['private_adapter_tokenizer_unchanged'],
        'original_serving_sources': {v['path']: v['source_sha256'] for v in original.values()},
        'arms': ['lora', 'base_disabled'], 'seed': 20261022,
        'science_process_seconds': 900, 'setup_seconds': 1800, 'collector_seconds': 1200,
        'same_profile_single_assignment_only': True, 'fallback_after_denial': False,
        'two_fresh_model_loads': True, 'planned_original_queries': 8,
        'planned_generation_range': [8, 16],
        'conditional_second_generation': 'Only the unchanged original error-specific reprompt; at most one. Every first failure/raw output retained. No added reprompt/decoder/seed/checkpoint sweep.',
        'generation': {'max_new_tokens': 384, 'do_sample': False, 'use_cache': True,
                       'max_context': 4096, 'no_input_truncation': True},
        'FIRST_ZONE_causal_boundary': 'Empty feedback is faithful only for first zone at first iteration. No fabricated later-zone feedback, no speculative remaining controller trajectory.',
        'input_binding': 'Actual captured full native NETs identified by external old PF-return anchors. Network/solver/old measurement/replay/preparation costs remain separately paid; no root PF repeated.',
        'nonrepeat_scope': 'These distinct L1/L2 physical inputs had no original LLM calls in the numerical-only source-bound study. Prior204named-recipe non-overlap is scoped, not universal all-history proof. Source-order roots selected before new model outputs.',
        'fixed_gate': 'Both LoRA queries accepted by unchanged original parser/candidate validator; all source/token/context/actual-loader/frozen-state/cold/cost/manifest evidence PASS. Invalid outputs remain failures; base is disclosed control, not a weak physical comparator.',
        'on_failed_gate': 'Stop this fixed interface intervention, retain raw outputs and costs; no outcome retune or automatic rollout.',
        'on_passed_gate': 'Limited original-role integration readiness only; independently prospective full-controller/query/commit/physical/common118 external benchmark still required.',
        'full_optimizer_backward_PF_training_calls': 0,
        'historical_base_runtime_revision': 'Not exactly recovered; this is unchanged saved adapter on the same explicitly pinned NF4 base used in prior current studies, not a bit-exact historical runtime replication.',
        'own_input_sha256': {name: sha(P / name) for name in ['All2_Original_FIRST_ZONE_Inputs.json', 'Exact_Paid_Root_State_Bindings.json', 'Prompt_And_Reprompt_Software_Checks.json', 'Original_Function_AST_Pins.json', 'Preparation_Result.json']}}
    put(P / 'Frozen_Engineering_Protocol.json', protocol)
    remote_names = ['run_original_reflection_saved_roots_remote_v2_20261022.py', 'original_reflection_saved_roots_guardian_v2_20261022.py',
        'original_reflection_serving_pure_20261022.py', 'original_reflection_tokenizer_tensor_view_v2_20261022.py', 'native13_lora_setup_remote_v2_20261020.py',
        'native13_lora_environment_check_v2_20261020.py', 'candidate_process_pretrained_loader_native13_v2_20261020.py',
        'public_size_u61_preservation.py', 'frozen_gpu_requirements.txt', 'frozen_dependency_closure.txt', 'uv_bootstrap_version.txt']
    payload = {'work/' + n: R / 'work' / n for n in remote_names}
    for rec in original.values(): payload[rec['path']] = R / rec['path']
    adapter = R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for name, h in protocol['private_adapter_tokenizer_unchanged'].items():
        assert sha(adapter / name) == h
        payload['work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/' + name] = adapter / name
    payload['prep/protocol.json'] = P / 'Frozen_Engineering_Protocol.json'
    payload['prep/All2_Original_FIRST_ZONE_Inputs.json'] = P / 'All2_Original_FIRST_ZONE_Inputs.json'
    manifest = {name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in payload.items()}
    archive = P / 'Private_Adapter_And_Two_Original_Role_Inputs.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for name, path in payload.items(): z.write(path, name)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(manifest) + 1
        for name, rec in manifest.items():
            raw = z.read(name); assert len(raw) == rec['bytes'] and hashlib.sha256(raw).hexdigest() == rec['sha256']
    put(P / 'Cloud_Payload_Manifest.json', {'archive': str(archive.relative_to(R)).replace('\\', '/'),
        'bytes': archive.stat().st_size, 'sha256': sha(archive), 'members': len(manifest) + 1,
        'human_authority_source': str((P / 'Direct_Human_Authority.json').relative_to(R)).replace('\\', '/'),
        'human_authority_sha256': sha(P / 'Direct_Human_Authority.json'),
        'private_adapter_tokenizer_authorized': True, 'credentials_network_bank_private_TRAIN_labels_uploaded': False})
    for kind, source, output, coordination, python, bound in [
        ('Primary', 'run_original_reflection_saved_roots_colab_v2_20261022.py', 'original_reflection_saved_root_execution_v2_20261022', 'original_reflection_saved_root_coordination_v2_20261022', 'work/colab_access_env/Scripts/python.exe', 3900),
        ('Reader', 'audit_original_reflection_saved_roots_v2_20261022.py', 'original_reflection_saved_root_independent_v2_20261022', 'original_reflection_saved_root_reader_coordination_v2_20261022', 'work/vcsa_module_env/Scripts/python.exe', 600)]:
        put(P / (kind + '_Owner_Protocol.json'), {'single_owner': {'source': 'work/' + source,
            'sha256': sha(R / 'work' / source), 'python': python, 'output': 'outputs/' + output,
            'coordination': 'outputs/' + coordination, 'bound_seconds': bound}, 'require_ended_claims': []})
    put(P / 'Independent_Reader_Lock.json', {'source': 'work/audit_original_reflection_saved_roots_v2_20261022.py',
        'sha256': sha(R / 'work/audit_original_reflection_saved_roots_v2_20261022.py'),
        'only_after_actual_primary_ended_released_complete_preservation': True, 'new_PF_model_optimizer_calls': 0})
    source_names = remote_names + ['audit_original_reflection_saved_roots_v2_20261022.py', 'run_original_reflection_saved_roots_colab_v2_20261022.py',
        'coordinate_original_reflection_saved_roots_v2_20261022.py', 'public_size_local_preservation_v2.py', 'google_account_profile.py',
        'coordinate_atomic_source_owner_20261022.py', 'prepare_original_reflection_saved_roots_20261022.py',
        'freeze_original_reflection_saved_roots_v2_20261022.py']
    pins = {}
    for name in source_names:
        path = R / 'work' / name
        if path.suffix == '.py': ast.parse(path.read_text('utf-8'))
        pins['work/' + name] = sha(path)
    for path in P.glob('*.json'):
        pins[str(path.relative_to(R)).replace('\\', '/')] = sha(path)
    from candidate_process_evidence_utils import frozen_checks
    checks = frozen_checks()
    assert all(x['unchanged'] for x in checks) if isinstance(checks, list) else checks
    put(P / 'Launch_Readiness_Audit.json', {'passed': True, 'source_hashes': pins,
        'original_fixed_native_query_and_conditional_error_path_preserved': True,
        'real_saved_source_order_roots_no_new_physics': True,
        'no_automatic_training_or_performance_from_software': True,
        'separately_prospective_scoped_actual_model_gate': True,
        'single_selected_profile_allocation_no_rotation': True, 'fixed_frozen_checks': checks})
    print(json.dumps({'status': 'FROZEN_ORIGINAL_NATIVE_FIRST_ZONE_INFERENCE_ENGINEERING',
        'payload_bytes': archive.stat().st_size, 'members': len(manifest) + 1,
        'planned_queries': 8, 'planned_generations': [8, 16], 'new_model_PF_GPU_calls': 0}))


if __name__ == '__main__': main()
