"""Inventory actual journal identity schemas before claiming unseen query IDs.

All metadata is read, no new physics. Missing/unmapped schemas remain UNKNOWN;
substring absence is not scientific permission. Mock ledgers stay disclosed.
"""
import collections,gzip,hashlib,json,os,time
from pathlib import Path
from full_receding_paid_campaign_20261015 import R,read,put,sha
B=R/'outputs/prior_attempt_journal_scope_catalog_20261018'
def strings(d,depth=0):
    if depth>5 or not isinstance(d,dict):return
    for key,value in d.items():
        if isinstance(value,str) and any(s in key.lower() for s in ['point','state_key','world','phase','action_key','event','kind','case']):yield key,value
        elif isinstance(value,dict):yield from strings(value,depth+1)
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    inventory=R/'outputs/github_publication_20261018/snapshot/All_Research_Artifact_Inventory.jsonl.gz'
    rows=[json.loads(line) for line in gzip.open(inventory,'rt',encoding='utf-8')]
    journals=[d for d in rows if d['path'].endswith('.jsonl')]
    pending=read(R/'outputs/registry_following_engineering_input_preparation_v2_20261018/Prepared_Inputs.json')
    target=pending['observed_after_point_key'];aids={k.split('|')[1] for k in pending['candidate_following_keys']}
    put(B/'Protocol.json',{'role':'ALL314_SNAPSHOT_JSONL_JOURNAL_IDENTITY_SCHEMA_CATALOG_NOT_PERMISSION',
        'source_sha256':sha(Path(__file__)),'inventory_sha256':sha(inventory),'bound_seconds':600,
        'selection':'Every JSONL in complete saved workspace inventory; no reward/result filtering. New files since snapshot have zero scientific calls per saved source checkpoints and must be added to an eventual owner closure.',
        'scope':'Catalog every event/phase/world/point schema and any target point/action mention. Unmapped old PF contexts remain UNKNOWN, not absent/unexecuted or permission.',
        'candidate_input_preparation_sha256':sha(R/'outputs/registry_following_engineering_input_preparation_v2_20261018/Prepared_Inputs.json'),
        'new_science':0})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    catalog=[];matches=[]
    for i,row in enumerate(journals,1):
        assert time.perf_counter()-started<600
        path=R/row['path'];assert path.is_file() and path.stat().st_size==row['bytes'],row['path']
        events=collections.Counter();phases=collections.Counter();worlds=collections.Counter();point_tags=collections.Counter();point_values=set();pf_events=collections.Counter();examples=[];h=hashlib.sha256();lines=invalid=0
        with path.open('rb') as f:
            for line in f:
                assert time.perf_counter()-started<600
                h.update(line);lines+=1
                try:e=json.loads(line)
                except json.JSONDecodeError:invalid+=1;continue
                if not isinstance(e,dict):continue
                kind=str(e.get('event',e.get('kind',e.get('type','NO_EVENT_FIELD'))));events[kind]+=1
                tags=list(strings(e));is_pf=any(s in kind.lower() for s in ['pf_intent','pf_attempt','runpp_attempt','power_flow','physics_attempt'])
                if is_pf:
                    pf_events[kind]+=1
                    if len(examples)<3:examples.append({'event':kind,'top_keys':list(e),'data_keys':list(e.get('data',{})) if isinstance(e.get('data'),dict) else [],'identity_tags':tags[:24]})
                for key,value in tags:
                    low=key.lower()
                    if 'world' in low or 'case' in low:
                        if len(value)<256:worlds[value]+=1
                    if low=='phase':phases[value]+=1
                    if 'point' in low or 'state_key' in low:
                        point_tags[key]+=1
                        if len(value)==64:point_values.add(value)
                if target.encode() in line:
                    matches.append({'path':row['path'],'line':lines,'event':kind,'candidate_aid_mentions':[a for a in aids if a.encode() in line],
                        'schema_tags':tags[:30],'status':'MENTION_NOT_AN_EXECUTION_CLASSIFICATION'})
        if row.get('sha256'):assert h.hexdigest()==row['sha256'],row['path']
        item={'path':row['path'],'bytes':path.stat().st_size,'sha256':h.hexdigest(),'lines':lines,'invalid_or_torn_lines':invalid,
            'events':dict(events),'phases':dict(phases),'world_or_case_tags':dict(worlds),'point_tag_counts':dict(point_tags),'unique_named_points':len(point_values),
            'recognized_PF_intent_schemas':dict(pf_events),'PF_examples':examples,'contains_target_point_tag':target in point_values,
            'mock_label_in_path':'MOCK' in row['path'] or '/software' in row['path'],
            'unexecuted_identity_permission':False}
        catalog.append(item)
        put(B/f'Progress_{i}.json',{'journals_done':i,'total':len(journals),'workflow_seconds':time.perf_counter()-started,'science':0})
    put(B/'Journal_Schema_Catalog.json',catalog);put(B/'Candidate_Point_Mentions.json',matches)
    put(B/'Results.json',{'status':'COMPLETE_ALL_SNAPSHOT_JSONL_SCHEMA_CATALOG_COVERAGE_NOT_YET_CLOSED','journals':len(catalog),'bytes':sum(x['bytes'] for x in catalog),
        'recognized_PF_intent_journals':[x['path'] for x in catalog if x['recognized_PF_intent_schemas']],
        'candidate_point_mentions':len(matches),'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Event/identity schema catalog only. Resolve all relevant source contracts/aliases/torn/unmapped contexts and post-snapshot sources before declaring exact new query IDs unexecuted. No source-native physical claim or science permission.'})
    put(B/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()},'new_science':0})
    print(json.dumps({'journal_schema_catalog':'COMPLETE','journals':len(catalog),'candidate_mentions':len(matches),'new_science':0,'execution_permission':False}))
if __name__=='__main__':main()
