"""All-OPT current-information inventory. No targets, model or solver calls."""
import gzip
import hashlib
import json
import math
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'work'))
from candidate_process_evidence_utils import read, sha, write, seal

R = ROOT / 'outputs/critical_research_reset_20261010'
P = ROOT / 'outputs/llm_value_relational_adaptation_research_20261009'
B = ROOT / 'outputs/llm_value_candidate_development_20261009'
OUT = R / 'current_information_mechanism_audit_v2'
assert not OUT.exists(), 'Do not duplicate a completed inventory'
OUT.mkdir()
started = time.perf_counter()
source = B / 'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz'
support_source = B / 'current_added_support_observables/Current_Control_State_Observables.jsonl.gz'
prior = read(P / 'language_input_reuse_audit/Interface_and_Actual_Tokenizer_Audit.json')
assert sha(source) == prior['current_input_source_sha256']
forbidden = {'after', 'target', 'targets', 'scenario_id', 'scenario_sha256', 'world_sha256',
             'branch', 'branch_id', 'observation_id', 'model_input_sha256', 'split'}
narrative_keys = {'description', 'operator_instruction', 'operator_notes', 'text',
                  'message', 'notes', 'question', 'constraint_text'}
declaration = {
    'declared_at_utc': datetime.now(timezone.utc).isoformat(),
    'purpose': 'Stage0 current-information mechanism inventory, not context redesign or learned performance',
    'all239_OPT_views_all23_worlds': True,
    'no_outcome_selected_states_or_held_metrics': True,
    'input_sha256': sha(source), 'support_source_sha256': sha(support_source),
    'existing_tokenizer_results_reused_without_retokenization': True,
    'additive_control_repair': 'Use exact existing current_control_state wrapper in augmented-input hash; old v1 failed declaration/source preserved; no scientific calls repeated',
    'original_failed_source_sha256': sha(ROOT/'work/audit_current_information_language_mechanism_20261010.py'),
    'prior_stopped_full_and_partial_text_views_not_modified': True,
    'current_only_role_contract_before_new_method': True,
    'no_new_actor_representation_or_learning_protocol': True,
    'source_sha256': sha(Path(__file__)),
    'new_model_PF_optimizer_forecast_derivative_solve_controller_cloud_calls': 0,
}
write(OUT / 'Prospective_Current_Information_Inventory.json', declaration)

def canonical(v):
    return json.dumps(v, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(v):
    return hashlib.sha256(canonical(v).encode()).hexdigest()

def check_keys(v):
    if isinstance(v, dict):
        assert not set(v).intersection(forbidden)
        for child in v.values(): check_keys(child)
    elif isinstance(v, list):
        for child in v: check_keys(child)

def classify(v):
    if isinstance(v, dict) and '__missing__' in v:
        return 'tagged_missing'
    if v is None: return 'null'
    if type(v) is bool: return 'bool'
    if type(v) is int: return 'int'
    if type(v) is float:
        assert math.isfinite(v)
        return 'float'
    if isinstance(v, str): return 'string'
    return 'other_container'

supports = {}
with gzip.open(support_source, 'rt', encoding='utf-8') as f:
    for line in f:
        value = json.loads(line)
        assert value['observation_id'] not in supports
        supports[value['observation_id']] = value
assert len(supports) == 311

columns = {}
outside_strings = defaultdict(set)
narrative_paths = set()
table_names = None
records = []
seen = set()
worlds = set()
all_cell_types = Counter()
input_hash_groups = defaultdict(list)
augmented_hash_groups = defaultdict(list)

def external_walk(v, path):
    if isinstance(v, dict):
        for key, value in v.items():
            if key in narrative_keys: narrative_paths.add('/'.join(path + [key]))
            external_walk(value, path + [key])
    elif isinstance(v, list):
        for value in v: external_walk(value, path + ['<index>'])
    elif isinstance(v, str):
        outside_strings['/'.join(path)].add(v)

with gzip.open(source, 'rt', encoding='utf-8') as f:
    for line in f:
        outer = json.loads(line)
        if outer['split'] != 'optimization':
            continue # no held observations, targets or outcomes analyzed
        ident = outer['observation_id']
        assert ident not in seen; seen.add(ident)
        worlds.add(outer['world_sha256'])
        model_input = outer['model_input']
        assert set(model_input) == {'current_physical_observation', 'original_Q_grid'}
        check_keys(model_input)
        assert digest(model_input) == outer['model_input_sha256']
        assert model_input['original_Q_grid'] == [25.,50.,75.,100.,125.,150.,200.,250.,300.]
        observation = model_input['current_physical_observation']
        actual_names = set(observation['physical_tables'])
        if table_names is None: table_names = actual_names
        assert actual_names == table_names and len(actual_names) == 19
        counts = Counter()
        for table, frame in observation['physical_tables'].items():
            assert set(frame) == {'columns', 'index', 'values'}
            assert len(frame['index']) == len(frame['values'])
            assert all(len(row) == len(frame['columns']) for row in frame['values'])
            for j, name in enumerate(frame['columns']):
                key = table + '/' + name
                entry = columns.setdefault(key, {'table':table, 'column':name,
                    'rows_min':len(frame['index']), 'rows_max':len(frame['index']),
                    'cell_types':Counter(), 'data_strings':set(), 'vector_hashes':set(),
                    'numeric_min':None, 'numeric_max':None})
                entry['rows_min'] = min(entry['rows_min'], len(frame['index']))
                entry['rows_max'] = max(entry['rows_max'], len(frame['index']))
                vals = [row[j] for row in frame['values']]
                entry['vector_hashes'].add(digest({'index':frame['index'], 'values':vals}))
                for value in vals:
                    typ = classify(value)
                    entry['cell_types'][typ] += 1
                    counts[typ] += 1
                    if typ == 'string': entry['data_strings'].add(value)
                    if typ in {'int','float'}:
                        number = float(value)
                        entry['numeric_min'] = number if entry['numeric_min'] is None else min(entry['numeric_min'], number)
                        entry['numeric_max'] = number if entry['numeric_max'] is None else max(entry['numeric_max'], number)
        all_cell_types.update(counts)
        external_walk({key:value for key,value in observation.items() if key != 'physical_tables'}, [])
        control = supports[ident]
        assert control['original_cap_MVAr'] == 450.0 and control['no_future_outcome_or_branch_ID_in_forward']
        added = control['current_added_support_MVAr_by_bus']
        assert len(added) == 118 and all(type(x) in (int,float) and math.isfinite(x) and 0 <= x <= 450 for x in added)
        augmented = dict(model_input, current_control_state={'original_per_bus_added_support_cap_MVAr':450.0,'added_abs_Q_MVAr_by_bus':added})
        check_keys(augmented)
        assert digest(augmented) == control['augmented_model_input_sha256']
        input_hash_groups[outer['model_input_sha256']].append(ident)
        augmented_hash_groups[control['augmented_model_input_sha256']].append(ident)
        records.append({'observation_id':ident, 'world_sha256':outer['world_sha256'],
            'current_input_sha256':outer['model_input_sha256'],
            'augmented_input_sha256':control['augmented_model_input_sha256'],
            'physical_cell_types':dict(counts), 'current_support_cap_known':True,
            'administrative_keys_and_outcomes_outside_forward':True})
assert len(records) == 239 and len(worlds) == 23

inventory = []
for key, entry in sorted(columns.items()):
    entry['cell_types'] = dict(entry['cell_types'])
    entry['data_strings'] = sorted(entry['data_strings'])
    entry['unique_OPT_column_vectors'] = len(entry.pop('vector_hashes'))
    entry['changes_across_OPT_views'] = entry['unique_OPT_column_vectors'] > 1
    inventory.append(entry)
string_columns = [r for r in inventory if r['data_strings']]
string_vocab = sorted({s for r in string_columns for s in r['data_strings']})
summary = {
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'all_OPT_views':239, 'all_OPT_worlds':23, 'physical_tables':19,
    'table_columns':len(inventory),
    'columns_with_changing_current_vectors':sum(x['changes_across_OPT_views'] for x in inventory),
    'columns_constant_on_all239_OPT_views':sum(not x['changes_across_OPT_views'] for x in inventory),
    'physical_cell_types_all239':dict(all_cell_types),
    'string_data_columns':[{'table':x['table'], 'column':x['column'], 'strings':x['data_strings'],
                            'changes_across_OPT_views':x['changes_across_OPT_views']} for x in string_columns],
    'actual_physical_data_string_vocabulary':string_vocab,
    'max_physical_data_string_length':max(map(len,string_vocab),default=0),
    'non_table_string_fields':{k:sorted(v) for k,v in sorted(outside_strings.items())},
    'recognized_operator_narrative_field_paths':sorted(narrative_paths),
    'no_named_operator_narrative_channel':not narrative_paths,
    'schema_column_names_and_unit_labels_are_legitimate_semantics_not_dynamic_operator_instructions':True,
    'no_proof_language_pretraining_cannot_help_numeric_reasoning':True,
    'unique_current_input_hashes':len(input_hash_groups),
    'unique_augmented_current_input_hashes':len(augmented_hash_groups),
    'all239_current_support_vectors_118entries_exact_source_hash_roundtrip':True,
    'old_live_cap_getter_requirement_reused_not_reconstructed_as_new_solver_truth':True,
    'no_future_targets_branch_world_ids_inside_actor_candidate_input':True,
    'no_held_outcome_access_or_new_tokenizer_context':True,
    'no_new_method_representation_chosen':True,
    'language_specific_incremental_mechanism_gate': 'UNESTABLISHED: metadata semantics exist, but no measured language-specific advantage or justified sufficient textual interface',
    'no_new_training_or_physical_campaign_ready':True,
    'new_model_PF_optimizer_forecast_derivative_solve_controller_cloud_calls':0,
    'seconds_before_seal':time.perf_counter()-started,
}
contract = {
    'contract_type':'Stage0 information boundary; provisional full-universe hypothesis, not deployed actor/interface',
    'actor_candidate_current_fields':{'current_physical_observation':sorted(records and observation),
        'current_added_support_MVAr_by_bus':'118 current values from previously verified current snapshot plus frozen baseline; actual original getter required for future live collection',
        'original_Q_grid':[25.,50.,75.,100.,125.,150.,200.,250.,300.]},
    'no_current_textual_actor_is_certified_to_fit':True,
    'administrative_only_fields':['observation_id','world_sha256','split','source hashes','branch provenance','prefix audit receipt'],
    'training_supervision_only':'Existing measured candidate AFTER/global labels; unknown fields stay unknown. No invented successor vectors, mode labels or delayed rewards.',
    'numerical_tool_information':'All19 current tables/current scopes/450cap; predicted numerical forecasts and nonphysical/unknown status are prediction evidence, not measured AFTER truth. Costs charged. Any actor-visible prior must be equally visible to numerical controls.',
    'decoder_and_verifier':'Original joint bus/Q membership, raw common AND zone scopes, original nine-Q grid and450cap; actual downstream verifier/normal-band check. Grammar alone is not physical safety.',
    'pretraining_external_information':'Pretrained base/private adapter knowledge must be separately attributed; same current fields do not establish equal pretraining or inductive bias.',
    'controls':'Same decoded actor fields plus same numerical prior/data/objective and stronger full-table controls; random/pretraining/adapter controls still required.',
    'mechanism_limit':'Current schema names can convey units/physical meaning. Absence of dynamic narrative is not a universal language-impossibility proof. A specific useful reasoning mechanism and a complete current interface remain to be justified.',
    'no_world_selection_prompt_sweep_or_revival_of_stopped_views':True,
}
write(OUT/'All239_Current_Information_Identity_Records.json',records)
write(OUT/'All_Current_Physical_Column_Inventory.json',inventory)
write(OUT/'Information_Mechanism_Inventory_Summary.json',summary)
write(OUT/'Provisional_Causal_Information_Contract.json',contract)
decision = f'''# Current-information mechanism audit

All239 optimization inputs/all23 historical worlds were inspected, without targets or held metrics. Original input and augmented-current-support hashes matched. All19 physical tables, {len(inventory)} table columns and all118 support entries per state are accounted for. This inventories existing inputs, not an information projection, tokenizer retry, training or physics experiment.

Physical string values have vocabulary {json.dumps(string_vocab)}. Operator narrative field paths recognized by the declared keys: {json.dumps(sorted(narrative_paths))}. Non-table string values are explicit region names; exact field inventory is attached. Table names/columns/units are meaningful domain semantics, so absence of operator prose does not prove that pretrained language reasoning is useless. It does show that the existing task offers no separate observed narrative channel that a numerical control lacks. Both methods can access the same current physical evidence; any difference must come from learning or pretrained reasoning and requires controlled attribution.

{sum(x['changes_across_OPT_views'] for x in inventory)} column vectors change across the239 views and {sum(not x['changes_across_OPT_views'] for x in inventory)} are constant in this development set. Constancy is not permission to omit a field in unseen worlds or replace topology with a scenario identifier. No new compressed representation was designed, and neither stopped overflowing view was retokenized.

The support-cap vector is legitimate current control state, separately verified in prior work from current snapshots and the frozen baseline. Prefix receipts/provenance remain administrative only. Future physical collection must use the actual original getter; this inventory does not create a mature live collector.

The attached information contract separates actor candidates, full-table numerical tools, administrative identities, training-only measured labels and external pretraining knowledge. It is not a signed-off sufficient language interface. Native physical convergence, unseen-world performance, novelty and a99percent success probability remain unproved.

**Decision:** useful language-specific mechanism UNESTABLISHED; actual current textual context UNKNOWN for any materially different justified design. Do not launch a copied-LoRA/full-universe policy from these inventory counts. Next local research must establish a specific current reasoning mechanism and derive the exact deployed preference/decoder behavior, with same-information numerical and pretraining controls. A renamed numerical head, new prompt-size sweep or future-label inclusion fails this boundary. All completed/stopped methods and frozen inputs remain unchanged.

Actual new model/PF/optimizer/forecast/derivative/linear-solve/controller/cloud calls:0. The source hashes, complete input identities and output manifest are separately sealed. This is development-information evidence, not another learning campaign or proof of D-SE superiority.
'''
(OUT/'Current_Information_and_Language_Mechanism_Decision.md').write_text(decision,encoding='utf-8')
files={f.name:f for f in OUT.iterdir() if f.is_file()}
files['sources/auditor.py']=Path(__file__)
archive=seal(OUT,files,'Current_Information_Mechanism_Evidence.zip')
print(json.dumps({'summary':summary,'archive':archive}))
