# Actual complete S1 controller result and next comparison

The full native-greedy controller reached its observed legal terminal in TWO
protected commitments, within its maximum25 slots. A fresh process resumed
the full commitment cursor/history, receipt registry, RNG, direct/root/commit
costs and complete-tree storage ledger. This is a complete observed S1 episode,
not a claim that25 commitments were executed or all future roots are certified.

251 actual nonlinear PF calls returned;0exceptions:243nativequery calls,
3root/actualcommit calls,5separately charged continuous independent rebuild
calls. All exact original72input tables/native menus/Q450cap/score/admission,
all4checkpoints, source/environment/ownership and continuousVm/angle/P/Q1e-10
plus exactUV/caps passed. Maximum replay delta0.0. FinalUV0,deficit0.0,
vmin0.9520000000000004,vmax1.0500000000000005. RawOVcount1 is retained separately;
commonupper protection is1.05+1e-8, so do not claim exactrawOVzero/fullfeasibility.

The original cold receiver8272 failed before any solver call because the
inherited checkpoint hash was absent from its administrative claim. Its source,
claim, failure,9.144528300035745seconds setup and original coordinatorfailure
remain preserved. A separately fixed new receiver18232 continued ONLY the
unexecuted identities from the full warm checkpoint, with no warm/root retry,
source/scientific setting change or extension of the original03:31:10.503070UTC
deadline. Actual replay23856 and sole reader1748 completed; new coordinator25032
and all actual/launcher chains endedexit0. The old failed attempt was not erased
or relabelledsuccessful.

848-member33,101,621-byte full engineering ZIP SHA
bf7c9958aeda102ec0c81eb6e051c9927dc9ffbe1b9f14b62393e7ec04990deb
passedCRC/every-member hashes and ninefreshfrozen checks. Complete extended-path
inventory is used. Reuse this certificate without rehashing on each heartbeat.

Pure solver seconds are recorded separately from query/state/journal/checkpoint/
storage/transfer/archive workflow. Warm wholeowned67.46960050007328seconds,
cold86.0004366999492seconds,replay12.681610400089994seconds and reader
32.649085300043225seconds include their import/setup/preservation/exit. Original
failedcold setup additionally9.144528300035745seconds; all preparation/failed
software/controlcontinuation/coordinator costs remain separate. Unisolated
hash/coordination latency is not a free or deployment-efficiency claim.

## Next substantive work

Implement/source-lock original literalDFF/root-onlyALT/unchangedselector branch
preservation and one independent reader, retaining both individualresults and
FULLBOTH costs. Bind separately labelled commonprotected counterparts and strong
equally informed greedy2/fixedbeam8/exhaustive2 controls. Keep all eight fixed
development roots and their exact input/physics/source/cost/UNKNOWN denominators;
S1 is now inspecteddevelopment. Reuse the certifiedS1samegreedy trajectory and
paidreceipt/cost evidence through exact joins instead of repeating it.

The full opportunity/economic gate remains UNKNOWN. Width8nominal9N versus2N
DSEroot menu cost concern remains; no outcome-selected width or cheaper
comparator. Freeze complete source/ownership/allcost/persistent preservation/
continuous replay and reader protocol BEFORE any comparison performance. A
passed software or single numerical episode gate is not permission for a new
learner/GPU or evidence of novelty/90%confidence/LLMsuperiority. Matchedscale and
all prior adverse methods stay stopped. Original frozenassets/baseline and
Stage3/security limitations stay intact. No current ownedjob or readyGPU.
