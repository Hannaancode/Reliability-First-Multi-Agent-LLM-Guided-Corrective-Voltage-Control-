"""Exact paid-query journal references, removing duplicate decision payloads.

No action/search/score/solver/owner is supplied. A future owner must call
observe only AFTER the original scientific event has been fsynced and must
separately verify the complete scientific chain/dependency prefix.
"""
import copy,hashlib,json
from pathlib import Path
from paid_receding_chunked_history_v2_20261018 import History,verify_history
R=Path(__file__).resolve().parents[1]
FIELDS=('parent','aid','row','record','successor')
MAX_QUERY_EVENT_BYTES=1024**2
MAX_REFERENCED_RECORD_BYTES=4*1024**2
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def context(v):return [v['world'],v['method'],v['decision']]
def local(path):
    p=Path(path).resolve()
    if not p.is_relative_to(R):raise ValueError('Journal outside workspace')
    return p

class ReceiptJournalIndex:
    def __init__(self,journal_path,*,protocol_sha256):
        self.path=local(journal_path);self.protocol=protocol_sha256;self.pending={}
    def observe_closed_durable_query(self,offset,line):
        if not 0<len(line)<=MAX_QUERY_EVENT_BYTES or not line.endswith(b'\n'):raise ValueError('Fixed closed-query line bound')
        event=json.loads(line)
        if event['event']!='every_query_receipt_closed_before_more_science' or event['protocol_sha256']!=self.protocol:raise ValueError('Wrong source protocol or event role')
        d=event['data'];ctx=context(d);message={k:d[k] for k in FIELDS}
        ref={'journal':str(self.path.relative_to(R)),'offset':offset,'bytes':len(line),'line_sha256':digest(line),
             'message_sha256':digest(canon(message)),'context':ctx,'protocol_sha256':self.protocol}
        self.pending.setdefault(tuple(ctx),[]).append(ref)
    def references_for(self,report):
        refs=self.pending.pop(tuple(context(report)))
        if len(refs)!=len(report['query_messages']):raise ValueError('Missing or surplus paid-query receipt')
        for ref,msg in zip(refs,report['query_messages']):
            if ref['message_sha256']!=digest(canon(msg)):raise ValueError('Paid-query order/content mismatch')
        return refs

def read_reference(ref,*,expected_protocol,expected_context):
    if ref['protocol_sha256']!=expected_protocol or ref['context']!=expected_context:raise ValueError('Foreign protocol/context')
    if type(ref['offset']) is not int or ref['offset']<0 or not 0<ref['bytes']<=MAX_QUERY_EVENT_BYTES:raise ValueError('Invalid reference bound')
    path=local(R/ref['journal'])
    with path.open('rb') as stream:
        stream.seek(ref['offset']);line=stream.read(ref['bytes'])
    if len(line)!=ref['bytes'] or digest(line)!=ref['line_sha256'] or not line.endswith(b'\n'):raise ValueError('Missing/changed query journal bytes')
    e=json.loads(line)
    if e['event']!='every_query_receipt_closed_before_more_science' or e['protocol_sha256']!=expected_protocol or context(e['data'])!=expected_context:raise ValueError('Wrong causal event identity')
    message={k:e['data'][k] for k in FIELDS}
    if digest(canon(message))!=ref['message_sha256']:raise ValueError('Query content mismatch')
    return message

def expand_reference_record(payload):
    if payload['codec']!='paid_query_journal_references_v1_20261018':raise ValueError('Wrong history codec')
    report=copy.deepcopy(payload['report_without_query_messages'])
    refs=payload['query_references']
    report['query_messages']=[read_reference(r,expected_protocol=payload['scientific_protocol_sha256'],expected_context=context(report)) for r in refs]
    if digest(canon(report))!=payload['original_report_sha256']:raise ValueError('Original complete report identity mismatch')
    return report

class ReferencedHistory:
    def __init__(self,path,*,source_anchor,input_anchor,max_bytes,query_index):
        self.history=History(path,source_anchor=source_anchor,input_anchor=input_anchor,max_bytes=max_bytes)
        self.query_index=query_index
    def append(self,event,payload):
        if event=='complete_paid_receding_decision':
            report=payload;refs=self.query_index.references_for(report)
            payload={'codec':'paid_query_journal_references_v1_20261018',
                     'scientific_protocol_sha256':self.query_index.protocol,
                     'original_report_sha256':digest(canon(report)),
                     'report_without_query_messages':{k:v for k,v in report.items() if k!='query_messages'},
                     'query_references':refs}
            if len(canon(payload))>MAX_REFERENCED_RECORD_BYTES:raise ValueError('Fixed referenced-record bound, no extension')
        self.history.append(event,payload)
    def anchor(self):
        return self.history.anchor()
    def close(self):self.history.close()

def verify_reference_history(anchor):
    records=verify_history(anchor);checked=0
    for record in records:
        if record['event']=='complete_paid_receding_decision':
            original=expand_reference_record(record['payload']);checked+=len(original['query_messages'])
    return {'records':records,'all_referenced_queries_exact':checked,
            'no_unqueried_or_missing_receipt_fill':True,'new_scientific_calls':0}
