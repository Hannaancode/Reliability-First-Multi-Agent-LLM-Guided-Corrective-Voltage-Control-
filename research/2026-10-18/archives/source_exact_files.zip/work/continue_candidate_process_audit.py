"""One finite owner waits for CPU science, then owns its saved-data audit."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,time,subprocess,traceback
from candidate_process_evidence_utils import ROOT,read,sha,write
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';DATA=BASE/'numerical_process_pilot';OUT=BASE/'numerical_audit_continuation'
assert not OUT.exists();OUT.mkdir();claim=read(DATA/'owner.claim');pid=claim['owner_pid']
reader=ROOT/'work/analyze_candidate_process_numerical_pilot.py';reader_sha=sha(reader)
write(OUT/'owner.claim',{'owner_pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat(),
 'scientific_owner_pid':pid,'source_sha256':sha(Path(__file__)),'external_reader_sha256':reader_sha})
def status(stage,**kw):
    tmp=OUT/'status.tmp';tmp.write_text(json.dumps({'stage':stage,'owner_pid':os.getpid(),'scientific_owner_pid':pid,
        'updated_at_utc':datetime.now(timezone.utc).isoformat(),'new_model_or_PF_calls':0,**kw},indent=2));tmp.replace(OUT/'status.json')
def active():
    p=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    command=p.stdout.strip()
    if command:assert 'run_candidate_process_numerical_pilot.py' in command,'PID no longer belongs to exact scientific owner'
    return bool(command)
try:
    status('waiting_for_actual_scientific_owner_end');start=time.monotonic()
    while active():
        assert time.monotonic()-start<2400,'Finite handoff observation bound; preserve no duplicate science'
        time.sleep(15)
    assert read(DATA/'status.json')['stage']=='complete_closed_numerical_process_study'
    assert read(DATA/'summary.json')['all_declared_training_identity_checkpoint_cost_gates_passed'] and (DATA/'manifest.json').exists()
    assert not (BASE/'numerical_process_pilot_audit').exists(),'Existing audit or partial: no duplicate'
    assert sha(reader)==reader_sha
    status('running_single_saved_artifact_external_audit')
    with (OUT/'audit_stdout.log').open('x') as out,(OUT/'audit_stderr.log').open('x') as err:
        child=subprocess.Popen([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(reader)],cwd=ROOT,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        status('running_single_saved_artifact_external_audit',reader_launcher_pid=child.pid)
        assert child.wait()==0,'External reader failed; preserve actual partial, no scientific rerun'
    audit=BASE/'numerical_process_pilot_audit';cert=read(audit/'Independent_Identity_Checkpoint_and_Cost_Audit.json')
    assert cert['all_hash_identity_journal_cost_checkpoint_gates_passed'] and read(audit/'Local_Archive_Audit.json')['CRC_and_every_member_hash_passed']
    status('numerical_process_science_and_external_local_seal_complete')
except BaseException as e:
    write(OUT/'Terminal_Handoff_Failure.json',{'exception':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'new_model_or_PF_calls':0})
    status('terminal_control_failure_preserved_no_scientific_rerun');raise
