"""One first physics reader after the prior zero-replay analysis failure."""
import subprocess
from graph118_native_campaign_core_20261028 import *
H=R/'outputs/graph118_reader_rng_v2_handoff_20261028'
Q=R/'outputs/graph118_reader_rng_binding_v2_preparation_20261028'
OUT=R/'outputs/graph118_native_campaign_independent_rng_v2_20261028'
def main():
    from coordinate_native_inverter_linear_reference_20261020 import process
    for folder,source in [(E,'run_graph118_native_campaign_20261028.py'),(A,'audit_graph118_native_campaign_20261028.py'),(R/'outputs/graph118_native_campaign_handoff_20261028','coordinate_graph118_native_campaign_20261028.py')]:
        claim=read(folder/'owner.claim')
        for pid in [claim['actual_pid'],claim['parent_pid']]:
            current=process(pid);assert current is None or source not in current.get('CommandLine','')
    p=read(Q/'Protocol.json');assert p['first_replays_already_entered']==0 and read(A/'Failure.json')['first_replay_attempts']==0
    source=R/'work/audit_graph118_native_campaign_rng_v2_20261028.py';assert sha(source)==p['new_reader_sha256']
    H.mkdir(exist_ok=False);put(H/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    start=time.monotonic()
    try:
        with (H/'Reader.log').open('x',encoding='utf-8') as log:
            child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(source)],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            while not (OUT/'owner.claim').exists():assert child.poll() is None and time.monotonic()-start<120;time.sleep(.2)
            claim=read(OUT/'owner.claim');a=process(claim['actual_pid']);parent=process(claim['parent_pid'])
            assert a and parent and a['ParentProcessId']==claim['parent_pid'] and source.name in a['CommandLine']
            assert claim['parent_pid']==child.pid or a['ProcessId']==child.pid
            put(OUT/'Launcher_ACK.json',dict(actual_pid=a['ProcessId'],parent_pid=a['ParentProcessId'],command=a['CommandLine'],source_sha256=sha(source),fresh_exact_source_PID_parent_command=True,at_utc=datetime.now(timezone.utc).isoformat()))
            try:code=child.wait(timeout=max(1,7500-time.monotonic()+start))
            except subprocess.TimeoutExpired:
                current=process(claim['actual_pid'])
                if current and source.name in current['CommandLine']:subprocess.run(['taskkill.exe','/PID',str(claim['actual_pid']),'/T','/F'],capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
                child.wait(timeout=30);raise
        for pid in [claim['actual_pid'],child.pid]:
            current=process(pid);assert current is None or source.name not in current.get('CommandLine','')
        put(OUT/'End_ACK.json',dict(actual_pid=claim['actual_pid'],parent_pid=claim['parent_pid'],launcher_pid=child.pid,exit_code=code,actual_owned_chain_ended=True,workflow_seconds=time.monotonic()-start))
        assert code==0
        audit=read(OUT/'Independent_Audit.json');put(H/'Completion.json',dict(status='ADDITIVE_FIRST_READER_TERMINAL',all4_complete=audit['all4_complete'],audit_status=audit['status'],old_analysis_failure_preserved=True,primary_scientific_calls_repeated=0))
        print(json.dumps(dict(status='PASS',audit=audit['status'])))
    except BaseException as exc:
        put(H/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),no_automatic_retry=True));raise
if __name__=='__main__':main()
