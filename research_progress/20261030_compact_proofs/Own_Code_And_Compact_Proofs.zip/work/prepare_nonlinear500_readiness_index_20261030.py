"""Join exact saved preparation reviews, without running their tests again."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_acquisition_readiness_20261030'
GATES={
 'engine_repair':'outputs/nonlinear13_receding_engine_independent_review_20261030/Review.json',
 'math_bank':'outputs/nonlinear13_saved_math_reader_preparation_20261030/Bank_Final_Review.json',
 'current_state':'outputs/nonlinear13_current_state_v2_preparation_20261030/Independent_Review.json',
 'acquisition_engine':'outputs/nonlinear13_receding_acquisition_preparation_20261030/Independent_Review.json',
 'independent_reader':'outputs/nonlinear13_acquisition_reader_preparation_20261030/Readiness.json',
 'owner_wrapper':'outputs/nonlinear500_acquisition_owner_review_20261030/Review.json',
 'all500_input_binding':'outputs/nonlinear500_input_binding_independent_20261029/Independent_Audit.json'}
NEEDED=[
 'work/run_nonlinear500_receding_acquisition_20261030.py','work/nonlinear13_receding_acquisition_engine_20261030.py',
 'work/nonlinear13_math_receipt_bank_20261030.py','work/nonlinear13_current_state_v2_20261030.py',
 'work/nonlinear13_acquisition_reader_20261030.py','work/audit_nonlinear500_receding_acquisition_20261030.py',
 'work/coordinate_nonlinear500_receding_acquisition_20261030.py','work/coordinate_acquisition_source_bound_owner_20261030.py',
 'work/nonlinear13_saved_math_reader_20261030.py','work/nonlinear13_receding_policy_engine_v2_20261030.py']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
 refs={};pairs=set()
 def walk(x):
  if isinstance(x,dict):
   if isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str):pairs.add((x['path'],x['sha256']))
   for k,v in x.items():
    if k.startswith('work/') and isinstance(v,str) and len(v)==64:pairs.add((k,v))
    walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 for key,path in GATES.items():
  raw=(R/path).read_bytes();v=json.loads(raw);assert v['status'].startswith('PASS'),path
  refs[key]=dict(path=path,sha256=sha(raw),required_status=v['status']);walk(v)
 reviewed={};missing=[]
 for path in NEEDED:
  h=sha((R/path).read_bytes())
  if (path,h) not in pairs:missing.append(dict(path=path,sha256=h))
  else:reviewed[path]=h
 if missing:raise ValueError('Current source not bound by a saved source review: '+json.dumps(missing))
 O.mkdir(exist_ok=False)
 value=dict(status='EXACT_SOURCE_REVIEW_JOIN_FOR_PROSPECTIVE_FREEZE_NO_LAUNCH',at_utc=datetime.now(timezone.utc).isoformat(),
  gates=refs,reviewed_current_sources=reviewed,launch_blockers=[],
  scope='Source/test/current-root preparation joined. Actual owner/clock/source/input/preservation gates still execute before any new numerical call; no performance guarantee.',
  new_optimizer_PF_model_calls=0,old_tests_or_calculations_replayed=0)
 with (O/'Readiness_Index.json').open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.flush();os.fsync(f.fileno())
 print(json.dumps(dict(status='EXACT_REVIEW_JOIN_PASS',gates=len(refs),current_sources=len(reviewed),new_science=0)))
if __name__=='__main__':main()
