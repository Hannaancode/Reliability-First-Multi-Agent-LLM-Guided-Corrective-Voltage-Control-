"""Separate Decimal/count/selector check of the historical67-case saved table.

Not a physical replay. No model, power system or production-audit imports.
"""
import csv
import hashlib
import json
import os
from decimal import Decimal
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/reflection_v4_federation_reconciliation_v3_20261022'


def main():
    p = O / 'Reconciliation.json'
    claim = json.loads(p.read_text(encoding='utf-8'))
    master = list(csv.DictReader((R / 'work/e/handoff/reflection_v4_master_completed_cases.csv').open(encoding='utf-8')))
    total = {'DFF': 0, 'HG-VF': 0, 'HG-SE': 0}
    missing = []
    maximum_delta = Decimal(0)
    for s in master:
        sid = s['scenario_id']
        rows = list(csv.DictReader((R / 'work/e/handoff/branch_results' / (sid + '__branches.csv')).open(encoding='utf-8')))
        n, l = (next(x for x in rows if x['method'] == k) for k in ['no_llm_fallback_first', 'reflection_v2'])
        assert all(x['scenario_id'] == sid for x in rows)
        nu, lu = int(n['final_uv']), int(l['final_uv'])
        if lu != nu:
            chosen = l if lu < nu else n
        else:
            # Intentionally preserve literal original `or 1e99` treatment,
            # including missing and exactly zero deficits.
            nd = Decimal(n['final_deficit'] or '0') or Decimal('1e99')
            ld = Decimal(l['final_deficit'] or '0') or Decimal('1e99')
            if ld < nd - Decimal('1e-12'):
                chosen = l
            elif nd < ld - Decimal('1e-12'):
                chosen = n
            else:
                chosen = l if int(l['accepted_actions']) < int(n['accepted_actions']) else n
        assert chosen['method'] == s['selected_branch']
        for field in ['final_uv', 'accepted_actions', 'llm_direct', 'llm_guided', 'fallback', 'guided_tests', 'fallback_tests', 'llm_direct_tests']:
            assert int(s[field]) == int(chosen[field])
        for field in ['final_vmin', 'final_deficit']:
            if not chosen[field] or not s[field]:
                assert chosen[field] == s[field] == ''
                missing.append({'case_id': sid, 'field': field})
            else:
                delta = abs(Decimal(chosen[field]) - Decimal(s[field]))
                assert delta <= Decimal('1e-12')
                maximum_delta = max(maximum_delta, delta)
        for label, row in [('DFF', n), ('HG-VF', l), ('HG-SE', s)]:
            total[label] += int(row['final_uv'])
    assert total == {'DFF': 32, 'HG-VF': 29, 'HG-SE': 19} and len(master) == 67
    assert len(missing) == 2 and len(claim['historical_missing_selected_fields']) == 2
    assert total['HG-SE'] == claim['branch_totals']['selected_v4']['final_uv']
    manifest = json.loads((O / 'Closed_Manifest.json').read_text())
    for f in manifest['files']:
        b = (O / f['path']).read_bytes()
        assert len(b) == f['bytes'] and hashlib.sha256(b).hexdigest() == f['sha256']
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_INDEPENDENT_SAVED67_COUNTS_AND_LITERAL_SELECTOR_ONLY',
              'checked_cases': len(master), 'checked_branch_rows': 2 * len(master), 'residual_UV': total,
              'maximum_decimal_saved_serialization_delta': str(maximum_delta),
              'missing_selected_deficit_fields_remain_unknown': missing,
              'four_missing_candidate_branch_deficit_fields_not_imputed_as_measurements': True,
              'new_independent_PF_model_training_solver_GPU_calls': 0,
              'fresh_continuous_physics_full137_case_join': 'NOT_CERTIFIED',
              'claim_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
              'reader_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with (O / 'Independent_Saved_Summary_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    print(json.dumps(result))


if __name__ == '__main__':
    main()
