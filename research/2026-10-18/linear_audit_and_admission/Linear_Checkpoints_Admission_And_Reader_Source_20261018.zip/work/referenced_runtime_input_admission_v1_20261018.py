"""Pre-query source/schema/storage admission, no science or outcome selection."""
from pathlib import Path
from paid_receding_referenced_commit_v2_20261018 import validate
from paid_receding_journal_reference_history_v2_20261018 import MAX_QUERY_REFERENCES,MAX_REFERENCE_BYTES,MAX_DECISION_METADATA_BYTES,MAX_REFERENCED_RECORD_BYTES
from owned_bank_joint_reallocation_v1 import Q_GRID
from shared_original_serving_action_domain_v1 import build_current_domain
R=Path(__file__).resolve().parents[1]
METHODS=('immediate1_followup16','breadth4_followup4')

def admit_input(net,cursor,*,world,method,decision,journal_path,runner,zones):
    if not isinstance(world,str) or not world.isascii() or not 0<len(world)<=128:raise ValueError('Bounded ASCII case identity required')
    if method not in METHODS:raise ValueError('Original fixed method required')
    if type(decision) is not int or not 0<=decision<=25:raise ValueError('Original decision-count bound')
    path=Path(journal_path).resolve()
    if not path.is_relative_to(R):raise ValueError('Journal outside workspace')
    relative=str(path.relative_to(R))
    if not relative.isascii() or len(relative.encode())>240:raise ValueError('Reference path exceeds fixed schema bound')
    if set(net.bus.index)!=set(range(118)) or set(net.res_bus.index)!=set(range(118)):raise ValueError('Source118-bus schema required')
    if cursor.get('original_device_operation_budget')!=25 or len(cursor.get('owned_bank_rows',[]))>25:raise ValueError('Unsupported operation/owned-row envelope')
    if Q_GRID!=(25.,50.,75.,100.,125.,150.,200.,250.,300.):raise ValueError('Original nine-Q source changed')
    validate(net,cursor)
    domain=build_current_domain(net,cursor,runner=runner,zones=zones)
    count=len(domain['all_declared_original9Q_ordinary_and_owned_joint_identities'])
    maximum=118*len(Q_GRID)*(1+25)
    if count>maximum or maximum+16!=MAX_QUERY_REFERENCES:raise ValueError('Source full-universe count exceeds frozen encoding envelope')
    # A one-byte list delimiter allowance per bounded reference, declared
    # metadata limit, and conservative fixed envelope overhead.
    upper=MAX_QUERY_REFERENCES*(MAX_REFERENCE_BYTES+1)+MAX_DECISION_METADATA_BYTES+4096
    if upper>=MAX_REFERENCED_RECORD_BYTES:raise ValueError('Encoding capacities do not cover source envelope')
    return {'role':'INPUT_SCHEMA_ADMITTED_NOT_SCIENTIFIC_AUTHORIZATION','world':world,'method':method,'decision':decision,
        'actual_current_menu_rows':count,'max_current_menu_rows':maximum,'max_receipts':MAX_QUERY_REFERENCES,
        'max_referenced_record_bytes':MAX_REFERENCED_RECORD_BYTES,'conservative_encoding_upper_bytes':upper,
        'original_operation_cap_grid_scope_verifier_unchanged':True,
        'domain':domain,'new_model_PF_derivative_forecast_solve_calls':0}
