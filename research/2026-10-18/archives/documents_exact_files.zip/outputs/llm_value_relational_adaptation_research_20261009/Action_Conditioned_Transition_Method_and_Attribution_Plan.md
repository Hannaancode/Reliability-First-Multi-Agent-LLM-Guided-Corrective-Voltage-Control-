# Separate action-conditioned voltage-response research plan

Status: prospective method design, not a launch-ready training or rollout runner.
The failed relational, dense-body, VCSA and branch-selection interventions remain
stopped. This design does not change their objectives, results or stop gates.

## Measured reason to consider the different target

The verified OPT inventory contains 216 actual committed transitions, 193 current
states, 23 worlds, three families and 23 exact same-before/different-action pairs.
Full measured successor vectors exist for these actions only. The independent
source reader checked 101,952 target scalars. They are correlated teacher-selected
development records, not independent examples or a counterfactual action dataset.

The newly preserved, unchanged AC-control magnitude forecasts give equal-world
118-bus MSE 0.000014188962349793972 versus current-state persistence
0.00012149968731525306: an 88.32% reduction. The AC control forecasts upper-guard
crossings for 58 of the 216 measured protected successors. These are OPT design
measurements, not held-performance or D-SE superiority results. They indicate
finite-action residual error worth investigating, while making AC a necessary
strong control. An LLM cannot receive credit for reproducing this analytic benefit.

There were 193 new linear solves, 386 directly instrumented converter calls and
216 analytic vectors; zero exceptions, new PF, model, optimizer or cloud calls.
The original AC source and prior global/ranking results were unchanged. Deriving
previously unsaved matrices cost 72.20 seconds before sealing; original physical
collection/replay costs remain separate. The 202-member, 40,516,200-byte measurement
archive and separate vector/algebra/cost audit passed. See
`OPT_transition_AC_vector_measurement` and `OPT_transition_AC_vector_external_audit`.

## Hypothesis and precise proposed intervention

Test whether an action-conditioned decoder-only LM can learn the finite-action
voltage-response error left by the current analytic control. This replaces the
old acceptance classifier/current-input reconstruction task with measured
next-voltage supervision. No language-generation accuracy, current-state copying
or cheaper search budget is used as a substitute for decision value.

For native candidate bus b and original Q value q, let v be the actual current
118-bus magnitude vector and d(s,b) the unchanged current AC-control response
column. The proposed equation is

    predicted_v_next = v + q*d(s,b) + (q/300)^2 * sigma_OPT * h_theta(s,b,q,d).

`h_theta` is a smooth 118-vector decoder, locally bounded near zero Q, with the candidate bus, Q and
current-derived analytic direction supplied BEFORE the LM body. Q is not supplied
only to a final classification head. Current full-table information, topology,
device state and added support remain available. Exact world, branch, scenario,
source and prefix identifiers, AFTER fields and labels stay outside forward inputs.

The q-squared prefactor gives zero correction and zero correction derivative at
q=0 for locally bounded smooth h. There is no fixed +/-1 output restriction:
use smooth hidden layers and a finite linear output, without clipping the needed
residual range. The q=0 extension must use continuous Q features before the body.
It preserves the supplied analytic tangent.
That tangent is an approximation: the existing PV/PQ bound inference is not a
certificate of the nonlinear solver's active set. Active-set changes may weaken
the usefulness of this inductive bias. This is an explicit falsifiable restriction,
not a safety guarantee or proof that quadratic response learning will succeed.
Zero Q is an algebra fixture only; the original nine-action Q grid is unchanged.

Use a NEW rank-4 additive LoRA at the original seven projection types/all 24 layers,
alpha=4 and dropout=0, initialized once with seed 20261009, B initially zero. The
original four-bit base and original private rank-16 adapter remain frozen and
unchanged. The new adapter has analytically 2,199,552 parameters, one quarter of
the original adapter's 8,798,208. This rank is fixed for the bounded data/resource
budget before performance; there is no rank sweep. A separate immutable loader
must prove actual module names/counts, simultaneous old-plus-new computation,
gradient masks AFTER PEFT restoration and unchanged original values/quantization.
No old trained intervention or smoke checkpoint is used for initialization.

Current data must pass a lossless field/schema boundary. Use frozen native LM
embeddings for literal physical schema names plus a numerical current-row/action
encoder. Common encoder initialization and features are identical across arms.
The numerical controls receive the same numerical fields, physical relations,
action and analytic direction, including the same fixed schema features where
used. A static schema embedding is not an uncharged contextual LLM prediction.
Its extraction/source/preparation costs must be reported. If a lossless full
current representation does not fit, stop implementation readiness; do not trim
information after seeing performance.

This is one-step numerical segment prediction using a causal LM, not a claim of
tested multi-step autoregressive dynamics or a certified AC state. Vm is the
primary output. Measured angles/P/Q remain retained but are not fabricated model
outputs, physics-residual targets or convergence labels.

## Controls, partitions and fixed optimization

Keep the exact existing 23 OPT/eight historical-held world partition. All prefixes
and alternative actions from a world stay together. Join all held committed
transitions by fixed identity only after the method/control protocol is frozen;
do not inspect their target errors for design. Preserve the invalid original world,
zero-action branches, four missing candidate ledgers, unlabelled views and every
partial/failure denominator. Held worlds were inspected historically and remain
development, not independent confirmation.

First implement two strong full-information numerical residual learners: an
electrical graph message-passing model and a global row-attention/MLP model. Both
use the same forecast equation, data, target, scope and actual AC input. Analytically
match ACTIVE trainable capacity to the proposed LM intervention before outcomes;
do not count unused layers or choose widths by validation. Report numerical
conditioning, architecture, precision, frozen-backbone and FLOP differences.
The prior poor acceptance-classifier controls are not these transition controls.

If the numerical/target implementation is viable, use three prospectively fixed
LM attribution arms: pretrained body with the new rank-4 adapter; the same frozen
pretrained body with a capacity-matched active residual head; and the same Qwen
architecture with a seeded random backbone and matched rank-4 adaptation. The
random control receives the identical common input features. Its original-adapter
handling, quantization and initialization comparison must be explicit and tested;
it isolates backbone pretraining only under those controlled conditions. No
pretrained-LLM attribution claim precedes that control. No arm is dropped because
another account has idle compute or a result is adverse.

Fit conditioning on OPT current inputs only. Set the single output unit scale to
the OPT equal-world residual RMS, with a fixed 1e-6-pu numerical floor; do not use
held means/covariances. Train the physical residual error divided by this scale,
averaged over all 118 buses. Do not train an acceptance classifier or a current
reconstruction auxiliary. Each OPT transition has weight 216/(23*n_world).

Use five epochs, microbatch one, ascending transition SHA order, AdamW shared
LR .001/new LoRA LR .0002, decay .01, clip 1 and final epoch 5 only. These are
prospective fixed settings, not claims of being optimal. With the present 216 OPT
transitions each arm has 1,080 planned optimizer steps. Record untrained, final and
fresh-model replay outputs for every declared transition, including failures.
If N is the final exact OPT-plus-held transition count, each trained arm has
1,080+3N planned forwards. Counts are plans, never completed evidence.

The numerical pilot's minimum implementation/data gate requires complete identities,
fresh reload agreement, active gradient/moment participation and at least 10%
OPT residual-MSE reduction versus unchanged AC by a full-information learner.
Failure stops this bounded route; it does not prove the task globally impossible.
No automatic hyperparameter changes or new GPU study follow a failed pilot.

The LM prediction gate requires at least 10% lower held equal-world response MSE
than BOTH the matched frozen-body head and strongest completed numerical/AC
control, strict improvement in at least two exact held worlds against each,
and no new missing/nonfinite identities. Report all bus maxima, upper crossings,
worlds, actions, Q levels and measured same-before contrasts, not a favorable subset.

## Decision and physical gates

A teacher-transition prediction pass permits only a separate fixed native-candidate
evaluation. Full successor vectors for rejected/uncommitted actions remain unknown.
Use all actual saved native global candidate outcomes as decision diagnostics,
with all unknown denominators retained. Every method receives the same raw common
AND zone membership, original Q grid and 450 cap, estimated-score rule, protection
predicate and proposed candidate scope. Predicting convergence is not justified
by these positive teacher vectors; the actual solver/verifier remains authoritative.

The native decision gate remains a K4 recorded-best margin of at least five
percentage points above BOTH the matched frozen LM control and strongest numerical
control, improvement in at least two exact held worlds against each, and no increase
in known rejected fraction. Report K1/4/8/pool results, missing/invalid/unmeasured
actions and preparation/inference costs. Do not choose K, decoder, threshold or
checkpoint after outcomes. A prediction-only pass cannot bypass this gate.

Any later episode study needs a new prospective matched manifest and fresh per-state
observations/inference. The primary comparator stays literal original D-SE = DFF
plus DFF-ALT plus unchanged selector, with full BOTH-branch costs and exact zero/
missing handling. Report each branch. Include a full-search common-guard D-SE
counterpart for protection attribution; do not silently cap the original portfolio.
Ranked proposals must be checked by the unchanged physical solver/verifier. Require
continuous independent replay, normal-upper protection, strict UV outcomes and full
training/setup/inference/solver/failure costs. Genuinely unused authorized confirmation
is still required before superiority. The locked bank is not a new holdout.

## Compute, preservation and execution order

No GPU is allocated by this document. Next implement the common input/target compiler,
numerical controls, masks/count accounting and independent reader; freeze source/input
closure before a single CPU pilot owner. New learned hardware timing is unmeasured.
The original fixed relational arms took 80.05/89.78 scientific minutes and
85.10/96.55 owned minutes at 1,195 steps/2,128 forwards. Those measurements are
planning references, not a promised runtime for this different representation.

For rank-4 LoRA alone, parameter+gradient+two F32 Adam moments are 35,192,832 bytes;
this excludes the base, original adapter, common encoder, activations, runtime,
checkpoint copies and transfer buffers. Do not call it total VRAM. A real bounded
new gradient/memory/context/cold-checkpoint integration must precede full LM training.
Use a copied test instance and reset to independently verified initial values for
science. Preserve and charge the integration calls separately.

Plan at most one allocation request per fixed arm. Three legitimately available T4s
could run the three attribution arms independently; two require an additional
sequential slot. They do not pool VRAM. No account fallback after denial, purchases,
free-hour/reset/lifetime assumptions or allocations because resources are idle.
Freeze the account/arm allocation plan after real readiness, before requests.

The previous 100-step complete AdamW/RNG/cursor plus epoch-boundary ACK discipline
is mandatory: full-state byte hashes and journal prefix checks locally verified
before more science, prediction blocks bounded, small transfer chunks, no silent
replay of completed or unobserved steps. Charge all ACK/copy/hash/transfer times;
larger checkpoints may dominate the compute estimate. A disappearing assignment
produces a preserved partial unless the prospective protocol proves an exact
continuation boundary. Do not invent an optimizer state from a weight checkpoint.

After the new integration, compute the timing bound from actual context distributions,
forward/backward/checkpoint/transfer samples and exact N. A provisional 90–150
minutes per LM arm is only a conservative planning envelope, not measured capacity
or guaranteed access. Three T4s make this roughly one slot; two make two slots.
CPU preparation/controls/audits and conditional native-candidate inference are
additional. Full native inference needs tested independent-prefix KV reuse; each
actual candidate query is charged. It is not one free forward for all actions.

## Literature and novelty limit

[AutoTimes, NeurIPS 2024](https://proceedings.neurips.cc/paper_files/paper/2024/file/dcf88cbc8d01ce7309b83d0ebaeb9d29-Paper-Conference.pdf)
motivates next-numerical-segment transfer; it does not establish action-conditioned
grid benefit. [Jena et al., IEEE TSG 2025](https://doi.org/10.1109/TSG.2025.3583934)
already propose an LLM power-flow surrogate inside topology-adaptive voltage MPC.
The primary abstract is available; full method comparisons were not accessible
in this check. Therefore an LLM surrogate plus voltage control is not a novelty claim.

[In-Context Whitening, 2026 preprint](https://arxiv.org/abs/2607.12241)
adapts power-flow surrogates using solved target-topology output statistics across
multiple backbones. Our held output statistics cannot be borrowed for that purpose.
[Droop-Aware Foundation Model Power Flow, 2026 preprint](https://arxiv.org/abs/2609.23723)
already exposes control parameters to a graph-transformer surrogate. Control-aware
inputs or a transformer alone are not new. [Tan et al., NeurIPS 2024](https://proceedings.neurips.cc/paper_files/paper/2024/file/6ed5bf446f59e2c6646d23058c86424b-Paper-Conference.pdf)
support the need for LM-free/random/pretraining ablations.

The proposed contribution to test is a specific tangent-anchored, action-conditioned
finite-response adapter with exact protected decision/cost attribution. Its components
have precedents; novelty and useful pretrained transfer are unproved. Obtain the
closest prior method details before claiming originality. No 90% success estimate,
positive-result guarantee, D-SE superiority or thesis completion follows this plan.
