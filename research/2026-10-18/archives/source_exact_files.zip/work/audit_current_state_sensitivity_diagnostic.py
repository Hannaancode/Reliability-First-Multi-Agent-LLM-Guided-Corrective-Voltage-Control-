"""External saved-forecast audit and explicitly descriptive baseline checks."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
import gzip,json,math,subprocess
import torch
from candidate_process_evidence_utils import ROOT,read,sha,write,frozen_checks,seal
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';DATA=BASE/'current_state_sensitivity_diagnostic';CACHE=BASE/'tensor_readiness_v2';OUT=BASE/'current_sensitivity_external_audit'
assert not OUT.exists();OUT.mkdir();torch.set_num_threads(2)
pid=read(DATA/'owner.claim')['owner_pid']
p=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
assert not p.stdout.strip(),'Actual current-state diagnostic owner must have ended'
for n,m in read(DATA/'manifest.json').items():assert sha(DATA/n)==m['sha256'] and (DATA/n).stat().st_size==m['bytes']
protocol=read(DATA/'protocol.json');assert sha(ROOT/'work/run_current_state_sensitivity_diagnostic.py')==protocol['source_sha256']
assert sha(ROOT/'work/current_state_linearized_control_native_v3.py')==protocol['control_source_sha256']
def rows(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return [json.loads(s) for s in f]
original=BASE/'input_and_target_contract_nullable_v2'
inputs={r['observation_id']:r for r in rows(original/'Current_Input_Rows.jsonl.gz')}
labels={r['observation_id']:r for r in rows(original/'Measured_Target_Rows.jsonl.gz')}
support={r['observation_id']:r['current_added_support_MVAr_by_bus'] for r in rows(BASE/'current_added_support_observables/Current_Control_State_Observables.jsonl.gz')}
records=read(DATA/'Actual_Current_Sensitivity_Records.json');summary=read(DATA/'summary.json');assert len(records)==311
assert {r['observation_id'] for r in records}==set(inputs)
events=[json.loads(s) for s in (DATA/'Actual_State_Journal.jsonl').read_text().splitlines()]
assert [e['observation_id'] for e in events if e['event']=='linear_state_attempt']==[r['observation_id'] for r in records]
assert [e['observation_id'] for e in events if e['event']=='state_closed']==[r['observation_id'] for r in records]
forecast_count=finite=0;worlds={};priority={};failure_ids=[]
for r in records:
    row=inputs[r['observation_id']];assert row['world_sha256']==r['world_sha256'] and row['split']==r['split']
    if r['status']!='finite_current_linear_system':failure_ids.append(r['observation_id']);continue
    assert math.isfinite(r['condition']) and r['linear_residual']<=1e-8
    obs=row['model_input']['current_physical_observation'];before=obs['global_metrics'];pools=set(b for p in obs['raw_common_and_zone_pools'].values() for b in p)
    expected={(b,j) for b in pools for j,q in enumerate((25.,50.,75.,100.,125.,150.,200.,250.,300.)) if support[r['observation_id']][b]+q<=450.}
    assert {(p['bus'],p['Q_index']) for p in r['candidate_predictions']}==expected
    for prediction in r['candidate_predictions']:
        forecast_count+=1;assert prediction['actual_PF_convergence'] is None
        if prediction['status']=='finite_linear_forecast':
            a=prediction['estimated_after_metrics'];g=prediction['estimated_gains']
            assert g==[before['uv_count']-a['uv_count'],before['deficit_sum']-a['deficit_sum'],a['vmin']-before['vmin'],1.05+1e-8-a['vmax']]
            assert all(math.isfinite(x) for x in g);finite+=1
    if r['observation_id'] in labels and r['known_finite_gain_standardized_MSE'] is not None:
        worlds.setdefault((r['split'],r['world_sha256']),[]).append(r['known_finite_gain_standardized_MSE'])
        priority.setdefault((r['split'],r['world_sha256']),[]).append(r['recorded_oracle_priority'])
assert forecast_count==summary['costs']['analytic_candidate_forecasts']==49471 and summary['costs']['linear_solve_attempts']==311
assert summary['costs']['new_PF_calls']==summary['costs']['new_model_calls']==summary['costs']['new_optimizer_steps']==0
linear={}
for split in ('optimization','development_held'):
    means=[sum(v)/len(v) for (s,w),v in worlds.items() if s==split];linear[split]={'equal_world_standardized_gain_MSE':sum(means)/len(means),'worlds_with_measured_forecasts':len(means),'states_with_measured_forecasts':sum(len(v) for (s,w),v in worlds.items() if s==split),'oracle_inclusion':{}}
    for k in (1,4,8):
        rates=[];den=count=unknown=0
        for (s,w),values in priority.items():
            if s!=split:continue
            supported=[v[str(k)] for v in values if v[str(k)]['known_admissible_oracle_exists']]
            if supported:rates.append(sum(v['recorded_best_score_included'] for v in supported)/len(supported))
            den+=len(supported);count+=sum(v['recorded_best_score_included'] for v in supported);unknown+=sum(v[str(k)]['unknown_unmeasured'] for v in values)
        linear[split]['oracle_inclusion'][str(k)]={'oracle_supported_states':den,'included_states':count,'equal_world_rate':sum(rates)/len(rates) if rates else None,'unknown_predictions_retained':unknown}
# New posthoc descriptive check, not added retrospectively to the pilot's primary claim:
# zero standardized gains = the earlier fixed optimization-only target mean.
constant={};cw={}
for row in read(CACHE/'Target_Index.json'):
    t=torch.load(CACHE/row['tensor_path'],weights_only=True);mask=t['regression_mask']
    mse=float((t['regression'][mask]**2).mean());cw.setdefault((row['split'],row['world_sha256']),[]).append(mse)
for split in ('optimization','development_held'):
    means=[sum(v)/len(v) for (s,w),v in cw.items() if s==split];constant[split]=sum(means)/len(means)
old=read(BASE/'numerical_process_pilot_audit/Actual_Measured_Learning_Results.json')
comparison={'current_linearized_control':linear,'completed_numerical_pilot':old['world_grouped_gain_errors'],
 'posthoc_optimization_mean_global_gain_constant_baseline':constant,
 'constant_baseline_is_descriptive_posthoc_not_confirmatory':True,
 'all_controls_have_same_measured_gain_units_and_normalization':True,'failed_or_nonphysical_linear_forecasts_retained_unknown':failure_ids,
 'linearized_candidate_voltages_not_actual_physical_after':True,'none_is_a_new_DSE_rollout_or_LLM_advantage':True,
 'actual_linear_compute':summary}
cert={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_identity_hash_scope_cap_arithmetic_and_journal_gates_passed':True,
 'current_state_identities':311,'candidate_forecasts':forecast_count,'finite_candidate_forecasts':finite,
 'unknown_linear_state_failures':len(failure_ids),'source_solve_returns':summary['costs']['linear_solve_returns'],
 'actual_native_PF_convergence_remains_unknown_in_all_forecasts':True,'new_model_PF_or_matrix_solves_in_reader':0,
 'original_current_only_derivative_readiness_236columns_verified':True,
 'closed_manifest_sha256':sha(DATA/'manifest.json'),'source_sha256':sha(Path(__file__))}
write(OUT/'Independent_Current_Sensitivity_Audit.json',cert);write(OUT/'Measured_Control_Comparison.json',comparison);write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
held=linear['development_held'];text=f'''# Current-state sensitivity control

All311 exact existing state identities and {forecast_count} analytic forecasts were preserved and externally checked. This required311 finite current-Jacobian linear-system solves,622 converter calls,118.99 seconds and zero new nonlinear PF/model/training calls. Native nonlinear convergence is unknown in every forecast. The Q-bound active set is inferred from current observed generator data and is not the original solver's internal active-set certificate.

Held-development equal-world measured-gain error: {held['equal_world_standardized_gain_MSE']:.6f}. AllK=1/4/8 recorded-oracle inclusion, failed/unmeasured denominators and the completed numerical control's results are retained. A separately labelled posthoc optimization-mean baseline is also reported to prevent interpreting improvement against random initialization as learned superiority.

These are existing-label forecasts and diagnostics, not measured successor voltages, new protected episodes, independent confirmation or LLM value. Original literal D-SE and full both-branch costs remain the primary later physical comparator. No objective/parameter/Q/seed sweep or new learning campaign automatically follows.
'''
(OUT/'Results.md').write_text(text,encoding='utf-8')
files={}
for p in DATA.iterdir():
    if p.is_file() and p.name not in {'status.json','owner.claim'}:files['closed_current_sensitivity/'+p.name]=p
for p in OUT.iterdir():
    if p.is_file():files[p.name]=p
for folder in ('linearized_control_import_readiness_failure','linearized_control_software_readiness','linearized_control_native_v3_readiness'):
    for p in (BASE/folder).iterdir():
        if p.is_file():files['readiness_and_preserved_failures/'+folder+'/'+p.name]=p
for n in ('current_state_linearized_control_native_v3.py','test_current_state_linearized_control_native_v3.py','run_current_state_sensitivity_diagnostic.py',Path(__file__).name):files['sources/'+n]=ROOT/'work'/n
files['prior_numerical_audit.json']=BASE/'numerical_process_pilot_audit/Independent_Identity_Checkpoint_and_Cost_Audit.json'
local=seal(OUT,files,'Current_Sensitivity_Control_Supplement.zip');print(json.dumps({'held_linear_gain_MSE':held['equal_world_standardized_gain_MSE'],'held_optimization_mean_baseline_MSE':constant['development_held'],'held_oracle_inclusion':held['oracle_inclusion'],'archive':local},indent=2))
