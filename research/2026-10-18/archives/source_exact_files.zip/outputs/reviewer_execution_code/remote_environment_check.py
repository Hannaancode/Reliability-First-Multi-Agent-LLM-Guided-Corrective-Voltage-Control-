"""Run inside the isolated Colab Python 3.12 environment, before test-bank use."""
from pathlib import Path
import os,json,hashlib,importlib.metadata as md
os.environ['HF_HOME']=str(Path('cache/huggingface').resolve())
os.environ['UNSLOTH_DISABLE_STATISTICS']='1'
import torch
from unsloth import FastLanguageModel
from huggingface_hub import snapshot_download,HfApi
modeldir=Path('work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1').resolve()
cfg=json.loads((modeldir/'adapter_config.json').read_text())
original_hash=hashlib.sha256((modeldir/'adapter_config.json').read_bytes()).hexdigest()
revision='10413c288cb9629acdf60b3e0229f3ba75efe413'
info=HfApi().model_info(cfg['base_model_name_or_path'],revision='main',files_metadata=True)
assert info.sha==revision,'Canonical base repository moved since the provenance check'
snapshot=Path(snapshot_download(repo_id=cfg['base_model_name_or_path'],revision='main'))
expected=next(s.lfs.sha256 for s in info.siblings if s.rfilename=='model.safetensors')
actual=hashlib.sha256((snapshot/'model.safetensors').read_bytes()).hexdigest()
assert actual==expected
# Base weights are now cached and their revision verified. Preserve adapter config.
os.environ['HF_HUB_OFFLINE']='1'
model,tokenizer=FastLanguageModel.from_pretrained(model_name=str(modeldir),max_seq_length=4096,dtype=None,load_in_4bit=True)
FastLanguageModel.for_inference(model);model.eval()
assert hashlib.sha256((modeldir/'adapter_config.json').read_bytes()).hexdigest()==original_hash
report={'gpu':torch.cuda.get_device_name(0),'cuda_available':torch.cuda.is_available(),'adapter_config_unchanged':True,'base_revision_verified':revision,'base_weight_sha256':actual,'model_loaded':True,'versions':{n:md.version(n) for n in ['torch','numpy','pandas','scipy','numba','pandapower','transformers','peft','accelerate','bitsandbytes','unsloth','unsloth_zoo']}}
Path('outputs/remote_frozen_environment.json').write_text(json.dumps(report,indent=2));print('HIERGRID_FROZEN_ENVIRONMENT '+json.dumps(report),flush=True)
