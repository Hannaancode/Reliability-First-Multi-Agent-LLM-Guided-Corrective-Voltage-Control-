"""Complete-or-partial preserved-output reader, zero additional inference/PF."""
import json,hashlib,os,time,ast
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/original_lora_native13_transfer_preparation_20261020';SRC=ROOT/'outputs/original_lora_native13_transfer_execution_20261020';OUT=SRC/'independent_audit'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();(OUT/'owner.claim').write_text(json.dumps({'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()}),encoding='utf-8');state=json.loads((SRC/'status.json').read_text(encoding='utf-8'));assert state['runtime_released'] and state['all_actual_closed_artifacts_preserved'] and state['scientific_process_ended']
    ready=json.loads((PREP/'Launch_Readiness_Audit.json').read_text(encoding='utf-8'))
    for n,h in ready['source_hashes'].items():assert sha(ROOT/n)==h
    descriptor=json.loads((SRC/'remote_closed_descriptor.json').read_text(encoding='utf-8'));study=SRC/'staged/study'
    for n,m in descriptor['members'].items():assert sha(study/n)==m['sha256'] and (study/n).stat().st_size==m['bytes']
    p=json.loads((PREP/'Production_Protocol.json').read_text(encoding='utf-8'));events=[];previous='0'*64
    if (study/'events.jsonl').exists():
        for line in (study/'events.jsonl').read_text(encoding='utf-8').splitlines():
            r=json.loads(line);e=r['event'];assert e['previous']==previous and hashlib.sha256(json.dumps(e,sort_keys=True,separators=(',',':')).encode()).hexdigest()==r['sha256'];previous=r['sha256'];events.append(e)
    from prepare_original_lora_native13_transfer_gate_20261020 import parse
    cases=[];complete=(study/'Results.json').exists();remote=json.loads((study/'Results.json').read_text(encoding='utf-8')) if complete else None
    for i in range(3):
        pri=study/f'primary_Agent_{i}.json';cold=study/f'cold_Agent_{i}.json';row={'agent':i,'primary':'UNKNOWN_UNRECOVERED','cold':'UNKNOWN_UNRECOVERED','schema':'UNKNOWN'}
        if pri.exists():
            a=json.loads(pri.read_text(encoding='utf-8'));row.update(primary='RETURNED',primary_token_count=len(a['token_ids']),raw_text=a['raw_text'])
            try:row.update(schema='VALID',parsed=parse(a['raw_text']))
            except (ValueError,TypeError,OverflowError) as exc:row.update(schema='INVALID_NATIVE_ROLE_OUTPUT',parse_error=type(exc).__name__)
            assert a['prefix_token_count']+len(a['token_ids'])<=1024 and a['actual_forward_returns']==len(a['token_ids'])
            if cold.exists():
                b=json.loads(cold.read_text(encoding='utf-8'));assert a['token_ids']==b['token_ids'];row['cold']='EXACT_FRESH_MODEL_SEQUENCE'
        cases.append(row)
    if complete:
        assert remote['actual_costs']['generation_returns']==6 and remote['cold_all3_token_sequences_exact']
        for label in ['primary','cold']:
            assert json.loads((study/f'{label}_Immutable_Values_Before.json').read_text(encoding='utf-8'))==json.loads((study/f'{label}_Immutable_Values_After.json').read_text(encoding='utf-8'))
            proof=json.loads((study/f'{label}_Loader_Proof.json').read_text(encoding='utf-8'));assert proof['exact_copied_tensors']==336 and proof['exact_copied_parameters']==8798208 and proof['trainable_body_parameters']==0
            memory=json.loads((study/f'{label}_Memory_And_Source_Proof.json').read_text(encoding='utf-8'));assert memory['actual_private_LoRA_copy_after']['source_tensor_values_identical'] and memory['private_input_hashes_unchanged'] and memory['optimizer_and_trainable_parameters']==0
        assert sum(e['kind']=='generation_attempt' for e in events)==sum(e['kind']=='generation_return' for e in events)==6
        assert sum(e['kind']=='pretrained_forward_return' for e in events)==remote['actual_costs']['pretrained_forward_returns']==sum(json.loads((study/f'{r}_Agent_{i}.json').read_text(encoding='utf-8'))['actual_forward_returns'] for r in ['primary','cold'] for i in range(3))
    valid=sum(c['schema']=='VALID' for c in cases);gate=('PASS_FORMAT_TRANSFER_ONLY' if valid==3 else 'FAIL_FIXED_NATIVE_ROLE_SCHEMA_SCREEN') if complete else 'UNKNOWN_PARTIAL_MODEL_OR_PRESERVATION'
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_INDEPENDENT_PRESERVED_COMPLETE_OR_PARTIAL_SOURCE_COSTS_IMMUTABLE_VALUES_AND_RAW_TOKEN_OUTPUT_AUDIT','science_complete':complete,'fixed_transfer_gate':gate,'strict_valid_primary':valid,'declared_primary':3,'cases':cases,'actual_remote_costs':remote['actual_costs'] if complete else json.loads((study/'Failure.json').read_text(encoding='utf-8')).get('actual_costs') if (study/'Failure.json').exists() else 'UNKNOWN','new_model_PF_GPU_optimizer_calls_by_reader':0,'physics_or_LLM_superiority_claim':False,'native_role_limit':'ExplicitnewnativePIzero-shotservingrolewithunalteredtrainedprivateadapter;failureisnotoriginalpaperformatfailureoruniversalLLMinability. Anyfuturephysicsneedsfullsource/action/history/owner/reader/costgates.','all_actual_artifacts_locally_preserved':True,'actual_selected_T4_released':True,'workflow_seconds':time.monotonic()-start}
    result['actuable_primary_proposals']=sum(c.get('parsed',{}).get('kind')=='native_PI_proposal' for c in cases);result['explicit_abstentions']=sum(c.get('parsed',{}).get('kind')=='explicit_abstain' for c in cases)
    (OUT/'Independent_Audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(OUT/'Closed_Manifest.json').write_text(json.dumps({n:{'bytes':(OUT/n).stat().st_size,'sha256':sha(OUT/n)} for n in ['owner.claim','Independent_Audit.json']},indent=2),encoding='utf-8');print(json.dumps({'independent':'PASS','complete':complete,'native_transfer_gate':gate,'valid':valid,'new_reader_model_PF_calls':0}))
if __name__=='__main__':main()
