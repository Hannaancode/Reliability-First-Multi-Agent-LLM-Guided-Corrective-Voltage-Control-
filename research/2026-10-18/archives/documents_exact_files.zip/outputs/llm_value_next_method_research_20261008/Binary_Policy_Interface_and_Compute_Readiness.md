# Conditional copied-LoRA interface and compute readiness

This is preparation for a possible new method. The guarded TRAIN collection and its independent prospective feasibility gate still govern the research decision. This document does not authorize a scientific gate change, prove novelty, claim a successful model intervention, or start training. The original adapter, VCSA failure, literal D-SE portfolio and sealed thesis baseline remain preserved.

## What was actually measured

The first software prototype passed 14 labelled algebra/input checks, including normalized two-token probabilities, reference-relative preference loss, canonical option order and scope rejection. A separate lossless-codec extension passed eight new software checks. These fixtures made zero model, optimizer or physical solver calls.

The real frozen tokenizer then processed 28 exact original TRAIN root inputs and previously paid first-step receipts. Three other declared worlds lacked saved original root candidate details; they remain explicitly retained rather than reconstructed or replaced. The uncompressed maximum was 5,522 tokens, failing the frozen 4,096 context and 384-token reserve. Lossless bus-voltage references reduced that maximum to 3,719, still seven tokens over the same reserve. An additive explanation-only revision reduced it to 3,697, and all 28 checked inputs now fit. Every semantic payload hash and exact reconstructed field remained identical. Both earlier failed fit proofs and all prior sources are retained. There was no rounding, truncation, outcome-dependent case selection, learned prompt search or model call.

The conditional policy uses the genuine single-token IDs 15 and 16 for `0` and `1`. Its probability is explicitly the two-logit conditional softmax. This is a new finite-option policy, not the likelihood of the old four-zone generation, verification and physics-winner pipeline. No original query function was edited.

The installed adapter header contains 336 F32 tensors and 8,798,208 parameters. Parameters, gradients and two F32 Adam moments alone would occupy 140,771,328 bytes. This excludes the frozen backbone, quantization state, activations, temporary tensors, framework allocations and optimizer overhead. It is not a total GPU memory estimate. Earlier VCSA step times cannot establish full copied-LoRA preference-training time. A genuine bounded gradient/memory/checkpoint integration is required before an execution estimate.

## Scientific and implementation limits

The original DFF-ALT source changes candidate selection only at the first iteration and then uses ordinary DFF. Consequently, its actually executed trajectory can support a first-action continuation target when exact roots, action identities, original continuations and both costs have been audited. This does not assign a future reward to any other unexecuted action. The new guarded collection has not yet supplied a complete audited model-ready set merely because these 28 older contexts fit.

The present input projection includes complete bus voltages, original zonal reports, native scope and two paid one-step option receipts. It excludes other physical tables. It is not claimed Markov-complete. A numerical control must receive exactly the decoded semantic payload; an additional stronger full-table control must also be retained. Labels, branch IDs, scenario IDs and future outcomes remain outside model forwards. Complete production schema validation, all actual guarded root receipts and per-input round trips still need to be sealed.

Selecting two options can at most match the better of their executed endpoints. Its plausible value is avoiding an unnecessary full continuation while retaining quality. Literal original D-SE remains the primary comparison with both branches charged. G-DSE, a shared-root deterministic portfolio, constant-branch choices, an immediate-score choice and strong same-data numerical learners are necessary additional controls. A guard, cache, smaller search or faster solver is not incremental LLM value. Copied-LoRA adaptation would modify genuine attention/MLP adapter parameters, unlike detached VCSA heads, but changing parameters alone is not evidence of contribution.

## Critical research implications

[Decision Transformer](https://arxiv.org/html/2106.01345) conditions sequence decisions on returns and history. It motivates measured episode targets, but requesting a high return does not create protected recoveries or demonstrate that a pretrained language backbone contributes.

[Trajectory Transformer](https://arxiv.org/abs/2106.02039) describes trajectory sequence modelling with planning. Only its abstract was used here. Applying that idea would require supported transition coverage and charged planning; it does not justify inventing oracle successors.

[Q-Transformer](https://arxiv.org/html/2309.10150) trains an autoregressive action-value model with offline value-learning mechanisms. Native language-token logits are not calibrated grid Q-values. Bellman learning would need a separately defined target, trustworthy transitions and unsupported-action controls.

[Constrained Decision Transformers via Value Functions](https://proceedings.mlr.press/v283/wang25a.html) motivates constrained trajectory stitching through learned values; the current assessment uses its abstract. Relabelled trajectories or rewards would need actual physical support. None of these results establishes grid superiority or a 90% chance of success for our small historical partition.

The earlier review also identifies direct AC-derived preference tuning for grid actions. Binary DPO or algorithm selection alone is not a new scientific contribution. Any eventual contribution must be demonstrated through a supported physical mechanism and clean attribution rather than a new name.

## Efficient execution order

1. Let the single existing guarded CPU owner finish. Let its existing finite handoff run the external audit and local archive seal. Preserve all exceptions, adverse findings, unexecuted identities and native/current boundary counters.
2. Read the exact predeclared target gate. Failure stops this guarded branch-selection proposal; incompleteness remains unknown. Passing permits method design only. The separate read-only mechanism reader examines immediate versus terminal UV evidence without extra PF/model calls or gate relaxation.
3. If justified, freeze the complete genuine guarded inputs, objective, copied-weight identity, final-checkpoint rule, controls and cost ledger before model outcomes. Numerical controls run first, without rerunning completed controls or selecting a favorable checkpoint.
4. Only after that readiness, run one bounded genuine copied-LoRA integration to measure CUDA gradients, memory, frozen-source preservation, native-token decision probabilities and checkpoint reload. Use the measured cost to size a single prospective pilot. Additional CLI profiles do not combine VRAM; live access is checked only when useful work is ready.
5. Require fresh matched physical trajectories, all model/root-search/continuation/preparation/training/failure costs and continuous independent replay. Development TRAIN/VAL and inspected bank cases cannot supply unused confirmation. A genuinely independent authorized confirmation remains necessary before declaring LLM superiority or moving to full security evaluation.

The overall research objective remains unachieved. This preparation has zero new model or PF calls and no performance result.
