# Actual D-SE on the eight development cases

The original DFF and DFF-ALT, original full search,25 iterations and portfolio selector were executed without the new normal-band guard or32/512 search limits. These exact1.25/1.50 historical points are development data; they are not the sealed62-case campaign.

All16 branches and eight selected portfolios passed independent identity, full-cost, scientific-manifest and committed-state replay gates. Controller19,772 actual PF attempts,19,745 returns,27 retained exceptions. Independent replay113 solves, zero exceptions, all recorded committed metrics within1e-10. No model calls.

| Case | Selected branch | UV | Vmax | Joint UVzero/normal-upper | Portfolio PF |
|---|---|---:|---:|---|---:|
| fed_combined_load_1p25_line_35_MG1 | DFF | 0 | 1.050000000 | True | 1003 |
| fed_combined_load_1p5_line_35_MG1 | DFF-ALT | 9 | 1.059936640 | False | 3762 |
| fed_combined_load_1p25_line_84_MG2 | DFF | 0 | 1.050966115 | False | 1009 |
| fed_combined_load_1p5_line_84_MG2 | DFF-ALT | 10 | 1.059959358 | False | 3905 |
| fed_combined_load_1p25_line_127_MG3 | DFF | 0 | 1.051797064 | False | 1027 |
| fed_combined_load_1p5_line_127_MG3 | DFF-ALT | 7 | 1.059993259 | False | 3717 |
| fed_combined_load_1p25_line_36_MG1 | DFF | 0 | 1.054473624 | False | 1308 |
| fed_combined_load_1p5_line_36_MG1 | DFF-ALT | 9 | 1.059995610 | False | 4041 |

Strict undervoltage cleared4/8; joint UVzero and normal upper band1.05+1e-8 met1/8. These measurements establish the correct reference, not LLM superiority, an optimum or full operating-limit feasibility.

Audit-only repair: the original28-entry manifest included a changing operational audit_status.json. The original file/failed audit remain preserved. Verified_Scientific_Manifest.json separately verifies all27 scientific members; the sole mutable status is explicitly excluded with provenance. No scientific outputs or controller executions changed.