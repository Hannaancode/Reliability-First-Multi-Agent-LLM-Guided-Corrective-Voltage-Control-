"""Join existing reviewed gates with the new runtime-only source review."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_receding_acquisition_v3_source_preparation_20261030'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 old=R/'outputs/nonlinear500_acquisition_readiness_20261030/Readiness_Index.json'
 index=json.loads(old.read_text(encoding='utf-8'))
 review=O/'Independent_Source_Review.json';r=json.loads(review.read_text(encoding='utf-8'))
 assert r['status']=='PASS_V3_ACTUAL_HOST_RUNTIME_ONLY_SOURCE_REVIEW'
 assert sha(review)=='71d8ac0f61f38d773247f0b2cb45c7bc68056925268e39e8227fc709d235a1d6'
 index['original_reviewed_readiness_index']={'path':old.relative_to(R).as_posix(),'sha256':sha(old)}
 index['original_owner_wrapper_gate']=index['gates']['owner_wrapper']
 index['gates']['owner_wrapper']={'path':review.relative_to(R).as_posix(),'sha256':sha(review),'required_status':r['status']}
 for name in ['run_nonlinear500_receding_acquisition_v3_20261030.py','audit_nonlinear500_receding_acquisition_v3_20261030.py',
  'coordinate_nonlinear500_receding_acquisition_v3_20261030.py','freeze_nonlinear500_receding_acquisition_v3_20261030.py',
  'nonlinear500_isolated_owner_runtime_v3_20261030.py']:
  index['reviewed_current_sources']['work/'+name]=sha(R/'work'/name)
 index.update(at_utc=datetime.now(timezone.utc).isoformat(),status='PASS_V3_READINESS_JOIN_NO_SCIENTIFIC_ENTRY',launch_blockers=[])
 with (O/'Readiness_Index.json').open('x',encoding='utf-8') as f:json.dump(index,f,indent=2);f.flush();os.fsync(f.fileno())
 print(json.dumps({'gates':len(index['gates']),'source_pins':len(index['reviewed_current_sources']),'new_science':0}))
if __name__=='__main__':main()
