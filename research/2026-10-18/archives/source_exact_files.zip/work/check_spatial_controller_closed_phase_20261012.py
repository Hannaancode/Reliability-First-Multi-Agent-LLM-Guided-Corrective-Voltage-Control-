"""Fresh additive SOFTWARE test; original passed v1 suite/source retained.

Reuses check logic, not old fixture outputs. New two-process synthetic/mock
fixture tests closed issuing journal and complete final known cost inheritance.
"""
import copy
import json
import os
import pickle
import random
import sys
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pandapower as pp
import check_spatial_controller_checkpoint_20261012 as suite
import paid_spatial_controller_checkpoint_v1 as base
import paid_spatial_controller_checkpoint_v2 as closed
from native_continuation_preservation_v2 import canonical, EvidenceJournal, extended_local_path
from paid_spatial_native_queries_v2 import NativeQueriesV2
from value_normal_band_mediation import NormalUpperMediation
from frozen_physics_loader import load_stack
from trusted_causal_controller_snapshot import SOLVER_ROLES, write_bytes

suite.OUT = suite.ROOT/'outputs/critical_research_reset_20261010/spatial_controller_closed_phase_software_20261012'
suite.__file__ = __file__
original_sources = suite.sources
def sources():
    return {**original_sources(), **{n: suite.sha((suite.ROOT/n).read_bytes()) for n in
        ['work/paid_spatial_controller_checkpoint_v2.py', 'work/check_spatial_controller_closed_phase_20261012.py']}}
suite.sources = sources


def warm():
    out = suite.OUT
    directory = extended_local_path(out/'fixture')
    directory.mkdir(exist_ok=False)
    protocol = json.loads((out/'Protocol.json').read_text('utf8'))
    ph = suite.sha((out/'Protocol.json').read_bytes())
    write_bytes(directory/'owner.claim', canonical({'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(),
        'protocol_sha256': ph, 'execution_kind': 'LABELLED_MOCK_SOFTWARE'}))
    _, runner, _ = load_stack()
    net = pp.create_empty_network()
    for _ in range(3):
        pp.create_bus(net, vn_kv=110.)
    net.res_bus = pd.DataFrame({'vm_pu': [.92, .94, 1.], 'va_degree': [0., 0., 0.],
                              'p_mw': [1., 1., 1.], 'q_mvar': [0., 0., 0.]}, index=net.bus.index)
    net['converged'] = True
    calls = []
    original = pp.runpp
    def mock(trial, **kwargs):
        assert kwargs == SOLVER_ROLES['trial']
        calls.append(kwargs)
        if len(calls) == 2:
            raise RuntimeError('LABELLED_MOCK_FAILURE_NOT_PHYSICS')
        trial.res_bus.loc[:, 'vm_pu'] = [.94, .96, 1.01]
    pp.runpp = mock
    journal = EvidenceJournal(directory/'warm_events.jsonl', ph)
    random.seed(20261012)
    np.random.seed(20261012)
    q = None
    try:
        with NormalUpperMediation(runner.rescue, 1.05, 1e-8):
            q = NativeQueriesV2(pp, runner, {'MG1': [0, 1, 2]}, directory, journal, protocol, ph)
            process = {'actual_commit_count': 0, 'remaining_slots': 25, 'actual_action_history': [],
                       'failed_signatures': [], 'episode': 'SYNTHETIC_CHECKPOINT_ONLY'}
            parent = q.register(net, process, label='SYNTHETIC_FIXTURE_NO_PHYSICS')
            actions = q.menu(parent)
            accepted = q.query(parent, actions[0])
            failed = q.query(parent, actions[1])
            assert accepted.accepted and not failed.accepted
            action = q.menus[parent][actions[0]]
            process = {**process, 'actual_commit_count': 1, 'remaining_slots': 24,
                       'actual_action_history': [action], 'failed_signatures': [actions[1]]}
            current = q.register(q.restore(accepted.successor)['net'], process,
                                 label='SYNTHETIC_SIMULATED_CURSOR_NO_COMMIT_PF')
            controller = {'phase': 'PRE_SELECTION', 'episode': process['episode'], 'policy': 'SOFTWARE_FIXTURE',
                'actual_commit_count': 1, 'remaining_slots': 24,
                'actual_action_history': [{'iteration': 1, 'parent_handle': parent, 'selected_action_id': actions[0],
                    'trial_successor': accepted.successor, 'action': action, 'committed_handle': current}],
                'current_handle': current, 'failed_signatures': [actions[1]],
                'guard': {'upper': 1.05, 'tolerance': 1e-8}, 'perbus_cap': 450,
                'input_sha256': {'synthetic_fixture': suite.sha(canonical({'buses': 3, 'label': 'MOCK_ONLY'}))},
                'runtime_identity': {'numpy': np.__version__, 'pandas': pd.__version__, 'pandapower': pp.__version__},
                'direct_costs': {'actual_initial_PF': 0, 'actual_commit_PF': 0, 'cursor_fixture_only': True},
                'Qgrid': runner.rescue.Q_SWEEP}
            anchor = closed.save_checkpoint(q, controller, 'planned_warm_prefix')
            phase_anchor = closed.close_planned_phase(q, controller, anchor)
            expected_rng = {'python': [random.random() for _ in range(5)], 'numpy': np.random.random(5).tolist()}
            # Deliberately constructed UNKNOWN software fixture. No query,
            # journal or old scientific artifact is executed or rewritten.
            raw = (Path(anchor['directory'])/'trusted_local_controller.pkl').read_bytes()
            partial = pickle.loads(raw)
            partial['attempted'].add((parent, actions[2]))
            partial['counters_before_checkpoint']['new_queries'] += 1
            partial['stopped'] = True
            partial['resumable'] = False
            row = {'sequence': partial['journal_sequence'], 'previous_sha256': partial['journal_tip'],
                'at_utc': datetime.now(timezone.utc).isoformat(), 'event': 'new_query_intent',
                'payload': {'identity': 'query_000003', 'parent': parent, 'action': q.menus[parent][actions[2]],
                            'label': 'CONSTRUCTED_UNEXECUTED_SOFTWARE_FIXTURE'}}
            tip = suite.sha(canonical(row))
            partial['journal_bytes'] += canonical({'row': row, 'sha256': tip})+b'\n'
            partial['journal_sequence'] += 1
            partial['journal_tip'] = tip
            meta = json.loads((Path(anchor['directory'])/'Manifest.json').read_text('utf8'))
            data = pickle.dumps(partial, protocol=5)
            meta.update(payload_sha256=suite.sha(data), payload_bytes=len(data), journal_tip=tip,
                        journal_sequence=partial['journal_sequence'], resumable_prefix_not_execution_permission=False,
                        software_constructed_fixture=True)
            partial_out = directory/'controller_checkpoints/constructed_unknown'
            partial_out.mkdir(exist_ok=False)
            encoded_meta = canonical(meta)
            write_bytes(partial_out/'trusted_local_controller.pkl', data)
            write_bytes(partial_out/'Manifest.json', encoded_meta)
            partial_anchor = {'directory': str(partial_out), 'payload_sha256': suite.sha(data),
                              'manifest_sha256': suite.sha(encoded_meta)}
            write_bytes(out/'Warm_Returned_Anchor.json', canonical({'anchor': anchor, 'closed_phase_anchor': phase_anchor,
                'partial_anchor': partial_anchor, 'controller': controller, 'expected_rng': expected_rng,
                'warm_pid': os.getpid(), 'parent': parent, 'accepted_action': actions[0], 'failed_action': actions[1],
                'new_unexecuted_action': actions[3], 'original_ordered_menu': actions,
                'warm_mock_solver_calls': len(calls), 'unknown_fixture_is_constructed_not_actual_failure': True}))
    finally:
        if q is not None:
            q.close()
        journal.close()
        pp.runpp = original


extra_checks = []
def bind(q, state, manifest, *, anchor, handoff):
    evidence = json.loads((suite.OUT/'Warm_Returned_Anchor.json').read_text('utf8'))
    phase = evidence['closed_phase_anchor']
    if handoff['receiver_pid'] == os.getpid() and anchor == evidence['anchor']:
        if not extra_checks:
            try:
                closed.bind_planned_handoff(q, state, manifest, anchor=anchor, handoff=handoff,
                    closed_phase_anchor={**phase, 'sha256': '0'*64})
            except ValueError:
                extra_checks.append('wrong_external_closed_phase_anchor_refused')
            else:
                raise AssertionError('Unanchored phase accepted')
            path = q.directory/'warm_events.jsonl'
            saved = path.read_bytes()
            try:
                suite.replace_fixture_file(path, saved+b'{}\n')
                try:
                    closed.bind_planned_handoff(q, state, manifest, anchor=anchor, handoff=handoff,
                                               closed_phase_anchor=phase)
                except ValueError:
                    extra_checks.append('any_issuing_activity_after_checkpoint_closure_refused')
                else:
                    raise AssertionError('Old checkpoint allowed after additional issuing activity')
            finally:
                suite.replace_fixture_file(path, saved)
    result = closed.bind_planned_handoff(q, state, manifest, anchor=anchor, handoff=handoff,
                                       closed_phase_anchor=phase)
    phase_info = json.loads(Path(phase['path']).read_text('utf8'))
    assert q.preservation_seconds >= phase_info['final_query_costs_before_closed_phase_receipt_write']['preservation_seconds']
    extra_checks.append('final_known_checkpoint_and_phase_costs_inherited_without_reset')
    return result


suite.checkpoint = SimpleNamespace(**{name: getattr(base, name) for name in
    ('process_alive', 'read_checkpoint', 'local_file')}, save_checkpoint=closed.save_checkpoint, bind_planned_handoff=bind)


if __name__ == '__main__':
    if '--warm' in sys.argv:
        warm()
    else:
        suite.main()
        result = json.loads((suite.OUT/'Software_Readiness.json').read_text('utf8'))
        result['checks'] += extra_checks
        result['check_count'] = len(result['checks'])
        result['closed_phase_v2_guards_verified'] = True
        result['prior_v1_source_and_first_fixture_preserved'] = True
        result['unknown_fixture_is_constructed_software_only'] = True
        write_bytes(suite.OUT/'Closed_Phase_Software_Readiness.json', canonical(result))
        print(json.dumps({'closed_phase_gate': 'PASS', 'checks': result['check_count'], 'actual_new_PF_model_calls': 0}))
