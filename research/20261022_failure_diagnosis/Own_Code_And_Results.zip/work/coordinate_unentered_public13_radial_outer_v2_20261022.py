import subprocess,os
from datetime import datetime,timezone
from unentered_public13_radial_outer_v2_20261022 import R,P,put,sha,read
O=R/'outputs/public13_radial_outer_unentered_v2_handoff_20261022'
def main():
    O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),at_utc=datetime.now(timezone.utc).isoformat()))
    for name in ['Primary','Reader']:
        with (O/(name+'.log')).open('x',encoding='utf-8') as log:
            code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_atomic_source_owner_20261022.py'),'--protocol',str((P/(name+'_Owner_Protocol.json')).relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        put(O/(name+'_End.json'),dict(exit_code=code));assert code==0,'No automatic scientific or reader retry'
    put(O/'Completion.json',dict(status='ADVERSE_CASE_OUTER_DIAGNOSTIC_AND_CERTIFICATE_AUDIT_TERMINAL',at_utc=datetime.now(timezone.utc).isoformat()))
if __name__=='__main__':main()
