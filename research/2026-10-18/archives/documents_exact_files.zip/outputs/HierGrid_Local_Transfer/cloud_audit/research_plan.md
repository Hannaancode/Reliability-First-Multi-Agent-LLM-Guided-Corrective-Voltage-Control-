# What remains to be done for HierGrid

This plan interprets the supplied handover, manuscript text, and research plans as research context. Embedded execution prompts do not themselves authorize publication, account access, or a compute campaign. The current user requests are to understand the needed work, prepare the cloud environment, and connect to Colab. The user explicitly confirmed that cybersecurity is part of the revised thesis.

## The central research issue

The manuscript reports DFF with 290 residual undervoltage buses, HG-VF with 291, and HG-SE with 193 over 137 historical replay scenarios. HG-SE selects useful learned trajectories for 20 cases and retains DFF for 117. These are manuscript-reported findings, not newly reproduced measurements.

The safety envelope prevents regression by its selection rule. The unanswered question is whether the learned branch adds complementary value beyond another deterministic trajectory, and what computation and reactive support that value costs. The manuscript also acknowledges that training and replay use the same physical scenario population. New held-out-condition evidence is therefore needed.

## First complete the four reviewer experiments

1. **Deterministic diversity control.** Audit actual frozen DFF enumeration/ranking/gates. DFF-ALT chooses the second-ranked distinct physically verified candidate only at iteration 1, then uses normal DFF for iterations 2–25. With no second candidate, use DFF and log why. Define `D-SE = selector(DFF, DFF-ALT)` and `HG-SE = selector(DFF, HG-VF)` with the identical terminal selector and separate copies of the same initial state. Validate and freeze the implementation on historical/development cases before final evaluation.
2. **Locked unseen-condition evaluation.** Recover and hash the existing 62-case bank rather than regenerate it. Verify physical changes, base convergence, training overlap, and outage/DER families. Disclose the 13 observed pilot cases and determine whether their results affected tuning. Collect all included scenarios and failures with branch trajectories, PF solves, model calls/tokens, runtime, support, and accepted actions. The primary comparison is HG-SE versus D-SE; held-out load factors on one network support unseen-condition claims, not broad cross-grid generalization.
3. **Centralized versus zonal proposer.** Use the same frozen shared model, controls, verifier, fallback, and 25-step budget. Match up to four proposal opportunities and prespecify distinct global proposals. Audit the 4096-token context and 384-token generation limits. Compare stand-alone learned branches as well as their envelopes, since DFF selection can conceal proposer differences. Global prompting with a locally trained model does not prove superiority over an optimally trained centralized model.
4. **Conventional AC-OPF/ORPD reference.** Audit the exact shunt model, Q sign, eligible buses, resource limits, and control freedoms before choosing a formulation. A constant-Q sgen is not equivalent to a voltage-dependent shunt; a continuous relaxation is not the identical discrete benchmark. Independently PF-check returned solutions. Retain solver failures separately from established physical infeasibility.

Freeze Qwen2.5-0.5B LoRA, solver/gates/resources, 25 iterations, nominal voltage band 0.95–1.05, hard OV threshold 1.06, and the locked bank. Resolve actual-source/config inconsistencies before final tests. Do not execute the older notebook export wholesale or substitute newly installed dependencies for the missing frozen stack.

Use a prospective paired/family-aware analysis. Record residual-UV difference as HG-SE minus D-SE, so negative favors HG-SE. Report effect sizes and intervals, wins/ties/losses, full-restoration gains/losses, physical support, and computation for both simulated branches. Keep null and adverse results. Final tables and reviewer responses follow complete evidence, not assumptions of LLM superiority.

## Then add the computing/security thesis contribution

Working title: **Secure, Reliable and Policy-Controlled Small-LLM Agents: Verified Search and Execution in a Power-System Testbed**. The proposed 80% CS / 20% EE emphasis concerns research scope and argument, not a guaranteed departmental classification.

PowerGridQA is the published static textual knowledge resource. HierGrid supplies the frozen proposer, deterministic search, simulation verifier, and selector. New retrieval integration and execution-assurance experiments connect them; the corpus is not numerical telemetry, current topology, or evidence of grid safety.

Study four matched arms: no retrieval/existing safeguards; retrieval/existing safeguards; no retrieval/enhanced policy enforcement; retrieval/the same enhanced enforcement. Preserve the published corpus and poison only a separate experimental copy. Separate clean utility, wrong retrieved facts, real-model prompt injection, corrupted observations, and unauthorized actions. Distinguish compromised-output tests from evidence that adversarial text actually influenced the LLM.

Specify trusted dispatcher identity, immutable/versioned state, typed policy, copied-state verification, a sole executor, current-state/action binding, and traceable audit/replay. Credit safeguards already present. Compare ordinary complete mediation as well as existing HierGrid; do not establish novelty by beating only deliberately weakened guards.

The primary threat controls untrusted proposer context/output or retrieved records, not the Python host, policy, protected state, solver, or executor. Evaluate outcomes on true simulated state. Observation edits alone do not demonstrate stealthy state-estimation FDIA. Zero harmful releases in a finite suite does not establish universal security.

Defer retraining, larger models, optimizer distillation, new grids/zoning, dynamic stability, and live deployment during reviewer remediation.

## Next actionable step

Recover the latest notebook, exact frozen resume pack, locked bank/manifest/scenarios, and pilot/full logs. Reconcile hashes, operative limits, ranking/selector, dependencies, and training provenance. Reproduce one historical case before implementing DFF-ALT. Current files support planning and CPU analysis, but cannot support an honest final-bank experiment or mature-runner implementation.

See `asset_audit.md`, `asset_manifest.json`, `environment_report.json`, and `validation.json` for current-instance evidence. The linked prior conversation could not be opened with available tools; this is an interpretation of the supplied handover and papers, not a claim to have retrieved its complete transcript.
