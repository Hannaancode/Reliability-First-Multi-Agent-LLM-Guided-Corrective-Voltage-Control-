# Actual dense-process pretrained learning results

Both fixed arms completed935optimizersteps/1868pretrainedforwards each, with exact311-state fresh-model reproduction per arm. All10epochcheckpoints, source/input/environment/journal/cost/frozen-file and exact owned-release gates passed. No new PF or physical controller trajectory was run.

Held-development gain MSE: frozen heads 1.484750, copied LoRA 1.461735. Equal-world top4 recorded-best inclusion: 0.313641 versus 0.266738. All K values, per-state outcomes and invalid/unknown denominators remain in the actual-results files. Internal-body gate passed=False; future physical-study gate passed=False.

STOP this intervention branch on this dataset; preserve actual evidence, no minor parameter changes/retraining. These are historical learning/development results, not LLM superiority over literal D-SE, causal pretraining, unused confirmation or a novelty claim.
