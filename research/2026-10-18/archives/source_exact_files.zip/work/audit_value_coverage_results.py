"""Independently audit saved coverage results; never execute controller or PF."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
DEV = ROOT / 'outputs/llm_value_development'
OUT = DEV / 'coverage_control_study'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_manifest(folder):
    manifest = read(folder / 'manifest.json')
    assert len(manifest) == len(set(manifest))
    for name, item in manifest.items():
        path = folder / name
        assert path.is_file() and path.stat().st_size == item['bytes']
        assert sha(path) == item['sha256'], name
    return len(manifest)

def same_metrics(left, right):
    return set(left) == set(right) and all(abs(float(left[k])-float(right[k])) <= 1e-10 for k in left)

def main():
    assert not (OUT / 'independent_results_audit.json').exists(), 'Preserve completed audit'
    manifest_count = check_manifest(OUT)
    protocol = read(OUT / 'protocol.json')
    summary = read(OUT / 'summary.json')
    assert sha(DEV / 'Coverage_Control_Protocol_Design.md') == protocol['design_document_sha256']
    for name, digest in protocol['sources'].items():
        assert sha(ROOT / 'work' / name) == digest
    for name, digest in protocol['reference_manifests'].items():
        assert sha(DEV / name / 'manifest.json') == digest
        check_manifest(DEV / name)
    for case in protocol['scenarios']:
        assert sha(ROOT / case['path']) == case['sha256']
    for name, digest in read(ROOT / 'outputs/matched_campaign_protocol.json')['source_sha256'].items():
        assert sha(ROOT / name.replace('\\', '/')) == digest
    rows = summary['rows']
    assert len(rows) == 16 and len({(r['scenario_id'], r['policy'], r['guard']) for r in rows}) == 16
    expected = {(c['scenario_id'], policy, guard) for c in protocol['scenarios']
                for policy in ['frozen_enumeration', 'lowest_voltage', 'seeded_random', 'bus_first_voltage']
                for guard in protocol['guard_conditions']}
    assert {(r['scenario_id'], r['policy'], r['guard']) for r in rows} == expected
    controller_total = replay_total = exceptions = new_count = reference_count = 0
    trajectory_details = []
    for row in rows:
        new = not row['reused_existing_trajectory_without_rerun']
        folder = OUT if new else DEV / ('full_limit_CPU_validation' if row['guard'] == 'original_hard_OV' else 'normal_band_ablation')
        filename = row['scenario_id'] + '__' + row['policy'] + ('__' + row['guard'] if new else '') + '.json'
        path = folder / filename
        assert sha(path) == row['source_file_sha256']
        trial = read(path)
        assert trial['scenario_id'] == row['scenario_id'] and trial['policy'] == row['policy']
        assert trial['PF_budget']['attempts'] == row['actual_original_controller_PF_attempts']
        assert same_metrics(trial['final_metrics'], row['final_metrics'])
        assert row['joint_success'] == (trial['final_metrics']['uv_count'] == 0 and trial['final_metrics']['vmax'] <= 1.05 + 1e-8)
        assert trial['base_network_preserved'] and trial['new_model_calls'] == 0
        if not new:
            reference_count += 1
            continue
        new_count += 1
        assert trial['limits'] == protocol['limits'] and trial['seed'] == protocol['seed']
        assert trial['source_worlds_preserved'] and trial['independent_all_states_candidates_and_committed_actions_match_1e10']
        assert trial['scenario_sha256'] == next(c['sha256'] for c in protocol['scenarios'] if c['scenario_id'] == row['scenario_id'])
        assert trial['PF_budget']['attempts'] <= protocol['limits']['total_pf_cap']
        assert len(trial['decisions']) <= protocol['limits']['max_decisions']
        state = trial['initial_metrics']
        actions, magnitudes, tested_magnitudes, candidate_pf, execution_pf = [], [], {}, 0, 0
        for decision in trial['decisions']:
            assert same_metrics(state, decision['before'])
            candidate_pf += decision['actual_candidate_PF_attempts']
            execution_pf += decision['actual_execution_PF_attempts']
            assert decision['actual_candidate_PF_attempts'] <= decision['candidate_PF_limit'] <= 32
            assert decision['actual_execution_PF_attempts'] <= 1
            for tested in decision['tested']:
                for q in tested['action']['add_shunts_q_mvar'].values():
                    tested_magnitudes[str(q)] = tested_magnitudes.get(str(q), 0) + 1
            chosen = decision['selected_action']
            if chosen is None:
                assert decision['actual_execution_PF_attempts'] == 0
                continue
            assert decision['actual_execution_PF_attempts'] == 1 and decision['fresh_execution_matches_verification']
            matching = [t for t in decision['tested'] if t['action'] == chosen]
            assert len(matching) == 1 and matching[0]['verification']['accepted']
            assert same_metrics(matching[0]['verification']['after'], decision['executed_after_metrics'])
            state = decision['executed_after_metrics']
            if row['guard'] == 'normal_upper_mediation':
                assert state['vmax'] <= 1.05 + 1e-8
            actions.append(chosen)
            magnitudes.extend(float(q) for q in chosen['add_shunts_q_mvar'].values())
        assert actions == trial['executed_actions'] and same_metrics(state, trial['final_metrics'])
        assert trial['PF_budget']['attempts'] == 1 + candidate_pf + execution_pf
        controller_total += trial['PF_budget']['attempts']
        exceptions += trial['PF_budget']['exceptions']
        replay_total += trial['independent_replay_PF_counts']['attempts']
        comparator = next(r for r in rows if r['scenario_id'] == row['scenario_id'] and r['policy'] == 'lowest_voltage' and r['guard'] == 'normal_upper_mediation')
        trajectory_details.append({
            'trial_id': trial['trial_id'], 'decisions': len(trial['decisions']),
            'executed_actions': len(actions), 'nominal_support_mvar': sum(magnitudes),
            'selected_Q_mvar': magnitudes, 'tested_Q_counts': tested_magnitudes,
            'strict_UV_final': trial['final_metrics']['uv_count'],
            'controller_PF_attempts': trial['PF_budget']['attempts'],
            'UV_delta_vs_predeclared_guarded_lowest_voltage': trial['final_metrics']['uv_count'] - comparator['final_metrics']['uv_count'],
            'PF_delta_vs_predeclared_guarded_lowest_voltage': trial['PF_budget']['attempts'] - comparator['actual_original_controller_PF_attempts'],
            'stop_reason': trial['stop_reason']})
    assert (new_count, reference_count) == (4, 12)
    assert controller_total == summary['actual_controller_PF_attempts'] == 1356
    assert replay_total == summary['independent_replay_PF_counts']['attempts'] == 46
    assert exceptions == summary['actual_controller_PF_exceptions'] == 0
    audit = {'audited_at_utc': datetime.now(timezone.utc).isoformat(),
             'auditor_source_sha256': sha(Path(__file__)), 'manifest_sha256': sha(OUT/'manifest.json'),
             'actual_manifest_members_verified': manifest_count,
             'exact_unique_factorial_rows': 16, 'new_trajectories': 4, 'preserved_reference_trajectories': 12,
             'declared_source_case_reference_and_frozen_hashes_passed': True,
             'all_recorded_state_chains_actions_verification_and_costs_passed': True,
             'controller_PF_attempts': controller_total, 'independent_replay_PF_attempts': replay_total,
             'actual_model_calls': 0, 'new_PF_calls_by_this_audit': 0,
             'mechanism_details': trajectory_details,
             'interpretation_limit': 'Recorded-action audit and historical descriptive evidence; no new physical replay, model superiority or full operating feasibility'}
    (OUT/'independent_results_audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps(audit, indent=2))

if __name__ == '__main__':
    main()
