"""Exact deterministic solver-input identity, never a new power-flow solve.

The native runpp option path is cloned byte-for-byte; only its powerflow
binding is replaced by the exact original prefix ending BEFORE the algorithm
call. Equal ppci/options/kwargs mean the solver receives identical arguments.
This is an input/receipt transformation, not an additional measured PF return.
"""
import ast,copy,hashlib,inspect,types

def native_input_prefix(net,kwargs):
    import pandapower as pp
    import pandapower.powerflow as pf
    source=inspect.getsource(pf._powerflow);node=ast.parse(source).body[0]
    cut=next(i for i,n in enumerate(node.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='_run_pf_algorithm')
    body=node.body[:cut]
    assert '_run_pf_algorithm' not in ast.unparse(ast.Module(body=body,type_ignores=[]))
    returned=ast.parse('return net, ppc, ppci, kwargs').body[0]
    prefix=copy.deepcopy(node);prefix.name='_only_native_input_prefix';prefix.body=body+[returned]
    tree=ast.fix_missing_locations(ast.Module(body=[prefix],type_ignores=[]));scope=dict(pf._powerflow.__globals__)
    exec(compile(tree,'<pinned_native_prefix_no_solver>','exec'),scope)
    prefix_function=scope[prefix.name]
    original=pp.runpp
    environment=dict(original.__globals__);environment['_powerflow']=prefix_function
    entry=types.FunctionType(original.__code__,environment,original.__name__,original.__defaults__,original.__closure__)
    entry.__kwdefaults__=original.__kwdefaults__
    assert entry.__code__.co_code==original.__code__.co_code
    prepared,ppc,ppci,algorithm_kwargs=entry(net,**kwargs)
    assert prepared is net and not net['_options']['init_results'] and net['_options'].get('recycle') is None
    assert net['_options']['algorithm']=='nr' and net['_options']['ac'] and net['_options']['mode']=='pf'
    return dict(net=prepared,ppc=ppc,ppci=ppci,algorithm_options=copy.deepcopy(net['_options']),algorithm_kwargs=algorithm_kwargs,
        proof=dict(native_runpp_source_sha256=hashlib.sha256(inspect.getsource(original).encode()).hexdigest(),native_powerflow_source_sha256=hashlib.sha256(source.encode()).hexdigest(),exact_original_prefix_AST_sha256=hashlib.sha256(ast.dump(ast.Module(body=body,type_ignores=[]),include_attributes=False).encode()).hexdigest(),algorithm_invocations=0,one_native_input_preparation_invocation=True))

def assert_solver_input_identity(new,old):
    from strict_saved_native_input_match_v2_20261018 import require_same
    require_same(new['ppci'],old['ppci'],'actual_native_solver_ppci')
    require_same(new['algorithm_options'],old['algorithm_options'],'actual_native_solver_options')
    require_same(new['algorithm_kwargs'],old['algorithm_kwargs'],'actual_native_solver_kwargs')
    assert new['proof']==old['proof']

def map_paid_return(prepared,paid_after):
    from pandapower.results import _extract_results
    from pandapower.auxiliary import _clean_up
    assert paid_after.converged and paid_after._ppc['success']==1
    net=copy.deepcopy(prepared['net']);net['_ppc']=copy.deepcopy(paid_after._ppc);net['converged']=True;net['OPF_converged']=False
    _extract_results(net,net['_ppc']);_clean_up(net)
    return net
