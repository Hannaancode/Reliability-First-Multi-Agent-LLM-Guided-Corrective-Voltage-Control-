# Alignment with the original HierGrid paper and trained zone agent

The original0.5B command-training work is present and preserved. Four original adapter/tokenizer members from the Desktop archive exactly match the frozen workspace files. The public1.5B screen used an unadapted model, different observations/action schema and stricter output parser. It is not a matched test of upgrading the trained HierGrid zone proposer, and its format failures cannot negate the original training results.

This review reads the federation-only revised paper, three original Phase2 handoff reports, saved adapter configuration and trainer states, grouped training rows, original inference/parser source and two offline evaluation summaries. Originals are unchanged. Extracted text supports a methods/evidence review; no visual layout review or fresh reproduction of the historical evaluation is claimed.

## What the original system already implemented

The shared Qwen2.5-0.5B LoRA adapter serves MG1–MG4 through zone-conditioned calls. This is one adapted model reused across four local agent roles. The paper describes137 cleaned physical records per zone and20,000 linguistic instruction variants. The saved grouped inputs contain16,000 training,2,000 validation and2,000 test rows, assigned to109/13/15 original scenario groups. Linguistic variants are not20,000 independent physical worlds.

The original adapter configuration is rank16, alpha16, dropout0, with q/k/v/o and gate/up/down projections adapted. Four saved trainer-state checkpoints document500/1000/1500/2000 steps, reaching two epochs. The final frozen adapter is retained; this review does not select an earlier checkpoint or restart training.

The trained output includes state_summary, fault_detected, zone, voltage/count fields, proposed_action, verification and confidence. Coordination-capable variants also use candidate_action_for_coordinator. It is not the later minimal `{bus,Q_index}` contract. The original inference source asks for a local zone decision and JSON, uses the model's chat template and greedy generation, then strips Markdown fences and extracts the JSON object. A later strict raw-output parser measures a different interface.

Recorded100-example and balanced400-example summaries both report100% valid JSON, required keys and zone match. These are saved historical evaluation results under their original evaluator, not a new run or proof that every unseen prompt is well formed. The100-example result has87 exact-action matches and87 both-no-action matches; action accuracy there is dominated by no-action examples. In the balanced400 summary, verdict matching is96.75%, proposed-bus matching87%, effective-bus matching84%, and effective-action exact matching64.25%. Format learning and numerical action quality are distinct.

The production architecture is broader than a language decoder: proposal generation, parsing/normalization, schema and zone ownership checks, AC verification, magnitude refinement, deterministic critic/router and safety fallback. The Phase2G report explicitly documents actual LLM bus/MVAr proposals and also inconsistent outputs/stalling. The revised paper reports92 of162 executed actions from direct or LLM-guided sources in its25-case checkpoint. That supports participation and useful verified proposals within that checkpoint; it is not a controlled proof of advantage over the original fully costed D-SE portfolio.

The learned Phase2E critic is already a rejected ablation. The retained semantic-policy critic is deterministic and covers forbidden buses, maintenance blacklists, budgets, reactive-power limits and lower-magnitude alternatives. Generic LLM critic or operator-policy parsing must not be proposed as an unimplemented novel idea without acknowledging this prior work.

## Reconciliation with recent research

| Work | Relationship to the original paper | Correct interpretation |
|---|---|---|
| Sealed original baseline and actual trained zone-agent studies | Preserve the trained proposer, network/controller assets and executed proposal evidence. | Original work remains valid within its recorded scope. Stronger matched comparisons can still fail to establish incremental benefit. |
| VCSA, dense and relational structured-head studies | Distinct interventions using the preserved backbone/adapter through new representations and targets. They do not reproduce the original text-command training task. | Real gradients and changed weights are measured, but neither proves that the original learned command skill was effectively used. Their adverse results remain. |
| Public1.5B bounded screen | No original adapter or equivalent1.5B fine-tuning; different current context/schema and strict parser. | Reject its exact tested interface. Do not call it a fair trained0.5B-versus1.5B comparison, a capacity ceiling or failure of the original trained parser. |
| Current saved-feedback numerical control | A different local development test; no LLM actor or training, original command skill not evaluated. | May test whether causal feedback supports numerical acquisition. It cannot establish paper novelty, command-format improvement or LLM superiority. |

The current research goal is aligned with proving actual incremental LLM value over D-SE, but not every exploratory arm reproduces the original paper's agent role. That distinction must be visible in planning, reports and progress records. Poor structured-head outcomes do not erase the original command-training achievement; original format success does not prove a recovery advantage.

## Required correction before a future larger-model comparison

No matched trained1.5B upgrade has been executed. If the scale question is pursued, prospectively define the SAME zone-proposal role, actual current fields, canonical original schema, equivalent training/split information and original parser/validation/refinement contract for both sizes. Preserve the trained0.5B baseline without retraining it. A1.5B adapter must be newly initialized for its own dimensions; transplanting incompatible0.5B matrices is invalid. Use one justified budget and final checkpoint, not a sweep to repair the public screen after observing failures.

Report JSON/zone/action eligibility first, then actual protected physical outcomes and total costs against the literal DFF+DFF-ALT+unchanged selector, with both branches individually. Decoder repair and larger capacity are engineering changes, not independent language-pretraining attribution or novelty. Historical train/validation/test/inspected cases remain development; unused confirmation is still required.

Review and source reconciliation therefore precede any additional model launch. The existing saved-only CPU owner may finish its frozen budget and preserve partials, but it does not authorize another LLM study. The whole validated-superiority/full-security goal remains unachieved.

Evidence: [exact training/model/schema reconciliation](Original_Training_Model_and_Contract_Reconciliation.json), [original paper text](Original_Paper_Source.txt), [original inference and parser](Original_Phase2C_Inference_Source.txt), and the three extracted original handoff reports in this folder. Original archives remain in the human-specified Desktop directory.
