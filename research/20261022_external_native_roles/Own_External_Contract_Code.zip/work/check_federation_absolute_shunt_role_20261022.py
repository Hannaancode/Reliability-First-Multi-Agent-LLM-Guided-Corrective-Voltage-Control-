"""Exhaustive scalar action correspondence plus actual native application.

No model/solver/training. This action port does not imply a trained external
controller, a ready physics campaign or measured performance.
"""
import copy,json,pickle,sys,time
from reflection118_chronological_core_20261022 import R,read,put,sha
from federation_absolute_shunt_role_20261022 import AbsoluteShuntRole,Q,TARGETS
O=R/'outputs/federation_common_absolute_shunt_role_20261022'


def main():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    def no(*a,**k):raise BaseException('No PF/model calls in action correspondence gate')
    pp.runpp=no
    from frozen_physics_loader import load_stack,AUDIT
    _,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    O.mkdir(exist_ok=False);start=time.perf_counter();role=AbsoluteShuntRole(tuple(range(118)))
    # Integer enumeration is independent of the role's encode/decode method.
    scalar_pairs=0
    for current in range(0,451,25):
        stocks={b:current for b in range(118)};mask=role.mask(stocks,set(range(118)))
        expected={(b,current+q) for b in range(118) for q in (25,50,75,100,125,150,200,250,300) if current+q<=450}
        actual={role.decode(a) for a,v in enumerate(mask) if a and v};assert actual==expected
        for b,target in expected:
            idx=role.encode(b,target);assert role.decode(idx)==(b,target)
            assert role.native_delta(idx,stocks,set(range(118)))=={'add_shunts_q_mvar':{str(b):float(target-current)}}
        scalar_pairs+=len(expected)
        # An already-set absolute target cannot be used again; it is a no-op
        # or decrease, never an available original positive increment.
        if current:
            for b in range(118):assert not mask[role.encode(b,current)]
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    integrations=[]
    for row in roots:
        net=pickle.loads((R/row['solved_payload']).read_bytes())['net']
        stocks={b:runner.rescue.llm_q_abs_at_bus(net,b) for b in role.buses};assert all(q==0 for q in stocks.values())
        assert sum(role.mask(stocks,role.buses))==1063
        for bus,q in [(12,25),(20,150),(117,300)]:
            native=role.native_delta(role.encode(bus,q),stocks,role.buses);test=copy.deepcopy(net)
            runner.rescue.apply_action(test,native)
            assert runner.rescue.llm_q_abs_at_bus(test,bus)==q
            assert len(test.shunt)==len(net.shunt)+1 and test.res_bus.equals(net.res_bus)
        integrations.append({'case_id':row['case_id'],'all1062positive_initial_native_actions_bijective':True,'pure_apply_checks':3})
    put(O/'Independent_Action_Correspondence.json',{'status':'PASS_EXHAUSTIVE_ABSOLUTE_TARGET_TO_ORIGINAL_NATIVE_INCREMENT_CORRESPONDENCE',
        'source_sha256':sha(R/'work/federation_absolute_shunt_role_20261022.py'),'scalar_pairs_checked':scalar_pairs,
        'full_action_classes_including_explicit_stop':role.size,'all4_real_root_checks':integrations,
        'new_PF_model_training_calls':0,'not_a_trained_model_or_ready_performance_campaign':True,
        'important_scope':'Caller must bind identical actual allowed buses/raw protection/history/budget for all methods. Full118catalog is a named common-task port; it does not silently replace original paper candidate pruning.',
        'workflow_seconds':time.perf_counter()-start})
    print(json.dumps(read(O/'Independent_Action_Correspondence.json')))


if __name__=='__main__':main()
