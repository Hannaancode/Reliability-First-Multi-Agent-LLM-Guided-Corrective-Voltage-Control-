"""New input-contract audit: final solver mask versus restored bus labels.

No PF, derivative, factorization, forecast, model, training or source repair.
All four paid roots and all30 closed checkpoint states, without selection.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import inspect
import json
import os
import pickle
import sys
import time
import zlib
import numpy as np
import pandapower as pp
import pandapower.pf.run_newton_raphson_pf as native
from joint_reallocation_opportunity_core_v1 import load_endpoint

R=Path(__file__).resolve().parents[1]
B=R/'outputs/actual_solver_mask_namespace_20261014'
S=R/'outputs/full_joint_suffix_benchmark_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def prepare():
    B.mkdir(exist_ok=False);p=read(OLD/'preparation/Protocol.json')
    names=[Path(__file__),Path(inspect.getsourcefile(native)),R/'work/joint_reallocation_opportunity_core_v1.py',
           OLD/'preparation/Protocol.json',S/'partial_audit_v1/Independent_Preserved_Prefix_Audit.json']
    for e in p['current_endpoints']:
        path=R/e['endpoint_record'];record=read(path)
        names += [path,R/e['decoded_net_container_root']/record['endpoint']['path']]
    for i in range(1,31):names += [S/'actual/checkpoints'/str(i)/'Manifest.json',S/'actual/checkpoints'/str(i)/'State.zlib']
    source=inspect.getsource(native)
    assert '"pv": pv, "pq": pq, "ref": ref' in source
    assert 'bus[setdiff1d(changed_gens, ref), BUS_TYPE] = PV' in source
    put(B/'Protocol.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'question':'Does the case-table PQ/PV namespace used in the paid ordering helper equal the final native solve mask preserved in ppci.internal?',
        'all_four_roots':[e['world'] for e in p['current_endpoints']], 'all30_closed_checkpoints':list(range(1,31)),
        'source_input_sha256':{str(x.relative_to(R)):sha(x) for x in names},
        'original_ordering_source_statement':'types=case[bus][:,1]; nr=flatnonzero(types!=3); pq=flatnonzero(types==1)',
        'installed_source_binding':'Final native Newton call stores internal.pv/pq/ref. Q-limit completion can restore displayed BUS_TYPE toPV without regenerating those final internal sets.',
        'source_and_observation_assertions':'Each final pv/pq/ref partition disjoint/covers118, one ref; stored Newton J dimensions agree with that partition; compare restored labels and actual sets for every declared state.',
        'new_PF_derivative_factor_solve_forecast_model_optimizer_calls':0,
        'original_science_sources_inputs_gates_unchanged':True,
        'no_automatic_recompute_repair_or_rollout':True,
        'resource_bound_seconds':120.})
    print(json.dumps({'prepared':str(B),'saved_states':34,'new_science_calls':0}))

def mask_record(net,identifier,extra):
    case=net['_ppc'];inner=case['internal'];n=len(case['bus'])
    assert n==118 and net.converged
    ref=np.asarray(inner['ref'],dtype=int);pv=np.asarray(inner['pv'],dtype=int);pq=np.asarray(inner['pq'],dtype=int)
    assert len(ref)==1 and len(ref)+len(pv)+len(pq)==n
    assert len(set(ref)|set(pv)|set(pq))==n and set(ref)|set(pv)|set(pq)==set(range(n))
    assert inner['J'].shape==(len(pv)+2*len(pq),len(pv)+2*len(pq))
    displayed=case['bus'][:,1].astype(int)
    shown_ref=np.flatnonzero(displayed==3);shown_pv=np.flatnonzero(displayed==2);shown_pq=np.flatnonzero(displayed==1)
    return {'state':identifier,**extra,'actual_final_ref':ref.tolist(),'actual_final_PV':pv.tolist(),'actual_final_PQ':pq.tolist(),
        'displayed_ref':shown_ref.tolist(),'displayed_PV':shown_pv.tolist(),'displayed_PQ':shown_pq.tolist(),
        'final_Newton_J_shape':list(inner['J'].shape),'displayed_mask_J_dimension':len(shown_pv)+2*len(shown_pq),
        'displayed_mask_matches_actual_final_solver':set(shown_ref)==set(ref) and set(shown_pv)==set(pv) and set(shown_pq)==set(pq),
        'displayed_PV_but_actual_PQ':sorted(set(shown_pv)&set(pq)),
        'final_internal_V_matches_res_bus':bool(np.max(np.abs(inner['V'][net['_pd2ppc_lookups']['bus']] -
            (net.res_bus.loc[range(118),'vm_pu'].to_numpy()*np.exp(1j*np.deg2rad(net.res_bus.loc[range(118),'va_degree'].to_numpy())))))<=1e-14)}

def worker():
    p=read(B/'Protocol.json')
    for name,h in p['source_input_sha256'].items():assert sha(R/name)==h,name
    out=B/'actual';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'argv':sys.argv})
    def blocked(*a,**k):raise AssertionError('Mask input audit permits no solving')
    for name in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,name,blocked)
    rows=[];old=read(OLD/'preparation/Protocol.json')
    for i,e in enumerate(old['current_endpoints'],1):
        net,_,_=load_endpoint(e);r=mask_record(net,'ROOT'+str(i),{'world':e['world'],'kind':'root'})
        with np.load(OLD/'actual'/f'W{i}_Current_Jacobian.npz',allow_pickle=False) as packet:
            assert np.array_equal(packet['PQ'],r['displayed_PQ'])
            assert list(packet['J'].shape)==[r['displayed_mask_J_dimension']]*2
            r['original_saved_ordering_J_shape']=list(packet['J'].shape)
        rows.append(r)
    for i in p['all30_closed_checkpoints']:
        assert time.perf_counter()-start<p['resource_bound_seconds']
        folder=S/'actual/checkpoints'/str(i);manifest=read(folder/'Manifest.json');encoded=(folder/'State.zlib').read_bytes()
        assert hashlib.sha256(encoded).hexdigest()==manifest['encoded_sha256']
        raw=zlib.decompress(encoded);assert hashlib.sha256(raw).hexdigest()==manifest['raw_sha256']
        saved=pickle.loads(raw);c=saved['cursor'];phase=saved['next_phase']
        rows.append(mask_record(saved['net'],'CHECKPOINT'+str(i),{'world':c['world'],'kind':'checkpoint',
            'checkpoint':i,'method':phase['method'],'decision':phase['decision']}))
    assert len(rows)==34 and all(r['final_internal_V_matches_res_bus'] for r in rows)
    put(out/'All_Actual_Mask_Records.json',{'rows':rows,'all_declared_saved_states':34,'elapsed_seconds':time.perf_counter()-start,
        'source_input_contract':'MATCH' if all(r['displayed_mask_matches_actual_final_solver'] for r in rows) else 'FAIL_DISPLAYED_MASK_IS_NOT_FINAL_SOLVER_MASK',
        'new_PF_derivative_factor_solve_forecast_model_calls':0,
        'physical_receipts_and_original_failed_scientific_gates_not_relabelled':True})
    put(out/'Result.json',{'exit_code':0,'saved_input_namespace_audit_complete':True})
    print(json.dumps({'closed_states':34,'mismatches':sum(not r['displayed_mask_matches_actual_final_solver'] for r in rows),'new_science_calls':0}))

def audit():
    out=B/'audit';out.mkdir(exist_ok=False);p=read(B/'Protocol.json')
    for name,h in p['source_input_sha256'].items():assert sha(R/name)==h,name
    d=read(B/'actual/All_Actual_Mask_Records.json');assert read(B/'actual/Result.json')['exit_code']==0
    roots=[];nonroot=0
    for r in d['rows']:
        actual=[set(r[k]) for k in ['actual_final_ref','actual_final_PV','actual_final_PQ']]
        assert sum(map(len,actual))==len(set.union(*actual))==118
        assert set.union(*actual)==set(range(118)) and len(actual[0])==1
        assert r['final_Newton_J_shape']==[len(actual[1])+2*len(actual[2])]*2
        displayed=[set(r[k]) for k in ['displayed_ref','displayed_PV','displayed_PQ']]
        match=displayed==actual;assert match==r['displayed_mask_matches_actual_final_solver']
        assert r['displayed_PV_but_actual_PQ']==sorted(displayed[1]&actual[2])
        if r['kind']=='root':roots.append({'world':r['world'],'actual_PQ':len(actual[2]),'displayed_PQ':len(displayed[2]),
            'mask_match':match,'actual_J_shape':r['final_Newton_J_shape'],'old_saved_J_shape':r['original_saved_ordering_J_shape']})
        else:nonroot+=int(not match)
    assert len(roots)==4 and len(d['rows'])==34
    report={'status':'PASS_ALL34_SAVED_FINAL_MASK_PARTITION_AND_J_SHAPE_IDENTITIES',
        'actual_input_namespace_contract':d['source_input_contract'],'all_four_roots':roots,
        'closed_checkpoint_masks_not_matching_displayed_types':nonroot,'all30_checkpoint_masks_retained':True,
        'source_proof':'Installed native solver preserves final internalPV/PQ/ref, then restores some displayed BUS_TYPE labels after Q-limit enforcement.',
        'new_model_PF_derivative_factor_solve_forecast_optimizer_calls':0,
        'original_numerical_guidance_and_MILP_inputs':'PRESERVED_AS_EXECUTED; no recomputation or repaired primary result',
        'original_native_physical_receipt_and_commit_validity':'Separate; no solver/controller/action/protection change and no new replay',
        'next_gate':'Any newly specified actual-mask numerical engineering must reuse exact paid dS arrays where compatible, retain old wrong-mask sources/costs/gates, freeze new matrix/input/source/ownership/checks before calls, and make no automatic performance/LLM claim.'}
    put(out/'Independent_Actual_Mask_Namespace_Audit.json',report)
    print(json.dumps(report))

if __name__=='__main__':
    cli=argparse.ArgumentParser()
    for k in ('prepare','worker','audit'):cli.add_argument('--'+k,action='store_true')
    a=cli.parse_args();assert sum(vars(a).values())==1
    if a.prepare:prepare()
    elif a.worker:worker()
    else:audit()
