"""Minimal first-iteration diversity extension of the saved DFF controller."""
import ast,copy,inspect

def choose_candidate(candidates,iteration,score,signature):
    accepted=[c for c in candidates if c['verif']['accepted']]
    if not accepted:return None,{'iteration':iteration,'reason':'no_accepted_candidate','alt_unavailable':iteration==1}
    best=max(accepted,key=score)
    if iteration!=1:
        return best,{'iteration':iteration,'reason':'ordinary_dff','chosen_action':best['action'],'chosen_score':score(best)}
    ranked=sorted(accepted,key=score,reverse=True) # stable: retains original DFF tie order
    distinct=[];seen=set()
    for c in ranked:
        sig=signature(c['action'])
        if sig not in seen:distinct.append(c);seen.add(sig)
    second=distinct[1] if len(distinct)>1 else None
    chosen=second if second is not None else best
    return chosen,{'iteration':iteration,'reason':'second_ranked_distinct' if second is not None else 'second_candidate_unavailable','alt_unavailable':second is None,'accepted_count':len(accepted),'distinct_count':len(distinct),'first_action':distinct[0]['action'],'first_score':score(distinct[0]),'second_action':second['action'] if second else None,'second_score':score(second) if second else None,'chosen_action':chosen['action']}

def build_dff_alt(reflection,runner):
    """Change exactly one best-candidate expression; retain the original loop."""
    fn=ast.parse(inspect.getsource(reflection.run_one_scenario_no_llm_fallback_first)).body[0]
    original=copy.deepcopy(fn);fn.name='run_dff_alt'
    target=[n for n in ast.walk(fn) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='best']
    assert len(target)==1 and ast.unparse(target[0].value)=='max(accepted, key=runner.rescue.score_candidate)'
    target[0].value=ast.parse('_choose(accepted, it + 1)',mode='eval').body
    # Assert the candidate selection is the only loop/body change.
    check=copy.deepcopy(fn);check.name=original.name
    t=next(n for n in ast.walk(check) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='best')
    t.value=copy.deepcopy(next(n for n in ast.walk(original) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='best').value)
    assert ast.dump(check,include_attributes=False)==ast.dump(original,include_attributes=False)
    decisions=[]
    def choose(candidates,iteration):
        candidate,audit=choose_candidate(candidates,iteration,runner.rescue.score_candidate,runner.action_signature)
        decisions.append(audit);return candidate
    env=reflection.__dict__.copy();env['_choose']=choose
    tree=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]));exec(compile(tree,'<DFF-ALT one-expression extension>','exec'),env)
    def run(*args,**kwargs):
        decisions.clear();result=env['run_dff_alt'](*args,**kwargs)
        result['method']='dff_alt';result['dff_alt_decisions']=copy.deepcopy(decisions)
        return result
    return run,ast.unparse(tree)
