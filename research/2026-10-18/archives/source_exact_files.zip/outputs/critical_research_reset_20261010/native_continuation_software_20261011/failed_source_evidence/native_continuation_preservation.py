"""Additive native continuation/preservation implementation; import does no PF.

No implicit scenario application, root solve, replay, model, retry or allocation.
Actual execution requires an independently authorized, closed input contract.
The preparatory API exposes no automatic execution from a software result.
"""
import ast,copy,hashlib,inspect,json,os,pickle,random,re,time
from datetime import datetime,timezone
from pathlib import Path
from collections import Counter
import numpy as np
from trusted_causal_controller_snapshot import capture,validate,write_bytes,sha_bytes
from dff_alt import choose_candidate
from train_trajectory_measurement_nullable_v2 import safe

class PreservationStop(BaseException):pass
class ResourceStop(BaseException):pass

def canonical(value):return json.dumps(safe(value),sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')
def now():return datetime.now(timezone.utc).isoformat()

class EvidenceJournal:
    """One exclusive writer with fsynced ordered hash-chain entries."""
    def __init__(self,path,protocol_sha256):
        self.stream=Path(path).open('xb');self.sequence=0;self.previous=protocol_sha256
    def emit(self,event,payload):
        row={'sequence':self.sequence,'previous_sha256':self.previous,'at_utc':now(),'event':event,'payload':safe(payload)}
        body=canonical(row);identity=sha_bytes(body)
        self.stream.write(canonical({'row':row,'sha256':identity})+b'\n');self.stream.flush();os.fsync(self.stream.fileno())
        self.sequence+=1;self.previous=identity
        return identity
    def close(self):self.stream.close()

def derive_continuation(reflection,runner,expected_source_sha256,*,alt=False):
    """Retain the native tail AST. Change only the resume range and ALT choice.

    The discarded initial section applies scenario and solves the root; the
    caller instead supplies the actual solved state and complete prefix result.
    No textual search/replacement or old source edit is performed.
    """
    path=Path(reflection.__file__);source=path.read_bytes()
    if sha_bytes(source)!=expected_source_sha256:raise ValueError('Native source pin mismatch')
    tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_one_scenario_no_llm_fallback_first')
    original=copy.deepcopy(fn)
    offset=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and ast.unparse(n)=='failed_sigs = set()')
    tail=copy.deepcopy(fn.body[offset:]);loops=[n for n in tail if isinstance(n,ast.For)]
    if len(loops)!=1 or ast.unparse(loops[0].iter)!='range(runner.MAX_ITERATIONS)':raise ValueError('Unsupported native loop structure')
    loop=loops[0];loop.iter=ast.parse('range(start_iteration, runner.MAX_ITERATIONS)',mode='eval').body
    targets=[n for n in ast.walk(loop) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='best']
    if len(targets)!=1 or ast.unparse(targets[0].value)!='max(accepted, key=runner.rescue.score_candidate)':raise ValueError('Unsupported native selector')
    if alt:targets[0].value=ast.parse('_native_alt_choice(accepted, it + 1)',mode='eval').body
    # Reverse the two declared changes and require exact original tail identity.
    check=copy.deepcopy(tail);original_loop=next(n for n in original.body[offset:] if isinstance(n,ast.For))
    checked_loop=next(n for n in check if isinstance(n,ast.For));checked_loop.iter=copy.deepcopy(original_loop.iter)
    checked_best=next(n for n in ast.walk(checked_loop) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='best')
    checked_best.value=ast.parse('max(accepted, key=runner.rescue.score_candidate)',mode='eval').body
    if ast.dump(ast.Module(body=check,type_ignores=[]),include_attributes=False)!=ast.dump(ast.Module(body=original.body[offset:],type_ignores=[]),include_attributes=False):raise ValueError('Undeclared tail change')
    native=ast.FunctionDef(name='_continue_native_loop',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n) for n in ['net','zones','base_metrics','result','start_iteration']],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),body=tail,decorator_list=[])
    compiled=ast.fix_missing_locations(ast.Module(body=[native],type_ignores=[]));env=reflection.__dict__.copy();env['runner']=runner;decisions=[]
    def choose(candidates,iteration):
        selected,entry=choose_candidate(candidates,iteration,runner.rescue.score_candidate,runner.action_signature);decisions.append(entry);return selected
    env['_native_alt_choice']=choose;exec(compile(compiled,'<native continuation: certified tail AST>','exec'),env)
    certificate={'source_sha256':expected_source_sha256,'original_tail_ast_sha256':sha_bytes(ast.dump(ast.Module(body=original.body[offset:],type_ignores=[]),include_attributes=False).encode()),'transformed_source_sha256':sha_bytes(ast.unparse(compiled).encode()),'only_tail_changes':['range starts at completed iteration']+(['existing root-only ALT choice'] if alt else []),'root_scenario_or_root_PF_not_in_compiled_body':True,'native_selection_preserved':True}
    return env['_continue_native_loop'],certificate,decisions

def validate_prefix(net,process,prefix,runner):
    validate(net,process)
    if process['phase']!='PRE_SELECTION':raise ValueError('Unsolved/software fixture is not a native continuation input')
    k=process['after_commit'];actions=prefix.get('executed_actions',[]);logs=prefix.get('logs',[])
    if len(actions)!=k or [a.get('iteration') for a in actions]!=list(range(1,k+1)):raise ValueError('Complete chronological action prefix required')
    if len(logs)!=k or [a.get('iteration') for a in logs]!=list(range(1,k+1)):raise ValueError('Pending/terminal/partial search is not a committed prefix')
    if prefix.get('stop_reason') is not None or prefix.get('base_converged') is not True:raise ValueError('Native prefix must be nonterminal and initially solved')
    if prefix.get('scenario_id')!=process['episode_identity']:raise ValueError('Episode/prefix mismatch')
    if k and canonical(runner.rescue.grid_metrics(net))!=canonical(actions[-1]['post_metrics']):raise ValueError('Current state does not match final committed prefix')
    base=prefix.get('base_metrics')
    if not isinstance(base,dict) or any(field not in base for field in ['uv_count','deficit_sum','vmin','vmax']):raise ValueError('Actual original root metrics required')
    if k==0 and canonical(runner.rescue.grid_metrics(net))!=canonical(base):raise ValueError('Root metrics mismatch')
    if int(prefix.get('counters',{}).get('fallback_tests',0))!=sum(int(l.get('fallback_tests',0)) for l in logs):raise ValueError('Original prefix candidate costs mismatch')
    if runner.MAX_ITERATIONS!=25 or not isinstance(process['zone_configuration'].get('zones'),dict):raise ValueError('Native loop/zone configuration mismatch')
    if runner.rescue.Q_SWEEP!=process['policy_configuration']['q_grid'] or runner.rescue.MAX_ABS_Q_PER_BUS!=450 or runner.rescue.V_MIN!=.95 or runner.rescue.V_MAX!=1.05 or runner.rescue.HARD_OV!=1.06 or runner.rescue.ANCHOR_BUSES!=[20,37,52,75,117]:raise ValueError('Effective native constants changed')
    if not re.fullmatch('[A-Za-z0-9_-]{1,96}',process['snapshot_id']):raise ValueError('Snapshot identity must be a bounded local name')
    return True

class NativePreservation:
    """Interpose observers only, retaining all paid test outcomes and full nets.

    Trial capsules are labelled UNCOMMITTED and carry no resume permission.
    Preserved solved caches are not certified future trajectories.
    """
    def __init__(self,pp,runner,zones,process,directory,journal):
        self.pp,self.runner,self.zones,self.process=pp,runner,copy.deepcopy(zones),copy.deepcopy(process)
        self.directory=Path(directory);self.journal=journal;self.active=None;self.decision=None;self.owner_frame=None;self.entered=False
        self.deadline=datetime.fromisoformat(process['absolute_deadline_utc'])
        owner=json.loads((self.directory/'owner.claim').read_text('utf8'))
        if owner.get('actual_pid')!=os.getpid() or owner.get('protocol_sha256')!=journal.previous:raise ValueError('Exclusive current-owner claim and journal protocol anchor required')
        self.costs={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'solver_seconds':0.0,'preservation_seconds':0.0,'trial_capsules':0,'commit_capsules':0,'candidate_attempts':0,'candidate_returns':0}
    def boundary(self):
        if datetime.now(timezone.utc)>=self.deadline:raise ResourceStop('Original absolute deadline reached; no new entry')
    def emit(self,event,payload):
        try:return self.journal.emit(event,payload)
        except Exception as exc:raise PreservationStop('Evidence journal failed; stop before further science') from exc
    def capsule(self,net,role,identity,*,solver_returned=True):
        started=time.perf_counter();path=self.directory/identity
        try:
            path.mkdir(exist_ok=False)
            data=pickle.dumps({'net':net,'python_random_state':random.getstate(),'numpy_random_state':np.random.get_state()},protocol=5)
            write_bytes(path/'trusted_local_net.pkl',data)
            status=('MEASURED_TRIAL_UNCOMMITTED_NO_EXECUTION_PERMISSION' if role=='trial' else 'ACTUAL_NATIVE_COMMIT_PF_RETURN') if solver_returned else ('FAILED_TRIAL_NO_SUCCESSOR_CLAIM' if role=='trial' else 'MUTATED_COMMIT_EXCEPTION_NO_SOLVED_CLAIM')
            manifest={'role':role,'status':status,'native_solver_returned':solver_returned,'net_converged_flag_recorded_not_an_exception_solve_certificate':bool(net.get('converged',False)),'parent_snapshot_id':self.decision['snapshot_id'],'process_after_commit':self.decision['after_commit'],'payload_sha256':sha_bytes(data),'payload_bytes':len(data),'source_sha256':self.process['source_sha256'],'runtime_identity':self.process['runtime_identity'],'not_a_counterfactual_reward':True}
            encoded=canonical(manifest);write_bytes(path/'manifest.json',encoded)
            item={'relative_directory':path.name,'payload_sha256':manifest['payload_sha256'],'manifest_sha256':sha_bytes(encoded),'payload_bytes':len(data),'solver_returned':solver_returned,'converged_flag':manifest['net_converged_flag_recorded_not_an_exception_solve_certificate']}
            self.costs[role+'_capsules']+=1;return item
        except Exception as exc:raise PreservationStop('Native solved-state preservation failed; no scientific retry') from exc
        finally:self.costs['preservation_seconds']+=time.perf_counter()-started
    def solve(self,*args,**kwargs):
        self.boundary();net=args[0] if args else kwargs['net'];role='trial' if self.active is not None else 'commit'
        identity=f"{role}_PF_{self.costs['PF_attempts']+1:06d}"
        options={key:value for key,value in kwargs.items() if key!='net'}
        if options!=self.process['solver_roles'][role]:raise PreservationStop('Effective trial/commit solver options changed before PF')
        self.emit('native_PF_entry_intent',{'identity':identity,'role':role,'decision':self.decision['next_iteration'],'effective_kwargs':options,'candidate_id':self.active['candidate_id'] if self.active else None})
        self.costs['PF_attempts']+=1
        started=time.perf_counter()
        try:
            answer=self.original_pf(*args,**kwargs)
        except Exception as exc:
            self.costs['PF_exceptions']+=1;self.costs['solver_seconds']+=time.perf_counter()-started
            snapshot=self.capsule(net,role,identity,solver_returned=False)
            if self.active is not None:self.active['solver_capsules'].append(snapshot)
            self.emit('native_PF_exception',{'identity':identity,'role':role,'exception':type(exc).__name__,'message':str(exc),'failed_state_snapshot':snapshot})
            raise
        self.costs['PF_returns']+=1;self.costs['solver_seconds']+=time.perf_counter()-started
        snapshot=self.capsule(net,role,identity)
        if self.active is not None:self.active['solver_capsules'].append(snapshot)
        self.emit('native_PF_return',{'identity':identity,'role':role,'snapshot':snapshot})
        return answer
    def verify(self,net,action):
        self.boundary()
        if self.active is not None or self.decision is None:raise PreservationStop('Concurrent/reentrant/unbound native verifier')
        self.costs['candidate_attempts']+=1
        active={'candidate_id':f"D{self.decision['next_iteration']:02d}_C{self.costs['candidate_attempts']:06d}",'parent_snapshot_id':self.decision['snapshot_id'],'action':copy.deepcopy(action),'solver_capsules':[]};self.active=active
        self.emit('native_candidate_attempt',active)
        try:
            answer=self.original_verify(net,action);self.costs['candidate_returns']+=1
            if len(active['solver_capsules'])>1:raise PreservationStop('Original verifier made unexpected multiple PF returns')
            self.emit('native_candidate_return',{**active,'verification':answer,'admitted_for_continuation':False})
            return answer
        finally:self.active=None
    def fallback(self,*args,**kwargs):
        self.boundary();bound=dict(zip(['net','zones','zone_reports','llm_actions','failed_sigs'],args));bound.update(kwargs)
        if bound['zones']!=self.zones or bound['llm_actions']!=[] or bound['failed_sigs']!=set():raise PreservationStop('Native DFF information/memory changed')
        frame=inspect.currentframe().f_back
        if frame.f_code.co_name!='_continue_native_loop' or frame.f_locals.get('net') is not bound['net']:raise PreservationStop('Recorder not bound to native continuation frame')
        k=frame.f_locals['it'];self.owner_frame=frame
        self.decision={**copy.deepcopy(self.process),'snapshot_id':f"{self.process['snapshot_id']}_BEFORE_{k+1:02d}",'after_commit':k,'next_iteration':k+1,'remaining_slots':25-k,'continuation_mode':'ROOT_DFF_ALT' if self.process['continuation_mode']=='ROOT_DFF_ALT' and k==0 else 'ORDINARY_DFF','cost_counters':{key:int(self.process['cost_counters'].get(key,0))+self.costs[key] for key in ['PF_attempts','PF_returns','PF_exceptions']}}
        started=time.perf_counter()
        try:
            snapshot=capture(self.directory/self.decision['snapshot_id'],bound['net'],self.decision)
            prefix=copy.deepcopy(frame.f_locals['result']);prefix['counters']=dict(prefix['counters'])
            data=canonical(prefix);write_bytes(self.directory/self.decision['snapshot_id']/'native_prefix_result.json',data)
            self.emit('native_preselection_snapshot',{'process':self.decision,'anchors':snapshot,'prefix_sha256':sha_bytes(data),'native_cap_accounting':'ALL_ABS_Q_NAMED_LLM_SHUNTS_INCLUDING_INACTIVE'})
        except Exception as exc:raise PreservationStop('Pre-selection capture failed before new candidate physics') from exc
        finally:self.costs['preservation_seconds']+=time.perf_counter()-started
        answer=self.original_fallback(*args,**kwargs)
        self.emit('native_search_return',{'decision':k+1,'ordered_candidates':answer,'exact_native_scores':[self.runner.rescue.score_candidate(c) for c in answer]})
        return answer
    def __enter__(self):
        if self.entered or hasattr(self.runner,'_native_preservation_owner'):raise ValueError('Refuse duplicate observer/writer')
        self.boundary();self.original_pf=self.pp.runpp;self.original_verify=self.runner.rescue.verify_action;self.original_fallback=self.runner.fallback_physics_candidates
        self.runner._native_preservation_owner=os.getpid();self.pp.runpp=self.solve;self.runner.rescue.verify_action=self.verify;self.runner.fallback_physics_candidates=self.fallback;self.entered=True
        return self
    def __exit__(self,*exc):
        self.pp.runpp=self.original_pf;self.runner.rescue.verify_action=self.original_verify;self.runner.fallback_physics_candidates=self.original_fallback
        del self.runner._native_preservation_owner;self.entered=False;self.owner_frame=None

def prepare_continuation(reflection,runner,net,process,prefix,expected_source_sha256):
    """Return a bound native tail and proof. This function does not execute it."""
    validate_prefix(net,process,prefix,runner)
    if process['source_sha256'].get(str(Path(reflection.__file__).resolve()))!=expected_source_sha256:raise ValueError('Actual native source not pinned in process')
    if process['zone_configuration'].get('order')!=sorted(process['zone_configuration']['zones']):raise ValueError('Exact sorted native zone order required')
    loop,certificate,decisions=derive_continuation(reflection,runner,expected_source_sha256,alt=process['continuation_mode']=='ROOT_DFF_ALT')
    result=copy.deepcopy(prefix);result['counters']=Counter(result.get('counters',{}));result['final_metrics']=None
    def execute_with_already_owned_recorder():
        if not hasattr(runner,'_native_preservation_owner'):raise ValueError('Actual owner, recorder and frozen science contract required before execution')
        if runner._native_preservation_owner!=os.getpid():raise ValueError('Recorder belongs to another owner')
        returned=loop(net,process['zone_configuration']['zones'],result['base_metrics'],result,process['after_commit'])
        if process['continuation_mode']=='ROOT_DFF_ALT':returned['dff_alt_decisions']=copy.deepcopy(decisions)
        return returned
    return execute_with_already_owned_recorder,certificate
