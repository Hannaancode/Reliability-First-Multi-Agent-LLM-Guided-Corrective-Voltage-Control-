"""Check whether the exact released assignment still exposes original files; GET only."""
from pathlib import Path
from datetime import datetime,timezone
import json,logging,os,uuid
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from google_account_profile import verify_account
logging.disable(logging.CRITICAL)
out=Path('outputs');restore=json.loads((out/'colab_frozen_restore_status.json').read_text())
assert restore['created_by_this_task'] and restore['verified_google_account']=='sheenahammed@gmail.com'
os.environ['HIERGRID_EXPECTED_GOOGLE_ACCOUNT']=restore['verified_google_account']
proof={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'notebook_hash':restore['notebook_hash'],'runtime_allocated':False,'get_only':True}
session=None
try:
    credentials=Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud-hiergrid-sheenah\application_default_credentials.json');credentials.refresh(Request())
    session=AuthorizedSession(credentials);assert verify_account(session)==restore['verified_google_account']
    client=Client(Prod(),session)
    assignment=client._get_assignment(uuid.UUID(restore['notebook_hash']),variant=Variant.GPU,accelerator=Accelerator.T4)
    proof['original_files_accessible_through_existing_assignment']=hasattr(assignment,'runtime_proxy_info')
    proof['response_type']=type(assignment).__name__
except Exception as exc:
    proof['failure_type']=type(exc).__name__
    response=getattr(exc,'response',None)
    if response is not None:proof['failure_http_status']=response.status_code
finally:
    if session is not None:session.close()
folder=out/'runtime_health_checks';folder.mkdir(exist_ok=True)
(folder/(datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_released_assignment')+'.json')).write_text(json.dumps(proof,indent=2))
print(json.dumps(proof,indent=2))
