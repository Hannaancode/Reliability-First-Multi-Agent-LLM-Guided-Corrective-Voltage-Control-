"""Hash source/input bytes once while Windows handles deny write and delete.

The exact existing certificate function runs with only its source-pin service
bound to this verified, still-open immutable snapshot. All physical/input/
verdict/score/cost statements and saved-result checks are unchanged.
"""
import ast,ctypes,hashlib,importlib.metadata,json,msvcrt,os
from pathlib import Path
from types import SimpleNamespace
import certify_archived_receipt_on_use_v1_20261018 as original
R=Path(__file__).resolve().parents[1]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
class LockedSourceSnapshot:
    def __init__(self,protocol_path):
        self.files={};self.closed=False
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        self.open_file=kernel.CreateFileW;self.open_file.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p];self.open_file.restype=ctypes.c_void_p
        try:
            handle=self._lock(Path(protocol_path));raw=handle.read();handle.seek(0)
            self.protocol=json.loads(raw);self.protocol_sha256=digest(raw)
            self.pins={}
            for relative,expected in self.protocol['source_input_sha256'].items():
                path=(R/relative).resolve();f=self._lock(path);h=hashlib.sha256()
                while b:=f.read(1024**2):h.update(b)
                f.seek(0);assert h.hexdigest()==expected,relative;self.pins[relative]=expected
            assert {n:importlib.metadata.version(n) for n in self.protocol['runtime_versions']}==self.protocol['runtime_versions']
        except BaseException:self.close();raise
    def _lock(self,path):
        path=Path(path).resolve();assert path.is_relative_to(R)
        if str(path) in self.files:return self.files[str(path)]
        # GENERIC_READ, FILE_SHARE_READ only, OPEN_EXISTING. An existing
        # writer or subsequent writer/deleter is a genuine failure, not retried.
        handle=self.open_file(str(path),0x80000000,0x00000001,None,3,0x80,None)
        if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
        fd=msvcrt.open_osfhandle(int(handle),os.O_RDONLY|os.O_BINARY)
        stream=os.fdopen(fd,'rb');self.files[str(path)]=stream;return stream
    def verify(self,p):
        assert not self.closed and all(not f.closed for f in self.files.values())
        assert p==self.protocol,'A different protocol cannot borrow source locks'
    def anchor(self):
        self.verify(self.protocol)
        return {'protocol_sha256':self.protocol_sha256,'source_input_sha256':self.pins,
            'runtime_versions':self.protocol['runtime_versions'],'mode':'WINDOWS_READ_HANDLE_DENIES_WRITE_AND_DELETE_UNTIL_CLOSE',
            'not_scientific_execution_permission':True}
    def close(self):
        for f in self.files.values():f.close()
        self.closed=True

class LockedReceiptVerifier:
    def __init__(self):
        self.snapshot=LockedSourceSnapshot(R/'outputs/full_receding_paid_campaign_20261015/Protocol.json')
        # Keep actual certificate and native reader source bytes immutable too.
        for path in [Path(original.__file__),Path(original.source_reader.__file__),Path(__file__)]:
            f=self.snapshot._lock(path);h=hashlib.sha256(f.read()).hexdigest();f.seek(0)
            self.snapshot.pins[str(path.relative_to(R))]=h
        proxy=SimpleNamespace(read=original.source_reader.read,check_query=original.source_reader.check_query,
            pin=self.snapshot.verify,__file__=original.source_reader.__file__)
        functions=[n for n in ast.parse(Path(original.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='certify']
        env=original.__dict__.copy();env['source_reader']=proxy
        exec(compile(ast.Module(body=functions,type_ignores=[]),str(Path(original.__file__)),'exec'),env)
        self.certify=env['certify']
    def anchor(self):return self.snapshot.anchor()
    def close(self):self.snapshot.close()
SOURCE_CERTIFICATE={'certificate_function_AST_exact':True,'native_check_query_unchanged':True,
    'only_dependency_binding':'pin(p) validates exact already-hashed protocol under continuously open OS handles denying writes/deletes.',
    'scope_source_input_native_guard_score_cost_not_relaxed':True,'new_scientific_calls':0}
