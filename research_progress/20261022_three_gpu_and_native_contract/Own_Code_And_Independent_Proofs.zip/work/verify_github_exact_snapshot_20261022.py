"""Verify an expected publication's leased head/tree and exact downloaded bytes."""
import argparse,base64,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
from verify_two_query_github_publication_20261018 import R,get

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--snapshot',required=True);args=ap.parse_args()
    p=(R/args.snapshot).resolve();assert p.is_relative_to(R)
    expected=json.loads((p/'Expected_Remote_Files.json').read_text('utf-8'))
    head=get('/git/ref/heads/research-progress-20261018')['object']['sha'];assert head==expected['head']
    commit=get('/git/commits/'+head);assert commit['tree']['sha']==expected['tree']
    assert [x['sha'] for x in commit['parents']]==[expected['previous_head']]
    tree=get('/git/trees/'+expected['tree']+'?recursive=1');assert not tree['truncated']
    entries={x['path']:x for x in tree['tree']};rows=[]
    for f in expected['files']:
        local=(R/f['local']).read_bytes();digest=hashlib.sha256(local).hexdigest()
        blob=hashlib.sha1(b'blob '+str(len(local)).encode()+b'\0'+local).hexdigest()
        assert len(local)==f['bytes'] and digest==f['sha256'] and blob==f['blob']==entries[f['path']]['sha']
        fetched=get('/git/blobs/'+blob);assert fetched['encoding']=='base64'
        raw=base64.b64decode(fetched['content']);assert raw==local and len(raw)==entries[f['path']]['size']
        rows.append({'path':f['path'],'bytes':len(raw),'sha256':digest,'blob':blob,'remote_bytes_equal_local':True})
    receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_LEASED_HEAD_TREE_ALL_EXPECTED_EXACT_DOWNLOADED_BYTES',
        'head':head,'tree':expected['tree'],'previous_head':expected['previous_head'],'files':rows,
        'verified_downloaded_files':len(rows),'no_complete_private_raw_backup_claim':True,
        'verifier_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with (p/'Verified_GitHub_Receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)
    print(json.dumps({'GitHub':'PASS','head':head,'exact_downloaded_files':len(rows)}))

if __name__=='__main__':main()
