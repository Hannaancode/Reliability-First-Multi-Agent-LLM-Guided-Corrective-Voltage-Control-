"""Additive THREE-query transport: unchanged reservation and physical predicates.

Original sources are never edited. Arity/phase routing and receipt namespace
are the only transformations of the existing execution components.
"""
import ast,copy,hashlib,json,pickle,random,time,traceback
from pathlib import Path
import numpy as np
import exact_two_paid_query_engineering_20261018 as old
import exact_new_query_reservations_v1_20261018 as reservation_source
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/remaining_three_fixed_queries_20261019'
I=old.I;PYTHON=old.PYTHON;PHASES=('warm','cold_1','cold_2')

def transform(text,edits):
    result=text
    for before,after in edits:
        assert result.count(before)==1,(before,result.count(before));result=result.replace(before,after)
    inverse=result
    for before,after in reversed(edits):assert inverse.count(after)==1;inverse=inverse.replace(after,before)
    assert inverse==text
    return result

rsrc=Path(reservation_source.__file__).read_text('utf-8')
redits=[('assert len(rows)==len(self.allowed)==2','assert len(rows)==len(self.allowed)==3')]
rtree=ast.parse(transform(rsrc,redits));rclass=next(n for n in rtree.body if isinstance(n,ast.ClassDef) and n.name=='Reservations')
renv=reservation_source.__dict__.copy();exec(compile(ast.Module(body=[rclass],type_ignores=[]),str(__file__),'exec'),renv)
Reservations=renv['Reservations']

def ack_name(index):return ('Warm_State_ACK.json','cold_1_State_ACK.json','Final_State_ACK.json')[index]
def known_keys():
    keys=old.known_keys();past=read(I/'Exact_Candidate_Inputs.json')
    return set(keys)|{v['point_action_key'] for v in past['exact_new_query_rows']}

def helpers(entrypoint):
    text=Path(old.__file__).read_text('utf-8');tree=ast.parse(text)
    nodes=[copy.deepcopy(n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name not in ('worker','coordinator','known_keys')]
    env=old.__dict__.copy();env.update(B=B,I=I,__file__=str(entrypoint),Reservations=Reservations,known_keys=known_keys)
    # Keep the actual caller path in the exact claim function: no imported
    # worker __file__ in a reader claim, the previous failure is preserved.
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(old.__file__),'exec'),env)
    execute=ast.unparse(next(n for n in nodes if n.name=='execute_one'))
    execute=transform(execute,[("f'exact_two_query_{index + 1}'","f'exact_three_fixed_query_{index + 1}'")])
    exec(compile(execute,str(__file__),'exec'),env)
    return env

WORKER_EDITS=[
    ("p=read(B/'Protocol.json');out=B/mode;claim(out,p);start=time.perf_counter();e=None;snapshot=None;reservations=history=None;code=1",
     "p=read(B/'Protocol.json');phase_index=PHASES.index(mode);out=B/mode;claim(out,p);start=time.perf_counter();e=None;snapshot=None;reservations=history=None;code=1"),
    ("'PASS_FIXED_TWO_QUERY_PRELAUNCH_ZERO_SCIENCE'","'PASS_FIXED_THREE_QUERY_PRELAUNCH_ZERO_SCIENCE'"),
    ("state=restore_state(read(B/'Warm_State_ACK.json'));assert state['next_index']==1", "state=restore_state(read(B/ack_name(phase_index-1)));assert state['next_index']==phase_index"),
    ("assert p['exact_new_query_rows'][1]['point_action_key'] not in reservations.states", "assert p['exact_new_query_rows'][phase_index]['point_action_key'] not in reservations.states"),
    ("records=verify_history(state['history_anchor']);assert len(records)==1 and records[0]['payload']==state['paid_query_registry'][p['exact_new_query_rows'][0]['point_action_key']]",
     "records=verify_history(state['history_anchor']);assert len(records)==phase_index and all(records[j]['payload']==state['paid_query_registry'][p['exact_new_query_rows'][j]['point_action_key']] for j in range(phase_index))"),
    ("if mode=='cold':e.serial", "if mode!='warm':e.serial"),
    ("if mode=='cold':state['closed_prefix_files']+=restore_state(read(B/'Warm_State_ACK.json'))['closed_prefix_files']",
     "if mode!='warm':state['closed_prefix_files']+=restore_state(read(B/ack_name(phase_index-1)))['closed_prefix_files']"),
    ("put(B/('Warm_State_ACK.json' if mode=='warm' else 'Final_State_ACK.json'),ack)","put(B/ack_name(phase_index),ack)")
]

def bound_worker(entrypoint):
    source=Path(old.__file__).read_text('utf-8');tree=ast.parse(source);n=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worker')
    start=n.lineno-1;stop=n.end_lineno;function='\n'.join(source.splitlines()[start:stop])
    changed=transform(function,WORKER_EDITS);env=helpers(entrypoint);env.update(PHASES=PHASES,ack_name=ack_name)
    exec(compile(changed,str(__file__),'exec'),env);return env['worker']

def fixture_phase(entrypoint,phase):
    env=helpers(entrypoint);p=read(B/'Protocol.json');out=B/('fixture_'+phase);env['claim'](out,p)
    snapshot=old.LockedSourceSnapshot(B/'Protocol.json');r=h=None;index=PHASES.index(phase)
    try:
        _,runner,_=old.load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
        coverage=dict(read(B/'Attempt_Coverage_Certificate.json'),mode='SOFTWARE_FIXTURE_NO_PF')
        if index==0:
            state=env['input_state']();random.seed(p['seed']);np.random.seed(p['seed'])
            r=Reservations(B/'fixture_reservations',protocol=p,coverage=coverage,known_attempt_keys=known_keys(),runner=runner,zones=zones)
            h=old.History(B/'fixture_history',source_anchor=sha(B/'Protocol.json'),input_anchor=p['input_state_sha256'],max_bytes=1024**2)
            state.update(paid_query_registry={},next_index=0,absolute_deadline_utc=p['absolute_deadline_utc'],protocol_sha256=sha(B/'Protocol.json'))
        else:
            state=env['restore_state'](read(B/f'Fixture_State_ACK_{index-1}.json'));original=env['input_state']();old.require_same(state['net'],original['net']);assert state['cursor']==original['cursor']
            assert state['next_index']==index and state['absolute_deadline_utc']==p['absolute_deadline_utc'] and state['protocol_sha256']==sha(B/'Protocol.json')
            r=Reservations(B/'fixture_reservations',protocol=p,coverage=coverage,known_attempt_keys=known_keys(),runner=runner,zones=zones,restore_anchor=state['reservation_anchor'])
            h=old.reopen_latest_history(state['history_anchor']);assert len(old.verify_history(state['history_anchor']))==index
            random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
            assert pickle.dumps(random.getstate(),5)==pickle.dumps(state['python_rng'],5) and pickle.dumps(np.random.get_state(),5)==pickle.dumps(state['numpy_rng'],5)
            prior=p['exact_new_query_rows'][index-1]
            try:r.reserve(state['net'],state['cursor'],prior['row'],role=prior['role'])
            except reservation_source.AlreadyAttemptedIdentity:pass
            else:raise AssertionError('Cold duplicate cannot pass')
        item=p['exact_new_query_rows'][index];key=r.reserve(state['net'],state['cursor'],item['row'],role=item['role'])
        r.start(key,PF_id='SOFTWARE_ONLY_'+str(index),solver_kwargs=p['solver_kwargs'],software_fixture=True);r.closed(key,{'PF_id':'SOFTWARE_ONLY_'+str(index),'outcome':'SOFTWARE_NO_PF'})
        state['paid_query_registry'][key]={'software_only':True};h.append('software_boundary',{'key':key,'no_physics':True})
        state.update(reservation_anchor=r.anchor(),history_anchor=h.anchor(),next_index=index+1,python_rng=random.getstate(),numpy_rng=np.random.get_state())
        r.close();r=None;h.close();h=None
        put(B/f'Fixture_State_ACK_{index}.json',env['save_state'](out/'Fixture_State.zlib',state))
        put(out/'Result.json',{'status':'PASS_THREE_IDENTITY_WARM_COLD_SOFTWARE_BOUNDARY','index':index,'scientific_calls':0,'actual_source_claim_correct':True})
    finally:
        if r:r.close()
        if h:h.close()
        snapshot.close();manifest(out)

def certificate():
    # Constructing worker verifies every inverse substitution before launch.
    bound_worker(Path(__file__))
    return {'reservation_source_sha256':sha(reservation_source.__file__),'reservation_change':redits,'reservation_inverse_exact':True,
        'worker_original_sha256':sha(old.__file__),'worker_inverse_transform_exact':True,'worker_changes':WORKER_EDITS,
        'execute_one_only_receipt_namespace_changed':True,'all_native_solver_verifier_action_scope_Q_cap_stock_score_predicates_unchanged':True,
        'claim_entrypoint_bound_explicitly_not_imported_worker_path':True}
