"""Independent static source/data reader; no policy, environment or PF execution."""
import io,json,pickle,hashlib,ast,math
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import networkx as nx
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/mapdn_native_contract_v2_20261020'
class Restricted(pickle.Unpickler):
    def find_class(self,module,name):
        if (module,name)==('numpy','dtype'):return np.dtype
        raise ValueError('Unapproved global')
def same(a,b):
    if isinstance(a,np.dtype):return b['symbolic_numpy_dtype']==a.str.lstrip('<>=|') or np.dtype(b['symbolic_numpy_dtype'])==a
    if type(a) is dict:return set(a)==set(b) and all(same(v,b[k]) for k,v in a.items())
    if isinstance(a,(tuple,list)):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    if isinstance(a,float) and math.isnan(a):return isinstance(b,float) and math.isnan(b)
    return a==b
def main():
    audit=OUT/'independent_audit';audit.mkdir(exist_ok=False)
    results=json.loads((OUT/'Results.json').read_text(encoding='utf-8'));rows=[]
    for r in results['networks']:
        source=ROOT/'outputs/benchmark_priority_20261020/MAPDN/static_network_objects'/(r['network']+'.p')
        raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['input_sha256']
        original=Restricted(io.BytesIO(raw)).load()
        native=json.loads((OUT/(r['network']+'_native_input_tables.json')).read_text(encoding='utf-8'))
        for name,records in native.items():
            frame=original[name]['DF'];assert len(records)==len(frame['data'])==r['counts'][name]
            for index,values,record in zip(frame['index'],frame['data'],records):
                assert same(dict(zip(frame['columns'],values),index=index),record)
        graph=nx.Graph();graph.add_nodes_from(x['index'] for x in native['bus'])
        graph.add_edges_from((x['from_bus'],x['to_bus']) for x in native['line'] if x['in_service'])
        graph.add_edges_from((x['hv_bus'],x['lv_bus']) for x in native['trafo'] if x['in_service'])
        assert nx.is_tree(graph) and set(graph.nodes)==set(nx.node_connected_component(graph,r['slack_buses'][0]))
        assert all(x['name']==next(b['zone'] for b in native['bus'] if b['index']==x['bus']) for x in native['sgen'])
        rows.append({'network':r['network'],'tables_all_cells_exact':True,'all_native_branches_connected_tree':True,'PV_name_matches_bus_zone':True,'counts':r['counts']})
    proof=json.loads((OUT/'All_Author_Source_Proof.json').read_text(encoding='utf-8'));parsed=0
    for f in proof['files']:
        p=OUT/'author_code'/f['path'];b=p.read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['git_blob']
        if p.suffix=='.py':ast.parse(b);parsed+=1
    headers=json.loads((OUT/'timeseries_headers/Results.json').read_text(encoding='utf-8'))
    assert len(headers['files'])==9 and all(r['value_columns']==r['native_device_count'] and r['initial_sampling_interval_seconds']==180 for r in headers['files'])
    final={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL3_STATIC_NATIVE_INPUTS_ALL71_SOURCE_BLOBS_AND9_HEADER_CONTRACTS','networks':rows,'author_files':len(proof['files']),'author_python_files_AST_parsed':parsed,'new_PF_model_optimizer_solver_calls':0,'scope':'Independent restricted dtype-only deserialization and every-cell comparison; graph via networkx independently from data interpreter. Headers checked against saved intake; range network transfer not repeated.','limitations':['Source/schema/structural results, not operating point feasibility or model performance.','All9 complete CSV CRCs/coverage and a common causal serving/split contract remain pending.','Native paper results and current source reproduction remain distinct; no automatic training launch.']}
    (audit/'Independent_Audit.json').write_text(json.dumps(final,indent=2),encoding='utf-8');print(json.dumps({'status':final['status'],'python_AST_files':parsed,'science_calls':0}))
if __name__=='__main__':main()
