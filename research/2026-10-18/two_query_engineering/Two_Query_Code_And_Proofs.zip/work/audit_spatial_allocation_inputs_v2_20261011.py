"""Independent outcome-free input reader, using direct table transformations."""
import copy,hashlib,json,os,pickle,time,sys
from datetime import datetime,timezone
from pathlib import Path
import pandas as pd
import pandapower as pp
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010'
PREP=BASE/'spatial_allocation_input_preparation_v2_20261011'
OUT=BASE/'spatial_allocation_input_audit_v2_20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):
    with (OUT/name).open('x',encoding='utf8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def signature(net):
    hashes={}
    for name in sorted(net):
        table=net[name]
        if isinstance(table,pd.DataFrame) and not name.startswith('res_'):
            hashes[name]=hashlib.sha256(pickle.dumps(table,protocol=5)).hexdigest()
    return hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest(),hashes
def independent_apply(net,mods,zones):
    ans=copy.deepcopy(net)
    for m in mods:
        a=m['action']
        if a=='scale_all_loads':ans.load['scaling']=ans.load['scaling'].astype(float)*float(m['factor'])
        elif a=='scale_loads_by_zone':
            for i in ans.load.index:
                if int(ans.load.at[i,'bus']) in set(zones[m['zone']]):ans.load.at[i,'scaling']=float(ans.load.at[i,'scaling'])*float(m['factor'])
        elif a=='open_line':
            if int(m['line_idx']) in ans.line.index:ans.line.at[int(m['line_idx']),'in_service']=False
        elif a=='drop_sgen_indices':
            for i in m.get('sgen_indices',[]):
                if int(i) in ans.sgen.index:ans.sgen.at[int(i),'p_mw']=0.0
        elif a=='drop_all_sgens':
            if len(ans.sgen):ans.sgen['p_mw']=0.0
        elif a=='metadata_only_fault_event':pass
        else:raise ValueError('Unknown input grammar cannot be silently interpreted')
    return ans
def main():
    OUT.mkdir(exist_ok=False);start=time.perf_counter()
    write('owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'command':sys.argv,'source_sha256':sha(Path(__file__))})
    proto=json.loads((PREP/'Input_Closure.json').read_text('utf8'))
    assert proto['status']=='INPUT_CLOSURE_PASS_REQUIRES_INDEPENDENT_READER'
    for p,h in proto['source_sha256'].items():assert sha(ROOT/p)==h,p
    old=BASE/'spatial_allocation_input_preparation_20261011/Input_Closure.json'
    assert sha(old)==proto['previous_preparation_sha256']
    oldresult=json.loads(old.read_text('utf8'))
    assert oldresult['status']=='INPUT_PREPARATION_STOP_NO_REPLACEMENT'
    assert {r['root'] for r in oldresult['fixed_roots'] if r['recorded_effective_input_overlaps']}=={'S1','S2'}
    network=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json';metadata=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
    assert sha(network)==proto['network_sha256'] and sha(metadata)==proto['metadata_sha256']
    attempted=[]
    def refuse(*a,**k):attempted.append(True);raise AssertionError('Independent reader cannot solve')
    original={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph')}
    for n in original:setattr(pp,n,refuse)
    try:
        net=pp.from_json(str(network));zones=json.loads(metadata.read_text('utf8'))['zones'];initial,_=signature(net)
        known={};applications=0
        for c in proto['catalog_rows']:
            p=ROOT/c['path'];assert sha(p)==c['sha256']
            if 'effective_input_signature' not in c:continue
            s=json.loads(p.read_text('utf8'));h,_=signature(independent_apply(net,s.get('modifications',[]),zones));applications+=1
            assert h==c['effective_input_signature'],c['path']
            known.setdefault(h,[]).append(c['path'])
        rows=[];root_hashes=[]
        assert len(proto['fixed_roots'])==8 and len({r['root'] for r in proto['fixed_roots']})==8
        for r in proto['fixed_roots']:
            p=PREP/(r['root']+'.json');assert sha(p)==r['scenario_sha256'];s=json.loads(p.read_text('utf8'))
            if r['root'] in ('S1','S2'):
                pair=('MG1','MG2') if r['root']=='S1' else ('MG3','MG4')
                buses={int(b) for z in pair for b in zones[z]}
                indices=sorted(int(i) for i in net.sgen.index if int(net.sgen.at[i,'bus']) in buses)
                assert s['modifications']==[{'action':'drop_sgen_indices','sgen_indices':indices}]
            elif r['root'] in ('L1','L2'):
                assert s['modifications']==[{'action':'scale_all_loads','factor':1.387241 if r['root']=='L1' else 1.473619}]
            elif r['root'] in ('T1','T2'):
                pair=(101,103) if r['root']=='T1' else (127,135)
                assert all(i in net.line.index and bool(net.line.at[i,'in_service']) for i in pair)
                assert s['modifications']==[{'action':'open_line','line_idx':i} for i in pair]
            else:
                assert r['root'] in ('C1','C2')
                factor,line=(1.417263,101) if r['root']=='C1' else (1.463927,129)
                assert s['modifications']==[{'action':'scale_all_loads','factor':factor},{'action':'open_line','line_idx':line}]
            effective=independent_apply(net,s['modifications'],zones);h,tables=signature(effective);applications+=1
            assert h==r['effective_input_signature'] and tables==r['table_sha256']
            assert h!=initial and not known.get(h) and not r['invalid'] and not r['recorded_effective_input_overlaps']
            root_hashes.append(h);rows.append({'root':r['root'],'non_result_tables_exact':len(tables),'effective_change':True,'recorded_catalog_overlap':False})
        assert len(set(root_hashes))==8 and not attempted
        result={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS',
          'actual_reader_pid':os.getpid(),'input_closure_sha256':sha(PREP/'Input_Closure.json'),
          'reader_source_sha256':sha(Path(__file__)),'verified_roots':rows,'eight_effective_inputs_distinct':True,
          'exact_source_network_metadata_scenario_hashes':True,'catalog_recomputed_independently':len(known),
          'catalog_files':proto['catalog_files'],'old_duplicate_preparation_retained':True,
          'physical_outcomes_inspected':0,'actual_PF_model_optimizer_forecast_controller_calls':0,
          'pure_network_decodes':1,'pure_table_transformations':applications,
          'actual_seconds':time.perf_counter()-start,'new_performance_or_GPU_job_ready':False,
          'limitations':['Excludes only the named retained catalog, not every historical state.','Historical-development design; not unused confirmation.','Actual native query/commit/cold following/full episode integration remains untested.','No measured sequence opportunity, novelty or90percent winnerconfidence.']}
        write('Independent_Input_Audit.json',result)
        print(json.dumps({'status':'PASS','roots':8,'catalog_files':proto['catalog_files'],'PF_model_calls':0,'new_performance_job_ready':False}))
    finally:
        for n,f in original.items():setattr(pp,n,f)
if __name__=='__main__':main()
