"""Preserved, source-native DFF continuation. No controller/math changes.

Existing exact returned inputs are memoized; failed inputs are never solved
again. A retained-history collision without a recoverable same-contract result
stops the study before entry. This module does not supply candidate actions.
"""
import copy, hashlib, json, os, pickle, random, sys, time, zlib
from collections import defaultdict
from reflection118_chronological_core_20261022 import *

P = R/'outputs/r118_dff_missing_continuation_preparation_20261023'
E = R/'outputs/r118_dff_missing_continuation_execution_20261023'
A = R/'outputs/r118_dff_missing_continuation_independent_20261023'

class OperationalStop(BaseException): pass
class PaidBoundary(BaseException): pass

def net_value(value):
    return value['net'] if isinstance(value, dict) and 'net' in value else value

def saved_net(directory, descriptor):
    return net_value(decode(directory, descriptor))

def setup():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np, pandapower as pp
    from frozen_physics_loader import load_stack, AUDIT
    v2, runner, reflection = load_stack()
    assert all(a['all_function_asts_unchanged'] for a in AUDIT)
    return np, pp, v2, runner, reflection

def validate_pins(protocol):
    for name, digest in protocol['source_hashes'].items(): assert sha(R/name) == digest, name
    for name, digest in protocol['input_hashes'].items(): assert sha(R/name) == digest, name

def source_run(v2, runner, reflection, scenario, base, zones, provider, on_commit):
    """Call the original whole function, tracing only its commitment boundary."""
    import numpy as np, pandapower as pp
    target = reflection.run_one_scenario_no_llm_fallback_first
    oldpf, oldtrace = pp.runpp, sys.gettrace()
    seen = 0
    def trace(frame, event, arg):
        nonlocal seen
        if frame.f_code is not target.__code__: return None
        if event == 'line':
            loc = frame.f_locals; result = loc.get('result')
            count = len(result.get('executed_actions', [])) if result else 0
            if count > seen:
                assert count == seen + 1; seen = count
                state = copy.deepcopy({k:loc[k] for k in ['net','result','failed_sigs','it'] if k in loc})
                state['python_rng'] = random.getstate(); state['numpy_rng'] = np.random.get_state()
                on_commit(state)
        return trace
    pp.runpp = provider
    try:
        sys.settrace(trace)
        return target(scenario, base, zones, v2)
    finally:
        pp.runpp = oldpf; sys.settrace(oldtrace)

def current_receipts():
    """Named current complete/failed/unentered scope, with raw capsules retained."""
    receipts = []; covered = set()
    def add(directory, source, row, kwargs, failed=None):
        if 'before' not in row: return
        covered.add((directory/row['before']['path']).resolve())
        receipts.append(dict(directory=directory, source=source.relative_to(R).as_posix(),
            source_sha256=sha(source), before=row['before'], after=row.get('after'), kwargs=kwargs,
            exception=row.get('exception',failed)))
    d=R/'outputs/r118chrono_20261022/local_controller'
    for f in sorted(d.glob('*/*/pf_*.json')):
        row=read(f);add(f.parent,f,row,row['kwargs'])
    d=R/'outputs/r118_first_round_missing_only_execution_20261022'
    for row in read(d/'Result.json')['rows']:
        if 'before' in row: add(d,d/f"record_{row['identity']:04d}.json",row,row['solver_kwargs'])
    for name,prep in [('r118_solver_contract_bridge_execution_20261022','r118_solver_contract_bridge_preparation_20261022'),
                      ('r118_remaining_native80_contracts_execution_20261022','r118_remaining_native80_contracts_preparation_20261022'),
                      ('published_graph118_first_queries_execution_20261022','published_graph118_first_queries_preparation_20261022')]:
        d=R/'outputs'/name; proto=read(R/'outputs'/prep/'Protocol.json')
        kw=proto.get('solver_kwargs',proto.get('new_native_kwargs'))
        assert isinstance(kw,dict),name+' must have an explicit source solver contract'
        if (d/'Result.json').exists(): add(d,d/'Result.json',read(d/'Result.json'),kw)
        else:
            for i,row in enumerate(read(d/'Results.json')['rows']): add(d,d/f'query_{i:02d}.json',row,kw)
    # Some old controller exceptions ended before a per-call JSON was written.
    # Such raw reservations are blockers, never silently classified unexecuted.
    for f in sorted((R/'outputs/r118chrono_20261022/local_controller').glob('*/*/pf_*_before.zlib')):
        if f.resolve() in covered: continue
        raw=f.read_bytes();value=zlib.decompress(raw)
        desc=dict(path=f.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),decoded_bytes=len(value),decoded_sha256=hashlib.sha256(value).hexdigest())
        receipts.append(dict(directory=f.parent,source=f.relative_to(R).as_posix(),source_sha256=sha(f),before=desc,after=None,kwargs=None,exception='UNRECOVERED_OLD_ATTEMPT_OR_RESERVATION'))
    return receipts

class Registry:
    def __init__(self, receipts, include_history=True):
        from prior_physical_query_footprints_20261018 import component
        from run_reflection118_chronological_local_20261022 import necessary, History
        self.component, self.necessary = component, necessary
        self.items=defaultdict(list);self.decoded={};self.count=len(receipts)
        self.history=History() if include_history else None
        for item in receipts:
            before=saved_net(item['directory'],item['before'])
            key=self.key(before);self.items[key].append(item)
    def key(self,net):
        return self.component(net)[0]+':'+hashlib.sha256(canonical(self.necessary(net))).hexdigest()
    def lookup(self,net,kwargs):
        candidates=self.items.get(self.key(net),[]);exact=[];mismatched=[]
        for item in candidates:
            before=saved_net(item['directory'],item['before'])
            try:frames_equal(net,before)
            except (AssertionError,KeyError,ValueError):mismatched.append(item['source']);continue
            exact.append(item)
        successful=[r for r in exact if r['kwargs']==kwargs and r['after'] is not None and r['exception'] is None]
        if successful:
            item=successful[0]
            return saved_net(item['directory'],item['after']),None,dict(kind='PAID_EXACT_RETURN_REUSE',source=item['source'],source_sha256=item['source_sha256'],same_input_returns=len(successful),other_same_input_attempts=len(exact)-len(successful))
        failed=[r for r in exact if r['kwargs']==kwargs and r['after'] is not None and r['exception'] is not None]
        if failed:
            item=failed[0]
            return saved_net(item['directory'],item['after']),item['exception'],dict(kind='PAID_FAILED_INPUT_NO_RETRY',source=item['source'],source_sha256=item['source_sha256'])
        if exact: raise OperationalStop('PRIOR_EXACT_INPUT_WITH_UNRECOVERED_OR_OTHER_CONTRACT_NO_CALL: '+str([r['source'] for r in exact]))
        # Equal aggregate shunt and load with different bookkeeping remains
        # conservative UNKNOWN rather than another potentially duplicate solve.
        if mismatched: raise OperationalStop('PRIOR_NECESSARY_COMPONENT_COLLISION_NO_CALL: '+str(mismatched[:5]))
        if self.history is not None:
            after,scope=self.history.find(net,kwargs)
            if after is not None:return after,None,dict(kind='PAID_TRACKED_RETURN_REUSE',scope=scope)
        else:scope=dict(named_current_scope_only=True)
        return None,None,dict(kind='UNENTERED_IN_NAMED_RETAINED_SCOPE',scope=scope,current_receipts_checked=self.count)
    def add(self,directory,source,row):
        item=dict(directory=directory,source=source.relative_to(R).as_posix(),source_sha256=sha(source),before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=row['exception'])
        self.items[self.key(saved_net(directory,row['before']))].append(item);self.count+=1

def wait_ack(output,began):
    while not (output/'Launcher_ACK.json').exists():
        assert time.monotonic()-began<120;time.sleep(.1)
    ack=read(output/'Launcher_ACK.json')
    assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']

def failure_message(exception):
    return 'PRESERVED_NATIVE_EXCEPTION_NO_RETRY: '+str(exception)

def frozen_checks():
    """Reuse the fixed original anchor list, measuring current file identity."""
    from candidate_process_evidence_utils import frozen_checks as original_checks
    return original_checks()
