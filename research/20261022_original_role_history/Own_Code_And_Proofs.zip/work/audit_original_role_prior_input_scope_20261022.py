"""Independent arithmetic and exact ALL45 coverage check; no solver/model calls."""
import copy, gzip, hashlib, json, os, pickle, sys, time
from fractions import Fraction
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_prior_input_scope_20261022'

def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def independent_key(net):
    accum = {}
    for ix in net.shunt.index:
        s = net.shunt.loc[ix]; b = int(s['bus'])
        if not bool(s['in_service']) or not bool(net.bus.loc[b, 'in_service']): continue
        ratio = Fraction.from_float(float(net.bus.loc[b, 'vn_kv'])) / Fraction.from_float(float(s['vn_kv']))
        w = Fraction.from_float(float(s['step'])) * ratio * ratio
        a = accum.setdefault(b, [Fraction(0), Fraction(0)])
        a[0] += Fraction.from_float(float(s['p_mw'])) * w
        a[1] += Fraction.from_float(float(s['q_mvar'])) * w
    records = [[b, [v[0].numerator, v[0].denominator], [v[1].numerator, v[1].denominator]]
               for b, v in sorted(accum.items()) if v[0] or v[1]]
    encoded = json.dumps(records, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest(), records

def main():
    started = time.perf_counter(); A = O / 'independent_audit'; A.mkdir(exist_ok=False)
    p = read(O / 'Protocol.json')
    assert all(sha(R / rel) == h for rel, h in p['pins'].items())
    assert all(sha(O / rel) == h for rel, h in read(O / 'Closed_Manifest.json')['members'].items())
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    calls = []
    def blocked(*a, **k): calls.append(True); raise BaseException('Solver forbidden in read-only audit')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, blocked)
    from frozen_physics_loader import load_stack, AUDIT
    _, runner, _ = load_stack()
    assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    prep = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'
    roots = {}
    for b in read(prep / 'Exact_Paid_Root_State_Bindings.json'):
        path = R / b['full_actual_root_payload']; assert sha(path) == b['payload_sha256']
        roots[b['root']] = pickle.loads(path.read_bytes())['net']
    expected = read(R / 'outputs/original_reflection_native_role_handoff_20261022/Exact45_Missing_Paid_Action_Identities_NOT_Execution_Authority.json')
    rows = read(O / 'All45_Indexed_Scope_Query.json')
    assert [(x['root'], x['bus'], x['q_mvar']) for x in expected] == [(x['root'], x['bus'], x['q_mvar']) for x in rows]
    idx = json.loads(gzip.decompress((R / p['index']).read_bytes()))
    assert len(idx) == 58516 and sum(map(len, idx.values())) == 60426
    for item in rows:
        net = copy.deepcopy(roots[item['root']])
        runner.rescue.apply_action(net, {'add_shunts_q_mvar': {str(item['bus']): item['q_mvar']}})
        key, values = independent_key(net)
        assert key == item['physical_component_sha256'] and values == item['perbus_exact_rational_P_Q_shunt_admittance']
        refs = idx.get(key, [])
        assert refs == item['matching_indexed_attempts'] and len(refs) == item['matching_indexed_attempt_count']
        assert item['indexed_scope_disposition'] == ('EXCLUDED_ALL60426_INDEXED_INPUTS' if not refs else 'UNKNOWN_COMPONENT_MATCH')
    assert not calls
    result = {'status': 'PASS_ALL45_SOURCE_ORDER_TARGETS_INDEPENDENT_EXACT_ARITHMETIC_AND_60426_INDEX_QUERY',
              'targets': 45, 'targets_excluded_in_index': sum(x['matching_indexed_attempt_count'] == 0 for x in rows),
              'component_matches_remain_UNKNOWN': sum(x['matching_indexed_attempt_count'] != 0 for x in rows),
              'new_scientific_calls': 0, 'full_historical_closure': 'PENDING_OTHER_RELEVANT_LINEAGES',
              'not_new_PF_execution_authority': True, 'workflow_seconds': time.perf_counter() - started}
    for name, value in [('Independent_Audit.json', result), ('Closed_Manifest.json', {'members': {'Independent_Audit.json': None}})]:
        if name == 'Closed_Manifest.json': value['members']['Independent_Audit.json'] = sha(A / 'Independent_Audit.json')
        with (A / name).open('x', encoding='utf-8') as f:
            json.dump(value, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())
    print(json.dumps(result))

if __name__ == '__main__': main()
