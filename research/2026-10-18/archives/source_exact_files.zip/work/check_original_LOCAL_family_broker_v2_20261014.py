"""Actual-input broker boundary/coverage checks, zero new scientific calls."""
import copy,hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
from original_LOCAL_family_broker_v2 import families,numerical_current_family_proposals
from original_local_paid_branch_broker_v1 import resource_eligible
from equal_operation_benchmark_v2 import initial_data
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
R=Path(__file__).resolve().parents[1];B=R/'outputs/original_LOCAL_family_broker_v2_20261014'
PAID=R/'outputs/bounded_paid_lookahead_physics_20261014'
ROLE=R/'outputs/actual_mask_original_role_ceiling_20261014'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(r):return tuple(r[k] for k in ['kind','receiver','q','donor_index','donor_bus'])
def main():
    B.mkdir(exist_ok=False);start=time.perf_counter();checks=[];rows=[]
    def check(name,value):assert value,name;checks.append(name)
    old,_,_=initial_data();_,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    for i,e in enumerate(old['current_endpoints'],1):
        net,cursor,_=load_endpoint(e);domain=build_current_domain(net,cursor,runner=runner,zones=zones);saved=copy.deepcopy(domain)
        role=read(ROLE/'actual'/f'W{i}_Role_Ceiling.json');branch=read(PAID/'actual'/f'Branch_{2*i}.json')
        chosen=next(m['row'] for m in branch['query_messages'] if m['parent']==branch['root'] and m['aid']==branch['plan']['selected']['first'])
        permitted=[z for z,pool in domain['original_LOCAL_allowed_per_zone'].items() if chosen['receiver'] in pool]
        check(f'ROOT{i}_MEASURED_FIRST_RECIPIENT_ORIGINAL_ROLE_LEGAL',bool(permitted))
        parsed={z:None for z in zones};parsed[permitted[0]]={'add_shunts_q_mvar':{str(chosen['receiver']):chosen['q']}}
        result=families(parsed,domain=domain,normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)
        expected=[r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if r['receiver']==chosen['receiver'] and r['q']==chosen['q'] and resource_eligible(r,domain['expanded_cursor_for_separately_fixed_future_protocol'])]
        check(f'ROOT{i}_ALL_LEGAL_VARIANTS_RETAINED_EXACTLY',result['families'][0]['all_resource_legal_variants']==expected)
        check(f'ROOT{i}_MEASURED_FIRST_PRESENT_WITHOUT_DONOR_HARDCODE',key(chosen) in {key(r) for f in result['families'] for r in f['all_resource_legal_variants']})
        check(f'ROOT{i}_PARENT_DOMAIN_UNMUTATED',domain==saved)
        null=families({z:None for z in zones},domain=domain,normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)
        check(f'ROOT{i}_NO_NULL_NUMERIC_FILL',not null['families'])
        invalid={z:{'add_shunts_q_mvar':{'9999':100.}} for z in zones}
        rejected=families(invalid,domain=domain,normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)
        check(f'ROOT{i}_INVALID_SCOPE_NEVER_REPAIRED',not rejected['families'])
        proposals=numerical_current_family_proposals(domain=domain,causal_ordering=role['full_order'])
        numerical=families(proposals,domain=domain,normalize=runner.rescue.normalize_action,validate=runner.validate_action_against_candidates)
        check(f'ROOT{i}_NUMERICAL_CONTROL_EXACT_SAME_INTERFACE',numerical['language_role']==result['language_role'] and numerical['donor_global_planning_role']==result['donor_global_planning_role'])
        rows.append({'world':e['world'],'original_recipient':chosen['receiver'],'original_q':chosen['q'],
            'complete_legal_variants':len(expected),'measured_first_variant_present':True,
            'scope':'Coverage fixture for all4 inspected paths, not actual model selection or a new performance outcome'})
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL4_ACTUAL_DOMAINS_COMPLETE_FAMILIES_ORIGINAL_SCHEMA_BOUNDARIES',
        'checks':checks,'all4_rows':rows,'source_sha256':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),R/'work/original_LOCAL_family_broker_v2.py']},
        'new_model_PF_derivative_forecast_solve_or_commits':0,'workflow_seconds':time.perf_counter()-start,
        'actual_model_family_selection_and_policy_effect':'UNKNOWN_NOT_MEASURED',
        'no_automatic_allocation_or_performance_launch':True,'old_fixed_broker_role_gate_unchanged':'UNKNOWN'}
    with (B/'Actual_Input_And_Boundary_Readiness.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'actual_root_domains':4,'checks':len(checks),'measured_first_variants_retained':4,'new_model_PF_calls':0}))
if __name__=='__main__':main()
