"""Actual author source contracts and next common-task design; zero execution."""
import ast,json,pickle,sys
from datetime import datetime,timezone
from reflection118_chronological_core_20261022 import R,read,put,sha
I=R/'outputs/published_voltage_source_intake_20261022'
O=R/'outputs/published_voltage_common118_design_20261022'


def evidence(repo,relative,needles):
    f=I/repo/'source'/relative;s=f.read_text('utf-8');lines=s.splitlines()
    assert all(n in s for n in needles)
    return {'path':f.relative_to(R).as_posix(),'sha256':sha(f),
        'line_anchors':[{'needle':n,'line':next(i+1 for i,line in enumerate(lines) if n in line)} for n in needles]}


def main():
    O.mkdir(exist_ok=False);assert read(I/'Result.json')['status']=='COMPLETE_PINNED_AUTHOR_SOURCE_INTAKE_ONLY'
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    pp.runpp=lambda *a,**k:(_ for _ in ()).throw(BaseException('No solver in source contract review'))
    rows=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    counts=[]
    for r in rows:
        net=pickle.loads((R/r['solved_payload']).read_bytes())['net']
        counts.append({'case_id':r['case_id'],'buses':len(net.bus),'generators':len(net.gen),
            'static_PV_sgens':len(net.sgen),'existing_shunts':len(net.shunt)})
    ev={
        'unique_DQN':evidence('blthayer__drl-powerworld','experiments/dqn_mod.py',['class DQNUniqueActions','import tensorflow as tf','action_list = list()']),
        'graph':evidence('blthayer__drl-powerworld','experiments/compare_agents.py',['class GraphAgent','def _get_shunt_action','def _get_gen_action']),
        'simulator':evidence('blthayer__gym-powerworld','gym_powerworld/envs/voltage_control_env.py',['from esa import SAW','pwb_path']),
        'RRL_config':evidence('RWTH-IAEW__RRL-voltage-control','src/configs.py',["'number_steps': 900000","'type': SACTrainer","1-LV-rural3-minQmaxP-augmented-curtail_cleaned.p"]),
        'RRL_droop':evidence('RWTH-IAEW__RRL-voltage-control','src/custom_envs/voltage_control/controller.py',['class DroopControl','class CentralizedDroopController']),
        'PV_device':evidence('RWTH-IAEW__voltage-control-env','src/voltage_control_env/env_utils.py',['self.ctrl_sgen_indices','self.net.sgen'])}
    commits={repo:read(I/repo.replace('/','__')/'Source_Intake.json')['commit'] for repo in
        ['blthayer/drl-powerworld','blthayer/gym-powerworld','RWTH-IAEW/RRL-voltage-control','RWTH-IAEW/voltage-control-env']}
    decision={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PINNED_SOURCE_CONTRACTS_AND_COMMON_ACTUATOR_PORT_DESIGN_ONLY',
        'repositories':commits,'actual_root_devices':counts,'source_evidence':ev,
        'families':[
            {'family':'Thayer/Overbye transmission DQN and unique-action DQN; graph agent',
             'primary_paper':'https://arxiv.org/abs/2006.06728','author_repository':'https://github.com/blthayer/drl-powerworld',
             'native_role':'PowerWorld generator voltage setpoints and existing binary switched capacitors; graph agent uses reactive proximity and available devices.',
             'direct_original118_shunt_admission':'NOT_SOURCE_EQUIVALENT. Original paper model adds25..300MVAr positive shunts at chosen buses,450owned-cap; author setpoint/switch actions differ.',
             'trained118common_task_checkpoint':'NOT_CERTIFIED. Source code existence is not a trained compatible policy.',
             'next':'Implement separately named common-task dueling/Double-DQN + original unique-idempotent-target logic with genuine controlled training, full state/checkpoint/cost gates. Preserve native/source-fidelity rows separately.'},
            {'family':'Bouchkati et al.2025 residual SAC and SAC voltage control',
             'author_repository':'https://github.com/RWTH-IAEW/RRL-voltage-control',
             'native_role':'Partially observed PV inverter P/Q setpoints with droop residual; published config uses a low-voltage feeder,900000training steps.',
             'direct_original118_shunt_admission':'NOT_SOURCE_EQUIVALENT. Actual four federation roots have no staticPV sgen devices; generator and shunt tables are distinct. Do not manufacture PV devices or score invalid raw outputs as method losses.',
             'trained118common_task_checkpoint':'NOT_CERTIFIED. A discrete categorical/SAC actuator conversion changes the method and must be named/evaluated as an adaptation.'}],
        'new_common_action_port':{
            'source':'work/federation_absolute_shunt_role_20261022.py',
            'gate':'outputs/federation_common_absolute_shunt_role_20261022/Independent_Action_Correspondence.json',
            'why':'Published unique-actions logic assumes idempotent setpoints. Treating repeated positive increments as the same action would incorrectly forbid additional useful banks. Encode absolute owned-Q targets and translate to the exact allowed increment.',
            'actual_gate':'14160exhaustive stock/action pairs and12actual original apply-only checks on4roots passed,0PF/model/training.',
            'role_only_not_complete_environment':'Actual allowed-bus scope, observations, native/common protection, committed trajectories, rewards, strong same-information controls and paid environment/source-history must still be bound.',
            'training_plan_constraints':'Freeze genuine TRAIN/VAL/unused TEST exact states and world clusters before reward data. Published training counts/architecture and any resource-limited budget differences disclosed. No underspecified or zero-shot foreign checkpoint counted beaten. No tuning from TEST, no fixed existing LoRA rescue without separate justified method.'},
        'runtime_performance':'PENDING_CURRENT_ORIGINAL_NATIVE_STUDY_AND_SEPARATE_ADMITTED_EXTERNAL_PORTS',
        'new_PF_model_training_GPU_calls':0,'no_superiority_from_bus_count_or_source_intake':True}
    put(O/'Source_Contract_And_Execution_Decision.json',decision)
    text='''Comparison work added two further author implementation families: transmission DQN/unique-action DQN/graph, and residual SAC/SAC voltage control. All four author repositories pinned;60text/config files540752bytes checked against Git object identities;72GETs,41.047seconds,0executed author/model/PF/training calls. Native device roles differ from the federation paper shunt interface. The original4root source-device counts and exact implementation line/hash anchors are saved. Not counted as completed benchmarks or methods beaten.

The new common-task absolute-shunt action port preserves every positive native25..300increment/450cap while giving an idempotent target identity suitable for the published unique-action rule.14160scalar pairs and12actual apply-only checks passed; source-owned shunt stock was used, static original shunts were not reclassified. This is substantive actuator-compatibility software, not a trained DQN or performance gain. Strong genuine training/observation/protection/reward/preservation/fullcost/unused-confirmation gates remain required before execution. Current original trained chronological study remains the active performance dependency.
'''
    (O/'Research_Progress_Entry.txt').write_text(text,encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+decision['at_utc']+'\n'+text+'\n')
    print(json.dumps({'saved':True,'new_author_families':2,'exact_pinned_repositories':4,'new_PF_model_calls':0,'all_final_goals':'OPEN'}))


if __name__=='__main__':main()
