"""Closed LOCAL evidence view; no controller, handoff or solver execution.

The exact original checkpoint readers run with a read-only byte filesystem.
Their code objects, assertions and old absolute deadline are unchanged. This
view never falls back to the original artifact tree for a missing packet.
Passing an offline read is deliberately not permission to resume science.
"""
import ast
import inspect
import json
import struct
import types
from pathlib import Path

import paid_spatial_controller_checkpoint_v1 as checkpoint_v1
import paid_spatial_controller_checkpoint_v3 as checkpoint_v3
import paid_spatial_actual_controller_checkpoint_v1 as actual_v1
from durable_opaque_evidence_store_v1 import EvidenceStop, local_root
from lossless_evidence_byte_codec_v1 import canonical, digest

MAGIC = b'HIERGRID_CLOSED_BYTES_V1\n'


def safe_relative(name):
    checkpoint_v1.local_file(Path(__file__).resolve().parents[1], name)
    return name


def pack_files(files, expected_inventory):
    """Already anchored complete bytes only; immutable deterministic framing."""
    if set(files) != set(expected_inventory):
        raise EvidenceStop('Missing/additional declared closed evidence')
    index = []
    for name in sorted(files):
        safe_relative(name)
        raw = files[name]
        if type(raw) is not bytes or {'bytes': len(raw), 'sha256': digest(raw)} != expected_inventory[name]:
            raise EvidenceStop('Closed evidence differs: ' + name)
        index.append({'relative': name, **expected_inventory[name]})
    header = canonical(index)
    return MAGIC + struct.pack('>Q', len(header)) + header + b''.join(files[x['relative']] for x in index)


def unpack_files(raw, expected_inventory, *, max_raw_bytes):
    if type(raw) is not bytes or len(raw) > max_raw_bytes or not raw.startswith(MAGIC):
        raise EvidenceStop('Invalid/bounded closed byte frame')
    prefix = len(MAGIC) + 8
    if len(raw) < prefix:
        raise EvidenceStop('Truncated frame header')
    n = struct.unpack('>Q', raw[len(MAGIC):prefix])[0]
    if n > len(raw)-prefix:
        raise EvidenceStop('Truncated frame index')
    index = json.loads(raw[prefix:prefix+n])
    expected = [{'relative': name, **expected_inventory[name]} for name in sorted(expected_inventory)]
    if index != expected:
        raise EvidenceStop('Frame file inventory differs from external declaration')
    position = prefix+n
    files = {}
    for entry in index:
        name = safe_relative(entry['relative'])
        size = entry['bytes']
        if type(size) is not int or size < 0 or size > len(raw)-position:
            raise EvidenceStop('Truncated/invalid file payload')
        value = raw[position:position+size]; position += size
        if digest(value) != entry['sha256']:
            raise EvidenceStop('Frame file hash mismatch: ' + name)
        files[name] = value
    if position != len(raw):
        raise EvidenceStop('Trailing frame bytes refused')
    return files


class _ReadPath:
    """Only the original readers' path/byte operations; no filesystem writes."""
    def __init__(self, path, view):
        self.path, self.view = path, view

    def __str__(self):
        return str(self.path)

    def __truediv__(self, relative):
        return _ReadPath(self.path / relative, self.view)

    def is_relative_to(self, other):
        return self.path.is_relative_to(other.path if isinstance(other, _ReadPath) else other)

    def read_bytes(self):
        return self.view.read_bytes(self.path)


class ClosedActualControllerView:
    def __init__(self, original_root, files, *, allowed_source_sha256):
        self.root = local_root(original_root)
        self.files = dict(files)
        for name, value in self.files.items():
            safe_relative(name)
            if type(value) is not bytes:
                raise EvidenceStop('Immutable complete file bytes required')
        self.sources = dict(allowed_source_sha256)
        self.workspace = Path(__file__).resolve().parents[1]
        self.artifact_reads = self.source_reads = 0
        # Copy function environments; never mutate imported old modules.
        env1 = dict(checkpoint_v1.read_checkpoint.__globals__)
        env1.update(extended_local_path=self.path, local_file=self.local_file)
        read1 = types.FunctionType(checkpoint_v1.read_checkpoint.__code__, env1,
                                   checkpoint_v1.read_checkpoint.__name__)
        env3 = dict(checkpoint_v3.validate_linkages.__globals__)
        env3.update(extended_local_path=self.path, local_file=self.local_file)
        linkage = types.FunctionType(checkpoint_v3.validate_linkages.__code__, env3,
                                     checkpoint_v3.validate_linkages.__name__)
        env3_read = dict(checkpoint_v3.read_checkpoint.__globals__)
        env3_read.update(read_v1=read1, validate_linkages=linkage, extended_local_path=self.path)
        read3 = types.FunctionType(checkpoint_v3.read_checkpoint.__code__, env3_read,
                                   checkpoint_v3.read_checkpoint.__name__)
        enva = dict(actual_v1.read_actual_controller_checkpoint.__globals__)
        enva.update(read_checkpoint=read3, extended_local_path=self.path, local_file=self.local_file)
        self.read = types.FunctionType(actual_v1.read_actual_controller_checkpoint.__code__, enva,
                                       actual_v1.read_actual_controller_checkpoint.__name__)
        self.linkages = linkage
        pairs = [(checkpoint_v1.read_checkpoint, read1),
                 (checkpoint_v3.validate_linkages, linkage),
                 (checkpoint_v3.read_checkpoint, read3),
                 (actual_v1.read_actual_controller_checkpoint, self.read)]
        self.source_certificate = {'all_four_original_code_objects_identical': all(a.__code__ is b.__code__ for a,b in pairs),
            'original_function_AST_sha256': {a.__module__+'.'+a.__name__:
                digest(ast.dump(ast.parse(inspect.getsource(a)), include_attributes=False).encode('utf8')) for a,b in pairs},
            'only_environment_changes': ['closed read-only path/bytes routing', 'routing the same chained original reader functions'],
            'old_semantic_assertions_and_deadline_unchanged': True,
            'old_artifact_tree_fallback_allowed': False, 'scientific_resume_permission': False}

    def path(self, value):
        if isinstance(value, _ReadPath):
            value = value.path
        return _ReadPath(local_root(value), self)

    def local_file(self, root, relative):
        original = root.path if isinstance(root, _ReadPath) else root
        # Execute all existing traversal/absolute/symlink rejection first.
        path = checkpoint_v1.local_file(original, relative)
        return _ReadPath(path, self)

    def read_bytes(self, path):
        path = local_root(path)
        if path.is_relative_to(self.root):
            name = path.relative_to(self.root).as_posix()
            if name not in self.files:
                raise EvidenceStop('Missing compressed artifact; original-tree fallback refused: '+name)
            self.artifact_reads += 1
            return self.files[name]
        if path.is_relative_to(local_root(self.workspace)):
            name = path.relative_to(local_root(self.workspace)).as_posix()
            if name in self.sources:
                raw = path.read_bytes()
                if digest(raw) != self.sources[name]:
                    raise EvidenceStop('Pinned external source changed')
                self.source_reads += 1
                return raw
        raise EvidenceStop('Unpinned external read refused')
