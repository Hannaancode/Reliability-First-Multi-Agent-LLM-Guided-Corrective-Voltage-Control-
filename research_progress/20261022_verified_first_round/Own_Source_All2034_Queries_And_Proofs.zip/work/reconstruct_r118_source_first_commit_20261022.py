"""Original DFF first commitment from complete paid verifier receipts.

The source candidate generator, score, selector, apply and controller execute
unchanged. Memoized verifiers serve only already independently checked exact
root/action pairs. This is cached source reconstruction, not a fresh episode.
"""
import copy,json,pickle,random,sys,time
from pathlib import Path
from reflection118_chronological_core_20261022 import *
O=R/'outputs/r118_source_first_commit_reconstruction_20261022'
def main():
    O.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np,pandapower as pp
    from frozen_physics_loader import load_stack,AUDIT
    _,runner,reflection=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    E=R/'outputs/r118_first_round_missing_only_execution_20261022';C=R/'outputs/r118_remaining_native80_contracts_execution_20261022'
    assert read(R/'outputs/r118_first_round_missing_only_independent_20261022/Independent_Audit.json')['maximum_field_delta']==0.
    assert read(R/'outputs/r118_remaining_native80_contracts_independent_20261022/Independent_Audit.json')['first_independent_PF_replays']==3
    summaries=read(R/'outputs/r118_first_round_missing_only_report_v2_20261022/Case_Summaries.json')['cases']
    assert all(s['first_round_source_choice_status']=='EXACT_FROM_COMPLETE_FIXED_MENU' for s in summaries)
    records=read(E/'Result.json')['rows'];contracts=read(C/'Results.json')['rows'];ctargets=read(R/'outputs/r118_remaining_native80_contracts_preparation_20261022/Protocol.json')['targets']
    byid={r['identity']:r for r in records}
    for j,t in enumerate(ctargets):byid[t['original_declared_identity']]=dict(byid[t['original_declared_identity']],status='CONTRACT_ADDENDUM',directory=C,record=contracts[j])
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    base=pp.from_json(str(R/'work/e/pack/testbeds/federation_4mg_ieee118.json'));zones=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    p=read(R/'outputs/reflection118_chronological_preparation_20261022/Frozen_Engineering_Protocol.json');native=pp.runpp;original_verifier=runner.rescue.verify_action;results=[]
    def forbidden(*a,**k):raise BaseException('RECONSTRUCTION_FORBIDS_NEW_MODEL_OR_PF')
    pp.runpp=forbidden
    try:
        for binding,summary in zip(bindings,summaries):
            root=pickle.loads((R/binding['solved_payload']).read_bytes())['net'];scenario=read(R/binding['registration']['recipe']);table={};afters={}
            for rec in byid.values():
                if rec['case_id']!=binding['case_id']:continue
                identity=json.dumps(rec['action'],sort_keys=True);verif=rec.get('verification')
                if rec['status']=='PAID_NATIVE80_REUSE_NO_NEW_PF':
                    old=rec['paid_matches'][0];path=R/old['source'];assert sha(path)==old['source_sha256'];d=path.parent;physical=read(path)
                elif rec['status']=='CONTRACT_ADDENDUM':d=C;physical=rec['record']
                else:d=E;physical=rec
                value=decode(d,physical['after']);after=value['net'] if isinstance(value,dict) and 'net' in value else value
                if verif is None:
                    expected=copy.deepcopy(root);runner.rescue.apply_action(expected,rec['action'])
                    def saved(n,**kw):
                        try:assert kw==rec['solver_kwargs'];frames_equal(n,expected);restore_exact(n,after)
                        except Exception as e:raise BaseException('VERIFIER_RECEIPT_ERROR: '+repr(e)) from e
                    pp.runpp=saved
                    try:verif=original_verifier(copy.deepcopy(root),rec['action'])
                    finally:pp.runpp=forbidden
                table[identity]=verif;afters[identity]=after
            assert len(table)==summary['declared']
            checkpoints=[];orders=[]
            for mode in ['warm','cold']:
                accesses=[];pf_calls=[];captured=None;seen_net=None
                random.seed(p['seed']);np.random.seed(p['seed'])
                def receipt_verifier(net,action):
                    nonlocal seen_net
                    if seen_net is None:frames_equal(net,root);seen_net=net
                    else:assert net is seen_net
                    key=json.dumps(action,sort_keys=True);assert key in table
                    accesses.append(key);return copy.deepcopy(table[key])
                runner.rescue.verify_action=receipt_verifier
                def source_pf(net,**kw):
                    if not pf_calls:
                        assert kw==binding['solver_kwargs'];frames_equal(net,root);restore_exact(net,root)
                    else:
                        assert len(pf_calls)==1
                        row=summary['best_available_only_descriptive'];action={'add_shunts_q_mvar':{str(row['bus']):float(row['Q_Mvar'])}}
                        expected=copy.deepcopy(root);runner.rescue.apply_action(expected,action);frames_equal(net,expected)
                        assert kw==read(R/'outputs/r118_first_round_missing_only_preparation_20261022/Protocol.json')['solver_kwargs']
                        restore_exact(net,afters[json.dumps(action,sort_keys=True)])
                    pf_calls.append(kw)
                def boundary(state):
                    nonlocal captured
                    captured=state;raise FirstCommitBoundary()
                try:controller(v2,runner,reflection,scenario,base,zones,forbidden,source_pf,'no_llm_fallback_first',boundary)
                except FirstCommitBoundary:pass
                finally:runner.rescue.verify_action=original_verifier
                assert captured is not None and len(accesses)==summary['declared'] and len(set(accesses))==len(accesses) and len(pf_calls)==2
                assert len(captured['result']['executed_actions'])==1
                state=capsule(O/(binding['case_id']+'_'+mode+'.zlib'),captured);checkpoints.append(captured);orders.append(accesses)
            checkpoint_equal(checkpoints[0],checkpoints[1]);assert orders[0]==orders[1]
            committed=checkpoints[0]['result']['executed_actions'][0]
            results.append(dict(case_id=binding['case_id'],source_committed_action=committed,source_committed_operation_count=1,remaining_original_operations=24,
                cached_verifier_receipt_accesses_per_source_pass=len(orders[0]),source_initial_and_commit_PF_receipt_reuses_per_pass=2,
                warm_cold_actual_source_checkpoint_exact=True,not_a_fresh_or_complete_physical_trajectory=True))
    finally:pp.runpp=native;runner.rescue.verify_action=original_verifier
    put(O/'Verified_First_Commit_And_Continuation_Gates.json',dict(status='PASS_ALL4_ORIGINAL_DFF_SOURCE_FIRST_COMMIT_FROM_PAID_TABLE_WARM_COLD',cases=results,
        original_outer_controller_candidate_generator_score_and_apply_AST_unchanged=True,verifier_memoization_scope='Exact original solved root and all source-ordered independently checked action receipts only.',
        source_costs='All original+new first-menu preparation/physics/failures/replays remain paid; memoization is not a zero-cost deployed search or new trajectory.',
        next='New prospectively bounded missing-only native continuation must bind these complete source first-commit cursors, original24remaining operations, all query/failed histories, exact ownership and first-new-replay reader before entry.',
        new_model_PF_derivative_optimizer_training_calls=0,new_real_physical_commits=0,all6_goals='OPEN',source_sha256=sha(__file__),workflow_seconds=time.monotonic()-start))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(all4_source_first_commit_warm_cold='PASS',remaining_original_operations=24,new_scientific_calls=0)))
if __name__=='__main__':main()
