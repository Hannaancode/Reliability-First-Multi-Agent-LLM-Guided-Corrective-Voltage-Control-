"""Independent polar equation expansion for all36, zero solver/model calls."""
import json,os,time
import numpy as np
from audit_pfdelta_fixed36_native_20261019 import R,BASE,B,read,put,sha,manifest,evaluate,polar_flows,complex_flows,extract

def main():
    out=B/'independent_polar_audit';out.mkdir(exist_ok=False);started=time.perf_counter();p=read(B/'Protocol.json');assert sha(__file__)==p['reader_sha256']
    assert sha(R/'work/audit_pfdelta_fixed36_native_20261019.py')==p['source_sha256']
    for rel,h in read(B/'Closed_Manifest.json')['members'].items():assert sha(B/rel)==h
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    rows=read(B/'Results.json')['rows'];assert len(rows)==36;diffs=[]
    for record in rows:
        path=BASE/'selected36'/record['file'];assert sha(path)==record['sha256']==p['pins'][str(path.relative_to(R))]
        data=read(path)
        try:second=evaluate(data,polar_flows)
        except Exception as error:
            assert record['native']['status']=='UNKNOWN_UNSUPPORTED_SCHEMA_OR_FIELDS' and record['native']['error_type']==type(error).__name__
            diffs.append({'file':record['file'],'status':'SAME_UNKNOWN_NOT_PHYSICS_PASS'});continue
        first=record['native'];assert second['status']==first['status']
        e=extract(data);delta=float(np.max(abs(complex_flows(e)-polar_flows(e))));assert delta<=1e-10
        for family in ('equation_residuals','operating_limit_violations'):
            for key,value in second[family].items():assert abs(value-first[family][key])<=1e-10,(record['file'],key)
        for key in ['PF_equations_pass','all_checked_operating_limits_pass','UV_below_original_0p95','OV_above_original_1p05plus1e8','active_branches','inactive_branches','reference_above_original_guard']:assert second[key]==first[key]
        diffs.append({'file':record['file'],'status':'PASS_INDEPENDENT_POLAR_COMPLEX_AGREEMENT','max_flow_delta_pu':delta})
    put(out/'Independent_Audit.json',{'status':'PASS_ALL36_IDENTITIES_AND_AVAILABLE_NATIVE_EQUATION_RESULTS_INDEPENDENTLY_CHECKED','rows':diffs,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
      'limits':'Same source schema extraction, separate real polar vs complex branch equations. A matching unknown is not a physical pass. PF consistency does not imply all operating limits or our-control compatibility.'})
    manifest(out);print(json.dumps({'independent_rows':36,'status':'PASS','newPF':0}))

if __name__=='__main__':main()
