"""One bounded index of prior physical PF inputs, not another experiment.

An absent exact resource key is insufficient: compare a necessary physical
input component (the full per-bus shunt P/Q admittance) across prior intents.
Any matching component stays UNKNOWN pending full input comparison.
"""
import argparse,collections,gzip,hashlib,json,os,pickle,subprocess,sys,time,zlib
from fractions import Fraction
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/prior_physical_query_footprints_20261018'
INPUT=R/'outputs/next_exact_paid_query_preparation_20261018'
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def component(net):
    # Rational arithmetic prevents differences caused only by summation order.
    # Split colocated shunts with equal physical admittance map to the same key.
    assert not bool(net.shunt.get('step_dependency_table',False).any()) if 'step_dependency_table' in net.shunt else True
    values={}
    for _,row in net.shunt.iterrows():
        bus=int(row['bus'])
        if not bool(row['in_service']) or not bool(net.bus.at[bus,'in_service']):continue
        ratio=Fraction(float(net.bus.at[bus,'vn_kv']))/Fraction(float(row['vn_kv']))
        scale=ratio**2*Fraction(float(row['step']));p=Fraction(float(row['p_mw']))*scale;q=Fraction(float(row['q_mvar']))*scale
        old=values.get(bus,(Fraction(0),Fraction(0)));values[bus]=(old[0]+p,old[1]+q)
    rows=[[bus,[p.numerator,p.denominator],[q.numerator,q.denominator]] for bus,(p,q) in sorted(values.items()) if p or q]
    return hashlib.sha256(canonical(rows)).hexdigest(),rows
def decode(directory,descriptor):
    if 'encoded_offset' in descriptor:
        from equal_operation_benchmark_v2 import decode_capsule
        with (directory/descriptor['path']).open('rb') as f:return decode_capsule(f,descriptor)['net']
    choices=[(directory/descriptor['path']).resolve(),(directory.parent/descriptor['path']).resolve()]
    choices=list(dict.fromkeys(p for p in choices if p.is_file()));assert len(choices)==1 and choices[0].is_relative_to(R)
    raw=choices[0].read_bytes();assert len(raw)==descriptor['encoded_bytes'] and hashlib.sha256(raw).hexdigest()==descriptor['encoded_sha256']
    decoded=zlib.decompress(raw);assert len(decoded)==descriptor['raw_bytes'] and hashlib.sha256(decoded).hexdigest()==descriptor['raw_sha256']
    obj=pickle.loads(decoded);return obj['net'] if 'net' in obj else obj
def prepare():
    import copy
    from joint_reallocation_opportunity_core_v1 import build_verifier,action
    from frozen_physics_loader import load_stack
    B.mkdir(exist_ok=False);data=read(INPUT/'Exact_Candidate_Inputs.json');stored=pickle.loads(zlib.decompress((INPUT/'Exact_Current_Input.zlib').read_bytes()))
    _,runner,_=load_stack();verify,actuate,certificate=build_verifier(runner.rescue,stored['cursor']);targets=[]
    for row in data['exact_new_query_rows']:
        net=actuate(copy.deepcopy(stored['net']),action(row['row']));key,values=component(net)
        targets.append({**row,'physical_component_sha256':key,'perbus_exact_rational_P_Q_shunt_admittance':values})
    # A genuine equivalent split is equal even if resource bookkeeping differs.
    fixture=copy.deepcopy(stored['net']);index=fixture.shunt.index[-1];old=fixture.shunt.loc[index].copy();fixture.shunt.at[index,'q_mvar']=float(old['q_mvar'])/2;fixture.shunt.at[index,'p_mw']=float(old['p_mw'])/2
    newindex=int(max(fixture.shunt.index))+1;fixture.shunt.loc[newindex]=old;fixture.shunt.at[newindex,'q_mvar']=float(old['q_mvar'])/2;fixture.shunt.at[newindex,'p_mw']=float(old['p_mw'])/2
    assert component(fixture)==component(stored['net'])
    fixture.shunt.at[newindex,'q_mvar']+=1.;assert component(fixture)!=component(stored['net'])
    catalog=read(R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json');sources=[x for x in catalog if x['events'].get('PF_intent')]
    assert len(sources)==10 and sum(x['events']['PF_intent'] for x in sources)==60426
    files=[Path(__file__),R/'work/audit_prior_physical_query_footprints_20261018.py',INPUT/'Exact_Candidate_Inputs.json',INPUT/'Exact_Current_Input.zlib',
        R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json',R/'work/equal_operation_benchmark_v2.py',R/'work/joint_reallocation_opportunity_core_v1.py']
    put(B/'Protocol.json',{'status':'FROZEN_BEFORE_PHYSICAL_COMPONENT_INDEX','sources':sources,'targets':targets,'producer_bound_seconds':1800,'reader_bound_seconds':1800,
        'selection':'ALL60426 retained PF intents across ALL10 recognized native four-root/controller lineage journals, including replay/exception/initial calls; no outcome or favorable identity subset',
        'component':'Exact rational sum of active shunt P/Q*step*(busVN/shuntVN)^2 at each in-service bus. Mathematical split/order equivalence retained. Not a full nonlinear input fingerprint.',
        'fixtures':'Actual saved NET split-equivalent shunt fixture equality and1MVAr change inequality PASS, zero science',
        'absence_gate':'Only no matching necessary physical component excludes all indexed prior exact input calls. Any component match means UNKNOWN; never repeat to settle uncertainty.',
        'scope':'Tracked native PF journals only. The separately audited3418fresh-root lineage still needs physical aggregate exclusion or full comparison; source cardinality alone is not aggregate-equivalence proof. Older untracked original kernel histories not universally certified.',
        'new_scientific_calls':0,'independent_reader_sha256':sha(R/'work/audit_prior_physical_query_footprints_20261018.py'),
        'pins':{str(x.relative_to(R)):sha(x) for x in files}})
    print(json.dumps({'physical_footprint_index_prepared':True,'all_intents':60426,'new_science':0}))
def worker():
    p=read(B/'Protocol.json')
    for rel,h in p['pins'].items():assert sha(R/rel)==h
    out=B/'actual';out.mkdir(exist_ok=False);started=time.perf_counter();put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    index={};counts=[];complete=True;failure=None;total=0;hits={t['point_action_key']:[] for t in p['targets']}
    try:
        for source in p['sources']:
            directory=(R/source['path']).parent;whole=hashlib.sha256();number=0
            with (R/source['path']).open('rb') as f:
                for line in f:
                    assert time.perf_counter()-started<p['producer_bound_seconds'],'Fixed physical-index bound, no extension'
                    whole.update(line);e=json.loads(line)
                    if e['event']!='PF_intent':continue
                    d=e['data'];net=decode(directory,d['before']);key,_=component(net)
                    ref={'journal':source['path'],'intent_line_sha256':hashlib.sha256(line).hexdigest(),'id':d.get('identity',d.get('id')),'before':d['before']}
                    index.setdefault(key,[]).append(ref);number+=1;total+=1
                    for t in p['targets']:
                        if key==t['physical_component_sha256']:hits[t['point_action_key']].append(ref)
                    if total%1000==0:
                        # One writer; atomic progress only, not completion proof.
                        temp=out/'Progress.new';temp.write_text(json.dumps({'intents_decoded':total,'unique_components':len(index),'seconds':time.perf_counter()-started}),'utf-8');os.replace(temp,out/'Progress.json')
            assert whole.hexdigest()==source['sha256'] and number==source['events']['PF_intent'];counts.append({'path':source['path'],'sha256':whole.hexdigest(),'decoded_intents':number})
    except BaseException:
        import traceback
        complete=False;failure=traceback.format_exc();(out/'Failure_Traceback.txt').write_text(failure,'utf-8')
    with gzip.open(out/'Physical_Component_Input_References.json.gz','wb') as f:f.write(canonical(index))
    put(out/'Result.json',{'status':'COMPLETE_ALL_TRACKED_INPUT_COMPONENTS' if complete else 'PARTIAL_MISSING_INPUTS_UNKNOWN_NO_RESTART',
        'actual_intents_decoded':total,'unique_components':len(index),'closed_sources':counts,'target_matching_prior_inputs':hits,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'coverage_gate':'NOT_AUTOMATIC_PF_AUTHORITY; independent all-input read and remaining lineage/global scope required','failure_preserved':failure is not None})
    manifest(out)
def run():
    worker();p=read(B/'Protocol.json');reader=R/'work/audit_prior_physical_query_footprints_20261018.py';assert sha(reader)==p['independent_reader_sha256']
    with (B/'Reader_Console.log').open('xb') as f:
        child=subprocess.Popen([sys.executable,'-X','utf8',str(reader)],cwd=R,stdout=f,stderr=subprocess.STDOUT);put(B/'Reader_Launch.json',{'actual_pid':child.pid,'parent_pid':os.getpid(),'source_sha256':sha(reader)})
        try:code=child.wait(timeout=p['reader_bound_seconds'])
        except subprocess.TimeoutExpired:child.kill();code=child.wait()
    put(B/'Completion.json',{'reader_exit_code':code,'retries':0})
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args();prepare() if args.prepare else run()
