# Receding 25-step implementation and exact execution decision

The new numerical coordinator, complete-tree storage admission, original
comparator bindings and fixed opportunity arithmetic are implemented. Two new
labelled software suites passed 35 and 21 checks. An external reader verified
all 56 checks, source identities, the real long-path storage fixture, all eight
fixed root file anchors and nine original frozen evidence checks. It reran no
suite and made zero model/PF/optimizer/controller science calls. Reader25424
endedexit0. The new21-member28,191-byte preparation ZIP has SHA
1f572066792c4f76ef4d96beb25b6a8c1c69477192c723d742242a8d77e11900,
CRC/every-member hashes PASS. Reuse that certificate; do not rehash it each check.

## Concrete before/after

- Before: one real protected commitment and cold following were certified.
  After: the full25-commit orchestration is coded and adversarially tested, with
  current cursor/history/checkpoint boundaries and legal zero-UV/no-action/25
  stops. The new full loop has NOT yet run on actual physics.
- Before: plain Windows inventory could omit deep returned states. After: the
  additive guard counts the entire extended-path owner tree, including failed
  states, journals, checkpoints and archives; unknown I/O stops new science.
  Paid returned bytes remain saved when crossing the bound. The source stores
  scan costs separately. This is not a disk-free-space or speed guarantee.
- Before: planning core could be called without irreversible trajectory
  orchestration. After: only current and paid first-child parents can receive
  new acquisition; only the selected FIRST action is committed. Subsequent
  selection uses the actual new current state. Hypothetical leaf rewards never
  become an actual terminal trajectory.
- Before: comparison was a plan. After: source-bound original DFF/ALT/selector
  and complete BOTH-branch cost aggregation are implemented; partial branch,
  root mismatch, missing timing or nonfinite costs leave UNKNOWN. Literal
  zero-as-missing deficit semantics are retained unchanged.

The actual ALT code chooses the second DISTINCT original-score action only at
the first decision, then ordinary DFF. Lowest-Vm gain is the original score's
fourth component. Do not substitute a different independently lowest-Vm action
selector for this source-defined comparator. Original historical sources and
all measured results remain untouched.

## Fixed research gates, before future outcomes

Keep L1,L2,S1,S2,T1,T2,C1,C2 exactly as anchored by the independent component
certificate, including the prior paired-zone input revision. All are development;
L1/L2 were inspected engineering, not unused confirmation. Preserve original
GLOBAL menu/raw scopes, nine positive Qs,450cap,25commitments, source-defined
trial/commit options and original score. Report literal original controllers
separately from common protected counterparts at1.05+1e-8.

Numerical controls remain native greedy, greedy depth-two expansion, fixed
width-eight beam and exhaustive depth-two reference. The latter is expensive
and already maximizes its fully paid same-horizon objective; imitating that
known argmax is not language value. Width-eight is retained from the prior
prospective plan, not selected from inspected outcomes.

Opportunity arithmetic requires all eight independently complete physical and
continuous-replay records. Equal-root terminal UV mean must improve by at least
0.5 against BOTH literalDSE and protectedDSE, with strict wins in at least two
exact roots against each, no root UV regression and no new protection failure.
Deployable acquisition additionally needs total online PF and measured workflow
time<=1.5x literal FULLBOTH DSE. Preparation, teachers, training, replay, failures
and existing reused evidence costs are additionally disclosed, not free.
Any missing outcome, physical certificate or timing yields UNKNOWN. A measured
failure stops that fixed intervention; no favorable roots/width/seed/Q/budget/
checkpoint/prompt/objective/threshold retunes. A PASS never auto-launches an LM.

Cost preflight: if all root/child menus had equal sizeN, width-eight depth-two
needs9N trial requests against about2N for two DSE root branches: nominal4.5x
at that decision, exceeding1.5x. This is NOT an episode-cost prediction or an
impossibility theorem: menus, early stops, trajectories and paid reuse differ.
Do not impute uniform query latency, reduce the comparator charge or silently
change width to claim affordability. The economic concern must be addressed
prospectively before investing in a full campaign or another learner.

## Exact next substantive implementation

1. Implement the real root/commit/failure owner callbacks. Before each new PF,
   require original absolute deadline, complete-tree admission and fresh exact
   owner claim/PID/parent/command. Preserve each actual return/failure before
   raising. A commit failure remains pending/UNKNOWN, with no rollback or retry.
   Keep actual direct PF/time/preservation costs live in every controller
   checkpoint, not just the query subset.
2. Finish the new complete-storage checkpoint integration with a separately
   fixed real process gate. The wrapper now preserves tree/limit/scan counters
   and refuses later activity after its final checkpoint, but only MOCK binding
   was tested this turn. The previous completed real L2 protocol cannot restart
   or have its900-second bound extended. No crash-resume certification follows.
3. Complete unchanged literal branch and common-protected branch preservation,
   all root/arm/failure/unexecuted accounting, source/input/effective-state pins,
   final cursor/journal/closed-manifest ownership and the source-locked independent
   full continuous trajectory reader. Declare initial/trial/commit/replay/IO/
   hash/archive/setup/preparation and failure intervals separately.
4. Freeze one justified full numerical protocol BEFORE any performance result,
   including exact unexecuted identities, evidence-reuse joins, all eight roots,
   strong same-information controls and resource/economic bounds. The older
   proposed28800seconds/3600perroot/32GiB is a draft, not a live budget. Do not
   automatically launch just because these software components passed.
5. Only a surviving numerical/physical mechanism can justify separately frozen
   causal language acquisition, actual fresh inference, strong trained numerical
   and architecture/pretraining controls, complete protected matched trajectories
   and unused authorized confirmation. No new GPU is justified now.

Matched adapted1.5B improved exact commands53.125% versus0.5B41.6667%, but trails
the numerical72.9167% and failed its fixed gate. It and all prior adverse/partial
stopped methods remain stopped. Validated incremental LLM advantage, DSE
superiority, fullsecurity and calibrated90%confidence are still unachieved.
