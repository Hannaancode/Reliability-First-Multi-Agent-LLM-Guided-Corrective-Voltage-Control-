from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear_readiness_publication_20261029'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    O.mkdir(exist_ok=False)
    scripts=['remaining85_source_binder_20261029.py','remaining85_run_source_binding_20261029.py','remaining85_source_binder_v2_20261029.py','remaining85_run_source_binding_v2_20261029.py','remaining85_certified_loader_20261029.py',
      'nonlinear13_validated_kernel_v2_20261029.py','nonlinear13_analytic_derivatives_20261029.py','check_nonlinear13_analytic_derivatives_20261029.py','audit_nonlinear500_kernel_boundaries_20261029.py','audit_nonlinear500_input_binding_20261029.py',
      'nonlinear13_preserved_solver_20261029.py','nonlinear13_preserved_solver_v2_20261029.py','nonlinear13_preserved_solver_v3_20261029.py','audit_nonlinear13_preserved_solver_20261029.py','audit_nonlinear13_preserved_solver_v3_20261029.py',
      'run_nonlinear13_first_proposal_20261029.py','audit_nonlinear13_first_proposal_20261029.py','coordinate_nonlinear13_first_proposal_20261029.py','freeze_nonlinear13_first_proposal_20261029.py',
      'nonlinear13_current_state_20261029.py','common118_history_recovery_20261029.py','nonlinear500_paid_registry_20261029.py','audit_nonlinear500_paid_registry_20261029.py',
      'nonlinear500_paid_lookup_v2_20261029.py','join_nonlinear13_first_proposal_paid_result_20261029.py','join_nonlinear13_first_proposal_paid_result_v2_20261029.py','save_nonlinear_readiness_checkpoint_20261029.py',Path(__file__).name]
    sources=[]
    for name in scripts:
        p=R/'work'/name
        if not p.exists():raise FileNotFoundError(p)
        sources.append(p)
    folders=['nonlinear13_derivative_preparation_20261029','nonlinear500_kernel_independent_review_20261029','nonlinear500_input_binding_independent_20261029',
      'nonlinear13_preserved_solver_review_20261029','nonlinear13_preserved_solver_review_20261029/v3_changed_paths','nonlinear13_current_state_preparation_20261029','nonlinear13_current_state_independent_review_20261029',
      'common118_history_recovery_20261029','nonlinear13_first_proposal_preparation_review_20261029','nonlinear13_first_proposal_preparation_20261029',
      'nonlinear13_first_proposal_execution_20261029','nonlinear13_first_proposal_independent_20261029','nonlinear13_first_proposal_paid_join_20261029','nonlinear13_first_proposal_paid_join_v2_20261029','nonlinear500_paid_registry_independent_20261029']
    for folder in folders:
        for p in sorted((R/'outputs'/folder).glob('*.json')):
            if p.name in ['Launcher_ACK.json','Closed_Manifest.json']:continue
            sources.append(p)
    sources.extend([R/'outputs/nonlinear500_source_binding_20261029/Readiness_And_Exact_Next_State.json',R/'outputs/nonlinear500_source_binding_20261029/v2_validated_full_admittance/Results.json',R/'outputs/nonlinear500_paid_registry_20261029/Result.json',R/'outputs/nonlinear500_paid_registry_20261029/Frozen_Registry_Manifest.json'])
    sources=list(dict.fromkeys(sources));rows=[]
    for p in sources:
        raw=p.read_bytes();assert len(raw)<5_000_000;rows.append(dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=sha(raw)))
    pack=O/'Own_Code_And_Compact_Proofs.zip'
    with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,row in zip(sources,rows):z.write(p,row['path'])
    with zipfile.ZipFile(pack) as z:
        assert z.testzip() is None
        for row in rows:assert sha(z.read(row['path']))==row['sha256']
    put(O/'Artifact_Index.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),members=rows,archive_sha256=sha(pack.read_bytes()),archive_bytes=pack.stat().st_size,
      scope='Own code and compact generated proofs only. No rawNETs, pretrained weights, model packs, full logs, third-party library sources or thesisDOCX. Not a full raw backup.'))
    for src,dest in [('outputs/research_tasks_20261014/Tasks.json','Research_Tasks.json'),('outputs/thesis_research_closure_20261028/Tasks.json','Thesis_Checklist.json'),('outputs/nonlinear_research_checkpoint_20261029/Exact_Resume.json','Exact_Resume.json')]:shutil.copy2(R/src,O/dest)
    (O/'Verified_Progress.txt').write_text('All500 initial nonlinear controller inputs independently bound. One new fixed numerical proposal at source-orderseed0 completed two actualSLSQPstages;70calculationreturns independentlyverified, maxdifference7.106e-15. NoPF/model/GPU/actualcommits. Exactoldpaidphysics for that proposal:12UVto12UV/0OV,originalguardPASS,nonlinearpredictionerror2.703e-9. This is initial solver/model consistency, not a restoration gain or full500policy. Firstproposal and oldphysics must be reused, never rerun.\n\nCompleteDFFselected-action history recovered29commits across33savedprefixes; candidate-query rejections and future learned histories remain scopedunknowns. Exactpaidregistry11355keys/11354reusable/1blocked missingafterNET; no universalhistory/newPFpermission.\n\nFull receding worker, semanticreceipt/guard/journal/cache/cost/clock joins and independentphysicalreader remain pending. All6finalgoalsOPEN,27/35thesisrequirementsclosed. No guaranteed winner, newtuning, purchases or quota assumptions. All oldfailures/unknowns/costs retained.\n',encoding='utf-8')
    fs=[]
    for name in ['Artifact_Index.json','Own_Code_And_Compact_Proofs.zip','Research_Tasks.json','Thesis_Checklist.json','Exact_Resume.json','Verified_Progress.txt']:
        p=O/name;b=p.read_bytes();fs.append(dict(local=p.relative_to(R).as_posix(),path='research_progress/20261029_nonlinear_readiness/'+name,bytes=len(b),sha256=sha(b),blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
    put(O/'Prepared_Files.json',dict(files=fs));print(json.dumps(dict(files=6,members=len(rows),archive_bytes=pack.stat().st_size)))
if __name__=='__main__':main()
