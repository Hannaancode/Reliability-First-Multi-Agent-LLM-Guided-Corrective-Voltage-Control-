"""Sole coordinator/four separate actual query owners; no retries or GPU."""
import argparse,os
from pathlib import Path
from next_fixed_four_followup_core_20261019 import B,PHASES,helpers,bound_worker,fixture_phase
from public118_slsqp_native_20261018 import R,read,put,sha
def coordinator():
    p=read(B/'Protocol.json');h=helpers(__file__);put(B/'Coordinator_Claim.json',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'protocol_sha256':sha(B/'Protocol.json'),'started_utc':h['now']()})
    codes={}
    try:
        assert not any((B/phase).exists() for phase in (*PHASES,'audit'))
        assert read(B/'Readiness.json')['status']=='PASS_FIXED_FOUR_QUERY_PRELAUNCH_ZERO_SCIENCE'
        for phase in PHASES:
            codes[phase]=h['launch'](Path(__file__),phase,B/phase,p)
            if codes[phase]!=0:break
        codes['audit']=h['launch'](R/p['independent_reader_source'],'reader',B/'audit',p)
    finally:put(B/'Completion.json',{'at_utc':h['now'](),'exit_codes':codes,'no_science_retry_or_extra_identity':True,'GPU_model_calls':0})
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--coordinator',action='store_true')
    for phase in PHASES:parser.add_argument('--'+phase,action='store_true');parser.add_argument('--fixture_'+phase,action='store_true')
    a=parser.parse_args()
    if a.coordinator:coordinator()
    else:
        for phase in PHASES:
            if getattr(a,'fixture_'+phase):fixture_phase(__file__,phase);break
            if getattr(a,phase):bound_worker(__file__)(phase);break
