"""Saved-only source, input, decoded-output, cost and full-cohort scoring audit.

No model is loaded and no inference is repeated. Label access occurs only in this
administrator process after all fixed primary assignments close.
"""
from pathlib import Path
import argparse, ast, hashlib, json, re
from typing import Any
from tokenizers import Tokenizer
from audit_public_qa_worker_20261029 import audit as journal_audit

R = Path(__file__).resolve().parents[1]
def read(p): return json.loads(Path(p).read_text('utf-8'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canon(x): return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def native_parser():
    sources = [(R/'outputs/veragrid_native_prompt_contract_20261029/source/benchmark_runner.py','extract_final_letter'),
        (R/'outputs/veragrid_source_admission_20261029/source/evaluator.py','extract_letter')]
    fs=[]
    for p,name in sources:
        fs.append(next(n for n in ast.parse(p.read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name==name))
    ns={'re':re,'Any':Any,'FINAL_LETTER_RE':re.compile(r'\b([A-D])\b')}
    exec(compile(ast.Module(body=fs,type_ignores=[]),'pinned_pure_parsers_only','exec'),ns)
    f=ns['extract_final_letter']; assert f('A then D')=='D' and f('I cannot answer')=='C'
    return f

def audit_arm(folder, assignment, pack, tokenizer_directory, expected_source):
    ids=[q['question_id'] for q in pack['questions']]
    result=read(folder/'Result.json') if (folder/'Result.json').exists() else {'status':'TERMINAL_PARTIAL','wall_seconds':None}
    if (folder/'Closed_Manifest.json').exists():
        proof=journal_audit(folder,ids)
    else:
        # A hard stop can leave no worker manifest. The terminal supervisor packet
        # fixes every byte; only complete, hash-linked return records can be scored.
        packets=sorted((folder.parent/'packets').glob('packet_*/descriptor.json'))
        descriptor=read(packets[-1]);assert descriptor['terminal'] is True
        for name,m in descriptor['members'].items():
            assert (folder/name).stat().st_size==m['bytes'] and sha(folder/name)==m['sha256']
        previous='0'*64;attempts=[];returns=[];rows=[];incomplete_line=False
        journal=(folder/'journal.jsonl').read_bytes() if (folder/'journal.jsonl').exists() else b''
        for i,line in enumerate(journal.splitlines()):
            try:event=json.loads(line)
            except json.JSONDecodeError:
                assert i==len(journal.splitlines())-1;incomplete_line=True;break
            assert event['index']==i and event['previous']==previous
            assert hashlib.sha256(canon({k:v for k,v in event.items() if k!='sha256'})).hexdigest()==event['sha256']
            previous=event['sha256'];rows.append(event)
            if event['kind']=='generation_attempt':
                n=event['ordinal'];assert n==len(attempts) and event['question_id']==ids[n]
                assert sha(folder/f'pre_rng_{n:03}.pt')==event['rng_sha256'];attempts.append(ids[n])
            elif event['kind']=='generation_return':
                n=event['ordinal'];assert n==len(returns) and event['question_id']==attempts[n]
                assert sha(folder/f'output_{n:03}.json')==event['output_sha256'];returns.append(ids[n])
        proof={'status':'PASS_PRESERVED_TERMINAL_PREFIX_ONLY','attempted':len(attempts),'completed':len(returns),
            'unknown_attempts':len(attempts)-len(returns),'unexecuted':150-len(attempts),'incomplete_final_journal_line':incomplete_line}
        result.update(attempted=attempts)
    if (folder/'owner.claim').exists():
        early_claim=read(folder/'owner.claim')
        assert early_claim['source_sha256']==expected_source
        assert early_claim['assignment_sha256']==hashlib.sha256(canon(assignment)).hexdigest()
    if proof['attempted']==0:
        return {'integrity':proof,'result_status':result['status'],'outputs':[],
            'actual_returned_science_generations':0,'actual_attempted_science_generations':0,
            'worker_wall_seconds':result['wall_seconds'],'engineering_status':'RETAINED_IN_RAW_ARTIFACTS_NO_SCIENTIFIC_ENTRY',
            'limits':'All150 scientific outcomes unknown. No no-entry failure is evidence of model accuracy or inability.'}
    claim=read(folder/'owner.claim')
    assert claim['source_sha256']==expected_source
    assert claim['assignment_sha256']==hashlib.sha256(canon(assignment)).hexdigest()
    integration=read(folder/'Actual_Integration.json')
    assert integration['model']==assignment['model'] and integration['revision']==assignment['revision']
    assert integration['dtype']=='float16' and integration['attention']=='eager' and 'T4' in integration['device']
    assert integration['transformers']==assignment['transformers_version'] and integration['private_adapter_loaded'] is False
    for name in ['config.json','tokenizer.json','tokenizer_config.json']:
        assert integration['snapshot_files'][name]==sha(tokenizer_directory/name)
    for name,expected in assignment.get('expected_weights',{}).items():
        assert integration['snapshot_files'][name]==expected['sha256']
    decoder=Tokenizer.from_file(str(tokenizer_directory/'tokenizer.json'))
    for q in pack['questions']:
        assert decoder.encode(q['rendered_prefix'],add_special_tokens=False).ids==q['input_ids']
    events=rows if not (folder/'Closed_Manifest.json').exists() else [json.loads(x) for x in (folder/'journal.jsonl').read_text('utf-8').splitlines()]
    warm=read(folder/'Engineering_Warm.json'); cold=read(folder/'Engineering_Cold.json')
    assert len(warm['new_token_ids'])==len(cold['new_token_ids'])==256
    assert warm['new_token_ids']==cold['new_token_ids'] and warm['raw_text']==cold['raw_text']
    assert sum(x['kind']=='engineering_warm_attempt' for x in events)==1
    assert sum(x['kind']=='engineering_cold_attempt' for x in events)==1
    decoded=[]; latency=0.; peak=0; tokens=0; cap_hits=0
    for event in events:
        if event['kind']=='generation_attempt':
            ordinal=event['ordinal']; q=pack['questions'][ordinal]
            assert event['input_sha256']==hashlib.sha256(canon(q['input_ids'])).hexdigest()
        if event['kind']=='generation_return':
            value=read(folder/f"output_{event['ordinal']:03}.json")
            assert decoder.decode(value['new_token_ids'],skip_special_tokens=True)==value['raw_text']
            assert value['elapsed_seconds']>=0 and value['peak_allocated_bytes']>0
            latency+=value['elapsed_seconds']; peak=max(peak,value['peak_allocated_bytes'])
            tokens+=len(value['new_token_ids']); cap_hits+=len(value['new_token_ids'])==256
            decoded.append(value)
    return {'integrity':proof,'result_status':result['status'],'outputs':decoded,
        'actual_returned_science_generations':len(decoded),'actual_attempted_science_generations':len(result['attempted']),
        'engineering_generations':2,'science_returned_generation_seconds':latency,'peak_allocated_bytes':peak,
        'science_generated_tokens':tokens,'output_cap_hits':cap_hits,'worker_wall_seconds':result['wall_seconds'],
        'engineering_generation_seconds':warm['elapsed_seconds']+cold['elapsed_seconds'],
        'limits':'Saved-source and decoded-evidence audit; model inference is not repeated. Engineering cold reload is not independent inference verification for every test answer.'}

def score_outputs(outputs,labels,parser):
    returns={x['question_id']:x for x in outputs};assert len(returns)==len(outputs) and set(returns)<=set(labels)
    primary=[];strict=[];valid=[]
    for qid,label in labels.items():
        text=returns[qid]['raw_text'] if qid in returns else ''
        selected=parser(text) if qid in returns else '?'
        s=text.strip();strict_letter=s if s in ['A','B','C','D'] else '?'
        primary.append(selected==label);strict.append(strict_letter==label);valid.append(strict_letter!='?')
    return primary,strict,valid,150-len(returns)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--protocol',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    protocol=read(args.protocol);o=Path(args.output);assert not o.exists()
    # All primary outcomes must be fixed before any administrator answer is read.
    for arm in protocol['arms']:
        host=read(R/arm['execution']/'status.json')
        assert (R/arm['execution']/'Host_End.json').exists()
        if host['runtime_allocated']:
            assert host['runtime_released'] and host['all_artifacts_preserved'] and host['actual_remote_child_ended']
        else:
            assert host.get('failure_http_status') in (401,403,429) or host['allocation_requests']==0, 'Uncertain allocation must be resolved before analysis'
    for p,h in protocol['source_hashes'].items(): assert sha(R/p)==h
    o.mkdir(parents=True)
    with (o/'owner.claim').open('x') as f:
        import os,sys
        json.dump({'pid':os.getpid(),'parent_pid':os.getppid(),'command':sys.argv,'source_sha256':sha(__file__)},f)
    results=[]
    for arm in protocol['arms']:
        a=read(R/arm['assignment']);pack=read(R/arm['pack'])
        host=read(R/arm['execution']/'status.json')
        if host['runtime_allocated'] and host.get('science_started',True):
            result=audit_arm(R/arm['execution']/'study',a,pack,R/arm['tokenizer_directory'],protocol['worker_sha256'])
        else:
            result={'integrity':'HOST_NO_ALLOCATION_CLOSED','result_status':'UNENTERED','outputs':[],
                'actual_returned_science_generations':0,'actual_attempted_science_generations':0}
        results.append({'model':a['model'],**result})
    raw=R/'outputs/veragrid_source_admission_20261029/administrator/mcq_questions.web.json'
    assert sha(raw)=='1d363bfa22a1a631c129b9f5a6ca21c5d1bfedf1298b4ef8b69145feb22edb60'
    labels={q['id']:str(q.get('correct_answer','')).strip().upper() for q in read(raw)['questions']}
    assert len(labels)==150 and all(x in ['A','B','C','D'] for x in labels.values())
    parser=native_parser(); vectors=[]
    for result in results:
        primary,strict,valid,missing=score_outputs(result.pop('outputs'),labels,parser);vectors.append(primary)
        result.update(primary_correct=sum(primary),denominator=150,strict_correct=sum(strict),strict_valid=sum(valid),
            missing_unknown=missing,primary_fraction=sum(primary)/150,
            missing_evidence_range=[sum(primary)/150,(sum(primary)+missing)/150],
            full_performance_known=(missing==0 and result['result_status']=='COMPLETE'))
    paired=[]
    for i in range(len(results)):
        for j in range(i+1,len(results)):
            full=results[i]['full_performance_known'] and results[j]['full_performance_known']
            paired.append({'a':results[i]['model'],'b':results[j]['model'],'status':'DESCRIPTIVE_COMPLETE150' if full else 'UNKNOWN_PARTIAL',
                'b_only_correct':sum(b and not a for a,b in zip(vectors[i],vectors[j])) if full else None,
                'a_only_correct':sum(a and not b for a,b in zip(vectors[i],vectors[j])) if full else None})
    report={'status':'PASS_SAVED_SCIENTIFIC_OUTPUT_AND_SCORING_AUDIT','arms':results,'paired':paired,
        'new_model_PF_OPF_training_calls':0,'source_sha256':sha(__file__),
        'limits':['150 correlated questions from one public circuit; not150 independent grids.',
        'Public pretraining contamination unknown; not unused confirmation.',
        'No private adapter or RAG retrieval; not full original-paper system performance.',
        'Host download/setup/transfer/release costs remain separate and must be included with worker costs.',
        'No comparison to historical author accuracy without verified matching input, model, tool and runtime contracts.']}
    (o/'Independent_Audit.json').write_text(json.dumps(report,indent=2),'utf-8')
    print(json.dumps({'status':report['status'],'arms':len(results)}))
if __name__=='__main__':main()
