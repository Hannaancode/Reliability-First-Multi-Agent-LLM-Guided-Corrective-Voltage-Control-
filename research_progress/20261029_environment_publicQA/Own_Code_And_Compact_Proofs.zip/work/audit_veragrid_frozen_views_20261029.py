"""Independent input-field comparison using raw JSON, without the producer module."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path(__file__).resolve().parents[1];O=R/'outputs/veragrid_source_admission_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=O/'Independent_Input_View_Audit.json';assert not out.exists()
    protocol=json.loads((O/'Dataset_Intake_Protocol.json').read_text('utf-8'))
    raw=O/'administrator/mcq_questions.web.json';payload=O/'participant/Question_Views.json'
    r=json.loads(raw.read_text('utf-8'));v=json.loads(payload.read_text('utf-8'));proof=json.loads((O/'Actual150_Admission.json').read_text('utf-8'))
    assert sha(raw)==proof['raw_question_sha256'] and sha(payload)==proof['participant_payload_sha256']
    assert sha(O/'Dataset_Intake_Protocol.json')==proof['protocol_sha256']
    assert set(v)=={'questions'} and len(v['questions'])==len(r['questions'])==protocol['expected_count']==150
    ids=[]
    for source,visible in zip(r['questions'],v['questions']):
        assert set(visible)=={'question_id','question','options'}
        assert visible['question_id']==source['id'] and visible['question']==source['question'].strip()
        assert visible['options']==[[k,source['options'][k]] for k in 'ABCD']
        ids.append(source['id'])
    assert len(set(ids))==150
    out.write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL150_EXACT_ORDER_TEXT_OPTIONS_AND_LABEL_FIELD_EXCLUSION','records':150,'source_order_preserved':True,'raw_sha256':sha(raw),'participant_sha256':sha(payload),'producer_record_sha256':sha(O/'Actual150_Admission.json'),'independent_checker_sha256':sha(Path(__file__)),'new_model_PF_OPF_training_calls':0,'labels_or_question_values_emitted':False,'limits':'Input packaging only. Does not prove process isolation, token fit, faithful circuit context, parser fairness, inference or QA performance.'},indent=2)+'\n','utf-8')
    print(json.dumps({'status':'PASS_ALL150_INPUT_VIEWS','records':150,'new_science':0}))
if __name__=='__main__':main()
