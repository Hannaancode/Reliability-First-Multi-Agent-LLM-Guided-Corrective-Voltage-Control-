# Additive input and binding revision, 12 October 2026

The initial plan remains preserved. Its S1/S2 single-zone losses duplicated earlier named recipes and were rejected before any new PF. The separately prepared v2 roots use **S1=MG1+MG2 source loss** and **S2=MG3+MG4 source loss**. The other six scenarios and all scientific opportunity, protection and economic gates stay unchanged. This revision followed input-identity checks, not physical outcomes.

The canonical current input certificate is `spatial_allocation_input_audit_v3_20261011/Independent_Input_Audit.json`: all eight roots distinct against the declared204-file catalog, all72 non-result frames checked exactly through independent table transformations. Raw pickle byte hashes are retained as provenance; cross-process effective-input identities now use exact typed values, axes and dtypes, with no tolerance or dropped frame. Original rejected preparation, failed reader and diagnostic remain preserved. This catalog check is development input closure, not universal historical exclusion or unused confirmation.

The new native query adapter has **not executed science** and is not launch-ready. Its operational resource/preservation exceptions must escape the native broad Exception handler, and its unlaunched timer must separate original solver time from storage. These must be repaired additively, followed by actual query/commit/cold continuation and complete episode integration before the numerical opportunity worker can launch. Software checks do not establish physical headroom, LLM advantage, novelty or90percent success.

Read `Research_Resume_20261012.json` for the exact ordered continuation. The matched-scale study completed with a failed numerical gate and remains stopped.
