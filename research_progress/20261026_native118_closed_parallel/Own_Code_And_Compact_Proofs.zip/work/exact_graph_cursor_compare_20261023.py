"""Explicit typed graph-state equality for saved controller cursors.

All node/adjacency insertion orders, graph/node/edge attributes and directed
flags are retained. Runtime cached view objects are not policy state.
"""
import networkx as nx
from strict_saved_native_input_match_v2_20261018 import require_same as ordinary

def encode_graphs(value):
    if type(value) is nx.Graph:
        return ('EXACT_NETWORKX_GRAPH_STATE',value.is_directed(),value.is_multigraph(),
            encode_graphs(value.graph),encode_graphs(value._node),encode_graphs(value._adj))
    if isinstance(value,dict):
        # Preserve native mapping type/order while replacing only Graph leaves.
        out=value.copy()
        for k,v in value.items():out[k]=encode_graphs(v)
        return out
    if isinstance(value,list):return [encode_graphs(x) for x in value]
    if isinstance(value,tuple):return tuple(encode_graphs(x) for x in value)
    return value

def require_same(a,b,path='cursor'):
    return ordinary(encode_graphs(a),encode_graphs(b),path)
