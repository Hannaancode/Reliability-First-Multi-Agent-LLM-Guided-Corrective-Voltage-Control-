"""Save/publish actual native-role integration, all adverse outputs and costs."""
import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_reflection_native_role_handoff_20261022'
P = R / 'outputs/original_reflection_saved_root_preparation_v2_20261022'
E = R / 'outputs/original_reflection_saved_root_execution_v2_20261022'
A = R / 'outputs/original_reflection_saved_root_independent_v2_20261022'
I = R / 'outputs/original_reflection_first_zone_paid_inventory_v2_20261022'
PUB = O / 'publication'


def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
    with p.open('w', encoding='utf-8', newline='') as f:
        if isinstance(value, str): f.write(value)
        else: json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush(); os.fsync(f.fileno())


def main():
    PUB.mkdir(exist_ok=False); at = datetime.now(timezone.utc).isoformat()
    audit = read(A / 'Independent_Audit.json')
    report = read(O / 'Verified_Native_Role_And_Paid_Proposal_Results.json')
    state = read(E / 'status.json')
    assert state['runtime_released'] and state['remote_exit_code'] == 0 and state['all_actual_closed_artifacts_preserved']
    assert audit['fixed_interface_gate'] == 'PASS_LIMITED_NATIVE_ROLE_READINESS'
    S = E / 'staged/study'
    science = read(S / 'Results.json')
    primary = read(R / 'outputs/original_reflection_saved_root_coordination_v2_20261022/End_ACK.json')
    reader = read(R / 'outputs/original_reflection_saved_root_reader_coordination_v2_20261022/End_ACK.json')
    assert primary['actual_owned_chain_ended'] and reader['actual_owned_chain_ended']
    raw = []
    for arm in ['lora', 'base_disabled']:
        for root in ['L1', 'L2']:
            q = read(S / f'primary_{arm}_{root}_Query_Result.json')
            calls = [read(S / f'primary_{arm}_{root}_Call_{j}.json') for j in range(1, q['actual_generation_calls'] + 1)]
            raw.append({'arm': arm, 'root': root, 'raw_outputs_in_order': [x['raw_text'] for x in calls],
                        'final_original_source_valid': q['original_info']['valid_action'],
                        'original_action': q['original_action'], 'reprompted': q['original_info']['reprompted']})
    unknown = [r for r in read(I / 'All144_Declared_Native_Query_Bindings.json') if r['status'] != 'BOUND_EXACT_EXISTING_NATIVE_ROOT_QUERY']
    assert len(unknown) == 45
    write(O / 'Exact45_Missing_Paid_Action_Identities_NOT_Execution_Authority.json', unknown)
    design = {
        'at_utc': at, 'status': 'MODEL_NATIVE_ROLE_GATE_COMPLETE_FULL_COMPARISON_STILL_OPEN',
        'all6goals': 'OPEN', 'current_owner': None, 'current_GPU_assignments': 0, 'timers': [],
        'completed': {
            'source_order_paid_development_roots': ['L1', 'L2'], 'initial_UV': [20, 46],
            'prefix_tokens': [1274, 1972], 'original_FIRST_ZONE_only': True,
            'model_protocol': 'outputs/original_reflection_saved_root_preparation_v2_20261022/Frozen_Engineering_Protocol.json',
            'model_protocol_sha256': sha(P / 'Frozen_Engineering_Protocol.json'),
            'actual_gpu': 'One selected original-account T4 allocated once, used, released',
            'actual_costs': audit['actual_costs'], 'scientific_workflow_seconds': science['workflow_seconds'],
            'primary_whole_owner_seconds': primary['elapsed_seconds'], 'reader_whole_owner_seconds': reader['elapsed_seconds'],
            'peak_allocated_bytes': {rep: read(S / f'{rep}_Memory_And_Source_Proof.json')['peak_allocated_bytes'] for rep in ['primary', 'cold']},
            'fresh_load_same_query_paths_and_all_tokens_exact': True,
            'source_original_native_parser_and_conditional_reprompt_AST_unchanged': True,
            'modern_token_container_compatibility': 'v1 blocked before model/allocation; v2 exact Tensor view preserves all input IDs/masks. No prompt/decoder/weight/physics change.',
            'base_same_quantized_weights_adapter_disabled_verified': True,
            'native_paid_query_inventory': {'all_legal_FIRST_ZONE_identities': 144, 'exact_existing_receipts': 99, 'unknown': 45},
            'no_new_PF_optimizer_derivative_or_training': True,
            'not_full203_case_closure_or_full137_paper_reconstruction': True},
        'adverse_and_limits': {
            'original_lora_first_reply_invalid_q_zero_both_roots': True,
            'final_validity_depends_on_existing_native_conditional_reprompt': True,
            'base_L1_raw_small_positive_Q_snapped_to25_by_original_normalizer': True,
            'no_new_normalizer_repair_invented': True,
            'both_LoRA_final_proposals_same_bus12Q50': True,
            'constant_bus12Q50_is_required_diagnostic_control_not_a_language_advantage': True,
            'base_L2_saved_candidate46to39_unsafe_maxVm': 1.1456680402983759,
            'LoRA_L2_saved_candidate46to44_original_accepted': True,
            'LoRA_L1_candidate_physical_result': 'UNKNOWN_MISSING_PAID_RECEIPT',
            'candidate_returns_are_not_actual_new_commits_or_complete_trajectories': True,
            'strict_OV_roundoff_counts_retained_no_rounding': True,
            'source_native1_06_and_common1_05_guards_not_conflated': True,
            'old_L2_scientific_study_was_partial_no_new_independent_full_physics_claim': True,
            'these_two_inputs_are_inspected_development_not_unused_confirmation': True,
            'no_90percent_confidence_LLM_DSE_external_or_novelty_claim': True},
        'next_ordered_tasks': [
            'Do not restart any model owner/reader or allocate another GPU for the same inputs; actual source/claims/results are terminal and closed.',
            'Close relevant full physical-attempt history for ALL45 missing native FIRST_ZONE identities. Current inventory alone is not universal never-executed proof. Include old source-order branches, cached probes and later lineages; retain unknowns.',
            'Only if genuinely unexecuted scope/source/ownership/preservation/cold/reader/cost gates pass, separately freeze an ALL45 missing-only physical measurement and first replay. Never select just the LoRA-favourable action, repeat old queries, or extend old budgets.',
            'Complete causal original four-zone queries using actual current paid verifier feedback. FIRST_ZONE success does not permit empty feedback for later zones, free receipts, fabricated continuations or automatic full rollout.',
            'Complete source-bound full25step model-query/refinement/commit/cursor/RNG/cost preservation and independent continuous replay before full-system testing.',
            'Resolve external-method native118 training/source/action compatibility. The two recovered roots are additional fixed8study states, not closure of the registered203 originals.',
            'Common-role controls must have equal physical access: exact native DFF vs LLM candidate pools differ. Keep unmodified originals as fidelity rows, explicitly name any common-union adaptation and preserve literal D-SE/fullBOTH costs.',
            'Full fixed cohorts and unused authorized confirmation precede superiority; preserve public13 missing441 and all stopped/adverse/UNKNOWN branches as secondary pending work.'],
        'actual_primary_ended': primary, 'actual_reader_ended': reader,
        'source_resumption': 'outputs/original_reflection_native_role_handoff_20261022/Current_Resume.json'}
    write(O / 'Current_Resume.json', design)
    write(O / 'All4_Primary_Raw_Query_Paths.json', raw)
    note = f'''## Actual original Reflection-v4 native-role GPU check — {at}

One selected original-accountT4 actually allocated/used/released. Two pre-existing paid fullNET states, first enteredL1/L2 of the old fixed8development study, have20/46initialUV and original FIRST_ZONE prompts1274/1972tokens. Original trained0.5B LoRA and exact same adapter-disabled pinnedNF4base each queried on both states, with actual fresh-load repetition. Independent source/context/parser/conditional-reprompt/loader/private tensor/quantized state/memory/token/cost/closed-artifact audit PASS.8complete source query paths,12actual generations,234pretrained forwards/tokens,2fresh model loads;0newPF/optimizer/training. Scientific workflow129.999552895seconds; whole primary320.10899999999674seconds and reader13.485000000044238seconds separately charged. Peak allocated1,158,896,128/1,732,376,576bytes. Exact historical base runtime remains unrecovered, disclosed. All actors endedexit0, exact runtime released; no timer or new allocation pending.

Both LoRA first outputs were bus20/q0, invalid under the unchanged mandatory native query. Existing source-specific reprompt gave bus12/Q50 in BOTH states; final source validity2/2 and exact cold paths. Same-action constant control remains required; no language reasoning/learning superiority follows. Base gave rawQ0.93479 onL1, snapped to25 by the original normalizer, andQ150 onL2. No new output repair or prompt tuning was added.

All144legal FIRST_ZONE actions were indexed before inspecting model outputs:99exact existing native trial receipts bound to captured roots and actuated physical tables;45missing remainUNKNOWN. Original LoRA L2 proposal matches old candidate46to44UV, native verifierACCEPTED,maxVm1.0500000000000003; strictOV1 remains retained. Base L2 candidate46to39UV isUNSAFE/maxVm1.145668/rejected. Base L1 oldcandidate20to16UV accepted/max1.05. LoRA L1 bus12/Q50 has no paid receipt in this index and staysUNKNOWN. These are saved candidate outcomes, not new commits/complete policies/new independent physical replay or a fair external benchmark.

New exact candidate-scope finding: native DFF pools20/46buses versus union of native DFF and all original zone pools33/48 onL1/L2. FIRST_ZONE includes4/1buses absent from DFF. Common-role comparisons need explicit equal-access controls; preserve native original variants/fullBOTH costs rather than credit menu expansion to language intelligence.

Unlaunched modelv1 token-container mismatch was caught before GPU/model calls; additivev2 preserves original function AST and exact tokens/masks. Initial paid-index dependency import failure had0record/model/PF entries, retained; additive dependency-pathv2 analysis did0science. All original assets/failednative13/failedscale/partial128/137paper results retained. Full203root registration, complete original controller/external118benchmark, zero-all/LLMsuperiority/security remainOPEN. Resume closes relevant history for all45 missing queries, then separately prospective missing-only measurement if gates pass; never automatic science from software/model readiness.
'''
    write(O / 'Research_Progress_Entry.md', note)
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n' + note + '\n'); f.flush(); os.fsync(f.fileno())
    header = f'''## Original native-role T4 study COMPLETE; independentPASS; full benchmark pending — {at}

Sole primary15932/shim21832, reader7816/shim10036, coordinator13024/shim26256 allENDEDexit0; exec39570 ended. One actualT4 released after all artifacts preserved.8source query paths/12generations/234forwards/2loads,0newPF/training. LoRA final native validity2/2 only through original reprompt(firstq0invalidboth); same bus12/Q50 both, no language advantage. L2 paidcandidate46to44accepted vs base46to39UNSAFE1.145668/rejected; L1 LoRAcandidateUNKNOWN. No actualnewcommit/fulltrajectory/externalbenchmark claim.

Read outputs/original_reflection_native_role_handoff_20261022/Current_Resume.json. ALL144legal FIRST_ZONE identities indexed:99paid/45UNKNOWN, no newPF. Two roots belong to additional fixed8development study; registered203closure remainspending. Next close ALL45 relevant attempted-identity history, then only a separate prospective missing-only physical study with exact source/native/ownership/persistentstate/independent first-replay/fullcost gates. No previousworker/reader/budget restart. Later-zone prompts require real current feedback; do not fabricate empty history or launch fullphysics automatically. Native DFF vs originalLLM menus differ; common equal-access controls needed. Original137reported290/291/193, frozenassets/literalDSE/fullBOTH/all adverse/partial/UNKNOWN retained. AllsixgoalsOPEN. No currentGPU/job/timer.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        path = R / rel; write(path, header + path.read_text('utf-8'))
    for path in [R / 'outputs/full_system_comparison_20261021/Current_Resume.json', R / 'outputs/federation_matched_benchmark_20261022/Current_Resume.json']:
        value = read(path); value.update(at_utc=at, status=design['status'],
            native_role_resume='outputs/original_reflection_native_role_handoff_20261022/Current_Resume.json',
            current_owner=None, current_single_scientific_owner=None, current_GPU='No assignments; actual singleT4study complete/released',
            next_ordered_tasks=design['next_ordered_tasks'], timers=[])
        write(path, value)
    path = R / 'outputs/research_tasks_20261014/Tasks.json'; tasks = read(path)
    goal = next(x for x in tasks['tasks'] if x['checklist_id'] == 'G3')
    goal.update(status=design['status'], current_result='Actual original-native-role LoRA/base/cold integration PASS on2fixed development states; originalLoRAneedsreprompt; candidate-level safety evidence only. Full203/externalbenchmark stillpending.',
                next=design['next_ordered_tasks'][1])
    for id_, text, evidence in [
        ('G3.F118.4a', 'Bind2actual paid fullNET roots and ALL144 FIRST_ZONE native action identities;99old receipts exact,45UNKNOWN retained. Not full203closure.', 'outputs/original_reflection_first_zone_paid_inventory_v2_20261022/Result.json'),
        ('G3.F118.6a', 'Execute originalnative FIRST_ZONE LoRA/same-base-disabled queries on2source-order paid roots, full fresh-load/cold/source/cost/immutability audit;T4released.', 'outputs/original_reflection_saved_root_independent_v2_20261022/Independent_Audit.json')]:
        assert id_ not in [x['id'] for x in goal['subtasks']]
        goal['subtasks'].append({'id': id_, 'completed': True, 'description': text, 'evidence': evidence, 'verified_at_save': at})
    tasks.update(updated_at_utc=at, latest_exact_execution_state='outputs/original_reflection_native_role_handoff_20261022/Current_Resume.json')
    write(path, tasks)
    # Public compact source/proof snapshot: never include private adapter ZIP,
    # credentials, NET capsules, full original bank or private TRAIN labels.
    own = []
    for pattern in ['*original_reflection*20261022.py', 'index_saved_first_zone_paid_queries*20261022.py', 'summarize_original_native_role_paid_proposals_20261022.py']:
        own.extend((R / 'work').glob(pattern))
    own.append(Path(__file__))
    files = {str(x.relative_to(R)).replace('\\', '/'): x.read_bytes() for x in set(own)}
    for folder in [O, A, I]:
        for f in folder.glob('*'):
            if f.is_file() and f.suffix in ['.json', '.md']:
                files[str(f.relative_to(R)).replace('\\', '/')] = f.read_bytes()
    for f in S.glob('*'):
        if f.is_file() and f.suffix in ['.json', '.jsonl']:
            files[str(f.relative_to(R)).replace('\\', '/')] = f.read_bytes()
    for f in P.glob('*.json'):
        data = read(f)
        if f.name == 'Frozen_Engineering_Protocol.json':
            data['profiles'] = {'public_0_5B': {'selected_original_account_identity_verified': True, 'GPU': 'T4'}}
            data['publication_note'] = 'Derived redacted account metadata; actual frozen protocol hash is in the independent audit.'
        files['public_preparation/' + f.name] = json.dumps(data, indent=2, ensure_ascii=False).encode()
    for folder in ['outputs/original_reflection_saved_root_preparation_20261022', 'outputs/original_reflection_first_zone_paid_inventory_20261022']:
        for name in ['Prelaunch_Container_Compatibility_Block.json', 'Failure.json']:
            f = R / folder / name
            if f.exists(): files[str(f.relative_to(R)).replace('\\', '/')] = f.read_bytes()
    archive = PUB / 'Own_Code_And_Model_Proofs.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for name, data in sorted(files.items()): z.writestr(name, data)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        member_proof = []
        for name in z.namelist():
            data = z.read(name); assert data == files[name]
            member_proof.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    write(PUB / 'Evidence_Manifest.json', {'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
        'CRC_every_member': 'PASS', 'members': member_proof, 'private_weights_NET_and_credentials_excluded': True})
    write(PUB / 'Verified_Results.json', report)
    write(PUB / 'Current_Resume.json', design)
    write(PUB / 'Research_Progress_Entry.md', note)
    write(PUB / 'All4_Primary_Raw_Query_Paths.json', raw)
    write(PUB / 'README.md', '''# Actual original Reflection-v4 native-role integration

OneT4 was actually used and released. Two captured federation development roots, original FIRST_ZONE only, unchanged privateLoRA and same disabled-adapter base, exact fresh-load repetitions.8query paths/12generations/234forwards; zero newPF/training. Independent model/source/cold/cost audit passed.

Both LoRA first replies were invalid q0; the existing source reprompt returned bus12/Q50 both times. This supports original-role integration, not learning benefit or reasoning novelty. L2 existing paid candidate evidence is46to44UV/accepted for LoRA; base46to39UV creates1.146p.u./rejected. L1 LoRA candidate remainsUNKNOWN. These are candidate outcomes, not newly committed whole-controller performance. All negative/partial/unknown records and full costs remain.

99of144fixed first-zone actions have exact paid receipts;45unknown. The native model/numerical menus differ, so common-access controls are necessary. Full203/paper137/external-method/unused-confirmation superiority is not achieved. Compact own code and actual model proofs exclude private weights, NET capsules, bank and credentials; not a full raw backup.
''')
    prepared = []
    for f in sorted(PUB.iterdir()):
        data = f.read_bytes()
        prepared.append({'local': str(f.relative_to(R)).replace('\\', '/'),
            'path': 'research/20261022_original_native_role/' + f.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
    assert len(prepared) == 7
    write(O / 'Publication_Files_Prepared.json', prepared)
    print(json.dumps({'status': design['status'], 'all6goals': 'OPEN', 'T4released': True,
                      'own_archive_members': len(files), 'archive_bytes': archive.stat().st_size, 'publication_files': len(prepared)}))


if __name__ == '__main__': main()
