"""Central, immutable-by-default configuration for the HierGrid revision.

The defaults reproduce paths and limits recovered from the frozen Phase-1 and
Phase-2G sources.  Environment variables may relocate files without editing
the frozen originals.  Importing this module never creates or modifies files.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Iterable


def _env_path(name: str, default: Path) -> Path:
    value = os.environ.get(name)
    return Path(value).expanduser() if value else default


# ---------------------------------------------------------------------------
# Frozen inputs (read-only by protocol)
# ---------------------------------------------------------------------------
COLAB_ROOT = _env_path("HIERGRID_COLAB_ROOT", Path("/content"))
PHASE1_ROOT = _env_path("HIERGRID_PHASE1_ROOT", COLAB_ROOT / "hiergrid_phase1")
PHASE2_ROOT = _env_path("HIERGRID_PHASE2_ROOT", COLAB_ROOT / "hiergrid_phase2")

FROZEN_NETWORK_PATH = _env_path(
    "HIERGRID_FROZEN_NETWORK",
    PHASE1_ROOT / "testbeds" / "saved_nets" / "federation_4mg_ieee118.json",
)
FROZEN_METADATA_PATH = _env_path(
    "HIERGRID_FROZEN_METADATA",
    PHASE1_ROOT / "testbeds" / "metadata" / "federation_4mg_ieee118_metadata.json",
)
FROZEN_MODEL_PATH = _env_path(
    "HIERGRID_FROZEN_MODEL",
    PHASE2_ROOT / "models" / "zone_agent_shared_lora_qwen05b_ultra_v1",
)

PHASE1_SOURCE_PATH = _env_path(
    "HIERGRID_PHASE1_SOURCE", COLAB_ROOT / "phase1_testbed_builders_colab.py"
)
PHASE2D_SOURCE_PATH = _env_path(
    "HIERGRID_PHASE2D_SOURCE",
    COLAB_ROOT / "phase2d_iterative_blackboard_v2_deficit_aware.py",
)
PHASE2G_MULTIAGENT_SOURCE_PATH = _env_path(
    "HIERGRID_PHASE2G_MULTIAGENT_SOURCE",
    COLAB_ROOT / "phase2g_multiagent_llm_runner.py",
)
PHASE2G_RESCUE_SOURCE_PATH = _env_path(
    "HIERGRID_PHASE2G_RESCUE_SOURCE", COLAB_ROOT / "phase2g_rescue_runner.py"
)
PHASE2G_GUIDED_SOURCE_PATH = _env_path(
    "HIERGRID_PHASE2G_GUIDED_SOURCE",
    COLAB_ROOT / "phase2g_llm_guided_rescue_runner.py",
)
REFLECTION_V4_SOURCE_PATH = _env_path(
    "HIERGRID_REFLECTION_V4_SOURCE",
    COLAB_ROOT / "run_reflection_v4_safety_envelope.py",
)


# ---------------------------------------------------------------------------
# New revision outputs.  Frozen paths above must never be write targets.
# ---------------------------------------------------------------------------
REVISION_ROOT = _env_path("HIERGRID_REVISION_ROOT", COLAB_ROOT / "hiergrid_revision")
UNSEEN_BANK_ROOT = _env_path(
    "HIERGRID_UNSEEN_BANK_ROOT",
    REVISION_ROOT / "scenario_banks" / "unseen_federation_v1",
)
UNSEEN_ALL_CANDIDATES_DIR = UNSEEN_BANK_ROOT / "all_candidates"
UNSEEN_SCENARIO_DIR = UNSEEN_BANK_ROOT / "scenarios"
UNSEEN_REPORT_DIR = UNSEEN_BANK_ROOT / "reports"
REVISION_RESULTS_ROOT = REVISION_ROOT / "results"


# ---------------------------------------------------------------------------
# Locked electrical/controller limits recovered from the existing runners.
# ---------------------------------------------------------------------------
V_MIN_PU = 0.95
V_MAX_PU = 1.05
HARD_OV_PU = 1.06
ITERATION_LIMIT = 25
Q_CANDIDATES_MVAR = (25.0, 50.0, 75.0, 100.0, 125.0, 150.0, 200.0, 250.0, 300.0)
MAX_ABS_Q_PER_BUS_MVAR = 450.0

PF_ALGORITHM = "nr"
PF_INIT = "auto"
PF_MAX_ITERATIONS_SCENARIO_FILTER = 50
PF_MAX_ITERATIONS_CONTROLLER = 80
PF_ENFORCE_Q_LIMITS = True
PF_CALCULATE_VOLTAGE_ANGLES = True

MAX_SEQUENCE_LENGTH = 4096
MAX_NEW_TOKENS = 384
DECODE_DO_SAMPLE = False


# ---------------------------------------------------------------------------
# Unseen-bank protocol.  Generation is deterministic; seeds are recorded for
# future extensions and for analyses that use resampling.
# ---------------------------------------------------------------------------
EXPERIMENT_SEED = 20260916
BOOTSTRAP_SEED = 20260917
BOOTSTRAP_REPLICATES = 10_000
UNSEEN_LOAD_FACTORS = (1.30, 1.40)
HISTORICAL_COMBINED_LOAD_FACTORS = (1.25, 1.35, 1.50)
TARGET_CONVERGED_SCENARIOS_MIN = 50
TARGET_CONVERGED_SCENARIOS_MAX = 80
UNSEEN_BANK_LABEL = "post_training_ieee118_combined_1p30_1p40_v1"


EXPERIMENT_LABELS: Dict[str, str] = {
    "dff": "DFF",
    "dff_alt": "DFF-ALT",
    "d_se": "D-SE",
    "hg_vf": "HG-VF",
    "hg_se": "HG-SE",
    "centralized": "HG-CENTRAL",
    "acopf": "AC-OPF/ORPD reference",
}


def frozen_inputs() -> Dict[str, Path]:
    """Return the canonical frozen artifacts used across revision scripts."""
    return {
        "network": FROZEN_NETWORK_PATH,
        "metadata": FROZEN_METADATA_PATH,
        "model": FROZEN_MODEL_PATH,
        "phase1_source": PHASE1_SOURCE_PATH,
        "phase2d_source": PHASE2D_SOURCE_PATH,
        "phase2g_multiagent_source": PHASE2G_MULTIAGENT_SOURCE_PATH,
        "phase2g_rescue_source": PHASE2G_RESCUE_SOURCE_PATH,
        "phase2g_guided_source": PHASE2G_GUIDED_SOURCE_PATH,
        "reflection_v4_source": REFLECTION_V4_SOURCE_PATH,
    }


def validate_paths(names: Iterable[str]) -> None:
    """Fail loudly when requested frozen artifacts are unavailable."""
    known = frozen_inputs()
    unknown = sorted(set(names) - set(known))
    if unknown:
        raise KeyError(f"Unknown frozen input keys: {unknown}")
    missing = {name: str(known[name]) for name in names if not known[name].exists()}
    if missing:
        details = "\n".join(f"  {name}: {path}" for name, path in missing.items())
        raise FileNotFoundError(f"Required frozen inputs are missing:\n{details}")


def assert_output_is_not_frozen(path: Path) -> None:
    """Prevent accidental writes into any frozen file or model directory."""
    target = path.expanduser().resolve(strict=False)
    for name, frozen in frozen_inputs().items():
        frozen_resolved = frozen.expanduser().resolve(strict=False)
        if (
            target == frozen_resolved
            or frozen_resolved in target.parents
            or target in frozen_resolved.parents
        ):
            raise ValueError(f"Refusing to write inside frozen input '{name}': {target}")
