"""Exact prospective warm/cold input identities, no solver or launch permission."""
import copy,hashlib,json,os,time
from pathlib import Path
import pandapower as pp
from full_receding_paid_campaign_20261015 import R,B as OLD,read,put,sha,pin,METHODS
from equal_operation_benchmark_v2 import decode_capsule
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible
from joint_reallocation_opportunity_core_v1 import load_endpoint
from frozen_physics_loader import load_stack
from lazy_paid_lineage_receipts_v1_20261018 import ArchivedLineage
import paid_receding_referenced_commit_v2_20261018 as transport
B=R/'outputs/registry_following_engineering_input_preparation_v2_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();p=read(OLD/'Protocol.json');pin(p)
    calls=[]
    def forbidden(*a,**k):calls.append(True);raise AssertionError('Input preparation cannot do physics')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,forbidden)
    result=read(OLD/'actual/Result.json');scope=read(R/'outputs/all_recorded_receding_commits_audit_20261018/Independent_Scoped_Audit.json')
    assert scope['status']=='PASS_ALL_RECORDED_COMMITTED_TRANSITIONS_AND_CLOSED_ENDPOINTS_SCOPED_ONLY' and scope['all_recorded_commits_checked']==26
    put(B/'Protocol.json',{'role':'PROSPECTIVE_SOURCE_INPUTS_ONLY_FOR_NEW_VERIFIED_REGISTRY_ENGINEERING',
        'source_sha256':sha(Path(__file__)),'bound_seconds':300,
        'selection':'First original declared unclosed branch in original endpoint/method order; its latest recorded observed commit after the last complete source checkpoint. Two full-current eligible identities in ascending actionSHA order absent from inspected attempt lineage. Global relevant-contract coverage still mandatory before any primary science.',
        'gates':'No solver/forecast/derivative/model call. No old owner/RNG/checkpoint resume or performance result. Source cursor resources remain original25 budget/450cap/no refund/9Q/common raw scope.',
        'no_science_launch_permission':True})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    closed={(x['world'],x['mode']) for x in result['branches']}
    entry,method=next((e,m) for e in p['endpoints'] for m in METHODS if (e['world'],m) not in closed)
    journal=OLD/'actual/scientific.jsonl';size=journal.stat().st_size
    assert sha(journal)==scope['journal_SHA256']==read(OLD/'actual/Closed_Manifest.json')['members']['scientific.jsonl']['sha256']
    start=max(0,size-4*1024**2)
    with journal.open('rb') as f:
        f.seek(start)
        if start:f.readline()
        matches=[]
        while line:=f.readline():
            end=f.tell();e=json.loads(line)
            if e['event']=='actual_receding_first_commit' and e['data']['world']==entry['world'] and e['data']['method']==method:
                matches.append({'event':e,'reference':{'offset':end-len(line),'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()}})
    assert matches,'Observed source commit must exist; never infer it'
    selected=max(matches,key=lambda m:m['reference']['offset']);record=selected['event']['data']['record'];receipt=record['replay_receipt']
    with (OLD/'actual/capsules.bin').open('rb') as f:after=decode_capsule(f,receipt['after'])['net']
    cursor=copy.deepcopy(record['following_cursor']);old_mode=cursor['commit_mode'];cursor['commit_mode']=transport.MODE;transport.validate(after,cursor)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    domain=build_current_domain(after,cursor,runner=runner,zones=zones);cursor=domain['expanded_cursor_for_separately_fixed_future_protocol']
    current=point_key(after,cursor);archive=ArchivedLineage()
    eligible=[r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if resource_eligible(r,cursor)]
    candidates=[r for r in sorted(eligible,key=action_key) if current+'|'+action_key(r) not in archive.index]
    assert len(candidates)>=2
    source_checkpoint=result['checkpoint_requests'][-1]
    import paid_receding_commit_and_history_v1 as original_state
    saved=original_state.restore(R/source_checkpoint['checkpoint'],source_checkpoint['receipt'])
    assert saved['cursor']['world']==entry['world'] and saved['cursor']['committed_transitions']==record['following_cursor']['committed_transitions'][:-1]
    original=saved['net'];before=copy.deepcopy(saved['cursor']);before['commit_mode']=transport.MODE;transport.validate(original,before)
    old_key=point_key(original,before)+'|'+action_key(record['candidate']);assert old_key in archive.index
    details={'status':'PASS_EXACT_OBSERVED_SOURCE_CURRENT_CURSOR_AND_HASH_ORDERED_PENDING_CANDIDATES',
        'source_entry':entry,'method':method,'source_before_checkpoint':source_checkpoint,'selected_source_commit_reference':selected['reference'],'selected_source_commit_record':record,
        'selected_paid_old_input_key':old_key,'observed_after_point_key':current,'current_metrics':runner.rescue.grid_metrics(after),
        'current_resource_cursor':cursor,'source_old_MODE_preserved_as_provenance':old_mode,
        'candidate_following_rows':candidates[:2],'candidate_following_keys':[current+'|'+action_key(r) for r in candidates[:2]],
        'eligible_rows':len(eligible),'absent_from_inspected_lineage':len(candidates),'all_current_native_rows':len(domain['all_declared_original9Q_ordinary_and_owned_joint_identities']),
        'global_unexecuted_status':'UNKNOWN_PENDING_RELEVANT_CONTRACT_HISTORY_CLOSURE_NOT_PERMISSION',
        'planned_roles_only':['One independently charged selected old commit replay for a NEW engineering branch','One warm following primary query ONLY if independent relevant-contract attempt closure passes','One different cold following query ONLY after exact full-state restoration and same attempt closure'],
        'new_independent_seed_if_justified_owner_is_frozen':20261018,'old_missing26th_RNG_or_checkpoint_reconstructed':False,
        'original_journal_sha256':scope['journal_SHA256'],'inspected_lineage_anchor':archive.anchors,
        'all_new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,'no_owner_or_scientific_launch':True}
    assert not calls and time.perf_counter()-started<300
    put(B/'Prepared_Inputs.json',details);put(B/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()},'new_science':0})
    print(json.dumps({'engineering_input_preparation':'PASS','world':entry['world'],'known_lineage_absent_candidates':len(candidates),'global_unexecuted':'UNKNOWN_PENDING_COVERAGE','science':0}))
if __name__=='__main__':main()
