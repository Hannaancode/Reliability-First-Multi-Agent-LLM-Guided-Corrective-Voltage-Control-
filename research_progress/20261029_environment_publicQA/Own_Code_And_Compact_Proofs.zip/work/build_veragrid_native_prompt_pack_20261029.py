"""Package the exact no-tool source prompts without invoking any model or solver."""
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from datetime import datetime, timezone
import ast, hashlib, json, re

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/veragrid_native_prompt_contract_20261029'
A = R / 'outputs/veragrid_source_admission_20261029'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def put(p, obj):
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', 'utf-8')

def blob(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

def main():
    out = O / 'participant'
    assert not out.exists()
    pinned = json.loads((O / 'Pinned_Input_Files.json').read_text())
    source_rows = []
    for row in pinned['files']:
        p = O / 'source' / row['path']
        b = p.read_bytes()
        if blob(b) != row['sha'] and b.endswith(b'\n') and blob(b[:-1]) == row['sha']:
            put(O / 'Circuit_Transfer_Newline_Correction.json', {'file': row['path'], 'extra_terminal_newline_removed': True,
                'before_sha256': sha(p), 'reason': 'Text-file transfer appended a terminal newline; exact pinned bytes required before parsing.', 'new_science': 0})
            p.write_bytes(b[:-1]); b = p.read_bytes()
        assert blob(b) == row['sha'] and len(b) == row['size'], row['path']
        source_rows.append({'path': row['path'], 'bytes': len(b), 'git_blob': row['sha'], 'sha256': sha(p)})
    runner = ast.parse((O / 'source/benchmark_runner.py').read_text('utf-8'))
    evaluator = ast.parse((A / 'source/evaluator.py').read_text('utf-8'))
    names = ['build_benchmark_circuit_context', 'question_block', 'no_tool_prompt', 'extract_final_letter']
    selected = [next(n for n in runner.body if isinstance(n, ast.FunctionDef) and n.name == name) for name in names]
    selected += [next(n for n in evaluator.body if isinstance(n, ast.FunctionDef) and n.name == 'extract_letter')]
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom)) for f in selected for n in ast.walk(f))
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
                   {'open', 'exec', 'eval', 'compile', '__import__', 'backend_call', 'run_no_tool', 'subprocess'} for f in selected for n in ast.walk(f))
    regex = next(n for n in runner.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'FINAL_LETTER_RE' for t in n.targets))
    assert ast.literal_eval(regex.value.args[0]) == r'\b([A-D])\b'
    ns = {'Any': Any, 'EvalQuestion': SimpleNamespace, 're': re, 'FINAL_LETTER_RE': re.compile(r'\b([A-D])\b')}
    exec(compile(ast.Module(body=selected, type_ignores=[]), 'pinned_pure_prompt_functions_only', 'exec'), ns)
    circuit = json.loads((O / 'source/eval_circuit.web.json').read_text('utf-8'))
    assert set(circuit) == {'GENERATORS', 'LOADS', 'LINES', 'LAYOUT'}
    field_sets = {'GENERATORS': {'bus', 'name', 'Pmin', 'Pmax', 'a', 'b', 'vset'},
                  'LOADS': {'bus', 'name', 'P', 'Q'}, 'LINES': {'from', 'to', 'name', 'r', 'x', 'b'}}
    for key, fields in field_sets.items():
        assert all(set(row) <= fields for row in circuit[key])
    context = ns['build_benchmark_circuit_context'](circuit)
    changed = dict(circuit, LAYOUT={'sentinel_ignored_metadata': 'NO_MODEL_REFERENCE_DATA'})
    assert ns['build_benchmark_circuit_context'](changed) == context
    views = json.loads((A / 'participant/Question_Views.json').read_text('utf-8'))['questions']
    assert len(views) == 150 and all(set(q) == {'question_id', 'question', 'options'} for q in views)
    records = []
    for q in views:
        assert len(q['options']) == 4 and [x[0] for x in q['options']] == ['A', 'B', 'C', 'D']
        # Intentionally lacks expected answer, explanation or other administrator fields.
        prompt = ns['no_tool_prompt'](context, SimpleNamespace(**q))
        records.append({'question_id': q['question_id'], 'prompt': prompt})
    synthetic = [('A', 'A'), ('A then D', 'D'), ('I cannot answer', 'C'), ('', '?'), ('?', '?'), ('option b', 'B'), ('A or B but D', 'D')]
    checks = []
    for text, expected in synthetic:
        actual = ns['extract_final_letter'](text)
        assert actual == expected
        strict = text.strip() if text.strip() in 'ABCD' and len(text.strip()) == 1 else '?'
        checks.append({'synthetic_response': text, 'native_final_parser': actual, 'strict_secondary': strict})
    assert ns['extract_letter']('A then D') == 'A' and ns['extract_final_letter']('A then D') == 'D'
    out.mkdir()
    put(out / 'Native_NoTool_Prompts.json', {'mode': 'no_tool', 'questions': records})
    report = {'at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'COMPLETE_AWAITING_SEPARATE_PROMPT_RECONSTRUCTION',
              'source_files': source_rows, 'protocol_sha256': sha(O / 'Prospective_Prompt_Pack_Protocol.json'),
              'source_function_ast': {n.name: hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest() for n in selected},
              'participant_input_sha256': sha(A / 'participant/Question_Views.json'),
              'prompt_pack_sha256': sha(out / 'Native_NoTool_Prompts.json'), 'records': 150,
              'prompt_character_range': [min(len(x['prompt']) for x in records), max(len(x['prompt']) for x in records)],
              'source_context_characters': len(context), 'circuit_counts': {k: len(circuit[k]) for k in field_sets},
              'synthetic_parser_checks': checks, 'source_order_preserved': True, 'labels_read': False,
              'source_runner_imported_or_executed': False, 'new_model_PF_OPF_training_GPU_calls': 0,
              'limits': 'No token fit, actual model identity/loader, CLI/runtime equivalence, performance or untouched-confirmation claim.'}
    put(O / 'Prompt_Pack_Result.json', report)
    print(json.dumps({k: report[k] for k in ['status', 'records', 'prompt_character_range', 'circuit_counts', 'new_model_PF_OPF_training_GPU_calls']}))

if __name__ == '__main__':
    main()
