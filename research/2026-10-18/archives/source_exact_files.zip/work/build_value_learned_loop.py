"""Create a separate proposal-dispatch clone; preserve sealed CPU prototype."""
from pathlib import Path
import ast
import hashlib

ROOT = Path(__file__).resolve().parent
source = ROOT/'value_closed_loop_cpu.py'
target = ROOT/'value_learned_closed_loop.py'
assert not target.exists(), 'Preserve existing implementation'
before = hashlib.sha256(source.read_bytes()).hexdigest()
old = source.read_text()
replacements = [
    ('from value_candidate_ordering import universe, order', 'from value_candidate_ordering import universe\nfrom value_live_zonal_proposer import decision_order'),
    ('total_pf_cap=512, seed=20261007):', 'total_pf_cap=512, seed=20261007, proposer=None):'),
    ("if policy not in ('frozen_enumeration', 'lowest_voltage', 'seeded_random'):", "if policy not in ('frozen_enumeration', 'lowest_voltage', 'seeded_random', 'bus_first_voltage', 'zonal_LoRA_prefix', 'zonal_base_prefix'):"),
    ("raise ValueError('Learned closed-loop inference is not wired or validated')", "raise ValueError('Unknown prospective ordering policy')\n    if policy.startswith('zonal_') and not callable(proposer):\n        raise ValueError('Learned policy requires per-state live proposer; no saved reply substitution')"),
    ("'new_model_calls': 0, 'learned_loop_implemented': False,", "'new_model_calls': 0, 'software_fixture_generation_entries': 0,\n              'learned_loop_implemented': True, 'model_identity_audit_pending': True,"),
    ("                    candidates, _ = order(allowed, policy,\n                        voltages={b: float(net.res_bus.vm_pu.at[b]) for b in buses},\n                        seed=seed + iteration)",
     "                    candidates, ordering_audit, batch = decision_order(pp, runner, net, zones, reports, allowed, policy, seed + iteration, iteration + 1, proposer)\n                    if batch is not None:\n                        key = 'software_fixture_generation_entries' if batch['evidence_kind'] == 'software_fixture' else 'new_model_calls'\n                        result[key] += batch['costs']['generation_entries']"),
    ("                    accepted = []", "                    row.update(ordering_audit=ordering_audit, per_state_proposal_batch=batch)\n                    accepted = []"),
]
for left, right in replacements:
    assert old.count(left) == 1, left
    old = old.replace(left, right)
module = ast.parse(old)
module.body[0].value.value = ('Separate learned-dispatch development loop. Reuses the preserved numerical prototype. '
    'No allocation/model loading/experiment claims. Per-state live proposal identity and actual inference require audited runtime evidence; software fixtures remain labelled.')
target.write_text(ast.unparse(module) + '\n')
assert hashlib.sha256(source.read_bytes()).hexdigest() == before
print('SEPARATE_LEARNED_DISPATCH_IMPLEMENTATION_CREATED')
