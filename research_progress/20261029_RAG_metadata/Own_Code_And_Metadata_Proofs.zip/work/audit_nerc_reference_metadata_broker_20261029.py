"""Independent saved-output reader; does not execute the metadata implementation."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, zipfile
from html.parser import HTMLParser
R=Path(__file__).resolve().parents[1]
O=R/'outputs/nerc_reference_metadata_broker_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':self.links.append(dict(attrs).get('href'))
def main():
    target=O/'Independent_Saved_Output_Audit.json'
    if target.exists():raise RuntimeError('reader_already_closed')
    protocol=json.loads((O/'Protocol.json').read_text('utf-8'))
    result=json.loads((O/'Result.json').read_text('utf-8'))
    rows=json.loads((O/'All_Fixed_Checks_LOCAL_ONLY.json').read_text('utf-8'))
    assert sha(O/'All_Fixed_Checks_LOCAL_ONLY.json')==result['all_checks_sha256']
    assert sha(R/'work/nerc_reference_metadata_broker_20261029.py')==protocol['implementation_sha256']
    assert sha(R/'work/check_nerc_reference_metadata_broker_20261029.py')==protocol['runner_sha256']
    with zipfile.ZipFile('C:/Users/HOME/Downloads/PowerGridQA-main.zip') as z:raw=z.read(protocol['member'])
    assert hashlib.sha256(raw).hexdigest()==protocol['expected_sha256']==result['source_sha256']
    source=json.loads(raw.decode('utf-8-sig'));assert len(source)==98
    seen=set();counts=Counter()
    for row in rows:
        label=row['label'];assert label not in seen;seen.add(label)
        req=row['request'];got=row['result'];counts[got['status']]+=1
        links=Links();links.feed(row['html'])
        if label.startswith('malformed:'):
            assert got['status']=='REJECTED' and links.links==[];continue
        key=req['document_id'];field=req['field'];assert key in source
        if label.endswith(':wrong_url'):
            assert req['value']!=source[key] and got['status']=='REJECTED' and links.links==[]
        elif ':absent:' in label:
            assert field in {'author','year','page','equation'} and got['status']=='NOT_STATED'
            assert 'value' not in got and links.links==[]
        else:
            assert field in {'document_id','url'} and got['status']=='REGISTERED_METADATA'
            assert got['value']==(key if field=='document_id' else source[key])
            assert got['citation']=={'document_id':key,'url':source[key]} and links.links==[source[key]]
        assert got['registry_sha256']==protocol['expected_sha256']
        assert got['provenance_scope']=='LOCAL_REGISTERED_REFERENCE_MAPPING_ONLY'
        assert got['linked_document_retrieved'] is False and got['answer_truth']=='NOT_ASSESSED'
    required={f'{k}:{op}:{f}' for k in source for op in ['lookup','verify'] for f in ['document_id','url']}
    required|={f'{k}:wrong_url' for k in source}
    required|={f'{k}:absent:{f}' for k in source for f in ['page','year','author','equation']}
    required|={f'malformed:{i}' for i in range(10)}
    assert seen==required and len(rows)==892
    assert counts=={'REGISTERED_METADATA':392,'NOT_STATED':392,'REJECTED':108}
    assert len(result['loader_negative_checks'])==4 and all(r['status']=='REJECTED' for r in result['loader_negative_checks'])
    out={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_INDEPENDENT_ALL_ENTRY_VALUES_MEMBERSHIP_AND_CITATIONS',
         'all98entries_covered':True,'all892_saved_responses_checked':True,'status_counts':dict(counts),
         'producer_result_sha256':sha(O/'Result.json'),'source_sha256':result['source_sha256'],
         'reader_sha256':sha(Path(__file__)),'new_model_retrieval_PF_training_calls':0,
         'no_producer_import_or_execution':True,'limits':'Metadata mapping only; loader negatives are preserved producer outcomes, not independently re-executed. No linked document retrieval, arbitrary prose entailment, historical 200-case replication, or end-to-end RAG guarantee.'}
    target.write_text(json.dumps(out,indent=2)+'\n','utf-8');print(json.dumps(out))
if __name__=='__main__':main()
