# Reviewer experiment closure

Updated 2026-10-08T00:36:27.438253+00:00.

Four concerns from supplied reviewer-plan paraphrase; verbatim reviewer email not present. This is experimental closure, not a claim of reviewer acceptance.

All four planned experiments complete: **True**.

| Step | Task | Status | Evidence / next requirement |
|---:|---|---|---|
| 1 | Confirm saved checkpoints | complete | 62 main case and RNG files verified |
| 2 | Preserve and verify frozen assets | complete | Model/network/settings/bank/source hashes |
| 3 | Reuse existing Google authentication | complete | Existing ADC refreshed; no secrets copied |
| 4 | Diagnose setup and verify current Colab GPU | complete | Actual isolated-account Tesla T4, CUDA tensor execution, and frozen environment verified |
| 5 | Complete AC reference campaign | complete | 62/62 complete records; frozen protocol preserved |
| 6 | Validate central historical GPU cases | complete | Both original historical GPU cases passed the frozen structural, context, diversity, and physical/numerical criteria |
| 7 | Complete central/zonal matched bank | complete | 62/62 complete records |
| 8 | Finalize main paired analysis | complete | Full bank, clustered uncertainty, pilot/family sensitivity, failures and charged costs |
| 9 | Consolidate physical validity and reference effort | complete | Main physical audit complete; reference/central integration pending |
| 10 | Close reviewer evidence and reproducibility package | complete | All four reviewer evidence gates required; full security evaluation awaits baseline closure; historical security development tracked separately |

## Comment 1: LLM complementarity versus deterministic trajectory diversity

Status: **experimental_evidence_complete_with_null_or_adverse_result**.

No residual-UV advantage of HG-SE over the specified D-SE. Fewer PF calls accompany greater wall time; common DFF was selected by HG-SE in every valid case.

Evidence: [matched_campaign_protocol.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/matched_campaign_protocol.json>), [dff_alt_development_validation.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/dff_alt_development_validation.json>), [main_campaign_detailed_audit.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/main_campaign_detailed_audit.json>), [matched_campaign_family_analysis.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/matched_campaign_family_analysis.json>), [physical_effort_ledger.csv](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/physical_effort_ledger.csv>).


## Comment 2: Evaluation on unseen physical operating points

Status: **archived_input_and_bank_evidence_complete_with_lineage_and_family_limits**.

No exact physical-modification overlap with recovered train/val/test or historical cases; all62 share training outage/DER patterns. Prior pilot awareness and incomplete final-adapter training invocation history are disclosed; no broad OOD claim.

Evidence: [frozen_input_verification.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/frozen_input_verification.json>), [recovered_training_provenance_assets.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/recovered_training_provenance_assets.json>), [training_bank_physical_overlap.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/training_bank_physical_overlap.json>), [main_campaign_detailed_audit.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/main_campaign_detailed_audit.json>).


## Comment 3: Centralized versus four-zone proposer

Status: **experimental_evidence_complete**.

See complete standalone/envelope results and physical replay; claims are conditional on the frozen zonally trained adapter.

Evidence: [central_ablation_development_checks.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/central_ablation_development_checks.json>), [next_gpu_stage_status.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/next_gpu_stage_status.json>), [colab_frozen_restore_status.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/colab_frozen_restore_status.json>), [central_gpu_development_validation.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/central_gpu_development_validation.json>), [central_experiment_protocol.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/central_experiment_protocol.json>).


## Comment 4: Conventional AC optimization/ORPD reference

Status: **experimental_evidence_complete_with_declared_relaxation_limits**.

62/62 reference records; 56 independently checked voltage-only references currently found. Full operating-limit feasibility is excluded by fixed-P slack balance; local solve failures are separate from infeasibility.

Evidence: [ac_reference_campaign_protocol.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/ac_reference_campaign_protocol.json>), [ac_reference_development_validation.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/ac_reference_development_validation.json>), [ac_reference_bank_summary.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/ac_reference_bank_summary.json>), [fixed_p_feasibility_audit.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/fixed_p_feasibility_audit.json>).


## Paper and justification

[HierGrid_Revision_Sections.md](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/HierGrid_Revision_Sections.md>) contains focused replacement sections based on confirmed results. [Experiment_Method_Justification.md](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/Experiment_Method_Justification.md>) connects design decisions to primary literature. Central and full-reference conclusions remain explicit pending sections until their data are complete.

Full security evaluation awaits audited baseline closure. Authorized historical development is tracked separately in [security/Experiment_Protocol.md](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/security/Experiment_Protocol.md>). The original paper, model, settings, and locked bank are preserved.

Additional completed checks: [effective_operating_point_overlap.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/effective_operating_point_overlap.json>) compares the actually applied physical inputs, and [physical_trajectory_validity.json](<C:/Users/HOME/Documents/Codex/2026-10-06/files-mentioned-by-the-user-hiergrid/outputs/physical_trajectory_validity.json>) aggregates all initial and accepted-action replay states. The completion gates above retain every missing experimental dependency.