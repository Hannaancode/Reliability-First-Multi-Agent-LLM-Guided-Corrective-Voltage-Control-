"""Freeze source/support/economic gates for a distinct native-trained model upgrade, zero science."""
import json,hashlib,ast,pickle,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_action_upgrade_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();import stable_ddpg_native_bridge_20261020 as b
    from candidate_process_evidence_utils import frozen_checks
    from native_upgrade_support_engine_20261020 import signature
    np=b.np;env,proxy,source=b.environment();captured=[]
    def mock(net,*args,**kwargs):
        assert not args and kwargs=={'algorithm':'bfsw'};captured.append({k:net[t][c].to_numpy(copy=True) for k,t,c in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]});net['res_bus']=b.pd.DataFrame({'vm_pu':np.ones(13)},index=net.bus.index)
    proxy.runpp=mock;seeds=list(range(500,508))
    for seed in seeds:env.reset(seed)
    arrays={k:np.stack([c[k] for c in captured]) for k in captured[0]};old=np.load(ROOT/'outputs/stable_ddpg_native500_input_roster_20261020/All500_Native_Physical_Input_Recipes.npz');kinds=[]
    def vector_hash(values,i):
        h=hashlib.sha256()
        for k in sorted(values):h.update(k.encode());h.update(values[k][i].tobytes())
        return h.hexdigest()
    oldhash={vector_hash(old,i) for i in range(500)};newhash=[]
    for pos,seed in enumerate(seeds):
        rng=np.random.RandomState(seed);kind=int(rng.choice([0,1]));kinds.append(kind);p=np.zeros(12);q=np.zeros(12)
        if kind==0:p[0]=-.5*rng.uniform(1,7);p[1]=-.8*rng.uniform(1,4);p[2]=-.3*rng.uniform(1,5)
        else:p[0]=rng.uniform(.5,4);p[1]=rng.uniform(0,4.51);p[2]=rng.uniform(0,5);q[3]=.3*rng.uniform(0,.2);p[4]=.5*rng.uniform(2,3);q[5]=.4*rng.uniform(0,10);p[10]=rng.uniform(.2,3);p[11]=rng.uniform(0,1.5)
        assert np.array_equal(p,arrays['sgen_p'][pos]) and np.array_equal(q,arrays['sgen_q'][pos]) and np.all(arrays['load_p'][pos]==0) and np.all(arrays['load_q'][pos]==0);newhash.append(vector_hash(arrays,pos))
    assert len(set(newhash))==8 and not (set(newhash)&oldhash);np.savez(OUT/'All8_New_Source_Physical_Inputs.npz',**arrays)
    relevant=[];old_signatures=set()
    for folder in ['stable_ddpg_native_engineering_20261020','stable_ddpg_native_remaining_engineering_v2_20261020','stable_ddpg_native_episode_20261020']:
        for f in (ROOT/'outputs'/folder).rglob('*before.pkl'):
            with f.open('rb') as z:net=pickle.load(z)
            assert len(net.bus)==13;old_signatures.add(signature(net));relevant.append({'path':f.relative_to(ROOT).as_posix(),'sha256':sha(f)})
    # Absence check against each actual relevant native13 action input, not merely seed labels.
    for pos in range(8):
        for k,t,c in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:env.network[t][c]=arrays[k][pos].copy()
        assert signature(env.network) not in old_signatures
    put(OUT/'Relevant_Actual13_And_All500_Input_Closure.json',{'status':'PASS_ALL8_ROOT_VECTORS_AND_RELEVANT_ACTUAL_NATIVE_INPUTS_DISTINCT','fixed_seeds':seeds,'all8_hashes':newhash,'no_match_all500_source_recipes':True,'actual_prior_native13_inputs_checked':len(relevant),'actual_unique_prior_input_signatures':len(old_signatures),'prior_inputs':relevant,'scope':'Knownsourcepinnednative13physicalroots/actions/readers;priorMAPDN33/141/322andfederation118differinbusuniverse. Not a universal historicalabsence theorem or standalonepermissiontoexecute. Newruntimealsofailsclosedonpaidinput/newinitializercollision.','source_low_high_branch_are_not_physical_labels':kinds,'new_real_model_PF_calls':0})
    sources=['work/native_upgrade_support_engine_20261020.py','work/run_native_upgrade_support_20261020.py','work/audit_native_upgrade_support_20261020.py','work/stable_ddpg_native_bridge_20261020.py']
    for n in sources:ast.parse((ROOT/n).read_text(encoding='utf-8'))
    inputs={'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz':sha(ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz'),'outputs/native_action_upgrade_preparation_20261020/All8_New_Source_Physical_Inputs.npz':sha(OUT/'All8_New_Source_Physical_Inputs.npz')}
    for n in ['safeDDPG.py','env_single_phase_13bus.py','case_13.mat']:
        f=b.AUTHOR/n
        if f.exists():inputs[f.relative_to(ROOT).as_posix()]=sha(f)
    # Actual create_13bus filename is source bound: pin every MATLAB input in that official root.
    for f in b.AUTHOR.rglob('*.mat'):inputs[f.relative_to(ROOT).as_posix()]=sha(f)
    for alg in ['safe-ddpg','linear','ddpg']:
        for i in range(3):f=b.AUTHOR/f'checkpoints/single-phase/13bus/{alg}/policy_net_checkpoint_a{i}.pth';inputs[f.relative_to(ROOT).as_posix()]=sha(f)
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scientific_question':'Before expensive native-action modelupgrade,do thefullsourcebaselines leave anyendpointUVheadroom on eight outcome-independentlyfixed NEWdevelopmentroots? Also measure fullstate/receipt support,perstepQcost andnativecontrolhorizon;noimitation/format orsize-onlywinclaim.','all8_development_seeds':seeds,'all8_generation_rule':'Ascending500..507 outsideofficial0..499testrecipes;chosenbeforephysics. Allbranches andfailed/partial/unexecuted identitiesretained,not unusedconfirmation.','algorithms':['safe-ddpg','linear','ddpg'],'native_original_maximum_steps':100,'worker_seconds':1200,'source_maximum_new_primary_PF_attempts':2408,'independent_replay_only_returned_unique_identities':True,'cold_proof':'FirstactualactionfrompersistedfullENV/Q/cursor/RNG/parameters/absolute-bound onfreshobjects eachbranch;allsubsequent returnedactions+physicalstates independentlyreexecutedbyseparatereader.','native_actuator':'Unchangedsourcefloat32rawincrementclip +/-0.3 then lastQ-u. First3sgencontrolled,buses2/7/9. No hiddenoldshuntconversion,rootoroutcomeretune.','stopping_rule':'Originalcontrolled3busdone only;recordALL13UV/OV/extremaandcumulativeQ_squared. No normalbandweakening orfavourablecase/iterationselection.','fixed_support_gate':'Onlyifall8x3episodescompletecanclassifyUVfloor. All24restored => no positiveendpointUVheadroomagainstthese3inthesefinite8worlds;donotspendonUV-onlySLMtrainingforthesamepointset. Ifresiduals exist,opportunityUNPROVEDuntilstrongsameinformationnumeric/economic/support/newmodelintegrationgate. AnyUNKNOWN => no pass/negative learningclaim. No automaticGPU/training.','sources':{n:sha(ROOT/n) for n in sources},'inputs':inputs,'no_scientific_retry_or_new_assignment':True,'independent_fields_tolerance':1e-10,'frozen_checks':frozen_checks()};put(OUT/'Protocol.json',protocol)
    for mode,sourcefile,out,coord in [('primary','work/run_native_upgrade_support_20261020.py','outputs/native_action_upgrade_support_20261020','outputs/native_action_upgrade_support_coordination_20261020'),('independent','work/audit_native_upgrade_support_20261020.py','outputs/native_action_upgrade_support_independent_20261020','outputs/native_action_upgrade_support_reader_coordination_20261020')]:
        put(OUT/(mode+'_Owner_Protocol.json'),{'single_owner':{'source':sourcefile,'sha256':sha(ROOT/sourcefile),'python':'work/vcsa_module_env/Scripts/python.exe','output':out,'coordination':coord,'bound_seconds':1250},'require_ended_claims':[] if mode=='primary' else ['outputs/native_action_upgrade_support_20261020/owner.claim'],'old_scientific_source_name':'run_native_upgrade_support_20261020.py'})
    put(OUT/'Readiness.json',{'status':'PASS_FIXED_ALL8_LITERAL_SOURCE_INPUT_PRIOR_ACTUAL_HISTORY_LOADER_STATIC_PERSISTENCE_AND_READER_LOCK_BEFORE_PERFORMANCE','all8_actual_physical_outcomes':'UNKNOWN','actual_model_PF_GPU_calls':0,'native_network_conversions':1,'labelled_mock_reset_callbacks':8,'full_source_AST_unchanged':source,'cold_full_state_and_exact_action_checks_in_actual_engine':True,'reader_hash':sha(ROOT/'work/audit_native_upgrade_support_20261020.py'),'workflow_seconds':time.monotonic()-start})
    print(json.dumps({'source_and_inputs':'PASS','new_development_seeds':seeds,'relevant_actual13_input_files':len(relevant),'source_only_gate':'ALL8_NOT_EXECUTED','new_model_PF_GPU_calls':0}))
if __name__=='__main__':main()
