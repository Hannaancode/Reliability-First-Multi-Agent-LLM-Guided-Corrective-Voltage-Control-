"""New input/label tensor readiness, not training or performance evidence."""
import candidate_process_runtime
import copy,gzip,hashlib,json,math,statistics,time
from pathlib import Path
from datetime import datetime,timezone
import torch
from candidate_process_tensor_inputs import compile_input,node_observables,NODE_FIELDS
from candidate_predictor_operational_state import augmented_model_input
from candidate_predictor_input_contract import canonical,Q_GRID
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
DATA=BASE/'input_and_target_contract_nullable_v2';SUPPORT=BASE/'current_added_support_observables';OUT=BASE/'tensor_readiness'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda v:hashlib.sha256(canonical(v).encode()).hexdigest()
def read_rows(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return [json.loads(s) for s in f]
def write(n,v):
    with (OUT/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
assert not OUT.exists();OUT.mkdir();(OUT/'inputs').mkdir();(OUT/'targets').mkdir()
started=time.perf_counter();torch.set_num_threads(2)
write('Preparation_Protocol.json',{'declared_at_utc':datetime.now(timezone.utc).isoformat(),
 'purpose':'Input-only compiler and actual-measurement masks; no training/performance',
 'original_world_split_unchanged':True,'known_prePF_cap_rules_shared_and_not_learned':True,
 'target_normalization':'Finite optimization-world actual global gains only',
 'node_normalization':'All239 optimization-world current states,118 buses,13 actual channels',
 'unknown_convergence_or_after_never_zero_imputed':True,'original_Q_grid':list(Q_GRID),
 'source_sha256':sha(Path(__file__)),'tensor_source_sha256':sha(ROOT/'work/candidate_process_tensor_inputs.py')})
for folder in (DATA,SUPPORT):
    for n,m in read(folder/'manifest.json').items():assert sha(folder/n)==m['sha256'] and (folder/n).stat().st_size==m['bytes']
assert read(BASE/'input_and_target_contract_operational_v3_audit/Independent_Current_Input_and_Measured_Target_Audit.json')['all_current_input_identity_scope_label_boundaries_passed']
inputs=read_rows(DATA/'Current_Input_Rows.jsonl.gz');labels=read_rows(DATA/'Measured_Target_Rows.jsonl.gz')
support={r['observation_id']:r for r in read_rows(SUPPORT/'Current_Control_State_Observables.jsonl.gz')}
assert len(inputs)==len(support)==311 and len(labels)==238
normal=read(DATA/'Input_Normalization.json');byid={r['observation_id']:r for r in inputs}
train=[r for r in inputs if r['split']=='optimization'];assert len(train)==239
raw_nodes=[];empty_tables={}
for row in inputs:
    obs=row['model_input']['current_physical_observation'];s=support[row['observation_id']]
    # Other topology types are not silently dropped; only their genuine absence permits this graph.
    for name in ('switch','impedance','trafo3w'):
        assert not obs['physical_tables'][name]['index'],name+' is present; graph prototype not ready'
        empty_tables[name]=empty_tables.get(name,0)+1
    nodes,_,_=node_observables(obs,s['added_abs_Q_MVAr_by_bus'])
    if row['split']=='optimization':raw_nodes.extend(nodes)
assert len(raw_nodes)==239*118
node_normal={'channels':list(NODE_FIELDS),'mean':[],'scale':[],'std':[],
 'optimization_inputs':239,'actual_bus_vectors':len(raw_nodes),'no_held_or_target_values':True}
for j in range(13):
    values=[r[j] for r in raw_nodes];mean=statistics.mean(values);std=statistics.pstdev(values)
    node_normal['mean'].append(mean);node_normal['std'].append(std);node_normal['scale'].append(std if std>=1e-6*max(1.,abs(mean)) else 1.)
gain_keys=('UV_gain','deficit_gain','vmin_gain','normal_upper_margin');samples=[]
for row in labels:
    if row['split']=='optimization':
        samples.extend([list(c['target']['measured_global_gains'][k] for k in gain_keys)
                        for c in row['measured_candidates'] if c['target']['has_finite_after_global_metrics']])
target_normal={'channels':list(gain_keys),'mean':[],'scale':[],'std':[],
 'fit':'finite optimization-world measured labels only','actual_finite_optimization_labels':len(samples)}
for j in range(4):
    values=[s[j] for s in samples];mean=statistics.mean(values);std=statistics.pstdev(values)
    target_normal['mean'].append(mean);target_normal['std'].append(std);target_normal['scale'].append(std if std>=1e-6*max(1.,abs(mean)) else 1.)
write('Node_Normalization.json',node_normal);write('Target_Normalization.json',target_normal)
index=[];target_index=[];cap_unknown=after_unknown=pair_count=0
for row in sorted(inputs,key=lambda r:r['observation_id']):
    ident=row['observation_id'];s=support[ident];aug=augmented_model_input(row['model_input']['current_physical_observation'],s['added_abs_Q_MVAr_by_bus'],450.)
    assert digest(aug)==s['augmented_model_input_sha256']
    value=compile_input(aug,normal,node_normal)
    assert len(value['field_ids'])>=10000 and value['node_features'].shape==(118,13)
    torch.save(value,OUT/'inputs'/f'{ident}.pt')
    index.append({'observation_id':ident,'world_sha256':row['world_sha256'],'split':row['split'],
        'augmented_raw_input_sha256':digest(aug),'tensor_path':f'inputs/{ident}.pt','tensor_sha256':sha(OUT/'inputs'/f'{ident}.pt'),
        'typed_records':len(value['field_ids']),'known_allowed_actions':int(value['allowed_actions'].sum()),
        'value_utf8_bytes':sum(map(len,value['value_bytes']))})
for row in labels:
    ident=row['observation_id'];x=torch.load(OUT/'inputs'/f'{ident}.pt',weights_only=True)
    target={'classification':torch.zeros(118,9,3),'classification_mask':torch.zeros(118,9,3,dtype=torch.bool),
        'regression':torch.zeros(118,9,4),'regression_mask':torch.zeros(118,9,4,dtype=torch.bool)}
    # Masked tensor padding is not a truth value: raw nullable records are separately preserved.
    for c in row['measured_candidates']:
        t=c['target'];b,j=t['bus'],t['Q_index'];v=t['recorded_verifier']
        if not bool(x['allowed_actions'][b,j]):
            assert not t['convergence_reported'] and v['after'] is None and not v['accepted'];cap_unknown+=1;continue
        for k,key in enumerate(('accepted','converged','UVzero')):
            truth=t['one_step_UV_zero'] if key=='UVzero' else v[key]
            if type(truth)is bool:target['classification'][b,j,k]=float(truth);target['classification_mask'][b,j,k]=True
        if t['has_finite_after_global_metrics']:
            for k,key in enumerate(gain_keys):
                target['regression'][b,j,k]=(t['measured_global_gains'][key]-target_normal['mean'][k])/target_normal['scale'][k]
                target['regression_mask'][b,j,k]=True
        else:after_unknown+=1
    assert bool(target['classification_mask'].any()) and bool(target['regression_mask'].any())
    pairs=target['regression_mask'][:,:-1]&target['regression_mask'][:,1:];pair_count+=int(pairs.sum())//4
    torch.save(target,OUT/'targets'/f'{ident}.pt')
    target_index.append({'observation_id':ident,'world_sha256':row['world_sha256'],'split':row['split'],
        'tensor_path':f'targets/{ident}.pt','tensor_sha256':sha(OUT/'targets'/f'{ident}.pt'),
        'actual_measured_candidates':len(row['measured_candidates']),
        'classification_masks':target['classification_mask'].sum((0,1)).tolist(),
        'finite_regression_candidates':int(target['regression_mask'].sum())//4,'actual_adjacent_Q_pairs':int(pairs.sum())//4})
write('Input_Index.json',index);write('Target_Index.json',target_index)
summary={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'current_input_tensors':len(index),'target_tensors':len(target_index),
 'actual_measured_state_actions_preserved':38727,'prePF_cap_unknown_not_learned':cap_unknown,
 'remaining_actual_missing_after_masked':after_unknown,'actual_adjacent_Q_pairs':pair_count,
 'actual_empty_other_topology_tables_verified':empty_tables,'node_channels':13,'typed_semantic_types':len(normal['typed_semantic_schema']),
 'preparation_wall_seconds':time.perf_counter()-started,'training_steps':0,'pretrained_model_PF_controller_cloud_calls':0,
 'all_inputs_actual_current_only_no_world_or_label_metadata_in_tensor':True,'no_LLMSuperiority_or_physical_policy_claim':True}
assert cap_unknown==219 and after_unknown==60
write('summary.json',summary)
members={p.relative_to(OUT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.rglob('*') if p.is_file()}
write('manifest.json',members);print(json.dumps(summary,indent=2))
