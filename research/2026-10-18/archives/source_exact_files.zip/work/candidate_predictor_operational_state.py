"""Conditional current-support derivation for the unchanged frozen testbed.

No missing shunt names are inserted into old observations. The derivation is
valid only after baseline/committed-prefix row identity proofs have passed.
Live deployment must use the original getter on the actual current network.
"""
import math
from candidate_predictor_input_contract import validate_observation,model_input
def support_from_verified_snapshot(observation,baseline_rows):
    validate_observation(observation)
    frame=observation['physical_tables']['shunt']
    rows={i:dict(zip(frame['columns'],v)) for i,v in zip(frame['index'],frame['values'])}
    if not set(baseline_rows)<=set(rows):raise ValueError('Frozen baseline rows must be present')
    for i,base in baseline_rows.items():
        for k in ('bus','q_mvar','p_mw'):
            if rows[i][k]!=base[k]:raise ValueError('Baseline shunt identity/value changed; no role inference')
    added=[0.]*118
    for i,row in rows.items():
        if i in baseline_rows:continue
        b=row['bus'];q=row['q_mvar']
        if type(b) not in (int,float) or int(b)!=b or not 0<=int(b)<118:raise ValueError('Native current bus required')
        if type(q) not in (int,float) or not math.isfinite(q) or q>=0:raise ValueError('Actual capacitive controller-added row required')
        added[int(b)]+=abs(float(q))
    return added
def augmented_model_input(observation,support,cap):
    if len(support)!=118 or any(type(x) not in (int,float) or not math.isfinite(x) or x<0 for x in support):
        raise ValueError('Exact current added-support vector required')
    if cap!=450.:raise ValueError('Original frozen cap only')
    result=model_input(observation)
    result['current_control_state']={'original_per_bus_added_support_cap_MVAr':cap,
                                     'added_abs_Q_MVAr_by_bus':list(support)}
    return result
