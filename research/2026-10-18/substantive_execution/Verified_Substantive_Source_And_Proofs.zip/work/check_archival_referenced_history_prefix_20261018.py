"""Real2580-receipt history prefix after append; live antirollback stays strict."""
import copy,hashlib,json,time
from pathlib import Path
from full_receding_paid_campaign_20261015 import read,put
from paid_receding_chunked_history_v2_20261018 import History
import bounded_chunk_evidence_store_v1_20261015 as live
import archival_referenced_history_prefix_v1_20261018 as archival
R=Path(__file__).resolve().parents[1];B=R/'outputs/archival_referenced_history_prefix_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'ARCHIVAL_READONLY_PREFIX_SOFTWARE_BOUNDARY_ON_REAL2580_QUERY_RECORD','source_sha256':sha(Path(archival.__file__)),'test_sha256':sha(Path(__file__)),
        'bound_seconds':180,'no_new_model_PF_optimizer_forecast_derivative_solve_calls':True,'live_restore_antirollback_must_remain_unchanged':True})
    old=read(R/'outputs/actual_journal_reference_history_20261018/Results.json');blocks=live.restore(old['anchor']);assert len(blocks)==1
    record=json.loads(blocks[0]['payload']);payload=record['payload'];refs=payload['query_references'];assert len(refs)==2580
    h=History(B/'history',source_anchor=old['anchor']['source_anchor'],input_anchor=old['anchor']['input_anchor'],max_bytes=16*1024**2)
    h.append(record['event'],payload);prefix=h.anchor();h.append('software_later_record',{'no_science':True});latest=h.anchor();h.close()
    args={'scientific_journal':refs[0]['journal'],'scientific_prefix_bytes':max(r['offset']+r['bytes'] for r in refs),'scientific_protocol':payload['scientific_protocol_sha256']}
    checks={};result=archival.read_archival_reference_prefix(prefix,**args)
    assert result['records'][0]==record and result['exact_referenced_queries']==2580 and result['execution_authorized'] is False
    checks['real2580_query_archived_prefix_exact_after_append']=True
    try:live.restore(prefix)
    except ValueError:checks['live_restore_still_rejects_stale_cursor']=True
    else:raise AssertionError('Live antirollback weakened')
    assert len(live.restore(latest))==2;checks['live_latest_anchor_still_passes']=True
    def reject(label,anchor=None,**kw):
        a=dict(args);a.update(kw)
        try:archival.read_archival_reference_prefix(anchor if anchor is not None else prefix,**a)
        except (ValueError,AssertionError):checks[label]=True
        else:raise AssertionError('Bad archival input accepted: '+label)
    reject('future_query_rejected',scientific_prefix_bytes=args['scientific_prefix_bytes']-1)
    reject('foreign_scientific_protocol',scientific_protocol='f'*64)
    reject('foreign_scientific_journal',scientific_journal='outputs/not_the_paid_journal.jsonl')
    bad=copy.deepcopy(prefix);bad['index_sha256']='0'*64;reject('changed_prefix_hash',bad)
    bad=copy.deepcopy(prefix);bad['source_anchor']='f'*64;reject('changed_source',bad)
    bad=copy.deepcopy(prefix);bad['index_bytes']-=1;reject('torn_prefix',bad)
    assert time.perf_counter()-started<180
    put(B/'Results.json',{'status':'PASS_REAL2580_REFERENCE_ARCHIVAL_PREFIX_AND_LIVE_ANTIROLLBACK_SEPARATION','checks':checks,
        'source_certificate':archival.SOURCE_CERTIFICATE,'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'One actual decision prefix/archive reader only; full new-owner scientific chain/cursor/receipt/cost and independent policy gates still required. Historical read-only acceptance is never live rollback authorization.'})
    print(json.dumps({'archival_prefix':'PASS','actual_queries':2580,'checks':len(checks),'science':0}))
if __name__=='__main__':main()
