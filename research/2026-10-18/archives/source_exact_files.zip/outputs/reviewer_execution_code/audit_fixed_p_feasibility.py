"""Necessary active-power balance check; no optimizer/control changes."""
from pathlib import Path
import copy,json,sys
import pandas as pd
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack
from ac_shunt_reference import fixed_p_balance_lower_bound
from physical_replay_audit import save
sys.stdout.reconfigure(encoding='utf-8')
v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
nonempty={k:len(v) for k,v in base.items() if isinstance(v,pd.DataFrame) and len(v) and not k.startswith('res_')}
extra=[t for t in ['ward','xward','motor','dcline','vsc'] if t in base and len(base[t])]
zip_columns=[c for c in base.load.columns if c.startswith(('const_z','const_i'))]
assumptions={'passive_line_r_nonnegative':bool((base.line.r_ohm_per_km>=0).all()),'passive_trafo_copper_loss_nonnegative':bool((base.trafo.vkr_percent>=0).all()),'passive_trafo_core_loss_nonnegative':bool((base.trafo.pfe_kw>=0).all()),'original_shunt_p_nonnegative':bool((base.shunt.p_mw>=0).all()),'scheduled_loads_constant_power':all(bool((base.load[c]==0).all()) for c in zip_columns),'other_power_injection_tables_absent':not extra,'frozen_storage_active_power_zero':bool((base.storage.p_mw==0).all()),'no_generator_slack':not bool(base.gen.slack.any()),'one_external_slack':len(base.ext_grid)==1,'controller_incremental_shunts_p_zero':True}
print('BALANCE_ASSUMPTIONS',json.dumps(assumptions),'extra_tables',extra,flush=True)
assert all(assumptions.values()),'Additional injections/loss conventions need explicit handling before a balance exclusion'
rows=[]
for p in sorted((ROOT/'bank/scenarios').glob('*.json')):
 net=copy.deepcopy(base);v2.v0.apply_scenario_to_net(net,json.loads(p.read_text()),zones);assert (net.storage.p_mw==0).all();b=fixed_p_balance_lower_bound(net)
 rows.append({'scenario_id':p.stem,**b,'declared_slack_p_limit_impossible_under_fixed_dispatch_and_fully_served_load':b['required_slack_before_nonnegative_losses_mw']>b['declared_ext_grid_max_p_mw_total']+1e-6})
report={'analysis':'Necessary active-power balance condition only; not a general AC feasibility proof. Cannot repair a violated slack active-power ceiling using zero-P reactive shunts while serving all frozen loads and preserving active dispatch.','assumptions_verified':assumptions,'nonempty_network_tables':nonempty,'locked_case_count':len(rows),'cases_excluded_by_necessary_fixed_p_condition':sum(x['declared_slack_p_limit_impossible_under_fixed_dispatch_and_fully_served_load'] for x in rows),'cases':rows}
save('outputs/fixed_p_feasibility_audit.json',report)
print('FIXED_P_BOUND_AUDIT',report['cases_excluded_by_necessary_fixed_p_condition'],'of',len(rows),'required_slack_mw_range',min(x['required_slack_before_nonnegative_losses_mw'] for x in rows),max(x['required_slack_before_nonnegative_losses_mw'] for x in rows),'limit',rows[0]['declared_ext_grid_max_p_mw_total'])
