"""Bind old component refs to necessary load/outage inputs for new four roots.

Reuses completed shunt-component certificates. Does not re-audit archives or
repeat physics. Only new necessary-input lookups are built for the controller.
"""
import copy, gzip, hashlib, json, os, pickle, sys, time
from reflection118_chronological_core_20261022 import *
P=R/'outputs/reflection118_chronological_preparation_20261022'


def main():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandas as pd, pandapower as pp
    def no(*a,**k):raise BaseException('No science in necessary input lookup preparation')
    pp.runpp=no
    from run_reflection118_chronological_local_20261022 import necessary
    from native_continuation_preservation_v2 import extended_local_path
    from frozen_physics_loader import load_stack
    _,runner,_=load_stack()
    source=R/'outputs/original_role_additional_history_scope_v2_20261022/All_Named_Prior_Attempt_Component_References.json.gz'
    refs=json.loads(gzip.decompress(source.read_bytes())); assert len(refs)==9297
    o=P/'Additional_Prior_Attempt_References.json'; assert not o.exists()
    began=time.monotonic();parent_cache={};fresh_cache={};index={};counts={}
    for ref in refs:
        assert time.monotonic()-began<900
        journal=R/ref['journal'];anchor=ref.get('anchor',{})
        if 'relative' in anchor:
            net=pickle.loads((journal.parent/anchor['relative']/'trusted_local_net.pkl').read_bytes())['net']
            n=necessary(net)
        elif 'parent' in anchor:
            identity=anchor['parent']
            if identity not in parent_cache:
                path=journal.parent/'states'/identity/'trusted_local_state.pkl'
                parent_cache[identity]=necessary(pickle.loads(extended_local_path(path).read_bytes())['net'])
            n=parent_cache[identity]
        else:
            if str(journal) not in fresh_cache:
                mapping={}
                for raw in journal.open('rb'):
                    e=json.loads(raw)
                    if e.get('event')=='solver_closed':
                        t=e['observation']['physical_tables']
                        class Net(dict):
                            def __getattr__(self,k):return self[k]
                        net=Net()
                        for k in ['load','bus','line']:
                            rec=t[k]; net[k]=pd.DataFrame(rec['values'],index=rec['index'],columns=rec['columns'])
                        mapping[canonical(e['identity']).decode()]=necessary(net)
                fresh_cache[str(journal)]=mapping
            if canonical(ref['identity']).decode() in fresh_cache[str(journal)]:n=fresh_cache[str(journal)][canonical(ref['identity']).decode()]
            else:
                # Native direct saved return is an actual immutable NET.
                candidates=[]
                for raw in journal.open('rb'):
                    e=json.loads(raw).get('row',{});d=e.get('payload',{})
                    if d.get('identity')==ref['identity'] and e.get('event')=='direct_PF_return':
                        a=d['anchors'];candidates.append(necessary(pickle.loads((journal.parent/a['payload']).read_bytes())['net']))
                assert len(candidates)==1;n=candidates[0]
        index.setdefault(ref['component_sha256'],[]).append({'identity':ref['identity'],'journal':ref['journal'],
            'necessary_input':n,'original_anchor':anchor,'matching_necessary_input_means_UNKNOWN_not_exclusion':True})
        counts[ref['journal']]=counts.get(ref['journal'],0)+1
    put(o,index)
    put(P/'Additional_Coverage_Readiness.json',{'status':'PASS_REUSABLE_NECESSARY_INPUT_LOOKUPS_ALL9297_OLD_ATTEMPTS',
        'source_index_sha256':sha(source),'output_sha256':sha(o),'actual_references':sum(map(len,index.values())),
        'scope':'Closed named lineages only; matching components/loads block new PF unless old exact return is separately resolved.',
        'source_counts':counts,'new_PF_model_calls':0,'workflow_seconds':time.monotonic()-began})
    print(json.dumps(read(P/'Additional_Coverage_Readiness.json')))


if __name__=='__main__':main()
