"""Fix native paper-system comparison metrics before remaining model outcomes."""
from datetime import datetime,timezone
from r118_dff_partition_core_20261023 import *
O=R/'outputs/original118_matched_analysis_preparation_20261023'

def main():
    O.mkdir(exist_ok=False)
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    # No new model case may be selected after seeing model outputs.
    for i in [1,2,3]:assert not (R/'outputs/reflection118_remaining_cases_execution_20261023'/f'case_{i:02d}'/'owner.claim').exists()
    put(O/'Protocol.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_DESCRIPTIVE_NATIVE_ALL4_ANALYSIS_BEFORE_REMAINING_MODEL_OUTPUTS',
        case_order=[b['case_id'] for b in bindings],root_hashes={b['case_id']:b['payload_sha256'] for b in bindings},
        original_model_scope='Unchanged saved private0.5BLoRA on disclosed pinned currentNF4base; exact historical base/SFT preprocessing unrecovered. Old completecase0 reused; exactly next original-role unenteredcases1/2/3, one prospective owner each. No outcome-selected model/checkpoint/prompt.',
        required_before_analysis=['Actual DFF scientist/reader/coordinator ENDED and all4 complete independent source/physics/menu/cursor/cost checks PASS.','Actual remaining3 model hosts/local children/guardians/readers ENDED, all artifacts preserved and exact selected runtimes released; each complete model/source/physics/cursor/cost audit PASS.','Freeze exact remaining-model source and output bindings BEFORE any of their actual model calls; a software path-only amendment may precede outputs, never choose a favorable completed study.','All4 input-root/source namespace/raw118bus endpoints must join exactly. Unknown/missing/wrong-role/partial is UNKNOWN, never zero or a pass.'],
        primary_metrics=['Per-case strict residualUV count(VM<0.95),strictOV count(VM>1.05),full118 normal-band restoration,buswise endpointVM.','All4 paired UV differences and wins/ties/losses; all adverse/unsafe/failed/unknown outcomes retained.'],
        secondary_metrics=['Vmin,Vmax,deficit sum,actual original operation count and installed named shuntQ.','Actual logical query counts,old/current paid reuse counts,new nativePF successes/exceptions,exact-input preparation/extraction costs,first independent replay costs.','All original model setup/load/inference/cold/transport/training/preparation/failure costs; unrecovered historical training/setup components remain UNKNOWN and are not free.'],
        fixed_development_gate='All4 complete; at least2strictHG-VF UVwins vsDFF,zeroUVlosses,and noadditionalstrictOV onanycase. This gate is mechanism development, not90percent winning confidence, external-method superiority or unused confirmation.',
        literal_original_selector='Evaluate original choose_safety_envelope on the complete original DFF/HG-VF rows without changing zero/missing/tie handling; selected HG-SE is a trajectory selector, and BOTH branch/model/preparation/failure costs remain paid.',
        important_comparator_distinction='Original paper HG-SE(DFF plusLLMbranch) is not the full literal numericalD-SE(DFF plusDFF-ALT). DFF-ALT and unchanged numerical envelope/BOTHcosts remain separate mandatory primary-control obligations.',
        statistics='Four inspected development roots share a federation template/loading regime. Report descriptive paired values. No iid significance/CI/generalization claim. Even four independent one-sided sign-test wins would have minimum null probability1/16; independence and unused sampling are not established here.',
        external_methods='Generator/setpoint/binary-capacitor GraphAgent native136action track is a contextual source-native comparison with different actions/horizon. It cannot be counted as an equal-resource trained-method win against new positive shunts. Shared-role adaptation needs separately frozen faithful source,actual training/loader/control/budget/protection contracts.',
        final_claims='All-method/zero-all/fullDSE/incrementalLLM/security claims require their own completed common-task/control/unused-confirmation gates. No manuscript expansion or guaranteed winning claim from this4case development comparison.',
        source_hashes={'work/e/audit/run_reflection_v4_safety_envelope.py':sha(R/'work/e/audit/run_reflection_v4_safety_envelope.py')},new_model_PF_optimizer_training_calls=0))
    print(json.dumps(dict(status='ALL4_NATIVE_ANALYSIS_METRICS_GATE_FROZEN',remaining3model_outputs_observed=0,new_scientific_calls=0)))

if __name__=='__main__':main()
