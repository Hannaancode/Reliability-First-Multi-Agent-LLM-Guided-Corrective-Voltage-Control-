"""Zero-forward independent audit of actual control identities, costs and labels."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/vcsa_development/state_only_pilot'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not (OUT / 'independent_audit.json').exists()
manifest = read(OUT / 'manifest.json')
for name, info in manifest.items():
    assert sha(OUT / name) == info['sha256'] and (OUT / name).stat().st_size == info['bytes']
protocol = read(OUT / 'protocol.json')
for name, digest in protocol['source_sha256'].items(): assert sha(ROOT / 'work' / name) == digest
data = ROOT / 'outputs/vcsa_development/training_interface'
assert sha(data / 'manifest.json') == protocol['data_manifest_sha256']
source = {r['local_observation_id']: r for r in read(data / 'rows.json')}
candidate_checks = 0
for variant in ['untrained', 'final']:
    actual = read(OUT / (variant + '_rows.json'))
    assert len(actual) == len(source) == 48 and len({r['id'] for r in actual}) == 48
    for r in actual:
        src = source[r['id']]
        assert src['split'] == r['split']
        if not src['training_eligible']:
            assert r['hard_abstained'] and r['no_numeric_input']; continue
        action = r['action']
        assert src['input']['allowed_bus_mask'][action['bus_position']]
        assert src['input']['bus_ids'][action['bus_position']] == action['bus']
        label = next(l for l in src['candidate_labels'] if l['bus'] == action['bus'] and l['q_mvar'] == action['q_mvar'])
        assert bool(label['guard_admissibility_target']) == r['measured_label_guard_admissible']
        assert label['after_metrics'] == r['label_after_metrics'] and not r['new_replay_performed']
        target = src['positive_action_target']
        assert r['matches_positive_target'] == ((target['bus_position'], target['q_index']) == (action['bus_position'], action['q_index']))
        candidate_checks += 1
    summary = read(OUT / 'summary.json')[variant]
    for split in ['train', 'validation']:
        finite = [r for r in actual if r['split'] == split and not r.get('hard_abstained')]
        assert summary[split]['finite_views'] == len(finite)
        assert summary[split]['positive_action_matches'] == sum(r['matches_positive_target'] for r in finite)
        assert summary[split]['guard_admissible_actions_in_existing_table'] == sum(r['measured_label_guard_admissible'] for r in finite)
summary = read(OUT / 'summary.json')
assert protocol['epochs'] == 5 and protocol['steps'] == summary['actual_optimizer_steps'] == 155
assert [r['actual_steps'] for r in summary['history']] == [31, 62, 93, 124, 155]
assert summary['pretrained_model_calls'] == summary['new_PF_calls'] == summary['genuine_LLM_weight_training_steps'] == 0
report = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'passed': True,
          'manifest_members_verified': len(manifest), 'exact_untrained_and_final_rows': 96,
          'actual_selected_label_and_scope_checks': candidate_checks, 'retained_invalid_inputs_each_variant': 1,
          'actual_state_control_steps_verified': 155, 'pretrained_model_or_PF_calls_by_audit': 0,
          'learned_performance_reporting_limited_to_existing_one_state_tables': True,
          'no_LLM_or_trajectory_superiority_claim': True, 'audit_source_sha256': sha(Path(__file__))}
(OUT / 'independent_audit.json').write_text(json.dumps(report, indent=2)); print(json.dumps(report))
