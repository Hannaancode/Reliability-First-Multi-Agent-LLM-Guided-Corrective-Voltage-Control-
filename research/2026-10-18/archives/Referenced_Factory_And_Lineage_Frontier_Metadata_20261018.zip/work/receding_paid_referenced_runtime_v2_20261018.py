"""Source-identical receding logic bound to causal referenced checkpoints."""
import ast,hashlib,time
from pathlib import Path
import receding_paid_runtime_v2 as original
import paid_receding_referenced_commit_v2_20261018 as transport
from paid_receding_journal_reference_history_v2_20261018 import ReceiptJournalIndex,ReferencedHistory
from full_receding_paid_campaign_20261015 import Evidence as OriginalEvidence
DEPENDENCY_KEY=original.DEPENDENCY_KEY
SOURCE=Path(original.__file__);source=SOURCE.read_text(encoding='utf-8')
before="self.registry[HISTORY_KEY]['sha256']";after="self.registry[HISTORY_KEY]['index_sha256']"
assert source.count(before)==1
changed=source.replace(before,after);assert changed.replace(after,before)==source
definitions=[n for n in ast.parse(changed).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
env=original.__dict__.copy()
for name in ['HISTORY_KEY','fields','fingerprint','commit_paid','save_complete','restore_complete']:env[name]=getattr(transport,name)
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(SOURCE),'exec'),env)
for n in definitions:globals()[n.name]=env[n.name]
SOURCE_CERTIFICATE={'all_original_controller_query_guard_score_cost_and_dependency_ASTs_unchanged_except_index_anchor':True,
    'original_runtime_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'before':before,'after':after,
    'history_change':'Exact query payloads remain in original fsynced scientific journal; checkpoint decision stores ordered source/protocol/hash/bounded byte references. No missing query fill.',
    'does_not_launch_any_science_or_resume_old_study':True}

class ReferencedEvidence(OriginalEvidence):
    """Capture references only after original durable scientific event closes."""
    def __init__(self,protocol,out):
        super().__init__(protocol,out)
        self.query_index=ReceiptJournalIndex(self.journal.name,protocol_sha256=protocol['protocol_sha256'])
    def event(self,name,data):
        offset=self.journal.tell();super().event(name,data)
        if name=='every_query_receipt_closed_before_more_science':
            started=time.perf_counter();end=self.journal.tell()
            with Path(self.journal.name).open('rb') as f:f.seek(offset);line=f.read(end-offset)
            self.query_index.observe_closed_durable_query(offset,line)
            self.costs['preservation_seconds']+=time.perf_counter()-started

def reconstruct_saved_readonly_factory(state,*,warm_dependencies,source_anchors):
    dependencies=restore_dependency_prefix(state,warm_dependencies=warm_dependencies,source_anchors=source_anchors)
    return {'dependencies':dependencies,'cursor':original.copy.deepcopy(state['cursor']),
            'original_absolute_deadline_utc':state['absolute_deadline_utc'],
            'execution_authorized_by_this_factory':False,
            'next_phase':'READONLY_SAVED_PREFIX_FACTORY_NO_SCIENCE','new_scientific_calls':0}
