"""One algebra/interface readiness check, not a new performance study."""
from pathlib import Path
import gzip,json,time
from unittest.mock import patch
import pandapower as pp
from current_state_linearized_control import sensitivity_at_observed_state,algebra_derivative_check
from candidate_process_evidence_utils import ROOT,read,sha,write
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';OUT=BASE/'linearized_control_software_readiness'
assert not OUT.exists();OUT.mkdir()
with gzip.open(BASE/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz','rt',encoding='utf-8') as f:row=json.loads(next(f))
network=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json';prior=sha(network);base=pp.from_json(str(network))
started=time.perf_counter()
with patch.object(pp,'runpp',side_effect=AssertionError('No PF entry allowed')) as public,patch('pandapower.powerflow._powerflow',side_effect=AssertionError('No PF backend allowed')) as backend:
    result=sensitivity_at_observed_state(base,row['model_input']['current_physical_observation']);derivative=algebra_derivative_check(result)
    assert public.call_count==backend.call_count==0
assert sha(network)==prior
summary={'all_readiness_gates_passed':True,'actual_current_observation_id':row['observation_id'],
 'actual_linear_system_solves':1,'actual_current_PF_calls':0,'actual_model_optimizer_cloud_calls':0,
 'declared_current_only_graph_and_voltage_inputs':True,'derivative_check':derivative,
 'observed_Q_bound_inferred_PQ_buses':result['observed_Q_bound_inferred_PQ_buses'],
 'linear_system_residual':result['linear_system_residual'],'linear_algebra_condition_number':result['linear_algebra_condition_number'],
 'active_set_inference_not_original_solver_certificate':True,'finite_Q_forecast_not_actual_after_voltage':True,
 'network_unchanged':True,'wall_seconds':time.perf_counter()-started,'source_sha256':sha(Path(__file__)),
 'control_source_sha256':sha(ROOT/'work/current_state_linearized_control.py'),'no_new_performance_claim':True}
write(OUT/'Readiness.json',summary);write(OUT/'manifest.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()})
print(json.dumps(summary,indent=2))
