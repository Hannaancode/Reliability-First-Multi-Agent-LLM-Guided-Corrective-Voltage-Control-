"""Exact saved-episode guard/stop adapters, alongside UNCHANGED strong native rows.

No new model or physical call. A native endpoint comparator is never replaced by
an inferior wrapper. These are saved-policy prefixes, not new live deployments.
"""
import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
import stable_ddpg_native_bridge_20261020 as b
from public13_matched_numeric_engine_20261021 import original_guard,metric
R=Path(__file__).resolve().parents[1];O=R/'outputs/public13_common_guard_saved_prefix_20261021'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)
def main():
    O.mkdir(exist_ok=False);np=b.np;roots=read(R/'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json')['roots'];native=read(R/'outputs/public13_native_cohort_assembly_20261021/Native_Cohort_Results.json');assert native['status']=='COMPLETE_SOURCE_NATIVE_ALL500_THREE_METHOD_INPUT_CASE_COHORT';branches={}
    for file in ['outputs/public13_remaining_published_cohort_20261021/Failure.json','outputs/public13_missing_only_execution_20261021/Result.json']:
        for w in read(R/file)['worlds']:
            for a in w['algorithms']:
                if a['status']!='COMPLETE_NATIVE_EPISODE':continue
                key=(w['seed'],a['algorithm']);assert key not in branches;branches[key]=[{'step':s['step'],'vm':s['all13_vm_after'],'Q':s['absolute_Q_Mvar']} for s in a['steps']]
    initial=read(R/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020/Result.json');episode=read(R/'outputs/stable_ddpg_native_episode_20261020/Result.json')
    for a in ['safe-ddpg','linear','ddpg']:
        first=next(v for v in initial['results'] if v['algorithm']==a);index=first['source_PF'];fields=np.load(R/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020'/f'PF{index}_fields.npz');rows=[{'step':1,'vm':fields['res_bus'][:,0].tolist(),'Q':[[v] for v in first['absolute_Q_Mvar']]}];rows.extend({'step':s['step'],'vm':s['all_bus_vm_pu'],'Q':s['absolute_Q_Mvar']} for s in episode['steps'] if s['algorithm']==a);branches[(0,a)]=rows
    assert len(branches)==1500;results=[]
    for seed in range(500):
        for algorithm in ['safe-ddpg','linear','ddpg']:
            rows=branches[(seed,algorithm)];vm=np.asarray(roots[seed]['all13_initial_vm']);q=np.asarray(roots[seed]['initial_control_Q']);accepted=[];rejected=None
            for pos,row in enumerate(rows,1):
                assert row['step']==pos;after=np.asarray(row['vm']);target=np.asarray(row['Q']).reshape(3);assert np.max(np.abs(target-q))<=float(np.float32(.3))+1e-15
                if not original_guard(vm,after):rejected={'step':pos,'candidate':metric(after),'before':metric(vm)};break
                vm=after;q=target;accepted.append(pos)
            # Native stopping is retained. If no rejection, the source endpoint
            # must match exactly; no unseen continuation or null-action fill.
            endpoint=next(v for v in native['rows'] if v['case']==seed and v['method']==algorithm)
            if rejected is None:assert vm.tolist()==endpoint['all13_vm']
            results.append({'seed':seed,'algorithm':algorithm,'guard_wrapper':'SAVED_NATIVE_EPISODE_PREFIX_COMMON_GUARD_FIRST_REJECT_HOLD_STOP','native_initial_controller_state':'Source-observed per-episode initial inference state retained; not a new cross-case continuous model run','accepted_steps':len(accepted),'tested_queries':len(accepted)+(rejected is not None),'rejected':rejected,'final_vm':vm.tolist(),'final_Q':q.tolist(),'final':metric(vm),'source_native_stopping_retained':True,'new_live_model_or_solver_execution':False})
    summary={}
    for name in ['safe-ddpg','linear','ddpg']:
        rows=[v for v in results if v['algorithm']==name];summary[name]={'cases':500,'full13band':sum(v['final']['full13band'] for v in rows),'residual_UV':sum(v['final']['UV'] for v in rows),'residual_OV':sum(v['final']['OV'] for v in rows),'guard_stopped_cases':sum(v['rejected'] is not None for v in rows)}
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_EXACT1500_SAVED_NATIVE_GUARD_STOP_PREFIX_ADAPTERS_ZERO_NEW_SCIENCE','summaries':summary,'rows':results,'unchanged_native_stronger_rows_retained':native['methods'],'cannot_claim_win_by_weakening_published_methods':True,'comparison_rule':'Our new numerical row must be compared to ALL3 unmodified native endpoints AND ALL3 common guard-prefix endpoints on the entire500registered cases. Wrapper degradation is never counted as superiority over native published control.','limits':'Saved same-state source-policy prefixes with native stopping and observed per-episode initial model states. No new online inference, no full-system/LLM attribution or deployment time claim. Different raw actor/globalY information consumption remains disclosed.','new_model_PF_optimizer_derivative_LP_calls':0,'all6goals':'OPEN'};put(O/'Saved_Common_Guard_Results.json',result);print(json.dumps({'status':result['status'],'summaries':summary}))
if __name__=='__main__':main()
