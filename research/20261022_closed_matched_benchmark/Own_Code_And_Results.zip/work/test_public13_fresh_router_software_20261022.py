"""Labelled MOCK end-to-end preservation test; zero actual policy/PF/LP calls.

The native environment method ASTs still run, but physics, actor and numerical
dependencies are explicit mocks. This is software readiness, never performance.
"""
import copy,json,pickle,hashlib,os,types
from pathlib import Path
import candidate_process_runtime
import numpy as np
import torch
import stable_ddpg_native_bridge_20261020 as b
import public13_fresh_router_engine_20261022 as e
import native_fit_teacher_math_20261020 as math
import candidate_process_evidence_utils as evidence
import pandapower.pypower.makeSbus as sb

ROOT=Path(__file__).resolve().parents[1]
O=ROOT/'outputs/public13_fresh_router_software_checks_20261022'

class MockActor(torch.nn.Module):
    def __init__(self):
        super().__init__();self.b=torch.nn.Parameter(torch.ones(1));self.c=torch.nn.Parameter(torch.ones(1));self.scale=1.
    def get_action(self,inp):
        return np.asarray([-.1 if float(inp[0])<.95 else .1 if float(inp[0])>1.05 else 0],dtype=np.float32)

def main():
    O.mkdir(exist_ok=False);F=O/'LABELLED_MOCK_WORKSPACE';F.mkdir();(F/'work').mkdir();(F/'outputs').mkdir()
    P=F/'outputs/preparation';P.mkdir();primary=F/'outputs/primary';reader=F/'outputs/reader'
    graph=ROOT/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz'
    z=np.load(graph);Y=z['Y'];(F/'graph.npz').write_bytes(graph.read_bytes())
    sourceprep=ROOT/'outputs/public13_fresh_input_router_preparation_v2_20261021'
    ids=e.read(sourceprep/'All128_Prospective_Identities.json')[:2]
    # Input recipe generation is already exact-audited; this fixture changes
    # only MOCK output values and never calls a nonlinear solver.
    e.put(F/'identities.json',ids);(F/'recipes.npz').write_bytes((sourceprep/'All128_Source_Exact_Physical_Recipes.npz').read_bytes())
    (F/'base.pkl').write_bytes((ROOT/'outputs/stable_ddpg_native_engineering_20261020/PF0_after.pkl').read_bytes())
    for name in ['run_public13_fresh_router_20261022.py','audit_public13_fresh_router_20261022.py']:(F/'work'/name).write_text('# Labelled mock wrapper only\n',encoding='utf-8')
    e.put(P/'Historical_Physical_Attempt_Anchors.json',dict(physical_signatures=[],scope='MOCK_ONLY'))
    protocol=dict(science_seconds=180,reader_seconds=180,binary_preservation_cap_bytes=64*1024**2,source_and_input_hashes={},graph='graph.npz',base_NET='base.pkl',identities='identities.json',recipes='recipes.npz',primary_end_ACK='outputs/Primary_End.json')
    e.put(P/'Protocol.json',protocol)
    e.put(P/'Independent_Reader_Lock.json',dict(reader_sha256=e.sha(F/'work/audit_public13_fresh_router_20261022.py'),protocol_sha256=e.sha(P/'Protocol.json')))
    observed=dict(MOCK_PF=0,MOCK_ACTOR=0,MOCK_MATH=0)
    def fake_pf(net,**kwargs):
        observed['MOCK_PF']+=1
        v0=.94 if float(net.sgen.p_mw.iloc[0])<0 else 1.06
        net.res_bus.loc[:,'vm_pu']=v0+.06*float(net.sgen.q_mvar.iloc[:3].sum());net.res_bus.at[0,'vm_pu']=1.
        net._ppc['bus'][:,7]=net.res_bus.vm_pu.to_numpy();net._ppc['bus'][:,8]=0.;net.converged=True
    def fake_load(env,event=None):
        result={}
        for a in ['safe-ddpg','linear','ddpg']:
            result[a]=[]
            for i in range(3):
                if event:event('checkpoint_load_attempt',algorithm=a,agent=i,MOCK=True)
                result[a].append(MockActor())
                if event:event('checkpoint_load_return',algorithm=a,agent=i,MOCK=True)
        return result,[],{'MOCK':True}
    original_action=MockActor.get_action
    def counted(self,x):observed['MOCK_ACTOR']+=1;return original_action(self,x)
    MockActor.get_action=counted
    def fake_propose(net,Y,d,cost):
        observed['MOCK_MATH']+=1
        u=np.full(3,-.1 if net.res_bus.vm_pu.min()<.95 else .1,dtype=np.float32)
        for n in ['Current_Model.npz','LP1.npz','LP2.npz']:np.savez(d/n,u=u,MOCK=np.asarray(True))
        for k,v in dict(derivative_attempts=1,derivative_returns=1,LU_returns=1,RHS_returns=3,LP_attempts=2,LP_returns=2).items():cost[k]+=v
        return u,None
    def fake_verify(d,net):return np.load(d/'Current_Model.npz')['u'],None
    def fake_sbus(base,bus,gen):
        V=bus[:,7]*np.exp(1j*np.deg2rad(bus[:,8]));return V*np.conj(Y@V)
    old=(e.R,e.P,e.PRIMARY,e.READER,b.pp.runpp,b.load_three,math.propose,math.verify,evidence.frozen_checks,sb.makeSbus,e.put)
    e.R=F;e.P=P;e.PRIMARY=primary;e.READER=reader;b.pp.runpp=fake_pf;b.load_three=fake_load;math.propose=fake_propose;math.verify=fake_verify;sb.makeSbus=fake_sbus
    evidence.frozen_checks=lambda:dict(all_passed=True,MOCK_ONLY_NOT_FROZEN_ASSET_CERTIFICATE=True)
    original_put=e.put
    def autoack(path,v):
        original_put(path,v)
        if Path(path).name=='owner.claim':original_put(Path(path).parent/'Launcher_ACK.json',dict(actual_pid=os.getpid(),actual_parent_pid=os.getppid(),fresh_exact_source_PID_parent_command=True,LABELLED_MOCK_ACK_NOT_PROCESS_ATTESTATION=True))
    e.put=autoack
    try:
        e.run('primary');original_put(F/'outputs/Primary_End.json',dict(actual_owned_chain_ended=True,exit_code=0,LABELLED_IN_PROCESS_MOCK=True));e.run('independent')
    finally:
        e.R,e.P,e.PRIMARY,e.READER,b.pp.runpp,b.load_three,math.propose,math.verify,evidence.frozen_checks,sb.makeSbus,e.put=old
    primary_result=e.read(primary/'Result.json');audit=e.read(reader/'Independent_Audit.json')
    checks={
        'mock_primary_and_first_reader_closed':audit['status'].startswith('PASS_'),
        'partial_denominator_not_false128complete':not audit['all128_complete'] and len(primary_result['worlds'])==2,
        'all_six_actual_control_paths_exercised':all(len(w['arms'])==6 for w in primary_result['worlds']),
        'separate_router_mutable_model_banks':set(pickle.loads((primary/'Initial_All_Bank_State.pkl').read_bytes()))==set(pickle.loads((primary/'Final_All_Bank_State.pkl').read_bytes())),
        'one_first_mock_replay_per_new_return':audit['actual_independent_costs']['PF_attempts']==primary_result['costs']['PF_returns'],
        'one_first_mock_replay_per_returned_actor':audit['actual_independent_costs']['agent_forward_returns']==primary_result['costs']['agent_forward_returns'],
        'same_input_paid_physics_reuses_exercised':primary_result['costs']['paid_PF_reuses']>0,
        'no_second_actor_phase_in_decision_reconstruction':observed['MOCK_ACTOR']==2*primary_result['costs']['agent_forward_returns'],
        'actual_saved_cold_state_used':primary_result['costs']['cold_state_restorations']>0,
        'numerical_receipt_shared_without_second_solve':primary_result['costs']['paid_math_reuses']>0,
        'no_actual_PF_actor_LP_or_training':True,
        'UV_router_uses_safe':e.route('our-router',np.asarray([.94,1.]))=='safe-ddpg',
        'OV_router_uses_numeric':e.route('our-router',np.asarray([1.06,1.]))=='numerical',
        'mixed_router_uses_numeric':e.route('our-router',np.asarray([.94,1.06]))=='numerical',
        'published_router_uses_DDPG_for_OV':e.route('published-router',np.asarray([1.06,1.]))=='ddpg',
        'inclusive_compliant_boundary_stops':e.route('our-router',np.asarray([.95,1.05]))=='stop',
        'strict_boundary_failure_not_rounded':not e.metric(np.asarray([.95-1e-12,1.]))['full13band'],
    }
    from public13_matched_numeric_engine_20261021 import original_guard
    checks['guard_rejects_new_OV']=not original_guard(np.asarray([1.,.94]),np.asarray([1.06,.96]))
    checks['guard_accepts_count_reduction']=original_guard(np.asarray([1.,.94]),np.asarray([1.,.96]))
    assert all(checks.values()),checks
    e.put(O/'Software_Checks.json',dict(status='PASS_LABELLED_MOCK_E2E_AND_BOUNDARY_CHECKS_NOT_SCIENTIFIC_READINESS_ALONE',checks=checks,counts=observed,actual_new_PF_policy_derivative_LP_training_calls=0,engine_sha256=e.sha(ROOT/'work/public13_fresh_router_engine_20261022.py')))
    print(json.dumps(dict(checks=len(checks),all_passed=True,actual_new_science=0,MOCK_counts=observed)))

if __name__=='__main__':main()
