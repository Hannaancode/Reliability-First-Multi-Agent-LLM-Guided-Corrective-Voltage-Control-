# Why the next experiment must change the decision question

10 October 2026. This is an additive critical review following the completed, stopped public1.5B interface. It preserves every original result, parser, prompt, model, physical setting and comparator. The new work uses saved data and primary literature only: no new GPU allocation, pretrained inference, optimizer update, physical simulation, controller search or numerical forecast.

## A decisive, limited reason our immediate-action studies can hit a ceiling

The original DFF loop selects `max(accepted, key=runner.rescue.score_candidate)`. The unchanged score orders immediate UV clearance, UV reduction, deficit reduction, minimum-voltage improvement and lower absolute Q. DFF-ALT changes only the first choice; the literal D-SE portfolio still runs both complete branches and applies its unchanged safety-envelope selector.

For the SAME current state, verified candidate set and original score, no selector can choose a score strictly greater than that exact maximum. This is an elementary finite-set argument, independent of model size or training quality. Randomizing within that set does not create an action above its maximum. It does NOT prove that DFF maximizes eventual episode success, that the actual candidate set covers every physical intervention, or that an LLM cannot reduce total cost while preserving outcomes. It also does not equate the guarded teacher with the literal original comparator.

The new saved-data audit and separate reader verify all239 optimization inputs from23 fixed historical worlds. In187 states the current scope-and-cap legal action universe is fully recorded. There are30,390 legal measured targets, with12,269 guarded-accepted and18,121 guarded-rejected outcomes, plus120 recorded cap-precheck rejections. The remaining52 states have8,111 unmeasured legal actions retained as UNKNOWN. Original failed-signature history is not reconstructed from this table; a complete scope/cap table is not automatically the literal DFF history at deployment.

The reader independently checks12,269 guarded and16,572 original accepted-score comparisons. The maximum argument supports a scoped rejection: **do not promise a higher same-state immediate score merely by learning to imitate an already exact argmax on the identical set.** A model can still be a useful amortized predictor, a search heuristic, or a different-horizon policy. Those are different hypotheses and need their own evidence.

## Legal output, physical protection and learning are different things

In176 optimization states, the identical bus/Q/scope/cap grammar admits both a physically accepted and a rejected action. Preventing Markdown fences, illegal bus IDs and invalid Q indices would repair an interface. It would not determine which remaining action passes the real verifier. The31 malformed1.5B primary responses stay failures; the nine valid fence-removed payloads remain posthoc diagnostics, never repaired primary successes.

In95 states every recorded maximum under the original verifier is rejected by the added normal-upper guard. A deterministic guard can therefore change action choice materially. This is evidence for giving the SAME guard and observations to numerical competitors, not for attributing guard benefit to the LLM. The11 states with no guarded-accepted action remain in the denominator.

There are33 nontrivial states in17 optimization worlds with a measured protected one-step UV-clearance action. This shows usable immediate targets exist somewhere in the trajectories; it is not a root-only or episode-wide success rate, and states within a world are correlated. A better reconstruction or regression loss does not itself choose those actions. The audit includes an exact synthetic arithmetic witness where mean squared error falls from4/25 to121/10000 while the chosen action becomes worse. That witness is not invented grid data.

The candidate target file contains global AFTER metrics, not complete successor voltage/angle/table states or alternative-action episode returns. Other preserved committed-transition data exist separately; they cannot supply unobserved counterfactual successors. The stopped root-branch contrast study does not become a successful horizon dataset through a new loss name.

## Closest additional primary literature

### RestoreBench: useful interaction contract, different success and comparison

[RestoreBench v1](https://arxiv.org/html/2609.00384v1), sections2-4 and appendicesA, B.4.1, C.5 andG, studies reactive recovery through generator setpoints, shunts and taps. Its success deliberately excludes bus-voltage bounds. Tool agents receive an automatic ranking tool that physically tests up to12 maneuvers per call. Recoverability is certified offline, and each configuration is run once. The reported comparisons are between language models/agent architectures, rather than our fully costed D-SE. These details limit transfer of headline success to protected HierGrid superiority. Its published token-cost breakdown also does not replace a full teacher/search/PF accounting for our method. A deterministic agent with the same tools is an essential additional comparator.

### SafeVolt: close prior art, weak evidence for our particular attribution claim

The [SafeVolt publisher text](https://www.mdpi.com/2073-431X/15/7/422) describes multi-candidate simulation, an expert judge and distilled experience rules on a33-bus scenario. Its stated baselines are PureLLM, Reflection and Memory+Reflection; those lack the proposed physical simulation loop. Thus the displayed comparisons do not isolate a language contribution over an equally informed numerical controller. The text names a32B generator and gives inconsistent7B judge versions between sections4.1.1 and4.1.3. Direct publisher/PDF fetches failed; these specific inspected sections came from publisher-indexed text, not a certified full-PDF audit. The article is listed as open access. This is a retrieval/version issue, not evidence that QU credentials are required. The pipeline combination is already close prior art.

### Adaptive acquisition: a genuinely different role, not a small-model guarantee

[LMABO v1](https://arxiv.org/html/2602.07904v1), sections4-6 and appendicesB-E, uses the model to select acquisition strategies from process and surrogate summaries. A GP performs the numerical prediction. Gemini2.5Flash is the main model; the open8B variant is weaker. Invalid responses use UCB, and the prompt had6-7 preliminary refinements. Curated portfolio controls exist, but no equally trained selector with all the same process features is shown in the inspected baseline specification. Some speed advantage comes from optimizing fewer acquisition functions. An expensive black-box setting does not establish that language-call overhead is negligible for our CPU physics. The role is credible prior art; neither its novelty nor performance transfers to our1.5B policy.

### Constrained output: engineering prerequisite, not the scientific contribution

[Grammar-Constrained Decoding Makes Large Language Models Better Logical Parsers](https://aclanthology.org/2025.acl-industry.34.pdf), sections4.2-4.4 and8, includesQwen0.5B/1.5B and measures syntax separately from solver semantics. It explicitly retains semantic failures after grammar constraints and evaluates logic/arithmetic rather than grid control. A finite state-dependent action dictionary can enforce our scope and cap, but physical acceptance still needs verification. Do not treat the existing unconstrained diagnostic as a constrained experiment or change it retrospectively.

The [grid SFT/DPO study](https://arxiv.org/html/2602.15350v1), sectionsIII-IV, imitates a DC switching oracle and adds AC preferences with a different foundation model. Voltage results use common-convergence cases, while its neural baseline has the lowest failure rate. It motivates action-token learning as a testable implementation, not a guaranteed advantage over an exact immediate oracle or our two-branch portfolio. Oracle SFT plus physical DPO is already grid prior art.

## Three routes that should no longer be mixed

| Route | Claim it could establish | Required evidence before model compute | Present decision |
|---|---|---|---|
| Immediate-score imitation | Accurate or cheaper proposal of an already known best action | A prospectively defined cost/quality comparison; identical information and protection for strong numerical learners | Same-state score-superiority premise rejected on identical evaluated sets. Efficiency remains unproved. |
| Paid evidence acquisition | Choose useful real queries/verification order, then preserve or improve actual decisions within complete costs | Real state-specific query receipts, exact query outcome/cost semantics, a causally valid process summary and equally informed deterministic/learned acquisition controls | Distinct research hypothesis. Stored labels are not free online queries; no acquisition runner or learning launch is certified. |
| Horizon-aware physical decisions | A different admissible action sequence improves protected terminal outcomes beyond greedy D-SE | Measured alternative-action successors/continuations, meaningful contrasts beyond the failed root selector, common protection and complete costs | Unsupported by global-only candidate targets. Do not fabricate a world model, rewards or successful paths. |

## Concrete next work, with stop conditions

1. Inventory the ACTUAL available query/continuation receipts and their timing fields from the frozen source logs. Reuse exact prior reports. Do not solve physics, repeat a search or choose only prior mistakes. Missing per-query times and unobserved successors stay UNKNOWN. This can distinguish a potentially economical acquisition interface from an unsupported episode-value target.
2. For an acquisition proposal, specify current information, past paid evidence, legal query and commit actions, the unchanged verifier, complete accounting and how unknown outcomes terminate safely. Do not impose an arbitrary scalar scale on the original lexicographic tuple or charge preparation to nobody. The same process information must reach a deterministic acquisition rule and a strong trained numerical selector. No language performance test precedes this contract.
3. Check break-even using actual comparable model-call and query timing. Include numerical preprocessing, teacher data, training, verification, failures and preservation. If even a prospectively defined optimistic query saving cannot cover model overhead at the intended workload, reject that cost claim before GPU. Existing aggregate workflow rates are not isolated solver latency.
4. A terminal-quality proposal instead needs a bounded, outcome-independent TRAIN-only physical measurement protocol with all intended identities, failed/partial records and stop rules declared first. Require evidence of protected continuation headroom over both literal D-SE and its commonly protected numerical controls. Do not rerun the stopped root selector, widen its gate after failure or collect favorable worlds. No such collection is launched by this review.
5. Only a surviving mechanism receives one fixed typed interface, one budget/seed/final checkpoint, genuine integration and a matched numerical/pretraining attribution study. A failed measured gate stops that method. A favorable development result still needs fresh per-state inference, matched physical trajectories, full BOTH-branch D-SE costs, continuous replay and genuinely unused confirmation.

These are research prerequisites, not an asserted implemented experiment or99%winning plan. The exact argmax bound and real legal-but-rejected counterexamples are decisive within their stated scope. They cannot give100% certainty about every future method. The overall validated incremental LLM advantage remains unachieved; resources should be spent only on a claim these prerequisites could actually test.

New evidence: `one_step_oracle_and_query_measurement_audit/summary.json` and `one_step_oracle_necessity_independent_reader/Independent_Necessity_Certificate_Check.json`. The first analysis took4.3424seconds; the independent reader took2.0144seconds, excluding separately recorded interpreter startup and sealing. Both used zero new model/physics/numerical calls. The original teacher/PF/control costs remain separate and paid.
