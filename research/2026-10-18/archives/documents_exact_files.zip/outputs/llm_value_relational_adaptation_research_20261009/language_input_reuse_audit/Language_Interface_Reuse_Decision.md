The old binary branch selector legitimately consumed two already-paid accepted one-step receipts to predict an episode choice. Its compact input retained voltage/reports/scopes/options while omitting most physical tables. Its earlier28 root context checks do not certify a causal full-table native action proposer before candidate physics. Do not reuse them as its context or same-information proof.

This audit tests one unreduced canonical serialization of the exact current-only model input with a minimal user chat wrapper and the frozen tokenizer. It does not choose a training prompt or inspect held outcomes. All239 OPT inputs/all23 worlds and all19 physical tables remain, with exact round trips and no truncation/AFTER/labels/identity fields.

{
  "minimum_context_tokens": 92693,
  "actual_frozen_tokenizer_max_context_tokens": 96930,
  "fits4096_plus384reserve": 0,
  "overflow_contexts_retained": 239
}

Any overflow stops this raw full-table chat representation under the4096/384 contract. It is not a proof that every lossless or multistage representation is impossible. A future representation must define causal information, exact coverage, same-information and stronger controls, token/full-state checks and all preparation/inference costs before training. No rounding, dropped tables, paid future receipts or prompt sweeps may be hidden to claim readiness. The ongoing numerical sources/settings and all stopped methods are unchanged. No new GPU/model experiment is ready from this audit.
