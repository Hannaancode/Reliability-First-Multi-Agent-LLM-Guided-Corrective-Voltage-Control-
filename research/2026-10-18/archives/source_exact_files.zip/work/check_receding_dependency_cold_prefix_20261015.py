"""Real cold-process dependency reconstruction on an already paid prefix.

This is component engineering, not a fresh controller/physics performance run.
All old PF and numeric outputs retain their paid costs and original identities.
"""
import argparse,copy,hashlib,json,os,subprocess,sys,time
from pathlib import Path
import pandapower as pp
import numpy as np
from receding_paid_runtime_v1 import restore_dependency_prefix,DEPENDENCY_KEY,sha,read,put
from dynamic_actual_mask_guidance_v1 import identity
R=Path(__file__).resolve().parents[1];B=R/'outputs/receding_dependency_cold_prefix_20261015'
P=R/'outputs/bounded_paid_lookahead_physics_20261014';D=R/'outputs/receding_warm_dependency_closure_20261015'
def no_science(*a,**k):raise AssertionError('Cold engineering cannot repeat any science')
def main(cold):
    for n in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,n,no_science)
    if cold:
        request=read(B/'Request.json');dependencies=read(D/'Paid_Warm_Dependencies.json')
        result=restore_dependency_prefix(request['state'],warm_dependencies=dependencies,source_anchors=request['source_anchors'])
        assert result['cache']==dependencies['cache'] and result['paid_forecasts']==dependencies['existing_numeric_forecasts']
        assert len(result['closed_intent_ids'])==84 and result['new_scientific_calls']==0
        checks=['ACTUAL_PAID_PREFIX_CACHE_AND_FORECASTS_EXACT','ALL84_CLOSED_ATTEMPT_IDENTITIES_RETAINED','NO_NEW_SCIENTIFIC_CALLBACK']
        for bad in ('last_scientific_event_sha256','scientific_journal_bytes','source_anchors'):
            state=copy.deepcopy(request['state']);d=state['paid_query_registry'][DEPENDENCY_KEY]
            if bad=='scientific_journal_bytes':d[bad]-=1
            elif bad=='source_anchors':d[bad]={'wrong':'anchor'}
            else:d[bad]='f'*64
            try:restore_dependency_prefix(state,warm_dependencies=dependencies,source_anchors=request['source_anchors'])
            except (AssertionError,ValueError,KeyError):checks.append('REJECT_BAD_'+bad.upper())
            else:raise AssertionError('Invalid saved dependency prefix accepted')
        put(B/'Cold_Result.json',{'status':'PASS_COLD_PAID_DEPENDENCY_PREFIX_COMPONENT','checks':checks,
            'cache_entries':len(result['cache']),'forecast_entries':len(result['paid_forecasts']),
            'numeric_contexts':len(result['contexts']),'new_scientific_calls':0,
            'scope':'One already-audited scientific prefix; no new full trajectory or actual model result'})
        return
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    result=read(P/'actual/Result.json');assert result['exit_code']==0
    contexts=[]
    for path in sorted((P/'actual/contexts').glob('*.npz')):
        with np.load(path,allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
        contexts.append({'identity':identity(c),'path':str(path.relative_to(R)),'sha256':sha(path)})
    prefix='0'*64
    with (P/'actual/scientific.jsonl').open('rb') as stream:
        for line in stream:
            e=json.loads(line);assert e['previous_sha256']==prefix
            prefix=hashlib.sha256(line.rstrip(b'\n')).hexdigest()
    anchors={'runtime_source':sha(R/'work/receding_paid_runtime_v1.py'),'engineering_source':sha(Path(__file__))}
    dep={'source_anchors':anchors,'warm_dependency_path':str((D/'Paid_Warm_Dependencies.json').relative_to(R)),
        'warm_dependency_sha256':sha(D/'Paid_Warm_Dependencies.json'),
        'scientific_journal_path':str((P/'actual/scientific.jsonl').relative_to(R)),
        'scientific_journal_bytes':(P/'actual/scientific.jsonl').stat().st_size,'last_scientific_event_sha256':prefix,
        'capsules_bytes':(P/'actual/capsules.bin').stat().st_size,'warm_numeric_contexts':contexts,
        'current_numeric_contexts':[],'closed_new_receipt_occurrences':0}
    state={'paid_query_registry':{DEPENDENCY_KEY:dep},'protocol_sha256':sha(P/'Protocol.json'),
        'costs':{'actual_scientific':result['actual_new_costs']},
        'absolute_deadline_utc':read(P/'Protocol.json').get('absolute_deadline_utc','ORIGINAL_STUDY_CLOSED_NO_RESUME')}
    put(B/'Request.json',{'state':state,'source_anchors':anchors,'not_a_production_controller_checkpoint':True})
    with (B/'cold_console.log').open('x',encoding='utf-8') as log:
        process=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold'],
            stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        code=process.wait(timeout=120)
    assert code==0,'See retained cold_console.log'
    put(B/'Result.json',{'exit_code':0,'status':'PASS_REAL_COLD_DEPENDENCY_COMPONENT','actual_cold':read(B/'Cold_Result.json'),
        'workflow_seconds':time.perf_counter()-started,'new_scientific_calls':0,
        'whole_runtime_cold_checkpoint_and_independent_reader_still_required':True})
    put(B/'Closed_Manifest.json',{'exit_code':0,'members':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()}})
    print(json.dumps({'real_cold_dependency_component':'PASS','new_scientific_calls':0,'whole_runtime_performance':'NOT_STARTED'}))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--cold',action='store_true');main(parser.parse_args().cold)
