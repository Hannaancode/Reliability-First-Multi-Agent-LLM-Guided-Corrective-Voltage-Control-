"""Original Reflection-v4 function execution, with explicit causal providers.

Function ASTs, prompts, verifier, Q/cap/score/router remain original. This
module adds preservation and a replay boundary; it does not supply actions.
"""
import copy, hashlib, json, os, pickle, random, sys, time, zlib
from pathlib import Path

R = Path(__file__).resolve().parents[1]


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text('utf-8'))
def canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def put(p, v):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, ensure_ascii=False, allow_nan=False); f.flush(); os.fsync(f.fileno())


def capsule(p, v):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    raw = pickle.dumps(v, protocol=5); encoded = zlib.compress(raw)
    with p.open('xb') as f: f.write(encoded); f.flush(); os.fsync(f.fileno())
    return {'path': p.name, 'bytes': len(encoded), 'sha256': hashlib.sha256(encoded).hexdigest(),
            'decoded_bytes': len(raw), 'decoded_sha256': hashlib.sha256(raw).hexdigest()}


def decode(p, d):
    raw = (Path(p) / d['path']).read_bytes()
    assert len(raw) == d['bytes'] and hashlib.sha256(raw).hexdigest() == d['sha256']
    raw = zlib.decompress(raw)
    assert len(raw) == d['decoded_bytes'] and hashlib.sha256(raw).hexdigest() == d['decoded_sha256']
    return pickle.loads(raw)


def frames_equal(a, b):
    import pandas as pd
    keys = {k for k, v in a.items() if isinstance(v, pd.DataFrame) and not str(k).startswith('res_')}
    assert keys == {k for k, v in b.items() if isinstance(v, pd.DataFrame) and not str(k).startswith('res_')}
    for k in keys: pd.testing.assert_frame_equal(a[k], b[k], check_exact=True, check_dtype=True)
    assert float(a.sn_mva) == float(b.sn_mva) and float(a.f_hz) == float(b.f_hz)


def restore_exact(net, saved):
    frames_equal(net, saved)
    net.clear(); net.update(copy.deepcopy(saved))


class FirstCommitBoundary(BaseException): pass


def controller(v2, runner, reflection, scenario, base, zones, model_provider,
               pf_provider, arm, checkpoint_callback=None):
    """Execute original function; a checkpoint callback may stop at commit1.

    It runs only AFTER the original executed_actions append completed. Both
    feedback_state and failed histories are captured from the actual frame.
    """
    import numpy as np, pandapower as pp
    target = (reflection.run_one_scenario_two_best_v2 if arm == 'reflection_v2'
              else reflection.run_one_scenario_no_llm_fallback_first)
    oldpf = pp.runpp; oldgen = runner.base_runner.generate_response
    oldtrace = sys.gettrace(); seen = False; captured = None

    def trace(frame, event, arg):
        nonlocal seen, captured
        if frame.f_code is target.__code__ and event == 'line':
            loc = frame.f_locals
            result = loc.get('result')
            if result and len(result.get('executed_actions', [])) == 1 and not seen:
                seen = True
                captured = copy.deepcopy({k: loc[k] for k in
                    ['net', 'result', 'failed_sigs', 'failed_actions', 'feedback_state', 'it'] if k in loc})
                captured['python_rng'] = random.getstate(); captured['numpy_rng'] = np.random.get_state()
                if checkpoint_callback: checkpoint_callback(captured)
        return trace

    pp.runpp = pf_provider
    runner.base_runner.generate_response = lambda model, tokenizer, messages: model_provider(messages)
    try:
        sys.settrace(trace)
        if arm == 'reflection_v2':
            result = target(scenario, base, zones, v2, object(), object(), 'reflection_v2')
        else: result = target(scenario, base, zones, v2)
        return result, captured
    finally:
        sys.settrace(oldtrace); pp.runpp = oldpf; runner.base_runner.generate_response = oldgen


def checkpoint_equal(a, b):
    import numpy as np, pandas as pd
    assert set(a) == set(b)
    frames_equal(a['net'], b['net'])
    pd.testing.assert_frame_equal(a['net'].res_bus, b['net'].res_bus, check_exact=True)
    for k in a:
        if k not in {'net', 'numpy_rng'}: assert a[k] == b[k], k
    assert a['numpy_rng'][0] == b['numpy_rng'][0]
    assert np.array_equal(a['numpy_rng'][1], b['numpy_rng'][1])
    assert a['numpy_rng'][2:] == b['numpy_rng'][2:]

