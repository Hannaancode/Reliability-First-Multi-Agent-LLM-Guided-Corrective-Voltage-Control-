"""Next fixed native menu from closed same-policy screen; no new science."""
import ast,copy,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
import save_next_physical_cell_20261019 as original
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from fixed_four_query_core_20261019 import known_keys as earlier_keys,B as FOUR
B=R/'outputs/third_point_exact_cell_20261019'
SCREEN=R/'outputs/fixed_nine_second_context_policy_screen_20261019'
def known():return set(earlier_keys())|{v['point_action_key'] for v in read(FOUR/'Protocol.json')['exact_new_query_rows']}
def scoped_process(pid):
    q=subprocess.run(['powershell','-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId={pid}' | Select-Object ProcessId,ParentProcessId,CommandLine,@{{Name='CreatedUtc';Expression={{$_.CreationDate.ToUniversalTime().ToString('o')}}}} | ConvertTo-Json -Compress"],capture_output=True,text=True)
    assert q.returncode==0
    if not q.stdout.strip():return None
    current=json.loads(q.stdout);closed=datetime.fromtimestamp((SCREEN/'Closed_Manifest.json').stat().st_mtime,timezone.utc)
    if datetime.fromisoformat(current['CreatedUtc'])>closed:
        put(B/f'PID_Reuse_{pid}.json',{'new_actor_created_after_original_closure':current,'original_closed_utc':closed.isoformat()});return None
    return current
def main():
    text=Path(original.__file__).read_text('utf-8');n=copy.deepcopy(next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main'))
    cut=next(i for i,s in enumerate(n.body) if isinstance(s,ast.Expr) and isinstance(s.value,ast.Call) and ast.unparse(s.value.func)=='put' and 'Exact_Next_Cell.json' in ast.unparse(s))
    n.body=n.body[:cut+1];source=ast.unparse(n)
    old="for root, phases in [(R / 'outputs/exact_two_paid_query_engineering_20261018', ('warm', 'cold')), (THREE, ('warm', 'cold_1', 'cold_2'))]:"
    new="for root, phases in [(R / 'outputs/exact_two_paid_query_engineering_20261018', ('warm', 'cold')), (THREE, ('warm', 'cold_1', 'cold_2')), (FOUR, ('warm','cold_1','cold_2','cold_3'))]:"
    assert source.count(old)==1;source=source.replace(old,new).replace('assert len(recent) == 10','assert len(recent) == 18').replace("'recent10_BEFORE_matches'","'recent18_BEFORE_matches'")
    env=original.__dict__.copy();env.update(B=B,SCREEN=SCREEN,FOUR=FOUR,known_keys=known,process=scoped_process,__file__=__file__)
    exec(compile(source,__file__,'exec'),env);env['main']()
    d=read(B/'Exact_Next_Cell.json');d['scope_limits']='60426trackedBEFORE+3418staticAFTER+ALL18recentPFBEFOREs, two independent component equations; not universal unlogged history or PF authority.';d['required_next_gate']='New source/current-state/arity-specific protocol, tested atomic custody, original native verifier, persistent warm/cold/source/input/independent reader/full costs BEFORE physics.';put(B/'Exact_Next_Cell_Scope_Addendum.json',d)
    manifest(B);print(json.dumps({'point':d['point'],'UV':d['current_metrics']['uv_count'],'next_n':len(d['all_unexecuted_original_menu_queries']),'component_hits':[{k:v for k,v in row.items() if k.endswith('_matches')} for row in d['all_unexecuted_original_menu_queries']],'science':0}))
if __name__=='__main__':main()
