import json,pickle,hashlib,ast
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native15_saved_command_physics_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    np=b.np;audit=ROOT/'outputs/native_joint_15_engineering_independent_v2_20261020/Independent_Audit.json';assert json.loads(audit.read_text())['status'].startswith('PASS_');model=ROOT/'outputs/native_joint_15_engineering_execution_v2_20261020/staged/study/Results.json';value=json.loads(model.read_text());p=json.loads((ROOT/'outputs/native_full_grid_affine_preparation_20261020/Protocol.json').read_text());current=ROOT/p['all24contexts'][8]['paid_NET'];item=json.loads((ROOT/'outputs/native_slm_joint_input_preparation_20261020/Selected_Longest_Engineering_Context.json').read_text());assert sha(current)==item['current_NET_sha256']
    with current.open('rb') as f:net=pickle.load(f)
    q=net.sgen.q_mvar.to_numpy()[:3]-np.asarray(value['warm_u'][0],dtype=np.float32);assert np.array_equal(q,np.asarray(value['warm_Qnext'][0]));net.sgen.loc[net.sgen.index[:3],'q_mvar']=q;candidate=signature(net);known=set();anchors=[]
    for folder in ['stable_ddpg_native_engineering_20261020','stable_ddpg_native_remaining_engineering_v2_20261020','stable_ddpg_native_episode_20261020','native_action_upgrade_support_20261020','native_affine_physics_support_20261020','native_fit_teacher_execution_20261020']:
        for file in (ROOT/'outputs'/folder).rglob('*.pkl'):
            if 'before' not in file.name.lower():continue
            with file.open('rb') as f:old=pickle.load(f)
            if not hasattr(old,'bus') or len(old.bus)!=13:continue
            known.add(signature(old));anchors.append({'path':file.relative_to(ROOT).as_posix(),'sha256':sha(file)})
    assert candidate not in known
    sources=['work/native15_saved_command_physics_integration_20261020.py','work/run_native15_saved_command_physics_20261020.py','work/audit_native15_saved_command_physics_20261020.py']
    for rel in sources:ast.parse((ROOT/rel).read_text())
    inputs=[str(current.relative_to(ROOT)),str(model.relative_to(ROOT)),str(audit.relative_to(ROOT))];protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'question':'Actualsavednativeheadu to unchangednativephysics+protection engineering only. Context8 chosenlongestBEFOREallnativebodycalls;notafavorablecase/success/performance test. No newinference orlearning.','current_NET':inputs[0],'saved_native_model_result':inputs[1],'source_and_input_hashes':{n:sha(ROOT/n) for n in sources+inputs},'new_candidate_signature':candidate,'all_prior_physical_signatures':sorted(known),'relevant_prior_inputs':anchors,'planned_actual_costs':'One NEWnativePFprimary+one separatelychargedindependentreplay,0newmodel/optimizer/GPU/actualcommits. Allfailed/unsafe/unknown outputs retained. No retry/fill oroldscientificcallrepeat.','no_model_performance':'Two-updateengineeringweightsDISPOSABLE;currentstatealreadyfullysafe. Guardrejectionisvalidcontainment,notlearningbenefit oruniversalmodelweakness. No automaticbenchmark/SLMtraining.','physical_and_guard':'Same3nativeactuators,float32u±.3,float64Qnext=Qcurrent-u;all13normalband/noUVorOVincrease;rejectleavescurrentstateunchanged.'};put(OUT/'Protocol.json',protocol)
    for mode,file,output,coord in [('primary',sources[1],'outputs/native15_saved_command_physics_20261020','outputs/native15_saved_command_physics_coordination_20261020'),('independent',sources[2],'outputs/native15_saved_command_physics_independent_20261020','outputs/native15_saved_command_physics_reader_coordination_20261020')]:put(OUT/f'{mode}_Owner_Protocol.json',{'single_owner':{'source':file,'sha256':sha(ROOT/file),'python':'work/vcsa_module_env/Scripts/python.exe','output':output,'coordination':coord,'bound_seconds':120}})
    print('SAVED_NATIVE15_COMMAND_ACTUAL_NATIVE_IDENTITY_GATE_PASS_UNEXECUTED')
if __name__=='__main__':main()
