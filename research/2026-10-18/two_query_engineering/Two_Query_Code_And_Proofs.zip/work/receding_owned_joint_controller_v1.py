"""Complete native-universe greedy suffix, with explicit paid callbacks.

No solver/model/cache/training or scientific launch lives in this component.
Caller owns actual receipts, storage, cold checks and all external costs.
"""
import copy
import math
from joint_reallocation_opportunity_core_v1 import universe

METHODS = ('complete_ordinary_greedy_suffix', 'complete_ordinary_and_joint_greedy_suffix')
IDENTITY_KEYS = ('kind', 'receiver', 'q', 'donor_index', 'donor_bus', 'universe_index')


def candidate_identity(row):
    return {key: row[key] for key in IDENTITY_KEYS}


def declared_universe(cursor, method):
    assert method in METHODS and cursor['remaining_original_device_operation_slots'] > 0
    rows = universe(cursor)
    if method == METHODS[0] or cursor['remaining_original_device_operation_slots'] < 2:
        rows = [r for r in rows if r['kind'] == 'ordinary']
    assert len({r['universe_index'] for r in rows}) == len(rows)
    # Lifetime-cap refusals remain declared and accounted; they are not
    # silently dropped, incorrectly solved, or counted as negative physics.
    return rows


def choose(rows):
    accepted = [r for r in rows if r['verdict']['accepted']]
    for row in accepted:
        assert len(row['original_score']) == 5 and all(math.isfinite(float(v)) for v in row['original_score'])
    return max(accepted, key=lambda r: (tuple(r['original_score']), -r['candidate']['universe_index'])) if accepted else None


def run_suffix(net, cursor, *, method, metrics, query, commit, checkpoint, event, admit):
    """Finish at restoration, an exhausted original budget or no safe action.

    Whole-scenario DFF/DSE is NOT claimed: input is an already paid current
    state and its original prefix. Every complete decision queries all its
    original native identities. No hindsight stop/subset or favourable K.
    """
    assert method in METHODS and cursor['original_device_operation_budget'] == 25
    initial_cursor = copy.deepcopy(cursor); initial = metrics(net)
    decisions = []; reason = None
    while True:
        admit(); current = metrics(net)
        if current['uv_count'] == 0: reason = 'full_restoration'; break
        if cursor['remaining_original_device_operation_slots'] == 0: reason = 'original_device_operation_budget_exhausted'; break
        candidates = declared_universe(cursor, method)
        event('decision_declared', {'method': method, 'decision': len(decisions),
            'current_metrics': current, 'remaining_operations': cursor['remaining_original_device_operation_slots'],
            'candidate_identities': candidates})
        received = []
        for candidate in candidates:
            admit(); row = query(net, cursor, candidate)
            assert row['candidate'] == candidate_identity(candidate)
            received.append(row)
        selected = choose(received)
        event('decision_closed', {'method': method, 'decision': len(decisions),
            'declared': len(candidates), 'closed': len(received),
            'accepted': sum(r['verdict']['accepted'] for r in received),
            'selected_receipt_id': selected['receipt_id'] if selected else None})
        if selected is None: reason = 'complete_declared_universe_no_protected_accepted_action'; break
        before_slots = cursor['remaining_original_device_operation_slots']
        net, cursor, record = commit(net, cursor, selected)
        debit = 1 if selected['candidate']['kind'] == 'ordinary' else 2
        assert cursor['remaining_original_device_operation_slots'] == before_slots-debit >= 0
        assert record['device_operations_debited'] == debit
        decisions.append(record)
        checkpoint(net, cursor, {'method': method, 'decision': len(decisions), 'phase': 'NEXT_COMPLETE_CURRENT_STATE_DECISION'})
    final = metrics(net)
    result = {'method': method, 'initial_metrics': initial, 'final_metrics': final,
        'initial_prefix_device_operations': len(initial_cursor['original_prefix_actions']),
        'new_device_operations': initial_cursor['remaining_original_device_operation_slots']-cursor['remaining_original_device_operation_slots'],
        'remaining_original_operations': cursor['remaining_original_device_operation_slots'],
        'commits': decisions, 'stop_reason': reason,
        'whole_original_scenario_DFF_DSE_or_LLM_attribution': 'NOT_TESTED'}
    event('suffix_closed', result)
    return net, cursor, result
