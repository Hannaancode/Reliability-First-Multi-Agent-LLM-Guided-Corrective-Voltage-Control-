"""Descriptive all-response prompt admission check, zero inference or physics.

The first saved prompt was inspected before this protocol and showed a fixed bus52
example. This is a development diagnosis, not a prospective treatment estimate.
"""
import json,re,hashlib,collections,sys
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];O=R/'outputs/original_prompt_candidate_diagnosis_20261028'
def rd(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False)
def main():
    O.mkdir(exist_ok=False)
    source=R/'work/e/audit/run_reflection_v4_safety_envelope.py'
    put(O/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'All459 saved original controller responses on all4inspected development roots; exact candidate-list equality, example bus membership, output equality and acceptance counts, separately first/second. No causal estimate.','preinspected':'One saved first prompt showed fixed bus52/Q150 example. Source also shows candidate-first dynamic reprompt example.','source_sha256':sha(Path(__file__)),'original_source_sha256':sha(source),'new_model_PF_controller_optimizer_calls':0,'unchanged_old_science':True})
    allrows=[];counts=collections.defaultdict(collections.Counter);sources={}
    for i in range(4):
        attribution=rd(R/f'outputs/original118_raw_action_attribution_v2_20261028/case_{i:02d}_Attribution.json');summary=attribution['summary']
        resultfile=R/summary['result_path'];assert sha(resultfile)==summary['result_sha256'];result=rd(resultfile);calls=rd(resultfile.with_name('Call_Order.json'));gens=[]
        if i in (1,3):
            old=R/f'outputs/reflection118_remaining_cases_v2_execution_20261023/case_{i:02d}'
            manifest=rd(old/'remote_closed_descriptor.json')['members']
            for name in sorted(n for n in manifest if re.fullmatch(r'response_\d{5}\.json',n)):
                p=old/'staged/study'/name;assert sha(p)==manifest[name]['sha256'];v=rd(p)
                req=old/'local_controller/requests'/name.replace('response_','request_');assert rd(req)==v['request']
                gens.append({'messages':v['request']['messages'],'text':v['raw_text'],'request':v['request']['number']})
        gens+=calls['generations'];checks=attribution['response_checks'];assert len(gens)==len(checks)
        sources[summary['case_id']]={'result':summary['result_path'],'sha256':sha(resultfile),'calls_sha256':sha(resultfile.with_name('Call_Order.json'))}
        for g,ch in zip(gens,checks):
            assert hashlib.sha256(g['text'].encode()).hexdigest()==ch['raw_sha256']
            text=g['messages'][-1]['content'];attempt=ch['attempt']
            pattern=r'^CANDIDATE_BUSES_YOU_MAY_USE: (\[[^\n]*\])$' if attempt=='first' else r'^You must choose exactly one bus from this list: (\[[^\n]*\])$'
            m=re.findall(pattern,text,re.M);assert len(m)==1;candidate=json.loads(m[0]);assert candidate==result['logs'][ch['log']]['llm_info']['candidate_buses']
            em=re.findall(r'Example:\s*(\{[^\n]+\})',text);assert len(em)==1;example=json.loads(em[0]);eb=int(example['bus']);assert example['q_mvar'] in [25,50,75,100,125,150,200,250,300]
            # Separate raw numeric equality from parser output; no repaired copy credit.
            try:raw=json.loads(g['text'])
            except ValueError:raw=None
            rawbus=raw.get('bus') if isinstance(raw,dict) else None
            equalbus=str(rawbus)==str(example['bus'])
            exact=raw==example
            normal=ch['normalized_action'];nb=int(next(iter(normal['add_shunts_q_mvar']))) if normal else None
            row={'case_id':summary['case_id'],'log':ch['log'],'iteration':ch['iteration'],'zone':ch['zone'],'attempt':attempt,'candidate_buses':candidate,'example_bus':eb,'example_Q':example['q_mvar'],'example_candidate_valid':eb in candidate,'raw_bus_equals_example':equalbus,'raw_exact_example':exact,'normalized_bus':nb,'candidate_valid':ch['candidate_valid'],'reason':ch['reason'],'messages_sha256':hashlib.sha256(json.dumps(g['messages'],sort_keys=True,ensure_ascii=False).encode()).hexdigest(),'raw_sha256':ch['raw_sha256']}
            allrows.append(row)
            for key in ['ALL',attempt]:
                c=counts[key];c['responses']+=1;c['exact_candidate_list_binding']+=1;c['example_outside_candidates']+=int(eb not in candidate);c['raw_bus_equals_example']+=int(equalbus);c['raw_exact_example']+=int(exact);c['invalid_output_equal_example_bus']+=int(equalbus and not ch['candidate_valid']);c['candidate_valid']+=int(ch['candidate_valid'])
                c['example_outside_and_output_chooses_it']+=int(eb not in candidate and equalbus)
    assert len(allrows)==459 and counts['first']['responses']==308 and counts['second']['responses']==151
    put(O/'Per_Response_Checks.json',allrows)
    put(O/'Results.json',{'status':'COMPLETE_SAVED_PROMPT_CANDIDATE_DIAGNOSIS','counts':{k:dict(v) for k,v in counts.items()},'sources':sources,'new_model_PF_controller_optimizer_calls':0,'limits':['Descriptive association, no prompt repair, retraining, new inference or physical improvement','Exact saved messages are checked; this analysis does not independently decode actual model input token IDs or certify no token truncation','Invalid illustrative examples do not prove they caused all invalid outputs','Four inspected development roots; no unused confirmation']})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({k:dict(v) for k,v in counts.items()}))
if __name__=='__main__':main()
