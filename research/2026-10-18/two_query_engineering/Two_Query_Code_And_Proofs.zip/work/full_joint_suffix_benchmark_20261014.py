"""Fixed four-current-state COMPLETE ordinary/joint greedy continuations.

This is development action-space evidence, not original whole-scenario D-SE,
LLM attribution or confirmation. Previously paid exact query identities are
reused with attributed costs; only new queries and paid continuous replays run.
"""
import os
for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[variable] = '1'
import argparse, copy, hashlib, importlib.metadata, json, pickle, random, struct, subprocess, sys, time, traceback, zlib
from datetime import datetime, timezone, timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
from audit_spatial_allocation_inputs_v3_20261011 import signature
from candidate_process_evidence_utils import frozen_checks
from durable_opaque_evidence_store_v1 import local_root, inventory
from equal_operation_benchmark_v2 import initial_data, decode_capsule, native_scope, following_cursor, process
from frozen_physics_loader import load_stack, AUDIT
from joint_reallocation_opportunity_core_v1 import load_endpoint, action, build_verifier
from paid_joint_commit_v2 import initialize, validate, fields, fingerprint, commit_paid, save, restore, SOURCE_CERTIFICATE
from receding_owned_joint_controller_v1 import METHODS, candidate_identity, declared_universe, choose, run_suffix

R = Path(__file__).resolve().parents[1]
B = R/'outputs/full_joint_suffix_benchmark_20261014'
OLD = R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
TWO = R/'outputs/equal_operation_benchmark_v2_20261013'
ENG = R/'outputs/joint_commit_cold_engineering_20261013'
PYTHON = R/'work/physics_env/Scripts/python.exe'
read = lambda p: json.loads(local_root(p).read_bytes())
sha = lambda p: hashlib.sha256(local_root(p).read_bytes()).hexdigest()
canon = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
digest = lambda v: hashlib.sha256(canon(v)).hexdigest()


def put(path, value):
    with local_root(path).open('xb') as file:
        file.write(canon(value)); file.flush(); os.fsync(file.fileno())


def metrics(net):
    vm = [r['vm_pu'] for r in fields(net).values()]
    return {'uv_count': sum(v < .95 for v in vm), 'vmin': min(vm), 'vmax': max(vm),
            'deficit_sum': sum(max(.95-v, 0.) for v in vm),
            'raw_OV_1p05': sum(v > 1.05 for v in vm), 'tolerance_OV_1p05': sum(v > 1.05+1e-8 for v in vm)}


def array_identity(array):
    array = np.asarray(array)
    assert array.dtype != object
    return {'shape': list(array.shape), 'dtype': str(array.dtype), 'bytes_sha256': hashlib.sha256(array.tobytes()).hexdigest()}


def state_key(net, cursor):
    case = net['_ppc']; internal = case['internal']; y = internal['Ybus'].tocsr()
    case_identity = {k: array_identity(case[k]) for k in ('bus', 'branch', 'gen')}
    case_identity.update(baseMVA=float(case['baseMVA']), V=array_identity(internal['V']),
        Ydata=array_identity(y.data), Yindices=array_identity(y.indices), Yindptr=array_identity(y.indptr),
        Yshape=list(y.shape), lookup=array_identity(net['_pd2ppc_lookups']['bus']))
    return digest({'inputs': signature(net), 'current_bus_fields': fields(net), 'current_actual_case': case_identity,
        'positive_lifetime': cursor['positive_addition_lifetime_MVAr'], 'withdrawn_lifetime': cursor.get('withdrawn_lifetime_MVAr', {}),
        'remaining_operations': cursor['remaining_original_device_operation_slots'], 'scope': cursor['raw_current_receiver_scope'],
        'owned': [{k: row[k] for k in ('index', 'bus', 'name', 'q_mvar')} for row in cursor['owned_bank_rows']]})


def action_key(row):
    return digest({k: row[k] for k in ('kind', 'receiver', 'q', 'donor_index', 'donor_bus')})


def verdict(raw):
    band = raw.get('after') is not None and raw['after']['vmax'] <= 1.05+1e-8
    out = dict(raw, original_native_accepted=raw['accepted'], normal_upper_band_admissible=bool(band))
    if raw['accepted'] and not band: out.update(accepted=False, reason='normal_upper_band_mediation')
    return out


def legacy_cache():
    """Compiler of exact already-paid administrator receipts; no solver calls."""
    old, rows, times = initial_data(); _, runner, _ = load_stack()
    meta = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = meta.get('zones', meta)
    cache = {}; raw_roots = {}; endpoints = {}; root_rows = {}; packs = {}; following_keys = {}
    def add(key, row, origin, after, seconds):
        candidate = candidate_identity(row); k = (key, action_key(candidate))
        record = {'candidate': candidate, 'verdict': row['verif'], 'original_score': row['original_score'],
            'receipt_id': origin['receipt_id'], 'source_receipt': origin, 'after_reference': after,
            'attributed_PF_calls': int(after is not None), 'attributed_solver_seconds': seconds}
        if k in cache:
            previous = cache[k]
            assert previous['verdict'] == record['verdict'] and previous['original_score'] == record['original_score']
        else: cache[k] = record
    packs['old'] = local_root(OLD/'actual/capsules.bin').open('rb')
    for entry in old['current_endpoints']:
        net, cursor, rng = load_endpoint(entry); world = entry['world']; key = state_key(net, cursor)
        raw_roots[world] = (net, cursor, rng); endpoints[world] = entry; root_rows[world] = {}
        for row in (r for r in rows if r['world'] == world):
            paid = row['measured_receipt']; identifier = f"old_root_{world}_{row['universe_index']}"
            ref = {'kind': 'old', 'descriptor': paid['after']} if paid else None
            add(key, row, {'receipt_id': identifier, 'world': world, 'source': str((OLD/'actual/scientific.jsonl').relative_to(R)),
                'old_PF_id': paid['PF_id'] if paid else None, 'universe_index': row['universe_index']}, ref,
                times[paid['PF_id']] if paid else 0.)
            if paid: root_rows[world][paid['PF_id']] = row
    # Exact following contexts from the completed equal-two-operation study.
    for line in local_root(TWO/'actual/scientific.jsonl').read_bytes().splitlines():
        event = json.loads(line)
        if event['event'] != 'new_second_candidate_closed': continue
        context = event['data']['context']; row = event['data']['record']; world = context['world']
        first = root_rows[world][context['first_PF_id']]
        context_key = (world, context['first_PF_id'])
        if context_key not in following_keys:
            base, cursor, _ = raw_roots[world]
            first_net = decode_capsule(packs['old'], first['measured_receipt']['after'])['net']
            next_cursor = following_cursor(base, first_net, cursor, first, runner, zones)
            following_keys[context_key] = state_key(first_net, next_cursor)
        paid = row['measured_receipt']; identifier = f"old_second_{row['key']}"
        ref = {'kind': 'two', 'descriptor': paid['after']} if paid else None
        add(following_keys[context_key], row,
            {'receipt_id': identifier, 'world': world, 'source': str((TWO/'actual/scientific.jsonl').relative_to(R)),
             'old_PF_id': paid['PF_id'] if paid else None, 'conditional_key': row['key']}, ref, paid['seconds'] if paid else 0.)
    # The one already-executed cold following query must also never be repeated.
    from paid_joint_commit_v1 import restore as restore_engineering
    engineering = restore_engineering(ENG/'actual/committed_checkpoint', read(ENG/'actual/Checkpoint_ACK.json'))
    cold = read(ENG/'cold/Result.json'); row = cold['following_candidate']; paid = cold['following_receipt']
    wrapper = dict(row, verif=cold['following_verdict'], original_score=list(runner.rescue.score_candidate({'action': action(row), 'verif': cold['following_verdict']})))
    add(state_key(engineering['net'], engineering['cursor']), wrapper,
        {'receipt_id': 'old_engineering_following', 'source': str((ENG/'cold/scientific.jsonl').relative_to(R))},
        {'kind': 'engineering', 'descriptor': paid['after']}, paid['seconds'])
    # Prove the root-best joint's exact retained paid NET matches that engineering
    # following context. No mere field-only equivalence or raw pickle comparison.
    old_candidate = next(r for r in rows if r['world'] == engineering['cursor']['world'] and r['universe_index'] ==
                         engineering['cursor']['committed_transitions'][0]['candidate']['universe_index'])
    original_net, original_cursor, _ = raw_roots[engineering['cursor']['world']]
    saved = decode_capsule(packs['old'], old_candidate['measured_receipt']['after'])['net']
    new_cursor = initialize(original_net, original_cursor); _, actuate, _ = build_verifier(runner.rescue, new_cursor)
    received = dict(old_candidate['measured_receipt'], accepted=True, receipt_id='binding_only',
                    before_fingerprint=fingerprint(original_net, new_cursor))
    bound = commit_paid(original_net, saved, new_cursor, candidate_identity(old_candidate), received,
        commit_id='binding_only', actuate=actuate, next_scope=native_scope(saved, runner, zones))
    assert state_key(saved, bound) == state_key(engineering['net'], engineering['cursor']), 'No replay of an executed following identity through a mismatched cache'
    for pack in packs.values(): pack.close()
    return old, cache, raw_roots, endpoints


class Evidence:
    def __init__(self, protocol, out):
        self.p = protocol; self.out = out; self.previous = '0'*64; self.actual_backend = pp.runpp
        self.journal = local_root(out/'scientific.jsonl').open('xb'); self.pack = local_root(out/'capsules.bin').open('x+b')
        self.last = None; self.context = None; self.serial = 0
        self.costs = {'PF_attempts': 0, 'PF_returns': 0, 'PF_exceptions': 0, 'PF_seconds': 0.,
            'new_query_PF_attempts': 0, 'continuous_replay_PF_attempts': 0, 'preservation_seconds': 0.,
            'new_model_calls': 0, 'new_optimizer_steps': 0, 'new_derivative_forecast_linear_solve_calls': 0}
    def admit(self):
        assert datetime.now(timezone.utc) < datetime.fromisoformat(self.p['absolute_deadline_utc']), 'Absolute resource bound; no extension'
        assert self.costs['PF_attempts'] < self.p['maximum_PF_attempts']
        assert self.pack.tell()+64*1024**2 < self.p['maximum_storage_bytes']
    def event(self, name, data):
        t = time.perf_counter(); raw = canon({'event': name, 'data': data, 'previous_sha256': self.previous,
            'protocol_sha256': sha(B/'Protocol.json')}); self.previous = hashlib.sha256(raw).hexdigest()
        self.journal.write(raw+b'\n'); self.journal.flush(); os.fsync(self.journal.fileno())
        self.costs['preservation_seconds'] += time.perf_counter()-t
    def capsule(self, net, name):
        t = time.perf_counter(); raw = pickle.dumps({'net': net, 'python_rng': random.getstate(), 'numpy_rng': np.random.get_state()}, protocol=5)
        assert len(raw) < 32*1024**2; encoded = zlib.compress(raw, 6)
        header = {'label': name, 'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
            'encoded_bytes': len(encoded), 'encoded_sha256': hashlib.sha256(encoded).hexdigest()}
        hb = canon(header); offset = self.pack.tell()
        self.pack.write(struct.pack('<Q', len(hb))+hb+encoded); self.pack.flush(); os.fsync(self.pack.fileno())
        self.costs['preservation_seconds'] += time.perf_counter()-t
        return {'path': 'capsules.bin', 'record_offset': offset, 'header_bytes': len(hb), 'header_sha256': hashlib.sha256(hb).hexdigest(),
            'encoded_offset': offset+8+len(hb), **header}
    def solve(self, net, *args, **kwargs):
        assert not args and kwargs == self.p['solver_kwargs'] and self.context is not None
        self.admit(); self.serial += 1; identity = self.serial
        before = self.capsule(net, f'{identity}_before')
        self.event('PF_intent', {'identity': identity, 'context': self.context, 'before': before, 'kwargs': kwargs}); self.admit()
        start = time.perf_counter(); self.costs['PF_attempts'] += 1
        counter = 'continuous_replay_PF_attempts' if self.context['phase'] == 'CONTINUOUS_SELECTED_COMMIT_REPLAY' else 'new_query_PF_attempts'
        self.costs[counter] += 1
        try: result = self.actual_backend(net, **kwargs); self.costs['PF_returns'] += 1
        except BaseException as exc:
            seconds = time.perf_counter()-start; self.costs['PF_seconds'] += seconds; self.costs['PF_exceptions'] += 1
            self.last = {'PF_id': identity, 'outcome': 'EXCEPTION', 'seconds': seconds, 'after': self.capsule(net, f'{identity}_exception')}
            self.event('PF_exception', self.last); raise
        seconds = time.perf_counter()-start; self.costs['PF_seconds'] += seconds
        self.last = {'PF_id': identity, 'outcome': 'RETURNED', 'seconds': seconds, 'converged': bool(net.converged),
            'fields': fields(net) if net.converged else None, 'before': before, 'after': self.capsule(net, f'{identity}_after')}
        self.event('PF_return', self.last); return result
    def close(self):
        pp.runpp = self.actual_backend; self.journal.close(); self.pack.close()


def load_after(ref, pack):
    if ref['kind'] == 'new':
        position = pack.tell()
        try: return decode_capsule(pack, ref['descriptor'])
        finally: pack.seek(position)  # A selected read must never overwrite the append tail.
    if ref['kind'] in ('old', 'two'):
        base = OLD if ref['kind'] == 'old' else TWO
        with local_root(base/'actual/capsules.bin').open('rb') as stream: return decode_capsule(stream, ref['descriptor'])
    assert ref['kind'] == 'engineering'
    d = ref['descriptor']; encoded = local_root(ENG/d['path']).read_bytes()
    assert len(encoded) == d['encoded_bytes'] and hashlib.sha256(encoded).hexdigest() == d['encoded_sha256']
    dec = zlib.decompressobj(); raw = dec.decompress(encoded, d['raw_bytes']+1)
    assert dec.eof and not dec.unused_data and not dec.unconsumed_tail
    assert len(raw) == d['raw_bytes'] and hashlib.sha256(raw).hexdigest() == d['raw_sha256']
    return pickle.loads(raw)


def pin_check(p):
    for name, h in p['source_input_sha256'].items(): assert sha(R/name) == h, name
    assert {n: importlib.metadata.version(n) for n in p['runtime']} == p['runtime']


def claim(out):
    local_root(out).mkdir(exist_ok=False)
    put(out/'owner.claim', {'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(), 'argv': sys.argv,
        'source_sha256': sha(Path(__file__)), 'protocol_sha256': sha(B/'Protocol.json')})
    while not local_root(out/'Launcher_ACK.json').exists():
        assert datetime.now(timezone.utc) < datetime.fromisoformat(read(B/'Protocol.json')['absolute_deadline_utc']); time.sleep(.1)
    ack = read(out/'Launcher_ACK.json')
    assert ack['actual_pid'] == os.getpid() and ack['actual_parent_pid'] == os.getppid() and ack['fresh_exact_PID_parent_command']


def launch(mode, out):
    with local_root(B/(mode+'_console.log')).open('x', encoding='utf8') as log:
        child = subprocess.Popen([str(PYTHON), '-X', 'utf8', str(Path(__file__)), '--'+mode], stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
        begun = time.perf_counter()
        while not local_root(out/'owner.claim').exists():
            assert child.poll() is None and time.perf_counter()-begun < 120; time.sleep(.1)
        owner = read(out/'owner.claim'); actual = process(owner['actual_pid'])
        assert actual and actual['ParentProcessId'] == child.pid and Path(__file__).name in actual['CommandLine'] and '--'+mode in actual['CommandLine']
        put(out/'Launcher_ACK.json', {'actual_pid': owner['actual_pid'], 'actual_parent_pid': child.pid,
            'fresh_exact_PID_parent_command': True, 'actual_command': actual['CommandLine']})
        if mode == 'worker': put(B/'Live_Ownership.json', {'actual_pid': owner['actual_pid'], 'launcher_pid': child.pid,
            'source': str(Path(__file__).relative_to(R)), 'protocol_sha256': sha(B/'Protocol.json')})
        code = child.wait()
    put(B/(mode+'_End_ACK.json'), {'actual_pid': owner['actual_pid'], 'launcher_pid': child.pid, 'exit_code': code,
        'closed_manifest_sha256': sha(out/'Closed_Manifest.json'), 'exact_owned_chains_ended': True})
    return code


def checkpoint_cold():
    out = B/'cold'; claim(out); p = read(B/'Protocol.json'); pin_check(p); code = 1
    try:
        descriptor = read(B/'actual/Cold_Check_Request.json'); state = restore(B/descriptor['path'], descriptor['receipt'])
        assert state['absolute_deadline_utc'] == p['absolute_deadline_utc'] and state['protocol_sha256'] == sha(B/'Protocol.json')
        assert state['next_phase'] == descriptor['next_phase'] and state['paid_query_registry'] == descriptor['registry']
        assert state['costs'] == descriptor['costs']
        assert digest(array_identity(state['numpy_rng'][1])) == descriptor['numpy_rng_array_digest']
        assert hashlib.sha256(pickle.dumps(state['numpy_rng'], protocol=5)).hexdigest() == descriptor['numpy_rng_full_digest']
        assert hashlib.sha256(pickle.dumps(state['python_rng'], protocol=5)).hexdigest() == descriptor['python_rng_digest']
        _, runner, _ = load_stack(); meta = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = meta.get('zones', meta)
        assert native_scope(state['net'], runner, zones) == state['cursor']['raw_current_receiver_scope']
        # This cold child owns no science. Parent continues only future identities
        # after exact complete-state confirmation, under the same absolute bound.
        put(out/'Result.json', {'exit_code': 0, 'status': 'PASS_ACTUAL_COLD_COMPLETE_CONTROLLER_CHECKPOINT',
            'next_phase': state['next_phase'], 'remaining_slots': state['cursor']['remaining_original_device_operation_slots'],
            'new_model_PF_optimizer_calls': 0}); code = 0
    except BaseException as exc:
        put(out/'Failure.json', {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc(), 'no_retry': True})
        put(out/'Result.json', {'exit_code': 1})
    finally: put(out/'Closed_Manifest.json', {'exit_code': code, 'members': inventory(out, hashes=True)})
    raise SystemExit(code)


def worker():
    out = B/'actual'; claim(out); p = read(B/'Protocol.json'); pin_check(p)
    code = 1; evidence = None; results = []; begun = time.perf_counter(); current = {}; cold_checked = False
    try:
        old, cache, roots, entries = legacy_cache(); _, runner, _ = load_stack()
        meta = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = meta.get('zones', meta)
        evidence = Evidence(p, out); pp.runpp = evidence.solve
        attributed = {}; registry = {}; checkpoint_serial = 0; decision_context = {}
        for world in p['all_four_fixed_worlds']:
            for method in METHODS:
                current = {'world': world, 'method': method}; original, source_cursor, rng = roots[world]
                net = copy.deepcopy(original); cursor = initialize(net, source_cursor)
                assert native_scope(net, runner, zones) == cursor['raw_current_receiver_scope']; validate(net, cursor)
                random.setstate(rng['python_rng']); np.random.set_state(rng['numpy_rng'])
                registry = {}; branch_cost = {'attributed_PF_query_calls': 0, 'attributed_solver_query_seconds': 0.,
                    'already_paid_query_reuses': 0, 'new_primary_query_calls': 0, 'cap_refusals_without_PF': 0,
                    'new_continuous_replay_PF': 0}; attributed[world+'|'+method] = branch_cost
                evidence.event('branch_initialized', {'context': current, 'original_cursor': source_cursor,
                    'current_cursor': cursor, 'initial_capsule': evidence.capsule(net, 'branch_initial')})
                def query(actual, c, row):
                    # Key/verifier is compiled once per complete decision.
                    fp = fingerprint(actual, c)
                    if decision_context.get('fingerprint') != fp:
                        v, a, cert = build_verifier(runner.rescue, c)
                        decision_context.update(fingerprint=fp, state_key=state_key(actual, c), verify=v, actuate=a, certificate=cert)
                    key = (decision_context['state_key'], action_key(row))
                    if key in cache:
                        record = copy.deepcopy(cache[key]); branch_cost['already_paid_query_reuses'] += 1
                        record['candidate'] = candidate_identity(row)
                        evidence.event('paid_query_reused', {'context': current, 'state_key': key[0], 'action_key': key[1], 'record': record})
                    else:
                        evidence.last = None
                        evidence.context = {**current, 'phase': 'NEW_PRIMARY_QUERY', 'candidate': candidate_identity(row),
                            'state_key': key[0], 'action_key': key[1]}
                        if c['positive_addition_lifetime_MVAr'].get(str(row['receiver']), 0.)+row['q'] > 450:
                            raw = {'accepted': False, 'reason': 'positive_lifetime_cap_exceeded_without_refund',
                                'before': runner.rescue.grid_metrics(actual), 'after': None, 'converged': None}
                        else: raw = decision_context['verify'](actual, action(row))
                        closed = verdict(raw); paid = copy.deepcopy(evidence.last)
                        after_ref = {'kind': 'new', 'descriptor': paid['after']} if paid and paid['outcome'] == 'RETURNED' else None
                        record = {'candidate': candidate_identity(row), 'verdict': closed,
                            'original_score': list(runner.rescue.score_candidate({'action': action(row), 'verif': closed})),
                            'receipt_id': 'new_query_'+str(len(cache)), 'source_receipt': {'source': 'actual/scientific.jsonl', 'measured': paid},
                            'after_reference': after_ref, 'attributed_PF_calls': int(paid is not None),
                            'attributed_solver_seconds': paid['seconds'] if paid else 0.}
                        cache[key] = copy.deepcopy(record)
                        evidence.event('new_candidate_closed', {'context': current, 'state_key': key[0], 'action_key': key[1], 'record': record})
                        branch_cost['new_primary_query_calls'] += int(paid is not None)
                    branch_cost['attributed_PF_query_calls'] += record['attributed_PF_calls']
                    branch_cost['attributed_solver_query_seconds'] += record['attributed_solver_seconds']
                    branch_cost['cap_refusals_without_PF'] += int(not record['attributed_PF_calls'])
                    source_ref = record['source_receipt']
                    compact_source = {k: v for k, v in source_ref.items() if k != 'measured'}
                    if 'measured' in source_ref and source_ref['measured'] is not None:
                        compact_source['actual_PF_id'] = source_ref['measured']['PF_id']
                    registry[record['receipt_id']] = {'state_key': key[0], 'action_key': key[1],
                        'source_receipt': compact_source, 'record_sha256': digest(record), 'after_reference': record['after_reference']}
                    assert fingerprint(actual, c) == fp, 'Queries cannot change current committed state'
                    return record
                def commit(actual, c, selected):
                    row = selected['candidate']; solved = load_after(selected['after_reference'], evidence.pack)
                    target = solved['net']; assert bool(target.converged)
                    _, actuate, _ = build_verifier(runner.rescue, c)
                    replay = actuate(copy.deepcopy(actual), action(row)); evidence.context = {**current,
                        'phase': 'CONTINUOUS_SELECTED_COMMIT_REPLAY', 'candidate': row, 'selected_receipt_id': selected['receipt_id']}
                    pp.runpp(replay, **p['solver_kwargs']); assert replay.converged
                    delta = max(abs(fields(replay)[b][k]-fields(target)[b][k]) for b in fields(target) for k in fields(target)[b])
                    assert delta <= 1e-10
                    assert metrics(target)['vmax'] <= 1.05+1e-8
                    receipt = {'receipt_id': selected['receipt_id'], 'accepted': True, 'converged': True,
                        'fields': fields(target), 'before_fingerprint': fingerprint(actual, c)}
                    commit_id = world+'|'+method+'|'+str(len(c['committed_transitions']))
                    following = commit_paid(actual, target, c, row, receipt, commit_id=commit_id,
                        actuate=actuate, next_scope=native_scope(target, runner, zones))
                    branch_cost['new_continuous_replay_PF'] += 1
                    record = {'commit_id': commit_id, 'candidate': row, 'selected_receipt_id': selected['receipt_id'],
                        'device_operations_debited': 1 if row['kind'] == 'ordinary' else 2,
                        'replay_receipt': copy.deepcopy(evidence.last), 'replay_field_delta': delta,
                        'selected_solved_state_is_not_the_independent_replay': True, 'following_cursor': following}
                    evidence.event('actual_commit', {'context': current, 'record': record}); return target, following, record
                def checkpoint(actual, c, phase):
                    nonlocal checkpoint_serial, cold_checked
                    checkpoint_serial += 1; path = out/'checkpoints'/str(checkpoint_serial)
                    state = {'net': actual, 'cursor': c, 'paid_query_registry': registry,
                        'python_rng': random.getstate(), 'numpy_rng': np.random.get_state(), 'costs': copy.deepcopy(evidence.costs),
                        'absolute_deadline_utc': p['absolute_deadline_utc'], 'protocol_sha256': sha(B/'Protocol.json'),
                        'next_phase': {**current, **phase}}
                    anchors = {'source': sha(Path(__file__)), 'input': p['source_input_sha256'][entries[world]['endpoint_record']],
                        'paid_receipt': digest(registry), 'predecessor': evidence.previous}
                    t = time.perf_counter(); receipt = save(path, state, anchors)
                    restored = restore(path, receipt)
                    assert restored['paid_query_registry'] == registry and restored['next_phase'] == state['next_phase']
                    evidence.costs['preservation_seconds'] += time.perf_counter()-t
                    evidence.event('complete_checkpoint_ACK', {'context': current, 'path': str(path.relative_to(B)), 'receipt': receipt, 'next_phase': state['next_phase']})
                    if not cold_checked:
                        put(out/'Cold_Check_Request.json', {'path': str(path.relative_to(B)), 'receipt': receipt, 'next_phase': state['next_phase'],
                            'registry': registry, 'costs': state['costs'], 'numpy_rng_array_digest': digest(array_identity(state['numpy_rng'][1])),
                            'numpy_rng_full_digest': hashlib.sha256(pickle.dumps(state['numpy_rng'], protocol=5)).hexdigest(),
                            'python_rng_digest': hashlib.sha256(pickle.dumps(state['python_rng'], protocol=5)).hexdigest()})
                        # Exclusive parent waits; child is a source-locked readonly
                        # full-state check, not a duplicate scientific owner.
                        assert launch('checkpoint-cold', B/'cold') == 0
                        cold_checked = True
                net, cursor, result = run_suffix(net, cursor, method=method, metrics=metrics, query=query,
                    commit=commit, checkpoint=checkpoint, event=evidence.event, admit=evidence.admit)
                result.update(world=world, final_cursor=cursor, final_fields=fields(net),
                    attributed_query_and_new_replay_costs=copy.deepcopy(branch_cost),
                    paid_original_prefix_cost_source=entries[world]['endpoint_record'])
                results.append(result); put(out/('Branch_'+str(len(results))+'.json'), result)
                put(out/('Progress_'+str(len(results))+'.json'), {'complete_branches': len(results), 'total_planned_branches': 8,
                    'counts_do_not_establish_audit_completion': True, 'actual_costs': evidence.costs})
        assert len(results) == 8 and cold_checked; code = 0
    except BaseException as exc:
        put(out/'Failure.json', {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc(),
            'current': current, 'full_gate': 'UNKNOWN', 'no_scientific_retry': True})
    finally:
        costs = evidence.costs if evidence else None
        if evidence: evidence.close()
        put(out/'Result.json', {'exit_code': code, 'branches': results, 'actual_costs': costs,
            'owned_seconds_before_manifest': time.perf_counter()-begun, 'planned_8_missing_branches_UNKNOWN': 8-len(results),
            'all_fixed_four_world_gate': 'REQUIRES_COMPLETE_INDEPENDENT_READER' if code == 0 else 'UNKNOWN',
            'new_model_or_LLM_attribution': 'NOT_TESTED', 'whole_original_DFF_ALT_DSE': 'NOT_TESTED'})
        put(out/'Closed_Manifest.json', {'exit_code': code, 'members': inventory(out, hashes=True)})
    raise SystemExit(code)


def audit():
    out = B/'audit'; claim(out); p = read(B/'Protocol.json'); pin_check(p); begun = time.perf_counter(); code = 1
    try:
        end = read(B/'worker_End_ACK.json'); assert end['exit_code'] == 0
        assert process(end['actual_pid']) is None and process(end['launcher_pid']) is None
        assert sha(B/'actual/Closed_Manifest.json') == end['closed_manifest_sha256']
        manifest = read(B/'actual/Closed_Manifest.json'); assert manifest['exit_code'] == 0
        for name, descriptor in manifest['members'].items():
            assert local_root(B/'actual'/name).stat().st_size == descriptor['bytes'] and sha(B/'actual'/name) == descriptor['sha256']
        old, cache, roots, entries = legacy_cache(); _, runner, _ = load_stack()
        meta = read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'); zones = meta.get('zones', meta)
        def blocked(*args, **kwargs): raise AssertionError('Independent reader may not solve or call a model')
        for name in ('runpp', 'runopp', 'rundcpp', 'rundcopp'): setattr(pp, name, blocked)
        previous = '0'*64; net = None; cursor = None; context = None; declared = None; returned = []; decision_selected = None
        actual_returns = {}; actual_exceptions = {}; query_checked = 0; commits_checked = 0; checkpoints_checked = 0; completed = []
        with local_root(B/'actual/capsules.bin').open('rb') as pack:
            for line in local_root(B/'actual/scientific.jsonl').read_bytes().splitlines():
                event = json.loads(line); assert event['previous_sha256'] == previous and event['protocol_sha256'] == sha(B/'Protocol.json')
                previous = hashlib.sha256(line).hexdigest(); kind = event['event']; data = event['data']
                if kind == 'PF_return':
                    assert data['PF_id'] not in actual_returns
                    actual_returns[data['PF_id']] = data
                    saved = decode_capsule(pack, data['after'])['net']
                    assert bool(saved.converged) == data['converged']
                    if data['converged']: assert fields(saved) == data['fields']
                elif kind == 'PF_exception':
                    assert data['PF_id'] not in actual_exceptions; actual_exceptions[data['PF_id']] = data
                    decode_capsule(pack, data['after'])
                elif kind == 'branch_initialized':
                    context = data['context']; original, old_cursor, _ = roots[context['world']]
                    saved = decode_capsule(pack, data['initial_capsule'])['net']
                    assert signature(saved) == signature(original) and fields(saved) == fields(original)
                    net = saved; cursor = initialize(net, old_cursor); assert cursor == data['current_cursor']; validate(net, cursor)
                elif kind == 'decision_declared':
                    declared = declared_universe(cursor, context['method']); assert declared == data['candidate_identities']
                    assert data['current_metrics'] == metrics(net) and data['remaining_operations'] == cursor['remaining_original_device_operation_slots']
                    returned = []; decision_selected = None
                elif kind in ('paid_query_reused', 'new_candidate_closed'):
                    row = data['record']; assert data['context'] == context
                    candidate = row['candidate']; assert candidate == declared[len(returned)]
                    key = (state_key(net, cursor), action_key(candidate)); assert key == (data['state_key'], data['action_key'])
                    if kind == 'paid_query_reused':
                        expected = copy.deepcopy(cache[key]); expected['candidate'] = candidate
                        assert row == expected
                    else:
                        assert key not in cache
                        verify, actuate, certificate = build_verifier(runner.rescue, cursor)
                        assert certificate['reverse_AST_exact']
                        measured = row['source_receipt']['measured']
                        if cursor['positive_addition_lifetime_MVAr'].get(str(candidate['receiver']), 0.)+candidate['q'] > 450:
                            assert measured is None
                            raw = {'accepted': False, 'reason': 'positive_lifetime_cap_exceeded_without_refund',
                                   'before': runner.rescue.grid_metrics(net), 'after': None, 'converged': None}
                        else:
                            if measured:
                                source = actual_returns if measured['outcome'] == 'RETURNED' else actual_exceptions
                                assert measured == source[measured['PF_id']]
                                if measured['outcome'] == 'RETURNED':
                                    after = decode_capsule(pack, measured['after'])['net']
                                    expected_input = actuate(copy.deepcopy(net), action(candidate))
                                    actual_input = decode_capsule(pack, measured['before'])['net']
                                    assert signature(expected_input) == signature(actual_input)
                                    assert signature(after) == signature(actual_input)
                                    def saved_result(target, **kwargs):
                                        assert kwargs == p['solver_kwargs'] and signature(target) == signature(after)
                                        target.res_bus = after.res_bus.copy(deep=True); target.converged = after.converged
                                else:
                                    # Reproduce the already closed recorded exception
                                    # through the original verifier; no new solve.
                                    def saved_result(target, **kwargs):
                                        assert kwargs == p['solver_kwargs']; raise RuntimeError('RECORDED_PAID_NONCONVERGENCE')
                                pp.runpp = saved_result
                            else: pp.runpp = blocked
                            raw = verify(net, action(candidate)); pp.runpp = blocked
                        expected_verdict = verdict(raw)
                        assert expected_verdict == row['verdict']
                        score = list(runner.rescue.score_candidate({'action': action(candidate), 'verif': expected_verdict}))
                        assert score == row['original_score']
                        assert row['attributed_PF_calls'] == int(measured is not None)
                        assert row['attributed_solver_seconds'] == (measured['seconds'] if measured else 0.)
                        cache[key] = copy.deepcopy(row)
                    returned.append(row); query_checked += 1
                elif kind == 'decision_closed':
                    assert len(returned) == len(declared) == data['declared'] == data['closed']
                    decision_selected = choose(returned)
                    assert data['selected_receipt_id'] == (decision_selected['receipt_id'] if decision_selected else None)
                    assert data['accepted'] == sum(r['verdict']['accepted'] for r in returned)
                elif kind == 'actual_commit':
                    assert data['context'] == context and decision_selected is not None
                    record = data['record']; selected = decision_selected
                    assert record['candidate'] == selected['candidate'] and record['selected_receipt_id'] == selected['receipt_id']
                    after = load_after(selected['after_reference'], pack)['net']; _, actuate, _ = build_verifier(runner.rescue, cursor)
                    replay = record['replay_receipt']; assert replay == actual_returns[replay['PF_id']]
                    expected_input = actuate(copy.deepcopy(net), action(selected['candidate']))
                    assert signature(expected_input) == signature(decode_capsule(pack, replay['before'])['net'])
                    delta = max(abs(fields(after)[b][k]-replay['fields'][b][k]) for b in fields(after) for k in fields(after)[b])
                    assert delta == record['replay_field_delta'] and delta <= 1e-10
                    received = {'receipt_id': selected['receipt_id'], 'accepted': True, 'converged': True,
                                'fields': fields(after), 'before_fingerprint': fingerprint(net, cursor)}
                    cursor = commit_paid(net, after, cursor, selected['candidate'], received, commit_id=record['commit_id'],
                        actuate=actuate, next_scope=native_scope(after, runner, zones)); net = after
                    assert cursor == record['following_cursor'] and metrics(net)['tolerance_OV_1p05'] == 0
                    commits_checked += 1
                elif kind == 'complete_checkpoint_ACK':
                    saved = restore(B/data['path'], data['receipt'])
                    assert fingerprint(saved['net'], saved['cursor']) == fingerprint(net, cursor)
                    assert saved['absolute_deadline_utc'] == p['absolute_deadline_utc'] and saved['next_phase'] == data['next_phase']
                    assert all(t['paid_receipt_id'] in saved['paid_query_registry'] for t in cursor['committed_transitions'])
                    checkpoints_checked += 1
                elif kind == 'suffix_closed':
                    assert data['final_metrics'] == metrics(net) and data['remaining_original_operations'] == cursor['remaining_original_device_operation_slots']
                    assert data['stop_reason'] in ('full_restoration', 'original_device_operation_budget_exhausted', 'complete_declared_universe_no_protected_accepted_action')
                    if data['stop_reason'] == 'full_restoration': assert metrics(net)['uv_count'] == 0
                    if data['stop_reason'] == 'original_device_operation_budget_exhausted': assert cursor['remaining_original_device_operation_slots'] == 0
                    if data['stop_reason'] == 'complete_declared_universe_no_protected_accepted_action': assert decision_selected is None and len(returned) == len(declared)
                    completed.append((context['world'], context['method']))
        results = read(B/'actual/Result.json'); costs = results['actual_costs']; assert results['exit_code'] == 0
        assert completed == [(world, method) for world in p['all_four_fixed_worlds'] for method in METHODS]
        assert costs['PF_returns'] == len(actual_returns) and costs['PF_exceptions'] == len(actual_exceptions)
        assert costs['PF_attempts'] == len(actual_returns)+len(actual_exceptions)
        assert abs(costs['PF_seconds']-sum(v['seconds'] for v in list(actual_returns.values())+list(actual_exceptions.values()))) <= 1e-8
        assert commits_checked == checkpoints_checked == costs['continuous_replay_PF_attempts']
        assert costs['new_query_PF_attempts']+costs['continuous_replay_PF_attempts'] == costs['PF_attempts']
        cold = read(B/'cold/Result.json'); assert cold['exit_code'] == 0 and cold['new_model_PF_optimizer_calls'] == 0
        worlds = []; wins = 0; losses = 0
        for world in p['all_four_fixed_worlds']:
            ordinary, joint = [r for r in results['branches'] if r['world'] == world]
            assert ordinary['method'] == METHODS[0] and joint['method'] == METHODS[1]
            u = ordinary['final_metrics']['uv_count']; j = joint['final_metrics']['uv_count']
            wins += j < u; losses += j > u
            assert ordinary['final_metrics']['tolerance_OV_1p05'] == joint['final_metrics']['tolerance_OV_1p05'] == 0
            worlds.append({'world': world, 'ordinary': ordinary['final_metrics'], 'joint': joint['final_metrics'],
                'ordinary_new_device_operations': ordinary['new_device_operations'], 'joint_new_device_operations': joint['new_device_operations'],
                'ordinary_costs': ordinary['attributed_query_and_new_replay_costs'], 'joint_costs': joint['attributed_query_and_new_replay_costs']})
        gate = 'PASS_DEVELOPMENT_FULL_SUFFIX_JOINT_ACTUATION_OPPORTUNITY' if wins >= 2 and losses == 0 else 'FAIL_STOP_THIS_FULL_SUFFIX_GREEDY_INTERVENTION'
        put(out/'Independent_Audit.json', {'status': 'PASS_COMPLETE_DECLARED_CURRENT_STATE_SUFFIX_SOURCE_PHYSICS_CURSOR_REPLAY_CHECKPOINT_AND_COST_AUDIT',
            'all_eight_branches_complete': True, 'query_identities_checked': query_checked, 'actual_commits_checked': commits_checked,
            'complete_checkpoints_checked': checkpoints_checked, 'actual_costs': costs,
            'saved_result_verifier_callbacks_new_PF_calls': 0, 'new_model_optimizer_calls': 0,
            'audit_seconds_before_manifest': time.perf_counter()-begun, 'whole_original_DFF_ALT_DSE_or_LLM_superiority': 'NOT_TESTED',
            'fresh_nine_frozen': frozen_checks()})
        put(out/'Fixed_Gate_Decision.json', {'fixed_gate': gate, 'strict_UV_wins': wins, 'UV_losses': losses, 'worlds': worlds,
            'all_four_predeclared_inspected_development_worlds_retained': True, 'minimum_voltage_and_cost_tradeoffs_retained': True,
            'no_unused_confirmation_novelty_LLMattribution_or_full_DSE_claim': True,
            'failed_gate_no_LR_seed_Q_width_objective_budget_checkpoint_world_retunes': True})
        put(out/'Result.json', {'exit_code': 0, 'fixed_gate': gate, 'strict_UV_wins': wins, 'UV_losses': losses}); code = 0
    except BaseException as exc:
        put(out/'Failure.json', {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc(),
            'full_gate': 'UNKNOWN', 'original_failed_reader_retained': True, 'no_scientific_retry': True})
        put(out/'Result.json', {'exit_code': 1, 'fixed_gate': 'UNKNOWN'})
    finally: put(out/'Closed_Manifest.json', {'exit_code': code, 'members': inventory(out, hashes=True)})
    raise SystemExit(code)


def software_checks(roots):
    checked = []; new_science = 0
    for world, (_, original, _) in roots.items():
        for method in METHODS:
            current = copy.deepcopy(original); current['original_device_operation_budget'] = 25
            assert len(declared_universe(current, method)) > 0
            current['remaining_original_device_operation_slots'] = 1
            assert all(r['kind'] == 'ordinary' for r in declared_universe(current, method))
            checked.append(world+'|'+method+'|one_slot_no_joint')
    def mock(method, slots, uv, selection):
        c = {'original_device_operation_budget': 25, 'remaining_original_device_operation_slots': slots,
             'original_prefix_actions': [{}]*(25-slots), 'raw_current_receiver_scope': [0, 1],
             'positive_addition_lifetime_MVAr': {'0': 450.},
             'owned_bank_rows': [{'index': 7, 'bus': 0, 'q_mvar': -50.}]}
        calls = []; commits = []
        def measure(n): return {'uv_count': max(uv-n, 0)}
        def query(n, cursor, row):
            calls.append(row); accepted = selection == 'ordinary' and row['kind'] == 'ordinary' and row['receiver'] == 1 and row['q'] == 25
            accepted |= selection == 'joint' and row['kind'] == 'equal_owned_reallocation' and row['q'] == 25
            return {'candidate': candidate_identity(row), 'verdict': {'accepted': accepted},
                    'original_score': [0, int(accepted), 1., 0., -row['q']], 'receipt_id': str(len(calls))}
        def commit(n, cursor, selected):
            row = selected['candidate']; debit = 1 if row['kind'] == 'ordinary' else 2
            updated = copy.deepcopy(cursor); updated['remaining_original_device_operation_slots'] -= debit
            commits.append(debit); return n+1, updated, {'device_operations_debited': debit}
        result = run_suffix(0, c, method=method, metrics=measure, query=query, commit=commit,
            checkpoint=lambda *a: None, event=lambda *a: None, admit=lambda: None)[2]
        return calls, commits, result
    calls, commits, res = mock(METHODS[0], 2, 5, 'ordinary')
    assert commits == [1, 1] and len(calls) == 36 and res['stop_reason'] == 'original_device_operation_budget_exhausted'
    checked.append('two_complete_ordinary_decisions_and_original_budget_stop')
    calls, commits, res = mock(METHODS[1], 2, 5, 'joint')
    assert commits == [2] and len(calls) == 20 and res['new_device_operations'] == 2
    checked.append('complete_joint_universe_and_two_operation_debit')
    calls, commits, res = mock(METHODS[1], 2, 5, 'none')
    assert len(calls) == 20 and not commits and res['stop_reason'] == 'complete_declared_universe_no_protected_accepted_action'
    checked.append('all_cap_and_rejected_identities_retained_no_accepted_stop')
    calls, commits, res = mock(METHODS[1], 2, 0, 'none')
    assert not calls and res['stop_reason'] == 'full_restoration'
    checked.append('zero_UV_stops_without_queries')
    row = {'candidate': {'universe_index': 3}, 'verdict': {'accepted': True}, 'original_score': [0, 1, 2, 3, -25]}
    other = copy.deepcopy(row); other['candidate']['universe_index'] = 2
    assert choose([row, other]) == other; checked.append('original_earliest_tie_order')
    assert SOURCE_CERTIFICATE['all_original_commit_validation_checkpoint_function_ASTs_unchanged']
    return {'status': 'PASS_COMPLETE_LOOP_LABELLED_SOFTWARE_AND_ALL_FOUR_ACTUAL_INPUT_SCOPE_CHECKS',
            'checks': checked, 'new_model_PF_optimizer_calls': new_science,
            'software_is_not_full_policy_physics_or_model_benefit': True}


def prepare():
    local_root(B).mkdir(exist_ok=False); begun = time.perf_counter()
    try:
        old, cache, roots, entries = legacy_cache(); checks = software_checks(roots)
        put(B/'Software_Readiness.json', checks)
        pins = dict(read(TWO/'Protocol.json')['source_input_sha256'])
        sources = ['work/full_joint_suffix_benchmark_20261014.py', 'work/receding_owned_joint_controller_v1.py',
            'work/paid_joint_commit_v1.py', 'work/paid_joint_commit_v2.py', 'work/audit_spatial_allocation_inputs_v3_20261011.py',
            'work/audit_spatial_allocation_inputs_v2_20261011.py', 'work/lossless_evidence_byte_codec_v1.py',
            'work/durable_opaque_evidence_store_v1.py', 'work/candidate_process_evidence_utils.py']
        for name in sources: pins[name] = sha(R/name)
        for base, names in [(TWO, ['actual/Closed_Manifest.json', 'verified_handoff/Verified_Equal_Operation_Completion.json']),
                            (ENG, ['cold/Closed_Manifest.json', 'actual/Checkpoint_ACK.json', 'actual/committed_checkpoint/Manifest.json',
                                   'actual/committed_checkpoint/State.zlib', 'cold/Result.json', 'verified_handoff/Verified_Joint_Commit_Engineering.json'])]:
            for name in names: pins[str((base/name).relative_to(R))] = sha(base/name)
        assert len(roots) == 4 and read(TWO/'Completion.json')['reader_exit'] == 0
        assert read(ENG/'Completion.json')['reader_exit'] == 0
        # Pre-performance fixed source/reader/control/input lock. The worker does
        # not receive success-selected worlds or a mutable scientific config.
        now = datetime.now(timezone.utc)
        protocol = {'study': 'FOUR_FIXED_INSPECTED_CURRENT_STATE_FULL_RECEDING_ORDINARY_VS_OWNED_JOINT_DEVELOPMENT_SUFFIX',
            'frozen_at_utc': now.isoformat(), 'absolute_deadline_utc': (now+timedelta(seconds=7200)).isoformat(),
            'maximum_PF_attempts': 60000, 'maximum_storage_bytes': 16*1024**3,
            'all_four_fixed_worlds': list(roots), 'methods': list(METHODS), 'source_input_sha256': pins,
            'runtime': {n: importlib.metadata.version(n) for n in ('numpy', 'pandas', 'scipy', 'pandapower')},
            'solver_kwargs': old['trial_solver_kwargs'], 'old_exact_paid_cache_identities': len(cache),
            'seed': 'EXACT_SAVED_INPUT_RNG_EACH_BRANCH; no outcome seed sweep',
            'selection': 'ALL four original inspected severe current endpoints, both complete methods, original remaining slots out of25',
            'fixed_gate': 'At least2strict UV wins and0UV losses for complete joint suffix versus complete ordinary suffix acrossALL4; both fullprotected trajectories/source/rawscope/ops/stock/cap/cold/checkpoint/continuousreplay/cost/independent audit complete. Retain minvoltage,deficit,cost tradeoffs.',
            'refused_or_unknown': 'Explicit cap refusals, exceptions, missing/unexecuted identities and partials retained. A partial whole gate is UNKNOWN; no scientific retry/budget extension.',
            'whole_original_DFF_ALT_DSE_or_LLM_superiority': 'NOT_TESTED. Separate whole-scenario literal references/model-serving/same-joint-numerical control/unused confirmation still required.',
            'cached_queries': 'Previously paid exact typed-input/current-real-case/rawscope/stock/lifetime/resource identities reused, all attributed solver costs retained. Primary executed queries NEVER rerun; independent continuous commit replay explicitly paid.',
            'source_locked_reader': str(Path(__file__).relative_to(R)), 'reader_model_PF_optimizer_calls': 0,
            'new_model_optimizer_derivative_forecast_linear_solve_calls': 0,
            'goal_lifecycle': 'Actual goal active after host-authorized continuation; no assistant lifecycle override',
            'prior_eng_budget': 'Closed600seconds never extended/restarted; this new fixed study has own independent bounds',
            'cold_gate': 'Prior actual paid commit/cold backend following integration reused; new COMPLETE controller checkpoint cold-process check before further commits. Any failure stops original science; no replacement.',
            'cost_scope': 'New actual unique queries and continuous replay separately, attributed old/shared queries perbranch, full prefix/preparation/prior failure/preservation/cold/audit costs retained. No deployment latency claim; unmeasured historical subphases UNKNOWN.',
            'economic_superiority_gate': 'NOT_DEMONSTRATED by lowerUV alone; require fullmodel/physics/control/preparation costs in later matched study.'}
        put(B/'Protocol.json', protocol)
        put(B/'Preperformance_Reader_Source_Lock.json', {'status': 'FIXED_SOURCE_INPUT_CONTROL_READER_BEFORE_PERFORMANCE',
            'reader_source_sha256': sha(Path(__file__)), 'source_input_sha256': pins, 'methods': list(METHODS),
            'complete_8_branches_required': True, 'all_native_identities_and_continuous_actual_replays_required': True,
            'cold_state_scope': protocol['cold_gate'], 'no_complete_reader_on_partial': True})
        put(B/'Fresh_Frozen_Before.json', frozen_checks())
        put(B/'Preparation_Costs.json', {'software_input_cache_reader_source_lock_seconds': time.perf_counter()-begun,
            'new_model_PF_optimizer_calls': 0})
        print(json.dumps({'prepared': str(B), 'known_exact_cache': len(cache), 'checks': len(checks['checks']),
            'absolute_deadline': protocol['absolute_deadline_utc'], 'new_scientific_calls': 0}))
    except BaseException as exc:
        put(B/'Preparation_Failure.json', {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc(),
            'new_model_PF_optimizer_calls': 0, 'no_science_started': True}); raise


def run():
    p = read(B/'Protocol.json'); pin_check(p)
    assert datetime.now(timezone.utc) < datetime.fromisoformat(p['absolute_deadline_utc'])
    assert read(B/'Preperformance_Reader_Source_Lock.json')['reader_source_sha256'] == sha(Path(__file__))
    command = "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -match 'full_joint_suffix_benchmark_20261014.py.*--(worker|audit|checkpoint-cold)|joint_commit_cold_engineering_v1.py.*--(worker|cold|audit)|equal_operation_benchmark_v2.py' } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    check = subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe', '-NoProfile', '-Command', command],
        capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    assert check.returncode == 0 and not check.stdout.strip(), 'A real source owner already exists'
    put(B/'Fresh_Source_Ownership_Check.json', {'no_matching_actual_scientific_reader_sources': True,
        'checked_at_utc': datetime.now(timezone.utc).isoformat()})
    put(B/'coordinator.claim', {'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(), 'argv': sys.argv,
        'source_sha256': sha(Path(__file__))})
    science = launch('worker', B/'actual'); reader = launch('audit', B/'audit') if science == 0 else None
    put(B/'Completion.json', {'science_exit': science, 'reader_exit': reader, 'all_owned_chains_ended': True,
        'finished_at_utc': datetime.now(timezone.utc).isoformat(), 'no_automatic_retry': True})
    print(json.dumps({'science_exit': science, 'reader_exit': reader, 'path': str(B)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for flag in ('prepare', 'run', 'worker', 'audit', 'checkpoint-cold'): parser.add_argument('--'+flag, action='store_true')
    args = parser.parse_args(); assert sum(vars(args).values()) == 1
    if args.prepare: prepare()
    elif args.run: run()
    elif args.worker: worker()
    elif args.audit: audit()
    else: checkpoint_cold()
