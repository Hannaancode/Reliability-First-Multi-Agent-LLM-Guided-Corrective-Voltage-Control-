"""Bounded reads tolerate a concurrent writer, without accepting partial JSON."""
from pathlib import Path
import json,time
def read_json_ready(path,attempts=12):
    for attempt in range(attempts):
        try:return json.loads(Path(path).read_text(encoding='utf-8'))
        except (json.JSONDecodeError,FileNotFoundError,PermissionError):
            if attempt+1==attempts:raise
            time.sleep(.25)
