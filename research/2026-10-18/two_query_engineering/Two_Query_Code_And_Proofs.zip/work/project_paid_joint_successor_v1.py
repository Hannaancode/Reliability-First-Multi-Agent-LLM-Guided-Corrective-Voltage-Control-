"""Source-owned resource cursor for an observed paid simulated successor.

Does not commit, solve, generate, invent a successor or claim physical operation.
"""
import copy
from audit_spatial_allocation_inputs_v3_20261011 import signature
from joint_reallocation_opportunity_core_v1 import action,build_verifier
from original_local_paid_branch_broker_v1 import resource_eligible
from shared_original_serving_action_domain_v1 import build_current_domain

def project(before,after,cursor,row,receipt,*,runner,zones):
    if receipt['verdict']['accepted'] is not True:raise ValueError('Only an actually accepted paid successor')
    if not after.converged:raise ValueError('Unconverged paid successor')
    if max(after.res_bus.vm_pu)>1.05+1e-8:raise ValueError('Normal upper-band protection')
    if not resource_eligible(row,cursor):raise ValueError('Stock/cap/original operation limit')
    if row['receiver'] not in cursor['raw_current_receiver_scope']:raise ValueError('Native current receiver scope')
    _,actuate,_=build_verifier(runner.rescue,cursor)
    expected=actuate(copy.deepcopy(before),action(row))
    if signature(expected)!=signature(after):raise ValueError('Paid AFTERinputs do not match source actuation')
    vm=after.res_bus.vm_pu.to_numpy();observed=receipt['verdict']['after']
    if int((vm<.95).sum())!=observed['uv_count'] or abs(float(vm.min())-observed['vmin'])>1e-12 or abs(float(vm.max())-observed['vmax'])>1e-12:
        raise ValueError('Paid metric binding')
    c=copy.deepcopy(cursor);q=float(row['q']);bus=str(row['receiver']);debit=1 if row['kind']=='ordinary' else 2
    c['remaining_original_device_operation_slots']-=debit
    c['positive_addition_lifetime_MVAr'][bus]=c['positive_addition_lifetime_MVAr'].get(bus,0.)+q
    if debit==2:
        bank=next(r for r in c['owned_bank_rows'] if r['index']==row['donor_index'])
        if int(bank['bus'])!=row['donor_bus'] or -bank['q_mvar']<q:raise ValueError('Source-owned donor binding')
        bank['q_mvar']+=q
        c.setdefault('withdrawn_lifetime_MVAr',{})[str(row['donor_bus'])]=c.get('withdrawn_lifetime_MVAr',{}).get(str(row['donor_bus']),0.)+q
    introduced=[int(i) for i in after.shunt.index if i not in before.shunt.index]
    if len(introduced)!=1:raise ValueError('Source native added-bank count')
    bank=after.shunt.loc[introduced[0]]
    c['owned_bank_rows'].append({'index':introduced[0],'bus':int(bank.bus),'name':str(bank['name']),
        'q_mvar':float(bank.q_mvar),'origin':'OBSERVED_PAID_VIRTUAL_SUCCESSOR_NOT_ACTUAL_COMMIT'})
    for owned in c['owned_bank_rows']:
        actual=after.shunt.loc[owned['index']]
        if int(actual.bus)!=int(owned['bus']) or float(actual.q_mvar)!=float(owned['q_mvar']):raise ValueError('Whole owned-stock binding')
    assert c['withdrawals_refund_positive_addition_cap'] is False and c['remaining_original_device_operation_slots']>=0
    assert all(v<=450 for v in c['positive_addition_lifetime_MVAr'].values())
    c.setdefault('paid_virtual_projection_trace',[]).append({'candidate':dict(row),'operations_debited':debit,
        'actual_commit':False,'source':'ACTUAL_OBSERVED_ACCEPTED_PAID_SIMULATION_RECEIPT'})
    domain=build_current_domain(after,c,runner=runner,zones=zones)
    result=domain['expanded_cursor_for_separately_fixed_future_protocol']
    assert result['remaining_original_device_operation_slots']==c['remaining_original_device_operation_slots']
    return result
