"""Labelled software checks and four existing-paid physical cursor projections."""
import copy,hashlib,json,os
from datetime import datetime,timezone
from pathlib import Path
import pandapower as pp
from operation_aware_paid_lookahead_v1 import Receipt,MissingEvidence,plan
from project_paid_joint_successor_v1 import project
from equal_operation_benchmark_v2 import initial_data,decode_capsule
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack

R=Path(__file__).resolve().parents[1];B=R/'outputs/operation_aware_lookahead_software_20261014'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(row):return tuple(row[k] for k in ['kind','receiver','q','donor_index','donor_bus'])
def main():
    B.mkdir(exist_ok=False);checks=[]
    def check(name,condition):assert condition,name;checks.append(name)
    def m(uv):return dict(uv_count=uv,deficit_sum=float(uv),vmin=.94 if uv else .95,vmax=1.04)
    def receipt(parent,aid,uv,ops=1,accepted=True,unknown=False):
        return Receipt(parent,aid,True,accepted,ops,parent+'/'+aid if accepted else None,m(uv) if accepted else None,
                       (int(uv==0),10-uv,10.-uv,.01,-25.) if accepted else None,unknown)
    def menu(parent,slots):return ['a','b','c','d']
    def second(parent,slots,k):return ['s'+str(i) for i in range(k)]
    calls=[]
    def query(parent,aid):
        calls.append((parent,aid))
        if parent=='r':return receipt(parent,aid,{'a':2,'b':3,'c':4,'d':5}[aid],2)
        return receipt(parent,aid,0 if parent=='r/b' else 1,2)
    wide=plan('r',m(10),4,menu,second,query,mode='breadth4_followup4')
    narrow=plan('r',m(10),4,menu,second,query,mode='immediate1_followup16')
    check('SYNTHETIC_BREADTH_CAN_DIFFER_FROM_IMMEDIATE_GREEDY',wide['selected']['first']=='b' and narrow['selected']['first']=='a')
    check('IDENTICAL16_FOLLOWUP_ALLOWANCE',wide['second_queries']==narrow['second_queries']==16)
    check('JOINT_PLUS_JOINT_DEBITS4_NOT2',wide['selected']['operations']==4)
    check('NO_COMMIT_IN_KERNEL',wide['not_an_actual_commit_or_LLM_or_whole_policy'] is True)
    no_calls=len(calls)
    terminal=plan('r',m(0),4,menu,second,query,mode='breadth4_followup4')
    check('ZERO_UV_TERMINAL_NOQUERY',terminal['selected'] is None and len(calls)==no_calls)
    no_slots=plan('r',m(10),0,menu,second,query,mode='breadth4_followup4')
    check('EXHAUSTED_ORIGINAL_BOUND_NOQUERY',no_slots['selected'] is None and len(calls)==no_calls)
    def joint_menu(parent,slots):return ['a']
    tight=plan('r',m(10),2,joint_menu,second,query,mode='breadth4_followup4')
    check('JOINT_USES_LAST2_SLOTS_NOFOLLOWUP',tight['second_queries']==0 and tight['selected']['operations']==2)
    def bad_query(parent,aid):return Receipt(parent,aid,False,None,1,None,None,None,True)
    try:plan('r',m(10),4,joint_menu,second,bad_query,mode='breadth4_followup4');raise AssertionError('Missing verifier accepted')
    except MissingEvidence:checks.append('MISSING_VERIFIER_RETURN_ABORTS_NOT_NEGATIVE')
    def rejected(parent,aid):return receipt(parent,aid,10,1,False,True)
    reject=plan('r',m(10),4,joint_menu,second,rejected,mode='breadth4_followup4')
    check('RECORDED_NATIVE_PF_REJECT_PRESERVES_PHYSICAL_UNKNOWN',reject['selected'] is None and reject['physical_failure_rejections']==1)
    def unsafe(parent,aid):
        r=receipt(parent,aid,0);return Receipt(r.parent,r.action,True,True,1,r.successor,{**r.metrics,'vmax':1.051},r.native_score)
    try:plan('r',m(10),4,joint_menu,second,unsafe,mode='breadth4_followup4');raise AssertionError('Unsafe accepted')
    except MissingEvidence:checks.append('UPPER_GUARD_CANNOT_BE_BYPASSED_BY_ZERO_UV')
    try:plan('r',m(10),1,joint_menu,second,query,mode='breadth4_followup4');raise AssertionError('Extra operation')
    except MissingEvidence:checks.append('ONE_SLOT_CANNOT_ADMIT_JOINT')
    def duplicate(parent,slots):return ['a','a']
    try:plan('r',m(10),4,duplicate,second,query,mode='breadth4_followup4');raise AssertionError('Duplicate root')
    except MissingEvidence:checks.append('DUPLICATE_ROOT_ID_ABORTS')
    def forged(parent,aid):return receipt('other',aid,1)
    try:plan('r',m(10),4,joint_menu,second,forged,mode='breadth4_followup4');raise AssertionError('Wrong parent')
    except MissingEvidence:checks.append('FORGED_PARENT_ABORTS')
    try:plan('r',m(10),4,joint_menu,second,query,mode='unfrozen');raise AssertionError('New mode')
    except ValueError:checks.append('UNFROZEN_WIDTH_MODE_REJECTED')
    # Actual-data projection checks reuse previously measured NETs only.
    def blocked(*a,**k):raise AssertionError('Software projection tests forbid new PF')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,blocked)
    old,paid,_=initial_data();_,runner,_=load_stack()
    metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    oldbase=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
    newbase=R/'outputs/shared_current_domain_physics_guarded_v2_20261014'
    new=read(newbase/'actual/Actual_New_Action_Records.json')['records'];fixtures=[]
    with (oldbase/'actual/capsules.bin').open('rb') as oldpack,(newbase/'actual/capsules.bin').open('rb') as newpack:
        for i,e in enumerate(old['current_endpoints'],1):
            before,cursor,_=load_endpoint(e);domain=build_current_domain(before,cursor,runner=runner,zones=zones)
            cursor=domain['expanded_cursor_for_separately_fixed_future_protocol'];rows={key(x):x for x in domain['all_declared_original9Q_ordinary_and_owned_joint_identities']}
            candidates=[]
            for x in paid:
                if x['world']==e['world'] and x['verif']['accepted'] and x['verif']['after']['vmax']<=1.05+1e-8:
                    candidates.append((x['original_score'],rows[key(x)],x['verif'],x['measured_receipt']['after'],oldpack))
            for x in new:
                if x['world']==e['world'] and x['verdict']['accepted']:
                    candidates.append((x['original_score'],rows[key(x['candidate'])],x['verdict'],x['measured_receipt']['after'],newpack))
            score,row,verdict,descriptor,pack=max(candidates,key=lambda x:tuple(x[0]));after=decode_capsule(pack,descriptor)['net']
            before_bytes=repr(before.shunt.to_dict());cursor_copy=copy.deepcopy(cursor)
            projected=project(before,after,cursor,row,{'verdict':verdict},runner=runner,zones=zones)
            debit=1 if row['kind']=='ordinary' else 2
            check(f'ACTUAL_ROOT{i}_EXACT_OPERATION_DEBIT',projected['remaining_original_device_operation_slots']==cursor['remaining_original_device_operation_slots']-debit)
            check(f'ACTUAL_ROOT{i}_NO_PARENT_MUTATION',repr(before.shunt.to_dict())==before_bytes and cursor==cursor_copy)
            check(f'ACTUAL_ROOT{i}_NO_WITHDRAWAL_CAP_REFUND',projected['positive_addition_lifetime_MVAr'][str(row['receiver'])]==cursor['positive_addition_lifetime_MVAr'].get(str(row['receiver']),0.)+row['q'])
            check(f'ACTUAL_ROOT{i}_VIRTUAL_NOT_ACTUAL_COMMIT',projected['paid_virtual_projection_trace'][-1]['actual_commit'] is False)
            check(f'ACTUAL_ROOT{i}_SOURCE_OWNED_STOCK',all(float(after.shunt.at[b['index'],'q_mvar'])==b['q_mvar'] for b in projected['owned_bank_rows']))
            fixtures.append({'world':e['world'],'candidate':row,'operations':debit,'after_UV':verdict['after']['uv_count'],
                'scope':'Existing paid result, software integration fixture only; not new method outcome'})
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_LABELLED_SOFTWARE_AND_ALL4_EXISTING_PAID_CURSOR_FIXTURES',
        'checks':checks,'number_of_checks':len(checks),'actual_input_fixtures':fixtures,
        'new_model_PF_derivative_forecast_linear_solve_commits':0,
        'new_method_performance':'NOT_MEASURED','source_sha256':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),
            R/'work/operation_aware_paid_lookahead_v1.py',R/'work/project_paid_joint_successor_v1.py']}}
    with (B/'Software_And_Paid_Input_Readiness.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'software_checks':len(checks),'actual_paid_roots':4,'new_PF_model_calls':0,'method_performance':'NOT_MEASURED'}))
if __name__=='__main__':main()
