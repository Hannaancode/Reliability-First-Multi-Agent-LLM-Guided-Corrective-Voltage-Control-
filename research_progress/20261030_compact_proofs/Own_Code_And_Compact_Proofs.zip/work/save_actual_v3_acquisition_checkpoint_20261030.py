"""Save actual source-bound ownership and completed parallel evidence, no science."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/nonlinear500_v3_live_checkpoint_20261030'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def put(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
 O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
 ps="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python(w)?\\.exe$' -and $_.CommandLine -match '(run|audit|coordinate)_nonlinear500_receding_acquisition_v3_20261030|coordinate_acquisition_source_bound_owner_20261030' } | Select-Object ProcessId,ParentProcessId,CommandLine) | ConvertTo-Json -Depth 4"
 raw=subprocess.run(['pwsh','-NoProfile','-Command',ps],capture_output=True,text=True,check=True).stdout.strip()
 processes=json.loads(raw) if raw else [];processes=processes if isinstance(processes,list) else [processes]
 claim=read(R/'outputs/nonlinear500_receding_acquisition_v3_execution_20261030/owner.claim')
 ack=read(R/'outputs/nonlinear500_receding_acquisition_v3_execution_20261030/Bound_Owner_ACK.json')
 handoff=read(R/'outputs/nonlinear500_receding_acquisition_v3_handoff_20261030/owner.claim')
 primary=[x for x in processes if x['ProcessId']==claim['actual_pid'] and x['ParentProcessId']==claim['parent_pid'] and 'run_nonlinear500_receding_acquisition_v3_20261030.py' in x['CommandLine']]
 parent=[x for x in processes if x['ProcessId']==claim['parent_pid'] and 'run_nonlinear500_receding_acquisition_v3_20261030.py' in x['CommandLine']]
 coordinator=[x for x in processes if x['ProcessId']==handoff['actual_pid'] and x['ParentProcessId']==handoff['parent_pid'] and 'coordinate_nonlinear500_receding_acquisition_v3_20261030.py' in x['CommandLine']]
 source=R/'work/run_nonlinear500_receding_acquisition_v3_20261030.py'
 assert hashlib.sha256(source.read_bytes()).hexdigest()==claim['source_sha256']
 assert ack['actual_pid']==claim['actual_pid'] and ack['actual_parent_pid']==claim['parent_pid']
 state=dict(at_utc=now,status='ACTUAL_V3_NUMERICAL_ACQUISITION_LIVE' if primary and parent else 'ACTUAL_V3_PHASE_CHANGE_REQUIRES_TERMINAL_EVIDENCE',
  goal='ACTIVE',primary_live=bool(primary and parent),coordinator_live=bool(coordinator),
  actual_primary=claim,actual_bound_ACK=ack,actual_coordinator=handoff,actual_processes=processes,exec_session_id=65202,
  frozen_protocol='outputs/nonlinear500_receding_acquisition_v3_preparation_20261030/Protocol.json',
  source_protocol_sha256='1e71232539b687b6fbdfb727d81aef770143c520cf0b6fa2ed5c77403ad0d742',
  final_independent_readiness='outputs/nonlinear500_receding_acquisition_v3_source_preparation_20261030/Final_Prospective_Protocol_Review.json',
  actual_HOST_admission='outputs/nonlinear500_frozen_v3_host_admission_20261030/Result.json',
  science_seconds=7200,reader_seconds=7200,process_seconds=7500,original_deadline_monotonic=claim['original_deadline_monotonic'],
  registered_cases=500,case_order='0..499 unchanged',horizon=100,new_PF_model_GPU_training_entry_enabled=False,
  numerical_costs='Actual live journals; final counts and evidence pending independent reader. Counts are not completion.',
  physical_rule='Reuse only exact verified old paid receipts. Missing/unsafe/unclosed paths UNKNOWN; no new PF or whole500 performance claim from acquisition.',
  first_paid_numerical_proposal='Mandatory old receipt reuse; no repeated first computation.',
  old_v1_failure='Missing dependency; independent zero-science diagnosis and unknown unclaimed original chain retained.',
  old_v2_failure='Runtime source read access denied; independent zero-science diagnosis and unknown unclaimed original chain retained.',
  access_repair='Only public isolated dependency read/execute access for HOME corrected; source bytes/original scientific environment unchanged. Initial partial ACL repair and failed HOST inventory check retained.',
  GPU_assignments=[],waiting_timer=None,thesis_requirements_complete=27,thesis_requirements_total=35,all_six_final_goals='OPEN',
  usage_observation=dict(usedPercent=74,remainingPercent=26,ordinaryUsageAllowed=True,not_a_reset_prediction=True),
  parallel_evidence=dict(thesis_independent_prose_review='outputs/thesis_evidence_updates_independent_prose_20261030/Review.json',
   RAG500_source_match='outputs/rag500_source_membership_recovery_20261030/Aggregate_Findings.json',
   RAG500_ambiguity='outputs/rag500_source_membership_recovery_20261030/Content_Identity_Clarification.json',
   T05='All4-root per-commit descriptive attribution ledger in preparation; no causal claim.'),
  next_ordered_actions=[
   'Leave current source/settings/bounds unchanged. Never duplicate/restart this owner or its one pinned first reader.',
   'Sole coordinator follows actual closed primary termination with one partial-aware saved-evidence reader; inspect actual EndACK/Result/Manifest/IndependentAudit/Completion at terminal.',
   'Missing identities and partial/failure costs remain UNKNOWN/retained; no automatic new physics, extension or performance rollout.',
   'Finish all500 historical THEORY source-lineage DOCX integration and all4-root component ledger in parallel.',
   'Publish compact own source/proofs/current resume with fresh GitHub lease and exact downloaded-byte verification.',
   'Only if the actual live result is the sole ready dependency, schedule one estimated check and delete it at terminal.'])
 put(O/'Exact_Resume.json',state)
 master=R/'outputs/research_resumption_20261028/Current_Resume.json';shutil.copy2(master,O/'Previous_Current_Resume.json');r=read(master)
 r.update(state);r['latest_exact_execution_state']=(O/'Exact_Resume.json').relative_to(R).as_posix();r['owned_scientific_jobs']=[{'source':source.relative_to(R).as_posix(),'pid':claim['actual_pid'],'parent_pid':claim['parent_pid']}] if primary else [];r['new_work_publication']='Current30October additions remain local pending compact proof publication.';put(master,r)
 tasks=R/'outputs/research_tasks_20261014/Tasks.json';t=read(tasks);t.update(updated_at_utc=now,latest_exact_execution_state=r['latest_exact_execution_state'],current_owned_jobs=r['owned_scientific_jobs'],current_GPU_assignments=[],thesis_documentation_requirements_complete=27);put(tasks,t)
 header='Actual numerical acquisition live; parallel source findings — '+now
 text=('Exact resume: '+r['latest_exact_execution_state']+'. Source-bound primary'+str(claim['actual_pid'])+'/parent'+str(claim['parent_pid'])+' and sole coordinator'+str(handoff['actual_pid'])+'/parent'+str(handoff['parent_pid'])+' freshly inspected. Fixed7200-second numerical bound,7500process bound, all500 fixed-order cases; newPF/model/GPU disabled and old paid first math/physics reused. One independent partial-aware reader follows actual closure. No completed benchmark or LLM superiority result yet. Both zero-science setup failures and access-repair limitations retained; no old owner restarted. All500 historical RAG printed questions/reference pairs exactly match THEORY content;575question occurrences versus511exact QA pairs, with ambiguity retained, and4NERC cross-corpus QA matches. This does not establish runtime-index/training membership or99percent accuracy.27/35thesis items and all6finalgoalsOPEN. No waiting timer.\n')
 for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
  p=R/rel;p.write_text('## '+header+'\n\n'+text+'\n'+p.read_text(encoding='utf-8'),encoding='utf-8')
 with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+header+'\n'+text)
 print(json.dumps({'state':state['status'],'primary_pid':claim['actual_pid'],'coordinator_pid':handoff['actual_pid'],'source_bound_live':bool(primary and parent),'progress_saved':True}))
if __name__=='__main__':main()
