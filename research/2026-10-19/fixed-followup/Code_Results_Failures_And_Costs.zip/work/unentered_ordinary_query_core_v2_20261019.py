"""One-identity routing of the existing query/replay and independent reader.

Only arity, source namespace, readiness name and single cold-reader accounting
change. All native action, solver, score, field and reservation predicates stay.
"""
import ast,copy,json,pickle,random,time
from pathlib import Path
import numpy as np
import exact_two_paid_query_engineering_20261018 as old
import exact_new_query_reservations_v1_20261018 as reservation
import audit_exact_two_paid_query_engineering_20261018 as audit
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from fixed_three_query_core_20261019 import transform
from prospective_query_custody_v3_20261019 import bind
B=R/'outputs/unentered_ordinary_query_acquisition_v2_20261019'
I=R/'outputs/next_ordinary_query_input_20261019'
rsrc=Path(reservation.__file__).read_text('utf-8');redits=[('assert len(rows)==len(self.allowed)==2','assert len(rows)==len(self.allowed)==1')]
node=next(n for n in ast.parse(transform(rsrc,redits)).body if isinstance(n,ast.ClassDef) and n.name=='Reservations')
env=reservation.__dict__.copy();exec(compile(ast.Module(body=[node],type_ignores=[]),__file__,'exec'),env);Reservations=env['Reservations']

def known_keys():return set(old.known_keys())|set(read(I/'Exact_Candidate_Inputs.json')['all_recent13_paid_keys'])

def helpers(entrypoint):
    nodes=[copy.deepcopy(n) for n in ast.parse(Path(old.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name not in ('worker','coordinator','known_keys')]
    env=old.__dict__.copy();env.update(B=B,I=I,__file__=str(entrypoint),Reservations=Reservations,known_keys=known_keys)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(old.__file__),'exec'),env)
    fn=ast.unparse(next(n for n in nodes if n.name=='execute_one'));fn=transform(fn,[("f'exact_two_query_{index + 1}'","f'exact_ordinary_query_{index + 1}'")]);exec(compile(fn,__file__,'exec'),env)
    return bind(env,entrypoint)

def worker(entrypoint):
    text=Path(old.__file__).read_text('utf-8');n=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='worker');fn='\n'.join(text.splitlines()[n.lineno-1:n.end_lineno])
    fn=transform(fn,[("'PASS_FIXED_TWO_QUERY_PRELAUNCH_ZERO_SCIENCE'","'PASS_FIXED_SINGLE_QUERY_PRELAUNCH_ZERO_SCIENCE'")])
    h=helpers(entrypoint);exec(compile(fn,str(old.__file__),'exec'),h);return h['worker']

READER_EDITS=[
    ("['uv_count']==17","['uv_count']==p['source_metrics']['uv_count']"),
    ("for phase in ('warm','cold'):","for phase in ('warm',):"),
    ("len(all_messages)==2 and len(replays)==2 and counts['PF_attempts']==4 and counts['PF_returns']==4","len(all_messages)==1 and len(replays)==1 and counts['PF_attempts']==2 and counts['PF_returns']==2"),
    ("if (B/'Final_State_ACK.json').exists():","if (B/'Warm_State_ACK.json').exists():"),
    ("final=restore_state(read(B/'Final_State_ACK.json'))","final=restore_state(read(B/'Warm_State_ACK.json'))"),
    ("warm['next_index']==1 and final['next_index']==2 and len(final['paid_query_registry'])==2","warm['next_index']==1 and final['next_index']==1 and len(final['paid_query_registry'])==1"),
    ("history=verify_history(final['history_anchor']);assert len(history)==2","history=verify_history(final['history_anchor']);assert len(history)==1"),
    ("assert read(B/'cold/Cold_Restore_Proof.json')['status'].startswith('PASS_EXACT_LATEST_QUERY_ONLY_STATE')","import random, numpy as np\n            random.setstate(final['python_rng']);np.random.set_state(final['numpy_rng'])\n            assert pickle.dumps(random.getstate(),5)==pickle.dumps(final['python_rng'],5) and pickle.dumps(np.random.get_state(),5)==pickle.dumps(final['numpy_rng'],5)\n            put(out/'Cold_Query_State_Restore_Proof.json',{'status':'PASS_INDEPENDENT_COLD_READER_FULL_QUERY_STATE_NET_CURSOR_REGISTRY_HISTORY_RNG_COSTS_ORIGINAL_DEADLINE','no_new_science':True,'not_controller_restart':True})"),
    ("'PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING'","'PASS_COMPLETE_FIXED_SINGLE_QUERY_AND_CHARGED_REPLAY_COLD_READER'")]

def reader(entrypoint):
    text=Path(audit.__file__).read_text('utf-8');n=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main');fn='\n'.join(text.splitlines()[n.lineno-1:n.end_lineno]);fn=transform(fn,READER_EDITS)
    h=helpers(entrypoint);env=audit.__dict__.copy();env.update({k:h[k] for k in ['B','I','claim','admit','input_state','restore_state','verify_file']});env.update(__file__=str(entrypoint),pickle=pickle)
    exec(compile(fn,str(audit.__file__),'exec'),env);return env['main']

def certificate():
    worker(__file__);reader(__file__)
    return {'original_worker_sha256':sha(old.__file__),'original_reader_sha256':sha(audit.__file__),'reservation_source_sha256':sha(reservation.__file__),'reservation_change_inverse_exact':redits,
       'worker_change':'Readiness name only; only warm mode exposed for one allowed identity. execute_one changes receipt namespace only.','independent_reader_inverse_exact_changes':READER_EDITS,'native_source_solver_score_field_checks_unchanged':True,'new_scientific_calls':0}

def fixture_warm(entrypoint):
    h=helpers(entrypoint);p=read(B/'Protocol.json');out=B/'fixture_warm';h['claim'](out,p);state=h['input_state']();_,runner,_=old.load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    random.seed(p['seed']);np.random.seed(p['seed']);coverage=dict(read(B/'Attempt_Coverage_Certificate.json'),mode='SOFTWARE_FIXTURE_NO_PF')
    r=Reservations(B/'fixture_reservations',protocol=p,coverage=coverage,known_attempt_keys=known_keys(),runner=runner,zones=zones)
    hist=old.History(B/'fixture_history',source_anchor=sha(B/'Protocol.json'),input_anchor=p['input_state_sha256'],max_bytes=1024**2)
    item=p['exact_new_query_rows'][0];key=r.reserve(state['net'],state['cursor'],item['row'],role=item['role']);r.start(key,PF_id='SOFTWARE_ONLY',solver_kwargs=p['solver_kwargs'],software_fixture=True);r.closed(key,{'PF_id':'SOFTWARE_ONLY','outcome':'SOFTWARE_NO_PF'})
    hist.append('software_boundary',{'key':key,'newPF':0});state.update(reservation_anchor=r.anchor(),history_anchor=hist.anchor(),next_index=1,python_rng=random.getstate(),numpy_rng=np.random.get_state(),absolute_deadline_utc=p['absolute_deadline_utc'],protocol_sha256=sha(B/'Protocol.json'))
    r.close();hist.close();put(B/'Fixture_State_ACK.json',h['save_state'](out/'State.zlib',state));put(out/'Result.json',{'status':'PASS_SINGLE_RESERVED_SOFTWARE_BOUNDARY','new_scientific_calls':0});manifest(out)

def fixture_cold(entrypoint):
    h=helpers(entrypoint);p=read(B/'Protocol.json');out=B/'fixture_cold';h['claim'](out,p);state=h['restore_state'](read(B/'Fixture_State_ACK.json'));source=h['input_state']();old.require_same(state['net'],source['net']);assert state['cursor']==source['cursor'] and state['next_index']==1
    assert state['absolute_deadline_utc']==p['absolute_deadline_utc'] and state['protocol_sha256']==sha(B/'Protocol.json')
    assert len(old.verify_history(state['history_anchor']))==1
    random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng']);assert pickle.dumps(random.getstate(),5)==pickle.dumps(state['python_rng'],5) and pickle.dumps(np.random.get_state(),5)==pickle.dumps(state['numpy_rng'],5)
    _,runner,_=old.load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    r=Reservations(B/'fixture_reservations',protocol=p,coverage=dict(read(B/'Attempt_Coverage_Certificate.json'),mode='SOFTWARE_FIXTURE_NO_PF'),known_attempt_keys=known_keys(),runner=runner,zones=zones,restore_anchor=state['reservation_anchor'])
    item=p['exact_new_query_rows'][0]
    try:r.reserve(state['net'],state['cursor'],item['row'],role=item['role'])
    except reservation.AlreadyAttemptedIdentity:pass
    else:raise AssertionError('Cold duplicate must reject')
    r.close();put(out/'Result.json',{'status':'PASS_REAL_COLD_QUERY_STATE_AND_DUPLICATE_REJECTION','new_scientific_calls':0});manifest(out)
