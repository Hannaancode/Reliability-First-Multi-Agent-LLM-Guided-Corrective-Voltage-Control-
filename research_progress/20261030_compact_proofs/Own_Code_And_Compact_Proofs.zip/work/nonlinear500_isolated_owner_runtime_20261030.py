"""Source-only/runtime admission for the distinct v2 acquisition owner and reader.

No scientific module is imported here. Pure validation precedes sys.path changes
and importing the isolated psutil package. Failed original ownership stays UNKNOWN.
"""
from pathlib import Path
from datetime import datetime
import hashlib
import importlib
import json
import sys

SOURCE_FILE = 'work/nonlinear500_isolated_owner_runtime_20261030.py'
DEPENDENCY_DIRECTORY = 'work/owner_runtime_dependencies_20261030'
WHEEL_FILE = 'work/owner_runtime_wheels_20261030/psutil-7.2.2-cp37-abi3-win_amd64.whl'
WHEEL_SHA256 = 'eb7e81434c8d223ec4a219b5fc1c47d0417b12be7ea866e24fb5ad6e84b3d988'
OLD_PROTOCOL = 'outputs/nonlinear500_receding_acquisition_preparation_20261030/Protocol.json'
OLD_SOURCE_PATTERNS = {
    'run_nonlinear500_receding_acquisition_20261030',
    'audit_nonlinear500_receding_acquisition_20261030',
    'coordinate_nonlinear500_receding_acquisition_20261030',
    'coordinate_acquisition_source_bound_owner_20261030',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_path(root, relative):
    root = Path(root).resolve()
    path = (root / relative).resolve()
    path.relative_to(root)
    return path


def read_ref(root, reference):
    path = checked_path(root, reference['path'])
    if sha(path) != reference['sha256']:
        raise ValueError('Admission reference bytes changed: ' + reference['path'])
    if 'bytes' in reference and path.stat().st_size != reference['bytes']:
        raise ValueError('Admission reference size changed')
    return json.loads(path.read_text(encoding='utf-8'))


def validate_previous_setup(root, previous):
    """Verify preserved setup failure and independent, separately scoped absence."""
    if previous['old_study_never_restarted'] is not True:
        raise ValueError('Original failed study must remain closed')
    if previous['failed_protocol']['path'] != OLD_PROTOCOL:
        raise ValueError('Wrong failed study lineage')
    old = read_ref(root, previous['failed_protocol'])
    diagnostic = read_ref(root, previous['independent_failure_diagnosis'])
    terminal = read_ref(root, previous['fresh_terminal_absence'])
    if diagnostic['status'] != 'PASS_SOURCE_BOUND_PREENTRY_ZERO_CALLBACK_DIAGNOSIS_ACTUAL_PID_UNCLAIMED':
        raise ValueError('Independent pre-entry diagnosis required')
    evidence = {r['path']: r for r in diagnostic['evidence']}
    if evidence[OLD_PROTOCOL]['sha256'] != previous['failed_protocol']['sha256']:
        raise ValueError('Diagnosis belongs to another protocol')
    for reference in diagnostic['evidence']:
        if sha(checked_path(root, reference['path'])) != reference['sha256']:
            raise ValueError('Failed study evidence changed')
    account = diagnostic['derived_scientific_accounting']
    for key in ('new_numerical_proposals_attempted', 'scipy_optimizer_calls', 'native_slsqp_calls',
                'AC_equation_or_derivative_callbacks', 'new_PF_calls', 'model_GPU_training_calls',
                'scientifically_entered_cases'):
        if type(account[key]) is not int or account[key] != 0:
            raise ValueError('An entered scientific identity cannot be restarted')
    if account['registered_cases'] != 500 or account['unentered_cases'] != 500 or account['first_paid_mathematics_consumed'] is not False:
        raise ValueError('All500 must have remained scientifically unentered')
    if diagnostic['preserved_unknowns']['original_End_ACK_chain_ended'] is not False:
        raise ValueError('Do not rewrite failed original ownership evidence')
    if terminal['status'] != 'PASS_FRESH_EXACT_SOURCE_PROCESS_ABSENCE_AFTER_PREENTRY_FAILURE':
        raise ValueError('Separate fresh terminal source absence required')
    if terminal['count'] != 0 or terminal['matching_processes'] != [] or set(terminal['source_patterns']) != OLD_SOURCE_PATTERNS:
        raise ValueError('Original exact-source process remains present or incomplete inventory')
    if terminal['original_authenticated_End_ACK_unchanged'] is not True or terminal['original_authenticated_chain_end'] != 'UNKNOWN':
        raise ValueError('Original unclaimed chain uncertainty must remain')
    if terminal['new_scientific_calls'] != 0 or terminal['failed_launcher_pid'] != diagnostic['observed_failure']['launcher_pid']:
        raise ValueError('Terminal certificate does not bind setup failure')
    if terminal['observed_launcher_exit_code'] != diagnostic['observed_failure']['exit_code']:
        raise ValueError('Failed launcher exit differs')
    if datetime.fromisoformat(terminal['checked_utc'].replace('Z', '+00:00')) < datetime.fromisoformat(diagnostic['at_utc']):
        raise ValueError('Terminal absence predates independent diagnosis')
    for relative, digest in old['sources'].items():
        if sha(checked_path(root, relative)) != digest:
            raise ValueError('Original frozen source changed: ' + relative)
    return old


def validate_runtime_spec(root, spec, sources, *, expected_executable=None):
    """Pure byte/source validation; deliberately does not import the dependency."""
    root = Path(root).resolve()
    if spec['directory'] != DEPENDENCY_DIRECTORY or spec['package'] != 'psutil' or spec['version'] != '7.2.2':
        raise ValueError('Unreviewed isolated dependency configuration')
    certificate = read_ref(root, spec['actual_runtime_certificate'])
    admission_source = spec['actual_runtime_admission_source']
    if admission_source['path'] != 'work/check_acquisition_actual_runtime_20261030.py' or sources.get(admission_source['path']) != admission_source['sha256'] or sha(checked_path(root, admission_source['path'])) != admission_source['sha256']:
        raise ValueError('Actual runtime admission source is not pinned')
    if certificate['status'] != 'PASS_NEW_ACTUAL_RUNTIME_IMPORT_PROCESS_CLOCK_ADMISSION_ONLY':
        raise ValueError('Actual runtime import/process/clock admission is missing')
    if certificate['official_wheel_sha256'] != WHEEL_SHA256 or spec['official_wheel']['path'] != WHEEL_FILE or spec['official_wheel']['sha256'] != WHEEL_SHA256:
        raise ValueError('Official pinned wheel changed')
    if sha(checked_path(root, WHEEL_FILE)) != WHEEL_SHA256:
        raise ValueError('Installed wheel custody changed')
    if certificate['clock_stable_in_process'] is not True or certificate['exact_command_parser_roundtrip'] is not True:
        raise ValueError('Actual clock/command check is incomplete')
    if certificate['old_physics_environment_modified'] is not False or certificate['previous_failed_setup_preserved'] is not True:
        raise ValueError('Dependency admission must preserve prior scientific environment and failure')
    if certificate['new_optimizer_PF_model_equation_derivative_calls'] != 0 or certificate['old_NETs_NPZs_calculation_journals_or_fixtures_read'] != 0:
        raise ValueError('Runtime certificate is not imports-only evidence')
    if expected_executable is not None and Path(certificate['executable']).resolve() != Path(expected_executable).resolve():
        raise ValueError('Actual interpreter differs from admitted interpreter')
    directory = checked_path(root, DEPENDENCY_DIRECTORY)
    actual_files = {p.relative_to(root).as_posix() for p in directory.rglob('*')
                    if p.is_file() and p.suffix.lower() in ('.py', '.pyd') and '__pycache__' not in p.parts}
    pins = spec['source_files']
    if actual_files != set(pins) or pins != certificate['isolated_dependency_sources'] or len(pins) != 11:
        raise ValueError('Isolated runtime source inventory differs from actual admission')
    for relative, digest in pins.items():
        if sources.get(relative) != digest or sha(checked_path(root, relative)) != digest:
            raise ValueError('Isolated runtime source pin failed: ' + relative)
    for name, row in certificate['imports'].items():
        path = Path(row['file']).resolve()
        relative = path.relative_to(root).as_posix()
        if sources.get(relative) != row['sha256'] or sha(path) != row['sha256']:
            raise ValueError('Admitted runtime import bytes changed: ' + name)
    for name, digest in certificate['local_modules'].items():
        relative = 'work/' + name + '.py'
        if sources.get(relative) != digest or sha(checked_path(root, relative)) != digest:
            raise ValueError('Admitted local module bytes changed: ' + name)
    return certificate


def admit_isolated_runtime(root, protocol):
    """Both prospective owner and reader call this before any psutil use."""
    if protocol['campaign_id'] != 'nonlinear500_receding_acquisition_v2_20261030':
        raise ValueError('Isolated runtime gate is only for the distinct v2 study')
    if protocol['sources'].get(SOURCE_FILE) != sha(checked_path(root, SOURCE_FILE)):
        raise ValueError('Runtime gate source is not frozen')
    validate_previous_setup(root, protocol['previous_failed_setup'])
    certificate = validate_runtime_spec(root, protocol['isolated_owner_runtime'], protocol['sources'],
                                        expected_executable=sys.executable)
    if sys.version != certificate['python']:
        raise ValueError('Python runtime version differs from actual admission')
    directory = checked_path(root, DEPENDENCY_DIRECTORY)
    sys.path.insert(0, str(directory))
    module = importlib.import_module('psutil')
    if Path(module.__file__).resolve() != checked_path(root, DEPENDENCY_DIRECTORY + '/psutil/__init__.py') or module.__version__ != '7.2.2':
        raise ValueError('Imported psutil is not the isolated admitted package')
    return {'actual_runtime_certificate': protocol['isolated_owner_runtime']['actual_runtime_certificate'],
            'package': 'psutil', 'version': module.__version__, 'module_file': str(Path(module.__file__).resolve()),
            'source_files_verified': len(certificate['isolated_dependency_sources']),
            'scope': 'Owner runtime admission only; no scientific callback'}
