# Expanded benchmark comparison and ownership

TPA is the KDD2024 authors' model. Our new current-Jacobian/LP controller is code implemented in this project using established numerical methods; it contains no LLM and its novelty is unproved. The original HierGrid trained LoRA/multi-agent controller remains a separate system. The one-point108→0UV result belongs to the numerical controller, while TPA ended77UV. It is not evidence that the original paper LLM beats published systems.

The roster now covers TPA; all10 current official MAPDN algorithm implementations; Stable-DDPG plus ordinary DDPG/linear controls; IJCAI2024MA-DELC; AAMAS2023safety-layerMARL; PowerGym PPO/SAC; classical droop/ACOPF; and two separately labelled LLM voltage-control preprints. This is a relevant comparison roster,not an exhaustive literature census or completed leaderboard. See Expanded_Comparator_Roster.json for primary links,availability and exact comparison gaps.

New substantive readiness:205 pinned official Stable-DDPG files were downloaded and byte-verified,including183 agent checkpoint files totaling4,051,067bytes. A separate local verification checked every Gitblob/SHA256 and all129 paths required by the author's four environment branches and three control families. All54extra checkpoint files are retained,not chosen by outcomes. These are checkpoint components,not183 different models. No author code executed,no checkpoint loaded,and no model/PF/GPU call occurred.

Execution sequence: (1)native13bus Stable-DDPG/DDPG/linear source-action-observation/plant/cold-loader engineering,using all3 source agent indices without checkpoint search;retain all other native families for subsequentfixed protocols;(2)complete HierGrid native inverter full-context/loader/physics gates with no input trimming;(3)freeze shared data,legal devices,information,protection,horizon,seed/training/finalcheckpoint,budgets and full costs before matched performance;(4)compare all preregistered cases and reportUV/OV,complete-restoration rate,trajectory violations,minimumvoltage,reactive support,operations,failures,PF/model/training/preparation time;(5)confirm any gain on genuinely unused cases. Native author reproductions and adaptations to our federation must stay distinguishable. A score on a different feeder/device set is not a valid superiority claim.

The current322 numerical zero uses centralized known-network information. TPA has distributed current/history/seasonal inputs. A fair LLM contribution test must separate these information roles and include the same numerical controller in the no-LLM ablation. The current HierGrid4096+384native interface is stopped for6/44 inputoverflows; no shorter prompts/dropped zones or automatic GPU launch.

Current human tasks in order:
1.G3 Compare relevant published methods and verify whether our complete system is better.
2.G2 Test our actual system on published datasets/test sets.
3.G1 Aim for zeroUV on severe federation cases while safely beating original DFF/DFF-ALT/unchanged DSE,with full BOTH costs.
4.G4 Fairly compare larger SLMs.
5.G5 Establish incremental LLM superiority using matched no-LLM and strong numerical controls.
6.G6 Implement/test cybersecurity after validated control/attribution.

All6finalgoals remainOPEN. No promise of a winning outcome,novelty or success probability. Frozen original assets,all stopped/partial/UNKNOWN evidence and exact costs remain preserved.
