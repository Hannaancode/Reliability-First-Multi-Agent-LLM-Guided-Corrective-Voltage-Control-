"""Persist measured progress, actual ownership and public code/proof package."""
import hashlib,json,os,zipfile
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from fixed_three_query_core_20261019 import B,PHASES
from candidate_process_evidence_utils import seal,frozen_checks
from equal_operation_benchmark_v2 import process
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
SCREEN=R/'outputs/unstarted_paid_suffix_with_fixed_three_20261019'
def atomic(path,v):
    temp=path.with_name(path.name+'.new')
    with temp.open('w',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(temp,path)
def main():
    at=datetime.now(timezone.utc).isoformat();audit=read(B/'audit/Independent_Audit.json');assert audit['status']=='PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
    out=B/'verified_completion';out.mkdir(exist_ok=False)
    actors=[]
    for phase in (*PHASES,'audit'):
        c=read(B/phase/'owner.claim');assert process(c['actual_pid']) is None and process(c['actual_parent_pid']) is None
        actors.append({'phase':phase,'claim':c,'End_ACK':read(B/(phase+'_End_ACK.json'))})
    summary=read(B/'fixed_k4_summary/All4_Results.json');assert summary['accepted_queries']==3 and summary['safe_query_best_UV']==14
    live=None
    if (SCREEN/'owner.claim').exists():
        c=read(SCREEN/'owner.claim');actual=process(c['actual_pid'])
        if actual:
            assert actual['ParentProcessId']==c['parent_pid'] and 'replay_paid_suffix_with_fixed_three_20261019.py' in actual['CommandLine']
            live={'actual_pid':c['actual_pid'],'shim_pid':c['parent_pid'],'source':'work/replay_paid_suffix_with_fixed_three_20261019.py','actual_command':actual['CommandLine'],'source_sha256':c['source_sha256'],'fixed_bound_seconds':900,'new_scientific_calls':0,'do_not_duplicate':True}
    checkpoint={'at_utc':at,'status':'COMPLETE_THREE_FIXED_QUERIES_INDEPENDENT_PASS_SAFE_CONDITIONAL_17TO14_UV','all_science_reader_actors_ended':True,'actors':actors,'audit':audit,
        'all4_original_menu':summary,'active_readonly_analysis':live,'GPU_allocations':[],'timers':[],
        'actual_new_commit_model_derivative_forecast_solve_calls':0,'all6finalgoals':'OPEN','full_matched_policy_DSE_LLM_superiority':'UNACHIEVED',
        'next':'Finish unchanged policy changed-evidence screen. Reuse ALL5newpaid receipts with costs and source-native verification. Missing next inputs stayUNKNOWN; no automatic newPF or simulation of unobserved AFTER.'}
    put(out/'Verified_Completion.json',checkpoint);put(out/'Frozen_Completion.json',frozen_checks())
    tasks=read(R/'outputs/research_tasks_20261014/Tasks.json');tasks['at_utc']=at;tasks['tasks'][0]['latest_20261019_query_acquisition']=str((out/'Verified_Completion.json').relative_to(R))
    tasks['tasks'][0]['current_result']='Two development worlds have observed zeroUV archived-prefix/numerical evidence. New originalK4 followup acquisition is complete: all3remaining queries safely reduce17to14UV under normalupper1.05, with exact independent replays and complete cold state. No new actual commit, complete policy outcome or LLM/DSE superiority.'
    tasks['tasks'][0]['next']=checkpoint['next'];tasks['latest_exact_execution_state']=str((out/'Verified_Completion.json').relative_to(R));atomic(R/'outputs/research_tasks_20261014/Tasks.json',tasks)
    master=R/'RESEARCH_TASKS.md';text=master.read_text('utf-8');lines=text.splitlines();lines[2]=f'Updated {at}. All six final goals remain open; verified subtasks retain their original evidence.'
    master.write_text('\n'.join(lines)+'\n\n19October measured step towardG1.7: originalK4 remaining3queries COMPLETE/independentPASS. Each safely17to14UV, Vmmax<=1.05; all118replays exact. No actualcommit/completepolicy/LLMadvantage. [Evidence](outputs/remaining_three_fixed_queries_20261019/verified_completion/Verified_Completion.json).\n','utf-8')
    path=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';state=read(path);state.update(at_utc=at,
        current_task={'status':'NEW_THREE_QUERY_ACQUISITION_COMPLETE_SAFE17TO14_UNCHANGED_POLICY_ANALYSIS_NEXT','evidence':str((out/'Verified_Completion.json').relative_to(R))},
        active_owned_jobs=[live] if live else [],latest_closed_continuation=str((out/'Verified_Completion.json').relative_to(R)),
        next_tasks=[checkpoint['next'],'Preserve exact next missing state/query/context, outcome-independent selection, source/native/mask/stock/cap/full-cost/persistent/ownership/reader gates before any further new science.','Keep all6priorities, fullbothDSEcosts and all adverse/partial/UNKNOWN/frozen evidence; no newGPU from these local physics outcomes.'])
    atomic(path,state)
    entry=f'\n\n{at} —19October remaining originalK4 ranks2/3/4 acquired ONCE. All3ACCEPTED: equal-owned bus14to19,100/75/50MVAr each reduce current17UVto14UV withVmmax<=1.05.6newPF(3primary+3explicitlychargedreplays),6returns0exceptions,2actualcoldprocessstatehandoffs,all118fieldsreplayexact. Sourceverifier/input/cursor/registry/history/RNG/cost/deadline/source/claims/ninefrozen independentauditPASS. No actualcommit or freshLLM/GPU/derivative/forecast/solve. CompleteoriginalK4 retainspriorbus42queryrejectedforOV; separateoldhashorderedcoldaction remainsseparate. FullDSE/LLM/zero-allgoalsUNACHIEVED. Allscience/readersended; sole changed-evidence policy analysis may be live perexactresume. Actualcosts '+json.dumps(audit['costs'],separators=(',',':'))+'.\n'
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write(entry);f.flush();os.fsync(f.fileno())
    header=f'LATEST VERIFIED THREE-QUERY ACQUISITION {at}\n\nAll3fixed remainingK4queries COMPLETE/independentPASS, safe17to14UV/Vmmax<=1.05.6PF incl3chargedreplays,all118fieldsexact,0exceptions. Noactualcommit/LLM/GPU/wholepolicyclaim. Read RESEARCH_TASKS.md and outputs/remaining_three_fixed_queries_20261019/verified_completion/Verified_Completion.json. Sole changed-evidence read-only analysis may be live; verify actualsourceclaim beforeintervention. No oldworkerrestart, duplicatedscience, sourceedit or budgetextension. All6finalgoalsopen; all oldadverse/partial/UNKNOWN/frozenassets and fullbothDSEcosts retained.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    names=['fixed_three_query_core_20261019.py','run_remaining_three_fixed_queries_20261019.py','audit_remaining_three_fixed_queries_20261019.py','certify_remaining_three_coverage_20261019.py','prepare_remaining_three_fixed_queries_20261019.py','summarize_fixed_k4_receipts_20261019.py','replay_paid_suffix_with_fixed_three_20261019.py','save_fixed_three_progress_20261019.py']
    files={p.relative_to(R).as_posix():p for p in B.rglob('*') if p.is_file() and 'verified_completion' not in p.parts and 'publication' not in p.parts}
    for n in names:files['work/'+n]=R/'work'/n
    files['completion/Verified_Completion.json']=out/'Verified_Completion.json';files['completion/Frozen_Completion.json']=out/'Frozen_Completion.json'
    local=seal(out,files,'Complete_Local_Three_Query_Evidence.zip')
    public=B/'publication';public.mkdir();selected={}
    for rel,h in read(B/'Protocol.json')['source_input_sha256'].items():
        p=R/rel
        if p.suffix=='.py':selected[p.relative_to(R).as_posix()]=p
    for n in names:selected['work/'+n]=R/'work'/n
    for p in B.rglob('*'):
        if not p.is_file() or 'publication' in p.parts:continue
        if p.suffix in ('.json','.md','.log') or p.name=='owner.claim':selected[p.relative_to(R).as_posix()]=p
    for rel in ('RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json'):selected[rel]=R/rel
    withheld=[]
    for n,p in list(selected.items()):
        if SECRET_NAME.search(p.name) or any(s.search(p.read_text('utf-8')) for s in SECRET):withheld.append(n);del selected[n]
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in selected.items()}
    put(public/'Manifest.json',{'status':'PUBLIC_CODE_AND_PROOFS_NO_RAW_NET_OR_MODEL_EXPORT','files':desc,'withheld_secret_screen':withheld,'local_complete_archive':local,'no_full_raw_backup_claim':True,'all6goalsopen':True})
    dest=public/'Three_Query_Code_And_Proofs.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in selected.items():z.write(p,n)
        z.write(public/'Manifest.json','Manifest.json')
    with zipfile.ZipFile(dest) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(selected)+1 and z.testzip() is None
        for n,m in desc.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
    put(public/'Package_Audit.json',{'status':'PASS_UNIQUE_MEMBERS_CRC_ALL_HASH_SECRET_SCREEN','bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(selected)+1,'withheld_secret_paths':withheld})
    print(json.dumps({'saved':True,'safe_query_UV':'17to14','new_PF':audit['costs']['PF_attempts'],'active_readonly_analysis':bool(live),'public_archive_bytes':dest.stat().st_size,'secrets_withheld':len(withheld)}))
if __name__=='__main__':main()
