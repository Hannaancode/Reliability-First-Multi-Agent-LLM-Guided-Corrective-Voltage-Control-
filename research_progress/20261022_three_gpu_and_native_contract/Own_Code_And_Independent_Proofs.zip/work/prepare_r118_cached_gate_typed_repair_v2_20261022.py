"""Preserve and invalidate a saved-only cache gate with a container mismatch."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    old=R/'work/check_r118_dff_paid_prefix_continuation_20261022.py';s=old.read_text('utf-8')
    s=s.replace("O=R/'outputs/r118_dff_paid_prefix_continuation_20261022'","O=R/'outputs/r118_dff_paid_prefix_continuation_v2_20261022'")
    s=s.replace("for c in cache:c['before']=decode(c['directory'],c['rec']['before']);c['after']=None", "for c in cache:\n        value=decode(c['directory'],c['rec']['before']);c['before']=value['net'] if isinstance(value,dict) and set(value)=={'net'} else value;c['after']=None")
    s=s.replace("if c['after'] is None:c['after']=decode(c['directory'],c['rec']['after'])", "if c['after'] is None:\n                    value=decode(c['directory'],c['rec']['after']);c['after']=value['net'] if isinstance(value,dict) and set(value)=={'net'} else value")
    s=s.replace("        def checkpoint(state):", "        raw_saved_pf=saved_pf\n        def saved_pf(net,**kw):\n            try:return raw_saved_pf(net,**kw)\n            except Exception as e:raise BaseException('CACHE_ENGINEERING_FAILURE_NOT_PHYSICS: '+repr(e)) from e\n        def checkpoint(state):")
    s=s.replace("    runs=[]", "    assert all(hasattr(c['before'],'shunt') for c in cache)\n    put(O/'Typed_Cache_Admission.json',dict(all_cached_before_are_actual_NET=True,unexpected_provider_errors_escape_original_Exception_handler=True,new_PF_calls=0))\n    runs=[]")
    new=R/'work/check_r118_dff_paid_prefix_continuation_v2_20261022.py';assert not new.exists();new.write_text(s,encoding='utf-8')
    p=R/'outputs/r118_dff_paid_prefix_continuation_20261022/Invalidated_Engineering_Gate_Addendum.json'
    with p.open('x',encoding='utf-8') as f:json.dump(dict(status='OLD_SOFTWARE_GATE_INVALID_NOT_A_DFF_RESULT',
        cause='Bridge capsules contain {net:NET}; old prefix capsules contain raw NET. Missing unwrap raised AttributeError, caught by original run_pf and treated as pf_failed. No native solve or model was called.',
        original_source_sha256=sha(old),original_result_sha256=sha(p.parent/'Continuation_Readiness.json'),
        additive_v2_source_sha256=sha(new),old_complete_source_result_must_not_be_used_for_performance=True,
        new_PF_model_calls=0,repair='Typed bridge container unwrap and fatal unexpected-cache-error propagation; old artifact/source kept.'),f,indent=2)
if __name__=='__main__':main()
