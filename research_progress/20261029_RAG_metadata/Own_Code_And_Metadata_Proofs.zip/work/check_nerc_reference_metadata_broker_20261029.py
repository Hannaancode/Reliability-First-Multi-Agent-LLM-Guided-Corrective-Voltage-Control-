"""One fixed all-entry check of an additive broker, zero model or physics calls."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, time, zipfile
from nerc_reference_metadata_broker_20261029 import ReferenceRegistry

R = Path(__file__).resolve().parents[1]
O = R/'outputs/nerc_reference_metadata_broker_20261029'
def sha(b): return hashlib.sha256(b).hexdigest()
def put(name, value): (O/name).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

def main():
    if O.exists(): raise RuntimeError('existing_output_no_repeat')
    O.mkdir(); start = time.perf_counter()
    inventory = json.loads((R/'outputs/powergridqa_archive_inventory.json').read_text('cp1252'))
    archive = next(a for a in inventory['archives'] if a['path'].endswith('PowerGridQA-main.zip'))
    member = next(m for m in archive['members'] if m['name'].endswith('/references.json'))
    protocol = {'at_utc': datetime.now(timezone.utc).isoformat(), 'status':'FIXED_BEFORE_OUTPUTS',
        'member':member['name'], 'expected_sha256':member['sha256'],
        'implementation_sha256':sha((R/'work/nerc_reference_metadata_broker_20261029.py').read_bytes()),
        'runner_sha256':sha(Path(__file__).read_bytes()),
        'cases':'Every registered entry: exact ID/URL lookup and verification; wrong URL from next entry; absent page/year/author/equation; malformed requests; source mutation; duplicate keys and wrong URL scheme.',
        'selection':'ALL entries in source order; no model-selected or outcome-selected subset.',
        'criterion':'Every expected status/value must agree. Preserve failures; no automatic repair or retry.',
        'claim_scope':'Metadata-bound application software. Registered URL does not establish document truth, answer entailment, retrieval or historical runtime.',
        'new_model_retrieval_PF_training_calls':0, 'original_sources_unchanged':True}
    put('Protocol.json',protocol)
    try:
        with zipfile.ZipFile(archive['path']) as z: raw = z.read(member['name'])
        registry = ReferenceRegistry.from_trusted_bytes(raw, member['sha256'])
        source = json.loads(raw.decode('utf-8-sig')); keys=list(source); rows=[]
        def check(label, req, status, value=None):
            got=registry.render(req); result=got['result']
            assert result['status']==status, (label,result)
            if value is not None: assert result['value']==value
            if status=='REGISTERED_METADATA':
                assert result['citation']=={'document_id':req['document_id'],'url':source[req['document_id']]}
                assert result['answer_truth']=='NOT_ASSESSED' and not result['linked_document_retrieved']
            rows.append({'label':label,'request':req,'expected_status':status,**got})
        for index,key in enumerate(keys):
            for field,value in [('document_id',key),('url',source[key])]:
                for operation in ['lookup','verify']:
                    req={'operation':operation,'document_id':key,'field':field}
                    if operation=='verify':req['value']=value
                    check(f'{key}:{operation}:{field}',req,'REGISTERED_METADATA',value)
            check(f'{key}:wrong_url',{'operation':'verify','document_id':key,'field':'url','value':source[keys[(index+1)%len(keys)]]},'REJECTED')
            for field in ['page','year','author','equation']:
                check(f'{key}:absent:{field}',{'operation':'lookup','document_id':key,'field':field},'NOT_STATED')
        malformed=[None, [], {}, {'operation':[]}, {'operation':'lookup','document_id':[],'field':'url'},
            {'operation':'lookup','document_id':keys[0],'field':[]},
            {'operation':'lookup','document_id':'LL00000000','field':'url'},
            {'operation':'lookup','document_id':keys[0],'field':'url','answer':'untrusted prose'},
            {'operation':'lookup','document_id':keys[0],'field':'answer'},
            {'operation':'verify','document_id':keys[0],'field':'url','value':True}]
        for i,req in enumerate(malformed):check(f'malformed:{i}',req,'REJECTED')
        negative=[]
        for label,data,expected in [
            ('mutated_source',raw+b' ',member['sha256']),
            ('duplicate_key',b'{"LL20190201":"https://www.nerc.com/a","LL20190201":"https://www.nerc.com/b"}',None),
            ('script_url',b'{"LL20190201":"javascript:alert(1)"}',None),
            ('credentials_url',b'{"LL20190201":"https://x:y@www.nerc.com/a"}',None)]:
            try:ReferenceRegistry.from_trusted_bytes(data,expected or sha(data))
            except ValueError as exc: negative.append({'label':label,'status':'REJECTED','reason':str(exc)})
            else:raise AssertionError(label)
        put('All_Fixed_Checks_LOCAL_ONLY.json',rows)
        put('Result.json',{'status':'PASS_ALL_FIXED_METADATA_CHECKS','at_utc':datetime.now(timezone.utc).isoformat(),
            'registry_entries':len(keys),'response_checks':len(rows),'loader_negative_checks':negative,
            'source_sha256':sha(raw),'all_checks_sha256':sha((O/'All_Fixed_Checks_LOCAL_ONLY.json').read_bytes()),
            'protocol_sha256':sha((O/'Protocol.json').read_bytes()),'workflow_seconds':time.perf_counter()-start,
            'new_model_retrieval_PF_training_calls':0,'end_to_end_RAG_or_security':'NOT_TESTED',
            'arbitrary_free_text_truth':'NOT_ASSESSED','original_sources_unchanged':True})
        print(json.dumps({'status':'PASS','entries':len(keys),'response_checks':len(rows),'loader_rejections':len(negative)}))
    except BaseException as exc:
        put('Failure.json',{'type':type(exc).__name__,'error':str(exc),'seconds':time.perf_counter()-start,'new_model_retrieval_PF_training_calls':0})
        raise

if __name__=='__main__':main()
