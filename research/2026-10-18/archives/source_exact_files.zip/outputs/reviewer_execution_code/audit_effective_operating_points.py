"""Compare applied network input states, including equivalent modification syntax."""
from pathlib import Path
from collections import defaultdict
import copy,json,hashlib
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack
v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json');before=pp.to_json(base)
split=json.loads((ROOT/'training_provenance/scenario_split_map.json').read_text());historical={};locked={};unknown=[]
known={'scale_all_loads','scale_loads_by_zone','open_line','drop_sgen_indices','drop_all_sgens','metadata_only_fault_event'}
def fingerprint(s):
    net=copy.deepcopy(base);v2.v0.apply_scenario_to_net(net,s,zones)
    # These are all physical variables changed by the actual scenario applicator.
    # Loads use effective P/Q so equivalent p/scaling representations coincide.
    state={'frozen_network_sha256':hashlib.sha256((ROOT/'pack/testbeds/federation_4mg_ieee118.json').read_bytes()).hexdigest(),'loads':[[int(i),int(r.bus),bool(r.in_service),float(r.p_mw)*float(r.scaling),float(r.q_mvar)*float(r.scaling)] for i,r in net.load.iterrows()],'line_status':[[int(i),bool(r.in_service)] for i,r in net.line.iterrows()],'sgens':[[int(i),int(r.bus),bool(r.in_service),float(r.p_mw)*float(r.scaling),float(r.q_mvar)*float(r.scaling)] for i,r in net.sgen.iterrows()]}
    for m in s['modifications']:
        if m['action'] not in known:unknown.append({'scenario_id':s['scenario_id'],'action':m['action']})
    return hashlib.sha256(json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
for p in sorted((ROOT/'pack/scenarios/federation').glob('*.json')):historical[p.stem]=fingerprint(json.loads(p.read_text()))
for p in sorted((ROOT/'bank/scenarios').glob('*.json')):locked[p.stem]=fingerprint(json.loads(p.read_text()))
assert pp.to_json(base)==before
groups=defaultdict(list)
for sid,h in historical.items():groups[h].append(sid)
rows=[{'scenario_id':sid,'effective_input_fingerprint':h,'overlap_with_saved_historical_ids':groups.get(h,[]),'overlap_with_saved_train_ids':[s for s in split['train_ids'] if historical[s]==h]} for sid,h in locked.items()]
report={'status':'applied_frozen_network_input_states_compared','historical_scenario_id_count':len(historical),'historical_distinct_effective_operating_points':len(groups),'split_unique_effective_points':{k:len({historical[sid] for sid in ids}) for k,ids in split.items()},'all_split_scenario_ids_unique_effective_points':len({historical[sid] for ids in split.values() for sid in ids}),'locked_case_count':len(locked),'locked_distinct_effective_operating_points':len(set(locked.values())),'exact_overlap_with_any_saved_historical':sum(bool(r['overlap_with_saved_historical_ids']) for r in rows),'exact_overlap_with_saved_train':sum(bool(r['overlap_with_saved_train_ids']) for r in rows),'historical_duplicate_effective_points':[ids for ids in groups.values() if len(ids)>1],'unknown_modifications_ignored_by_original_applicator':unknown,'base_preserved':True,'scope':'The original applicator is used on separate copies of the same frozen network. Fingerprints represent applied input states, not IDs, timestamps, or metadata-only fault labels. No new scenarios or controllers generated. This supplements the modification-level and saved-record audit; the exact final-adapter training invocation hash remains unavailable.','rows':rows}
Path('outputs/effective_operating_point_overlap.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['rows','historical_duplicate_effective_points']},indent=2))
