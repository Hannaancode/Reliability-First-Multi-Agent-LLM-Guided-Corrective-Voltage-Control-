"""Current live/closed ownership and documentation record; no scientific execution."""
from pathlib import Path
import datetime,hashlib,json,psutil
R=Path(__file__).resolve().parents[1]
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sh(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def put(p,d):(R/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n','utf-8')
now=datetime.datetime.now(datetime.timezone.utc).isoformat();cases=[]
for i in (1,3):
 base=f'outputs/original_missing_suffix_execution_20261028/case_{i:02d}'
 c=rd(base+'/owner.claim');s=rd(base+'/status.json')
 assert c['source_sha256']==sh('work/run_original_missing_suffix_colab_20261028.py')
 live=False
 if psutil.pid_exists(c['actual_pid']):
  proc=psutil.Process(c['actual_pid']);args=proc.cmdline()
  live=any(Path(a).name=='run_original_missing_suffix_colab_20261028.py' for a in args)
  if live:assert proc.ppid()==c['parent_pid'] and args[-2:]==['--case-index',str(i)]
 row={'case_index':i,'claim':c,'actual_matching_owner_live':live,'status_snapshot':s}
 if not live:
  row['end_ack']=rd(f'outputs/original_missing_suffix_coordination_20261028/case_{i:02d}/End_ACK.json')
  assert row['end_ack']['actual_owned_chain_ended'] and row['end_ack']['exit_code']==0
  assert s['runtime_released'] and s['all_actual_closed_artifacts_preserved']
 if (R/f'outputs/original_missing_suffix_independent_20261028/case_{i:02d}/Independent_Audit.json').exists():
  row['audit_status']=rd(f'outputs/original_missing_suffix_independent_20261028/case_{i:02d}/Independent_Audit.json')['status']
 else:row['audit_status']='PENDING_SOLE_COORDINATOR'
 cases.append(row)
coord=rd('outputs/original_missing_suffix_handoff_20261028/owner.claim')
assert coord['source_sha256']==sh('work/coordinate_original_missing_suffix_20261028.py')
active=[]
for p in psutil.process_iter(['pid','ppid','cmdline']):
 try:
  args=p.info['cmdline'] or []
  if any(Path(a).name in ['coordinate_original_missing_suffix_20261028.py','run_original_missing_suffix_colab_20261028.py','run_original_missing_suffix_local_20261028.py','audit_original_missing_suffix_20261028.py'] for a in args):active.append(p.info)
 except (psutil.NoSuchProcess,psutil.AccessDenied):pass
snap={'at_utc':now,'cases':cases,'coordinator_claim':coord,'exact_live_processes':active,'exec_session':57180,
 'allocated_unreleased_T4s':sum(x['status_snapshot']['runtime_allocated'] and not x['status_snapshot']['runtime_released'] for x in cases),
 'third_profile':'No separately ready GPU protocol; unallocated','new_science_from_snapshot':0}
put('outputs/original_missing_suffix_live_handoff_20261028/Latest_Continuation.json',snap)
r=rd('outputs/research_resumption_20261028/Current_Resume.json')
r.update(at_utc=now,scientific_jobs=cases,gpu_assignments=snap['allocated_unreleased_T4s'],actual_process_snapshot='outputs/original_missing_suffix_live_handoff_20261028/Latest_Continuation.json')
r['parallel_completed']=['Three-page source-bound contribution/selector/verifier insert visually checked; final105-page thesis integration pending.',
 'All500 historical RAG printed QA triples recovered; recipe/source-scope documented,99percent exactfactualcontract stillUNKNOWN. No newmodel/PF.',
 'All4 descriptive assembler prepared with unchanged23Oct metrics; refuses live/partial inputs.']
r['next']=['Let sole existing coordinator close both primaries and pinned first-new-return readers. No duplicate reader.',
 'After actual actor closure and allPASS, run work/assemble_original118_closed_comparison_20261028.py once using outputs/original118_analysis_binding_20261028/Prepared_Analysis_Lock.json. Do not run on partial outputs.',
 'Preserve adverse outcomes/fullbothcosts; update tasks and thesis only from verified endpoints.',
 'Recover exact RAG data/index/factuallabels and external118faithful episode controls before further model launches.']
put('outputs/research_resumption_20261028/Current_Resume.json',r)
header=f'''## Original-controller continuations and thesis evidence — {now}

Read outputs/research_resumption_20261028/Current_Resume.json and outputs/original_missing_suffix_live_handoff_20261028/Latest_Continuation.json. Active unreleased T4s: {snap['allocated_unreleased_T4s']}. Case1/3 status and exact actors are recorded there; sole coordinator20640/parent3644, exec57180, owns primary closure and pinned readers. Do not infer audited completion from raw endpoints or counts. No duplicate/restart/live-edit/budget extension. All4 assembler PREPARED ONLY under outputs/original118_analysis_binding_20261028, unchanged23Oct metrics; run once only after all actors terminal and independent completePASS. T03/T08/T18/T24 source-bound insert reviewed; full thesis integration pending. All500 historical RAG printed QA triples recovered without inference, but99percent factual contract/data-index revisions stillUNKNOWN. All6finalgoals remainOPEN; preserve extraOV/UVlosses/fullbothcosts and original frozen assets.

'''
for path in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
 p=R/path;p.write_text(header+p.read_text('utf-8-sig'),'utf-8')
t=rd('outputs/thesis_research_closure_20261028/Tasks.json')
for x in t['tasks']:
 if x['id'] in ['T03','T08','T18','T24']:
  x['status']='SOURCE_BOUND_INSERT_VISUALLY_REVIEWED_FINAL_THESIS_INTEGRATION_PENDING'
  x['limitation']='Existing105-page reviewed thesis remains unchanged; chapter3Markdown updated and3pageWord insert ready. Finalcoauthorallocation remains pending where undocumented.'
  if 'outputs/thesis_research_closure_20261028/Insert_Visual_QA.json' not in x['evidence']:x['evidence'].append('outputs/thesis_research_closure_20261028/Insert_Visual_QA.json')
put('outputs/thesis_research_closure_20261028/Tasks.json',t)
put('outputs/thesis_research_closure_20261028/Insert_Visual_QA.json',{'at_utc':now,'status':'PASS_ALL3_PAGES_REVIEWED','document':'Candidate_Contribution_and_Verification_Insert.docx','sha256':sh('outputs/thesis_research_closure_20261028/Candidate_Contribution_and_Verification_Insert.docx'),'pages':3,'renderer':'PackagedLibreOfficeattemptfailed:sofficeunavailable. MicrosoftWordCOM PDF export plus bundledPopplerPNG successful. All3 finalPNGs inspected. Titleborder/themefontfixed.','full_thesis_rebuilt':False})
with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+' — Saved live/terminal status and exact continuation. All3pages of contribution/selector/verifier insert visually reviewed. HistoricalRAG500transcript recovered;99percentcontractstillUNKNOWN. All4originalcomparisonassemblerpreparedonly; waitsolecoordinator/independentclosure. No newsciencefromdocumentation or snapshot.\n')
print(json.dumps({'snapshot':'SAVED','active_T4':snap['allocated_unreleased_T4s'],'cases':[{'case':x['case_index'],'owner_live':x['actual_matching_owner_live'],'audit':x['audit_status']} for x in cases]}))
