"""Finite local continuation of the exact approved pilot, no cloud actions.

One owner waits for the existing GPU collector's actual end and release, then
executes fixed identity/cost and all-selected-action physics validation once.
Failures and partials stop the continuation without science reruns.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, time
import psutil

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/vcsa_development'
EXEC = BASE / 'pretrained_pilot_execution'
PREP = BASE / 'pretrained_pilot_preparation'
OUT = BASE / 'pretrained_pilot_cpu_continuation_20261008'
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), 'Do not duplicate or restart this finite continuation'
    authorization = read(PREP / 'Pretrained_Pilot_Direct_Human_Authorization_20261008.json')
    assert authorization['approved'] and authorization['payload_sha256'] == '5f0f483b02ced8af884153f85f97fd5c7ef0392a5c0350eaf59305a208dcaaf9'
    pid = int((EXEC / 'owner.claim').read_text())
    OUT.mkdir(); (OUT / 'owner.claim').write_text(str(os.getpid()))
    state = {'started_at_utc': datetime.now(timezone.utc).isoformat(),
             'stage': 'waiting_existing_GPU_owner_end_and_exact_release',
             'existing_GPU_owner_pid': pid, 'new_cloud_calls': 0,
             'new_training_steps': 0, 'restarts_or_reruns': 0}
    def save():
        state['updated_at_utc'] = datetime.now(timezone.utc).isoformat()
        p = OUT / 'status.tmp'; p.write_text(json.dumps(state, indent=2)); p.replace(OUT / 'status.json')
    def alive(target_pid, script):
        if not psutil.pid_exists(target_pid):
            return False
        try:
            return any(script in arg for arg in psutil.Process(target_pid).cmdline())
        except psutil.NoSuchProcess:
            return False
    def ensure_no_worker(script):
        for process in psutil.process_iter(['pid', 'cmdline']):
            try:
                assert not any(script in arg for arg in process.info['cmdline'] or []), 'Existing worker must not be duplicated'
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    def run(script, environment, timeout):
        ensure_no_worker(script)
        state['stage'] = script; save()
        with (OUT / (script + '.stdout.log')).open('x') as stdout, (OUT / (script + '.stderr.log')).open('x') as stderr:
            child = subprocess.Popen([str(ROOT / 'work' / environment / 'Scripts/python.exe'), str(ROOT / 'work' / script)],
                                     cwd=ROOT, stdout=stdout, stderr=stderr)
            state['current_child_pid'] = child.pid; save()
            try:
                result = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                # No termination/rerun: preserve the genuinely live child's owner.
                state['current_child_live_at_timeout'] = True; save(); raise
        state.pop('current_child_pid', None)
        assert result == 0, 'Actual audit failure preserved; no rerun'
    save(); began = time.monotonic()
    try:
        while alive(pid, 'run_vcsa_pretrained_pilot_colab_20261008.py'):
            assert time.monotonic() - began < 95 * 60, 'Existing owner remains live beyond bounded local wait; no restart'
            time.sleep(30)
        terminal = read(EXEC / 'status.json')
        assert terminal.get('finished_at_utc') and terminal.get('runtime_released')
        assert terminal.get('all_actual_artifacts_preserved') and terminal.get('remote_exit_code') == 0
        assert terminal['notebook_hash'] == '6fb2db3b-2d84-4f3e-b5dc-0da1e6dfa882'
        assert not (BASE / 'pretrained_pilot_analysis').exists()
        run('analyze_vcsa_pretrained_pilot_20261008.py', 'vcsa_module_env', 300)
        analysis = BASE / 'pretrained_pilot_analysis'
        identity_cost = read(analysis / 'Independent_Source_Action_Journal_Cost_Audit.json')
        assert identity_cost['passed']
        plan = read(PREP / 'Pretrained_Selected_Physics_Validation_Plan_20261008.json')
        for name, digest in plan['source_sha256'].items():
            assert sha(ROOT / 'work' / name) == digest
        assert not (BASE / 'pretrained_selected_physical_replay_20261008').exists()
        run('replay_vcsa_pretrained_selected_actions_20261008.py', 'physics_env', 1800)
        run('audit_vcsa_pretrained_selected_physics_20261008.py', 'vcsa_module_env', 300)
        physical = BASE / 'pretrained_selected_physical_replay_20261008'
        physics_audit = read(physical / 'independent_audit.json'); assert physics_audit['passed']
        results = {'verified_at_utc': datetime.now(timezone.utc).isoformat(), 'completed': True,
            'actual_optimizer_steps': identity_cost['actual_new_model_training_steps'],
            'actual_model_forwards': identity_cost['actual_new_model_forwards'],
            'descriptive_validation_VCSA_vs_controls': identity_cost['validation_descriptive_VCSA_vs_controls'],
            'all_selected_physics_audit': physics_audit,
            'owner_runtime_release_verified': True, 'both_numerical_controls_preserved': True,
            'all_adverse_failures_invalid_selections_retained': True,
            'original_DSE_superiority_established': False, 'unused_confirmation': False,
            'next_decision_requires_actual_results': True,
            'science_sources': {name: sha(ROOT / 'work' / name) for name in
                ['analyze_vcsa_pretrained_pilot_20261008.py', *plan['source_sha256']]}}
        (OUT / 'Verified_Completion.json').write_text(json.dumps(results, indent=2))
        summary = read(physical / 'summary.json')
        lines = ['The fixed pretrained one-state pilot completed with independently audited training, checkpoint reloads and selected physical states.',
                 '', f"Actual training: {results['actual_optimizer_steps']} optimizer steps and {results['actual_model_forwards']} model forwards across both arms.",
                 f"New selected-physics PF attempts: {summary['actual_new_PF_attempts']}; exact prior reports and their separate costs retained.",
                 '', 'Descriptive validation VCSA versus each preserved comparator:']
        for comparator, values in results['descriptive_validation_VCSA_vs_controls'].items():
            lines.append(f"- {comparator}: {values['UVwins']} UV wins, {values['UVties']} ties, {values['UVlosses']} losses, {values['unavailable_pairs']} unavailable pairs; {values['admissible_changed_actions']} admissible changed actions.")
        lines += ['', 'These are correlated historical one-state development results. They do not establish full D-SE trajectory superiority, clean component attribution, deployment efficiency or unused independent confirmation. Preserve final epoch5 and both controls; no outcome-chasing retraining.']
        (OUT / 'Results.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
        state.update(stage='complete_model_and_selected_physics_independently_audited', completed=True,
                     finished_at_utc=datetime.now(timezone.utc).isoformat()); save()
        # Operational status/claims are excluded from the immutable science seal.
        scientific = ['Verified_Completion.json', 'Results.md']
        (OUT / 'manifest.json').write_text(json.dumps({name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha(OUT / name)} for name in scientific}, indent=2))
        print(json.dumps(results), flush=True)
    except Exception as exc:
        state.update(stage='failed_preserve_all_existing_owners_and_partials', failure_type=type(exc).__name__,
                     finished_at_utc=datetime.now(timezone.utc).isoformat()); save(); raise


if __name__ == '__main__':
    main()
