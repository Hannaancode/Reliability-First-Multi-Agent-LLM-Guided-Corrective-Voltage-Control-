The requested paired publicQwen2.5-0.5B/1.5B screen has one minimum-observationSHA view from each of31 finite historical worlds, frozen before target/model access. Both arms receive the same partial current physical view and single-action prompt. All original invalid denominators remain separately saved.

{
  "completed_at_utc": "2026-10-10T04:45:24.830965+00:00",
  "selected_worlds": 31,
  "actual_public_tokenizer_cases": 62,
  "context_tokens_min": 4214,
  "context_tokens_max": 4517,
  "all62_fit8192_with384reserve": true,
  "all31_public_model_token_ids_identical": true,
  "local_transformers_version": "5.5.0",
  "original_case_input_prompt_selection_and_failed_provenance_preserved": true,
  "targets_or_held_metrics_read": false,
  "no_original_private_weight_or_setting_change": true,
  "actual_model_forward_generation_optimizer_PF_cloud_calls": 0,
  "real_1_5B_T4_memory_speed_performance_UNKNOWN": true,
  "production_driver_collector_external_reader_not_yet_sealed": true,
  "eligible_for_production_implementation_only": true,
  "no_learning_superiority_or99percent_success_claim": true,
  "seconds_before_seal": 11.93938979995437
}

This uses an explicitly new common8192context/reserve384 research contract, not an edit to the frozen private4096 baseline or a relabelling of the old projection failure. Public tokenizer/config files were reused from the original import-failed preparer; no download or scientific call was repeated. Real memory/load/cold-result/source/owner/collector/external-reader gates still precede actual inference. Fit is not sufficient input, learned value, a clean causal parameter-only intervention, independent confirmation or D-SE superiority. Public model pretraining/post-training recipe differences remain possible confounders. The private0.5B adapter cannot be transplanted; any eventual1.5B training needs its own justified adapter/protocol. No automatic training or newPF follows this preparation.
