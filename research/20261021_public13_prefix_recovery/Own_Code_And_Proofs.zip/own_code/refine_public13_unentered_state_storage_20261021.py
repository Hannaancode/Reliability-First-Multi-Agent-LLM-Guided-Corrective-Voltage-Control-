"""Pre-launch immutable history anchors avoid quadratic checkpoint duplication."""
import ast,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_missing_only_preparation_20261021'
def main():
    assert not (R/'outputs/public13_missing_only_execution_20261021').exists()
    path=R/'work/run_public13_missing_only_continuation_20261021.py';old=path.read_text(encoding='utf-8');new=old
    new=new.replace("historical_attempts={(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True)) for r in old_result['receipts']}","historical_attempts={(r['physical_signature'],json.dumps(r['kwargs'],sort_keys=True)) for r in old_result['receipts']};historical_index_anchor={'path':'outputs/public13_remaining_published_cohort_20261021/Failure.json','sha256':sha(OLD/'Failure.json'),'receipt_count':len(old_result['receipts'])}")
    assert new.count("'historical_attempts':historical_attempts.copy()")==2
    assert new.count("'paid_receipts':copy.deepcopy(receipts)")==2
    new=new.replace("'historical_attempts':historical_attempts.copy()","'historical_attempts':historical_index_anchor.copy()")
    new=new.replace("'paid_receipts':copy.deepcopy(receipts)","'paid_receipts':copy.deepcopy([r for r in receipts if r['context']['seed']==seed]),'global_paid_journal':{'path':'events.jsonl','last_sha256':previous,'byte_offset':stream.tell()}")
    new=new.replace("check_cursor(loaded,models,deadline);assert", "check_cursor(loaded,models,deadline);assert loaded['historical_attempts']==historical_index_anchor and loaded['global_paid_journal']['last_sha256']==previous and loaded['global_paid_journal']['byte_offset']==stream.tell();assert")
    ast.parse(new);path.write_text(new,encoding='utf-8')
    reader=R/'work/audit_public13_missing_only_continuation_20261021.py';text=reader.read_text(encoding='utf-8')
    text=text.replace("cursor=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());current_model_state=", "cursor=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());assert cursor['historical_attempts']['sha256']==sha(OLD/'Failure.json') and all(v['context']['seed']==seed for v in cursor['paid_receipts']);current_model_state=")
    ast.parse(text);reader.write_text(text,encoding='utf-8')
    out={'status':'PRELAUNCH_STORAGE_REFINEMENT_ZERO_NEW_SCIENCE','before_worker_sha256':hashlib.sha256(old.encode()).hexdigest(),'after_worker_sha256':hashlib.sha256(new.encode()).hexdigest(),'old_history':'Immutable pinned original failed-file/receipt index, loaded and hashed before any new identity; per-cursor hash reference instead of copying the same2787old rows every time','current_history':'Complete current-seed receipts, attempted IDs, actual full model/env/RNG/absolute bound plus fsynced global journal byte offset/hash. Prior seeds cannot recur under exact distinct noncontrolled regimes.','restoration_rule':'Read hash-anchored old index and current seed registry, validate journal prefix; never assume missing attempt was unentered.','reason':'Avoid O(total_receipts*total_steps) repeated archive bytes; no changed policy, input, resource horizon, outcome or source equations','original_source_worker_study_unchanged':True,'new_model_PF_calls':0}
    with (P/'Prelaunch_Storage_Refinement.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
    print('PRELAUNCH_STATE_INDEX_ANCHORS_PREPARED_NO_SCIENCE')
if __name__=='__main__':main()
