"""Canonicalize prelaunch manifest path keys; zero science, old failure retained."""
import json,os,subprocess
from pathlib import Path
from full_receding_paid_campaign_20261015 import R,B,pin,local_source_closure
from receding_paid_runtime_v2 import read,put,sha
def main():
    assert not (B/'Execution_Bound.json').exists() and not (B/'actual').exists() and not (B/'Prelaunch_Readiness.json').exists()
    p=read(B/'Protocol.json');put(B/'Protocol_Before_Path_Key_Normalization.json',p)
    normalized={}
    for name,h in p['source_input_sha256'].items():
        canonical=Path(name).as_posix()
        assert canonical not in normalized or normalized[canonical]==h
        assert sha(R/canonical)==h;normalized[canonical]=h
    normalized[Path(__file__).relative_to(R).as_posix()]=sha(Path(__file__))
    p['source_input_sha256']=normalized
    temporary=B/'Canonical_Protocol.tmp'
    with temporary.open('x',encoding='utf-8') as f:json.dump(p,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(temporary,B/'Protocol.json');pin(p)
    fixture=read(R/'outputs/full_receding_cached_reader_v2_fixture_checks_20261015/Result.json')
    reader=R/'work/audit_full_receding_paid_campaign_cached_state_v2_20261015.py'
    pipeline=R/'work/run_full_receding_cached_reader_v2_pipeline_20261015.py'
    assert fixture['query_receipts_checked']==12872 and fixture['reader_source_sha256']==sha(reader)
    command="Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and $_.CommandLine -match '(check_full_receding.*fixtures_20261015|full_receding_paid_campaign_20261015|audit_full_receding.*20261015|bounded_paid_lookahead_physics_20261014|full_joint_suffix_benchmark_20261014)\\.py' } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    actual=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-Command',command],capture_output=True,text=True,check=True)
    assert not actual.stdout.strip()
    put(B/'Path_Namespace_Repair_Certificate.json',{'normalized_manifest_keys_only':True,'all_file_identities_and_scientific_settings_unchanged':True,
        'zero_scientific_calls':True,'original_failed_prepare_source_and_stderr_preserved':True,
        'cause':'Windows relative manifest keys used backslashes while coordinator lookup used slash literals; no job had launched.',
        'source_sha256':sha(Path(__file__))})
    put(B/'Prelaunch_Readiness.json',{'status':'PASS_PRELAUNCH_SOURCE_INPUT_COMPONENT_READER_AND_OWNERSHIP',
        'all4_exact_initial_identities':p['all4_initial_identities'],'same2_methods_and16followup_queries':True,
        'unchanged_native_scope_Q_grid_25operations_cap450_protection_score_stop_gate':True,
        'paid_engine_source_and_durable_history_all8_independent':'PASS','independent_selected_reader_all8_actual_saved_decisions_12872queries':'PASS',
        'actual_previous_jobs_observed_ended':True,'nine_original_frozen_checks':'PASS',
        'real_first_checkpoint_cold_gate_before_more_science':'REQUIRED_BY_OWNER_NOT_YET_EXECUTED',
        'fixed_science_seconds':p['science_bound_seconds'],'protocol_sha256':sha(B/'Protocol.json'),
        'selected_sources':{'worker':normalized['work/full_receding_paid_campaign_20261015.py'],'reader':sha(reader),'coordinator':sha(pipeline),'runtime':p['runtime_source_sha256']},
        'new_PF_model_calls':0,'scientific_performance':'NOT_STARTED','no_LLM_whole_DSE_or_zero_all_claim':True})
    print(json.dumps({'canonical_manifest_and_prelaunch':'PASS','all4_roots':4,'all8_branches':8,'new_PF_model_calls':0}))
if __name__=='__main__':main()
