"""Prospective new-case expert routing with actual mutable native policy carry.

The primary executes six arms. The first reader replays each NEW returned PF
and each returned native actor call once, then reconstructs all decisions using
those independently checked outputs. No LLM, GPU, learning or old PF replay.
"""
import copy, hashlib, json, os, pickle, random, time, traceback, types
from datetime import datetime, timezone
from pathlib import Path

R=Path(__file__).resolve().parents[1]
P=R/'outputs/public13_fresh_router_execution_preparation_20261022'
PRIMARY=R/'outputs/public13_fresh_router_execution_20261022'
READER=R/'outputs/public13_fresh_router_independent_20261022'
ARMS=('safe-ddpg','linear','ddpg','numerical','our-router','published-router')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:
        json.dump(v,f,indent=2,allow_nan=False); f.flush(); os.fsync(f.fileno())

def metric(vm):
    return dict(UV=int((vm<.95).sum()),OV=int((vm>1.05).sum()),
                full13band=bool(((vm>=.95)&(vm<=1.05)).all()),vmin=float(vm.min()),vmax=float(vm.max()))

def route(arm,vm):
    m=metric(vm)
    if arm not in ('our-router','published-router'): return arm
    if m['full13band']: return 'stop'
    if m['UV'] and not m['OV']: return 'safe-ddpg'
    return 'numerical' if arm=='our-router' else 'ddpg'

def state_digest(values):
    h=hashlib.sha256()
    for name,v in sorted(values.items()):
        h.update(name.encode());h.update(str((v.dtype.str,v.shape)).encode());h.update(v.tobytes())
    return h.hexdigest()

def run(mode):
    out=PRIMARY if mode=='primary' else READER
    out.mkdir(exist_ok=False);began=time.monotonic()
    source=R/('work/run_public13_fresh_router_20261022.py' if mode=='primary' else 'work/audit_public13_fresh_router_20261022.py')
    put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(source),at_utc=datetime.now(timezone.utc).isoformat()))
    while not (out/'Launcher_ACK.json').exists():
        assert time.monotonic()-began<60;time.sleep(.1)
    p=read(P/'Protocol.json');deadline=began+p['science_seconds' if mode=='primary' else 'reader_seconds']
    ack=read(out/'Launcher_ACK.json')
    assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    for rel,h in p['source_and_input_hashes'].items(): assert sha(R/rel)==h,rel
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from run_public13_remaining_published_cohort_20261021 import regime
    from public13_complete_policy_state_contract_20261021 import snapshot,restore,source_transition,check_cursor
    from public13_matched_numeric_engine_20261021 import original_guard
    from native_fit_teacher_math_20261020 import propose,verify
    from candidate_process_evidence_utils import frozen_checks
    from pandapower.pypower.makeSbus import makeSbus
    np=b.np;torch=b.torch;torch.set_num_threads(1)
    random.seed(20261022);np.random.seed(20261022);torch.manual_seed(20261022)
    cost={k:0 for k in ['checkpoint_load_attempts','checkpoint_load_returns','agent_forward_attempts','agent_forward_returns',
        'logical_PF_queries','PF_attempts','PF_returns','PF_exceptions','paid_PF_reuses','derivative_attempts','derivative_returns',
        'LU_returns','RHS_returns','LP_attempts','LP_returns','paid_math_reuses','independent_dense_checks',
        'decisions','accepted_commits','rejected_candidates','cold_state_restorations']}
    cost['LLM_GPU_optimizer_training_converter_calls']=0
    previous='0'*64;binarybytes=0;worlds=[];receipts=[];forward_calls=[];math_receipts=[]
    paid={};attempted=set();scope={};current=None;mathcache={};maxdelta=0.;replaying=False
    stream=(out/'events.jsonl').open('x',encoding='utf-8')
    for n in ('physics','forwards','cases'): (out/n).mkdir()
    def event(kind,**data):
        nonlocal previous
        v=dict(kind=kind,elapsed_seconds=time.monotonic()-began,previous=previous,**data)
        h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        stream.write(json.dumps(dict(event=v,sha256=h),separators=(',',':'))+'\n');stream.flush();os.fsync(stream.fileno());previous=h
    def bound():
        if time.monotonic()>deadline-30: raise TimeoutError('Fixed absolute resource bound; no extension/retry')
        if binarybytes>p['binary_preservation_cap_bytes']-10*1024**2: raise TimeoutError('Fixed storage bound; no extension')
    def binary(path,v):
        nonlocal binarybytes
        raw=pickle.dumps(v,protocol=5)
        if binarybytes+len(raw)>p['binary_preservation_cap_bytes']:raise TimeoutError('Fixed binary preservation bound')
        with Path(path).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        binarybytes+=len(raw)
    def key(sig,kwargs): return sig+'|'+json.dumps(kwargs,sort_keys=True)
    graph=np.load(R/p['graph']);Y=graph['Y'];identities=read(R/p['identities']);recipes=np.load(R/p['recipes'])
    regs={v['seed']:v['noncontrolled_regime'] for v in identities}
    history=read(P/'Historical_Physical_Attempt_Anchors.json')
    old_attempts=set(history['physical_signatures']);historical_hash=sha(P/'Historical_Physical_Attempt_Anchors.json')
    targets={};primary=None;forward_state_hashes={};replayed_raw={}
    def query(net,*args,**kwargs):
        nonlocal current,maxdelta,binarybytes
        bound();assert not args and kwargs in ({'algorithm':'bfsw'},{'algorithm':'bfsw','init':'dc'})
        sig=signature(net);k=key(sig,kwargs);assert regime(net)==regs[scope['seed']]
        assert sig not in old_attempts,'Old physical identity: no repeated scientific call'
        cost['logical_PF_queries']+=1
        if k in paid:
            rec=paid[k];path=R/rec['after'];assert sha(path)==rec['after_sha256']
            solved=pickle.loads(path.read_bytes());assert signature(solved)==sig
            net.update(copy.deepcopy(solved));current=rec;cost['paid_PF_reuses']+=1
            event('paid_PF_reuse',scope=scope.copy(),receipt=rec['index'],physical_signature=sig);return
        if sig in attempted: raise RuntimeError('Previously attempted input without same-initializer returned evidence: UNKNOWN, no retry')
        if mode=='independent': assert replaying and k in targets and targets[k]['status']=='RETURNED','Reader attempted unentered/failed science'
        index=cost['PF_attempts'];before=out/'physics'/f'PF{index:05d}_before.pkl';binary(before,net)
        rec=dict(index=index,physical_signature=sig,kwargs=kwargs,scope=scope.copy(),status='ATTEMPTED',before=before.relative_to(R).as_posix(),before_sha256=sha(before))
        receipts.append(rec);attempted.add(sig);cost['PF_attempts']+=1;event('PF_attempt',**rec);t=time.perf_counter()
        try:b.pp.runpp(net,**kwargs)
        except BaseException as exc:
            cost['PF_exceptions']+=1;rec.update(status='EXCEPTION',failure_type=type(exc).__name__,seconds=time.perf_counter()-t);event('PF_exception',**rec);raise
        cost['PF_returns']+=1;assert net.converged and signature(net)==sig
        pp=net._ppc
        assert pp['baseMVA']==float(graph['baseMVA']) and np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]])
        V=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));kcl=float(np.max(np.abs(V*np.conj(Y@V)-makeSbus(pp['baseMVA'],pp['bus'],pp['gen']))));assert kcl<=1e-7
        after=out/'physics'/f'PF{index:05d}_after.pkl';binary(after,net)
        fields=out/'physics'/f'PF{index:05d}_fields.npz'
        arrays={n:net[n].select_dtypes(include=[np.number]).to_numpy(float) for n in ('res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid')}
        np.savez(fields,**arrays);binarybytes+=fields.stat().st_size
        if mode=='independent':
            expected=targets[k];z=np.load(R/expected['fields']);assert set(z.files)==set(arrays)
            for n,v in arrays.items():
                assert np.array_equal(np.isnan(v),np.isnan(z[n])) and np.allclose(v,z[n],atol=1e-10,rtol=0,equal_nan=True)
                mask=np.isfinite(v)&np.isfinite(z[n]);maxdelta=max(maxdelta,float(np.max(np.abs(v[mask]-z[n][mask]),initial=0)))
        rec.update(status='RETURNED',after=after.relative_to(R).as_posix(),after_sha256=sha(after),fields=fields.relative_to(R).as_posix(),fields_sha256=sha(fields),KCL_pu=kcl,seconds=time.perf_counter()-t)
        paid[k]=rec;current=rec;event('PF_return',**rec)
    class Proxy:
        runpp=staticmethod(query)
    native,_=b.definitions(b.AUTHOR/'env_single_phase_13bus.py',['IEEE13bus'],dict(np=np,LA=np.linalg,gym=types.SimpleNamespace(Env=object),copy=copy,pp=Proxy()))
    base=pickle.loads((R/p['base_NET']).read_bytes());template=native['IEEE13bus'](base,np.array([2,7,9]))
    def load_event(kind,**data):
        if kind in cost:cost[kind]+=1
        elif kind=='checkpoint_load_attempt':cost['checkpoint_load_attempts']+=1
        elif kind=='checkpoint_load_return':cost['checkpoint_load_returns']+=1
        event(kind,**data)
    models,loads,_=b.load_three(template,load_event)
    banks={k:v for k,v in models.items()}
    banks['our-router:safe-ddpg']=copy.deepcopy(models['safe-ddpg'])
    banks['published-router:safe-ddpg']=copy.deepcopy(models['safe-ddpg'])
    banks['published-router:ddpg']=copy.deepcopy(models['ddpg'])
    put(out/'Actual_Checkpoint_Loads.json',loads);binary(out/'Initial_All_Bank_State.pkl',snapshot(banks))
    put(out/'Frozen_Before.json',frozen_checks())
    try:
        if mode=='independent':
            end=read(R/p['primary_end_ACK']);assert end['actual_owned_chain_ended'] and end['exit_code']==0
            lock=read(P/'Independent_Reader_Lock.json');assert lock['reader_sha256']==sha(source) and lock['protocol_sha256']==sha(P/'Protocol.json')
            manifest=read(PRIMARY/'Closed_Manifest.json')
            for row in manifest['files']:assert sha(PRIMARY/row['path'])==row['sha256'],row['path']
            prior='0'*64
            for line in (PRIMARY/'events.jsonl').read_text(encoding='utf-8').splitlines():
                row=json.loads(line);v=row['event'];assert v['previous']==prior and hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==row['sha256'];prior=row['sha256']
            assert prior==manifest['journal_last_sha256']
            primary=read(PRIMARY/'Result.json');targets={key(v['physical_signature'],v['kwargs']):v for v in primary['receipts']}
            initial=pickle.loads((PRIMARY/'Initial_All_Bank_State.pkl').read_bytes());assert state_digest(snapshot(banks))==state_digest(initial)
            replaying=True
            for rec in primary['receipts']:
                if rec['status']!='RETURNED':event('failed_or_unreturned_primary_not_replayed',index=rec['index'],status=rec['status']);continue
                scope.clear();scope.update(rec['scope']);assert sha(R/rec['before'])==rec['before_sha256'];net=pickle.loads((R/rec['before']).read_bytes());query(net,**rec['kwargs'])
            replaying=False
            # One first independent execution of every RETURNED actor call.
            # Failed/unreturned calls are never tried again.
            forward_state_hashes[0]=state_digest(snapshot(banks))
            for call in primary['forward_calls']:
                bound()
                if call['status']!='RETURNED':event('unreturned_actor_not_replayed',index=call['index']);continue
                assert sha(R/call['before'])==call['before_sha256'] and sha(R/call['after'])==call['after_sha256']
                pre=pickle.loads((R/call['before']).read_bytes());assert state_digest(snapshot(banks))==state_digest(pre['all_banks'])
                m=banks[call['bank']][call['agent']];old={n:v.detach().cpu().clone() for n,v in m.state_dict().items()}
                cost['agent_forward_attempts']+=1
                with torch.no_grad():a=m.get_action(np.asarray(pre['input']))
                source_transition(m,call['algorithm'],old);cost['agent_forward_returns']+=1
                assert a.dtype==np.float32 and a.tolist()==call['output']
                post=pickle.loads((R/call['after']).read_bytes());assert state_digest(snapshot(banks))==state_digest(post)
                replayed_raw[call['index']]=a.copy();forward_state_hashes[cost['agent_forward_returns']]=state_digest(snapshot(banks));event('independent_actor_return',index=call['index'],bank=call['bank'],agent=call['agent'])
            for rec in primary['math_receipts']:
                if rec['status']!='RETURNED':continue
                bound();assert sha(R/rec['current_NET'])==rec['current_NET_sha256']
                net=pickle.loads((R/rec['current_NET']).read_bytes())
                for name,h in rec['proof_hashes'].items():assert sha(R/rec['directory']/name)==h
                u,_=verify(R/rec['directory'],net);assert u.tolist()==rec['u'];mathcache[rec['key']]=rec;cost['independent_dense_checks']+=1
            # Source decision reconstruction uses checked actor outputs above;
            # it must not invoke any policy a second time.
        for pos,identity in enumerate(identities):
            seed=identity['seed']
            if mode=='independent' and pos>=len(primary['worlds']):break
            try:bound()
            except TimeoutError:break
            scope.clear();scope.update(seed=seed,arm='root',step=0)
            world=dict(seed=seed,root_status='UNKNOWN',arms=[]);worlds.append(world)
            d=out/'cases'/f'seed{seed}';d.mkdir()
            env=copy.deepcopy(template)
            if mode=='independent' and primary['worlds'][pos]['root_status']!='RETURNED':
                world.update(primary['worlds'][pos]);continue
            try:
                env.reset(seed)
                for name,table,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(env.network[table][col].to_numpy(),recipes[name][pos])
                root=copy.deepcopy(env.__dict__);root_ref=current['after'];binary(d/'Root_ENV.pkl',root)
                world.update(root_status='RETURNED',root_signature=signature(env.network),root_receipt=current['index'],initial=metric(env.network.res_bus.vm_pu.to_numpy()))
                # Decisions fixed before any terminal label for this case.
                plan={a:route(a,env.network.res_bus.vm_pu.to_numpy()) for a in ARMS}
                put(d/'Before_Any_Expert_Route_Plan.json',dict(seed=seed,routes=plan,initial_vm=env.network.res_bus.vm_pu.tolist(),root_signature=world['root_signature']))
                event('input_only_route_plan',seed=seed,routes=plan,root_signature=world['root_signature'])
            except BaseException as exc:
                world.update(failure_type=type(exc).__name__,failure=str(exc));event('root_UNKNOWN',seed=seed,type=type(exc).__name__)
                if isinstance(exc,TimeoutError):break
                continue
            for arm in ARMS:
                if mode=='independent' and len(world['arms'])>=len(primary['worlds'][pos]['arms']):break
                backend=plan[arm];env.__dict__.clear();env.__dict__.update(copy.deepcopy(root));last=np.zeros((3,1));netref=root_ref
                branch=dict(arm=arm,backend=backend,status='UNKNOWN',steps=[]);world['arms'].append(branch)
                expected=primary['worlds'][pos]['arms'][len(world['arms'])-1] if mode=='independent' else None
                if mode=='independent':assert backend==expected['backend'] and arm==expected['arm']
                try:
                    for step in range(1,101):
                        bound();scope.clear();scope.update(seed=seed,arm=arm,step=step)
                        vm=env.network.res_bus.vm_pu.to_numpy(copy=True)
                        if backend=='stop' or (backend=='numerical' and metric(vm)['full13band']):branch['status']='COMPLETE_GLOBAL_BAND_STOP';break
                        if mode=='independent' and step>len(expected['steps']):branch['status']=expected['status'];break
                        sd=d/f'{arm}_{step:03d}';sd.mkdir()
                        packet=dict(environment=copy.deepcopy(env.__dict__),last_Q=last.copy(),state=env.state.copy(),history=copy.deepcopy(branch['steps']),
                            complete_model_state=snapshot(banks),paid_receipts=copy.deepcopy(receipts),attempted_inputs=sorted(attempted),historical_attempts=dict(path=str((P/'Historical_Physical_Attempt_Anchors.json').relative_to(R)),sha256=historical_hash),
                            paid_registry={k:dict(after=v['after'],sha256=v['after_sha256']) for k,v in paid.items()},python_rng=random.getstate(),numpy_rng=np.random.get_state(),torch_rng=torch.get_rng_state().numpy(),
                            math_cache=copy.deepcopy(mathcache),scope=scope.copy(),preserved_binary_bytes=binarybytes,
                            absolute_deadline_monotonic=deadline,protocol_sha256=sha(P/'Protocol.json'),costs=cost.copy(),journal_sha256=previous,journal_byte_offset=stream.tell(),next_step=step,remaining_horizon=101-step)
                        if mode=='primary':
                            binary(sd/'Full_Cursor.pkl',packet);loaded=pickle.loads((sd/'Full_Cursor.pkl').read_bytes());check_cursor(loaded,banks,deadline)
                            # Perform the next actual work from cold, saved state.
                            env.__dict__.clear();env.__dict__.update(loaded['environment']);restore(banks,loaded['complete_model_state']);last=loaded['last_Q'].copy()
                            cold_paid={key(v['physical_signature'],v['kwargs']):v for v in loaded['paid_receipts'] if v['status']=='RETURNED'}
                            assert {k:dict(after=v['after'],sha256=v['after_sha256']) for k,v in cold_paid.items()}==loaded['paid_registry']
                            assert loaded['journal_sha256']==previous and loaded['journal_byte_offset']==stream.tell() and loaded['scope']==scope
                            paid=cold_paid;attempted=set(loaded['attempted_inputs']);receipts=loaded['paid_receipts'];mathcache=loaded['math_cache']
                            random.setstate(loaded['python_rng']);np.random.set_state(loaded['numpy_rng']);torch.set_rng_state(torch.from_numpy(loaded['torch_rng'].copy()))
                            cost['cold_state_restorations']+=1
                        else:
                            saved=PRIMARY/'cases'/f'seed{seed}'/f'{arm}_{step:03d}'/'Full_Cursor.pkl';loaded=pickle.loads(saved.read_bytes())
                            assert loaded['protocol_sha256']==sha(P/'Protocol.json') and loaded['absolute_deadline_monotonic']==primary['absolute_deadline_monotonic'] and loaded['remaining_horizon']==101-step
                            assert loaded['history']==branch['steps'] and signature(loaded['environment']['network'])==signature(env.network) and np.array_equal(loaded['state'],env.state) and np.array_equal(loaded['last_Q'],last)
                            assert state_digest(loaded['complete_model_state'])==forward_state_hashes[loaded['costs']['agent_forward_returns']]
                        if mode=='independent' and expected['steps'][step-1]['status']!='RETURNED':
                            partial_row=expected['steps'][step-1]
                            assert partial_row['current_signature']==signature(env.network) and partial_row['current_vm']==vm.tolist() and partial_row['last_Q']==last.tolist()
                            branch['steps'].append(copy.deepcopy(partial_row));break
                        row=dict(step=step,status='STARTED',current_signature=signature(env.network),current_vm=vm.tolist(),last_Q=last.tolist(),actor_call_ids=[])
                        branch['steps'].append(row)
                        if backend=='numerical':
                            ctx=signature(env.network)+'|'+hashlib.sha256(env.network._ppc['bus'][:,7:9].tobytes()).hexdigest()
                            if ctx in mathcache:
                                m=mathcache[ctx];u=np.asarray(m['u'],dtype=np.float32);cost['paid_math_reuses']+=1
                            else:
                                assert mode=='primary','Independent reconstruction lacks returned numerical proof'
                                m=dict(key=ctx,directory=sd.relative_to(R).as_posix(),current_NET=netref,current_NET_sha256=sha(R/netref),status='ATTEMPTED',scope=scope.copy())
                                math_receipts.append(m);event('numerical_attempt',**m);u,_=propose(env.network,Y,sd,cost)
                                m.update(status='RETURNED',u=u.tolist(),proof_hashes={n:sha(sd/n) for n in ('Current_Model.npz','LP1.npz','LP2.npz')})
                                binarybytes+=sum((sd/n).stat().st_size for n in m['proof_hashes']);mathcache[ctx]=m;event('numerical_return',**m)
                            action=env.network.sgen.q_mvar.to_numpy()[:3]-u;row.update(native_u=u.tolist(),math_key=ctx,math_directory=m['directory']);candidate=copy.deepcopy(env)
                            candidate.network.sgen.loc[candidate.network.sgen.index[:3],'q_mvar']=action;query(candidate.network,algorithm='bfsw',init='dc');candidate.state=candidate.network.res_bus.iloc[[2,7,9]].vm_pu.to_numpy();done=False;reward=None
                        else:
                            bank=arm if arm in ('safe-ddpg','linear','ddpg') else arm+':'+backend
                            raw=[]
                            for agent,model in enumerate(banks[bank]):
                                if mode=='primary':
                                    index=len(forward_calls);before=out/'forwards'/f'F{index:06d}_before.pkl'
                                    inp=np.asarray([env.state[agent]]);binary(before,dict(all_banks=snapshot(banks),input=inp.copy()))
                                    call=dict(index=index,scope=scope.copy(),bank=bank,algorithm=backend,agent=agent,status='ATTEMPTED',before=before.relative_to(R).as_posix(),before_sha256=sha(before));forward_calls.append(call);cost['agent_forward_attempts']+=1;event('actor_attempt',**call)
                                    old={n:v.detach().cpu().clone() for n,v in model.state_dict().items()};t=time.perf_counter()
                                    with torch.no_grad():a=model.get_action(inp)
                                    source_transition(model,backend,old);cost['agent_forward_returns']+=1
                                    assert a.shape==(1,) and a.dtype==np.float32 and np.isfinite(a).all()
                                    after=out/'forwards'/f'F{index:06d}_after.pkl';binary(after,snapshot(banks))
                                    call.update(status='RETURNED',output=a.tolist(),after=after.relative_to(R).as_posix(),after_sha256=sha(after),seconds=time.perf_counter()-t);event('actor_return',**call)
                                else:
                                    index=expected['steps'][step-1]['actor_call_ids'][agent];a=replayed_raw[index];call=primary['forward_calls'][index]
                                    assert call['scope']==scope and call['bank']==bank and call['agent']==agent
                                    pre=pickle.loads((R/call['before']).read_bytes());assert np.array_equal(pre['input'],np.asarray([env.state[agent]]))
                                row['actor_call_ids'].append(index);raw.append(a.copy())
                            raw=np.asarray(raw);action=last-np.clip(raw,-.3,.3);candidate=copy.deepcopy(env)
                            state,reward,_,done=candidate.step_Preward(action,last-action);row['raw_policy']=raw.tolist()
                        after_vm=candidate.network.res_bus.vm_pu.to_numpy(copy=True)
                        if mode=='primary':accepted=True if arm in ('safe-ddpg','linear','ddpg') else original_guard(vm,after_vm)
                        else:
                            normal=np.flatnonzero((vm>=.95)&(vm<=1.05));accepted=True if arm in ('safe-ddpg','linear','ddpg') else bool(np.isfinite(after_vm).all() and all(.95-1e-8<=after_vm[i]<=1.05+1e-8 for i in normal) and int((after_vm<.95).sum())<=int((vm<.95).sum()) and int((after_vm>1.05).sum())<=int((vm>1.05).sum()))
                        row.update(status='RETURNED',candidate_Q=np.asarray(action).tolist(),candidate_vm=after_vm.tolist(),candidate_metrics=metric(after_vm),native_done=bool(done),native_reward=None if reward is None else float(reward),accepted=accepted,physical_signature=signature(candidate.network))
                        if mode=='independent':assert row==expected['steps'][step-1],(seed,arm,step)
                        put(sd/'Decision.json',row);cost['decisions']+=1;cost['accepted_commits' if accepted else 'rejected_candidates']+=1;event('decision',scope=scope.copy(),accepted=accepted,receipt=current['index'])
                        if accepted:env=candidate;last=np.asarray(action).copy();netref=current['after']
                        if mode=='primary':
                            post=dict(environment=copy.deepcopy(env.__dict__),last_Q=last.copy(),state=env.state.copy(),history=copy.deepcopy(branch['steps']),complete_model_state=snapshot(banks),paid_registry={k:dict(after=v['after'],sha256=v['after_sha256']) for k,v in paid.items()},paid_receipts=copy.deepcopy(receipts),math_cache=copy.deepcopy(mathcache),attempted_inputs=sorted(attempted),historical_attempts=packet['historical_attempts'],python_rng=random.getstate(),numpy_rng=np.random.get_state(),torch_rng=torch.get_rng_state().numpy(),absolute_deadline_monotonic=deadline,protocol_sha256=sha(P/'Protocol.json'),costs=cost.copy(),journal_sha256=previous,journal_byte_offset=stream.tell(),next_step=step+1,remaining_horizon=100-step)
                            binary(sd/'Completed_Full_State.pkl',post)
                        else:
                            post=pickle.loads((PRIMARY/'cases'/f'seed{seed}'/f'{arm}_{step:03d}'/'Completed_Full_State.pkl').read_bytes())
                            assert post['history']==branch['steps'] and post['next_step']==step+1 and post['remaining_horizon']==100-step
                            assert post['absolute_deadline_monotonic']==primary['absolute_deadline_monotonic'] and post['protocol_sha256']==sha(P/'Protocol.json')
                            assert signature(post['environment']['network'])==signature(env.network) and np.array_equal(post['state'],env.state) and np.array_equal(post['last_Q'],last)
                            assert state_digest(post['complete_model_state'])==forward_state_hashes[post['costs']['agent_forward_returns']]
                        if not accepted:branch['status']='COMPLETE_GUARD_REJECTED_HOLD_STOP';break
                        if backend!='numerical' and done:branch['status']='COMPLETE_SOURCE3_STRICT_DONE';break
                    else:branch['status']='COMPLETE_SOURCE100_ROUND_LIMIT'
                    if mode=='independent' and not expected['status'].startswith('COMPLETE_'):
                        assert branch['steps']==expected['steps']
                        branch.clear();branch.update(copy.deepcopy(expected))
                        event('primary_unknown_arm_retained_no_failed_or_unentered_call_replayed',seed=seed,arm=arm)
                        continue
                    branch.update(final_vm=env.network.res_bus.vm_pu.tolist(),final_Q=env.network.sgen.q_mvar.to_numpy()[:3].tolist(),final=metric(env.network.res_bus.vm_pu.to_numpy()))
                    if mode=='independent':assert branch==expected,(seed,arm)
                except BaseException as exc:
                    branch.update(failure_type=type(exc).__name__,failure=str(exc));event('arm_UNKNOWN',scope=scope.copy(),type=type(exc).__name__)
                    if mode=='independent':raise
                    if isinstance(exc,TimeoutError):break
            put(d/'World_Result.json',world)
            if time.monotonic()>deadline-30 or binarybytes>p['binary_preservation_cap_bytes']-10*1024**2:break
        complete=len(worlds)==128 and all(w['root_status']=='RETURNED' and len(w['arms'])==6 and all(a['status'].startswith('COMPLETE_') for a in w['arms']) for w in worlds)
        result=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='COMPLETE_FRESH128_ACTUAL_SIX_ARM_ROUTING' if complete else 'TERMINAL_PARTIAL_FRESH128_ACTUAL_ROUTING',all128_complete=complete,worlds=worlds,
            unentered_seeds=[v['seed'] for v in identities[len(worlds):]],receipts=receipts,forward_calls=forward_calls,math_receipts=math_receipts,costs=cost,workflow_seconds=time.monotonic()-began,absolute_deadline_monotonic=deadline,
            full_fields_max_delta=maxdelta,not_LLM_or_same_information_learning_superiority=True,synthetic_source_generated_inputs_not_certified_external_training_holdout=True,all6goals='OPEN')
        put(out/'Result.json',result);binary(out/'Final_All_Bank_State.pkl',snapshot(banks))
        if mode=='independent':
            assert complete==primary['all128_complete'] and cost['PF_attempts']==cost['PF_returns']==primary['costs']['PF_returns']
            assert cost['agent_forward_returns']==primary['costs']['agent_forward_returns']
            assert state_digest(snapshot(banks))==state_digest(pickle.loads((PRIMARY/'Final_All_Bank_State.pkl').read_bytes()))
            put(out/'Independent_Audit.json',dict(status='PASS_FIRST_NEW_PHYSICS_NATIVE_ACTORS_DENSE_PROOFS_ROUTING_COLD_CONTINUOUS_STATE_SOURCE_COST_AUDIT',all128_complete=complete,full_fields_max_delta=maxdelta,primary_costs=primary['costs'],actual_independent_costs=cost,workflow_seconds=time.monotonic()-began,new_derivative_LU_LP_calls=0,all6goals='OPEN'))
        put(out/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(out/'Result.json'));stream.close()
        put(out/'Closed_Manifest.json',dict(files=[dict(path=f.relative_to(out).as_posix(),bytes=f.stat().st_size,sha256=sha(f)) for f in out.rglob('*') if f.is_file()],journal_last_sha256=previous))
        print(result['status'])
    except BaseException as exc:
        put(out/'Failure.json',dict(type=type(exc).__name__,failure=str(exc),traceback=traceback.format_exc(),worlds=worlds,receipts=receipts,forward_calls=forward_calls,math_receipts=math_receipts,costs=cost,workflow_seconds=time.monotonic()-began));stream.close();raise
