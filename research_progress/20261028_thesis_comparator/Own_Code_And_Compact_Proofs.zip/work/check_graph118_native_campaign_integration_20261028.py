"""New campaign-provider integration on paid saved data only, zero PF."""
from graph118_native_campaign_core_20261028 import *
O=R/'outputs/graph118_native_campaign_integration_20261028'
def main():
    O.mkdir(exist_ok=False);began=time.monotonic();p=read(P/'Protocol.json');pins(p);np,pp=setup()
    from published_graph118_episode_engine_v2_20261026 import NativeGraphEpisode
    from exact_graph_cursor_compare_20261023 import require_same
    from native_solver_input_identity_v3_20261023 import assert_solver_input_identity
    def forbidden(*a,**k):raise RuntimeError('CAMPAIGN_INTEGRATION_FORBIDS_NONLINEAR_CALL')
    pp.runpp=forbidden
    prior=read(R/'outputs/graph118_current_history_admission_20261028/build/Result.json')
    cursors=read(OLD/'Saved_Transition_And_Cursor_Readiness.json')['rows'];h=History(p,O/'native_identity');rows=[]
    try:
        for i,meta in enumerate(cursors):
            d=O/f'case_{i:02d}';d.mkdir();episode=NativeGraphEpisode.restore(d,decode(OLD,meta['cursor']))
            # Exercise the new campaign's exact native-input provider on a
            # previously paid identical physical request. No solver executes.
            reused,proof=h.lookup(episode.env.net,p['solver_kwargs']);assert reused is not None
            assert proof['kind']=='DERIVED_EXACT_NATIVE_INPUT_NOT_NEW_PF';frames_equal(reused,episode.env.net)
            assert np.array_equal(reused.res_bus.vm_pu.values,episode.env.net.res_bus.vm_pu.values)
            pending=episode.next_intent();saved=capsule(d/'pending.zlib',episode.snapshot())
            cold=NativeGraphEpisode.restore(d,decode(d,saved));require_same(episode.snapshot(),cold.snapshot(),'NEW_CAMPAIGN_PENDING_COLD')
            target=decode(R/'outputs/graph118_current_history_admission_20261028/build',prior['rows'][i]['target']);require_same(pending,target,'SOURCE_TARGET_BOUND_TO_PREVIOUS_ADMISSION')
            answer,gate=h.lookup(pending['before'],p['solver_kwargs']);assert answer is None and gate['kind']=='UNENTERED_IN_FIXED_RETAINED_SCOPE'
            receipt=read(R/proof['proof']);pd=(R/proof['proof']).parent
            a=decode(pd,receipt['newargs']);b=decode(pd,receipt['oldargs']);assert_solver_input_identity(a,b)
            # Mutate a real source solver keyword, not a synthetic outcome.
            changed=copy.deepcopy(b);key='kwargs'
            if key in changed:
                changed[key]=dict(changed[key],max_iteration=79)
                try:assert_solver_input_identity(a,changed)
                except (AssertionError,RuntimeError,ValueError):rejected=True
                else:raise AssertionError('Mutated solver contract accepted')
            else:rejected='SOURCE_ARGUMENT_SCHEMA_HAS_NO_KWARGS_LEAF; no claimed mutation test'
            rows.append(dict(case_id=meta['case_id'],actual_paid_native_input_reuse=True,source_next_target_exact=True,new_provider_unentered_gate=True,pending_cold_exact=True,mutation_check=rejected))
        put(O/'Result.json',dict(status='PASS_ALL4_NEW_CAMPAIGN_PROVIDER_INTEGRATION_NO_PHYSICS',rows=rows,costs=h.costs,
            new_PF_model_calls=0,source_hashes=p['source_hashes'],workflow_seconds=time.monotonic()-began,
            actual_new_commit_warm_cold='REQUIRED_AT_EACH_ACTUAL_NEW_COMMIT_BEFORE_NEXT_QUERY'))
    except BaseException as exc:
        put(O/'Failure.json',dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),new_PF_model_calls=0));raise
    finally:manifest(O)
    print(json.dumps(dict(status='PASS',cases=4,costs=h.costs,new_PF=0)))
if __name__=='__main__':main()
