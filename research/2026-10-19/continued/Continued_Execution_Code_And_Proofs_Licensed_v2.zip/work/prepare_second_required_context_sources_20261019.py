"""Freeze additive second context sources, not a retry of an old identity."""
import ast
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
def sub(text,a,b):
    assert text.count(a)==1,(a,text.count(a));return text.replace(a,b)
def main():
    out=R/'outputs/second_required_context_source_preparation_20261019';out.mkdir(exist_ok=False)
    src=R/'work/next_required_numeric_context_20261019.py';t=src.read_text('utf-8')
    t=t.replace("B=R/'outputs/next_required_numeric_context_20261019'","B=R/'outputs/second_required_numeric_context_20261019'").replace("SCREEN=R/'outputs/unstarted_paid_suffix_with_fixed_three_20261019'","SCREEN=R/'outputs/fixed_nine_preserved_receipts_screen_v3_20261019'")
    t=t.replace('audit_next_required_numeric_context_20261019.py','audit_second_required_numeric_context_20261019.py')
    t=sub(t,'from equal_operation_benchmark_v2 import process','from equal_operation_benchmark_v2 import process\nfrom prospective_query_custody_v2_20261019 import bind,atomic_new')
    t=sub(t,'        put(path,value)','        (atomic_new if Path(path).name==\'owner.claim\' else put)(path,value)')
    t=sub(t,"    catalog=read(R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json')", """    last=R/'outputs/next_required_numeric_context_20261019'
    previous=read(last/'independent_audit/Independent_Audit.json');assert previous['status'].startswith('PASS_SINGLE_EXACT_') and ident!=previous['identity']
    assert read(last/'additive_menu_join_v2/Full_Native_Menu_ACK.json')['status']=='PASS_EXACT_COMPLETE_SOURCE_NATIVE_MENU_NOT_A_FAVORABLE_SUBSET'
    assert ident.encode() not in (last/'actual/scientific.jsonl').read_bytes()
    for rel,digest in read(SCREEN/'Closed_Manifest.json')['members'].items():assert sha(SCREEN/rel)==digest
    assert read(SCREEN/'Results.json')['new_model_PF_optimizer_derivative_forecast_solve_calls']==0
    assert read(R/'outputs/prospective_query_custody_v2_20261019/Results.json')['status']=='PASS_THREE_REAL_ZERO_SCIENCE_CUSTODY_CASES'
    catalog=read(R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json')""")
    t=sub(t,"extra/'independent_audit/Independent_Audit.json',B/'Attempt_Coverage.json']", "extra/'independent_audit/Independent_Audit.json',last/'independent_audit/Independent_Audit.json',last/'actual/Closed_Manifest.json',last/'additive_menu_join_v2/Full_Native_Menu_ACK.json',R/'outputs/prospective_query_custody_v2_20261019/Results.json',B/'Attempt_Coverage.json']")
    t=t.replace('after all3pre-existing K4 queries measured','after ALL nine paid receipts retained, including four at a distinct saved point; no lifecycle-complete or physical-performance claim')
    t=sub(t,"    codes={}\n    try:","    h=bind(h,__file__)\n    codes={}\n    try:")
    t=sub(t,"if __name__=='__main__':", """def fixture():
    p=read(B/'Protocol.json');out=B/'fixture';writer=claim_writer(__file__)
    writer(out/'owner.claim',{'actual_pid':os.getpid()});put(out/'Result.json',{'status':'PASS_NEW_ACTUAL_SOURCE_CLAIM_ZERO_SCIENCE','scientific_calls':0})
    from public118_slsqp_native_20261018 import manifest
    manifest(out)
def preflight():
    p=read(B/'Protocol.json');h=helpers(__file__);h['B']=B;h=bind(h,__file__)
    code=h['launch'](Path(__file__),'identity-fixture',B/'fixture',p);assert code==0
    put(B/'Readiness.json',{'status':'PASS_ACTUAL_ATOMIC_OWNER_ACK_AND_CUSTODY_PLUS_EXACT_SOURCE_CONTEXT','fixture_exit_code':code,'new_scientific_calls':0})
if __name__=='__main__':""")
    t=t.replace("a.add_argument('--coordinator',action='store_true');args=a.parse_args()", "a.add_argument('--coordinator',action='store_true');a.add_argument('--identity-fixture',action='store_true');a.add_argument('--preflight',action='store_true');args=a.parse_args()")
    t=sub(t,'    if args.prepare:prepare()','    if args.identity_fixture:fixture()\n    elif args.preflight:preflight()\n    elif args.prepare:prepare()')
    t=sub(t,"    p=read(B/'Protocol.json');h=helpers(__file__);h['B']=B", "    p=read(B/'Protocol.json');assert read(B/'Readiness.json')['status']=='PASS_ACTUAL_ATOMIC_OWNER_ACK_AND_CUSTODY_PLUS_EXACT_SOURCE_CONTEXT';h=helpers(__file__);h['B']=B") if t.count("    p=read(B/'Protocol.json');h=helpers(__file__);h['B']=B")==1 else t
    producer=R/'work/second_required_numeric_context_20261019.py';ast.parse(t);producer.write_text(t,'utf-8')
    oldreader=R/'work/audit_next_required_numeric_context_20261019.py';r=oldreader.read_text('utf-8').replace('from next_required_numeric_context_20261019 import B,claim_writer','from second_required_numeric_context_20261019 import B,claim_writer').replace('from joint_reallocation_opportunity_core_v1 import action_key','from compile_lookahead_paid_input_cache_20261014 import action_key')
    reader=R/'work/audit_second_required_numeric_context_20261019.py';ast.parse(r);reader.write_text(r,'utf-8')
    put(out/'Sources.json',{'new_scientific_calls':0,'producer':sha(producer),'reader':sha(reader),'old_producer_untouched':sha(src),'old_failed_import_reader_untouched':sha(oldreader),'scientific_worker_original_FunctionDef_AST_reused':True,'new_scope':'Only ae3254... missing context of closed first original fixed leg; full native action table, fixed original equations; new custody transport and corrected import only.'})
    print('Second distinct numerical context sources prepared; no science')
if __name__=='__main__':main()
