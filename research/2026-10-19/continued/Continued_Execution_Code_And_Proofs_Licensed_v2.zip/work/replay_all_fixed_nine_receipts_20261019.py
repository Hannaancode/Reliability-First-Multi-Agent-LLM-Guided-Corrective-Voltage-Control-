"""Same fixed policy, ALL nine newly acquired receipts and existing contexts.

Read-only: no model/PF/derivative/forecast/solve/actual controller commit. Adds
four verified distinct-point receipts to the two-plus-three paid registry.
"""
import ast,copy,hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
import replay_paid_suffix_with_fixed_three_20261019 as three
import replay_fixed_receipts_with_next_context_20261019 as previous
import replay_unstarted_paid_suffix_numeric_v2_20261018 as original
import verified_paid_cache_engine_v2_20261018 as binding
from fixed_four_query_core_20261019 import B as FOUR,PHASES
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from strict_saved_native_input_match_v2_20261018 import require_same
from equal_operation_benchmark_v2 import decode_capsule
from audit_full_receding_linear_composed_v4_20261018 import check_query
from fixed_three_query_core_20261019 import transform
B=R/'outputs/all_nine_fixed_receipt_policy_screen_20261019'
PREP=R/'outputs/all_nine_fixed_receipt_policy_screen_preparation_20261019'
NUM=previous.NUM

# Invertible additive registry: parent retains old two and three receipts;
# separate four_* attributes and ledger prevent shadowing either old layer.
node=next(n for n in ast.parse(Path(three.__file__).read_text('utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='Registry')
text=ast.unparse(node)
edits=[('class Registry(TwoRegistry):','class Registry(three.Registry):')]
text=transform(text,edits)
text=text.replace('self.more','self.four').replace('THREE','FOUR').replace('new_three','new_four').replace('NEW_THREE','NEW_FOUR')
text=text.replace('PASS_COMPLETE_FIXED_FOUR_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY','PASS_COMPLETE_FIXED_FOUR_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY')
text=text.replace('len(self.four) == 3','len(self.four) == 4')
text=text.replace('assert key not in self.new_data and key not in self.archive.index','assert key not in self.new_data and key not in self.more and key not in self.archive.index')
exec(compile(text,__file__,'exec'),globals())

def main():
    assert read(FOUR/'Completion.json')['exit_codes']=={**{p:0 for p in PHASES},'audit':0}
    assert read(FOUR/'audit/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_FOUR_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
    assert not B.exists() and not PREP.exists()
    n=next(n for n in ast.parse(Path(previous.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    function='\n'.join(Path(previous.__file__).read_text('utf-8').splitlines()[n.lineno-1:n.end_lineno])
    before="files=[Path(__file__),Path(original.__file__),R/'work/replay_paid_suffix_with_fixed_three_20261019.py',NUM/'Protocol.json',NUM/'Completion.json',NUM/'additive_menu_join_v2/Full_Native_Menu_ACK.json',NUM/'menu_join_repair_v2_preparation/Completion.json',NUM/'independent_audit/Independent_Audit.json',NUM/'actual/Closed_Manifest.json']"
    after=before+";files += [Path(three.__file__),Path(previous.__file__),FOUR/'Protocol.json',FOUR/'Completion.json',FOUR/'audit/Independent_Audit.json']"
    changed=transform(function,[(before,after)])
    # Previous main already uses identical source menus and 900-second bound.
    env=previous.__dict__.copy();env.update(B=B,PREP=PREP,Registry=Registry,FOUR=FOUR,three=three,previous=previous,__file__=__file__)
    exec(compile(changed,__file__,'exec'),env);env['main']()
if __name__=='__main__':main()
