# Initial deployed-role compatibility: independently verified

11 October 2026. The prospectively frozen check and its single independent reader both ended with exit 0. This is a contract diagnostic, not another model-training or physical-performance experiment.

## The concrete finding

The original teacher targets permit a locally healthy agent to return null. The actual HG-VF campaign uses Reflection-v2, which requests a proposal while any global undervoltage remains. They are different tasks.

All 16,000 original TRAIN row identities and 109 world groups were retained. Four-zone CURRENT observations could be joined with exact scopes and boundary-voltage agreement in 105 worlds. Four worlds failed the scope/coherence gate and remain UNKNOWN; their 570 rows were not repaired or dropped. This source-consistent derivation does not certify the historical execution or augmentation lineage.

Among the 104 supported, globally stressed FIRST-ZONE source templates, **79 targets were null and 25 were grammar-compatible proposals**. Null conflicts with this mandatory initial serving role. This alone rejects direct, unmodified reuse of all old action-value targets for that role.

Across all 420 checked world-zone observations, 98 targets were null while global undervoltage remained (3,634 original rows), 318 were grammar-compatible action values (11,646 rows), and four observations had no live model slot because the whole grid was healthy (150 rows). The 312 later-zone empty-history prompts are explicitly COUNTERFACTUAL fixtures: actual earlier-zone actions and returned feedback are unknown. Their compatibility counts must not be reported as actual deployed calls.

Grammar compatibility certifies neither original assistant-response format, generated outputs, physical acceptance nor future recovery. The unchanged parser can transcribe the already saved action values; no generation or repair was performed. All complete records, unknown worlds and original multiplicities are saved.

## Evidence and actual cost

Owner 24268 executed `work/check_initial_reflection_target_compatibility_20261011.py` once. Reader 23244 executed `work/audit_initial_reflection_target_compatibility_20261011.py` once, after the actual owner ended and its manifest closed. Source and reader hashes were fixed before the owner started.

The reader independently reconstructed all row identities, current joins, exact Pandas lowest-eight tie handling, native candidate sets, action categories, current-only prompt fields, first-versus-later history distinctions and cost counters. All nine frozen-asset checks passed. It did not invoke controller functions, models, fits, forecasts or physics.

The producer paid 1.8464973999653012 seconds before manifest work, with 105 global extracts, 420 local extracts, 420 candidate-function returns and 416 pure prompt fixtures. Of these, 104 were supported first-zone templates and 312 counterfactual later-zone fixtures. The independent reader paid 2.635253000073135 seconds including frozen checks and archive sealing. These are diagnostic workflow measurements, not inference or deployment latency. All new model, nonlinear PF, optimizer, trained numerical, controller-loop, forecast, tokenizer and cloud calls were zero.

The new local archive has 23 members, 1,194,302 bytes and SHA256 `a87e9e9b6b80a9059d4ecc4cb1a277623746f8fd7b25d6841a9d738e918d68de`; CRC and every member hash passed. Reuse this certificate rather than rehashing the completed archive on each monitor check.

## Decision

Fixed gate: **DIRECT_UNMODIFIED_TARGET_REUSE_FAIL**. Stop direct reuse of these unchanged local/null targets for the mandatory-global Reflection-v2 policy. Preserve the original successful 0.5B format learning and original actor; this finding does not invalidate their separate local-role achievement.

Before: a larger actor could have been trained on targets that contradict its serving request. After: that invalid route is ruled out cheaply, without another GPU run. The previous 72.92% original-role numerical teacher-matching result remains valid for its declared local/null subrole; it cannot be transferred to the mandatory-global task. The mismatch is not an established explanation for every earlier failed neural intervention, whose inputs and targets differed.

No target rewriting, outcome-selected world removal, fabricated mandatory actions, feedback history or future reward is permitted. A next method must explicitly bind its role, current/process/receipt inputs, legal output, objective and complete costs. A faithful local-role scale experiment would answer a capacity question only. A materially different coordinator/sequence intervention needs prospective evidence of protected terminal opportunity beyond literal D-SE and strong equally informed numerical controls before expensive learning. Neither route is currently launch-ready.

The earlier stopped same-bus receipt intervention and its conditional stages remain stopped. No current GPU or physical performance campaign is justified by this diagnostic. Validated incremental LLM advantage over original D-SE and full security remain unachieved; no calibrated 90% winning probability has been established.

Evidence: `preparation/Protocol.json`, `execution/Results.json`, `execution/All_Initial_Contract_Compatibility_Records.json`, `execution/All_World_Current_Joins.json`, `execution/Actual_Costs.json`, `independent_audit/Independent_Audit.json`, `independent_audit/Fresh_Frozen_Asset_Checks.json`, `independent_audit/Actual_Reader_Final_Workflow_Cost.json`, and `independent_audit/Local_Archive_Audit.json`.
