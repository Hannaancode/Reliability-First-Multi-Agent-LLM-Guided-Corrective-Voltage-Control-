"""Audit observed UV0 even when source checkpoint/branch closure failed.

Does not manufacture the missing26th state, finish the old study, pass its
policy gate or infer LLM attribution. No additional physics is appropriate at
this already-UV0 current observation solely to fill an engineering run.
"""
import copy,gzip,hashlib,json,os,time
from pathlib import Path
import numpy as np,pandapower as pp
from full_receding_paid_campaign_20261015 import R,B as OLD,read,put,sha
import paid_receding_commit_and_history_v1 as original
from joint_reallocation_opportunity_core_v1 import load_endpoint,build_verifier,action
from shared_original_serving_action_domain_v1 import build_current_domain
from compile_lookahead_paid_input_cache_20261014 import point_key
from bounded_paid_lookahead_physics_20261014 import load_after
from equal_operation_benchmark_v2 import decode_capsule
from locked_source_receipt_verifier_v1_20261018 import LockedReceiptVerifier
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks
B=R/'outputs/observed_unclosed_zero_state_audit_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    prepared=R/'outputs/registry_following_engineering_input_preparation_v4_20261018/Prepared_Inputs.json';d=read(prepared)
    put(B/'Protocol.json',{'role':'INDEPENDENT_OBSERVED_UNCLOSED_SOURCE_UV0_STATE_AUDIT_NOT_FULL_POLICY',
        'source_sha256':sha(Path(__file__)),'input_extraction_sha256':sha(prepared),'bound_seconds':180,
        'selection':'First original declared unclosed branch selected before its endpoint was inspected; verify its actual latest committed paid NET. All other closed/partial/unknown outcomes retained.',
        'zero_is_observation_not_missing_branch_completion':True,'new_model_PF_optimizer_derivative_forecast_solve_calls':0})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    blocked=[]
    def no_science(*a,**k):blocked.append(True);raise AssertionError('Independent saved-data audit has no physics')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,no_science)
    ref=d['source_commit_reference']
    with (OLD/'actual/scientific.jsonl').open('rb') as f:f.seek(ref['offset']);raw=f.read(ref['bytes'])
    assert hashlib.sha256(raw).hexdigest()==ref['sha256'];event=json.loads(raw)
    assert event['event']=='actual_receding_first_commit' and event['protocol_sha256']==sha(OLD/'Protocol.json')
    record=event['data']['record'];assert record==d['source_commit_record']
    request=d['source_before_checkpoint'];before=original.restore(R/request['checkpoint'],request['receipt'])
    assert point_key(before['net'],before['cursor'])==request['expected_point_key']
    pbase=R/'outputs/primary_input_reference_index_20261018';indexraw=(pbase/'All_Primary_Input_References.json.gz').read_bytes()
    assert hashlib.sha256(indexraw).hexdigest()==read(pbase/'Results.json')['index_sha256'];entries=json.loads(gzip.decompress(indexraw))
    key=d['selected_paid_old_input_key'];assert key in entries
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    verifier=LockedReceiptVerifier()
    try:ack=verifier.certify(before['net'],before['cursor'],record['candidate'],entries[key],runner=runner,zones=zones,ack_path=B/'Independent_Selected_Source_Receipt_ACK.json')
    finally:verifier.close()
    assert ack['verdict']['accepted']
    after=load_after(d['selected_paid_after_reference'],None)['net'];cursor=record['following_cursor'];original.validate(after,cursor)
    assert cursor['committed_transitions'][:-1]==before['cursor']['committed_transitions']
    _,actuate,_=build_verifier(runner.rescue,before['cursor'])
    receipt={'receipt_id':record['paid_receipt_id'],'accepted':True,'converged':True,'fields':original.fields(after),'before_fingerprint':original.fingerprint(before['net'],before['cursor'])}
    following=original.commit_paid(before['net'],after,before['cursor'],record['candidate'],receipt,commit_id=record['commit_id'],actuate=actuate,
        next_scope=build_current_domain(after,before['cursor'],runner=runner,zones=zones)['shared_raw_receivers_for_BOTH_controls'])
    assert following==cursor
    with (OLD/'actual/capsules.bin').open('rb') as f:replay=decode_capsule(f,record['replay_receipt']['after'])['net']
    assert original.fields(after)==original.fields(replay)==record['replay_receipt']['fields']
    initial,initialcursor,_=load_endpoint(d['source_entry']);vm=after.res_bus.loc[range(118),'vm_pu'].to_numpy(dtype=float)
    assert vm.shape==(118,) and np.isfinite(vm).all() and int((vm<.95).sum())==0 and float(vm.max())<=1.05+1e-8
    initialUV=int((initial.res_bus.loc[range(118),'vm_pu'].to_numpy()<.95).sum())
    assert cursor['remaining_original_device_operation_slots']==1 and len(cursor['committed_transitions'])==12
    source=read(OLD/'actual/Result.json');assert not any(b['world']==d['source_entry']['world'] and b['mode']==d['method'] for b in source['branches'])
    assert source['all4_gate']=='UNKNOWN' and not (OLD/'actual/checkpoints/26').exists()
    output={'status':'PASS_INDEPENDENT_ACTUAL_OBSERVED_ZERO_UV_SOURCE_PREFIX_WITHOUT_BRANCH_CLOSURE',
        'world':d['source_entry']['world'],'method':d['method'],'source_start_residual_UV':initialUV,'observed_latest_UV':0,
        'all118_fields_saved_replay_exact':True,'vmin':float(vm.min()),'vmax':float(vm.max()),
        'original_total_operation_allowance':25,'observed_total_operations_debited':24,'remaining_original_operations':1,
        'observed_added_numerical_commits':12,'observed_added_numerical_device_operations':24-len(initialcursor['original_prefix_actions']),
        'normal_upper_1p05plus1e8_protection_pass':True,'cap450_no_refund_owned_stock_source_checks_pass':True,
        'source_selected_receipt_independently_reverified':True,'source_input_preparation_used_actual_selected_NET_not_replay_substitution':True,
        'initial_input_is_archived_trained_LLM_prefix':True,'fresh_LLM_calls':0,'LLM_causal_advantage':'NOT_ESTABLISHED',
        'DSE_or_whole_policy_superiority':'NOT_ESTABLISHED','source_full_four_world_gate':'UNKNOWN',
        'missing26th_complete_checkpoint_and_RNG':'NOT_RECOVERED_OR_INFERRED','branch_closure':'UNOBSERVED_NOT_INVENTED',
        'engineering_queries_at_this_zero_UV_state':'NOT_JUSTIFIED_BY_LEGAL_RECEDING_STOP; DO_NOT_LAUNCH_FROM_THE_PREPARED_338_ABSENT_KEYS',
        'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started}
    assert not blocked and time.perf_counter()-started<180
    put(B/'Results.json',output);put(B/'Fresh_Frozen_Checks.json',frozen_checks())
    put(B/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()},'new_science':0})
    print(json.dumps({'observed_zero_state_audit':'PASS','world':output['world'],'UV_before':initialUV,'UV_after':0,'total_operations':24,'branch_closed':False,'science':0}))
if __name__=='__main__':main()
