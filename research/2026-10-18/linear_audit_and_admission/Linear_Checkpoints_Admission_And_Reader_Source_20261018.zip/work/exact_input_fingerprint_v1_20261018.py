"""Exact all-non-result-frame equality key, with numeric column encoding.

The digest value differs from the original typed-JSON key. It MUST NOT replace
physical point IDs, frozen signatures or manifests. It is only an equality
predicate for an independently checked pair of saved input NETs. Axes, names,
dtypes and every frame (including empty templates) remain in the encoding.
"""
import hashlib,json,struct
import numpy as np,pandas as pd
from audit_spatial_allocation_inputs_v3_20261011 import typed

def _json(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def _add(h,b):h.update(struct.pack('<Q',len(b)));h.update(b)

def signature(net):
    frames={}
    for name in sorted(net):
        frame=net[name]
        if not isinstance(frame,pd.DataFrame) or name.startswith('res_'):continue
        h=hashlib.sha256()
        meta={'table':name,'index_type':type(frame.index).__name__,'index_dtype':str(frame.index.dtype),
              'index_names':typed(list(frame.index.names)),'index':typed(list(frame.index)),
              'column_type':type(frame.columns).__name__,'column_names':typed(list(frame.columns.names)),
              'columns':typed(list(frame.columns)),'dtypes':[str(d) for d in frame.dtypes]}
        _add(h,_json(meta))
        for i in range(len(frame.columns)):
            values=frame.iloc[:,i].to_numpy()
            kind=values.dtype.kind
            native_numeric=(kind in 'biu' and values.dtype.itemsize<=8) or (kind=='f' and values.dtype.itemsize in (2,4,8))
            if native_numeric:
                # The original typed encoding treats all NaN payloads alike,
                # while preserving finite values, signed zero and infinities.
                if kind=='f' and np.isnan(values).any():
                    values=values.copy();values[np.isnan(values)]=np.nan
                _add(h,b'NUMERIC_COLUMN');_add(h,str(values.dtype).encode());_add(h,np.ascontiguousarray(values).tobytes())
            else:
                _add(h,b'TYPED_COLUMN');_add(h,_json([typed(v) for v in values]))
        frames[name]=h.hexdigest()
    return hashlib.sha256(_json(frames)).hexdigest(),frames

def assert_same_inputs(a,b):
    if signature(a)!=signature(b):raise AssertionError('Exact non-result input tables differ')
