# Verified improvements since the initial work

This table lists positive, verified changes in the research system. It describes improvements in data, protection, implementation, testing and reliability. It does not turn those improvements into an unmeasured LLM-superiority claim. Dataset rows and compute costs overlap where measurements were reused and must not be summed into a new total.

| Before | After | Practical benefit |
|---|---|---|
| Some development comparisons used a bounded lowest-voltage approximation. | We audited the actual D-SE portfolio: original DFF plus DFF-ALT and the unchanged selector, charging both branches. | Future comparisons can target the real deterministic method. |
| Voltage summaries alone could hide a path violation or a wrong action identity. | Independent replay checks per-bus fields, committed actions, scope and continuous physical values to 1e-10. | We can distinguish a genuine recovery from an unsafe or mismatched result. |
| The initial material did not provide complete current observations along all training paths. | We now have verified development observations and 38,727 unique physically measured state/action labels across 31 fixed training worlds. | New hypotheses can be screened using real saved evidence instead of guessed rewards. These are correlated labels, not 38,727 independent worlds. |
| We had incomplete numerical rankings. | All 77,002 declared native arm records are now accounted for: 76,824 finite forecasts, 177 nonphysical results and one explicitly retained original unknown. | We can calculate honest opportunity ceilings without repeating the physics. |
| The proposed internal learning paths were implementation hypotheses. | Genuine pretrained runs updated the intended internal tensors, preserved the original weights and reproduced final outputs from fresh checkpoints. | We can separate working implementation from whether it makes better decisions. |
| A runtime loss could destroy the ability to reconstruct the exact optimizer state. | Completed later studies used locally verified full optimizer, RNG and cursor checkpoints with small hashed transfer acknowledgements. | Preserved progress and exact restoration are supported by actual evidence. |
| UV-only success could accept excessive upper voltage. | In the controlled guard study, endpoint upper-band breaches fell from four to zero. | Protection improved on those tested cases; this is a guard benefit, not language attribution. |
| Expensive learning trials sometimes preceded a decisive feasibility test. | A read-only candidate ceiling now rejected the next restricted selector with zero GPU, model, PF or controller calls. | We saved the cost of another unsupported training campaign. |
| Results and proposed ideas were spread across separate studies. | The critical review links the whole evidence record, prior-art overlaps, explicit stop gates and a conditional next-method plan. | Future work has one evidence-based decision record. |

Evidence paths and hashes are recorded in `Evidence_and_Source_Ledger.json`. The numerical-union and read-only calculations reference already verified archives; this review does not rerun or rehash those scientific packages.
