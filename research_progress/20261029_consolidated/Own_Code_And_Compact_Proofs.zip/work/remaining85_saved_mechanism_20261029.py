"""New saved-only rejection taxonomy; no controller, model, PF, or solver imports.

Reads the already audited endpoint selection and the last stored decision/proof
for each remaining case. Matrix products evaluate SAVED affine predictions only.
Does not repeat the all500 arithmetic audit or compute a new derivative/LP.
"""
import collections
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/remaining85_mechanism_review_20261029'
INPUTS = [
    'outputs/public13_voltage_magnitude_analysis_20261029/Results.json',
    'outputs/public13_voltage_magnitude_analysis_20261029/Independent_Arithmetic_Check.json',
    'outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json',
    'outputs/public13_saved_numeric_stagnation_20261022/All500_Arithmetic_Diagnosis.json',
    'outputs/public13_matched_numeric_execution_20261021/Result.json',
    'work/public13_matched_numeric_engine_20261021.py',
    'work/native_fit_teacher_math_20261020.py',
    'work/native_full_grid_affine_core_20261020.py',
]


def read(p):
    return json.loads((R / p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256((R / p).read_bytes()).hexdigest()


def count(v):
    return {'UV': int(np.sum(v < .95)), 'OV': int(np.sum(v > 1.05))}


def distance(v):
    return float(max(0., .95 - min(v), max(v) - 1.05))


def span(values):
    values = list(values)
    return {'min': min(values), 'median': float(np.median(values)), 'max': max(values)}


def main():
    O.mkdir(exist_ok=False)
    summary_source = read(INPUTS[0])
    comparison = read(INPUTS[2])
    primary = read(INPUTS[4])
    selected = {
        row['seed']: row for row in summary_source['rows']
        if row['method'] == 'our_numerical' and not row['descriptive_common_epsilon_fullband']
    }
    paired = {row['seed']: row for row in comparison['all500_paired_rows']}
    proofs = {m['directory']: m for m in primary['math_receipts'] if m['status'] == 'RETURNED'}
    rows = []
    for world in primary['worlds']:
        seed = world['seed']
        if seed not in selected:
            continue
        d = world['steps'][-1]
        assert world['status'] == 'COMPLETE_GUARD_REJECTED_HOLD_STOP'
        assert not d['accepted'] and all(s['accepted'] for s in world['steps'][:-1])
        before = np.asarray(d['current_vm'])
        after = np.asarray(d['candidate_vm'])
        normal = (before >= .95) & (before <= 1.05)
        assert world['final_vm'] == d['current_vm']
        directory = d['math_proof_directory']
        receipt = proofs[directory]
        for name in ['Current_Model.npz', 'LP1.npz', 'LP2.npz']:
            assert sha(directory + '/' + name) == receipt['proof_hashes'][name]
        with np.load(R / directory / 'Current_Model.npz', allow_pickle=False) as z:
            assert np.array_equal(z['vm'], before)
            S = z['S'].copy()
        with np.load(R / directory / 'LP1.npz', allow_pickle=False) as z:
            first = z['x'].copy()
        with np.load(R / directory / 'LP2.npz', allow_pickle=False) as z:
            second = z['x'].copy()
        dq = np.asarray(d['candidate_Q']) - np.asarray(d['current_Q'])
        predicted = before + S @ dq
        predicted_lp1 = before + S @ first[:3]
        predicted_lp2 = before + S @ second[:3]
        newly_uv = np.flatnonzero(normal & (after < .95 - 1e-8))
        newly_ov = np.flatnonzero(normal & (after > 1.05 + 1e-8))
        residual = after - predicted
        effect_round = predicted - predicted_lp2
        before_count, after_count = count(before), count(after)
        violated = np.r_[newly_uv, newly_ov]
        rows.append({
            'seed': seed,
            'input_stratum': paired[seed]['input_stratum'],
            'stopped_after_candidate_step': d['step'],
            'accepted_actions_before_hold': d['step'] - 1,
            'remaining_original_steps': 100 - d['step'],
            'status': world['status'],
            'terminal_band_distance_pu': distance(before),
            'rejected_candidate_band_distance_pu': distance(after),
            'candidate_reduced_max_band_distance': distance(after) < distance(before),
            'terminal_counts': before_count,
            'candidate_counts': after_count,
            'guard_violations': {
                'nonfinite': not bool(np.isfinite(after).all()),
                'previously_normal_bus_below_original_guard': newly_uv.tolist(),
                'previously_normal_bus_above_original_guard': newly_ov.tolist(),
                'strict_UV_count_increased': after_count['UV'] > before_count['UV'],
                'strict_OV_count_increased': after_count['OV'] > before_count['OV'],
            },
            'saved_LP1_minimax_t': float(first[-1]),
            'saved_LP2_t': float(second[-1]),
            'saved_LP1_absolute_final_Q_sum': float(np.sum(np.abs(np.asarray(d['current_Q']) + first[:3]))),
            'saved_LP2_absolute_final_Q_sum': float(np.sum(np.abs(np.asarray(d['current_Q']) + second[:3]))),
            'unrounded_LP1_affine_normal_min_vm': float(predicted_lp1[normal].min()),
            'unrounded_LP2_affine_normal_min_vm': float(predicted_lp2[normal].min()),
            'rounded_action_affine_normal_min_vm': float(predicted[normal].min()),
            'unrounded_LP2_affine_normal_guard_satisfied': bool(np.all(predicted_lp2[normal] >= .95 - 1e-8) and np.all(predicted_lp2[normal] <= 1.05 + 1e-8)),
            'rounded_action_affine_normal_guard_satisfied': bool(np.all(predicted[normal] >= .95 - 1e-8) and np.all(predicted[normal] <= 1.05 + 1e-8)),
            'affine_normal_lower_boundary_distance_pu': float(np.min(np.abs(predicted_lp2[normal] - .95))),
            'actual_normal_guard_max_shortfall_pu': float(max(0., .95 - 1e-8 - after[normal].min())),
            'actual_vm_minus_saved_affine_max_abs_pu': float(np.max(np.abs(residual))),
            'rounding_effect_on_saved_affine_max_abs_pu': float(np.max(np.abs(effect_round))),
            'newly_violating_buses': [{
                'bus_index': int(i), 'before_vm': float(before[i]), 'affine_unrounded_LP2_vm': float(predicted_lp2[i]),
                'affine_applied_action_vm': float(predicted[i]), 'actual_candidate_vm': float(after[i]),
                'actual_minus_applied_affine_vm': float(residual[i]),
            } for i in violated],
            'native_u': d['native_u'],
            'candidate_action_at_increment_cap': bool(np.any(np.abs(dq) >= float(np.float32(.3)) - 1e-12)),
            'candidate_Q': d['candidate_Q'],
            'current_Q': d['current_Q'],
            'native_endpoint_success': {m: v['full13band'] for m, v in paired[seed]['native'].items()},
            'native_common_guard_saved_prefix_success': {m: v['full13band'] for m, v in paired[seed]['common_guard_prefix'].items()},
            'current_NET': receipt['current_NET'],
            'candidate_saved_physical_receipt': {'path': d['candidate_receipt_after'], 'sha256': d['candidate_receipt_after_sha256']},
            'proof_directory': directory,
            'proof_hashes': receipt['proof_hashes'],
        })
    assert len(rows) == len(selected) == 85
    summary = {
        'cases': len(rows),
        'input_strata': dict(collections.Counter(r['input_stratum'] for r in rows)),
        'statuses': dict(collections.Counter(r['status'] for r in rows)),
        'stop_step_distribution': dict(sorted(collections.Counter(r['stopped_after_candidate_step'] for r in rows).items())),
        'previously_normal_bus_UV_guard_violation_cases': sum(bool(r['guard_violations']['previously_normal_bus_below_original_guard']) for r in rows),
        'previously_normal_bus_OV_guard_violation_cases': sum(bool(r['guard_violations']['previously_normal_bus_above_original_guard']) for r in rows),
        'strict_UV_count_increased_cases': sum(r['guard_violations']['strict_UV_count_increased'] for r in rows),
        'strict_OV_count_increased_cases': sum(r['guard_violations']['strict_OV_count_increased'] for r in rows),
        'candidate_reduced_max_band_distance_cases': sum(r['candidate_reduced_max_band_distance'] for r in rows),
        'rounded_action_affine_normal_guard_satisfied_cases': sum(r['rounded_action_affine_normal_guard_satisfied'] for r in rows),
        'unrounded_LP2_affine_normal_guard_satisfied_cases': sum(r['unrounded_LP2_affine_normal_guard_satisfied'] for r in rows),
        'saved_LP1_positive_t_above1e8_cases': sum(r['saved_LP1_minimax_t'] > 1e-8 for r in rows),
        'candidate_action_at_increment_cap_cases': sum(r['candidate_action_at_increment_cap'] for r in rows),
        'terminal_UV_total': sum(r['terminal_counts']['UV'] for r in rows),
        'terminal_OV_total': sum(r['terminal_counts']['OV'] for r in rows),
        'terminal_band_distance_pu': span(r['terminal_band_distance_pu'] for r in rows),
        'actual_normal_guard_max_shortfall_pu': span(r['actual_normal_guard_max_shortfall_pu'] for r in rows),
        'affine_normal_lower_boundary_distance_pu': span(r['affine_normal_lower_boundary_distance_pu'] for r in rows),
        'actual_vm_minus_saved_affine_max_abs_pu': span(r['actual_vm_minus_saved_affine_max_abs_pu'] for r in rows),
        'rounding_effect_on_saved_affine_max_abs_pu': span(r['rounding_effect_on_saved_affine_max_abs_pu'] for r in rows),
        'newly_UV_normal_bus_index_frequencies': dict(sorted(collections.Counter(b for r in rows for b in r['guard_violations']['previously_normal_bus_below_original_guard']).items())),
        'native_endpoint_success_on_same85': {m: sum(r['native_endpoint_success'][m] for r in rows) for m in ['safe-ddpg', 'linear', 'ddpg']},
        'native_guarded_prefix_success_on_same85': {m: sum(r['native_common_guard_saved_prefix_success'][m] for r in rows) for m in ['safe-ddpg', 'linear', 'ddpg']},
        'all_native_methods_failed_seeds': [r['seed'] for r in rows if not any(r['native_endpoint_success'].values())],
    }
    result = {
        'status': 'COMPLETE_NEW_SAVED_ONLY_REMAINING85_REJECTION_MECHANISM_TAXONOMY',
        'at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'New85-case last-candidate source/proof taxonomy. Selection reused completed common1e-8 analysis. Not a repeat audit or a new rollout.',
        'input_hashes': {p: sha(p) for p in INPUTS},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'summary': summary,
        'rows': rows,
        'historical_scores_retained': {'strict': {'ours': 264, 'ddpg': 363}, 'common1e8': {'ours': 415, 'ddpg': 363, 'safe_ddpg': 262, 'linear': 258}},
        'calls': {'new_PF': 0, 'new_model': 0, 'new_derivative': 0, 'new_LP': 0, 'new_optimizer': 0, 'new_training': 0, 'GPU': 0},
        'limits': [
            'Saved affine residual is a model-versus-returned-solver discrepancy, not a theorem identifying curvature or eliminating all solver errors.',
            'LP1 and LP2 saved predictions alone do not reveal the nonlinear result of the unexecuted LP1 action.',
            'Native successful paths demonstrate root-specific restoration under their contracts; they do not certify one-step feasibility at the numerical held state.',
            'No global or pathwise infeasibility certificate, new controller performance, LLM contribution, or unused confirmation is produced.',
        ],
    }
    with (O / 'Remaining85_Taxonomy.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
