from reflection118_remaining_cases_v2_core_20261023 import *
from original_case_missing_suffix_20261028 import OriginalMissingSuffix
TOP=R/'outputs/original_missing_suffix_preparation_20261028'
def case_paths():
    ap=argparse.ArgumentParser();ap.add_argument('--case-index',type=int,choices=[1,3],required=True)
    i=ap.parse_args().case_index
    return i,TOP/f'case_{i:02d}',R/'outputs/original_missing_suffix_execution_20261028'/f'case_{i:02d}'
