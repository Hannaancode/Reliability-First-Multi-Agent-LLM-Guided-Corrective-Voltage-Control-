# Decision after measured TRAIN trajectories

The original thesis baseline is sealed and the superiority objective is unachieved. VCSA remains stopped: both genuine pretrained arms selected identical actions on all 47 finite views, with no measured validation UV wins and greater VCSA training cost. An internal weight change and a lower training loss did not establish a useful intervention. Repeating its one-state objective with small parameter changes is not justified.

The new literal TRAIN measurement is complete and independently audited: 31 fixed finite TRAIN worlds, 62 branch identities, six prior searches reused, 56 missing searches measured, 343 actual full observation states and 281 executed actions. New search cost was 41,391 PF attempts, including 47 solver exceptions; 343 independent replay solves had no exceptions. Fourteen worlds contain a nontrivial protected recovery across three declared families. All 281 executed actions have native common/zone/Q support; 1,372 native zonal prompt checks fit the frozen 4,096-token context with the existing 384-token reserve. These are data and measurement results, not a trained LLM advantage.

The data gate passed, but its nine protected-versus-nonprotected branch contrasts are entirely explained by an immediate upper-band violation on the negative first action. Among five worlds where both entire recorded paths stayed in the upper band, there is no terminal UV difference. Thus these nine labels do not establish a need for long-horizon reasoning. A posthoc first-step veto matches the protected recorded branch in all nine pairs; it is a descriptive lookup, not a newly executed controller or a cost-saving result. The corresponding diagnostics are preserved with zero new model or PF calls.

## Critical literature and novelty boundary

The following assessment uses primary papers. It motivates tests; it does not transfer their results or supply a success probability.

| Paper | Relevant mechanism | Limit and decision for HierGrid |
|---|---|---|
| [Fine-Tuning LLMs to Generate Economical and Reliable Actions for the Power Grid](https://arxiv.org/html/2602.15350) | DC-oracle supervised adaptation followed by AC-derived DPO preferences and structured switching outputs. | This is direct power-grid prior art for AC preference tuning and action grammar. Its neural baseline has the lowest AC failure rate, while voltage comparisons also use a common-success subset. Its open-only switching task, API model and oracle differ from our shunt-control portfolio. Simple grid DPO is not a novel contribution by itself, and those results do not prove superiority over our D-SE. |
| [Contrastive Preference Learning](https://arxiv.org/html/2310.13639) | Connect discounted state/action log likelihoods with preference learning through a maximum-entropy advantage formulation. | Its optimal-regret feedback and coverage assumptions are not established by our small, deterministic, immediate-safety contrasts. Finite-data policy ambiguity and its conservative regularization matter. Renaming our existing one-step labels as trajectory preferences would not repair this gap. |
| [Inverse Preference Learning](https://arxiv.org/html/2305.15363) | Relate preference learning, values and rewards through an inverse Bellman formulation. | This is a distinct value-learning hypothesis, requiring trustworthy transitions, support and consistent preference semantics. Adding a value network cannot manufacture missing protected continuation evidence. |
| [Grammar-Aligned Decoding](https://arxiv.org/html/2405.21047) | Analyze the difference between grammar masking and the LM distribution conditioned on valid grammar. | A constrained action policy must have an explicit probability model. Token masking is not automatically the original LM conditioned on valid actions. Our four-zone query, verification and candidate selection pipeline is not the likelihood of one executed JSON action. |

Eight of the nine existing protected contrasts share a legal first-action zone; one is cross-zone. A naive single-zone chosen/rejected training pair is therefore not valid for every contrast. The existing two-best response grammar is also different from a single-action JSON string. No teacher-forced single-action likelihood, future reward for an unexecuted candidate, or mature training implementation is assumed.

## The next actual CPU question

Apply the already-declared normal-upper mediation equally to both full literal branches, preserving their original 25 iterations, solver, verifier, Q grid, seed, scoring and selector. Label this new reference G-DSE. Keep the original unguarded D-SE and its full two-branch costs separately; the primary comparator has not been replaced.

Measure all 31 previously fixed TRAIN worlds. Reuse four complete individual guarded references from two exact TRAIN worlds; their parent Stage3 campaign remains terminal partial and its missing global costs stay unknown. Only the 58 genuinely missing guarded searches may run. Existing controls and completed scientific searches are not restarted. Capture actual states, every candidate, exceptions, committed actions, original selection, and all controller and replay costs. Preserve unsafe, failed, partial and unexecuted identities. The collection is CPU-only, with one writer, a three-hour overall bound and a 30-minute per-branch bound. The previous 46.5-minute literal collection suggests a conditional 45–90-minute planning range; the guard can change paths, so this is not an ETA.

The target-feasibility gate was fixed before new guarded searches:

- Every declared branch and root pair must have verified actual evidence; every committed prefix must satisfy the unchanged 1.05+1e-8 common guard.
- At least three nontrivial protected-success worlds across two declared families and two protected-versus-residual-UV pairs.
- At least three distinct-root-action worlds across two families where ALT ends with fewer UV buses than DFF, and at least one world where DFF ends with fewer than ALT. These conditions reject an always-choose-one-branch learning target.
- All inherited and current costs remain separate. Counts alone cannot pass the data gate. Incomplete measurement is UNKNOWN, not a negative scientific target result.

Passing permits method design, not automatic training. Failure stops this guarded branch-selection episode-learning proposal. There will be no lower threshold, larger-Q sweep, prompt/seed/checkpoint selection, fabricated reward or favorable-case substitution after the results.

## Native replay and control recovery

The first guarded owner stopped before any new controller search after one actual prefix PF return. Native Linux voltages and a previously measured Windows root differ by at most about1.9e-15; the original strict OV display count changes from1 to0 at1.05. The original source records and both counters remain intact. This is not a physical failure or proof that protected targets are absent.

An additive, explicitly posthoc measurement contract preserves native and current OV counts separately. It requires all 118 voltages and continuous metrics to agree within1e-10, every UV membership and count to agree exactly, both OV counts to match their own genuine voltage vectors, and every differing OV classification to lie within1e-10 of the unchanged1.05 boundary. The existing1.05+1e-8 common guard remains mandatory. No original score, verifier, selector or threshold uses a replacement OV value. The data cannot be described as reproducing all native discrete metrics exactly.

The subsequent owner stored ten genuine prefix measurements but then encountered a Python local-import scope error, still before any new controller search. Its source, closed journal, manifest and ten actual PF returns are preserved. The additive control repair reuses those ten saved measurements and performs their previously unexecuted independent replay; it does not repeat their derivation or restart the old owner. Both readiness attempts and their costs remain separate. Six guard/observer tests and six new boundary-contract checks passed; they are software/read-only evidence, not model performance.

## Conditional model route after the data gate

A candidate worth investigating is a copied-LoRA policy aligned with verified continuation utility, rather than the detached one-state classifier tested by VCSA. A first bounded implementation could choose between two verified root options under a precisely normalized binary token policy. The original base and adapter remain preserved; only an independently identified copy may learn. This directly tests adaptation of genuine LM parameters, with an exact forward/inference decision contract and checkpoint replay.

This is a research hypothesis, not a claimed novel algorithm. Binary option selection is contextual algorithm selection; applying DPO alone already has prior art. The novelty search must examine physically supported credit assignment, cost-aware decision utility and uncertainty/abstention mechanisms before naming a contribution. No model architecture or optimizer pilot is ready from this document alone.

Both options would use a measured shared root candidate search, whose cost is charged. The learner cannot receive future outcomes, branch IDs, scenario IDs or labels as inputs. Raw native observations and prospective action identities must define one common context. Strong numerical controls receive the same information, data, options and training partitions, including constant-branch and immediate-rule baselines. Capacity, frozen-backbone computation, precision and training budgets must be disclosed. A shared-root deterministic portfolio is an additional strong efficiency control, while literal original D-SE remains primary with both complete branches charged.

A two-option selector cannot beat the best of its two fully evaluated options on physical endpoints. Its possible value is amortized branch selection with less total work and retained endpoint quality; any claimed LLM-specific value also has to beat the same-information numerical learner. A guard benefit, reduced budget, faster solver or copied teacher answer alone does not count.

If the targets and interfaces pass, freeze one objective and a final-checkpoint rule before training. Run the numerical control first, then one genuine bounded copied-LoRA integration smoke to measure actual memory, gradients, restoration and step costs. The previous pilot used one T4 and29.19 owned minutes for310 steps/654 forwards, but that does not establish the cost of full LoRA preference adaptation. A new ETA requires the new measured smoke; additional CLI accounts do not combine VRAM or establish free hours.

Finally, require actual fresh matched trajectories, raw common/zone scope, common protection, complete training/model/solver/preparation/failure costs, continuous physical replay and genuinely unused authorized confirmation. Historical TRAIN, inspected validation and the sealed bank are development evidence. No90percent outcome guarantee or superiority claim follows from these preparation or data gates. Full security integration remains downstream of clean attribution.
