from public13_radial_outer_certificate_20261022 import execute
if __name__=='__main__':execute()
