"""Verify actual leased branch head, tree identities, lengths and remote bytes."""
import base64,hashlib,json,urllib.request
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/exact_two_paid_query_engineering_20261018/publication_paths_v2'
def get(s):
    u='https://api.github.com/repos/Hannaancode/Reliability-First-Multi-Agent-LLM-Guided-Corrective-Voltage-Control-'+s
    return json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'Accept':'application/vnd.github+json','User-Agent':'HierGrid-evidence-verifier'}),timeout=60))
def main():
    e=json.loads((P/'Expected_Remote_Files.json').read_text('utf-8'));head=get('/git/ref/heads/research-progress-20261018')['object']['sha'];assert head==e['head']
    c=get('/git/commits/'+head);assert c['tree']['sha']==e['tree'] and [v['sha'] for v in c['parents']]==[e['previous_head']]
    tree=get('/git/trees/'+e['tree']+'?recursive=1');assert not tree['truncated'];entries={v['path']:v for v in tree['tree']};rows=[]
    for f in e['files']:
        p=R/f['local'];local=p.read_bytes();assert len(local)==f['bytes'] and hashlib.sha256(local).hexdigest()==f['sha256']
        blob=hashlib.sha1(b'blob '+str(len(local)).encode()+b'\0'+local).hexdigest();assert blob==f['blob']==entries[f['path']]['sha'] and len(local)==entries[f['path']]['size']
        remote=get('/git/blobs/'+blob);assert remote['encoding']=='base64';raw=base64.b64decode(remote['content']);assert raw==local
        rows.append({'path':f['path'],'bytes':len(raw),'blob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'remote_bytes_equal_local':True})
    receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_REMOTE_LEASED_HEAD_TREE_ALL7_BLOBS_SIZES_AND_EXACT_DOWNLOADED_BYTES','head':head,'tree':e['tree'],'previous_head':e['previous_head'],'files':rows,
        'no_complete_raw_binary_backup_claim':True,'all6finalgoalsopen':True}
    with (P/'Verified_GitHub_Receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)
    print(json.dumps({'GitHub':'PASS','head':head,'exact_downloaded_files':len(rows)}))
if __name__=='__main__':main()
