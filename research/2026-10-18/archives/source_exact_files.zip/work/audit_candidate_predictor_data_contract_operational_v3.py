"""Independent closed-data boundary/label and original cheap-rule audit.

No pretrained model, optimizer, numerical solver or controller is invoked.
"""
from pathlib import Path
from datetime import datetime,timezone
from types import SimpleNamespace
import ast,gzip,hashlib,json,math
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'outputs/llm_value_next_method_research_20261008'
DATA=PARENT/'guarded_train_trajectory_measurement_native_v3'
BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
CONTRACT=BASE/'input_and_target_contract_nullable_v2';OUT=BASE/'input_and_target_contract_operational_v3_audit'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
digest=lambda v:hashlib.sha256(canonical(v).encode()).hexdigest()
ROOT_FIELDS={'schema_version','physical_tables','zone_buses','zone_reports','global_metrics',
             'literal_fallback_bus_pool','raw_zonal_bus_pools','raw_common_and_zone_pools'}
Q=(25.,50.,75.,100.,125.,150.,200.,250.,300.)
assert not OUT.exists(),'No duplicate or partial audit restart'
protocol=read(CONTRACT/'protocol.json');assert read(CONTRACT/'summary.json')['method_training_or_performance_not_started']
assert sha(ROOT/'work/prepare_candidate_predictor_data_contract_nullable_v2.py')==protocol['source_sha256']
assert sha(ROOT/'work/candidate_predictor_input_contract.py')==protocol['input_contract_source_sha256']
SUPPORT=BASE/'current_added_support_observables'
assert read(SUPPORT/'summary.json')['old_observations_input_targets_manifests_unchanged']
for folder in (DATA,CONTRACT,SUPPORT):
    for n,m in read(folder/'manifest.json').items():assert sha(folder/n)==m['sha256'] and (folder/n).stat().st_size==m['bytes']
optimization=set(protocol['optimization_world_sha256']);held=set(protocol['development_held_world_sha256'])
assert len(optimization)==23 and len(held)==8 and not optimization&held
allworlds={w['sha256']:w for w in read(DATA/'protocol.json')['worlds']}
assert optimization|held==set(allworlds)
expected_inputs={};expected_labels={};raw_occurrences=0
for world in allworlds.values():
    for branch in ('DFF','DFF-ALT'):
        r=read(DATA/'branches'/(world['scenario_id']+'__'+branch+'.json'))
        for o in r['observations']:
            obs=o['input_observation'];obs_id=o['observation_sha256'];assert digest(obs)==obs_id
            if obs_id in expected_inputs:assert canonical(expected_inputs[obs_id]['observation'])==canonical(obs) and expected_inputs[obs_id]['world']==world['sha256']
            else:expected_inputs[obs_id]={'observation':obs,'world':world['sha256']}
        for d in r['measured_decisions'] or []:
            for c in d['candidates']:
                raw_occurrences+=1;act=c['action']['add_shunts_q_mvar'];bus,q=next(iter(act.items()))
                key=(d['observation_sha256'],int(bus),Q.index(float(q)))
                if key in expected_labels:assert canonical(expected_labels[key]['verif'])==canonical(c['verif'])
                else:expected_labels[key]=c
source=ROOT/'work/e/audit/phase2g_rescue_runner.py';tree=ast.parse(source.read_text(encoding='utf-8'))
functions=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name) for name in ('score_candidate','llm_q_abs_at_bus')]
scope={};exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),scope)
cap_assignment=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MAX_ABS_Q_PER_BUS' for t in n.targets))
cap=ast.literal_eval(cap_assignment.value);assert cap==450.
class SavedShunts:
    def __init__(self,frame):self.frame=frame
    def __len__(self):return len(self.frame['values'])
    def iterrows(self):
        for i,row in zip(self.frame['index'],self.frame['values']):yield i,dict(zip(self.frame['columns'],row))
def lines(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:
        for line in f:yield json.loads(line)
support_rows={r['observation_id']:r for r in lines(SUPPORT/'Current_Control_State_Observables.jsonl.gz')}
assert len(support_rows)==311
asset=read(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json')['_object']['shunt']
baseline_frame=json.loads(asset['_object']);baseline_ids=set(baseline_frame['index'])
assert len(baseline_ids)==14
inputs={};typed_rows=0;cheap_support={}
for row in lines(CONTRACT/'Current_Input_Rows.jsonl.gz'):
    identity=row['observation_id'];assert identity not in inputs and identity in expected_inputs
    x=row['model_input'];assert set(x)=={'current_physical_observation','original_Q_grid'}
    assert tuple(x['original_Q_grid'])==Q and set(x['current_physical_observation'])==ROOT_FIELDS
    assert canonical(x['current_physical_observation'])==canonical(expected_inputs[identity]['observation'])
    assert digest(x)==row['model_input_sha256'] and row['world_sha256']==expected_inputs[identity]['world']
    assert row['split']==('optimization' if row['world_sha256'] in optimization else 'development_held')
    f=x['current_physical_observation']['physical_tables']['shunt']
    current_rows=[(i,dict(zip(f['columns'],v))) for i,v in zip(f['index'],f['values'])]
    independently_summed=[0.]*118
    for i,r in current_rows:
        if i not in baseline_ids:independently_summed[int(r['bus'])]+=abs(float(r['q_mvar']))
    s=support_rows[identity]
    assert s['current_added_support_MVAr_by_bus']==independently_summed and s['original_cap_MVAr']==450.
    assert s['committed_prefix_checks'] and all(p['baseline_and_added_row_correspondence_passed'] for p in s['committed_prefix_checks'])
    for p in s['committed_prefix_checks']:assert p['record_sha256'] in {m['sha256'] for m in read(DATA/'manifest.json').values()}
    augmented={**x,'current_control_state':{'original_per_bus_added_support_cap_MVAr':450.,'added_abs_Q_MVAr_by_bus':independently_summed}}
    assert digest(augmented)==s['augmented_model_input_sha256']
    cheap_support[identity]={b:v for b,v in enumerate(independently_summed)}
    inputs[identity]=row;typed_rows+=1
assert set(inputs)==set(expected_inputs)
seen=set();unknown_convergence=0;raw_cap_reject_occurrences=0;unique_cap_rejects=0;finite=0;after_unknown=0
targeted_states=set();regression_checks=0
for row in lines(CONTRACT/'Measured_Target_Rows.jsonl.gz'):
    obs_id=row['observation_id'];assert obs_id in inputs and obs_id not in targeted_states
    targeted_states.add(obs_id);assert row['world_sha256']==inputs[obs_id]['world_sha256'] and row['split']==inputs[obs_id]['split']
    root=inputs[obs_id]['model_input']['current_physical_observation'];pools=root['raw_common_and_zone_pools']
    for item in row['measured_candidates']:
        t=item['target'];key=(obs_id,t['bus'],t['Q_index']);assert key in expected_labels and key not in seen;seen.add(key)
        c=expected_labels[key];v=c['verif'];assert canonical(t['recorded_verifier'])==canonical(v) and canonical(t['action'])==canonical(c['action'])
        assert t['q_mvar']==Q[t['Q_index']] and any(t['bus'] in p for p in pools.values())
        assert t['recorded_original_score']==list(scope['score_candidate'](c))
        reported=type(v['converged']) is bool;assert t['convergence_reported']==reported
        cap_reject=cheap_support[obs_id][t['bus']]+abs(t['q_mvar'])>cap
        # This checks the exact original pre-PF cap, not a learned label or new safety threshold.
        assert cap_reject==(v['reason']=='q_cap_exceeded')
        if cap_reject:
            unique_cap_rejects+=1;raw_cap_reject_occurrences+=item['occurrences']
            assert v['accepted'] is False and v['after'] is None and v['converged'] is None
        if not reported:unknown_convergence+=1
        after=v['after'];actual_finite=after is not None and all(type(x) in (int,float) and math.isfinite(x) for x in after.values())
        assert t['has_finite_after_global_metrics']==actual_finite
        if actual_finite:
            finite+=1;regression_checks+=1
            expected={'UV_gain':v['before']['uv_count']-after['uv_count'],
                      'deficit_gain':v['before']['deficit_sum']-after['deficit_sum'],
                      'vmin_gain':after['vmin']-v['before']['vmin'],'normal_upper_margin':1.05+1e-8-after['vmax']}
            assert canonical(t['measured_global_gains'])==canonical(expected) and t['one_step_UV_zero']==(after['uv_count']==0)
        else:
            after_unknown+=1;assert t['measured_global_gains'] is None and t['one_step_UV_zero'] is None
assert seen==set(expected_labels) and len(seen)==38727 and raw_occurrences==44649 and len(targeted_states)==238
normal=read(CONTRACT/'Input_Normalization.json');assert set(normal['optimization_world_sha256'])==optimization
assert len(read(CONTRACT/'World_and_Invalid_Denominators.json')['original_invalid_TRAIN_inputs'])==1
result={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_current_input_identity_scope_label_boundaries_passed':True,
 'unique_current_input_rows':typed_rows,'unique_measured_state_action_targets':len(seen),'targeted_states':len(targeted_states),
 'raw_candidate_occurrences_preserved':raw_occurrences,'world_groups_disjoint':True,'no_after_or_identity_metadata_in_forward_inputs':True,
 'exact_recorded_original_scores_verified':len(seen),'finite_global_outcome_and_gain_checks':regression_checks,
 'unique_missing_global_outcomes_not_imputed':after_unknown,'unique_unreported_convergence_targets_not_labelled_failure':unknown_convergence,
 'exact_original_450MVAr_cumulative_added_support_precheck_verified':len(seen),
 'unique_actual_prePF_Q_cap_rejections':unique_cap_rejects,'raw_actual_prePF_Q_cap_rejection_occurrences':raw_cap_reject_occurrences,
 'known_original_prechecks_must_be_shared_with_future_comparator_arms':True,
 'omitted_name_role_limitation_disclosed_no_names_claimed_recaptured':True,
 '311_augmented_current_support_inputs_independently_checked':True,
 'original_frame_excluded_name_geo_geometry_coords_std_type_not_claimed_complete_net_snapshot':True,
 'cap_observable_manifest_sha256':sha(SUPPORT/'manifest.json'),
 'failed_cap_reconstruction_source_and_evidence_preserved':True,
 'new_model_optimizer_solver_controller_cloud_calls':0,'old_failed_branch_selector_gate_not_relaxed':True,
 'data_is_historical_development_not_independent_confirmation':True,'future_predictor_architecture_or_training_not_certified':True,
 'data_manifest_sha256':sha(CONTRACT/'manifest.json'),'source_sha256':sha(Path(__file__))}
OUT.mkdir()
with (OUT/'Independent_Current_Input_and_Measured_Target_Audit.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
with (OUT/'manifest.json').open('x',encoding='utf-8') as f:
    json.dump({'Independent_Current_Input_and_Measured_Target_Audit.json':{'bytes':(OUT/'Independent_Current_Input_and_Measured_Target_Audit.json').stat().st_size,
          'sha256':sha(OUT/'Independent_Current_Input_and_Measured_Target_Audit.json')}},f,indent=2)
print(json.dumps(result,indent=2))
