# Evidence-led experiments after mixed prototype outcomes

Prepared8 October2026 before endpoint diagnostic evaluation. The human requested continued, well-designed experiments and explicitly rejected minor tweaks followed by repeated attempts to obtain a preferred result. The research objective is measurable useful learned contribution under protected physical verification and honest cost accounting. A positive model outcome is a hypothesis, not a guaranteed output.

## 1. Diagnose the mechanism before another controller variant

All six saved historical prototype endpoints enter one CPU diagnostic, including the three that cleared UV and the three that retained UV. No endpoint is selected because it looks favorable. Reconstruct each endpoint from the preserved physical case and exact committed actions; require unchanged sources and continuous state equality within1e-10. Then test every unique action from the existing no-model candidate-bus construction and unchanged nine-value Q sweep. Do not generate another case, add a bus, change the Q grid, relax verification, or continue a recovery trajectory.

The diagnostic is exhaustive only over that finite, state-specific, one-action universe. It is not a global optimization certificate, a reachable-trajectory bound, or a new policy campaign. Its computation exceeds the controller's32-candidate search and is separately charged as an offline diagnostic. Count solver exceptions, cap rejections, reconstruction and independent selected-action confirmation solves. The entire job is capped at5,180 PF attempts and refuses duplicate/partial reruns.

At every endpoint retain original accepted actions, rejection reasons, best original score, first accepted position under each declared ordering, and whether accepted actions also satisfy the normal upper1.05 band at the already labelled1e-8 diagnostic tolerance. This normal-band classification does not alter the original verifier or overwrite strict metric counts. At each stopped endpoint compare the actual saved terminal search with the full set; confirm its tested actions' acceptance and metrics reproduce. Successful endpoints are descriptive controls, not outcome-independent held-out cases.

## 2. Fix the decision rules before seeing diagnostic results

| Evidence | Consequence |
|---|---|
|A stopped endpoint has accepted actions outside its actual bounded search|Ordering/coverage is a supported mechanism to investigate. Test the already declared LoRA/base/no-model screen when real model execution is available. Do not increase only the model arm's budget.|
|No original-verifier accepted action exists in the entire declared one-action universe|Stop claiming ordering alone can rescue that endpoint. Analyze multi-step admissibility/search-space limitations before proposing a different method; this is not global infeasibility.|
|Original accepted actions exist but none pass the diagnostic normal-upper band|Study common constraint mediation or trajectory viability as a separately declared change, applied to every arm. Do not call UV clearance full physical success.|
|Learned screen shows no improvement over its fixed primary deterministic control|Retain the null/adverse result. Diagnose applicability, input/output and proposal utility before any new bounded experiment; no automatic prompt/Q/budget sweep to chase a win.|
|LoRA improves the two-state primary screen|Advance to the already specified outcome-independent broader development set and matched controls. Two points in one family cannot establish superiority or independent confirmation.|

These diagnoses can coexist across different endpoints. Every selected decision will cite the actual corresponding artifact and explain what it can and cannot establish. Success for the next diagnostic means an audited distinction between mechanisms, even if that distinction shows a proposed improvement cannot work.

## 3. Complete the clean attribution experiment when GPU access is genuinely restored

Preserve the prepared12 genuine LoRA/base proposal batches, verified adapter isolation and original generation settings. The18 no-model one-state controls are already completed and must be reused without rerun. Complete only the12 learned numerical rows and then the complete30-row descriptive comparison, with lowest-voltage ordering at budget32 fixed as primary; retain enumeration, seeded random, base model, budgets8/32/128, invalid proposals, all costs and voltage-band outcomes. Do not substitute saved pilot text for new inference or alter the frozen model/network/bank. Colab explicitly denies the selected account GPU access due to usage limits; no allocation retries or account rotation to bypass it are part of this CPU plan.

## 4. Justification and research scope

The budget-dependent quality of a search space is a distinct problem from changing the optimizer; that motivates measuring whether useful actions exist before spending inference on their ordering. This is a methodological inference from [Ariafar et al., AISTATS2022](https://proceedings.mlr.press/v151/ariafar22a.html), whose applications are hyperparameter tuning, not this power system. The inspected primary abstract supports this distinction; it does not predict our outcome.

Use targets and actual function-call effort alongside timing, consistent with the benchmarking rationale in [COCO](https://arxiv.org/abs/1603.08785). A PF call and an LLM call remain separate real costs; inference latency is not removed by calling the numerical arm cheaper.

[LLAMBO](https://arxiv.org/abs/2402.03921) motivates isolating candidate generation and other components rather than attributing a tool-assisted portfolio's success to its LLM. Its hyperparameter-optimization results do not establish usefulness for the frozen0.5B grid model. These are focused primary-source design justifications, not a general manuscript review or a guarantee of positive results.

Full cybersecurity evaluation follows clean-value and adapter gates. The preserved24-trial pilot remains development evidence. Frozen active-power/slack limitations are not repaired by relabelling reactive compensation or adjusting success thresholds.
