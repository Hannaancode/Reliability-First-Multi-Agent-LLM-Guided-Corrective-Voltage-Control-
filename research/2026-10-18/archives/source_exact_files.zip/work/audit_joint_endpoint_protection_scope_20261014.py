"""Source-only paired-action protection/resource contract; no physics or model."""
import ast,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];OUT=R/'outputs/joint_endpoint_protection_scope_20261014'
def put(p,d):
    with p.open('x',encoding='utf8') as f:json.dump(d,f,indent=2);f.flush();os.fsync(f.fileno())
def function(path,name):
    tree=ast.parse((R/path).read_text('utf8'))
    return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
def calls(f,name):
    return [n for n in ast.walk(f) if isinstance(n,ast.Call) and ast.unparse(n.func).split('.')[-1]==name]
def main():
    paths=['work/owned_bank_joint_reallocation_v1.py','work/joint_reallocation_opportunity_core_v1.py',
      'work/paid_joint_commit_v1.py','work/paid_joint_commit_v2.py','work/e/audit/phase2g_rescue_runner.py',
      'work/physics_env/Lib/site-packages/pandapower/results_bus.py']
    prepare=function(paths[0],'prepare_equal_reallocation');verify=function(paths[4],'verify_action')
    commit=function(paths[2],'commit_paid');shunt=function(paths[5],'_get_shunt_results')
    assert not calls(prepare,'run_pf') and not calls(prepare,'runpp')
    assert len(calls(prepare,'add_positive'))==1 and len(calls(verify,'run_pf'))==1
    donor=next(n for n in ast.walk(prepare) if isinstance(n,ast.Assign) and 'target.shunt.at[donor_index' in ast.unparse(n))
    assert donor.lineno<calls(prepare,'add_positive')[0].lineno
    apply=calls(verify,'apply_action');assert len(apply)==1 and apply[0].lineno<calls(verify,'run_pf')[0].lineno
    expressions=[ast.unparse(n.value) for n in ast.walk(shunt) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='q_shunt' for t in n.targets)]
    assert 'u_shunt ** 2 * q_shunt_step * shunt_is * v_ratio * step' in expressions
    checks={'paired_actuation_changes_donor_then_receiver_before_any_solve':True,
      'original_verifier_solves_once_after_complete_actuation':True,
      'commit_validation_uses_paid_final_fields_and_two_operation_debit':"debit = 1 if row['kind'] == 'ordinary' else 2" in ast.unparse(commit),
      'commit_normal_band_checks_final_receipt_only':"max((x['vm_pu'] for x in receipt['fields'].values())) <= 1.05 + 1e-08" in ast.unparse(commit),
      'installed_shunt_actual_reactive_output_depends_on_voltage_squared':True}
    assert all(checks.values()),checks
    OUT.mkdir(exist_ok=False)
    certificate={'status':'SOURCE_SCOPE_VERIFIED_NO_NEW_PHYSICAL_MEASUREMENT','checks':checks,
      'source_sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},
      'source_lines':{'paired_donor_change':donor.lineno,'paired_receiver_change':calls(prepare,'add_positive')[0].lineno,
       'original_complete_candidate_solve':calls(verify,'run_pf')[0].lineno,'commit_paid':commit.lineno,'shunt_results':shunt.lineno},
      'paired_endpoint_is_measured_intermediate_switch_states_are':'UNKNOWN_NOT_MEASURED_BY_THIS_CONTRACT',
      'both_switching_orders_or_transients_safe':'UNKNOWN_NOT_CERTIFIED',
      'equal_resource_quantity':'EQUAL_NOMINAL_MVAR_TWO_DEVICE_OPERATIONS_NOT_EQUAL_ACTUAL_Q_OR_NO_NEW_HARDWARE',
      'post_move_actual_Q_no_cost_or_conservation_inference_from_equal_nominal_Q':True,
      'no_current_scientific_or_reader_source_edit':True,'new_model_PF_optimizer_forecast_solve_calls':0}
    put(OUT/'Source_Scope_Certificate.json',certificate)
    note=('The paired move is a static complete-candidate endpoint experiment. Source changes the donor bank and creates a receiving bank before a single PF solve. '
      'The paid commit checks that solved endpoint, unchanged native improvement predicates and final normal upper band, and debits two device operations. '
      'It does not measure a donor-only or receiver-only intermediate state or certify physical synchronized switching/transients. '
      'The original pending-action component already explicitly labels switchability as a research-block assumption; this review binds that limitation to the actual source rather than introducing a new physical result.\n\n'
      'Equal reallocation means equal nominal MVAr withdrawn/added. The actual installed shunt-result equation is q = vm_pu^2 * nominal_q * in_service * voltage_rating_ratio * step. '
      'Actual reactive output therefore need not cancel between different buses/voltages. A newly created receiving bank is still charged capacity and a device operation; no free hardware or unchanged actual total reactive power follows.\n\n'
      'For a future model attribution experiment, give the numerical controls exactly the same batched-pair action, stock, receiver scope, paid receipts, operation/resource charges and endpoint protection. '
      'Report any gain over original add-only D-SE as a distinct action-space effect before attributing an additional model benefit. '
      'If the intended deployment requires per-device switching protection, prospectively specify the legal switching schedule and independently paid intermediate states, convergence/protection and rejection rules before outcomes. '
      'Existing endpoint archives cannot certify these unexecuted intermediate states; do not fabricate them or rerun old physics. '
      'Keep literal DFF/DFF-ALT/unchanged selector and FULL BOTH costs, and distinguish any common-protection variant from those originals. '
      'This source certificate does not establish a new unsafe case, invalidate measured endpoints, prove operational feasibility, novelty or LLM superiority.\n')
    (OUT/'Required_Protection_And_Resource_Controls.md').write_text(note,encoding='utf8')
    entry={'event_id':'joint_endpoint_protection_and_nominal_resource_scope_20261014',
      'method':'Source-only audit of the paired actuation, single original candidate solve, paid final-state commit/protection, and actual installed shunt reactive-output equation.',
      'result':'Both device changes precede one endpoint PF; normal band and native improvement are checked on the paid final state. Intermediate switching states remain unmeasured. Equal withdrawn/added nominalMVAr is not equal actualQ because the installed equation includes voltage squared. Zero model/PF/optimizer/forecast/solve calls.',
      'improvements':'Future attribution and operational protocols now have explicit same-batched-action controls, intermediate-state evidence requirements if applicable, and actual-versus-nominal resource accounting. Avoids crediting an enlarged action space, skipped switching-state checks or nominal-capacity assumptions to language pretraining.',
      'limitations':'Source scope only, not a new physical safety failure, performance test or field hardware certificate. Existing measured endpoints remain preserved; no future intermediate fields or costs invented.',
      'decision':'Keep current sole partial reader unchanged. Use the contract before a separately justified future matched protocol; no automatic physics/model launch from this certificate.',
      'sources':[str((OUT/'Source_Scope_Certificate.json').relative_to(R)),str((OUT/'Required_Protection_And_Resource_Controls.md').relative_to(R))]+paths[:5]}
    ep=OUT/'Research_Progress_Entry.json';put(ep,entry)
    subprocess.run([sys.executable,str(R/'work/append_research_progress.py'),'--entry-json',str(ep)],check=True)
    rp=R/'outputs/critical_research_reset_20261010/Research_Resume_20261012.json';resume=json.loads(rp.read_text(encoding='utf-8-sig'))
    resume['latest_joint_endpoint_switching_and_nominal_resource_scope']=str((OUT/'Source_Scope_Certificate.json').relative_to(R))
    with rp.open('w',encoding='utf8') as f:json.dump(resume,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'source_checks':checks,'new_scientific_calls':0,'endpoint_intermediate_protection':'UNKNOWN_NOT_MEASURED'}))
if __name__=='__main__':main()
