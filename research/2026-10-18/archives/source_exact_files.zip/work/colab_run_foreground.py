"""Keep the actual experiment execution in an active Colab code cell."""
import json,logging,sys,uuid
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8');logging.disable(logging.CRITICAL)
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from colab_cli.runtime import ColabRuntime
status=json.loads(Path('outputs/colab_frozen_restore_status.json').read_text());assert not status['runtime_released'] and status['created_by_this_task']
credentials=Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud\application_default_credentials.json');credentials.refresh(Request())
session=AuthorizedSession(credentials);runtime=None
try:
 client=Client(Prod(),session);assignment=client._get_assignment(uuid.UUID(status['notebook_hash']),variant=Variant.GPU,accelerator=Accelerator.T4)
 assert hasattr(assignment,'runtime_proxy_info')
 runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-active-code-cell')
 code="""
import os,subprocess,json
from pathlib import Path
os.chdir('/content/hiergrid_execution')
log=open('outputs/matched_campaign.log','w')
proc=subprocess.Popen(['env/bin/python','work/run_matched_campaign.py','--resume'],stdout=log,stderr=subprocess.STDOUT)
Path('outputs/matched_campaign_process.json').write_text(json.dumps({'pid':proc.pid,'created_by_this_task':True,'execution':'active_code_cell'}))
print('HIERGRID_FOREGROUND_CAMPAIGN_STARTED',proc.pid,flush=True)
return_code=proc.wait()
log.close()
print('HIERGRID_FOREGROUND_CAMPAIGN_FINISHED',return_code,flush=True)
assert return_code==0,'Campaign process exited with an error; see saved log'
"""
 def stream(out):
  if out.get('output_type')=='stream':
   for line in out.get('text','').splitlines():
    if line.startswith('HIERGRID_'):print(line,flush=True)
 outputs=runtime.execute_code(code,output_hook=stream,allow_stdin=False,timeout=43200)
 for out in outputs:
  if out.get('output_type')=='error':print('FOREGROUND_KERNEL_ERROR_TYPE',out.get('ename'),flush=True)
except Exception as exc:print('FOREGROUND_CONNECTION_FAILURE_TYPE',type(exc).__name__,flush=True)
finally:
 if runtime is not None:runtime.stop()
 session.close()
