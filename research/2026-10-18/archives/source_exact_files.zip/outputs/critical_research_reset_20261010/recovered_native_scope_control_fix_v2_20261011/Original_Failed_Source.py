"""Only the 20 previously untested native scope bindings; no solver/model imports."""
import ast,hashlib,json,os,time
from pathlib import Path
from datetime import datetime,timezone
from types import SimpleNamespace
import numpy as np
import pandas as pd
from train_trajectory_measurement_nullable_v2 import safe,digest
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'outputs/critical_research_reset_20261010/recovered_native_scope_binding_20261011'
def ext(p):return Path('\\\\?\\'+str(p)) if os.name=='nt' else p
OUT=ext(RAW)
DATA=ROOT/'outputs/critical_research_reset_20261010/native_cached_contexts_20261011'
RESCUE=ROOT/'work/e/audit/phase2g_rescue_runner.py'
RUNNER=ROOT/'work/e/audit/phase2g_llm_guided_rescue_runner.py'
META=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
def read(p):return json.loads(ext(p).read_text('utf8'))
def sha(p):return hashlib.sha256(ext(p).read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(safe(v),f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def subset(path,names,constants,env):
 tree=ast.parse(path.read_text('utf8'));chosen=[]
 for n in tree.body:
  if isinstance(n,ast.FunctionDef) and n.name in names:chosen.append(n)
  elif isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in constants:
   ast.literal_eval(n.value);chosen.append(n)
 assert {n.name for n in chosen if isinstance(n,ast.FunctionDef)}==set(names)
 exec(compile(ast.Module(body=chosen,type_ignores=[]),str(path),'exec'),env)
 return hashlib.sha256(ast.dump(ast.Module(body=chosen,type_ignores=[]),include_attributes=False).encode()).hexdigest()
def main():
 OUT.mkdir(exist_ok=False);start=time.perf_counter();source_protocol=read(DATA/'Protocol.json');result=read(DATA/'Results.json');index=read(DATA/'Descriptor_Index.json')
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'source_pins':{p.relative_to(ROOT).as_posix():sha(p) for p in [RESCUE,RUNNER,META,ROOT/'work/train_trajectory_measurement_nullable_v2.py']},'input_pins':{p.relative_to(ROOT).as_posix():sha(p) for p in [DATA/'Protocol.json',DATA/'Descriptor_Index.json',DATA/'Results.json']},'exact_targets':[{'world_sha256':r['world_sha256'],'branch':r['branch'],'after_commit':r['after_commit'],'path':r['path'],'sha256':r['sha256']} for r in index if r['world_sha256'] in {s['world_sha256'] for s in result['recovered_individual_sources']}],'fixed_gate':'All 20 exact common ordered bus pool, zone reports, raw zone pools and common AND zone intersections; every discrepancy retained; no relaxed equality or physics retry.','resource_seconds':120,'new_solver_model_fit_forecast_derivative_converter_cloud_calls':0,'held8_outcomes_NOT_READ':source_protocol['held8_branch_files_NOT_READ']}
 assert len(protocol['exact_targets'])==20
 write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'command':Path(__file__).name,'at_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha(OUT/'Protocol.json')})
 previous_recipe=read(ROOT/'outputs/critical_research_reset_20261010/OPT_native_current_recipe_20261011/Protocol.json')
 assert sha(META)==previous_recipe['input_sha256']['metadata']
 env={'np':np};ast_rescue=subset(RESCUE,['global_uv_buses','lowest_buses','extract_zone_state_full','candidate_buses_from_state'],['V_MIN','V_MAX','ANCHOR_BUSES'],env)
 ast_runner=subset(RUNNER,['get_zone_candidate_buses'],['ZONE_ANCHORS'],env)
 zones={k:[int(b) for b in v] for k,v in read(META)['zones'].items()};branches={};rows=[]
 for target in protocol['exact_targets']:
  assert time.perf_counter()-start<120,'Bound exceeded; no extension/retry'
  node=read(DATA/target['path']);assert sha(DATA/target['path'])==target['sha256']
  binding=node['branch_source'];path=ROOT/binding['path']
  if binding['path'] not in branches:
   assert sha(path)==binding['sha256'];branches[binding['path']]=read(path)
  occurrence=next(o for o in branches[binding['path']]['observations'] if o['decision']==target['after_commit'])
  obs=occurrence['input_observation'];assert digest(obs)==node['observation_sha256']
  ids=obs['physical_tables']['res_bus']['index'];busids=obs['physical_tables']['bus']['index'];vector=node['native_current']['vm_pu']
  assert set(vector)=={str(int(b)) for b in ids}
  net=SimpleNamespace(bus=pd.DataFrame(index=busids),res_bus=pd.DataFrame({'vm_pu':[vector[str(int(b))] for b in ids]},index=ids))
  reports={z:env['extract_zone_state_full'](net,z,zones) for z in sorted(zones)}
  common=env['candidate_buses_from_state'](net,zones,reports,[])
  zonal={z:env['get_zone_candidate_buses'](net,z,zones,reports[z]) for z in sorted(zones)}
  intersections={z:[b for b in common if b in zonal[z]] for z in zonal}
  checks={'common_ordered_pool_exact':common==obs['literal_fallback_bus_pool'],'raw_zone_pools_exact':safe(zonal)==obs['raw_zonal_bus_pools'],'common_AND_zone_exact':safe(intersections)==obs['raw_common_and_zone_pools'],'descriptor_zone_scope_exact':safe(intersections)==node['legal_zone_bus_intersections']}
  # Reports are new deterministic source computations, not previously promised exact replay scalars.
  rows.append({**target,'checks':checks,'gate':'PASS_EXACT_SCOPE' if all(checks.values()) else 'UNKNOWN_SCOPE_DISAGREEMENT','actual_native_vector_sha256':digest(vector),'native_zone_reports':safe(reports),'native_common_pool':common,'native_raw_zone_pools':zonal,'native_common_AND_zone':intersections,'source_scope_computation_only_NOT_a_new_PF_or_successor':True})
 results={'at_utc':datetime.now(timezone.utc).isoformat(),'rows':20,'pass_exact_scope':sum(r['gate']=='PASS_EXACT_SCOPE' for r in rows),'unknown_scope_disagreements':sum(r['gate']!='PASS_EXACT_SCOPE' for r in rows),'prior242_scope_evaluations_NOT_REPEATED':True,'native_function_ast_sha256':{'rescue_subset':ast_rescue,'runner_subset':ast_runner},'actual_branch_reads':len(branches),'pure_scope_evaluations':len(rows),'new_scientific_calls':0,'workflow_seconds_before_report_manifest':time.perf_counter()-start,'actor_and_physical_performance_ready':False,'overall_LLM_advantage':'UNPROVED'}
 write(OUT/'All20_Native_Scope_Records.json',rows);write(OUT/'Results.json',results)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.relative_to(OUT).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
 print(json.dumps(results))
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'state':'TERMINAL_SCOPE_CHECK_PARTIAL_NO_AUTOMATIC_RETRY','exception':type(exc).__name__,'message':str(exc),'actual_pid':os.getpid(),'new_scientific_calls':0})
  raise
