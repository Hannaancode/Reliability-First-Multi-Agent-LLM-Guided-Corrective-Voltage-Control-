"""Read existing native reference/engineering/fresh-root inputs for ALL45 gaps.

No nonlinear/model replay. Every missing input, component match or unclosed
attempt blocks exclusion. This separately closes named lineages only.
"""
import gzip, hashlib, json, os, pickle, sys, time
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_additional_history_scope_20261022'
Q = R / 'outputs/original_role_prior_input_scope_20261022'
REF = R / 'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012'
ENG = R / 'outputs/critical_research_reset_20261010/spatial_native_engineering_20261012/execution'

def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(x): return json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def write(name, value):
    with (O / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())

def observation_component(tables):
    # Independently translate only preserved physical-input columns. Results
    # and the prior cardinality-only exclusion are not used for this query.
    def records(table):
        return {i: dict(zip(table['columns'], row)) for i, row in zip(table['index'], table['values'])}
    buses = records(tables['bus']); values = {}
    for s in records(tables['shunt']).values():
        b = int(s['bus']); bus = buses[b]
        assert s.get('step_dependency_table', False) is False
        if not s['in_service'] or not bus['in_service']: continue
        v = Fraction(float(bus['vn_kv'])) / Fraction(float(s['vn_kv']))
        w = v * v * Fraction(float(s['step']))
        p, q = values.get(b, (Fraction(0), Fraction(0)))
        values[b] = (p + Fraction(float(s['p_mw'])) * w, q + Fraction(float(s['q_mvar'])) * w)
    rows = [[b, [p.numerator, p.denominator], [q.numerator, q.denominator]]
            for b, (p, q) in sorted(values.items()) if p or q]
    return hashlib.sha256(canonical(rows)).hexdigest()

def main():
    O.mkdir(exist_ok=False); started = time.perf_counter()
    targets = read(Q / 'All45_Indexed_Scope_Query.json')
    catalog = read(R / 'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json')
    fresh = next(x for x in catalog if x['path'].endswith('fresh_paid_receipt_opportunity_preparation_v1/execution/Actual_Observation_Journal.jsonl'))
    branchjournals = sorted((REF / 'branches').glob('*/scientific.jsonl'))
    assert [p.parent.name for p in branchjournals] == ['L1_literal_DFF', 'L1_literal_DFF_ALT', 'L1_protected_DFF', 'L1_protected_DFF_ALT', 'L2_literal_DFF']
    sources = branchjournals + [ENG / 'events.jsonl', R / fresh['path']]
    write('Protocol.json', {'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'FROZEN_BEFORE_ALL45_QUERY_OF_ADDITIONAL_INPUTS', 'fixed_seconds': 900,
        'targets_sha256': sha(Q / 'All45_Indexed_Scope_Query.json'),
        'selection': 'ALL45missing targets, all five actual original reference branches, every native engineering attempt and all3418 fresh-root attempts; no outcome subset',
        'source_sha256': sha(Path(__file__)), 'sources': {str(p.relative_to(R)): sha(p) for p in sources},
        'reader_source_sha256': sha(R / 'work/audit_original_role_additional_histories_20261022.py'),
        'old60426index': 'Reused through separate independent ALL45 query; not decoded or audited again',
        'new_scientific_calls': 0,
        'limits': 'Necessary shunt admittance only, any match UNKNOWN. Named tracked lineages, not all universal histories. Native PF leaves these physical shunt parameters unchanged, as preserved original source and old independent checks establish.'})
    write('owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(), 'source_sha256': sha(Path(__file__))})
    import candidate_process_runtime
    sys.path.append(str(R / 'work/physics_env/Lib/site-packages'))
    import pandapower as pp
    def forbidden(*a, **k): raise BaseException('Solver/model forbidden in read-only input history closure')
    for n in ['runpp', 'rundcpp', 'runopp', 'runpp_3ph']:
        if hasattr(pp, n): setattr(pp, n, forbidden)
    from prior_physical_query_footprints_20261018 import component
    keys = {t['physical_component_sha256'] for t in targets}; matches = {k: [] for k in keys}
    refs = []; counts = []; unknown = []; total = 0
    def record(key, source, identity, anchor=None):
        nonlocal total
        total += 1
        ref = {'journal': str(source.relative_to(R)), 'identity': identity, 'component_sha256': key}
        if anchor is not None: ref['anchor'] = anchor
        refs.append(ref)
        if key in keys: matches[key].append(ref)
        assert time.perf_counter() - started < 900, 'Original read-only bound, no extension'
    for path in branchjournals:
        pending = {}; start = total
        with path.open('rb') as f:
            for raw in f:
                row = json.loads(raw)['row']; e = row['event']; d = row['payload']
                if e == 'literal_PF_intent':
                    assert d['identity'] not in pending; pending[d['identity']] = d
                elif e in ['literal_PF_return', 'literal_PF_exception']:
                    assert d['identity'] in pending; del pending[d['identity']]
                    a = d['anchors']; folder = path.parent / a['relative']
                    assert sha(folder / 'Manifest.json') == a['manifest_sha256']
                    rawnet = (folder / 'trusted_local_net.pkl').read_bytes()
                    assert hashlib.sha256(rawnet).hexdigest() == a['payload_sha256']
                    net = pickle.loads(rawnet)['net']; key, _ = component(net)
                    record(key, path, d['identity'], a)
        if pending: unknown.append({'journal': str(path.relative_to(R)), 'unclosed_intents': pending})
        counts.append({'journal': str(path.relative_to(R)), 'closed_attempts': total - start, 'unclosed_attempts': len(pending)})
    # Native engineering's query input is the immutable parent plus its exact
    # action. Resolve returns AND exceptions from that pre-call saved state.
    path = ENG / 'events.jsonl'; starts = {}; intents = {}; closed = set(); start = total
    for raw in path.open('rb'):
        row = json.loads(raw)['row']; e, d = row['event'], row['payload']
        if e == 'new_query_intent': starts[d['identity']] = d
        elif e in ['PF_intent', 'direct_PF_intent']: intents[d['identity']] = d
        elif e in ['PF_return', 'PF_exception']:
            q = starts[d['identity']]
            rawparent = (ENG / 'states' / q['parent'] / 'trusted_local_state.pkl').read_bytes()
            assert hashlib.sha256(rawparent).hexdigest() == q['parent']
            parent = pickle.loads(rawparent)['net']
            from frozen_physics_loader import load_stack
            if 'runner' not in locals(): _, runner, _ = load_stack()
            import copy
            net = copy.deepcopy(parent); runner.rescue.apply_action(net, q['action'])
            key, _ = component(net); record(key, path, d['identity'], {'parent': q['parent'], 'action': q['action']}); closed.add(d['identity'])
        elif e in ['direct_PF_return', 'direct_PF_exception']:
            if e == 'direct_PF_return': a = d['anchors']; payload = ENG / a['payload']; expected = a['payload_sha256']
            else: raise AssertionError('Unobserved direct failure input needs explicit closure, no guessed exclusion')
            rawnet = payload.read_bytes(); assert hashlib.sha256(rawnet).hexdigest() == expected
            key, _ = component(pickle.loads(rawnet)['net']); record(key, path, d['identity']); closed.add(d['identity'])
    pending = set(intents) - closed
    if pending: unknown.append({'journal': str(path.relative_to(R)), 'unclosed_intents': sorted(pending)})
    counts.append({'journal': str(path.relative_to(R)), 'closed_attempts': total - start, 'unclosed_attempts': len(pending)})
    # ALL actual fresh-root observations; do not use the older target's shunt
    # row-count proof. Every intent must have a closed finite observation.
    path = R / fresh['path']; pending = None; start = total; attempts = 0; h = hashlib.sha256()
    for raw in path.open('rb'):
        h.update(raw); d = json.loads(raw)
        if d['event'] == 'solver_attempt':
            assert pending is None; pending = (d['identity'], d['phase'], d['arguments']); attempts += 1
        elif d['event'] == 'solver_closed':
            assert pending == (d['identity'], d['phase'], d['arguments']); pending = None
            assert d['exception'] is None and d['observation'] is not None
            key = observation_component(d['observation']['physical_tables'])
            record(key, path, d['identity'])
    assert h.hexdigest() == fresh['sha256'] and attempts == total - start == 3418 and pending is None
    counts.append({'journal': str(path.relative_to(R)), 'closed_attempts': total - start, 'unclosed_attempts': 0})
    with gzip.open(O / 'All_Named_Prior_Attempt_Component_References.json.gz', 'wb') as f: f.write(canonical(refs))
    result = {'status': 'COMPLETE_NAMED_ADDITIONAL_INPUT_SCOPE_ONLY' if not unknown else 'PARTIAL_PENDING_ATTEMPT_INPUTS_UNKNOWN',
        'declared_targets': 45, 'actual_named_attempts_checked': total, 'source_counts': counts,
        'target_match_counts': {f"{t['root']}|{t['bus']}|{t['q_mvar']}": len(matches[t['physical_component_sha256']]) for t in targets},
        'matching_refs': matches, 'unclosed_or_missing': unknown, 'new_scientific_calls': 0,
        'not_universal_historical_closure_or_PF_authority': True, 'workflow_seconds': time.perf_counter() - started}
    write('Result.json', result)
    write('Closed_Manifest.json', {'members': {p.name: sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({k: result[k] for k in ['status', 'actual_named_attempts_checked', 'new_scientific_calls', 'workflow_seconds']}))

if __name__ == '__main__': main()
