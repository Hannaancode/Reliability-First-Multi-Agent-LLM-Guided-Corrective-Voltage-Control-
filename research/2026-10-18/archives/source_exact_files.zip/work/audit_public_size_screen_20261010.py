"""External complete/partial saved-output reader; no pretrained or PF calls."""
import argparse,collections,gzip,json,os,sys,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'work'))
import candidate_process_runtime
import numpy as np
from transformers import AutoTokenizer
from public_size_screen_reader_contract_v2_20261010 import validate_fixed_case,parse_response,find_saved_outcome,compare_known_pair
from candidate_process_evidence_utils import read,sha,write,seal,frozen_checks

R=ROOT/'outputs/critical_research_reset_20261010';PREP=R/'public_size_production_preparation_v4'
EX=R/'public_size_execution';OUT=R/'public_size_external_audit'
def rows(path):
    with gzip.open(path,'rt',encoding='utf-8') as f:return [json.loads(x) for x in f]
def score_saved(target):
    v=target['recorded_verifier']
    if not v['accepted']:return [-999]*5
    a,b=v['after'],v['before'];q=sum(abs(float(x)) for x in target['action']['add_shunts_q_mvar'].values())
    return [int(a['uv_count']==0),b['uv_count']-a['uv_count'],b['deficit_sum']-a['deficit_sum'],a['vmin']-b['vmin'],-q]
def measure(case,parsed,target):
    result=find_saved_outcome(case,parsed,target)
    if parsed['kind']=='command' and target:
        matches=[x['target'] for x in target['measured_candidates'] if x['target']['bus']==parsed['bus'] and x['target']['Q_index']==parsed['Q_index']]
        if matches:
            assert matches[0]['recorded_original_score']==score_saved(matches[0])
    return result

def main():
    assert not OUT.exists(),'No duplicate external reader';OUT.mkdir();started=time.perf_counter()
    write(OUT/'audit.claim',{'pid':os.getpid(),'source_sha256':sha(Path(__file__))})
    protocol=read(PREP/'protocol.json');status=read(EX/'status.json');desc=read(EX/'remote_closed_descriptor.json')
    assert status['runtime_released'] and status['all_actual_closed_artifacts_preserved'] and desc['scientific_process_ended']
    for path,h in read(PREP/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha(ROOT/path)==h
    for path,h in protocol['local_analysis_source_hashes'].items():assert sha(ROOT/path)==h
    study=EX/'staged/study'
    for name,m in desc['members'].items():assert (study/name).stat().st_size==m['bytes'] and sha(study/name)==m['sha256']
    with zipfile.ZipFile(EX/'preserved_remote_science.zip') as z:
        assert z.testzip() is None and set(z.namelist())==set(desc['members'])
        for name,m in desc['members'].items():
            value=z.read(name);assert len(value)==m['bytes'] and __import__('hashlib').sha256(value).hexdigest()==m['sha256']
    identity=read(study/'scientific_identity.json')
    assert identity['protocol_sha256']==sha(PREP/'protocol.json') and identity['cases_sha256']==sha(PREP/'cases.json')
    assert identity['source_hashes']==protocol['remote_source_hashes']
    assert identity['environment']==read(EX/'staged/public_size_environment.json')
    assert identity['environment']['versions']==protocol['framework_versions']
    assert identity['environment']['device']=='Tesla T4'
    assert len(identity['environment']['models'])==len(protocol['models'])==2
    vocab={}
    for declared,actual in zip(protocol['models'],identity['environment']['models']):
        for key in ['arm','repo','revision']:assert declared[key]==actual[key]
        assert actual['files']==declared['files'] and actual['actual_header_parameters']==declared['public_safetensors_parameters']
        config=read(PREP/'tokenizers'/declared['arm']/'config.json')
        vocab[declared['arm']]=vocab[declared['arm']+'_cold']=config['vocab_size']
    cases=read(PREP/'cases.json');assert len(cases)==31
    for c in cases:validate_fixed_case(c)
    events=[json.loads(x) for x in (study/'events.jsonl').read_text().splitlines()]
    attempts={};returns={};generation_attempts=[];generation_returns=[]
    for e in events:
        if e['kind']=='forward_attempt':
            key=(e['arm'],e['sequence']);assert key not in attempts;attempts[key]=e
            assert e['arm'] in vocab and e['input_tokens']==len(e['input_ids']) and e['input_tokens']>0
            assert all(type(i) is int and 0<=i<vocab[e['arm']] for i in e['input_ids'])
        elif e['kind']=='forward_return':
            key=(e['arm'],e['sequence']);assert key in attempts and key not in returns
            a=attempts[key];assert all(e[k]==a[k] for k in ['arm','sequence','phase','observation_id','input_tokens'])
            p=study/e['logits_file'];assert sha(p)==e['logits_sha256']
            with np.load(p,allow_pickle=False) as block:
                assert set(block.files)=={'logits'};values=block['logits']
                assert values.ndim==1 and len(values)==e['vocab_size']==vocab[e['arm']] and np.isfinite(values).all()
                assert str(values.dtype)==e['last_logits_dtype'] and int(np.argmax(values))==e['greedy_argmax_token_id']
            assert e['model_wall_seconds']>=0;returns[key]=e
        elif e['kind']=='generation_attempt':generation_attempts.append((e['arm'],e['observation_id']))
        elif e['kind']=='generation_return':
            generation_returns.append((e['arm'],e['observation_id']))
            assert sha(study/e['response_file'])==e['response_sha256']
    assert len(generation_attempts)==len(set(generation_attempts)) and len(generation_returns)==len(set(generation_returns))
    assert set(generation_returns)<=set(generation_attempts)
    target_path=ROOT/protocol['targets']['path'];assert sha(target_path)==protocol['targets']['sha256']
    targets={r['observation_id']:r for r in rows(target_path)}
    assert sha(PREP/'Local_Numerical_Control_References.json')==protocol['local_control_references_sha256']
    controls=read(PREP/'Local_Numerical_Control_References.json');by_case={};results={};tokenizers={};claimed_forwards=set()
    for declaration in protocol['models']:
        arm=declaration['arm'];tokenizer=AutoTokenizer.from_pretrained(str(PREP/'tokenizers'/arm),local_files_only=True,trust_remote_code=False)
        tokenizers[arm]=tokenizer;arm_rows=[]
        for c in cases:
            key=(arm,c['observation_id']);path=study/arm/'responses'/f'{c["observation_id"]}.json'
            if not path.exists():
                row={'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],
                  'response_status':'attempt_without_closed_response' if key in generation_attempts else 'unexecuted',
                  'outcome':{'physical_outcome_known':False,'outcome_status':'missing_model_response'}}
            else:
                record=read(path);assert key in generation_returns
                for name in ['observation_id','world_sha256','current_input_sha256','message_sha256']:assert record[name]==c[name]
                ids=tokenizer.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False)
                assert ids==record['prompt_ids']
                generated=record['generated_ids'];assert 0<len(generated)<=protocol['max_new_tokens']
                assert tokenizer.decode(generated,skip_special_tokens=True)==record['raw_text']
                assert tokenizer.decode(generated,skip_special_tokens=False)==record['full_decoded_text']
                selected=[returns[(arm,i)] for i in record['forward_sequences']]
                keys={(arm,i) for i in record['forward_sequences']}
                assert len(keys)==len(selected) and not keys.intersection(claimed_forwards);claimed_forwards.update(keys)
                assert len(selected)==len(generated) and generated==[e['greedy_argmax_token_id'] for e in selected]
                assert all(e['phase']=='generation' and e['observation_id']==c['observation_id'] for e in selected)
                a=attempts[(arm,record['forward_sequences'][0])];assert a['input_ids']==ids
                for pos,e in enumerate(selected[1:],1):
                    actual=attempts[(arm,e['sequence'])]['input_ids']
                    assert actual==[generated[pos-1]] or actual==ids+generated[:pos]
                parsed=parse_response(record['raw_text'],c['selected_same_information_input'])
                row={'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],'split':c['split'],
                  'initial_UV':c['selected_same_information_input']['current_global_metrics']['uv_count'],
                  'response_status':'returned','parsed':parsed,'outcome':measure(c,parsed,targets.get(c['observation_id'])),
                  'generated_tokens':len(generated),'generation_seconds':record['generation_seconds_includes_instrumentation']}
            by_case[key]=row;arm_rows.append(row)
        initial=[e for e in returns.values() if e['arm']==arm and e['phase']=='engineering_initial_prefill']
        cold=[e for e in returns.values() if e['arm']==arm+'_cold' and e['phase']=='engineering_cold_prefill']
        cold_known=False
        if initial and cold:
            assert len(initial)==len(cold)==1 and initial[0]['observation_id']==cold[0]['observation_id']==protocol['engineering_context_observation_id']
            with np.load(study/initial[0]['logits_file']) as a,np.load(study/cold[0]['logits_file']) as b:assert np.array_equal(a['logits'],b['logits'])
            gates=read(study/arm/'Final_Model_Gates.json');assert gates['all_original_public_tensors_unchanged'] and gates['cold_state_equals_initial'] and gates['cold_full_context_last_logits_exact']
            initial_gates=read(study/arm/'Initial_Model_Gates.json')
            assert initial_gates['before_state']==gates['after_state']==gates['cold_loaded_state']
            cold_known=True
        counts=collections.Counter(r['outcome']['outcome_status'] for r in arm_rows)
        results[arm]={'all31_rows':arm_rows,'outcome_counts':dict(counts),'genuine_cold_gate_verified':cold_known,
           'finite_world_denominator':31,'original_invalid_world_denominator':1,'total_declared_world_denominator':32}
    pairs=[];control_rows=[]
    for c in cases:
        left=by_case[('public_1_5B',c['observation_id'])]['outcome'];right=by_case[('public_0_5B',c['observation_id'])]['outcome']
        pairs.append({'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],'larger_vs_smaller':compare_known_pair(left,right)})
        for method,items in controls['methods'].items():
            ref=next(r for r in items if r['observation_id']==c['observation_id']);assert ref['world_sha256']==c['world_sha256']
            if ref['action_pair'] is None:outcome={'physical_outcome_known':False,'outcome_status':ref['status']}
            else:
                text=json.dumps({'bus':ref['action_pair'][0],'Q_index':ref['action_pair'][1]})
                parsed=parse_response(text,c['selected_same_information_input']);assert parsed['kind']=='command'
                outcome=measure(c,parsed,targets.get(c['observation_id']))
            control_rows.append({'method':method,'observation_id':c['observation_id'],'reference':ref,'outcome':outcome,
                'larger_vs_reference':compare_known_pair(left,outcome) if ref['ranking_complete'] else 'unknown_incomplete_reference_rank'})
    final=read(study/'Final_Status.json') if (study/'Final_Status.json').is_file() else None
    complete=bool(final and final['complete'] and len(generation_returns)==62 and len(generation_attempts)==62 and all(r['genuine_cold_gate_verified'] for r in results.values()))
    if complete:
        expected={(arm,c['observation_id']) for arm in protocol['ordered_arms'] for c in cases}
        assert set(generation_returns)==set(generation_attempts)==expected
        assert len(attempts)==len(returns) and len([e for e in returns.values() if e['phase'].startswith('engineering_')])==4
        assert claimed_forwards=={k for k,e in returns.items() if e['phase']=='generation'}
        assert final['optimizer_steps']==final['PF_calls']==0
    costs={'forward_attempts_lower_bound':len(attempts),'forward_returns_lower_bound':len(returns),
       'generation_attempts':len(generation_attempts),'generation_returns':len(generation_returns),
       'actual_input_tokens_returned':sum(e['input_tokens'] for e in returns.values()),
       'forward_wall_seconds_sum':sum(e['model_wall_seconds'] for e in returns.values()),
       'forward_wall_excludes_artifact_copy_but_includes_pre_hook_journal_overhead':True,
       'generation_wall_includes_nested_forward_instrumentation_do_not_sum_twice':True,
       'environment_setup':read(EX/'staged/public_size_setup_exit.json'),
       'complete_science_workflow_seconds':final['science_workflow_seconds'] if final else None,
       'owner_started_at_utc':status['started_at_utc'],'owner_finished_at_utc':status['finished_at_utc'],
       'all_transfer_attempts':read(EX/'Transfer_Costs.json'),
       'prior_numerical_and_physical_costs':controls['prior_paid_costs'],'prior_costs_not_free':True,
       'inflight_and_unobserved_costs_UNKNOWN_if_partial':not complete}
    decision={'complete_engineering_and_paired_response_study':complete,'development_only':True,
       'paired_counts':dict(collections.Counter(x['larger_vs_smaller'] for x in pairs)),
       'missing_unmeasured_malformed_abstention_failures_retained':True,
       'this_is_not_a_training_or_superiority_gate':True,'no_automatic_training_or_full_physical_campaign':True,
       'full_DSE_both_branches_matched_trajectories_and_unused_confirmation_still_required':True,
       'goal_achieved':False}
    write(OUT/'All_Actual_Paired_And_Control_Results.json',{'models':results,'pairs':pairs,'numerical_controls':control_rows,'fixed_missing_and_invalid':read(PREP/'denominators.json')})
    write(OUT/'Actual_Compute_And_Preservation.json',costs);write(OUT/'Prospective_Diagnostic_Decision.json',decision)
    write(OUT/'Independent_Actual_Output_Audit.json',{'all_closed_member_hashes_and_saved_greedy_logits_verified':True,
      'actual_complete_study':complete,'actual_attempts':len(attempts),'actual_returns':len(returns),
      'zero_new_model_PF_solver_calls':True,'seconds_before_seal':time.perf_counter()-started})
    write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
    (OUT/'Results.md').write_text('Fixed public0.5B/1.5B development diagnostic.\n\n'+json.dumps(decision,indent=2)+
      '\n\nAll31 finite worlds plus the original invalid world remain. Existing measured one-step targets are reused, with no new physics. Unknown outcomes are not ties or losses. Numerical controls have stronger full-table information; public sizes share identical partial prompts. Recipe, architecture, precision/FLOP and original-private-adapter differences remain. This does not establish learning value, full protected trajectories or original D-SE superiority.\n',encoding='utf-8')
    files={p.name:p for p in OUT.iterdir() if p.is_file()};files['sources/external_reader.py']=Path(__file__)
    archive=seal(OUT,files,'Independent_Public_Size_Diagnostic_Audit.zip')
    print(json.dumps({'decision':decision,'archive':archive}))
if __name__=='__main__':main()
