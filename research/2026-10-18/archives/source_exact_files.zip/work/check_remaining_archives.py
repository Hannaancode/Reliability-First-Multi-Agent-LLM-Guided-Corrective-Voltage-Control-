from pathlib import Path
import json,zipfile,subprocess,shutil
inv=json.loads(Path('outputs/actual_experiment_inventory.json').read_text())
print('base-weight candidates in inventoried ZIPs')
for a in inv['archives']:
 hits=[e for e in a.get('entries',[]) if any(t in e['path'].lower() for t in ['model.safetensors','pytorch_model.bin','config.json']) and 'adapter_model' not in e['path'].lower()]
 if hits:print(a['path'],hits[:20])
errors=[]
for a in inv['archives']:
 if a.get('error'):
  try:
   with zipfile.ZipFile(a['path']) as z:print('retry readable',a['path'],len(z.infolist()))
  except Exception as e:errors.append({'path':a['path'],'error':str(e),'winerror':getattr(e,'winerror',None)});print(errors[-1])
rarpaths=[Path(x['path']) for x in inv['files'] if x['path'].lower().endswith('.rar')]
rarpaths.append(Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm.rar'))
for p in rarpaths:
 if not p.exists():continue
 print('RAR',str(p),'bytes',p.stat().st_size)
 try:
  proc=subprocess.run(['tar.exe','-tf',str(p)],capture_output=True,text=True,timeout=60)
  names=proc.stdout.splitlines();print('tar status',proc.returncode,'entries',len(names),'stderr',proc.stderr[:300])
  Path('work/'+('desktop_rar' if p.parent.name=='Desktop' else 'inner_rar')+'_entries.txt').write_text(proc.stdout)
  print('relevant entries',[n for n in names if any(s in n.lower() for s in ['safetensors','pytorch_model','snapshot','ipynb','resume_pack'])][:30])
 except Exception as e:print(type(e).__name__,str(e))
Path('outputs/remaining_archive_status.json').write_text(json.dumps(errors,indent=2))
