"""Receding-policy software and actual paid-state cold-storage engineering.

Four existing paid first moves and their independently checked replay evidence
are reused. No new PF/model/derivative/solve or performance episode is run.
"""
import argparse,copy,hashlib,json,os,pickle,random,subprocess,sys,time
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
from receding_paid_lookahead_controller_v1 import run
from paid_receding_commit_and_history_v1 import (initialize,validate,commit_paid,save_complete,restore_complete,
    fields,fingerprint,History,HISTORY_KEY,SOURCE_CERTIFICATE,verify_history)
from bounded_paid_lookahead_physics_20261014 import load_after
from compile_lookahead_paid_input_cache_20261014 import point_key
from joint_reallocation_opportunity_core_v1 import load_endpoint,build_verifier
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks

R=Path(__file__).resolve().parents[1];B=R/'outputs/receding_controller_cold_engineering_20261014'
PAID=R/'outputs/bounded_paid_lookahead_physics_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def state_hash(value):return hashlib.sha256(pickle.dumps(value,protocol=5)).hexdigest()
def no_science():
    def blocked(*a,**k):raise AssertionError('Cold/controller engineering forbids new scientific calls')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,blocked)
def prepare():
    B.mkdir(exist_ok=False)
    prior=read(PAID/'verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json')
    assert prior['fixed_opportunity_gate']=='PASS' and prior['strict_UV_wins']==2
    names=[Path(__file__),R/'work/receding_paid_lookahead_controller_v1.py',R/'work/paid_receding_commit_and_history_v1.py',
        R/'work/paid_joint_commit_v1.py',PAID/'Protocol.json',PAID/'verified_handoff/Verified_Bounded_Lookahead_Checkpoint.json',
        PAID/'audit_cached_receipts_v2/Independent_Bounded_Paid_Lookahead_Audit.json',OLD/'preparation/Protocol.json']
    names += [PAID/'actual'/f'Branch_{i}.json' for i in [2,4,6,8]]
    for e in read(OLD/'preparation/Protocol.json')['current_endpoints']:
        ep=R/e['endpoint_record'];record=read(ep);names += [ep,R/e['decoded_net_container_root']/record['endpoint']['path']]
    put(B/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),
        'question':'Can complete first-only receding state/query history/caps/stock/absolute bound/RNG survive genuine cold process restoration?',
        'all4_existing_paid_fixture_worlds':read(PAID/'Protocol.json')['all_four_worlds'],
        'source_input_sha256':{str(p.relative_to(R)):sha(p) for p in names},
        'original_commit_AST_mode_certificate':SOURCE_CERTIFICATE,'resource_bound_seconds':600.,
        'history_byte_bound':128*1024**2,'history_semantics':'Full paid query/plan/cost records in hashed durable prefix. Checkpoint preserves exact anchor and committed receipts. Future suffix is hidden on restore; missing/stale/tampered prefixes abort.',
        'engineering_only':'All4 selected breadth FIRST moves reused from actual prior measured/replayed paths, no old outcome selected away. New logical engineering commitments, not fresh physical performance or deployment.',
        'new_PF_model_optimizer_derivative_forecast_solve_calls':0,'no_automatic_fullpolicy_or_LLM_launch':True})
    print(json.dumps({'prepared_complete_controller_cold_engineering':True,'new_science_calls':0}))
def pins():
    p=read(B/'Protocol.json')
    for name,digest in p['source_input_sha256'].items():assert sha(R/name)==digest,name
    return p
def synthetic_checks():
    checks=[]
    def m(uv):return {'uv_count':uv,'deficit_sum':float(uv),'vmin':.95 if not uv else .94,'vmax':1.04}
    cursor={'original_device_operation_budget':25,'remaining_original_device_operation_slots':4}
    seen=[];commits=[];saved=[]
    def search(net,c,mode):
        seen.append(net)
        return {'status':'complete_declared_bounded_horizon','selected':{'first':f'first{net}',
            'first_successor':f'state{net+1}','second':f'future{net}','measured_leaf':m(0)}}
    def commit(net,c,proposal):
        c=copy.deepcopy(c);c['remaining_original_device_operation_slots']-=2
        record={'device_operations_debited':2,'first_action_id':proposal['selected']['first'],
            'paid_successor_id':proposal['selected']['first_successor']};commits.append(record)
        return net+1,c,record
    end,cur,result=run(0,cursor,mode='breadth4_followup4',observe=lambda net:m(2-net),search=search,commit=commit,
        checkpoint=lambda n,c,s:saved.append((n,copy.deepcopy(c),s)),event=lambda *a:None,admit=lambda:None)
    assert seen==[0,1] and end==2 and result['final_metrics']['uv_count']==0;checks.append('SYNTHETIC_REPLAN_AFTER_FIRST_ONLY')
    assert len(commits)==len(saved)==2 and all('first' in r['first_action_id'] for r in commits);checks.append('SYNTHETIC_SECOND_HYPOTHESIS_NEVER_AUTOCOMMITTED')
    assert cur['remaining_original_device_operation_slots']==0 and result['new_device_operations']==4;checks.append('SYNTHETIC_EXACT_1OR2_DEVICE_DEBITS')
    assert all(s[2]['lookahead_second_is_not_automatically_committed'] for s in saved);checks.append('SYNTHETIC_CHECKPOINT_RECEDING_PHASE')
    from operation_aware_paid_lookahead_v1 import MissingEvidence
    def bad(net,c,proposal):
        after,c,record=commit(net,c,proposal);record['paid_successor_id']='unqueried_future';return after,c,record
    try:run(0,cursor,mode='breadth4_followup4',observe=lambda n:m(2-n),search=search,commit=bad,
        checkpoint=lambda *a:None,event=lambda *a:None,admit=lambda:None);raise AssertionError('Wrong successor allowed')
    except MissingEvidence:checks.append('SYNTHETIC_WRONG_SUCCESSOR_ABORTS')
    return checks
def cold(index):
    no_science();p=pins();request=read(B/'actual'/f'Cold_Request_{index}.json')
    out=B/'cold'/str(index);out.mkdir(parents=True,exist_ok=False)
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'source_sha256':sha(Path(__file__))})
    state,history=restore_complete(R/request['checkpoint'],request['receipt'])
    random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
    assert state['absolute_deadline_utc']==request['absolute_deadline_utc'] and datetime.now(timezone.utc)<datetime.fromisoformat(state['absolute_deadline_utc'])
    assert point_key(state['net'],state['cursor'])==request['actual_point_key']
    assert fingerprint(state['net'],state['cursor'])==request['receipt']['state_fingerprint']
    assert fields(state['net'])==request['fields'] and state['next_phase']==request['next_phase']
    assert state_hash(random.getstate())==request['python_rng_sha256'] and state_hash(np.random.get_state())==request['numpy_rng_sha256']
    assert len(history)==request['history_records'] and history[-1]['event']=='engineering_first_commit'
    assert state['paid_query_registry'][HISTORY_KEY]==request['history_anchor']
    assert len(state['cursor']['committed_transitions'])==1
    put(out/'Result.json',{'exit_code':0,'status':'PASS_ACTUAL_COLD_NET_MASK_CURSOR_STOCK_CAP_HISTORY_PREFIX_RNG_DEADLINE_AND_NEXT_PHASE',
        'history_records':len(history),'physical_source_point_key':request['actual_point_key'],
        'committed_receipt_id':state['cursor']['committed_transitions'][0]['paid_receipt_id'],'new_scientific_calls':0})
    print(json.dumps({'cold_root':index,'PASS':True,'new_science_calls':0}))
def worker():
    no_science();p=pins();out=B/'actual';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,'source_sha256':sha(Path(__file__))})
    checks=synthetic_checks();_,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    entries=read(OLD/'preparation/Protocol.json')['current_endpoints'];records=[]
    deadline=(datetime.now(timezone.utc)+timedelta(seconds=p['resource_bound_seconds'])).isoformat()
    with (PAID/'actual/capsules.bin').open('rb') as pack:
        for i,e in enumerate(entries,1):
            assert time.perf_counter()-start<p['resource_bound_seconds']
            branch=read(PAID/'actual'/f'Branch_{2*i}.json');assert branch['world']==e['world'] and branch['method']=='breadth4_followup4'
            selected=branch['plan']['selected'];source=next(m for m in branch['query_messages'] if m['parent']==branch['root'] and m['aid']==selected['first'])
            before,original_cursor,rng=load_endpoint(e);domain=build_current_domain(before,original_cursor,runner=runner,zones=zones)
            cursor=initialize(before,domain['expanded_cursor_for_separately_fixed_future_protocol'])
            target=load_after(source['record']['after_reference'],pack)['net'];row=source['row']
            _,actuate,_=build_verifier(runner.rescue,cursor)
            receipt={'receipt_id':source['record']['receipt_id'],'accepted':True,'converged':True,
                'fields':fields(target),'before_fingerprint':fingerprint(before,cursor)}
            next_scope=build_current_domain(target,cursor,runner=runner,zones=zones)['shared_raw_receivers_for_BOTH_controls']
            current=commit_paid(before,target,cursor,row,receipt,commit_id=f'COLD_ENGINEERING_ROOT{i}_FIRST',actuate=actuate,next_scope=next_scope)
            history=History(out/f'Root{i}_Complete_Query_History.bin',source_anchor=sha(Path(__file__)),
                input_anchor=p['source_input_sha256'][str((R/e['endpoint_record']).relative_to(R))],max_bytes=p['history_byte_bound'])
            history.append('reused_complete_paid_search_receipts',{'world':e['world'],'root':branch['root'],
                'menus':branch['menus'],'query_messages':branch['query_messages'],'attributed_costs':branch['attributed_costs'],
                'source_branch_sha256':sha(PAID/'actual'/f'Branch_{2*i}.json')})
            history.append('engineering_first_commit',{'candidate':row,'receipt':receipt,'new_controller_cursor':current,
                'not_a_new_physics_or_performance_result':True})
            anchor=history.anchor();registry={source['record']['receipt_id']:source['record'],HISTORY_KEY:anchor}
            phase={'world':e['world'],'mode':'breadth4_followup4','decision':1,'phase':'REPLAN_FROM_ACTUAL_COMMITTED_FIRST_SUCCESSOR',
                'second_hypothesis_not_committed':True}
            random.setstate(rng['python_rng']);np.random.set_state(rng['numpy_rng'])
            state={'net':target,'cursor':current,'paid_query_registry':registry,'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),
                'costs':{'reused_paid_full_search_costs':branch['attributed_costs'],'new_PF_model_optimizer_derivative_solve_calls':0},
                'absolute_deadline_utc':deadline,'protocol_sha256':sha(B/'Protocol.json'),'next_phase':phase}
            anchors={'source':sha(Path(__file__)),'input':history.input_anchor,'paid_receipt':anchor['sha256'],'predecessor':'0'*64}
            path=out/f'Root{i}_Complete_Controller_Checkpoint';saved=save_complete(path,state,anchors)
            warm,seen=restore_complete(path,saved);assert len(seen)==2 and warm['paid_query_registry']==registry
            # Appending later data must not expose it through an older checkpoint.
            history.append('future_not_in_saved_prefix',{'must_not_appear_in_cold_restore':True});history.close()
            _,limited=restore_complete(path,saved);assert len(limited)==2;checks.append(f'ROOT{i}_LATER_HISTORY_SUFFIX_HIDDEN')
            for field,wrong in [('sha256','f'*64),('source_anchor','e'*64),('input_anchor','d'*64)]:
                invalid=copy.deepcopy(anchor);invalid[field]=wrong
                try:verify_history(invalid);raise AssertionError('Bad prefix accepted')
                except ValueError:checks.append(f'ROOT{i}_BAD_{field.upper()}_REJECTED')
            request={'checkpoint':str(path.relative_to(R)),'receipt':saved,'history_anchor':anchor,'history_records':2,
                'absolute_deadline_utc':deadline,'actual_point_key':point_key(target,current),'fields':fields(target),'next_phase':phase,
                'python_rng_sha256':state_hash(state['python_rng']),'numpy_rng_sha256':state_hash(state['numpy_rng'])}
            put(out/f'Cold_Request_{i}.json',request)
            log_path=B/f'cold_root{i}_console.log'
            with log_path.open('x',encoding='utf-8') as log:
                process=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold',str(i)],
                    stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);code=process.wait()
            assert code==0,log_path
            result=read(B/'cold'/str(i)/'Result.json');assert result['exit_code']==0
            records.append({'world':e['world'],'old_paid_first_action':row,'new_engineering_operation_debit':1 if row['kind']=='ordinary' else 2,
                'checkpoint':str(path.relative_to(R)),'cold_result':str((B/'cold'/str(i)/'Result.json').relative_to(R)),
                'cold_checks':'PASS','new_scientific_calls':0})
    put(out/'Result.json',{'exit_code':0,'status':'PASS_RECEDING_SOFTWARE_AND_ALL4_ACTUAL_PAID_FIRST_COMMIT_COLD_CHECKPOINTS',
        'software_checks':checks,'actual4_input_records':records,'elapsed_seconds':time.perf_counter()-start,
        'new_engineering_logical_first_commits':4,'new_PF_model_optimizer_derivative_forecast_solve_calls':0,
        'scientific_policy_outcomes':'NOT_MEASURED','no_automatic_performance_or_LLM_launch':True})
    put(out/'Closed_Manifest.json',{'members':{str(f.relative_to(out)):sha(f) for f in out.rglob('*') if f.is_file()}})
    print(json.dumps({'all4_real_paid_state_cold_restores':'PASS','software_checks':len(checks),'new_scientific_calls':0}))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--worker',action='store_true');a.add_argument('--cold',type=int);x=a.parse_args()
    assert sum([bool(x.prepare),bool(x.worker),x.cold is not None])==1
    if x.prepare:prepare()
    elif x.worker:worker()
    else:cold(x.cold)
