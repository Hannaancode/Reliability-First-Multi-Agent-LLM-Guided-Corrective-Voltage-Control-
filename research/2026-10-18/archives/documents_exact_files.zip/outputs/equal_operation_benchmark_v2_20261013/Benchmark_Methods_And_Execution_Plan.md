# Benchmark direction and execution plan

Saved 2026-10-13T17:47:18.386500+00:00. OverallLLMadvantage remains unproven; existinggoal lifecycleusageLimited is not changed. This is a new bounded task directly requested by the human.

The first test removes the main action-budget confound in the positive reallocation result. It compares two ordinary positive-support actions against one equal-support transfer charged as two device operations. Allfourpreviously inspected severe states stay in the denominator. No originalrootphysics is rerun: the already measured first/joint receipts are reused with paidcosts; only new followingstatequeries and declared selected-action replay are executed.

| Method | Current benchmark status | Meaning |
|---|---|---|
| Complete protected ordinary greedy2 | RUNNING | All native positive second-actions examined after best measured ordinary first-action; two-operation allowance. DFF-style development control, not a whole literalDFF trajectory. |
| Lowest-voltage ordinary greedy2 | RUNNING | Secondary simple control; originalQgrid and guard, two-operation allowance. It is not sufficient as the main comparator. |
| One complete owned reallocation | Paid original results reused | Source-owned withdrawal+positiveaddition, two charged operations. All actual root-search costs retained. |
| Original DFF | Wholepolicy benchmark not launched | Exact original fallback-first source/iteration/action/cap/solver behaviour; preserve alreadycompleted runs. |
| Original DFF-ALT | Wholepolicy benchmark not launched | Exact alternative-firstaction branch; no weaker or shorter substitute. |
| Original D-SE | Wholepolicy benchmark not launched | Unchanged selector after both complete branches; FULL BOTH branch costs, plus all preparation/failures. |
| Current Jacobian admission-first search | Saved currentstate ordering complete; trajectory untested | Sameinformation, all native actions retained; prediction never substitutes for nonlinear physical verification. |
| Numerical method allowed the same relocation hardware | Prospective fullpolicy specification needed | Essential control before assigning any improvement to theLLM rather than expanded actuation. |
| AdaptedLLM + same planner | Not ready for performance | Exact serving/format binding and matched controls required; unadapted7B screen remainsSTOPPED. No sign/prompt primary repair or training from fit. |
| AC/optimization reference | Existing voltage-only diagnostics retained | Not certified fullfeasibility/optimality; a true ACOPF benchmark needs separately fixed device/objective/constraints and observed solver status. |

Primary measurements: finalUVcount; deficit/min/max voltage; raw and tolerance-aware protection; completed operation count and cumulativepositive450cap; successful/failed/reused solvercalls; actualsolver time; preparation/preservation/audit costs. A quality gain with morequeries must be labelled that way. No cached or imputed deploymentlatency advantage.

The two-operation screen is not globaltwo-action optimization: its firstordinary action is the frozen completegreedy choice. Joint success here does not prove superiority over nonmyopicMPC, complete25-operationDFF/DSE, everyhardware-feasible solution or anLLM contribution.

Fixed developmentgate: at leasttwo strictjointUVwins andzeroUVlosses against completeordinarygreedy2, with allsource/protection/replay/auditchecks passing. Failed measuredgate stops this specific claim; incompletegate staysUNKNOWN. Fullpublishable superiority still requires prospectively fixed matchedcomplete trajectories, strong same-actuation controls, fullcosts and genuinely unusedconfirmation. No90%winning-confidence claim.
