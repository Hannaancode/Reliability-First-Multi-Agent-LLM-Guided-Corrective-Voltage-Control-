"""Bounded no-tool public QA worker. Host allocation/collection is separate.

No administrator labels, private adapter, retrieval, optimizer or solver is used.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, random, sys, time, traceback

def digest(b):
    return hashlib.sha256(b).hexdigest()

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def atomic(path, value):
    data = canonical(value)
    assert not path.exists(), str(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('xb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    tmp.replace(path)

class Ledger:
    def __init__(self, path):
        self.path, self.previous, self.count = path, '0' * 64, 0
        assert not path.exists()
    def add(self, kind, **values):
        row = {'index': self.count, 'previous': self.previous, 'kind': kind, **values}
        row['sha256'] = digest(canonical(row))
        with self.path.open('ab') as f:
            f.write(canonical(row) + b'\n'); f.flush(); os.fsync(f.fileno())
        self.previous = row['sha256']; self.count += 1

class TorchBackend:
    def __init__(self, assignment, output):
        # All package/model initialization is after durable claim creation.
        os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
        import torch, transformers, numpy as np
        from huggingface_hub import snapshot_download
        from transformers import AutoModelForCausalLM, AutoTokenizer
        assert transformers.__version__ == assignment['transformers_version']
        assert torch.cuda.is_available() and 'T4' in torch.cuda.get_device_name(0)
        torch.use_deterministic_algorithms(True)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.manual_seed(assignment['seed']); random.seed(assignment['seed']); np.random.seed(assignment['seed'])
        self.torch, self.np, self.assignment = torch, np, assignment
        self.path = Path(snapshot_download(repo_id=assignment['model'], revision=assignment['revision'],
            allow_patterns=['*.safetensors', '*.json', 'merges.txt', 'vocab.json', 'LICENSE']))
        assert self.path.name == assignment['revision']
        self.files = {}
        for p in sorted(self.path.iterdir()):
            if p.is_file():
                with p.open('rb') as f: self.files[p.name] = hashlib.file_digest(f, 'sha256').hexdigest()
        assert any(n.endswith('.safetensors') for n in self.files)
        os.environ['HF_HUB_OFFLINE'] = '1'
        self.tokenizer = AutoTokenizer.from_pretrained(self.path, local_files_only=True, trust_remote_code=False)
        self.loader = AutoModelForCausalLM
        self.load()
        atomic(output / 'Actual_Integration.json', {'model': assignment['model'], 'revision': assignment['revision'],
            'torch': torch.__version__, 'transformers': transformers.__version__, 'device': torch.cuda.get_device_name(0),
            'dtype': 'float16', 'attention': 'eager', 'snapshot_files': self.files, 'private_adapter_loaded': False})
    def load(self):
        self.model = self.loader.from_pretrained(self.path, local_files_only=True, trust_remote_code=False,
            dtype=self.torch.float16, attn_implementation='eager').to('cuda').eval()
        assert not self.model.training
    def reload(self):
        import gc
        del self.model; gc.collect(); self.torch.cuda.empty_cache(); self.load()
    def seed(self):
        self.torch.manual_seed(self.assignment['seed']); random.seed(self.assignment['seed']); self.np.random.seed(self.assignment['seed'])
    def verify_input(self, row):
        ids = self.tokenizer(row['rendered_prefix'], add_special_tokens=False)['input_ids']
        assert ids == row['input_ids'] and len(ids) + 256 <= 4096
    def synthetic_ids(self, longest):
        # No test item used for disposable warm/cold generation.
        text = 'Reply with only A. Context padding: ' + ('context ' * (longest + 32))
        ids = self.tokenizer.apply_chat_template([{'role': 'user', 'content': text}], tokenize=True,
            add_generation_prompt=True, return_dict=False)
        assert longest <= len(ids) and len(ids) + 4 <= 4096
        return ids
    def capture(self, path):
        state = {'torch_cpu': self.torch.get_rng_state(), 'torch_cuda': self.torch.cuda.get_rng_state_all(),
                 'python': random.getstate(), 'numpy': self.np.random.get_state()}
        assert not path.exists()
        self.torch.save(state, path)
        with path.open('rb') as f: os.fsync(f.fileno())
        return digest(path.read_bytes())
    def generate(self, ids, bound):
        torch = self.torch
        x = torch.tensor([ids], dtype=torch.long, device='cuda')
        torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats(); start = time.monotonic()
        with torch.inference_mode():
            y = self.model.generate(input_ids=x, attention_mask=torch.ones_like(x), do_sample=False,
                num_beams=1, max_new_tokens=bound, pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id, use_cache=True)
        torch.cuda.synchronize()
        new = y[0, len(ids):].detach().cpu().tolist()
        return {'new_token_ids': new, 'raw_text': self.tokenizer.decode(new, skip_special_tokens=True,
            clean_up_tokenization_spaces=False), 'elapsed_seconds': time.monotonic() - start,
            'peak_allocated_bytes': torch.cuda.max_memory_allocated(), 'peak_reserved_bytes': torch.cuda.max_memory_reserved()}

def run(assignment, pack, output, backend_factory=TorchBackend):
    assert not output.exists(), 'No restart or overwrite of a prior assignment.'
    output.mkdir(parents=True)
    atomic(output / 'owner.claim', {'pid': os.getpid(), 'parent_pid': os.getppid(), 'command': sys.argv,
        'source_sha256': digest(Path(__file__).read_bytes()), 'assignment_sha256': digest(canonical(assignment)),
        'started_at_utc': datetime.now(timezone.utc).isoformat()})
    ledger = Ledger(output / 'journal.jsonl')
    records = pack['questions']; assert len(records) == assignment['records'] == 150
    assert pack['model'] == assignment['model'] and pack['revision'] == assignment['revision']
    assert len({x['question_id'] for x in records}) == 150
    for row in records:
        assert set(row) == {'question_id', 'rendered_prefix', 'input_ids', 'input_tokens'}
        assert row['input_tokens'] == len(row['input_ids']) and len(row['input_ids']) + 256 <= 4096
    completed = []; attempted = []; entered = time.monotonic(); science_start = None
    try:
        ledger.add('setup_attempt')
        backend = backend_factory(assignment, output)
        for row in records: backend.verify_input(row)
        assert time.monotonic() - entered <= assignment['setup_seconds']
        synthetic = backend.synthetic_ids(max(len(x['input_ids']) for x in records))
        backend.seed(); ledger.add('engineering_warm_attempt', input_tokens=len(synthetic))
        warm = backend.generate(synthetic, 4); atomic(output / 'Engineering_Warm.json', warm)
        ledger.add('engineering_warm_return')
        backend.reload(); backend.seed(); ledger.add('engineering_cold_attempt', input_tokens=len(synthetic))
        cold = backend.generate(synthetic, 4); atomic(output / 'Engineering_Cold.json', cold)
        ledger.add('engineering_cold_return')
        assert warm['new_token_ids'] == cold['new_token_ids'] and warm['raw_text'] == cold['raw_text']
        assert time.monotonic() - entered <= assignment['setup_seconds']
        # Fresh scientific RNG after disposable engineering; inference weights never trained.
        backend.seed(); science_start = time.monotonic(); ledger.add('science_start')
        for ordinal, row in enumerate(records):
            if time.monotonic() - science_start >= assignment['science_seconds']:
                ledger.add('absolute_science_bound_stop', next_ordinal=ordinal); break
            qid = row['question_id']
            rng_path = output / f'pre_rng_{ordinal:03}.pt'
            state_hash = backend.capture(rng_path)
            ledger.add('generation_attempt', ordinal=ordinal, question_id=qid, input_sha256=digest(canonical(row['input_ids'])), rng_sha256=state_hash)
            attempted.append(qid)
            value = backend.generate(row['input_ids'], 256)
            atomic(output / f'output_{ordinal:03}.json', {'ordinal': ordinal, 'question_id': qid, **value})
            completed.append(qid)
            ledger.add('generation_return', ordinal=ordinal, question_id=qid, output_sha256=digest((output / f'output_{ordinal:03}.json').read_bytes()))
        status = 'COMPLETE' if len(completed) == 150 else 'TERMINAL_PARTIAL'
    except Exception:
        status = 'TERMINAL_PARTIAL'
        atomic(output / 'Failure.json', {'traceback': traceback.format_exc(), 'completed': completed, 'attempted': attempted})
        ledger.add('failure_preserved')
    result = {'status': status, 'completed': completed, 'attempted': attempted,
        'unexecuted': [x['question_id'] for x in records if x['question_id'] not in attempted],
        'attempted_without_return': [x for x in attempted if x not in completed],
        'wall_seconds': time.monotonic() - entered,
        'science_seconds': None if science_start is None else time.monotonic() - science_start,
        'engineering_expected_max_generations': 2, 'journal_events': ledger.count, 'journal_tail': ledger.previous,
        'accuracy': 'NOT_COMPUTED_LABELS_ABSENT', 'new_PF_OPF_optimizer_calls': 0}
    atomic(output / 'Result.json', result)
    files = {p.name: {'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())} for p in output.iterdir() if p.is_file()}
    atomic(output / 'Closed_Manifest.json', {'status': 'CLOSED', 'files': files})
    return result

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--assignment', required=True); p.add_argument('--pack', required=True); p.add_argument('--output', required=True)
    args = p.parse_args()
    run(json.loads(Path(args.assignment).read_text()), json.loads(Path(args.pack).read_text()), Path(args.output))
