"""Sole complete-actual engineering reader; blocks all solver/model calls."""
import hashlib
import json
import math
import os
import pickle
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import pandapower as pp

from audit_spatial_allocation_inputs_v3_20261011 import signature
from candidate_process_evidence_utils import frozen_checks, seal
from frozen_physics_loader import load_stack, AUDIT
from native_continuation_preservation_v2 import canonical, extended_local_path
from native_postcommit_preservation import measured_bus_fields, check_commit
from paid_spatial_actual_controller_checkpoint_v1 import read_actual_controller_checkpoint
from paid_spatial_controller_checkpoint_v1 import process_alive, validate_chain
from paid_spatial_controller_checkpoint_v3 import validate_linkages
from trusted_causal_controller_snapshot import cap_totals, write_bytes

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'outputs/critical_research_reset_20261010/spatial_full_controller_engineering_20261012'
OUT = extended_local_path(BASE/'independent_audit_continuation_v2')
SHARED = extended_local_path(BASE/'query_state')
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False); begun = time.perf_counter()
    write_bytes(OUT/'reader.claim',canonical({'actual_pid':os.getpid(),'parent_pid':os.getppid(),
        'argv':sys.argv,'source_sha256':sha(Path(__file__)),'new_PF_model_calls':0}))
    p = read(BASE/'preparation/Protocol.json'); ph = sha(BASE/'preparation/Protocol.json'); qp = read(BASE/'Query_Protocol.json')
    control = read(BASE/'continuation_v2_preparation/Protocol.json')
    assert control['zero_original_cold_PF_proved'] and control['original_absolute_deadline_utc'] == qp['absolute_deadline_utc']
    for name,digest in control['source_sha256'].items(): assert sha(ROOT/name) == digest
    ownership = read(BASE/'Science_Ownership_And_Walltime_Continuation_v2.json')
    assert ownership['all_actual_phase_owners_ended_exit0'] and len(ownership['phases']) == 3
    for item in ownership['phases']:
        assert item['exit_code'] == 0 and not process_alive(item['actual_pid'])
        phase = item['phase']; folder = extended_local_path(BASE/(phase if phase == 'warm' else phase+'_continuation_v2'))
        claim = read(folder/'owner.claim'); ack = read(folder/'Launcher_ACK.json'); closed = read(folder/'Closed_Manifest.json')
        assert claim['actual_pid'] == ack['actual_pid'] == item['actual_pid'] and ack['exact_PID_parent_command_verified']
        assert '--phase '+phase in ack['fresh_CIM_identity']['CommandLine']
        assert ('run_spatial_full_controller_engineering_20261012.py' if phase == 'warm' else 'run_spatial_full_controller_continuation_v2_20261012.py') in ack['fresh_CIM_identity']['CommandLine']
        assert closed['exit_code'] == 0
        for name, info in closed['members'].items():
            assert sha(folder/name) == info['sha256'] and (folder/name).stat().st_size == info['bytes']
    for name, digest in p['source_sha256'].items():
        assert sha(ROOT/name) == digest
    assert sha(ROOT/p['network_path']) == p['network_sha256'] and sha(ROOT/p['metadata_path']) == p['metadata_sha256']
    warm = read(BASE/'warm/Result.json'); cold = read(BASE/'cold_continuation_v2/Result.json'); replay = read(BASE/'replay_continuation_v2/Result.json')
    attempted = []
    def refused(*args,**kwargs):
        attempted.append(True); raise AssertionError('Mechanical reader cannot execute a solver')
    originals = {n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph')}
    for n in originals: setattr(pp,n,refused)
    try:
        _, runner, _ = load_stack(); assert all(a['all_function_asts_unchanged'] for a in AUDIT)
        zones = read(ROOT/p['metadata_path'])['zones']
        for phase in ('warm','replay_continuation_v2'):
            original = pickle.loads((BASE/phase/'Before_Initial_Input.pkl').read_bytes())
            assert signature(original) == (p['canonical_input_signature'],p['canonical_input_tables'])
        state, _ = read_actual_controller_checkpoint(cold['anchor'], expected_protocol=qp,
            expected_protocol_sha256=ph, expected_controller_identity=cold['controller'], expected_directory=SHARED)
        assert len(validate_linkages(state,SHARED)) == 1
        rows, _ = validate_chain(state['journal_bytes'],ph)
        def capsule(h):
            return pickle.loads((SHARED/state['handles'][h]['relative_path']/'trusted_local_state.pkl').read_bytes())['net']
        raw_by_key = {}
        for path in (SHARED/'queries').glob('*/Receipt.json'):
            raw = read(path); key = (raw['parent'],raw['action_id']); assert key not in raw_by_key
            raw_by_key[key] = raw
            parent = capsule(key[0]); before = runner.rescue.grid_metrics(parent)
            action = state['menus'][key[0]][key[1]]
            assert action == raw['action'] and runner.action_signature(action) == key[1]
            assert canonical(before) == canonical(raw['verification']['before'])
            if raw['solver_handles']:
                assert len(raw['solver_handles']) == 1
                net = capsule(raw['solver_handles'][0]); after = runner.rescue.grid_metrics(net)
                assert canonical(after) == canonical(raw['verification']['after'])
                native = (after['vmax'] <= runner.rescue.HARD_OV and after['uv_count'] <= before['uv_count'] and
                    after['deficit_sum'] <= before['deficit_sum']+1e-9 and
                    (after['uv_count'] < before['uv_count'] or after['deficit_sum'] < before['deficit_sum']-1e-9 or
                     after['vmin'] > before['vmin']+1e-9))
                assert raw['verification']['accepted'] == bool(native and after['vmax'] <= 1.05+1e-8)
                if raw['verification']['accepted']:
                    assert tuple(raw['original_score']) == tuple(runner.rescue.score_candidate({'action':action,'verif':raw['verification']}))
            else:
                assert raw['verification']['accepted'] is False
        assert len(raw_by_key) == state['counters_before_checkpoint']['new_queries'] == len(state['receipts'])
        for parent, actions in state['menus'].items():
            net = capsule(parent)
            reports = {z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
            buses = runner.rescue.candidate_buses_from_state(net,zones,reports,[])
            actual_menu = [runner.rescue.make_action(b,q) for b in buses for q in runner.rescue.Q_SWEEP]
            assert canonical(list(actions.values())) == canonical(actual_menu)
        history = cold['controller']['actual_action_history']; k = len(history)
        assert 0 <= k <= 25 and cold['controller']['remaining_slots'] == 25-k
        decisions = [r['payload'] for r in rows if r['event'] == 'complete_current_decision']
        assert len(decisions) in (k,k+1) or (k == 0 and len(decisions) == 2)
        for i, entry in enumerate(history,1):
            parent = entry['parent_handle']; menu = tuple(state['menus'][parent])
            paid = [state['receipts'][(parent,a)] for a in menu]
            admitted = [r for r in paid if r.accepted]
            assert admitted and max(admitted,key=lambda r:r.native_score).action == entry['selected_action_id']
            assert decisions[i-1]['parent'] == parent and decisions[i-1]['plan']['first'] == entry['selected_action_id']
            before = runner.rescue.grid_metrics(capsule(parent))
            check_commit(measured_bus_fields(capsule(entry['trial_successor'])),
                         measured_bus_fields(capsule(entry['committed_handle'])),before,cap_totals(capsule(entry['committed_handle'])))
        reason = cold['loop_result']['reason']; final = runner.rescue.grid_metrics(capsule(cold['controller']['current_handle']))
        assert cold['loop_result']['status'] == 'observed_terminal'
        if reason == 'full_restoration': assert final['uv_count'] == 0
        elif reason == 'max_iterations': assert k == 25
        else:
            assert reason == 'no_admitted_first_action' and decisions[-1]['plan']['first'] is None
        direct = cold['known_direct_costs']; query = cold['known_query_costs']
        assert direct == cold['controller']['direct_costs'] and direct['attempts'] == direct['returns'] == 1+k
        assert direct['initial_attempts'] == 1 and direct['commit_attempts'] == k and direct['exceptions'] == 0
        assert query['pf_attempts'] == query['pf_returns']+query['pf_exceptions']
        for key, event in [('attempts','actual_direct_PF_intent'),('returns','actual_direct_PF_return'),('exceptions','actual_direct_PF_exception')]:
            assert sum(r['event'] == event for r in rows) == direct[key]
        assert abs(sum(r['payload']['solver_seconds'] for r in rows if r['event'] in ('actual_direct_PF_return','actual_direct_PF_exception'))-
                   direct['pure_solver_seconds']) < 1e-8
        assert abs(sum(r['payload']['solver_seconds'] for r in rows if r['event'] in ('PF_return','PF_exception'))-
                   query['pf_seconds']) < 1e-8
        assert replay['replayed_commits'] == k and replay['charged_replay_costs']['attempts'] == replay['charged_replay_costs']['returns'] == 1+2*k
        assert replay['max_field_delta'] <= 1e-10 and replay['charged_replay_costs']['exceptions'] == 0
        assert canonical(replay['continuous_final_metrics']) == canonical(final)
        # All checkpoint bytes/direct artifacts are checked, not only final counts.
        checkpoint_count = 0
        for folder in (SHARED/'controller_checkpoints').iterdir():
            if not folder.is_dir(): continue
            manifest = read(folder/'Manifest.json')
            anchor = {'directory':str(folder),'payload_sha256':manifest['payload_sha256'],'manifest_sha256':sha(folder/'Manifest.json')}
            read_actual_controller_checkpoint(anchor,expected_protocol=qp,expected_protocol_sha256=ph,
                expected_controller_identity={},expected_directory=SHARED)
            checkpoint_count += 1
        assert checkpoint_count == k+2
        assert not attempted
    finally:
        for n, fn in originals.items(): setattr(pp,n,fn)
    result = {'audited_at_utc':datetime.now(timezone.utc).isoformat(), 'status':'PASS',
        'actual_full_controller_cold_integration':'PASS' if warm['controller']['actual_commit_count'] == 1 and k >= 1 else 'UNKNOWN_NONTRIVIAL_COMMIT_NOT_OBSERVED',
        'complete_observed_native_trajectory':True,'actual_commit_count':k,'terminal_reason':reason,
        'terminal_metrics':final,'actual_direct_costs':direct,'actual_query_costs':query,
        'charged_replay_costs':replay['charged_replay_costs'], 'complete_checkpoints_verified':checkpoint_count,
        'complete_storage_costs':cold['complete_storage_costs'],'continuous_max_field_delta':replay['max_field_delta'],
        'all_72_original_input_tables_native_menu_score_caps_common_upper_source_and_cold_cost_checks':True,
        'new_reader_PF_model_optimizer_calls':0,
        'new_total_PF_attempts':direct['attempts']+query['pf_attempts']+replay['charged_replay_costs']['attempts'],
        'whole_episode_DSE_comparator_or_LLM_superiority_established':False,
        'original_failed_cold_phase_and_coordinator_preserved':True,
        'original_failed_cold_setup_costs_additionally_paid':control['failed_cold_ownership'],
        'all_eight_development_opportunity_gate':'UNKNOWN; single fixed engineering arm is not the comparison campaign',
        'reader_seconds_before_certificates_and_archive':time.perf_counter()-begun}
    write_bytes(OUT/'Independent_Actual_Full_Controller_Audit.json',canonical(result))
    write_bytes(OUT/'Fresh_Frozen_Checks.json',canonical(frozen_checks()))
    files = {name:ROOT/name for name in {**p['source_sha256'],**control['source_sha256']}}
    for directory in ('preparation','warm','cold','cold_continuation_v2','replay_continuation_v2','query_state','continuation_v2_preparation'):
        for path in extended_local_path(BASE/directory).rglob('*'):
            if path.is_file(): files['actual/'+path.relative_to(extended_local_path(BASE)).as_posix()] = path
    for name in ('Actual_Launch.json','Query_Protocol.json','Cold_Handoff.json','Science_Ownership_And_Walltime_Continuation_v2.json'):
        files['actual/'+name] = BASE/name
    for name in ('owner_status.json','Coordinator_Failure.json','cold_Owner_Ended.json'):
        files['original_failed_provenance/'+name] = BASE/name
    files['Independent_Actual_Full_Controller_Audit.json'] = OUT/'Independent_Actual_Full_Controller_Audit.json'
    files['Fresh_Frozen_Checks.json'] = OUT/'Fresh_Frozen_Checks.json'
    archive = seal(OUT,files,'Actual_Full_Controller_Engineering.zip')
    write_bytes(OUT/'Completion.json',canonical({'status':'COMPLETE_AUDITED_ENGINEERING',
        'actual_reader_pid':os.getpid(),'finished_at_utc':datetime.now(timezone.utc).isoformat(),
        'reader_seconds_with_all_hash_archive_checks':time.perf_counter()-begun,'archive':archive,'new_reader_science_calls':0}))
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    main()
