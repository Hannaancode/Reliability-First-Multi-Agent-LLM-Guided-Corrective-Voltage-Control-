"""Only the previously unexecuted full-menu join tail; ZERO repeated science.

Original equation reader already PASSED. Preserve its later import failure;
bind action_key to its actual original module in a separate analysis output.
"""
import argparse,ast,copy,json,os,time
from pathlib import Path
import audit_next_required_numeric_context_20261019 as original
from next_required_numeric_context_20261019 import B,claim_writer
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from equal_operation_benchmark_v2 import process
from fixed_three_query_core_20261019 import helpers
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
OUT=B/'additive_menu_join_v2';PREP=B/'menu_join_repair_v2_preparation'
def source_tail():
    main=next(n for n in ast.parse(Path(original.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    offset=next(i for i,n in enumerate(main.body) if isinstance(n,ast.ImportFrom) and n.module=='dynamic_actual_mask_guidance_v1')
    old=copy.deepcopy(main.body[offset:]);new=copy.deepcopy(old);changed=0
    for node in new:
        if isinstance(node,ast.ImportFrom) and node.module=='joint_reallocation_opportunity_core_v1':
            assert [v.name for v in node.names]==['action_key'];node.module='compile_lookahead_paid_input_cache_20261014';changed+=1
    assert changed==1
    return ast.Module(body=new,type_ignores=[])
def prepare():
    PREP.mkdir(exist_ok=False);actors=[]
    for part in ('actual','independent_audit'):
        c=read(B/part/'owner.claim');assert process(c['actual_pid']) is None and process(c['actual_parent_pid']) is None
        actors.append(c)
    assert read(B/'Completion.json')['exit_codes']=={'actual':0,'independent_audit':1}
    log=B/'independent_audit_console.log';assert 'ImportError: cannot import name \'action_key\'' in log.read_text('utf-8')
    assert read(B/'independent_audit/Independent_Audit.json')['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
    source_tail();files=[Path(__file__),Path(original.__file__),B/'Protocol.json',B/'Completion.json',log,B/'independent_audit/Independent_Audit.json']
    put(PREP/'Protocol.json',{'status':'FROZEN_ZERO_SCIENCE_FAILED_IMPORT_MENU_JOIN_REPAIR','source_input_sha256':{str(v.relative_to(R)):sha(v) for v in files},'runtime_versions':read(B/'Protocol.json')['runtime_versions'],
        'old_actors_ended':actors,'allowed':'Execute only unexecuted menu-join tail, corrected action_key import; save output in additive directory. Original equation audit/source/stderr remain intact. No dS/LU/PF/model or forecasts rerun.'})
    h=helpers(__file__);h['B']=B;code=h['launch'](Path(__file__),'reader',OUT,read(B/'Protocol.json'))
    put(PREP/'Completion.json',{'reader_exit_code':code,'new_scientific_calls':0});manifest(PREP);print(json.dumps({'menu_join_repair_exit':code,'science':0}))
def reader():
    p=read(B/'Protocol.json');out=OUT;h=helpers(__file__);h['B']=B;h['claim'](out,p);guard=LockedSourceSnapshot(PREP/'Protocol.json')
    try:
        for rel,v in p['pins'].items():assert sha(R/rel)==v
        assert read(B/'independent_audit/Independent_Audit.json')['status'].startswith('PASS_SINGLE_EXACT_')
        def additive_put(path,value):
            assert path==B/'Full_Native_Menu_ACK.json';put(out/'Full_Native_Menu_ACK.json',value)
        env=original.__dict__.copy();env.update(B=B,put=additive_put)
        exec(compile(source_tail(),str(original.__file__),'exec'),env)
        put(out/'Result.json',{'status':'PASS_ADDITIVE_COMPLETE_NATIVE_MENU_JOIN_ORIGINAL_EQUATION_AUDIT_PRESERVED','new_dS_factor_solve_forecast_model_PF_calls':0})
    finally:guard.close();manifest(out)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--reader',action='store_true');args=a.parse_args();reader() if args.reader else prepare()
