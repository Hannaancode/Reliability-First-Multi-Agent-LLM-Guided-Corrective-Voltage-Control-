"""Exactly one prospective worker followed by exactly one first reader."""
import json,os,subprocess
from datetime import datetime,timezone
from public13_fresh_router_engine_20261022 import R,P,PRIMARY,READER,put,read,sha
O=R/'outputs/public13_fresh_router_handoff_20261022'

def main():
    assert not PRIMARY.exists() and not READER.exists();O.mkdir(exist_ok=False)
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),at_utc=datetime.now(timezone.utc).isoformat()))
    protocol=read(P/'Protocol.json')
    for rel,h in protocol['source_and_input_hashes'].items():assert sha(R/rel)==h
    readiness=read(P/'Independent_Launch_Review.json');assert readiness['status']=='PASS_SOURCE_INPUT_STATE_SCOPE_OWNERSHIP_STATIC_REVIEW'
    for label in ['Primary','Reader']:
        with (O/(label+'.log')).open('x',encoding='utf-8') as log:
            code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str((P/(label+'_Owner_Protocol.json')).relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        put(O/(label+'_End.json'),dict(exit_code=code,at_utc=datetime.now(timezone.utc).isoformat()))
        assert code==0,'Retain original failed claim/source/stderr; no automatic science/reader retry'
    with (O/'Comparison.log').open('x',encoding='utf-8') as log:
        code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/compare_public13_fresh_router_20261022.py')],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
    put(O/'Comparison_End.json',dict(exit_code=code));assert code==0
    put(O/'Completion.json',dict(status='FRESH128_PRIMARY_FIRST_READER_AND_FIXED_ANALYSIS_TERMINAL',at_utc=datetime.now(timezone.utc).isoformat()))

if __name__=='__main__':main()
