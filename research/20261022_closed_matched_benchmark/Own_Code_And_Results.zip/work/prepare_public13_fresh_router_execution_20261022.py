"""Freeze the one prospective fresh128 routing study after software/input gates.
No native policy forward, PF, derivative, LP or learning call occurs here.
Nine actual checkpoint reads for a full saved-state engineering fixture are paid.
"""
import ast,copy,hashlib,json,os,pickle,random
from datetime import datetime,timezone
from pathlib import Path
from public13_fresh_router_engine_20261022 import R,P,PRIMARY,READER,put,read,sha,state_digest

def main():
    P.mkdir(exist_ok=False)
    sw=read(R/'outputs/public13_fresh_router_software_checks_v2_20261022/Software_Checks.json')
    assert all(sw['checks'].values()) and sw['engine_sha256']==sha(R/'work/public13_fresh_router_engine_20261022.py')
    inputs=R/'outputs/public13_fresh_input_router_preparation_v2_20261021'
    assert read(inputs/'Independent_Input_Audit.json')['status'].startswith('PASS')
    assert not PRIMARY.exists() and not READER.exists()
    # Compile every actual entry and shared implementation without executing it.
    sources=['work/public13_fresh_router_engine_20261022.py','work/run_public13_fresh_router_20261022.py','work/audit_public13_fresh_router_20261022.py',
        'work/stable_ddpg_native_bridge_20261020.py','work/public13_complete_policy_state_contract_20261021.py',
        'work/public13_matched_numeric_engine_20261021.py','work/native_fit_teacher_math_20261020.py','work/native_full_grid_affine_core_20261020.py',
        'work/native_upgrade_support_engine_20261020.py','work/run_public13_remaining_published_cohort_20261021.py',
        'work/candidate_process_evidence_utils.py','work/candidate_process_runtime.py',
        'work/coordinate_public13_fresh_router_20261022.py','work/compare_public13_fresh_router_20261022.py']
    for rel in sources:compile((R/rel).read_text(encoding='utf-8'),str(R/rel),'exec')
    index=read(R/'outputs/public13_matched_numeric_preparation_20261021/Historical_Paid_Physical_Index.json')
    signatures=set(index['all_relevant_attempted_signatures'])
    old=read(R/'outputs/public13_matched_numeric_execution_20261021/Result.json')
    signatures.update(v['physical_signature'] for v in old['receipts'])
    put(P/'Historical_Physical_Attempt_Anchors.json',dict(status='CLOSED_SOURCE13_ATTEMPT_HISTORY_UNION_NO_NEW_SCIENCE',physical_signatures=sorted(signatures),
        anchors=[dict(path='outputs/public13_matched_numeric_preparation_20261021/Historical_Paid_Physical_Index.json',sha256=sha(R/'outputs/public13_matched_numeric_preparation_20261021/Historical_Paid_Physical_Index.json')),
                 dict(path='outputs/public13_matched_numeric_execution_20261021/Result.json',sha256=sha(R/'outputs/public13_matched_numeric_execution_20261021/Result.json'))],
        noncontrolled_regime_closure=read(inputs/'No_Repeat_And_Source_Input_Readiness.json'),scope='All named closed native13 attempts, not universal history. New recipes independently disjoint; no old roots or old calls replayed.'))
    # Actual saved native data/model state, without a new forward or physics.
    import stable_ddpg_native_bridge_20261020 as b
    from public13_complete_policy_state_contract_20261021 import snapshot,restore,check_cursor
    np=b.np;torch=b.torch;random.seed(20261022);np.random.seed(20261022);torch.manual_seed(20261022)
    base=R/'outputs/stable_ddpg_native_engineering_20261020/PF0_after.pkl';net=pickle.loads(base.read_bytes())
    ns={'np':np,'LA':np.linalg,'gym':type('GymNamespace',(),{'Env':object}),'copy':copy,'pp':type('NoPhysics',(),{'runpp':staticmethod(lambda *a,**k:(_ for _ in ()).throw(AssertionError('No engineering PF allowed')))})}
    native,definition=b.definitions(b.AUTHOR/'env_single_phase_13bus.py',['IEEE13bus'],ns)
    env=native['IEEE13bus'](net,np.asarray([2,7,9]));env.state=net.res_bus.iloc[[2,7,9]].vm_pu.to_numpy()
    calls=[];models,loads,policy_proof=b.load_three(env,lambda kind,**kw:calls.append(dict(kind=kind,**kw)))
    banks={**models,'our-router:safe-ddpg':copy.deepcopy(models['safe-ddpg']),'published-router:safe-ddpg':copy.deepcopy(models['safe-ddpg']),'published-router:ddpg':copy.deepcopy(models['ddpg'])}
    before=snapshot(banks);deadline=123456789.125
    packet=dict(complete_model_state=before,paid_receipts=[],attempted_inputs=[],historical_attempts=read(P/'Historical_Physical_Attempt_Anchors.json')['anchors'],python_rng=random.getstate(),numpy_rng=np.random.get_state(),torch_rng=torch.get_rng_state().numpy(),absolute_deadline_monotonic=deadline,environment=copy.deepcopy(env.__dict__),last_Q=net.sgen.q_mvar.to_numpy()[:3].copy(),state=env.state.copy(),history=[],protocol_sha256='ENGINEERING_ONLY_NOT_PRODUCTION_PROTOCOL')
    with (P/'Actual_No_Forward_Complete_State_Fixture.pkl').open('xb') as f:pickle.dump(packet,f,protocol=5);f.flush();os.fsync(f.fileno())
    loaded=pickle.loads((P/'Actual_No_Forward_Complete_State_Fixture.pkl').read_bytes());check_cursor(loaded,banks,deadline)
    for group in banks.values():
        for model in group:
            assert model.training is False
    cold=copy.deepcopy(banks);restore(cold,loaded['complete_model_state']);assert state_digest(snapshot(cold))==state_digest(before)
    negatives={}
    for name,mutate in [('missing_model_tensor',lambda v:v['complete_model_state'].pop(next(iter(v['complete_model_state'])))),
                        ('changed_absolute_bound',lambda v:v.update(absolute_deadline_monotonic=deadline+1)),
                        ('missing_paid_history',lambda v:v.pop('historical_attempts'))]:
        bad=copy.deepcopy(loaded);mutate(bad)
        try:check_cursor(bad,banks,deadline)
        except AssertionError:negatives[name]=True
        else:negatives[name]=False
    assert all(negatives.values())
    put(P/'Actual_No_Forward_State_Readiness.json',dict(status='PASS_REAL_SAVED_NATIVE_NET_AND_ALL_SEPARATE_SOURCE_MODEL_BANKS_ZERO_FORWARD_ZERO_PHYSICS',
        saved_NET=base.relative_to(R).as_posix(),source_environment=definition,source_policies=policy_proof,actual_checkpoint_load_attempts=9,actual_checkpoint_load_returns=9,
        exact_original_checkpoint_metadata=loads,all_source_state_digest=state_digest(before),negative_controls=negatives,
        new_actor_PF_derivative_LP_training_calls=0,scope='Saved parameter/environment/RNG/cursor roundtrip; production uses cold state before every decision. Not yet a new physical integration or full OS/process restart certificate.'))
    source_files=[R/x for x in sources]+[b.AUTHOR/'env_single_phase_13bus.py',b.AUTHOR/'safeDDPG.py']+[b.AUTHOR/v['checkpoint'] for v in loads]
    input_files=[inputs/n for n in ['All128_Source_Exact_Physical_Recipes.npz','All128_Prospective_Identities.json','Prospective_Router_Protocol.json','Independent_Input_Audit.json']]
    graph=R/'outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz'
    source_files+=[base,graph,P/'Historical_Physical_Attempt_Anchors.json',P/'Actual_No_Forward_State_Readiness.json',R/'outputs/public13_fresh_router_software_checks_v2_20261022/Software_Checks.json']+input_files
    hashes={f.relative_to(R).as_posix():sha(f) for f in source_files}
    protocol=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_PROSPECTIVE_FRESH128_SIX_ARMS_NO_RESULTS_YET',
        science_seconds=7200,reader_seconds=7200,binary_preservation_cap_bytes=8*1024**3,seeds=list(range(1000,1128)),arms=['safe-ddpg','linear','ddpg','numerical','our-router','published-router'],
        source_and_input_hashes=hashes,graph=graph.relative_to(R).as_posix(),base_NET=base.relative_to(R).as_posix(),
        identities=(inputs/'All128_Prospective_Identities.json').relative_to(R).as_posix(),recipes=(inputs/'All128_Source_Exact_Physical_Recipes.npz').relative_to(R).as_posix(),
        primary_end_ACK='outputs/public13_fresh_router_coordination_20261022/End_ACK.json',
        hypothesis_and_prior_frozen_rules=read(inputs/'Prospective_Router_Protocol.json'),
        precise_stopping='Native3 baseline methods retain original source3 strict done after a first step, including initially global-compliant roots, and100rounds. Our-router/published-router stop immediately only on initially globally compliant input; otherwise backend selected once. Safe and DDPG backend retains source3 strict done with common guard; numerical backend retains unchanged global-band/guard-first-rejection/100round stops. No guard applied to the three unmodified native primary comparators.',
        cold_rule='Before every primary decision persist and reload environment, all separate policy banks, Q/history/RNG, paid returned/attempted registry, numerical evidence cache, source/input anchors, costs, journal pointer and unchanged absolute bound. No additional cold model forward. Independently re-execute every returned actor once and only new returned PF once; no old or failed replays.',
        source9_checkpoint_reads_per_owner=9,extra_router_banks='Deep copies of exact canonical initial source policies, with independent actual skipped-episode/mutable b/c carry; not copied standalone episode outcomes.',
        prospective_statistics='All128 full-band endpoint; paired bootstrap10000 seed20261022, Holm4 exact discordant-binomial tests versus all three native baselines and same-input published-router. Gate fraction>=.90 and positive95%lower bound/Holm<.05 versus EACH. Partial means gateUNKNOWN.',
        full_costs='Record all root/query/reuse/actor/derivative/LU/RHS/LP/rejection/failure/preparation/preservation/reader costs. Prior source training, old studies, private model and frozen paper DSE BOTH-branch costs remain separately paid, not free. No speed/equal-information/LLM/novelty or full AC-feasibility claim.',
        no_performance_or_LLM_claim_from_readiness=True,all6finalgoals='OPEN')
    put(P/'Protocol.json',protocol)
    put(P/'Independent_Reader_Lock.json',dict(reader='work/audit_public13_fresh_router_20261022.py',reader_sha256=sha(R/'work/audit_public13_fresh_router_20261022.py'),engine_sha256=sha(R/'work/public13_fresh_router_engine_20261022.py'),protocol_sha256=sha(P/'Protocol.json')))
    for label,source,output,coord in [('Primary','work/run_public13_fresh_router_20261022.py',PRIMARY,'outputs/public13_fresh_router_coordination_20261022'),('Reader','work/audit_public13_fresh_router_20261022.py',READER,'outputs/public13_fresh_router_reader_coordination_20261022')]:
        put(P/f'{label}_Owner_Protocol.json',dict(single_owner=dict(source=source,sha256=sha(R/source),output=output.relative_to(R).as_posix(),coordination=coord,python='work/vcsa_module_env/Scripts/python.exe',bound_seconds=7500)))
    put(P/'Preparation_Readiness.json',dict(status='PASS_FIXED_SOURCE_INPUT_SOFTWARE_AND_REAL_NO_FORWARD_STATE_GATES',protocol_sha256=sha(P/'Protocol.json'),actual_new_checkpoint_reads=9,actual_new_policy_PF_derivative_LP_training_calls=0,launch_requires_fresh_exact_process_claim_command_and_no_existing_output=True))
    print(json.dumps(dict(preparation='PASS',new_checkpoint_reads=9,new_scientific_calls=0,protocol_sha256=sha(P/'Protocol.json'))))

if __name__=='__main__':main()
