from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,re
from docx import Document
from docx.oxml.ns import qn
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_current_comparison_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pictures(d):
 return [(hashlib.sha256(d.part.related_parts[s._inline.graphic.graphicData.pic.blipFill.blip.embed].blob).hexdigest(),s.width,s.height) for s in d.inline_shapes]
def main():
 dest=O/'Independent_Content_Fields_And_Index_Check.json';assert not dest.exists()
 c=json.loads((O/'Change_Record.json').read_text());b=Document(R/c['base']);d=Document(R/c['current'])
 expected=Counter(p.text for p in b.paragraphs if p.text);expected.update(c['added_paragraphs'])
 for x in c['changes']:
  assert expected[x['old']]>0,x['old'];expected[x['old']]-=1;expected[x['new']]+=1
 assert +expected==Counter(p.text for p in d.paragraphs if p.text)
 fp=lambda t:tuple(tuple(c.text for c in r.cells) for r in t.rows)
 tables=Counter(fp(t) for t in b.tables);tables.update([tuple(tuple(r) for r in c['new_table']['rows'])]);assert tables==Counter(fp(t) for t in d.tables)
 assert pictures(b)==pictures(d) and len(d.tables)==23 and len(d.inline_shapes)==22
 names=[x.get(qn('w:name')) for x in d.element.xpath('.//w:bookmarkStart')];fields=d.element.xpath('.//w:fldSimple')
 expectednames={x['bookmark'] for x in c['automatic_page_fields']};assert len(expectednames)==57 and expectednames<=set(names)
 localfields=[x for x in fields if x.get(qn('w:instr'),'').startswith('PAGEREF hg_evidence_page_')]
 assert len(localfields)==57 and {x.get(qn('w:instr')).split()[1] for x in localfields}==expectednames
 index=json.loads((O/'Thesis_Evidence_Navigation.json').read_text());assert index['docx_sha256']==sha(R/c['current']) and len(index['tables'])==23 and len(index['figures'])==22
 cache={};binding_count=0
 for t in index['tables']:
  assert set(t['components'])=={'code','data','model','config','result','verification','status'}
  for v in t['components'].values():
   for r in v['records']:
    p=Path(r['path']);p=p if p.is_absolute() else R/p
    if str(p) not in cache:cache[str(p)]=sha(p)
    assert cache[str(p)]==r['sha256'];binding_count+=1
 html=(O/'Evidence_Index.html').read_text();assert 'page None' not in html
 for t in index['tables']:assert 'id="t'+t['table']+'"' in html and 'href="#t'+t['table']+'"' in html
 sources=json.loads((R/'outputs/public13_voltage_magnitude_analysis_20261029/Results.json').read_text())
 assert [sources['summaries'][k]['descriptive_common_epsilon_fullband'] for k in ['our_numerical','safe-ddpg','linear','ddpg']]==[415,262,258,363]
 out=dict(status='PASS_ADDITIVE_DOCX_CONTENT_IMAGES_LOCAL_PAGE_FIELDS_ALL_TABLE_COMPONENT_LINKS',at_utc=datetime.now(timezone.utc).isoformat(),
  tables=23,figures=22,automatic_local_page_fields=57,source_bindings=binding_count,unique_small_source_files=len(cache),
  exact_original_image_bytes_and_old_table_values_preserved=True,docx_sha256=sha(R/c['current']),
  pagination='User explicitly will compile; no PDF or final page count claimed.',title_approval='PENDING',new_model_PF_calls=0)
 dest.write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
if __name__=='__main__':main()
