"""Freeze one new disposable integration, minimal public-only payload and full-state reader."""
import ast,json,hashlib,zipfile
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import read,sha,write
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_joint_15_engineering_preparation_20261020'
def main():
    OUT.mkdir(exist_ok=False)
    # Additive transport copies: original scientists/readers remain immutable.
    owner=(ROOT/'work/run_original_lora_native13_colab_v2_20261020.py').read_text(encoding='utf-8')
    owner=owner.replace('original_lora_native13_transfer_preparation_v2_20261020','native_joint_15_engineering_preparation_20261020').replace('original_lora_native13_transfer_execution_v2_20261020','native_joint_15_engineering_execution_20261020').replace("arm='public_0_5B'","arm='native_1_5B'")
    begin=owner.index("    profile['credential_path']=");end=owner.index("    state=",begin)
    owner=owner[:begin]+"    profile['credential_path']=r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud\\application_default_credentials.json'\n"+owner[end:]
    owner=owner.replace('native13_lora_setup_remote_v2_20261020.py','native_joint_15_setup_remote_20261020.py').replace('native13_lora_guardian_v2_20261020.py','native_joint_15_guardian_20261020.py')
    marker="        ack={'number':number"
    index=owner.index(marker)
    validation="""        # Full CPU state validation is a prerequisite to ACK, not a byte-only check.
        for checkpoint_name,step in [('initial0_complete.pt',0),('step2_complete.pt',2)]:
            if checkpoint_name in descriptor['members']:
                report=local/f'CPU_Full_State_{step}.json'
                if not report.exists():
                    import subprocess
                    subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(ROOT/'work/validate_native_joint_checkpoint_20261020.py'),str(OUT/'staged/study'/checkpoint_name),str(report),str(step)],check=True,timeout=180)
                validation_record=read(report);assert validation_record['status'].startswith('PASS_COMPLETE_CPU') and validation_record['checkpoint_sha256']==descriptor['members'][checkpoint_name]['sha256']
"""
    owner=owner[:index]+validation+owner[index:]
    (ROOT/'work/run_native_joint_15_colab_20261020.py').write_text(owner,encoding='utf-8')
    for old,new in [('native13_lora_setup_remote_v2_20261020.py','native_joint_15_setup_remote_20261020.py'),('native13_lora_guardian_v2_20261020.py','native_joint_15_guardian_20261020.py')]:
        text=(ROOT/'work'/old).read_text(encoding='utf-8').replace('native13_lora_environment_check_v2_20261020.py','native_joint_15_environment_check_20261020.py').replace('run_native13_lora_transfer_remote_v2_20261020.py','run_native_joint_15_engineering_remote_20261020.py')
        (ROOT/'work'/new).write_text(text,encoding='utf-8')
    text=(ROOT/'work/native13_lora_environment_check_v2_20261020.py').read_text(encoding='utf-8')
    text=text.replace("report={'gpu':", "assert hashlib.sha256((snapshot/'config.json').read_bytes()).hexdigest()==p['base_for_new_experiment']['config_sha256']\nreport={'gpu':")
    (ROOT/'work/native_joint_15_environment_check_20261020.py').write_text(text,encoding='utf-8')
    files=['work/run_native_joint_15_engineering_remote_20261020.py','work/native_slm_joint_head_v2_20261020.py','work/native_joint_checkpoint_contract_20261020.py','work/candidate_process_pretrained_loader.py','work/public_size_u61_preservation.py','work/native_joint_15_guardian_20261020.py','work/native_joint_15_environment_check_20261020.py','work/frozen_dependency_closure.txt','work/frozen_gpu_requirements.txt','work/uv_bootstrap_version.txt']
    source_hashes={n:sha(ROOT/n) for n in files}
    for n in files:
        if n.endswith('.py'):ast.parse((ROOT/n).read_text(encoding='utf-8'))
    for n in ['work/run_native_joint_15_colab_20261020.py','work/validate_native_joint_checkpoint_20261020.py','work/audit_native_joint_15_engineering_20261020.py']:ast.parse((ROOT/n).read_text(encoding='utf-8'))
    item=ROOT/'outputs/native_slm_joint_input_preparation_20261020/Selected_Longest_Engineering_Context.json';assert read(item)['tokens']==3229
    previous=read(ROOT/'outputs/native_upgrade_verified_handoff_20261020/Verified_Progress.json');assert previous['new_actual_costs']['pretrained_SLM_GPU_optimizer_calls']==0
    model=next(m for m in read(ROOT/'outputs/matched_scale_20261011/preparation/protocol.json')['models'] if m['arm']=='public_1_5B')
    protocol={'study_id':'native_joint_15_disposable_integration_20261020','at_utc':datetime.now(timezone.utc).isoformat(),'scientific_scope':'Engineering ONLY: native joint three-actuator action head on one longest causal development context. Dispose two-update weights; no benchmark or learning win.',
      'base_for_new_experiment':{'repo':model['repo'],'revision':model['revision'],'public_weight_sha256':model['files']['model.safetensors']['sha256'],'config_sha256':model['files']['config.json']['sha256']},'profiles':{'native_1_5B':{'account':'abdulhannaan2002@gmail.com'}},'source_hashes':source_hashes,'selected_input_sha256':sha(item),
      'context_selection':'Longest complete3229token input from all24native causal contexts;index8 independent of model outputs. No truncation, generation or futurelabels. Global-current-information variant, not unchanged originalLOCALpaperrole.',
      'native_action':'One public1.5B body, FP32bounded3head outputs u; exactsource float32u±.3 and float64Qnext=Qcurrent-u. No Q cap invented.',
      'engineering':{'planned_body_forward_calls':4,'planned_backward_calls':2,'planned_optimizer_returns':2,'planned_model_loads':2,'seed':20261020,'LoRA_r_alpha_dropout':[16,16,0],'LoRA_parameters':18464768,'head_parameters':4611,'expected_trainable_tensors':394,'optimizer':{'name':'AdamW','lr':.0002,'decay':.01,'clip':1,'scaler_initial':1024},'objective':'Current-affine full13band squaredviolation+.01absoluteQnext squarednorm. Currentderivative only; no candidateAFTER/teacherused in bodyforward. Engineering only, not proposed validated policyobjective.','initial_zero_LoRA_A_gradient_expected':True,'second_update_all_tensors_nonzero_required':True},
      'preservation':'Initial0 and step2 complete trainables/AdamWmoments/perparametersteps/scaler/RNG/cursor/source/input on CPU before ACK and any subsequent modelcalls. Independently hashed <=2MiB chunks/delta journal; exactfreshmodel loss/u/Q comparison. Guardian preserves allpartial attempts before exactrelease.',
      'setup_seconds':1800,'science_process_seconds':1800,'collector_seconds':2100,'local_owner_bound_seconds':4500,'one_allocation_no_fallback_no_retry':True,'peak_allocated_limit_bytes':12*1024**3,'no_actual_model_PF_call_by_preparation':True,'engineering_success_not_automatic_full_training_or_physics':True,'cost_limitations':'Bodyapplication counts are exactdirectcaller counts; gradient-checkpoint inner recomputation FLOPs and kernel costs not separately measured; full workflow/load/transfer/failure costs retained.'}
    write(OUT/'Production_Protocol.json',protocol)
    write(OUT/'Direct_Human_Authority.json',{'instruction':'Continue substantive tasks and upgrade model under full necessary human authority, with evidence-led source/ownership/preservation, no guaranteed benchmark winner.','one_selected_account':'original','no_private_model_network_credentials_exported':True})
    payload={n:ROOT/n for n in files};payload['prep/protocol.json']=OUT/'Production_Protocol.json';payload['prep/Selected_Longest_Engineering_Context.json']=item
    descriptor={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in payload.items()};archive=OUT/'Native_Joint15_Public_Engineering_Input.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for n,p in payload.items():z.write(p,n)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json',json.dumps(descriptor,indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for n,m in descriptor.items():assert len(z.read(n))==m['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
    write(OUT/'Cloud_Payload_Manifest.json',{'archive':str(archive.relative_to(ROOT)),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(payload)+1,'human_authority_source':str((OUT/'Direct_Human_Authority.json').relative_to(ROOT)),'human_authority_sha256':sha(OUT/'Direct_Human_Authority.json'),'no_private_adapter_tokenizer_network_credentials':True})
    write(OUT/'Independent_Reader_Lock.json',{'reader_sha256':sha(ROOT/'work/audit_native_joint_15_engineering_20261020.py'),'protocol_sha256':sha(OUT/'Production_Protocol.json'),'validator_sha256':sha(ROOT/'work/validate_native_joint_checkpoint_20261020.py'),'only_after_actual_owner_ended_release_and_closed_outputs':True,'zero_new_model_PF_optimizer_calls':True})
    hashes=dict(source_hashes)
    for rel in ['work/run_native_joint_15_colab_20261020.py','work/native_joint_15_setup_remote_20261020.py','work/validate_native_joint_checkpoint_20261020.py','work/audit_native_joint_15_engineering_20261020.py']:hashes[rel]=sha(ROOT/rel)
    write(OUT/'Launch_Readiness_Audit.json',{'passed':True,'source_hashes':hashes,'AST_and_complete_bundled_static_import_closure':True,'actual_GPU_integration_performance':'UNKNOWN','no_scientific_retry_or_idle_GPU':True,'payload_public_only':True,'independent_reader_locked':True})
    write(OUT/'Owner_Protocol.json',{'single_owner':{'source':'work/run_native_joint_15_colab_20261020.py','sha256':sha(ROOT/'work/run_native_joint_15_colab_20261020.py'),'python':'work/vcsa_module_env/Scripts/python.exe','output':'outputs/native_joint_15_engineering_execution_20261020','coordination':'outputs/native_joint_15_engineering_coordination_20261020','bound_seconds':4500}})
    print(json.dumps({'status':'FROZEN_PUBLIC_ONLY_NATIVE15_DISPOSABLE_ENGINEERING_PREPARATION','payload_bytes':archive.stat().st_size,'payload_sha256':sha(archive),'no_model_PF_GPU_calls':True}))
if __name__=='__main__':main()
