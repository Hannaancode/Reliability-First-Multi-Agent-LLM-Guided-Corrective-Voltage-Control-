from pathlib import Path
from copy import deepcopy
from datetime import datetime, timezone
import hashlib, json, re
from docx import Document
from docx.text.paragraph import Paragraph

R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_citations_integrated_20261029'
P=R/'outputs/thesis_citation_reconciliation_20261029/citation_reconciliation.json'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
def main():
    cfg=json.loads(P.read_text(encoding='utf-8')); base=Path(cfg['source_master'])
    assert sha(base)==cfg['source_master_sha256']
    O.mkdir(exist_ok=False); doc=Document(base); changes=[]; inserted=[]
    def find(t):
        got=[p for p in doc.paragraphs if p.text==t]; assert len(got)==1,(len(got),t[:100]);return got[0]
    def replace(p,t,why):
        old=p.text;assert not p._p.xpath('.//w:drawing|.//w:fldSimple|.//w:bookmarkStart'),old[:70]
        if old!=t:
            # Preserve paragraph and first-run formatting; none of these prose anchors contains fields/images.
            rp=deepcopy(p.runs[0]._r.rPr) if p.runs and p.runs[0]._r.rPr is not None else None
            p.clear();rr=p.add_run(t)
            if rp is not None:rr._r.insert(0,rp)
            changes.append(dict(old=old,new=t,reason=why))
    def insert(anchor,text,before=False):
        el=deepcopy(anchor._p)
        for child in list(el):
            if child.tag.endswith('}pPr'):continue
            el.remove(child)
        (anchor._p.addprevious if before else anchor._p.addnext)(el)
        p=Paragraph(el,anchor._parent);p.add_run(text);inserted.append(text);return p
    for patch in cfg['paragraph_recommendations']:
        p=find(patch['anchor_exact']);op=patch['operation']
        if op=='replace':replace(p,patch['new_text'],patch['id'])
        else:
            assert op in ('insert_before','insert_after');insert(p,patch['new_text'],op=='insert_before')
    for correction in cfg['existing_reference_corrections']:
        if correction['kind']=='bibliography_replace':replace(find(correction['old']),correction['new'],'verified_bibliography_metadata')
    refs={int(m.group(1)):p for p in doc.paragraphs if (m:=re.match(r'^\[(\d+)\] ',p.text))}
    assert sorted(refs)==list(range(1,40))
    removed=refs[38].text;refs[38]._p.getparent().remove(refs[38]._p)
    last=refs[39]
    for b in cfg['bibliography_additions']:last=insert(last,b['citation'])
    mapping={n:(29 if n==38 else n-1 if n>=39 else n) for n in range(1,73)}
    # Citations are numeric bracket groups; do not modify ordinary quantities or voltages.
    cite=re.compile(r'\[(\d+(?:\s*[,–-]\s*\d+)*)\]')
    def renumber(text):
        def rep(m):
            ids=[int(x) for x in re.findall(r'\d+',m[1])]
            if not all(x in mapping for x in ids):return m[0]
            return '['+re.sub(r'\d+',lambda z:str(mapping[int(z[0])]),m[1])+']'
        return cite.sub(rep,text)
    # All original table values remain unchanged except genuine reference tokens, if any.
    table_changes=[]
    for p in list(doc.paragraphs):
        new=renumber(p.text)
        if new!=p.text:replace(p,new,'single_pass_reference_renumber')
    seen=set()
    for ti,t in enumerate(doc.tables):
        for ri,row in enumerate(t.rows):
            for ci,c in enumerate(row.cells):
                if id(c._tc) in seen:continue
                seen.add(id(c._tc))
                for p in c.paragraphs:
                    new=renumber(p.text)
                    if new!=p.text:
                        table_changes.append(dict(table=ti,row=ri,col=ci,old=p.text,new=new));replace(p,new,'table_reference_renumber')
    refs2=[p.text for p in doc.paragraphs if re.match(r'^\[\d+\] ',p.text)]
    assert [int(re.match(r'^\[(\d+)\]',x)[1]) for x in refs2]==list(range(1,72))
    out=O/'Hannaan_Thesis_Citations_And_Current_Results.docx';doc.save(out)
    write(O/'Citation_Integration_Record.json',dict(status='CONTENT_INTEGRATED_PENDING_INDEPENDENT_CHECK',at_utc=datetime.now(timezone.utc).isoformat(),
      base=str(base.relative_to(R)),base_sha256=sha(base),current=str(out.relative_to(R)),current_sha256=sha(out),
      reconciliation=str(P.relative_to(R)),reconciliation_sha256=sha(P),paragraph_changes=changes,inserted_paragraphs=inserted,
      removed_duplicate_reference=removed,table_citation_changes=table_changes,renumber_mapping=mapping,
      references=71,figures=len(doc.inline_shapes),tables=len(doc.tables),new_model_PF_training_calls=0,
      pagination='Not rendered or compiled, at explicit user request. Last full visual review belongs to the prior134page revision.',
      final_source_crosswalk=[dict(x,final_thesis_number=mapping.get(x.get('proposed_thesis_number'))) for x in cfg['source_crosswalk']]))
    print(json.dumps(dict(docx=str(out),references=71,tables=len(doc.tables),figures=len(doc.inline_shapes),paragraph_changes=len(changes),inserted=len(inserted),table_citation_changes=len(table_changes))))
if __name__=='__main__':main()
