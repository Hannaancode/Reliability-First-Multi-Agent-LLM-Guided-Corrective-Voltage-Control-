import os,time,json
from pathlib import Path
from datetime import datetime,timezone
from stable_ddpg_native_episode_engine_20261020 import execute,sha,put,PRIMARY
def main():
    PRIMARY.mkdir(exist_ok=False);start=time.monotonic();put(PRIMARY/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (PRIMARY/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    a=json.loads((PRIMARY/'Launcher_ACK.json').read_text(encoding='utf-8'));assert a['actual_pid']==os.getpid() and a['actual_parent_pid']==os.getppid() and a['fresh_exact_source_PID_parent_command']
    r=execute(PRIMARY,'primary');print(json.dumps({'status':r['status'],'endpoints':[{k:e[k] for k in ['algorithm','completed_original_steps','all_bus_UV','all_bus_OV','native_controlled_done']} for e in r['endpoints']],'costs':r['costs']}))
if __name__=='__main__':main()
