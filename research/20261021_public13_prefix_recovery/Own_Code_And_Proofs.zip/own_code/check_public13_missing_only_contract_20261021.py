"""Labeled software tests only; zero pretrained forwards or nonlinear PF."""
import ast,copy,hashlib,json,random,argparse
from pathlib import Path
import public13_complete_policy_state_contract_20261021 as c
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_missing_only_preparation_20261021'
np=c.np;torch=c.torch
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',default='Software_Readiness.json');args=parser.parse_args();assert Path(args.output).name==args.output
    checks=[]
    def accept(name,fn):fn();checks.append({'name':name,'expected':'ACCEPT','actual':'ACCEPT'})
    def reject(name,fn):
        try:fn()
        except (AssertionError,KeyError):checks.append({'name':name,'expected':'REJECT','actual':'REJECT'})
        else:raise AssertionError(name)
    class Tiny(torch.nn.Module):
        def __init__(self):
            super().__init__();self.b=torch.nn.Parameter(torch.tensor([[1.,2.]]));self.c=torch.nn.Parameter(torch.tensor([[3.,4.]]));self.q=torch.nn.Parameter(torch.tensor([5.]));self.scale=.15
    models={'safe-ddpg':[Tiny()]};values=c.snapshot(models)
    accept('mock_tensor_exact_restore',lambda:c.restore(models,values))
    reject('missing_actual_parameter',lambda:c.restore(models,{k:v for k,v in values.items() if not k.endswith('::q')}))
    reject('wrong_actual_parameter_dtype',lambda:c.restore(models,{k:v.astype(np.float64) for k,v in values.items()}))
    packet={'complete_model_state':values,'paid_receipts':[],'attempted_inputs':{},'historical_attempts':set(),'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'absolute_deadline_monotonic':123.,'environment':{},'last_Q':np.zeros((3,1)),'state':np.ones(3),'history':[],'protocol_sha256':'fixture'}
    accept('complete_mock_cold_cursor',lambda:c.check_cursor(packet,models,123.))
    reject('missing_paid_registry',lambda:c.check_cursor({k:v for k,v in packet.items() if k!='paid_receipts'},models,123.))
    reject('renewed_absolute_deadline',lambda:c.check_cursor(packet,models,124.))
    bad=copy.deepcopy(packet);bad['complete_model_state']['safe-ddpg::0::q'][0]+=1
    reject('altered_live_policy_state',lambda:c.check_cursor(bad,models,123.))
    bad=copy.deepcopy(packet);bad['torch_rng'][0]^=1
    reject('altered_rng',lambda:c.check_cursor(bad,models,123.))
    model=models['safe-ddpg'][0];before={n:v.detach().clone() for n,v in model.state_dict().items()}
    with torch.no_grad():
        for name in ['b','c']:
            v=before[name].clamp(min=0);getattr(model,name).data=model.scale*v/torch.norm(v,1)
    accept('native_mock_b_c_projection',lambda:c.source_transition(model,'safe-ddpg',before))
    with torch.no_grad():model.q.add_(1.)
    reject('unexpected_other_tensor_mutation',lambda:c.source_transition(model,'safe-ddpg',before))
    source=R/'work/run_public13_missing_only_continuation_20261021.py';reader=R/'work/audit_public13_missing_only_continuation_20261021.py'
    new=ast.parse(source.read_text(encoding='utf-8'));old=ast.parse((R/'work/run_public13_remaining_published_cohort_20261021.py').read_text(encoding='utf-8'))
    for name in ['metrics','regime']:
        a=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name==name);b=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name==name);assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
    checks.append({'name':'source_metric_and_noncontrolled_input_definitions_AST_exact','expected':'ACCEPT','actual':'ACCEPT'})
    ast.parse(reader.read_text(encoding='utf-8'));assert not (R/'outputs/public13_missing_only_execution_20261021').exists()
    result={'status':'PASS_LABELED_SOFTWARE_AND_SOURCE_CONTRACT_ONLY','checks':checks,'count':len(checks),'pretrained_model_forward_PF_converter_optimizer_training_calls':0,'mock_only_not_performance':True,'worker_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'reader_sha256':hashlib.sha256(reader.read_bytes()).hexdigest(),'state_helper_sha256':hashlib.sha256((R/'work/public13_complete_policy_state_contract_20261021.py').read_bytes()).hexdigest()}
    with (P/args.output).open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print('11LABELED_SOFTWARE_CHECKS_PASS_ZERO_PRETRAINED_OR_PHYSICS_CALLS')
if __name__=='__main__':main()
