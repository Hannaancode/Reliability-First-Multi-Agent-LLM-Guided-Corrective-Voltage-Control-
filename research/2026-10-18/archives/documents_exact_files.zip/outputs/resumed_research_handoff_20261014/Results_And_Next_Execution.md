The direct human resume revokes the earlier pause. No scientific, audit, or archive worker remains. The original full suffix study remains terminal partial; its independent preserved-prefix audit and archive passed.

| Development state | Add-only final UV | Paired-control final UV | New operations, add / paired | Status |
|---|---:|---:|---:|---|
| Line 35, MG1 | 9 | 0 | 3 / 11 | Both branches closed |
| Line 36, MG1 | 21 | 1 | 3 / 19 | Both branches closed |
| Line 84, MG2 | 24 | UNKNOWN | 2 / UNKNOWN | Paired branch unfinished |
| Line 127, MG3 | UNKNOWN | UNKNOWN | UNKNOWN | Both branches unexecuted |

These are all declared development states, without a selected-prefix aggregate. Same total allowed operation limits do not mean identical consumed operations or query costs. The line-36 paired trajectory exhausted its original 25-operation total; reaching zero requires a different legal path, not adding an extra operation to this old trajectory. Raw upper-band counts and the frozen 1e-8 tolerance remain in the recorded metrics. All-four gate UNKNOWN.

Validated LLM superiority over complete literal DFF plus DFF-ALT with FULL BOTH costs remains unachieved. No model ran in this suffix comparison. Relocation is a system-component finding; both model and numerical controls must receive that capability in a future attribution study. Intermediate switching safety and transients are unmeasured.

Next work:
1. Finish a primary-source benchmark registry with exact actuator/state/objective/training/code compatibility; published numerical tables are not matched wins.
2. Specify a materially different global discrete-allocation numerical control using only causal current state and existing exact guidance; same nominal stock, 450 non-refunding cap, original remaining operations, raw scopes, solver and protection.
3. Freeze input identities, surrogate equations, solver budget, unknown classifications and independent saved-result checks before measuring this new numerical mechanism. A linear feasibility result is not nonlinear zero-UV feasibility.
4. Only a surviving mechanism receives separately prospective NEW physical identities and persistent ownership/replay/full costs. Never complete the old partial by restarting it or extending its budget.
5. Retain a separate incremental LLM question against equally capable numerical acquisition/lookahead and trained controls. The failed fixed rich 4096 context and stopped learning arms remain stopped.

Archive and full paid costs are in Verified_Resumed_Research_Checkpoint.json; old failures, sources, pause and closed ownership chains are in Closed_Ownership_And_Pause_Provenance.zip. Reuse certificates; do not rehash completed archives.
