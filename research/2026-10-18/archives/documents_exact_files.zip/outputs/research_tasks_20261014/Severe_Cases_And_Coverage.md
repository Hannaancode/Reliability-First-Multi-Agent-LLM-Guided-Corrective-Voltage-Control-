# Federation coverage and severe cases

118 is the bus count. All 141 recipes are listed in All141_Federation_Case_Status.json; 68 have historical completed log rows and 73 lack a result in that log. No missing outcome was filled or counted as failure. This reuses recorded evidence, with zero new model or PF calls.

| Recipe | Recorded initial UV | Historical final UV |
|---|---:|---:|
| fed_combined_load_1p5_line_101_MG1 | 61 | 21 |
| fed_combined_load_1p5_line_127_MG3 | 55 | 41 |
| fed_combined_load_1p5_line_128_MG3 | 60 | 15 |
| fed_combined_load_1p5_line_129_MG3 | 57 | 3 |
| fed_combined_load_1p5_line_135_MG3 | 58 | 20 |
| fed_combined_load_1p5_line_35_MG1 | 56 | no historical run |
| fed_combined_load_1p5_line_36_MG1 | 58 | no historical run |
| fed_combined_load_1p5_line_84_MG2 | 57 | no historical run |

These are inspected development cases. Stage3 outcomes and unknowns remain distinct from the historical log. Neither source is a complete matched comparison on all 141 recipes. The original sealed 62-case bank is a different bank and will not be regenerated.
