"""Exact prospective engineering inputs; absence alone never authorizes PF."""
import copy,gzip,hashlib,json,os,pickle,time,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from lazy_paid_lineage_receipts_v1_20261018 import ArchivedLineage
from original_local_paid_branch_broker_v1 import resource_eligible
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
from bounded_paid_lookahead_physics_20261014 import load_after
B=R/'outputs/next_exact_paid_query_preparation_20261018'
SOURCE=R/'outputs/unstarted_paid_suffix_support_screen_numeric_v2_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();leg=read(SOURCE/'Leg_1.json');assert leg['status']=='UNKNOWN_UnknownLineageIdentity'
    ref=leg['frontier_input'];raw=(SOURCE/ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['encoded_sha256']
    packet=zlib.decompress(raw);assert hashlib.sha256(packet).hexdigest()==ref['raw_sha256'];d=pickle.loads(packet)
    archive=ArchivedLineage();_,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    domain=build_current_domain(d['net'],d['cursor'],runner=runner,zones=zones);cursor=domain['expanded_cursor_for_separately_fixed_future_protocol']
    point=point_key(d['net'],cursor);assert point+'|'+action_key(d['row'])==d['key'] and resource_eligible(d['row'],cursor)
    assert d['key'] not in archive.index and runner.rescue.grid_metrics(d['net'])['uv_count']>0
    rows=[r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if resource_eligible(r,cursor) and point+'|'+action_key(r) not in archive.index]
    second=next(r for r in sorted(rows,key=action_key) if action_key(r)!=action_key(d['row']))
    candidates=[{'row':d['row'],'point_action_key':d['key'],'role':'WARM_FIRST_REQUIRED_CAUSAL_FRONTIER_QUERY'},
        {'row':second,'point_action_key':point+'|'+action_key(second),'role':'COLD_FIRST_OTHER_HASH_ORDERED_ELIGIBLE_ABSENT_QUERY'}]
    # The current NET must be an actual paid AFTER, not a forecast or a
    # fabricated numeric successor. Locate its parent-edge message exactly.
    edge=None
    with (SOURCE/'scientific.jsonl').open('rb') as f:
        for line in f:
            e=json.loads(line)
            if e['event']=='every_query_receipt_closed_before_more_science' and e['data'].get('successor')==d['parent']:
                assert edge is None;edge=e['data']
    assert edge is not None and edge['record']['after_reference'] is not None
    with (SOURCE/'capsules.bin').open('rb') as pack:actual=load_after(edge['record']['after_reference'],pack)['net']
    for table in ['bus','load','line','gen','shunt','res_bus']:assert actual[table].equals(d['net'][table]),table
    for table in ['bus','gen','branch']:assert actual['_ppc'][table].tobytes()==d['net']['_ppc'][table].tobytes(),table
    fresh=read(R/'outputs/fresh_root_query_nonoverlap_20261018/Independent_Audit.json');assert fresh['status'].startswith('PASS_ALL_PRIOR_')
    assert len(actual.shunt)>fresh['maximum_prior_observed_shunt_rows']
    put(B/'Exact_Candidate_Inputs.json',{'status':'PREPARED_INPUTS_NOT_PF_PERMISSION','world':leg['world'],'method':leg['method'],'parent_handle':d['parent'],
        'observed_current_metrics':runner.rescue.grid_metrics(actual),'physical_shunt_rows':len(actual.shunt),'point':point,'exact_new_query_rows':candidates,
        'eligible_absent_in_60377_lineage_keys':len(rows),'actual_paid_AFTER_reference':edge['record']['after_reference'],
        'actual_paid_AFTER_source_receipt':edge['record'].get('source_original_receipt_id',edge['record']['receipt_id']),
        'source_frontier_sha256':sha(SOURCE/ref['path']),'source_journal_sha256':sha(SOURCE/'scientific.jsonl'),
        'native_ref_PV_PQ_and_case_exact':True,'cursor_role':'Source-paid hypothetical branch projection, not actual newly committed deployment/trajectory; original25ops/cap450/no-refund/ownedstock unchanged',
        'remaining_original_operations':cursor['remaining_original_device_operation_slots'],'new_model_PF_derivative_forecast_solve_calls':0,
        'fresh_root_disjoint_physical_cardinality':True,'coverage_status':'UNKNOWN_UNTIL_INDEPENDENT_RELEVANT_LINEAGE_CLASSIFICATION_AND_SOURCE_LOCK',
        'next_gate':'Independent exact attempted-key closure/classification of all recognized PF source lineages, source/nativeverifier/cold preservation/reader protocol and fresh ownership before any native call. Existing Mock reservation tests are not execution authority.',
        'prohibited':'No queries at previously prepared UV0terminal; no old-owner resume, old-budget extension, repeated old identity or selected performance claim.',
        'workflow_seconds':time.perf_counter()-started})
    # Preserve the exact complete causal current NET/cursor as an engineering
    # input. A new engineering seed/cursor is separate from missing old RNG.
    payload={'net':actual,'cursor':cursor,'source_paid_branch_projection_not_new_commit':True,'source_edge':edge}
    encoded=zlib.compress(pickle.dumps(payload,protocol=5),6)
    with (B/'Exact_Current_Input.zlib').open('xb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
    manifest(B);print(json.dumps({'exact_two_query_inputs':'PREPARED_NOT_AUTHORIZED','current_UV':runner.rescue.grid_metrics(actual)['uv_count'],'new_science':0}))
if __name__=='__main__':main()
