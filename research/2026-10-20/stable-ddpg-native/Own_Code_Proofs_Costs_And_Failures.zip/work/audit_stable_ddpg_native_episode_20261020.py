"""One separate source-bound replay owner; every new learned policy and unique physics call charged."""
import os,time,json
from datetime import datetime,timezone
from stable_ddpg_native_episode_engine_20261020 import execute,sha,put,PRIMARY
OUT=PRIMARY/'independent_audit'
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    a=json.loads((OUT/'Launcher_ACK.json').read_text(encoding='utf-8'));assert a['actual_pid']==os.getpid() and a['actual_parent_pid']==os.getppid() and a['fresh_exact_source_PID_parent_command']
    import stable_ddpg_native_bridge_20261020 as b
    np=b.np;p=json.loads((PRIMARY/'Result.json').read_text(encoding='utf-8'));manifest=json.loads((PRIMARY/'Closed_Manifest.json').read_text(encoding='utf-8'))
    for f in manifest['files']:assert sha(PRIMARY/f['path'])==f['sha256'] and (PRIMARY/f['path']).stat().st_size==f['bytes']
    r=execute(OUT,'independent_replay')
    assert p['steps']==r['steps'] and p['endpoints']==r['endpoints']
    assert len(p['receipts'])==len(r['receipts']);maximum=0.
    for index in range(p['costs']['PF_returns']):
        original=np.load(PRIMARY/'physics'/f'PF{index:03d}_fields.npz');replay=np.load(OUT/'physics'/f'PF{index:03d}_fields.npz');assert set(original.files)==set(replay.files)
        for name in original.files:
            x=original[name];y=replay[name];assert np.allclose(x,y,rtol=0,atol=1e-9,equal_nan=True);finite=np.isfinite(x)&np.isfinite(y)
            if finite.any():maximum=max(maximum,float(np.max(np.abs(x[finite]-y[finite]))))
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL3_NATIVE100HORIZON_SUFFIXES_EVERY_RAW_POLICY_ACTION_CONTINUOUS_PHYSICS_CHECKPOINT_COST_AND_FULL_FIELDS','source_costs':p['costs'],'actual_independent_costs':r['costs'],'all_new_steps':len(p['steps']),'endpoints':p['endpoints'],'all_numeric_replay_field_delta':maximum,'retained_prior_costs':p['retained_original_costs'],'our_LLM_or_aggregate_superiority_claim':False,'workflow_seconds':time.monotonic()-start}
    put(OUT/'Independent_Audit.json',result);print(json.dumps({'independent':'PASS','steps':len(p['steps']),'endpoints':[{k:e[k] for k in ['algorithm','completed_original_steps','all_bus_UV','all_bus_OV']} for e in p['endpoints']],'field_delta':maximum,'reader_costs':r['costs']}))
if __name__=='__main__':main()
