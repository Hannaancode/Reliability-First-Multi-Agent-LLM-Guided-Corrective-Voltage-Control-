"""New actual environment admission: imports/process/clock only, no science."""
from pathlib import Path
from datetime import datetime,timezone
import sys,os,json,hashlib,time,importlib
R=Path(__file__).resolve().parents[1];D=R/'work/owner_runtime_dependencies_20261030';O=R/'outputs/nonlinear500_actual_runtime_admission_20261030'
sys.path.insert(0,str(D))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 start=time.monotonic();O.mkdir(exist_ok=False)
 wheel=R/'work/owner_runtime_wheels_20261030/psutil-7.2.2-cp37-abi3-win_amd64.whl'
 assert sha(wheel)=='eb7e81434c8d223ec4a219b5fc1c47d0417b12be7ea866e24fb5ad6e84b3d988'
 versions={}
 for name in ['numpy','pandas','scipy','scipy.optimize._slsqp_py','scipy.optimize._slsqplib','psutil']:
  m=importlib.import_module(name);versions[name]={'file':m.__file__,'version':getattr(m,'__version__',None),'sha256':sha(m.__file__)}
 import psutil
 assert psutil.__version__=='7.2.2' and Path(psutil.__file__).resolve().is_relative_to(D.resolve())
 process=psutil.Process();assert process.pid==os.getpid() and process.ppid()==os.getppid()
 from nonlinear13_receding_policy_engine_v2_20261030 import clock_domain
 from run_nonlinear500_receding_acquisition_20261030 import windows_arguments
 clock1=clock_domain();clock2=clock_domain();assert clock1==clock2
 import subprocess
 assert windows_arguments(subprocess.list2cmdline(process.cmdline()))==process.cmdline()
 modules=['nonlinear13_current_state_v2_20261030','nonlinear13_math_receipt_bank_20261030',
  'nonlinear13_receding_acquisition_engine_20261030','nonlinear13_saved_math_reader_20261030',
  'nonlinear13_acquisition_reader_20261030','audit_nonlinear500_receding_acquisition_20261030']
 imported={name:sha(importlib.import_module(name).__file__) for name in modules}
 files={p.relative_to(R).as_posix():sha(p) for p in sorted(D.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.pyd')}
 result=dict(status='PASS_NEW_ACTUAL_RUNTIME_IMPORT_PROCESS_CLOCK_ADMISSION_ONLY',at_utc=datetime.now(timezone.utc).isoformat(),
  python=sys.version,executable=sys.executable,actual_pid=os.getpid(),actual_parent_pid=os.getppid(),
  clock_domain=clock1,clock_stable_in_process=True,exact_command_parser_roundtrip=True,imports=versions,local_modules=imported,
  isolated_dependency_sources=files,official_wheel_sha256=sha(wheel),workflow_seconds=time.monotonic()-start,
  old_physics_environment_modified=False,new_optimizer_PF_model_equation_derivative_calls=0,
  old_NETs_NPZs_calculation_journals_or_fixtures_read=0,
  previous_failed_setup_preserved=True,
  limits='Actual imports/clock/process admission only; no actual experiment owner, policy, optimizer or PF has been executed by this check.')
 with (O/'Result.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
 print(json.dumps({'status':result['status'],'isolated_runtime_files':len(files),'new_science':0}))
if __name__=='__main__':main()
