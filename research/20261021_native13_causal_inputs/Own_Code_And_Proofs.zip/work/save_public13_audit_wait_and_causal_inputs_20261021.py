"""Save verified primary closure, live-reader wait and software-only port work."""
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/public13_matched_numeric_audit_wait_20261021'
S = R / 'outputs/paper_native13_causal_contract_v3_20261021'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    O.mkdir(exist_ok=False)
    now = datetime.now(timezone.utc).isoformat()
    end = read(R / 'outputs/public13_matched_numeric_coordination_20261021/End_ACK.json')
    assert end['actual_owned_chain_ended'] and end['exit_code'] == 0
    software = read(S / 'Software_Input_Admission.json')
    audit = read(S / 'independent_input_audit/Independent_Input_Audit.json')
    assert software['status'].startswith('PASS_') and audit['status'].startswith('PASS_')
    assert sha(S / 'Software_Input_Admission.json') == audit['admission_sha256']
    assert sha(S / 'All500_Initial_Causal_Frames.json') == audit['all500_frames_sha256']
    assert sha(S / 'All500_Physical_Role_Contracts.json') == audit['all500_contracts_sha256']
    actors = []
    for directory, live in [('public13_matched_numeric_execution_20261021', False),
                            ('public13_matched_numeric_independent_20261021', True),
                            ('public13_matched_numeric_handoff_20261021', True)]:
        claim = read(R / 'outputs' / directory / 'owner.claim')
        actors.append({'output': 'outputs/' + directory, **claim,
                       'matching_owned_source_live_at_last_observation': live,
                       'exact_PID_parent_command_source_verified_at_UTC': '2026-10-21T19:34:37+00:00'})
    checkpoint = {'at_utc': now, 'status': 'PRIMARY_ALL500_COMPLETE_SOLE_INDEPENDENT_READER_LIVE_COMPARISON_PENDING',
                  'actors': actors, 'primary_End_ACK': end, 'exec_session': 39727,
                  'reader_fixed_science_seconds': 7200, 'reader_fixed_process_seconds': 7500,
                  'reader_started_at_utc': actors[1]['at_utc'],
                  'last_observed_reader_progress': {'seed': 249, 'step': 73, 'elapsed_seconds': 2787.7179999999935},
                  'progress_is_not_independent_completion': True,
                  'next_check_Asia_Qatar': '2026-10-21 23:10',
                  'waiting_automation_id': 'hiergrid-matched-numerical-benchmark-result-check',
                  'waiting_policy': 'One estimated check only; rearm if exact owned actor is live; delete at actual terminal. No recurring monitor.',
                  'comparison_lock': 'outputs/public13_matched_numeric_preparation_20261021/Comparison_Analysis_Lock.json',
                  'comparison_source': 'work/compare_closed_public13_numeric_and_published_20261021.py',
                  'comparison_source_sha256': '8e6adeeea2f105e4a2127cca1df0c2831df0dddfa17ae3c1fc966bc3ace130cc',
                  'comparison_output': 'outputs/public13_matched_numeric_comparison_20261021',
                  'next': 'Only after actual primary/reader/coordinator end, exit0, independentPASS, Result and closed manifests, run locked comparison once if absent. Strict near-boundary failures remain failures. No outcome rescue.',
                  'new_input_contract': str(S.relative_to(R)).replace('\\', '/'),
                  'new_input_contract_scope': 'All500 causal initial inputs/action support software only; no actual inference/full paper policy/physics admission.',
                  'all6goals': 'OPEN', 'no_new_GPU_model_PF_training_call_by_this_continuation': True}
    write(O / 'Current_Wait_And_Resume.json', checkpoint)
    bundle = {'software_admission': software, 'independent_saved_input_audit': audit,
              'scope': 'Not independently retokenized, complete controller, process recovery, model performance or physics.',
              'old_software_failures': [read(R / f'outputs/{n}/Failure.json') for n in
                                       ['paper_native13_causal_contract_20261021', 'paper_native13_causal_contract_v2_20261021']]}
    write(O / 'Verified_Native13_Input_Contract.json', bundle)
    p = R / 'outputs/full_system_comparison_20261021/Current_Resume.json'
    state = read(p)
    state.update(at_utc=now, status=checkpoint['status'], current_single_scientific_owner=None,
                 current_single_independent_reader=actors[1], current_sole_coordinator=actors[2],
                 latest_closed_numerical_primary=actors[0],
                 current_wait_and_resume=O.relative_to(R).as_posix() + '/Current_Wait_And_Resume.json',
                 current_waiting_check=checkpoint['waiting_automation_id'],
                 next_dependency='Actual sole numerical reader closure and independentPASS; primary complete. No paired score before closure.',
                 new_native13_input_contract=O.relative_to(R).as_posix() + '/Verified_Native13_Input_Contract.json',
                 timers=[{'id': checkpoint['waiting_automation_id'], 'type': 'ONE_TIME_ESTIMATED_RESULT_CHECK',
                          'Asia_Qatar': checkpoint['next_check_Asia_Qatar'], 'delete_at_terminal': True}])
    state['next_ordered_tasks'] = [checkpoint['next'],
        'Keep unmodified published primary rows and all500 cases; full13 strict endpoint, paired frozen tests, complete costs. NUM has extra global information; no LLM attribution.',
        'Complete explicitly named whole original-paper/native-role router/refinement/fallback/feedback/two-branch port and strong controls before prospective actual model integration; software success alone permits no GPU/performance launch.',
        'Preserve old source/claims/failures and completed independent phases. A failed fixed numerical gate stops that intervention, with no LP/guard/epsilon/horizon rescue.',
        'Save meaningful closed results and compact code/proofs with GitHub lease and downloaded-byte checks; private/raw assets remain local.']
    if 'missing_only_prospective_study' in state:
        state['missing_only_prospective_study']['status'] = 'COMPLETE_ALL1013_INDEPENDENT_PASS_PREVIOUSLY_REPORTED'
    write(p, state)
    tasks_path = R / 'outputs/research_tasks_20261014/Tasks.json'
    tasks = read(tasks_path)
    tasks.update(updated_at_utc=now, latest_resume=p.relative_to(R).as_posix())
    g3 = next(t for t in tasks['tasks'] if t['checklist_id'] == 'G3')
    g3['status'] = checkpoint['status']
    g3['current_result'] = 'All500 numerical primary complete; independent sole reader live, paired performance pending. Native13 positive-only causal input software and saved-input audit PASS, zero model/PF; whole paper policy not ready.'
    task_id = 'G3.2y_20261021'
    assert not any(s['id'] == task_id for s in g3['subtasks'])
    g3['subtasks'].append({'id': task_id, 'completed': True,
                         'description': 'Bind all500 saved native13 roots to four topology-only roles, positive literal native increments and causal initial input packets; saved-input source/namespace audit PASS. Software only; no whole policy, inference or physics claim.',
                         'evidence': (S / 'independent_input_audit/Independent_Input_Audit.json').relative_to(R).as_posix(),
                         'verified_at_save': now})
    write(tasks_path, tasks)
    latest = R / 'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json'
    data = read(latest)
    data.update(updated_at_utc=now, status=checkpoint['status'], current_single_scientific_owner=None,
                current_single_independent_reader=actors[1], current_sole_coordinator=actors[2],
                current_waiting_check=checkpoint['waiting_automation_id'], latest_resume=p.relative_to(R).as_posix())
    write(latest, data)
    note = f'''## All500 numerical primary closed; independent audit pending — {now}

The frozen numerical scientist ended exit0 after all500 episodes. Its sole independent reader24388/18264 and coordinator27116/25120 remain source/command/claim verified live. The reader's observed source-order seed249 is progress only. No paired performance or winning claim is available until actual independent closure. Settings, strict scores, bounds and all failed/near-boundary outcomes remain unchanged. No GPU/model/training was started.

Parallel native13 causal input/action contract and saved-input audit passed across500 roots/2000 zone frames:696 available model-input prefixes,232 empty-actuator-zone skips,1072 original-UV-stop frames; max566 tokens, no truncation. This named positive-only native-unit/four-role port is software only, not the complete original paper controller or actual inference. Empty saved internalY and a mistaken software test against the original first-recipient parser semantics are preserved. Lost696 earlier software encodings/preparation remain separately paid; no scientific call repeated. The eventual runtime must retain raw and normalized outputs and independently anchor real feedback.

One estimated follow-up is set for23:10Asia/Qatar today; rearm only for confirmed live ownership and delete at terminal. Resume outputs/public13_matched_numeric_audit_wait_20261021/Current_Wait_And_Resume.json. All six final goals remain OPEN.

'''
    for name in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        f = R / name
        f.write_bytes(note.encode('utf-8') + f.read_bytes())
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n' + note)
    pub = O / 'publication'
    pub.mkdir()
    (pub / 'README.md').write_text(note + '\nThis compact publication is own code/proofs, not a raw model/NET/checkpoint backup. The 500-case paired performance is pending, not an LLM superiority result.\n', encoding='utf-8')
    shutil.copyfile(O / 'Current_Wait_And_Resume.json', pub / 'Audit_Wait_Checkpoint.json')
    shutil.copyfile(O / 'Verified_Native13_Input_Contract.json', pub / 'Native13_Input_Contract_And_Audit.json')
    shutil.copyfile(p, pub / 'Current_Resume.json')
    shutil.copyfile(tasks_path, pub / 'Task_Progress.json')
    paths = [R / 'work' / name for name in [
        'paper_native13_causal_contract_20261021.py',
        'paper_native13_causal_contract_v2_20261021.py',
        'prepare_paper_native13_causal_contract_20261021.py',
        'prepare_paper_native13_causal_contract_v2_20261021.py',
        'prepare_paper_native13_causal_contract_v3_20261021.py',
        'audit_paper_native13_causal_contract_v3_20261021.py',
        'save_public13_audit_wait_and_causal_inputs_20261021.py']]
    paths += [S / 'Software_Input_Admission.json', S / 'independent_input_audit/Independent_Input_Audit.json']
    paths += [R / f'outputs/{n}/Failure.json' for n in ['paper_native13_causal_contract_20261021', 'paper_native13_causal_contract_v2_20261021']]
    inventory = [{'path': f.relative_to(R).as_posix(), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in paths]
    archive = pub / 'Own_Code_And_Proofs.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for f in paths:
            z.write(f, f.relative_to(R).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.infolist()) == len(inventory)
        for row in inventory:
            assert hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256']
    write(pub / 'Evidence_Manifest.json', {'at_utc': now, 'files': inventory,
          'archive': {'members': len(inventory), 'bytes': archive.stat().st_size,
                      'sha256': sha(archive), 'CRC_and_all_member_hashes': 'PASS'},
          'actual_all500_inputs_local_only': audit['all500_frames_sha256'],
          'new_scientific_calls': 0, 'not_complete_raw_backup': True})
    print(json.dumps({'saved': O.relative_to(R).as_posix(), 'archive_members': len(inventory),
                      'archive_bytes': archive.stat().st_size, 'all6goals': 'OPEN'}))


if __name__ == '__main__':
    main()
