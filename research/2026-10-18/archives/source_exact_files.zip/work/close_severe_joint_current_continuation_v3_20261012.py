"""Mechanical closure after the real child exit; never relaunches scientific code."""
import hashlib,json,os,re,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
from prepare_and_run_severe_joint_current_engineering_20261012 import process,put

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/severe_joint_current_engineering_continuation_v2_20261012'
read=lambda p:json.loads(p.read_text('utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert not (BASE/'Owner_End_ACK.json').exists() and not (BASE/'cold_reader').exists()
    claim=read(BASE/'actual/owner.claim');ack=read(BASE/'actual/Launcher_ACK.json');coord=read(BASE/'coordinator.claim')
    assert all(process(i) is None for i in (claim['actual_pid'],ack['launcher_pid'],coord['actual_pid']))
    completion=read(BASE/'actual/Completion.json');assert completion['exit_code']==0 and completion['actual_pid']==claim['actual_pid']
    p=read(BASE/'preparation/Protocol.json');assert datetime.fromisoformat(completion['ended_at_utc'])<datetime.fromisoformat(p['absolute_deadline_utc'])
    m=read(BASE/'actual/Closed_Manifest.json');assert m['exit_code']==0
    result=read(BASE/'actual/Result.json');assert result['exit_code']==0 and result['actual_costs']['PF_returns']==20
    creation=ack['launcher_process']['CreationDate'];now=datetime.now(timezone.utc)
    if creation.startswith('/Date('):started=datetime.fromtimestamp(int(re.search(r'-?\d+',creation).group())/1000,timezone.utc)
    else:started=datetime.fromisoformat(creation)
    charge=(now-started).total_seconds();assert charge>=result['owned_seconds_before_closure']
    qualifier={'mechanical_failure':'Original coordinator exited at immediate post-Popen actual-descendant alive assertion; fresh exact CIM now proves actual/launcher/coordinator absent.',
        'old_coordinator_source_and_failure_preserved':True,'old_coordinator_source_sha256':coord['source_sha256'],
        'all20scientific_returns_and_manifest_retained':True,'new_physics_model_optimizer_calls':0,
        'exact_replay_owner_total_latency':'UNKNOWN; collector stopped before recording its end interval',
        'source_observed_owned_seconds_before_final_manifest':result['owned_seconds_before_closure'],
        'charged_conservative_wall_upper_bound_including_external_end_observation':charge,
        'upper_bound_is_not_intrinsic_solver_or_deployment_latency':True,'observed_end_at_utc':now.isoformat(),
        'repair_source_sha256':sha(Path(__file__))}
    put(BASE/'Closure_Repair_And_Cost_Qualification.json',qualifier)
    put(BASE/'Owner_End_ACK.json',{'actual_pid':claim['actual_pid'],'launcher_pid':ack['launcher_pid'],'returncode':0,
        'closed_manifest_sha256':sha(BASE/'actual/Closed_Manifest.json'),'whole_owned_seconds':charge,
        'whole_owned_seconds_is_conservative_observation_upper_bound':True,'exact_actual_owned_seconds':'UNKNOWN',
        'complete_closure_and_exit_charged':True,'fresh_actual_launcher_coordinator_CIM_absent':True})
    begun=time.perf_counter()
    with (BASE/'Reader_stdout.log').open('x',encoding='utf-8') as log:
        reader=subprocess.Popen([str(ROOT/'work/physics_env/Scripts/python.exe'),'-X','utf8',
            str(ROOT/'work/read_severe_joint_current_replay_v2_20261012.py')],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        reader.wait()
    put(BASE/'Reader_End_ACK.json',{'launcher_pid':reader.pid,'exit_code':reader.returncode,'whole_reader_seconds_including_output_exit':time.perf_counter()-begun,
        'source_runtime_and_physics_checks_unchanged':True,'replay_owner_wall_cost_scope':qualifier,
        'science_relaunch_or_repetition':False})
    print(json.dumps({'cold_reader_exit':reader.returncode,'scientific_owner_restarted':False,'exact_science_whole_latency':'UNKNOWN','charged_upper_bound_seconds':charge}))

if __name__=='__main__':main()
