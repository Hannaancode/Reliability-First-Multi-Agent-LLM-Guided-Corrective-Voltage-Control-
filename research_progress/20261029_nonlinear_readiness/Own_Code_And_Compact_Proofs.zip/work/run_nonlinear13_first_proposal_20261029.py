"""One prospective first-entry numerical proposal; no PF or control commit.

The source-order first case0 is fixed before execution. Its new proposal/math
receipt must be reused by any later identical full-cohort controller, never
recomputed as a free engineering trial. No optimizer retry or adaptive setting.
"""
from pathlib import Path
from datetime import datetime,timezone
import os,json,time,hashlib,pickle,random,traceback
import numpy as np
R=Path(__file__).resolve().parents[1];P=R/'outputs/nonlinear13_first_proposal_preparation_20261029';O=R/'outputs/nonlinear13_first_proposal_execution_20261029'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    from nonlinear13_preserved_solver_v3_20261029 import serial
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2,default=serial,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    began=time.monotonic();O.mkdir(exist_ok=False)
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),at_utc=datetime.now(timezone.utc).isoformat()))
    while not (O/'Launcher_ACK.json').exists():
        if time.monotonic()-began>60:raise TimeoutError('No exact owner ACK; no science entered')
        time.sleep(.1)
    p=json.loads((P/'Protocol.json').read_text(encoding='utf-8'));deadline=began+p['science_seconds']
    ack=json.loads((O/'Launcher_ACK.json').read_text(encoding='utf-8'));assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    for rel,h in p['sources_and_gates'].items():assert sha(R/rel)==h,rel
    from remaining85_certified_loader_20261029 import load_certified_case
    from nonlinear13_preserved_solver_v3_20261029 import solve_once,PersistentCalculationJournal,RECIPE
    assert p['recipe']==RECIPE and p['seed']==0
    from candidate_process_evidence_utils import frozen_checks
    put(O/'Frozen_Before.json',frozen_checks())
    model,binding=load_certified_case(R,0);binding['all_required_current_state_checks_passed']=True
    assert binding['pack']==p['input_pack'] and binding['root']==p['input_root']
    random.seed(p['rng_seed']);np.random.seed(p['rng_seed'])
    cursor=dict(seed=0,step=1,remaining_horizon=100,history=[],current_input=binding,
      python_rng=random.getstate(),numpy_rng=np.random.get_state(),absolute_deadline_monotonic=deadline,
      recipe=RECIPE.copy(),model_costs=model.costs.copy(),protocol_sha256=sha(P/'Protocol.json'))
    raw=pickle.dumps(cursor,protocol=5)
    with (O/'Complete_Pre_Proposal_Cursor.pkl').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    cold=pickle.loads((O/'Complete_Pre_Proposal_Cursor.pkl').read_bytes())
    coldmodel,coldbinding=load_certified_case(R,cold['seed'])
    for name in ['Y','V_current','ppc_bus','ppc_gen','lookup','control','current_vm','current_q','injection0']:
        assert np.array_equal(getattr(model,name),getattr(coldmodel,name)),name
    assert cold['absolute_deadline_monotonic']==deadline and not coldmodel.costs and cold['history']==[]
    put(O/'Cold_Pre_Proposal_Check.json',dict(status='PASS_EXACT_STATE_RECONSTRUCTION_ZERO_SOLVER_CALLS',cursor_sha256=sha(O/'Complete_Pre_Proposal_Cursor.pkl'),source_input_binding=binding,new_optimizer_PF_model_calls=0))
    journal=PersistentCalculationJournal(O/'calculations.jsonl',deadline,p['journal_byte_cap']);result=None;failure=None
    try:
        result=solve_once(model,journal,binding)
        put(O/'Proposal_Result.json',result)
    except BaseException as exc:
        failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),model_costs=model.costs.copy())
        put(O/'Failure.json',failure)
    finally:journal.close()
    status='COMPLETE_FIRST_NUMERICAL_PROPOSAL_ONLY' if result and result['status']=='ADMITTED_UNMEASURED_PROPOSAL' else 'TERMINAL_FIRST_PROPOSAL_FAILURE_NO_RETRY'
    put(O/'Result.json',dict(status=status,at_utc=datetime.now(timezone.utc).isoformat(),seed=0,proposal_status=None if result is None else result['status'],
      workflow_seconds=time.monotonic()-began,science_seconds=p['science_seconds'],journal_bytes=journal.bytes,journal_events=journal.calls,journal_last_sha256=journal.previous,
      kernel_costs=model.costs.copy(),failure=failure,physical_calls=0,model_calls=0,GPU_calls=0,actual_control_commits=0,
      interpretation='One new numerical proposal for source-order seed0. No returned physical outcome, whole-episode score or restoration claim. Preserve/reuse exact math receipt in a future identical owner.'))
    put(O/'Frozen_After.json',frozen_checks())
    put(O/'Closed_Manifest.json',dict(files=[dict(path=f.relative_to(O).as_posix(),bytes=f.stat().st_size,sha256=sha(f)) for f in O.iterdir() if f.is_file()]))
    print(status)
if __name__=='__main__':main()
