"""Administrator-only source-latched projections of completed forecasts.

Policies must never receive this loader, original record or administrator.
"""
from pathlib import Path
from candidate_process_evidence_utils import read, sha
from paid_feedback_acquisition_control import FIELDS, VARIANTS

P = 'outputs/llm_value_relational_adaptation_research_20261009'
DATA_FILES = tuple(P + '/' + n for n in (
    'nnrank2/Actual_State_File_Index.json', 'nnrank2/Supplement_Manifest.json',
    'native_unexecuted_measurement/Actual_State_File_Index.json', 'native_unexecuted_measurement/Supplement_Manifest.json',
    'native_unexecuted_measurement_audit/Independent_New_Equations_and_Union_Audit.json'))


def load_priors(root, inputs, counters):
    root = Path(root); old = root/P/'nnrank2'; new = root/P/'native_unexecuted_measurement'
    certificate = read(root/DATA_FILES[-1]); assert certificate['all_passed'] and certificate['no_old_forecast_replaced_or_repeated']
    old_manifest = read(old/'Supplement_Manifest.json'); new_manifest = read(new/'Supplement_Manifest.json')
    new_index = {x['state_index']: x for x in read(new/'Actual_State_File_Index.json')}
    result = {}; native_records = 0; unavailable = 0
    for ix in read(old/'Actual_State_File_Index.json'):
        oid = ix['observation_id']; assert oid in inputs and oid not in result
        path = old/ix['record_file']; assert sha(path) == ix['sha256'] == old_manifest[ix['record_file']]['sha256']
        record = read(path); counters['prior_record_files_read'] += 1
        assert record['observation_id'] == oid and record['model_input_sha256'] == inputs[oid]['model_input_sha256']
        assert record['world_sha256'] == inputs[oid]['world_sha256'] and record['split'] == 'optimization'
        replacements = {}
        if ix['state_index'] in new_index:
            ni = new_index[ix['state_index']]; path = new/ni['record_file']
            assert ni['observation_id'] == oid and sha(path) == ni['sha256'] == new_manifest[ni['record_file']]['sha256']
            new_record = read(path); counters['prior_record_files_read'] += 1
            assert new_record['prior_record_sha256'] == ix['sha256'] and new_record['observation_id'] == oid
            for item in new_record['records']:
                key = item['action_index'], item['arm']; assert key not in replacements
                replacements[key] = item
        projection = {}; used = set()
        for variant in VARIANTS:
            values = []
            for i, item in enumerate(record['arms'][variant]):
                key = i, variant
                if key in replacements:
                    assert item['record_kind'] == 'unexecuted' and not item['steps'] and item['final_vm_key'] is None
                    replacement = replacements[key]; assert replacement['native_action'] == item['native_action']
                    item = replacement; used.add(key)
                b, j = item['native_action']; prediction = item['prediction']; native_records += 1
                assert [b, j] == record['allowed_actions'][i]
                metrics = prediction.get('estimated_after_metrics') if prediction['status'] == 'finite_linear_forecast' else None
                if metrics is None: unavailable += 1
                values.append({'bus': b, 'Q_index': j, 'metrics': {f: metrics[f] for f in FIELDS} if metrics else None,
                               'native_nonlinear_convergence': None})
            projection[variant] = values
        assert used == set(replacements)
        result[oid] = projection
    assert set(result) == set(inputs) and native_records == 77002 and unavailable == 178
    counters.update(prior_native_arm_records=native_records, unavailable_prior_records=unavailable)
    return result
