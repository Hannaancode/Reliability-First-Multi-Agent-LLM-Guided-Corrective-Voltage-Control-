# Critical design gate for a language-policy correction

This is a hypothesis and algebra review, not a frozen training experiment. The full native numerical comparison is running; it must finish with its actual failures and costs before a different learning intervention is justified. All stopped methods remain stopped.

## What prior research already establishes

[Rafailov et al., DPO](https://arxiv.org/html/2305.18290v3) optimizes policy-to-reference log-likelihood differences from paired preferences under a specified preference model. Thus a learned likelihood ratio is established machinery, not our new contribution. Its text-task results do not prove grid recovery, superiority to D-SE, or safety under our sparse deterministic labels.

[Silver et al., Residual Policy Learning](https://arxiv.org/abs/1812.06298) already learns corrections to imperfect hand-designed or model-predictive controllers in robotic tasks. Adding a learned correction to a numerical controller is therefore not novel by itself. Its online RL setting also differs from our saved one-step labels.

[Laroche et al., SPIBB](https://proceedings.mlr.press/v97/laroche19a.html) studies baseline-constrained improvement from offline trajectories, including a variant with theoretical guarantees. We cannot import that guarantee: our repeated state/action labels are clustered development observations, not a demonstrated MDP sample model with certified uncertainty. Unmeasured actions and missing episode outcomes remain unknown.

[Liu et al., Understanding Reference Policies in DPO](https://aclanthology.org/anthology-files/pdf/naacl/2025.naacl-findings.447.pdf) analyzes reference-policy dependence and reports sensitivity to regularization and model compatibility. Correct implicit reward ordering need not imply correct raw-policy ordering. Consequently a different decoder/reference combination requires direct action-quality evaluation, not a training-loss claim. This evidence is a reason to freeze one justified setting and retain failures, not a license for parameter sweeps.

The closest grid precedent and its limitations are recorded in Native_Preference_Adaptation_Critical_Review.md. Physics-derived DPO labels for grid actions already exist. No90%success expectation or novelty claim follows from combining these papers.

## A possible mechanism and its exact limit

Let A(s) be the finite raw-scope-and-cap-valid action set. Suppose a separately defined numerical distribution pN(a|s) is positive and reproduces the numerical ranking. Let ellTheta and ellRef denote log-likelihoods of the same canonical action string under a trainable copied language policy and its frozen reference. A possible composite policy is

    pComposite(a|s) proportional to pN(a|s) * exp(ellTheta(a|s) - ellRef(a|s)).

At identical initialization, the likelihood difference is zero for every action. Normalization then returns pComposite=pN exactly in mathematical arithmetic. This is an initialization identity, not an improvement theorem. Actual CUDA/tokenization/context/cache/dropout/adapter behavior would still need a genuine numerical gate. Unknown numerical actions cannot be assigned invented outcomes to define the prior.

There is a further limitation: standard DPO on this composite policy relative to pN cancels the numerical prior between a preferred and dispreferred action. The training margin becomes the difference of the two language likelihood ratios. Merely changing decoding would not make the training loss focus on numerical errors. A prior-margin offset would change the preference model or reference; it cannot be asserted equivalent, novel or effective without a derivation and controlled evaluation. This prevents presenting a product formula as a fully designed scientific method.

## What verification can and cannot guarantee

If an admitted numerical incumbent action is physically evaluated at exactly the same current state and included in a candidate set, choosing the maximum original score among admitted candidates cannot have a lower *one-step score* than that incumbent. This follows from set inclusion. It is ordinary verified selection, not an LLM improvement proof. It charges the incumbent's actual solve, requires a valid incumbent and says nothing about terminal recovery, optimum, unmeasured operating limits or efficiency. A better immediate action can still lead to a worse later trajectory.

Compare learned proposals with numerical proposals at the same proposal/verification budget, alongside original full D-SE with both branch costs. Otherwise extra solves, the guard or a smaller search budget could explain the apparent gain. The original full-search one-step selector may already maximize its searched score; a one-step imitation target principally offers an acquisition/efficiency hypothesis, not guaranteed higher endpoint quality.

## Evidence needed before training

First finish the strong native numerical ranking and retain both derivative variants, every K/world/rejection/unknown result and all costs. The existing11,884 pairs were already used in a failed intervention; they are not new evidence or independent samples. A new language-native policy would require an outcome-independent objective/decoder/reference definition, actual frozen-tokenizer context checks, same-information numerical preference learning, frozen-reference and pretraining/architecture controls, immutable initialization/final-checkpoint rules, genuine gradient/checkpoint integration and complete failure denominators. No new GPU launch is authorized merely by this design sketch.

Pure factor/solve latency was not separately timed in the current numerical owner; its measured workflow includes journaling, storage and hashing. Counts or OS CPU snapshots cannot establish deployment latency superiority. Any later efficiency claim requires a prospectively instrumented matched workflow, including model preparation, training, fresh inference and failures.

Positive development ranking would permit only a separately prospective fresh physical attribution study and genuinely unused confirmation. Until that evidence exists, validated LLM contribution, novelty, D-SE superiority and full security remain unachieved.
