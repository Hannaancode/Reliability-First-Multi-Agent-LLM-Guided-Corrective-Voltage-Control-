"""Provider adapter for paid-prefix reconstruction before an unentered suffix.

No model or solver is owned here. Live providers are mandatory explicit inputs;
the original pending controller frame must match before either is reachable.
"""
import copy
import hashlib
import inspect
import random
from reflection118_remaining_cases_v2_core_20261023 import (
    R, read, saved_net, frames_equal, restore_exact, failure_message,
    checkpoint_equal, decode)


class OriginalMissingSuffix:
    def __init__(self, case_index, reflection, new_model, new_physics):
        if case_index not in (1,3):
            raise ValueError('Only the two interrupted registered cases are admitted')
        self.index=case_index;self.reflection=reflection
        self.new_model=new_model;self.new_physics=new_physics
        self.host=R/'outputs/reflection118_remaining_cases_v2_execution_20261023'/f'case_{case_index:02d}'
        proof=read(R/'outputs/pending_source_state_20261028/verify'/f'case_{case_index:02d}'/'Cold_State_Check.json')
        assert proof['status']=='PASS_EXACT_PENDING_NET_HISTORY_FEEDBACK_FAILURE_RNG_REQUEST_CURSORS'
        audit=read(R/'outputs/reflection118_remaining_cases_v2_independent_20261023'/f'case_{case_index:02d}'/'Independent_Audit.json')
        assert audit['status']=='PASS_PRESERVED_PARTIAL_FULL_CASE_UNKNOWN'
        self.d=self.host/'local_controller'/audit['case_id']/'reflection_v2'
        self.calls=read(self.d/'Call_Order.json')
        self.manifest=read(self.host/'remote_closed_descriptor.json')['members']
        prior=R/'outputs/pending_source_state_20261028/capture'/f'case_{case_index:02d}'
        self.pending=decode(prior,read(prior/'Pending_Source_State.json'))
        self.pi=self.gi=0;self.admitted=False
        self.costs={'paid_source_PF_restores':0,'paid_source_model_responses':0,
                    'new_model_provider_calls':0,'new_physics_provider_calls':0}

    def physics(self, net, **kwargs):
        if self.pi<len(self.calls['PF']):
            rec=self.calls['PF'][self.pi]
            assert kwargs==rec['kwargs'];frames_equal(net,saved_net(self.d,rec['before']))
            restore_exact(net,saved_net(self.d,rec['after']))
            self.pi+=1;self.costs['paid_source_PF_restores']+=1
            if rec['exception'] is not None:raise RuntimeError(failure_message(rec['exception']))
            return
        if not self.admitted:raise RuntimeError('Unpaid physics before pending-state admission')
        self.costs['new_physics_provider_calls']+=1
        return self.new_physics(net,**kwargs)

    def model(self,messages):
        name=f'response_{self.gi:05d}.json'
        if not self.admitted and name in self.manifest:
            path=self.host/'staged/study'/name;raw=path.read_bytes()
            assert hashlib.sha256(raw).hexdigest()==self.manifest[name]['sha256']
            ans=read(path)
            assert ans['number']==self.gi and ans['request']['messages']==messages
            self.gi+=1;self.costs['paid_source_model_responses']+=1
            return ans['raw_text']
        if not self.admitted:
            import numpy as np
            frame=inspect.currentframe()
            while frame is not None and frame.f_code is not self.reflection.run_one_scenario_two_best_v2.__code__:frame=frame.f_back
            if frame is None:raise RuntimeError('Not executing the bound original controller')
            state=copy.deepcopy({k:frame.f_locals[k] for k in ['net','result','failed_sigs','failed_actions','feedback_state','it'] if k in frame.f_locals})
            state.update(python_rng=random.getstate(),numpy_rng=np.random.get_state(),pending_messages=copy.deepcopy(messages),PF_cursor=self.pi,model_cursor=self.gi)
            checkpoint_equal(state,self.pending)
            assert self.pi==len(self.calls['PF'])
            self.admitted=True
        self.costs['new_model_provider_calls']+=1
        return self.new_model(messages)
