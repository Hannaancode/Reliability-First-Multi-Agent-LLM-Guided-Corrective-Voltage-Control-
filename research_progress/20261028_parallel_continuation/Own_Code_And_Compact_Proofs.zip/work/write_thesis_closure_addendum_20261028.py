"""Source-bound thesis inserts; documentation only, no experimental calls."""
from pathlib import Path
import ast, datetime, hashlib, json
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Mm
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

R=Path(__file__).resolve().parents[1]
O=R/'outputs/thesis_research_closure_20261028'
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def func(path,name):
    text=(R/path).read_text('utf-8-sig'); tree=ast.parse(text)
    n=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return {'path':path,'source_sha256':sha(path),'function':name,'line':n.lineno,'end_line':n.end_lineno,
            'function_sha256':hashlib.sha256(ast.get_source_segment(text,n).encode()).hexdigest()}
anchors=[func('work/e/audit/phase2g_rescue_runner.py',x) for x in ['grid_metrics','llm_q_abs_at_bus','verify_action']]
anchors += [func('work/e/audit/phase2g_multiagent_llm_runner.py','run_pf'),func('work/e/audit/run_reflection_v4_safety_envelope.py','choose_safety_envelope')]
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
contribution_intro=("I carried out the main technical work for PowerGridQA, the RAG assistant and HierGrid, including the implementation, experiments and preparation of the research manuscripts. The work developed from a power-system question–answer dataset into a grounded assistant and then a multi-agent voltage-control system. The table separates this technical work from the review and supervision contributed by collaborators.")
contributions=[
['PowerGridQA','Main technical work on dataset construction, implementation, analysis and manuscript preparation, as confirmed by the candidate.','The published paper records source selection and answer review by domain experts, including coauthors. Their review and resolution of ambiguous answers remain acknowledged.'],
['RAG assistant','Main technical work on the assistant implementation, experiments and manuscript preparation, as confirmed by the candidate.','A detailed allocation of collaborator roles was not recovered from the supplied manuscript. Do not infer that coauthors made no contribution.'],
['HierGrid','Conceptualisation, methodology, software, data curation, formal analysis, investigation, validation, visualisation and writing, as recorded in the supplied CRediT statement.','The draft credits Amith Khandakar and S. M. Muyeen with supervision, methodology, validation, project administration and review/editing. Other provisional entries need confirmation before submission.'],
['Later comparison studies','Candidate-led research direction and experimental decisions, with AI-assisted coding, analysis preparation and writing disclosed.','Execution logs identify automated work. These studies should not be described as manually implemented or independently checked by the candidate unless that review is documented.']]
contribution_end=("This statement describes research responsibility rather than claiming sole authorship of every activity. The HierGrid draft supports the listed technical roles, while the dataset publication specifically describes expert review. The RAG allocation and provisional coauthor entries should be reconciled with the final author-approved statements. No Qatar University requirement for a separate contribution section has been established in this review.")
selection=[
"HG-SE is an offline selection between completed DFF and HG-VF trajectories. Both branches are evaluated before the selector compares their endpoints, so the selected endpoint is not a decision that an online controller could make using future outcomes that it has not yet observed.",
"The retained choose_safety_envelope function first selects the lower final UV count, then the lower final voltage deficit and finally the smaller accepted-action count. A remaining tie selects DFF. The function does not include a separate final overvoltage comparison. Each branch's original verifier and the reported strict overvoltage results must therefore remain visible.",
"There is a source detail that affects equal-UV ties: final_deficit is read using an `or 1e99` default. A numerical zero is therefore treated the same way as a missing or false value. Reproducing the historical selector requires preserving that behaviour and reporting it; silently changing it would create a different method.",
"The selected 911 actions reported for the 137-case HG-SE cohort describe the retained paths. They do not include all work spent producing the two candidate trajectories. A full cost comparison includes both branches' physical queries, model calls, preparation and failures, with shared cached calls identified separately. Historical costs that have not been recovered remain unknown.",
"The later numerical D-SE comparator is a different construction: DFF plus DFF-ALT with the unchanged selector. It tests whether an alternative numerical trajectory provides the benefit attributed to the language branch. The manuscript's HG-SE result alone does not establish an advantage over this stronger comparator."]
verification=[
['Power-flow convergence','Explicit acceptance condition','run_pf uses Newton–Raphson, automatic initialisation, voltage angles, enforce_q_lims=True and max_iteration=80. A failed solve rejects the candidate. Convergence is not a complete feasibility certificate.'],
['Lower-voltage behaviour','Explicit acceptance condition','UV uses Vm < 0.95. UV count may not increase; total deficit may not increase by more than 1e-9. At least UV count, deficit or minimum voltage must improve under the coded tolerances.'],
['Upper-voltage behaviour','Guard and reporting differ','Native acceptance rejects max Vm > 1.06. Strict OV reports Vm > 1.05. An accepted action can therefore retain strict OV, and zero UV does not imply whole-band restoration.'],
['Added reactive support','Explicit source resource check','Cumulative support from shunts identified as LLM-added is capped at 450 Mvar per bus. Positive support is applied using the negative-q pandapower shunt convention. This cap is not a complete device capability model.'],
['Bus and action admissibility','Distributed across source interfaces','Parser, zone menus, action signatures and source resource state restrict proposals. The verifier function alone is not a complete certificate of every possible packet or device rating.'],
['Generator limits','Partial solver setting only','enforce_q_lims=True is configured. verify_action does not independently certify all generator active/reactive limits, slack limits or capability curves at every accepted endpoint.'],
['Branch thermal and angle limits','Not an explicit acceptance test here','verify_action contains no separate branch-loading, thermal-rating or angle-difference rejection. A voltage-accepted action must not be called fully AC-feasible on this evidence.'],
['Dynamics and cybersecurity','Not evaluated by this verifier','Transient/frequency stability, protection coordination, contingencies and attack resilience are not established by the steady-state voltage acceptance function.']]
guard_text=("This matrix describes the inspected original source functions and their configured solver call. It does not certify every study in the thesis or replace independent trajectory replay. The 0.95–1.05 reporting band and the native 1.06 acceptance guard must be reported together. Source scope is stated explicitly because a numerical verifier can enforce only the conditions actually implemented.")

source_record={'at_utc':now,'scope':'Documentation and static source inspection only','new_model_PF_optimizer_calls':0,
 'source_anchors':anchors,'paper_text_anchors':[
 {'path':'outputs/thesis_expanded_20261028/multi.txt','sha256':sha('outputs/thesis_expanded_20261028/multi.txt'),'lines':'966–970','role':'supplied draft CRediT'},
 {'path':'outputs/thesis_draft_20261028/dataset_version_of_record.txt','sha256':sha('outputs/thesis_draft_20261028/dataset_version_of_record.txt'),'lines':'284–305','role':'published expert review description'}],
 'candidate_confirmation':'28 October 2026: main technical work in the three projects done by Abdul Hannaan',
 'uncertainties':['No verified QU requirement for a separate section','RAG coauthor allocation not recovered','Provisional NIL entries in HierGrid draft are not final proof of no contribution','Final four-case endpoints remain under independent-study closure']}
(O/'Contribution_And_Verifier_Source_Record.json').write_text(json.dumps(source_record,indent=2,ensure_ascii=False)+'\n','utf-8')

def mdtable(heads,rows):return '\n'.join(['| '+' | '.join(heads)+' |','| '+' | '.join(['---']*len(heads))+' |']+['| '+' | '.join(r)+' |' for r in rows])
contribution_md='## 3.10 Candidate contribution within the coauthored work\n\n'+contribution_intro+'\n\n'+mdtable(['Research output','Candidate contribution','Collaborator roles and evidence'],contributions)+'\n\n'+contribution_end+'\n'
selection_md='## Offline selection and its exact source behaviour\n\n'+'\n\n'.join(selection)+'\n'
verification_md='## Extent of the original physical verification\n\n'+guard_text+'\n\n'+mdtable(['Condition','Evidence level','What the source does and does not establish'],verification)+'\n'
(O/'Candidate_Contribution_Statement.md').write_text(contribution_md,'utf-8')
(O/'Source_Contract_And_Contribution_Addendum.md').write_text('# Thesis contribution and verification addendum\n\n'+contribution_md+'\n'+selection_md+'\n'+verification_md,'utf-8')
# Update chapter sources only once; preserve the previously reviewed DOCX unchanged.
chap=R/'outputs/thesis_expanded_20261028/03_Contributions.md'
old=chap.read_text('utf-8-sig')
assert '## 3.10 Candidate contribution within the coauthored work' not in old
(O/'Prior_03_Contributions.md').write_text(old,'utf-8')
chap.write_text(old.rstrip()+'\n\n'+contribution_md,'utf-8')

doc=Document()
sec=doc.sections[0];sec.page_width=Mm(210);sec.page_height=Mm(297)
sec.top_margin=Mm(22);sec.bottom_margin=Mm(22);sec.left_margin=Mm(25);sec.right_margin=Mm(25)
for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
 s=doc.styles[name];s.font.name='Times New Roman';s.font.color.rgb=RGBColor(0,0,0)
doc.styles['Normal'].font.size=Pt(11.5)
doc.styles['Normal'].paragraph_format.line_spacing=1.15
doc.styles['Normal'].paragraph_format.space_after=Pt(7)
doc.styles['Title'].font.size=Pt(17)
doc.styles['Heading 1'].font.size=Pt(14)
def p(text):return doc.add_paragraph(text)
def table(heads,rows,widths):
 t=doc.add_table(rows=1,cols=len(heads));t.autofit=False
 for j,h in enumerate(heads):t.rows[0].cells[j].text=h
 for values in rows:
  cells=t.add_row().cells
  for j,value in enumerate(values):cells[j].text=value
 for i,row in enumerate(t.rows):
  trPr=row._tr.get_or_add_trPr()
  no_split=OxmlElement('w:cantSplit');trPr.append(no_split)
  if i==0:trPr.append(OxmlElement('w:tblHeader'))
  for j,c in enumerate(row.cells):
   c.width=Mm(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   pr=c._tc.get_or_add_tcPr()
   borders=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
   pr.append(borders)
   mar=OxmlElement('w:tcMar')
   for side in ['top','left','bottom','right']:
    e=OxmlElement('w:'+side);e.set(qn('w:w'),'85');e.set(qn('w:type'),'dxa');mar.append(e)
   pr.append(mar)
   if i==0:
    shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'DEE7EF');pr.append(shade)
   for para in c.paragraphs:
    para.paragraph_format.line_spacing=1.05;para.paragraph_format.space_after=Pt(3)
    for run in para.runs:run.font.size=Pt(10.5);run.bold=(i==0)
 return t

doc.add_heading('Candidate contribution and verification scope',0)
p('Abdul Hannaan  |  Thesis review insert  |  28 October 2026')
doc.add_heading('Candidate contribution',1)
p(contribution_intro)
table(['Research output','Candidate contribution','Collaborator roles and evidence'],contributions,[27,63,70])
p(contribution_end)
doc.add_page_break()
doc.add_heading('Offline selection and full costs',1)
for x in selection:p(x.replace('`',''))
p('Source: run_reflection_v4_safety_envelope.py, choose_safety_envelope, lines 718–742. Manuscript figures remain reported results until their final raw trajectory join is certified.')
doc.add_page_break()
doc.add_heading('Extent of physical verification',1)
p(guard_text)
table(['Condition','Evidence level','Source behaviour and limits'],verification,[29,35,96])
p('Sources: phase2g_rescue_runner.py, grid_metrics, llm_q_abs_at_bus and verify_action; phase2g_multiagent_llm_runner.py, run_pf. Exact source hashes and line ranges accompany this insert in Contribution_And_Verifier_Source_Record.json.')
doc.core_properties.author='Abdul Hannaan';doc.core_properties.title='Candidate contribution and verification scope'
for root in [doc.styles.element,doc.element]:
 for e in list(root.iter(qn('w:pBdr'))):e.getparent().remove(e)
 for e in root.iter(qn('w:rFonts')):
  for attr in list(e.attrib):
   if attr.endswith('Theme'):del e.attrib[attr]
  for attr in ['ascii','hAnsi','eastAsia','cs']:e.set(qn('w:'+attr),'Times New Roman')
for para in doc.paragraphs:
 if para.text.startswith(('This statement describes','Sources:')):para.paragraph_format.space_before=Pt(7)
doc.save(O/'Candidate_Contribution_and_Verification_Insert.docx')
tasks=json.loads((O/'Tasks.json').read_text('utf-8-sig'))
for t in tasks['tasks']:
 if t['id'] in ['T03','T08','T18','T24']:
  t['status']='SOURCE_BOUND_INSERT_PREPARED_FINAL_THESIS_INTEGRATION_PENDING'
  t['evidence']=['outputs/thesis_research_closure_20261028/Source_Contract_And_Contribution_Addendum.md','outputs/thesis_research_closure_20261028/Contribution_And_Verifier_Source_Record.json']
  t['limitation']='Rendered document review and final thesis integration remain pending; T24 retains unconfirmed collaborator details.'
 if t['id']=='T07':
  t['status']='MISSING_ONLY_CONTINUATIONS_RUNNING_TWO_T4'
  t['evidence']=['outputs/original_missing_suffix_live_handoff_20261028/Verified_Actual_Live_Checkpoint.json']
tasks['updated_utc']=now
(O/'Tasks.json').write_text(json.dumps(tasks,indent=2,ensure_ascii=False)+'\n','utf-8')
with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
 f.write(f'\n{now} — Thesis checklist CPU work: T24 candidate contribution statement bound to user confirmation, supplied HierGrid CRediT and published dataset coauthor-review description. T03 offline HG-SE, exact zero/missing deficit handling and full both-branch costs clarified. T08 thresholds and T18 original verifier scope documented from exact AST/function/source anchors. No new scientific calls. Chapter3 source updated; existing105-page reviewed DOCX preserved. Final insert visual review and full-thesis integration pending.\n')
print(json.dumps({'status':'INSERT_WRITTEN','docx':str(O/'Candidate_Contribution_and_Verification_Insert.docx'),'scientific_calls':0}))
