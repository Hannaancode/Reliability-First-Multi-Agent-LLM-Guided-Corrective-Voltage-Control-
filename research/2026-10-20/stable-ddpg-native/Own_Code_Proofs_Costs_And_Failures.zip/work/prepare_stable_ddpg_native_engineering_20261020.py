"""Pure import/native-MAT/definition/strict-load engineering readiness; zero forward/PF."""
import hashlib,json,inspect,os,time,pickle
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/stable_ddpg_native_engineering_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic()
    from candidate_process_evidence_utils import frozen_checks
    import stable_ddpg_native_bridge_20261020 as b
    from scipy.io import loadmat
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'First author-native13bus engineering at original first test repetition seed0,all3policies(Stable-DDPG,linear,DDPG),first action only;not full500repetition/100step paper or HierGrid superiority.','original_author_commit':'fb6098c1aeb2bd4c42e04afbb0da372907aeb63c','fixed_root_seed':0,'fixed_author_torch_seed':10,'control_bus_indices':[2,7,9],'algorithms_in_author_order':['safe-ddpg','linear','ddpg'],'actuator':'Author native PI absoluteQ=lastQ-clip(policy_output,-.3,.3),startlastQzero. Clip is original published action operation,not an added rescue. No absolute inverter capacity asserted. Native existing non-controlled sgen input retained.','physics':'reset seed0 usesauthor pp.runpp(algorithm=bfsw);eachcandidate usesauthor pp.runpp(algorithm=bfsw,init=dc). No root rerun,share exactly saved solved root acrossall3one-step policies.','metrics':'Saveauthor3control-node state/done plusALL13bus UV/OV/minmax/.95to1.05 safety,all numericfields/KCL;author3percent policydeadband unchanged. No only-success-case filtering.','planned_not_completed_calls':{'primary_unique_PF_max':4,'independent_unique_replay_PF_max':4,'agent_policy_forward_primary':9,'agent_policy_forward_cold':9,'primary_plus_cold_checkpoint_loads':18,'optimizer_backward_training_GPU_calls':0},'fixed_worker_bound_seconds':600,'fixed_reader_bound_seconds':300,'cold':'Freshmodelstrict checkpoint reload then first action on exact same root state;all3policies/all3agents;exact output arrays required;counts charged. SafePolicy author first-forward b/c normalization mutates weights, retained and recorded.','failure':'Preservepartial/source/claimedattempts/exceptions/UNKNOWN;no original ownerrestart,model/physicsretry,sourcechange orbudgetextension. Complete-only readerafteractualscienceendedexit0andclosedmanifest.','duplicate_physical_identity':'SameexactQ/input acrosspolicies orroot reuses paidfields,neverduplicateprimaryPF. Independentreader replaysuniqueprimaryidentities once only.','baseline_fidelity':'Modernpandapower3.4/PyTorch2.10CPU API/headless reference;unchanged authorfunctionASTs. Not an assertion of historical CUDAbitidentity.','own_LLM_nativebenchmark':'NOT_READY;not run by this engineering. All6goalsOPEN.','readiness_model_PF_GPU_calls':0}
    (OUT/'Protocol_Before_Readiness.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    before=frozen_checks();(OUT/'Frozen_Before.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
    env,proxy,envproof=b.environment();assert len(env.network.bus)==13 and env.agentnum==3 and list(env.network.sgen.bus[:3])==[2,7,9]
    assert env.network._ppc is None,'Native importer must not solve initialphysics'
    models,loads,policyproof=b.load_three(env)
    assert len(loads)==9 and all(not any(v.grad is not None for v in m.parameters()) for group in models.values() for m in group)
    # Mat/NET closure checks before any real powerflow or forward. Original converter/additions exact.
    mat=loadmat(b.AUTHOR/'pandapower models/pandapower models/case_13.mat',struct_as_record=False,squeeze_me=True)['case_mpc']
    assert len(mat.bus)==13 and len(mat.branch)==len(env.network.line)+len(env.network.trafo)
    assert env.network.sgen.q_mvar.eq(0).all() and env.network.sgen.p_mw.eq(0).all()
    sources=['stable_ddpg_native_bridge_20261020.py','run_stable_ddpg_native_engineering_20261020.py','audit_stable_ddpg_native_engineering_20261020.py','coordinate_stable_ddpg_native_engineering_20261020.py','candidate_process_runtime.py','candidate_process_evidence_utils.py']
    protocol['sources']={name:sha(ROOT/'work'/name) for name in sources}
    names=['safeDDPG.py','env_single_phase_13bus.py','test.py','pandapower models/pandapower models/case_13.mat']+[x['checkpoint'] for x in loads]
    protocol['author_inputs']={name:sha(b.AUTHOR/name) for name in names}
    protocol['installed_runtime']={'torch':b.torch.__version__,'pandapower':b.pp.__version__,'numpy':b.np.__version__,'from_mpc_source':inspect.getsourcefile(b.from_mpc),'from_mpc_source_sha256':sha(inspect.getsourcefile(b.from_mpc))}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_NATIVE13_MAT_CONVERTER_ADDITIONS_SOURCE_AST_AND_ALL9_STRICT_POLICY_LOADS_NO_FORWARD_NO_PF','environment_AST':envproof,'policy_AST':policyproof,'strict_checkpoint_loads':loads,'native_bus_count':len(env.network.bus),'source_branch_count':len(mat.branch),'native_sgen_buses':env.network.sgen.bus.astype(int).tolist(),'native_limits':[env.vmin,env.vmax],'prospective_action_increment_cap':.3,'costs':{'checkpoint_loads':9,'network_conversions':1,'model_forward_PF_GPU_optimizer_calls':0},'workflow_seconds':time.monotonic()-start}
    (OUT/'Readiness.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(OUT/'Frozen_After.json').write_text(json.dumps(frozen_checks(),indent=2),encoding='utf-8');print(json.dumps({'readiness':result['status'],'checkpoint_loads':9,'model_PF_calls':0}))
if __name__=='__main__':main()
