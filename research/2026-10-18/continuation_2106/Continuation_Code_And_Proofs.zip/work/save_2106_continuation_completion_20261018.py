"""Save exact closed work, remaining source gates, and a canonical public delta."""
import hashlib,json,os,zipfile
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
B=R/'outputs/continuation_2106_completion_20261018'
def atomic(path,v):
    temp=path.with_name(path.name+'.new')
    with temp.open('w',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(temp,path)
def main():
    B.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    query=read(R/'outputs/exact_two_paid_query_engineering_20261018/audit_source_claim_v2/Independent_Audit.json')
    gap=read(R/'outputs/unstarted_paid_suffix_new_receipts_v3_preparation_20261018/closed_gap_audit/Verified_Closed_Gap.json')
    static=read(R/'outputs/fresh_static_component_index_20261018/Results.json');roster=read(R/'outputs/all141_benchmark_roster_20261018/Independent_Roster_Check.json')
    assert static['observations']==3418 and all(v==0 for v in static['target_component_matches'].values())
    remaining=read(R/'outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json')
    tasks=read(R/'outputs/research_tasks_20261014/Tasks.json');assert all(s['completed'] for s in tasks['tasks'][0]['subtasks'] if s['id'] in ('G1.5','G1.6'))
    next_steps=[
        'Do NOT restart any completed worker/coordinator/reader. All science and analysis actors ended; no GPU or timers. Read exact remaining3inputs and original pre-outcomeK4 menu proof first.',
        'Implement a separately prospective THREE-identity paid-acquisition worker and independent reader: remaining originalK4 ranks2/3/4 at the same17UV observed hypothetical branch. Ordinary/native9Q/receiver/donor/rawscope/450cap/no-refund/ownedstock/remaining15ops/normalupper1.05+1e-8/verifier/score unchanged. This is completion of an already fixed menu, not outcome-driven Q/width tuning.',
        'Existing Reservations v1 is explicitly TWO-only. Additive N=3 source must preserve every predicate and prove only declared arity differs. Never silently edit old pinned source or feed3identities into the2-only API.',
        'Freeze source/current input/exact3keys/coverage/solver/cost/absolute new resource bound/owner claims/independent reader BEFORE outcomes. Use completed60426BEFORE component index plus new280staticAFTER index and both already-paid newprimary/replay input fingerprints. Broader unlogged-history/fullBEFORE limitations remain explicit; scoped absence alone is not launch permission.',
        'Preserve full query-onlyNET/cursor/registry/history/source/input/RNG/cost/absolute-bound state before cold queries and before more science. Verify fresh exact realPID/parent/command/claim. Original core imported claim() used worker __file__ for reader: fix that provenance binding in NEW source before launch; preserve old failure.',
        'Only after actual gates pass, acquire exactly those3unexecuted primary identities once, plus atmost3explicitlycharged independent converged-query replays; no retries/old-budget extension/extra identities. Retain all rejects/exceptions/UNKNOWN and full118fields. A query-only engineering/acquisition result does NOT establish G1.7 or policy/LLM superiority.',
        'Then reuse all paid receipts in the unchanged source policy. Missing future context/receipt remainsUNKNOWN; no invented AFTER or partial-menu choice. A full matched complete trajectory worker/reader still needs its own frozen persistent-state and continuous-replay protocol.',
        'Use the exact141-recipe development roster for G1.7:8known initial>=50, including primary61UV line101 and60UV line128;70initialsUNKNOWN stayincluded. The recent4-root numerical studies do not cover both primary>=60 identities. Frozen62bank is separate, not a name-only join. Historical/inspected worlds are not unused confirmation.',
        'Keep all6human priorities and final acceptance criteria. G2/G3 public native benchmark attempts failed and must not be retuned; G4size-only imitation stopped. No idleGPU allocation. Final claims require fresh inference, matched controls/full bothDSE costs and unused confirmation.'
    ]
    put(B/'Exact_Resume.json',{'at_utc':at,'status':'CLOSED_TWO_QUERY_ENGINEERING_AND_NEW_RECEIPT_SCREEN_ROSTER_INPUT_PREPARATION','human_start_honored_UTC':'2026-10-18T18:06:01+00:00',
        'all_owned_jobs':[],'timers':[],'GPU_allocations':[],'G1_5_G1_6':'COMPLETE','all6finalgoals':'OPEN','verified_query_engineering':query,
        'new_readonly_gap_proof':gap,'new_static_index':static,'all141_roster':roster,'remaining_original_K4_identities':remaining['all_remaining_ordered_identities'],
        'next_steps_in_order':next_steps,'latest_verified_GitHub_head_before_this_delta':'cd3d7111370eb44f1eb0697157c8ac3beff00e11','current_source_full_four_world_gate':'UNKNOWN','new_LLM_advantage':'NOT_ESTABLISHED'})
    (B/'Next_Execution.md').write_text('# Exact next execution after21:06continuation\n\nAll owned jobs ended; no GPU/timers. G1.5/G1.6 complete, all six final goals OPEN.\n\n'+'\n\n'.join(f'{i}. {s}' for i,s in enumerate(next_steps,1))+'\n','utf-8')
    tasks['at_utc']=at;tasks['scheduled_continuation']['status']='TRIGGERED_REQUESTED_TIME_START_ONLY_AUTOMATION_DELETED'
    tasks['tasks'][0]['next']='Follow outputs/continuation_2106_completion_20261018/Next_Execution.md; prepare exact remaining3source/protocol/persistent/reader gates. No new PF or GPU is ready solely from scope proofs.'
    tasks['tasks'][0]['new_roster_binding']='outputs/all141_benchmark_roster_20261018/Independent_Roster_Check.json'
    tasks['tasks'][0]['new_exact_followups']='outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json'
    tasks['latest_exact_execution_state']='outputs/continuation_2106_completion_20261018/Exact_Resume.json';atomic(R/'outputs/research_tasks_20261014/Tasks.json',tasks)
    state=read(R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json');state.update(at_utc=at,active_owned_jobs=[],timers='NONE; start-only automation deleted after requested time.',
        latest_closed_continuation='outputs/continuation_2106_completion_20261018/Exact_Resume.json',next_tasks=next_steps,
        current_task={'status':'NEXT_THREE_ORIGINAL_K4_IDENTITIES_PREPARED_NOT_READY_FOR_PF','required_new_worker_reader_and_N3_persistent_gates':True,
            'remaining_key_source':'outputs/remaining_fixed_followup_preparation_20261018/Exact_Remaining_Followups.json','old_tracked_component_hits':[0,0,0],'static_observed_component_hits':[0,0,0]},
        latest_verified_GitHub_head='cd3d7111370eb44f1eb0697157c8ac3beff00e11',verified_subtasks_completed=sum(s['completed'] for t in tasks['tasks'] for s in t['subtasks']))
    atomic(R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json',state)
    md=R/'RESEARCH_TASKS.md';text=md.read_text('utf-8');lines=text.splitlines();lines[2]=f'Updated {at}. Human priority order preserved. **0 of6final goals verified complete;13verified subtasks complete.**'
    text='\n'.join(lines)+'\n\nG1.7 readiness: exact141recipe bytes bound;8known initialUV>=50(2>=60),70unknown initials retained. Source-policy analysis with the new receipts preserves a next gap of3previously fixedK4queries; all prior scope component matches0, but newN=3worker/reader/ownership/preservation protocol remains required. [Exact next execution](outputs/continuation_2106_completion_20261018/Next_Execution.md). NoGPU/timers/livejobs.\n';md.write_text(text,'utf-8')
    note=f'\n\n{at} —21:06continuation saved. G1.5/G1.6 independentlyCOMPLETE:2newquery+2chargedreplayPF,4returns0exceptions, all118fields replaydelta0. BothactionsREJECTED(17to14UV exceeds1.05upper;17to18UV). No actualcommit/LLM/GPU/acceptedUVgain. Source-claim reader failure preserved, additive0PF repairPASS. Complete local78member1,468,445byte archiveSHA36eb9365d420a5ccf6490d9709c02e62de37453a974eb9edebd92c402fef3998 passedCRC/allhash; public109member350,857byte code/proof pack remote7files byteverified atcd3d7111370eb44f1eb0697157c8ac3beff00e11. New changed-evidence causal screen408.891998sec/1518closedqueries/2contexts2860oldforecastsreused/0newscience; same fixedmenu retains3missingidentities, fullgateUNKNOWN. Exact141recipe roster bound8known>=50/2>=60/70initialUNKNOWN. New280component staticindex3418dual-equation references,3targetmatches0,45.480088sec/0science. No completed trajectory/LLM/DSE/zero-all claim. Allactorsended; noGPU/timers. Exactnext outputs/continuation_2106_completion_20261018/Next_Execution.md.\n'
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write(note);f.flush();os.fsync(f.fileno())
    header=f'LATEST VERIFIED21:06CONTINUATION CLOSED {at}\n\nG1.5/G1.6COMPLETE query-onlyengineeringPASS; BOTHactionsREJECTED, noacceptedUVgain.4PF(2new+2chargedreplays),4returns0exceptions,all118replaydelta0. Allactorsended/noGPU/timers.13verifiedsubtasks; all6finalgoalsOPEN. New same-policy1518receiptanalysis0science stops at3fixed missingK4queries. Exact141recipe roster:8known>=50,2>=60,70initialUNKNOWN retained. Scopeindex0targetmatches is NOT automaticPFauthority. Next additiveN=3worker/source/persistent/reader/ownership protocol; read outputs/continuation_2106_completion_20261018/Next_Execution.md and RESEARCH_TASKS.md. No oldowner/retry/sourceedit/budgetextension/stoppedmethod revival or frozenasset changes.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    folders=['outputs/continuation_2106_completion_20261018','outputs/all141_benchmark_roster_20261018','outputs/remaining_fixed_followup_preparation_20261018','outputs/fresh_static_component_index_20261018','outputs/unstarted_paid_suffix_new_receipts_v3_preparation_20261018']
    files={}
    for folder in folders:
        for p in (R/folder).rglob('*'):
            if p.is_file() and p.suffix in ('.json','.md','.gz'):files[p.relative_to(R).as_posix()]=p
    files['outputs/unstarted_paid_suffix_new_receipts_v3_20261018/Results.json']=R/'outputs/unstarted_paid_suffix_new_receipts_v3_20261018/Results.json'
    files['outputs/unstarted_paid_suffix_new_receipts_v3_20261018/Closed_Manifest.json']=R/'outputs/unstarted_paid_suffix_new_receipts_v3_20261018/Closed_Manifest.json'
    names=['freeze_all141_benchmark_roster_20261018.py','prepare_remaining_fixed_followups_20261018.py','index_fresh_static_components_20261018.py','audit_new_receipt_screen_gap_20261018.py','replay_paid_suffix_new_receipts_v3_20261018.py','record_new_receipt_screen_20261018.py','save_2106_continuation_completion_20261018.py','verify_two_query_github_publication_20261018.py']
    for n in names:files['work/'+n]=R/'work'/n
    for n in ('RESEARCH_TASKS.md','outputs/research_tasks_20261014/Tasks.json','outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json'):files[n]=R/n
    desc={}
    for n,p in files.items():
        assert not SECRET_NAME.search(p.name)
        if p.suffix!='.gz':assert not any(s.search(p.read_text('utf-8')) for s in SECRET),n
        desc[n]={'bytes':p.stat().st_size,'sha256':sha(p)}
    put(B/'Delta_Manifest.json',{'files':desc,'all_unique_canonical_paths':True,'raw_NET_states_and_large_journals_local_only':True,'all6goalsopen':True})
    dest=B/'Continuation_Code_And_Proofs.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in files.items():z.write(p,n)
        z.write(B/'Delta_Manifest.json','Delta_Manifest.json')
    with zipfile.ZipFile(dest) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(files)+1 and z.testzip() is None
        for n,m in desc.items():raw=z.read(n);assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
    put(B/'Delta_Archive_Audit.json',{'status':'PASS_UNIQUE_MEMBERS_CRC_ALL_HASH_SCREEN','members':len(files)+1,'bytes':dest.stat().st_size,'sha256':sha(dest),'local_large_raw_NOT_uploaded':True})
    print(json.dumps({'saved':'CLOSED_EXACT_RESUME_AND_PROOFS','verified_subtasks':state['verified_subtasks_completed'],'goalscomplete':0,'delta_archive_bytes':dest.stat().st_size}))
if __name__=='__main__':main()
