"""Prepare additive parallel case owners; no allocation or scientific execution."""
import ast
from reflection118_remaining_cases_v2_core_20261023 import *

def save(name,value):
    ast.parse(value)
    with (R/'work'/name).open('x',encoding='utf-8') as f:f.write(value)

def rewrite(text):
    for old,new in [
      ('reflection118_remaining_cases_core_20261023','reflection118_remaining_cases_v2_core_20261023'),
      ('reflection118_remaining_cases_preparation_20261023','reflection118_remaining_cases_v2_preparation_20261023'),
      ('reflection118_remaining_cases_execution_20261023','reflection118_remaining_cases_v2_execution_20261023'),
      ('reflection118_remaining_cases_independent_20261023','reflection118_remaining_cases_v2_independent_20261023'),
      ('reflection118_remaining_cases_reader_coordination_20261023','reflection118_remaining_cases_v2_reader_coordination_20261023'),
      ('reflection118_remaining_cases_coordination_20261023','reflection118_remaining_cases_v2_coordination_20261023'),
      ('reflection118_remaining_cases_handoff_20261023','reflection118_remaining_cases_v2_handoff_20261023'),
      ('run_reflection118_remaining_local_20261023','run_reflection118_remaining_v2_local_20261023'),
      ('r118_dff_missing_continuation_handoff_20261023','r118_dff_partition_continuation_handoff_20261023')]:text=text.replace(old,new)
    return text

def main():
    TOP.mkdir(exist_ok=False)
    for i in [1,2,3]:
        old=R/'outputs/reflection118_remaining_cases_preparation_20261023'/f'case_{i:02d}'
        p=read(old/'Frozen_Engineering_Protocol.json')
        p.update(status='DESIGN_ONLY_NEW_CLOSED_PARTITION_HISTORY_AND_PROVIDER_OBSERVER_INTEGRATION',
            complete_partition_required=True,zero_new_science_or_allocation_in_preparation=True,
            closed_paid_registry=(TOP/'closed_registry/Closed_Physical_Receipt_Registry.json').relative_to(R).as_posix(),
            identity_reuse='Every differing shunt representation requires exact native ppci/options/kwargs identity and original native result extraction; preserve target rows and charge preparation/extraction. No solver rescue.',
            observer='Original source commitment observer preserved. Proven provider-only tracing pause affects instrumentation, not decisions or budgets.')
        put(TOP/f'case_{i:02d}'/'Frozen_Engineering_Protocol.json',p)
        put(TOP/f'case_{i:02d}'/'Direct_Human_Authority.json',read(old/'Direct_Human_Authority.json'))
    local=rewrite((R/'work/run_reflection118_remaining_local_20261023.py').read_text('utf-8'))
    local=local.replace("registry=ClosedPaidRegistry(R/p['closed_paid_registry']);native=pp.runpp", "require_partition_closed()\n    registry=ClosedPaidRegistry(R/p['closed_paid_registry'],O/'solver_input_identity');native=pp.runpp")
    needle="    previous='0'*64;pf_rows=[];"
    assert needle in local
    local=local.replace(needle,"    costs['exact_solver_input_preparation']=registry.preparation_costs\n    from run_reflection118_chronological_local_20261022 import necessary\n    fixed_case_component=necessary(root)\n"+needle)
    local=local.replace("if costs['binary_bytes']+4*1024**2>p['local_binary_bound_bytes']:","if costs['binary_bytes']+registry.preparation_costs['proof_bytes']+4*1024**2>p['local_binary_bound_bytes']:")
    local=local.replace("        nonlocal initial\n        bound();", "        nonlocal initial\n        assert necessary(net)==fixed_case_component,'Fixed case load/outage changed; parallel physical identities could collide'\n        bound();")
    save('run_reflection118_remaining_v2_local_20261023.py',local)
    reader=rewrite((R/'work/audit_reflection118_remaining_case_20261023.py').read_text('utf-8'))
    needle="        local=read(C/'Results.json');assert replays==local['costs']['new_PF_returns']"
    assert needle in reader
    reader=reader.replace(needle,needle+"\n        from audit_solver_input_identity_receipts_20261023 import audit as audit_identities\n        identities=audit_identities(C/'solver_input_identity')\n        assert identities['identity_receipts']==local['costs']['exact_solver_input_preparation']['identity_receipts']\n        put(O/'Exact_Solver_Input_Receipt_Audit.json',identities)")
    save('audit_reflection118_remaining_v2_case_20261023.py',reader)
    host=rewrite((R/'work/run_reflection118_remaining_colab_20261023.py').read_text('utf-8'))
    host=host.replace("assert closure['independent_audit_status'].startswith('PASS_')","assert closure['independent_audit_status']=='PASS_ALL4_COMPLETE_NATIVE_DFF_SOURCE_PHYSICS_COST'")
    save('run_reflection118_remaining_v2_colab_20261023.py',host)
    coord=rewrite((R/'work/coordinate_reflection118_remaining_cases_20261023.py').read_text('utf-8'))
    coord=coord.replace(" assert read(TOP/'Final_All3_Readiness.json')['passed']"," require_partition_closed()\n assert read(TOP/'Final_All3_Readiness.json')['passed']")
    save('coordinate_reflection118_remaining_v2_cases_20261023.py',coord)
    put(TOP/'Draft_Source_Change_Scope.json',dict(status='NEW_SOURCES_PARSED_NO_SCIENCE_OR_ALLOCATION',original_controller_prompts_parser_actions_verifier_unchanged=True,three_roots_preselected=True,exact_solver_input_reuse_and_observer_pause_only=True,old_sources_preserved=True,requires_new_incremental_registry_and_integration_and_final_freeze=True))
    print(json.dumps(dict(status='ADDITIVE_THREE_CASE_PIPELINE_PREPARED',new_PF_model_allocations=0)))
if __name__=='__main__':main()
