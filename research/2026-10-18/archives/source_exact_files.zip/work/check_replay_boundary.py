from pathlib import Path
import json,copy
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack
v2,runner,reflection=load_stack()
report=json.loads(Path('outputs/historical_replay_verification.json').read_text())
result=json.loads(Path('outputs/historical_replay_result.json').read_text())
net=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'))
_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
scenario=json.loads((ROOT/'pack/scenarios/federation'/f"{report['scenario_id']}.json").read_text())
net=v2.v0.apply_scenario_to_net(net,scenario,zones);v2.v0.run_pf(net)
for row in result['executed_actions']:runner.rescue.apply_action(net,row['action']);runner.rescue.r.run_pf(net)
values=net.res_bus.vm_pu
boundary=[{'bus':int(b),'vm_pu':float(v),'distance_to_1p05':float(v-1.05),'classified_soft_ov':bool(v>1.05)} for b,v in values.items() if abs(v-1.05)<1e-12]
report['soft_ov_boundary_diagnostic']=boundary
report['continuous_metrics_within_1e-10']=all(v<1e-10 for k,v in report['final_metric_absolute_errors'].items() if k not in ['uv_count','ov_count'])
report['final_uv_count_matches']=report['final_metric_absolute_errors']['uv_count']==0
report['strict_soft_ov_count_matches']=report['final_metric_absolute_errors']['ov_count']==0
report['interpretation']='Exact actions, candidate counts and final UV reproduced; continuous metrics agree within 1e-10. Strict soft-OV count differs by one, with a bus within floating-point roundoff of 1.05. This is disclosed, not corrected by changing thresholds.'
Path('outputs/historical_replay_verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(boundary,indent=2))
