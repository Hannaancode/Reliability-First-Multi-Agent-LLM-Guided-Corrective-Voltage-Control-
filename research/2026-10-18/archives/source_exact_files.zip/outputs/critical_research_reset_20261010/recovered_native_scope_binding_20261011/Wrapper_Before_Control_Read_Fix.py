"""Mechanical extended-path fix; first attempt stopped before any scope evaluation."""
import hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
import check_recovered_native_scopes_20261011 as original
PREFIX='\\\\?\\'
def idempotent_extended(p):
 return Path(PREFIX+str(p)) if os.name=='nt' and not str(p).startswith(PREFIX) else p
if __name__=='__main__':
 old=original.OUT
 failure=original.read(old/'Failure.json')
 assert failure['exception']=='FileNotFoundError' and 'Protocol.json' in failure['message']
 assert not (old/'owner.claim').exists() and not (old/'Results.json').exists()
 prep=original.ROOT/'outputs/critical_research_reset_20261010/recovered_native_scope_control_fix_v2_20261011'
 prep.mkdir(exist_ok=False)
 source=Path(original.__file__);saved=prep/'Original_Failed_Source.py'
 with saved.open('xb') as f:f.write(source.read_bytes());f.flush();os.fsync(f.fileno())
 wrapper=Path(__file__)
 control={'at_utc':datetime.now(timezone.utc).isoformat(),'old_failure_preserved':str(old/'Failure.json'),'old_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'old_failure_sha256':hashlib.sha256((old/'Failure.json').read_bytes()).hexdigest(),'old_scope_evaluations_before_failure':0,'mechanical_change':'Idempotent Windows extended prefix only; same 20 previously unexecuted native scope checks and exact gate.','wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest(),'prior_scientific_calls':0,'new_scientific_calls':0}
 original.write(prep/'Control_Fix_Protocol.json',control)
 original.ext=idempotent_extended
 original.OUT=idempotent_extended(original.ROOT/'outputs/critical_research_reset_20261010/recovered_native_scope_binding_v2_20261011')
 # Executed wrapper is frozen by main's own source pin, old implementation by control protocol.
 original.__file__=str(wrapper)
 try:original.main()
 except BaseException as exc:
  if original.OUT.is_dir():original.write(original.OUT/'Failure.json',{'state':'TERMINAL_SCOPE_CHECK_PARTIAL_NO_AUTOMATIC_RETRY','exception':type(exc).__name__,'message':str(exc),'actual_pid':os.getpid(),'new_scientific_calls':0})
  raise
