"""Record closed evidence and update task/resume documents without scientific calls."""
from pathlib import Path
import datetime, hashlib, json

R=Path(__file__).resolve().parents[1]
O=R/'outputs/original118_comparison_completion_20261028'
def read(p): return json.loads((R/p).read_text('utf-8-sig'))
def write(p,obj): (R/p).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n','utf-8')
def sha(p): return hashlib.sha256((R/p).read_bytes()).hexdigest()

def main():
    result=read('outputs/original118_closed_comparison_20261028/Comparison.json')
    manifest=read('outputs/original118_closed_comparison_20261028/Closed_Manifest.json')
    assert manifest['members']['Comparison.json']==sha('outputs/original118_closed_comparison_20261028/Comparison.json')
    assert result['status']=='ALL4_AUDITED_DESCRIPTIVE_ORIGINAL_NATIVE_COMPARISON'
    assert result['fixed_development_gate']=='FAIL'
    assert result['totals']['DFF_UV']==51 and result['totals']['HGVF_UV']==26 and result['totals']['HGSE_UV']==20
    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    O.mkdir(exist_ok=False)
    anchors=['outputs/original118_closed_comparison_20261028/'+n for n in ['Comparison.json','Full_Cost_Source_Blocks.json','Closed_Manifest.json']]
    audits=[]
    for i in (1,3):
        folder=f'outputs/original_missing_suffix_independent_20261028/case_{i:02d}'
        a=read(folder+'/Independent_Audit.json'); m=read(folder+'/Closed_Manifest.json')
        assert a['complete'] and a['status']=='PASS_ONE_COMPLETE_ORIGINAL_REFLECTION_CASE'
        assert m['members']['Independent_Audit.json']==sha(folder+'/Independent_Audit.json')
        audits.append(a); anchors += [folder+'/Independent_Audit.json',folder+'/Closed_Manifest.json']
    checkpoint={'at_utc':now,'status':'ALL4_ORIGINAL_NATIVE_ENDPOINTS_INDEPENDENTLY_CLOSED_FIXED_GATE_FAIL',
      'comparison':result,'new_suffix_costs':{'primary_PF_attempts':sum(a['primary_costs']['new_PF_attempts'] for a in audits),
      'primary_PF_returns':sum(a['primary_costs']['new_PF_returns'] for a in audits),
      'primary_PF_exceptions':sum(a['primary_costs']['new_PF_exceptions'] for a in audits),
      'first_new_return_replays':sum(a['first_new_return_replays'] for a in audits),
      'controller_model_responses':sum(a['actual_model_responses_verified'] for a in audits),
      'remote_generations_including_cold_checks':sum(a['actual_remote_model_costs']['generation_returns'] for a in audits),
      'prior_costs':'All old prefixes, failures, training, preparation and shared paid calls remain separate; this is not total research cost or deployment latency.'},
      'owned_jobs':[],'active_GPU_assignments':0,'waiting_timer':'DELETED via app automation tool after all actors terminal',
      'all_six_final_goals':'OPEN','goal_tool_at_check':None,'new_science_during_assembly':0,
      'anchors':{p:sha(p) for p in anchors},
      'next':['Finish evidence-backed thesis revisions and all35 checklist triage.',
              'Freeze a faithful external118 comparison only after its action/information/cost/episode and preservation gates are complete.',
              'Do not tune this failed four-root intervention or repeat original calls. A new mechanism needs prospective justification and unused confirmation.']}
    write(O.relative_to(R)/'Verified_Completion.json',checkpoint)
    resume_path=Path('outputs/research_resumption_20261028/Current_Resume.json')
    prior=read(resume_path); write(O.relative_to(R)/'Prior_Resume.json',prior)
    prior.update(at_utc=now,scientific_jobs=[],coordinator=None,exec_session=None,gpu_assignments=0,
      waiting_check=None,new_status=checkpoint['status'],fixed_gate='FAIL:3UVwins/1UVloss and additional strictOV on2cases',
      unresolved='No whole-band restoration on these4roots; equal-cost, literalDSE, external118 and causalLLM superiority remain unproven.',
      next=checkpoint['next'],verified_comparison='outputs/original118_closed_comparison_20261028/Comparison.json',
      completion_checkpoint='outputs/original118_comparison_completion_20261028/Verified_Completion.json')
    write(resume_path,prior)
    write('outputs/original_missing_suffix_live_handoff_20261028/Latest_Continuation.json',{
      'at_utc':now,'status':checkpoint['status'],'cases':[{'case_index':i,'audit_status':a['status'],'complete':True,'summary':a['summary']} for i,a in zip((1,3),audits)],
      'allocated_unreleased_T4s':0,'owned_jobs':[],'waiting_check_local':None,
      'checkpoint':'outputs/original118_comparison_completion_20261028/Verified_Completion.json','next':checkpoint['next']})
    tp='outputs/research_tasks_20261014/Tasks.json';tasks=read(tp)
    tasks.update(at_utc=now,updated_at_utc=now,latest_status_at_utc=now,current_owned_jobs=[],current_GPU_assignments=0,
      waiting_automations=[],current_waiting_automations=[],all6_final_goals='OPEN',latest_resume=str(resume_path).replace('\\','/'),
      actual_goal_tool_status=None,latest_verified_update=checkpoint['status'])
    for task in tasks['tasks']:
        gid=task['checklist_id']
        if gid=='G3':
            task.update(status='ORIGINAL_ALL4_COMPARISON_COMPLETE_FIXED_GATE_FAIL_EXTERNAL118_STILL_OPEN',
              current_result='DFF51UV/11OV; originalHG-VF26UV/11OV,3wins1loss; offlineHG-SE20UV/12OV. ExtraOV2cases; fixedgateFAIL. No equalcost/external/causal superiority.',
              next=checkpoint['next'][1])
            sid='G3.original118_closed_comparison_20261028'
            assert not any(x['id']==sid for x in task.get('subtasks',[]))
            task.setdefault('subtasks',[]).append({'id':sid,'completed':True,
              'description':'Close both missing original Reflection-v4 suffixes, independently replay1927newreturns and assemble ALL4unchanged matched outcomes, fullcosts and failedgate.',
              'evidence':'outputs/original118_comparison_completion_20261028/Verified_Completion.json','verified_at_save':now})
        if gid=='G1':task.update(status='FOUR_ORIGINAL_ENDPOINTS_CLOSED_NONE_WHOLE_BAND',current_result='DFF51 versus HG-VF26 versus offlineHG-SE20 residualUV; no complete normal-band case among4roots.')
        if gid=='G5':task.update(status='FULL_ORIGINAL_COMPARISON_CLOSED_CAUSAL_ADVANTAGE_UNPROVEN',current_result='Descriptive hybrid UV benefit on3/4developmentroots; oneUVloss and2additionalOVcases. Attribution remains open.')
        task['completed']=False
    write(tp,tasks)
    tt='outputs/thesis_research_closure_20261028/Tasks.json';thesis=read(tt)
    for t in thesis['tasks']:
        if t['id']=='T07':
            t.update(status='EVIDENCE_COMPLETE_THESIS_SOURCE_INTEGRATION_PENDING',evidence_complete=True,
              evidence=['outputs/original118_closed_comparison_20261028/Comparison.json','outputs/original118_comparison_completion_20261028/Verified_Completion.json'],
              limitation='Historical partials retained; now completed by separately frozen missing-only studies. Final thesis text still requires integration.')
    thesis['updated_utc']=now;write(tt,thesis)
    header=f'''## Original four-case comparison complete and independently verified — {now}

All primary/readers/coordinator ended; both T4s released and waiting timer deleted. ALL4 original native DFF/HG-VF outcomes closed: DFF51UV/11OV, HG-VF26UV/11OV, offlineHG-SE20UV/12OV. HG-VF wins3/loses1; additional strictOV on2cases; fixedgateFAIL. Original1.06guard/strict1.05report retained. HG-SE pays BOTH branches; numericalDSE and causal/external superiority unproven. Missing suffixes paid1933newPFattempts/1927returns/6exceptions,1927firstreplays,140controllerresponses+2coldgenerations. Oldprefix/model/training/preparation/failure costs remain paid. No new science in assembly. Read outputs/original118_comparison_completion_20261028/Verified_Completion.json and currentresume. All6finalgoalsOPEN. Continue thesis/checklist and justified external118 preparation; no retune/restart or idleGPU allocation.

'''
    for p in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        q=R/p;q.write_text(header+q.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+header)
    print(json.dumps({'status':checkpoint['status'],'T07':'EVIDENCE_COMPLETE','goals':'ALL6_OPEN','new_science':0}))

if __name__=='__main__': main()
