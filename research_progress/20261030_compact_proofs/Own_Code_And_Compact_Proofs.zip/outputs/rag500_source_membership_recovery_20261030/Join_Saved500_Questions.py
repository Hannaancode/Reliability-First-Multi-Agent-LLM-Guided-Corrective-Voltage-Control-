"""Saved-only exact/whitespace membership join under the prior frozen scope.
Never opens an archive, invokes a model/retriever or repairs source records.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
import hashlib,json,time
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
P=O/'Protocol.json'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def shatext(value):return digest(value.encode('utf-8')) if isinstance(value,str) else None
def norm(value):return ' '.join(value.split())
def put(name,value):
 with (O/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
def read_lines(raw):return [json.loads(x) for x in raw.decode('utf-8-sig').splitlines() if x.strip()]
def main():
 start=time.monotonic();protocol=json.loads(P.read_text(encoding='utf-8'));raws={}
 for item in protocol['inputs']:
  raw=(R/item['path']).read_bytes();assert digest(raw)==item['sha256'] and len(raw)==item['bytes'],item['path'];raws[item['path']]=raw
 printed=read_lines(raws['outputs/rag_evaluation_contract_recovery_20261028/Historical_500_Printed_QA_Records_LOCAL_ONLY.jsonl'])
 corpus=read_lines(raws['outputs/security/corpus/powergridqa_source_records.jsonl'])
 nerc_meta=read_lines(raws['outputs/nerc_membership_recovery_20261030/NERC_Source_ID_Join_LOCAL_ONLY.jsonl'])
 nerc_by_line={x['line']:x for x in nerc_meta};assert len(nerc_by_line)==4696
 assert len(printed)==500 and [x['idx'] for x in printed]==list(range(1,501))
 assert len(corpus)==28475 and len({x['id'] for x in corpus})==len(corpus)
 source_sets={};all_ids=set();invalid_source=[]
 for spec in protocol['frozen_source_sets']:
  selected=[x for x in corpus if x['source_member']==spec['source_member']]
  assert len(selected)==spec['preserved_extracted_occurrences']
  assert all(x['source_sha256']==spec['source_sha256'] for x in selected)
  exact=defaultdict(list);whitespace=defaultdict(list)
  for row in selected:
   q=row.get('question')
   if not isinstance(q,str) or not q.strip():invalid_source.append({'corpus':spec['name'],'source_record_id':row['id'],'reason':'MISSING_NONEMPTY_STRING_QUESTION'});continue
   exact[q].append(row);whitespace[norm(q)].append(row)
  source_sets[spec['name']]={'spec':spec,'selected':selected,'exact':exact,'whitespace':whitespace}
 inventory={};matches=[];status_counts={key:Counter() for key in source_sets};extra_counts={key:Counter() for key in source_sets}
 def source_ref(row,gold):
  item={k:row[k] for k in ['id','content_sha256','source_member','source_sha256','source_byte_start','source_byte_stop','source_line_start','source_array_index']}
  item.update(question_sha256=shatext(row.get('question')),answer_sha256=shatext(row.get('answer')))
  if row['source_member'].endswith('/Nerc questions.jsonl'):
   meta=nerc_by_line.get(row['source_line_start'])
   item['recovered_lesson_id']=None if meta is None else meta['source_group_id']
   item['lesson_group_basis']='UNJOINED_SOURCE_LINE' if meta is None else meta['source_group_basis']
  else:item['document_level_source_ID']='UNKNOWN_NOT_PRESENT_IN_THIS_PRESERVED_THEORY_RECORD'
  inventory[row['id']]=dict(item)
  answer=row.get('answer');both=isinstance(gold,str) and isinstance(answer,str)
  item['saved_reference_answer_exact_identity']=gold==answer if both else None
  item['saved_reference_answer_whitespace_identity']=norm(gold)==norm(answer) if both else None
  return item
 for case in printed:
  q=case.get('question');gold=case.get('gold_answer');valid=isinstance(q,str) and bool(q.strip())
  result={'historical_idx':case['idx'],'question':q,'saved_reference_answer':gold,
   'question_sha256':shatext(q),'saved_reference_sha256':shatext(gold),
   'printed_character_span':case.get('printed_character_span'),'corpora':{}}
  for name,data in source_sets.items():
   exact=data['exact'].get(q,[]) if valid else []
   normalized=data['whitespace'].get(norm(q),[]) if valid else []
   exact_ids={x['id'] for x in exact};additional=[x for x in normalized if x['id'] not in exact_ids]
   if not valid:status='INVALID_QUESTION'
   elif exact:status='EXACT_UNIQUE' if len(exact)==1 else 'EXACT_MULTIPLE'
   elif additional:status='WHITESPACE_ONLY_UNIQUE' if len(additional)==1 else 'WHITESPACE_ONLY_MULTIPLE'
   else:status='NO_MATCH'
   e=[source_ref(x,gold) for x in exact];w=[source_ref(x,gold) for x in additional]
   exact_qa=sum(x['saved_reference_answer_exact_identity'] is True for x in e)
   normalized_qa=sum(x['saved_reference_answer_whitespace_identity'] is True for x in e+w)
   result['corpora'][name]={'status':status,'exact_question_matches':e,'additional_whitespace_question_matches':w,
    'exact_QA_identity_occurrences':exact_qa,'whitespace_QA_identity_occurrences':normalized_qa}
   status_counts[name][status]+=1
   extra_counts[name].update({'exact_question_occurrences':len(e),'additional_whitespace_occurrences':len(w),
    'cases_with_any_exact_QA_identity':int(exact_qa>0),'cases_with_any_whitespace_QA_identity':int(normalized_qa>0),
    'cases_with_exact_question_and_no_exact_reference_identity':int(bool(e) and exact_qa==0),
    'cases_with_additional_whitespace_matches_beside_exact':int(bool(e) and bool(w))})
  matches.append(result)
 with (O/'All500_Question_Source_Matches_LOCAL_ONLY.jsonl').open('x',encoding='utf-8') as f:
  for result in matches:f.write(json.dumps(result,ensure_ascii=False)+'\n')
 duplicates=defaultdict(list);normduplicates=defaultdict(list)
 for case in printed:
  if isinstance(case.get('question'),str):duplicates[case['question']].append(case['idx']);normduplicates[norm(case['question'])].append(case['idx'])
 dupdetail={'exact_question_duplicate_groups':[{'question':q,'indices':ids} for q,ids in duplicates.items() if len(ids)>1],
  'whitespace_question_duplicate_groups':[{'normalized_question':q,'indices':ids} for q,ids in normduplicates.items() if len(ids)>1]}
 put('Historical_Question_Duplicates_LOCAL_ONLY.json',dupdetail)
 summaries={}
 for name,data in source_sets.items():
  group=[m['corpora'][name] for m in matches]
  exact_cases=sum(bool(x['exact_question_matches']) for x in group)
  normal_only=sum(not x['exact_question_matches'] and bool(x['additional_whitespace_question_matches']) for x in group)
  matched_ids={y['id'] for x in group for y in x['exact_question_matches']+x['additional_whitespace_question_matches']}
  summaries[name]={'source_member':data['spec']['source_member'],'source_sha256':data['spec']['source_sha256'],
   'frozen_extracted_source_occurrences':len(data['selected']),'role':data['spec']['role'],
   'status_counts':dict(status_counts[name]),'cases_with_exact_question_match':exact_cases,
   'cases_with_only_whitespace_question_match':normal_only,'cases_with_no_question_match':status_counts[name]['NO_MATCH'],
   'distinct_matched_source_occurrences':len(matched_ids),**dict(extra_counts[name]),
   'all500_questions_have_an_exact_match':exact_cases==500,
   'all500_questions_and_saved_references_have_exact_QA_identity':extra_counts[name]['cases_with_any_exact_QA_identity']==500}
 checks={'exactly500_original_order_retained':len(matches)==500 and [x['historical_idx'] for x in matches]==list(range(1,501)),
  'each_corpus_classification_accounts_for500':all(sum(x.values())==500 for x in status_counts.values()),
  'no_exact_occurrence_repeated_as_whitespace_only':all(not({x['id'] for x in m['corpora'][name]['exact_question_matches']} & {x['id'] for x in m['corpora'][name]['additional_whitespace_question_matches']}) for m in matches for name in source_sets),
  'all_corpus_occurrence_IDs_preserved_unique':len({x['id'] for x in corpus})==len(corpus),
  'source_counts_match_frozen_scope':all(len(x['selected'])==x['spec']['preserved_extracted_occurrences'] for x in source_sets.values()),
  'all_matches_exist_in_frozen_source_sets':set(inventory)<={x['id'] for data in source_sets.values() for x in data['selected']},
  'all_inputs_unchanged':all(digest((R/x['path']).read_bytes())==x['sha256'] for x in protocol['inputs'])}
 assert all(checks.values()),checks
 put('Source_ID_And_Hash_Inventory.json',{'scope':'Matched source occurrence identities and hashes only; no QA text or runtime membership claim.','records':list(inventory.values())})
 findings={'status':'COMPLETE_SAVED500_EXACT_AND_WHITESPACE_CONTENT_COMPARISON_WITH_EXPLICIT_SCOPE',
  'at_utc':datetime.now(timezone.utc).isoformat(),'cohort':'Historical500 printed theory-recipe evaluation; not the NERC215 printed-occurrence cohort.',
  'protocol_sha256':digest(P.read_bytes()),'analysis_source_sha256':digest(Path(__file__).read_bytes()),
  'historical_printed_source_sha256':digest(raws['outputs/rag_evaluation_contract_recovery_20261028/Historical_500_Printed_QA_Records_LOCAL_ONLY.jsonl']),
  'historical_questions':500,'distinct_exact_question_strings':len(duplicates),'exact_question_duplicate_groups':len(dupdetail['exact_question_duplicate_groups']),
  'distinct_whitespace_question_strings':len(normduplicates),'whitespace_question_duplicate_groups':len(dupdetail['whitespace_question_duplicate_groups']),
  'corpora':summaries,'invalid_source_question_records':invalid_source,
  'interpretation':'These are text-membership and saved-reference identity checks against frozen preserved content, not model-answer accuracy or evidence of the actual historical retrieval index.',
  'preserved_extraction_limit':'Theory22994 extracted occurrences remain distinct from published23368 and from unparsed material; no parser or syntax repair was rerun.',
  'remaining_unknown':['Actual historical runtime data hash/order and FAISS/docstore membership','Which evaluation cohort and factual-adjudication labels produced the reported99percent','Actual training/test memberships and source passages','Document-level provenance not present in the theory QA occurrence records'],
  'T11_closed':False,'T13_closed':False,'raw_questions_answers_or_transcripts_published':False,
  'new_model_retrieval_embedding_training_PF_optimizer_calls':0,'archives_opened_or_rehashed':0,
  'master_DOCX_or_publication_pack_modified':False,'analysis_seconds':time.monotonic()-start}
 put('Aggregate_Findings.json',findings)
 put('Accounting_Check.json',{'status':'PASS_SIMPLE_SAVED_ONLY_MEMBERSHIP_ACCOUNTING','checks':checks,'counts':{'historical':500,'corpus_total':28475,'theory':22994,'nerc':4696},'no_generated_answer_scoring':True})
 put('Closed_Manifest.json',{'scope':'New saved-only source-membership analysis; LOCAL_ONLY files are not publication material.',
  'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':digest(p.read_bytes()),'publication_scope':'LOCAL_ONLY' if 'LOCAL_ONLY' in p.name else 'AGGREGATE_OR_METHOD_METADATA'} for p in sorted(O.iterdir()) if p.is_file()]})
 print(json.dumps({'status':findings['status'],'corpora':summaries,'distinct_historical_question_strings':len(duplicates),'T11_closed':False,'T13_closed':False,'science_calls':0}))
if __name__=='__main__':main()
