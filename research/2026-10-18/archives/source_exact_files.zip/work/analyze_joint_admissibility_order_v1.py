"""Post-hoc development control analysis: no new PF/model/forecast/linear solve."""
import hashlib,json,os,time
from pathlib import Path
from durable_opaque_evidence_store_v1 import local_root,process_alive
from joint_admissibility_order_v1 import KEYS,order_all_current_forecasts,forecast_admissible

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
BASE=ROOT/'outputs/critical_research_reset_20261010/joint_admissibility_control_20261012'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()
def put(p,d):
    with local_root(p).open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def chosen(rows):
    admissible=[r for r in rows if r['verif']['accepted']]
    return max(admissible,key=lambda r:(tuple(r['original_score']),-r['universe_index'])) if admissible else None
def brief(r):
    return None if r is None else {'universe_index':r['universe_index'],'kind':r['kind'],'receiver':r['receiver'],'q':r['q'],
        'donor_bus':r['donor_bus'],'actual_metrics':r['verif']['after'],'original_score':r['original_score']}

def main():
    started=time.perf_counter();verified=read(OLD/'verified_handoff/Verified_Physical_Opportunity_Checkpoint.json')
    assert verified['fixed_gate']=='PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY'
    assert all(not process_alive(p) for p in verified['all_exact_owner_coordinator_reader_chains_ended'])
    local_root(BASE).mkdir(exist_ok=False)
    sources={n:sha(ROOT/n) for n in ('work/joint_admissibility_order_v1.py','work/analyze_joint_admissibility_order_v1.py')}
    p={'frozen_before_this_analysis_at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        'study':'POSTHOC_DEVELOPMENT_STRENGTHENED_NUMERICAL_CONTROL_WITH_UNCHANGED_COMPLETED_GATE',
        'source_sha256':sources,'fixed_all_K':[1,4,16,64,256],
        'order':'Predicted native strict improvement/UV/deficit and normal1.05+1e-8, original lifetime450cap and operation slots first; then original objective score and earliest universe index. Keep all candidates; no safety certification by forecast.',
        'causal_boundary':'Core receives only current row identity/current saved forecast/before/cursor; rejects outcome receipt/verifier fields. Physical labels joined only after full ordering returned.',
        'already_inspected_development':'All four opportunity results have already been examined. This additional control is explicitly post-hoc, not a prospective performance result or unused confirmation.',
        'all_prior_results_costs_retained_no_budget_threshold_or_gate_retune':True,
        'fresh_policy_economics_and_LLM_benefit':'NOT_TESTED; do not choose deploymentK or online stop from this oracle analysis',
        'new_scientific_calls':0,'anchors':{n:sha(OLD/n) for n in ('preparation/Protocol.json','audit/Independent_Audit.json','actual/Closed_Manifest.json')}}
    put(BASE/'Protocol.json',p);put(BASE/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sources['work/analyze_joint_admissibility_order_v1.py']})
    science=read(OLD/'preparation/Protocol.json');ph=sha(OLD/'preparation/Protocol.json');prev='0'*64;cases=[];PF={}
    with local_root(OLD/'actual/scientific.jsonl').open('rb') as f:
        for b in f:
            r=json.loads(b);assert r['previous_sha256']==prev and r['protocol_sha256']==ph;prev=hashlib.sha256(b.rstrip(b'\n')).hexdigest()
            if r['event']=='candidate_closed':cases.append(r['data'])
            elif r['event'] in ('PF_return','PF_exception'):PF[r['data']['id']]=r['data']['seconds']
    assert len(cases)==sum(science['declared_universe_counts'])==4001
    result=[];boundary_checks=0
    for entry in science['current_endpoints']:
        endpoint=read(ROOT/entry['endpoint_record']);cursor={**endpoint['cursor'],'raw_current_receiver_scope':endpoint['native_common_AND_zone_buses']}
        rows=[r for r in cases if r['world']==entry['world']];before=rows[0]['verif']['before']
        causal=[{k:r[k] for k in KEYS} for r in rows];order=order_all_current_forecasts(causal,before,cursor)
        poisoned={**causal[0],'measured_receipt':rows[0]['measured_receipt']}
        try:order_all_current_forecasts([poisoned],before,cursor)
        except ValueError:boundary_checks+=1
        else:raise AssertionError('Outcome label entered the causal ordering API')
        byid={r['universe_index']:r for r in rows};ordered=[byid[r['universe_index']] for r in order];full=chosen(rows)
        assert full is not None
        prefixes=[]
        for k in p['fixed_all_K']:
            head=ordered[:k];best=chosen(head);receipts=[r['measured_receipt'] for r in head if r['measured_receipt'] is not None]
            prefixes.append({'K':k,'retained_count':len(head),'best_known_safe_action':brief(best),
                'same_full_UV':best is not None and best['verif']['after']['uv_count']==full['verif']['after']['uv_count'],
                'same_full_original_score':best is not None and best['original_score']==full['original_score'],
                'historical_paid_query_PF_attempts':len(receipts),'historical_paid_query_PF_exceptions':sum(r['outcome'].startswith('EXCEPTION') for r in receipts),
                'historical_PF_seconds_only':sum(PF[r['PF_id']] for r in receipts)})
        result.append({'world':entry['world'],'all_declared_candidates_kept':len(order),
            'predicted_admissible_ordering_candidates':sum(forecast_admissible(r,before,cursor) for r in causal),
            'first_full_original_score_match':next(i+1 for i,r in enumerate(ordered) if r['verif']['accepted'] and r['original_score']==full['original_score']),
            'first_full_UV_match':next(i+1 for i,r in enumerate(ordered) if r['verif']['accepted'] and r['verif']['after']['uv_count']==full['verif']['after']['uv_count']),
            'all_fixed_K':prefixes,'retrospective_oracle_ranks_are_not_legal_online_stop':True})
    report={'status':'COMPLETE_POSTHOC_DEVELOPMENT_CONTROL_ANALYSIS','world_results':result,'actual_data_outcome_boundary_rejections':boundary_checks,
        'all4001candidate_identities_kept':True,'completed_opportunity_gate_unchanged':'PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY',
        'new_model_optimizer_PF_forecast_derivative_factor_solve_calls':0,'total_policy_latency_or_LLM_economic_allowance':'UNKNOWN_NOT_ESTABLISHED',
        'source_and_input_pins':p['source_sha256'],'analysis_seconds_before_output':time.perf_counter()-started}
    put(BASE/'Results.json',report);put(BASE/'Closed_Manifest.json',{n:sha(BASE/n) for n in ('Protocol.json','owner.claim','Results.json')})
    print(json.dumps({'status':report['status'],'actual_data_causal_boundary_checks':boundary_checks,
        'first_full_score_matches':[r['first_full_original_score_match'] for r in result],'new_science_calls':0}))
if __name__=='__main__':main()
