The two numerical controls completed and passed the external exact identity/checkpoint/cost audit. These are historical saved-label development diagnostics, not physical recovery or LLM value.

edge_conditioned_graph: held equal-world top4=0.015037594; pooled best inclusion=2/49; current-input grounding MSE=0.818144661.

full_row_attention: held equal-world top4=0.000000000; pooled best inclusion=0/49; current-input grounding MSE=0.111387866.

Strongest numerical/AC top4=0.385964912; predeclared required new LLM top4=0.435964912. All failures/unknowns/73unlabelled/originalinvalid/missing ledgers and allK1/4/8 retained. Seven labelled held worlds are inspected development, not unused confirmation. Exact622 final/reload pairs passed; 2390optimizersteps/4256cumulativeforwards(4255current+1prior). OneOPTinitialpredictionlost/UNKNOWN; finalandreloadcomplete,noinitialforwardrepeat. No new pretrained/PF/cloud calls.
