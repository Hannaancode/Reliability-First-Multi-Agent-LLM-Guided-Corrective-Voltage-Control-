"""Local CPU feature shape/finite/cold/complete-block checks BEFORE every ACK, zero model calls."""
import sys,json
from pathlib import Path
import numpy as np
study=Path(sys.argv[1]);descriptor=json.loads(Path(sys.argv[2]).read_text());width=int(sys.argv[3]);out=Path(sys.argv[4]);assert not out.exists();checks=[]
for name in descriptor['members']:
    path=study/name
    if '_block_' in name and name.endswith('.npz'):
        z=np.load(path);ids=z['ids'];values=z['features'];assert ids.ndim==1 and len(set(ids.tolist()))==len(ids) and ((ids>=0)&(ids<241)).all() and values.shape==(len(ids),width) and values.dtype==np.float32 and np.isfinite(values).all()
        if name.startswith('cold_'):
            primary=np.load(study/'primary_All241_Features.npy');assert np.array_equal(values,primary[ids])
        checks.append(name)
    elif name.endswith('.npy'):
        a=np.load(path);assert a.dtype==np.float32 and np.isfinite(a).all()
        if 'All241' in name:
            assert a.shape==(241,width)
            prefix=name.split('_')[0];seen=[]
            for block in study.glob(prefix+'_block_*.npz'):
                b=np.load(block);assert np.array_equal(a[b['ids']],b['features']);seen+=b['ids'].tolist()
            assert sorted(seen)==list(range(241))
            if name.startswith('cold_'):assert np.array_equal(a,np.load(study/'primary_All241_Features.npy'))
        else:assert a.shape==(width,)
        checks.append(name)
out.write_text(json.dumps({'status':'PASS_CPU_ALL_NEW_FEATURE_SHAPES_FINITE_ORDER_PRIMARY_BLOCK_AND_COLD_EXACT_BEFORE_ACK','checked_files':checks,'new_model_PF_calls':0},indent=2),encoding='utf-8')
