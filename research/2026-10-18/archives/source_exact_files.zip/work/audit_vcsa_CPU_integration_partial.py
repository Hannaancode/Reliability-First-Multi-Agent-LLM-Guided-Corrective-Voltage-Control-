"""Audit actual bounded CPU partials without rerun/model calls or invented gates."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json
import psutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/vcsa_development/CPU_integration_partial_audit'
assert not OUT.exists()
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owner=ROOT/'outputs/vcsa_development/CPU_integration_owner'
child=ROOT/'outputs/vcsa_development/genuine_CPU_integration'
watch=ROOT/'outputs/vcsa_development/CPU_real_descendant_watch'
protocol=read(ROOT/'outputs/vcsa_development/Local_CPU_Integration_Protocol.json')
status=read(owner/'status.json'); scientific=read(child/'status.json'); watcher=read(watch/'status.json')
for pid in [status['owner_pid'],status['child_pid'],scientific['pid'],watcher['watch_pid']]:
    if psutil.pid_exists(pid):
        process=psutil.Process(pid)
        assert not any('run_vcsa_CPU_integration_owner.py' in arg or 'run_vcsa_genuine_CPU_integration.py' in arg or 'watch_vcsa_real_CPU_descendant.py' in arg for arg in process.cmdline()),'Exact previous owner still alive'
assert status['stage']=='child_ended' and status['resource_limit_reason']=='declared_time_limit'
assert status['elapsed_seconds']>=protocol['max_wall_seconds']
assert watcher['stage']=='same_scientific_child_ended'
assert sha(ROOT/'work/run_vcsa_genuine_CPU_integration.py')==protocol['source_sha256']
assert scientific['counts']['pretrained_forward_calls']==5 and scientific['counts']['input_tokens']==14015
assert scientific['counts']['real_gradient_steps']==0
assert not (child/'step_01.json').exists() and not list(child.glob('*.pt')) and not (child/'summary.json').exists()
assert scientific['stage']=='actual_pretrained_forward_backward'
# At this exact point in preserved unchanged source, baseline enabled/disabled,
# zero-path check, and frozen reference calls have returned, followed by the
# first training call entering. Gate Boolean values were in memory and lost.
tree=ast.parse((ROOT/'work/run_vcsa_genuine_CPU_integration.py').read_text())
assert any(isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='backward' for node in ast.walk(tree))
proof=read(ROOT/'outputs/frozen_input_verification.json')
modeldir=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
for name,digest in proof['model_files'].items():assert sha(modeldir/name)==digest
base=read(ROOT/'outputs/vcsa_development/local_public_base_restoration/summary.json')
assert sha(Path(base['snapshot_path'])/'model.safetensors')==protocol['base_model_weight_sha256']
OUT.mkdir()
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'partial_integrity_passed':True,'full_integration_passed':False,
        'termination':'Prospectively declared900second resource limit, not a scientific endpoint result',
        'started_pretrained_forward_attempts':5,'source_control_flow_verified_returned_forwards':4,
        'input_tokens_started':14015,'returned_forward_input_tokens':11212,
        'completed_optimizer_steps_preserved':0,'optimizer_execution_past_last_saved_status':'No completion proof; do not invent an unpreserved update',
        'new_module_checkpoints_preserved':0,'peak_real_interpreter_RSS_bytes':watcher['peak_actual_RSS_bytes'],
        'Windows_launcher_monitor_repair':'Actual interpreter verified as owned descendant and separately watched under unchanged bounds, no model restart',
        'model_load_seconds':scientific['counts']['model_load_seconds'],'elapsed_seconds':status['elapsed_seconds'],
        'first_training_entry_utc':scientific['updated_at_utc'],'known_gate_values':'Not emitted before termination; CPU or CUDA framework completion not established',
        'frozen_adapter_and_base_files_exact':True,'private_export_or_Google_allocation':False,
        'PF_calls':0,'audit_pretrained_calls':0,'LLM_or_DSE_superiority_established':False,
        'next_action':'Keep this attempt terminal; real T4 integration waits for exact payload/destination approval. No shorter-context or outcome-driven rerun.'}
(OUT/'summary.json').write_text(json.dumps(report,indent=2))
files=[p for folder in [owner,child,watch] for p in folder.iterdir() if p.is_file()]
(OUT/'Preserved_Partial_Manifest.json').write_text(json.dumps({p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files},indent=2))
print(json.dumps(report))
