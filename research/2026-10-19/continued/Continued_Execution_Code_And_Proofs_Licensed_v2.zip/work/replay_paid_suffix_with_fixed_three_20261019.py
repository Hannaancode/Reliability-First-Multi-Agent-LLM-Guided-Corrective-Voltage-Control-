"""Changed-evidence screen with ALL5 newly measured queries available.

No new physics/model/forecast/derivative/solve. The unchanged source policy
sees the same original menus; three additional audited receipts fill a gap.
"""
import ast,copy,hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
import replay_unstarted_paid_suffix_numeric_v2_20261018 as source
import verified_paid_cache_engine_v2_20261018 as binding
from replay_paid_suffix_new_receipts_v3_20261018 import Registry as TwoRegistry,Overlay
from fixed_three_query_core_20261019 import B as THREE,PHASES
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from strict_saved_native_input_match_v2_20261018 import require_same
from equal_operation_benchmark_v2 import decode_capsule
from audit_full_receding_linear_composed_v4_20261018 import check_query
B=R/'outputs/unstarted_paid_suffix_with_fixed_three_20261019'
PREP=R/'outputs/unstarted_paid_suffix_with_fixed_three_preparation_20261019'

class Registry(TwoRegistry):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.more_lock=LockedSourceSnapshot(THREE/'Protocol.json');self.more={};self.more_p=read(THREE/'Protocol.json')
        assert read(THREE/'Completion.json')['exit_codes']=={**{p:0 for p in PHASES},'audit':0}
        assert read(THREE/'audit/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
        for phase in PHASES:
            root=THREE/phase
            for rel,h in read(root/'Closed_Manifest.json')['members'].items():assert sha(root/rel)==h
            message=read(root/'Result.json')['receipt']['message'];key=self.more_p['point']+'|'+message['aid'];record=copy.deepcopy(message['record'])
            record['after_reference']={'kind':'external_capsule','base':str(THREE.relative_to(R)),'descriptor':{**record['after_reference']['descriptor'],'path':phase+'/capsules.bin'}}
            intents={};returns={};exceptions={}
            for raw in (root/'scientific.jsonl').read_bytes().splitlines():
                e=json.loads(raw);d=e['data']
                if e['event']=='PF_intent':intents[d['identity']]=d
                elif e['event']=='PF_return':returns[d['PF_id']]=d
                elif e['event']=='PF_exception':exceptions[d['PF_id']]=d
            assert key not in self.new_data and key not in self.archive.index
            self.more[key]={'root':root,'message':message,'record':record,'intents':intents,'returns':returns,'exceptions':exceptions}
        assert len(self.more)==3;self.cache=Overlay(self.cache,{k:v['record'] for k,v in self.more.items()});self.more_stream=(self.path/'new_three_receipt_uses.jsonl').open('xb')
    def lookup(self,node,row,key):
        if key not in self.more:return super().lookup(node,row,key)
        start=time.perf_counter();assert key==point_key(node['net'],node['cursor'])+'|'+action_key(row);d=self.more[key];assert row==d['message']['row']
        native=build_verifier(self.runner.rescue,node['cursor'])[1](copy.deepcopy(node['net']),action(row));pid=d['message']['record']['actual_measured_receipt']['PF_id']
        with (d['root']/'capsules.bin').open('rb') as pack:
            require_same(native,decode_capsule(pack,d['intents'][pid]['before'])['net'])
            check_query(node,row,d['message'],cache={},intents=d['intents'],returns=d['returns'],exceptions=d['exceptions'],pack=pack,p=self.more_p,runner=self.runner)
        record=copy.deepcopy(d['record']);seconds=time.perf_counter()-start;record['source_original_receipt_id']=record['receipt_id'];record['receipt_id']='ARCHIVED_NEW_THREE_'+hashlib.sha256(key.encode()).hexdigest()
        event={'key':key,'source_protocol_sha256':sha(THREE/'Protocol.json'),'independent_audit_sha256':sha(THREE/'audit/Independent_Audit.json'),
            'record_sha256':hashlib.sha256(json.dumps(d['record'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'actual_verification_CPU_seconds':seconds,'new_PF':0}
        raw=json.dumps(event,sort_keys=True,separators=(',',':')).encode()+b'\n';self.more_stream.write(raw);self.more_stream.flush();os.fsync(self.more_stream.fileno())
        record['verified_use_reference']={'path':str((self.path/'new_three_receipt_uses.jsonl').relative_to(R)),'prefix_bytes':self.more_stream.tell(),
            'event_sha256':hashlib.sha256(raw[:-1]).hexdigest(),'actual_verification_CPU_seconds':seconds};return record
    def close(self):self.more_stream.close();self.more_lock.close();super().close()

def main():
    PREP.mkdir(exist_ok=False)
    files=[Path(__file__),Path(source.__file__),R/'work/replay_paid_suffix_new_receipts_v3_20261018.py',THREE/'Protocol.json',THREE/'audit/Independent_Audit.json',THREE/'Completion.json']
    p=read(THREE/'Protocol.json')
    put(PREP/'Protocol.json',{'status':'FROZEN_CHANGED_EVIDENCE_CAUSAL_SCREEN_ALL5_ADDITIONAL_RECEIPTS','source_input_sha256':{str(x.relative_to(R)):sha(x) for x in files},'runtime_versions':p['runtime_versions'],
        'selection':'Same original first unstarted leg/unchanged menus/policies; include BOTH old engineering receipts and ALL3 newly measured originalK4 remaining receipts, not only safe winners.',
        'fixed_bound_seconds':900,'new_model_PF_derivative_forecast_solve_calls_allowed':0,'no_new_actual_commit_or_full_policy_claim':True})
    guard=LockedSourceSnapshot(PREP/'Protocol.json')
    try:
        node=copy.deepcopy(next(n for n in ast.parse(Path(source.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main'))
        for n in ast.walk(node):
            if isinstance(n,ast.Constant) and type(n.value) is int and n.value==1800:n.value=900
        env=source.__dict__.copy();proxy=SimpleNamespace(**binding.__dict__);proxy.VerifiedPaidUseRegistry=Registry
        env.update(B=B,binding=proxy,__file__=__file__);exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(source.__file__),'exec'),env);env['main']()
    finally:guard.close()
if __name__=='__main__':main()
