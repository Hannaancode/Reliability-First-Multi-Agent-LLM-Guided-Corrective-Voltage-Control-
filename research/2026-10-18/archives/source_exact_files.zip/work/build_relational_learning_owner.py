"""Adapt tested control-only collector for separate fixed arm claims/deltas."""
import ast
from candidate_process_evidence_utils import ROOT
source=(ROOT/'work/run_relational_cuda_integration_colab_v3.py').read_text()
source=source.replace('import ast,base64,','import argparse,ast,base64,')
old="BASE=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';PREP=BASE/'cuda_integration_preparation_v3';OUT=BASE/'cuda_integration_execution_v3'"
new="""BASE=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';PREP=BASE/'learning_preparation'
parser=argparse.ArgumentParser();parser.add_argument('--arm',required=True,choices=['internal_residual','frozen_capacity_head']);arm=parser.parse_args().arm
OUT=BASE/('lm_i' if arm=='internal_residual' else 'lm_f')
profile={'internal_residual':{'account':'abdulhannaan2002@gmail.com','ADC':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud\\application_default_credentials.json'},
         'frozen_capacity_head':{'account':'sheenahammed@gmail.com','ADC':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud-hiergrid-sheenah\\application_default_credentials.json'}}[arm]"""
assert old in source;source=source.replace(old,new)
source=source.replace("'expected_account':'ahammedsheen@gmail.com'", "'expected_account':profile['account'],'arm':arm")
source=source.replace("credentials=Credentials.from_authorized_user_file(r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud-hiergrid-ahammedsheen\\application_default_credentials.json')", "credentials=Credentials.from_authorized_user_file(profile['ADC'])")
source=source.replace("science_root='content/hiergrid_execution/outputs/llm_value_relational_adaptation_research_20261009/cuda_integration_science_v3'", "science_root='content/hiergrid_execution/outputs/llm_value_relational_adaptation_research_20261009/'+('science_i' if arm=='internal_residual' else 'science_f')")
source=source.replace('relational_transfer_packages','learning_transfer_packages').replace('relational_closed_','learning_closed_').replace('relational_exit.json','learning_exit.json').replace('relational_science.log','learning_science.log')
oldprefix="""        assert set(z.namelist())==set(descriptor['members'])|{'journal_prefix.jsonl'}"""
assert oldprefix in source;source=source.replace(oldprefix,"        assert set(z.namelist())==set(descriptor['members'])|{'journal_delta.jsonl'}")
begin=source.index("        prefix=z.read('journal_prefix.jsonl')");end=source.index("    certificate=local/'CPU_Full_State_Verification.json'",begin)
source=source[:begin]+"""        delta=z.read('journal_delta.jsonl');assert len(delta)==descriptor['journal_delta_bytes'] and digest(delta)==descriptor['journal_delta_sha256']
        live=OUT/'live_journals/events.jsonl';previous=live.read_bytes() if live.exists() else b''
        if len(previous)==descriptor['journal_prefix_bytes']:
            assert digest(previous)==descriptor['journal_prefix_sha256'];previous=previous[:descriptor['journal_offset']]
        assert len(previous)==descriptor['journal_offset'] and digest(previous)==descriptor['journal_previous_sha256']
        prefix=previous+delta;assert len(prefix)==descriptor['journal_prefix_bytes'] and digest(prefix)==descriptor['journal_prefix_sha256']
        live.parent.mkdir(parents=True,exist_ok=True)
        if not live.exists() or live.stat().st_size==len(previous):
            with live.open('ab') as f:f.write(delta);f.flush();os.fsync(f.fileno())
"""+source[end:]
source=source.replace("'work/verify_relational_cuda_package_cpu.py'", "'work/verify_relational_learning_package_cpu.py'")
source=source.replace("'--prep',str(PREP),'--certificate'", "'--prep',str(PREP),'--prefix',str(OUT/'live_journals/events.jsonl'),'--certificate'")
source=source.replace('len(acknowledged)==8','len(acknowledged)==38').replace('began<2400','began<10200')
source=source.replace('work/relational_cuda_environment_check_v3.py','work/relational_learning_environment_check.py')
source=source.replace("guardian=(ROOT/'work/relational_cuda_guardian_v3.py').read_text();ast.parse(guardian)", "guardian=(ROOT/'work/relational_learning_guardian.py').read_text();ast.parse(guardian)")
source=source.replace("subprocess.Popen(['env/bin/python','-c',code]", "subprocess.Popen(['env/bin/python','-c',code,'--arm',"+repr('ARM_ARGUMENT_SENTINEL')+"]")
source=source.replace("guardian)+\"\\nwith", "guardian).replace('ARM_ARGUMENT_SENTINEL',arm)+\"\\nwith") if False else source
# The launch is a generated string; splice only the fixed validated arm argument.
source=source.replace("'ARM_ARGUMENT_SENTINEL'", "\"+repr(arm)+\"")
source=source.replace('relational_guardian','learning_guardian').replace('relational_input','learning_input')
source=source.replace('hiergrid-relational-engineering','hiergrid-relational-learning')
ast.parse(source);assert 'gcloud-hiergrid-ahammedsheen' not in source
out=ROOT/'work/run_relational_learning_colab.py';assert not out.exists();out.write_text(source)
print('SINGLE_ARM_COLLECTOR_WITH_JOURNAL_DELTAS_IMPLEMENTED_NO_ALLOCATION')
