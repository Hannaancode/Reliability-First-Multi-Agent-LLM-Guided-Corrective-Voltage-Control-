"""ALL10 first actual PF input capsules and mutation boundaries; zero PF."""
import copy,json,pickle,time
from prior_physical_query_footprints_20261018 import R,read,put,manifest,decode
from strict_saved_native_input_match_v2_20261018 import require_same,InputNotExactlyMatched
B=R/'outputs/strict_saved_native_input_match_v2_20261018'
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();sources=read(R/'outputs/prior_physical_query_footprints_20261018/Protocol.json')['sources'];checks=[];unsupported=[]
    for source in sources:
        with (R/source['path']).open('rb') as stream:
            for raw in stream:
                e=json.loads(raw)
                if e['event']=='PF_intent':break
        net=decode((R/source['path']).parent,e['data']['before']);clone=pickle.loads(pickle.dumps(net,protocol=5))
        try:require_same(net,clone)
        except InputNotExactlyMatched as exc:unsupported.append({'source':source['path'],'reason':str(exc)});continue
        for role in ['shunt','warm_result','native_mask','metadata','solver_kwargs']:
            altered=copy.deepcopy(clone);a=net;b=altered
            if role=='shunt':altered.shunt.at[altered.shunt.index[-1],'q_mvar']+=1.
            elif role=='warm_result':altered.res_bus.at[altered.res_bus.index[0],'vm_pu']+=1e-8
            elif role=='native_mask':
                if '_ppc' not in altered or altered['_ppc'] is None:continue
                altered['_ppc']['bus'][0,1]+=1
            elif role=='metadata':altered['_unrecognized_future_field']='must block'
            else:a=e['data']['kwargs'];b={**a,'unrecognized_solver_flag':True}
            rejected=False
            try:require_same(a,b)
            except InputNotExactlyMatched:rejected=True
            assert rejected,role
        checks.append({'source':source['path'],'actual_cold_pickle_NET_equal':True,'mutation_boundaries':'shunt/warmresults/nativebusmask/metadata/solverargs rejected'})
    put(B/'Results.json',{'status':'PASS_ALL10_ACTUAL_COLD_NATIVE_INPUTS_AND_MUTATION_BOUNDARIES' if len(checks)==10 else 'PARTIAL_UNSUPPORTED_TYPES_RETAINED_FAIL_CLOSED',
        'actual_inputs':checks,'unsupported':unsupported,'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Positive-only input matcher software, not a mature raw-PF cache, new measurement permission, policy score/verdict reuse or physical/model benefit. All original source verifier/current resources must still run against a matching saved PF result.'})
    manifest(B);print(json.dumps({'strict_native_input_matching':len(checks),'unsupported':len(unsupported),'newPF':0}))
if __name__=='__main__':main()
