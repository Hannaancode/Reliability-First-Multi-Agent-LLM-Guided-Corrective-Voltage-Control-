# TRAIN trajectory measurement results

The external reader verified 62 exact declared branch identities, 343 physical observation inputs, 41319 recorded candidate outcomes, and the original portfolio selector and both-branch cost arithmetic. It performed zero new solver/model calls. Physical observation derivation and continuous replay were actual separately charged numerical work in the collection.

Protected nontrivial episode worlds: 14; represented families: 3; informative distinct-first-action root pairs: 27; protected-versus-nonprotected pairs: 9. The predeclared target-feasibility gate is passed, permitting method design only.

Six original searches were reused. The nullable-field readiness failure, its one real solver return and all unexecuted records remain preserved separately. Current table fields are measured data; missing fields are explicit tags, never zero-imputed. Candidate outcomes are one-step labels only. Root contrasts contain outcomes of actual executed sequences; no unexecuted candidate has a fabricated episode reward.

This is historical TRAIN development data, not independent confirmation, LLM performance, novelty or superiority. Exact physical input and branch costs are retained. Previously evaluated validation cases and the sealed bank remain excluded. The stopped VCSA intervention remains stopped.
