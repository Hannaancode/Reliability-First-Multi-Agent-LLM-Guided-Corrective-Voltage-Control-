"""New scalar ceiling analysis of closed portfolios; no controller execution."""
import hashlib,json,math,os,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/saved_DSE_primary_ceiling_20261011'
INPUT=ROOT/'outputs/llm_value_next_method_research_20261008'
ARMS={'original_literal_DSE':'train_trajectory_collection_nullable_v2','common_guard_reference_NOT_LLM_benefit':'guarded_train_trajectory_measurement_native_v3'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text('utf8'))
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
 OUT.mkdir(exist_ok=False);start=time.perf_counter()
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'resource_seconds':60,'scope':'ALL31_CLOSED_HISTORICAL_TRAIN_PORTFOLIOS_NO_SELECTED_SUBSET','arms':ARMS,'input_manifest_sha256':{a:sha(INPUT/d/'manifest.json') for a,d in ARMS.items()},'selector_source_sha256':sha(ROOT/'work/e/audit/run_reflection_v4_safety_envelope.py'),'selector':'REUSE_SAVED_LITERAL_SELECTED_BRANCH; NO NEW SELECTOR OR ZERO/MISSING HANDLING','primary':'selected final UV count, nonnegative integer floor zero','question':'How many worlds have ANY possible strict terminal UV win, and what is the optimistic full-world mean UV reduction ceiling?','proof':'For any admissible terminal count u>=0 and saved b>=0, improvement b-u<=b. If b=0 a strict UV win is impossible. Ignore feasibility to keep optimistic bound.','no_performance_gate_or_training_launch':True,'new_PF_model_fit_optimizer_controller_forecast_solve_cloud_calls':0}
 write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':'check_saved_DSE_primary_ceiling_20261011.py','protocol_sha256':sha(OUT/'Protocol.json')})
 arms={};ids=None;input_checks=[]
 for arm,directory in ARMS.items():
  base=INPUT/directory;manifest=read(base/'manifest.json');names=sorted(k for k in manifest if k.startswith('portfolios/') and k.endswith('.json'));assert len(names)==31
  rows=[]
  for name in names:
   assert time.perf_counter()-start<60,'Resource bound; do not extend or rerun'
   path=(base/name).resolve();assert path.is_relative_to(base.resolve());identity=manifest[name];assert sha(path)==identity['sha256'] and path.stat().st_size==identity['bytes']
   p=read(path);assert p['scenario_id']==path.stem and p['selected_branch'] in {'DFF','DFF-ALT'}
   cost=p['full_original_controller_costs_both_branches'];assert cost['attempts']==cost['returns']+cost['exceptions'] and cost['attempts']>=0 and cost['wall_seconds']>=0
   metrics=p.get('selected_final_metrics') or {};value=metrics.get('uv_count')
   known=p.get('valid') is True and p.get('exact_shared_root_verified') is True and type(value) is int and 0<=value<=118
   rows.append({'scenario_id':p['scenario_id'],'scenario_sha256':p['scenario_sha256'],'selected_branch':p['selected_branch'],'source_valid':p['valid'],'selected_final_uv':value,'ceiling_class':'ZERO_STRICT_UV_WIN_IMPOSSIBLE' if known and value==0 else 'POSITIVE_HEADROOM_NOT_ACHIEVABLE_BENEFIT_PROOF' if known else 'UNKNOWN','full_original_controller_costs_both_branches':cost,'selected_entire_prefix_normal_upper':p['every_prefix_normal_upper_by_branch'][p['selected_branch']],'new_calls':0})
   input_checks.append({'arm':arm,'path':str(path.relative_to(ROOT)),'sha256':identity['sha256'],'bytes':identity['bytes']})
  identityset={(r['scenario_id'],r['scenario_sha256']) for r in rows}
  assert len(identityset)==31
  if ids is None:ids=identityset
  else:assert identityset==ids
  zero=sum(r['ceiling_class']=='ZERO_STRICT_UV_WIN_IMPOSSIBLE' for r in rows);positive=sum(r['ceiling_class']=='POSITIVE_HEADROOM_NOT_ACHIEVABLE_BENEFIT_PROOF' for r in rows);unknown=31-zero-positive
  upper=sum(r['selected_final_uv'] for r in rows if r['ceiling_class']!='UNKNOWN')
  arms[arm]={'all_worlds_retained':31,'zero_UV_primary_ceiling_worlds':zero,'positive_UV_worlds':positive,'unknown_worlds':unknown,'strict_UV_win_fraction_ceiling':positive/31 if unknown==0 else None,'optimistic_mean_UV_gain_ceiling':upper/31 if unknown==0 else None,'unknown_inclusive_conservative_mean_ceiling':(upper+118*unknown)/31,'rows':rows,'no_favorable_world_selection_or_claimed_counterfactual_outcome':True}
 result={'arms':arms,'proof':protocol['proof'],'scope_limits':['UV only; does not rule out secondary vmin, action or economic changes','Original DSE may have abnormal-band states; UV floor alone does not certify protection','Positive baseline UV does not prove any admissible better continuation or LLM learnability','All historical worlds remain development, not confirmation','No selected residual-world evaluation or revival of stopped routes','Guarded reference is separate and guard improvement is not LLM attribution'],'no_new_science':True,'overall_LLM_superiority':'UNACHIEVED'}
 write(OUT/'Input_Identity_Checks.json',input_checks);write(OUT/'Results.json',result)
 write(OUT/'Actual_Costs.json',{'actual_pid':os.getpid(),'new_scientific_calls':0,'scalar_portfolio_files_read':62,'new_PF_model_fit_optimizer_controller_forecast_solve_cloud_calls':0,'workflow_seconds_before_manifest':time.perf_counter()-start,'prior_collection_and_replay_costs':'RETAINED_PER_WORLD_BOTH_BRANCH_COSTS; NOT_FREE; NOT_RERUN'})
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
 print(json.dumps({a:{k:v for k,v in r.items() if k!='rows'} for a,r in arms.items()}))
if __name__=='__main__':
 try:main()
 except BaseException as e:
  if OUT.is_dir():write(OUT/'Failure.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'exception':type(e).__name__,'message':str(e),'state':'TERMINAL_READONLY_PARTIAL_NO_AUTOMATIC_RETRY','new_scientific_calls':0})
  raise
