"""Freeze a different, saved-only causal numerical screen before outcomes."""
import copy, json, os
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal
from public_size_local_preservation_v2 import extended
from saved_query_receipt_anchored_dataset import EXPECTED_ORIGINAL_EVIDENCE
from paid_feedback_acquisition_inputs import DATA_FILES
from paid_feedback_acquisition_control import ARMS, VARIANTS, choose_query, interpolate

OUT = extended(ROOT/'outputs/critical_research_reset_20261010/paid_feedback_acquisition_preparation')


def run():
    assert not OUT.exists(); OUT.mkdir()
    write(OUT/'preparation.claim', {'pid': os.getpid(), 'started_at_utc': datetime.now(timezone.utc).isoformat()})
    sources = ('work/paid_feedback_acquisition_control.py', 'work/paid_feedback_acquisition_inputs.py',
        'work/run_paid_feedback_acquisition_screen.py', 'work/audit_paid_feedback_acquisition_screen.py',
        'work/saved_query_receipt_anchored_dataset.py', 'work/prepare_paid_feedback_acquisition_screen.py',
        'work/candidate_process_evidence_utils.py', 'work/public_size_local_preservation_v2.py')
    protocol = {'declared_at_utc': datetime.now(timezone.utc).isoformat(), 'purpose': 'Necessary historical OPT causal query support/numerical screen; no LLM value or physical performance claim',
        'all239_OPT_inputs_23_worlds': True, 'held72_sessions_and_metrics_blocked': True, 'all52_unlabelled_OPT_states_retained_UNKNOWN': True,
        'arms': list(ARMS), 'queries_per_state': 8, 'API_request_bound_including_terminal_operation': 9,
        'budget_justification': 'One fixed eight-query screen retains the existing native K8 diagnostic scale and permits two same-bus feedback anchors without testing the full legal table. It is a development design choice, not an inferred optimal deployment budget. No sweep or outcome-based shortening.',
        'stop_rule': 'Exactly min(8,legal action count) distinct queries; no oracle/coverage/score threshold stopping. Then best actually accepted/converged returned original score, or abstain. One irreversible saved commitment; successors unused for performance.',
        'hypothesis': 'Within-state paid global feedback can correct numerical-prior ranking on the full original action universe through reusable same-bus Q residuals. This numerical mechanism test does not establish a language-pretraining mechanism.',
        'feedback_rule': 'For each bus/global metric, add piecewise-linear observed-minus-predicted residual from returned finite converged receipts, zero residual at Q0, constant after largest measured Q. UV rounded/clamped, deficit nonnegative, vmax>=vmin. No cross-bus transfer, monotonicity guarantee or invented successor vector.',
        'ranking': 'All original legal bus/Q actions retained. Finite predictions ranked by estimated original verifier plus COMMON normal guard, original lexicographic score, then native bus/Q order. Unavailable/nonphysical forecasts remain legal at tail, not imputed safe/failing.',
        'primary': 'K8 recorded-best inclusion, conditional on the fixed originally measured OPT oracle states, averaged equally by original world. All239 input/world denominators and conservative missing-label bounds separately retained.',
        'secondary_prefixes': [1,4], 'secondary_metrics': ['accepted/rejected/unknown queries','zero-UV protected selection','score of committed nomination','all world gains/losses','software cost'],
        'numerical_mechanism_gate': {'minimum_equal_world_improvement_over_both_static_controls': .05, 'minimum_positive_worlds_against_each_static': 3, 'no_unsafe_or_unqueried_commit': True},
        'headroom_gate': 'If 1 minus strongest control lower-bound K8 inclusion is below0.05, the fixed measured-state target cannot supply a five-point gain even to an oracle. This is a scoped upper bound, not universal LLM failure. Otherwise headroom is necessary, not sufficient.',
        'unknown_costs': 'Saved lookup time is not deployed PF time; per-query PF counts/timers absent. Aggregate original PF timing remains descriptive and separately paid. No economic/deployment gate can PASS from this replay.',
        'automatic_model_GPU_physical_training_launch': False, 'required_before_future_model': ['justified language-relevant mechanism','strong trained same-information acquisition control','actual loader/context/gradient/checkpoint journals','architecture/pretraining control','measured complete tool/inference costs','unused confirmation and actual matched DSE trajectories'],
        'not_new_science': ['no new nonlinear PF','no native affine forecast or linear solve','no pretrained model or language generation','no optimizer/controller/cloud allocation'],
        'new_numerical_arithmetic_is_charged': 'Each priority evaluation and interpolated metric estimate counted; complete saved-replay/reader workflow charged.',
        'resource_bound_seconds': 600, 'resource_bound_scope': 'Loading and scientific replay loop; checked before further policy calls. Closing, hashing, sealing and external reading are separately charged preservation costs, not a science extension.', 'no_retry_or_budget_extension': True,
        'original_evidence_sha256': dict(EXPECTED_ORIGINAL_EVIDENCE),
        'source_sha256': {n: sha(ROOT/n) for n in sources}, 'prior_data_sha256': {n: sha(ROOT/n) for n in DATA_FILES},
        'literature': {'LMABO': 'https://arxiv.org/html/2602.07904v1', 'boundary': 'Adaptive evidence/acquisition selection is prior art; this screen makes no novelty claim. LMABO continuous BO/tool costs do not establish grid superiority.'}}
    write(OUT/'Protocol.json', protocol)
    # NEW labelled software checks; no actual-data performance or prior suite rerun.
    before = {'uv_count': 1, 'deficit_sum': .1, 'vmin': .85, 'vmax': 1.}
    view = {'current_model_input': {'original_Q_grid': [25.,50.], 'current_physical_observation': {'global_metrics': before}},
            'legal_queries': [{'bus':0,'Q_index':0},{'bus':0,'Q_index':1},{'bus':1,'Q_index':0}], 'past_requested_receipts': []}
    values = [{'bus':0,'Q_index':0,'metrics':{'uv_count':1,'deficit_sum':.04,'vmin':.91,'vmax':1.02}},
              {'bus':0,'Q_index':1,'metrics':{'uv_count':1,'deficit_sum':.01,'vmin':.94,'vmax':1.04}},
              {'bus':1,'Q_index':0,'metrics':{'uv_count':1,'deficit_sum':.03,'vmin':.92,'vmax':1.03}}]
    priors = {v:copy.deepcopy(values) for v in VARIANTS}; checks=[]
    assert interpolate([(25.,.02),(50.,.04)],12.5)==.01 and interpolate([(25.,.02)],100.)==.02
    checks.append('fixed interpolation and constant extrapolation arithmetic')
    response = {'request':{'bus':0,'Q_index':0}, 'response':{'status':'known_saved_verifier_receipt','verifier':{'converged':True,'after':{'uv_count':1,'deficit_sum':.09,'vmin':.86,'vmax':1.08}}}}
    view['past_requested_receipts']=[response]
    assert choose_query(view,priors,'old_static')=={'bus':0,'Q_index':1}
    assert choose_query(view,priors,'old_feedback')=={'bus':1,'Q_index':0}
    checks.append('actual returned numerical error changes feedback next query; static remains fixed')
    mutated=copy.deepcopy(view); mutated['past_requested_receipts'][0]['response']['verifier']['after']=dict(values[0]['metrics'])
    assert choose_query(mutated,priors,'old_feedback')=={'bus':0,'Q_index':1}
    checks.append('feedback response, not administrator coverage, controls correction')
    import ast
    tree=ast.parse((ROOT/'work/paid_feedback_acquisition_control.py').read_text(encoding='utf8'))
    imports=[n for n in ast.walk(tree) if isinstance(n,(ast.Import,ast.ImportFrom))]
    assert len(imports)==1 and isinstance(imports[0],ast.Import) and [a.name for a in imports[0].names]==['math']
    assert not any(isinstance(n,ast.Name) and n.id in ('open','eval','exec','__import__') for n in ast.walk(tree))
    checks.append('pure actor module has math only; no filesystem/model/PF imports or dynamic execution')
    assert all(set(p)=={'bus','Q_index','metrics'} for p in values)
    write(OUT/'Software_Readiness.json', {'all_passed':True, 'new_labelled_checks':checks, 'prior11_actual_boundary_and9_anchor_checks_reused_not_repeated':True,
          'new_model_PF_optimizer_calls':0, 'production_journals_present_in_new_runner_source':True})
    write(OUT/'Source_Lock.json', {'protocol_sha256':sha(OUT/'Protocol.json'), **protocol['source_sha256']})
    files={f.name:f for f in OUT.iterdir() if f.is_file() and f.name!='preparation.claim'}
    for n in sources: files['sources/'+Path(n).name]=ROOT/n
    print(json.dumps({'software_checks':len(checks),'archive':seal(OUT,files,'Preparation.zip')}))

if __name__=='__main__': run()
