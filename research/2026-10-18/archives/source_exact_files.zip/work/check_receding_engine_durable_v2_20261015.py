"""Actual all8 paid-decision integration without repeating existing science.

Old forecasts and solved contexts are served from exact paid dependency keys.
Any missing dependency or attempted PF/derivative/solve aborts this software
fixture; it never secretly reruns an old numerical or physical measurement.
"""
import copy,hashlib,json,os,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandapower as pp
import receding_paid_decision_engine_durable_v2 as engine_module
from receding_paid_decision_engine_durable_v2 import PaidDecisionEngine
from dynamic_actual_mask_guidance_v1 import current_inputs,identity
from paid_receding_commit_and_history_v1 import History,initialize
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
from compile_lookahead_paid_input_cache_20261014 import action_key
R=Path(__file__).resolve().parents[1];B=R/'outputs/receding_engine_durable_v2_integration_20261015'
DEP=R/'outputs/receding_warm_dependency_closure_20261015'
PAID=R/'outputs/bounded_paid_lookahead_physics_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
class NoScienceEvidence:
    def __init__(self):self.pack=None;self.events=[];self.costs={'new_scientific_calls':0}
    def admit(self):pass
    def event(self,name,data):self.events.append({'event':name,'data':data})
    def solve(self,*a,**k):raise AssertionError('Warm integration must not repeat science')
def main():
    B.mkdir(exist_ok=False);(B/'contexts').mkdir();start=time.perf_counter()
    put(B/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    dependencies=read(DEP/'Paid_Warm_Dependencies.json');assert read(DEP/'Result.json')['exit_code']==0
    evidence=NoScienceEvidence();pp.runpp=evidence.solve
    for n in ['runopp','rundcpp','rundcopp']:setattr(pp,n,evidence.solve)
    cache=copy.deepcopy(dependencies['cache']);contexts={}
    paths=list((PAID/'actual/contexts').glob('*.npz'))
    paths+=list((R/'outputs/actual_mask_jacobian_engineering_20261014/actual').glob('*Context.npz'))
    paths+=list((R/'outputs/all30_dynamic_actual_guidance_storage_v2_20261014/actual').glob('*.npz'))
    for path in paths:
        with np.load(path,allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
        contexts[identity(c)]=c
    cached_forecasts=dependencies['existing_numeric_forecasts'];lookup_ids={};calls={'context_reuses':0,'forecast_reuses':0}
    def paid_context(net,shared,cost,event):
        exact=current_inputs(net);ident=identity(exact)
        if ident not in shared:raise AssertionError('Unmeasured context in warm software fixture')
        c=shared[ident]
        for k in exact:assert np.array_equal(exact[k],c[k]),k
        lookup_ids[id(c)]=ident;calls['context_reuses']+=1;cost['exact_context_reuses']+=1
        event('exact_paid_context_reused',{'context':ident,'no_new_numerical_call':True});return c,ident
    def paid_forecast(row,c,before):
        ident=lookup_ids[id(c)];key=ident+'|'+action_key(row)
        if key not in cached_forecasts:raise AssertionError('No exact previously paid forecast for software integration')
        calls['forecast_reuses']+=1;return copy.deepcopy(cached_forecasts[key])
    engine_module.compile_current=paid_context;engine_module.forecast=paid_forecast
    _,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    history=History(B/'Complete_Decision_History.bin',source_anchor=sha(Path(__file__)),input_anchor=sha(DEP/'Paid_Warm_Dependencies.json'),max_bytes=128*1024**2)
    cost={k:0 for k in ['public_derivative_attempts','public_derivative_returns','LU_factor_attempts','LU_factor_returns',
        'LU_solve_attempts','LU_solve_returns','RHS_columns','exact_context_reuses','compile_seconds','new_forecasts','exact_paid_forecast_reuses']}
    engine=PaidDecisionEngine(out=B,evidence=evidence,runner=runner,zones=zones,cache=cache,
        blocked=dependencies['blocked_prior_incomplete_identities'],contexts=contexts,numeric_cost=cost,history=history,paid_forecasts=copy.deepcopy(cached_forecasts))
    rows=[]
    for i,e in enumerate(read(OLD/'preparation/Protocol.json')['current_endpoints'],1):
        for j,mode in enumerate(['immediate1_followup16','breadth4_followup4']):
            before,cursor,_=load_endpoint(e);domain=build_current_domain(before,cursor,runner=runner,zones=zones)
            cursor=initialize(before,domain['expanded_cursor_for_separately_fixed_future_protocol'])
            actual=engine.decision(before,cursor,e['world'],mode,0)
            reference=read(PAID/'actual'/f'Branch_{2*i-1+j}.json');ap=actual['plan'];rp=reference['plan']
            assert ap['status']==rp['status'] and ap['selected']['first']==rp['selected']['first'] and ap['selected']['second']==rp['selected']['second']
            assert ap['selected']['measured_leaf']==rp['selected']['measured_leaf'] and ap['selected']['operations']==rp['selected']['operations']
            assert ap['root_queries']==rp['root_queries'] and ap['second_queries']==rp['second_queries']
            assert actual['attributed_costs']['attributed_query_PF_calls']==reference['attributed_costs']['attributed_query_PF_calls']
            assert abs(actual['attributed_costs']['attributed_query_solver_seconds']-reference['attributed_costs']['attributed_query_solver_seconds'])<=1e-9
            rows.append({'world':e['world'],'mode':mode,'exact_same_selected_paid_path':True,
                'endpoint_UV':ap['selected']['measured_leaf']['uv_count'],'operations':ap['selected']['operations'],
                'new_scientific_calls':0,'scope':'Same old observed fixture, new runtime integration only'})
    anchor=history.anchor();history.close()
    assert len(rows)==8 and cost['public_derivative_attempts']==cost['LU_factor_attempts']==cost['LU_solve_attempts']==0
    put(B/'Actual_All8_Warm_Engine_Integration.json',{'at_utc':datetime.now(timezone.utc).isoformat(),
        'status':'PASS_ALL8_EXACT_PAID_PATH_MENU_COST_EQUIVALENCE_WITH_NO_SCIENTIFIC_RERUN',
        'all8_rows':rows,'complete_durable_history_anchor':anchor,'existing_numeric_contexts_reused':calls['context_reuses'],
        'already_paid_forecasts_reused':cost['exact_paid_forecast_reuses'],'new_forecasts':cost['new_forecasts'],'new_PF_model_derivative_solve_forecast_calls':0,
        'workflow_seconds':time.perf_counter()-start,'source_sha256':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),
            R/'work/receding_paid_decision_engine_durable_v2.py',DEP/'Paid_Warm_Dependencies.json']},
        'not_a_new_policy_outcome':True,'new_scientific_campaign_not_started':True})
    print(json.dumps({'all8_warm_paid_engine_fixtures':'PASS','old_forecasts_reused':cost['exact_paid_forecast_reuses'],'new_scientific_calls':0}))
if __name__=='__main__':main()
