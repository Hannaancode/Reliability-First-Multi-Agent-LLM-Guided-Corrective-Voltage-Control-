"""Source-identical controller with fail-closed admission before each decision.

No launch, old-owner resume or new-science authorization is supplied here.
"""
import ast,hashlib,time
from pathlib import Path
import receding_paid_referenced_runtime_v2_20261018 as referenced
from receding_paid_decision_engine_durable_v2 import PaidDecisionEngine as OriginalEngine
from referenced_runtime_input_admission_v1_20261018 import admit_input

class AdmittedPaidDecisionEngine(OriginalEngine):
    def decision(self,original,original_cursor,world,mode,decision):
        self.evidence.admit()
        started=time.perf_counter()
        facts=admit_input(original,original_cursor,world=world,method=mode,decision=decision,
            journal_path=Path(self.out)/'scientific.jsonl',runner=self.runner,zones=self.zones)
        facts.pop('domain')
        seconds=time.perf_counter()-started
        self.evidence.costs.setdefault('input_admission_seconds',0.)
        self.evidence.costs['input_admission_seconds']+=seconds
        self.evidence.event('referenced_input_admission_before_query',{**facts,'input_admission_seconds':seconds})
        return super().decision(original,original_cursor,world,mode,decision)

# Compile the exact already source-locked controller class into a private
# namespace. Only its engine dependency changes; every original run/commit/
# query/checkpoint/cold/deadline statement remains unchanged.
node=next(n for n in ast.parse(referenced.changed).body if isinstance(n,ast.ClassDef) and n.name=='PaidRecedingRuntime')
env=referenced.PaidRecedingRuntime.__init__.__globals__.copy()
env['PaidDecisionEngine']=AdmittedPaidDecisionEngine
exec(compile(ast.Module(body=[node],type_ignores=[]),str(referenced.SOURCE),'exec'),env)
PaidRecedingRuntime=env['PaidRecedingRuntime']
SOURCE_CERTIFICATE={'controller_class_AST_unchanged':True,
    'original_runtime_sha256':hashlib.sha256(referenced.SOURCE.read_bytes()).hexdigest(),
    'referenced_transport_binding_sha256':hashlib.sha256(Path(referenced.__file__).read_bytes()).hexdigest(),
    'new_boundary':'Budget admission, current input/source/schema/encoding admission, paid CPU timing and durable source event BEFORE original decision engine.',
    'no_model_physics_launch_or_old_owner_resume':True}
