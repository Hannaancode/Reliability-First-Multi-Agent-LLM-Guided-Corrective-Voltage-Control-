# Paused by user

Paused at 2026-10-06T18:40:41.918311+00:00. No automatic resume is scheduled.

- Matched HG-SE versus D-SE campaign: 62/62 case checkpoints saved, including RNG checkpoints. The campaign finished; 60 paired terminal outcomes are valid and two invalid cases remain recorded.
- AC reference campaign: 11/62 complete cases saved. Partial work for `rev_unseen_combined_load_1p3_line_167_MG2` is retained separately. Resume the same frozen protocol and recompute the unfinished case.
- Central comparison: bank execution has not started. Setup recorded a service-unavailable Colab request, followed by a continuation AssertionError. Diagnose the saved setup status before allocating another GPU runtime.
- Remaining local experiment and follow-up jobs were stopped. Colab cleanup: `recorded_runtime_not_assigned`.
- Frozen model, settings, case bank, and original archives remain unchanged. Manuscript review stays deferred; cybersecurity follows the four reviewer experiments.

On resume, read `pause_status.json`, `ac_reference_campaign_status.json`, and `next_gpu_stage_status.json` first. Continue the AC reference from the completed checkpoints using `work/physics_env/Scripts/python.exe work/run_ac_reference_campaign.py`. Inspect the saved central setup failure before retrying its existing development validation. Do not regenerate assets or change the frozen protocol.
