"""Fail-closed registration gates for the requested same-case federation table.

Software only. This module neither simulates nor fits any controller. An admitted
registration still needs its actual loader, execution/preservation and reader.
"""
from dataclasses import dataclass
from typing import Optional, Tuple


class Incomparable(ValueError):
    pass


@dataclass(frozen=True)
class Task:
    plant_sha256: str
    root_sha256: str
    solver_contract_sha256: str
    actuator_contract_sha256: str
    observation_contract_sha256: str
    protection_contract_sha256: str
    horizon: int = 25
    full_bus_count: int = 118

    def validate(self):
        for name in ('plant_sha256', 'root_sha256', 'solver_contract_sha256',
                     'actuator_contract_sha256', 'observation_contract_sha256',
                     'protection_contract_sha256'):
            value = getattr(self, name)
            if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
                raise Incomparable('Missing exact contract: ' + name)
        if self.horizon != 25 or self.full_bus_count != 118:
            raise Incomparable('Wrong federation horizon or all-bus score scope')


@dataclass(frozen=True)
class Method:
    name: str
    variant: str
    task: Task
    source_sha256: str
    checkpoint_sha256: Optional[str]
    learned: bool
    actual_loaded: bool
    source_plant_sha256: str
    named_retraining_or_port: bool
    teacher_or_test_leak: bool
    cold_cursor_verified: bool


def admit(reference: Task, method: Method):
    reference.validate()
    method.task.validate()
    if method.task != reference:
        raise Incomparable('Not the same root/information/actions/protection/horizon/solver')
    if method.teacher_or_test_leak:
        raise Incomparable('Unavailable outcome or teacher information exposed')
    if not method.source_sha256 or len(method.source_sha256) != 64:
        raise Incomparable('Actual executed source must be pinned')
    if method.learned and (not method.checkpoint_sha256 or not method.actual_loaded):
        raise Incomparable('Trained checkpoint and actual loader not established')
    if method.learned and method.source_plant_sha256 != reference.plant_sha256 and not method.named_retraining_or_port:
        raise Incomparable('Native foreign-plant weights cannot be relabelled as federation weights')
    if not method.cold_cursor_verified:
        raise Incomparable('Complete controller/cost/query/model/RNG cursor not cold verified')
    return {'method': method.name, 'variant': method.variant, 'registration_only': True,
            'performance_execution_admitted': False}


@dataclass(frozen=True)
class Outcome:
    case_id: str
    method: str
    task: Task
    status: str
    residual_uv: Optional[int]
    residual_ov: Optional[int]
    source_and_continuous_physics_audit: bool
    costs_complete: bool
    charged_branches: Tuple[str, ...]
    portfolio: Optional[str] = None


def assess_pair(left: Outcome, right: Outcome):
    left.task.validate()
    right.task.validate()
    if left.case_id != right.case_id or left.task != right.task:
        raise Incomparable('Case-name/bus-count equality cannot replace exact task identity')
    for row in (left, right):
        if row.status != 'COMPLETE' or not row.source_and_continuous_physics_audit or not row.costs_complete:
            return 'UNKNOWN'
        if row.residual_uv is None or row.residual_ov is None:
            return 'UNKNOWN'
        if isinstance(row.residual_uv, bool) or isinstance(row.residual_ov, bool):
            raise Incomparable('Boolean is not a violation count')
        if not isinstance(row.residual_uv, int) or not isinstance(row.residual_ov, int):
            raise Incomparable('Violation counts must be integer')
        if min(row.residual_uv, row.residual_ov) < 0 or row.residual_uv + row.residual_ov > row.task.full_bus_count:
            raise Incomparable('Invalid all-bus violation counts')
        required = {'HG-SE': {'DFF', 'HG-VF'}, 'D-SE': {'DFF', 'DFF-ALT'}}.get(row.portfolio)
        if required and set(row.charged_branches) != required:
            raise Incomparable('Full BOTH-branch costs missing')
    # Full normal-band restoration is primary. Never call a UV improvement
    # that introduces overvoltage a normal-band win.
    left_safe = left.residual_uv == left.residual_ov == 0
    right_safe = right.residual_uv == right.residual_ov == 0
    if left_safe != right_safe:
        return 'LEFT_RESTORATION_WIN' if left_safe else 'RIGHT_RESTORATION_WIN'
    return 'BOTH_RESTORED' if left_safe else 'NEITHER_RESTORED_REPORT_UV_OV_SEPARATELY'


def cohort_gate(expected_ids, rows):
    if len(expected_ids) != len(set(expected_ids)):
        raise Incomparable('Duplicate expected case IDs')
    if len(rows) != len({r.case_id for r in rows}):
        raise Incomparable('Duplicate outcome case IDs')
    actual = {r.case_id for r in rows}
    if actual - set(expected_ids):
        raise Incomparable('Out-of-cohort records')
    if actual != set(expected_ids) or any(r.status != 'COMPLETE' or not r.costs_complete or
                                         not r.source_and_continuous_physics_audit or
                                         r.residual_uv is None or r.residual_ov is None for r in rows):
        return 'UNKNOWN_INCOMPLETE_COHORT'
    return 'COMPLETE_REQUIRED_EVIDENCE_PRESENT_NOT_A_SUPERIORITY_CLAIM'
