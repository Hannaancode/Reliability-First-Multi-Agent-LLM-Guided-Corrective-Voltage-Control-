"""Additive analysis binds three new native contracts; old unknown table stays."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/r118_remaining_native80_contracts_preparation_20261022'
old=R/'work/summarize_verified_r118_first_round_20261022.py';s=old.read_text('utf-8')
s=s.replace("O=R/'outputs/r118_first_round_missing_only_report_20261022'","O=R/'outputs/r118_first_round_missing_only_report_v2_20261022'")
s=s.replace("outputs/r118_first_round_missing_only_preparation_20261022/Analysis_Lock.json","outputs/r118_remaining_native80_contracts_preparation_20261022/Analysis_Lock_V2.json")
needle="    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')"
addition="""    C=R/'outputs/r118_remaining_native80_contracts_execution_20261022'
    assert read(R/'outputs/r118_remaining_native80_contracts_handoff_20261022/Completion.json')['status']=='PRIMARY_AND_FIRST_NEW_RETURN_READER_ENDED'
    ca=read(R/'outputs/r118_remaining_native80_contracts_independent_20261022/Independent_Audit.json')
    cr=read(C/'Results.json');cp=read(R/'outputs/r118_remaining_native80_contracts_preparation_20261022/Protocol.json')
    assert ca['first_independent_PF_replays']==3 and ca['maximum_numeric_field_delta']==0. and len(cr['rows'])==3
"""
assert s.count(needle)==1;s=s.replace(needle,addition+needle)
needle="    for i,d in enumerate(decl):"
addition="""    for j,(target,contract) in enumerate(zip(cp['targets'],cr['rows'])):
        i=target['original_declared_identity'];assert records[i]['status']=='PRIOR_COLLISION_UNKNOWN_NO_CALL'
        assert contract['case_id']==decl[i]['case_id'] and contract['action']==decl[i]['action'] and contract['exception'] is None
        source=C/f'query_{j:02d}.json'
        records[i]=dict(records[i],status='RETURNED_NEW_NATIVE80_CONTRACT_ADDENDUM',paid_matches=[dict(source=source.relative_to(R).as_posix(),source_sha256=sha(source))])
"""
assert s.count(needle)==1;s=s.replace(needle,addition+needle)
s=s.replace("if status=='PAID_NATIVE80_REUSE_NO_NEW_PF':","if status in ['PAID_NATIVE80_REUSE_NO_NEW_PF','RETURNED_NEW_NATIVE80_CONTRACT_ADDENDUM']:")
s=s.replace("isinstance(value,dict) and set(value)=={'net'}","isinstance(value,dict) and 'net' in value")
s=s.replace("primary_costs=result['costs'],first_independent_replays=audit['first_independent_PF_replays']", "primary_costs=dict(original_missing_only_batch=result['costs'],new_contract_addendum=cr['costs']),first_independent_replays=audit['first_independent_PF_replays']+ca['first_independent_PF_replays']")
s=s.replace("maximum_field_delta=audit['maximum_field_delta'],maximum_KCL_pu=audit['maximum_KCL_pu']", "maximum_field_delta=max(audit['maximum_field_delta'],ca['maximum_numeric_field_delta']),maximum_KCL_pu=max(audit['maximum_KCL_pu'],ca['maximum_KCL_pu'])")
new=R/'work/summarize_verified_r118_first_round_v2_20261022.py';assert not new.exists();new.write_text(s,encoding='utf-8')
with (P/'Analysis_Lock_V2.json').open('x',encoding='utf-8') as f:json.dump(dict(source=new.relative_to(R).as_posix(),sha256=hashlib.sha256(new.read_bytes()).hexdigest(),
    source_score_and_tie_handling_unchanged=True,all_original2034query_rows_retained=True,original_unknown_report_preserved=True,only_new3verified_contract_receipts_added=True,
    no_new_PF_model_or_fitting_calls=True,only_after_actual_all_contract_actors_ended_and_independent_pass=True),f,indent=2)
