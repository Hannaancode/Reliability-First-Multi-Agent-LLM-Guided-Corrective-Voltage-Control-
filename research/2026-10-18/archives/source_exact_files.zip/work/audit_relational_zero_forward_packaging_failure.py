"""Independent closed zero-forward failure audit; no scientific rerun."""
import json,subprocess
from datetime import datetime,timezone
from candidate_process_evidence_utils import ROOT,read,write,sha,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';E=P/'cuda_integration_execution';S=E/'staged/study'
OUT=P/'cuda_zero_forward_failure_audit';assert not OUT.exists();OUT.mkdir()
state=read(E/'status.json');assert state['runtime_released'] and state['all_actual_artifacts_preserved'] and state['remote_exit_code']==1
for script,pid in [('run_relational_cuda_integration_colab.py',int((E/'owner.claim').read_text())),
 ('continue_relational_cuda_audit.py',read(P/'cuda_audit_continuation/owner.claim')['pid'])]:
    command=f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; if ($p -and $p.CommandLine -match '{script}') {{ 'LIVE' }} else {{ 'ENDED' }}"
    r=subprocess.run(['powershell','-NoProfile','-Command',command],capture_output=True,text=True,timeout=30);assert r.stdout.strip()=='ENDED'
manifest=read(S/'Closed_Actual_Manifest.json')
for n,v in manifest.items():assert (S/n).stat().st_size==v['bytes'] and sha(S/n)==v['sha256']
events=[json.loads(l) for l in (S/'events.jsonl').read_text().splitlines()]
assert len(events)==1 and events[0]['event']=='terminal_failure'
failure=read(S/'Terminal_Failure.json');assert failure['exception']=='ModuleNotFoundError'
assert failure['message']=="No module named 'candidate_process_pretrained_loader'"
assert all(v==0 for v in failure['actual_counts_lower_bounds'].values())
assert read(E/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
payload=read(P/'cuda_integration_preparation_v2/Cloud_Payload_Manifest.json')
assert 'work/candidate_process_pretrained_loader.py' not in payload['members']
assert 'from candidate_process_pretrained_loader import' in (ROOT/'work/candidate_process_trainability_contract_v2.py').read_text()
audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,
 'actual_third_T4_allocation_and_exact_release_verified':True,'111_dependencies_verified':True,
 'scientific_forward_backward_optimizer_PF_generation_attempts_returns_all_zero':True,
 'missing_transitive_private_loader_import_proved':True,'old_partial_load_and_wall_costs_not_free':True,
 'actual_partial_model_load_workflow_seconds':failure['seconds'],
 'actual_owned_workflow_seconds':(datetime.fromisoformat(state['finished_at_utc'])-datetime.fromisoformat(state['started_at_utc'])).total_seconds(),
 'actual_masks_private_final_tensor_preservation_gradients_CUDA_memory_and_learning_gates_unknown':True,
 'no_completed_or_partial_scientific_forward_is_repeated_by_a_new_packaging_continuation':True,
 'bounded_same_profile_new_control_continuation_requires_frozen_import_closure_and_fresh_ownership':True,
 'new_model_PF_optimizer_cloud_calls_by_reader':0}
write(OUT/'Independent_Zero_Forward_Failure_Audit.json',audit)
files={'science/'+n:S/n for n in manifest};files['science/Closed_Actual_Manifest.json']=S/'Closed_Actual_Manifest.json'
files.update({'audit.json':OUT/'Independent_Zero_Forward_Failure_Audit.json','actual_owned_status.json':E/'status.json',
 'actual_log.txt':E/'staged/pilot.log','payload_manifest.json':P/'cuda_integration_preparation_v2/Cloud_Payload_Manifest.json',
 'source/failed_remote.py':ROOT/'work/relational_cuda_integration_remote.py',
 'source/audit.py':ROOT/'work/audit_relational_zero_forward_packaging_failure.py'})
seal(OUT,files,'Verified_Zero_Forward_Packaging_Failure.zip');print(json.dumps(audit,indent=2))
