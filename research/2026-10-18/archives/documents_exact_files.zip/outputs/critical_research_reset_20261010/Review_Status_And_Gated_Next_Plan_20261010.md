# Review status and the next candidate plan

10 October 2026. This responds to the human's question about the earlier critical review and a90%-confidence plan. It records a research recommendation, not a launch-ready empirical protocol or a probability of success. No new scientific call or allocation is made by this document.

The focused critical literature/evidence review was completed and written today. Relevant full-text sections were examined subsequently; some sources were available only as abstracts or indexed publisher text. It is not an exhaustive novelty certificate, an independent reproduction of every paper, or a completed review of all original/Sheena notebook contents. The original training/serving reconciliation remains in progress.

## What the review established

The preserved original0.5B proposer did learn its command format. Later structured-head failures and the public unadapted1.5B malformed-output screen do not erase that achievement or constitute a matched adapted-scale comparison. Several subsequent genuine learning runs changed weights and lowered losses without beating the strongest decision controls. Correct training execution is insufficient evidence of better control.

The literal DFF immediate-score maximizer cannot be beaten on that same state, completely verified candidate set and score merely by predicting it more accurately. This scoped ceiling does not prove that its two-branch portfolio is episode-optimal or that its search order is economical. It gives a reason to study a different costed question rather than repeat scalar/head training.

The recovered original notebook materially corrects the earlier raw-data interpretation: the candidate final ultra_v1 recipe uses compact512-token chats and packing=False. Eleven saved training arguments and five LoRA configuration checks match. Saved precursor lengths peak at461 before the training formatter's extra EOS. Earlier raw4096 length and full-target bounds do not describe this effective compact objective. Historical masks/base snapshot and actual compact dataset bytes remain unresolved.

## Recommended research hypothesis

Preserve the paper's zone proposer, physical verifier and coordinator. Investigate whether an adapted small language model can choose the next legal action to VERIFY from the full native action universe, then update its next choice from actually returned physical feedback. Only an accepted verified action can be committed; explicit abstention and unknown outcomes remain. A1.5B proposer is the human-requested candidate capacity, not evidence of a useful mechanism or an automatic allocation decision.

The desired measured contribution is equal or better protected recovery with lower COMPLETE cost, or better protected recovery at a prospectively fixed comparable cost. Pay for inference, numerical priors, verification, preparation, training, failures and both literal D-SE branches. A smaller query budget or common guard alone is not an improvement. Do not replace actual complete trajectories with cached-label ranking results.

This is a hypothesis, not a fully specified learning algorithm. The causal current/history representation, receipt-conditioned deployed objective, legal query/commit/stopping rules, persistent collector and budgets still need an evidence-supported prospective specification. Generic adaptive acquisition is already prior art: [LMABO](https://arxiv.org/html/2602.07904v1) uses an LLM over a numerical predictor and optimization feedback. A specific contribution beyond that precedent is not yet established.

## Order of work and stop gates

1. **Recover and align the original role.** Obtain actual compact data and remaining training/serving source evidence. Verify actual input tokens, label spans, legal output actions and the source of every current feature. Retain the original trained0.5B unchanged. A new training implementation with unresolved historical differences must disclose them; it is not a pure parameter-count experiment.
2. **Establish opportunity before large model work.** Use complete trustworthy receipts and an outcome-independent declared measurement set to determine whether feedback can improve acquisition over equally informed deterministic and strong trained numerical policies. Preserve the existing replay partial and its UNKNOWN gates; do not restart it, reinterpret missing outcomes as failures or alter its thresholds. Missing query times and counterfactual successors remain UNKNOWN. Require credible full-cost break-even; aggregate controller timing is not per-query timing. Lack of support or an optimistic ceiling below the declared useful effect stops this proposal.
3. **Only a surviving mechanism receives a small fixed model pilot.** Freeze one data/world partition, objective, seed, budget and final checkpoint before outcomes. Implement actual causal contexts, loss labels, gradients/memory, full optimizer/RNG/cursor checkpoints and incremental preservation first. Include the preserved0.5B role baseline, equally informed trained numerical acquisition policy and appropriate architecture/pretraining attribution control. Old smoke tests do not certify a new input or objective. Valid JSON, lower loss and more parameters are readiness or secondary measurements.
4. **Confirm physical and economic value.** A development result can justify separately prospective fresh trajectories. Compare original DFF and DFF-ALT individually and their unchanged selector, with FULL BOTH-branch costs, common raw scopes/verifier/normal-band protection and continuous independent replay. Use genuinely unused authorized worlds for confirmation. All known failures, partials, rejected actions and missing outcomes remain reported. Failed measured gates stop this intervention; no outcome-driven LR/prompt/Q/seed/checkpoint/threshold sweeps.

The requested aligned1.5B command-format/action comparison is a legitimate engineering question. It must not be sold as the novel acquisition method or assumed to improve protected recovery. No1.5B training or acquisition campaign has started from this recommendation.

## What90% can and cannot mean

There is no calibrated90% probability that this candidate is novel or will beat D-SE. Assigning that number now would be invented. Cheap exact tests can disprove a SPECIFIED impossible contract or inadequate opportunity ceiling; passing them does not guarantee a model will learn useful decisions.

If the human wants a90% statistical confidence level for an eventual measured effect, the estimand, practically useful margin, world-level sampling/paired analysis, power assumptions and missing/failure rules must be fixed before genuinely unused confirmation. A confidence interval concerns the inferential procedure under those assumptions; it is not a90% chance that the next experiment will win. No sample-size or power calculation is certified here.

The present decision is therefore: continue source/data/causal-opportunity/economic/novelty work, not another full learned-head campaign. Overall validated incremental LLM advantage, D-SE superiority and full security remain unachieved.

Evidence: Critical_Review_and_Research_Decision.md; Full_Text_Assumption_Review_20261010.md; Post_15B_Mechanism_And_Comparator_Critical_Review.md; Paid_Feedback_Acquisition_Prospective_Review.md; paid_feedback_partial_gate_interpretation/Decision.md; original_compact_training_contract_review/Source_Recovery_Correction_And_Next_Decision.md. Primary-source verification in this response also opened LMABO v1, [grammar-constrained logical parsing](https://aclanthology.org/2025.acl-industry.34/) and [DAgger](https://proceedings.mlr.press/v15/ross11a.html); no new grid-performance result is inferred from them.
