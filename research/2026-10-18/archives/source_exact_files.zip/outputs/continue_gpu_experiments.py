"""Dependency-ordered continuation of the currently authorized experiments.

Waits for the running paired campaign's checkpoint/release, then performs
historical central GPU validation before its locked-bank paired experiment.
No scheduled automation, token persistence, tuning on locked cases, or cyber work.
"""
from pathlib import Path
from types import SimpleNamespace
import concurrent.futures,json,logging,subprocess,sys,time,uuid,shutil
from datetime import datetime,timezone
from checkpoint_io import read_json_ready
from google_account_profile import credential_path, verify_account, expected_account
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True);logging.disable(logging.CRITICAL)
root=Path('outputs');state={'stage':'waiting_for_main_campaign','central_bank_started':False,'runtime_released':False};status_path=root/'next_gpu_stage_status.json'
history=root/'execution_history'/datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_central_attempt');history.mkdir(parents=True,exist_ok=True)
for name in ['next_gpu_stage_status.json','colab_frozen_restore_status.json','continuation_colab_environment_prepare.log','resume_colab_environment_prepare.log']:
    p=root/name
    if p.exists():shutil.copy2(p,history/name)
def save():status_path.write_text(json.dumps(state,indent=2))
def local_script(name):
    with (root/('continuation_'+name.removesuffix('.py')+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,'work/'+name],stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode==0,'Continuation prerequisite script failed: '+name
save();print('CENTRAL_GPU_STAGE_QUEUED_AFTER_MAIN_CAMPAIGN',flush=True);started=time.monotonic()
while time.monotonic()-started<43200:
    supervisor=read_json_ready(root/'campaign_supervisor_status.json')
    if supervisor['status'] in ['interrupted','time_limit_reached']:
        state.update(stage='waiting_on_campaign_recovery',blocker='Main campaign interrupted; no central bank run started. Preserve and resume main checkpoints first.');save();print('CENTRAL_STAGE_BLOCKED_BY_MAIN_CAMPAIGN_INTERRUPTION',flush=True);sys.exit(0)
    if supervisor['status']=='complete' and supervisor.get('runtime_released'):
        assert len(list((root/'matched_campaign/cases').glob('*.json')))==62;break
    time.sleep(20)
else:
    state.update(stage='dependency_wait_limit',blocker='The preceding main campaign did not complete and release within the bounded 12-hour wait.');save();sys.exit(0)
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from colab_cli.runtime import ColabRuntime
from colab_cli.contents import ContentsClient
runtime=None;session=None;endpoint=None
try:
    state['stage']='preparing_same_frozen_environment';save()
    if '--reuse-prepared' not in sys.argv:
        local_script('prepare_remote_bundle.py');local_script('colab_environment_prepare.py')
    restore=read_json_ready(root/'colab_frozen_restore_status.json');assert restore['created_by_this_task'] and restore['stage']=='frozen_model_loaded' and not restore['runtime_released']
    credentials=Credentials.from_authorized_user_file(str(credential_path()));credentials.refresh(Request());session=AuthorizedSession(credentials);client=Client(Prod(),session)
    state['verified_google_account']=verify_account(session)
    if expected_account():assert restore.get('verified_google_account')==expected_account(), 'Prepared runtime belongs to a different credential profile'
    assignment=client._get_assignment(uuid.UUID(restore['notebook_hash']),variant=Variant.GPU,accelerator=Accelerator.T4);assert hasattr(assignment,'runtime_proxy_info');endpoint=assignment.endpoint
    runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-central-reviewer-execution')
    contents=ContentsClient(SimpleNamespace(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token))
    for name in ['central_ablation.py','run_central_experiment.py','analyze_central_campaign.py']:contents.upload('work/'+name,'content/hiergrid_execution/work/'+name)
    code="""
import os,subprocess,json
from pathlib import Path
os.chdir('/content/hiergrid_execution')
for stage,args in [('central_gpu_development',['--development','--resume']),('central_matched_campaign',['--locked','--resume'])]:
 log=open('outputs/'+stage+'.log','w')
 proc=subprocess.Popen(['env/bin/python','work/run_central_experiment.py',*args],stdout=log,stderr=subprocess.STDOUT)
 print('HIERGRID_CENTRAL_STAGE_STARTED',stage,proc.pid,flush=True)
 code=proc.wait();log.close()
 print('HIERGRID_CENTRAL_STAGE_FINISHED',stage,code,flush=True)
 assert code==0,'Central stage failed; inspect saved logs and checkpoints'
"""
    def stream(out):
        if out.get('output_type')=='stream':
            for line in out.get('text','').splitlines():
                if line.startswith('HIERGRID_CENTRAL_'):print(line,flush=True)
    def execute():return runtime.execute_code(code,allow_stdin=False,timeout=43200,output_hook=stream)
    state.update(stage='central_gpu_development',notebook_hash=restore['notebook_hash']);save()
    seen={'central_gpu_development':set(),'central_matched_campaign':set()};errors=0
    pool=concurrent.futures.ThreadPoolExecutor(max_workers=1)
    try:
        future=pool.submit(execute);started=time.monotonic()
        while time.monotonic()-started<43200:
            try:
                for name in ['central_gpu_development_validation.json','central_experiment_protocol.json','central_gpu_development.log','central_matched_campaign.log']:
                    try:contents.download('content/hiergrid_execution/outputs/'+name,str(root/name))
                    except FileNotFoundError:pass
                for stage in seen:
                    dest=root/stage;dest.mkdir(exist_ok=True)
                    for name in ['progress.json','config.json']:
                        try:contents.download('content/hiergrid_execution/outputs/'+stage+'/'+name,str(dest/name))
                        except FileNotFoundError:pass
                    if not (dest/'progress.json').exists():continue
                    p=json.loads((dest/'progress.json').read_text());state[stage+'_completed_count']=p['completed_count']
                    if stage=='central_matched_campaign':state.update(stage='central_matched_campaign',central_bank_started=True)
                    for idx,sid in enumerate(p['completed_ids'],1):
                        if sid in seen[stage]:continue
                        case=dest/'cases'/(sid+'.json');case.parent.mkdir(exist_ok=True);contents.download('content/hiergrid_execution/outputs/'+stage+'/cases/'+sid+'.json',str(case))
                        rng=dest/'rng'/f'{idx:03d}.pt';rng.parent.mkdir(exist_ok=True);contents.download('content/hiergrid_execution/outputs/'+stage+'/rng/'+rng.name,str(rng));seen[stage].add(sid);print('CENTRAL_DOWNLOADED_CHECKPOINT',stage,idx,sid,flush=True)
                errors=0;save()
            except Exception as exc:
                errors+=1;state['last_download_failure_type']=type(exc).__name__;save()
                if errors>=3:raise RuntimeError('Repeated failure downloading own central runtime; complete local checkpoints preserved')
            if future.done():
                outputs=future.result();failed=any(x.get('output_type')=='error' for x in outputs)
                # Fetch the final progress and any last case/RNG pair before release.
                for stage in seen:
                    dest=root/stage
                    try:contents.download('content/hiergrid_execution/outputs/'+stage+'/progress.json',str(dest/'progress.json'))
                    except FileNotFoundError:continue
                    final=json.loads((dest/'progress.json').read_text());state[stage+'_completed_count']=final['completed_count']
                    for idx,sid in enumerate(final['completed_ids'],1):
                        if sid in seen[stage]:continue
                        case=dest/'cases'/(sid+'.json');case.parent.mkdir(exist_ok=True);contents.download('content/hiergrid_execution/outputs/'+stage+'/cases/'+sid+'.json',str(case))
                        rng=dest/'rng'/f'{idx:03d}.pt';rng.parent.mkdir(exist_ok=True);contents.download('content/hiergrid_execution/outputs/'+stage+'/rng/'+rng.name,str(rng));seen[stage].add(sid)
                for name in ['central_gpu_development_validation.json','central_experiment_protocol.json']:
                    try:contents.download('content/hiergrid_execution/outputs/'+name,str(root/name))
                    except FileNotFoundError:pass
                done=(root/'central_matched_campaign/progress.json').exists() and json.loads((root/'central_matched_campaign/progress.json').read_text())['status']=='complete'
                state['stage']='complete' if done and not failed else 'central_stage_failed_or_incomplete';save();break
            time.sleep(20)
        else:raise RuntimeError('Central execution reached its bounded 12-hour cap')
    finally:pool.shutdown(wait=False,cancel_futures=True)
except Exception as exc:
    setup=read_json_ready(root/'colab_frozen_restore_status.json') if (root/'colab_frozen_restore_status.json').exists() else {}
    state.update(stage='interrupted',failure_type=type(exc).__name__,setup_failure_http_status=setup.get('failure_http_status'),setup_failure_type=setup.get('failure_type'),setup_assignment_state=setup.get('post_failure_assignment_state'),blocker='Continuation failed or a prerequisite/runtime became unavailable; inspect sanitized setup status, experiment logs and preserved complete case/RNG checkpoints.');save();print('CENTRAL_CONTINUATION_FAILURE_TYPE',type(exc).__name__,flush=True)
finally:
    if runtime is not None:
        try:runtime.stop()
        except Exception:pass
    if endpoint is not None:
        try:client.unassign(endpoint);state['runtime_released']=True;restore['runtime_released']=True;(root/'colab_frozen_restore_status.json').write_text(json.dumps(restore,indent=2))
        except Exception as exc:state['release_failure_type']=type(exc).__name__
    if session is not None:session.close()
    save();print('CENTRAL_CONTINUATION_FINAL_STAGE',state['stage'],flush=True)
