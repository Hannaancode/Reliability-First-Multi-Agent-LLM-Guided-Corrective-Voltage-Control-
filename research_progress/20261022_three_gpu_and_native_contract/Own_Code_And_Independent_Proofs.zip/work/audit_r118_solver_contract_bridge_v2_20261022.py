"""Prepared ONLY: first independent new80 replay, no old50rerun."""
import hashlib,json,os,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/r118_solver_contract_bridge_preparation_20261022';E=R/'outputs/r118_solver_contract_bridge_execution_20261022';O=R/'outputs/r118_solver_contract_bridge_independent_20261022'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    p=read(P/'Protocol.json');approval=read(P/'Explicit_Human_Clarification.json');assert approval['approved_single_new80_measurement_and_first_verification'] and approval['protocol_sha256']==sha(P/'Protocol.json')
    O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    claimed=time.monotonic()
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-claimed<120;time.sleep(.1)
    ack=read(O/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid()
    end=read(R/'outputs/r118_solver_contract_bridge_coordination_v2_20261022/End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp,numpy as np
    from reflection118_chronological_core_20261022 import decode,frames_equal
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    for name,h in read(E/'Closed_Manifest.json')['members'].items():assert sha(E/name)==h
    result=read(E/'Result.json');assert result['exception'] is None,'Never replay failed scientific calls'
    net=decode(E,result['before'])['net'];reference=decode(E,result['after'])['net'];start=time.perf_counter();pp.runpp(net,**p['new_native_kwargs']);frames_equal(net,reference);delta=0.
    for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
        a=net[name].select_dtypes(include=[np.number]).to_numpy(float);b=reference[name].select_dtypes(include=[np.number]).to_numpy(float)
        assert a.shape==b.shape and np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True);m=np.isfinite(a)&np.isfinite(b);delta=max(delta,float(np.max(abs(a[m]-b[m]),initial=0)))
    q=net._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0];V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]));kcl=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
    put(O/'Independent_Audit.json',{'status':'PASS_FIRST_NEW80_CONTRACT_REPLAY_ALL_FIELDS_AND_KCL','maximum_field_delta':delta,'KCL_pu':kcl,'new80first_replay_calls':1,'old50calls_repeated':0,'new_model_calls':0,'seconds':time.perf_counter()-start,'does_not_certify_all_other50_vs80contexts':True})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
if __name__=='__main__':main()
