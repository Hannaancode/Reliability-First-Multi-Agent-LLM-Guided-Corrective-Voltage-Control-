"""Consolidate actual closed evidence, stopped interventions and next work."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/verified_benchmark_model_and_router_state_20261022'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def write(p, v):
    Path(p).write_text(json.dumps(v, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def main():
    O.mkdir(exist_ok=False)
    now = datetime.now(timezone.utc).isoformat()
    numeric = read(R / 'outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json')
    assert numeric['status'] == 'COMPLETE_SAME500_PHYSICAL_NUMERICAL_VS_PUBLISHED_COMPARISON'
    assert numeric['fixed_gate'].startswith('FAIL_')
    private = read(R / 'outputs/native13_fullband_original_adapter_engineering_independent_20261021/Independent_Functional_Audit.json')
    private_cert = read(R / 'outputs/native13_fullband_model_terminal_artifact_certification_v2_20261021/Terminal_Artifact_Certification.json')
    base = read(R / 'outputs/native13_adapter_disabled_diagnostic_independent_v2_20261021/Independent_Functional_Audit.json')
    base_end = read(R / 'outputs/native13_adapter_disabled_diagnostic_reader_repair_coordination_20261021/End_ACK.json')
    assert base_end['actual_owned_chain_ended'] and base_end['exit_code'] == 0
    assert private_cert['source_bound_reader_completed_artifacts']
    for name in ['native13_fullband_original_adapter_engineering_execution_20261021', 'native13_adapter_disabled_diagnostic_execution_20261021']:
        s = read(R / 'outputs' / name / 'status.json')
        assert s['runtime_released'] and s['all_actual_closed_artifacts_preserved'] and s['remote_exit_code'] == 0
    complement = read(R / 'outputs/public13_expert_complementarity_development_20261021/Saved_Expert_Complementarity_And_Prospective_Question.json')
    fresh = read(R / 'outputs/public13_fresh_input_router_preparation_v2_20261021/Independent_Input_Audit.json')
    result = {'at_utc': now, 'status': 'NUMERICAL500_AND_BOTH_MODEL_TESTS_CLOSED_ALL_GATES_REPORTED_NO_ACTIVE_OWNERS',
              'numeric': {'fixed_gate': numeric['fixed_gate'], 'summaries': numeric['summaries'],
                          'paired_tests': numeric['primary_paired_tests'],
                          'strata': numeric['input_defined_strata_descriptive'],
                          'primary_costs': numeric['numeric_actual_primary_costs'],
                          'independent_costs': numeric['numeric_actual_independent_costs'],
                          'full_fields_max_delta': 0.0},
              'original_private_adapter_native_role_test': {
                  'physical_input_states': 2, 'primary_zone_prompts': 6, 'fresh_load_repetitions': 6,
                  'strict_legal_or_null': private['strict_JSON_or_null'],
                  'fixed_gate': private['fixed_functional_gate'], 'costs': private['actual_model_costs'],
                  'new_PF': 0, 'weights_unchanged_and_cold_exact': True,
                  'reader_OS_exit_UNRECOVERED_preserved': True,
                  'closed_source_bound_artifact_certification': 'outputs/native13_fullband_model_terminal_artifact_certification_v2_20261021/Terminal_Artifact_Certification.json',
                  'not_original_federation_paper_performance': True},
              'adapter_disabled_diagnostic': {
                  'same6_input_SHA256': base['identical_six_input_file_sha256'],
                  'strict_legal_or_null': base['strict_JSON_or_null'], 'gate': base['fixed_functional_gate'],
                  'costs': base['actual_model_costs'], 'all12_hit384_token_limit': base['actual_model_costs']['generated_token_count'] == 12 * 384,
                  'new_PF': 0, 'all6_cold_sequences_exact': True,
                  'original_reader_path_failure_retained': 'outputs/native13_adapter_disabled_diagnostic_handoff_20261021/Reader_Owner_Protocol.json.log',
                  'additive_path_only_first_output_reader': 'outputs/native13_adapter_disabled_diagnostic_independent_v2_20261021/Independent_Functional_Audit.json',
                  'interpretation': 'Disabling LoRA did not restore native instruction/command validity. No uniquely LoRA-specific cause, universal small-model inability or model replacement success is established.'},
              'conditional_UV_only_stop_ceiling': {'value': 249, 'denominator': 500,
                  'proof': 'outputs/paper_uv_stop_public13_ceiling_20261021/Independent_Conditional_Bound_Audit.json',
                  'conditional_not_observed_model_score': True},
              'posthoc_complementarity': {k: complement[k] for k in ['status', 'saved_route_fullband',
                  'saved_route_remaining_UV', 'saved_route_remaining_OV', 'published_only_input_router_saved_fullband',
                  'all3_published_available_trajectory_envelope_fullband']},
              'fresh_router_preparation': fresh,
              'current_owned_jobs': [], 'current_owned_GPUs': [], 'waiting_timers': [],
              'deleted_old_waiting_timer': 'hiergrid-matched-numerical-benchmark-result-check',
              'all6finalgoals': 'OPEN',
              'last_verified_GitHub': 'b7e0e6404ac6d22ebfcd503a968662d2e5128b86',
              'new_work_not_yet_published': True,
              'next_ordered_tasks': [
                  'Complete and freeze the fresh128 router worker, partial-aware independent reader, causal initial route plans, separate mutable SafeDDPG model states, native controls, paid history, source/cost/persistent warm-cold/ownership fixtures. No source or budget changes to old studies.',
                  'Only when all actual gates pass, execute the source-order new128 comparison once, including every control and unknown/adverse outcome. Fresh128 recipes and arithmetic/no-repeat input audit are complete, but physics has not started.',
                  'Publish verified closed benchmark/model results, source proofs, tasks and code to existing GitHub branch with fresh lease and byte checks; private weights/NET/checkpoints stay local.',
                  'Do not retune the failed private interface or its decoder, switch in a diagnostic control as a repaired primary, or train from software success. Any future LLM mechanism requires justified target/information/support/economic/strong-numerical-control gates.',
                  'Original literal DFF+DFFALT+unchanged selector and FULL BOTH costs remain primary original-domain references. Original137paper benefit and all frozen/failed/partial/unknown evidence stay intact.'],
              'claim_scope': 'Native public13 benchmark differs from federation118highUV cases. Saved496/500 route is post-hoc, not an executed controller, LLM benefit, calibrated confidence, novelty or unused confirmation.'}
    write(O / 'Verified_Closed_Results_And_Exact_Resume.json', result)
    report = '''# Verified benchmark and model results

All500same public13starting cases; strict all13voltage-band endpoint, not full AC feasibility.

| Controller | Full13band restored | Remaining UV | Remaining OV |
|---|---:|---:|---:|
| Published Safe-DDPG |262/500|0|324|
| Published linear |258/500|0|345|
| Published DDPG |363/500|59|121|
| Our frozen numerical controller |264/500|765|5|

The fixed numerical superiority gate FAILED. Differences versus Safe-DDPG and linear were not significant; NUM was inferior to DDPG on the registered fullband endpoint. All151near-boundary failures remain failures. NUM uses global13VM/currentY; source actors consume local VM and source stopping checks only3controlled buses. These are three policies from one external publication family.

The frozen original trained0.5B LoRA was tested on six new signed-native prompts across two physical states, with six fresh-load repetitions. All six copied placeholders rather than legal numeric commands. Twelve generations/204forward calls were retained, noPF or training. The same pinned0.5Bbase with the adapter disabled also produced0/6valid outputs; all12control generations reached384tokens (4608forward calls). That diagnostic does not uniquely blame LoRA or establish universal model inability. Original private weights are unchanged; the newly pinned public NF4base is disclosed because the exact historical SFTbase revision is unrecovered. Neither test is a full original-paper/federation performance score.

The private-model reader produced its source-bound closed audit but its launcher failed a PID-ACK assertion after the fast reader ended. The original reader OS exit remains UNKNOWN; additive saved-artifact certification preserved that failure without repeating science. The base-control reader failed before output analysis at an incorrect protocol filename; an additive path-only reader completed the first output audit with0newmodel/PF. All failures, sources and stderr remain retained. Both exactT4assignments were released.

Complementarity is substantial: Safe-DDPG restored232/232UV-only cases; NUM restored247/251OV-only cases. Selecting their existing branches using the INITIAL violation class gives496/500,0UV/5OV. This is a POST-HOC DEVELOPMENT ASSEMBLY, not an executed new controller or anLLMresult. A published-only input rule gives381/500; the full3published available-trajectory envelope gives383/500. Native SafeDDPG changes b/c during inference, so a new router must maintain its own causal model state rather than copy standalone outcomes.

New source-generated recipes1000..1127 are prepared and independently checked:128distinct physical regimes,0intersections with the scoped closed history,0newphysics. External checkpoint training overlap is UNKNOWN. A complete worker/independent reader/persistence/source/ownership/cost protocol is still required before execution. This proposed controller combines a PUBLISHED Safe-DDPG expert with OUR unchanged numerical controller; it is not the original paper LLM or a new learned model.

The source-proved UV-only stopping ceiling is249/500 for an adaptation retaining that stop in both branches. It explains why an OV-aware role is necessary; it does not invalidate the paper's original UV-focused137case result (HG-SE193versusDFF290remainingUV).

All six final goals, including original-domain zeroUV, LLM superiority and full security, remain OPEN. No current owned worker/GPU or waiting timer remains at this checkpoint. The next useful work is the fresh128 router execution implementation and evidence publication, not prompt/threshold/checkpoint sweeps.
'''
    (O / 'Results_And_Next_Execution.md').write_text(report, encoding='utf-8')
    current = R / 'outputs/full_system_comparison_20261021/Current_Resume.json'
    state = read(current)
    state.update(at_utc=now, status=result['status'], current_single_scientific_owner=None,
                 current_single_independent_reader=None, current_sole_coordinator=None,
                 current_GPU_engineering_owner=None, current_GPU_engineering_coordinator=None,
                 current_GPU='No ownedGPU; both exactT4s released. Other current availability/freehours/reset UNKNOWN.',
                 current_waiting_check=None, timers=[],
                 latest_verified_closed_results=O.relative_to(R).as_posix() + '/Verified_Closed_Results_And_Exact_Resume.json',
                 next_ordered_tasks=result['next_ordered_tasks'],
                 next_dependency='Fresh128 full actual worker/reader/persistent-state/source/ownership gates; no current live job to poll.',
                 native_public13_numeric_fixed_gate=numeric['fixed_gate'],
                 original_adapter_new_native_role_fixed_gate=private['fixed_functional_gate'],
                 base_activation_diagnostic=base['fixed_functional_gate'],
                 saved_expert_route_not_actual_new_controller={'fullband': 496, 'cases': 500, 'new_PF': 0, 'not_LLM': True})
    write(current, state)
    tasks_path = R / 'outputs/research_tasks_20261014/Tasks.json'
    tasks = read(tasks_path)
    tasks.update(updated_at_utc=now, latest_resume=current.relative_to(R).as_posix(), latest_verified_resume=result['status'])
    g3 = next(t for t in tasks['tasks'] if t['checklist_id'] == 'G3')
    g3.update(status=result['status'], current_result='NUM264/500 versusDDPG363/500 fixed gateFAIL; originaladapter0/6native commands and basecontrol0/6both cold-exact, noPF. Saved complementarity496/500 is posthoc; new128input/source arithmetic auditPASS, actual router execution pending.')
    for task in g3['subtasks']:
        if task['id'] == 'G3.2aa_20261021':
            task.update(completed=True, evidence='outputs/native13_fullband_model_terminal_artifact_certification_v2_20261021/Terminal_Artifact_Certification.json', verified_at_save=now,
                        result='Measured fixed functional gateFAIL; original reader launcher failure and OSexitUNKNOWN preserved separately.')
    additions = [
        ('G3.3a_20261021', True, 'Complete same500fixedNUMphysical policy, all1071newPF first replays/16144continuous decisions/dense-dual/cold/cost audit and locked paired tests; preserve failed primary superiority gate.', 'outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json'),
        ('G3.2ab_20261021', True, 'Complete same6prefix LoRA-disabled diagnostic with6primary+6cold,0/6valid, source/cost audit; original failed reader path and additive0science repair retained.', 'outputs/native13_adapter_disabled_diagnostic_independent_v2_20261021/Independent_Functional_Audit.json'),
        ('G3.3b_20261022', False, 'Freeze and execute genuine new128input-router comparison with causal native model state, strong same-input controls/fullcosts/independent continuous replay; saved496is not actual performance.', 'outputs/public13_fresh_input_router_preparation_v2_20261021/Prospective_Router_Protocol.json')]
    for task_id, completed, text, evidence in additions:
        assert not any(t['id'] == task_id for t in g3['subtasks'])
        g3['subtasks'].append({'id': task_id, 'completed': completed, 'description': text,
                              'evidence': evidence, 'verified_at_save': now if completed else None})
    write(tasks_path, tasks)
    latest_path = R / 'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json'
    latest = read(latest_path)
    latest.update(updated_at_utc=now, status=result['status'], current_single_scientific_owner=None,
                  current_single_independent_reader=None, current_sole_coordinator=None,
                  current_waiting_check=None, latest_resume=current.relative_to(R).as_posix())
    write(latest_path, latest)
    header = f'''## Closed benchmark/model results and fresh router preparation — {now}

Same500NUMcomparison independently complete:264fullband/765UV/5OV, versusDDPG363/59/121. Fixed primary gateFAIL; all151near-boundary failures retained. Private0.5Bnewnative interface0/6valid and same-base adapter-disabled control0/6valid, all12outputs/cold sequences perstudy retained,0PF/training; bothT4sreleased. Source-bound reader failures and additive saved-only/path-only repairs are preserved, including unrecovered original private-reader OSexit.

Saved complementary branches give496/500(0UV/5OV), versus published-onlyinputrouter381andfull3policyenvelope383. This is posthoc development, NOT an executed controller/LLMwin. New128source-generated recipes1000..1127 have independent exact arithmetic/scoped no-repeat inputPASS,0newphysics; source worker/reader/persistent model-state/cost/ownership gates remain unfinished. No current owned job/GPU/waiting timer. Continue substantive fresh128 implementation and publication; never poll/restart ended owners or retune old failures.

Exactresume outputs/verified_benchmark_model_and_router_state_20261022/Verified_Closed_Results_And_Exact_Resume.json. All six final goals OPEN. Original frozenassets, original137paperbenefit, literalDFF+DFFALT+unchangedselector/FULLBOTH and all adverse/partial/UNKNOWN evidence preserved.

'''
    for n in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        p = R / n
        p.write_bytes(header.encode('utf-8') + p.read_bytes())
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n' + header + report + '\n')
    print(json.dumps({'saved': O.relative_to(R).as_posix(), 'NUM_fixed_gate': numeric['fixed_gate'],
                      'original_LoRA_valid': private['strict_JSON_or_null'], 'base_control_valid': base['strict_JSON_or_null'],
                      'current_GPU': None, 'saved_route_496_NOT_actual_controller': True, 'all6goals': 'OPEN'}))


if __name__ == '__main__':
    main()
