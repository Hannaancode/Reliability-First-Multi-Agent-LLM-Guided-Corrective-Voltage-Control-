"""Exercise the complete shared initializer and pure native APIs, zero fresh PF."""
from pathlib import Path
import sys,ast,json,hashlib,traceback
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'work'))
OUT=ROOT/'outputs/tpa_native_wrapper_complete_readiness_v3_20261020'
def main():
    OUT.mkdir(exist_ok=False);source=ROOT/'work/tpa_native_one_step_engineering_v3_20261020.py';tree=ast.parse(source.read_text(encoding='utf-8'))
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main');body=next(n for n in fn.body if isinstance(n,ast.Try)).body;prefix=[]
    for node in body:
        if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='original_runpp' for x in node.targets):break
        prefix.append(node)
    env={'ROOT':ROOT,'PREP':ROOT/'outputs/tpa_native_one_step_preparation_20261020','OUT':OUT,'event':lambda *a,**k:None,'sha':lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(),'put':lambda p,v:Path(p).write_text(json.dumps(v,indent=2),encoding='utf-8'),'json':json,'Path':Path,'hashlib':hashlib}
    try:
        exec(compile(ast.Module(body=prefix,type_ignores=[]),str(source),'exec'),env)
        np=env['np'];native=env['env'];args=env['args'];native.powergrid.res_bus=env['pd'].DataFrame(np.zeros((len(native.powergrid.bus),4)),index=native.powergrid.bus.index,columns=['vm_pu','va_degree','p_mw','q_mvar']);combo=native.get_obs();native._cal_mask();native._cal_adj_matrix()
        assert np.array(combo['agents_obs']).shape==(38,234) and combo['time_obs'].shape==(38,100,3)
        assert np.array_equal(args.obs_bus_num,native.get_obs_bus_num()) and np.array_equal(args.agent2region,native.get_agent2region()) and np.array_equal(args.agent_index_in_obs,native.get_agent_index_in_obs())
        assert all(np.array_equal(x,y) for x,y in zip(args.region_adj,native.get_region_adj())) and native.get_avail_actions().shape==(1,38,1)
        (OUT/'Result.json').write_text(json.dumps({'status':'PASS_FULL_PURE_INITIALIZER_NATIVE_OBSERVATION_ADJACENCY_ACTION_AVAILABILITY','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fixture_kind':'EXPLICIT_MOCK_RESULT_FRAME_FOR_SOFTWARE_CONTROL_FLOW_ONLY_NOT_FRESH_PHYSICS_OR_POLICY_VALUE','new_model_forward_PF_calls':0,'obs_shape':[38,234],'history_shape':[38,100,3],'all_expected_derived_arrays_equal':True},indent=2),encoding='utf-8');print('Complete initializer/pure native API fixture PASS;0freshPF/model')
    except BaseException as e:(OUT/'Failure.json').write_text(json.dumps({'failure':str(e),'traceback':traceback.format_exc(),'new_model_PF_calls':0}),encoding='utf-8');raise
if __name__=='__main__':main()
