# Static DFF continuation-state review — 2026-10-11

This is a source-only review. No retained dataset, outcome, archive, or model artifact was opened; no controller, import, PF, forecast, fit, or hashing operation was run. Only this new report was written. It does not establish an LLM advantage over the original literal D-SE with unchanged selector and full costs of both branches. That goal remains unachieved. Missing or unmeasured continuations remain UNKNOWN.

## Source-defined process

The literal DFF function is `work/e/audit/run_reflection_v4_safety_envelope.py:586`. `runner.MAX_ITERATIONS` is forced to 25 at line 31, and the frozen loader repeats that setting (`work/frozen_physics_loader.py:36`). A causal state immediately before a candidate search comprises:

- The current network and solved numerical state, zone membership, source/runtime and PF settings, and active verifier/mediation contract.
- The next iteration and remaining budget. A solved observation marked `decision=k` is the state **after commit k**, with root k=0. The next search is decision d=k+1; 25-k slots remain, including that decision. This differs from a search row's `decision=d` (`train_trajectory_measurement_nullable_v2.py:88,106,131`).
- Per-bus counted support and the failed-signature set.
- Selection mode. DFF always selects ordinary DFF; ALT selects the second distinct ranked action only at d=1, then ordinary DFF at every d>1.
- Phase and terminal/resource state. A solved prefix is not automatically an active decision opportunity.

Logs, counters, and prior accepted/rejected candidate verdicts do not themselves influence later DFF choices. They remain necessary evidence for provenance, costs, and terminal/partial classification.

## Caps, candidate order, and memory

`failed_sigs` starts empty (`run_reflection_v4_safety_envelope.py:624`) and is never mutated in the DFF loop. The fallback helper only reads it and skips matching signatures; it does not add rejected tests (`phase2g_rescue_runner.py:386`). ALT preserves this loop. Consequently literal DFF/ALT rejection memory is exactly empty, including after rejected physics tests. A nonempty recorded failed set would require an explanation of changed execution, not an inferred history.

The cumulative cap is 450 MVAr **per bus**, tested by a strict `existing + abs(q) > 450` comparison. `llm_q_abs_at_bus` sums absolute `q_mvar` for every shunt row whose `name` begins `llm_shunt`, without filtering service status or multiplying by step (`phase2g_rescue_runner.py:238,287`). `apply_action` appends a named `llm_shunt` with negative q (`:254`). No global q cap, per-search candidate cap, or rejection-based pruning appears in these paths. The iteration budget is the action budget. Cap-invalid candidates are still returned as rejected candidate rows, but bypass their trial PF.

Fallback uses the sorted union of global UV buses, the 12 globally lowest buses, each zone's worst bus, and anchors [20,37,52,75,117], intersected with existing buses; there are no LLM-proposed buses in DFF (`phase2g_rescue_runner.py:356`; `phase2g_llm_guided_rescue_runner.py:278`). It enumerates bus ascending, then q in [25,50,75,100,125,150,200,250,300], testing the whole pool. The global lowest-bus and zone-lowest operations use pandas `sort_values()` without an explicit stable tie algorithm, so a saved native pool is stronger evidence than recomputing a near-tied cutoff elsewhere.

## Verdict, score, and ties

The original verifier trial-copies the network and checks convergence, `vmax > 1.06`, UV increase, deficit increase above 1e-9, and whether UV, deficit (1e-9), or vmin (1e-9) improves (`phase2g_rescue_runner.py:275`). The guarded measurement adds a separately identified post-verification normal-upper check `vmax <= 1.05 + 1e-8`; it can reject an originally accepted candidate without changing the original source (`value_normal_band_mediation.py:12`). Guarded and original unguarded continuations cannot be treated as one process.

Accepted candidates rank lexicographically by `(after_uv==0, before_uv-after_uv, before_deficit-after_deficit, after_vmin-before_vmin, -abs(q))` (`phase2g_rescue_runner.py:412`). Python `max` retains the first exact-score tie in enumeration order. ALT stable-sorts accepted candidates by this score descending, retains the first representative of each action signature, and chooses representative two at d=1, or the best when none exists (`work/dff_alt.py:4`). Its generated loop changes exactly the `best` expression; d>1 uses ordinary DFF. Different floating scores, even within replay tolerance, are not exact ties.

## What prefixes and records can establish

From a complete ordered committed prefix and known initial counted support, added cap totals can be calculated exactly as initial counted support plus the sum of committed action magnitudes at each bus. Source scenario application does not modify shunts (`phase2d_iterative_blackboard_v0.py:85`). The initial counted total must still be known; a physical snapshot alone does not supply it because `observation()` excludes `name`, including `shunt.name` (`train_trajectory_measurement_nullable_v2.py:13,34`). Different prefixes can be causally equivalent: identical prefix history is sufficient, but unnecessary, when current full network/caps, budget, guard, and continuation mode are equal and DFF memory is empty.

Recorded physical observations supply current tables, metrics, zones, and saved bus pools. They do not explicitly store iteration budget, cap totals, failed memory, guard mode, all top-level network/solver state, or a pending-search/terminal phase. Complete original network and runtime lineage remain relevant to an exact executable continuation claim. A voltage-only state is weaker still. Prefix actions and metrics cannot derive unseen candidate PF outcomes without new physics evaluation.

New `TrainingObserver` records preserve the failed set before search, ordered returned candidates, and original scores (`train_trajectory_measurement_nullable_v2.py:99`). Old reuse sets `measured_decisions=None` but retains `original_candidate_verifications` (`run_guarded_train_trajectory_measurement_native_v3.py:93`). `FullBranchObserver` records action/verdict rows in verification-call order with search decision labels (`value_observe_original_DFF.py:46`). These schemas can support a pure-record reconstruction of original scores and order **if** a future inventory verifies completeness against the source enumeration. This review did not inspect whether any concrete record satisfies that condition. `check_literal_selections` explicitly skips a fresh candidate-detail check when `measured_decisions` is absent; prefix replay is not a candidate-search replay.

The initial PF uses v0 settings (NR, init auto, enforce q limits, max iterations 50). Trial and committed action PF use the base-runner settings (NR, init auto, enforce q limits, max iterations 80, voltage angles enabled). Prefix replay again uses v0 settings. Native replay's 1e-10 voltage certificate and exact UV classification preserve useful evidence, but do not prove native candidate scores, rankings, or trial verdicts (`guarded_native_prefix_replay.py:10`; the two `run_pf` definitions).

## Terminal and partial distinctions

Literal stops are base failure; UV=0 checked at the start of an iteration; no accepted candidate; failed committed-action PF; and exhaustion of 25 iterations. A commit that first achieves UV=0 on iteration 25 can have `full_restoration=True` while its stop reason remains `max_iterations_reached` (`run_reflection_v4_safety_envelope.py:680`). A no-accepted iteration has a search/log row but no commit. A failed execution applies its action before PF and does not roll back; the last solved prefix cannot silently stand in for that failed live state. The externally declared deadline is a separate `BaseException` resource stop and retains partial observations/searches; a partial search may have an attempt without a return (`train_trajectory_measurement_nullable_v2.py:69`; measurement owner `:160`). None of these missing continuations is a success or a negative terminal outcome by imputation.

## Prospective cheap support gate

Grouping all retained edges by exact physical before-observation ID while ignoring caps, budget, prefix, and mode is an optimistic relaxation. Any stricter full-process grouping that is a **refinement of those same IDs** can only split groups. Therefore a complete, unambiguous joined inventory with zero retained later multi-action nodes cannot contain a later full-process fork. This is a statement about retained support only, not future possible alternatives or performance.

Use the actual immutable occurrence's before-prefix k to classify root (k=0) versus later (k>0); child/post indices and branch labels are insufficient. Missing, ambiguous, or incomplete joins retain UNKNOWN. A positive relaxed later fork is `UNKNOWN_NEEDS_FULL_PROCESS`, with no terminal-benefit calculation. If a future equality rule merges current physical IDs by tolerance or a new normalization, recheck the refinement argument.

DFF and ALT introduce diversity only at the root. At the same complete later process state their selector is identical. Later edges from their divergent histories are observations of those histories, not automatically alternative continuations from one common state. The proposed gate can check for retained support without inventing another action, rerunning searches, or reviving the stopped binary root selector.
