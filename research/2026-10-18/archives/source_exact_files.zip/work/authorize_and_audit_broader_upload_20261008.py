"""Record the direct human approval and verify the unchanged prepared export."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/llm_value_broader_development'
read = lambda p: json.loads(p.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
archive = ROOT / 'work/broader_value_model_inputs.zip'
expected = read(OUT / 'GPU_Input_Manifest.json')
assert archive.stat().st_size == expected['bytes'] == 34905869
assert sha(archive.read_bytes()) == expected['archive_sha256'] == '12d9521d472d404d3097323909aa16767773711b10c2083fa9513275641a9c22'
with zipfile.ZipFile(archive) as sealed:
    assert sealed.testzip() is None
    names = sealed.namelist()
    assert len(names) == len(set(names)) == 36
    assert json.loads(sealed.read('CLEAN_VALUE_INPUT_MANIFEST.json')) == expected['members']
    assert set(names) == set(expected['members']) | {'CLEAN_VALUE_INPUT_MANIFEST.json'}
    for name, digest in expected['members'].items():
        assert sha(sealed.read(name)) == digest == sha((ROOT / name).read_bytes())
adaptation = read(OUT / 'program_adaptation_manifest.json')
for section in ['original_programs_preserved_sha256', 'new_programs_sha256']:
    for name, digest in adaptation[section].items():
        assert sha((ROOT / 'work' / name).read_bytes()) == digest
assert sha((OUT / 'clean_value_development_protocol.json').read_bytes()) == adaptation['protocol_sha256']
assert read(OUT / 'gpu_prompt_preflight.json')['passed']
assert not (OUT / 'gpu_execution.claim').exists()
assert not (OUT / 'clean_analysis_continuation.claim').exists()
authorization = {
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'direct_human_message': 'plan for other expermens nad excute also yes upload it',
    'approval_context': 'Direct response to exact bundle/destination question in this chat',
    'archive': archive.relative_to(ROOT).as_posix(),
    'archive_bytes': expected['bytes'],
    'archive_sha256': expected['archive_sha256'],
    'destination_account': 'abdulhannaan2002@gmail.com',
    'payload_members_CRC_and_live_hashes_verified': 35,
    'selected_profile': 'original',
    'allocation_requests_maximum': 1,
    'automatic_profile_fallback': False,
    'credentials_exported': False,
    'scientific_inputs_modified': False,
}
with (OUT / 'Broader_Cloud_Upload_Authorization.json').open('x') as f:
    json.dump(authorization, f, indent=2)
request = read(OUT / 'Cloud_Upload_Approval_Request.json')
request.update(status='direct_human_approved_exact_bundle_and_destination',
               direct_authorization_record='Broader_Cloud_Upload_Authorization.json')
(OUT / 'Cloud_Upload_Approval_Request.json').write_text(json.dumps(request, indent=2))
print('DIRECT_HUMAN_APPROVAL_RECORDED_UNCHANGED_BUNDLE_VERIFIED', len(expected['members']))
