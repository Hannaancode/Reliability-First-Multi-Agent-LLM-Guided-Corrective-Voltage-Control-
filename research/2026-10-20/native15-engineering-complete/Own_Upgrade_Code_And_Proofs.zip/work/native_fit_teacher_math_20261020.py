"""Primary public-derivative LP and separate dense/dual verification; no PF/model API."""
import numpy as np
def propose(net,Y,directory,cost):
    from scipy.sparse import bmat,csc_matrix
    from scipy.sparse.linalg import splu
    from scipy.optimize import linprog
    from pandapower.pypower.dSbus_dV import dSbus_dV
    from native_full_grid_affine_core_20261020 import problem,second_problem
    pp=net._ppc;v=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));pq=np.flatnonzero(pp['bus'][:,1]==1);lookup=net._pd2ppc_lookups['bus'][net.bus.index.to_numpy()];assert len(pq)==12 and not np.any(pp['bus'][:,1]==2);vm=net.res_bus.vm_pu.to_numpy(copy=True);q=net.sgen.q_mvar.to_numpy(copy=True)[:3]
    cost['derivative_attempts']+=1;dm,da=dSbus_dV(csc_matrix(Y),v);cost['derivative_returns']+=1;J=bmat([[da[pq,:][:,pq].real,dm[pq,:][:,pq].real],[da[pq,:][:,pq].imag,dm[pq,:][:,pq].imag]],format='csc');rhs=np.zeros((24,3));order={int(k):i for i,k in enumerate(pq)};control=net._pd2ppc_lookups['bus'][net.sgen.bus.to_numpy()[:3]]
    for i,k in enumerate(control):rhs[12+order[int(k)],i]=1/pp['baseMVA']
    lu=splu(J);cost['LU_returns']+=1;x=lu.solve(rhs);cost['RHS_returns']+=3;assert np.max(np.abs(J@x-rhs))<1e-9;full=np.zeros((13,3));full[pq]=x[12:];S=full[lookup];c,A,b,bounds=problem(vm,S,q);np.savez(directory/'Current_Model.npz',Y=Y,V=v,pq=pq,lookup=lookup,control=control,baseMVA=pp['baseMVA'],vm=vm,q=q,J=J.toarray(),rhs=rhs,response=x,S=S)
    solutions=[]
    for stage in [1,2]:
        if stage==2:c,A,b,bounds=second_problem(c,A,b,bounds,solutions[0].x[-1])
        cost['LP_attempts']+=1;sol=linprog(c,A_ub=A,b_ub=b,bounds=bounds,method='highs',options={'time_limit':10.,'maxiter':10000});cost['LP_returns']+=1;assert sol.success,'Fixed LP failed; no solver/settings retry';solutions.append(sol);np.savez(directory/f'LP{stage}.npz',c=c,A=A,b=b,x=sol.x,ineq=sol.ineqlin.marginals,lower=sol.lower.marginals,upper=sol.upper.marginals)
    return np.clip(-solutions[-1].x[:3],-.3,.3).astype(np.float32),S
def verify(directory,net):
    z=np.load(directory/'Current_Model.npz');Y=z['Y'];v=z['V'];pq=z['pq'];I=Y@v;n=v/np.abs(v);dm=np.diag(v)@np.conj(Y@np.diag(n))+np.diag(np.conj(I))@np.diag(n);da=1j*np.diag(v)@np.conj(np.diag(I)-Y@np.diag(v));J=np.block([[da[np.ix_(pq,pq)].real,dm[np.ix_(pq,pq)].real],[da[np.ix_(pq,pq)].imag,dm[np.ix_(pq,pq)].imag]])
    assert np.allclose(J,z['J'],atol=1e-10,rtol=1e-12) and np.max(np.abs(J@z['response']-z['rhs']))<1e-9
    rhs=np.zeros((24,3));order={int(k):i for i,k in enumerate(pq)}
    for i,k in enumerate(z['control']):rhs[12+order[int(k)],i]=1/float(z['baseMVA'])
    assert np.array_equal(rhs,z['rhs']);full=np.zeros((13,3));full[pq]=z['response'][12:];S=full[z['lookup']];assert np.array_equal(S,z['S']);assert np.array_equal(z['vm'],net.res_bus.vm_pu.to_numpy()) and np.array_equal(z['q'],net.sgen.q_mvar.to_numpy()[:3])
    # Independently reconstruct both LP objectives and constraints.
    rows=[];bs=[]
    for vm,s in zip(z['vm'],S):
        for sign,limit in [(1,1.05),(-1,-.95)]:rows.append(np.r_[sign*s,np.zeros(3),-1.]);bs.append(limit-sign*vm)
        if .95<=vm<=1.05:
            for sign,limit in [(1,1.05),(-1,-.95)]:rows.append(np.r_[sign*s,np.zeros(4)]);bs.append(limit-sign*vm)
    for i in range(3):
        for sign in [1,-1]:row=np.zeros(7);row[i]=sign;row[3+i]=-1;rows.append(row);bs.append(-sign*z['q'][i])
    A=np.asarray(rows);b=np.asarray(bs);c=np.r_[np.zeros(6),1.];cap=float(np.float32(.3));first=None
    for stage in [1,2]:
        f=np.load(directory/f'LP{stage}.npz')
        if stage==2:A=np.vstack([A,np.r_[np.zeros(6),1.]]);b=np.r_[b,first[-1]+1e-10];c=np.r_[np.zeros(3),np.ones(3),0.]
        assert np.array_equal(A,f['A']) and np.array_equal(b,f['b']) and np.array_equal(c,f['c']);x=f['x'];lo=np.r_[np.full(3,-cap),np.zeros(4)];di=f['ineq'];dl=f['lower'];du=f['upper'];assert np.max(A@x-b)<=1e-7 and np.max(lo-x)<=1e-7 and np.max(x[:3]-cap)<=1e-7 and np.max(np.abs(c-A.T@di-dl-du))<=1e-7 and abs(float(c@x-b@di-lo@dl-cap*du[:3].sum()))<=1e-7 and di.max()<=1e-9 and dl.min()>=-1e-9 and du.max()<=1e-9 and np.max(np.abs(du[3:]))<=1e-9;first=x.copy() if stage==1 else first
    return np.clip(-x[:3],-.3,.3).astype(np.float32),S
