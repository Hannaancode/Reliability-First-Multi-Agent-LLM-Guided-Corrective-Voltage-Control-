"""Independent source/case registration and fairness-boundary checks, zero science."""
import json,hashlib,copy
from pathlib import Path
from datetime import datetime,timezone
from common_case_comparison_contract_20261021 import paired,require_record,MATCH_KEYS
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/full_system_comparison_20261021'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def main():
    protocol=read(OUT/'Protocol.json')
    for rel,h in protocol['source_and_input_pins'].items():assert sha(ROOT/rel)==h
    cases=read(OUT/'All203_Existing_Federation_Input_Cases.json');matrix=read(OUT/'Federation_Common_Case_Result_Matrix_Empty.json')
    assert len(cases)==203 and len({c['case_id'] for c in cases})==203 and len(matrix)==203*8
    allcases={c['case_id']:c for c in cases};methods={r['method'] for r in matrix}
    for method in methods:
        rows=[r for r in matrix if r['method']==method];assert len(rows)==203 and {r['case_id'] for r in rows}==set(allcases)
        assert all(r['recipe_sha256']==allcases[r['case_id']]['recipe_sha256'] and r['outcome']=='UNKNOWN_FOR_THIS_PROTOCOL' for r in rows)
    public=read(OUT/'Public_Cohort_Closure.json');assert public['TPA_rows']==120 and public['public13_author_cases']==500
    # Positive and negative records are labelled software fixtures, never benchmark results.
    record={key:'a'*64 if key.endswith('sha256') else 'LABELLED_SOFTWARE_FIXTURE' for key in MATCH_KEYS}
    record.update(controller_id='FIXTURE_LEFT',commitment_horizon=25,status='COMPLETE_INDEPENDENTLY_VERIFIED_TRAJECTORY',source_role='EXPLICIT_PORT',
                  case_in_frozen_manifest=True,actual_policy_inference_preserved=True,continuous_independent_physics_replay=True,
                  all_actual_costs_and_unknowns_disclosed=True,all_case_failures_and_unknowns_retained=True,
                  final_UV=0,final_OV=0,final_vmin=.96,final_vmax=1.04,full_band_restored=True)
    right=copy.deepcopy(record);right['controller_id']='FIXTURE_RIGHT';assert paired(record,right)['left_minus_right_UV']==0
    rejects=[]
    for key in MATCH_KEYS:
        bad=copy.deepcopy(right);bad[key]='b'*64 if key.endswith('sha256') else (26 if key=='commitment_horizon' else 'DIFFERENT')
        try:paired(record,bad)
        except ValueError:rejects.append('mismatch_'+key)
        else:raise AssertionError('Incomparable fixture accepted: '+key)
    changes=[('partial_cannot_be_win',{'status':'PARTIAL'}),('missing_inference',{'actual_policy_inference_preserved':False}),
             ('no_replay',{'continuous_independent_physics_replay':False}),('hidden_costs',{'all_actual_costs_and_unknowns_disclosed':False}),
             ('dropped_failures',{'all_case_failures_and_unknowns_retained':False}),('UVonly_softOV_not_full_restoration',{'final_OV':1,'final_vmax':1.055}),
             ('UNKNOWN_voltage_not_filled',{'final_UV':None})]
    for label,change in changes:
        bad=copy.deepcopy(right);bad.update(change)
        try:paired(record,bad)
        except ValueError:rejects.append(label)
        else:raise AssertionError('Bad fixture accepted: '+label)
    invalid=copy.deepcopy(right);invalid['physical_initial_state_sha256']='PENDING'
    try:require_record(invalid)
    except ValueError:rejects.append('same_seed_pending_full_state_not_enough')
    else:raise AssertionError('Missing initial state allowed')
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_COMMON_CASE_REGISTRATION_AND_INCOMPARABILITY_REJECTION_SOFTWARE_ONLY',
            'exact_federation_case_count':203,'paired_empty_slots':1624,'all_methods_same_case_sets':True,
            'all120_public_schedule_rows_and500_native13_recipes_retained':True,
            'labelled_software_positive_fixture_count':1,'labelled_software_negative_rejections':rejects,
            'benchmark_trajectories_newly_completed':0,'superiority_established':False,
            'not_ready_reasons':protocol['known_ready_gaps'],
            'new_PF_model_GPU_optimizer_forecast_derivative_solve_calls':0,
            'contract_source_sha256':sha(ROOT/'work/common_case_comparison_contract_20261021.py'),
            'audit_source_sha256':sha(Path(__file__))}
    with (OUT/'Independent_Registration_Audit.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps({'case_sets_exact':True,'negative_boundaries_rejected':len(rejects),'new_science':0,'fairness_software_only':True,'performance_ready':False}))
if __name__=='__main__':main()
