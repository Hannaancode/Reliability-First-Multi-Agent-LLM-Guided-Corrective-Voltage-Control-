"""Real CPU tensor/hook boundary checks, with no pretrained model or GPU."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,time,types,traceback
R=Path(__file__).resolve().parents[1];O=R/'outputs/inference_numerical_admission_20261029/tensor_hook'
def main():
    assert not O.exists();O.mkdir();started=time.perf_counter()
    try:
        # Established local MSVC DLL binding; previous direct import failed before
        # Torch initialization, any model call or tensor fixture entry.
        import candidate_process_runtime
        import torch
        from inference_numerical_admission_gate_20261029 import RawLogitObserver,NumericalAdmissionFailure
        torch.set_num_threads(1)
        class Toy(torch.nn.Module):
            def __init__(self,x,named=True):super().__init__();self.x=x;self.named=named
            def forward(self):return types.SimpleNamespace(logits=self.x) if self.named else (self.x,)
        results=[]
        for label,x,named,expected in [('finite',[[[1.,2.,3.]]],True,True),('nan',[[[1.,float('nan'),3.]]],True,False),
            ('positive_infinity',[[[1.,float('inf'),3.]]],True,False),('negative_infinity',[[[1.,-float('inf'),3.]]],True,False),
            ('missing_named_logits',[[[1.,2.,3.]]],False,False)]:
            tensor=torch.tensor(x,dtype=torch.float32);before=tensor.clone();events=[];observer=RawLogitObserver(events.append);module=Toy(tensor,named)
            handle=module.register_forward_hook(observer);continued=False;caught=False
            try:out=module();continued=True
            except NumericalAdmissionFailure:caught=True
            finally:handle.remove()
            assert continued is expected and caught is (not expected) and observer.calls==1
            assert torch.equal(torch.nan_to_num(tensor),torch.nan_to_num(before))
            assert len(events)==1 and (events[0].get('all_finite') is True if expected else True)
            results.append({'case':label,'continued_to_generation_step':continued,'rejected':caught,'input_scores_unchanged':True,'event':events[0]})
        report={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS5_REAL_CPU_TENSOR_FORWARD_HOOK_BOUNDARIES','torch_version':torch.__version__,'results':results,
            'toy_module_forwards':5,'pretrained_model_PF_training_GPU_calls':0,'source_sha256':hashlib.sha256((R/'work/inference_numerical_admission_gate_20261029.py').read_bytes()).hexdigest(),
            'scope':'Real CPU tensor and forward-hook behavior only. No actual pretrained loader or GPU inference integration certified; numerical cause of old1.5B output remains unknown.',
            'prior_import_failure':'Direct vcsa runtime Torch import failed with c10.dll WinError1114 before any fixture/model entry; established candidate_process_runtime MSVC DLL initialization used for this distinct fixture.',
            'workflow_seconds':time.perf_counter()-started,'launch_ready':False}
        (O/'Result.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n','utf-8')
        print(json.dumps({'status':report['status'],'pretrained_calls':0,'GPU_calls':0}))
    except BaseException:
        (O/'Failure.json').write_text(json.dumps({'traceback':traceback.format_exc(),'workflow_seconds':time.perf_counter()-started,'pretrained_model_calls':0},indent=2),'utf-8');raise
if __name__=='__main__':main()
