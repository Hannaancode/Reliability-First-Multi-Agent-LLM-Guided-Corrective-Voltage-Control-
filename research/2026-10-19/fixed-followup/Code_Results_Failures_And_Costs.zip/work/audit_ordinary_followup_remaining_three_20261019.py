"""Frozen independent three-phase saved-result reader, zero scientific calls.

Exact inverse proof retains every original physical/evidence assertion; only
declared phase count, routing, namespace and stronger intermediate-state checks
are added. Reader claim binds THIS entrypoint, avoiding the old claim failure.
"""
import argparse,ast,copy
from pathlib import Path
import audit_exact_two_paid_query_engineering_20261018 as original
from ordinary_followup_remaining_three_core_20261019 import B,PHASES,helpers,transform
from public118_slsqp_native_20261018 import read,put,sha,manifest
EDITS=[
    ("assert runner.rescue.grid_metrics(source['net'])['uv_count']==17", "assert runner.rescue.grid_metrics(source['net'])['uv_count']==12"),
    ("for phase in ('warm','cold'):","for phase in ('warm','cold_1','cold_2'):"),
    ("index=0 if phase=='warm' else 1", "index=p['phases'].index(phase)"),
    ("len(all_messages)==2 and len(replays)==2 and counts['PF_attempts']==4 and counts['PF_returns']==4", "len(all_messages)==3 and len(replays)==3 and counts['PF_attempts']==6 and counts['PF_returns']==6"),
    ("final=restore_state(read(B/'Final_State_ACK.json'));warm=restore_state(read(B/'Warm_State_ACK.json'))", "final=restore_state(read(B/'Final_State_ACK.json'));warm=restore_state(read(B/'Warm_State_ACK.json'));middle=restore_state(read(B/'cold_1_State_ACK.json'))"),
    ("for state in (warm,final):", "for state in (warm,middle,final):"),
    ("assert warm['next_index']==1 and final['next_index']==2 and len(final['paid_query_registry'])==2", "assert warm['next_index']==1 and middle['next_index']==2 and final['next_index']==3 and len(final['paid_query_registry'])==3"),
    ("assert len(history)==2", "assert len(history)==3"),
    ("assert read(B/'cold/Cold_Restore_Proof.json')['status'].startswith('PASS_EXACT_LATEST_QUERY_ONLY_STATE')", "assert all(read(B/ph/'Cold_Restore_Proof.json')['status'].startswith('PASS_EXACT_LATEST_QUERY_ONLY_STATE') for ph in ('cold_1','cold_2'))"),
    ("'PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING'", "'PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'")
]
def compiled_main():
    source=Path(original.__file__).read_text('utf-8');node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    function='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno]);changed=transform(function,EDITS)
    env=original.__dict__.copy();h=helpers(__file__)
    env.update(B=B,claim=h['claim'],admit=h['admit'],input_state=h['input_state'],restore_state=h['restore_state'],verify_file=h['verify_file'])
    exec(compile(changed,str(__file__),'exec'),env);return env['main']
def certificate():
    compiled_main();return {'original_reader_sha256':sha(original.__file__),'all_original_reader_assertions_retained_except_exact_declared_count_routing':True,
        'inverse_source_transform_exact':True,'intermediate_state_check_added':True,'edits':EDITS,'physical_verifier_input_replay_cost_hash_and_frozen_checks_unchanged':True,'new_scientific_calls':0}
def identity_fixture():
    p=read(B/'Protocol.json');h=helpers(__file__);out=B/'fixture_reader';h['claim'](out,p)
    snapshot=original.LockedSourceSnapshot(B/'Protocol.json')
    try:put(out/'Result.json',{'status':'PASS_ACTUAL_READER_SOURCE_PID_PARENT_COMMAND_ACK','new_scientific_calls':0,'reader_certificate':certificate()})
    finally:snapshot.close();manifest(out)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--reader',action='store_true');a.add_argument('--identity-fixture',action='store_true');args=a.parse_args()
    if args.identity_fixture:identity_fixture()
    else:compiled_main()()
