"""New labelled random CPU continuation/transfer tests; no pretrained/GPU/PF."""
import candidate_process_runtime
from pathlib import Path
import copy,json,random,tempfile
import numpy as np
import torch
from candidate_complete_state_and_transfer import *
from candidate_process_evidence_utils import ROOT,read,write,frozen_checks,seal
OUT=ROOT/'outputs/llm_value_candidate_development_20261009/reliable_replication_software_readiness'
assert not OUT.exists();OUT.mkdir()
torch.set_num_threads(2);torch.manual_seed(20261009);random.seed(20261009);np.random.seed(20261009)
model=torch.nn.Sequential(torch.nn.Linear(4,8),torch.nn.Dropout(.2),torch.nn.Linear(8,3))
opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01)
def step(m,o):
    x=torch.randn(3,4)+random.random()+float(np.random.random());target=torch.randn(3,3)
    o.zero_grad(set_to_none=True);y=m(x);loss=(y-target).square().mean();loss.backward();o.step();return y.detach()
for _ in range(2):step(model,opt)
contract={'study_id':'explicit_random_fixture','program_sha256':'fixture'}
checkpoint=full_checkpoint(model.state_dict(),{},opt,[[n for n,p in model.named_parameters()]],
 {'completed_optimizer_steps':2,'next_epoch':1,'next_epoch_offset':2},contract)
assert verify_complete_checkpoint(checkpoint,contract,2)
with tempfile.TemporaryDirectory(prefix='complete_resume_fixture_') as tmp:
    folder=Path(tmp);p=folder/'full_state.pt';torch.save(checkpoint,p)
    loaded=torch.load(p,weights_only=True,map_location='cpu')
    reference=[step(model,opt),step(model,opt)];reference_model=cpu_tree(model.state_dict());reference_opt=cpu_tree(opt.state_dict())
    fresh=torch.nn.Sequential(torch.nn.Linear(4,8),torch.nn.Dropout(.2),torch.nn.Linear(8,3))
    newopt=torch.optim.AdamW(fresh.parameters(),lr=.001,weight_decay=.01)
    fresh.load_state_dict(loaded['common']);newopt.load_state_dict(loaded['optimizer']);restore_rng(loaded['rng'])
    replay=[step(fresh,newopt),step(fresh,newopt)]
    assert all(torch.equal(a,b) for a,b in zip(reference,replay))
    assert all(torch.equal(v,fresh.state_dict()[n]) for n,v in reference_model.items())
    for i,s in reference_opt['state'].items():assert all(torch.equal(v,newopt.state_dict()['state'][i][n]) for n,v in s.items())
    altered=copy.deepcopy(loaded);altered['optimizer']['state'][0]['step']+=1
    try:verify_complete_checkpoint(altered,contract,2)
    except AssertionError:pass
    else:raise AssertionError('Wrong optimizer position accepted')
    try:verify_complete_checkpoint(loaded,{'study_id':'wrong'},2)
    except AssertionError:pass
    else:raise AssertionError('Wrong study contract accepted')
    journal=folder/'events.jsonl';journal.write_text('{"event":"fixture_only"}\n')
    binary=folder/'binary.bin';binary.write_bytes(bytes(np.random.default_rng(20261009).integers(0,256,size=5*1024*1024,dtype=np.uint8)))
    package,descriptor=make_package(folder/'packages',0,{'checkpoints/full_state.pt':p,'binary.bin':binary},journal,contract)
    assert len(descriptor['parts'])>=3 and validate_package(package/'artifact_package.zip',descriptor)
    for bad in ['../escape','C:/escape','/escape','wrong\\path']:
        try:safe_relative(bad)
        except AssertionError:pass
        else:raise AssertionError('Unsafe path accepted')
    before=(package/'artifact_package.zip').read_bytes();badzip=folder/'altered.zip';badzip.write_bytes(before[:-1]+bytes([before[-1]^1]))
    try:validate_package(badzip,descriptor)
    except AssertionError:pass
    else:raise AssertionError('Changed archive accepted')
    try:wait_for_ack(package,descriptor,bound_seconds=.01)
    except TimeoutError:pass
    else:raise AssertionError('Missing acknowledgement did not stop')
    stale=expected_ack(descriptor);stale['number']=99;(package/'ack.json').write_text(json.dumps(stale))
    try:wait_for_ack(package,descriptor,bound_seconds=1)
    except AssertionError:pass
    else:raise AssertionError('Stale acknowledgement accepted')
    (package/'ack.json').write_text(json.dumps(expected_ack(descriptor)));assert wait_for_ack(package,descriptor,1)>=0
report={'all_passed':True,'software_only_random_CPU_forwards':6,'software_only_random_CPU_backwards_optimizer_steps':6,
 'actual_pretrained_GPU_PF_allocation_calls':0,'complete_AdamW_RNG_reload_matches_uninterrupted_outputs_parameters_and_optimizer_exactly':True,
 'incorrect_optimizer_step_and_study_contract_rejected':True,'all_chunk_CRC_hashes_and_journal_prefix_verified':True,
 'tampered_archive_unsafe_paths_missing_and_stale_acknowledgements_rejected':True,
 'source_sha256':sha(Path(__file__)),'helper_sha256':sha(ROOT/'work/candidate_complete_state_and_transfer.py')}
write(OUT/'Software_Readiness.json',report);write(OUT/'Fresh_Frozen_Asset_Audit.json',frozen_checks())
files={p.name:p for p in OUT.iterdir() if p.is_file()};files['helper.py']=ROOT/'work/candidate_complete_state_and_transfer.py';files['test.py']=Path(__file__)
print(json.dumps({'software':report,'archive':seal(OUT,files,'Complete_State_and_Transfer_Software_Readiness.zip')},indent=2))
