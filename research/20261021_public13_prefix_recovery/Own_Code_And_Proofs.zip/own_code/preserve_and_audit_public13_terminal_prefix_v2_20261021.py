"""Additive saved-output/source/equation audit. No policy inference or PF call."""
import ast,copy,hashlib,json,os,pickle,time,traceback,collections
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];PRIMARY=ROOT/'outputs/public13_remaining_published_cohort_20261021';OUT=ROOT/'outputs/public13_terminal_saved_prefix_v2_20261021'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);began=time.monotonic();put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    import candidate_process_runtime,sys
    sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import numpy as np,torch
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    from coordinate_native_inverter_linear_reference_20261020 import process
    p=json.loads((ROOT/'outputs/public13_full_cohort_preparation_20261021/Protocol.json').read_text());end=json.loads((ROOT/p['primary_coordination']/'End_ACK.json').read_text());assert end['actual_owned_chain_ended'] and end['exit_code']==1
    for pid,source in [(13544,'run_public13_remaining_published_cohort_20261021.py'),(6736,'coordinate_public13_cohort_20261021.py')]:
        current=process(pid);assert not current or source not in (current.get('CommandLine') or '')
    assert not (ROOT/'outputs/public13_published_cohort_independent_20261021').exists(),'No reader beside an earlier claim'
    for name,h in p['source_and_input_hashes'].items():assert sha(ROOT/name)==h
    deadline=began+1800;failure=json.loads((PRIMARY/'Failure.json').read_text());assert failure['type']=='AssertionError' and 'final_parameters=parameters()' in failure['traceback'];put(OUT/'Frozen_Before.json',frozen_checks())
    costs={'new_policy_forward_calls':0,'new_PF_calls':0,'new_optimizer_backward_training_calls':0,'new_converter_derivative_factor_solve_calls':0,'saved_b_c_projection_vector_operations':0,'saved_equation_states_checked':0};prior='0'*64;counts=collections.Counter();safe_counts=collections.Counter();attempts={}
    for line in (PRIMARY/'events.jsonl').read_text(encoding='utf-8').splitlines():
        item=json.loads(line);v=item['event'];assert v['previous']==prior and hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==item['sha256'];prior=item['sha256'];counts[v['kind']]+=1
        if v['kind']=='agent_forward_return' and v['algorithm']=='safe-ddpg':safe_counts[v['agent']]+=1
        if v['kind']=='PF_attempt':assert v['index'] not in attempts;attempts[v['index']]=v
    for name,kind in [('PF_attempts','PF_attempt'),('PF_returns','PF_return'),('PF_exceptions','PF_exception'),('agent_forward_attempts','agent_forward_attempt'),('agent_forward_returns','agent_forward_return'),('checkpoint_load_returns','checkpoint_load_return')]:assert counts[kind]==failure['costs'][name]

    import shutil
    previous_output=ROOT/'outputs/public13_terminal_saved_prefix_20261021'
    previous_claim=json.loads((previous_output/'owner.claim').read_text());assert previous_claim['source_sha256']==sha(ROOT/'work/preserve_and_audit_public13_terminal_prefix_20261021.py')
    previous_end=json.loads((ROOT/'outputs/public13_terminal_saved_prefix_coordination_20261021/End_ACK.json').read_text());assert previous_end['actual_owned_chain_ended'] and previous_end['exit_code']==1
    previous_log=(ROOT/'outputs/public13_terminal_saved_prefix_coordination_20261021/Owner.log').read_text();assert 'np.array_equal(q,np.asarray(row' in previous_log
    # The equation loop and source projection completed before this continuity
    # assertion failed. Reuse their exact phase outputs; no repeated KCL/projection.
    for name in ['All_Saved_Equation_Checks.json','Source_Normalization_Diagnosis.json','Derived_Source_Projected_Parameters_NOT_Actual_Final.npz']:shutil.copyfile(previous_output/name,OUT/name)
    index_rows=json.loads((OUT/'All_Saved_Equation_Checks.json').read_text());receipts=failure['receipts'];assert len(index_rows)==len(receipts)==2787
    for r,a in zip(receipts,index_rows):assert a['index']==r['index'] and a['physical_signature']==r['physical_signature'] and a['status']=='SAVED_NATIVE_EQUATIONS_PASS_NEW_SOLVER_REPLAY_NOT_EXECUTED'
    maximum_kcl=max(a['KCL_max_pu'] for a in index_rows);maximum_flow=max(a['complex_branch_flow_max_MVA'] for a in index_rows);assert maximum_kcl<=1e-7 and maximum_flow<=1e-7
    root_recipes=np.load(ROOT/p['recipes']);costs['reused_completed_saved_equation_checks']=len(index_rows)
    diagnosis=json.loads((OUT/'Source_Normalization_Diagnosis.json').read_text());assert diagnosis['status'].startswith('PASS_');costs['inherited_source_state_projection_vector_operations']=sum(a['source_call_count'] for a in diagnosis['saved_state_projections'])
    put(OUT/'Mechanical_Dtype_Repair_Proof.json',{'original_saved_audit_source_sha256':sha(ROOT/'work/preserve_and_audit_public13_terminal_prefix_20261021.py'),'original_saved_audit_end':previous_end,'phase_artifacts_reused':[{'name':n,'sha256':sha(previous_output/n)} for n in ['All_Saved_Equation_Checks.json','Source_Normalization_Diagnosis.json','Derived_Source_Projected_Parameters_NOT_Actual_Final.npz']],'defect':'Raw returned float32 actions were serialized as JSON numbers, then reloaded float64 before clipping. Native clipping uses float32 .3, not float64 .3. Restore source dtype with exact roundtrip check before native clip; do not relax tolerances.','new_model_PF_solver_policy_calls':0,'completed_equation_or_projection_phases_repeated':False})
    complete_worlds=[];branches=[];steps=0
    for world in failure['worlds']:
        seed=world['seed'];d=PRIMARY/f'seed{seed:03d}';root=pickle.loads((d/'Root_Complete_ENV.pkl').read_bytes());assert sha(d/'Root_Complete_ENV.pkl')==world['root_ENV_sha256']
        for n,tab,col in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]:assert np.array_equal(root['network'][tab][col].to_numpy(),root_recipes[n][seed])
        for branch in world['algorithms']:
            current=copy.deepcopy(root);last=np.zeros((3,1));history=[]
            for pos,row in enumerate(branch['steps'],1):
                cursor_file=d/f"{branch['algorithm']}_{pos:03d}"/'Full_Cursor.pkl';assert sha(cursor_file)==row['cursor_sha256'];cursor=pickle.loads(cursor_file.read_bytes());assert cursor['history']==history and cursor['next_step']==pos and cursor['remaining_source_horizon']==101-pos and np.array_equal(cursor['state'],current['state']) and np.array_equal(cursor['last_Q'],last) and signature(cursor['environment']['network'])==signature(current['network'])==row['before_physical_signature'];raw=np.asarray(row['raw_policy'],dtype=np.float32);assert np.array_equal(raw.astype(np.float64),np.asarray(row['raw_policy'],dtype=np.float64));q=last-np.clip(raw,-.3,.3);assert np.array_equal(q,np.asarray(row['absolute_Q_Mvar']));expected=copy.deepcopy(current['network']);expected.sgen.loc[expected.sgen.index[:3],'q_mvar']=q.reshape(3);receipt=receipts[row['PF_receipt']];assert signature(expected)==receipt['physical_signature'] and receipt['status']=='RETURNED';after=pickle.loads((PRIMARY/'physics'/f"PF{receipt['index']:06d}_after.pkl").read_bytes());vm=after.res_bus.vm_pu.to_numpy();assert np.array_equal(vm,np.asarray(row['all13_vm_after']));controlled=vm[[2,7,9]];assert np.array_equal(controlled,np.asarray(row['controlled_vm_after'])) and bool(controlled.min()>.95 and controlled.max()<1.05)==row['native_done'];current['network']=after;current['state']=controlled;last=q.copy();history.append(row);steps+=1
            branches.append({'seed':seed,'algorithm':branch['algorithm'],'status':branch['status'],'completed_steps':len(history),'endpoint':branch.get('endpoint'),'scope':'Descriptive saved prefix; actual primary-final weights and fresh independent policy/PF replay remain UNKNOWN'})
        if len(world['algorithms'])==3 and all(a['status']=='COMPLETE_NATIVE_EPISODE' for a in world['algorithms']):complete_worlds.append(seed)
    put(OUT/'Preserved_Prefix_Inventory.json',{'entered_worlds':[w['seed'] for w in failure['worlds']],'all3_complete_worlds':complete_worlds,'all_branches':branches,'entirely_unentered_seeds':list(range(failure['worlds'][-1]['seed']+1,500)),'case162_linear_ddpg_unentered_or_partial':'Explicit branch status/zero-step data retained; do not infer completion.','original_seed0':'Already verified, not rerun','all500_benchmark':'UNKNOWN_NOT_COMPLETE'})
    # Capture a new immutable inventory, never fabricate original success/exit0.
    old_files=[p for p in PRIMARY.rglob('*') if p.is_file()];put(OUT/'Original_Failed_Study_File_Manifest.json',{'original_exit_code':1,'files':[{'path':f.relative_to(PRIMARY).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(old_files)],'journal_last_sha256':prior,'original_result_and_closedmanifest_absent':True,'failure_sha256':sha(PRIMARY/'Failure.json')})
    audit={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_SAVED_PREFIX_SOURCE_JOURNAL_NATIVE_EQUATION_AND_CONTINUITY_AUDIT_ONLY','scientific_study':'TERMINAL_RESOURCE_PARTIAL_WITH_FINALIZATION_ASSERTION_FAILURE','complete_original500':False,'source_normalization_explanation':'Only b/c have source-defined in-forward data normalization; original universal immutability assertion invalid for author policy. Actual final-state snapshot was not saved and stays UNKNOWN.','old_scientist_and_handoff_ended':True,'original_reader_started':False,'entered_worlds':len(failure['worlds']),'complete_all3_worlds':len(complete_worlds),'completed_branches':sum(a['status']=='COMPLETE_NATIVE_EPISODE' for a in branches),'saved_control_steps':steps,'saved_equation_states':len(index_rows),'maximum_KCL_pu':maximum_kcl,'maximum_complex_branch_power_MVA':maximum_flow,'primary_costs_retained':failure['costs'],'new_analysis_costs':costs,'full_independent_rebuilt_solver_policy_replay':'NOT_EXECUTED_NOT_CERTIFIED','actual_primary_final_parameter_bytes':'UNRECOVERED','superiority_result':'UNKNOWN_NO_OURS_ROWS','workflow_seconds':time.monotonic()-began};put(OUT/'Independent_Saved_Output_Audit.json',audit);put(OUT/'Frozen_After.json',frozen_checks());put(OUT/'Closed_Manifest.json',{'files':[{'path':f.relative_to(OUT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in OUT.rglob('*') if f.is_file()]});print(json.dumps({k:audit[k] for k in ['status','entered_worlds','complete_all3_worlds','completed_branches','saved_equation_states','maximum_KCL_pu','actual_primary_final_parameter_bytes']}))
if __name__=='__main__':main()
