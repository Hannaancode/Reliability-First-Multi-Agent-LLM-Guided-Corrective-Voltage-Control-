"""Frozen synthetic counterexamples against source-only notebook functions.
No notebook global code, retrieval index, pretrained model or network executes.
"""
from pathlib import Path
from datetime import datetime,timezone
from types import SimpleNamespace
from typing import Any,Dict,List,Tuple
import ast,hashlib,json,re,time
from pydantic import BaseModel,ValidationError,conint
from source_metadata_admission_20261029 import bind_evidence,validate_metadata,cited_source_metadata
R=Path(__file__).resolve().parents[1];O=R/'outputs/source_metadata_admission_20261029'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(name,x):(O/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8')
def selected_namespace(source,names,namespace):
    tree=ast.parse(source);selected=[]
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names:selected.append(node)
        elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in node.targets):selected.append(node)
    present={n.name if isinstance(n,(ast.FunctionDef,ast.ClassDef)) else n.targets[0].id for n in selected}
    assert present==set(names),(present,names)
    exec(compile(ast.Module(body=selected,type_ignores=[]),'source_only_selected_nodes','exec'),namespace)
    return namespace
def main():
    assert not O.exists();O.mkdir();start=time.perf_counter()
    nerc=Path('C:/Users/HOME/Downloads/RAG_Based_Integration_NERC (3).ipynb');theory=Path('C:/Users/HOME/Downloads/RAG_Based_Integration (4).ipynb')
    nb=json.loads(nerc.read_text('utf-8'));tb=json.loads(theory.read_text('utf-8'));s=''.join(nb['cells'][4]['source']);t=''.join(tb['cells'][6]['source'])
    assert sha(nerc.read_bytes())=='2fbcf40ecc3904dedbf66aae366d8f82e33df4700b072c8212881d7f4cdd5c83'
    assert sha(theory.read_bytes())=='201893d74f23840a7e65aa5ef670984807d5e29fc3dc3bfb80c1dc8ee8a026e8'
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Engineering source counterexamples and a separate structured metadata prototype; no scientific performance population.',
      'notebooks':[{'path':str(nerc),'sha256':sha(nerc.read_bytes()),'cell':5,'cell_sha256':sha(s.encode())},{'path':str(theory),'sha256':sha(theory.read_bytes()),'cell':7,'cell_sha256':sha(t.encode())}],
      'source':{'path':'work/source_metadata_admission_20261029.py','sha256':sha((R/'work/source_metadata_admission_20261029.py').read_bytes())},
      'test_source_sha256':sha(Path(__file__).read_bytes()),'new_model_retrieval_PF_training_calls':0,
      'cases':['empty_claims','nonentailing_claim','first_doc_citation_mismatch','wrong_page_present_type','wrong_year_present_type','wrong_url_present_type','correct_page','wrong_page','unknown_equation','second_cited_doc','empty_citation','unknown_citation','wrong_doc_field','unknown_id','bool_page','string_page','extra_request_key','changed_active_source','duplicate_id','tampered_source_bytes','untyped_loader_metadata'],
      'outcome_policy':'Retain all source and prototype outcomes. Do not convert this fixture into a historical failure rate or a benchmark result.'}
    put('Protocol.json',protocol)
    g={'re':re,'json':json,'Any':Any,'Dict':Dict,'List':List,'Tuple':Tuple,'BaseModel':BaseModel,'ValidationError':ValidationError,'conint':conint}
    g=selected_namespace(s,['normalize_ws','extract_json_object','Claim','RefLockedAnswer','retrieve_docs','generate_reference_locked_answer'],g)
    docs=[SimpleNamespace(page_content='Transformer cooling uses forced air.',metadata={'lesson_id':'LL_A'}),SimpleNamespace(page_content='Protective relays detect electrical faults.',metadata={'lesson_id':'LL_B'})]
    db=SimpleNamespace(similarity_search=lambda query,k:docs);tokenizer=SimpleNamespace(apply_chat_template=lambda *a,**kw:'PROMPT:')
    historical=[]
    for cid,obj in [('empty_claims',{'answer':'The source says page99.','claims':[]}),('nonentailing_claim',{'answer':'All grid faults are harmless.','claims':[{'claim':'All grid faults are harmless.','support_quote':docs[1].page_content,'source_id':1}]})]:
        fake=lambda prompt,o=obj:[{'generated_text':prompt+json.dumps(o)}]
        answer,claims,returned=g['generate_reference_locked_answer']('Synthetic software fixture',db,tokenizer,fake)
        historical.append({'case':cid,'original_source_accepts':answer==obj['answer'],'returned_claims':len(claims),'model_calls':0,'stubbed_generation':True})
    # Execute only the actual module-level citation if/else, not resource loading.
    node=next(n for n in ast.parse(s).body if isinstance(n,ast.For) and n.lineno==284)
    citation=next(n for n in node.body if isinstance(n,ast.If) and n.lineno==300)
    cns={'docs':docs,'REFERENCES_MAP':{'LL_A':'https://example.invalid/A','LL_B':'https://example.invalid/B'}}
    exec(compile(ast.Module(body=[citation],type_ignores=[]),'source_citation_only','exec'),cns)
    historical.append({'case':'first_doc_citation_mismatch','claim_source_id':1,'actual_link_source':cns['retrieved_id'],'expected_claim_source':'LL_B','mismatch':cns['retrieved_id']!='LL_B'})
    patterns=['STD_PATTERN','YEAR_PATTERN','PAGE_PATTERN','EQ_PATTERN','DOI_PATTERN','URL_PATTERN','fabricated_metadata_flags']
    flags=selected_namespace(t,patterns,{'re':re,'List':List})['fabricated_metadata_flags']
    for cid,answer,context in [('wrong_page_present_type','page99','page3'),('wrong_year_present_type','published in2025','published in2020'),('wrong_url_present_type','See https://example.invalid/wrong','See https://example.invalid/right')]:
        # Spaces make years true standalone tokens for the original regex.
        answer=answer.replace('in2','in 2');context=context.replace('in2','in 2')
        historical.append({'case':cid,'answer':answer,'context':context,'original_flags':flags(answer,context),'counterexample':'metadata class exists but value is different'})
    a=b'synthetic source A';b=b'synthetic source B';ea=bind_evidence('A',a,sha(a),docs[0].page_content,{'page':3,'year':2020,'document_id':'LL_A','url':'https://example.invalid/A'})
    eb=bind_evidence('B',b,sha(b),docs[1].page_content,{'page':7,'document_id':'LL_B','url':'https://example.invalid/B'})
    evidence=[ea,eb];active={'A':sha(a),'B':sha(b)};results=[]
    def check(cid,result,expected):
        assert result['status']==expected,(cid,result,expected);results.append({'case':cid,'expected':expected,'result':result,'pass':True})
    def req(e,f,v):return {'evidence_id':e,'field':f,'value':v}
    for cid,r,expect in [('correct_page',req('A','page',3),'VERIFIED_METADATA_ONLY'),('wrong_page',req('A','page',99),'REJECTED'),('unknown_equation',req('A','equation','3.1'),'NOT_STATED'),('wrong_doc_field',req('B','page',3),'REJECTED'),('unknown_id',req('C','page',3),'REJECTED'),('bool_page',req('A','page',True),'REJECTED'),('string_page',req('A','page','3'),'REJECTED'),('extra_request_key',{**req('A','page',3),'url':'https://example.invalid/wrong'},'REJECTED')]:check(cid,validate_metadata(r,evidence,active),expect)
    check('second_cited_doc',cited_source_metadata(['B'],evidence,active),'BOUND_CITATIONS_ONLY');assert results[-1]['result']['citations'][0]['document_id']=='LL_B'
    check('empty_citation',cited_source_metadata([],evidence,active),'REJECTED');check('unknown_citation',cited_source_metadata(['C'],evidence,active),'REJECTED')
    check('changed_active_source',validate_metadata(req('A','page',3),evidence,{'A':sha(b)}),'REJECTED')
    check('duplicate_id',validate_metadata(req('A','page',3),[ea,ea],active),'REJECTED')
    for cid,args in [('tampered_source_bytes',('A',b,sha(a),'x',{'page':3})),('untyped_loader_metadata',('A',a,sha(a),'x',{'page':True}))]:
        try:bind_evidence(*args)
        except ValueError as exc:results.append({'case':cid,'rejected':True,'reason':str(exc),'pass':True})
        else:raise AssertionError(cid)
    assert len(historical)==6 and len(results)==15
    assert all(x.get('original_source_accepts',True) for x in historical[:2]) and historical[2]['mismatch'] and all(not x['original_flags'] for x in historical[3:])
    streams=''.join(''.join(x.get('text',[])) for x in tb['cells'][6].get('outputs',[]) if x.get('output_type')=='stream')
    summary=streams[streams.index('ROBUST SUMMARY'):];(O/'Historical_Printed_Summary_LOCAL_ONLY.txt').write_text(summary,'utf-8')
    printed_ids=re.findall(r'^CASE (\d+)/200 ',streams,re.M)
    report={'status':'PASS_SOURCE_COUNTEREXAMPLES_AND15_STRUCTURED_METADATA_FIXTURES','at_utc':datetime.now(timezone.utc).isoformat(),'historical_source_counterexamples':historical,'new_prototype_results':results,
      'historical_summary_only':{'printed_case_headers':len(printed_ids),'unique_printed_ids':len(set(printed_ids)),'full200_per_case_recovery':False,'reported_total':200,'impossible_n':28,'reported_impossible_fail':0.893,'out_of_scope_n':25,'reported_out_of_scope_fail':0.36,'summary_sha256':sha(summary.encode())},
      'workflow_seconds':time.perf_counter()-start,'new_model_retrieval_PF_training_GPU_calls':0,'pydantic_fixture_version':__import__('pydantic').__version__,
      'scope_limits':['Executed selected original functions with synthetic stub responses, not a historical model replay.','Historical runtime dependencies and full200rawcase file remain unknown.','Category-presence regex misses wrong values in shown counterexamples; do not recalculate historical89.3% without exact rawcases.','New validator covers structured metadata and citedsource binding only; no arbitrary prose truth, semantic relevance or out-of-scope refusal guarantee.','Trusted loader must attest actual metadata extraction and source bytes. SHA identity is not factual authority.','No actual answering integration or pretrained inference performed. T12 remainsPARTIAL.'],'launch_ready':False}
    put('Source_Counterexamples_And_Prototype_Check.json',report)
    print(json.dumps({'status':report['status'],'source_counterexamples':6,'prototype_checks':15,'printed_case_headers':len(printed_ids),'new_science':0}))
if __name__=='__main__':main()
