"""Additive explicit failed-replay handling; retained v1 checks unchanged.

A finished measurement with an unavailable/partial independent replay does
not become a failed policy or a complete physical reference. Its evidence and
all actual costs survive as UNKNOWN. Also bind the new replay cost footer.
"""
import ast
import copy
import inspect
import json
from pathlib import Path

import compressed_literal_DSE_independent_reader_v1 as previous
from durable_opaque_evidence_store_v1 import EvidenceStop,local_root


def replay_terminal_report(folder, *, exit_code):
    folder=local_root(folder)
    if not (folder/'Replay_Terminal_Cost_Receipt.json').exists():
        return {'status':'UNKNOWN_TERMINAL_REPLAY_COUNTERS_UNRECOVERED','whole_owned_interval_charged_elsewhere':True}
    raw=(folder/'Replay_Terminal_Costs.json').read_bytes()
    receipt=previous.read(folder/'Replay_Terminal_Cost_Receipt.json')
    if (previous.sha(raw)!=receipt['sha256'] or len(raw)!=receipt['bytes'] or
        not previous.finite_nonnegative(receipt['terminal_export_write_seconds'])):
        raise EvidenceStop('Replay terminal export footer changed')
    terminal=json.loads(raw);costs=terminal['costs']
    if (terminal['actual_pid']!=previous.read(folder/'owner.claim')['actual_pid'] or
        terminal['exit_code']!=exit_code or not all(previous.finite_nonnegative(v) for v in costs.values())):
        raise EvidenceStop('Replay terminal code/cost values invalid')
    if any(type(costs[k]) is not int for k in ('attempts','returns','exceptions')) or costs['attempts']<costs['returns']+costs['exceptions']:
        raise EvidenceStop('Replay terminal attempt/return/exception arithmetic invalid')
    if exit_code==0:
        reported=previous.read(folder/'Result.json')
        if (previous.canonical(costs)!=previous.canonical(reported['charged_replay_costs']) or
            terminal['complete_storage_scans']!=reported['complete_storage_scan_costs']['scans'] or
            terminal['complete_storage_scan_seconds']!=reported['complete_storage_scan_costs']['seconds']):
            raise EvidenceStop('Replay final source/storage counter snapshot changed')
    return {'status':'REPLAY_SOURCE_COUNTERS_BOUND_NOT_NEW_PHYSICS',
        'source_reported_costs':costs,'complete_storage_scans':terminal['complete_storage_scans'],
        'complete_storage_scan_seconds':terminal['complete_storage_scan_seconds'],
        'terminal_export_write_seconds':receipt['terminal_export_write_seconds'],
        'receipt_write_and_process_exit_remain_in_actual_parent_owned_cost':True}


def incomplete_replay_record(study,spec,protocol,ownership,protocol_sha256,branch,entry):
    cost=previous.read_terminal_prefix(branch,protocol,protocol_sha256,science_exit_code=0)
    physical=previous.verify_paid_partial_scope(branch,spec,protocol,protocol_sha256)
    replay=entry.get('replay')
    evidence={'status':'NOT_EXECUTED_OR_UNRECOVERED_UNKNOWN','whole_owned_seconds':'UNKNOWN'}
    if replay and replay.get('actual_pid'):
        folder=local_root(study/'replays'/spec['job_id'])
        previous.verify_closed_owner(folder,replay,protocol_sha256,protocol['source_sha256'][protocol['replay_worker_path']])
        evidence={'status':'PRESERVED_PARTIAL_REPLAY_UNKNOWN','whole_owned_seconds':replay['owned_seconds'],
            'terminal':replay_terminal_report(folder,exit_code=replay['exit_code'])}
    return {'job_id':spec['job_id'],'status':'PASS_PRESERVED_MEASUREMENT_REPLAY_GATE_UNKNOWN',
        'complete_measurement_terminal_ledger':cost,'paid_scope_only_not_complete_policy_selection':physical,
        'incomplete_replay':evidence,'whole_branch_owned_seconds':entry['branch']['owned_seconds'],
        'continuous_full_physical_reference_endpoint_economic_headroom_and_LLM_gates':'UNKNOWN',
        'actual_new_reader_PF_model_optimizer_calls':0,'no_scientific_retry':True}


def _derive():
    old=ast.parse(inspect.getsource(previous.audit_closed_job)).body[0]
    new=copy.deepcopy(old)
    # Input/source/external branch closure assertions occur BEFORE this route.
    point=next(i for i,n in enumerate(new.body) if isinstance(n,ast.Import))
    added=ast.parse('''
if closed['exit_code']==0 and (entry.get('replay') or {}).get('exit_code')!=0:
    return incomplete_replay_record(study,spec,protocol,ownership,protocol_sha256,branch,entry)
''').body[0]
    new.body.insert(point,added)
    reverse=copy.deepcopy(new);reverse.body.pop(point)
    assert ast.dump(reverse,include_attributes=False)==ast.dump(old,include_attributes=False)
    env=previous.__dict__.copy();env['incomplete_replay_record']=incomplete_replay_record
    exec(compile(ast.fix_missing_locations(ast.Module(body=[new],type_ignores=[])),
        '<unchanged v1 audit plus explicit incomplete replay UNKNOWN route>','exec'),env)
    return env['audit_closed_job'],{
        'v1_audit_reverse_AST_exact':True,
        'original_complete_source_counter_and_field_checks_unmodified':True,
        'only_new_route':'complete measurement with missing/partial replay retained UNKNOWN before complete-only reader',
        'original_closed_readers_or_science_executed_on_import':False}


_audit,SOURCE_INCOMPLETE_REPLAY_CERTIFICATE=_derive()


def audit_closed_job(study,spec,protocol,ownership,protocol_sha256):
    result=_audit(study,spec,protocol,ownership,protocol_sha256)
    if result['status']=='PASS_COMPLETE_SOURCE_FIELDS_PAID_REPLAY_COST_AND_CLOSURE':
        study=Path(study)
        report=replay_terminal_report(study/'replays'/spec['job_id'],exit_code=0)
        if report['status']!='REPLAY_SOURCE_COUNTERS_BOUND_NOT_NEW_PHYSICS':
            raise EvidenceStop('Complete new replay has no terminal counter footer')
        result['replay_terminal_footer']=report
    return result
