"""Independent saved-result reader; zero new forwards/backwards/solves."""
import candidate_process_runtime
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
import json,time,os,numpy as np,torch
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';D=P/'transition_OPT_tensor_preparation'
S=P/'transition_CPU_pilot';PRE=P/'transition_CPU_pilot_preparation';OUT=P/'transition_CPU_pilot_external_audit'
assert read(S/'status.json')['stage']=='complete_fixed_OPT_numerical_pilot_pending_independent_audit'
assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
proto=read(PRE/'Prospective_CPU_Pilot_Protocol.json')
for name,h in proto['source_sha256'].items():assert sha(ROOT/name)==h
for name,m in read(S/'Closed_Scientific_Manifest.json').items():assert sha(S/name)==m['sha256'] and (S/name).stat().st_size==m['bytes']
index=read(D/'Input_Index.json');target={r['transition_id']:r for r in read(D/'Target_Index.json')}
worldcounts=Counter(r['world_sha256'] for r in index);scale=proto['OPT_scale_pu'];journal=[json.loads(l) for l in (S/'Actual_Learning_Journal.jsonl').read_text().splitlines()]
all_results={};certificates={};rows=[];exact_reloads=0;forecast_count=0
for arm in proto['arms']:
    folder=S/arm;certificate=read(folder/'Actual_Arm_Completion_Certificate.json');j=[e for e in journal if e.get('arm')==arm]
    per_phase={}
    for phase,n in (('untrained',216),('train',1080),('final',216),('reload',216)):
        attempts=[e['transition_id'] for e in j if e['event']=='forward_attempt' and e['phase']==phase]
        returns=[e['transition_id'] for e in j if e['event']=='forward_return' and e['phase']==phase]
        expected=[r['transition_id'] for r in index]*(5 if phase=='train' else 1)
        assert attempts==returns==expected and len(returns)==n;per_phase[phase]=n
    optimizer=[e for e in j if e['event']=='optimizer_return'];assert len(optimizer)==1080
    assert [e['step'] for e in optimizer]==list(range(1,1081))
    for n,e in enumerate(optimizer):
        r=index[n%216];assert e['transition_id']==r['transition_id'] and e['world_sha256']==r['world_sha256']
        assert e['epoch']==n//216+1 and e['world_weight']==216/(23*worldcounts[r['world_sha256']])
    for event_name in ('backward_attempt','backward_return','optimizer_attempt'):
        assert len([e for e in j if e['event']==event_name])==1080
    checkpoints=[e for e in j if e['event']=='epoch_complete_checkpoint'];assert len(checkpoints)==5
    names=list(read(folder/'Actual_Parameter_Registry.json')['active'])
    for epoch,e in enumerate(checkpoints,1):
        path=folder/f'Complete_Epoch{epoch}_State.pt';assert sha(path)==e['sha256']
        checkpoint=torch.load(path,weights_only=False)
        assert checkpoint['cursor']=={'completed_epoch':epoch,'optimizer_returns':216*epoch,'next_epoch':epoch+1,'next_offset':0}
        assert checkpoint['parameter_names']==names and set(checkpoint['actual_gradient_participation'])==set(names)
        assert set(checkpoint['optimizer']['state'])==set(range(len(names)))
        assert all(v==216*epoch for v in checkpoint['actual_gradient_participation'].values())
        assert all(int(v['step'])==216*epoch and torch.isfinite(v['exp_avg']).all() and torch.isfinite(v['exp_avg_sq']).all()
                   for v in checkpoint['optimizer']['state'].values())
        assert 'RNG' in checkpoint
    phase_results={}
    for phase in ('untrained','final'):
        grouped=defaultdict(list);upper=0;max_errors=[]
        for offset,r in enumerate(index):
            ident=r['transition_id'];t=target[ident];x=torch.load(D/r['path'],weights_only=True)
            a=torch.load(folder/phase/f't{offset:04d}.pt',weights_only=True)
            assert a['transition_id']==ident and a['input_canonical_sha256']==r['input_canonical_sha256']
            coefficient=a['coefficient'].numpy().astype(np.float64);assert coefficient.shape==(118,) and np.isfinite(coefficient).all()
            q=x['q_abs_mvar'];baseline=np.array(t['current_vm'])+q*np.array(x['AC_direction_per_MVAr'])
            assert np.max(np.abs(baseline-t['analytic_next_vm']))<=1e-10
            forecast=baseline+(q/300.)**2*scale*coefficient;actual=np.array(t['actual_next_vm'])
            mse=float(np.mean((forecast-actual)**2));maximum=float(np.max(np.abs(forecast-actual)))
            grouped[r['world_sha256']].append(mse);upper+=int(forecast.max()>1.05+1e-8);max_errors.append(maximum);forecast_count+=1
            if phase=='final':
                b=torch.load(folder/'reload'/f't{offset:04d}.pt',weights_only=True)
                assert b['transition_id']==ident and torch.equal(a['coefficient'],b['coefficient']);exact_reloads+=1
            rows.append({'arm':arm,'phase':phase,'transition_id':ident,'world_sha256':r['world_sha256'],
                'response_MSE':mse,'max_abs_error_pu':maximum,'predicted_upper_crossing':bool(forecast.max()>1.05+1e-8),
                'unphysical_forecast':bool(np.any(forecast<=0)),'actual_successor_is_teacher_selected':True})
        means={w:sum(v)/len(v) for w,v in grouped.items()}
        assert len(means)==23
        phase_results[phase]={'equal_world_response_MSE':sum(means.values())/23,'world_MSE':means,
            'predicted_upper_crossings':upper,'maximum_bus_error_pu':max(max_errors)}
    ac=read(P/'OPT_transition_AC_vector_measurement/Summary.json')['equal_world_MSE']['AC_MSE']
    passed=phase_results['final']['equal_world_response_MSE']<=.9*ac
    all_results[arm]={'phases':phase_results,'AC_OPT_baseline_MSE':ac,
        'final_relative_MSE_reduction_vs_AC':1-phase_results['final']['equal_world_response_MSE']/ac,
        'fixed_10percent_OPT_viability_gate_passed':passed,'held_or_physical_performance':None}
    c=certificate['actual_counts'];assert c['forward_attempts']==c['forward_returns']==1728
    assert c['phase_forward_returns']==per_phase
    assert c['backward_attempts']==c['backward_returns']==c['optimizer_attempts']==c['optimizer_returns']==1080
    for field,event_name in (('forward_seconds','forward_return'),('backward_clip_seconds','backward_return'),('optimizer_seconds','optimizer_return')):
        assert abs(c[field]-sum(e['seconds'] for e in j if e['event']==event_name))<=1e-6
    assert c['new_pretrained_contextual_forward_PF_cloud_calls']==0
    certificates[arm]={'exact_identity_phase_order_world_weights_and_costs_passed':True,
        'five_full_model_AdamW_RNG_cursor_and_participation_checkpoints_passed':True,
        'all216final_fresh_reload_predictions_bit_exact':True,'actual_numerical_forwards':1728,'actual_optimizer_returns':1080}
assert read(S/'Fresh_Frozen_Preservation.json')['all_passed']
passed=any(r['fixed_10percent_OPT_viability_gate_passed'] for r in all_results.values())
audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_identity_checkpoint_cost_gates_passed':True,
    'arms':certificates,'actual_numerical_forwards':3456,'actual_task_optimizer_returns':2160,
    'exact_final_fresh_reload_coefficients':exact_reloads,'saved_forecast_diagnostics':forecast_count,
    'new_reader_neural_optimizer_PF_cloud_calls':0,'all_original_frozen_checks_passed':True,
    'reader_seconds':time.perf_counter()-started}
decision={'fixed_OPT_minimum_viability_gate_passed':passed,
    'decision':'Separate frozen held-transition join/evaluation and genuine new integration readiness may be prepared; NO automatic GPU or rollout' if passed else
        'STOP this bounded residual route/dataset: fixed OPT viability gate failed. No objective/rank/LR/Q/seed/budget/epoch/decoder sweeps',
    'all_held_LLM_incremental_DSE_physics_confirmation_gates_unknown':True,
    'all_adverse_arms_untrained_final_unknown_denominators_retained':True}
write(OUT/'Independent_Actual_OPT_Control_Audit.json',audit);write(OUT/'Actual_All_Control_Results.json',all_results)
write(OUT/'Actual_All_Transition_Diagnostics.json',rows);write(OUT/'Fixed_Prospective_OPT_Gate_Decision.json',decision)
text='''# Fixed numerical OPT transition pilot\n\nThese are measured-target numerical learning results on23 OPT worlds, not LLM,
held-world, protected rollout or D-SE superiority evidence. The original failed
methods remain stopped. Both current/action/AC-informed controls used the same
new targets/equation/initial frontend and five fixed epochs/final epoch5 only.\n\n'''
for arm,r in all_results.items():
    text+=f"{arm}: final equal-world response MSE {r['phases']['final']['equal_world_response_MSE']:.12g}; relative reduction versus AC {100*r['final_relative_MSE_reduction_vs_AC']:.3f}%; gate {r['fixed_10percent_OPT_viability_gate_passed']}.\n\n"
text+=decision['decision']+'''\n\nAll216 transitions per arm,3456 actual forwards,2160 actual optimizer returns,
10 complete epoch checkpoints and432 exact final/fresh reload outputs passed
identity/cost/source checks. Prior mock6steps/12forwards and all prior physical
costs remain separate. No new PF/pretrained contextual model/cloud calls.\n'''
(OUT/'Results.md').write_text(text,encoding='utf8')
files={str(p.relative_to(S)).replace('\\','/'):p for p in S.rglob('*') if p.is_file() and p.name not in {'owner.claim','status.json'}}
files.update({'external/'+p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='audit.claim'})
files['source/independent_reader.py']=Path(__file__)
archive=seal(OUT,files,'Verified_Action_Transition_CPU_Pilot.zip')
write(OUT/'status.json',{'stage':'complete_OPT_control_external_audit','integrity_passed':True,'OPT_viability_passed':passed})
print(json.dumps({'audit':audit,'results':all_results,'decision':decision,'archive':archive},indent=2))
