"""Additive all500 fixed-order numerical acquisition; PREPARATION ONLY.

Uses fixed receding controls and only exact already-paid physical receipts.
An incomplete/unsafe/unknown path cannot become a complete-policy score.
No CLI starts work. Numerical entry is disabled by default and requires a
separate source-bound live owner/ACK/reader gate plus explicit constructor opt-in.
"""
from pathlib import Path
import copy
import json
import time
import numpy as np
import nonlinear13_receding_policy_engine_v2_20261030 as base
from nonlinear13_math_receipt_bank_20261030 import NumericalReceiptBank, context_key, PINNED_RUNTIME

SOURCE = 'work/nonlinear13_receding_acquisition_engine_20261030.py'
CURRENT_SOURCE = 'work/nonlinear13_current_state_v2_20261030.py'
BANK_SOURCE = 'work/nonlinear13_math_receipt_bank_20261030.py'
READER_SOURCE = 'work/nonlinear13_acquisition_reader_20261030.py'
MATH_READER_SOURCE = 'work/nonlinear13_saved_math_reader_20261030.py'
NEW_NUMERICAL_ACQUISITION_ENTRY_ENABLED = False
NEW_PF_ENTRY_ENABLED = False
CHECKPOINT_BYTE_CAP = 1024**2
JSON_BYTE_CAP = 8*1024**2
RESULT_JSON_BYTE_CAP = 64*1024**2


class AcquisitionEventJournal(base.EventJournal):
    """Charge actual policy-line bytes; closure notices confer no science rights."""
    def event(self, kind, numeric=None, unknown=None, **data):
        self.owner.check()
        return self._write(kind, numeric, unknown, data, mechanical=False)

    def mechanical_event(self, kind, **data):
        base.need(kind in {'outstanding_cost_receipt_notice', 'mechanical_closure_notice'}, 'Mechanical event cannot admit actions or calculations')
        return self._write(kind, {}, {}, data, mechanical=True)

    def _write(self, kind, numeric, unknown, data, mechanical):
        event = dict(seq=len(self.rows), kind=kind, previous=self.previous,
                     numeric_cost=numeric or {}, unknown_cost=unknown or {}, **data)
        raw = base.canonical(event); digest = base.sha(raw)
        line = base.canonical({'event': event, 'sha256': digest})+b'\n'
        base.need(self.bytes+len(line) <= self.owner.protocol['journal_byte_cap'], 'Original policy journal cap exhausted')
        validate = base.CostLedger(); validate.add(event['numeric_cost'], event['unknown_cost'])
        if mechanical:
            self.owner.admit_mechanical_write(len(line))
        else:
            self.owner.admit_metadata_write(len(line))
        self.stream.write(line); self.stream.flush(); base.os.fsync(self.stream.fileno())
        self.costs.add(event['numeric_cost'], event['unknown_cost'])
        self.bytes += len(line); self.previous = digest; self.rows.append(event)
        return event['seq']


class AcquisitionOwnerGate(base.OwnerGate):
    def __init__(self, root, protocol_ref, ack_ref):
        super().__init__(root, protocol_ref, ack_ref)
        p, a = self.protocol, self.ack
        base.need(p.get('new_math_mode') == 'SOURCE_ORDER_RECEDING_FIXED_RECIPE'
                  and p.get('new_PF_entry_enabled') is False, 'Wrong acquisition role/physical authority')
        base.need(p.get('numerical_acquisition_authorized') is True
                  and a.get('numerical_acquisition_authorized') is True, 'No separately authenticated numerical launch')
        required = [SOURCE, CURRENT_SOURCE, BANK_SOURCE, READER_SOURCE, MATH_READER_SOURCE,
                    'work/nonlinear13_receding_policy_engine_20261029.py', *PINNED_RUNTIME]
        base.need(set(required) <= p['sources'].keys(), 'Acquisition dependencies/reader absent')
        for source in required:
            base.read_ref(root, {'path': source, 'sha256': p['sources'][source]})
        base.need(p['independent_reader_source'] == {'path': READER_SOURCE, 'sha256': p['sources'][READER_SOURCE]},
                  'First-reader source is not frozen')
        base.need(type(p['per_proposal_journal_byte_cap']) is int and p['per_proposal_journal_byte_cap'] > 0,
                  'Missing fixed per-proposal preservation budget')
        base.need(p['protocol_binary_byte_cap'] == 8*1024**3 and p['per_proposal_journal_byte_cap'] == 64*1024**2
                  and p['science_budget_seconds'] == 7200, 'Changed fixed prospective acquisition resource budget')
        base.need(p['checkpoint_byte_cap'] == CHECKPOINT_BYTE_CAP and p['nonjournal_json_byte_cap'] == JSON_BYTE_CAP
                  and p['aggregate_result_json_byte_cap'] == RESULT_JSON_BYTE_CAP, 'Changed fixed metadata caps')
        self.root_roster = json.loads(base.read_ref(root, p['root_roster_ref']))
        base.need(isinstance(self.root_roster, list) and [r['seed'] for r in self.root_roster] == list(range(500))
                  and all({'seed', 'root', 'input_pack'} <= r.keys() for r in self.root_roster), 'Invalid fixed all500 root roster')


def numerical_costs(primary, proposal, journal_raw):
    """Record observed partial work; unknown native internals never become zero."""
    numeric = {'numerical.workflow_seconds': primary['workflow_seconds'],
               'numerical.journal_bytes': primary['journal_bytes'],
               'numerical.journal_events': primary['journal_events']}
    unknown = {'numerical.optimizer.internal_QP_factorizations': 'UNKNOWN_INSIDE_PINNED_NATIVE_LIBRARY_NOT_FREE',
               'numerical.optimizer.internal_linear_solves': 'UNKNOWN_INSIDE_PINNED_NATIVE_LIBRARY_NOT_FREE'}
    for key, value in primary['kernel_costs'].items():
        numeric['numerical.kernel.'+key] = value
    if proposal is not None:
        for key, value in proposal.get('costs', {}).items():
            (numeric if type(value) in (int, float) else unknown)['numerical.optimizer.'+key] = value
    else:
        # Count only complete durable event records. The unclosed tail remains
        # referenced in the receipt and explicitly UNKNOWN, not silently dropped.
        count = {}; seconds = 0.; malformed = False
        for line in journal_raw.splitlines():
            try: event = json.loads(line)['event']
            except (ValueError, KeyError): malformed = True; break
            kind = event['kind']; count[kind] = count.get(kind, 0)+1
            if kind == 'native_solver_call_end': seconds += event['elapsed_seconds']
        for kind, name in [('optimizer_attempt','optimizer_attempts'),('optimizer_lossless_raw_return','optimizer_returns'),
                           ('optimizer_exception','optimizer_exceptions'),('native_solver_call_attempt','native_slsqp_calls'),
                           ('major_iteration_return','major_iteration_callbacks')]:
            numeric['numerical.observed_durable.'+name] = count.get(kind, 0)
        numeric['numerical.observed_durable.native_slsqp_seconds'] = seconds
        unknown['numerical.complete_failed_optimizer_totals'] = 'UNKNOWN: no complete proposal; durable observed counts only, no scientific retry'
        if malformed:
            unknown['numerical.partial_journal_tail'] = 'UNKNOWN: malformed/unclosed tail retained; no complete cost claim'
    for value in numeric.values():
        base.need(type(value) in (int, float) and np.isfinite(value) and value >= 0, 'Invalid numerical cost')
    for value in unknown.values():
        base.need(isinstance(value, str) and value.startswith('UNKNOWN'), 'Unknown cost description lost')
    return numeric, unknown


class SourceOrderedAcquisitionEngine(base.RecedingEngine):
    def __init__(self, root, output_directory, owner, *, enable_numerical_entry=NEW_NUMERICAL_ACQUISITION_ENTRY_ENABLED):
        base.need(enable_numerical_entry is True, 'PREPARATION_ONLY_NUMERICAL_ENTRY_DISABLED')
        base.need(isinstance(owner, AcquisitionOwnerGate), 'Acquisition requires its separately frozen owner gate')
        base.need(callable(getattr(owner, 'reserve_new_math', None))
                  and callable(getattr(owner, 'preservation_budget_check', None))
                  and callable(getattr(owner, 'admit_metadata_write', None))
                  and callable(getattr(owner, 'admit_mechanical_write', None)), 'Owner binary preservation gate missing')
        owner.check()
        self._numerical_entry_admitted = True
        self.root, self.owner = Path(root).resolve(), owner
        self.out = (self.root/output_directory).resolve(); self.out.relative_to(self.root)
        self.out.mkdir(exist_ok=False)
        self.journal = AcquisitionEventJournal(self.root, self.out/'policy.jsonl', owner)
        self.paid_snapshot = base.PaidSnapshot(self.root, owner.protocol['paid_registry_manifest']['sha256'])
        self.provenance = base.PaidProvenance(self.root, owner.protocol['paid_registry_manifest'])
        self.journal.event('paid_metadata_loaded', base.counter_delta({}, self.paid_snapshot.costs, 'snapshot.')
                           | base.counter_delta({}, self.provenance.costs, 'provenance.'))
        self.math, self.attempted_math, self.results = {}, set(), []
        start = time.monotonic()
        self.bank = NumericalReceiptBank(self.root, (self.out/'numerical').relative_to(self.root).as_posix(), owner)
        self.journal.event('numerical_bank_constructed', {'numerical.bank_setup_seconds': time.monotonic()-start},
            {'numerical.bank_setup_bytes': 'UNKNOWN: setup byte accounting not exposed by bank; source/import references retained'})
        self.unique_new_receipts = {}
        self.numerical_receipt_contexts = {}
        self.outstanding_cost_receipts = {}
        self.active_preproposal = None
        self._mechanical_closure_mode = False

    def require_numerical_entry(self):
        base.need(getattr(self, '_numerical_entry_admitted', False), 'PREPARATION_ONLY_NUMERICAL_ENTRY_DISABLED')
        base.need(isinstance(self.owner, AcquisitionOwnerGate), 'Acquisition owner gate missing')
        self.owner.check()

    def put(self, name, value):
        raw = base.canonical(value)
        limit = RESULT_JSON_BYTE_CAP if name == 'Result.json' else JSON_BYTE_CAP
        base.need(len(raw) <= limit, 'UNKNOWN_FIXED_JSON_PRESERVATION_BOUND_EXHAUSTED')
        if getattr(self, '_mechanical_closure_mode', False):
            self.owner.admit_mechanical_write(len(raw))
        else:
            self.owner.admit_metadata_write(len(raw))
        return super().put(name, value)

    def prepare_preproposal_checkpoint(self, seed, model, binding, state, history, paid):
        from nonlinear13_current_state_v2_20261030 import pack_current_state, load_current_state
        c = self.cursor(seed, binding, state, history, paid, None)
        self.owner.check(c)
        self.owner.admit_metadata_write(CHECKPOINT_BYTE_CAP)
        kernel, ref = pack_current_state(self.root, seed, state['NET'], c,
            (self.out/f'seed{seed:03d}_step{len(history)+1:03d}_Preproposal.pkl').relative_to(self.root).as_posix())
        cold_kernel, cold = load_current_state(self.root, ref)
        base.need(base.typed(cold) == base.typed(c) and base.typed(vars(cold_kernel)) == base.typed(vars(kernel)), 'Preproposal cold state/type mismatch')
        base.need(context_key(model, self.owner.protocol['sources']) == context_key(kernel, self.owner.protocol['sources']), 'Preproposal context changed')
        self.journal.event('preproposal_preserved', {'preproposal_packs': 1, 'preproposal_cold_loads': 1},
                           seed=seed, step=len(history)+1, checkpoint=ref)
        return ref

    def step(self, seed, step, model, state, history, binding, paid):
        self.require_numerical_entry()
        checked = self.owner.preservation_budget_check()
        self.journal.event('preservation_step_budget_checked', checked['numeric_cost'], seed=seed, step=step,
                           evidence_ref=checked.get('evidence_ref'))
        checkpoint = self.prepare_preproposal_checkpoint(seed, model, binding, state, history, paid)
        self.active_preproposal = {'seed': seed, 'step': step, 'reference': checkpoint}
        try:
            return super().step(seed, step, model, state, history, binding, paid)
        finally:
            self.active_preproposal = None

    def preserve_committed(self, seed, step, binding, state, history, paid, stop):
        # Same authoritative postcommit contract, with the additive representation
        # adapter on both warm and cold construction.
        from nonlinear13_current_state_v2_20261030 import pack_current_state, load_current_state
        stage = 'cursor_build'
        try:
            c = self.cursor(seed, binding, state, history, paid, stop)
            stage = 'pack_current_state'
            self.owner.admit_metadata_write(CHECKPOINT_BYTE_CAP)
            kernel, ref = pack_current_state(self.root, seed, state['NET'], c,
                (self.out/f'seed{seed:03d}_step{step:03d}_Cursor.pkl').relative_to(self.root).as_posix())
            stage = 'cold_load'
            cold_kernel, cold = load_current_state(self.root, ref)
            stage = 'cold_equality'
            base.need(base.typed(cold) == base.typed(c) and base.typed(vars(cold_kernel)) == base.typed(vars(kernel)), 'Cold state/type mismatch')
            stage = 'cursor_preserved_event'
            self.journal.event('cursor_preserved', {'cursor_packs': 1, 'cursor_cold_loads': 1}, seed=seed, step=step, checkpoint=ref)
            return kernel
        except Exception as exc:
            raise base.PostCommitPreservationError(state, paid, history, stage, exc) from exc

    def resolve_math(self, model, seed, step):
        self.require_numerical_entry()
        active = self.active_preproposal
        base.need(active and (active['seed'], active['step']) == (seed, step), 'Missing complete preproposal checkpoint')
        key = context_key(model, self.owner.protocol['sources'])
        if key in self.attempted_math and key not in self.math:
            raise RuntimeError('UNKNOWN_PREVIOUS_UNCLOSED_OR_FAILED_MATH_NO_RETRY')
        new_attempt = key not in self.math
        if new_attempt:
            reserved = self.owner.reserve_new_math(key, active['reference'])
            self.journal.event('preservation_budget_reserved', reserved['numeric_cost'],
                context_key=key, seed=seed, step=step, reservation_ref=reserved['reservation_ref'])
            self.attempted_math.add(key)
            self.journal.event('math_attempt', {'new_numerical_proposals_attempted': 1}, context_key=key,
                seed=seed, step=step, preproposal_checkpoint_ref=active['reference'])
        try:
            response = self.bank.resolve(model, active['reference'], seed, step)
        except BaseException as exc:
            claim_path = self.bank.claims/(key+'.json')
            claim_ref = None
            if claim_path.exists():
                raw = claim_path.read_bytes()
                claim_ref = {'path': claim_path.relative_to(self.root).as_posix(), 'sha256': base.sha(raw), 'bytes': len(raw)}
            self.journal.event('math_failure', unknown={'numerical.unclosed_attempt_costs': 'UNKNOWN: bank raised before closed receipt; global claim retained, no retry'},
                context_key=key, seed=seed, step=step, preproposal_checkpoint_ref=active['reference'], failure=repr(exc),
                numerical_receipt_ref=None, attempt_claim_ref=claim_ref, status='FAILED_OR_UNCLOSED_NO_RETRY')
            if new_attempt:
                self.post_math_budget_check(key, seed, step)
            raise
        # Preserve the returned receipt/costs before a postcall budget failure.
        try:
            return self.consume_bank_return(response, key, seed, step, active['reference'], new_attempt)
        finally:
            if new_attempt:
                self.post_math_budget_check(key, seed, step)

    def post_math_budget_check(self, key, seed, step):
        checked = self.owner.preservation_budget_check()
        self.journal.event('preservation_budget_checked', checked['numeric_cost'], context_key=key,
            seed=seed, step=step, evidence_ref=checked.get('evidence_ref'))

    def consume_bank_return(self, response, key, seed, step, checkpoint, new_attempt):
        """Saved receipt admission and cost joins only; calls no numerical code."""
        base.need(response['context_key'] == key, 'Bank context substitution')
        kind = response['kind']
        if kind in ('PAID_MATH_REUSE', 'CURRENT_OWNER_MATH_REUSE_AUDIT_PENDING'):
            base.need(not new_attempt and key in self.math, 'Reuse without this owner imported/returned proposal')
            record = response['record']; prior = self.math[key]
            base.need(record['context_key'] == key and record['proposal_ref'] == prior['proposal_ref'], 'Reuse proposal changed')
            verification = 'PASS' if kind == 'PAID_MATH_REUSE' else 'PENDING_FIRST_READER'
            base.need(record['independent_verification'] == verification, 'Historical/current-owner reader status conflated')
            if verification == 'PENDING_FIRST_READER':
                base.need(record['receipt_ref'] == prior['receipt_ref'] and key in self.unique_new_receipts, 'Pending reuse is not this owner completed receipt')
            self.journal.event('math_reuse', {'complete_proposal_reuses': 1}, context_key=key, seed=seed, step=step,
                proposal_ref=record['proposal_ref'], numerical_receipt_ref=record.get('receipt_ref'),
                preproposal_checkpoint_ref=checkpoint, independent_verification=verification, bank_return_kind=kind)
            return key, prior
        base.need(kind == 'NEW_FIXED_NUMERICAL_RECEIPT' and new_attempt, 'Unexpected/new duplicate mathematical return')
        receipt_ref = response['receipt_ref']
        self.unique_new_receipts[key] = receipt_ref
        if not hasattr(self, 'numerical_receipt_contexts'):
            self.numerical_receipt_contexts = {}
        self.numerical_receipt_contexts[key] = {'context_key': key, 'receipt_ref': receipt_ref,
            'preproposal_checkpoint_ref': checkpoint, 'seed': seed, 'step': step}
        receipt = json.loads(base.read_ref(self.root, receipt_ref))
        base.need(receipt['context_key'] == key and receipt['owner_protocol_ref'] == self.owner.protocol_ref
                  and receipt['sources'] == self.owner.protocol['sources'], 'Numerical receipt owner/context/source changed')
        binding = receipt['source_input_binding']
        base.need(binding['complete_preproposal_cursor_ref'] == checkpoint and binding['seed'] == seed
                  and binding['step'] == step and binding['context_key'] == key, 'Numerical receipt preproposal/decision changed')
        primary = json.loads(base.read_ref(self.root, receipt['primary']))
        raw = base.read_ref(self.root, receipt['journal'])
        base.read_ref(self.root, receipt['input_pack']); base.read_ref(self.root, receipt['attempt_claim'])
        proposal = None if receipt['proposal'] is None else json.loads(base.read_ref(self.root, receipt['proposal']))
        base.need(primary['context_key'] == key and primary['status'] == receipt['status'] == response['status'], 'Numerical primary/receipt status mismatch')
        base.need(proposal == response['proposal'] and response['independent_verification'] == 'PENDING_FIRST_READER', 'Numerical return altered or prematurely certified')
        numeric, unknown = numerical_costs(primary, proposal, raw)
        admitted = bool(primary['status'] == 'RETURNED_FIXED_NUMERICAL_RESULT' and proposal and proposal.get('status') == 'ADMITTED_UNMEASURED_PROPOSAL')
        base.need(response['candidate_admitted'] is admitted, 'Candidate admission label mismatch')
        event_kind = 'math_return' if admitted else 'math_failure'
        try:
            self.journal.event(event_kind, numeric, unknown, context_key=key, seed=seed, step=step,
                proposal_ref=receipt['proposal'], numerical_receipt_ref=receipt_ref, primary_ref=receipt['primary'],
                attempt_claim_ref=receipt['attempt_claim'],
                preproposal_checkpoint_ref=checkpoint, independent_verification='PENDING_FIRST_READER',
                candidate_admitted=admitted, status=primary['status'])
        except Exception as exc:
            self.outstanding_cost_receipts[key] = {
                'context_key': key, 'receipt_ref': receipt_ref, 'primary_ref': receipt['primary'],
                'preproposal_checkpoint_ref': checkpoint, 'seed': seed, 'step': step,
                'status': 'UNJOURNALED_AFTER_DEADLINE_OR_PRESERVATION_FAILURE', 'failure': repr(exc),
                'reported_numeric_cost': numeric, 'reported_unknown_cost': unknown}
            raise RuntimeError('UNKNOWN_UNJOURNALED_NUMERICAL_COST_RECEIPT_NO_CANDIDATE_REUSE') from exc
        if not admitted:
            raise RuntimeError('UNKNOWN_FIXED_NUMERICAL_REJECTED_OR_PARTIAL_NO_RETRY')
        row = {'proposal': proposal, 'proposal_ref': receipt['proposal'], 'receipt_ref': receipt_ref,
               'reader_ref': None, 'independent_verification': 'PENDING_FIRST_READER'}
        self.math[key] = row
        return key, row

    def run_acquisition(self):
        self.require_numerical_entry()
        self.import_first_paid_math()
        for seed in range(500):
            history = []; state = None; status = 'UNKNOWN_NOT_ENTERED'; failure = None; entered = False
            try:
                self.owner.check()
                model, binding = base.load_certified_case(self.root, seed)
                registered = self.owner.root_roster[seed]
                base.need(binding['root'] == registered['root'] and binding['pack'] == registered['input_pack'], 'Current case differs from frozen all500 roster')
                state, paid = self.bind_initial_root(seed, model, binding)
                self.journal.event('case_entered', seed=seed, root=binding['root'], initial_Q=state['Q'], initial_vm=state['vm'], root_receipt_ref=paid['record_ref'])
                entered = True
                for step in range(1, 101):
                    if base.endpoint(state['vm'])['strict_fullband']:
                        status = 'COMPLETE_STRICT_BAND'; break
                    model, state, paid, stop = self.step(seed, step, model, state, history, binding, paid)
                    if stop:
                        status = {'BAND_COMPLETE': 'COMPLETE_STRICT_BAND',
                                  'ORIGINAL_GUARD_HOLD_STOP': 'UNKNOWN_UNSAFE_CANDIDATE_HOLD_STOP',
                                  'ORIGINAL_HORIZON': 'COMPLETE_ORIGINAL100_HORIZON'}[stop]
                        break
                else: status = 'COMPLETE_ORIGINAL100_HORIZON'
            except base.PostCommitPreservationError as exc:
                state, paid, history = exc.state, exc.paid, exc.history
                status = 'UNKNOWN_POST_COMMIT_PRESERVATION'; failure = str(exc)
            except Exception as exc:
                status = 'UNKNOWN_'+type(exc).__name__; failure = str(exc)
            row = self.finalize_episode(seed, status, state, history, entered, failure)
            row['entered'] = entered
            self.results.append(row)
        self._mechanical_closure_mode = True
        self.owner.admit_mechanical_write(0)  # Irreversible: future science is forbidden by the owner.
        closure_errors = []
        attempts = {e['context_key']: e for e in self.journal.rows if e['kind'] == 'math_attempt'}
        closed_attempts = {e['context_key'] for e in self.journal.rows if e['kind'] in ('math_return', 'math_failure')
                           and e.get('status') != 'FAILED_OR_UNCLOSED_NO_RETRY'}
        outstanding_math_attempts = {key: {'context_key': key, 'seed': e['seed'], 'step': e['step'],
            'preproposal_checkpoint_ref': e['preproposal_checkpoint_ref'],
            'status': 'UNKNOWN_UNCLOSED_MATH_ATTEMPT_COSTS_NO_RETRY'}
            for key, e in attempts.items() if key not in closed_attempts}
        logged_receipts = {e['context_key'] for e in self.journal.rows if e['kind'] in ('math_return', 'math_failure')
                           and e.get('numerical_receipt_ref') is not None}
        for key in set(self.unique_new_receipts)-logged_receipts-self.outstanding_cost_receipts.keys():
            self.outstanding_cost_receipts[key] = dict(self.numerical_receipt_contexts[key],
                status='UNJOURNALED_UNVALIDATED_RECEIPT', reported_numeric_cost={},
                reported_unknown_cost={'new_receipt_costs': 'UNKNOWN: preserved receipt did not reach normal journal admission'},
                failure='Receipt preserved but parsing/admission/normal journal did not close')
        for key, evidence in self.outstanding_cost_receipts.items():
            try:
                self.journal.mechanical_event('outstanding_cost_receipt_notice', context_key=key, receipt_ref=evidence['receipt_ref'])
            except Exception as exc:
                closure_errors.append({'stage': 'outstanding_receipt_notice', 'context_key': key, 'error': repr(exc)})
        try:
            replayed = base.replay_semantics(self.journal.rows, self.root)
            base.need(replayed.numeric == self.journal.costs.numeric and replayed.unknown == self.journal.costs.unknown
                      and replayed.retained_by_receipt == self.journal.costs.retained_by_receipt, 'Acquisition cost/semantic replay mismatch')
        except Exception as exc:
            closure_errors.append({'stage': 'semantic_replay', 'error': repr(exc)})
        result = {'status': ('PARTIAL_ACQUISITION_COST_CLOSURE_FIRST_READER_PENDING' if self.outstanding_cost_receipts or outstanding_math_attempts or closure_errors
                             else 'FIXED_ACQUISITION_ACCOUNTING_COMPLETE_FIRST_READER_PENDING'),
            'scope': 'NUMERICAL_ACQUISITION_OVER_EXACT_PAID_PHYSICS_NOT_FULL_POLICY_SCORE',
            'cases': self.results, 'registered_population': list(range(500)), 'original_horizon': 100,
            'unique_new_numerical_receipt_refs': self.unique_new_receipts,
            'outstanding_cost_receipts': self.outstanding_cost_receipts,
            'outstanding_math_attempts': outstanding_math_attempts,
            'cost_accounting_complete': not self.outstanding_cost_receipts and not outstanding_math_attempts and not closure_errors,
            'independent_recovered_costs': 'PENDING_FIRST_READER_SEPARATE_FROM_COMMITTED_JOURNAL_TOTALS',
            'mechanical_closure_errors': closure_errors,
            'numeric_costs': self.journal.costs.numeric, 'unknown_costs': self.journal.costs.unknown,
            'retained_paid_costs_by_receipt': self.journal.costs.retained_by_receipt,
            'new_PF_entry_enabled': False, 'new_PF_calls': 0,
            'independent_verification': 'PENDING_FIRST_READER', 'full_policy_score_available': False,
            'complete_case_paths': sum(r['status'].startswith('COMPLETE') for r in self.results),
            'unknown_case_paths': sum(r['status'].startswith('UNKNOWN') for r in self.results),
            'owner_protocol_ref': self.owner.protocol_ref, 'policy_journal_ref': self.journal.reference(),
            'journal_last_sha256': self.journal.previous, 'journal_events': len(self.journal.rows),
            'journal_bytes': self.journal.bytes}
        self.put('Result.json', result); self.journal.close()
        files = []
        for path in sorted(self.out.rglob('*')):
            if path.is_file():
                raw = path.read_bytes()
                files.append({'path': path.relative_to(self.out).as_posix(), 'sha256': base.sha(raw), 'bytes': len(raw)})
        self.put('Closed_Manifest.json', {'status': 'MECHANICAL_ACQUISITION_FILE_CLOSURE_NOT_INDEPENDENT_PASS', 'files': files})
        return result

    def run_paid_only(self):
        raise RuntimeError('Use separately admitted acquisition entry; old paid-only500 is not rerun')


if __name__ == '__main__':
    raise SystemExit('Preparation only: numerical acquisition and new PF are disabled; no CLI launch.')
