"""Independent source-leaf/input-boundary/train-normalization audit, no model/PF."""
from pathlib import Path
import hashlib,json,math,statistics
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/vcsa_development/common_information_contract'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (OUT/'independent_audit.json').exists()
for name,entry in read(OUT/'manifest.json').items():assert sha(OUT/name)==entry['sha256'] and (OUT/name).stat().st_size==entry['bytes']
old={r['local_observation_id']:r for r in read(ROOT/'outputs/vcsa_development/training_interface/rows.json')}
new=read(OUT/'input_only_rows.json'); norm=read(OUT/'train_input_normalization.json')
assert len(new)==len({r['local_observation_id'] for r in new})==48 and set(old)=={r['local_observation_id'] for r in new}
samples={};scalar_count=0;numeric_count=0
for r in new:
    prior=old[r['local_observation_id']]
    assert r['split']==prior['split'] and r['scenario_id']==prior['scenario_id']
    assert r['identity_fields_are_audit_only_never_model_input']
    if not prior['training_eligible']:
        assert r['hard_abstained'] and r['model_input'] is None;continue
    model_input=r['model_input']; assert set(model_input)=={'full_observed_prompt_state','graph_and_bus_state','fixed_instruction'}
    assert model_input['graph_and_bus_state']=={k:v for k,v in prior['input'].items() if k!='messages'}
    assert model_input['fixed_instruction']==prior['input']['messages'][0]
    original=json.loads(prior['input']['messages'][1]['content'])
    assert set(original)=={'Q_values_MVAr','candidate_buses','zone_state'}
    encoded=model_input['full_observed_prompt_state']
    assert encoded['model_use_permitted'] and not encoded['unsupported_typed_field_patterns']
    seen=set(); expected_count=0
    def count_tree(value):
        if isinstance(value,dict):return 1+sum(count_tree(v) for v in value.values())
        if isinstance(value,list):return 1+sum(count_tree(v) for v in value)
        return 1
    for item in encoded['records']:
        path=tuple(item['path']);assert path not in seen;seen.add(path)
        value=original
        for component in path:value=value[component]
        if isinstance(value,dict):assert item['kind']=='object'
        elif isinstance(value,list):assert item['kind']=='array' and item['length']==len(value)
        else:
            actual_kind='null' if value is None else 'bool' if type(value)==bool else 'int' if type(value)==int else 'float' if type(value)==float else 'str'
            assert actual_kind==item['kind'] and type(value)==type(item['value']) and value==item['value']
            scalar_count+=1
        assert item['path_utf8']==[list(part.encode('utf-8')) if isinstance(part,str) else part for part in path]
        if item['kind']=='str':assert item['value_utf8']==list(value.encode('utf-8'))
        if item['kind'] in {'int','float'}:
            numeric_count+=1;stats=norm['numeric_fields'][item['field_pattern']]
            assert math.isclose(item['normalized_numeric'],(value-stats['mean'])/stats['scale'],rel_tol=0,abs_tol=1e-12)
            if r['split']=='train':samples.setdefault(item['field_pattern'],[]).append(float(value))
    assert len(seen)==count_tree(original)
assert scalar_count==10741 and set(samples)==set(norm['numeric_fields'])
assert set(norm['fit_train_ids'])=={identity for identity,r in old.items() if r['split']=='train' and r['training_eligible']}
for key,values in samples.items():
    stats=norm['numeric_fields'][key];mean=statistics.mean(values);std=statistics.pstdev(values)
    assert stats['mean']==mean and stats['observed_std']==std and stats['observations']==len(values)
    floor=1e-6*max(1,abs(mean));assert stats['near_constant_floor']==floor
    assert stats['scale']==(std if std>=floor else 1.)
report={'passed':True,'exact_identities':48,'source_scalar_fields_independently_checked':scalar_count,
        'numeric_field_transform_checks':numeric_count,'train_only_normalization_groups':len(samples),
        'input_targets_and_scenario_identifiers_excluded_from_model_payload':True,
        'scope_graph_original_inputs_unchanged':True,'source_manifest_sha256':sha(OUT/'manifest.json'),
        'new_model_PF_optimizer_calls':0,'source_sha256':sha(Path(__file__))}
(OUT/'independent_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
