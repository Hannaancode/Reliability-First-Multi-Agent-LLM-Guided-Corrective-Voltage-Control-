# Closed expert complementarity: development finding only

The frozen numerical controller restored264/500 all13bus voltage bands, versus363/500 publishedDDPG. Its primary superiority gate FAILED. All232 UV-only cases failed strict fullband under NUM, while247/251 OV-only cases succeeded. PublishedSafeDDPG restored232/232 UV-only cases but13/251 OV-only cases.

A rule using only the initial violation class selects saved successful branches for496/500 cases. This is a post-hoc development assembly, not a measured new policy, ourLLM result, calibrated winning probability or confirmation. The published-only input rule and all3published available-trajectory envelope are explicit stronger controls in the JSON.

The scientific hypothesis is complementary failure modes, not a threshold/LP rescue. The current numerical method and failed private-model interface remain stopped. A new router needs fresh exact physical identities, its OWN source-native SafeDDPG parameter carry, actual continuous episodes, all costs and a locked independent reader. The mutable SafeDDPG b/c behavior prevents calling copied standalone outcomes an executed router.

All six final goals remain open. No new model or physics call was made by this analysis.
