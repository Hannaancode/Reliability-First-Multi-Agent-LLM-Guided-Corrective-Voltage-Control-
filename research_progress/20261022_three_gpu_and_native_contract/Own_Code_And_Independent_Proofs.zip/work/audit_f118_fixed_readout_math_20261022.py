"""Saved readout equations/decisions only; no fitting, factorization or PF."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['OMP_NUM_THREADS']='2'
import argparse,hashlib,json,sys,time
from pathlib import Path
from collections import defaultdict
R=Path(__file__).resolve().parents[1];P=R/'outputs/f118_encoder_readout_preparation_20261022'
sys.path.insert(0,str(R/'work'))
from run_original_role_numeric_gate_20261011 import identity,legal
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import numpy as np
    ap=argparse.ArgumentParser();ap.add_argument('--study',choices=['numeric','encoders'],required=True);args=ap.parse_args()
    source=R/('outputs/f118_fixed_numeric_readouts_20261022' if args.study=='numeric' else 'outputs/f118_fixed_encoder_readouts_20261022')
    O=R/('outputs/f118_fixed_numeric_readout_audit_20261022' if args.study=='numeric' else 'outputs/f118_fixed_encoder_readout_audit_20261022');O.mkdir(exist_ok=False)
    start=time.monotonic();manifest=read(source/'Closed_Manifest.json')['members']
    for n,h in manifest.items():assert sha(source/n)==h
    rows=read(P/'Readout_Rows_Local_Only.json');fit=[r for r in rows if r['readout_partition']=='FIT'];held=[r for r in rows if r['readout_partition']=='HELD']
    actions={identity(r['action']):r['action'] for r in fit};actions[identity(None)]=None;classes=sorted(actions)
    weights=np.asarray([r['weight'] for r in fit],np.float64);sw=np.sqrt(weights);y=np.zeros((340,len(classes)),np.float64)
    for i,r in enumerate(fit):y[i,classes.index(identity(r['action']))]=1
    predictions=read(source/'Predictions.json');result=read(source/'Results.json');checks={}
    for name in ['same_current_numeric'] if args.study=='numeric' else read(P/'Protocol.json')['arms']:
        data=np.load(source/(name+'_source.npz'));xf=data['xf'];xh=data['xh'];d=xf.shape[1]
        mean=np.average(xf,axis=0,weights=weights);sd=np.maximum(np.sqrt(np.average((xf-mean)**2,axis=0,weights=weights)),1e-6)
        assert np.array_equal(mean,data['mean']) and np.array_equal(sd,data['sd']) and np.array_equal(y,data['y'])
        zf=(xf-mean)/sd;zh=(xh-mean)/sd;fd=zf@zf.T/d;hd=zh@zf.T/d
        for kernel in ['linear','rbf']:
            if kernel=='linear':K=fd;KH=hd
            else:
                K=np.exp(-np.maximum(0,np.sum(zf*zf,axis=1)[:,None]/d+np.sum(zf*zf,axis=1)[None,:]/d-2*fd))
                KH=np.exp(-np.maximum(0,np.sum(zh*zh,axis=1)[:,None]/d+np.sum(zf*zf,axis=1)[None,:]/d-2*hd))
            key=name+'_'+kernel;a=np.load(source/(key+'_fit.npz'));A=sw[:,None]*K*sw[None,:]+.001*weights.sum()*np.eye(340)
            assert np.max(abs(A-a['A']))<1e-10 and np.array_equal(sw[:,None]*y,a['rhs'])
            L=a['lower_cholesky'];assert np.all(np.diag(L)>0)
            chol_error=float(np.max(abs(L@L.T-A)));res=float(np.max(abs(A@a['alpha']-a['rhs'])))
            assert chol_error<1e-8 and res<1e-8
            scores=KH@(sw[:,None]*a['alpha']);assert np.max(abs(scores-a['scores']))<1e-10
            pred=[r for r in predictions if r['representation']==name and r['kernel']==kernel];assert len(pred)==96
            worlds=defaultdict(list)
            for i,(r,observed) in enumerate(zip(held,pred)):
                allowed=np.array([legal(actions[c],r['packet']) for c in classes]);idx=int(np.argmax(np.where(allowed,scores[i],-np.inf)))
                expected=actions[classes[idx]];hit=identity(expected)==identity(r['action'])
                assert expected==observed['prediction'] and r['action']==observed['target'] and hit==observed['exact'] and observed['legal']
                worlds[r['world_sha256']].append(hit)
            metric=float(np.mean([np.mean(v) for v in worlds.values()]));assert metric==result['results'][key]['equal_world_exact_action']
            checks[key]={'maximum_saved_Cholesky_equation_error':chol_error,'maximum_regularized_fit_equation_error':res,'all96_predictions_targets_legality_exact':True,'equal_world_exact_action':metric}
    put(O/'Independent_Audit.json',{'status':'PASS_ALL_FIXED_READOUT_EQUATIONS_AND_ORDERED_DECISIONS','checks':checks,'new_fits_factorizations_solves_model_PF_calls':0,
        'historical_private_adapter_training_overlap_retained':True,'not_physical_superiority':True,'source_sha256':sha(__file__),'workflow_seconds':time.monotonic()-start})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'audit':'PASS','readouts':len(checks),'new_fits_model_PF_calls':0}))
if __name__=='__main__':main()
