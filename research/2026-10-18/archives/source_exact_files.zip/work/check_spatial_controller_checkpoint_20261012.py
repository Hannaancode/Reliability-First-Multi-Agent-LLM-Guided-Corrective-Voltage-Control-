"""One fresh two-process SOFTWARE fixture; labelled synthetic nets/mock solver.

Never invokes real runpp, pretrained model, optimizer or original experiment.
Checks controller persistence/ownership/unknown handling, not physical benefit.
"""
import copy
import hashlib
import json
import os
import pickle
import random
import subprocess
import sys
import time
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import pandapower as pp
import paid_spatial_controller_checkpoint_v1 as checkpoint
from frozen_physics_loader import load_stack, AUDIT
from native_continuation_preservation_v2 import EvidenceJournal, canonical, extended_local_path
from paid_spatial_native_queries_v2 import NativeQueriesV2, OperationalStop
from trusted_causal_controller_snapshot import SOLVER_ROLES, write_bytes
from value_normal_band_mediation import NormalUpperMediation

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/critical_research_reset_20261010/spatial_controller_checkpoint_software_20261012'
sha = lambda data: hashlib.sha256(data).hexdigest()


def replace_fixture_file(path, data):
    assert path.resolve().is_relative_to(extended_local_path(OUT/'fixture').resolve())
    with path.open('wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def sources():
    names = ['work/paid_spatial_native_queries.py', 'work/paid_spatial_native_queries_v2.py',
             'work/paid_spatial_controller_checkpoint_v1.py', 'work/check_spatial_controller_checkpoint_20261012.py',
             'work/paid_spatial_two_step_search.py', 'work/native_continuation_preservation.py']
    return {n: sha((ROOT/n).read_bytes()) for n in names}


def warm():
    directory = extended_local_path(OUT/'fixture')
    directory.mkdir(exist_ok=False)
    write_bytes(directory/'owner.claim', canonical({'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(),
        'protocol_sha256': sha((OUT/'Protocol.json').read_bytes()), 'execution_kind': 'LABELLED_MOCK_SOFTWARE'}))
    protocol = json.loads((OUT/'Protocol.json').read_text('utf8'))
    protocol_sha256 = sha((OUT/'Protocol.json').read_bytes())
    _, runner, _ = load_stack()
    assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    net = pp.create_empty_network()
    for _ in range(3):
        pp.create_bus(net, vn_kv=110.)
    net.res_bus = pd.DataFrame({'vm_pu': [.92, .94, 1.], 'va_degree': [0., 0., 0.],
                              'p_mw': [1., 1., 1.], 'q_mvar': [0., 0., 0.]}, index=net.bus.index)
    net['converged'] = True
    mock_calls = []
    original = pp.runpp
    def mock_solver(trial, **kwargs):
        assert kwargs == SOLVER_ROLES['trial']
        mock_calls.append(kwargs)
        if len(mock_calls) == 2:
            raise RuntimeError('LABELLED_MOCK_FAILURE_NOT_PHYSICS')
        trial.res_bus.loc[:, 'vm_pu'] = [.94, .96, 1.01]
    pp.runpp = mock_solver
    journal = EvidenceJournal(directory/'warm_events.jsonl', protocol_sha256)
    random.seed(20261012)
    np.random.seed(20261012)
    q = None
    try:
        with NormalUpperMediation(runner.rescue, 1.05, 1e-8):
            q = NativeQueriesV2(pp, runner, {'MG1': [0, 1, 2]}, directory, journal, protocol, protocol_sha256)
            process = {'actual_commit_count': 0, 'remaining_slots': 25, 'actual_action_history': [],
                       'failed_signatures': [], 'episode': 'SYNTHETIC_CHECKPOINT_ONLY'}
            parent = q.register(net, process, label='SYNTHETIC_UNSOLVED_FIXTURE_NO_PHYSICS')
            actions = q.menu(parent)
            accepted = q.query(parent, actions[0])
            failed = q.query(parent, actions[1])
            assert accepted.accepted and not failed.accepted and failed.successor is None
            # Simulate an already recorded commitment cursor; this fixture does
            # NOT claim a real application/commit PF or physical trajectory.
            history = [{'iteration': 1, 'parent_handle': parent, 'selected_action_id': actions[0],
                        'trial_successor': accepted.successor, 'action': q.menus[parent][actions[0]],
                        'committed_handle': 'TEMP'}]
            process = {**process, 'actual_commit_count': 1, 'remaining_slots': 24,
                       'actual_action_history': history, 'failed_signatures': [actions[1]]}
            # Avoid recursive self-hash: the network's process stores action
            # history, while checkpoint history stores external capsule handles.
            # Native actual-action history is therefore normalized to actions;
            # coordinator chronology lives in the separate commitment ledger.
            process['actual_action_history'] = [q.menus[parent][actions[0]]]
            committed = q.register(q.restore(accepted.successor)['net'], process,
                                   label='SYNTHETIC_SIMULATED_COMMIT_CURSOR_NO_COMMIT_SOLVE')
            history[0]['committed_handle'] = committed
            controller = {'phase': 'PRE_SELECTION', 'episode': process['episode'], 'policy': 'SOFTWARE_FIXTURE',
                          'actual_commit_count': 1, 'remaining_slots': 24, 'actual_action_history': history,
                          'current_handle': committed, 'failed_signatures': [actions[1]],
                          'guard': {'upper': 1.05, 'tolerance': 1e-8}, 'perbus_cap': 450,
                          'input_sha256': {'synthetic_fixture': sha(canonical({'buses': 3, 'label': 'MOCK_ONLY'}))},
                          'runtime_identity': {'numpy': np.__version__, 'pandas': pd.__version__,
                                               'pandapower': pp.__version__},
                          'direct_costs': {'actual_initial_PF': 0, 'actual_commit_PF': 0,
                                           'cursor_fixture_only': True}, 'Qgrid': runner.rescue.Q_SWEEP}
            anchor = checkpoint.save_checkpoint(q, controller, 'planned_warm_prefix')
            expected = {'python': [random.random() for _ in range(5)], 'numpy': np.random.random(5).tolist()}
            # Preserve a SECOND labelled UNKNOWN fixture without running its
            # attempted call. No failed/unfinished identity becomes negative.
            q.new_queries += 1
            q.attempted.add((parent, actions[2]))
            q._journal('new_query_intent', {'identity': 'query_000003', 'parent': parent,
                       'action': q.menus[parent][actions[2]], 'label': 'UNEXECUTED_PENDING_MOCK_IDENTITY'})
            q.stopped = True
            partial = checkpoint.save_checkpoint(q, controller, 'terminal_unknown_fixture')
            write_bytes(OUT/'Warm_Returned_Anchor.json', canonical({'anchor': anchor, 'partial_anchor': partial,
                'controller': controller, 'expected_rng': expected, 'warm_pid': os.getpid(),
                'parent': parent, 'accepted_action': actions[0], 'failed_action': actions[1],
                'original_ordered_menu': actions,
                'new_unexecuted_action': actions[3], 'warm_mock_solver_calls': len(mock_calls)}))
    finally:
        if q is not None:
            q.close()
        journal.close()
        pp.runpp = original


def main():
    OUT.mkdir(exist_ok=False)
    begun = time.perf_counter()
    checks = []
    protocol = {'execution_kind': 'LABELLED_SYNTHETIC_MOCK_ONLY_NO_PHYSICS',
                'actual_query_binding_authorized': True, 'planned_process_handoff_authorized': True,
                'scope': 'GLOBAL_ORIGINAL_DFF_MENU', 'new_query_limit': 8, 'payload_byte_limit': 10000000,
                'absolute_deadline_utc': (datetime.now(timezone.utc)+timedelta(seconds=600)).isoformat(),
                'source_sha256': sources()}
    write_bytes(OUT/'Protocol.json', canonical(protocol))
    protocol_sha256 = sha((OUT/'Protocol.json').read_bytes())
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    child = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--warm'], capture_output=True,
                           timeout=180, creationflags=flags)
    write_bytes(OUT/'Warm_stdout.txt', child.stdout)
    write_bytes(OUT/'Warm_stderr.txt', child.stderr)
    assert child.returncode == 0, child.stderr.decode(errors='replace')
    evidence = json.loads((OUT/'Warm_Returned_Anchor.json').read_text('utf8'))
    anchor = evidence['anchor']
    directory = extended_local_path(OUT/'fixture')
    def check(name, condition):
        assert condition, name
        checks.append(name)
    check('actual_distinct_warm_process_ended', not checkpoint.process_alive(evidence['warm_pid']) and
          evidence['warm_pid'] != os.getpid())
    check('live_pid_recognition', checkpoint.process_alive(os.getpid()))
    def read(anchor_to_read=anchor, expected=protocol, identity=None):
        return checkpoint.read_checkpoint(anchor_to_read, expected_protocol=expected,
            expected_protocol_sha256=protocol_sha256,
            expected_controller_identity=identity if identity is not None else evidence['controller'],
            expected_directory=directory)
    state, manifest = read()
    check('complete_cursor_history_failed_signatures', state['controller'] == evidence['controller'] and
          state['controller']['actual_commit_count'] == 1 and state['controller']['remaining_slots'] == 24)
    check('paid_receipts_and_real_mock_exception_retained', state['counters_before_checkpoint']['pf_attempts'] == 2 and
          state['counters_before_checkpoint']['pf_returns'] == 1 and state['counters_before_checkpoint']['pf_exceptions'] == 1)
    check('ordered_native_menu_full_registry_preserved', list(state['menus'][evidence['parent']]) == evidence['original_ordered_menu'] and
          len(state['handles']) == 3 and len(state['attempted']) == len(state['receipts']) == 2)
    def reject(name, fn, exception=ValueError):
        try:
            fn()
        except exception:
            checks.append(name)
        else:
            raise AssertionError('Unrejected unsafe fixture: '+name)
    reject('wrong_external_payload_anchor_before_unpickle', lambda: read({**anchor, 'payload_sha256': '0'*64}))
    reject('wrong_external_manifest_anchor', lambda: read({**anchor, 'manifest_sha256': '0'*64}))
    reject('extended_deadline_protocol_refused', lambda: read(expected={**protocol,
           'absolute_deadline_utc': (datetime.now(timezone.utc)+timedelta(days=1)).isoformat()}))
    reject('changed_root_input_refused', lambda: read(identity={**evidence['controller'], 'input_sha256': {'bad': '0'*64}}))
    reject('relative_path_traversal_refused', lambda: checkpoint.local_file(directory, '../outside'))
    reject('absolute_artifact_path_refused', lambda: checkpoint.local_file(directory, 'C:/outside'))
    saved = directory/'queries/query_000001/Receipt.json'
    original = saved.read_bytes()
    try:
        replace_fixture_file(saved, original+b' ')
        reject('changed_receipt_artifact_refused', read)
    finally:
        replace_fixture_file(saved, original)
    state, manifest = read()
    partial, partial_meta = read(evidence['partial_anchor'])
    check('pending_attempt_preserved_unknown_without_scientific_call', not partial['resumable'] and
          partial['counters_before_checkpoint']['new_queries'] == 3 and len(partial['receipts']) == 2 and
          partial['counters_before_checkpoint']['pf_attempts'] == 2)
    claim = {'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(), 'protocol_sha256': protocol_sha256,
             'inherited_checkpoint_sha256': anchor['payload_sha256'], 'mock_only': True}
    replace_fixture_file(directory/'owner.claim', canonical(claim))
    _, runner, _ = load_stack()
    original_pf = pp.runpp
    cold_mock_calls = []
    def cold_mock(trial, **kwargs):
        assert kwargs == SOLVER_ROLES['trial']
        cold_mock_calls.append(kwargs)
        trial.res_bus.loc[:, 'vm_pu'] = [.94, .96, 1.01]
    pp.runpp = cold_mock
    journal = EvidenceJournal(directory/'cold_events.jsonl', protocol_sha256)
    q = None
    handoff = {'issuer_pid': evidence['warm_pid'], 'receiver_pid': os.getpid(),
               'checkpoint_sha256': anchor['payload_sha256'], 'issuer_exit_code': child.returncode,
               'phase': 'PLANNED_PRESERVED_HANDOFF_NOT_TERMINAL_SCIENCE_RETRY'}
    try:
        with NormalUpperMediation(runner.rescue, 1.05, 1e-8):
            q = NativeQueriesV2(pp, runner, {'MG1': [0, 1, 2]}, directory, journal, protocol, protocol_sha256)
            reject('terminal_unknown_checkpoint_cannot_bind', lambda: checkpoint.bind_planned_handoff(
                q, partial, partial_meta, anchor=evidence['partial_anchor'], handoff=handoff))
            reject('wrong_receiver_owner_refused', lambda: checkpoint.bind_planned_handoff(q, state, manifest,
                anchor=anchor, handoff={**handoff, 'receiver_pid': os.getpid()+999}))
            check('failed_binding_keeps_owner_empty', not q.handles and not q.attempted and journal.sequence == 0)
            restored = checkpoint.bind_planned_handoff(q, state, manifest, anchor=anchor, handoff=handoff)
            check('complete_process_controller_cold_binding', restored == evidence['controller'])
            check('rng_restoration_exact_across_real_processes',
                  [random.random() for _ in range(5)] == evidence['expected_rng']['python'] and
                  np.random.random(5).tolist() == evidence['expected_rng']['numpy'])
            check('absolute_deadline_query_and_storage_bounds_unchanged',
                  q.deadline.isoformat() == protocol['absolute_deadline_utc'] and
                  q.query_limit == 8 and q.storage_limit == 10000000)
            check('prior_checkpoint_bytes_solver_and_preservation_costs_not_reset',
                  q.payload_bytes == state['counters_before_checkpoint']['payload_bytes']+manifest['payload_bytes'] and
                  q.pf_seconds == state['counters_before_checkpoint']['pf_seconds'] and
                  q.preservation_seconds >= state['counters_before_checkpoint']['preservation_seconds'])
            first = q.query(evidence['parent'], evidence['accepted_action'])
            failure = q.query(evidence['parent'], evidence['failed_action'])
            check('cold_success_and_failure_cache_reuse_zero_mock_solver_calls', first.accepted and not failure.accepted and
                  len(cold_mock_calls) == 0 and q.pf_attempts == 2 and q.new_queries == 2 and q.reused_receipts == 2)
            reject('v1_second_process_handoff_checkpoint_blocked', lambda: checkpoint.save_checkpoint(q, restored, 'unsupported_second'))
            next_receipt = q.query(evidence['parent'], evidence['new_unexecuted_action'])
            check('only_distinct_unexecuted_identity_runs_after_handoff', len(cold_mock_calls) == 1 and
                  q.new_queries == 3 and q.pf_attempts == 3 and q.pf_returns == 2 and q.pf_exceptions == 1 and
                  next_receipt.action == evidence['new_unexecuted_action'])
    finally:
        if q is not None:
            q.close()
        journal.close()
        pp.runpp = original_pf
    result = {'saved_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS', 'checks': checks,
              'check_count': len(checks), 'source_sha256': sources(), 'warm_pid': evidence['warm_pid'],
              'cold_pid': os.getpid(), 'warm_mock_solver_calls': evidence['warm_mock_solver_calls'],
              'cold_distinct_mock_solver_calls': len(cold_mock_calls),
              'actual_new_nonlinear_PF_model_optimizer_controller_cloud_forecast_calls': 0,
              'native_verifier_used_on_labelled_synthetic_nets_only': True,
              'all_loaded_original_function_ASTs_unchanged': all(x['all_function_asts_unchanged'] for x in AUDIT),
              'software_workflow_seconds': time.perf_counter()-begun,
              'limitations': ['Synthetic cursor/history only; no actual protected commitment or full physical cold process trajectory.',
                             'v1 permits one planned process handoff; linked multi-segment checkpoints unsupported and explicitly blocked.',
                             'Checkpoint timing excludes final cost-receipt fsync; full walltime and reader/handoff costs require separate owner ledger.',
                             'No full 25-step policy/comparator campaign or learner is ready; no LLM or physical performance claim.']}
    write_bytes(OUT/'Software_Readiness.json', canonical(result))
    print(json.dumps({'status': 'PASS', 'checks': len(checks), 'actual_new_PF_model_calls': 0}))


if __name__ == '__main__':
    if '--warm' in sys.argv:
        warm()
    else:
        main()
