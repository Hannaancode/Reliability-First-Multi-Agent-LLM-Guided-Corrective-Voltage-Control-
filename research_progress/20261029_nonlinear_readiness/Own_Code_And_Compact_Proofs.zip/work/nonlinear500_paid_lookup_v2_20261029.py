"""Thin source/manifest-pinned exact-result reader. No producer/science imports."""
from pathlib import Path
import json,hashlib
def lookup_exact(root,physical_signature,kwargs,expected_manifest_sha256):
    root=Path(root).resolve();directory=root/'outputs/nonlinear500_paid_registry_20261029'
    def verified(path,expected):
        path=path.resolve();path.relative_to(root);raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Pinned evidence changed: '+str(path))
        return raw
    manifest=json.loads(verified(directory/'Frozen_Registry_Manifest.json',expected_manifest_sha256))
    registry=json.loads(verified(directory/'Paid_Physical_Registry.json',manifest['Paid_Physical_Registry.json']['sha256']))
    bindings=json.loads(verified(directory/'Source_Bindings.json',manifest['Source_Bindings.json']['sha256']))
    key=physical_signature+'|'+json.dumps(kwargs,sort_keys=True);entry=registry['entries'].get(key)
    if entry and entry['reuse']:
        reuse=entry['reuse']
        for field in ['after','fields']:verified(root/reuse[field]['path'],reuse[field]['sha256'])
        cert=reuse['independent_certificate'];verified(root/cert,bindings[cert]['sha256'])
        return dict(status='VERIFIED_EXACT_PAID_REUSE',key=key,reuse=reuse,source_manifest_sha256=expected_manifest_sha256,new_PF_permitted=False)
    if physical_signature in registry['signature_deny_provenance']:
        return dict(status='BLOCKED_PREVIOUSLY_ATTEMPTED_NO_ELIGIBLE_EXACT_KEY',key=key,new_PF_permitted=False)
    return dict(status='MISS_IN_FINITE_SCOPED_REGISTRY',key=key,new_PF_permitted=False,universal_absence_claim=False)
