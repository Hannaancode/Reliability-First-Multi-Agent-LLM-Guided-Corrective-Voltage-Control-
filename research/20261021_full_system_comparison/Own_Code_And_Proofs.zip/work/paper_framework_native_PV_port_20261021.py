"""Explicit paper-framework/native-PV port boundaries; original weights/source unchanged.

This is a named PORT, not the unchanged federation shunt controller. Positive
LLM requests retain literal Mvar units. No rescaling/clipping or invalid fill.
Numerical candidate generation, model inference and PF remain external.
"""
import ast,copy,hashlib,json,math,collections
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
PAPER_GRID=(25.,50.,75.,100.,125.,150.,200.,250.,300.)
PORT_FRACTIONS=tuple(v/300. for v in PAPER_GRID)

def paper_normalizer():
    path=ROOT/'work/e/audit/phase2g_rescue_runner.py';tree=ast.parse(path.read_text(encoding='utf-8'))
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='normalize_action')
    namespace={};exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec'),namespace)
    return namespace['normalize_action'],hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()

def native_contract(bus_ids,PV_bus_ids,current_Q,caps,Y):
    buses=np.asarray(bus_ids);pv=np.asarray(PV_bus_ids);q=np.asarray(current_Q,dtype=np.float64);c=np.asarray(caps,dtype=np.float64);y=np.asarray(Y)
    if buses.ndim!=1 or len(set(buses.tolist()))!=len(buses) or y.shape!=(len(buses),len(buses)):raise ValueError('Exact ordered native bus/Y contract')
    if pv.ndim!=1 or len(pv)!=len(set(pv.tolist())) or q.shape!=pv.shape or c.shape!=pv.shape:raise ValueError('Native device namespace ambiguous')
    if not set(pv.tolist())<=set(buses.tolist()) or not np.isfinite(q).all() or not np.isfinite(c).all() or not (c>0).all() or not (np.abs(q)<=c+1e-12).all():raise ValueError('Native finite currentQ/caps required')
    if not np.isfinite(y).all():raise ValueError('Finite source admittance required')
    order={int(b):i for i,b in enumerate(buses)};pv_sorted=sorted(int(v) for v in pv)
    if len(pv_sorted)<4:raise ValueError('Four-zone port requires four native actuators')
    roots=[pv_sorted[(i*len(pv_sorted))//4] for i in range(4)];adj={int(b):[] for b in buses}
    for i,b in enumerate(buses):
        for j,other in enumerate(buses):
            if i!=j and (y[i,j]!=0 or y[j,i]!=0):adj[int(b)].append(int(other))
    distances=[]
    for root in roots:
        distance={root:0};todo=collections.deque([root])
        while todo:
            b=todo.popleft()
            for nxt in sorted(adj[b]):
                if nxt not in distance:distance[nxt]=distance[b]+1;todo.append(nxt)
        if len(distance)!=len(buses):raise ValueError('Disconnected/native topology needs explicit island contract')
        distances.append(distance)
    zones={f'MG{i+1}':[] for i in range(4)}
    for b in buses:
        winner=min(range(4),key=lambda z:(distances[z][int(b)],z));zones[f'MG{winner+1}'].append(int(b))
    # Each actuator belongs to its actual bus zone, never a favored recipient subset.
    pv_zones={z:[int(b) for b in pv if int(b) in set(members)] for z,members in zones.items()}
    if set(b for members in pv_zones.values() for b in members)!=set(pv.tolist()):raise ValueError('Lost native actuator')
    return {'bus_ids':[int(b) for b in buses],'PV_bus_ids':[int(b) for b in pv],
            'current_Q_Mvar':q,'caps_Mvar':c,'bus_order':order,'zones':zones,'PV_zones':pv_zones,
            'partition_roots':roots,'partition_rule':'Four sortedPVquartile roots; minimum currentYgraph hop distance, zone-index tie-break. No voltage outcomes or candidate results used.'}

def request_to_native_Q(parsed,contract):
    normalize,_=paper_normalizer();canonical=normalize(parsed)
    if not canonical:return {'valid':False,'reason':'original_normalizer_no_action','native_Q':None}
    payload=canonical.get('add_shunts_q_mvar',{})
    if len(payload)!=1:return {'valid':False,'reason':'one_receiver_required_by_paper_port','native_Q':None}
    bus_s,request=next(iter(payload.items()));bus=int(bus_s);delta=float(request)
    if bus not in contract['PV_bus_ids']:return {'valid':False,'reason':'not_a_native_PV_bus','native_Q':None}
    if not math.isfinite(delta) or delta<=0:return {'valid':False,'reason':'invalid_positive_literal_Mvar_increment','native_Q':None}
    index=contract['PV_bus_ids'].index(bus);q=contract['current_Q_Mvar'].copy();target=q[index]+delta
    if abs(target)>contract['caps_Mvar'][index]:return {'valid':False,'reason':'native_cap_exceeded_no_rescale_or_clip','native_Q':None,'requested_Mvar':delta}
    q[index]=target
    return {'valid':True,'reason':'literal_positive_Mvar_increment_native_PV_port','native_Q':q,
            'bus':bus,'increment_Mvar':delta,'original_normalized_action':canonical}

def native_positive_refinement_menu(contract,only_buses=None):
    # Explicit hardware-normalized menu of the same nine source magnitudes.
    # It is a new menu for a named native port, never a reinterpretation of raw
    # LLM output or a claim that the original 25Mvar physical command is legal.
    buses=contract['PV_bus_ids'] if only_buses is None else list(only_buses)
    if not set(buses)<=set(contract['PV_bus_ids']):raise ValueError('Illegal refinement namespace')
    rows=[]
    for bus in buses:
        i=contract['PV_bus_ids'].index(bus);headroom=float(contract['caps_Mvar'][i]-contract['current_Q_Mvar'][i])
        if headroom<=0:continue
        for fraction in PORT_FRACTIONS:
            increment=headroom*fraction;q=contract['current_Q_Mvar'].copy();q[i]=q[i]+increment
            if abs(q[i])>contract['caps_Mvar'][i]+1e-12:raise ValueError('Derived native menu exceeded its cap')
            rows.append({'bus':bus,'increment_Mvar':increment,'native_absolute_Q_Mvar':q,'source_fraction':fraction})
    return rows

def messages_for_zone(contract,current_VM,zone,feedback=None):
    vm=np.asarray(current_VM,dtype=np.float64)
    if vm.shape!=(len(contract['bus_ids']),) or not np.isfinite(vm).all():raise ValueError('Complete finite current-only voltage vector required')
    if zone not in contract['zones']:raise ValueError('Unknown deterministic zone')
    order=contract['bus_order'];members=contract['zones'][zone];local={b:float(vm[order[b]]) for b in members}
    allowed=contract['PV_zones'][zone];fullUV={str(b):float(vm[order[b]]) for b in contract['bus_ids'] if vm[order[b]]<.95}
    if not fullUV:return None
    if not allowed:return None
    worst=sorted(local,key=lambda b:(local[b],b));limits=[]
    for bus in allowed:
        i=contract['PV_bus_ids'].index(bus);limits.append({'bus':bus,'current_Q_mvar':float(contract['current_Q_Mvar'][i]),
            'native_abs_Q_cap_mvar':float(contract['caps_Mvar'][i]),'maximum_positive_increment_mvar':float(contract['caps_Mvar'][i]-contract['current_Q_Mvar'][i])})
    state={'zone':zone,'min_voltage_pu':min(local.values()),'max_voltage_pu':max(local.values()),
           'n_undervoltage':sum(v<.95 for v in local.values()),'n_overvoltage':sum(v>1.05 for v in local.values()),
           'worst_bus':worst[0],'undervoltage_buses':{str(b):v for b,v in local.items() if v<.95},
           'lowest_voltage_buses':{str(b):local[b] for b in worst[:8]}}
    # No source outcome, teacher/algorithm name or after-state label is a body input.
    user=('You are a zone agent inside a physics-verified multi-agent voltage controller.\n'
          'This explicitly named native-PV port uses signed absolute inverter bounds; your positive request is a literal capacitive Mvar increment at one allowed nativePVbus. '
          'It is not a shunt installation. Never output the federation25-300Mvar values unless the actual device headroom permits them. No unit rescaling will be performed.\n'
          'LOCAL_ZONE_STATE:\n'+json.dumps(state,separators=(',',':'))+'\nGLOBAL_UNDERVOLTAGE_BUSES:\n'+json.dumps(fullUV,separators=(',',':'))+
          '\nNATIVE_LEGAL_RECIPIENTS_AND_MEASURED_HEADROOM:\n'+json.dumps(limits,separators=(',',':'))+
          '\nPAST_CURRENT_EPISODE_FEEDBACK:\n'+json.dumps(feedback or [],separators=(',',':'))+
          '\nReturn the original compact action schema only: {"bus":"BUS_ID","q_mvar":POSITIVE_LITERAL_MVAR_INCREMENT}. '
          'A no-action answer is legal when no positive support is available. The common physical verifier tests every proposed action before commitment.')
    return [{'role':'system','content':'You are a microgrid zone agent. Return only valid JSON. No prose.'},{'role':'user','content':user}]
