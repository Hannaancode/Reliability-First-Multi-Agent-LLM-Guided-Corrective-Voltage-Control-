"""Saved-only historical D-SE join. Never imports a controller or physics/model API."""
from pathlib import Path
import ast, csv, datetime, hashlib, json, os

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original118_saved_dse_reconciliation_20261028'
OLD = 'outputs/actual_DSE_development_reference'
NEW = 'outputs/original118_closed_comparison_20261028'
evidence = {}

def sha(path):
    return hashlib.sha256((R / path).read_bytes()).hexdigest()

def read(path):
    evidence[path] = sha(path)
    return json.loads((R / path).read_text('utf-8-sig'))

def write(name, obj):
    (O / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', 'utf-8')

def main():
    assert not O.exists(), 'Additive output already exists; do not repeat this analysis.'
    oldp = read(OLD + '/protocol.json')
    oldaudit = read(OLD + '/Independent_Completion_Audit.json')
    assert oldaudit['all_identity_selector_manifest_and_cost_gates_passed']
    assert oldaudit['all_branch_committed_metric_replays_passed_1e10']
    oldmanifest = read(OLD + '/Verified_Scientific_Manifest.json')
    current = read(NEW + '/Comparison.json')
    currentmanifest = read(NEW + '/Closed_Manifest.json')
    assert currentmanifest['members']['Comparison.json'] == sha(NEW + '/Comparison.json')
    currentcosts = read(NEW + '/Full_Cost_Source_Blocks.json')
    currentp = read('outputs/r118_dff_partition_continuation_preparation_20261023/Protocol.json')
    bindings = read(currentp['bindings'])
    recipes = {x['scenario_id']: x for x in oldp['scenarios']}
    bindings = {x['case_id']: x for x in bindings}
    source_equal = []
    for path, digest in oldp['frozen_source_sha256'].items():
        path = path.replace('\\', '/')
        assert sha(path) == digest
        evidence[path] = digest
        if path != 'work/dff_alt.py':
            assert currentp['source_hashes'][path] == digest
            source_equal.append(path)
    driver = 'work/run_actual_DSE_development_reference.py'
    assert sha(driver) == oldp['driver_sha256']
    evidence[driver] = sha(driver)
    selector = 'work/e/audit/run_reflection_v4_safety_envelope.py'
    tree = ast.parse((R / selector).read_text('utf-8-sig'))
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'choose_safety_envelope')
    namespace = {}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), selector, 'exec'), namespace)
    choose = namespace['choose_safety_envelope']
    rows, checks, costs = [], [], []
    for original in current['rows']:
        cid = original['case_id']
        recipe = recipes[cid]
        assert recipe['sha256'] == bindings[cid]['registration']['recipe_sha256']
        recipe_path = recipe['path'].replace('\\', '/')
        assert sha(recipe_path) == recipe['sha256']
        evidence[recipe_path] = recipe['sha256']
        branches = {}
        for arm in ['DFF', 'DFF-ALT']:
            rel = f'branches/{cid}__{arm}.json'
            b = read(OLD + '/' + rel)
            assert sha(OLD + '/' + rel) == oldmanifest[rel]['sha256']
            assert b['scenario_sha256'] == recipe['sha256']
            assert b['protocol_sha256'] == sha(OLD + '/protocol.json')
            assert b['base_network_preserved'] and b['independent_committed_state_physical_replay']['passed']
            assert b['result']['base_metrics'] == bindings[cid]['initial_metrics']
            branches[arm] = b
        recent_path = f'outputs/r118_dff_partition_continuation_execution_20261023/{cid}/Result.json'
        recent = read(recent_path)
        # Whole result equality includes every action, log, metric, counter and stop reason.
        assert branches['DFF']['result'] == recent
        pf = read(OLD + f'/portfolios/{cid}.json')
        assert sha(OLD + f'/portfolios/{cid}.json') == oldmanifest[f'portfolios/{cid}.json']['sha256']
        assert pf['valid'] and pf['scenario_sha256'] == recipe['sha256']
        selected = 'DFF-ALT' if choose(pf['summaries']['DFF'], pf['summaries']['DFF-ALT']) == 'reflection_v2' else 'DFF'
        assert selected == pf['selected_branch']
        assert pf['selected_final_metrics'] == branches[selected]['result']['final_metrics']
        for key in ['attempts', 'returns', 'exceptions', 'wall_seconds', 'llm_calls']:
            assert pf['full_two_branch_charged_costs'][key] == sum(b['actual_controller_costs'][key] for b in branches.values())
        d, alt = (branches[x]['result']['final_metrics'] for x in ['DFF', 'DFF-ALT'])
        assert d['uv_count'] == original['DFF_UV'] and d['ov_count'] == original['DFF_OV']
        m = pf['selected_final_metrics']
        row = dict(original)
        row.update(DFF_ALT_UV=alt['uv_count'], DFF_ALT_OV=alt['ov_count'],
                   numerical_DSE_selected=selected, numerical_DSE_UV=m['uv_count'], numerical_DSE_OV=m['ov_count'],
                   HGVF_minus_DSE_UV=original['HGVF_UV']-m['uv_count'], HGVF_minus_DSE_OV=original['HGVF_OV']-m['ov_count'],
                   HGSE_minus_DSE_UV=original['HGSE_UV']-m['uv_count'], HGSE_minus_DSE_OV=original['HGSE_OV']-m['ov_count'],
                   DSE_whole_band=m['uv_count']==0 and m['ov_count']==0)
        rows.append(row)
        checks.append({'case_id':cid,'scenario_sha256':recipe['sha256'], 'complete_old_and_new_DFF_result_exact':True,
                       'exact_DFF_committed_actions':len(recent['executed_actions']), 'initial_metric_dictionary_exact':True,
                       'original_selector_recomputed':selected, 'historical_ALT_native_ppci_byte_identity':'UNKNOWN_NOT_STORED_IN_THIS_OLD_RECORD'})
        costs.append({'case_id':cid,'full_DSE_two_branch_controller':pf['full_two_branch_charged_costs'],
                      'individual_branches':{arm:{'controller':b['actual_controller_costs'],
                       'separately_paid_committed_replay':b['independent_committed_state_physical_replay']} for arm,b in branches.items()}})
    assert len(rows)==4 and [x['case_id'] for x in rows] == current['protocol']['case_order']
    O.mkdir()
    write('owner.claim', {'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha('work/reconcile_saved_dse_original118_20261028.py')})
    limits = [
      'This is a retrospective source/recipe/complete-DFF-output join over all four previously fixed inspected roots, not unused confirmation or a new prospective success gate.',
      'Historical ALT has independently replayed initial and committed-state metrics. Its old record does not certify every candidate query full field, cold runtime, KCL or exact native solver-input bytes to the newer audit standard.',
      'Strict UV below 0.95 and OV above 1.05 are unchanged. Native verifier upper guard remains 1.06. No zero-UV case or whole-band restoration in these four endpoints.',
      'The LLM branch includes numerical normalization, guarded selection, guided and fallback search. Offline HG-SE selects DFF or HG-VF and pays both; numerical D-SE selects DFF or DFF-ALT and pays both.',
      'Raw costs remain in distinct historical source blocks. Shared paid receipts, setup, training, failed stages and missing old timing are not free; no equal-cost or deployment-speed claim.',
      'No inference, physics, optimizer, derivative, replay or old-reader call was made. No general external-method or causal LLM superiority follows.'
    ]
    comparison = {'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'status':'ALL4_SAVED_SOURCE_RECIPE_AND_COMPLETE_DFF_RESULT_JOIN', 'rows':rows,'identity_checks':checks,
       'seven_shared_original_source_hashes_exact':source_equal,
       'totals':{k:sum(row[k] for row in rows) for k in ['initial_UV','DFF_UV','DFF_OV','DFF_ALT_UV','DFF_ALT_OV','numerical_DSE_UV','numerical_DSE_OV','HGVF_UV','HGVF_OV','HGSE_UV','HGSE_OV']},
       'HGVF_vs_DSE_UV':{'wins':sum(x['HGVF_minus_DSE_UV']<0 for x in rows),'ties':sum(x['HGVF_minus_DSE_UV']==0 for x in rows),'losses':sum(x['HGVF_minus_DSE_UV']>0 for x in rows)},
       'HGSE_vs_DSE_UV':{'wins':sum(x['HGSE_minus_DSE_UV']<0 for x in rows),'ties':sum(x['HGSE_minus_DSE_UV']==0 for x in rows),'losses':sum(x['HGSE_minus_DSE_UV']>0 for x in rows)},
       'limitations':limits,'new_scientific_calls':0,'all_six_final_goals':'OPEN'}
    write('Comparison.json',comparison)
    write('Full_Cost_Source_Blocks.json',{'historical_DSE_all4':costs,'current_original_comparison':currentcosts,'accounting_note':limits[4]})
    write('Input_And_Source_Bindings.json',evidence)
    with (O/'Comparison.csv').open('x',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    text=['# Saved D-SE and original Reflection-v4 comparison','',
      'All four current DFF result objects exactly match the earlier DFF records, including every action and log. Scenario hashes and shared source hashes match. The existing DFF-ALT branch is reused with its original committed-state audit; no science was repeated.','',
      '| Severe root | Initial UV | DFF UV/OV | DFF-ALT UV/OV | Numerical D-SE UV/OV | HG-VF UV/OV | Offline HG-SE UV/OV |',
      '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for x in rows:text.append(f"| {x['case_id']} | {x['initial_UV']} | {x['DFF_UV']}/{x['DFF_OV']} | {x['DFF_ALT_UV']}/{x['DFF_ALT_OV']} | {x['numerical_DSE_UV']}/{x['numerical_DSE_OV']} | {x['HGVF_UV']}/{x['HGVF_OV']} | {x['HGSE_UV']}/{x['HGSE_OV']} |")
    text += ['', 'HG-VF has 26 residual UV versus numerical D-SE 35: three UV wins and one loss. Offline HG-SE has 20 residual UV: three wins and one tie. Both language-containing systems have one case with more strict OV than numerical D-SE. These are descriptive development findings; they do not pass a no-loss/no-extra-OV claim.', '']
    text += ['- '+s for s in limits]
    (O/'Results.md').write_text('\n'.join(text)+'\n','utf-8')
    write('Closed_Manifest.json',{'members':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'status':comparison['status'],'totals':comparison['totals']}))

if __name__=='__main__':main()
