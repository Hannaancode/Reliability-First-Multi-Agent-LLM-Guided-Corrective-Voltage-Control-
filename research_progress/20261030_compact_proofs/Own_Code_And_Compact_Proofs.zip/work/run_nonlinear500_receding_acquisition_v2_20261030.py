"""Prospective source-ordered numerical acquisition, never a new PF campaign.

No entry until the separate frozen protocol, independent source gates and exact
supervisor ACK exist. All500 identities retained; unknown frontiers are not wins.
"""
from pathlib import Path
from datetime import datetime,timezone
import json,os,sys,time,hashlib,random,traceback

R=Path(__file__).resolve().parents[1]
P=R/'outputs/nonlinear500_receding_acquisition_v2_preparation_20261030'
O=R/'outputs/nonlinear500_receding_acquisition_v2_execution_20261030'
REQUIRED_READINESS={'engine_repair','math_bank','current_state','acquisition_engine','independent_reader','owner_wrapper','all500_input_binding'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,value):
 with Path(p).open('x',encoding='utf-8',newline='\n') as f:
  json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def ref(p):return dict(path=Path(p).relative_to(R).as_posix(),sha256=sha(p))
def windows_arguments(command):
 import ctypes
 from ctypes import wintypes
 shell=ctypes.WinDLL('shell32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 shell.CommandLineToArgvW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_int)]
 shell.CommandLineToArgvW.restype=ctypes.POINTER(wintypes.LPWSTR)
 kernel.LocalFree.argtypes=[wintypes.HLOCAL];kernel.LocalFree.restype=wintypes.HLOCAL
 count=ctypes.c_int();argv=shell.CommandLineToArgvW(command,ctypes.byref(count))
 if not argv:raise OSError(ctypes.get_last_error(),'Cannot parse supervisor command')
 try:return [argv[i] for i in range(count.value)]
 finally:kernel.LocalFree(ctypes.cast(argv,wintypes.HLOCAL))

def budgeted_owner_type(base_type):
 class BudgetedOwner(base_type):
  """One scan per boundary, cheap metadata debits between scans; no callbacks."""
  def __init__(self,*args):
   super().__init__(*args);self.budget_seq=0;self.measured_used=0;self.metadata_debits=0;self.mechanical_mode=False
   self.budget_out=O/'preservation_budget';self.budget_out.mkdir(exist_ok=False)
   self.closure_reserve=128*1024**2
  def check(self,cursor=None):
   if getattr(self,'mechanical_mode',False):raise RuntimeError('Science permanently closed for this owner')
   return super().check(cursor)
  def _scan(self,context_key=None,checkpoint_ref=None,reserve=0):
   self.check();t=time.monotonic();files=[p for p in O.rglob('*') if p.is_file()]
   claims=R/'outputs/nonlinear13_math_identity_claims_20261030'
   if claims.exists():files.extend(p for p in claims.iterdir() if p.is_file())
   used=sum(p.stat().st_size for p in files);self.measured_used=used;self.metadata_debits=0
   numeric={'preservation_budget_scans':1,'preservation_files_inspected':len(files),'preservation_scan_seconds':time.monotonic()-t}
   accepted=used+reserve+self.closure_reserve<=self.protocol['binary_byte_cap']
   evidence=dict(context_key=context_key,checkpoint_ref=checkpoint_ref,owner_protocol_ref=self.protocol_ref,
    numeric_cost=numeric,observed_bytes=used,reserved_new_bytes=reserve,mechanical_closure_reserve=self.closure_reserve,
    original_binary_byte_cap=self.protocol['binary_byte_cap'],original_deadline_monotonic=self.deadline,
    scope='Owner output plus all global numerical claims conservatively counted; not new scientific calls',accepted=accepted)
   path=self.budget_out/f'{self.budget_seq:06d}.json';self.budget_seq+=1;put(path,evidence)
   self.metadata_debits+=path.stat().st_size
   if not accepted:raise TimeoutError('Original preservation allowance insufficient; no extension')
   return {'numeric_cost':numeric,'evidence_ref':ref(path),'reservation_ref':ref(path)}
  def reserve_new_math(self,context_key,preproposal_checkpoint_ref):
   return self._scan(context_key,preproposal_checkpoint_ref,self.protocol['per_proposal_journal_byte_cap']+64*1024**2)
  def preservation_budget_check(self):return self._scan()
  def admit_metadata_write(self,byte_count):
   if self.mechanical_mode:raise RuntimeError('Ordinary metadata path disabled after mechanical closure')
   if type(byte_count) is not int or byte_count<0:raise ValueError('Invalid metadata debit')
   if self.measured_used+self.metadata_debits+byte_count+self.closure_reserve>self.protocol['binary_byte_cap']:
    raise TimeoutError('Original metadata preservation allowance exhausted')
   self.metadata_debits+=byte_count
  def admit_mechanical_write(self,byte_count):
   from nonlinear13_receding_policy_engine_v2_20261030 import clock_domain
   assert type(byte_count) is int and byte_count>=0
   assert self.ack['actual_pid']==os.getpid() and self.ack['actual_parent_pid']==os.getppid()
   assert clock_domain()==self.protocol['clock_domain']
   assert time.monotonic()<=self.deadline+300,'Original mechanical closure allowance exhausted'
   if not self.mechanical_mode:
    for rel,digest in self.protocol['sources'].items():assert sha(R/rel)==digest,'Source changed during owner'
    self.measured_used=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
    claims=R/'outputs/nonlinear13_math_identity_claims_20261030'
    if claims.exists():self.measured_used+=sum(p.stat().st_size for p in claims.iterdir() if p.is_file())
    self.metadata_debits=0;self.mechanical_mode=True
   if self.measured_used+self.metadata_debits+byte_count>self.protocol['binary_byte_cap']:
    raise TimeoutError('Original total preservation cap exhausted during mechanical closure')
   self.metadata_debits+=byte_count
 return BudgetedOwner
def main():
 began=time.monotonic();base=json.loads((P/'Protocol.json').read_text(encoding='utf-8'))
 assert base['status']=='FROZEN_NEW_NUMERICAL_ACQUISITION_OVER_PAID_PHYSICS'
 assert base['science_seconds']==7200 and base['binary_byte_cap']==8*1024**3
 assert base['new_PF_entry_enabled'] is False and base['numerical_acquisition_authorized'] is True
 assert base['cases']==list(range(500)) and base['horizon']==100
 assert {row['key'] for row in base['independent_readiness']}==REQUIRED_READINESS
 assert len(base['independent_readiness'])==len(REQUIRED_READINESS)
 for rel,digest in base['sources'].items():assert sha(R/rel)==digest,rel
 for row in base['independent_readiness']:
  assert sha(R/row['path'])==row['sha256'];e=json.loads((R/row['path']).read_text(encoding='utf-8'))
  assert e['status']==row['required_status'] and e['status'].startswith('PASS')
 from nonlinear500_isolated_owner_runtime_20261030 import admit_isolated_runtime
 runtime_admission=admit_isolated_runtime(R,base)
 O.mkdir(exist_ok=False)
 from nonlinear13_receding_policy_engine_v2_20261030 import clock_domain
 protocol={**base,'clock_domain':clock_domain(),'absolute_deadline_monotonic':began+base['science_seconds'],
  'original_deadline_monotonic':began+base['science_seconds'],
  'owner_started_monotonic':began,'frozen_preparation_protocol':ref(P/'Protocol.json'),
  'isolated_owner_runtime_admission':runtime_admission}
 put(O/'Runtime_Protocol.json',protocol);protocol_ref=ref(O/'Runtime_Protocol.json')
 put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),
  actual_argv=sys.argv,protocol_ref=protocol_ref,owner_started_monotonic=began,
  original_deadline_monotonic=protocol['absolute_deadline_monotonic'],clock_domain=protocol['clock_domain'],at_utc=datetime.now(timezone.utc).isoformat()))
 while not (O/'Launcher_ACK.json').exists():
  if time.monotonic()-began>60:raise TimeoutError('No exact supervisor ACK; zero scientific entry')
  time.sleep(.1)
 launcher=json.loads((O/'Launcher_ACK.json').read_text());import psutil
 actual=psutil.Process(os.getpid());command=actual.cmdline()
 assert launcher['actual_pid']==os.getpid() and launcher['actual_parent_pid']==os.getppid()==actual.ppid()
 assert launcher['fresh_exact_source_PID_parent_command'] is True and command[-len(sys.argv):]==sys.argv
 assert windows_arguments(launcher['actual_command'])==command,'Supervisor command does not bind actual argv'
 ack={**launcher,'protocol_sha256':protocol_ref['sha256'],'campaign_id':protocol['campaign_id'],
  'actual_argv':sys.argv,'clock_domain':protocol['clock_domain'],'owner_started_monotonic':began,
  'absolute_deadline_monotonic':protocol['absolute_deadline_monotonic'],
  'original_deadline_monotonic':protocol['original_deadline_monotonic'],
  'numerical_acquisition_authorized':True,'frozen_preparation_protocol':ref(P/'Protocol.json')}
 put(O/'Bound_Owner_ACK.json',ack)
 from nonlinear13_receding_acquisition_engine_20261030 import AcquisitionOwnerGate,SourceOrderedAcquisitionEngine
 from candidate_process_evidence_utils import frozen_checks
 import numpy as np
 random.seed(base['rng_seed']);np.random.seed(base['rng_seed'])
 owner=budgeted_owner_type(AcquisitionOwnerGate)(R,protocol_ref,ref(O/'Bound_Owner_ACK.json'))
 initial_budget=owner.preservation_budget_check()
 before=frozen_checks();put(O/'Frozen_Before.json',before)
 assert before['all_passed'] is True and len(before['checks'])==9 and all(before['checks'].values()),'Frozen originals fail before science'
 engine=None;result=None;failure=None
 try:
  engine=SourceOrderedAcquisitionEngine(R,O/'policy',owner,enable_numerical_entry=True)
  result=engine.run_acquisition()
 except BaseException as exc:
  failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc())
 finally:
  if engine is not None:
   try:engine.journal.close()
   except BaseException as exc:
    failure=failure or dict(type=type(exc).__name__,message=str(exc),scope='Journal closure failure')
 # Mechanical preservation only after the original scientific boundary.
 def closure_put(path,value):
  raw=(json.dumps(value,indent=2,allow_nan=False)+'\n').encode('utf-8')
  owner.admit_mechanical_write(len(raw))
  with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 if failure is not None:closure_put(O/'Failure.json',failure)
 try:after=frozen_checks()
 except BaseException as exc:
  after=dict(all_passed=False,checks={},failure=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
  failure=failure or dict(type=type(exc).__name__,message=str(exc),scope='Frozen-after verification failure')
 closure_put(O/'Frozen_After.json',after)
 frozen_pass=bool(after['all_passed'] is True and before['checks']==after['checks'] and all(after['checks'].values()))
 policy_cases=[] if result is None else result.get('cases',[])
 closure_put(O/'Result.json',dict(status='CLOSED_ACQUISITION_ACCOUNTING' if result is not None and frozen_pass and failure is None else 'TERMINAL_PARTIAL_ACQUISITION',
  at_utc=datetime.now(timezone.utc).isoformat(),failure=failure,workflow_seconds=time.monotonic()-began,
  workflow_scope='Before final manifest hashing; exact supervisor End_ACK retains complete process/setup/preservation time separately.',
  owner_initial_preservation_budget=initial_budget,
  original_science_seconds=base['science_seconds'],actual_protocol_ref=protocol_ref,
  policy_result=None if not (O/'policy/Result.json').exists() else ref(O/'policy/Result.json'),
  reported_case_rows=len(policy_cases),new_PF_calls=0,new_model_GPU_training_calls=0,
  whole_policy_performance='UNKNOWN unless every registered trajectory independently complete; acquisition accounting is not restoration.',
  frozen_originals_preserved=frozen_pass,frozen_before=ref(O/'Frozen_Before.json'),frozen_after=ref(O/'Frozen_After.json')))
 files=[dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in O.rglob('*') if p.is_file()]
 closure_put(O/'Closed_Manifest.json',dict(files=files,actual_bytes_before_manifest=sum(x['bytes'] for x in files),
  binary_byte_cap=base['binary_byte_cap'],no_retry=True))
 actual_bytes=sum(p.stat().st_size for p in O.rglob('*') if p.is_file())
 assert actual_bytes<=base['binary_byte_cap'],'Actual final owner bytes exceed original bound'
 print('NEW_NUMERICAL_ACQUISITION_TERMINAL_NO_NEW_PF')
if __name__=='__main__':main()
