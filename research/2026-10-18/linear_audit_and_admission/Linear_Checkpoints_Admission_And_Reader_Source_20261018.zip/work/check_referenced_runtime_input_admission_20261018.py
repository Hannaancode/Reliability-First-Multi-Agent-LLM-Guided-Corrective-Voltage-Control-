"""ALL4 actual source endpoints and fail-closed input/schema tests, zero science."""
import copy,hashlib,json,os,time
from pathlib import Path
import pandapower as pp
from full_receding_paid_campaign_20261015 import read,put
from referenced_runtime_input_admission_v1_20261018 import admit_input
from joint_reallocation_opportunity_core_v1 import load_endpoint
from paid_receding_referenced_commit_v2_20261018 import initialize
from shared_original_serving_action_domain_v1 import build_current_domain
from frozen_physics_loader import load_stack
R=Path(__file__).resolve().parents[1];B=R/'outputs/referenced_runtime_input_admission_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'ALL4_FIXED_SOURCE_INPUT_ADMISSION_SOFTWARE_NOT_PERFORMANCE','source_sha256':sha(R/'work/referenced_runtime_input_admission_v1_20261018.py'),'test_sha256':sha(Path(__file__)),
        'selection':'Every original inspected endpoint, both fixed method names; no outcome-based subset.','bound_seconds':120,'new_scientific_calls':0})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    calls=[]
    def forbidden(*a,**k):calls.append(True);raise AssertionError('Input admission cannot solve')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,forbidden)
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    entries=read(R/'outputs/full_receding_paid_campaign_20261015/Protocol.json')['endpoints'];positive=[];checks={}
    for entry in entries:
        net,old,_=load_endpoint(entry);domain=build_current_domain(net,old,runner=runner,zones=zones)
        cursor=initialize(net,domain['expanded_cursor_for_separately_fixed_future_protocol'])
        for mode in ['immediate1_followup16','breadth4_followup4']:
            a=admit_input(net,cursor,world=entry['world'],method=mode,decision=0,journal_path=B/'UNEXECUTED/scientific.jsonl',runner=runner,zones=zones)
            positive.append({k:v for k,v in a.items() if k!='domain'})
        if len(positive)==2:first=(net,cursor,entry['world'])
    net,cursor,world=first
    def reject(label,*,n=None,c=None,**kw):
        args={'world':world,'method':'immediate1_followup16','decision':0,'journal_path':B/'UNEXECUTED/scientific.jsonl','runner':runner,'zones':zones};args.update(kw)
        try:admit_input(n if n is not None else net,c if c is not None else cursor,**args)
        except (AssertionError,ValueError):checks[label]=True
        else:raise AssertionError('Unsupported input admitted: '+label)
    reject('unsupported_world_unicode',world='foreign_\u2603')
    reject('unbounded_world',world='x'*129)
    reject('unknown_method',method='outcome_selected_width')
    reject('boolean_decision',decision=True)
    reject('over_original_decisions',decision=26)
    reject('outside_workspace_journal',journal_path=R.parent.parent/'external.jsonl')
    reject('unbounded_journal_reference',journal_path=R/('x'*241)/'scientific.jsonl')
    bad=copy.deepcopy(cursor);bad['original_device_operation_budget']=26;reject('changed_operation_budget',c=bad)
    bad=copy.deepcopy(cursor);bad['owned_bank_rows']=bad['owned_bank_rows']*26;reject('excess_owned_rows',c=bad)
    bad=copy.deepcopy(cursor);bad['withdrawals_refund_positive_addition_cap']=True;reject('cap_refund',c=bad)
    bad=copy.deepcopy(cursor);bad['remaining_original_device_operation_slots']+=1;reject('operation_credit',c=bad)
    badnet=copy.deepcopy(net);badnet['res_bus']=badnet.res_bus.iloc[:-1];reject('missing_bus_result',n=badnet)
    assert len(positive)==8 and all(checks.values()) and not calls
    put(B/'Results.json',{'status':'PASS_ALL4_SOURCE_INPUTS_BOTH_FIXED_METHODS_AND_FAILCLOSED_SCHEMA','all8_admissions':positive,'rejection_checks':checks,
        'no_scientific_permission_or_live_owner_created':True,'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Current4 root inputs only; future replanned states must be readmitted before queries. Independent physical policy/cache/reader/source/ownership/budget gates still required. Not all141 cases or unused confirmation.'})
    print(json.dumps({'input_admission':'PASS','actual_inputs':4,'method_bindings':8,'negative_checks':len(checks),'science':0}))
if __name__=='__main__':main()
