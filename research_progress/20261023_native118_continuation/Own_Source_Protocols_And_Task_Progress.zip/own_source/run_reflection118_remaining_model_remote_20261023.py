"""One immutable original private LoRA; causal requests from native controller.

No prompts, actions or feedback are synthesized here. Both actual first-prompt
replicas are charged; subsequent requests remain source chronological.
"""
import os
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
os.environ['HF_HUB_OFFLINE'] = '1'
import functools, gc, hashlib, json, time, traceback
from pathlib import Path
from public_size_u61_preservation import atomic_json, journal, Publisher, file_hash

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/public_size_science'
O.mkdir(exist_ok=False); began = time.monotonic()
p = json.loads((R / 'prep/protocol.json').read_text())
env = json.loads((R / 'outputs/public_size_environment.json').read_text())
Q = R / 'outputs/public_size_requests'; Q.mkdir(exist_ok=True)
atomic_json(O / 'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(),
    'source_sha256': file_hash(__file__), 'protocol_sha256': file_hash(R/'prep/protocol.json')})
cost = {'model_load_attempts': 0, 'model_load_returns': 0, 'generation_attempts': 0, 'generation_returns': 0,
        'pretrained_forward_attempts': 0, 'pretrained_forward_returns': 0, 'generated_tokens': 0,
        'PF_optimizer_backward_training_calls': 0}
previous = '0'*64


def event(kind, **data):
    global previous
    assert time.monotonic()-began < p['science_process_seconds']
    row = {'kind': kind, 'elapsed_seconds': time.monotonic()-began, 'previous': previous, **data}
    h = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    journal(O/'events.jsonl', {'event': row, 'sha256': h}); previous = h


def progress(stage): atomic_json(O/'progress.json', {'stage':stage,'costs':cost,'updated_unix':time.time()})


publisher = Publisher(O, R/'outputs/public_size_transfer', wait_seconds=180)
try:
    import numpy as np, torch
    from transformers import AutoTokenizer
    from candidate_process_pretrained_loader_native13_v2_20261020 import load_isolated_body, preservation_inventory
    from original_reflection_serving_pure_20261022 import definitions
    from original_reflection_tokenizer_tensor_view_v2_20261022 import TensorTemplateView
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0) == 'Tesla T4'
    adapter=R/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for n,h in p['private_adapter_tokenizer_unchanged'].items(): assert file_hash(adapter/n)==h
    for n,h in p['original_serving_sources'].items(): assert file_hash(R/n)==h
    tokenizer=AutoTokenizer.from_pretrained(str(adapter),local_files_only=True,trust_remote_code=False)
    original_generate_response=definitions('base', {'torch':torch})['generate_response']
    model=core=original_forward=original_generate=before=None

    def load(label):
        global model,core,original_forward,original_generate,before
        torch.manual_seed(p['seed']);torch.cuda.manual_seed_all(p['seed']);np.random.seed(p['seed'])
        cost['model_load_attempts']+=1;event('model_load_attempt',label=label); tick=time.perf_counter()
        model,proof=load_isolated_body(Path(env['base_snapshot']),adapter,train_body=False)
        assert not any(x.requires_grad for x in model.parameters())
        flags={n:m.disable_adapters for n,m in model.named_modules() if isinstance(getattr(m,'disable_adapters',None),bool)}
        assert flags and not any(flags.values())
        atomic_json(O/f'{label}_Actual_Enabled_Adapter_State.json',flags)
        cost['model_load_returns']+=1;event('model_load_return',label=label,seconds=time.perf_counter()-tick)
        atomic_json(O/f'{label}_Loader_Proof.json',proof)
        before=preservation_inventory(model);atomic_json(O/f'{label}_Immutable_Before.json',before)
        core=model.get_base_model();original_forward=core.forward;original_generate=model.generate
        @functools.wraps(original_forward)
        def forward(*a,**kw):
            cost['pretrained_forward_attempts']+=1;tick=time.perf_counter();out=original_forward(*a,**kw)
            assert torch.isfinite(out.logits).all();cost['pretrained_forward_returns']+=1
            event('pretrained_forward_return',number=cost['pretrained_forward_returns'],seconds=time.perf_counter()-tick)
            return out
        core.forward=forward

    def unload(label):
        global model,core,original_forward,original_generate,before
        after=preservation_inventory(model);assert before==after
        atomic_json(O/f'{label}_Immutable_After.json',after)
        core.forward=original_forward;model.generate=original_generate
        model=core=original_forward=original_generate=before=None;gc.collect();torch.cuda.empty_cache()

    def generate(req, replica):
        messages=req['messages'];encoded=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True)
        ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
        assert len(ids)>0 and len(ids)+384<=4096,'Original full causal context exceeds fixed limit; preserve, never truncate.'
        receipt={'number':req['number'],'request':req,'replica':replica,'input_token_ids':ids}
        @functools.wraps(original_generate)
        def generated(*a,**kw):
            assert not a and kw['max_new_tokens']==384 and not kw['do_sample'] and kw['use_cache']
            assert kw['input_ids'].tolist()==[ids] and bool(kw['attention_mask'].all())
            cost['generation_attempts']+=1;event('generation_attempt',number=req['number'],replica=replica,input_tokens=len(ids))
            tick=time.perf_counter();fc=cost['pretrained_forward_returns']
            with torch.inference_mode():sequence=original_generate(*a,**kw)
            torch.cuda.synchronize();new=sequence[0,len(ids):].detach().cpu().tolist()
            assert 0<len(new)<=384 and cost['pretrained_forward_returns']-fc==len(new)
            assert sequence[0,:len(ids)].cpu().tolist()==ids
            cost['generation_returns']+=1;cost['generated_tokens']+=len(new)
            receipt.update(output_token_ids=new,generation_seconds=time.perf_counter()-tick,
                actual_forward_returns=len(new),peak_allocated_bytes=torch.cuda.max_memory_allocated(),peak_reserved_bytes=torch.cuda.max_memory_reserved())
            assert receipt['peak_allocated_bytes']<=12*1024**3
            event('generation_return',number=req['number'],replica=replica,output_tokens=len(new),seconds=receipt['generation_seconds'])
            return sequence
        model.generate=generated
        try:receipt['raw_text']=original_generate_response(model,TensorTemplateView(tokenizer),messages)
        finally:model.generate=original_generate
        return receipt

    event('source_loader_preconditions_pass');progress('loading_primary');load('primary')
    event('primary_ready');publisher.publish('actual_original_model_loaded')
    number=0;first=None
    while time.monotonic()-began<p['science_process_seconds']-60:
        stop=Q/'STOP.json';path=Q/f'request_{number:05d}.json'
        if stop.exists():break
        if not path.exists():time.sleep(.25);continue
        req=json.loads(path.read_text());assert req['number']==number and set(req)=={'number','active','messages'}
        answer=generate(req,'primary' if number==0 else 'serving')
        if number==0:
            atomic_json(O/'First_Primary_Generation.json',answer);unload('primary');load('cold_serving')
            cold=generate(req,'cold');assert answer['input_token_ids']==cold['input_token_ids']
            assert answer['output_token_ids']==cold['output_token_ids'] and answer['raw_text']==cold['raw_text']
            atomic_json(O/'First_Cold_Generation.json',cold)
            atomic_json(O/'Actual_Cold_Model_Gate.json',{'status':'PASS_COMPLETE_IMMUTABLE_FRESH_LOADER_FIRST_CONTEXT_TOKEN_SEQUENCE','new_actual_cold_generations':1})
        atomic_json(O/f'response_{number:05d}.json',answer);progress('preserving_actual_causal_response')
        publisher.publish(f'causal_request_{number:05d}');number+=1
    else:raise TimeoutError('Fixed original model service bound; no extension')
    assert (Q/'STOP.json').exists();stop=json.loads((Q/'STOP.json').read_text())
    unload('cold_serving' if number else 'primary')
    atomic_json(O/'Results.json',{'status':'MODEL_SERVICE_TERMINAL_COMPLETE_OR_LOCAL_PARTIAL','served_requests':number,
        'local_controller_stop':stop,'costs':cost,'workflow_seconds':time.monotonic()-began,
        'physical_or_external_method_claim':False})
    event('closed_results');progress('closed_preserving');publisher.publish('closed_original_model_service')
except BaseException as e:
    atomic_json(O/'Failure.json',{'type':type(e).__name__,'failure':str(e),'traceback':traceback.format_exc(),'costs':cost,'workflow_seconds':time.monotonic()-began})
    progress('failed_partial_preserved');raise
