"""Fixed500epoch numeric FIT control, finalonly; blocked unless all64teacher+input audits complete."""
import os,json,hashlib,time,random,math
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_same_information_MLP_FIT_20261020';INPUT=ROOT/'outputs/native_fit_training_inputs_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    assert json.loads((INPUT/'Readiness.json').read_text())['status'].startswith('PASS_ALL_COMPLETE_AUDITED_NATIVE_FIT');OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});started=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-started<60;time.sleep(.1)
    import candidate_process_runtime
    import torch,numpy as np
    from native_same_information_MLP_20261020 import NativeMLP
    from native_joint_checkpoint_contract_20261020 import assert_same
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True);torch.manual_seed(20261020);np.random.seed(20261020);random.seed(20261020)
    f=INPUT/'Same_Information_Numeric_FIT_And_Current_Loss_Auxiliary.npz';z=np.load(f);N=len(z['X']);w=z['weight'];mu=np.average(z['X'],axis=0,weights=w);sd=np.sqrt(np.average((z['X']-mu)**2,axis=0,weights=w));sd=np.maximum(sd,1e-8);X=torch.tensor((z['X']-mu)/sd,dtype=torch.float32);target=torch.tensor(z['target'],dtype=torch.float32);weights=torch.tensor(w,dtype=torch.float32);S=torch.tensor(z['S'],dtype=torch.float32);vm=torch.tensor(z['vm'],dtype=torch.float32);assert X.shape==(N,435) and torch.isfinite(X).all()
    model=NativeMLP();opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01);cost={'forward_attempts':0,'forward_returns':0,'backward_attempts':0,'backward_returns':0,'optimizer_attempts':0,'optimizer_returns':0,'pretrained_LLM_PF_GPU_calls':0};step=0;events=(OUT/'events.jsonl').open('x',encoding='utf-8');previous='0'*64;contract={'input_sha256':sha(f),'source_sha256':sha(__file__),'architecture_sha256':sha(ROOT/'work/native_same_information_MLP_20261020.py'),'all500epochs_finalonly':True,'seed':20261020,'normalization':'FITonlyworldweighted','numeric_feature_count':435}
    def event(kind,**data):
        nonlocal previous
        row={'kind':kind,'elapsed_seconds':time.monotonic()-started,'previous':previous,**data};h=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest();events.write(json.dumps({'event':row,'sha256':h})+'\n');events.flush();os.fsync(events.fileno());previous=h
    def forward(x,phase):
        cost['forward_attempts']+=1;u=model(x);assert torch.isfinite(u).all() and (u.abs()<=torch.tensor(.3)).all();cost['forward_returns']+=1;return u
    def snapshot(epoch,next_batch,path):
        torch.save({'model':model.state_dict(),'optimizer':opt.state_dict(),'normalization':{'mean':mu,'std':sd},'RNG':{'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state()},'cursor':{'completed_updates':step,'epoch':epoch,'next_batch':next_batch},'contract':contract,'actual_costs':cost.copy()},path)
    snapshot(0,0,OUT/'initial0_complete.pt');epoch_results=[]
    for epoch in range(1,501):
        order=torch.randperm(N);running=0.
        for batch_index,ids in enumerate(order.split(32)):
            assert time.monotonic()-started<900,'FixedMLPbound;noextension/retry/checkpointselection';opt.zero_grad(set_to_none=True);u=forward(X[ids],'FIT');pred=vm[ids]-torch.einsum('nij,nj->ni',S[ids],u);loss=((((u-target[ids])/.3).square().mean(1)+(torch.relu(.95-pred).square()+torch.relu(pred-1.05).square()).mean(1))*weights[ids]).mean();assert torch.isfinite(loss);cost['backward_attempts']+=1;loss.backward();cost['backward_returns']+=1;assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters());cost['optimizer_attempts']+=1;opt.step();cost['optimizer_returns']+=1;step+=1;running+=float(loss.detach())*len(ids);event('optimizer_return',epoch=epoch,batch=batch_index,update=step,loss=float(loss.detach()),finite_gradient_tensors=6)
            if step%100==0:snapshot(epoch,batch_index+1,OUT/f'update_{step:06d}_complete.pt')
        epoch_results.append({'epoch':epoch,'FIT_loss_descriptive_not_selection':running/N})
    snapshot(500,math.ceil(N/32),OUT/'final500_complete.pt');model.eval()
    with torch.no_grad():reference=torch.cat([forward(x,'warm_final') for x in X.split(128)]).clone()
    saved=torch.load(OUT/'final500_complete.pt',weights_only=False);cold=NativeMLP();cold.load_state_dict(saved['model'],strict=True);cold_opt=torch.optim.AdamW(cold.parameters(),lr=.001,weight_decay=.01);cold_opt.load_state_dict(saved['optimizer'])
    for v in cold_opt.state.values():assert int(v['step'])==step and torch.isfinite(v['exp_avg']).all() and torch.isfinite(v['exp_avg_sq']).all()
    assert_same(cold_opt.state_dict(),saved['optimizer']);assert_same(cold.state_dict(),saved['model']);random.setstate(saved['RNG']['python']);np.random.set_state(saved['RNG']['numpy']);torch.set_rng_state(saved['RNG']['torch']);assert_same({'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state()},saved['RNG']);assert saved['cursor']=={'completed_updates':step,'epoch':500,'next_batch':math.ceil(N/32)} and saved['contract']==contract;assert np.array_equal(saved['normalization']['mean'],mu) and np.array_equal(saved['normalization']['std'],sd)
    model=cold;model.eval()
    with torch.no_grad():actual=torch.cat([forward(x,'cold_final') for x in X.split(128)])
    assert torch.equal(reference,actual);torch.save({'final_FIT_actions':reference,'targets':target},OUT/'Cold_Exact_FIT_Outputs.pt');put(OUT/'All_Epoch_Descriptive_FIT_Losses.json',epoch_results)
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_FIXED500_EPOCH_FINAL_ONLY_SAME_INFORMATION_MLP_FIT_NOT_HELD_PERFORMANCE','FIT_rows':N,'declared_FIT_worlds':64,'parameters':178179,'actual_costs':cost,'all6moment_steps':step,'all_final_FIT_actions_cold_exact':True,'native_float32_bounded3actions':True,'DEV_confirmation_physics_inference_calls':0,'workflow_seconds':time.monotonic()-started,'no_LLM_or_benchmark_superiority_claim':True,'contract':contract};put(OUT/'Results.json',result);event('closed',results_sha256=sha(OUT/'Results.json'));events.close();put(OUT/'Closed_Manifest.json',{'files':{p.relative_to(OUT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.rglob('*') if p.is_file()}});print(result['status'],step)
if __name__=='__main__':main()
