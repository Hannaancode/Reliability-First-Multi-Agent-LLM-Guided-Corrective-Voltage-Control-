Separate new-identity numerical measurement and existing audited outputs form a full declared union. Original lost output and any new partial/failure remain UNKNOWN. These are historical OPT saved-label rankings, not LLM value, nonlinear physical recovery, D-SE superiority, novelty or unused confirmation. No automatic learning follows.

{
  "K4": {
    "old_admittance_derivative": {
      "oracle_states": 176,
      "known_inclusions": 129,
      "unknown_inclusions": 1,
      "equal_world_lower": 0.6893379347924802,
      "equal_world_upper": 0.6943884398429853,
      "known_miss_states": 46,
      "known_miss_worlds": 20,
      "known_miss_families": [
        "DER_drop",
        "N1_tieline",
        "combined"
      ],
      "available_shortlist_counts": {
        "known_accepted": 553,
        "known_rejected": 195,
        "unknown_unmeasured": 208,
        "unavailable_slots": 0
      }
    },
    "candidate_admittance_derivative": {
      "oracle_states": 176,
      "known_inclusions": 97,
      "unknown_inclusions": 0,
      "equal_world_lower": 0.5704527795436886,
      "equal_world_upper": 0.5704527795436886,
      "known_miss_states": 79,
      "known_miss_worlds": 20,
      "known_miss_families": [
        "DER_drop",
        "N1_tieline",
        "combined"
      ],
      "available_shortlist_counts": {
        "known_accepted": 664,
        "known_rejected": 84,
        "unknown_unmeasured": 208,
        "unavailable_slots": 0
      }
    }
  },
  "new_audit": {
    "audited_at_utc": "2026-10-10T03:34:10.291662+00:00",
    "all_passed": true,
    "all77002_union_identities_retained": true,
    "new33736_scope_exactly_old_unexecuted": true,
    "no_old_forecast_replaced_or_repeated": true,
    "previous145861_equation_certificate_reused_with_bound_record_hashes": true,
    "new_equation_steps_independently_verified": 115988,
    "new_dense_reader_contexts": 102,
    "new_max_equation_residual": 1.2705864138595757e-11,
    "independent_strict_update_disagreements": [],
    "all_strict_updates_agreed": true,
    "new_model_PF_controller_optimizer_cloud_linear_solve_calls_by_reader": 0,
    "reader_seconds_before_seal": 187.13715759990737,
    "original_lost_output_still_UNKNOWN": true,
    "old_terminal_partial_unchanged": true,
    "no_held_metric_or_confirmation": true
  }
}
