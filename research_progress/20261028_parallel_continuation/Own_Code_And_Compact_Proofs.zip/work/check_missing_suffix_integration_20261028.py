"""Actual original-source provider admission, with no live model or PF provider."""
from original_missing_suffix_core_20261028 import *

class AtNewRequest(BaseException):pass

def main():
    out=R/'outputs/missing_suffix_integration_20261028';out.mkdir(exist_ok=False)
    began=time.monotonic();put(out/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)));wait_ack(out,began)
    np,pp,v2,runner,reflection=setup();results=[]
    def no_physics(*a,**k):raise AssertionError('New physics reached before first missing model request')
    for i in [1,3]:
        p=read(R/'outputs/reflection118_remaining_cases_v2_preparation_20261023'/f'case_{i:02d}'/'Frozen_Engineering_Protocol.json')
        binding=read(R/p['bindings'])[i];observed=[]
        def new_model(messages):
            observed.append(messages);raise AtNewRequest()
        suffix=OriginalMissingSuffix(i,reflection,new_model,no_physics)
        # Calling outside the bound original source cannot admit a missing response.
        denied=OriginalMissingSuffix(i,reflection,new_model,no_physics)
        denied.gi=denied.pending['model_cursor'];denied.pi=denied.pending['PF_cursor']
        try:denied.model(denied.pending['pending_messages'])
        except RuntimeError as e:assert str(e)=='Not executing the bound original controller'
        else:raise AssertionError('Unbound provider entered')
        assert not observed
        mutated=copy.deepcopy(suffix.pending);mutated['pending_messages']=[]
        try:checkpoint_equal(mutated,suffix.pending)
        except AssertionError:pass
        else:raise AssertionError('Changed pending request accepted')
        assert time.monotonic()-began<300
        random.seed(p['seed']);np.random.seed(p['seed'])
        base=pp.from_json(str(R/p['base_net']));zones=read(R/p['metadata'])['zones']
        try:run_original(v2,runner,reflection,read(R/binding['registration']['recipe']),base,zones,suffix.model,suffix.physics)
        except AtNewRequest:pass
        else:raise AssertionError('Expected missing boundary not reached')
        assert observed==[suffix.pending['pending_messages']]
        assert suffix.admitted and suffix.costs['new_model_provider_calls']==1 and suffix.costs['new_physics_provider_calls']==0
        results.append(dict(case_index=i,source_frame_request_RNG_exact=True,unbound_call_rejected=True,mutated_request_rejected=True,costs=suffix.costs,provider_is_stop_fixture_not_model=True,new_PF_model_calls=0))
    put(out/'Results.json',dict(status='PASS_ACTUAL_ORIGINAL_SOURCE_MISSING_SUFFIX_ADMISSION',cases=results,workflow_seconds=time.monotonic()-began,new_PF_model_calls=0))
    print(json.dumps(dict(status='PASS_ACTUAL_ORIGINAL_SOURCE_MISSING_SUFFIX_ADMISSION',cases=len(results))))

if __name__=='__main__':main()
