"""Three fixed own-profile case owners, no replacement or rotation."""
import subprocess
from reflection118_remaining_cases_v2_core_20261023 import *
TOP=R/'outputs/reflection118_remaining_cases_v2_preparation_20261023'
O=R/'outputs/reflection118_remaining_cases_v2_handoff_20261023'
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
 require_partition_closed()
 assert read(TOP/'Final_All3_Readiness.json')['passed']
 eligible=[1,2,3]; all_outcomes=[]
 for phase in ['Primary','Reader']:
  children=[]
  for index in eligible:
   path=TOP/f'case_{index:02d}'/(phase+'_Owner_Protocol.json')
   log=(O/f'{phase}_{index:02d}.log').open('x',encoding='utf-8')
   child=subprocess.Popen([sys.executable,'-X','utf8',str(R/'work/coordinate_single_owner_arguments_v2_20261022.py'),'--protocol',str(path.relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
   put(O/f'{phase}_{index:02d}_Launch.json',dict(pid=child.pid,parent=os.getpid(),protocol_sha256=sha(path)));children.append((index,child,log))
  outcomes=[]
  for index,child,log in children:
   code=child.wait(timeout=13800 if phase=='Primary' else 7800);log.close();outcomes.append(dict(case_index=index,exit_code=code));put(O/f'{phase}_{index:02d}_End.json',outcomes[-1])
  all_outcomes.extend(dict(phase=phase,**x) for x in outcomes)
  eligible=[x['case_index'] for x in outcomes if x['exit_code']==0]
  put(O/(phase+'_All_Outcomes.json'),dict(outcomes=outcomes,no_retries_or_fallback=True))
 put(O/'Completion.json',dict(status='ALL3_CASE_OWNERS_TERMINAL_SUCCESSFUL_HOSTS_AUDITED_PARTIALS_RETAINED',all_outcomes=all_outcomes,all6_final_goals='OPEN'))
if __name__=='__main__':main()
