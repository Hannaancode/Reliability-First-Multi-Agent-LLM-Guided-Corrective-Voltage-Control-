"""Continue the authorized current jobs through full evidence integration.

This is a bounded current-job supervisor, not a scheduled automation. It waits
for the already-running local AC process, resumes only a clean per-case time
limit, then makes one further GPU attempt after the CPU dependency completes.
No bank tuning, replacement assets, paid-plan changes, or cybersecurity.
"""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys,time
from checkpoint_io import read_json_ready
root=Path('outputs');status=root/'ordered_completion_status.json'
state={'stage':'waiting_for_active_AC_campaign','started_at_utc':datetime.now(timezone.utc).isoformat(),'central_retry_after_AC_attempted':False,'all_four_experiments_complete':False}
def save():
    state['updated_at_utc']=datetime.now(timezone.utc).isoformat();p=status.with_suffix('.tmp');p.write_text(json.dumps(state,indent=2));p.replace(status)
def run(name,python=None):
    with (root/('ordered_'+name.removesuffix('.py')+'.log')).open('a',encoding='utf-8') as log:
        p=subprocess.run([python or sys.executable,'work/'+name],stdout=log,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError('Ordered stage failed: '+name)
def refresh():
    run('summarize_ac_reference_bank.py');run('write_reviewer_closure.py')
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True);save();print('ORDERED_COMPLETION_SUPERVISOR_STARTED',flush=True)
started=time.monotonic();seen=-1
try:
    while time.monotonic()-started<86400:
        ac=read_json_ready(root/'ac_reference_campaign_status.json');count=ac.get('completed_count',0);state['AC_completed_count']=count
        if count!=seen:
            seen=count;refresh();save();print('ORDERED_AC_CHECKPOINT_COUNT',count,flush=True)
        if ac.get('status')=='complete':break
        if ac.get('status')=='time_limit_reached':
            state['stage']='resuming_AC_after_clean_per_case_time_limit';save();run('run_ac_reference_campaign.py');continue
        if ac.get('status') in ['paused_by_user','interrupted','waiting_on_campaign_recovery','dependency_wait_limit']:
            state.update(stage='AC_stopped_requires_recorded_blocker_resolution',AC_status=ac['status']);save();refresh();sys.exit(0)
        time.sleep(30)
    else:raise RuntimeError('Bounded current-job AC wait reached 24 hours; checkpoints preserved')
    assert len(list((root/'ac_reference_campaign/cases').glob('*.json')))==62
    state['stage']='auditing_complete_AC_campaign';save();run('verify_execution_preservation.py');refresh();run('compare_ac_reference.py');refresh();print('FULL_AC_REFERENCE_INTEGRATION_COMPLETE',flush=True)
    if '--observe-existing-central' in sys.argv:
        state['stage']='waiting_for_existing_isolated_central_campaign';save()
        gpu_wait_started=time.monotonic()
        while time.monotonic()-gpu_wait_started<43200:
            existing_gpu=read_json_ready(root/'next_gpu_stage_status.json')
            if existing_gpu.get('stage')=='complete' and existing_gpu.get('runtime_released'):break
            if existing_gpu.get('stage') in ['interrupted','central_stage_failed_or_incomplete','waiting_on_campaign_recovery','dependency_wait_limit']:
                state.update(stage='existing_central_stage_stopped',GPU_status=existing_gpu.get('stage'),GPU_failure_http_status=existing_gpu.get('setup_failure_http_status'));save();refresh();sys.exit(0)
            time.sleep(30)
        else:raise RuntimeError('Existing central campaign did not complete/release within bounded wait; no duplicate runtime allocated')
    elif not (root/'central_matched_summary.json').exists():
        state.update(stage='retrying_GPU_after_AC_dependency',central_retry_after_AC_attempted=True);save()
        run('check_adc_colab.py',str(Path('work/colab_access_env/Scripts/python.exe').resolve()))
        auth=read_json_ready(root/'local_auth_status.json');assert auth.get('adc_refresh_succeeded') and auth.get('assignments_http_status')==200,'Existing authentication/backend not available; no replacement token requested'
        run('continue_gpu_experiments.py',str(Path('work/colab_access_env/Scripts/python.exe').resolve()))
        gpu=read_json_ready(root/'next_gpu_stage_status.json')
        if gpu.get('stage')!='complete':
            state.update(stage='central_GPU_stage_blocked_or_incomplete',GPU_status=gpu.get('stage'),GPU_failure_http_status=gpu.get('setup_failure_http_status'));save();refresh();print('CENTRAL_STAGE_REMAINS_OPEN_CHECK_SAVED_BLOCKER',flush=True);sys.exit(0)
    state['stage']='final_central_physical_and_statistical_audit';save();run('audit_central_checkpoints.py');run('analyze_central_campaign.py');run('verify_execution_preservation.py');refresh()
    closure=read_json_ready(root/'reviewer_closure_status.json');assert closure['all_four_planned_reviewer_experiments_complete']
    state['stage']='exporting_verified_final_reproducibility_package';save();run('export_reviewer_package.py');refresh()
    assert read_json_ready(root/'reviewer_closure_status.json')['all_ten_steps_complete']
    state.update(stage='all_ten_steps_complete',all_four_experiments_complete=True,all_ten_steps_complete=True);save();print('ALL_TEN_STEPS_COMPLETE_WITH_VERIFIED_EXPERIMENTAL_EVIDENCE',flush=True)
except Exception as exc:
    state.update(stage='interrupted',failure_type=type(exc).__name__,failure_note=str(exc)[:300]);save();print('ORDERED_COMPLETION_INTERRUPTED',type(exc).__name__,flush=True);sys.exit(1)
