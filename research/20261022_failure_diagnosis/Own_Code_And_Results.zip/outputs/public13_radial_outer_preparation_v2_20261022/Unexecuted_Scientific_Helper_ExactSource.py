"""Necessary radial AC branch-flow outer polytope and exact rational separation.

This is an adverse-case feasibility diagnostic, never a replacement score or
control trajectory. No PF, policy, derivative, LU or nonlinear solver is used.
"""
import hashlib,json,os,pickle,time
from fractions import Fraction as F
from pathlib import Path
from datetime import datetime,timezone
import candidate_process_runtime
import numpy as np
import stable_ddpg_native_bridge_20261020
R=Path(__file__).resolve().parents[1]
P=R/'outputs/public13_radial_outer_preparation_v2_20261022'
PRIMARY=R/'outputs/public13_radial_outer_execution_20261022'
READER=R/'outputs/public13_radial_outer_independent_20261022'

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def f(v):return F.from_float(float(v))
def enc(v):return str(v.numerator)+'/'+str(v.denominator)

def source(root):
    assert sha(R/root['path'])==root['sha256']
    value=pickle.loads((R/root['path']).read_bytes());net=value['network'] if root['kind']=='ENV' else value
    pp=net._ppc;bus=pp['bus'];branch=pp['branch'];gen=pp['gen']
    assert len(bus)==13 and len(branch)==12 and np.array_equal(bus[:,0],np.arange(13)) and np.all(bus[:,4:6]==0)
    assert len(gen)==1 and int(gen[0,0])==0 and bus[0,1]==3 and np.all(bus[1:,1]==1)
    assert np.all(branch[:,10]==1) and np.all(branch[:,4]==0) and np.all(branch[:,8]==1) and np.all(branch[:,9]==0)
    assert np.all(branch[:,2]>0) and np.all(branch[:,3]>=0)
    assert float(net.ext_grid.vm_pu.iloc[0])==1. and np.array_equal(net.sgen.q_mvar.to_numpy()[:3],np.zeros(3))
    assert not np.any(net.load.p_mw.to_numpy()) and not np.any(net.load.q_mvar.to_numpy())
    control=net._pd2ppc_lookups['bus'][net.sgen.bus.to_numpy()[:3]].tolist();assert control==[2,7,9]
    neighbors={i:[] for i in range(13)}
    for row in branch:
        i,j=map(int,row[:2]);neighbors[i].append((j,f(row[2]),f(row[3])));neighbors[j].append((i,f(row[2]),f(row[3])))
    seen={0};queue=[0];edges=[]
    for i in queue:
        for j,r,x in neighbors[i]:
            if j in seen:continue
            seen.add(j);queue.append(j);edges.append((i,j,r,x))
    assert len(seen)==13 and len(edges)==12
    # Independently binding the branch model to the audited actual admittance.
    z=np.load(R/read(P/'Protocol.json')['graph']);Y=np.zeros((13,13),complex)
    for row in branch:
        i,j=map(int,row[:2]);y=1/complex(row[2],row[3]);Y[i,i]+=y;Y[j,j]+=y;Y[i,j]-=y;Y[j,i]-=y
    assert np.allclose(Y,z['Y'],atol=1e-12,rtol=0) and np.array_equal(branch[:,:13],z['branch'][:,:13])
    return edges,[f(v)/f(pp['baseMVA']) for v in bus[:,2]],[f(v)/f(pp['baseMVA']) for v in bus[:,3]],f(pp['baseMVA']),control

def build(root):
    edges,pd,qd,base,control=source(root);n=52;vmax=f(1.05)**2;vmin=f(.95)**2
    cap=100*f(np.float32(.3))/(1-100*F(1,2**53))
    bounds=[]
    for i,j,r,x in edges:bounds.append((-2*vmax/max(r,x),2*vmax/max(r,x)))
    for i,j,r,x in edges:bounds.append((-2*vmax/max(r,x),2*vmax/max(r,x)))
    for i,j,r,x in edges:bounds.append((F(0),4*vmax/(r*r+x*x)))
    bounds += [(vmin,vmax)]*13+ [(-cap,cap)]*3
    A=[];b=[]
    for e,(i,j,r,x) in enumerate(edges):
        child=[k for k,t in enumerate(edges) if t[0]==j]
        ar={e:F(1),24+e:-r};ar.update({k:F(-1) for k in child});A.append(ar);b.append(pd[j])
        ar={12+e:F(1),24+e:-x};ar.update({12+k:F(-1) for k in child})
        for k,c in enumerate(control):
            if c==j:ar[49+k]=1/base
        A.append(ar);b.append(qd[j])
        A.append({36+j:F(1),36+i:F(-1),e:2*r,12+e:2*x,24+e:-(r*r+x*x)});b.append(F(0))
    A.append({36:F(1)});b.append(F(1))
    grid=[F(-2),F(-1),F(-1,2),F(-1,4),F(0),F(1,4),F(1,2),F(1),F(2)]
    C=[];d=[]
    for e in range(12):
        for u in grid:
            for v in grid:C.append({e:2*u,12+e:2*v,24+e:-vmax});d.append(u*u+v*v)
    assert len(bounds)==n and len(A)==37 and len(C)==972
    return A,b,C,d,bounds

def certificate(A,b,C,d,bounds,y,lam):
    if any(v>0 for v in lam):return dict(valid_signs=False,certified=False)
    coeff=[F(0)]*len(bounds)
    for row,w in zip(A,y):
        for j,a in row.items():coeff[j]+=a*w
    for row,w in zip(C,lam):
        for j,a in row.items():coeff[j]+=a*w
    rhs=sum((u*v for u,v in zip(b,y)),F(0))+sum((u*v for u,v in zip(d,lam)),F(0))
    support=sum((max(a*lo,a*hi) for a,(lo,hi) in zip(coeff,bounds)),F(0))
    allowance=F(1,10**7)*(sum(map(abs,y),F(0))+sum(map(abs,lam),F(0)))
    gap=rhs-support-allowance
    return dict(valid_signs=True,certified=gap>0,exact_gap=enc(gap),gap_float=float(gap),exact_rhs=enc(rhs),exact_box_support=enc(support),exact_residual_allowance=enc(allowance))

def execute():
    PRIMARY.mkdir(exist_ok=False);began=time.monotonic();put(PRIMARY/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(R/'work/run_public13_radial_outer_20261022.py'),at_utc=datetime.now(timezone.utc).isoformat()))
    while not (PRIMARY/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    p=read(P/'Protocol.json')
    for rel,h in p['hashes'].items():assert sha(R/rel)==h
    from scipy.optimize import linprog
    rows=[]
    for root in p['all4_adverse_roots']:
        assert time.monotonic()-began<120
        A,b,C,d,bounds=build(root);m=len(A);k=len(C);n=len(bounds)
        ae=np.zeros((m,n+2*m+k));au=np.zeros((k,n+2*m+k))
        for i,row in enumerate(A):
            for j,a in row.items():ae[i,j]=float(a)
        ae[:,n:n+m]=np.eye(m);ae[:,n+m:n+2*m]=-np.eye(m)
        for i,row in enumerate(C):
            for j,a in row.items():au[i,j]=float(a)
        au[:,n+2*m:]=-np.eye(k);c=np.r_[np.zeros(n),np.ones(2*m+k)]
        bounds_float=[(float(lo),float(hi)) for lo,hi in bounds]+[(0,None)]*(2*m+k)
        put(PRIMARY/f"seed{root['seed']}_Attempt.json",dict(status='ONE_NEW_PHASE1_LP_ATTEMPT',time_limit=10,maxiter=10000))
        start=time.perf_counter();sol=linprog(c,A_ub=au,b_ub=np.asarray(d,float),A_eq=ae,b_eq=np.asarray(b,float),bounds=bounds_float,method='highs',options={'time_limit':10.,'maxiter':10000});elapsed=time.perf_counter()-start
        result=dict(seed=root['seed'],solver_success=bool(sol.success),solver_status=int(sol.status),seconds=elapsed,status='UNKNOWN_NO_INFEASIBILITY_CERTIFICATE')
        if sol.success:
            y=[f(v) for v in sol.eqlin.marginals];lam=[f(v) for v in sol.ineqlin.marginals]
            proof=certificate(A,b,C,d,bounds,y,lam);result.update(phase1_objective=float(sol.fun),dual_equalities=[enc(v) for v in y],dual_inequalities=[enc(v) for v in lam],proof=proof)
            if proof['certified']:result['status']='EXACT_RATIONAL_NECESSARY_CONDITION_INFEASIBILITY_CERTIFICATE'
        put(PRIMARY/f"seed{root['seed']}_Result.json",result);rows.append(result)
    put(PRIMARY/'Result.json',dict(status='COMPLETE_ALL4_FIXED_ADVERSE_CASE_OUTER_MEASUREMENTS',rows=rows,costs=dict(LP_attempts=4,LP_returns=4,new_PF_model_derivative_LU_training_calls=0),workflow_seconds=time.monotonic()-began,
        scope='All four development roots outside the four-controller saved envelope. No case excluded from full500 benchmark; not a new control performance result. Only a positive independent exact certificate supports infeasibility; all other cases UNKNOWN.'))
    put(PRIMARY/'Closed_Manifest.json',dict(files=[dict(path=q.name,sha256=sha(q),bytes=q.stat().st_size) for q in PRIMARY.iterdir() if q.is_file()]))
    print('ALL4_OUTER_MEASUREMENTS_CLOSED')
