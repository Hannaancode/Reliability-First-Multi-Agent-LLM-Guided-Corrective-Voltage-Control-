"""Restore PEFT state first, then enforce the requested COPY gradient mask.

PEFT enable/disable is an adapter-execution operation which can also change
requires_grad. An enabled adapter may legitimately be entirely frozen.
"""
from candidate_process_pretrained_loader import ADAPTER_NAME, enabled_restored_gate

def copied_parameter_registry(model):
    return {n:p for n,p in model.named_parameters()
        if '.lora_A.'+ADAPTER_NAME+'.' in n or '.lora_B.'+ADAPTER_NAME+'.' in n}

def enforce_requested_mask(model, train_body, *, expected_tensors=336, expected_parameters=8798208):
    copied=copied_parameter_registry(model)
    assert len(copied)==expected_tensors and sum(p.numel() for p in copied.values())==expected_parameters
    for n,p in model.named_parameters(): p.requires_grad_(bool(train_body and n in copied))
    actual={n:p for n,p in model.named_parameters() if p.requires_grad}
    assert set(actual)==(set(copied) if train_body else set())
    return actual

def restore_and_enforce_requested_mask(model, train_body, *, expected_layers=168, expected_tensors=336, expected_parameters=8798208):
    enforce_requested_mask(model,train_body,expected_tensors=expected_tensors,expected_parameters=expected_parameters)
    restoration=enabled_restored_gate(model,expected_layers=expected_layers)
    after_restoration=sum(p.numel() for p in model.parameters() if p.requires_grad)
    actual=enforce_requested_mask(model,train_body,expected_tensors=expected_tensors,expected_parameters=expected_parameters)
    assert not model.training
    assert all(s.enabled and not s.merged_adapters and s.active_adapters==[ADAPTER_NAME] for s in model.get_layer_status())
    return actual,{**restoration,'requested_body_trainable':bool(train_body),
        'body_trainable_parameters_immediately_after_PEFT_restoration':after_restoration,
        'actual_final_body_trainable_parameters':sum(p.numel() for p in actual.values()),
        'exact_requested_gradient_mask_enforced_after_restoration':True}
