"""New TRAIN-only current-input/one-step target dataset. No model/PF/train."""
from pathlib import Path
from datetime import datetime,timezone
import ast,copy,gzip,hashlib,json,math,time
from candidate_predictor_input_contract import (model_input,canonical,Q_GRID,
    fit_input_normalization,audit_normalized_input,InputContractError)
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'outputs/llm_value_next_method_research_20261008'
DATA=PARENT/'guarded_train_trajectory_measurement_native_v3'
AUDIT=PARENT/'guarded_train_trajectory_measurement_native_v3_audit'
BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
OUT=BASE/'input_and_target_contract'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda v:hashlib.sha256(canonical(v).encode()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
assert not OUT.exists(),'Preserve every completed/partial preparation'
cert=read(AUDIT/'Independent_Identity_State_Scope_Selection_Cost_Audit.json')
assert cert['all_closed_member_hashes_and_mechanical_gates_passed'] and cert['exact_declared_branch_identities']==62
assert cert['target_feasibility_gate_passed'] is False,'The old stopped gate cannot be relabelled'
assert read(AUDIT/'Fresh_Frozen_Preservation.json')['all_passed']
assert read(AUDIT/'Local_Archive_Audit.json')['CRC_and_every_member_hash_passed']
manifest=read(DATA/'manifest.json')
for name,m in manifest.items():assert sha(DATA/name)==m['sha256'] and (DATA/name).stat().st_size==m['bytes']
worlds=sorted(read(DATA/'protocol.json')['worlds'],key=lambda w:w['sha256'])
assert len(worlds)==31
original_rows=read(ROOT/'outputs/vcsa_development/training_interface/rows.json')
invalid=[{k:copy.deepcopy(r[k]) for k in ('local_observation_id','scenario_id','scenario_sha256','reason')}
         for r in original_rows if r['split']=='train' and not r['training_eligible']]
assert len(invalid)==1
assert {w['sha256'] for w in worlds}=={r['scenario_sha256'] for r in original_rows if r['split']=='train' and r['training_eligible']}
excluded={r['scenario_sha256'] for r in original_rows if r['split']=='validation'}
excluded.update(read(ROOT/'work/e/bank/BANK_LOCK.json')['scenario_file_sha256'].values())
assert not ({w['sha256'] for w in worlds}&excluded)
optimization={w['sha256'] for w in worlds[:23]};held={w['sha256'] for w in worlds[23:]}
OUT.mkdir(parents=True)
protocol={'declared_at_utc':now(),'purpose':'Current-state/action to measured one-step verifier outcome feasibility; not an episode branch selector or performance study',
 'world_selection':'All31 previously fixed finite TRAIN worlds plus one original invalid TRAIN view retained',
 'group_split':'Ascending existing scenario SHA: first23 optimization worlds, last8 development held worlds; all states/actions of a world stay together',
 'optimization_world_sha256':sorted(optimization),'development_held_world_sha256':sorted(held),
 'not_unused_confirmation':True,'old_failed_guarded_branch_selection_proposal_remains_stopped':True,
 'forward_boundary':'Only exact current physical observation and original static Q grid; scenario/split/branch/outcomes/labels external',
 'after_metrics_are_targets_never_current_inputs':True,'raw_common_AND_zone_action_scope_required':True,
 'missing_successor_vectors_and_labels_never_inferred':True,'duplicates_joined_only_on_exact_input/action_identity_and_identical_outcomes':True,
 'input_normalization':'Optimization-world current inputs only, per named physical table column with explicit typed/missing records',
 'future_NN_or_LoRA_training_not_launched_or_certified':True,'new_PF_controller_model_cloud_calls':0,
 'data_preparation_wall_bound_seconds':1200,'parent_scientific_manifest_sha256':sha(DATA/'manifest.json'),
 'original_TRAIN_interface_sha256':sha(ROOT/'outputs/vcsa_development/training_interface/rows.json'),
 'source_sha256':sha(Path(__file__)),'input_contract_source_sha256':sha(ROOT/'work/candidate_predictor_input_contract.py')}
with (OUT/'protocol.json').open('x',encoding='utf-8') as f:json.dump(protocol,f,indent=2)
started=time.monotonic();states={};targets={};raw=0;missing=[];world_index=[]
source=ROOT/'work/e/audit/phase2g_rescue_runner.py';tree=ast.parse(source.read_text(encoding='utf-8'))
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='score_candidate')
scope={};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(source),'exec'),scope)
for world in worlds:
    split='optimization' if world['sha256'] in optimization else 'development_held'
    identity={'scenario_id':world['scenario_id'],'scenario_sha256':world['sha256'],'family':world['family'],
              'split':split,'branches':{}}
    for branch in ('DFF','DFF-ALT'):
        assert time.monotonic()-started<1200
        path=DATA/'branches'/(world['scenario_id']+'__'+branch+'.json');record=read(path)
        assert record['status']=='complete_verified_measurement'
        identity['branches'][branch]={'source_record_sha256':sha(path),'source_role':record['source_role']}
        for observation in record['observations']:
            obs=observation['input_observation'];obs_id=observation['observation_sha256'];assert digest(obs)==obs_id
            pure=model_input(obs)
            if obs_id not in states:
                states[obs_id]={'observation_id':obs_id,'world_sha256':world['sha256'],'split':split,
                                'model_input':pure,'model_input_sha256':digest(pure),'occurrences':1}
            else:
                prior=states[obs_id];assert prior['world_sha256']==world['sha256'] and prior['split']==split and prior['model_input_sha256']==digest(pure)
                prior['occurrences']+=1
        decisions=record['measured_decisions']
        if decisions is None:
            missing.append({'scenario_id':world['scenario_id'],'branch':branch,'status':'original_candidate_ledger_not_saved_no_targets_created'});continue
        for decision in decisions:
            obs_id=decision['observation_sha256'];obs=states[obs_id]['model_input']['current_physical_observation']
            pools=obs['raw_common_and_zone_pools'];actual=targets.setdefault(obs_id,{})
            for c in decision['candidates']:
                raw+=1;mapping=c['action']['add_shunts_q_mvar'];assert len(mapping)==1
                bus_text,q=next(iter(mapping.items()));bus=int(bus_text);q=float(q)
                assert str(bus)==bus_text and q in Q_GRID and any(bus in p for p in pools.values())
                v=copy.deepcopy(c['verif']);assert type(v['accepted']) is bool and type(v['converged']) is bool
                for key,value in v['before'].items():assert abs(value-obs['global_metrics'][key])<=1e-10
                after=v['after'];finite=after is not None and all(type(x) in (float,int) and math.isfinite(x) for x in after.values())
                gains=None
                if finite:
                    gains={'UV_gain':v['before']['uv_count']-after['uv_count'],
                           'deficit_gain':v['before']['deficit_sum']-after['deficit_sum'],
                           'vmin_gain':after['vmin']-v['before']['vmin'],
                           'normal_upper_margin':1.05+1e-8-after['vmax']}
                key=str(bus)+'__'+str(Q_GRID.index(q))
                target={'action':copy.deepcopy(c['action']),'bus':bus,'Q_index':Q_GRID.index(q),'q_mvar':q,
                        'recorded_verifier':v,'has_finite_after_global_metrics':finite,'measured_global_gains':gains,
                        'one_step_UV_zero':bool(after['uv_count']==0) if finite else None,
                        'recorded_original_score':list(scope['score_candidate'](c)),
                        'not_full_successor_or_episode_reward':True}
                if key in actual:
                    assert digest(actual[key]['target'])==digest(target),'Conflicting actual labels; no averaging or imputation'
                    actual[key]['occurrences']+=1
                else:actual[key]={'target':target,'occurrences':1}
    world_index.append(identity)
assert raw==cert['verified_candidate_label_rows']==44649
assert sum(len(x) for x in targets.values())==38727 and len(targets)==238
train_inputs=[s['model_input']['current_physical_observation'] for s in states.values() if s['split']=='optimization']
normal=fit_input_normalization(train_inputs)
normal['optimization_world_sha256']=sorted(optimization)
input_audits=[]
for state in states.values():
    a=audit_normalized_input(state['model_input']['current_physical_observation'],normal)
    input_audits.append({'observation_id':state['observation_id'],'split':state['split'],'has_measured_targets':state['observation_id'] in targets,**a})
# Real held-input mutation check; this is a labelled software mutation, not a physical outcome.
held_state=next(s for s in states.values() if s['split']=='development_held')
mutated=copy.deepcopy(held_state['model_input']['current_physical_observation'])
frame=mutated['physical_tables']['load'];frame['values'][0][frame['columns'].index('p_mw')]+=1000.
assert digest(model_input(mutated))!=held_state['model_input_sha256']
assert fit_input_normalization(train_inputs)=={k:v for k,v in normal.items() if k!='optimization_world_sha256'}
probe=copy.deepcopy(train_inputs[0]);probe['after_metrics']={'uv_count':0}
try:model_input(probe)
except InputContractError:pass
else:raise AssertionError('Injected future target accepted as forward input')
assert all(set(s['model_input'])=={'current_physical_observation','original_Q_grid'} for s in states.values())
def gzip_rows(name,rows):
    with (OUT/name).open('xb') as raw_file,gzip.GzipFile(fileobj=raw_file,mode='wb',mtime=0) as f:
        for row in rows:f.write((canonical(row)+'\n').encode('utf-8'))
gzip_rows('Current_Input_Rows.jsonl.gz',[{k:copy.deepcopy(v) for k,v in s.items() if k!='occurrences'} for s in sorted(states.values(),key=lambda s:s['observation_id'])])
gzip_rows('Measured_Target_Rows.jsonl.gz',[{'observation_id':obs_id,'world_sha256':states[obs_id]['world_sha256'],
            'split':states[obs_id]['split'],'measured_candidates':[x for _,x in sorted(labels.items())]}
            for obs_id,labels in sorted(targets.items())])
values={'Input_Normalization.json':normal,'World_and_Invalid_Denominators.json':{'worlds':world_index,'original_invalid_TRAIN_inputs':invalid,'missing_candidate_ledgers':missing},
        'Actual_Input_Contract_Audit.json':input_audits}
for name,value in values.items():
    with (OUT/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)
counts={}
for split in ('optimization','development_held'):
    ids=[s['observation_id'] for s in states.values() if s['split']==split]
    counts[split]={'declared_worlds':23 if split=='optimization' else 8,'unique_physical_inputs':len(ids),
                   'states_with_measured_targets':sum(i in targets for i in ids),
                   'unique_measured_state_actions':sum(len(targets.get(i,{})) for i in ids),
                   'unsupported_input_semantic_types':sum(bool(a['unsupported_semantic_types']) for a in input_audits if a['split']==split)}
summary={'completed_at_utc':now(),'declared_finite_TRAIN_worlds':31,'retained_original_invalid_TRAIN_views':1,
 'raw_candidate_records':raw,'unique_state_action_targets':sum(len(x) for x in targets.values()),
 'unique_current_physical_inputs':len(states),'states_with_measured_candidate_targets':len(targets),'partition_counts':counts,
 'all_raw_input_field_value_types_round_trip':True,'all_targets_in_original_raw_common_AND_zone_scope':True,
 'world_partition_disjointness_and_no_VAL_or_bank_overlap':True,'input_and_target_files_separate':True,
 'no_future_or_label_fields_in_forward_inputs':True,'held_input_mutation_cannot_affect_training_normalization':True,
 'new_declared_physical_table_column_conditioning_groups':len(normal['numeric']),
 'missing_candidate_ledgers_retained':len(missing),'actual_new_solver_model_controller_cloud_calls':0,
 'method_training_or_performance_not_started':True,'old_guarded_branch_selection_gate_remains_failed':True,
 'elapsed_seconds':time.monotonic()-started,'no_LLMSuperiority_or_unused_confirmation_claim':True}
with (OUT/'summary.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2)
members={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}
with (OUT/'manifest.json').open('x',encoding='utf-8') as f:json.dump(members,f,indent=2)
print(json.dumps(summary,indent=2))
