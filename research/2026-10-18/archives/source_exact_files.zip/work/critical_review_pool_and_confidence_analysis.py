"""Read-only necessary-opportunity analysis and explicitly hypothetical power.

No new forecast, solver, controller, model, training or cloud calls.
The input union is an already sealed development result, not a fresh holdout.
"""
import json
import math
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, write, sha, seal

OUT = ROOT / 'outputs/critical_research_reset_20261010/read_only_feasibility'
assert not OUT.exists()
OUT.mkdir()
start = time.perf_counter()
P = ROOT / 'outputs/llm_value_relational_adaptation_research_20261009'
source = P / 'native_unexecuted_measurement_audit/All239_State_and_World_Denominators.json'
protocol = {
 'declared_at_utc': datetime.now(timezone.utc).isoformat(),
 'purpose': 'Necessary candidate-pool opportunity, not learned performance or novel method proof',
 'fixed_pool': 'UNION of old-admittance K4 and candidate-admittance K4; at most8 unique native actions',
 'target_selection_budget': 4,
 'all239_OPT_inputs_all23_historical_worlds': True,
 'no_favorable_world_selection_or_increase_K_after_result': True,
 'missing_original_full_ranking_retained_UNKNOWN': True,
 'known_union_inclusion': 'For complete source rankings: old inclusion OR candidate inclusion',
 'primary_necessary_gate': 'Equal-world lower union inclusion minus old equal-world upper >=.05',
 'contrast_necessary_gate': 'At least3 known recoverable-old-miss worlds and2 families',
 'unlabelled_no_oracle_worlds_kept_not_zero_imputed': True,
 'zero_new_model_PF_optimizer_forecast_derivative_linear_solve_controller_cloud_calls': True,
 'input_sha256': sha(source),
 'source_sha256': sha(Path(__file__)),
 'resource_bound_seconds': 300,
 'confidence_analysis': 'Analytic examples under FABRICATED IID win/loss rates; not predictions of LLM success',
 'hypothetical_test': 'One-sided exact paired win-versus-loss test with per-comparison alpha .01/4',
 'hypothetical_power_target': .99,
 'hypothetical_rates': [[.10,.02],[.10,.05],[.075,.025]],
 'hypothetical_N': [31,100,250,500,1000,2000],
 'no99percent_success_or_novelty_assertion': True,
}
write(OUT / 'Prospective_Read_Only_Feasibility_Protocol.json', protocol)
data = read(source)
arms = ['old_admittance_derivative', 'candidate_admittance_derivative']
assert set(data) == set(arms)
maps = {a: {r['observation_id']: r for r in data[a]} for a in arms}
assert all(len(m) == 239 for m in maps.values())
assert set(maps[arms[0]]) == set(maps[arms[1]])
worlds = defaultdict(list)
rows = []
for ident in sorted(maps[arms[0]]):
    old, cand = (maps[a][ident] for a in arms)
    assert (old['world_sha256'], old['family'], old['oracle_exists']) == (cand['world_sha256'], cand['family'], cand['oracle_exists'])
    ao, ac = (r['K']['4']['actual_recorded_best_inclusion'] for r in (old, cand))
    complete = old['ranking_evidence_complete'] and cand['ranking_evidence_complete']
    pool = sorted({tuple(x) for r in (old,cand) for x in r['K']['4']['chosen_available_actions']})
    assert len(pool) <= 8
    if not old['oracle_exists']:
        hit = None
    elif not complete or ao is None or ac is None:
        hit = None
    else:
        assert type(ao) is type(ac) is bool
        hit = ao or ac
    row = {'observation_id': ident, 'world_sha256': old['world_sha256'], 'family': old['family'],
           'oracle_exists': old['oracle_exists'], 'full_pool_construction_known': complete,
           'available_union_action_count': len(pool), 'available_union': pool,
           'recorded_best_in_available_union': hit,
           'known_old_miss_recoverable': old['oracle_exists'] and complete and ao is False and ac is True,
           'old_K4_inclusion': ao, 'candidate_K4_inclusion': ac}
    rows.append(row)
    worlds[old['world_sha256']].append(row)
assert len(worlds) == 23
byworld = {}
for w, rr in worlds.items():
    oo = [r for r in rr if r['oracle_exists']]
    hit = sum(r['recorded_best_in_available_union'] is True for r in oo)
    unknown = sum(r['recorded_best_in_available_union'] is None for r in oo)
    old_hit = sum(r['old_K4_inclusion'] is True for r in oo)
    old_unknown = sum(r['old_K4_inclusion'] is None for r in oo)
    byworld[w] = {'all_inputs': len(rr), 'oracle_states': len(oo), 'union_hits': hit, 'unknowns': unknown,
        'union_lower': hit/len(oo) if oo else None, 'union_upper': (hit+unknown)/len(oo) if oo else None,
        'old_upper': (old_hit+old_unknown)/len(oo) if oo else None,
        'known_recoverable_old_misses': sum(r['known_old_miss_recoverable'] for r in oo),
        'family': rr[0]['family']}
measured = [v for v in byworld.values() if v['oracle_states']]
lower = sum(v['union_lower'] for v in measured)/len(measured)
upper = sum(v['union_upper'] for v in measured)/len(measured)
old_upper = sum(v['old_upper'] for v in measured)/len(measured)
recoverable = [r for r in rows if r['known_old_miss_recoverable']]
rw = {r['world_sha256'] for r in recoverable}
families = sorted({r['family'] for r in recoverable})
gate = lower-old_upper >= .05 and len(rw) >= 3 and len(families) >= 2
opportunity = {'actual_inputs': 239, 'declared_worlds': 23, 'oracle_states': sum(r['oracle_exists'] for r in rows),
    'worlds_with_measured_oracle': len(measured), 'known_union_hits': sum(r['recorded_best_in_available_union'] is True for r in rows if r['oracle_exists']),
    'unknown_union_oracle_states': sum(r['recorded_best_in_available_union'] is None for r in rows if r['oracle_exists']),
    'equal_world_union_lower': lower, 'equal_world_union_upper': upper, 'old_equal_world_upper': old_upper,
    'conservative_remaining_K4_opportunity': lower-old_upper,
    'known_recoverable_old_miss_states': len(recoverable), 'recoverable_worlds': len(rw), 'recoverable_families': families,
    'fixed_necessary_gate_passed': gate, 'not_a_learned_or_verifiable_policy': True,
    'no_actual_LLM_confidence_success_probability_or_novelty_estimated': True,
    'no_automatic_training_or_GPU_from_necessary_gate': True,
    'all23_world_denominators': byworld}
write(OUT / 'All239_Fixed_Pool_Feasibility_Rows.json', rows)
write(OUT / 'Actual_Fixed_Pool_Opportunity.json', opportunity)

from scipy.stats import binom
alpha = .01/4
def critical_wins(d):
    lo, hi = 0, d+1
    while lo < hi:
        mid = (lo+hi)//2
        if float(binom.sf(mid-1,d,.5)) <= alpha:
            hi = mid
        else:
            lo = mid+1
    return lo
critical = {d: critical_wins(d) for d in range(2001)}
def power(n,w,l):
    discord = w+l
    return sum(float(binom.pmf(d,n,discord))*float(binom.sf(critical[d]-1,d,w/discord)) for d in range(n+1))
power_rows = []
for w,l in protocol['hypothetical_rates']:
    for n in protocol['hypothetical_N']:
        power_rows.append({'FABRICATED_win_probability':w,'FABRICATED_loss_probability':l,
            'assumed_true_success_difference':w-l,'IID_independent_worlds':n,
            'exact_positive_difference_test_power':power(n,w,l),
            'does_not_include_effect_floor_safety_cost_or_other_comparator_gates':True})
n_zero = math.ceil(math.log(.01)/math.log(.99))
confidence = {'hypothetical_only_not_experiment_results':True, 'per_comparison_alpha':alpha,
    'four_comparison_family_budget':.01, 'exact_binomial_paired_positive_difference_power':power_rows,
    'minimum_IID_worlds_with_zero_failures_for_one_sided99percent_upper_risk_below1percent':n_zero,
    'zero_failure_upper_bound_at_23':1-.01**(1/23),
    'zero_failure_upper_bound_at_31':1-.01**(1/31),
    'zero_failure_upper_bound_at_n_zero':1-.01**(1/n_zero),
    'training_worlds_are_inspected_development_and_not_eligible_for_confirmatory_bounds':True,
    '99percent_statistical_confidence_is_not99percent_prior_probability_of_a_win':True,
    'exact_test_assumes_independent_worlds_and_identical_null_discordant_orientation':True,
    'a_true_effect_equal_to_a_required_point_effect_floor_cannot_have99percent_probability_of_exceeding_that_floor':True,
    'complete99percent_joint_power_and_full_cost_need_prospectively_justified_effect_assumptions_not_supplied':True}
assert n_zero == 459
write(OUT / 'Hypothetical_Confidence_and_Resource_Reality.json', confidence)
elapsed = time.perf_counter()-start
assert elapsed < 300
final = {'closed_at_utc':datetime.now(timezone.utc).isoformat(), 'seconds_before_seal':elapsed,
    'read_only_analysis_complete':True,'new_scientific_model_PF_training_forecast_derivative_solve_cloud_calls':0,
    'fixed_pool_necessary_opportunity_gate':gate,'source_sha256':sha(Path(__file__)),
    'does_not_justify99percent_concrete_novel_winning_plan':True}
write(OUT / 'Read_Only_Analysis_Status.json', final)
files = {f.name:f for f in OUT.iterdir() if f.is_file()}
files['sources/analyst.py'] = Path(__file__)
archive = seal(OUT,files,'Read_Only_Fixed_Pool_and_Confidence_Evidence.zip')
print(json.dumps({'opportunity':{k:v for k,v in opportunity.items() if k!='all23_world_denominators'},
                  'zero_failure_risk_n':n_zero,'status':final,'archive':archive}))
