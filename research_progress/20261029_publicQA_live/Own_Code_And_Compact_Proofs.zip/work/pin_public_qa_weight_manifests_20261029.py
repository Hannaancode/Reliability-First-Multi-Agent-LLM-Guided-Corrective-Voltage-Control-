"""Read public pinned artifact identities; download no model weights."""
from pathlib import Path
import hashlib,json,urllib.request
R=Path(__file__).resolve().parents[1];O=R/'outputs/public_qa_supervision_20261029/weight_metadata'
def main():
    O.mkdir();models=json.loads((R/'outputs/public_qa_scale_design_20261029/Pinned_Public_Model_Identities.json').read_text())['models'];rows=[]
    for m in models:
        url='https://huggingface.co/api/models/'+m['model']+'/tree/'+m['revision']+'?recursive=true&expand=false'
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'HierGrid-research-input-audit'}),timeout=40) as response:
            raw=response.read();assert response.headers.get('Link') is None,'Pagination must be handled explicitly'
        files=json.loads(raw);weights={x['path']:{'bytes':x['size'],'sha256':x['lfs']['oid']} for x in files if x['path'].endswith('.safetensors')}
        assert weights and all(len(x['sha256'])==64 for x in weights.values())
        name=m['model'].split('/')[-1];(O/(name+'.json')).write_bytes(raw)
        rows.append({'model':m['model'],'revision':m['revision'],'source':url,'metadata_sha256':hashlib.sha256(raw).hexdigest(),
            'weights':weights,'total_weight_bytes':sum(x['bytes'] for x in weights.values())})
    result={'status':'PASS_THREE_PINNED_PUBLIC_WEIGHT_MANIFESTS','models':rows,'model_weight_bytes_downloaded':0,'model_GPU_calls':0}
    (O/'Result.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps({'status':result['status'],'weight_files':[len(x['weights']) for x in rows]}))
if __name__=='__main__':main()
