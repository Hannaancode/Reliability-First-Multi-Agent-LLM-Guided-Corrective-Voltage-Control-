"""One independent closed-output reader: no PF, model, derivative or equation solve."""
import hashlib,json,math,os,pickle,struct,time,zlib
from pathlib import Path
import numpy as np
import pandas as pd
import pandapower as pp
from durable_opaque_evidence_store_v1 import local_root,inventory,process_alive
from joint_reallocation_opportunity_core_v1 import load_endpoint,universe,action

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()
def put(p,d):
    with local_root(p).open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def metrics(f):
    vm=np.array([f[b]['vm_pu'] for b in sorted(f,key=int)])
    return {'vmin':float(vm.min()),'vmax':float(vm.max()),'vmean':float(vm.mean()),'uv_count':int((vm<.95).sum()),
        'ov_count':int((vm>1.05).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum())}
def score(before,after,q,accepted):
    return [int(after['uv_count']==0),before['uv_count']-after['uv_count'],before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],-q] if accepted else [-999]*5

def main():
    begun=time.perf_counter();out=BASE/'actual';audit=BASE/'audit';local_root(audit).mkdir(exist_ok=False)
    put(audit/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    p=read(BASE/'preparation/Protocol.json');ph=sha(BASE/'preparation/Protocol.json');end=read(BASE/'Owner_End_ACK.json')
    assert not process_alive(end['actual_pid']) and not process_alive(end['launcher_pid'])
    assert end['returncode']==0 and end['closed_manifest_sha256']==sha(out/'Closed_Manifest.json')
    m=read(out/'Closed_Manifest.json');assert m['exit_code']==0
    assert inventory(out,hashes=True)=={**m['members'],'Closed_Manifest.json':{'bytes':local_root(out/'Closed_Manifest.json').stat().st_size,'sha256':sha(out/'Closed_Manifest.json')}}
    for n,h in p['source_input_sha256'].items():assert sha(ROOT/n)==h,n
    claim=read(out/'owner.claim');ack=read(out/'Launcher_ACK.json')
    assert claim['actual_pid']==ack['actual_pid']==end['actual_pid'] and claim['protocol_sha256']==ack['protocol_sha256']==ph
    assert ack['fresh_exact_PID_parent_command_verified'] and claim['source_sha256']==p['source_input_sha256']['work/run_joint_reallocation_opportunity_v1.py']
    def blocked(*a,**k):raise RuntimeError('No numerical/physical/model calls in independent reader')
    for n in ('runpp','rundcpp','runopp','rundcopp'):
        if hasattr(pp,n):setattr(pp,n,blocked)
    rows=[];prev='0'*64
    for b in local_root(out/'scientific.jsonl').read_bytes().splitlines():
        r=json.loads(b);assert r['previous_sha256']==prev and r['protocol_sha256']==ph;prev=hashlib.sha256(b).hexdigest();rows.append(r)
    intents={r['data']['id']:r['data'] for r in rows if r['event']=='PF_intent'}
    returns={r['data']['id']:r['data'] for r in rows if r['event']=='PF_return'}
    exceptions={r['data']['id']:r['data'] for r in rows if r['event']=='PF_exception'}
    assert set(returns).isdisjoint(exceptions) and set(intents)==set(returns)|set(exceptions)
    assert sorted(intents)==list(range(1,len(intents)+1))
    pack=local_root(out/'capsules.bin').open('rb');offsets={};packet_bytes=pack.seek(0,2);pack.seek(0)
    while pack.tell()<packet_bytes:
        offset=pack.tell();size=struct.unpack('<Q',pack.read(8))[0];assert 0<size<8192
        hb=pack.read(size);h=json.loads(hb);body_offset=pack.tell();body=pack.read(h['encoded_bytes'])
        assert len(body)==h['encoded_bytes'] and hashlib.sha256(body).hexdigest()==h['encoded_sha256']
        offsets[offset]={'header':h,'header_sha':hashlib.sha256(hb).hexdigest(),'body_offset':body_offset,'header_bytes':size}
    assert pack.tell()==packet_bytes
    accessed=set()
    def capsule(a):
        o=offsets[a['record_offset']];assert o['header_bytes']==a['header_bytes'] and o['header_sha']==a['header_sha256'] and o['body_offset']==a['encoded_offset']
        assert all(a[k]==v for k,v in o['header'].items());accessed.add(a['record_offset'])
        pack.seek(o['body_offset']);b=pack.read(a['encoded_bytes']);d=zlib.decompressobj();raw=d.decompress(b,a['raw_bytes']+1)
        assert d.eof and not d.unused_data and not d.unconsumed_tail and len(raw)==a['raw_bytes'] and hashlib.sha256(raw).hexdigest()==a['raw_sha256']
        return pickle.loads(raw)['net']
    result=read(out/'Result.json');c=result['actual_costs'];assert result['exit_code']==0
    assert c['PF_attempts']==len(intents) and c['PF_returns']==len(returns) and c['PF_exceptions']==len(exceptions)
    assert abs(sum(d['seconds'] for d in list(returns.values())+list(exceptions.values()))-c['PF_seconds'])<=1e-8
    assert c['public_derivative_attempts']==c['public_derivative_returns']==c['LU_factor_attempts']==c['LU_factor_returns']==c['LU_solve_attempts']==c['LU_solve_returns']==4 and c['RHS_columns']==472
    candidates=[r['data'] for r in rows if r['event']=='candidate_closed']
    assert len(candidates)==sum(p['declared_universe_counts'])==c['native_verifier_queries']==c['forecast_attempts']==c['forecast_returns']
    summaries=[];wins=0
    for w,entry in enumerate(p['current_endpoints']):
        current,cursor,_=load_endpoint(entry);base_fields={str(int(i)):{k:float(current.res_bus.at[i,k]) for k in ('vm_pu','va_degree','p_mw','q_mvar')} for i in current.res_bus.index}
        before=metrics(base_fields);expected_rows=universe(cursor);actual=[r for r in candidates if r['world']==entry['world']]
        assert len(actual)==len(expected_rows)
        assert {r['universe_index'] for r in actual}==set(range(len(expected_rows)))
        assert [r['universe_index'] for r in actual]==[r['universe_index'] for r in sorted(actual,key=lambda r:(tuple(-x for x in r['ordering_forecast']['score']),r['universe_index']))]
        ctx=dict(np.load(local_root(out/f'W{w+1}_Current_Jacobian.npz'),allow_pickle=False))
        V,Y=ctx['V'],ctx['Y'];unit=V/abs(V);I=Y@V
        m0=np.diag(V)@np.conj(Y@np.diag(unit))+np.diag(np.conj(I))@np.diag(unit)
        a0=1j*np.diag(V)@np.conj(np.diag(I)-Y@np.diag(V))
        assert np.max(abs(m0-ctx['m']))<=1e-9 and np.max(abs(a0-ctx['a']))<=1e-9
        nr,pq=ctx['nonref'],ctx['PQ'];J=np.block([[a0.real[np.ix_(nr,nr)],m0.real[np.ix_(nr,pq)]],[a0.imag[np.ix_(pq,nr)],m0.imag[np.ix_(pq,pq)]]])
        B=np.zeros_like(ctx['B']);positions={int(k):j for j,k in enumerate(pq)}
        for bus,k in enumerate(ctx['mapping']):
            if int(k) in positions:B[len(nr)+positions[int(k)],bus]=abs(V[k])**2/float(current['_ppc']['baseMVA'])
        assert np.max(abs(B-ctx['B']))<=1e-14 and np.max(abs(J@ctx['X']-B))<=1e-8
        S=np.zeros((118,118));S[pq,:]=ctx['X'][len(nr):,:];S=S[ctx['mapping'],:]
        assert np.array_equal(S,ctx['sensitivity'])
        by_kind={'ordinary':[],'equal_owned_reallocation':[]}
        for r in actual:
            e=expected_rows[r['universe_index']];assert all(r[k]==v for k,v in e.items()) and r['action']==action(e)
            assert not r['actually_committed'] and r['device_operations_if_committed']==(2 if e['kind']=='equal_owned_reallocation' else 1)
            assert cursor['remaining_original_device_operation_slots']>=r['device_operations_if_committed']
            prediction=ctx['current_vm']+e['q']*(S[:,e['receiver']]-(S[:,e['donor_bus']] if e['donor_bus'] is not None else 0))
            forecast=r['ordering_forecast']
            if np.isfinite(prediction).all() and (prediction>0).all():
                pm={'uv_count':int((prediction<.95).sum()),'deficit_sum':float(np.maximum(.95-prediction,0).sum()),'vmin':float(prediction.min()),'vmax':float(prediction.max())}
                assert pm==forecast['after'] and score(before,pm,e['q'],True)==forecast['score']
            else:assert forecast['status']=='UNKNOWN_NONPHYSICAL_LINEAR_FORECAST'
            receipt=r['measured_receipt'];verif=r['verif']
            if receipt is None:
                assert cursor['positive_addition_lifetime_MVAr'].get(str(e['receiver']),0)+e['q']>450
                assert not verif['accepted'] and verif['reason']=='q_cap_exceeded'
                continue
            intent=intents[receipt['PF_id']];assert intent['world']==entry['world'] and intent['phase']=='trial' and intent['kwargs']==p['trial_solver_kwargs']
            test=capsule(intent['before']);table=current.shunt.copy(deep=True)
            for name,value in current.items():
                if isinstance(value,pd.DataFrame) and name!='shunt' and not name.startswith('res_'):
                    assert isinstance(test[name],pd.DataFrame) and test[name].equals(value),('Physical input changed',name)
            if e['donor_index'] is not None:table.at[e['donor_index'],'q_mvar']+=e['q']
            assert test.shunt.loc[current.shunt.index].equals(table)
            extra=[i for i in test.shunt.index if i not in current.shunt.index];assert len(extra)==1
            added=test.shunt.loc[extra[0]];assert int(added.bus)==e['receiver'] and float(added.q_mvar)==-e['q'] and float(added.p_mw)==0 and float(added.step)==1
            assert verif['before']==before
            if receipt['outcome'].startswith('EXCEPTION'):
                capsule(receipt['after']);assert receipt['PF_id'] in exceptions and not verif['accepted'] and verif['reason']=='pf_failed';continue
            returned=returns[receipt['PF_id']];after_net=capsule(returned['after']);measured={str(int(i)):{k:float(after_net.res_bus.at[i,k]) for k in ('vm_pu','va_degree','p_mw','q_mvar')} for i in after_net.res_bus.index}
            assert measured==receipt['fields']==returned['fields'] and receipt['converged'] and after_net.converged
            after=metrics(measured);assert after==verif['after']
            raw_ok=after['vmax']<=1.06 and after['uv_count']<=before['uv_count'] and after['deficit_sum']<=before['deficit_sum']+1e-9 and (
                after['uv_count']<before['uv_count'] or after['deficit_sum']<before['deficit_sum']-1e-9 or after['vmin']>before['vmin']+1e-9)
            ok=raw_ok and after['vmax']<=1.05+1e-8
            assert verif['original_native_accepted']==raw_ok and verif['accepted']==ok
            assert r['original_score']==score(before,after,e['q'],ok)
            if ok:by_kind[e['kind']].append(r)
        world=result['world_results'][w];assert world['world']==entry['world'] and world['complete']
        for kind in by_kind:
            eligible=by_kind[kind];best=max(eligible,key=lambda r:(tuple(r['original_score']),-r['universe_index'])) if eligible else None
            selected=world['selected'][kind]
            if best is None:assert selected is None;continue
            assert selected['candidate']['universe_index']==best['universe_index'] and selected['metrics']==best['verif']['after']
            replay=returns[selected['independent_replay_PF_id']];assert intents[selected['independent_replay_PF_id']]['phase']=='independent_selected_replay'
            replay_net=capsule(replay['after']);capsule(intents[selected['independent_replay_PF_id']]['before'])
            rr={str(int(i)):{k:float(replay_net.res_bus.at[i,k]) for k in ('vm_pu','va_degree','p_mw','q_mvar')} for i in replay_net.res_bus.index}
            query=best['measured_receipt']['fields'];delta=max(abs(rr[b][k]-query[b][k]) for b in rr for k in rr[b])
            assert delta<=1e-10 and delta==selected['all_four_fields_max_delta'] and {b for b in rr if rr[b]['vm_pu']<.95}=={b for b in query if query[b]['vm_pu']<.95}
        ordinary=world['selected']['ordinary'];joint=world['selected']['equal_owned_reallocation']
        ordinary_uv=ordinary['metrics']['uv_count'] if ordinary else before['uv_count'];joint_uv=joint['metrics']['uv_count'] if joint else before['uv_count']
        win=joint is not None and joint_uv<ordinary_uv;wins+=int(win)
        summaries.append({'world':entry['world'],'current_uv':before['uv_count'],'best_complete_singleton_uv':ordinary_uv,
            'best_complete_equal_transfer_uv':joint_uv,'strict_extra_UV_improvement':win,
            'best_complete_singleton':ordinary,'best_complete_equal_transfer':joint,'new_commit_or_LLM_benefit':False})
    assert accessed==set(offsets),'Every returned/failed capsule must be independently read'
    pack.close();decision='PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY' if wins>=2 else 'FAIL_STOP_SPECIFIED_EQUAL_REALLOCATION_INTERVENTION'
    report={'status':'PASS_INDEPENDENT_FULL_DECLARED_ONE_MOVE_PHYSICAL_AUDIT','actual_pid':os.getpid(),
        'world_results':summaries,'strict_improved_worlds':wins,'fixed_gate_decision':decision,
        'actual_science_costs':c,'new_reader_PF_model_derivative_equation_solve_calls':0,
        'all_declared_candidates_checked':len(candidates),'all_capsule_records_checked':len(accessed),
        'full_two_ordinary_moves_full_policy_DSE_LLM_novelty_or_confirmation':'UNACHIEVED_NOT_TESTED',
        'reader_seconds_before_output':time.perf_counter()-begun}
    put(audit/'Independent_Audit.json',report);put(audit/'Fixed_Gate_Decision.json',{'decision':decision,'strict_win_worlds':wins,
        'automatic_GPU_training_rollout_authorized':False,'failed_gate_stops_no_budget_Q_root_seed_objective_retune':True})
    print(json.dumps({'status':report['status'],'fixed_gate':decision,'strict_worlds':wins,'reader_science':0}))
if __name__=='__main__':main()
