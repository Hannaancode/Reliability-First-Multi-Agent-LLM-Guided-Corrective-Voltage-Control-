# Full configured-limit CPU validation

Six new historical prototype trajectories completed on8 October2026 at04:42Qatar. Limits were declared before execution:25 decisions,32 candidate PF attempts per decision,512 controller PF attempts per trajectory. These differ from the completed18 one-state controls, which were preserved unchanged. All original baseline package/model/network/controller/settings/bank assets remain unchanged.

The exact six declared identities completed and their9-file JSON manifest passed an independent byte/hash check. Every decision's actual state and candidate-bus reconstruction, and every committed action, matched independently solved physical replay within1e-10. Base networks were preserved. There were1,488 charged controller PF attempts, including one solver exception, and48 separately charged independent replay solves with zero exceptions. The solver exception remains recorded; it did not become an accepted/released action. Natural stops occurred after4–13 decisions, so these results do not imply25 decisions or the512 cap was reached in a real trajectory. Earlier tiny-budget/software tests cover budget exhaustion separately.

| Historical load factor | Ordering | Final strict UV buses | Committed actions | Controller PF attempts | Normal upper band exceeded beyond1e-8 |
|---|---|---:|---:|---:|---|
|1.25|Frozen enumeration|4|6|231|Yes|
|1.25|Lowest voltage|0|4|133|No|
|1.25|Seeded random|0|4|133|No|
|1.50|Frozen enumeration|41|4|165|Yes|
|1.50|Lowest voltage|1|11|396|Yes|
|1.50|Seeded random|0|13|430|Yes|

Three trajectories cleared strict undervoltage; three retained residual undervoltage and stopped without an accepted action within the declared search. Four endpoints exceeded the normal1.05 upper band beyond the separately labelled1e-8 diagnostic tolerance. The unchanged original hard1.06 verifier and strict metrics remain intact. UV clearance is not full operational feasibility.

This is software/physical development evidence from two historical points in one family and one random seed. It justifies retaining enumeration, voltage-based and random controls when measuring learned ordering. It provides no LLM result, independent superiority claim, stochastic-policy ranking, confidence interval or security robustness claim. Actual clean-model calls remainzero because the newly human-authorized T4 request also failedHTTP503 before runtime allocation. The learned callback and separate normal-band mediation remain pending.
