# Verified one-move physical opportunity result

Independent actual audit PASS. Fixed opportunity gate: **PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY**.

| Fixed current state | Before UV | Best ordinary UV | Best equal-transfer UV | Strict extra UV reduction |
|---|---:|---:|---:|---|
| fed_combined_load_1p5_line_35_MG1 | 17 | 11 | 10 | True |
| fed_combined_load_1p5_line_36_MG1 | 33 | 27 | 23 | True |
| fed_combined_load_1p5_line_84_MG2 | 28 | 25 | 23 | True |
| fed_combined_load_1p5_line_127_MG3 | 15 | 12 | 8 | True |

All 4001 declared ordinary/owned-bank transfer identities closed; 4006 actual new PF attempts, 4006 returns and 0 solver exceptions. All actual return/exception packets and independent selected-action replays retained. No new model, optimizer or full policy rollout calls.

Only separately justified economic/matched equally capable numerical/control/fresh private0.5B-role design. No automatic GPU/training/rollout; preserve complete originalDSE branches/FULLBOTH costs.

This is an expanded research-model action space with source-owned partially switchable banks. Both device operations are charged; positive addition caps are never refunded. Original nonlinear predicates/raw scopes/Q and common normal upper bound remain. The numerical current-mask approximation orders candidates only. This is not a comparison with two ordinary actions, a full25step policy, D-SE portfolio superiority, incremental LLM benefit, novelty, security or unused confirmation.

The separate all-K numerical analysis retains K=1,4,16,64,256 on every root. Its oracle match ranks are descriptive, not legal hindsight stopping. Recorded PF timing omits other deployment costs. Old reconstruction/data/model/preparation/failure costs remain separately paid; no whole-system efficiency claim.
