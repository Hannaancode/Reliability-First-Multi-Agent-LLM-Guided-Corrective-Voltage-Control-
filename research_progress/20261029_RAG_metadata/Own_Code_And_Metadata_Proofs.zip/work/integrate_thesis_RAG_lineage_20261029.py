"""New thesis copy with source findings and explicitly limited retrieval claims."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re
from docx import Document
from docx.shared import Pt,RGBColor
R=Path(__file__).resolve().parents[1]
B=R/'outputs/thesis_caption_QA_v2_20261029'
O=R/'outputs/thesis_RAG_lineage_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return json.loads(p.read_text('utf-8-sig'))
def main():
    assert not (O/'Hannaan_Thesis_RAG_And_Lineage_Update.docx').exists();O.mkdir(exist_ok=True)
    base=B/'Hannaan_Thesis_Caption_And_QA_Update.docx'
    assert sha(base)==rd(B/'Final_Visual_And_Evidence_QA.json')['docx_sha256']
    d=Document(base);added=[];changed=[]
    def before(prefix,text,style='Normal'):
        anchor=next(p for p in d.paragraphs if p.text.startswith(prefix) and '\t' not in p.text)
        p=d.add_paragraph(text,style);anchor._p.addprevious(p._p)
        p.paragraph_format.space_after=Pt(6);p.paragraph_format.widow_control=True
        if style.startswith('Heading'):p.paragraph_format.keep_with_next=True
        for run in p.runs:run.font.name='Times New Roman';run.font.size=Pt(14 if style.startswith('Heading') else 12);run.font.color.rgb=RGBColor(0,0,0)
        added.append({'anchor':prefix,'text':text,'style':style});return p
    def replace(prefix,text):
        p=next(p for p in d.paragraphs if p.text.startswith(prefix));assert not p._p.xpath('.//w:drawing')
        old=p.text;p.text=text;changed.append({'old':old,'new':text})
    # Existing thesis and all original figures/tables remain the design authority.
    before('Chapter 3 Research','2.21 Citation support and absent source information','Heading 2')
    before('Chapter 3 Research','ALCE evaluates answer correctness separately from citation quality. Its citation recall asks whether the cited passages support each statement, while citation precision checks for unnecessary citations [36, Section 3.3]. The evaluation uses a learned inference model and human checks, so it is not an exact proof of factual truth. This distinction matters for our reference-locking code: finding a quote in a passage does not establish that the quote entails the generated claim. A source identifier can be correct even when the associated answer is wrong.')
    before('Chapter 3 Research','RAGTruth provides annotated responses with unsupported or conflicting spans and distinguishes missing information from explicit negative information [37, Sections 3.1 and 3.3]. Its analysis supports testing absent fields directly; a missing year or page must not be converted into a guessed value. The authors also leave transfer across datasets and contexts as a limitation [37, Section 8]. Our NERC metadata checks therefore establish only behavior on the declared registry and requests, rather than general hallucination resistance.')
    before('Chapter 3 Research','These studies suggest separating three future tests: whether retrieval finds the right source, whether each answer claim is supported, and whether displayed metadata matches the cited record. The current metadata broker addresses the last question. It is an engineering control based on established attribution principles, not a newly established reasoning capability or a substitute for an independent answer-quality evaluation.')
    before('Chapter 5 Grounded','4.8 Archived NERC serialization and source grouping','Heading 2')
    before('Chapter 5 Grounded','The archived NERC file contains 4,597 strictly parseable JSON-lines question–answer records, 99 additional question–answer objects with a single trailing comma, and 91 other nonblank lines. The latter include 78 lesson headings and 13 other text lines. A separate reader accounted for all 4,787 nonblank lines and confirmed that removing only the terminal comma from the 99 candidate objects gives 4,696 content records in a separate syntax view. The supplied notebook catches JSON decoding errors and continues, so it would skip those 99 records if run on these exact archived bytes. The original file remains unchanged and this candidate view has not been substituted into past experiments.')
    before('Chapter 5 Grounded','The count of 4,696 agrees with the operational subset size reported in the dataset paper, but it does not establish which file was used in its runtime. The strict archived view contains 4,397 questions matching the notebook’s lesson-identifier rule, including 4,340 whose first identifier exists in the reference map. Another 200 strict records do not match the identifier rule. The paper’s 4,396 evaluated records therefore remain unresolved at the identity level; removing one record to force numerical agreement would be unjustified.')
    before('Chapter 5 Grounded','No exact duplicate questions were found in the strict view. There are 112 normalized question-template groups that span more than one lesson identifier, which provides a useful warning for a future split by source document. It does not demonstrate leakage into a historical training or test partition because those complete memberships have not been recovered. The audit retains every record identity, malformed line and source hash, and uses no model inference or retrieval.')
    before('Chapter 6 Multi-agent','5.10 Source metadata checks and the limits of retrieval claims','Heading 2')
    before('Chapter 6 Multi-agent','The adversarial notebook’s saved summary reports an 89.3% failure rate for 28 impossible-metadata requests and a 36% failure rate for 25 out-of-scope requests. Those figures belong to a 200-case summary, but only 11 individual case headers were recovered from the printed outputs. We retain the reported category rates without treating the printed subset as a reconstruction of all 200 decisions.')
    before('Chapter 6 Multi-agent','Controlled checks of selected source functions found six counterexamples without running the original notebooks or a language model. The reference-locking path accepts an answer with an empty claim list and accepts a quote that appears in a source even when it does not support the claim. Its displayed citation can come from the first retrieved document rather than the document named by the claim. A separate metadata detector misses changed page, year and URL values when the context contains some value of the same type. These are source-level failure mechanisms, not new estimates of their prevalence in natural model answers.')
    before('Chapter 6 Multi-agent','An additive broker now loads the exact bytes of the saved 98-entry NERC reference map and returns only registered document identifiers and URLs. It does not infer author, year, page or equation fields from the URL. Fixed checks across every entry produced 392 exact-value responses, 392 explicit missing-field responses and 108 rejections, with four further loader rejection checks. A separate saved-output reader verified every request, returned value and citation. The renderer displays only the requested registered metadata and does not attach a citation to arbitrary generated prose. A registered URL is not evidence that its linked document was retrieved or that it supports an answer.')
    before('Chapter 6 Multi-agent','The broker is tested application software and has not been connected to the complete answering pipeline. It does not resolve semantic answer truth or out-of-scope refusal. The historical RAG scores are consequently treated as reported whole-system results. They do not establish a causal retrieval benefit, because the exact common question membership, runtime index, model revisions and scoring contract are incomplete. A future retrieval-on/off study would hold the model, questions, prompts apart from supplied evidence, decoding and scoring fixed, while charging index construction and retrieval costs separately.')
    replace('The result supports the importance of providing relevant evidence in that configuration.',
      'The manuscript reports stronger results for its retrieval-assisted configuration, but the retained records do not establish a matched causal retrieval comparison. The thesis therefore limits this conclusion to the reported whole-system result. Neither a causal retrieval benefit nor a pure parameter-size effect follows from comparing different information and serving configurations. A future matched study needs the same model revision, questions, scoring and decoding, with retrieval as the declared intervention and complete preparation and retrieval costs retained.')
    # Add verified bibliographic entries without renumbering any prior reference.
    refs=[
      '[36] T. Gao, H. Yen, J. Yu, and D. Chen, “Enabling Large Language Models to Generate Text with Citations,” in Proceedings of EMNLP, 2023, pp. 6465–6488. doi: 10.18653/v1/2023.emnlp-main.398. Available: https://aclanthology.org/2023.emnlp-main.398/',
      '[37] C. Niu et al., “RAGTruth: A Hallucination Corpus for Developing Trustworthy Retrieval-Augmented Language Models,” in Proceedings of ACL, vol. 1, 2024, pp. 10862–10878. doi: 10.18653/v1/2024.acl-long.585. Available: https://aclanthology.org/2024.acl-long.585/']
    for text in refs:
        p=before('Appendix A Experimental',text)
        p.paragraph_format.line_spacing=1
        for run in p.runs:run.font.size=Pt(11)
    assert len(d.inline_shapes)==22 and len(d.tables)==19
    out=O/'Hannaan_Thesis_RAG_And_Lineage_Update.docx';d.save(out)
    evidence=['outputs/nerc_release_lineage_v2_20261029/Release_Lineage_And_Grouping.json','outputs/nerc_release_lineage_v2_20261029/independent_audit_v2/Independent_Lineage_Audit.json','outputs/source_metadata_admission_20261029/Source_Counterexamples_And_Prototype_Check.json','outputs/nerc_reference_metadata_broker_20261029/Result.json','outputs/nerc_reference_metadata_broker_20261029/Independent_Saved_Output_Audit.json','outputs/rag_evaluation_contract_recovery_20261028/Recovered_Evaluation_Contract.json']
    rec={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'AWAITING_RENDER_AND_REVIEW','base':base.relative_to(R).as_posix(),'base_sha256':sha(base),'output':out.relative_to(R).as_posix(),'added':added,'changed':changed,'source_bindings':[{'path':p,'sha256':sha(R/p)} for p in evidence],'references_added':refs,'new_model_PF_training_calls':0,'T14':'AWAITING_REVIEWED_CLAIM_SCOPE','T12_T13':'PARTIAL'}
    (O/'Integration_Record.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n','utf-8')
    ps=(R/'work/paginate_caption_QA_thesis_v2_20261029.ps1').read_text('utf-8-sig').replace('thesis_caption_QA_v2_20261029','thesis_RAG_lineage_20261029').replace('Hannaan_Thesis_Caption_And_QA_Update.docx','Hannaan_Thesis_RAG_And_Lineage_Update.docx')
    (R/'work/paginate_RAG_lineage_thesis_20261029.ps1').write_text(ps,'utf-8')
    print(json.dumps({'added_paragraphs':len(added),'revised_paragraphs':len(changed),'tables':len(d.tables),'figures':len(d.inline_shapes)}))
if __name__=='__main__':main()
