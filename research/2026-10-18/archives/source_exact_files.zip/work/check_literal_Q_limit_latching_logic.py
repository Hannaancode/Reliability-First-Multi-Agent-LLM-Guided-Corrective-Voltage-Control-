"""Labelled mock-inner fixtures for the installed original Q-limit loop.

The real source control routine runs on fabricated arrays. Every nonlinear
solver entry is replaced or blocked; these are software proofs, not PF data.
"""
from pathlib import Path
from datetime import datetime,timezone
from unittest.mock import patch
import importlib,importlib.metadata,json,time
import numpy as np
import pandapower as pp
from pandapower.pypower.idx_bus import BUS_TYPE,REF,PV,PD,QD,VM
from pandapower.pypower.idx_gen import GEN_BUS,PG,QG,QMAX,QMIN,GEN_STATUS,VG
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
OUT=P/'literal_Q_limit_latching_software_proof';assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
mod=importlib.import_module('pandapower.pf.run_newton_raphson_pf')
results=[]
for name in ('one_latched_upper','two_accumulating_limits'):
    bus=np.zeros((3,18));bus[:,0]=np.arange(3);bus[:,BUS_TYPE]=[REF,PV,PV];bus[:,VM]=1.
    gen=np.zeros((3,26));gen[:,GEN_BUS]=np.arange(3);gen[:,GEN_STATUS]=1
    gen[:,PG]=[20,30,40];gen[:,QMAX]=[100,10,10];gen[:,QMIN]=[-100,-10,-10];gen[:,VG]=1.
    branch=np.zeros((0,23));initialpg=gen[:,PG].copy();initialloads=bus[:,[PD,QD]].copy();inner=[];limited_calls=[]
    vals=(100.,bus,gen,branch,*[np.zeros((0,1)) for _ in range(4)],np.array([0]),np.array([1,2]),
          np.array([],dtype=int),np.arange(3),np.ones(3,dtype=complex),np.array([0]))
    def inner_mock(case,options):
        n=len(inner)+1;inner.append(n)
        if n==1:gen[1,QG]=20.
        elif n==2:
            assert gen[1,GEN_STATUS]==0
            bus[1,VM]=1.06
            if name=='two_accumulating_limits':gen[2,QG]=-20.
        else:
            assert name=='two_accumulating_limits' and n==3 and gen[1,GEN_STATUS]==gen[2,GEN_STATUS]==0
            bus[1,VM]=1.06;bus[2,VM]=.97
        return case,True,1
    def solved_mock(case,options,limited):
        limited_calls.append([int(i) for i in limited]);return bus,gen,branch
    with patch.object(mod,'_get_pf_variables_from_ppci',return_value=vals), \
         patch.object(mod,'_run_ac_pf_without_qlims_enforced',side_effect=inner_mock) as actualmock, \
         patch.object(mod,'ppci_to_pfsoln',side_effect=solved_mock), \
         patch.object(pp,'runpp',side_effect=AssertionError('PF forbidden')) as public, \
         patch('pandapower.powerflow._powerflow',side_effect=AssertionError('PF forbidden')) as backend:
        _,success,_,actualbus,actualgen,_=mod._run_ac_pf_with_qlims_enforced({}, {'enforce_q_lims':True})
        assert success and public.call_count==backend.call_count==0
        assert actualmock.call_count==len(inner)==(2 if name=='one_latched_upper' else 3)
    assert actualgen[1,QG]==10. and actualgen[1,GEN_STATUS]==1 and actualbus[1,VM]>actualgen[1,VG]+1e-10
    assert limited_calls[:2]==[[],[1]]
    if name=='two_accumulating_limits':
        assert limited_calls[2]==[1,2] and actualgen[2,QG]==-10. and actualgen[2,GEN_STATUS]==1
        assert actualbus[2,VM]<actualgen[2,VG]-1e-10
    assert np.array_equal(actualgen[:,PG],initialpg) and np.array_equal(actualbus[:,[PD,QD]],initialloads)
    results.append({'fixture':name,'fabricated_array_fixture_only':True,'actual_source_control_function_called':True,
      'mocked_inner_solver_returns':len(inner),'actual_PF_calls':0,'limited_arguments':limited_calls,
      'latched_upper_Q_mvar':float(actualgen[1,QG]),'upper_voltage_pu':float(actualbus[1,VM]),
      'voltage_command_pu':float(actualgen[1,VG]),'original_injections_restored':True})
assert read(P/'OPT_measured_QV_complementarity_audit/Summary.json')['nominal_occupancy_labels_certify_usual_complementarity'] is False
proof={'verified_at_utc':datetime.now(timezone.utc).isoformat(),'installed_pandapower':importlib.metadata.version('pandapower'),
 'exact_local_solver_source_path':str(Path(mod.__file__).relative_to(ROOT)).replace('\\','/'),
 'exact_local_solver_source_sha256':sha(Path(mod.__file__)),'all2_labelled_control_fixtures_passed':True,
 'actual_source_control_calls':2,'mocked_inner_returns':5,'actual_PF_model_optimizer_linear_solve_calls':0,
 'proven_control_behavior':'With enforce_q_lims=True, all violated nonreference generators accumulate in limited and are temporarily disabled; this loop has no release based on voltage crossing back over command',
 'not_original_hidden_modes_causal_history_PF_convergence_or_new_physical_performance':True,
 'fixture_records':results,'elapsed_seconds':time.perf_counter()-start}
write(OUT/'Literal_Control_Logic_Software_Proof.json',proof)
files={'Literal_Control_Logic_Software_Proof.json':OUT/'Literal_Control_Logic_Software_Proof.json',
 'source/fixtures.py':Path(__file__),'source/exact_local_Qlimit_loop.py':Path(mod.__file__)}
archive=seal(OUT,files,'Literal_Qlimit_Latching_Software_Proof.zip')
print(json.dumps({'proof':proof,'archive':archive}))
