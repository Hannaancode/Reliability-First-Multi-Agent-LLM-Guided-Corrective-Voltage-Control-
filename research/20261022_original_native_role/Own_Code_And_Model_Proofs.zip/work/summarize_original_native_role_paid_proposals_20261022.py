"""All4 primary native-role proposals joined to existing paid root evidence.

Read only after the sole model owner and reader have ended. Candidate returns
are not new commits, whole-controller trajectories or an external benchmark.
"""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_reflection_native_role_handoff_20261022'
I = R / 'outputs/original_reflection_first_zone_paid_inventory_v2_20261022'
A = R / 'outputs/original_reflection_saved_root_independent_v2_20261022'
H = R / 'outputs/original_reflection_saved_root_handoff_v2_20261022'


def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    assert (H / 'Completion.json').exists(), 'Actual owner/sole reader/coordinator must all be terminal'
    audit = read(A / 'Independent_Audit.json')
    assert audit['status'] == 'PASS_INDEPENDENT_ORIGINAL_NATIVE_ROLE_MODEL_AND_COLD_SOURCE_COST_AUDIT'
    manifest = read(I / 'Closed_Manifest.json')
    for name, rec in manifest['members'].items():
        assert (I / name).stat().st_size == rec['bytes'] and sha(I / name) == rec['sha256']
    inventory = read(I / 'All144_Declared_Native_Query_Bindings.json')
    index = {(r['root'], r['bus'], r['q_mvar']): r for r in inventory}
    assert len(inventory) == len(index) == 144
    table = []
    for row in audit['primary_lora_and_disabled_base_table']:
        rec = {**row, 'matched_paid_physical_candidate': 'UNKNOWN',
               'new_actual_commit_or_episode': False, 'new_PF_calls': 0}
        if not row['original_source_valid']:
            rec['matched_paid_physical_candidate'] = 'NO_VALID_ORIGINAL_QUERY_OUTPUT'
        else:
            action = row['original_source_action']['add_shunts_q_mvar']
            assert len(action) == 1
            bus, q = next(iter(action.items()))
            paid = index.get((row['root'], int(bus), float(q)))
            assert paid is not None, 'Original output must remain in exact native FIRST_ZONE universe'
            rec['matched_paid_physical_candidate'] = paid['status']
            if paid['status'] == 'BOUND_EXACT_EXISTING_NATIVE_ROOT_QUERY':
                v = paid['original_verification']
                rec.update(initial_UV=v['before']['uv_count'], candidate_UV=v['after']['uv_count'],
                           initial_OV_strict=v['before']['ov_count'], candidate_OV_strict=v['after']['ov_count'],
                           candidate_minVm=v['after']['vmin'], candidate_maxVm=v['after']['vmax'],
                           original_native_verifier_accepted=v['accepted'], original_verifier_reason=v['reason'],
                           normal_upper_tolerance_admissible=paid['normal_upper_tolerance_admissible'],
                           strict_normal_band_restored=paid['strict_0_95_1_05_normal_band_restored'],
                           prior_actual_PF_seconds=paid['prior_actual_PF_seconds'], receipt=paid['receipt'])
        table.append(rec)
    assert len(table) == 4
    O.mkdir(exist_ok=False)
    report = {'at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'COMPLETE_ALL4_ORIGINAL_NATIVE_ROLE_PROPOSALS_AND_PAID_EVIDENCE_DISPOSITIONS',
        'independent_model_gate': audit['fixed_interface_gate'], 'actual_model_costs': audit['actual_costs'],
        'all_primary_proposals': table, 'missing_action_receipts_unknown_not_failed_or_filled': True,
        'source_native1_06_verifier_vs_normal1_05_band_explicit': True,
        'same_state_lora_vs_base_not_a_trajectory_superiority_test': True,
        'new_actual_physical_commit_or_full_v4_run': False,
        'new_model_PF_optimizer_training_calls_by_this_analysis': 0,
        'original137_and_full203_external_comparison': 'UNACHIEVED',
        'model_audit_sha256': sha(A / 'Independent_Audit.json'),
        'paid_inventory_sha256': sha(I / 'All144_Declared_Native_Query_Bindings.json'),
        'source_sha256': sha(Path(__file__))}
    with (O / 'Verified_Native_Role_And_Paid_Proposal_Results.json').open('x', encoding='utf-8') as f:
        json.dump(report, f, indent=2, allow_nan=False); f.flush(); os.fsync(f.fileno())
    with (O / 'Closed_Manifest.json').open('x', encoding='utf-8') as f:
        json.dump({'members': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in O.iterdir() if p.is_file()}}, f, indent=2)
    print(json.dumps(report))


if __name__ == '__main__': main()
