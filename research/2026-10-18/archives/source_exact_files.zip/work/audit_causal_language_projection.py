"""One declared partial projection, OPT only, no model/performance sweep."""
import os
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',
                  OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='')
import ctypes,gzip,json,time,hashlib,copy
from pathlib import Path
from datetime import datetime,timezone
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
from causal_voltage_reactive_language_projection import compile_context,parse_command,canonical,decode
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';OUT=P/'causal_language_projection_readiness'
assert not OUT.exists();OUT.mkdir();started=time.perf_counter()
declaration={'declared_at_utc':datetime.now(timezone.utc).isoformat(),
 'purpose':'Check one current-only V/reactive-constraint view for a future language correction; no training/method selected',
 'fields_selected_before_tokenization':['all118currentVm','all53generator_bus_Q0_Qmin_Qmax_voltage_commands','current_reference_bus_vm_commands','current_global_metrics','raw_common_AND_zone_scope','current_added_shunt_support','original9Qgrid'],
 'mechanistic_justification':'Current Vm and reactive/voltage limits describe local feasibility and source-constraint occupancy; full numerical prior retains network/angles/all physical fields. This is not generator-mode target learning.',
 'partial_projection':True,'omitted_angles_and_other_tables_disclosed':True,
 'same_information_numerical_residual_control_must_receive_identical_decoded_view_AND_prior':True,
 'additional_stronger_full_table_graph_and_physics_prior_controls_required':True,
 'all239OPTinputs_23worlds_retained_no_held_outcome_access':True,
 'single_fixed_template_no_repeated_format_or_prompt_search_if_overflow':True,
 'encoder_source_sha256':sha(ROOT/'work/causal_voltage_reactive_language_projection.py'),
 'original_context4096_outputreserve384_unchanged':True,
 'zero_model_PF_optimizer_controller_derivative_linear_solve_cloud_calls':True}
write(OUT/'Prospective_Interface_Declaration.json',declaration)
def rows(path):
 with gzip.open(path,'rt',encoding='utf-8') as f:return [json.loads(x) for x in f]
B=ROOT/'outputs/llm_value_candidate_development_20261009'
inputs=[x for x in rows(B/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz') if x['split']=='optimization']
support={x['observation_id']:x for x in rows(B/'current_added_support_observables/Current_Control_State_Observables.jsonl.gz')}
assert len(inputs)==239
dll=Path('C:/Users/HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin')
guard=os.add_dll_directory(str(dll));runtime=ctypes.WinDLL(str(dll/'msvcp140.dll'))
from transformers import AutoTokenizer
model=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
for name,h in read(ROOT/'outputs/frozen_input_verification.json')['model_files'].items():
 if 'token' in name or name in ('vocab.json','merges.txt','special_tokens_map.json','adapter_config.json'):assert sha(model/name)==h
tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True,trust_remote_code=False)
records=[];worlds=set();commands_checked=0
for x in inputs:
 ident=x['observation_id'];added=support[ident]['current_added_support_MVAr_by_bus'];compiled=compile_context(x['model_input'],added)
 assert canonical(decode(compiled['encoded']))==canonical(compiled['selected_same_information_input'])
 ids=tokenizer.apply_chat_template(compiled['messages'],tokenize=True,add_generation_prompt=True,return_dict=False,truncation=False)
 selected=compiled['selected_same_information_input'];assert parse_command('null',selected) is None
 for bus in sorted({b for pool in selected['raw_common_and_zone_pools'].values() for b in pool}):
  for j,q in enumerate(selected['original_Q_grid']):
   if added[bus]+q<=450:
    command=canonical({'bus':bus,'Q_index':j});assert parse_command(command,selected)=={'bus':bus,'q_abs_mvar':q};commands_checked+=1
 records.append({'observation_id':ident,'world_sha256':x['world_sha256'],'actual_context_tokens':len(ids),
                 'fits4096_with384reserve':len(ids)+384<=4096,'token_ids_sha256':hashlib.sha256(canonical(ids).encode()).hexdigest(),
                 'selected_payload_sha256':hashlib.sha256(canonical(selected).encode()).hexdigest(),
                 'exact_selected_field_roundtrip':True,'partial_view_not_all_tables':True,'context_sha256':hashlib.sha256(canonical(compiled['messages']).encode()).hexdigest()})
 worlds.add(x['world_sha256'])
# Explicit software reply fixtures; no genuine generation.
fixture=compiled['selected_same_information_input'];checks=[]
for name,text in [('bool_bus','{"bus":true,"Q_index":0}'),('wrong_Q','{"bus":0,"Q_index":9}'),('extra_field','{"bus":0,"Q_index":0,"after":1}'),('float_bus','{"bus":0.0,"Q_index":0}'),('outside_bus','{"bus":118,"Q_index":0}')]:
 try:parse_command(text,fixture)
 except AssertionError:checks.append(name)
 else:raise AssertionError(name)
assert len(worlds)==23 and commands_checked==38501
summary={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'actual_OPT_tokenizer_contexts':239,'OPT_worlds':23,
         'minimum_context_tokens':min(r['actual_context_tokens'] for r in records),'maximum_context_tokens':max(r['actual_context_tokens'] for r in records),
         'fits4096_with384reserve':sum(r['fits4096_with384reserve'] for r in records),'overflow_views_retained':sum(not r['fits4096_with384reserve'] for r in records),
         'all_selected_fields_exactly_preserved':True,'all38501_exact_current_scope_and_Qcap_commands_checked_without_model':True,
         'labelled_fake_reply_rejections':checks,'full_table_information_preserved_in_language_view':False,
         'no_AFTER_receipts_targets_world_branch_IDs_in_forward':True,'no_new_performance_or_training_protocol':True,
         'actual_model_PF_optimizer_controller_derivative_linear_solve_cloud_calls':0,'no_weights_loaded_or_genuine_generation':True,
         'actual_workflow_seconds_before_seal':time.perf_counter()-started,'unexecuted_measurement_source_settings_untouched':True}
write(OUT/'Actual_All239_Projected_Context_Records.json',records);write(OUT/'Actual_Projection_Context_and_Parser_Audit.json',summary)
(OUT/'Projection_Readiness_and_Information_Limits.md').write_text('One fixed causal V/reactive-constraint projection was declared before tokenization. It preserves its selected numerical fields exactly through dictionary and sparse-zero encoding, without rounding. Current angles, line/load/transformer/impedance/active-power tables and other fields are explicitly outside the language view. It is not full-table losslessness, a proved sufficient statistic, Markov completeness or learned benefit.\n\nThe physical numerical prior still uses full current information. A prospective method must supply the identical decoded projection AND numerical prior to strong non-LLM residual controls, and retain stronger full-table/graph/physical controls. Those implementations and performance protocols do not follow from this software test. Generator-regime and other failed studies stay stopped.\n\n'+json.dumps(summary,indent=2)+'\n\nIf any context overflows, retain it and reject this single representation under4096/384 rather than adjust a prompt until a desired outcome. Fit only permits further justified interface work; it does not authorize a model study or establish novelty, pretraining value, D-SE superiority or confirmation. No candidate AFTER receipts or labels are input. All commands here were software fixtures, not genuine model replies.\n',encoding='utf-8')
files={f.name:f for f in OUT.iterdir() if f.is_file()};files['sources/encoder.py']=ROOT/'work/causal_voltage_reactive_language_projection.py';files['sources/auditor.py']=Path(__file__)
archive=seal(OUT,files,'Causal_Projection_Interface_Readiness.zip')
print(json.dumps({'summary':summary,'archive':archive}))
