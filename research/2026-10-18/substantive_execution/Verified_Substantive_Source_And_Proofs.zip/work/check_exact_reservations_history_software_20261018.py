"""Real current-input geometry, MOCK reservation events, strict live history.

No fixture can authorize a native PF call. Actual complete NET/RNG/cursor cold
restoration is covered by the separate passed real engine cold integration.
"""
import argparse,copy,hashlib,json,os,subprocess,time
from pathlib import Path
import pandapower as pp
from full_receding_paid_campaign_20261015 import R,read,put,sha
from exact_new_query_reservations_v1_20261018 import Reservations,UnclosedAttemptCoverage,AlreadyAttemptedIdentity
from paid_receding_chunked_history_v2_20261018 import History,verify_history
from reopen_exact_chunked_history_v1_20261018 import reopen_latest_history
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import load_endpoint
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible
from frozen_physics_loader import load_stack
import paid_receding_referenced_commit_v2_20261018 as transport
B=R/'outputs/exact_reservations_history_SOFTWARE_20261018'
def stack():
    _,runner,_=load_stack();m=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');return runner,m.get('zones',m)
def forbid():
    calls=[]
    def fail(*a,**k):calls.append(True);raise AssertionError('Only MOCK source events, zero native science')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,fail)
    return calls
def cold():
    calls=forbid();runner,zones=stack();d=read(B/'Cold_Request.json')
    reg=Reservations(B/'reservations',protocol=d['protocol'],coverage=d['coverage'],known_attempt_keys=[],runner=runner,zones=zones,restore_anchor=d['anchor'])
    assert reg.states==d['states'] and reg.execution_authorized is False
    key=d['reserved_cold_key'];reg.start(key,PF_id='MOCK2',solver_kwargs=d['protocol']['solver_kwargs'],software_fixture=True)
    reg.closed(key,{'PF_id':'MOCK2','outcome':'SOFTWARE_TEST_ONLY_NO_SOLVER_RETURN'});reg.close()
    history=reopen_latest_history(d['history_anchor']);history.append('SOFTWARE_COLD_RECORD_NO_SCIENCE',{'mock':True});anchor=history.anchor();history.close()
    assert len(verify_history(anchor))==2 and not calls
    put(B/'Cold_Result.json',{'status':'PASS_MOCK_RESERVATION_COLD_AND_STRICT_LATEST_HISTORY_APPEND','new_science':0,'history_anchor':anchor,'original_mock_reservations_restored':True})
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();calls=forbid();runner,zones=stack()
    p=read(R/'outputs/full_receding_paid_campaign_20261015/Protocol.json');entry=p['endpoints'][1]
    net,c,_=load_endpoint(entry);c=transport.initialize(net,build_current_domain(net,c,runner=runner,zones=zones)['expanded_cursor_for_separately_fixed_future_protocol'])
    rows=[r for r in build_current_domain(net,c,runner=runner,zones=zones)['all_declared_original9Q_ordinary_and_owned_joint_identities'] if resource_eligible(r,c)][:2]
    point=point_key(net,c);keys=[point+'|'+action_key(r) for r in rows]
    protocol={'role':'SOFTWARE_FIXTURE_NO_NATIVE_OWNER','solver_kwargs':p['solver_kwargs'],'input_preparation_sha256':'f'*64,
        'exact_new_query_rows':[{'point_action_key':k,'row':r,'role':role} for k,r,role in zip(keys,rows,['WARM_MOCK','COLD_MOCK'])]}
    fixture={'status':'PASS_RELEVANT_SOURCE_CONTRACT_ATTEMPT_COVERAGE','mode':'SOFTWARE_FIXTURE_NO_PF','exact_candidate_keys':keys,'input_preparation_sha256':'f'*64}
    put(B/'Protocol.json',{'role':'SOFTWARE_ONLY_BOUNDARIES_NO_COVERAGE_OR_PF_AUTHORITY','source_sha256':sha(Path(__file__)),'mock_protocol':protocol,'mock_coverage':fixture,'bound_seconds':300,'new_science':0})
    checks={}
    try:Reservations(B/'NEVER_UNKNOWN',protocol=protocol,coverage={'status':'UNKNOWN'},known_attempt_keys=[],runner=runner,zones=zones)
    except UnclosedAttemptCoverage:checks['unknown_coverage_blocks_constructor']=True
    else:raise AssertionError('Unknown coverage accepted')
    try:Reservations(B/'NEVER_OLD',protocol=protocol,coverage=fixture,known_attempt_keys=keys,runner=runner,zones=zones)
    except AssertionError:checks['known_old_identity_blocks_before_native']=True
    else:raise AssertionError('Old key admitted')
    reg=Reservations(B/'reservations',protocol=protocol,coverage=fixture,known_attempt_keys=[],runner=runner,zones=zones)
    assert reg.execution_authorized is False
    reg.reserve(net,c,rows[0],role='WARM_MOCK')
    try:reg.start(keys[0],PF_id='NEVER_NATIVE',solver_kwargs=p['solver_kwargs'])
    except UnclosedAttemptCoverage:checks['mock_certificate_can_never_authorize_actual_PF_start']=True
    else:raise AssertionError('Mock native authorization leaked')
    reg.start(keys[0],PF_id='MOCK1',solver_kwargs=p['solver_kwargs'],software_fixture=True)
    reg.closed(keys[0],{'PF_id':'MOCK1','outcome':'SOFTWARE_TEST_ONLY_NO_SOLVER_RETURN'})
    try:reg.reserve(net,c,rows[0],role='WARM_MOCK')
    except AlreadyAttemptedIdentity:checks['repeated_identity_blocks_before_native']=True
    else:raise AssertionError('Duplicate key admitted')
    reg.reserve(net,c,rows[1],role='COLD_MOCK');anchor=reg.anchor();states=copy.deepcopy(reg.states);reg.close()
    history=History(B/'history',source_anchor=sha(Path(__file__)),input_anchor=sha(B/'Protocol.json'),max_bytes=1024**2)
    history.append('SOFTWARE_WARM_RECORD_NO_SCIENCE',{'mock':True});hanchor=history.anchor();history.close()
    put(B/'Cold_Request.json',{'protocol':protocol,'coverage':fixture,'anchor':anchor,'states':states,'reserved_cold_key':keys[1],'history_anchor':hanchor})
    with (B/'cold_console.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--cold'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);code=child.wait(timeout=180)
    put(B/'Child_Exit.json',{'pid':child.pid,'exit_code':code});assert code==0
    try:Reservations(B/'reservations',protocol=protocol,coverage=fixture,known_attempt_keys=[],runner=runner,zones=zones,restore_anchor=anchor)
    except AssertionError:checks['stale_reservation_cursor_rejected_after_append']=True
    else:raise AssertionError('Stale reservation cursor accepted')
    try:reopen_latest_history(hanchor)
    except ValueError:checks['stale_live_history_reopen_rejected']=True
    else:raise AssertionError('Stale live append accepted')
    assert not calls and time.perf_counter()-started<300
    put(B/'Results.json',{'status':'PASS_MOCK_WRITEONCE_RESERVATIONS_AND_LIVE_HISTORY_COLD_BOUNDARIES','checks':checks,'cold':read(B/'Cold_Result.json'),
        'new_model_PF_optimizer_derivative_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Actual input geometry but explicitly MOCK event/coverage fixtures. No real new-attempt coverage, native engineering authorization or physical outcome. New owner still needs independent genuine coverage/source/reader gates.'})
    print(json.dumps({'mock_reservations_live_history_cold':'PASS','checks':len(checks),'new_science':0,'native_authorization':False}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cold',action='store_true');a=p.parse_args();cold() if a.cold else main()
