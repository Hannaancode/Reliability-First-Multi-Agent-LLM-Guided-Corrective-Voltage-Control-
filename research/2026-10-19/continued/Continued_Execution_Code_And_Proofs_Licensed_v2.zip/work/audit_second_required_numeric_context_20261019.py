"""Unchanged independent derivative/JX/forecast equations plus full-menu join."""
import argparse,ast,json,pickle,zlib
from pathlib import Path
import audit_first_missing_paid_numeric_context_20261018 as original
from second_required_numeric_context_20261019 import B,claim_writer
from public118_slsqp_native_20261018 import R,read,put,sha
def main():
    node=next(n for n in ast.parse(Path(original.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    env=original.__dict__.copy();env.update(B=B,__file__=__file__,put=claim_writer(__file__))
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(original.__file__),'exec'),env);env['main']()
    from dynamic_actual_mask_guidance_v1 import current_inputs,identity
    from compile_lookahead_paid_input_cache_20261014 import action_key
    from shared_original_serving_action_domain_v1 import build_current_domain
    from frozen_physics_loader import load_stack
    p=read(B/'Protocol.json');state=pickle.loads(zlib.decompress((R/p['input_frontier']).read_bytes()));_,runner,_=load_stack()
    meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    rows=build_current_domain(state['net'],state['cursor'],runner=runner,zones=zones)['all_declared_original9Q_ordinary_and_owned_joint_identities']
    expected={p['identity']+'|'+action_key(r) for r in rows if (1 if r['kind']=='ordinary' else 2)<=state['cursor']['remaining_original_device_operation_slots']}
    actual=read(B/'actual/All_Current_Native_Forecasts.json');assert set(actual)==expected and identity(current_inputs(state['net']))==p['identity']
    put(B/'Full_Native_Menu_ACK.json',{'status':'PASS_EXACT_COMPLETE_SOURCE_NATIVE_MENU_NOT_A_FAVORABLE_SUBSET','all_forecast_keys':len(expected),'source_frontier_sha256':sha(R/p['input_frontier']),'new_PF_model_calls':0})
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--reader',action='store_true');a.parse_args();main()
