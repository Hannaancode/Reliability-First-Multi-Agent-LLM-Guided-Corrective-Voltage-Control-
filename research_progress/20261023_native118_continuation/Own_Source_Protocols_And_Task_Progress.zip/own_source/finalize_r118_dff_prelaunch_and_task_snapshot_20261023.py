"""Final prospective source lock and human-facing milestone snapshot, no science."""
import json,re,os
from datetime import datetime,timezone
from r118_dff_missing_continuation_core_20261023 import *

def replace_json(path,value):
    temp=path.with_name(path.name+'.pending')
    with temp.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.flush();os.fsync(f.fileno())
    os.replace(temp,path)

def main():
    assert not E.exists() and not A.exists()
    p=read(P/'Protocol.json');changed=[n for n,h in p['source_hashes'].items() if sha(R/n)!=h]
    assert changed==['work/run_r118_dff_missing_continuation_20261023.py']
    worker=R/changed[0];new=worker.read_text('utf-8')
    old=new.replace("    put(E/'Frozen_Original_Before.json',frozen_checks())\n",'')
    assert hashlib.sha256(old.encode()).hexdigest()==p['source_hashes'][changed[0]]
    (P/'Original_Worker_Before_Prospective_Anchor_Check.py').write_text(old,encoding='utf-8')
    for name in ['Protocol.json','Owner_Protocol.json','Readiness.json']:
        (P/('Initial_'+name)).write_bytes((P/name).read_bytes())
    p['source_hashes'][changed[0]]=sha(worker)
    p['source_hashes']['work/candidate_process_evidence_utils.py']=sha(R/'work/candidate_process_evidence_utils.py')
    replace_json(P/'Protocol.json',p)
    owner=read(P/'Owner_Protocol.json');owner['single_owner']['sha256']=sha(worker);replace_json(P/'Owner_Protocol.json',owner)
    readiness=read(P/'Readiness.json');readiness['protocol_sha256']=sha(P/'Protocol.json');readiness['prelaunch_addendum']='Add fresh nine frozen-original anchors before the new owner enters science, in addition to its after checks. No source controller, physical contract, outcomes or settings changed.';replace_json(P/'Readiness.json',readiness)
    validate_pins(p)
    put(P/'Prelaunch_Lock_Addendum.json',dict(status='PASS_NO_SCIENTIFIC_OWNER_OR_OUTCOMES_EXIST',old_worker_exactly_reconstructed=True,only_change='Fresh original-anchor measurement before entry; no math or scientific setting change.',new_source_sha256=sha(worker),protocol_sha256=sha(P/'Protocol.json'),all_new_scientific_calls=0))
    now=datetime.now(timezone.utc).isoformat();taskfile=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(taskfile)
    progress=[]
    for t in tasks['tasks']:
        main=[s for s in t.get('subtasks',[]) if re.fullmatch(r'G\d+\.\d+',s['id'])]
        done=sum(bool(s.get('completed')) for s in main)
        progress.append(dict(id=t['checklist_id'],priority=t['priority'],task=t['target'],completed_main_milestones=done,total_main_milestones=len(main),milestone_percent=round(100*done/len(main),1),final_goal_completed=False))
    put(P/'Human_Task_Progress_Snapshot.json',dict(at_utc=now,basis='Equal-weight completion of the existing main checklist IDs; supplementary engineering subtasks excluded. Not the fraction of cases solved, winning confidence, or final-goal achievement.',tasks=progress,all6_final_goals='OPEN'))
    put(P/'Exact_Next_State.json',dict(at_utc=now,status='PROSPECTIVE_ALL4_DFF_READY_NOT_YET_LAUNCHED',current_jobs=[],next='Launch the single frozen coordinator once. It owns one primary and only then one partial-aware first-new-return reader.',source='work/coordinate_r118_dff_missing_continuation_20261023.py',protocol_sha256=sha(P/'Protocol.json'),science_seconds=7200,reader_seconds=7200,no_model_GPU_training=True))
    print(json.dumps(dict(status='FINAL_LOCK_PASS',source_hashes=len(p['source_hashes']),tasks=[(r['id'],r['milestone_percent']) for r in progress])))

if __name__=='__main__':main()
