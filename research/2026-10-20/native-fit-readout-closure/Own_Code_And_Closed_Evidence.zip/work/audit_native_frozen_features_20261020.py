"""Onecomplete source/input/frozen/cold/cost reader across all3predeclared nativebody featurearms."""
import os,json,hashlib,time,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native_frozen_feature_preparation_20261020';OUT=ROOT/'outputs/native_frozen_feature_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import numpy as np
    p=json.loads((PREP/'Protocol.json').read_text());inputs=json.loads((PREP/'Causal_Inputs_Only.json').read_text());assert len(inputs)==241;results={};all_features={}
    for arm in p['arms']:
        source=ROOT/'outputs/native_frozen_feature_execution_20261020'/arm;state=json.loads((source/'status.json').read_text());end=json.loads((ROOT/'outputs/native_frozen_feature_coordination_20261020'/arm/'End_ACK.json').read_text());assert end['actual_owned_chain_ended'] and end['exit_code']==0 and state['runtime_released'] and state['all_actual_closed_artifacts_preserved'] and state['remote_exit_code']==0
        study=source/'staged/study';desc=json.loads((source/'remote_closed_descriptor.json').read_text())
        for rel,v in desc['members'].items():assert (study/rel).stat().st_size==v['bytes'] and sha(study/rel)==v['sha256']
        result=json.loads((study/'Results.json').read_text());private=arm=='private_0_5B';expected=482+2*int(private);assert result['status'].startswith('COMPLETE_ALL241') and result['actual_costs']['body_forward_attempts']==result['actual_costs']['body_forward_returns']==expected and result['actual_costs']['model_load_returns']==2 and result['actual_costs']['generation_backward_optimizer_PF_calls']==0
        events=[];previous='0'*64
        for line in (study/'events.jsonl').read_text().splitlines():
            row=json.loads(line);assert row['event']['previous']==previous;previous=hashlib.sha256(json.dumps(row['event'],sort_keys=True,separators=(',',':')).encode()).hexdigest();assert previous==row['sha256'];events.append(row['event'])
        attempts=[e for e in events if e['kind']=='body_forward_attempt'];returns=[e for e in events if e['kind']=='body_forward_return'];assert len(attempts)==len(returns)==expected
        for e in attempts:
            item=inputs[e['id']];assert e['tokens']==e['attention_mask_ones']==item['tokens'] and e['input_ids_sha256']==hashlib.sha256(np.asarray(item['input_ids'],dtype=np.int64).tobytes()).hexdigest()
        for replica in ['primary','cold']:
            assert sorted(e['id'] for e in attempts if e['replica']==replica and not e['zero_path'])==list(range(241));assert json.loads((study/f'{replica}_Immutable_Before.json').read_text())==json.loads((study/f'{replica}_Immutable_After.json').read_text())
        a=np.load(study/'primary_All241_Features.npy');b=np.load(study/'cold_All241_Features.npy');assert a.shape==b.shape==(241,p['models'][arm]['hidden_size']) and a.dtype==b.dtype==np.float32 and np.array_equal(a,b) and np.isfinite(a).all();all_features[arm]=a;results[arm]={'actual_costs':result['actual_costs'],'primary_and_cold_all241_features_bit_exact':True,'hidden_size':a.shape[1],'peak_allocated_bytes':result['peak_allocated_bytes'],'workflow_seconds':result['workflow_seconds'],'source':p['models'][arm]}
    private=ROOT/'outputs/native_frozen_feature_execution_20261020/private_0_5B/staged/study'
    for replica in ['primary','cold']:
        identity=json.loads((private/f'{replica}_Zero_Path_Identity.json').read_text());zero=np.load(private/f'{replica}_Public_Base_Zero_Path.npy');assert np.array_equal(zero,all_features['public_0_5B'][identity['case_id']])
    audit={'status':'PASS_ALL3_NATIVE_CURRENT_ONLY_BODY_FEATURE_COMPLETE_SOURCE_INPUT_MASK_COLD_IMMUTABLE_COST_AUDIT','models':results,'all1448_actual_body_calls_accounted':True,'private05_disabled_path_matches_same_public05_base_on_actual_longest_input':True,'new_model_PF_optimizer_calls':0,'head_fit_and_native_benchmark_not_yet_measured':True,'DEV16_confirmation32_unentered':True,'workflow_seconds':time.monotonic()-start};put(OUT/'Independent_Audit.json',audit);put(OUT/'Closed_Manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}});print('ALL3_NATIVE_FROZEN_REPRESENTATIONS_INDEPENDENT_PASS')
if __name__=='__main__':main()
