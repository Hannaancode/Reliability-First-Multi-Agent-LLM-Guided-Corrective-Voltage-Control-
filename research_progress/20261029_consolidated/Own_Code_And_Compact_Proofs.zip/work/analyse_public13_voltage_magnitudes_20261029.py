"""Human-requested saved-only magnitude/sensitivity analysis; primary scores unchanged."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,statistics
R=Path(__file__).resolve().parents[1];S=R/'outputs/public13_matched_numeric_comparison_20261021/Matched_Comparison_And_Fixed_Decision.json';O=R/'outputs/public13_voltage_magnitude_analysis_20261029'
def main():
    O.mkdir(exist_ok=False);j=json.loads(S.read_text());raw=j['all500_paired_rows'];assert len(raw)==500
    epsilon=1e-8;methods=['our_numerical','safe-ddpg','linear','ddpg'];rows=[];summary={}
    for m in methods:
        rr=[]
        for x in raw:
            a=x['ours'] if m=='our_numerical' else x['native'][m]
            low=max(0.,.95-a['vmin']);high=max(0.,a['vmax']-1.05);worst=max(low,high)
            strict=.95<=a['vmin'] and a['vmax']<=1.05;assert strict==a['full13band']
            rr.append(dict(seed=x['seed'],method=m,strict_fullband=strict,descriptive_common_epsilon_fullband=(worst<=epsilon),vmin=a['vmin'],vmax=a['vmax'],UV=a['UV'],OV=a['OV'],max_UV_shortfall_pu=low,max_OV_excess_pu=high,max_band_distance_pu=worst))
        failures=[x for x in rr if not x['strict_fullband']];near=[x for x in failures if x['descriptive_common_epsilon_fullband']];far=[x for x in failures if not x['descriptive_common_epsilon_fullband']]
        summary[m]=dict(cases=500,strict_fullband=sum(x['strict_fullband'] for x in rr),UV_total=sum(x['UV'] for x in rr),OV_total=sum(x['OV'] for x in rr),
          descriptive_common_epsilon_fullband=sum(x['descriptive_common_epsilon_fullband'] for x in rr),strict_failures_inside_epsilon=len(near),remaining_cases_outside_epsilon=len(far),
          UV_counts_in_near_cases=sum(x['UV'] for x in near),OV_counts_in_near_cases=sum(x['OV'] for x in near),
          maximum_UV_shortfall_pu=max(x['max_UV_shortfall_pu'] for x in rr),maximum_OV_excess_pu=max(x['max_OV_excess_pu'] for x in rr),
          mean_case_max_band_distance_pu=statistics.fmean(x['max_band_distance_pu'] for x in rr),median_case_max_band_distance_pu=statistics.median(x['max_band_distance_pu'] for x in rr),
          near_failure_max_distance_pu=max((x['max_band_distance_pu'] for x in near),default=None),
          far_failure_min_distance_pu=min((x['max_band_distance_pu'] for x in far),default=None))
        rows.extend(rr)
    result=dict(status='DESCRIPTIVE_POSTHOC_COMMON_TOLERANCE_AND_MAGNITUDE_ANALYSIS_PRIMARY_UNCHANGED',at_utc=datetime.now(timezone.utc).isoformat(),
      source=str(S.relative_to(R)).replace('\\','/'),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),epsilon_pu=epsilon,
      epsilon_origin='The same1e-8descriptive boundary used in the closed21October diagnosis; requested by human on29October. One value, no sweep.',
      summaries=summary,rows=rows,primary_gate=j['fixed_gate'],
      interpretation=['Same epsilon applied to every method on all500 identical saved cases.','Strict primary outcomes are retained; no clipped, rounded or edited voltage.','Sensitivity is post hoc, not unused confirmation or a new physical controller result.','Only per-case minimum/maximum magnitudes are used; mean worst-case distance is not total bus-voltage deviation or a full AC/security measure.','Different native information/actuators/guard/stop/training costs remain; no causal LLM claim.'],
      new_model_PF_optimizer_training_calls=0)
    (O/'Results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(summary))
if __name__=='__main__':main()
