"""Independent identity/cost/selection label audit. Solver access is prohibited."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import copy,hashlib,json,math
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/vcsa_development/candidate_label_pilot'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def rank(c):
    before=c['verification']['before'];after=c['verification']['after']
    return (int(after['uv_count']==0),before['uv_count']-after['uv_count'],before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],-abs(c['q_mvar']))
def main():
    protocol=read(OUT/'protocol.json');manifest=read(OUT/'manifest.json');summary=read(OUT/'summary.json')
    assert sha(ROOT/'work/run_vcsa_candidate_label_pilot.py')==protocol['pilot_driver_sha256']
    for name,item in manifest.items():assert sha(OUT/name)==item['sha256'] and (OUT/name).stat().st_size==item['bytes']
    for name,h in protocol['frozen_sources'].items():assert sha(ROOT/name.replace('\\','/'))==h
    assert sha(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json')==protocol['network_sha256']
    def forbidden(*a,**kw):raise AssertionError('No PF call permitted in this independent label audit')
    pp.runpp=forbidden
    v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'))
    zones=read(ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json')['zones']
    worlds=[read(p) for p in (OUT/'worlds').glob('*.json')]
    assert {w['scenario_id'] for w in worlds}==set(protocol['scenario_sha256'])
    expected={e['local_observation_id']:split for split,group in protocol['selections'].items() for e in group}
    rows=[o for w in worlds for o in w['observations']]
    assert len(rows)==len(expected)==48 and {r['local_observation_id'] for r in rows}==set(expected)
    checks=0;replays=0
    for world in worlds:
        assert not world['failure'] and world['source_network_preserved']
        assert world['protocol_sha256']==sha(OUT/'protocol.json')
        assert sha(ROOT/f'work/e/pack/scenarios/federation/{world["scenario_id"]}.json')==protocol['scenario_sha256'][world['scenario_id']]
        for row in world['observations']:
            assert row['split']==expected[row['local_observation_id']] and row['split']!='test'
            if row['status']=='retained_support_negative_world':
                assert not row['full_world_finite'] and row['abstention_target'] and not row['candidate_rows'];continue
            assert row['fresh_state_sha256']==digest(row['fresh_local_measurements'])
            assert row['new_global_graph_input_sha256']==digest(row['global_bus_state'])
            assert all(math.isfinite(v['vm_pu']) for v in row['global_bus_state'].values())
            truth=copy.deepcopy(base)
            truth.res_bus=pd.DataFrame({'vm_pu':{int(b):v['vm_pu'] for b,v in row['global_bus_state'].items()}})
            reports={z:runner.rescue.extract_zone_state_full(truth,z,zones) for z in zones}
            common=runner.rescue.candidate_buses_from_state(truth,zones,reports,[])
            zone=row['zone'];pool=[b for b in runner.get_zone_candidate_buses(truth,zone,zones,reports[zone]) if b in set(common)]
            assert row['scope_bus_pool']==pool
            assert [(c['bus'],c['q_mvar']) for c in row['candidate_rows']]==[(b,float(q)) for b in pool for q in protocol['fixed_Q_values']]
            for candidate in row['candidate_rows']:
                assert candidate['action']=={'add_shunts_q_mvar':{str(candidate['bus']):float(candidate['q_mvar'])}}
                v=candidate['verification'];assert v['before']==row['before_metrics']
                assert candidate['normal_guard_admissible']==bool(v['accepted'] and v.get('after')['vmax']<=1.05+1e-8)
                cost=candidate['actual_candidate_costs'];assert cost['attempts']==cost['returns']+cost['exceptions'];checks+=1
            eligible=[c for c in row['candidate_rows'] if c['normal_guard_admissible']]
            ranked=sorted(eligible,key=rank,reverse=True)
            selected=row['selected_original_score_candidate']
            assert selected==({'bus':ranked[0]['bus'],'q_mvar':ranked[0]['q_mvar']} if ranked else None)
            if selected:
                replay=row['selected_action_replay'];assert replay['passed']
                assert all(abs(replay['metrics'][k]-ranked[0]['verification']['after'][k])<=1e-10 for k in replay['metrics']);replays+=1
        for phase in ['candidate','selected_action_replay']:
            key='actual_candidate_costs' if phase=='candidate' else 'actual_costs'
            costs=[c[key] for r in world['observations'] for c in r['candidate_rows']] if phase=='candidate' else [r['selected_action_replay'][key] for r in world['observations'] if r.get('selected_action_replay')]
            for count in ['attempts','returns','exceptions']:
                assert sum(c[count] for c in costs)==world['actual_PF_costs_by_phase'][phase][count]
    totals={phase:{k:sum(w['actual_PF_costs_by_phase'][phase][k] for w in worlds) for k in ['attempts','returns','exceptions','wall_seconds']} for phase in ['initial','candidate','selected_action_replay']}
    assert totals==summary['actual_PF_costs_by_phase']
    audit={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'passed':True,'manifest_members_verified':len(manifest),
        'exact_observation_identities':48,'world_identities':len(worlds),'candidate_membership_and_cost_checks':checks,
        'original_score_selected_replays_verified':replays,'zero_new_PF_calls':True,'zero_new_model_calls':True,
        'all_frozen_sources_and_network_unchanged':True,'no_test_or_stage3_output_labels':True,
        'no_model_advantage_claim':True,'audit_source_sha256':sha(Path(__file__))}
    with (OUT/'independent_audit.json').open('x') as f:json.dump(audit,f,indent=2)
    print(json.dumps(audit))
if __name__=='__main__':main()
