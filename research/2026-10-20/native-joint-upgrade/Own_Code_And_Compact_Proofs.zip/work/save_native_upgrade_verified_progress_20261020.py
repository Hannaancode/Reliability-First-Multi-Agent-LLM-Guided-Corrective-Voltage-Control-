"""Record closed new physical evidence and prospective native-head upgrade state."""
import json
from datetime import datetime,timezone
from pathlib import Path
from candidate_process_evidence_utils import read,write,sha,seal,frozen_checks
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_upgrade_verified_handoff_20261020'
def main():
    OUT.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    audits=[ROOT/'outputs'/p/'Independent_Audit.json' for p in ['native_action_upgrade_support_independent_20261020','native_full_grid_affine_independent_20261020','native_affine_physics_independent_20261020']]
    assert all(read(p)['status'].startswith('PASS') for p in audits)
    result={'at_utc':now,'status':'INDEPENDENTLY_VERIFIED_NEW_NATIVE_CONTROL_COMPONENT_PROGRESS_NOT_LLM_SUPERIORITY','all6goals':'OPEN','priority_order':['G3','G2','G1','G4','G5','G6'],
      'published_native_support':{'all8_development_seeds':list(range(500,508)),'all24_branches_complete':True,'all24_final_UV':0,'full13bus_restoration':{'stable_DDPG':3,'linear':3,'DDPG':5},'denominator_each':8,'source_done_only_checks_3_controlled_buses':True},
      'stronger_numerical_component':{'all24_frozen_proposals_evaluated':True,'accepted':15,'rejected_new_UV':9,'all13_residual_OV_contexts_safely_restored':True,'independent_development_worlds':5,'full_field_replay_max_delta':0.0,'extra_global_Y_information_and_one_query_disclosed':True,'no_matched_whole_policy_superiority':True},
      'new_actual_costs':{'PF_returns':276,'PF_exceptions':0,'published_agent_module_forwards':708,'checkpoint_loads':216,'dSbus_dV_returns':24,'LU_factorizations':24,'RHS_solves':72,'LP_returns':48,'separate_mock_LP_returns':5,'pretrained_SLM_GPU_optimizer_calls':0},
      'upgrade_stage':'Native bounded joint numerical action head and complete causal paired-token inputs software-ready; actual1.5B loader/gradient/memory/full-checkpoint engineering NOT YET LAUNCHED.',
      'upgrade_inputs':{'all24_current_states':True,'max_complete_tokens':3229,'body_context':4096,'one_body_three_native_actuators':True,'public05_15_token_ID_pairing_verified':True,'no_future_labels_in_forward':True,'native_float64_Q_cursor_fix_before_any_pretrained_call':True},
      'all_new_scientific_owners_and_readers':'ENDED','current_GPU_or_timer':'NONE','audit_anchors':{str(p.relative_to(ROOT)):sha(p) for p in audits},
      'previous_failed_freeform_transfer':'STOPPED;0/3valid,newnativecommandrole;do not prompt/decoder/budget repair/relabel as originalpaperfailure',
      'next_ordered_tasks':['Freeze actual1.5B public-body native-joint-head integration protocol, sources, complete-state CPU validator, full costs and exact ownership gates.','Execute one bounded disposable GPU engineering integration with longest full3229-token input, two updates, complete local moments/scaler/RNG/cursor ACK and exact fresh-model restoration.','Only after actual integration evidence, specify paired public0.5/1.5 and same-information MLP/numerical controls, fixed training/test identities and complete protected trajectories before performance.','Extend relevant reproducible public benchmarks only through native-faithful prospective contracts; retain every failed/partial/unknown outcome.'],
      'claim_limits':['13 corrected contexts are five inspected development worlds, not13independent samples.','All UV was already removed by source policies on this cohort; new component fixes residual OV.','Centralized extra information/query/stopping semantics preclude matched superiority or LLM attribution.','All six final goals and original DSE/federation/severe-case/security targets remain open.']}
    write(OUT/'Verified_Progress.json',result);write(OUT/'Current_Resume.json',result);write(OUT/'Fresh_Frozen_Asset_Checks.json',frozen_checks())
    folders=['native_action_upgrade_preparation_20261020','native_action_upgrade_support_20261020','native_action_upgrade_support_independent_20261020','native_full_grid_affine_preparation_20261020','native_full_grid_affine_gate_20261020','native_full_grid_affine_independent_20261020','native_affine_physics_preparation_20261020','native_affine_physics_support_20261020','native_affine_physics_independent_20261020','native_slm_causal_input_preparation_20261020','native_slm_joint_input_preparation_20261020']
    files={}
    for folder in folders:
        for p in (ROOT/'outputs'/folder).rglob('*'):
            if p.is_file():files[p.relative_to(ROOT).as_posix()]=p
    for pattern in ['*native*upgrade*20261020.py','*native*affine*20261020.py','native_slm*20261020.py','prepare_native_joint_inputs_20261020.py']:
        for p in (ROOT/'work').glob(pattern):files[p.relative_to(ROOT).as_posix()]=p
    for p in OUT.glob('*.json'):files[p.relative_to(ROOT).as_posix()]=p
    seal(OUT,files,'New_Native_Control_And_Upgrade_Evidence.zip')
    header=f'''## Latest verified native-control and model-upgrade progress — {now}

- [x] G3.2g: all24source-policy episodes on eight fixed NEWdevelopment roots independently complete; source3bus stopping removed allUV but full13restoration only3/8stable,3/8linear,5/8DDPG.
- [x] G3.2h: frozen all24global-affine candidates independently replayed; safely corrected ALL13residualOVstates acrossfiveworlds.15accepted/9unsafe proposals rejected, no threshold/objective retuning. Extra globalinformation/query; notmatchedLLM/wholepolicy superiority.
- [x] G4.3a: complete causal nativejointaction input/token/mask/float64cursor software gates passed;max3229tokens. Actual1.5B pretrained integration not yet launched.

Newturn actual276PFreturns/0exceptions,708publishedagentforwards,24derivatives/24LU/72RHS/48LP;0newSLM/GPU/training. AllscientificactorsENDED,notimer. AllsixfinalgoalsOPEN. Resume outputs/native_upgrade_verified_handoff_20261020/Current_Resume.json. Preserve stoppedfreeformtransfer, originalfrozenassets/literalDFF+DFFALT/unchangedDSE/FULLBOTHcosts and alladversepartialUNKNOWN.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=ROOT/rel;p.write_text(header+p.read_text(encoding='utf-8'),encoding='utf-8')
    p=ROOT/'reseacrh progress.txt'
    with p.open('a',encoding='utf-8') as f:f.write('\n'+header+'Limitations:13contexts=fiveworlds; currentgainOVratherthanUV; centralizedextraquery/information; no freshend-to-endSLMclaim. New bounded numerichead is materiallydifferent native adaptation, not rescue of failedfreeformoutputs. Exactfullcosts and closed independent audits are in the resume.\n')
    p=ROOT/'outputs/research_tasks_20261014/Tasks.json';tasks=read(p);tasks['at_utc']=now
    for t in tasks['tasks']:
        if t['checklist_id']=='G3':
            t['current_result']='Eight fixed NEWdevelopment roots/all24source branches independently complete; native globalaffine correction safely resolves13residualOVcontexts, nineunsafe rejected. Notmatchedwholepolicy/LLMsuperiority.'
            for id,description,evidence in [('G3.2g','Complete all24sourcefaithful baseline support episodes and independent physical/cold replay on eight newfixeddevelopmentroots.',str(audits[0].relative_to(ROOT))),('G3.2h','Complete all24frozen affine proposals and independent nonlinear replay retaining every rejection and full cost.',str(audits[2].relative_to(ROOT)))]:
                assert not any(s['id']==id for s in t['subtasks']);t['subtasks'].append({'id':id,'completed':True,'description':description,'evidence':evidence,'verified_at_save':now})
        if t['checklist_id']=='G4':
            t['next']=result['next_ordered_tasks'][0]+' '+result['next_ordered_tasks'][1]
            t.setdefault('subtasks',[]).append({'id':'G4.3a','completed':True,'description':'Complete native causal full3229token jointhead software/context/pairing/cursor gates; no nativepretrainedcall yet.','evidence':'outputs/native_slm_joint_input_preparation_20261020/Readiness.json','verified_at_save':now})
    p.write_text(json.dumps(tasks,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'status':'SAVED_CLOSED_NEW_EVIDENCE','resume':str(OUT/'Current_Resume.json'),'archive':read(OUT/'Local_Archive_Audit.json')}))
if __name__=='__main__':main()
