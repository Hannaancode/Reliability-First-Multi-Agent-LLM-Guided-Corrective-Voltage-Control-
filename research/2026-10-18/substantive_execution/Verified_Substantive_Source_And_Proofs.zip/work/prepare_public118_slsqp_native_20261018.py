"""Freeze ALL3 distinct first-order solver protocol before any new outcome."""
import hashlib,inspect,json,pickle,time
from pathlib import Path
import numpy as np
import scipy,pandapower
from scipy.optimize import _slsqp_py
from scipy.sparse import csr_matrix
from pandapower.pypower.ppoption import ppoption
from pandapower.pypower import opf_setup,opf_consfcn,opf_costfcn,makeYbus,opf_model
from public118_slsqp_native_20261018 import R,B,read,put,sha,prepare_case,split_linear
from audit_public118_native_acopf_reference_20261015 import certify
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();checks=[]
    A=csr_matrix([[1.,2.],[3.,4.],[5.,6.],[7.,8.]])
    E,e,I,i=split_linear(A,np.array([2.,-np.inf,1.,-np.inf]),np.array([2.,4.,np.inf,np.inf]))
    assert np.array_equal(E,[[1.,2.]]) and np.array_equal(e,[2.])
    assert np.array_equal(I,[[5.,6.],[-3.,-4.]]) and np.array_equal(i,[1.,-4.]);checks.append('Exact native linear equality/lower/upper/unbounded translation, no doubled equality')
    for x in [np.array([0.,0.]),np.array([1.,2.]),np.array([-3.,4.])]:
        assert np.array_equal(I@x-i,np.r_[(A@x)[2]-1,4-(A@x)[1]])
    checks.append('Signed SLSQP inequality>=0 equals original finite lower/upper tests')
    bus=np.zeros((2,13));bus[:,0]=[0,1];bus[:,1]=[3,1];bus[:,7]=1;bus[:,11]=1.06;bus[:,12]=.94
    gen=np.zeros((1,10));gen[0,[0,3,4,5,7,8,9]]=[0,100,-100,1,1,100,0]
    branch=np.zeros((1,13));branch[0,[0,1,2,3,5,10,11,12]]=[0,1,.01,.1,100,1,-30,30]
    cost=np.array([[2.,0,0,3,1,2,5.]])
    n={'bus':bus,'gen':gen,'branch':branch,'gencost':cost,'baseMVA':np.array(100.)}
    bp=np.pad(bus,((0,0),(0,4)));gp=np.pad(gen,((0,0),(0,11)));br=np.pad(branch,((0,0),(0,13)))
    assert certify(n,bp,gp,br,5.,5e-6)['all_native_constraints_and_saved_fields_pass'];checks.append('Independent native complex-equation checker accepts exact two-bus zero-flow feasible fixture')
    for role in ['voltage','balance','angle','flow','objective']:
        b=bp.copy();g=gp.copy();l=br.copy();objective=5.
        if role=='voltage':b[1,7]=1.2
        if role=='balance':g[0,1]=1.
        if role=='angle':b[1,8]=40.
        if role=='flow':l[0,13]=1.
        if role=='objective':objective=6.
        assert not certify(n,b,g,l,objective,5e-6)['all_native_constraints_and_saved_fields_pass']
    checks.append('Independent checker rejects each voltage/balance/angle/saved-flow/objective fixture violation')
    old=read(R/'outputs/public118_native_acopf_reference_20261015/Protocol.json');cases=[];case_layouts=[]
    options=ppoption(VERBOSE=0,OUT_ALL=0,OPF_FLOW_LIM=0,OPF_IGNORE_ANG_LIM=False)
    for j,rec in enumerate(old['cases'],1):
        assert sha(R/rec['case'])==rec['raw_sha256'] and sha(R/rec['full_native_ppc_path'])==rec['full_native_ppc_sha256']
        with np.load(R/rec['full_native_ppc_path'],allow_pickle=False) as z:native={k:z[k].copy() for k in z.files}
        t=time.perf_counter();prepared=prepare_case(native,options);f=B/f'Prepared_Case{j}.pkl'
        with f.open('xb') as stream:pickle.dump(prepared,stream,protocol=5)
        assert prepared['angle_constraint_rows']==186
        cases.append({**rec,'prepared_path':f.name,'prepared_sha256':sha(f)})
        E,e,I,i=prepared['linear'];case_layouts.append({'case':rec['case'],'variables':len(prepared['x0']),'angle_rows':prepared['angle_constraint_rows'],
            'linear_equalities':len(e),'linear_inequalities':len(i),'initial_dispatch_sum_MW':prepared['initial_dispatch_sum_MW'],
            'prepared_sha256':sha(f),'actual_model_setup_calls':1,'setup_seconds':time.perf_counter()-t,
            'objective_network_derivative_optimizer_PF_calls':0})
    checks.append('ALL3 full native case layouts344variables/186angle rows/zero-only padding/headroom initialization retained; no numerical outcome inspected')
    put(B/'Readiness.json',{'status':'PASS_SOFTWARE_AND_ALL3_NATIVE_MODEL_LAYOUT_ONLY','checks':checks,'all3_layouts':case_layouts,
        'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'pandapower':pandapower.__version__},
        'new_model_setup_calls':3,'new_optimizer_PF_objective_constraint_derivative_model_calls':0,'workflow_seconds':time.perf_counter()-started})
    files=[Path(__file__),R/'work/public118_slsqp_native_20261018.py',R/'work/audit_public118_slsqp_native_20261018.py',
        R/'work/audit_public118_native_acopf_reference_20261015.py',B/'Readiness.json']
    for mod in [opf_setup,opf_consfcn,opf_costfcn,makeYbus,opf_model,_slsqp_py]:files.append(Path(inspect.getfile(mod)))
    for rec in cases:files.extend([R/rec['case'],R/rec['full_native_ppc_path'],B/rec['prepared_path']])
    def relative(path):return str(path.resolve().relative_to(R))
    protocol={'at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        'status':'FROZEN_BEFORE_NEW_OPTIMIZER_OR_NETWORK_EVALUATION','role':'Different classical native public ACOPF/initialization benchmark, not a PIPS scientific retry or a discrete-shunt/LLM superiority test',
        'selection':'ALL3 originally pinned official PGLib IEEE118 variants in original order, one SLSQP attempt each',
        'cases':cases,'algorithm':'scipy.optimize.minimize(method=SLSQP), analytic full cost and constraint Jacobians, no Hessian or framework patch',
        'maxiter':100,'ftol':1e-9,'objective_positive_scale':100000.,'native_tolerance':5e-6,
        'per_case_bound_seconds':180,'workflow_bound_seconds':600,'reader_bound_seconds':180,'attempts_per_case':1,'retries':0,
        'initialization':prepared['initialization'],'bounds_and_constraints':'Full native generatorP/Q, busVm, referenceVa, all186native angle rows, both-end RATE_A, all118complex balances including shunts; no actuator/limit/objective relaxation',
        'final_selection':'Returned final iterate only, no intermediate/best/checkpoint selection. Exceptions/timeouts/unexecuted/failed feasibility stay explicit; failure is not infeasibility.',
        'fixed_primary_measurement':'Independent native feasible final point under all native constraints. Optimizer convergence flag separate, no global-optimum claim. All3 denominators retained.',
        'economics':'Three model setup calls separately paid and reused; all network/cost/derivative requests/returns/cache and workflow/CPU/preservation costs recorded. Internal SLSQP linear algebra/FLOPs not separately measured.',
        'native_vs_original_voltage':'Native case voltage bands retained. Original.95/1.05 UV/OV counts diagnostic only. No unchanged-DSE, zero-all, fresh LLM, novelty,90percent confidence or unused-confirmation claim.',
        'old_PIPS_status':'All three first-Hessian sparse API exceptions/source/costs preserved and stopped. No PIPS call/retry/patch.',
        'official_algorithm_documentation':'https://docs.scipy.org/doc/scipy/reference/optimize.minimize-slsqp.html',
        'pins':{relative(f):sha(f) for f in files},'independent_reader_sha256':sha(R/'work/audit_public118_slsqp_native_20261018.py')}
    put(B/'Protocol.json',protocol);print(json.dumps({'readiness':'PASS','all3_native_layouts':case_layouts,'new_optimization_or_network_evaluations':0}))
if __name__=='__main__':main()
