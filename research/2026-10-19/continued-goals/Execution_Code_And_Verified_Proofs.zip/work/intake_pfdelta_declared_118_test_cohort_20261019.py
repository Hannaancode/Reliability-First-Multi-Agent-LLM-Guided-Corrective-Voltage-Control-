"""Pinned author data only; fixed held-prefix IDs before outcomes. ZERO science."""
import argparse,hashlib,json,os,shutil,tarfile,time,traceback,urllib.request
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from save_fixed_three_progress_20261019 import atomic
B=R/'outputs/pfdelta_declared_118_test_cohort_20261019'
REV='83dc0437a10079f3eb408f1031786954669f653d'
EXPECTED='afc0dfa76c7b71f4e63aafc90bcdc50640939e251e159ca73ce7a30557b9b959'
SIZE=3762046939
def prepare():
    B.mkdir(exist_ok=False);known=R/'outputs/pfdelta_benchmark_source_review_20261019';selected={}
    assert sha(known/'shuffle_files.tar.gz')=='9db23253c4f37331be9b88d696287eb62f00f088c1c2d6afdce7e1d82154df5c'
    with tarfile.open(known/'shuffle_files.tar.gz','r:gz') as tar:
        for topology in ('n','n-1','n-2'):
            mapping=json.load(tar.extractfile(f'shuffle_files/{topology}/raw_shuffle.json'));assert [int(k) for k in mapping]==list(range(len(mapping)))
            all_ids=[int(mapping[str(i)])+1 for i in range(len(mapping))];assert len(set(all_ids))==len(all_ids)
            selected[topology]=all_ids[-2000:][:8]
    put(B/'Protocol.json',{'status':'FROZEN_DOWNLOAD_AND_INPUT_COHORT_BEFORE_ANY_SAMPLE_VALUES','at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(__file__),'dataset_revision':REV,'archive':'case118.tar.gz','expected_bytes':SIZE,'expected_sha256':EXPECTED,'fixed_nominal_author_test_ids':selected,'nominal_selection':'First8 in author last2000 shuffled feasible test IDs for EACH N/N-1/N-2; exact author source split, no label or voltage selection.24total.','near_limit_selection':'First4 regular JSON archive members in case118/{n,n-1,n-2}/nose/test for EACH topology. Archive order fixed before values, no voltage/status filtering;12total. This is a DEVELOPMENT support cohort, not a full benchmark/unused confirmation.','all_selected_rows_retained_including_failures':True,'license':'CC-BY4.0 dataset; MIT author code, source notices retained.','fixed_download_bound_seconds':900,'max_download_bytes':4*1024**3,'max_extract_file_bytes':5*1024**2,'zero_new_model_PF_OPF_optimizer_derivative_forecast_solve_calls':True,'one_owner_no_auto_retry_or_profile_fallback':True,'purpose':'Find and bind published operating inputs with contingencies/near-limit states; no claim control opportunity, feasibility or model superiority from author labels alone.'})
    print(json.dumps({'cohort_fixed_before_samples':True,'nominal_ids':selected,'near_limit_count':12,'science':0}))
def download():
    p=read(B/'Protocol.json');assert sha(__file__)==p['source_sha256'];assert not (B/'Download_Claim.json').exists();assert shutil.disk_usage(B).free>2*SIZE+100*1024**2
    start=time.perf_counter();put(B/'Download_Claim.json',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'started_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(__file__),'protocol_sha256':sha(B/'Protocol.json'),'mode':'PUBLIC_DATA_TRANSFER_NO_SCIENCE'})
    h=hashlib.sha256();count=0;last=0;url=f'https://huggingface.co/datasets/pfdelta/pfdelta/resolve/{REV}/case118.tar.gz'
    try:
        with urllib.request.urlopen(url,timeout=60) as response,(B/'case118.tar.gz').open('xb') as f:
            while raw:=response.read(4*1024**2):
                assert time.perf_counter()-start<p['fixed_download_bound_seconds'];count+=len(raw);assert count<=p['max_download_bytes'];f.write(raw);h.update(raw)
                if count-last>=64*1024**2:
                    f.flush();os.fsync(f.fileno());atomic(B/'Transfer_Progress.json',{'bytes':count,'expected':SIZE,'elapsed_seconds':time.perf_counter()-start,'scientific_calls':0});last=count
            f.flush();os.fsync(f.fileno())
        assert count==SIZE and h.hexdigest()==EXPECTED;put(B/'Download_Result.json',{'status':'PASS_PINNED_ALL_AUTHOR_ARCHIVE_BYTES_SHA256','bytes':count,'sha256':h.hexdigest(),'workflow_seconds':time.perf_counter()-start,'scientific_calls':0});print('Pinned118archive transfer complete and hash verified')
    except BaseException:
        put(B/'Download_Failure.json',{'traceback':traceback.format_exc(),'bytes_preserved':count,'prefix_sha256':h.hexdigest(),'workflow_seconds':time.perf_counter()-start,'science':0,'no_automatic_retry':True});raise
def extract():
    p=read(B/'Protocol.json');assert read(B/'Download_Result.json')['sha256']==EXPECTED;out=B/'selected36';out.mkdir(exist_ok=False);start=time.perf_counter();normal={t:set(ids) for t,ids in p['fixed_nominal_author_test_ids'].items()};near={t:0 for t in normal};records=[];seen=set()
    with tarfile.open(B/'case118.tar.gz','r|gz') as tar:
        for member in tar:
            parts=PurePosixPath(member.name).parts
            if not member.isfile() or '..' in parts or member.size>p['max_extract_file_bytes']:continue
            chosen=None
            for t,ids in normal.items():
                if len(parts)>=4 and parts[-4:-1]==('case118',t,'raw') and parts[-1].startswith('sample_') and parts[-1].endswith('.json'):
                    try:i=int(parts[-1][7:-5])
                    except ValueError:continue
                    if i in ids:chosen=(t,'nominal',i)
                if len(parts)>=5 and parts[-5:-1]==('case118',t,'nose','test') and parts[-1].endswith('.json') and near[t]<4:
                    chosen=(t,'near_limit',near[t]);near[t]+=1
            if chosen is None:continue
            assert chosen not in seen;seen.add(chosen);raw=tar.extractfile(member).read();name=f'{chosen[0]}_{chosen[1]}_{chosen[2]}.json';(out/name).write_bytes(raw)
            try:data=json.loads(raw);shape={'keys':list(data),'source_per_unit':data.get('per_unit'),'bus_count':len(data.get('bus',{}))};status='JSON_READABLE_NATIVE_SCHEMA_NOT_YET_VALIDATED'
            except BaseException:shape={};status='UNKNOWN_JSON_PARSE_FAILED_RAW_RETAINED'
            records.append({'source_member':member.name,'selected_identity':chosen,'local_file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'status':status,**shape})
    missing=[(t,'nominal',i) for t,ids in normal.items() for i in ids if (t,'nominal',i) not in seen];missing.extend((t,'near_limit',i) for t in near for i in range(near[t],4))
    put(out/'Input_Manifest.json',{'status':'COMPLETE_DECLARED_COHORT_INTAKE' if not missing else 'PARTIAL_DECLARED_COHORT_UNRECOVERED_UNKNOWN','records':records,'missing':missing,'workflow_seconds':time.perf_counter()-start,'native_physics':'NOT_YET_VALIDATED','model_test':'NOT_EXECUTED','scientific_calls':0,'selection_protocol_sha256':sha(B/'Protocol.json')});manifest(out);print(json.dumps({'selected_records':len(records),'missing':missing,'science':0}))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--download',action='store_true');a.add_argument('--extract',action='store_true');args=a.parse_args()
    if args.prepare:prepare()
    elif args.download:download()
    elif args.extract:extract()
