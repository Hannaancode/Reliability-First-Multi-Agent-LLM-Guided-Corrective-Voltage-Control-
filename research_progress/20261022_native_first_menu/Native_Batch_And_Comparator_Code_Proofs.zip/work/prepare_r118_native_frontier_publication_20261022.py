"""Publish prospective batch code/proofs and new comparator source findings."""
import hashlib,json,zipfile
from pathlib import Path
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];O=R/'outputs/r118_native_frontier_publication_20261022'
def main():
    O.mkdir(exist_ok=False)
    source_names=['map_r118_all4_first_round_query_frontier_20261022.py','check_r118_frontier_current_attempt_capsules_20261022.py',
      'run_r118_first_round_missing_only_20261022.py','audit_r118_first_round_missing_only_20261022.py','prepare_r118_first_round_missing_only_20261022.py',
      'coordinate_r118_first_round_missing_only_20261022.py','save_r118_first_round_live_handoff_20261022.py','summarize_verified_r118_first_round_20261022.py',
      'record_published_graph_environment_version_gap_20261022.py','record_compatible_graph_environment_semantics_20261022.py','prepare_graph_source_static_reader_v2_20261022.py',
      'record_compatible_graph_environment_semantics_v2_20261022.py','check_published_graph118_paid_transition_20261022.py',Path(__file__).name]
    paths=[R/'work'/n for n in source_names]
    names=['outputs/r118_all4_first_round_query_frontier_20261022/Frontier_Summary.json','outputs/r118_all4_first_round_attempt_coverage_20261022/Current_Attempt_Coverage.json',
      'outputs/r118_first_round_missing_only_preparation_20261022/Protocol.json','outputs/r118_first_round_missing_only_preparation_20261022/Source_And_Preservation_Readiness.json',
      'outputs/r118_first_round_missing_only_preparation_20261022/Analysis_Lock.json',
      'outputs/published_graph118_environment_source_20261022/Source_Version_Gap.json',
      'outputs/published_graph118_environment_source_20261022/compatible_archived/Static_Reader_V1_Failure.json',
      'outputs/published_graph118_environment_source_20261022/compatible_archived/Compatible_Source_Semantics.json',
      'outputs/published_graph118_paid_transition_20261022/Saved_Transition_And_Cursor_Readiness.json']
    paths.extend(R/n for n in names);members=[]
    pack=O/'Native_Batch_And_Comparator_Code_Proofs.zip'
    with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in paths:
            b=p.read_bytes();assert not any(x.search(b.decode('utf-8')) for x in SECRET)
            name=p.relative_to(R).as_posix();z.writestr(name,b);members.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
    with zipfile.ZipFile(pack) as z:
        assert z.testzip() is None
        for m in members:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
    (O/'Artifact_Index.json').write_text(json.dumps(dict(status='COMPACT_OWN_SOURCE_AND_PROOFS_NOT_RAW_BACKUP',members=members,private_raw_NETs_weights_tokens_and_third_party_environment_source_not_uploaded=True,new_scientific_calls=0),indent=2),encoding='utf-8')
    text='''# Native 118-bus comparison continuation

All four registered severe roots and all 2,034 original first-round DFF queries were mapped in source order before a new batch: 42 exact paid native80 returns can be reused, 1,989 inputs are unexecuted in the named retained scope, and three prior-input/contract collisions remain unknown. A further check covered all 404 current before capsules, including failed and unentered attempts, and found no extra collision among the proposed unexecuted inputs.

The new bounded CPU batch measures only those 1,989 unexecuted identities. Its original nine Q values, 450 MVAr cap, native solver, original verifier and raw strict voltage outcomes are fixed. It performs no initial solve, old physics replay, model inference, training or physical policy commitment. The sole reader follows actual owner exit and verifies first replays only of newly returned queries. Every failed, unsafe, partial and unentered result is retained. Three known contract collisions receive no automatic new call. A first-round menu is not a complete controller endpoint or LLM comparison.

The separate three-GPU frozen-representation experiment is complete and independently audited: private 0.5B linear71.875%, public0.5B59.375%, public1.5B64.583%, numerical75% teacher-action accuracy. Its fixed80% primary gate failed and stops. Private historical training overlap is disclosed; no unused-generalization or physical superiority claim follows.

External graph comparator integration progressed without new physics: a compatible archived author environment revision is now pinned. Its native episode cap is twice the number of generator units plus twice the number of shunts, giving136 for these roots. The author's experiment disables voltage truncation; optional robust-range rejection must not be imposed silently. Saved feedback, complete action-history/distance-cache serialization and the exact next source choice passed on all four paid first-query prefixes. This is same-process serialized cold engineering, not a full trajectory, actual commit or fresh-process certification. Full native and shared-role comparisons still need distinct named protocols because controls and safety differ from HierGrid.

All six final goals remain open. The code pack includes sources, fixed protocols, adverse results and scope proofs. Private raw physical data and weights stay local; this is not a complete raw backup. Use the exact current local resume for fresh process/claim/source checks and never restart or extend an old owner.
'''
    (O/'Results_And_Execution_Scope.md').write_text(text,encoding='utf-8')
    chosen=[pack,O/'Artifact_Index.json',O/'Results_And_Execution_Scope.md',R/'outputs/r118_first_round_missing_only_handoff_20261022/Current_Resume.json']
    files=[]
    for p in chosen:
        b=p.read_bytes();files.append(dict(local=p.relative_to(R).as_posix(),path='research_progress/20261022_native_first_menu/'+p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
    (O/'Publication_Files.json').write_text(json.dumps(files,indent=2),encoding='utf-8')
    print(json.dumps(dict(files_in_pack=len(members),zip_bytes=pack.stat().st_size,publish_files=len(files),new_scientific_calls=0)))
if __name__=='__main__':main()
