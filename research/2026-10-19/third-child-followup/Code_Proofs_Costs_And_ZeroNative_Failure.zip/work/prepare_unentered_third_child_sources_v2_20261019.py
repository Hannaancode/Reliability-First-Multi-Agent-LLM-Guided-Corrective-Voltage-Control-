"""New prospective namespace for all4 proven-unentered native identities.

Enrich metadata only, preserve the old terminal failure and test the exact
original warm-state constructor including its negative control before science.
"""
import ast,copy,hashlib,json,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from strict_saved_native_input_match_v2_20261018 import require_same

def main():
    diag=R/'outputs/third_child_zero_native_diagnosis_20261019/Independent_Diagnosis.json'
    assert read(diag)['status']=='PASS_TERMINAL_SOURCE_METADATA_FAILURE_BEFORE_RESERVATION_OR_PF'
    oldi=R/'outputs/third_child_fixed_four_followup_input_20261019';newi=R/'outputs/unentered_third_child_fixed_four_followup_input_v2_20261019';newi.mkdir(exist_ok=False)
    encoded=(oldi/'Exact_Current_Input.zlib').read_bytes();raw=zlib.decompress(encoded);old=pickle.loads(raw);assert 'source_edge' not in old
    new=copy.deepcopy(old);new['source_edge']={'role':'FIRST_MISSING_K4_CELL_OF_UNCHANGED_READONLY_POLICY','source_screen':'outputs/resumed16_next_fifth_context_20261019','raw_frontier_sha256':hashlib.sha256(raw).hexdigest(),'prior_costs':'All archived prefix/query/numeric/model/training/preparation/failure costs retained, not free. Original zero-native metadata failure remains preserved; no executed call repeated.'}
    require_same(old['net'],new['net']);assert old['cursor']==new['cursor']
    for k in old:
        if k!='net':assert old[k]==new[k]
    nraw=pickle.dumps(new,5);nenc=zlib.compress(nraw,6);(newi/'Exact_Current_Input.zlib').write_bytes(nenc)
    cell=read(oldi/'Exact_Current_Cell.json');cell['current_input']={'path':str((newi/'Exact_Current_Input.zlib').relative_to(R)),'raw_sha256':hashlib.sha256(nraw).hexdigest(),'encoded_sha256':hashlib.sha256(nenc).hexdigest()}
    put(newi/'Exact_Current_Cell.json',cell);put(newi/'Exact_Candidate_Inputs.json',read(oldi/'Exact_Candidate_Inputs.json'))
    proof={'status':'PASS_METADATA_ONLY_EXACT_NATIVE_NET_CURSOR_AND_ALL_OLD_FIELDS','original_input_sha256':sha(oldi/'Exact_Current_Input.zlib'),'new_input_sha256':sha(newi/'Exact_Current_Input.zlib'),'only_added_key':'source_edge','old_zero_native_diagnosis_sha256':sha(diag),'old_failure_preserved':True,'all4_native_identities_unchanged_and_unentered':True,'old_budget_or_owner_restarted':False,'new_scientific_calls':0,'source':str(Path(__file__).relative_to(R)),'source_sha256':sha(__file__)}
    put(newi/'Source_And_Input_Binding.json',proof)
    pairs=[('third_child_fixed_four_followup_core_20261019.py','unentered_third_child_fixed_four_followup_core_v2_20261019.py'),('run_third_child_fixed_four_followup_20261019.py','run_unentered_third_child_fixed_four_followup_v2_20261019.py'),('audit_third_child_fixed_four_followup_20261019.py','audit_unentered_third_child_fixed_four_followup_v2_20261019.py'),('certify_third_child_fixed_four_followup_20261019.py','certify_unentered_third_child_fixed_four_followup_v2_20261019.py'),('prepare_third_child_fixed_four_followup_20261019.py','prepare_unentered_third_child_fixed_four_followup_v2_20261019.py')]
    replacements=[('third_child_fixed_four_followup_core_20261019','unentered_third_child_fixed_four_followup_core_v2_20261019'),('third_child_fixed_four_followup_acquisition_20261019','unentered_third_child_fixed_four_followup_acquisition_v2_20261019'),('third_child_fixed_four_followup_input_20261019','unentered_third_child_fixed_four_followup_input_v2_20261019'),('run_third_child_fixed_four_followup_20261019','run_unentered_third_child_fixed_four_followup_v2_20261019'),('audit_third_child_fixed_four_followup_20261019','audit_unentered_third_child_fixed_four_followup_v2_20261019'),('certify_third_child_fixed_four_followup_20261019','certify_unentered_third_child_fixed_four_followup_v2_20261019'),('prepare_third_child_fixed_four_followup_20261019','prepare_unentered_third_child_fixed_four_followup_v2_20261019')]
    for before,after in pairs:
        s=(R/'work'/before).read_text('utf-8')
        for a,b in replacements:s=s.replace(a,b)
        if before.startswith('certify_'):
            a="assert sha(source/cell['source_frontier']['path'])==cell['current_input']['encoded_sha256']"
            b="""assert sha(source/cell['source_frontier']['path'])==cell['source_frontier']['encoded_sha256']
    original=pickle.loads(zlib.decompress((source/cell['source_frontier']['path']).read_bytes()))
    require_same(original['net'],state['net']);assert original['cursor']==state['cursor']
    assert set(state)==set(original)|{'source_edge'}
    for name in original:
        if name!='net':assert original[name]==state[name]
    diag=R/'outputs/third_child_zero_native_diagnosis_20261019/Independent_Diagnosis.json'
    assert read(diag)['actual_primary_replay_intents_returns_exceptions']==0 and read(diag)['all4_queries_unentered']
    files += [diag,R/'work/diagnose_third_child_zero_native_20261019.py',R/'work/prepare_unentered_third_child_sources_v2_20261019.py']"""
            assert s.count(a)==1;s=s.replace(a,b)
        if before.startswith('prepare_'):
            anchor="        h=helpers(__file__);fixtures={}"
            extra="""
        import ast
        import exact_two_paid_query_engineering_20261018 as original_worker
        tree=ast.parse(Path(original_worker.__file__).read_text('utf-8'))
        worker=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worker')
        assignment=next(n for n in ast.walk(worker) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='state' for t in n.targets) and isinstance(n.value,ast.Dict))
        exact_code=compile(ast.Module(body=[assignment],type_ignores=[]),str(original_worker.__file__),'exec')
        contract=h.copy();contract.update(source=h['input_state'](),p=protocol)
        exec(exact_code,contract);assert contract['state']['source_edge']==contract['source']['source_edge']
        require_same(contract['state']['net'],contract['source']['net']);assert contract['state']['cursor']==contract['source']['cursor']
        negative=h.copy();negative.update(source={k:v for k,v in contract['source'].items() if k!='source_edge'},p=protocol)
        try:exec(exact_code,negative)
        except KeyError as error:assert error.args==('source_edge',)
        else:raise AssertionError('Missing provenance must fail before any reservation/PF')
        put(B/'Exact_Actual_Warm_State_Construction.json',{'status':'PASS_ORIGINAL_STATE_ASSIGNMENT_AND_MISSING_METADATA_NEGATIVE_CONTROL','actual_original_AST_assignment':ast.dump(assignment,include_attributes=False),'native_NET_cursor_unchanged':True,'new_scientific_calls':0})
"""
            assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
        target=R/'work'/after;assert not target.exists();ast.parse(s);target.write_text(s,encoding='utf-8')
    print(json.dumps({'metadata_equivalence':'PASS','new_science':0,'all4_physical_outcomes':'UNKNOWN','no_old_restart':True}))

if __name__=='__main__':main()
