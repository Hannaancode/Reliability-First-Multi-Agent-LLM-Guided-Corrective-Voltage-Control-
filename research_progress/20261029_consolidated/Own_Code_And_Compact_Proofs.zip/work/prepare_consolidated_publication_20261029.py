from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parents[1];O=R/'outputs/consolidated_publication_20261029'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    O.mkdir(exist_ok=False)
    source=[
      'work/analyse_public13_voltage_magnitudes_20261029.py','work/audit_public13_voltage_magnitudes_20261029.py',
      'work/prove_external_dqn_bellman_contract_20261029.py','work/audit_external_dqn_bellman_contract_20261029.py',
      'work/remaining85_saved_mechanism_20261029.py','work/remaining85_prepare_nonlinear_spec_20261029.py',
      'work/remaining85_nonlinear_kernel_20261029.py','work/remaining85_check_nonlinear_kernel_20261029.py',
      'work/integrate_thesis_citations_20261029.py','work/audit_current_thesis_content_20261029.py',
      'work/rebind_cited_thesis_index_20261029.py','work/save_consolidated_research_checkpoint_20261029.py',
      'work/prepare_consolidated_publication_20261029.py',
      'outputs/public13_voltage_magnitude_analysis_20261029/Results.json','outputs/public13_voltage_magnitude_analysis_20261029/Independent_Arithmetic_Check.json',
      'outputs/common118_external_bellman_contract_20261029/Source_Contract_Proof.json','outputs/common118_external_bellman_contract_20261029/Independent_Audit.json','outputs/common118_external_bellman_contract_20261029/Research_Decision.json',
      'outputs/remaining85_mechanism_review_20261029/Remaining85_Taxonomy.json','outputs/remaining85_mechanism_review_20261029/New_Kernel_Algebra_Source_Check.json',
      'outputs/remaining85_mechanism_review_20261029/All500_Nonlinear_Preparation_Input_Manifest.json',
      'outputs/remaining85_mechanism_review_20261029/LLM_Contribution_Readiness_From_Inspected_Records.json',
      'outputs/remaining85_mechanism_review_20261029/Distinct_Mechanism_And_First_Measurement.json',
      'outputs/remaining85_mechanism_review_20261029/Prospective_Launch_Gates.json','outputs/remaining85_mechanism_review_20261029/Report.txt',
      'outputs/task_completion_criteria_review_20261029/Independent_Review.json',
      'outputs/thesis_current_comparison_20261029/Independent_Content_Fields_And_Index_Check.json',
      'outputs/thesis_citations_integrated_20261029/Independent_Citation_Integration_Check.json',
      'outputs/thesis_citation_reconciliation_20261029/citation_reconciliation.json',
      'outputs/thesis_citation_reconciliation_20261029/bibliography_additions.txt',
      'outputs/thesis_citation_reconciliation_20261029/integration_notes.txt',
      'outputs/consolidated_research_checkpoint_20261029/Exact_Resume.json']
    rows=[]
    for s in source:
        p=R/s;raw=p.read_bytes();assert len(raw)<3_000_000
        assert p.suffix in {'.py','.json','.txt'}
        # Explicit allow-list only: never traverse model/NET/source-paper trees.
        rows.append(dict(path=s,bytes=len(raw),sha256=sha(raw)))
    z=O/'Own_Code_And_Compact_Proofs.zip'
    with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as f:
        for s in source:f.write(R/s,s)
    with zipfile.ZipFile(z) as f:
        assert f.testzip() is None and f.namelist()==source
        for x in rows:assert sha(f.read(x['path']))==x['sha256']
    put(O/'Artifact_Index.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),members=rows,pack_bytes=z.stat().st_size,pack_sha256=sha(z.read_bytes()),
      scope='Own code and compact generated evidence only. No private weights, full NETs, thesis DOCX, credentials, raw GPU transcripts or third-party full sources. Not a complete raw backup.'))
    for src,dst in [('outputs/thesis_research_closure_20261028/Tasks.json','Thesis_Checklist.json'),('outputs/research_tasks_20261014/Tasks.json','Research_Tasks.json'),('outputs/consolidated_research_checkpoint_20261029/Exact_Resume.json','Exact_Resume.json')]:shutil.copy2(R/src,O/dst)
    (O/'Verified_Progress.txt').write_text('27 of35 scoped thesis checklist requirements are independently closed. Six final research goals remain open. The bounded larger-model comparison is complete with adverse results; conditional G4.3 remains open.\n\nThe user-requested common1e-8 p.u. allowance is applied identically to all four saved500-case controller cohorts: our numerical415,SafeDDPG262,linear258,DDPG363 whole-band cases. Raw values and historical strict264/500 are unchanged. This is retrospective engineering analysis, not LLM superiority or unused confirmation.\n\nAll85 remaining cases are actual guard-rejected candidates. Saved affine predictions satisfy the guard while actual returns harm previously normal buses; prediction error dominates float32 action rounding. New nonlinear AC residual adapter passed one unsolved algebra/source fixture only. No optimizer or performance result; all500 source/options/state/ownership/cost/reader gates still required.\n\nThesis now71 unique references,23tables,22figures; all57 source-paper references accounted for,11 tangential/unverified entries excluded or deferred. PDF/pagination is delegated to the user. No GPU allocation or new physical/model/training calls in this consolidation.\n',encoding='utf-8')
    names=['Artifact_Index.json','Own_Code_And_Compact_Proofs.zip','Thesis_Checklist.json','Research_Tasks.json','Exact_Resume.json','Verified_Progress.txt']
    pub=[]
    for n in names:
        p=O/n;b=p.read_bytes();pub.append(dict(local=p.relative_to(R).as_posix(),path='research_progress/20261029_consolidated/'+n,bytes=len(b),sha256=sha(b),blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
    put(O/'Prepared_Files.json',dict(files=pub));print(json.dumps(dict(files=len(pub),members=len(rows),pack_bytes=z.stat().st_size,total_publish_bytes=sum(x['bytes'] for x in pub))))
if __name__=='__main__':main()
