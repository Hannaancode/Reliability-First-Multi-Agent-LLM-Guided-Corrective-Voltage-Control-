"""Name the new contract receipts accurately before any scientific entry."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];P=R/'outputs/r118_remaining_native80_contracts_preparation_20261022'
assert not (R/'outputs/r118_remaining_native80_contracts_execution_20261022').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf-8')
protocol=json.loads((P/'Protocol.json').read_text('utf-8'))
(P/'Template_Protocol_Prelaunch_Copy.json').write_bytes((P/'Protocol.json').read_bytes())
for role in ['run','audit']:
    source=R/f'work/{role}_r118_remaining_native80_contracts_20261022.py';text=source.read_text('utf-8')
    (P/(role+'_Template_Prelaunch_Copy.txt')).write_bytes(source.read_bytes())
    source.write_text(text.replace('GRAPH','NATIVE80_CONTRACT').replace('graph','native80_contract'),encoding='utf-8')
    protocol['source_hashes'][source.relative_to(R).as_posix()]=sha(source)
save(P/'Protocol.json',protocol)
for n in ['Owner_Protocol.json','Reader_Owner_Protocol.json']:
    v=json.loads((P/n).read_text('utf-8'));v['single_owner']['sha256']=sha(R/v['single_owner']['source']);save(P/n,v)
v=json.loads((P/'Source_And_Preservation_Readiness.json').read_text('utf-8'));v['protocol_sha256']=sha(P/'Protocol.json');save(P/'Source_And_Preservation_Readiness.json',v)
save(P/'Prelaunch_Receipt_Label_Clarification.json',dict(status='NATIVE_DFF80_CONTRACT_MEASUREMENTS_NOT_GRAPH_POLICY',
    change='Only template output labels/prints were named correctly before scientific entry; no equations, fields, thresholds or targets changed.',
    prior_template_protocol_preserved=True,new_PF_model_calls=0,final_protocol_sha256=sha(P/'Protocol.json')))
