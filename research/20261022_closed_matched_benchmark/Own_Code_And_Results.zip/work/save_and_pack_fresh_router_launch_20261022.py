"""Save the exact live source chain and publishable closed evidence snapshot."""
import hashlib,json,zipfile,os
from datetime import datetime,timezone
from pathlib import Path
from coordinate_native_inverter_linear_reference_20261020 import process
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME,TEXT
from public13_fresh_router_engine_20261022 import R,P,PRIMARY,READER,read,sha,put
O=R/'outputs/public13_fresh_router_live_handoff_20261022'
B=R/'outputs/closed_benchmark_publication_20261022';S=B/'snapshot'

def mutable(path,v):Path(path).write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')

def main():
    O.mkdir(exist_ok=False);S.mkdir(parents=True,exist_ok=False)
    p=read(P/'Protocol.json');now=datetime.now(timezone.utc).isoformat()
    owners={}
    for role,folder,source in [('scientist',PRIMARY,'work/run_public13_fresh_router_20261022.py'),('coordinator',R/'outputs/public13_fresh_router_handoff_20261022','work/coordinate_public13_fresh_router_20261022.py')]:
        claim=read(folder/'owner.claim');actual=process(claim['actual_pid']);parent=process(claim['parent_pid'])
        assert actual and parent and actual['ParentProcessId']==claim['parent_pid'] and Path(source).name in actual['CommandLine'] and claim['source_sha256']==sha(R/source)
        owners[role]=dict(claim=claim,actual_process=actual,parent_process=parent,source=source)
    live=dict(at_utc=now,status='GENUINE_FRESH128_ROUTING_PRIMARY_LIVE_NO_PERFORMANCE_RESULT',owners=owners,exec_session=8529,
        protocol_sha256=sha(P/'Protocol.json'),frozen_engine_sha256=sha(R/'work/public13_fresh_router_engine_20261022.py'),science_seconds=7200,first_reader_seconds=7200,
        current_GPU=None,no_waiting_timer_yet_parallel_publication_ready=True,
        actual_preparation_checkpoint_reads=9,new_scientific_calls_in_preparation=0,
        original_NUM500_fixed_gate='FAIL',original_private_adapter_native_interface='FAIL_0_OF6_VALID_NOT_ORIGINAL_PAPER_SCORE',same_base_disabled_control='0_OF6_VALID_DIAGNOSTIC',
        saved496of500_not_new_controller_score=True,all6finalgoals='OPEN',
        next=['Do not change live source/settings/bounds or duplicate owners/readers. Sole coordinator owns first reader after actualend/exit0/closedmanifest.',
              'Inspect actual primary/reader End_ACK/closedmanifest and fixed comparison only at genuine completion. Partial keeps all128 gateUNKNOWN.',
              'Preserve original native/public/private-model/source/reader failures and original DSEboth-branch/full costs. No performance rescue retunes.',
              'Verify GitHub snapshot with fresh lease and all uploaded bytes. Compact evidence excludes private weights/NET/checkpoints and thirdparty source.',
              'Use one estimated waiting check only when this live result is sole dependency and useful parallel tasks are exhausted; no recurring monitors.'])
    put(O/'Verified_Actual_Live_Checkpoint.json',live)
    cp=R/'outputs/full_system_comparison_20261021/Current_Resume.json';current=read(cp)
    current.update(at_utc=now,status=live['status'],current_single_scientific_owner=owners['scientist'],current_sole_coordinator=owners['coordinator'],current_single_independent_reader=None,current_waiting_check=None,timers=[],current_GPU='No ownedGPU; current new control study runs onCPU.',latest_resume=(O/'Verified_Actual_Live_Checkpoint.json').relative_to(R).as_posix(),next_ordered_tasks=live['next'],next_dependency='Sole new128primary followed by pinned first reader and fixed comparison; sources/settings/bounds immutable.')
    mutable(cp,current)
    tp=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(tp);tasks.update(updated_at_utc=now,latest_resume=cp.relative_to(R).as_posix())
    g3=next(v for v in tasks['tasks'] if v['checklist_id']=='G3');g3.update(status=live['status'],current_result='NUM500primarygateFAIL; LoRAnative0/6andbasecontrol0/6stopped. New128actualsix-arm inputrouter study is genuinelylive, not a result.')
    t=next(v for v in g3['subtasks'] if v['id']=='G3.3b_20261022');t.update(completed=False,evidence=(O/'Verified_Actual_Live_Checkpoint.json').relative_to(R).as_posix(),status='ACTUAL_PRIMARY_LIVE_NO_VERIFIED_OUTCOMES')
    g3['subtasks'].append(dict(id='G3.3b1_20261022',completed=True,description='Freeze128exactinput/source/cost/ownership/partial-aware-first-reader protocol;19mockchecks plusactualsavednativeNET/separatepolicybank/RNG/cursor negatives,9paidcheckpointreads,0science.',evidence=(P/'Independent_Launch_Review.json').relative_to(R).as_posix(),verified_at_save=now))
    mutable(tp,tasks)
    ep=R/'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json';ex=read(ep);ex.update(updated_at_utc=now,status=live['status'],current_single_scientific_owner=owners['scientist'],current_sole_coordinator=owners['coordinator'],current_single_independent_reader=None,current_waiting_check=None,latest_resume=cp.relative_to(R).as_posix());mutable(ep,ex)
    header=f'''## Fresh128 actual routing study live — {now}

One newCPUscientist actual{owners['scientist']['claim']['actual_pid']}/parent{owners['scientist']['claim']['parent_pid']} and solecoordinator actual{owners['coordinator']['claim']['actual_pid']}/parent{owners['coordinator']['claim']['parent_pid']}, exec8529, fixed7200science/7200firstreader/8GiB, no extensions/restarts/source edits. All128newsource-seeds1000..1127/sixarms, causal initialrouteplans and separate mutablepolicybanks. Sole reader checks newPF/nativeactors once, dense/dual/math/source/cold/continuous/cost/frozen evidence; fixed full128gate only after true complete audit. All planned counts are not results. No GPU/newLLM/training.

Previous completedNUM500superioritygateFAIL (264vsDDPG363fullband); newnativeprivateLoRA0/6 and disabledcontrol0/6 command validity remain stopped and are not the original federation-paper score. Saved496/500 complementary branches are posthoc, not this actual study orLLMadvantage. Nine state-fixture checkpointreads/19labelledmockchecks paid,0newscience inpreparation. Resume {str((O/'Verified_Actual_Live_Checkpoint.json').relative_to(R)).replace(chr(92),'/')}. All six final goals OPEN; preserve original frozenassets/literalDSE/FULLBOTH and all adverse/partial/UNKNOWN evidence.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        path=R/rel;path.write_bytes(header.encode('utf-8')+path.read_bytes())
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+header)
    closed=R/'outputs/verified_benchmark_model_and_router_state_20261022'
    files=[]
    codes=['save_closed_benchmark_model_and_router_state_20261022.py','plot_verified_public13_comparison_20261022.py','prove_paper_uv_stop_public13_ceiling_20261021.py','audit_paper_uv_stop_public13_ceiling_20261021.py',
        'native13_fullband_hybrid_contract_20261021.py','prepare_native13_fullband_original_adapter_engineering_20261021.py','freeze_native13_fullband_original_adapter_engineering_20261021.py','audit_native13_fullband_engineering_launch_20261021.py',
        'run_native13_fullband_original_adapter_colab_20261021.py','run_native13_fullband_lora_remote_20261021.py','native13_fullband_lora_guardian_20261021.py','coordinate_native13_fullband_original_adapter_engineering_20261021.py','audit_native13_fullband_original_adapter_engineering_20261021.py','certify_closed_fullband_model_reader_artifacts_v2_20261021.py',
        'prepare_native13_adapter_disabled_diagnostic_20261021.py','audit_native13_adapter_disabled_launch_20261021.py','run_native13_adapter_disabled_remote_20261021.py','native13_adapter_disabled_guardian_20261021.py','run_native13_adapter_disabled_colab_20261021.py','coordinate_native13_adapter_disabled_diagnostic_20261021.py','audit_native13_adapter_disabled_diagnostic_20261021.py','audit_native13_adapter_disabled_diagnostic_v2_20261021.py',
        'analyze_closed_public13_expert_complementarity_20261021.py','prepare_public13_fresh_input_router_v2_20261021.py','audit_public13_fresh_router_input_recipes_20261021.py',
        'public13_fresh_router_engine_20261022.py','run_public13_fresh_router_20261022.py','audit_public13_fresh_router_20261022.py','test_public13_fresh_router_software_20261022.py','prepare_public13_fresh_router_execution_20261022.py','compare_public13_fresh_router_20261022.py','coordinate_public13_fresh_router_20261022.py','review_public13_fresh_router_launch_20261022.py','save_and_pack_fresh_router_launch_20261022.py']
    files += [R/'work'/n for n in codes]
    dirs=['public13_matched_numeric_comparison_20261021','paper_uv_stop_public13_ceiling_20261021','native13_fullband_model_terminal_artifact_certification_v2_20261021','native13_adapter_disabled_diagnostic_independent_v2_20261021','public13_expert_complementarity_development_20261021','public13_fresh_input_router_preparation_v2_20261021','verified_benchmark_model_and_router_state_20261022','public13_fresh_router_execution_preparation_20261022','public13_fresh_router_live_handoff_20261022']
    for directory in dirs:
        files += [v for v in (R/'outputs'/directory).iterdir() if v.is_file() and v.suffix.lower() in {'.json','.md','.png','.svg'}]
    files += [R/'outputs/public13_matched_numeric_independent_20261021/Independent_Audit.json',R/'outputs/native13_fullband_original_adapter_engineering_independent_20261021/Independent_Functional_Audit.json',R/'outputs/public13_fresh_router_software_checks_v2_20261022/Software_Checks.json']
    for folder in ['native13_fullband_original_adapter_engineering_execution_20261021','native13_adapter_disabled_diagnostic_execution_20261021']:
        for prefix in ['primary','cold']:files += list((R/'outputs'/folder/'staged/study').glob(prefix+'_Agent_*.json'))
    # No weights/NETs/full checkpoints or immutable tensor-value JSON exports.
    files=sorted(set(files));assert all(f.exists() for f in files)
    manifest={}
    for f in files:
        assert not SECRET_NAME.search(f.name) and f.suffix.lower() not in {'.pkl','.pt','.pth','.safetensors'}
        raw=f.read_bytes()
        if f.suffix.lower() in TEXT:assert not any(rule.search(raw.decode('utf-8')) for rule in SECRET),f.name
        manifest[f.relative_to(R).as_posix()]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    package=S/'Own_Code_And_Results.zip'
    with zipfile.ZipFile(package,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in files:z.write(f,f.relative_to(R).as_posix())
        z.writestr('EXACT_MEMBER_HASHES.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(package) as z:
        assert z.testzip() is None and len(z.namelist())==len(files)+1
        for name,v in manifest.items():raw=z.read(name);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256']
    (S/'Closed_Benchmark_And_Model_Results.json').write_bytes((closed/'Verified_Closed_Results_And_Exact_Resume.json').read_bytes())
    (S/'Current_Resume.json').write_bytes(cp.read_bytes());(S/'Task_Progress.json').write_bytes(tp.read_bytes())
    report=(closed/'Results_And_Next_Execution.md').read_text(encoding='utf-8')+'\n\n## New prospective execution\n\n'+header
    (S/'Results_And_Next_Execution.md').write_text(report,encoding='utf-8')
    (S/'README.md').write_text('''# Closed same-case numerical and original-adapter interface results

All500 public13 cases were independently verified. Full13 voltage-band restoration: published Safe-DDPG262, linear258, DDPG363; our frozen numerical264. Fixed numerical superiority gate FAILED. Our method had765residualUV/5OV; DDPG59UV/121OV. Strict near-boundary failures are retained.

The original private0.5B adapter on a NEW signed-native role produced0/6valid commands; the same-base adapter-disabled diagnostic also0/6. Six primary+six cold outputs perstudy and failures/costs are included. This is not a score for the original complete federation-paper controller.

Saved complementary expert branches give496/500, but that is POST-HOC DEVELOPMENT, not actual new-controller/LLM performance. The separately prospective fresh128/six-arm CPU study is now genuinely live with its own source/state/cost/first-reader protocol. No winning result yet; no GPU/LLM/training in that new study.

Three external policies are ONE publication family. Global information and safety differences are disclosed. Original137paperHGSE193vsDFF290residualUV remains preserved. All six final goals OPEN. No guaranteed superiority, full AC/security certificate, novelty or calibrated90percent success probability.

Archive includes own code, generated results, input recipes as source hashes and compact proofs, not private weights/NET/checkpoints/thirdparty source or a complete raw backup. Original reader launcher/path failures and additive zero-science repairs are retained. See Results_And_Next_Execution.md for exact scope.
''',encoding='utf-8')
    put(S/'Evidence_Manifest.json',dict(at_utc=now,status='LOCAL_PACKAGE_CRC_EVERY_MEMBER_HASH_PASS_NOT_YET_PUBLISHED',members=len(files)+1,archive_bytes=package.stat().st_size,archive_sha256=sha(package),members_manifest=manifest,private_weights_NET_checkpoints_thirdparty_source_excluded=True,not_complete_raw_backup=True,new_scientific_calls_from_packaging=0))
    descriptors=[dict(local=f.relative_to(R).as_posix(),path='research/20261022_closed_matched_benchmark/'+f.name,bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(S.iterdir())]
    put(B/'Local_Upload_Files.json',dict(repository='Hannaancode/Reliability-First-Multi-Agent-LLM-Guided-Corrective-Voltage-Control-',branch='research-progress-20261018',previous_head='b7e0e6404ac6d22ebfcd503a968662d2e5128b86',previous_tree='d90d369ddc2b6c77358c911dbd03108c5e989307',files=descriptors))
    print(json.dumps(dict(source_live=True,actual_scientist=owners['scientist']['claim']['actual_pid'],archive_members=len(files)+1,archive_bytes=package.stat().st_size,upload_files=len(descriptors))))

if __name__=='__main__':main()
