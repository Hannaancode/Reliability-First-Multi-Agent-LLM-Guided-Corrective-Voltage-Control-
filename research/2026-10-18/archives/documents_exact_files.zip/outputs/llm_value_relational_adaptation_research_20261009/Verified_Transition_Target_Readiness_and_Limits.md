# Verified transition targets: design support only

The read-only inventory and separate source/target reader completed. They used all
23 unchanged OPT worlds and both original guarded branches, with no held-target
design measurements. They made zero model, optimizer, controller, power-flow or
cloud calls. The failed relational intervention and all older failed methods stay
stopped; no training or physical rollout follows automatically.

There are **216 unique, complete transitions** from 193 distinct current states,
covering all 23 OPT worlds and three families. All 216 actions are inside the
recorded raw common-and-zone scope, original Q grid and 450-MVAr added-support cap.
The before/action/after identities match actual committed prefixes. The independent
reader checked 101,952 saved target scalars against source records: four fields
(`vm_pu`, `va_degree`, `p_mw`, `q_mvar`) at all 118 native buses for every transition.
This reused the prior genuine full-field physical replay certificate and its costs;
the new reader did not repeat those solves.

There are 23 exact same-world, same-before-state groups with different actually
executed actions, spanning all three families. Every original Q level is present;
eight of nine Q levels have at least ten distinct current states. There are no
duplicate transitions, conflicting targets, incomplete source branches or exclusions.
The prospectively fixed minimum coverage/excitation gates passed. This permits
precise method design, not a claim that the model will learn or outperform anything.

Every observed before/after state is within the unchanged `1.05 + 1e-8` upper
guard. Twelve native-versus-saved strict OV count differences near 1.05 are retained
and disclosed under the prior continuous `1e-10` replay contract. We do not claim
all native and replayed discrete OV counts agree. Original invalid input, missing
candidate ledgers, all world/branch identities, termination records and prior
collection/replay costs remain preserved.

The crucial limitation is **teacher selection**. These are transitions for committed
D-SE actions. They do not supply full successor vectors for rejected or uncommitted
candidates, nor independent samples of arbitrary actions. Correlated prefix records
must stay grouped by world. The same-before pairs provide limited measured action
contrast; they do not identify an unrestricted response operator or generalization
to a learned policy's new states. Missing vectors must stay unknown.

The next method design must address these limits explicitly. A proposed model input
can contain only the measured current state, current added support, original grid
and supplied candidate action. Actual next-state values and audit identities remain
separate targets. Train-only normalization and exact source conditioning are needed.
Simple current-state persistence and a correctly implemented full-response AC
linearization are necessary controls; so are a strong same-information numerical
state/action predictor and appropriate architecture/pretraining attribution. Old
poor classifier controls cannot substitute for these different prediction controls.

A lower absolute voltage MSE may mostly reward copying the current state. Any future
protocol must separately assess nontrivial action-response error and downstream native
ordering/protection/rejection, retaining unknown-action denominators. No numerical
target threshold, decoder or training schedule is fixed or justified by this inventory.
Actual available analytic-vector artifacts/functions must be inspected before claiming
that a control exists or that its costs can be reused. No new mature runner is inferred.

Evidence: `measured_OPT_transition_inventory/Protocol.json`, `Summary.json` and
`Actual_OPT_Transition_Rows.jsonl.gz`; independent
`measured_OPT_transition_inventory_external_audit_v2/Independent_Transition_Source_and_Target_Audit.json`.
Inventory ZIP: 8 members, 7,669,619 bytes, SHA256
`ee9cdbce7101628a42b1ad0acfdf16db9adfa1901c6b93ed484084a07b460a1a`.
Independent audit ZIP: 6 members, 32,228 bytes, SHA256
`bdb01c29efa7908d78ed2fabdec3863d68d7fe30af0d428614c26179316c6586`.
Both CRC/every-member-hash checks passed. The inventory's duplicate source `scope`
dictionary key and the first independent reader's certificate-key error were disclosed
and preserved; exact world selection, thresholds and source data did not change.

The original literal D-SE portfolio, both branches' complete costs, frozen assets and
locked bank remain unchanged. Historical data are development, not unused confirmation.
Validated incremental LLM contribution, matched protected physical superiority and
independent confirmation remain unachieved.
