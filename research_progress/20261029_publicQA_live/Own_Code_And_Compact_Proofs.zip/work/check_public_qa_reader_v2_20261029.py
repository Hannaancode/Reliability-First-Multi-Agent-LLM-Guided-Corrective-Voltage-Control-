"""Synthetic reader fixtures, independent of the real benchmark answers."""
from pathlib import Path
import json,hashlib,shutil
from tokenizers import Tokenizer,models,pre_tokenizers,decoders
from public_qa_inference_worker_v2_20261029 import run
from audit_public_qa_scientific_20261029 import audit_arm,native_parser,score_outputs
from public_qa_transfer_20261029 import publish_packet,sha
R=Path(__file__).resolve().parents[1];O=R/'outputs/public_qa_supervision_20261029/reader_checks_v2'
def put(p,v):p.write_text(json.dumps(v),'utf-8')
class Fake:
    def __init__(self,a,o):
        self.a=a
        put(o/'Actual_Integration.json',{'model':a['model'],'revision':a['revision'],'dtype':'float16','attention':'eager',
            'device':'T4 MOCK SOFTWARE ONLY','transformers':'5.5.0','private_adapter_loaded':False,
            'snapshot_files':{**{n:sha((O/'tokenizer'/n).read_bytes()) for n in ['config.json','tokenizer.json','tokenizer_config.json']},'model.safetensors':sha(b'MOCK_WEIGHT_IDENTITY_ONLY')}})
    def verify_input(self,r):assert r['input_ids']==[1]
    def synthetic_ids(self,n):return [1]
    def seed(self):pass
    def reload(self):pass
    def capture(self,p):p.write_bytes(b'MOCK_RNG');return sha(b'MOCK_RNG')
    def generate(self,ids,bound,minimum=0):
        new=[1]*(minimum or 1)
        return {'new_token_ids':new,'raw_text':Tokenizer.from_file(str(O/'tokenizer/tokenizer.json')).decode(new),
            'elapsed_seconds':.1,'peak_allocated_bytes':1,'peak_reserved_bytes':1}
def main():
    O.mkdir();(O/'tokenizer').mkdir()
    t=Tokenizer(models.WordLevel({'[UNK]':0,'A':1,'B':2,'C':3,'D':4},unk_token='[UNK]'));t.pre_tokenizer=pre_tokenizers.Whitespace()
    t.save(str(O/'tokenizer/tokenizer.json'))
    for n in ['config.json','tokenizer_config.json']:put(O/'tokenizer'/n,{'MOCK_ONLY':True})
    a={'model':'MOCK','revision':'MOCK','records':150,'seed':1,'setup_seconds':60,'science_seconds':60,'transformers_version':'5.5.0','expected_weights':{'model.safetensors':{'sha256':sha(b'MOCK_WEIGHT_IDENTITY_ONLY'),'bytes':25}}}
    pack={'model':'MOCK','revision':'MOCK','questions':[{'question_id':i,'rendered_prefix':'A','input_ids':[1],'input_tokens':1} for i in range(150)]}
    source=sha((R/'work/public_qa_inference_worker_v2_20261029.py').read_bytes())
    run(a,pack,O/'complete',Fake)
    full=audit_arm(O/'complete',a,pack,O/'tokenizer',source);assert len(full['outputs'])==150
    checks=['all150_complete_source_input_decode_cost_accounting']
    wrong={**a,'expected_weights':{'model.safetensors':{'sha256':'0'*64,'bytes':25}}}
    try:audit_arm(O/'complete',wrong,pack,O/'tokenizer',source)
    except AssertionError:checks.append('changed_pinned_assignment_rejected')
    else:raise AssertionError('Changed assignment accepted')
    partial=O/'partial';study=partial/'study';study.mkdir(parents=True)
    names=['owner.claim','Actual_Integration.json','Engineering_Warm.json','Engineering_Cold.json']
    names += [f'pre_rng_{n:03}.pt' for n in range(4)]+[f'output_{n:03}.json' for n in range(3)]
    for n in names:shutil.copyfile(O/'complete'/n,study/n)
    lines=(O/'complete/journal.jsonl').read_bytes().splitlines(keepends=True);prefix=[]
    for line in lines:
        e=json.loads(line);prefix.append(line)
        if e['kind']=='generation_attempt' and e['ordinal']==3:break
    (study/'journal.jsonl').write_bytes(b''.join(prefix)+b'{"interrupted_final_line":')
    publish_packet(study,partial/'packets',0,True,-15,'MOCK_HARD_STOP')
    p=audit_arm(study,a,pack,O/'tokenizer',source)
    assert len(p['outputs'])==3 and p['integrity']['unknown_attempts']==1 and p['integrity']['incomplete_final_journal_line']
    checks.append('hard_stop_prefix3_returns1_unknown_and_unclosed_tail')
    run(a,{**pack,'model':'WRONG'},O/'invalid_input',Fake)
    p=audit_arm(O/'invalid_input',a,pack,O/'tokenizer',source);assert p['actual_attempted_science_generations']==0
    checks.append('no_entry_closed_input_failure_all_unknown')
    # Rehashed tampering must fail semantic decoding even after byte hashes are updated.
    altered=O/'changed_decode';shutil.copytree(O/'complete',altered)
    p=altered/'output_000.json';v=json.loads(p.read_text());v['raw_text']='B';put(p,v)
    events=[json.loads(x) for x in (altered/'journal.jsonl').read_text().splitlines()];prev='0'*64
    from public_qa_inference_worker_v2_20261029 import canonical
    for e in events:
        e['previous']=prev
        if e['kind']=='generation_return' and e['ordinal']==0:e['output_sha256']=sha(p.read_bytes())
        e.pop('sha256');e['sha256']=sha(canonical(e));prev=e['sha256']
    (altered/'journal.jsonl').write_bytes(b''.join(canonical(e)+b'\n' for e in events))
    result=json.loads((altered/'Result.json').read_text());result['journal_tail']=prev;put(altered/'Result.json',result)
    m=json.loads((altered/'Closed_Manifest.json').read_text())
    for n in m['files']:b=(altered/n).read_bytes();m['files'][n]={'bytes':len(b),'sha256':sha(b)}
    put(altered/'Closed_Manifest.json',m)
    try:audit_arm(altered,a,pack,O/'tokenizer',source)
    except AssertionError:checks.append('rehashed_text_token_disagreement_rejected')
    else:raise AssertionError('Decoder forgery accepted')
    labels={i:'A' for i in range(150)};labels[0]='D';labels[1]='C'
    outputs=[{'question_id':0,'raw_text':'A then D'},{'question_id':1,'raw_text':'I cannot answer'},{'question_id':2,'raw_text':'A'}]
    pr,st,valid,missing=score_outputs(outputs,labels,native_parser())
    assert sum(pr)==3 and sum(st)==sum(valid)==1 and missing==147
    checks.append('native_last_letter_and_fallback_strict_secondary_unknown_denominator')
    report={'status':'PASS_SIX_FINAL_SCIENTIFIC_READER_SOFTWARE_CHECKS','checks':checks,'source_sha256':sha((R/'work/audit_public_qa_scientific_20261029.py').read_bytes()),
        'worker_sha256':source,'real_model_GPU_PF_calls':0,'real_test_labels_read':False,'fixture':'Synthetic outputs and synthetic labels only'}
    put(O/'Result.json',report);print(json.dumps({'status':report['status'],'checks':len(checks)}))
if __name__=='__main__':main()
