"""Save exact live/terminal changed-evidence analysis progress, no new science."""
import json,os
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
from equal_operation_benchmark_v2 import process
B=R/'outputs/unstarted_paid_suffix_new_receipts_v3_20261018';P=R/'outputs/unstarted_paid_suffix_new_receipts_v3_preparation_20261018'
def atomic(path,v):
    temp=path.with_name(path.name+'.new')
    with temp.open('w',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(temp,path)
def main():
    c=read(B/'owner.claim');actual=process(c['actual_pid']);source=R/'work/replay_paid_suffix_new_receipts_v3_20261018.py';assert c['source_sha256']==sha(source)
    if actual:assert actual['ParentProcessId']==c['parent_pid'] and source.name in actual['CommandLine']
    proof={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':c['actual_pid'],'shim_pid':c['parent_pid'],'source_sha256':c['source_sha256'],'actual_command':actual['CommandLine'] if actual else None,
        'actual_live':bool(actual),'zero_new_science':True,'source_claim_exact':True,'closed_result':read(B/'Results.json') if (B/'Results.json').exists() else None}
    atomic(P/'Latest_Execution_Checkpoint.json',proof)
    path=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';v=read(path);v['at_utc']=proof['at_utc'];v['new_receipt_causal_screen']=proof
    v['active_owned_jobs']=[{'kind':'CPU_READONLY_ANALYSIS_NOT_PHYSICS','actual_pid':c['actual_pid'],'shim_pid':c['parent_pid'],'source':str(source.relative_to(R)),'fixed_analysis_bound_seconds':900,'no_duplicate_or_restart':True}] if actual else []
    v['next_tasks']=['Inspect the sole changed-evidence analysis after actual process ends. Preserve next exact missing input and all partial results; no automatic newPF from absent key.','Publish closed two-query code/proofs/checklist to existing branch with head lease/byte checks.','Design the next complete matched protected continuation only from actual supported causal states, strong controls/full costs/ownership/preservation/independent reader gates. All6finalgoalsopen.']
    atomic(path,v)
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+proof['at_utc']+' — Saved changed-evidence paid-suffix analysis: '+('LIVE' if actual else 'ENDED')+f', actualPID{c["actual_pid"]}/shim{c["parent_pid"]}, source{c["source_sha256"]}. Same fixed first unstarted leg, BOTH newly audited receipts including both rejections; no new PF/model/forecast/derivative/solve. Fixed900sec CPU analysis only, no old owner restarted. Exact checkpoint '+str((P/'Latest_Execution_Checkpoint.json').relative_to(R))+'.\n');f.flush();os.fsync(f.fileno())
    print(json.dumps({'saved_actual_analysis_live':bool(actual),'actual_pid':c['actual_pid'],'new_science':0}))
if __name__=='__main__':main()
