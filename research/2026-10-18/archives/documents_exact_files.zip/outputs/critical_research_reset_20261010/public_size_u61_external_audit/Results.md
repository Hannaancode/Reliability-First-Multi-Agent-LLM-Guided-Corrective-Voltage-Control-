Public model-size development diagnostic, all31worlds plusoriginalinvalid.

{
  "complete_original_response_inventory": false,
  "old_after_tensor_gate_remains_UNKNOWN": true,
  "development_only": true,
  "paired_counts": {
    "unknown": 31
  },
  "no_missing_rejected_invalid_or_unexecuted_outcome_removed": true,
  "no_automatic_training_or_physical_campaign": true,
  "full_DSE_and_unused_confirmation_required": true,
  "goal_achieved": false
}

The original first0.5B response is reused, not generated again. Its old post-weight gate remainsUNKNOWN. Full-table numerical controls receive stronger information; publicmodels share fixed partialprompts. Architecture/pretraining/post-training/precision/FLOP differences remain. This is not protected full-trajectory D-SE superiority or independent confirmation.
