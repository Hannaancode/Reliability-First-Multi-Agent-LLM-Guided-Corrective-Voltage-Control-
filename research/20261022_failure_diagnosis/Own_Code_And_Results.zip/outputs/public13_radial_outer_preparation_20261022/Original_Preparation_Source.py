"""Freeze all-four adverse case diagnostic before any new LP outcome."""
from fractions import Fraction as F
from datetime import datetime,timezone
from public13_radial_outer_certificate_20261022 import R,P,PRIMARY,READER,read,put,sha,certificate

def main():
    assert not PRIMARY.exists() and not READER.exists();P.mkdir(exist_ok=False)
    closed=R/'outputs/public13_expert_complementarity_development_20261021/Saved_Expert_Complementarity_And_Prospective_Question.json'
    cases=read(closed);seeds=[v['seed'] for v in cases['rows'] if not v['all4_available_trajectory_envelope']];assert len(seeds)==4
    roots=read(R/'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json')['roots'];selected=[v for v in roots if v['seed'] in seeds];assert [v['seed'] for v in selected]==seeds
    code=['work/public13_radial_outer_certificate_20261022.py','work/run_public13_radial_outer_20261022.py','work/audit_public13_radial_outer_20261022.py','work/coordinate_public13_radial_outer_20261022.py']
    for rel in code:compile((R/rel).read_text(encoding='utf-8'),str(R/rel),'exec')
    paths=[R/v for v in code]+[R/v['path'] for v in selected]+[closed]
    graph='outputs/stable_ddpg_native_engineering_20261020/preserved_root_independent_audit/Verified_Admittance_And_State.npz';paths.append(R/graph)
    checks={
      'exact_separation_positive_fixture':certificate([{0:F(1)}],[F(2)],[],[],[(F(0),F(1))],[F(1)],[])['certified'],
      'feasible_fixture_not_false_infeasible':not certificate([{0:F(1)}],[F(1,2)],[],[],[(F(0),F(1))],[F(1)],[])['certified'],
      'negative_inequality_multiplier_validates':certificate([],[],[{0:F(-1)}],[F(-2)],[(F(0),F(1))],[],[F(-1)])['certified'],
      'positive_inequality_multiplier_rejected':not certificate([],[],[{0:F(-1)}],[F(-2)],[(F(0),F(1))],[],[F(1)])['valid_signs'],
      'one_e_minus7_residual_allowance_retained':not certificate([{0:F(1)}],[F(1,10**8)],[],[],[(F(0),F(0))],[F(1)],[])['certified']}
    assert all(checks.values());put(P/'Exact_Arithmetic_Fixtures.json',dict(status='PASS_EXACT_SEPARATION_POSITIVE_NEGATIVE_AND_RESIDUAL_CONTROLS',checks=checks,new_LP_PF_model_calls=0))
    protocol=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_ALL4_ADVERSE_ROOT_NECESSARY_CONDITION_DIAGNOSTIC_NO_OUTCOMES_YET',all4_adverse_roots=selected,graph=graph,
        hashes={v.relative_to(R).as_posix():sha(v) for v in paths},science_seconds=120,reader_seconds=120,LP_attempts_per_case=1,LP_time_limit_seconds=10,LP_maxiter=10000,
        method='Radial loss-aware branch-flow balance and voltage-drop equations; bounded nonnegative squared current, finite P/Q outer boxes, all13strictVMband squared, source-derived100*float32(.3) Qreachability with float64 sum error allowance. Drop nonconvex equality P^2+Q^2=v_i*l. Add ONLY fixed9x9 tangent cuts 2p0P+2q0Q-vmax*l<=p0^2+q0^2 at p0/q0 in[-2,-1,-.5,-.25,0,.25,.5,1,2]pu. One phase1 LP percase, no retries/adaptive cuts.',
        certificate='For Ax=b,Cx<=d,l<=x<=u and lambda<=0, b*y+d*lambda-max_box((A^Ty+C^Tlambda)*x)>1e-7*(norm1(y)+norm1(lambda)) proves even that residual-expanded outer system empty. Exact binary-float constants represented as rational fractions; independent row/box reconstruction. Solver status/objective alone never certifies infeasibility.',
        source_gates='Exactly13nodes/12connectedradialedges, no branch charging/taps/phase shifts/busshunts/non-slackPV, only fixedslackVM1, constant native sgenP/loads/noncontrolQ and exactcurrent sourceY; source gates must pass before LP.',
        target_selection='ALL four development cases outside the saved four-controller envelope, as failure diagnosis only. Never excluded from full500 denominator or new128 stream. No performance, LLM, general infeasibility or unused confirmation claim.',
        outcome_rule='Positive independently verified exactgap gives scoped endpoint impossibility. All other outcomes including phase1feasible/failure remainUNKNOWN; never retune cutgrid/Q/band/tolerance/root/budget.',
        actual_new_PF_model_derivative_LU_training_calls=0,all6finalgoals='OPEN')
    put(P/'Protocol.json',protocol)
    # Actual source assumptions and dimensions, still no LP/PF/model.
    from public13_radial_outer_certificate_20261022 import build
    dims=[]
    for root in selected:
        A,b,C,d,box=build(root);dims.append(dict(seed=root['seed'],equations=len(A),cuts=len(C),variables=len(box)))
    put(P/'Source_Admission.json',dict(status='PASS_ALL4_REAL_NATIVE_ROOT_RADIAL_CONSTANT_POWER_ADMITTANCE_AND_ACTUATOR_SOURCE_ASSUMPTIONS',dimensions=dims,new_LP_PF_model_calls=0))
    put(P/'Reader_Lock.json',dict(reader_sha256=sha(R/'work/audit_public13_radial_outer_20261022.py'),protocol_sha256=sha(P/'Protocol.json')))
    for role,source,output,coord in [('Primary','work/run_public13_radial_outer_20261022.py',PRIMARY,'outputs/public13_radial_outer_coordination_20261022'),('Reader','work/audit_public13_radial_outer_20261022.py',READER,'outputs/public13_radial_outer_reader_coordination_20261022')]:
        put(P/(role+'_Owner_Protocol.json'),dict(single_owner=dict(source=source,sha256=sha(R/source),output=output.relative_to(R).as_posix(),coordination=coord,python='work/vcsa_module_env/Scripts/python.exe',bound_seconds=180)))
    print('ALL4_SOURCE_AND_EXACT_ARITHMETIC_ADMISSION_PASS_NO_SCIENCE')
if __name__=='__main__':main()
