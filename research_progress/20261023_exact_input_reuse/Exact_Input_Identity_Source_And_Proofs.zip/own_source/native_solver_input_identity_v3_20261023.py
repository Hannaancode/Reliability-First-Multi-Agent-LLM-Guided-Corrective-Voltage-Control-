"""Additive return capture repair; original native preparation prefix retained."""
import ast,copy,hashlib,inspect,types,importlib
from native_solver_input_identity_20261023 import assert_solver_input_identity,map_paid_return

def native_input_prefix(net,kwargs):
    import pandapower as pp
    import pandapower.powerflow as pf
    source=inspect.getsource(pf._powerflow);node=ast.parse(source).body[0]
    cut=next(i for i,n in enumerate(node.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='_run_pf_algorithm')
    body=node.body[:cut]
    assert '_run_pf_algorithm' not in ast.unparse(ast.Module(body=body,type_ignores=[]))
    prefix=copy.deepcopy(node);prefix.name='_only_native_input_prefix';prefix.body=body+[ast.parse('return net, ppc, ppci, kwargs').body[0]]
    tree=ast.fix_missing_locations(ast.Module(body=[prefix],type_ignores=[]));scope=dict(pf._powerflow.__globals__)
    exec(compile(tree,'<pinned_native_prefix_no_solver>','exec'),scope)
    captured=[]
    def receive(n,**kw):
        captured.append(scope[prefix.name](n,**kw))
        # Native runpp intentionally discards _powerflow's return; capture is
        # external and changes no option/prefix instruction or solver input.
    original=importlib.import_module('pandapower.run').runpp;environment=dict(original.__globals__);environment['_powerflow']=receive
    entry=types.FunctionType(original.__code__,environment,original.__name__,original.__defaults__,original.__closure__);entry.__kwdefaults__=original.__kwdefaults__
    assert entry.__code__.co_code==original.__code__.co_code
    entry(net,**kwargs);assert len(captured)==1
    prepared,ppc,ppci,algorithm_kwargs=captured[0]
    assert prepared is net and not net['_options']['init_results'] and net['_options'].get('recycle') is None
    assert net['_options']['algorithm']=='nr' and net['_options']['ac'] and net['_options']['mode']=='pf'
    return dict(net=prepared,ppc=ppc,ppci=ppci,algorithm_options=copy.deepcopy(net['_options']),algorithm_kwargs=algorithm_kwargs,
        proof=dict(native_runpp_source_sha256=hashlib.sha256(inspect.getsource(original).encode()).hexdigest(),native_powerflow_source_sha256=hashlib.sha256(source.encode()).hexdigest(),exact_original_prefix_AST_sha256=hashlib.sha256(ast.dump(ast.Module(body=body,type_ignores=[]),include_attributes=False).encode()).hexdigest(),algorithm_invocations=0,one_native_input_preparation_invocation=True))
