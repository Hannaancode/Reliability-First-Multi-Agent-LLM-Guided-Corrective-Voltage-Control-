"""Prospectively resolve exactly three remaining distinct native80 contracts.

This does not reuse the first bridge's approval file as approval of a new
protocol. Authority is the ongoing matched-comparison execution request and
the human's instruction to use judgment. No old50 or previously run80 call
is repeated; actual80 results and first independent replays are separately paid.
"""
import ast,copy,json,pickle,sys
from pathlib import Path
from datetime import datetime,timezone
from reflection118_chronological_core_20261022 import *
P=R/'outputs/r118_remaining_native80_contracts_preparation_20261022'
def main():
    P.mkdir(exist_ok=False)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    from frozen_physics_loader import load_stack,AUDIT
    from run_reflection118_chronological_local_20261022 import History,necessary
    _,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    batch=read(R/'outputs/r118_first_round_missing_only_execution_20261022/Result.json');audit=read(R/'outputs/r118_first_round_missing_only_independent_20261022/Independent_Audit.json')
    assert audit['first_independent_PF_replays']==1988 and audit['maximum_field_delta']==0
    unknown=[r for r in batch['rows'] if r['status']=='PRIOR_COLLISION_UNKNOWN_NO_CALL'];assert len(unknown)==3
    bindings={r['case_id']:r for r in read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')}
    history=History();targets=[]
    for i,row in enumerate(unknown):
        binding=bindings[row['case_id']];net=pickle.loads((R/binding['solved_payload']).read_bytes())['net'];runner.rescue.apply_action(net,row['action'])
        try:history.find(net,row['solver_kwargs'])
        except BaseException as e:
            assert str(e).startswith('OLD_MATCHED_INPUT_DIFFERENT_OR_UNKNOWN_SOLVER_CONTRACT:')
            ref=ast.literal_eval(str(e).split(': ',1)[1])
        else:raise AssertionError('Expected a specifically unexecuted80/source50 contract; never repeat a paid80 return')
        journal=R/ref['journal'];events=history.sources[str(journal)]
        intents=[e['data'] for e in events if e.get('event')=='PF_intent' and e.get('data',{}).get('id',e.get('data',{}).get('identity'))==ref['id']]
        returns=[e['data'] for e in events if e.get('event')=='PF_return' and e.get('data',{}).get('id',e.get('data',{}).get('identity'))==ref['id']]
        assert len(intents)==len(returns)==1 and intents[0]['kwargs']['max_iteration']==50 and row['solver_kwargs']['max_iteration']==80
        assert 'after' in returns[0] and row['case_id']!='fed_combined_load_1p5_line_35_MG1'
        old=history.old_decode(journal.parent,ref['before']);frames_equal(net,old)
        target=capsule(P/f'target_{i:02d}.zlib',dict(net=net,case_id=row['case_id'],action=row['action']))
        targets.append(dict(case_id=row['case_id'],source_action=row['action'],target=target,original_declared_identity=row['identity'],
            actual_old50_reference=ref,old50_kwargs=intents[0]['kwargs'],old50_return=returns[0]['after'],
            new80_kwargs=row['solver_kwargs'],old50_preserved_not_repeated=True))
    # These are small, already validated field/cost-preserving owner/reader
    # skeletons; only the study namespace/count/description is changed.
    for kind in ['run','audit']:
        old=R/f'work/{kind}_published_graph118_first_queries_20261022.py'
        s=old.read_text('utf-8').replace('published_graph118_first_queries','r118_remaining_native80_contracts')
        s=s.replace("len(p['targets'])==4","len(p['targets'])==3").replace("len(result['rows'])==4","len(result['rows'])==3")
        s=s.replace('ALL4','ALL3').replace('all4','all3')
        end=s.find('"""',3)
        s='"""Three prospectively fixed native80 contract queries; old50 untouched.\nNo full controller or LLM superiority claim.\n"""'+s[end+3:]
        new=R/f'work/{kind}_r118_remaining_native80_contracts_20261022.py';assert not new.exists();new.write_text(s,encoding='utf-8');ast.parse(s)
    source=R/'work/coordinate_r118_first_round_missing_only_20261022.py'
    s=source.read_text('utf-8').replace('r118_first_round_missing_only','r118_remaining_native80_contracts').replace('timeout=2050','timeout=450')
    newcoord=R/'work/coordinate_r118_remaining_native80_contracts_20261022.py';assert not newcoord.exists();newcoord.write_text(s,encoding='utf-8')
    scientific=[R/'work/run_r118_remaining_native80_contracts_20261022.py',R/'work/audit_r118_remaining_native80_contracts_20261022.py']
    put(P/'Protocol.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_THREE_UNEXECUTED_NATIVE80_COMPARATOR_CONTRACTS',targets=targets,
        solver_kwargs=targets[0]['new80_kwargs'],source_hashes={p.relative_to(R).as_posix():sha(p) for p in scientific+[Path(__file__)]},
        bound_seconds=300,reader_seconds=300,binary_bytes=32*1024**2,new_primary_PF_calls_max=3,first_independent_replays_max=3,
        old50_or_previously_executed80_calls_repeated=0,new_model_GPU_training_optimizer_calls=0,actual_policy_commits=0,
        authority='Earlier direct matched-comparison execution instructions and latest do whats best. These are the remaining first80 contracts on three fixed source inputs, not retries of old50 or previously executed80.',
        first_explicit_two_call_bridge_scope_remains_one_input=True,no_equivalence_assumption_from_the_first_bridge=True,
        selection='ALL3 remaining contract gaps in original first-menu/case order, before their native80 outcomes; unchanged action/Q/guard/source/score.',
        no_retry_extension_outcome_tuning_or_automatic_trajectory=True))
    for name,src,out,coord in [('Owner_Protocol.json',scientific[0],'r118_remaining_native80_contracts_execution_20261022','r118_remaining_native80_contracts_coordination_20261022'),('Reader_Owner_Protocol.json',scientific[1],'r118_remaining_native80_contracts_independent_20261022','r118_remaining_native80_contracts_reader_coordination_20261022')]:
        put(P/name,dict(single_owner=dict(source=src.relative_to(R).as_posix(),sha256=sha(src),python='work/vcsa_module_env/Scripts/python.exe',output='outputs/'+out,coordination='outputs/'+coord,bound_seconds=400)))
    put(P/'Source_And_Preservation_Readiness.json',dict(status='PASS_PROSPECTIVE_ALL3_FIXED_NATIVE80_GAPS',targets=3,all_exact_inputs_match_successful_old50_contracts=True,
        no_previously_executed_native80_entry=True,no_other_branch_or_budget_restarted=True,new_scientific_calls_in_preparation=0,protocol_sha256=sha(P/'Protocol.json')))
    print(json.dumps(dict(prepared_native80_contracts=3,old50_repeats=0,new_science_in_preparation=0)))
if __name__=='__main__':main()
