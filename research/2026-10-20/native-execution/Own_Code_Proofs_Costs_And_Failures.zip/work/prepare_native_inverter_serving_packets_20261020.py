"""Full current-only packet/token/strict actuator software gate; no model/PF calls."""
import hashlib,json,pickle,time,inspect
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/native_inverter_serving_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic()
    import candidate_process_runtime
    import numpy as np
    from transformers import AutoTokenizer
    from native_inverter_serving_contract_v1_20261020 import messages,parse
    from candidate_process_evidence_utils import frozen_checks
    model=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    roots=[ROOT/'outputs/tpa_native_one_step_engineering_v3_20261020',ROOT/'outputs/tpa_native_second_identity_engineering_20261020']
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Prepare exact first2author root CURRENT-only native signed-inverter serving packets; tokenizer and parser software only. Explicitly new role, not original unchanged shunt/paper controller or full TPA equal-information benchmark.','identities_in_author_order':[{'day_id':366,'idx':176142},{'day_id':385,'idx':185262}],'no_outcome_selection':'First2author identities fixed before TPA action outcomes; retain first failed action UNKNOWN. All22actuated zones per root, all38inverters, no favourable-zone selection.','causal_input_allowlist':['PF0_before physical input bus/load/sgen tables','PF0_fields current solved bus voltage/angle','previously source-audited public native full-data Pmax capacities, same as TPA; future-data-derived author hardware convention disclosed'],'prohibited_inputs':['PF1/action outputs','teacher action','AFTER voltage','TPA score','unknown future trajectory','seasonal/history embedding'],'information_difference':'Current-only local schema gate. TPA temporal100x3/seasonal/global-prototype information omitted; this is not enough to claim a matched TPA benchmark.','actuator':'Instantaneous absolute signed inverter q_mvar in native units; full zonal controlled-bus coverage. No shunt addition/hidden rescale/clipping/invalid-null fill.','prospective_new_serving_context_bound':4096,'prospective_generation_reserve':384,'no_truncation':True,'frozen_parser_and_prompt_sha256':sha(ROOT/'work/native_inverter_serving_contract_v1_20261020.py'),'old_trained_adapter_weights_unchanged':True,'model_PF_GPU_calls_planned_by_this_preparation':0,'actual_inference_protocol_status':'NOT_READY; model/base loader/cold/ownership/preservation/generation/economics and both source input certification gates still required. No GPU allocation from this software outcome.'}
    put(OUT/'Protocol.json',protocol);put(OUT/'Frozen_Before.json',frozen_checks())
    tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True,trust_remote_code=False)
    maxima=np.array(json.loads((ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json').read_text(encoding='utf-8'))['native_column_max'])
    packets=[];sources={};fixtures=[]
    for ordinal,source in enumerate(roots):
        for file in ['PF0_before.pkl','PF0_fields.npz']:sources[(source/file).relative_to(ROOT).as_posix()]=sha(source/file)
        with (source/'PF0_before.pkl').open('rb') as f:net=pickle.load(f)
        fields=np.load(source/'PF0_fields.npz');busfields=fields['res_bus'];assert busfields.shape[0]==len(net.bus)==322
        p=net.sgen.p_mw.to_numpy();caps=.8*np.sqrt((1.2*maxima)**2-p**2);zones=sorted(set(net.sgen['name']),key=lambda x:int(x[4:]));assert len(zones)==22
        seen=[]
        for zone in zones:
            busids=net.bus.index[net.bus.zone==zone].tolist();rows=[];inv=[]
            for bus in busids:
                pos=int(net.bus.index.get_loc(bus));load=net.load[net.load.bus==bus];pv=net.sgen[net.sgen.bus==bus]
                rows.append({'bus':int(bus),'load_p_mw':float(load.p_mw.sum()),'load_q_mvar':float(load.q_mvar.sum()),'inverter_p_mw':float(pv.p_mw.sum()),'inverter_q_mvar':float(pv.q_mvar.sum()),'vm_pu':float(busfields[pos,0]),'va_degree':float(busfields[pos,1])})
            for index,row in net.sgen[net.sgen['name']==zone].iterrows():
                pos=int(net.sgen.index.get_loc(index));assert row.bus in busids;seen.append(int(index));inv.append({'bus':int(row.bus),'q_min_mvar':-float(caps[pos]),'q_max_mvar':float(caps[pos])})
            current={'zone':zone,'voltage_limits_pu':[.95,1.05],'buses':rows,'inverters':inv};chat=messages(current)
            ids=tokenizer.apply_chat_template(chat,tokenize=True,add_generation_prompt=True)
            # Text IDs are measured in full; no cropping, masking or inference.
            packet={'root_author_ordinal':ordinal,'source_verification':'primary+independentPF' if ordinal else 'primaryPF+zero-sciencepartialreader;independentPFpending','current':current,'messages':chat,'token_ids':ids,'prefix_tokens':len(ids),'fits_fixed4096_plus384':len(ids)+384<=4096}
            packets.append(packet)
            zeros={'set_inverter_q_mvar':{str(i['bus']):0. for i in inv}};assert parse(json.dumps(zeros),current)['kind']=='native_absolute_Q_set'
            assert parse('{"abstain":true}',current)=={'kind':'abstain'}
        assert sorted(seen)==sorted(map(int,net.sgen.index))
    first=packets[0]['current'];bus=str(first['inverters'][0]['bus']);cap=first['inverters'][0]['q_max_mvar']
    invalid=['null','{"abstain":1}','{"add_shunts_q_mvar":{"'+bus+'":25}}','{"set_inverter_q_mvar":{"'+bus+'":true}}','{"set_inverter_q_mvar":{"'+bus+'":NaN}}','{"set_inverter_q_mvar":{"'+bus+'":0,"'+bus+'":0}}','{"set_inverter_q_mvar":{"999999":0}}']
    values={str(i['bus']):0. for i in first['inverters']};values[bus]=cap*2;invalid.append(json.dumps({'set_inverter_q_mvar':values}))
    for text in invalid:
        try:parse(text,first)
        except (ValueError,TypeError):fixtures.append({'kind':'strict_schema_units_cap_failure_rejected','input_sha256':hashlib.sha256(text.encode()).hexdigest()})
        else:raise AssertionError('Invalid actuator output was accepted')
    assert list(inspect.signature(messages).parameters)==['current']
    try:messages(first,after_voltage=[])
    except TypeError:fixtures.append({'kind':'successor_label_unavailable_to_prompt_factory'})
    else:raise AssertionError('Causal boundary failed')
    put(OUT/'Packets.json',packets);put(OUT/'Input_Hashes.json',sources);put(OUT/'Frozen_After.json',frozen_checks())
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_INPUT_TOKEN_AND_STRICT_NATIVE_ACTUATOR_SOFTWARE_GATE','roots':2,'zonal_packets':len(packets),'inverters_per_root':38,'all_current_rows_retained':True,'prefix_token_range':[min(x['prefix_tokens'] for x in packets),max(x['prefix_tokens'] for x in packets)],'fixed4096_384_overflows':sum(not x['fits_fixed4096_plus384'] for x in packets),'exact_original_tokenizer_files':{f:sha(model/f) for f in ['tokenizer.json','tokenizer_config.json','chat_template.jinja']},'strict_output_positive_checks':88,'negative_checks':fixtures,'actual_LLM_PF_GPU_optimizer_calls':0,'no_inference_or_performance_claim':True,'workflow_seconds':time.monotonic()-start}
    put(OUT/'Results.json',result);print(json.dumps({k:result[k] for k in ['status','zonal_packets','prefix_token_range','fixed4096_384_overflows','actual_LLM_PF_GPU_optimizer_calls']}))
if __name__=='__main__':main()
