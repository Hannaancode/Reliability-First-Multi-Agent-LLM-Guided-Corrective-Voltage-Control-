# Reporting corrections from actual saved evidence

7 October2026. No original result, controller setting, model, network or case-bank entry is changed.

1. Use **original strict undervoltage clearance** for D-SE60/62 and HG-SE59/62. The original `full_restoration` boolean is defined by UV count alone. It does not establish all bus voltages within0.95–1.05.
2. Independent terminal replay shows, among60 valid pairs, normal upper-band exceedance beyond1e-8 in59 D-SE and60 HG-SE selected endpoints. Both normal bands are met at that separately labelled tolerance in one D-SE and zero HG-SE endpoints. No selected endpoint exceeds1.06 beyond that tolerance. Original strict counts and diagnostic tolerance remain separate.
3. Declared slack constraints remain violated in the frozen setup. Successful UV clearance, absence of hard OV, parse validity and protected verifier acceptance are different outcomes. None establishes full operational feasibility or universal safety.
4. HG-VF's626 direct executed actions demonstrate participation. Its whole branch was unselected by HG-SE in all60 valid pairs. Do not infer causal added value from action-source shares. CENTRAL-VF's better standalone UV outcomes still require full independent replay and model-independent proposer controls for learned-search attribution.
5. The actual24-trial PowerGridQA study measures independent proposals and protected verification. It does not execute a full recovery trajectory or establish harmful-action release, attack detection, stealth or multi-family robustness. Retrieval's clean baseline and equal-length control must accompany any attacked-minus-clean comparison.
6. Disclose60 original central pairs plus two explicit RNG060 recovery executions on a fresh standard T4. Keep original-prefix hashes, recovered-case lineage and family timing sensitivity. The missing original full remote log is a retained reproducibility limitation.
7. All62 bank outcomes are already known. New-method results on that bank are exploratory unless another genuinely independent approved confirmation source is available. Do not relabel inspected cases or regenerate missing originals to manufacture independence.

Evidence: `incremental_value_audit.json`, original main physical replays, `matched_campaign_family_analysis.json`, `fixed_p_feasibility_audit.json`, `central_recovery_provenance.json`, `central_recovery_timing_sensitivity.json`, and `security/gpu_development_audit.json`.
