"""Fixed conditional nonlinear lookahead screen, not a whole-policy/LLM test."""
import argparse,copy,hashlib,importlib.metadata,json,os,pickle,random,sys,time,traceback
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
import full_joint_suffix_benchmark_20261014 as prior
from operation_aware_paid_lookahead_v1 import Receipt,plan,MissingEvidence
from project_paid_joint_successor_v1 import project
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key,load_ref
from joint_reallocation_opportunity_core_v1 import load_endpoint,build_verifier,action,forecast
from shared_original_serving_action_domain_v1 import build_current_domain
from original_local_paid_branch_broker_v1 import resource_eligible
from joint_admissibility_order_v1 import order_all_current_forecasts
from dynamic_actual_mask_guidance_v1 import compile_current,identity
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks
from equal_operation_benchmark_v2 import decode_capsule

R=Path(__file__).resolve().parents[1];B=R/'outputs/bounded_paid_lookahead_physics_20261014'
CACHE=R/'outputs/operation_aware_lookahead_input_cache_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
MASK=R/'outputs/actual_mask_jacobian_engineering_20261014'
DYNAMIC=R/'outputs/all30_dynamic_actual_guidance_storage_v2_20261014'
METHODS=('immediate1_followup16','breadth4_followup4')
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def metrics(net):return prior.metrics(net)
def common_accept(record):
    v=record['verdict'];return bool(v['accepted'] and v.get('after') is not None and v['after']['vmax']<=1.05+1e-8)
def receipt(parent,aid,row,record,successor):
    accepted=common_accept(record)
    return Receipt(parent,aid,True,accepted,1 if row['kind']=='ordinary' else 2,
        successor if accepted else None,record['verdict']['after'] if accepted else None,
        tuple(record['original_score']) if accepted else None,
        bool(record['attributed_PF_calls'] and record['after_reference'] is None))
class Evidence(prior.Evidence):
    def event(self,name,data):
        t=time.perf_counter();raw=canon({'event':name,'data':data,'previous_sha256':self.previous,'protocol_sha256':sha(B/'Protocol.json')})
        self.previous=hashlib.sha256(raw).hexdigest();self.journal.write(raw+b'\n');self.journal.flush();os.fsync(self.journal.fileno())
        self.costs['preservation_seconds']+=time.perf_counter()-t
def prepare():
    B.mkdir(exist_ok=False)
    a=read(CACHE/'audit_trace_v2/Independent_Compatible_Paid_Input_Audit.json');assert a['status'].startswith('PASS_ALL_SOURCE_')
    ready=read(R/'outputs/operation_aware_lookahead_software_20261014/Software_And_Paid_Input_Readiness.json')
    assert ready['number_of_checks']==34
    names=[Path(__file__),R/'work/audit_bounded_paid_lookahead_physics_20261014.py',
        R/'work/operation_aware_paid_lookahead_v1.py',R/'work/project_paid_joint_successor_v1.py',
        R/'work/compile_lookahead_paid_input_cache_20261014.py',R/'work/dynamic_actual_mask_guidance_v1.py',
        R/'work/joint_admissibility_order_v1.py',R/'work/shared_original_serving_action_domain_v1.py',
        R/'work/joint_reallocation_opportunity_core_v1.py',R/'work/full_joint_suffix_benchmark_20261014.py',
        R/'work/frozen_physics_loader.py',CACHE/'Compatible_Paid_Receipt_Index.json',CACHE/'audit_trace_v2/Independent_Compatible_Paid_Input_Audit.json',
        OLD/'preparation/Protocol.json',R/'outputs/operation_aware_lookahead_software_20261014/Software_And_Paid_Input_Readiness.json']
    entries=read(OLD/'preparation/Protocol.json')['current_endpoints']
    for i,e in enumerate(entries,1):
        ep=R/e['endpoint_record'];rec=read(ep);names += [ep,R/e['decoded_net_container_root']/rec['endpoint']['path'],MASK/'actual'/f'W{i}_Actual_Final_Mask_Context.npz']
    names += list((DYNAMIC/'actual').glob('*.npz'))
    solver=read(R/'outputs/shared_current_domain_physics_guarded_v2_20261014/Protocol.json')['solver_kwargs']
    put(B/'Protocol.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'study':'Two-search conditional development opportunity screen, from all4 exact previously-paid trained-LoRA current endpoints.',
        'all_four_worlds':[e['world'] for e in entries],'methods':list(METHODS),
        'source_input_sha256':{str(x.relative_to(R)):sha(x) for x in names},
        'solver_kwargs':solver,'science_bound_seconds':1200.,'maximum_PF_attempts':144,'maximum_storage_bytes':512*1024**2,
        'runtime':{n:importlib.metadata.version(n) for n in ['numpy','scipy','pandas','pandapower']},
        'maximum_device_operations_per_proposed_path':4,'followup_queries_each_method':16,
        'first_stage':'Same complete declared resource-operation-compatible root menu, all6372 source-compatible paid root receipts. Source costs attributed to each method; no free historical queries.',
        'second_stage':'Correct causal current-mask numerical ordering. Breadth:top4 safe immediate children with at most4 second queries each; control:top1 safe immediate child with at most16 second queries. Identical first menu/safety/actions/stock/caps/operation and follow-up allowances.',
        'primary_gate':'Complete source/physics/cost/replay evidence for all8 branches; breadth endpoint strictly fewerUV in>=2ofALL4roots than immediate-first control, noUVloss. Report operation/deficit/min/max/cost differences, no equal-actual-operation or wholeDSE claim.',
        'failure_semantics':'Completed original native-verifier rejection after recorded PF failure is an operational reject with physical feasibilityUNKNOWN, retained and charged. Missing verifier response/transfer/artifact is incomplete, never a negative result.',
        'replay':'Each selected proposed path rebuilt from source root, native PF at every1/2-operation transition; all118Vm/angle/P/Q fields match paid targets<=1e-10. Replays are charged; no actual deployment/whole episode commit.',
        'activation':'Exact prior actors ended; source/input/34software+4paidfixture/index-independentPASS/current ownership ACK and nine original frozen checks before new science.',
        'old_studies':'Original suffix/role/domain gates and failures untouched; no scientific retry or budget extension. Old cached callbacks reused only under exact current physical/resource identity and source/current legal action.',
        'new_model_optimizer_calls':0,'original_model_prefix':'Reused observed development prefix with its paid/UNKNOWN costs retained, no new LLM inference or incremental attribution.',
        'no_auto_LLM_GPU_or_fullpolicy_rollout':True})
    put(B/'Preparation_Frozen_Checks.json',frozen_checks())
    assert read(B/'Preparation_Frozen_Checks.json')['all_passed']
    print(json.dumps({'prospective_all4_screen_prepared':True,'max_new_PF':144,'new_model_calls':0}))
def pins(p):
    for name,h in p['source_input_sha256'].items():assert sha(R/name)==h,name
    assert {n:importlib.metadata.version(n) for n in p['runtime']}==p['runtime']
def load_after(ref,pack):
    if ref['kind']=='new':
        position=pack.tell()
        try:return decode_capsule(pack,ref['descriptor'])
        finally:pack.seek(position)
    return load_ref(ref)
def worker():
    p=read(B/'Protocol.json');pins(p);out=B/'actual';out.mkdir(exist_ok=False);begun=time.perf_counter();evidence=None;exit_code=1
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv,
        'source_sha256':sha(Path(__file__)),'protocol_sha256':sha(B/'Protocol.json')})
    deadline=datetime.now(timezone.utc)+timedelta(seconds=p['science_bound_seconds'])
    while not (out/'Launcher_ACK.json').exists():
        assert datetime.now(timezone.utc)<deadline,'No exact ownership ACK';time.sleep(.1)
    ack=read(out/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_PID_parent_command']
    runtime={**p,'absolute_deadline_utc':deadline.isoformat()}
    put(out/'Actual_Runtime_Bound.json',{'absolute_deadline_utc':deadline.isoformat(),'original_seconds':p['science_bound_seconds'],'no_extension':True})
    put(out/'Prelaunch_Frozen_Checks.json',frozen_checks());assert read(out/'Prelaunch_Frozen_Checks.json')['all_passed']
    try:
        index=read(CACHE/'Compatible_Paid_Receipt_Index.json');cache=copy.deepcopy(index['cache']);blocked=index['blocked_prior_incomplete_identities']
        _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
        evidence=Evidence(runtime,out);pp.runpp=evidence.solve
        numeric_cost={k:0 for k in ['public_derivative_attempts','public_derivative_returns','LU_factor_attempts','LU_factor_returns','LU_solve_attempts','LU_solve_returns','RHS_columns','exact_context_reuses','compile_seconds']}
        numeric_cost['new_forecasts']=0;contexts={};saved_contexts=set();(out/'contexts').mkdir()
        for path in list((MASK/'actual').glob('*Context.npz'))+list((DYNAMIC/'actual').glob('*.npz')):
            with np.load(path,allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
            contexts[identity(c)]=c
        results=[];serial=0
        for e in read(OLD/'preparation/Protocol.json')['current_endpoints']:
            original,original_cursor,_=load_endpoint(e)
            for mode in METHODS:
                evidence.admit();context={'world':e['world'],'method':mode};nodes={};log=[];menus=[]
                branch={'attributed_query_PF_calls':0,'attributed_query_solver_seconds':0.,'cached_query_receipts':0,
                    'new_query_PF_calls':0,'root_query_count':0,'second_query_count':0}
                root=f'{e["world"]}|{mode}|ROOT';domain=build_current_domain(original,original_cursor,runner=runner,zones=zones)
                nodes[root]={'net':copy.deepcopy(original),'cursor':domain['expanded_cursor_for_separately_fixed_future_protocol']}
                root_refs=[]
                def ensure(handle):
                    node=nodes[handle]
                    if 'net' not in node:
                        parent=ensure(node['parent']);target=load_after(node['record']['after_reference'],evidence.pack)['net']
                        projected=project(parent['net'],target,parent['cursor'],node['row'],node['record'],runner=runner,zones=zones)
                        node.update(net=target,cursor=projected)
                    if 'point' not in node:node['point']=point_key(node['net'],node['cursor'])
                    return node
                def make_menu(parent,slots,k=None):
                    node=ensure(parent);d=build_current_domain(node['net'],node['cursor'],runner=runner,zones=zones)
                    node['cursor']=d['expanded_cursor_for_separately_fixed_future_protocol']
                    rows=[r for r in d['all_declared_original9Q_ordinary_and_owned_joint_identities'] if (1 if r['kind']=='ordinary' else 2)<=slots]
                    if k is not None:
                        if root_refs:
                            evidence.event('complete_cached_root_menu_ACK',{**context,'records':root_refs});root_refs.clear()
                        c,ident=compile_current(node['net'],contexts,numeric_cost,lambda n,data:evidence.event('numeric_'+n,{**context,**data}))
                        if ident not in saved_contexts:
                            path=out/'contexts'/(ident+'.npz')
                            with path.open('xb') as f:np.savez_compressed(f,**c);f.flush();os.fsync(f.fileno())
                            saved_contexts.add(ident);evidence.event('current_numeric_context_saved',{**context,'parent':parent,'identity':ident,'sha256':sha(path)})
                        before=runner.rescue.grid_metrics(node['net']);guided=[]
                        for r in rows:guided.append({**r,'ordering_forecast':forecast(r,c,before)});numeric_cost['new_forecasts']+=1
                        ordered=order_all_current_forecasts(guided,before,node['cursor'])
                        rows=[{key:r[key] for key in ['kind','receiver','q','donor_index','donor_bus','universe_index']} for r in ordered if resource_eligible(r,node['cursor'])][:k]
                        evidence.event('second_causal_context_and_forecasts',{**context,'parent':parent,'context_identity':ident,
                            'actual_mask_PV':c['actual_PV'].tolist(),'actual_mask_PQ':c['actual_PQ'].tolist(),
                            'rows':guided,'selected_ids':[action_key(r) for r in rows]})
                    node.setdefault('rows',{}).update({action_key(r):r for r in rows})
                    menu={'parent':parent,'slots':slots,'k':k,'ids':[action_key(r) for r in rows]};menus.append(menu)
                    evidence.event('menu_declared',{**context,**menu})
                    return menu['ids']
                def query(parent,aid):
                    nonlocal serial
                    evidence.admit();node=ensure(parent);row=node['rows'][aid];key=node['point']+'|'+aid
                    if key in blocked:raise MissingEvidence('Prior incomplete identity is forbidden to repeat')
                    if parent!=root and root_refs:
                        evidence.event('complete_cached_root_menu_ACK',{**context,'records':root_refs});root_refs.clear()
                    if key in cache:
                        record=copy.deepcopy(cache[key]);record['candidate']=dict(row);branch['cached_query_receipts']+=1
                    elif not resource_eligible(row,node['cursor']):
                        record={'candidate':row,'verdict':{'accepted':False,'reason':'exact_resource_cap_or_stock_rejection_noPF','after':None},
                            'original_score':[-1]*5,'after_reference':None,'attributed_PF_calls':0,'attributed_solver_seconds':0.,'receipt_id':'RESOURCE_'+key}
                        cache[key]=copy.deepcopy(record)
                    else:
                        verify,_,_=build_verifier(runner.rescue,node['cursor']);evidence.last=None
                        evidence.context={**context,'phase':'NEW_PRIMARY_QUERY','parent':parent,'point':node['point'],'candidate':row,'action_key':aid}
                        raw=verify(node['net'],action(row));v=prior.verdict(raw);paid=copy.deepcopy(evidence.last)
                        serial+=1;record={'candidate':row,'verdict':v,
                            'original_score':list(runner.rescue.score_candidate({'action':action(row),'verif':v})),
                            'after_reference':{'kind':'new','descriptor':paid['after']} if paid and paid['outcome']=='RETURNED' else None,
                            'attributed_PF_calls':int(paid is not None),'attributed_solver_seconds':paid['seconds'] if paid else 0.,
                            'receipt_id':'NEW_LOOKAHEAD_'+str(serial),'actual_measured_receipt':paid}
                        cache[key]=copy.deepcopy(record);branch['new_query_PF_calls']+=int(paid is not None)
                    branch['attributed_query_PF_calls']+=record['attributed_PF_calls'];branch['attributed_query_solver_seconds']+=record['attributed_solver_seconds']
                    branch['root_query_count' if parent==root else 'second_query_count']+=1
                    successor=parent+'/'+aid
                    if common_accept(record):nodes[successor]={'parent':parent,'row':row,'record':record}
                    message={'parent':parent,'aid':aid,'row':row,'record':record,'successor':successor if common_accept(record) else None}
                    log.append(message)
                    if parent==root:root_refs.append(message)
                    else:evidence.event('second_query_closed',{**context,**message})
                    return receipt(parent,aid,row,record,successor)
                result=plan(root,runner.rescue.grid_metrics(original),original_cursor['remaining_original_device_operation_slots'],
                    lambda parent,slots:make_menu(parent,slots),lambda parent,slots,k:make_menu(parent,slots,k),query,mode=mode)
                if root_refs:evidence.event('complete_cached_root_menu_ACK',{**context,'records':root_refs});root_refs.clear()
                replays=[]
                if result['selected']:
                    selected=result['selected'];path=[(root,selected['first'])]
                    if selected['second']:path.append((selected['first_successor'],selected['second']))
                    rebuilt=copy.deepcopy(original)
                    for parent,aid in path:
                        node=ensure(parent);r=next(x for x in log if x['parent']==parent and x['aid']==aid);_,actuate,_=build_verifier(runner.rescue,node['cursor'])
                        draft=actuate(copy.deepcopy(rebuilt),action(r['row']));evidence.context={**context,'phase':'CONTINUOUS_SELECTED_COMMIT_REPLAY','parent':parent,'candidate':r['row']}
                        pp.runpp(draft,**p['solver_kwargs']);target=ensure(r['successor'])['net']
                        assert draft.converged and draft.res_bus.vm_pu.max()<=1.05+1e-8
                        delta=max(abs(prior.fields(draft)[bus][key]-prior.fields(target)[bus][key]) for bus in prior.fields(target) for key in prior.fields(target)[bus])
                        assert delta<=1e-10;replays.append({'parent':parent,'aid':aid,'field_delta':delta,'measured':copy.deepcopy(evidence.last)})
                        rebuilt=draft
                branch_record={**context,'root':root,'initial_metrics':metrics(original),'plan':result,'menus':menus,'query_messages':log,
                    'attributed_costs':branch,'selected_path_replays':replays,'actual_deployment_or_whole_policy_commits':0}
                put(out/f'Branch_{len(results)+1}.json',branch_record)
                results.append({'world':e['world'],'method':mode,'status':result['status'],
                    'endpoint_UV':result['selected']['measured_leaf']['uv_count'] if result['selected'] else metrics(original)['uv_count'],
                    'operations':result['selected']['operations'] if result['selected'] else 0,'attributed_costs':branch})
                evidence.event('branch_closed',{**context,'endpoint':results[-1]})
        wins=losses=0
        for world in p['all_four_worlds']:
            rows={r['method']:r for r in results if r['world']==world};a=rows[METHODS[1]]['endpoint_UV'];b=rows[METHODS[0]]['endpoint_UV']
            wins+=int(a<b);losses+=int(a>b)
        put(out/'Result.json',{'exit_code':0,'all8_branches':results,'strict_UV_wins':wins,'UV_losses':losses,
            'fixed_opportunity_gate':'PASS' if wins>=2 and losses==0 else 'FAIL','actual_new_costs':evidence.costs,
            'numerical_costs':numeric_cost,'science_workflow_seconds_before_manifest':time.perf_counter()-begun,
            'new_model_optimizer_actual_deployment_commits':0,'no_auto_LLM_or_fullpolicy_launch':True})
        exit_code=0
    except BaseException as exc:
        put(out/'Failure.json',{'error':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),
            'partial_costs':evidence.costs if evidence else None,'science_workflow_seconds':time.perf_counter()-begun,
            'unexecuted_and_missing_outcomes':'UNKNOWN','no_retry_or_budget_extension':True})
        raise
    finally:
        if evidence:evidence.close()
        put(out/'Closed_Manifest.json',{'exit_code':exit_code,'members':{str(x.relative_to(out)):sha(x) for x in out.rglob('*') if x.is_file()}})
    print(json.dumps({'all8_bounded_branches_complete':True,'fixed_gate':read(out/'Result.json')['fixed_opportunity_gate'],'new_model_calls':0}))
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--worker',action='store_true');args=a.parse_args()
    assert args.prepare!=args.worker;prepare() if args.prepare else worker()
