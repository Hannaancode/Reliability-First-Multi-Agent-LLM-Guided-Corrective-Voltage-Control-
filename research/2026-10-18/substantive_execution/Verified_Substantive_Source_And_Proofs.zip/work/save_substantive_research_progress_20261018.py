"""Save exact verified results and unfinished work; never invent completion."""
import json,os,hashlib,zipfile
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];B=R/'outputs/substantive_research_progress_20261018'
def read(p):return json.loads(Path(p).read_text('utf-8-sig'))
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,d):
    p.parent.mkdir(exist_ok=True,parents=True);raw=json.dumps(d,indent=2,allow_nan=False);tmp=p.with_suffix(p.suffix+'.new')
    with tmp.open('w',encoding='utf-8') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def main():
    B.mkdir(exist_ok=True);at=datetime.now(timezone.utc).isoformat()
    zero=read(R/'outputs/observed_unclosed_zero_state_audit_20261018/Results.json')
    public=read(R/'outputs/public118_slsqp_native_20261018/independent_audit/Independent_Audit.json')
    numeric=read(R/'outputs/first_missing_paid_numeric_context_20261018/independent_audit/Independent_Audit.json')
    state={'at_utc':at,'status':'ACTIVE_SUBSTANTIVE_RESEARCH_WITH_TWO_ZERO_UV_WORLDS_OBSERVED_STRICT_PUBLIC_BENCHMARK_FAILURES_RETAINED',
        'human_instruction':'Continue until goals reached; no invented superiority, outcome-driven retunes, retries, quota evasion or weakened comparator',
        'new_observed_physical_finding':zero,'public_benchmark':public,'new_exact_numerical_measurement':numeric,
        'actual_cache_binding_and_cold':'V1 and lockedV2 each5parent+6cold checks PASS; native per-use receipt validation and durable ACK before cache return;6OS source-lock boundaries PASS. No new PF/model calls.',
        'complete_cache_path_decision':'1576 exact ordered paid receipts,4exact contexts,5947exact prior forecasts; full plan/menu/native verdict/cost match source.230.818CPUworkflow seconds. No new PF/model/forecasts.',
        'closed_paid_graph_screen':'All5 originally unstarted suffixes inspected,418.447seconds. First missing numerical context now measured and independently certified; four other paths first require missing eligible physical receipt. All remain UNKNOWN, not negative.',
        'current_task':{'source':'work/replay_unstarted_paid_suffix_numeric_v2_20261018.py','output':'outputs/unstarted_paid_suffix_support_screen_numeric_v2_20261018','actual_pid_at_14_53UTC':19048,'shim':10440,
            'role':'ONLY first unstarted suffix with newly certified context+1430forecasts. No repeated other four screens; no new scientific calls. Existing protocol prose inherits all5 wording but code explicit legs[:1], actual selected/input/output scopes one. Preserve this metadata limitation in analysis.',
            'ownership':'Verify fresh exact PID/parent/command and owner.claim; never infer liveness from this checkpoint; no duplicate/restart/extension.'},
        'proposed_queries_at_previous_zero_state':'STOP_NOT_JUSTIFIED;338absent keys at observed zero-UVline36terminal must not enter physics',
        'next_tasks':[
            'Inspect actual single-leg new-input support screen only when terminal or new evidence; retain exact first unknown context/receipt/forecast and all existing source/claims. No fullphysical result from graph projection.',
            'Before any actual newPF, independently close relevant exact source-contract attempted-identity coverage, bind two fixed eligible unexecuted rows/new owner and durable reservation/cold/preservation/independent reader. Mock6checks+cold is software readiness only; no realcoverage certificate yet.',
            'Use missing current-state numerical inputs cheaply and once; only prospectively fixed exact identities with prior-source exclusion. No guessing missing AFTER or treating absent receipts as negatives.',
            'Build common-cost full matched4world receding/hybrid trajectories and genuine fresh original LOCAL model choices/strong equally informed controls only after actual integration, support, causal-input, economic and preservation gates. No idle GPU.',
            'All3 new public SLSQP final points fail fixed5e-6 native gate; STOP this fixed100iteration intervention. Retain near-feasible residuals and costs, not a feasible reference or infeasibility proof. No tolerance/budget/initialization retune to rescue outputs.',
            'Publish closed source/proofs/progress on existing research-progress-20261018 GitHub branch with lease and byte verification; large raw scientific artifacts remain local and listed explicitly.'
        ],'all_six_final_goals':'UNACHIEVED','fresh_LLM_contribution':'NOT_ESTABLISHED','source_full_four_world_gate':'UNKNOWN',
        'old_failed_partial_stopped_sources_and_frozen_assets':'PRESERVED','timers':'NONE_CREATED; recurring cadence not revived','GPU_allocations':'NONE'}
    screen=R/'outputs/unstarted_paid_suffix_support_screen_numeric_v2_20261018/Results.json'
    if screen.exists():
        state['current_task']['terminal_results']=read(screen);state['current_task']['status']='TERMINAL; no owned screen assumed'
    save(B/'Exact_Next_Execution_State.json',state)
    report=f'''CONTINUING SUBSTANTIVE RESEARCH {at}

Before: one observed zero-UV world was verified. After: a second distinct
development world, line36/MG1, independently verifies33 residualUV to0,
24/25 total deviceoperations,12added numerical commits/18added operations,
Vmmin.9513699986812731/Vmmax1.05. This is an archived trained-LLM-prefix
plus numerical-control observation: no freshLLM causal advantage/fullDSE
superiority, no26th fullcheckpoint/RNG or branchclosure inferred.

Actual per-use verified cache and complete cold restore/source locks PASS;
one complete changed-cache-path decision matches1576old paid queries exactly.
All5 unstarted paid-graph suffixes screened with0newscience; missing evidence
staysUNKNOWN. First missing context was separately frozen and measured once:
1derivative/1factor/1solve118RHS and1430full-native-menu forecasts; independent
equations/source/cost/manifest/ninefrozen auditPASS,residual1.84e-17.

New ALL3 published PGLib118 SLSQP solves completed, one100iteration attempt
each, analytic native derivatives/all native constraints; independent audit
complete. ALL3 fixed native5e-6feasibility gatesFAIL: reactive balance errors
1.027e-5/1.847e-5/1.601e-5pu. No bound/tolerance/seed/initialization retune,
no feasible reference/infeasibility/globaloptimum/LLM claim. No GPUallocated.

Continuing ONLY newly supported first paid-graph suffix; exact missing newPF
coverage/persistent integration remains gated. No queries at the alreadyzero
line36terminal. All old failures/partials/stoppedmethods/frozenassets retained.
Exact resume outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_INDEX.md']:
        path=R/rel;old=path.read_text('utf-8-sig');path.write_text(report+old,'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+report);f.flush();os.fsync(f.fileno())
    tasks=read(R/'outputs/research_tasks_20261014/Tasks.json');tasks['at_utc']=at;tasks['latest_exact_execution_state']=str((B/'Exact_Next_Execution_State.json').relative_to(R));tasks['latest_verified_research']=tasks['latest_exact_execution_state']
    t=tasks['tasks'][0];t['status']='TWO_DEVELOPMENT_WORLDS_OBSERVED_ZERO_UV_FULL_DSE_LLM_ALLSEVERE_UNPROVEN';t['done']+=' New18Octsource-prefix independent audit:line36residual33UVto0,24/25operations,upperguardPASS; missing26thcheckpoint/closure retainedUNKNOWN. Cache/cold/source locks andwhole1576receiptdecisionPASS. All5unstartedgraphgaps explicit;1newcontext+1430forecasts independentlyPASS.';t['next']='Follow exact latest resume; no queries at solved terminal. New numerical source gaps/attempt coverage/source/cold/control/economic/reader before genuine unexecuted physics.'
    for t in tasks['tasks'][1:3]:
        t['status']='DISTINCT_ALL3_SLSQP_BENCHMARK_COMPLETE_STRICT_NATIVE_FEASIBILITY_FAIL_MODEL_TEST_PENDING'
        t['done']+=' New18Octall3distinctSLSQPbenchmark actual1attempt100iterations/finalonlyeach; allconstraints/nativeinputs/source/cost auditcomplete, reactivebalance>5e-6 inall3. No threshold/budgetretune, no feasible reference/infeasibilityclaim.'
    tasks['process_ownership_at_save']='Publicscientist/readers and exactnumericworker/reader ended; single-leg read-only support screen may be live, see actual owner/PID, never duplicate.'
    save(R/'outputs/research_tasks_20261014/Tasks.json',tasks)
    (B/'Verified_Results_And_Continuation.md').write_text(report,'utf-8')
    print(json.dumps({'progress_saved':str(B.relative_to(R)),'new_source_and_verified_results_preserved':True}))
if __name__=='__main__':main()
