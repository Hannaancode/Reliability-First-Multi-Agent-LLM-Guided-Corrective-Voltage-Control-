"""Additive correct counter binding for archived cache certification.

Closed query occurrences include cache hits; unique new primary PF attempts
are a different counter. The old prototype and its software evidence remain.
"""
from pathlib import Path
import lazy_paid_lineage_receipts_v1_20261018 as original
text=Path(original.__file__).read_text('utf-8')
before="proof['closed_query_receipts_checked']!=37656 or proof['commits_checked']!=26 or proof['checkpoints_checked']!=25"
after="proof['closed_query_receipts_checked']<37656 or proof['actual_new_costs']['new_query_PF_attempts']!=37656 or proof['commits_checked']!=26 or proof['checkpoints_checked']!=25"
assert text.count(before)==1
changed=text.replace(before,after)
assert changed.replace(after,before)==text
exec(compile(changed,str(Path(__file__)),'exec'),globals())
SOURCE_CERTIFICATE={'original_module':'lazy_paid_lineage_receipts_v1_20261018',
    'exact_counter_repair_only':True,'before':before,'after':after,
    'no_receipt_source_cost_physics_or_performance_change':True}
