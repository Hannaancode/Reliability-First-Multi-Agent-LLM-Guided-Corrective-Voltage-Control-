"""Independent preserved-prefix audit after loss of the exact owned runtime.

No allocation, model, optimizer, physics, remote execution or scientific retry.
"""
from pathlib import Path
from datetime import datetime,timezone
import collections,hashlib,json,math,subprocess
from candidate_process_evidence_utils import ROOT,read,write,sha,seal,frozen_checks
BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
EX=BASE/'pretrained_learning_trainability_execution_v3';PREP=BASE/'pretrained_learning_trainability_preparation_v3'
OUT=BASE/'pretrained_learning_trainability_partial_evidence_audit'
assert not OUT.exists()
state=read(EX/'status.json');availability=read(BASE/'same_assignment_trainability_availability_audit/Fresh_Actual_Assignment_Audit.json')
assert state['stage']=='failed_preserve_actual_partials' and state['finished_at_utc']
assert availability['same_exact_original_notebook']==state['notebook_hash'] and availability['selected_account_authenticated']==state['expected_account']
assert availability['fresh_assignments_before']==availability['fresh_assignments_after']==[]
assert availability['GET_response_type']=='GetAssignmentResponse' and not availability['existing_runtime_proxy_available']
for ident in [11900,21740,6376,6764]:
    r=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {ident}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert not r.stdout.strip(),'Prior exact local owners must have ended before closed audit'
for n,h in read(PREP/'Program_Input_Manifest.json').items():assert sha(ROOT/n)==h
assert read(EX/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
assert read(EX/'staged/remote_frozen_environment.json')==read(PREP/'Expected_Environment.json')
proto=read(PREP/'protocol.json');index=read(PREP/'Input_Index.json');byid={r['observation_id']:r for r in index}
raw=(EX/'live_journals/events.jsonl').read_bytes();assert raw.endswith(b'\n')
events=[json.loads(b) for b in raw.splitlines()]
assert all(a['elapsed_seconds']<=b['elapsed_seconds'] for a,b in zip(events,events[1:]))
assert all(e['arm']=='frozen_original_body_heads' for e in events)
attempts=[e for e in events if e['event']=='forward_attempt'];returns=[e for e in events if e['event']=='forward_return']
back=[e for e in events if e['event']=='backward_attempt'];backret=[e for e in events if e['event']=='backward_return']
steps=[e for e in events if e['event']=='optimizer_return'];stepattempts=[e for e in events if e['event']=='optimizer_attempt']
assert len(attempts)==499 and len(returns)==498 and len(back)==len(backret)==len(steps)==len(stepattempts)==187
assert [e['call'] for e in attempts]==list(range(1,500)) and [e['call'] for e in returns]==list(range(1,499))
assert [(e['call'],e['phase'],e['observation_id']) for e in returns]==[(e['call'],e['phase'],e['observation_id']) for e in attempts[:-1]]
assert [e['observation_id'] for e in attempts if e['phase']=='untrained']==sorted(byid)
assert [e['observation_id'] for e in attempts if e['phase']=='training']==proto['exact_optimization_order']+[proto['exact_optimization_order'][0]]
assert [e['observation_id'] for e in steps]==[e['observation_id'] for e in stepattempts]==[e['observation_id'] for e in back]==proto['exact_optimization_order']
assert [e['step'] for e in steps]==[e['step'] for e in stepattempts]==list(range(1,188))
assert all(e['epoch']==1 for e in steps)
for e in back:
    expected=187/(22*proto['optimization_world_target_counts'][byid[e['observation_id']]['world_sha256']])
    assert e['world_weight']==expected and math.isfinite(e['loss'])
assert all(e['actual_gradient_tensors']==29 and math.isfinite(e['gradient_clip_norm']) for e in backret)
assert all(math.isfinite(e['seconds']) and e['seconds']>=0 for e in returns)
gate=events[0];assert gate['event']=='actual_load_and_trainability_gate_passed'
assert gate['load']['actual_final_body_trainable_parameters']==gate['load']['trainable_body_parameters']==0
assert gate['load']['exact_copied_tensors']==336 and gate['load']['enabled_disabled_restored_unmerged']
assert gate['actual_wrapper_parameters']==289759
checkpoints=[e for e in events if e['event']=='epoch_checkpoint_preserved'];assert len(checkpoints)==1 and checkpoints[0]['epoch']==1 and checkpoints[0]['actual_steps']==187
assert not (EX/'staged/study').exists() and not list((EX/'early_epoch_preservation').rglob('*.pt'))
assert not (BASE/'pretrained_learning_trainability_external_audit_v3').exists()
assert not any(e['event'] in ['forward_exception','terminal_failure','science_complete','arm_complete'] for e in events)
OUT.mkdir()
compute={'recorded_forward_attempts_lower_bound':499,'recorded_forward_returns_lower_bound':498,'recorded_optimizer_returns_lower_bound':187,
 'recorded_backward_returns_lower_bound':187,'recorded_soft_positions_attempted_lower_bound':499*237,'recorded_soft_positions_returned_lower_bound':498*237,
 'recorded_typed_inputs_attempted_lower_bound':sum(byid[e['observation_id']]['typed_records'] for e in attempts),
 'recorded_UTF8_bytes_attempted_lower_bound':sum(byid[e['observation_id']]['value_utf8_bytes'] for e in attempts),
 'recorded_returned_forward_seconds_lower_bound':sum(e['seconds'] for e in returns),
 'recorded_backward_interval_seconds_lower_bound':sum(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(back,backret)),
 'recorded_optimizer_interval_seconds_lower_bound':sum(b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(stepattempts,steps)),
 'recorded_model_load_seconds':gate['load']['model_load_seconds'],
 'observed_scientific_journal_elapsed_seconds_lower_bound':events[-1]['elapsed_seconds'],
 'last_inflight_forward_return_unknown':499,'unobserved_subsequent_calls_costs_remote_termination_time_and_cause':'UNKNOWN'}
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'preserved_prefix_integrity_identity_and_cost_arithmetic_passed':True,
 'scientific_outcome_status':'TERMINAL PARTIAL; both learning and physical-readiness gates UNKNOWN',
 'actual_notebook_hash':state['notebook_hash'],'actual_recorded_compute':compute,
 'all_311_untrained_forward_returns_and_exact_first_187_training_world_prefix_verified':True,
 'actual_first_epoch_checkpoint_write_event_sha256':checkpoints[0]['sha256'],
 'epoch1_checkpoint_bytes_not_recovered_no_checkpoint_reproduction_or_performance_claim':True,
 'same_assignment_authenticated_GET_has_no_assignment_or_runtime_proxy':True,
 'intentional_release_not_claimed_old_runtime_released_false_preserved':True,
 'all_remote_actual_artifacts_preserved_NOT_established':True,
 'recorded_model_copy_initial_values_and_requested_frozen_mask_gates_passed':True,
 'final_original_remote_base_copy_parameter_preservation_unknown':True,
 'later_frozen_steps_copied_arm_completion_losses_final_predictions_and_reload_unknown':True,
 'no_recorded_solver_or_generation_calls_actual_unobserved_totals_unknown':True,
 'new_reader_model_optimizer_PF_or_allocation_calls':0,'no_scientific_rerun_or_profile_fallback':True,
 'overall_LLM_value_DSE_superiority_unachieved':True,'source_sha256':sha(Path(__file__))}
write(OUT/'Independent_Preserved_Prefix_Audit.json',report)
write(OUT/'Fresh_Frozen_Asset_Audit.json',frozen_checks())
(OUT/'Results.md').write_text('''# Preserved partial learning evidence\n\nThe exact Sheena T4 assignment became unreachable. Selected-account authentication, two fresh assignment lists and a GET for the same notebook found no current assignment or runtime proxy. No replacement allocation, account fallback, kernel execution, learning rerun or physics call was attempted. The cause and exact termination time are unknown. The lingering failed local control executor was stopped only after its main had ended and fresh remote checks proved no reachable assignment; the waiting handoff then ended without starting a complete-only reader.\n\nThe preserved append-only journal verifies 499 attempted and 498 returned pretrained forwards, 187 backward/optimizer returns in the fixed first-epoch order, the real frozen-body gradient mask and exact initial adapter restoration gates. These are lower bounds on actual cost, not complete study counts. The first-epoch checkpoint write and its hash were recorded, but checkpoint bytes were not retrieved. Later execution, final predictions, fresh checkpoint replay, both-arm comparisons, final remote tensor preservation and the two scientific decision gates remain UNKNOWN. No negative learning result or superiority conclusion is inferred.\n\nAll preserved scientific and control partials, failed sources/claims and nine fresh local frozen-asset gates are sealed. Original scientific settings, adverse prior studies and the baseline remain unchanged. This partial attempt is terminal; no automatic retraining, parameter tweak or checkpoint selection is authorized by the prospective protocol. A future resource-reliable study needs a separate justified prospective plan and ownership/preservation protocol.\n''',encoding='utf-8')
files={p.relative_to(ROOT).as_posix():p for p in EX.rglob('*') if p.is_file()}
for folder in ['pretrained_learning_trainability_audit_continuation_v3','same_assignment_trainability_availability_audit','trainability_continuation_launch_v3']:
    for p in (BASE/folder).rglob('*'):
        if p.is_file(): files[p.relative_to(ROOT).as_posix()]=p
for name in ['protocol.json','Cloud_Payload_Manifest.json','Launch_Readiness_Audit.json','Additive_Source_Adaptation_Audit.json','Program_Input_Manifest.json']:
    files['preparation/'+name]=PREP/name
for name in ['run_candidate_process_learning_trainability_v3_colab.py','continue_candidate_process_learning_trainability_v3_audit.py','candidate_process_pretrained_learning_trainability_v3_remote.py','candidate_process_pretrained_loader_trainability_v2.py','candidate_process_trainability_contract_v2.py','inspect_candidate_trainability_same_assignment.py','audit_candidate_same_assignment_availability.py','audit_candidate_trainability_unreachable_partial.py']:
    files['sources/'+name]=ROOT/'work'/name
for p in OUT.iterdir():files[p.name]=p
archive=seal(OUT,files,'Preserved_Unreachable_Runtime_Partial_Evidence.zip')
write(OUT/'status.json',{'stage':'terminal_partial_evidence_independently_sealed','actual_result_gates':'UNKNOWN','archive':archive})
print(json.dumps({'preserved_integrity_passed':True,'compute_lower_bounds':compute,'scientific_gates':'UNKNOWN','archive':archive},indent=2))
