"""Independent numerical-replay identity/metric/cost audit, zero new solves."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/vcsa_development/state_control_selected_replay'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (OUT/'independent_audit.json').exists()
manifest=read(OUT/'manifest.json')
for name,info in manifest.items():
    p=(OUT/name).resolve(); assert p.is_relative_to(OUT.resolve())
    assert p.stat().st_size==info['bytes'] and sha(p)==info['sha256']
protocol=read(OUT/'protocol.json'); assert sha(Path(__file__).with_name('replay_vcsa_state_control_actions.py'))==protocol['source_sha256']
for name,digest in protocol['frozen_sources'].items(): assert sha(ROOT/name.replace('\\','/'))==digest
for scenario,digest in protocol['scenario_sha256'].items(): assert sha(ROOT/f'work/e/pack/scenarios/federation/{scenario}.json')==digest
data=ROOT/'outputs/vcsa_development/training_interface'; control=ROOT/'outputs/vcsa_development/state_only_pilot'
assert sha(data/'manifest.json')==protocol['data_manifest_sha256'] and sha(control/'manifest.json')==protocol['control_manifest_sha256']
for folder in [data,control]:
    for name,info in read(folder/'manifest.json').items(): assert sha(folder/name)==info['sha256']
source={r['local_observation_id']:r for r in read(data/'rows.json')}
actions={r['id']:r for r in read(control/'final_rows.json')}
records=[r for p in (OUT/'worlds').glob('*.json') for r in read(p)['records']]
assert len(records)==len({r['id'] for r in records})==48 and set(source)=={r['id'] for r in records}
checks=0
for r in records:
    row=source[r['id']]; assert (r['scenario_id'],r['split'],r['zone'])==(row['scenario_id'],row['split'],row['zone'])
    assert r['scenario_sha256']==row['scenario_sha256']
    if not row['training_eligible']:
        assert r['retained_invalid_input'] and r['hard_abstained']; continue
    a=actions[r['id']]['action']; assert r['action']=={'add_shunts_q_mvar':{str(a['bus']):float(a['q_mvar'])}}
    candidate=next(l for l in row['candidate_labels'] if l['bus']==a['bus'] and l['q_mvar']==a['q_mvar'])
    after=r['independent_replay_metrics']; verifier=r['original_verification']['after']
    assert after is not None and verifier is not None and candidate['after_metrics'] is not None
    for k in after:
        assert abs(after[k]-verifier[k])<=1e-10 and abs(after[k]-candidate['after_metrics'][k])<=1e-10
    assert len(r['replayed_bus_voltages'])==118
    assert abs(min(r['replayed_bus_voltages'].values())-after['vmin'])<=1e-10
    assert abs(max(r['replayed_bus_voltages'].values())-after['vmax'])<=1e-10
    assert sum(v<.95 for v in r['replayed_bus_voltages'].values())==after['uv_count']
    assert r['normal_guard_admissible']==bool(candidate['guard_admissibility_target'])
    assert r['strict_UV_zero_and_normal_upper']==(after['uv_count']==0 and after['vmax']<=1.05+1e-8)
    checks+=1
summary=read(OUT/'summary.json'); costs=summary['costs']
assert summary['passed'] and checks==47
assert {phase:costs[phase]['attempts'] for phase in costs}==protocol['phases']
assert sum(c['attempts'] for c in costs.values())==139 and all(c['exceptions']==0 and c['returns']==c['attempts'] for c in costs.values())
for split in ['train','validation']:
    assert summary['split_counts'][split]['admissible']==sum(r['split']==split and r.get('normal_guard_admissible',False) for r in records)
report={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'passed':True,'manifest_members':len(manifest),
        'exact_worlds':45,'exact_views':48,'continuous_selected_action_replays':checks,
        'actual_PF_attempts_verified':139,'actual_PF_exceptions':0,'audit_PF_calls':0,'audit_model_calls':0,
        'generator_and_line_diagnostics':'No recorded finite bound violations. Missing-line-bound count includes an intentionally unprovided lower bound and does not establish missing upper limits; scope is snapshot finite gen/line bounds, not certified full operating feasibility.',
        'one_state_UV_clearances':0,'no_LLM_or_full_DSE_superiority_claim':True,'source_sha256':sha(Path(__file__))}
(OUT/'independent_audit.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report))
