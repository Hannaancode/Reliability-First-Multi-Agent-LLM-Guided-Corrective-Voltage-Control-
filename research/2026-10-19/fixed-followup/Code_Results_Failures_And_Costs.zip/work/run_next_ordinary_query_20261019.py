import argparse,json
from pathlib import Path
from next_ordinary_query_core_20261019 import B,helpers,worker,fixture_warm,fixture_cold
from public118_slsqp_native_20261018 import R,read,put

def coordinator():
    p=read(B/'Protocol.json');assert read(B/'Readiness.json')['status']=='PASS_FIXED_SINGLE_QUERY_PRELAUNCH_ZERO_SCIENCE';h=helpers(__file__);codes={}
    try:
        codes['warm']=h['launch'](Path(__file__),'warm',B/'warm',p)
        codes['audit']=h['launch'](R/p['independent_reader_source'],'reader',B/'audit',p)
    finally:put(B/'Completion.json',{'exit_codes':codes,'no_retries':True,'no_model_GPU_calls':True})
    print(json.dumps({'single_query_exit_codes':codes}))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for flag in ['coordinator','warm','fixture-warm','fixture-cold']:p.add_argument('--'+flag,action='store_true')
    a=p.parse_args()
    if a.warm:worker(__file__)('warm')
    elif a.fixture_warm:fixture_warm(__file__)
    elif a.fixture_cold:fixture_cold(__file__)
    else:coordinator()
