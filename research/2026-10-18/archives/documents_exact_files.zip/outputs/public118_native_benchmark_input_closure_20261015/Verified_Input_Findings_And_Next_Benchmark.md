# Native published benchmark: independently verified input contract

Saved 2026-10-14T22:05:18.933836+00:00. All three previously selected pinned PGLib118 variants retain every raw bus/gen/branch/gencost column, native angle/thermal/voltage/generator limits and cost objective in a full native PPC representation. Independent parser/identity audit passed. Original raw files and original three converted NETs remain untouched.

Installed from_ppc source imports ANGMIN/ANGMAX but does not read those values. Consequently its NET import alone cannot establish faithful native angle-constrained OPF benchmarking. The direct full-PPC native path preserves them; pinned native opf_setup calls makeAang, and OPF_IGNORE_ANG_LIM is explicitly false. This is source/input readiness, not an executed solver or constraint-feasibility certificate.

Earlier exact-decimal necessary-condition audit excludes all three RAW fixed-nonslack dispatch roles from respecting native Pmax, with optimistic active-power shortfalls393.5MW/2465.32MW/393.5MW before losses. It does not exclude generation-redispatch/ACOPF or establish voltage/controller infeasibility.

Next: freeze and implement a separately owned all-three native OPF/initialization solver and independent full objective/constraint/cost reader; retain all failures and no outcomes-driven solver/tolerance/initialization retries. Then specify matched discrete protected shunt-control/public model tests. Native OPF's P/Q/V actuators/objective differ from the original shunt controller; native published scores cannot be transferred into an LLM superiority claim. Four original zones and95%-105% protection are disclosed adaptations. Complete original DFF/DFF-ALT/DSE FULLBOTH costs and equally capable numerical/learned controls remain necessary.

This preparation made0OPF/PF/model/converter/derivative/forecast/solve calls. Packaging and independent reader CPU timings are retained in their result files; prior input/converter/preparation costs remain payable. The full receding physics campaign continues under its independently frozen sources; none was edited by this parallel preparation.
