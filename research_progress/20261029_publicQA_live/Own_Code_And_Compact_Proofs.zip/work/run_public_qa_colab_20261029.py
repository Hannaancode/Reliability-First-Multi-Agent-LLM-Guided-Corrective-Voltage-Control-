"""Fixed-profile T4 owner; one allocation, one setup, one science process tree."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import quote
import argparse, ast, base64, hashlib, json, logging, os, time, uuid, zipfile
import requests
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession, Request
from colab_cli.client import Client, Prod, Variant, Accelerator
from colab_cli.runtime import ColabRuntime
from public_qa_transfer_20261029 import read, json_once, write_once, accept_packet, sha

R=Path(__file__).resolve().parents[1]
class BoundedSession(AuthorizedSession):
    def request(self,*args,**kwargs): kwargs.setdefault('timeout',(10,30));return super().request(*args,**kwargs)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--protocol',required=True);ap.add_argument('--arm',required=True);args=ap.parse_args()
    protocol=read(args.protocol);arm=next(x for x in protocol['arms'] if x['id']==args.arm)
    assert protocol['launch_ready'] is True
    for relative,h in protocol['source_hashes'].items(): assert sha((R/relative).read_bytes())==h
    out=R/arm['execution'];out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    json_once(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__).read_bytes()),
        'command':__import__('sys').argv,'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (out/'Launcher_ACK.json').exists():
        assert time.monotonic()-start<60;time.sleep(.1)
    ack=read(out/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    state={'arm':args.arm,'allocation_requests':0,'runtime_allocated':False,'runtime_released':False,
        'all_artifacts_preserved':False,'actual_remote_child_ended':False,'science_started':False,'started_at_utc':datetime.now(timezone.utc).isoformat()}
    client=runtime=session=assignment=None;safe_release=True;nbh=uuid.uuid4();refreshed=0;transfers=[]
    def save():
        state['wall_seconds']=time.monotonic()-start
        p=out/'status.tmp';p.write_text(json.dumps(state,indent=2),'utf-8');p.replace(out/'status.json')
    def fresh():
        nonlocal assignment,refreshed
        current=client._get_assignment(nbh,variant=Variant.GPU,accelerator=Accelerator.T4)
        assert current.endpoint==state['endpoint'] and current.runtime_proxy_info is not None
        assignment=current;refreshed=time.monotonic()
    def content(method,path,payload=None,file=False):
        # Re-reading a preserved file or writing identical bytes is idempotent;
        # no runtime code execution or allocation is retried here.
        for attempt in range(3):
            if time.monotonic()-refreshed>90:fresh()
            began=time.monotonic();record={'method':method,'path':path,'returned':False,'transfer_attempt':attempt+1}
            try:
                response=requests.request(method,assignment.runtime_proxy_info.url.rstrip('/')+'/api/contents/'+quote(path,safe='/'),
                    params={'authuser':'0','colab-runtime-proxy-token':assignment.runtime_proxy_info.token,'content':'1',
                        **({'format':'base64'} if method=='GET' and file else {})},json=payload,timeout=(10,30))
                record['http_status']=response.status_code
                if response.status_code==404:raise FileNotFoundError(path)
                response.raise_for_status();record['returned']=True;record['response_bytes']=len(response.content);return response.json()
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                if attempt==2:raise
                time.sleep(1)
            finally:
                record['seconds']=time.monotonic()-began;transfers.append(record)
    def raw(path):
        v=content('GET',path,file=True)
        return base64.b64decode(v['content']) if v.get('format')=='base64' else str(v['content']).encode()
    def execute(code):
        ast.parse(code);values=runtime.execute_code(code,allow_stdin=False,timeout=45)
        assert not any(v.get('output_type')=='error' for v in values)
    def wait_file(path,bound):
        began=time.monotonic()
        while time.monotonic()-began<bound:
            try:return raw(path)
            except FileNotFoundError:time.sleep(3)
        raise TimeoutError('Exact existing remote stage exceeded collection wait; do not launch again')
    remote='content/hiergrid_public_qa_'+args.arm
    try:
        payload=R/arm['payload'];assert sha(payload.read_bytes())==arm['payload_sha256']
        credential=Path(os.environ['APPDATA'])/arm['credential_directory']/'application_default_credentials.json'
        credentials=Credentials.from_authorized_user_file(str(credential));transport=Request()
        def refresh(*a,**k):k.setdefault('timeout',25);return transport(*a,**k)
        credentials.refresh(refresh);session=BoundedSession(credentials,refresh_timeout=30,max_refresh_attempts=0)
        identity=session.get('https://www.googleapis.com/oauth2/v2/userinfo');identity.raise_for_status()
        assert sha(identity.json()['email'].casefold().encode())==arm['account_sha256']
        client=Client(Prod(),session);assert not client.list_assignments(),'Existing assignment; do not duplicate'
        response=session.get('https://colab.research.google.com/tun/m/ccu-info',params={'authuser':'0'},headers={'X-Colab-Client-Agent':'colab-cli','Accept':'application/json'})
        response.raise_for_status();eligibility=json.loads(response.text.removeprefix(")]}'\n"));assert 'T4' in eligibility.get('eligibleGpus',[])
        json_once(out/'Preallocation.json',{'account_sha256':arm['account_sha256'],'assignment_count':0,'eligible_gpus':eligibility['eligibleGpus'],
            'remaining_hours':'UNKNOWN','reset':'UNKNOWN'})
        state.update(allocation_requests=1,notebook_hash=str(nbh),stage='allocating_fixed_profile');save()
        assignment=client.assign(nbh,variant=Variant.GPU,accelerator=Accelerator.T4)
        assert assignment.accelerator==Accelerator.T4
        state.update(runtime_allocated=True,endpoint=assignment.endpoint);refreshed=time.monotonic();save()
        runtime=ColabRuntime(url=assignment.runtime_proxy_info.url,token=assignment.runtime_proxy_info.token,session_name='hiergrid-fixed-public-qa')
        parts=[];b=payload.read_bytes()
        for i,offset in enumerate(range(0,len(b),2*1024*1024)):
            path=f'content/qa_{args.arm}_{i:03d}.bin';parts.append('/'+path)
            content('PUT',path,{'type':'file','format':'base64','content':base64.b64encode(b[offset:offset+2*1024*1024]).decode()})
        code="from pathlib import Path\nimport hashlib,io,zipfile,json\nraw=b''.join(Path(p).read_bytes() for p in "+repr(parts)+")\nassert hashlib.sha256(raw).hexdigest()=="+repr(arm['payload_sha256'])+"\nr=Path("+repr('/'+remote)+")\nr.mkdir(exist_ok=False)\nwith zipfile.ZipFile(io.BytesIO(raw)) as z:\n assert z.testzip() is None\n for n,m in json.loads(z.read('Manifest.json')).items():\n  assert '/' not in n and '\\\\' not in n and ':' not in n and n not in ['.','..']\n  b=z.read(n);assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']\n  (r/n).write_bytes(b)\n"
        execute(code)
        # Bootstrap parent reaps the actual setup child before publishing Setup_Reaped.
        bootstrap="import subprocess,sys,json\nfrom pathlib import Path\nr=Path("+repr('/'+remote)+")\np=subprocess.Popen([sys.executable,'public_qa_remote_setup_20261029.py'],cwd=r)\nc=p.wait(timeout=1850)\n(r/'Setup_Reaped.json').write_text(json.dumps({'pid':p.pid,'exit_code':c,'actual_setup_child_ended':True}))\n"
        safe_release=False;state['stage']='bounded_setup';save()
        execute("import subprocess,sys\np=subprocess.Popen([sys.executable,'-c',"+repr(bootstrap)+"])\nprint(p.pid)")
        reaped=json.loads(wait_file(remote+'/Setup_Reaped.json',1900));assert reaped['actual_setup_child_ended']
        for name in ['setup.log','Setup_End.json','Setup_Reaped.json']:write_once(out/name,raw(remote+'/'+name))
        safe_release=True
        if reaped['exit_code']!=0:
            state.update(all_artifacts_preserved=True,actual_remote_child_ended=True,no_scientific_entry=True)
            raise RuntimeError('Setup failed before scientific entry')
        write_once(out/'environment.json',raw(remote+'/environment.json'))
        gate=raw(remote+'/Linux_Watchdog_Gate.json');assert json.loads(gate)['status']=='PASS_TWO_ACTUAL_LINUX_CHILD_STOPS'
        write_once(out/'Linux_Watchdog_Gate.json',gate)
        bootstrap="import subprocess,json\nfrom pathlib import Path\nr=Path("+repr('/'+remote)+")\np=subprocess.Popen(['env/bin/python','public_qa_remote_supervisor_20261029.py','--root',str(r)],cwd=r)\nc=p.wait(timeout=8000)\n(r/'Supervisor_Reaped.json').write_text(json.dumps({'pid':p.pid,'exit_code':c,'actual_supervisor_ended':True}))\n"
        safe_release=False;state.update(stage='science_with_local_ack',science_started=True);save()
        execute("import subprocess,sys\np=subprocess.Popen([sys.executable,'-c',"+repr(bootstrap)+"])\nprint(p.pid)")
        number=0;began=time.monotonic()
        while time.monotonic()-began<8400:
            try:descriptor=json.loads(raw(remote+f'/transfer/packet_{number:03d}/descriptor.json'))
            except FileNotFoundError:time.sleep(1);continue
            assert descriptor['number']==number
            blocks=[raw(remote+f'/transfer/packet_{number:03d}/'+part['name']) for part in descriptor['parts']]
            ack=accept_packet(descriptor,blocks,out)
            content('PUT',remote+f'/transfer/ack_{number:03d}.json',{'type':'file','format':'text','content':json.dumps(ack)})
            json_once(out/'packets'/f'packet_{number:03d}'/'ACK.json',ack)
            state['preserved_packets']=number+1;save();number+=1
            if descriptor['terminal']:
                remote_end=json.loads(wait_file(remote+'/Remote_End.json',30))
                reaped=json.loads(wait_file(remote+'/Supervisor_Reaped.json',30))
                assert remote_end['actual_child_ended'] and reaped['actual_supervisor_ended']
                for name in ['Remote_End.json','Supervisor_Reaped.json','supervisor.claim','child_launch.json','worker.log']:
                    write_once(out/name,raw(remote+'/'+name))
                state.update(actual_remote_child_ended=True,all_artifacts_preserved=True,stage='preserved_complete_or_partial')
                safe_release=True;save();break
        else:raise TimeoutError('Collector bound; preserve existing assignment, no retry')
    except BaseException as error:
        state.update(stage='failed_or_uncertain',failure_type=type(error).__name__,
            failure_http_status=getattr(getattr(error,'response',None),'status_code',None))
        # No raw request exception strings: they can contain proxy tokens.
        json_once(out/'Failure.json',{'failure_type':type(error).__name__,'http_status':getattr(getattr(error,'response',None),'status_code',None)})
    finally:
        if runtime:
            try:runtime.stop()
            except Exception:pass
        if client and state['allocation_requests']==1 and not state['runtime_allocated'] and state.get('failure_http_status') not in (401,403,429):
            # Resolve an ambiguous assign response by GET on the SAME notebook only.
            # A genuine denial remains a denial; no allocation or account fallback.
            try:
                recovered=client._get_assignment(nbh,variant=Variant.GPU,accelerator=Accelerator.T4)
                if getattr(recovered,'runtime_proxy_info',None) is not None:
                    state.update(runtime_allocated=True,endpoint=recovered.endpoint,assignment_recovered_by_exact_GET=True)
            except Exception as e:state['same_assignment_lookup_failure_type']=type(e).__name__
        if client and state['runtime_allocated'] and safe_release:
            try:
                client.unassign(state['endpoint']);state['runtime_released']=not any(a.endpoint==state['endpoint'] for a in client.list_assignments())
            except Exception as e:state['release_failure_type']=type(e).__name__
        if session:session.close()
        json_once(out/'Transfer_Costs.json',transfers)
        state['finished_at_utc']=datetime.now(timezone.utc).isoformat();save()
        json_once(out/'Host_End.json',{'status':state['stage'],'all_artifacts_preserved':state['all_artifacts_preserved'],
            'runtime_released':state['runtime_released'],'wall_seconds':state['wall_seconds']})
    if not state['all_artifacts_preserved'] or not state['runtime_released']:raise SystemExit(1)
if __name__=='__main__':logging.disable(logging.CRITICAL);main()
