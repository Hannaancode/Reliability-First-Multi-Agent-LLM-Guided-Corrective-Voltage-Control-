"""Polar recheck of12newly parsed near-limit rows; nominal24 keep prior audit."""
import os,time,json
import numpy as np
import audit_pfdelta_near_limit_schema_v2_20261019 as repair
import audit_pfdelta_fixed36_native_20261019 as old
from public118_slsqp_native_20261018 import R,read,put,sha,manifest

def main():
    B=repair.B;out=B/'independent_polar_audit';out.mkdir(exist_ok=False);start=time.perf_counter();p=read(B/'Protocol.json')
    assert sha(__file__)==p['reader_source_sha256'] and sha(repair.__file__)==p['source_sha256'] and sha(old.__file__)==p['original_source_sha256']
    for rel,h in read(B/'Closed_Manifest.json')['members'].items():assert sha(B/rel)==h
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    original={v['file']:v for v in read(old.B/'Results.json')['rows']};deltas=[]
    for row in read(B/'Results.json')['rows']:
        if row['file'] not in p['missing12_files']:
            assert all(row[k]==original[row['file']][k] for k in ['identity','file','sha256','native']);continue
        path=old.BASE/'selected36'/row['file'];assert sha(path)==row['sha256'];data=repair.normalize(read(path))
        second=old.evaluate(data,old.polar_flows);first=row['native'];e=old.extract(data)
        delta=float(np.max(abs(old.complex_flows(e)-old.polar_flows(e))));assert delta<1e-10
        for family in ['equation_residuals','operating_limit_violations']:
            for k,v in second[family].items():assert abs(v-first[family][k])<=1e-10
        for k in ['PF_equations_pass','all_checked_operating_limits_pass','UV_below_original_0p95','OV_above_original_1p05plus1e8','active_branches','inactive_branches','reference_above_original_guard']:assert second[k]==first[k]
        deltas.append({'file':row['file'],'polar_complex_max_delta_pu':delta})
    assert len(deltas)==12
    put(out/'Independent_Audit.json',{'status':'PASS_ALL36_COMPLETE_SCHEMA_IDENTITY_AND_UNCHANGED_NATIVE_EQUATION_CHECKS','new12_polar_checks':deltas,'reused24_original_audit_sha256':sha(old.B/'independent_polar_audit/Independent_Audit.json'),
       'new_scientific_calls':0,'workflow_seconds':time.perf_counter()-start,'limits':'Audit consistency is not dataset operational feasibility, our-model performance or a selected positive-control benchmark.'})
    manifest(out);print(json.dumps({'all36':'PASS_SCHEMA_EQUATION_AUDIT','newPF':0}))

if __name__=='__main__':main()
