# Bottlenecks and strategy reset

## What the latest evidence actually says

All23 declared OPT worlds and both46 guarded branches were retained. The independent reader checked their terminal native states, saved menus, exact cap predicate, unchanged upper band, source/input/manifest identities and world denominators. Eight held raw branch files stayed unread. No PF, model, optimizer, controller, numerical forecast, converter or derivative was called.

33 branches ended with zero undervoltage;13 ended with undervoltage remaining and no accepted next action. No branch exhausted the25-action limit. Support-cap rejection appeared in only2 of those13 residual branches. All13 had measured isolated actions that would lower UV but exceeded the unchanged1.05+1e-8 upper-voltage guard. Those actions remain unsafe and are not trusted successors. Branch/state counts are correlated observations, not independent samples.

This changes the diagnosis: lack of steps is not an observed bottleneck; support caps are a limited part of it. The main observed obstacle is protecting the other buses while repairing undervoltage. This does NOT prove that a better safe earlier allocation is impossible, nor that language models cannot help.

The prior all31 scalar result remains: original literal D-SE already has zero terminal UV in24 worlds. Only7 have any possible strict UV win. A larger network or lower training loss cannot create a strict UV win in a world whose baseline count is already zero. The positive residual worlds are not to be selected as a favorable benchmark.

## A planning mistake exposed before new physics

The just-frozen draft asked for support in at least2 families. The independent reader found that primary headroom against BOTH saved D-SE and guarded controls exists only in the combined-stress family on the declared OPT bank. Thus that cross-family design gate could not pass. The draft is rejected; its threshold is not lowered or rerun. This is a design-feasibility failure, not an executed failure of all sequence planning. All new counterfactual outcomes remain UNKNOWN.

## What the earlier experiments establish

Original0.5B command-format learning is preserved. Format competence does not demonstrate better protected grid decisions. Dense-copy, relational and VCSA learning did not establish the required incremental benefit and remain stopped. The public1.5B screen did not use an equivalently adapted serving/training contract, so it is not proof that trained1.5B cannot help. No matched adapted1.5B superiority study has completed.

Much of the saved supervision consists of one-step outcomes on repeated physical worlds. It cannot provide truthful terminal rewards for unmeasured alternative trajectories. The later-fork inventory found no directly paired later continuation targets. This matters more than nominal row count or model size. Numerical competitors also receive very strong information and can evaluate the same fixed action menu directly; another classifier may reproduce a decision that the comparator already computes.

## Changed execution strategy

1. Stop additional learning while its physical opportunity is unresolved. Keep all failed routes, sources, costs and gate decisions intact.
2. Specify a source-consistent optimistic physical feasibility/headroom analysis. It must include the unchanged network/scenario, positive shunt grammar, original caps, terminal voltage rules and original electrical assumptions. A valid relaxation may deliberately give a numerical solver MORE freedom to bound what any allowed allocation could achieve; that extra freedom cannot become a deployed-controller claim.
3. Distinguish a certified impossibility bound from a numerical candidate. Infeasibility of a local linear approximation or a failed optimizer is NOT physical impossibility. A relaxation that is feasible also does NOT prove a legal native trajectory. Any certificate needs an independently checked superset formulation, residual/dual arithmetic and all missing-assumption disclosures.
4. If a promising numerical allocation exists, freeze its exact discretization/irreversible sequence, fresh role IDs, native verification/protection/replay, all-world denominators, bounded ownership and full costs BEFORE evaluating it. Existing receipts are paid historical evidence, not free online tools; no old PF call is repeated to recover an artifact.
5. Only a surviving actual protected numerical opportunity can justify an LLM-specific hypothesis, equal-information/capacity numerical controls, actual causal model integration and one prospective learning pilot. A numerical success by itself is not LLM value. Final superiority still needs fresh inference, full D-SE BOTH costs and unused authorized confirmation.

This is the changed research direction, not a launch-ready solver or a90percent probability of finding a win. Optimistic AC relaxation modeling, exact source-bound matrix availability, interval/dual checking, actual optimizer readiness, scalar/native protection semantics and the bounded physical protocol remain unfinished. No current GPU or physical campaign is authorized by these software/data checks.

## Focused literature check

[LLM as an Operator](https://arxiv.org/pdf/2507.14800) addresses day-ahead OLTC/capacitor scheduling with coarse forecasts and retrieved experience. Its listed ablations remove control, experience, modification or reasoning; that list does not establish superiority over our full-cost D-SE and strong numerical controls. Its different information setting is not evidence that a larger classifier on our fixed numeric snapshots should win. This is an inference about transfer, not a replication result.

[Two-Stage LLM-RL voltage control](https://arxiv.org/pdf/2602.21715) gives the LLM coarse forecasts and semantic instructions for OLTC/capacitor scheduling, while RL handles precise inverter regulation. That division offers a specific reason language processing might matter. Our frozen static numerical action task lacks that same demonstrated semantic distinction; copying its headline result would not supply the missing attribution. This is a relevance assessment, not proof that its method fails here.

The IEEE2021 paper [voltage/reactive-power optimization with equipment operation loss](https://ieeexplore.ieee.org/document/9621667) already describes rolling MPC and MISOCP in its indexed abstract. Multi-step reactive planning therefore cannot be treated as novelty by itself. Full publisher access failed at robot verification; the present note relies only on the indexed abstract for this limited point.

All conclusions above remain development evidence. Original baseline assets, literal selector zero/missing handling, guard thresholds and stopped scientific protocols are unchanged.
