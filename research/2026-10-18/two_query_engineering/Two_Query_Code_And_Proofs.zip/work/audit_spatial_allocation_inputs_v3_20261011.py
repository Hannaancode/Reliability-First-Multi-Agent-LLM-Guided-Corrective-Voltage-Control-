"""Mechanical input identity repair; all exact table checks retained.

Original raw-pickle hash failure is preserved. Pickle byte identity is not
used as cross-process table-value identity. No outcome, PF or model is read.
"""
import copy,hashlib,json,math,os,sys,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack,AUDIT
from audit_spatial_allocation_inputs_v2_20261011 import independent_apply
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010'
PREP=BASE/'spatial_allocation_input_preparation_v2_20261011'
OUT=BASE/'spatial_allocation_input_audit_v3_20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):
    with (OUT/name).open('x',encoding='utf8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def typed(v):
    if isinstance(v,np.generic):v=v.item()
    if v is None:return ['None']
    if v is pd.NA:return ['pandas_NA']
    if v is pd.NaT:return ['pandas_NaT']
    if type(v) is bool:return ['bool',v]
    if type(v) is int:return ['int',str(v)]
    if type(v) is float:return ['float',v.hex() if math.isfinite(v) else ('nan' if math.isnan(v) else 'inf' if v>0 else '-inf')]
    if type(v) is str:return ['str',v]
    if isinstance(v,(tuple,list)):return [type(v).__name__,[typed(x) for x in v]]
    if isinstance(v,dict):return ['dict',sorted([[typed(k),typed(x)] for k,x in v.items()],key=lambda p:json.dumps(p[0],sort_keys=True))]
    if isinstance(v,np.ndarray):return ['ndarray',str(v.dtype),list(v.shape),typed(v.tolist())]
    if isinstance(v,(pd.Timestamp,datetime)):return [type(v).__name__,v.isoformat()]
    raise TypeError('Unsupported exact input value: '+type(v).__name__)
def signature(net):
    tables={}
    # Retain ALL non-result frames, including internal empty result templates.
    # Nothing is dropped merely to make the old hash comparison pass.
    for k in sorted(net):
        f=net[k]
        if not isinstance(f,pd.DataFrame) or k.startswith('res_'):continue
        record={'table':k,'index_type':type(f.index).__name__,'index_dtype':str(f.index.dtype),
                'index_names':typed(list(f.index.names)),'index':typed(list(f.index)),
                'column_type':type(f.columns).__name__,'column_names':typed(list(f.columns.names)),
                'columns':typed(list(f.columns)),'dtypes':[str(d) for d in f.dtypes],
                'values':[[typed(x) for x in row] for row in f.itertuples(index=False,name=None)]}
        tables[k]=hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    return hashlib.sha256(json.dumps(tables,sort_keys=True).encode()).hexdigest(),tables
def exact_frames(a,b):
    keys=[k for k,v in a.items() if isinstance(v,pd.DataFrame) and not k.startswith('res_')]
    assert set(keys)=={k for k,v in b.items() if isinstance(v,pd.DataFrame) and not k.startswith('res_')}
    for k in keys:pd.testing.assert_frame_equal(a[k],b[k],check_exact=True,check_dtype=True,check_index_type=True,check_column_type=True)
    return len(keys)
def main():
    OUT.mkdir(exist_ok=False);begun=time.perf_counter()
    write('owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'command':sys.argv,'source_sha256':sha(Path(__file__))})
    proto=json.loads((PREP/'Input_Closure.json').read_text('utf8'))
    assert proto['status']=='INPUT_CLOSURE_PASS_REQUIRES_INDEPENDENT_READER'
    for p,h in proto['source_sha256'].items():assert sha(ROOT/p)==h,p
    prior=BASE/'spatial_allocation_input_audit_v2_20261011'
    claim=json.loads((prior/'owner.claim').read_text('utf8'))
    assert claim['actual_pid']!=os.getpid() and not (prior/'Independent_Input_Audit.json').exists()
    # Parent verified the original reader exit1 before starting this reader.
    diagnostic=json.loads((prior/'Pickle_Identity_Diagnostic.json').read_text('utf8'))
    assert diagnostic['all_non_result_frames_exact'] and diagnostic['PF_model_optimizer_forecast_calls']==0
    attempted=[]
    def refuse(*a,**k):attempted.append(True);raise AssertionError('Reader may not solve')
    originals={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph')}
    for n in originals:setattr(pp,n,refuse)
    try:
        network=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json';meta=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
        assert sha(network)==proto['network_sha256'] and sha(meta)==proto['metadata_sha256']
        net=pp.from_json(str(network));zones=json.loads(meta.read_text('utf8'))['zones'];v2,_,_=load_stack()
        assert all(a['all_function_asts_unchanged'] for a in AUDIT)
        initial,_=signature(net);catalog={};verified_catalog=[];applications=0
        for c in proto['catalog_rows']:
            p=ROOT/c['path'];assert sha(p)==c['sha256']
            if 'effective_input_signature' not in c:
                verified_catalog.append({**c,'semantic_identity':'UNKNOWN_UNSUPPORTED_MODIFICATION'});continue
            s=json.loads(p.read_text('utf8'))
            a=v2.v0.apply_scenario_to_net(copy.deepcopy(net),s,zones);b=independent_apply(net,s.get('modifications',[]),zones);applications+=2
            n=exact_frames(a,b);h,tables=signature(b);assert signature(a)==(h,tables)
            catalog.setdefault(h,[]).append(c['path'])
            verified_catalog.append({'path':c['path'],'scenario_sha256':c['sha256'],'exact_tables':n,'canonical_effective_input_signature':h,
                                     'old_raw_pickle_signature_retained_as_provenance':c['effective_input_signature']})
        roots=[]
        for r in proto['fixed_roots']:
            p=PREP/(r['root']+'.json');assert sha(p)==r['scenario_sha256'];s=json.loads(p.read_text('utf8'))
            if r['root'] in ('S1','S2'):
                pair=('MG1','MG2') if r['root']=='S1' else ('MG3','MG4');buses={int(b) for z in pair for b in zones[z]}
                ids=sorted(int(i) for i in net.sgen.index if int(net.sgen.at[i,'bus']) in buses)
                assert s['modifications']==[{'action':'drop_sgen_indices','sgen_indices':ids}]
            else:
                # Exact unchanged six scenario bytes are bound to preserved v1.
                old=BASE/'spatial_allocation_input_preparation_20261011'/(r['root']+'.json')
                assert p.read_bytes()==old.read_bytes()
            a=v2.v0.apply_scenario_to_net(copy.deepcopy(net),s,zones);b=independent_apply(net,s['modifications'],zones);applications+=2
            n=exact_frames(a,b);h,tables=signature(b);assert signature(a)==(h,tables)
            assert h!=initial and not catalog.get(h),r['root']
            roots.append({'root':r['root'],'family':r['family'],'scenario_sha256':r['scenario_sha256'],'canonical_effective_input_signature':h,
                          'canonical_table_sha256':tables,'all_exact_non_result_tables':n,'physical_outcome':'NOT_MEASURED'})
        assert len(roots)==8 and len({r['canonical_effective_input_signature'] for r in roots})==8 and not attempted
        result={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','actual_reader_pid':os.getpid(),
          'input_closure_sha256':sha(PREP/'Input_Closure.json'),'reader_source_sha256':sha(Path(__file__)),
          'canonical_identity':'Typed exact values (float.hex), axes, names and dtypes; no numerical tolerance; all non-result frames retained.',
          'verified_roots':roots,'verified_catalog':verified_catalog,'catalog_files':proto['catalog_files'],
          'eight_roots_distinct_no_named_catalog_overlap':True,'old_reader_failure_and_raw_hashes_preserved':True,
          'physical_outcomes_inspected':0,'actual_PF_model_optimizer_forecast_controller_calls':0,
          'pure_input_transformations':applications,'elapsed_seconds':time.perf_counter()-begun,
          'new_performance_or_GPU_owner_ready':False,
          'limitations':['Named recipe catalog only; not universal historical exclusion or unused confirmation.','No actual new query-adapter/commit/cold following episode integration yet.','No physical opportunity, LLM benefit, novelty or calibrated90percent confidence.']}
        write('Independent_Input_Audit.json',result)
        print(json.dumps({'status':'PASS','roots':8,'catalog_files':proto['catalog_files'],'exact_table_count':roots[0]['all_exact_non_result_tables'],'new_PF_model_calls':0}))
    finally:
        for n,f in originals.items():setattr(pp,n,f)
if __name__=='__main__':main()
