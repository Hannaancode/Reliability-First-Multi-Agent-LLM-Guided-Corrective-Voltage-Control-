from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
import json,hashlib
R=Path(__file__).resolve().parents[1];O=R/'outputs/public13_voltage_magnitude_analysis_20261029'
def main():
    dest=O/'Independent_Arithmetic_Check.json';assert not dest.exists();p=O/'Results.json';j=json.loads(p.read_text())
    src=R/j['source'];assert hashlib.sha256(src.read_bytes()).hexdigest()==j['source_sha256'];s=json.loads(src.read_text(),parse_float=Decimal)
    by={(x['method'],x['seed']):x for x in j['rows']};assert len(by)==2000
    for name,total in j['summaries'].items():
        strict=tolerant=uv=ov=0;lowmax=highmax=Decimal(0)
        for a in s['all500_paired_rows']:
            x=a['ours'] if name=='our_numerical' else a['native'][name]
            low=max(Decimal(0),Decimal('.95')-x['vmin']);high=max(Decimal(0),x['vmax']-Decimal('1.05'))
            st=(low==0 and high==0);tol=max(low,high)<=Decimal('1e-8');r=by[(name,a['seed'])]
            assert st==r['strict_fullband']==x['full13band'] and tol==r['descriptive_common_epsilon_fullband']
            strict+=st;tolerant+=tol;uv+=x['UV'];ov+=x['OV'];lowmax=max(lowmax,low);highmax=max(highmax,high)
        assert (strict,tolerant,uv,ov)==(total['strict_fullband'],total['descriptive_common_epsilon_fullband'],total['UV_total'],total['OV_total'])
        assert abs(float(lowmax)-total['maximum_UV_shortfall_pu'])<1e-15 and abs(float(highmax)-total['maximum_OV_excess_pu'])<1e-15
    out=dict(status='PASS_ALL2000_SAVED_METHOD_CASE_ROWS_EXACT_DECIMAL_COUNTS_AND_MAXIMA',at_utc=datetime.now(timezone.utc).isoformat(),rows=2000,
      source_result_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),strict_primary_gate_unchanged=True,new_model_PF_training_calls=0,
      inference='Descriptive same-tolerance sensitivity; not a new primary performance claim or physical replay.')
    dest.write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
if __name__=='__main__':main()
