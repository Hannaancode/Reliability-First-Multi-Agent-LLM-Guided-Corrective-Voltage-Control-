"""Distinct ALL3 public native ACOPF SLSQP benchmark, never a PIPS retry.

Exactly one final-iterate solve per case; analytic first derivatives; all
native bounds, power balances, thermal and angle constraints retained.
"""
import argparse,collections,hashlib,json,os,pickle,subprocess,sys,time,traceback
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];B=R/'outputs/public118_slsqp_native_20261018'
def now():return datetime.now(timezone.utc).isoformat()
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text('utf-8-sig'))
def put(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def manifest(p):put(p/'Closed_Manifest.json',{'members':{str(x.relative_to(p)):sha(x) for x in p.rglob('*') if x.is_file()}})
def pins(p):
    for rel,h in p['pins'].items():assert sha(R/rel)==h,rel
def split_linear(A,l,u):
    import numpy as np
    A=A.toarray() if hasattr(A,'toarray') else np.asarray(A)
    eq=np.isfinite(l)&np.isfinite(u)&(l==u)
    lower=np.isfinite(l)&~eq;upper=np.isfinite(u)&~eq
    return A[eq],l[eq],np.vstack([A[lower],-A[upper]]),np.r_[l[lower],-u[upper]]
def prepare_case(native,opts):
    import numpy as np
    from pandapower.pypower.opf_setup import opf_setup
    ppc={k:v.copy() for k,v in native.items()};ppc['baseMVA']=float(ppc['baseMVA']);ppc['version']=str(ppc['version'])
    for key,width in [('bus',17),('gen',21),('branch',26)]:
        old=ppc[key];ppc[key]=np.pad(old,((0,0),(0,width-old.shape[1])));assert np.array_equal(old,ppc[key][:,:old.shape[1]])
    om=opf_setup(ppc,opts);om.build_cost_params();x,lo,hi=om.getv();vv,_,_,_=om.get_idx()
    assert len(x)==2*118+2*54 and set(vv['i1'])=={'Va','Vm','Pg','Qg'}
    x=np.minimum(np.maximum(x,lo),hi);s=slice(vv['i1']['Pg'],vv['iN']['Pg'])
    pg=x[s].copy();target=ppc['bus'][:,2].sum()/ppc['baseMVA'];delta=target-pg.sum()
    room=hi[s]-pg if delta>=0 else pg-lo[s]
    assert room.sum()>=abs(delta)-1e-12 and np.isfinite(room).all()
    if abs(delta)>0:pg+=delta*room/room.sum()
    x[s]=pg;assert np.all(x>=lo) and np.all(x<=hi)
    A,l,u=om.linear_constraints();E,e,I,i=split_linear(A,l,u)
    return {'om':om,'native':native,'x0':x,'lo':lo,'hi':hi,'vv':vv,'linear':(E,e,I,i),'opts':opts,
        'angle_constraint_rows':int(len(om.userdata('iang'))),'initial_dispatch_sum_MW':float(pg.sum()*ppc['baseMVA']),
        'initialization':'Native Va/Vm/Qg and Pg clipped to native bounds; distribute active-demand difference in proportion to unused native Pg headroom. No PF or loss estimate, no outcome-dependent initialization.'}
def arrays_at(prepared,x,Yf,Yt):
    import numpy as np
    n=prepared['native'];vv=prepared['vv'];base=float(n['baseMVA'])
    take=lambda name:x[vv['i1'][name]:vv['iN'][name]]
    bus=np.pad(n['bus'],((0,0),(0,17-n['bus'].shape[1])));gen=np.pad(n['gen'],((0,0),(0,21-n['gen'].shape[1])))
    branch=np.pad(n['branch'],((0,0),(0,26-n['branch'].shape[1])))
    bus[:,7]=take('Vm');bus[:,8]=np.rad2deg(take('Va'));gen[:,1]=take('Pg')*base;gen[:,2]=take('Qg')*base
    gen[:,5]=bus[gen[:,0].astype(int),7];v=take('Vm')*np.exp(1j*take('Va'))
    sf=v[branch[:,0].astype(int)]*np.conj(Yf@v)*base;st=v[branch[:,1].astype(int)]*np.conj(Yt@v)*base
    branch[:,13:17]=np.c_[sf.real,sf.imag,st.real,st.imag]
    return {'bus':bus,'gen':gen,'branch':branch,'gencost':n['gencost'],'x':x}
def worker(index):
    import numpy as np
    from scipy.optimize import minimize,Bounds
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.opf_consfcn import opf_consfcn
    from pandapower.pypower.opf_costfcn import opf_costfcn
    p=read(B/'Protocol.json');pins(p);out=B/'actual'/f'case{index}';out.mkdir(exist_ok=False)
    put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'at_utc':now(),'protocol_sha256':sha(B/'Protocol.json'),'source_sha256':sha(__file__)})
    started=time.perf_counter();cpu=time.process_time();counts=collections.Counter();attempted=False;returned=False
    journal=(out/'Optimizer_Journal.jsonl').open('xb');previous='0'*64
    def event(name,data):
        nonlocal previous
        raw=json.dumps({'event':name,'data':data,'previous_sha256':previous},sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        journal.write(raw+b'\n');journal.flush();os.fsync(journal.fileno());previous=hashlib.sha256(raw).hexdigest()
    names={'makeYbus','opf_consfcn','opf_costfcn','dSbus_dV','dSbr_dV','dAbr_dV'}
    def profile(frame,event,arg):
        if event=='call' and frame.f_code.co_name in names and 'pandapower' in frame.f_code.co_filename:counts[frame.f_code.co_name]+=1
    try:
        rec=p['cases'][index-1];prepared=pickle.loads((B/rec['prepared_path']).read_bytes());om=prepared['om'];ppc=om.get_ppc();base=float(ppc['baseMVA'])
        sys.setprofile(profile);Y,Yf,Yt=makeYbus(base,ppc['bus'],ppc['branch']);il=np.flatnonzero((ppc['branch'][:,5]>0)&(ppc['branch'][:,5]<1e10))
        state={'cost_x':None,'constraint_x':None};scale=p['objective_positive_scale']
        def cost(x):
            counts['objective_requests']+=1
            if state['cost_x'] is None or not np.array_equal(x,state['cost_x']):
                event('cost_application_attempt',{'ordinal':counts['opf_costfcn']+1});f,df=opf_costfcn(x,om)
                assert np.isfinite(f) and np.isfinite(df).all();state.update(cost_x=x.copy(),f=float(f),df=np.asarray(df));event('cost_application_return',{'objective':float(f)})
            return state['f']/scale,state['df']/scale
        def constraints(x):
            counts['constraint_requests']+=1
            if state['constraint_x'] is None or not np.array_equal(x,state['constraint_x']):
                event('constraint_application_attempt',{'ordinal':counts['opf_consfcn']+1})
                h,g,dh,dg=opf_consfcn(x,om,Y,Yf[il,:],Yt[il,:],prepared['opts'],il)
                dh=dh.T.toarray() if dh is not None else np.zeros((0,len(x)));dg=dg.T.toarray()
                assert all(np.isfinite(a).all() for a in [h,g,dh,dg]);state.update(constraint_x=x.copy(),h=np.asarray(h),g=np.asarray(g),dh=dh,dg=dg)
                event('constraint_application_return',{'maximum_balance_pu':float(np.max(abs(g))),'maximum_squared_flow_violation':float(np.max(h,initial=0))})
            return state['h'],state['g'],state['dh'],state['dg']
        E,e,I,i=prepared['linear'];cons=[{'type':'eq','fun':lambda x:constraints(x)[1],'jac':lambda x:constraints(x)[3]},
            {'type':'ineq','fun':lambda x:-constraints(x)[0],'jac':lambda x:-constraints(x)[2]}]
        if len(e):cons.append({'type':'eq','fun':lambda x:E@x-e,'jac':lambda x:E})
        if len(i):cons.append({'type':'ineq','fun':lambda x:I@x-i,'jac':lambda x:I})
        def iteration(x):
            counts['iteration_callbacks']+=1;f=out/f'Iterate_{counts["iteration_callbacks"]:03}.npz'
            with f.open('xb') as stream:np.savez_compressed(stream,x=x);stream.flush();os.fsync(stream.fileno())
            event('iterate_preserved',{'iteration':counts['iteration_callbacks'],'path':f.name,'sha256':sha(f)})
        event('optimizer_attempt',{'solver':'scipy.optimize.minimize SLSQP','maxiter':p['maxiter'],'ftol':p['ftol'],'objective_positive_scale':scale})
        attempted=True;t=time.perf_counter();result=minimize(lambda x:cost(x)[0],prepared['x0'],jac=lambda x:cost(x)[1],method='SLSQP',
            bounds=Bounds(prepared['lo'],prepared['hi']),constraints=cons,callback=iteration,options={'maxiter':p['maxiter'],'ftol':p['ftol'],'disp':False})
        returned=True;optimizer_seconds=time.perf_counter()-t
        final=arrays_at(prepared,np.asarray(result.x),Yf,Yt);objective=float(result.fun)*scale
        with (out/'Actual_Solver_Arrays.npz').open('xb') as f:np.savez_compressed(f,**final);f.flush();os.fsync(f.fileno())
        put(out/'Actual_Solver_Metadata.json',{'baseMVA':base,'f':objective,'success':bool(result.success),'status':int(result.status),'message':str(result.message),
            'nit':int(result.nit),'nfev':int(result.nfev),'njev':int(result.njev),'final_iterate_only':True,'optimizer_seconds':optimizer_seconds})
        event('optimizer_return',{'status':int(result.status),'success':bool(result.success),'final_array_sha256':sha(out/'Actual_Solver_Arrays.npz')})
        status='RETURNED_FINAL_ITERATE_NOT_YET_INDEPENDENTLY_CERTIFIED'
    except BaseException:
        (out/'Failure_Traceback.txt').write_text(traceback.format_exc(),'utf-8');status='EXCEPTION_RETAINED_FEASIBILITY_UNKNOWN'
    finally:
        sys.setprofile(None);journal.close()
    put(out/'Result.json',{'status':status,'optimizer_attempts':int(attempted),'optimizer_returns':int(returned),'actual_profile_counts':dict(counts),
        'workflow_seconds':time.perf_counter()-started,'CPU_seconds':time.process_time()-cpu,'journal_final_sha256':previous,'new_LLM_standalone_PF_PIPS_calls':0,
        'internal_SLSQP_linear_algebra_and_recomputation_FLOPs':'NOT_SEPARATELY_INSTRUMENTED'})
    manifest(out)
def run():
    p=read(B/'Protocol.json');pins(p);assert read(B/'Readiness.json')['status']=='PASS_SOFTWARE_AND_ALL3_NATIVE_MODEL_LAYOUT_ONLY'
    out=B/'actual';out.mkdir(exist_ok=False);started=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'at_utc':now(),'protocol_sha256':sha(B/'Protocol.json'),'source_sha256':sha(__file__)});jobs=[]
    for i in range(1,4):
        if time.perf_counter()-started>=p['workflow_bound_seconds']:jobs.append({'case':i,'status':'UNEXECUTED_UNKNOWN_WORKFLOW_BOUND'});continue
        cmd=[sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--case',str(i)]
        env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
        with (out/f'case{i}_console.log').open('xb') as f:
            child=subprocess.Popen(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT);put(out/f'case{i}_Launch.json',{'actual_pid':child.pid,'parent_pid':os.getpid(),'command':cmd,'at_utc':now()})
            timeout=False
            try:code=child.wait(timeout=min(p['per_case_bound_seconds'],p['workflow_bound_seconds']-(time.perf_counter()-started)))
            except subprocess.TimeoutExpired:timeout=True;child.kill();code=child.wait()
            jobs.append({'case':i,'actual_pid':child.pid,'exit_code':code,'fixed_bound_timeout':timeout,'result_present':(out/f'case{i}/Result.json').exists()})
    put(out/'Result.json',{'status':'ALL3_DECLARED_CASES_TERMINAL','jobs':jobs,'workflow_seconds':time.perf_counter()-started,'retries':0});manifest(out)
    reader=R/'work/audit_public118_slsqp_native_20261018.py';assert sha(reader)==p['independent_reader_sha256']
    with (B/'Reader_Console.log').open('xb') as f:
        child=subprocess.Popen([sys.executable,'-X','utf8',str(reader)],cwd=R,stdout=f,stderr=subprocess.STDOUT);put(B/'Reader_Launch.json',{'actual_pid':child.pid,'parent_pid':os.getpid(),'source_sha256':sha(reader),'at_utc':now()})
        try:code=child.wait(timeout=p['reader_bound_seconds'])
        except subprocess.TimeoutExpired:child.kill();code=child.wait()
    put(B/'Completion.json',{'reader_exit_code':code,'at_utc':now(),'scientific_retries':0})
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--case',type=int);args=parser.parse_args();worker(args.case) if args.case else run()
