"""One exact owner; complete-JSON claim observation and atomic ACK publication."""
import argparse,json,os,subprocess,time
from datetime import datetime,timezone
from coordinate_native_inverter_linear_reference_20261020 import ROOT,process,sha

def put(path,value):
    assert not path.exists();temporary=path.with_name(path.name+'.pending')
    with temporary.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.flush();os.fsync(f.fileno())
    os.replace(temporary,path)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--protocol',required=True);args=ap.parse_args();p=json.loads((ROOT/args.protocol).read_text(encoding='utf-8'));s=p['single_owner']
    source=ROOT/s['source'];out=ROOT/s['output'];coord=ROOT/s['coordination'];assert not out.exists() and not coord.exists() and sha(source)==s['sha256'];coord.mkdir()
    put(coord/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),at_utc=datetime.now(timezone.utc).isoformat()))
    with (coord/'Owner.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([str(ROOT/s['python']),'-X','utf8',str(source),*s.get('arguments',[])],cwd=ROOT,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);start=time.monotonic();claim=None
        while claim is None:
            assert child.poll() is None and time.monotonic()-start<180
            try:claim=json.loads((out/'owner.claim').read_text(encoding='utf-8'))
            except (FileNotFoundError,json.JSONDecodeError):time.sleep(.1)
        actual=process(claim['actual_pid']);parent=process(claim['parent_pid'])
        assert actual and parent and claim['parent_pid']==child.pid==actual['ParentProcessId'] and source.name in actual['CommandLine'] and sha(source)==claim['source_sha256']
        put(out/'Launcher_ACK.json',dict(actual_pid=claim['actual_pid'],actual_parent_pid=child.pid,actual_command=actual['CommandLine'],parent_command=parent['CommandLine'],fresh_exact_source_PID_parent_command=True,at_utc=datetime.now(timezone.utc).isoformat()))
        try:code=child.wait(timeout=max(1,s['bound_seconds']-(time.monotonic()-start)))
        except subprocess.TimeoutExpired:
            actual=process(claim['actual_pid'])
            if actual and source.name in actual['CommandLine']:subprocess.run(['taskkill.exe','/PID',str(claim['actual_pid']),'/T','/F'],capture_output=True,timeout=30)
            child.wait(timeout=30);raise
    assert process(claim['actual_pid']) is None and process(child.pid) is None
    put(coord/'End_ACK.json',dict(actual_pid=claim['actual_pid'],launcher_pid=child.pid,exit_code=code,actual_owned_chain_ended=True,elapsed_seconds=time.monotonic()-start));assert code==0,'Preserve failure, no retry'
    put(coord/'Completion.json',dict(status='EXACT_ATOMIC_OWNER_ENDED',at_utc=datetime.now(timezone.utc).isoformat()))

if __name__=='__main__':main()
