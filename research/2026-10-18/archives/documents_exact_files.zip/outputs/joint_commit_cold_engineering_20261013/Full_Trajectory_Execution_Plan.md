# Next full-trajectory comparison

The fixed equal-two-operation development benchmark found three strict UV wins,
one tie and zero UV losses for a support-relocation move against two complete
ordinary greedy additions. Those endpoints were 10/23/23/8 versus 10/24/24/12.
The first-root minimum-voltage tradeoff remains recorded. This establishes a
local actuation opportunity, not complete D-SE superiority or an LLM benefit.

The subsequent one-root actual engineering test committed one prospectively
charged independent replay of a retained joint query in a NEW engineering
branch. A cold process restored the complete cursor, paid registry, RNG, costs,
input state, remaining device-operation budget and fixed absolute deadline.
Its first cap-legal following joint query was rejected; it was independently
replayed with identical fields and rejection. The rejected query did not commit
or debit operations. Both replays are paid physical calls. None is a repeated
primary performance experiment or a restart of an old owner.

## Two different comparison scopes must remain distinct

1. **Current-state suffix study.** Use every one of the four fixed inspected
   current endpoints, retain all original prefix actions/costs and the remaining
   slots out of the original 25-device-operation budget. Compare complete
   ordinary native greedy continuation with complete ordinary-plus-owned-joint
   greedy continuation under the same current scope, original score, Q grid,
   cumulative positive cap and protection. This measures the benefit of the
   action-space extension. It cannot be called an unchanged whole-scenario
   literal DFF or D-SE benchmark.
2. **Whole-scenario model contribution study.** Begin every method at the same
   exact original recipe/network identity. Execute or attribute only genuinely
   unexecuted reference identities. Retain literal DFF and DFF-ALT independently
   and apply the unchanged selector with FULL BOTH costs. Compare the model
   plus joint planner with a numerical planner that has the same joint actions,
   paid observations, protection and operation allowance. Separately show
   protected-reference variants if protection differs from literal source.

No study in this document is already launched. No performance or GPU owner is
ready merely because the three-call engineering passed.

## Exact reference semantics

`work/paid_spatial_literal_comparator_binding_v1.py` binds the unchanged original
25-iteration DFF function and source-reversed ALT implementation. ALT selects
the **second distinct action by the original score on the first iteration**,
then follows ordinary DFF. Lowest-Vm gain is the fourth component of that score;
ALT is not a separate lowest-voltage chooser. Preserve the original selector's
exact zero/missing-deficit handling. The source certificate for this binding
is `Exact_Reference_Source_Binding.json` in this directory. Do not replace an
actual full reference run with this software/source certificate.

## Required implementation order

1. Build the complete receding controller around the now exercised paid joint
   commit component. Journal every query intent/return/refusal and exact input
   fingerprint. Commit only a paid accepted candidate. Save the complete
   cursor/history, owned stock, positive/withdrawn lifetime ledgers, paid-query
   registry, Python/NumPy RNG, protocol/source/input anchors, all costs and
   original absolute bound before independent ACK and more science. Recompute
   the original raw common/zone scope after each real commit. Never refund the
   positive 450-MVAr lifetime cap; each joint move costs two device operations.
2. Independently verify the complete-loop backend, cold restore and continuous
   replay under a separately fixed new engineering protocol. The present gate
   covers one accepted commit and one rejected following query; it does not
   certify a long sequence of accepted following commits, original LOCAL model
   serving or whole literal-controller backend integration.
3. Before performance, freeze the exact input list, complete control sources,
   all action/state identities, stops, bounds, manifests and independent reader.
   Include every input and every failed/partial/nonfinite/missing identity. Do
   not extend the completed engineering's 600-second budget or restart it.
4. Execute the development suffix comparison to determine whether the move
   yields sustained UV reduction at the same TOTAL operation budget. Numerical
   same-actuation results precede any LLM-credit claim. A materially different
   full-scenario campaign must separately satisfy step 3; this is not an
   automatic launch instruction.
5. Bind the original private model's actual deployed mandatory/feedback prompt,
   current observation, wire schema, positive MVAr units, parser/normalizer and
   original Q grid before new inference. The failed public 7B screen stays
   unchanged. Do not sign-flip its outputs or reuse a different prompt contract
   as if it were a matched primary result. Any model campaign needs actual
   loader/full-context/memory checks and complete inference/failure accounting.
6. Freeze a conditional model-attribution comparison against the equally
   informed numerical same-joint-action controller, model-disabled ablation
   and appropriate architecture/pretraining controls. Include both literal
   D-SE branches and their full costs. Only a surviving development result can
   justify a separately fixed genuinely unused confirmation campaign.

## Reporting and stopping

Report per-world UV, deficit, minimum and maximum voltage, raw and tolerance OV,
convergence, rejected/missing identities, device operations, added/withdrawn
nominal capacity and full paid costs. No UV-loss world or minimum-voltage
tradeoff may disappear in an aggregate. Report model/training/preparation,
numerical derivatives/solves, PF queries/replays, old attributed costs,
persistence, independent audit and all failures separately. Isolated deployment
latency and per-subphase preservation/setup timing that were not measured are
UNKNOWN, not zero or free.

Freeze the empirical primary gate before outcomes. Failed gates stop the exact
intervention; they do not authorize world/seed/Q/LR/objective/checkpoint/budget
sweeps. No 90-percent winning confidence is established. Capacitor relocation
is not automatically novel; prior-art and attribution checks precede such a
claim. Security implementation waits validated model-system advantage.

## Waiting policy requested by the human

When an experiment is the ONLY remaining dependency and no useful parallel task
can advance the goal, save its actual owner/source/status/output identities and
set a scheduled check at a time estimated from its measured/expected runtime.
At that check, if it remains live, schedule the next check without busy polling.
Delete the waiting check once the actual result/terminal state is available;
inspect the closed evidence and continue. Use a new waiting check for the next
experiment only when again necessary. Timers are observations, not quota-reset,
success or completion guarantees. Existing safety/science/goal constraints and
the human-configured independent monitor cadence remain in force. There is no
waiting timer to create now: this engineering and its reader have both ended.
