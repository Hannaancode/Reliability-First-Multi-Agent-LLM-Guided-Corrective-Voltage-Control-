# Bounded fresh128 study: terminal partial

Independent preserved-prefix audit PASS, full128 fixed gateUNKNOWN. All scientist/reader/coordinator actors endedexit0; the single waiting timer wasdeleted.

| Arm | Complete of128 | Available-only fullband | Unknown |
|---|---:|---:|---:|
|safe-ddpg|55|27|73|
|linear|55|28|73|
|ddpg|55|39|73|
|numerical|54|30|74|
|our-router|54|54|74|
|published-router|54|40|74|

The prefix is allsource-order, not chosen successes. Storage reached its fixed8GiB bound after54complete six-arm worlds plus the first3native policies ofseed1054. Numericalseed1054 completed43decisions;44has a saved zero-action/mathematical return but no entered physics/cache query. Seed1054routers andseeds1055..1127remainunentered. No full128performance/statistical claim.

Newscience paid1179PFreturns/0exceptions,3750native actor calls,226derivatives/LU,678RHS,452LP; firstreader repeated exactlythose newreturnedPF/actor calls once, independently reconstructed226dense proofs with0newLP/LU/derivative. Full-fielddelta0.0. Alloldcosts/unknowns/failures staypaid andpreserved.

A separately prospective missing-only protocol and byte-exact preservation engineering are needed. This is not anoldbudgetextension or permission to retryoldcalls. No GPU/LLMtraining; all six final goalsOPEN.
