"""One actual native options initialization, ZERO power flow/converter calls.

Source/configuration evidence only; not solved-state reconstruction or a claim
of historical score equality. Root/current numerical read sets stay separate.
"""
import ast,copy,hashlib,inspect,json,os,time
from pathlib import Path
from datetime import datetime,timezone
import pandapower as pp
from pandapower.auxiliary import _init_runpp_options
from train_trajectory_measurement_nullable_v2 import safe
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/native_solver_cache_readset_20261011'
NETWORK=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'
PACKAGE=Path(pp.__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(safe(v),f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
 OUT.mkdir(exist_ok=False);started=time.perf_counter()
 native_path=ROOT/'work/e/audit/phase2g_multiagent_llm_runner.py';native=ast.parse(native_path.read_text('utf8'));fn=next(n for n in native.body if isinstance(n,ast.FunctionDef) and n.name=='run_pf')
 call=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and ast.unparse(n.func)=='pp.runpp');kwargs={kw.arg:ast.literal_eval(kw.value) for kw in call.keywords}
 sources={str(p):sha(p) for p in [native_path,PACKAGE/'run.py',PACKAGE/'powerflow.py',PACKAGE/'pd2ppc.py',PACKAGE/'auxiliary.py',Path(__file__)]}
 write(OUT/'Protocol.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'question':'Does the native NR/auto/no-recycle entry consume saved prior ppc/results as initialization?','scope':'SOURCE_AND_ACTUAL_BASE_OPTIONS_ONLY; NOT_HISTORICAL_STATE_RESTORATION','resource_seconds':60,'network_sha256':sha(NETWORK),'source_sha256':sources,'native_explicit_kwargs':kwargs,'actual_planned_calls':{'network_decode':1,'private_options_initializer':1,'nonlinear_PF':0,'linear_PF':0,'converter':0,'model_optimizer_fit_forecast_derivative_cloud':0},'decision':'A missing ppc cache alone is not a proven reconstruction blocker if no-recycle/non-results conditions hold; physical inputs/native current metrics still require complete evidence.'})
 write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':'check_native_solver_cache_readset_20261011.py','protocol_sha256':sha(OUT/'Protocol.json')})
 signature=inspect.signature(pp.runpp);defaults={k:p.default for k,p in signature.parameters.items() if p.default is not inspect.Parameter.empty};combined={**defaults,**kwargs}
 real={key:getattr(pp,key) for key in ['runpp','rundcpp','runopp','runpp_3ph'] if hasattr(pp,key)};forbidden=[]
 def forbidden_call(*args,**kw):
  forbidden.append('FORBIDDEN_SCIENTIFIC_ENTRY');raise BaseException('Source/options check entered a solver; stop without retry')
 for key in real:setattr(pp,key,forbidden_call)
 try:
  net=pp.from_json(str(NETWORK));raw_user_options=copy.deepcopy(net.get('user_pf_options',{}));assert raw_user_options=={},'Unknown user overrides must remain unresolved'
  before_ppc=copy.deepcopy(net.get('_ppc'));before_results=net.res_bus.copy(deep=True)
  original_tables={key:frame.copy(deep=True) for key,frame in net.items() if hasattr(frame,'columns')}
  init_signature=inspect.signature(_init_runpp_options);required={k:combined[k] for k,p in init_signature.parameters.items() if k not in ['net','kwargs','passed_parameters'] and k in combined}
  _init_runpp_options(net,**required)
  options=copy.deepcopy(net['_options'])
  for key,frame in original_tables.items():assert frame.equals(net[key]),'Options initialization changed physical or result table'
  assert canonical_ppc(before_ppc)==canonical_ppc(net.get('_ppc')),'Options initialization changed cache'
  assert before_results.equals(net.res_bus) and not forbidden
 finally:
  for key,value in real.items():setattr(pp,key,value)
 assert sha(NETWORK)==read_protocol_network_sha()
 condition=options['recycle'] is None and options['init_results'] is False and options['init_va_degree']!='results' and options['init_vm_pu']!='results'
 proof={'native_runpp_explicit_recycle_argument':kwargs.get('recycle'),'raw_user_pf_options_empty':raw_user_options=={},'effective_recycle':options['recycle'],'effective_init_results':options['init_results'],'effective_init_va_degree':options['init_va_degree'],'effective_init_vm_pu':options['init_vm_pu'],'cache_free_initialization_conditions_hold':condition,'source_anchors':{'runpp_recycled_path':'run.py:218-220 only takes recycled route for explicit kwargs recycle dict and internal stored state','runpp_options_reinitialized':'run.py:229-242 initializes options then calls ordinary powerflow','ordinary_powerflow':'powerflow.py clears lookups, calls _pd2ppc, assigns new ppc; result initialization used only when init_results','new_case_construction':'pd2ppc.py:_init_ppc builds new arrays; _pd2ppc selects elements and builds input matrices','auto_initialization':'auxiliary.py:2152-2164 derives initialization from current ext_grid/gen/vsc settings, not saved res_bus'},'not_proven':['all historical physical input reconstruction','native historical Vm/score/tie/OV equality','case/snapshot resumption equivalence','admissible alternative future trajectory','physical or LLM advantage']}
 report={'source_and_actual_options_condition_verified':condition,'pandapower_version':pp.__version__,'proof':proof,'effective_options':safe(options),'actual_calls':{'network_decode':1,'private_options_initializer':1,'PF_converter_model_optimizer_fit_forecast_derivative_cloud':0},'forbidden_entry_attempts':len(forbidden),'network_bytes_unchanged':True,'all_original_tables_and_results_unchanged_by_options_init':True,'workflow_seconds_before_report_manifest':time.perf_counter()-started,'no_automatic_performance_launch':True,'next_safe_work':'Check complete physical-input/current-native-metric reconstruction from original base+scenario+ordered commits and saved solved evidence WITHOUT any PF. If incomplete keep UNKNOWN; do not fabricate solved flags or rerun roots. If certified, a separately frozen new counterfactual commit/continuation identity can be measured without historical root repeat.'}
 assert time.perf_counter()-started<60
 write(OUT/'Source_And_Actual_Options_Result.json',report)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file()}})
 print(json.dumps({'source_and_actual_options_condition_verified':condition,'actual_nonlinear_PF':0,'effective_init_results':options['init_results'],'effective_recycle':options['recycle'],'owner_pid':os.getpid(),'workflow_seconds_before_report_manifest':report['workflow_seconds_before_report_manifest']}))
def canonical_ppc(v):
 import pickle
 return hashlib.sha256(pickle.dumps(v,protocol=5)).hexdigest()
def read_protocol_network_sha():return json.loads((OUT/'Protocol.json').read_text('utf8'))['network_sha256']
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'exception':type(exc).__name__,'message':str(exc),'state':'TERMINAL_SOURCE_OPTIONS_PARTIAL_NO_AUTOMATIC_RETRY'})
  raise
