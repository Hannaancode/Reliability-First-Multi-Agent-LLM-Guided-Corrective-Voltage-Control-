"""Prospective equal-two-operation development benchmark, single owner/reader.

First-operation and joint receipts are reused with their paid costs. Only
previously unexecuted following-state queries and declared replay enter PF.
No model call, old scientific restart, full-DSE claim or outcome retuning.
"""
import argparse,copy,hashlib,importlib.metadata,json,os,pickle,random,struct,subprocess,sys,time,traceback,zlib
from datetime import datetime,timezone,timedelta
from pathlib import Path
import numpy as np
import pandapower as pp
from candidate_process_evidence_utils import frozen_checks
from durable_opaque_evidence_store_v1 import local_root,inventory,process_alive
from frozen_physics_loader import load_stack,AUDIT
from joint_reallocation_opportunity_core_v1 import load_endpoint,universe,action,build_verifier

R=Path(__file__).resolve().parents[1]
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
B=R/'outputs/equal_operation_benchmark_v2_20261013'
read=lambda p:json.loads(local_root(p).read_bytes())
sha=lambda p:hashlib.sha256(local_root(p).read_bytes()).hexdigest()
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def put(path,value):
    with local_root(path).open('xb') as f:f.write(canon(value));f.flush();os.fsync(f.fileno())
def fields(net):
    f={str(int(b)):{k:float(net.res_bus.at[b,k]) for k in ('vm_pu','va_degree','p_mw','q_mvar')} for b in net.res_bus.index}
    assert len(f)==118 and all(np.isfinite(x) for a in f.values() for x in a.values());return f
def metrics(f):
    values=[a['vm_pu'] for a in f.values()]
    return {'uv_count':sum(v<.95 for v in values),'vmax':max(values),'vmin':min(values),
            'deficit_sum':sum(max(0.,.95-v) for v in values)}
def decode_capsule(pack,d):
    pack.seek(d['record_offset']);size=struct.unpack('<Q',pack.read(8))[0];assert 0<size<8192
    hb=pack.read(size);h=json.loads(hb);assert size==d['header_bytes'] and hashlib.sha256(hb).hexdigest()==d['header_sha256']
    assert pack.tell()==d['encoded_offset'] and all(d[k]==v for k,v in h.items())
    encoded=pack.read(d['encoded_bytes']);assert len(encoded)==d['encoded_bytes'] and hashlib.sha256(encoded).hexdigest()==d['encoded_sha256']
    assert 0<d['raw_bytes']<=32*1024*1024
    dec=zlib.decompressobj();raw=dec.decompress(encoded,d['raw_bytes']+1)
    assert dec.eof and not dec.unused_data and not dec.unconsumed_tail and len(raw)==d['raw_bytes'] and hashlib.sha256(raw).hexdigest()==d['raw_sha256']
    return pickle.loads(raw)
def initial_data():
    protocol=read(OLD/'preparation/Protocol.json');manifest=read(OLD/'actual/Closed_Manifest.json')
    assert sha(OLD/'actual/scientific.jsonl')==manifest['members']['scientific.jsonl']['sha256']
    rows=[];times={};previous='0'*64
    for line in local_root(OLD/'actual/scientific.jsonl').read_bytes().splitlines():
        e=json.loads(line);assert e['previous_sha256']==previous;previous=hashlib.sha256(line).hexdigest()
        if e['event']=='candidate_closed':rows.append(e['data'])
        if e['event'] in ('PF_return','PF_exception'):times[e['data']['id']]=e['data']['seconds']
    assert len(rows)==4001
    return protocol,rows,times
def best(rows):
    safe=[r for r in rows if r['verif']['accepted']]
    return max(safe,key=lambda r:(tuple(r['original_score']),-r['universe_index'])) if safe else None
def native_scope(net,runner,zones):
    reports={z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
    return runner.rescue.candidate_buses_from_state(net,zones,reports,[])
def following_cursor(before,after,cursor,row,runner,zones):
    expected=copy.deepcopy(before);runner.rescue.apply_action(expected,row['action'])
    assert after.shunt.equals(expected.shunt) and after.converged
    c=copy.deepcopy(cursor);bus=str(row['receiver']);q=float(row['q'])
    c['positive_addition_lifetime_MVAr'][bus]=c['positive_addition_lifetime_MVAr'].get(bus,0.)+q
    c['remaining_original_device_operation_slots']-=1
    new=[int(i) for i in after.shunt.index if i not in before.shunt.index];assert len(new)==1
    bank=after.shunt.loc[new[0]]
    c['owned_bank_rows'].append({'index':new[0],'bus':int(bank.bus),'name':str(bank['name']),
        'q_mvar':float(bank.q_mvar),'origin':'PAID_FIRST_OPERATION_REUSED_IN_NEW_CONDITIONAL_TWO_OPERATION_SCREEN'})
    c['raw_current_receiver_scope']=native_scope(after,runner,zones)
    assert c['withdrawals_refund_positive_addition_cap'] is False and c['positive_addition_lifetime_MVAr'][bus]<=450
    return c
class BoundStop(BaseException):pass

def worker():
    p=read(B/'Protocol.json');ph=sha(B/'Protocol.json');out=B/'actual';local_root(out).mkdir(exist_ok=False)
    begun=time.perf_counter();deadline=datetime.fromisoformat(p['absolute_deadline_utc']);code=1;prev='0'*64;count=0
    journal=None;pack=None;oldpack=None;result=[];cache={};cost={'PF_attempts':0,'PF_returns':0,'PF_exceptions':0,'PF_seconds':0.,
        'replay_PF_attempts':0,'preservation_seconds':0.,'new_query_cache_reuses':0,'new_model_calls':0,'new_optimizer_steps':0}
    backend=pp.runpp;current={};last=None
    def admit():
        if datetime.now(timezone.utc)>=deadline or cost['PF_attempts']>=p['maximum_PF_attempts']:raise BoundStop('Fixed independent deadline/count; no extension')
        if pack is not None and pack.tell()+32*1024*1024>p['maximum_storage_bytes']:raise BoundStop('Fixed complete-storage bound')
    def event(kind,data):
        nonlocal prev
        raw=canon({'event':kind,'data':data,'previous_sha256':prev,'protocol_sha256':ph});prev=hashlib.sha256(raw).hexdigest()
        journal.write(raw+b'\n');journal.flush();os.fsync(journal.fileno())
    def capsule(net,label):
        t=time.perf_counter();raw=pickle.dumps({'net':net,'python_rng':random.getstate(),'numpy_rng':np.random.get_state()},protocol=5);encoded=zlib.compress(raw,6)
        h={'label':label,'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'encoded_bytes':len(encoded),'encoded_sha256':hashlib.sha256(encoded).hexdigest()}
        hb=canon(h);offset=pack.tell();pack.write(struct.pack('<Q',len(hb))+hb+encoded);pack.flush();os.fsync(pack.fileno())
        cost['preservation_seconds']+=time.perf_counter()-t
        return {'path':'capsules.bin','record_offset':offset,'header_bytes':len(hb),'header_sha256':hashlib.sha256(hb).hexdigest(),'encoded_offset':offset+8+len(hb),**h}
    def measured(net,*args,**kwargs):
        nonlocal count,last
        assert not args and kwargs==p['solver_kwargs'];admit();count+=1
        before=capsule(net,f'{count}_before');event('PF_intent',{'id':count,'context':current,'before':before,'kwargs':kwargs});admit()
        started=time.perf_counter();cost['PF_attempts']+=1
        if current['phase']=='selected_independent_replay':cost['replay_PF_attempts']+=1
        try:answer=backend(net,**kwargs);cost['PF_returns']+=1
        except Exception as exc:
            seconds=time.perf_counter()-started;cost['PF_seconds']+=seconds;cost['PF_exceptions']+=1
            last={'PF_id':count,'outcome':'EXCEPTION','seconds':seconds,'after':capsule(net,f'{count}_failed'),'exception':type(exc).__name__}
            event('PF_exception',last);raise
        seconds=time.perf_counter()-started;cost['PF_seconds']+=seconds
        last={'PF_id':count,'outcome':'RETURNED','seconds':seconds,'after':capsule(net,f'{count}_after'),'fields':fields(net),'converged':bool(net.converged)}
        event('PF_return',last);return answer
    try:
        put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'protocol_sha256':ph})
        while not local_root(out/'Launcher_ACK.json').exists():
            if datetime.now(timezone.utc)>=deadline:raise BoundStop('No fresh ownership ACK')
            time.sleep(.1)
        ack=read(out/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_PID_parent_command']
        for name,h in p['source_input_sha256'].items():assert sha(R/name)==h,name
        assert {n:importlib.metadata.version(n) for n in p['runtime']}==p['runtime']
        original,oldrows,times=initial_data();_,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
        metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
        journal=local_root(out/'scientific.jsonl').open('xb');pack=local_root(out/'capsules.bin').open('xb');oldpack=local_root(OLD/'actual/capsules.bin').open('rb');pp.runpp=measured
        for entry in original['current_endpoints']:
            admit();before,cursor,_=load_endpoint(entry);assert native_scope(before,runner,zones)==cursor['raw_current_receiver_scope']
            rows=[r for r in oldrows if r['world']==entry['world']];ordinary=[r for r in rows if r['kind']=='ordinary'];joint=best([r for r in rows if r['kind']=='equal_owned_reallocation'])
            assert joint and cursor['remaining_original_device_operation_slots']>=2
            worst=int(before.res_bus.vm_pu.idxmin());methods={
                'complete_protected_ordinary_greedy2':ordinary,
                'lowest_voltage_ordinary_greedy2':[r for r in ordinary if r['receiver']==worst]}
            branch_results=[]
            for method,first_rows in methods.items():
                admit();first=best(first_rows)
                if first is None:
                    branch_results.append({'method':method,'status':'NO_SAFE_FIRST_ACTION','final_fields':fields(before),'device_operations':0,
                        'reused_first_PF_ids':[r['measured_receipt']['PF_id'] for r in first_rows if r['measured_receipt']]});continue
                solved=decode_capsule(oldpack,first['measured_receipt']['after']);net=solved['net'];assert fields(net)==first['measured_receipt']['fields']
                random.setstate(solved['python_rng']);np.random.set_state(solved['numpy_rng'])
                next_cursor=following_cursor(before,net,cursor,first,runner,zones);event('cached_first_branch_bound',{'world':entry['world'],'method':method,'first':first,'next_cursor':next_cursor,'after':capsule(net,'cached_first')})
                verify,_,cert=build_verifier(runner.rescue,next_cursor);assert cert==original['verifier_source_certificate']
                actions=[r for r in universe(next_cursor) if r['kind']=='ordinary']
                if method=='lowest_voltage_ordinary_greedy2':actions=[r for r in actions if r['receiver']==int(net.res_bus.vm_pu.idxmin())]
                candidates=[]
                for row in actions:
                    admit();current={'world':entry['world'],'method':method,'phase':'new_second_operation_query','first_PF_id':first['measured_receipt']['PF_id'],'candidate':row}
                    key=canon([entry['world'],first['measured_receipt']['PF_id'],row['receiver'],row['q']]).decode()
                    if key in cache:
                        record=copy.deepcopy(cache[key]);cost['new_query_cache_reuses']+=1
                        event('new_second_query_receipt_reused',{'key':key,'context':current,'record':record})
                    else:
                        last=None;a=action(row);raw=verify(net,a);band=raw.get('after') is not None and raw['after']['vmax']<=1.05+1e-8
                        verif=dict(raw,original_native_accepted=raw['accepted'],normal_upper_band_admissible=bool(band))
                        if raw['accepted'] and not band:verif['accepted']=False;verif['reason']='normal_upper_band_mediation'
                        if last is None:assert not raw['accepted'] and raw['reason']=='q_cap_exceeded'
                        record={**row,'action':a,'verif':verif,'original_score':list(runner.rescue.score_candidate({'action':a,'verif':verif})),
                                'measured_receipt':last,'key':key}
                        cache[key]=copy.deepcopy(record);event('new_second_candidate_closed',{'context':current,'record':record})
                    candidates.append(record)
                chosen=best(candidates);finalfields=fields(net);replay=None
                if chosen:
                    receipt=chosen['measured_receipt'];finalfields=receipt['fields'];target=copy.deepcopy(net);runner.rescue.apply_action(target,chosen['action'])
                    current={'world':entry['world'],'method':method,'phase':'selected_independent_replay','first_PF_id':first['measured_receipt']['PF_id'],'candidate':chosen['action']}
                    pp.runpp(target,**p['solver_kwargs']);assert target.converged
                    assert max(abs(fields(target)[b][k]-finalfields[b][k]) for b in finalfields for k in finalfields[b])<=1e-10
                    replay=last
                branch={'method':method,'status':'COMPLETE_ALL_DECLARED_SECOND_CANDIDATES','first':first,'following_cursor':next_cursor,
                    'declared_second_candidates':len(actions),'second_candidates':candidates,'selected_second':chosen,'independent_replay':replay,
                    'final_fields':finalfields,'device_operations':1+bool(chosen),'reused_first_PF_ids':[r['measured_receipt']['PF_id'] for r in first_rows if r['measured_receipt']],
                    'reused_first_solver_seconds':sum(times[r['measured_receipt']['PF_id']] for r in first_rows if r['measured_receipt'])}
                branch_results.append(branch);event('branch_closed',{'world':entry['world'],'branch':branch})
            joint_fields=joint['measured_receipt']['fields'];joint_ids=[r['measured_receipt']['PF_id'] for r in rows if r['kind']=='equal_owned_reallocation' and r['measured_receipt']]
            world={'world':entry['world'],'current_fields':fields(before),'branches':branch_results,
                'one_joint_two_operations':{'selected':joint,'final_fields':joint_fields,'device_operations':2,'reused_root_PF_ids':joint_ids,
                    'reused_root_solver_seconds':sum(times[i] for i in joint_ids)},
                'all_first_and_joint_measurements_reused_not_reexecuted':True}
            result.append(world);event('world_closed',world);put(out/f'W{len(result)}.json',world)
        assert len(result)==4;code=0
    except BaseException as exc:put(out/'Failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'current':current,'full_benchmark_gate':'UNKNOWN'})
    finally:
        pp.runpp=backend
        if journal:journal.close()
        if pack:pack.close()
        if oldpack:oldpack.close()
        put(out/'Result.json',{'exit_code':code,'worlds':result,'actual_costs':cost,'owned_seconds_before_final_closure':time.perf_counter()-begun,
            'partial_missing_worlds_UNKNOWN':4-len(result),'original_literal_DFF_DSE_whole_policy':'NOT_TESTED','no_scientific_retry':True})
        put(out/'Closed_Manifest.json',{'exit_code':code,'members':inventory(out,hashes=True)})
    raise SystemExit(code)

def audit():
    out=B/'actual';p=read(B/'Protocol.json');ph=sha(B/'Protocol.json');end=read(B/'Owner_End_ACK.json')
    assert not process_alive(end['actual_pid']) and not process_alive(end['launcher_pid']) and end['exit_code']==0
    assert sha(out/'Closed_Manifest.json')==end['closed_manifest_sha256']
    m=read(out/'Closed_Manifest.json');assert m['exit_code']==0
    for n,d in m['members'].items():assert local_root(out/n).stat().st_size==d['bytes'] and sha(out/n)==d['sha256']
    for n,h in p['source_input_sha256'].items():assert sha(R/n)==h
    folder=B/'audit';local_root(folder).mkdir(exist_ok=False);put(folder/'owner.claim',{'actual_pid':os.getpid(),'source_sha256':sha(Path(__file__))})
    prev='0'*64;events=[]
    for raw in local_root(out/'scientific.jsonl').read_bytes().splitlines():
        e=json.loads(raw);assert e['previous_sha256']==prev and e['protocol_sha256']==ph;prev=hashlib.sha256(raw).hexdigest();events.append(e)
    returns={e['data']['PF_id']:e['data'] for e in events if e['event']=='PF_return'}
    _,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    def blocked(*a,**k):raise RuntimeError('No PF/model/optimizer/forecast in external audit')
    for n in ('runpp','rundcpp','runopp','rundcopp'):
        if hasattr(pp,n):setattr(pp,n,blocked)
    pack=local_root(out/'capsules.bin').open('rb');closed=[e for e in events if e['event']=='new_second_candidate_closed']
    for e in closed:
        r=e['data']['record'];receipt=r['measured_receipt']
        if receipt is None:assert not r['verif']['accepted'] and r['verif']['reason']=='q_cap_exceeded';continue
        assert receipt['outcome']=='RETURNED' and receipt==returns[receipt['PF_id']]
        net=decode_capsule(pack,receipt['after'])['net'];assert fields(net)==receipt['fields'] and bool(net.converged)==receipt['converged']
        actual=metrics(fields(net));expected=r['verif']['after']
        assert all(abs(actual[k]-expected[k])<=1e-12 for k in actual)
        assert r['original_score']==list(runner.rescue.score_candidate({'action':r['action'],'verif':r['verif']}))
        assert r['verif']['accepted']==(r['verif']['original_native_accepted'] and actual['vmax']<=1.05+1e-8)
    result=read(out/'Result.json');c=result['actual_costs'];assert c['PF_returns']==len(returns) and c['PF_exceptions']==0
    assert abs(c['PF_seconds']-sum(r['seconds'] for r in returns.values()))<=1e-8
    summaries=[];wins=0;losses=0
    for w in result['worlds']:
        baseline=next(b for b in w['branches'] if b['method']=='complete_protected_ordinary_greedy2')
        assert baseline['status']=='COMPLETE_ALL_DECLARED_SECOND_CANDIDATES' and len(baseline['second_candidates'])==baseline['declared_second_candidates']
        for branch in w['branches']:
            if 'selected_second' not in branch:continue
            selected=best(branch['second_candidates']);assert selected==branch['selected_second']
            assert branch['device_operations']==1+bool(selected) and branch['following_cursor']['remaining_original_device_operation_slots']>=1
            if selected:
                replay=branch['independent_replay'];assert replay==returns[replay['PF_id']]
                replay_net=decode_capsule(pack,replay['after'])['net'];assert fields(replay_net)==replay['fields']
                assert max(abs(replay['fields'][b][k]-branch['final_fields'][b][k]) for b in replay['fields'] for k in replay['fields'][b])<=1e-10
        a=metrics(baseline['final_fields']);j=metrics(w['one_joint_two_operations']['final_fields']);wins+=j['uv_count']<a['uv_count'];losses+=j['uv_count']>a['uv_count']
        summaries.append({'world':w['world'],'two_ordinary_greedy':a,'one_joint_charged_two_operations':j,
            'lowest_voltage_greedy':metrics(next(b for b in w['branches'] if b['method']=='lowest_voltage_ordinary_greedy2')['final_fields'])})
    assert len(summaries)==4;pack.close();gate='PASS_DEVELOPMENT_EQUAL_OPERATION_OPPORTUNITY' if wins>=2 and losses==0 else 'FAIL_STOP_EQUAL_OPERATION_CLAIM'
    put(folder/'Independent_Audit.json',{'state':'PASS_PRESERVED_FULL_DECLARED_EQUAL_OPERATION_AUDIT','fixed_gate':gate,'strict_joint_wins':wins,'joint_losses':losses,
        'world_results':summaries,'actual_costs':c,'new_audit_model_PF_calls':0,
        'scope':'Four inspected development current states, two-operation conditional measurements; not fullDFF/DSE trajectories, globaltwo-action optimum orLLMsuperiority.',
        'cost_limit':'Historical first/joint and any identical second-query reuse retained with attributed paidsolvercosts. Actual deployment walltime for isolated methods UNKNOWN; do not treat cache as free.'})
    put(folder/'Fresh_Frozen_After.json',frozen_checks());put(folder/'Closed_Manifest.json',inventory(folder,hashes=True))
    print(json.dumps({'audit':'PASS','gate':gate,'wins':wins,'losses':losses,'new_PF':c['PF_attempts']}))

def process(pid):
    cmd=f"Get-CimInstance Win32_Process -Filter 'ProcessId = {int(pid)}' | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress"
    q=subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',cmd],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert q.returncode==0;return json.loads(q.stdout) if q.stdout.strip() else None
def launch(mode):
    with local_root(B/(mode+'_console.log')).open('x',encoding='utf8') as log:
        child=subprocess.Popen([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(Path(__file__)),'--'+mode],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        if mode=='worker':
            start=time.perf_counter();path=B/'actual/owner.claim'
            while not local_root(path).exists():
                assert child.poll() is None and time.perf_counter()-start<120;time.sleep(.1)
            claim=read(path);real=process(claim['actual_pid']);assert real and real['ParentProcessId']==child.pid and Path(__file__).name in real['CommandLine']
            put(B/'actual/Launcher_ACK.json',{'actual_pid':claim['actual_pid'],'actual_parent_pid':child.pid,'fresh_PID_parent_command':True})
            put(B/'Live_Ownership.json',{'actual_pid':claim['actual_pid'],'launcher_pid':child.pid,'source':str(Path(__file__).relative_to(R)),'mode':'worker'})
        exitcode=child.wait()
    if mode=='worker':put(B/'Owner_End_ACK.json',{'actual_pid':claim['actual_pid'],'launcher_pid':child.pid,'exit_code':exitcode,'closed_manifest_sha256':sha(B/'actual/Closed_Manifest.json')})
    return exitcode
def prepare():
    local_root(B).mkdir(exist_ok=False);put(B/'coordinator.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'argv':sys.argv})
    verified=read(OLD/'verified_handoff/Verified_Physical_Opportunity_Checkpoint.json');assert verified['fixed_gate']=='PASS_LOCAL_PHYSICAL_OPPORTUNITY_ONLY'
    # Historical PIDs can be reused overnight. Require fresh exact source
    # ownership, not absence of an unrelated process with an old numeric ID.
    command="Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -match 'run_joint_reallocation_opportunity_v1.py|prepare_run_joint_reallocation_opportunity_v1.py|audit_joint_reallocation_opportunity_v1.py' } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Depth 3 -Compress"
    fresh=subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',command],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert fresh.returncode==0 and not fresh.stdout.strip(),'An actual original source owner is still live'
    put(B/'Fresh_Original_Source_Ownership.json',{'no_matching_live_original_sources':True,'historical_PID_reuse_is_not_owner_restart':True})
    original,rows,_=initial_data();_,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    for entry in original['current_endpoints']:
        net,cursor,_=load_endpoint(entry);assert native_scope(net,runner,zones)==cursor['raw_current_receiver_scope'] and cursor['remaining_original_device_operation_slots']>=2
    source_names=['work/equal_operation_benchmark_v2.py','work/frozen_physics_loader.py','work/joint_reallocation_opportunity_core_v1.py',
        'work/owned_bank_joint_reallocation_v1.py','work/durable_opaque_evidence_store_v1.py','work/candidate_process_evidence_utils.py',
        'work/e/audit/phase2g_rescue_runner.py','work/e/audit/phase2g_llm_guided_rescue_runner.py','work/e/audit/phase2g_multiagent_llm_runner.py',
        'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json']
    pins={n:sha(R/n) for n in source_names}
    for n in ['preparation/Protocol.json','actual/Closed_Manifest.json','verified_handoff/Verified_Physical_Opportunity_Checkpoint.json']:
        path=OLD/n;pins[str(path.relative_to(R))]=sha(path)
    for entry in original['current_endpoints']:pins[entry['endpoint_record']]=sha(R/entry['endpoint_record'])
    now=datetime.now(timezone.utc);p={'study':'PROSPECTIVE_EQUAL_TWO_DEVICE_OPERATION_DEVELOPMENT_SCREEN','frozen_at_utc':now.isoformat(),
        'absolute_deadline_utc':(now+timedelta(seconds=900)).isoformat(),'maximum_PF_attempts':4000,'maximum_storage_bytes':2*1024**3,
        'source_input_sha256':pins,'runtime':{n:importlib.metadata.version(n) for n in ('numpy','scipy','pandas','pandapower')},
        'solver_kwargs':original['trial_solver_kwargs'],'all4fixed_development_roots':[e['world'] for e in original['current_endpoints']],
        'methods':['complete_protected_ordinary_greedy2','lowest_voltage_ordinary_greedy2','one_complete_joint_charged_two_operations'],
        'fixed_gate':'At least2strict jointUVwins and0UVlosses versus complete two-ordinary greedy at equal2operation allowance; all source/replay/protection/audit gates PASS. Failedgate stops this specific equal-operation claim; no Q/width/seed/world/objective/budget retune.',
        'native_grid_cap_raw_scope_and_protection':'Original9Q/450positive-lifetime cap, no withdrawal refund, original verifier/score plus sharednormal1.05+1e-8; initialprefix operations retained.',
        'reuse':'All already executed first/joint rootqueries reused from exact paid receipts. Identical following-query key reused within this new owner. No old science repeated except separately charged prospectively declared independent selected second-action replay.',
        'goal_lifecycle':'Actual overarching goal observed usageLimited; no tool lifecycle override. This is bounded new direct-human-authorized benchmark work, not autonomous goal resumption.',
        'full_DFF_ALT_DSE_policy_or_LLM_value':'NOT_TESTED. Complete literal fullpolicybenchmark requires separately fixed source/execution/controls/fullboth costs.',
        'fresh_confirmation':'NONE; allfourinitial currentstates inspecteddevelopment',
        'reader':'One source-locked same-script audit after actualowner+launcher ended, exit0/fullclosedmanifest. Zero new model/PF/forecast calls; partialgateUNKNOWN/no complete-reader onpartial.'}
    put(B/'Protocol.json',p);put(B/'Fresh_Frozen_Before.json',frozen_checks())
    put(B/'status.json',{'stage':'FIXED_PROTOCOL_RUNNING_SINGLE_OWNER','source':'work/equal_operation_benchmark_v2.py','science_result':'UNKNOWN','goal_lifecycle_not_overridden':'usageLimited'})
    science=launch('worker');reader=None
    if science==0:reader=launch('audit')
    put(B/'Completion.json',{'science_exit':science,'reader_exit':reader,'all_original_chains_ended':True,'finished_at_utc':datetime.now(timezone.utc).isoformat()})
    put(B/'status_terminal.json',{'science_exit':science,'reader_exit':reader,'stage':'TERMINAL_COMPLETE' if science==reader==0 else 'TERMINAL_PARTIAL_OR_AUDIT_FAILURE','no_retry':True})
    print(json.dumps({'science_exit':science,'reader_exit':reader,'root':str(B)}))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--worker',action='store_true');parser.add_argument('--audit',action='store_true');a=parser.parse_args()
    if a.worker:worker()
    elif a.audit:audit()
    else:prepare()
