"""Compact exact-source/evidence publication after all new physics actors end."""
import hashlib,json,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,sha
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME

def main():
    base=R/'outputs/third_child_followup_handoff_20261019';s=base/'publication_snapshot';s.mkdir(exist_ok=False)
    actual=R/'outputs/unentered_third_child_fixed_four_followup_acquisition_v2_20261019'
    assert read(actual/'Completion.json')['exit_codes']=={'warm':0,'cold_1':0,'cold_2':0,'cold_3':0,'audit':0}
    assert read(actual/'audit/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_FOUR_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
    for source,name in [(R/'RESEARCH_TASKS.md','RESEARCH_TASKS.md'),(R/'outputs/research_tasks_20261014/Tasks.json','Tasks.json'),(base/'Checkpoint.json','Checkpoint.json'),(R/'outputs/fifth_numeric_dependency_handoff_20261019/publication_snapshot/DATA_ATTRIBUTION_AND_LICENSE.txt','DATA_ATTRIBUTION_AND_LICENSE.txt')]:s.joinpath(name).write_bytes(source.read_bytes())
    s.joinpath('Execution_Index.md').write_bytes((base/'Execution_Index.md').read_bytes())
    names=['prepare_third_child_followup_sources_20261019','third_child_fixed_four_followup_core_20261019','run_third_child_fixed_four_followup_20261019','audit_third_child_fixed_four_followup_20261019','certify_third_child_fixed_four_followup_20261019','prepare_third_child_fixed_four_followup_20261019','diagnose_third_child_zero_native_20261019','prepare_unentered_third_child_sources_v2_20261019','unentered_third_child_fixed_four_followup_core_v2_20261019','run_unentered_third_child_fixed_four_followup_v2_20261019','audit_unentered_third_child_fixed_four_followup_v2_20261019','certify_unentered_third_child_fixed_four_followup_v2_20261019','prepare_unentered_third_child_fixed_four_followup_v2_20261019','resume16_third_child_receipts_20261019','resume16_with_unentered_third_child_receipts_v2_20261019','prepare_third_child_publication_snapshot_20261019']
    files=[R/'work'/(n+'.py') for n in names]
    for rel,items in {
        'third_child_fixed_four_followup_acquisition_20261019':['Protocol.json','Readiness.json','Completion.json','warm/Failure.json','warm/Closed_Manifest.json','warm_End_ACK.json','audit/Independent_Audit.json','audit/Closed_Manifest.json','audit_End_ACK.json'],
        'third_child_zero_native_diagnosis_20261019':['Independent_Diagnosis.json'],
        'unentered_third_child_fixed_four_followup_input_v2_20261019':['Source_And_Input_Binding.json'],
        'unentered_third_child_fixed_four_followup_acquisition_v2_20261019':['Protocol.json','Readiness.json','Attempt_Coverage_Certificate.json','Source_Transformation_Proof.json','Exact_Actual_Warm_State_Construction.json','Independent_Reader_Lock.json','Frozen_Prelaunch.json','Completion.json','audit/Independent_Audit.json','audit/Closed_Manifest.json','storage_admission_fixture/Result.json'],
        'third_child_followup_handoff_20261019':['Conditional_Policy_Data_Addition.json','Conditional_Unentered_Policy_Data_Addition_v2.json','Final_Certificate_Closure_Proof.json','Verified_New_Physical_Completion.json'],
        'resumed16_next_fifth_context_20261019':['Results.json','Leg_1.json','Closed_Manifest.json','owner.claim','Protocol.json'],
    }.items():files.extend(R/'outputs'/rel/f for f in items)
    for phase in ['warm','cold_1','cold_2','cold_3']:
        files.extend(actual/phase/n for n in ['Result.json','Closed_Manifest.json','owner.claim','Launcher_ACK.json'])
        files.append(actual/(phase+'_End_ACK.json'))
    entries=[];pack=s/'Code_Proofs_Costs_And_ZeroNative_Failure.zip'
    with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):
            raw=p.read_bytes();assert len(raw)<4*1024**2 and not SECRET_NAME.search(p.name)
            assert not any(v.search(raw.decode('utf-8')) for v in SECRET)
            rel=p.relative_to(R).as_posix();z.writestr(rel,raw);entries.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    with zipfile.ZipFile(pack) as z:
        assert z.testzip() is None
        for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
    audit={'status':'PASS_CRC_ALL_EXACT_MEMBERS_AND_CREDENTIAL_SCREEN','at_utc':datetime.now(timezone.utc).isoformat(),'members':len(entries),'bytes':pack.stat().st_size,'sha256':sha(pack),'files':entries,'prior_verified_head':'935f05a6e29ffd909501e328cc4f5dd0e507d937','scope':'Compact source/proof/cost publication; rawNET/capsules/matrices/models remain local, not a full rawbackup.'}
    s.joinpath('Pack_Audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({k:v for k,v in audit.items() if k!='files'}))

if __name__=='__main__':main()
