"""Exclusive source/checkpoint engineering; no model forward or power flow."""
import hashlib,json,os,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/tpa_checkpoint_loader_engineering_v2_20261020'
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic()
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixed_bound_seconds':180,'scope':'CPU weights_only checkpoint load and strict actual author-class state binding using all322native input shapes/adjacency; headless class import, zero modelforward/PF/training/optimizer/GPU. No outcome-selectedarchitecture or parameter fill.'}
    put(OUT/'Protocol.json',protocol);put(OUT/'owner.claim',protocol)
    try:
        import candidate_process_runtime  # existing bundled C++ DLL initialization, local interpreter only
        import tpa_benchmark_bridge_20261020 as b
        b.torch.set_num_threads(1);b.torch.manual_seed(53)
        args,n=b.static_args();model,state=b.load_policy(args);cls,astproof=b.headless_environment_class()
        shapes={k:{'shape':list(x.shape),'dtype':str(x.dtype),'numel':x.numel()} for k,x in state['model_state_dict'].items()}
        assert time.monotonic()-start<180
        put(OUT/'Result.json',{**protocol,'status':'PASS_CPU_SAFE_LOAD_STRICT_AUTHOR_STATE_AND_HEADLESS_IMPORT','torch_version':b.torch.__version__,'numpy_version':b.np.__version__,'pandas_version':b.pd.__version__,'checkpoint_sha256':b.digest(b.CHECKPOINT),'native_agents':args.agent_num,'obs_size':args.obs_size,'bus_features':args.obs_bus_dim,'history_length':args.tp,'state_entries':len(shapes),'checkpoint_tensor_elements':sum(x['numel'] for x in shapes.values()),'shapes':shapes,'headless_AST_proof':astproof,'new_model_forwards_PF_optimizer_GPU_calls':0,'workflow_seconds':time.monotonic()-start})
        print(json.dumps({'loader':'PASS','state_entries':len(shapes),'agents':args.agent_num,'obs_size':args.obs_size,'model_PF_calls':0}))
    except BaseException as e:
        put(OUT/'Failure.json',{**protocol,'failure_type':type(e).__name__,'failure':str(e)[:1500],'new_model_forwards_PF_optimizer_GPU_calls':0,'workflow_seconds':time.monotonic()-start});raise
if __name__=='__main__':main()
