"""New paired central/zonal orchestration around unchanged frozen HG-VF code.

Historical GPU development must complete before creating a central protocol.
This file is prepared for the next GPU stage; it does not interrupt the main run.
"""
from pathlib import Path
import argparse,hashlib,json,math,os,random,sys,time,warnings,traceback
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True);warnings.filterwarnings('ignore')
os.environ['HF_HOME']=str(Path('cache/huggingface').resolve());os.environ['HF_HUB_OFFLINE']='1';os.environ['UNSLOTH_DISABLE_STATISTICS']='1'
import torch
from unsloth import FastLanguageModel
import numpy as np
import pandapower as pp
from frozen_physics_loader import ROOT,load_stack,AUDIT
from central_ablation import build_central_runner,CONTEXT,GENERATION
from run_matched_campaign import save,sha
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--development',action='store_true');parser.add_argument('--locked',action='store_true');parser.add_argument('--resume',action='store_true');args=parser.parse_args();assert args.development!=args.locked
    matched=json.loads(Path('outputs/matched_campaign_protocol.json').read_text())
    for name,h in matched['source_sha256'].items():assert sha(name.replace('\\','/'))==h
    dep=json.loads(Path('outputs/exact_dependency_check.json').read_text());assert dep['checked_count']==111 and not dep['differences']
    environment=json.loads(Path('outputs/remote_frozen_environment.json').read_text());assert environment['base_revision_verified']==matched['base_revision']
    inputs=json.loads(Path('outputs/frozen_input_verification.json').read_text());adapter=ROOT/'pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for name,h in inputs['model_files'].items():assert sha(adapter/name)==h
    lock=json.loads((ROOT/'bank/BANK_LOCK.json').read_text());manifest=json.loads((ROOT/'bank/scenario_manifest.json').read_text());assert lock['bank_digest_sha256']==matched['bank_digest']==manifest['bank_digest_sha256']
    assert sha(ROOT/'bank/scenario_manifest.json')==lock['manifest_sha256']
    for n,h in lock['scenario_file_sha256'].items():assert sha(ROOT/'bank/scenarios'/n)==h
    for name,key in [('federation_4mg_ieee118.json','federation_network_sha256'),('federation_4mg_ieee118_metadata.json','federation_metadata_sha256')]:assert sha(ROOT/'pack/testbeds'/name)==manifest['frozen_asset_hashes'][key]
    protocol={'parent_matched_protocol_sha256':sha('outputs/matched_campaign_protocol.json'),'central_source_sha256':sha('work/central_ablation.py'),'runner_sha256':sha(__file__),'source_sha256':matched['source_sha256'],'bank_digest':matched['bank_digest'],'base_revision':matched['base_revision'],'seed':20260916,'context_limit':CONTEXT,'max_new_tokens_each_call':GENERATION,'iterations':25,'branches':['HG-VF','CENTRAL-VF'],'branch_execution_order':'HG then central on odd case indices, central then HG on even indices. Sorted bank has 31 cases per load level, so order reverses within every outaged-line family across the two loads.','query_budget':'four primary proposal slots and at most one repair each per iteration for both branches; actual calls/input/output tokens charged','global_observation':'all 118 bus voltages rounded to six decimals for prompting, all four zone membership lists and summaries, exact union of original zonal candidate pools; physical inputs unmodified','overflow_policy':'reduce only feedback-memory character allowance 1200,900,600,300,0; fail explicitly if full physical observation plus generation still exceeds context; no silent token truncation','comparison_scope':'same frozen zonally trained LoRA; context/architecture ablation conditional on that model, not a retraining comparison','timing_scope':'both standalone branches run in this paired campaign; no portfolio or historical-run timing substituted'}
    protocol['central_proposal_diversity']='Four sequential global slots; exclude buses of earlier structurally valid proposals within the same iteration, reset on first slot of each iteration; repair uses the same reduced pool; explicit exhaustion yields no proposal. Physics and proposal refinement remain original.'
    protocol['analysis_status']='Secondary architecture comparison; both standalone branches first, envelopes with shared previously saved DFF outcomes separately. Shared historical DFF wall time is not a simultaneous matched-hardware portfolio timing.'
    protocol['analysis_source_sha256']=sha('work/analyze_central_campaign.py')
    protocol_path=Path('outputs/central_experiment_protocol.json')
    if args.locked:
        assert protocol_path.exists(),'Central protocol must be frozen after historical GPU validation'
        assert json.loads(protocol_path.read_text())==protocol,'Central protocol identity changed'
        validation=json.loads(Path('outputs/central_gpu_development_validation.json').read_text());assert validation['passed'] and validation['central_source_sha256']==protocol['central_source_sha256'] and validation['runner_sha256']==protocol['runner_sha256']
    v2,runner,ref=load_stack();runner.base_runner.__dict__['torch']=torch;assert runner.MAX_ITERATIONS==25 and runner.base_runner.MAX_NEW_TOKENS==GENERATION
    model,tokenizer=FastLanguageModel.from_pretrained(model_name=str(adapter),max_seq_length=CONTEXT,dtype=None,load_in_4bit=True);FastLanguageModel.for_inference(model);model.eval();torch.cuda.synchronize()
    central=build_central_runner(ref,runner);base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json');assert len(zones)==4
    files=[ROOT/'pack/scenarios/federation'/f'{sid}.json' for sid in ['fed_combined_load_1p25_line_101_MG1','fed_combined_load_1p5_line_101_MG1']] if args.development else sorted((ROOT/'bank/scenarios').glob('*.json'))
    if args.development:assert not {p.name for p in files}&set(lock['scenario_file_sha256'])
    else:assert len(files)==62 and {p.name for p in files}==set(lock['scenario_file_sha256'])
    out=Path('outputs/central_gpu_development' if args.development else 'outputs/central_matched_campaign');out.mkdir(parents=True,exist_ok=True)
    config={'protocol':protocol,'frozen_environment':environment,'dependency_check':dep,'loader_audit':AUDIT,'development':args.development}
    if (out/'config.json').exists():assert json.loads((out/'config.json').read_text())==config
    else:save(out/'config.json',config)
    counts={'pf_attempts':0,'pf_returns':0,'pf_exceptions':0,'pf_wall_seconds':0.,'llm_calls':0,'llm_exceptions':0,'llm_wall_seconds':0.,'input_tokens':0,'output_tokens':0};original_pf=pp.runpp;original_generate=model.generate
    def pf(*a,**kw):
        counts['pf_attempts']+=1
        started=time.perf_counter()
        try:r=original_pf(*a,**kw);counts['pf_returns']+=1;return r
        except Exception:counts['pf_exceptions']+=1;raise
        finally:counts['pf_wall_seconds']+=time.perf_counter()-started
    def generate(*a,**kw):
        ids=kw.get('input_ids',a[0] if a else None);n=int(ids.numel());assert n+GENERATION<=CONTEXT,'Actual model call exceeds declared context budget';counts['llm_calls']+=1;counts['input_tokens']+=n
        torch.cuda.synchronize();started=time.perf_counter()
        try:r=original_generate(*a,**kw);seq=r.sequences if hasattr(r,'sequences') else r;counts['output_tokens']+=int(seq.numel())-n;return r
        except Exception:counts['llm_exceptions']+=1;raise
        finally:torch.cuda.synchronize();counts['llm_wall_seconds']+=time.perf_counter()-started
    pp.runpp=pf;model.generate=generate
    random.seed(protocol['seed']);np.random.seed(protocol['seed']);torch.manual_seed(protocol['seed']);torch.cuda.manual_seed_all(protocol['seed']);done=[];checks=[]
    for idx,p in enumerate(files,1):
        path=out/'cases'/p.name;rng_path=out/'rng'/f'{idx:03d}.pt'
        if args.resume and path.exists():
            record=json.loads(path.read_text());assert record['scenario_sha256']==sha(p) and record['protocol']==protocol
            state=torch.load(rng_path,weights_only=False,map_location='cpu');random.setstate(state['python']);np.random.set_state(state['numpy']);torch.set_rng_state(state['torch']);torch.cuda.set_rng_state_all(state['cuda']);done.append(p.stem)
        else:
            scenario=json.loads(p.read_text());record={'scenario_id':p.stem,'scenario_sha256':sha(p),'protocol':protocol,'branches':{},'costs':{}};base_before=pp.to_json(base)
            order=protocol['branches'] if idx%2 else list(reversed(protocol['branches']));record['branch_execution_order']=order
            for name in order:
                prior=counts.copy();torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();start=time.perf_counter()
                call=central if name=='CENTRAL-VF' else ref.run_one_scenario_two_best_v2
                try:record['branches'][name]=call(scenario=scenario,base_net=base,zones=zones,v2=v2,model=model,tokenizer=tokenizer,mode='reflection_v2')
                except Exception as exc:record['branches'][name]={'status':'exception','exception_type':type(exc).__name__,'traceback':traceback.format_exc(),'executed_actions':[]}
                torch.cuda.synchronize();record['costs'][name]={k:counts[k]-prior[k] for k in counts};record['costs'][name].update(wall_seconds=time.perf_counter()-start,peak_gpu_memory_allocated_bytes=torch.cuda.max_memory_allocated())
                assert pp.to_json(base)==base_before,'Branch changed frozen base network'
            valid=all(b.get('base_converged') and b.get('final_metrics') and all(isinstance(v,(int,float)) and math.isfinite(v) for v in b['final_metrics'].values()) for b in record['branches'].values());record['paired_terminal_metrics_valid']=valid
            if valid:assert record['branches']['HG-VF']['base_metrics']==record['branches']['CENTRAL-VF']['base_metrics']
            save(path,record);rng_path.parent.mkdir(parents=True,exist_ok=True);torch.save({'python':random.getstate(),'numpy':np.random.get_state(),'torch':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all()},rng_path);done.append(p.stem)
            print('CENTRAL_CASE_SAVED',p.stem,'paired_valid',valid,flush=True)
        if args.development:
            checks.append({'scenario_id':p.stem,'finite_metrics':record['paired_terminal_metrics_valid'],'both_branches_generated':all(record['costs'][n]['llm_calls']>0 for n in protocol['branches']),'llm_exceptions_zero':all(record['costs'][n]['llm_exceptions']==0 for n in protocol['branches']),'action_budget_respected':all(len(b.get('executed_actions',[]))<=25 for b in record['branches'].values())})
            query_logs=[r for r in record['branches']['CENTRAL-VF'].get('logs',[]) if r.get('llm_info',{}).get('central_prompt')]
            by_iteration={}
            for r in query_logs:by_iteration.setdefault(r['iteration'],[]).append(r)
            checks[-1]['central_slots_within_four_per_iteration']=all(len(rs)<=4 and len({r['llm_info']['proposal_slot'] for r in rs})==len(rs) for rs in by_iteration.values())
            checks[-1]['central_replies_respect_diversity_exclusion']=all(not r.get('action') or str(runner.action_bus(r['action'])) not in r['llm_info'].get('previous_proposal_buses',[]) for r in query_logs)
            checks[-1]['central_context_and_observation_audit']=bool(query_logs) and all(r['llm_info']['central_prompt']['input_tokens']+GENERATION<=CONTEXT and not r['llm_info']['central_prompt']['physical_observation_truncated'] for r in query_logs)
            checks[-1]['central_accepted_bus_ownership_recorded']=all(r.get('physical_bus_owner') in zones for r in record['branches']['CENTRAL-VF'].get('executed_actions',[]) if r.get('action'))
        save(out/'progress.json',{'status':'running','completed_count':len(done),'planned_count':len(files),'completed_ids':done})
    save(out/'progress.json',{'status':'complete','completed_count':len(done),'planned_count':len(files),'completed_ids':done})
    if args.development:
        passed=all(all(v for k,v in row.items() if k!='scenario_id') for row in checks);validation={'passed':passed,'central_source_sha256':protocol['central_source_sha256'],'runner_sha256':protocol['runner_sha256'],'checks':checks,'criterion':'structural and physical/numerical execution validity, not superiority or tuning on the bank'};save('outputs/central_gpu_development_validation.json',validation)
        assert passed,'Historical GPU development validation failed; no central protocol frozen'
        save(protocol_path,protocol);print('CENTRAL_PROTOCOL_FROZEN_AFTER_GPU_DEVELOPMENT',flush=True)
if __name__=='__main__':main()
