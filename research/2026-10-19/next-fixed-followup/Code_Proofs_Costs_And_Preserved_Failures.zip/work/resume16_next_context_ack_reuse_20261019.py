"""Unchanged16UV saved policy, now with ALL4 declared followup receipts.

The zero-native storage admission failure is retained as software provenance,
never inserted as a measured physical rejection. No new science is possible.
"""
import ast,copy,hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
import resume_verified16_paid_policy_support_20261019 as previous
from replay_all_thirteen_paid_receipts_20261019 import Registry as PriorRegistry
from replay_paid_suffix_new_receipts_v3_20261018 import Overlay
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from strict_saved_native_input_match_v2_20261018 import require_same
from equal_operation_benchmark_v2 import decode_capsule
from audit_full_receding_linear_composed_v4_20261018 import check_query
B=R/'outputs/resumed16_next_context_ack_reuse_20261019'
PREP=R/'outputs/resumed16_next_context_ack_reuse_preparation_20261019'
FIRST=R/'outputs/unentered_ordinary_query_acquisition_v2_20261019'
REST=R/'outputs/ordinary_followup_remaining_three_acquisition_20261019'
from source_bound_receipt_ack_bundle_20261019 import P as ACKP,import_members
NUMBERS=previous.NUMBERS+['fourth_required_numeric_context_v2_20261019']

class Registry(PriorRegistry):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.followup_locks=[];self.followups={}
        assert read(FIRST/'Completion.json')['exit_codes']=={'warm':0,'audit':0}
        assert read(FIRST/'audit/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_SINGLE_QUERY_AND_CHARGED_REPLAY_COLD_READER'
        assert read(REST/'Completion.json')['exit_codes']=={'warm':0,'cold_1':0,'cold_2':0,'audit':0}
        assert read(REST/'audit/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_THREE_QUERY_ACQUISITION_COLD_AND_CHARGED_REPLAY'
        assert read(R/'outputs/next_ordinary_query_zero_native_diagnosis_20261019/Independent_Diagnosis.json')['native_PF_attempts_returns_exceptions']==0
        for base,phases in [(FIRST,('warm',)),(REST,('warm','cold_1','cold_2'))]:
            self.followup_locks.append(LockedSourceSnapshot(base/'Protocol.json'));p=read(base/'Protocol.json')
            for phase in phases:
                root=base/phase
                for rel,h in read(root/'Closed_Manifest.json')['members'].items():assert sha(root/rel)==h
                message=read(root/'Result.json')['receipt']['message'];key=p['point']+'|'+message['aid'];record=copy.deepcopy(message['record'])
                assert record['actual_measured_receipt'] is not None
                if record['after_reference'] is not None:record['after_reference']={'kind':'external_capsule','base':str(base.relative_to(R)),'descriptor':{**record['after_reference']['descriptor'],'path':phase+'/capsules.bin'}}
                intents={};returns={};exceptions={}
                for raw in (root/'scientific.jsonl').read_bytes().splitlines():
                    e=json.loads(raw);d=e['data']
                    if e['event']=='PF_intent':intents[d['identity']]=d
                    elif e['event']=='PF_return':returns[d['PF_id']]=d
                    elif e['event']=='PF_exception':exceptions[d['PF_id']]=d
                assert key not in self.archive.index and key not in self.followups and key not in self.new_data and key not in self.more and key not in self.four and key not in self.tail
                self.followups[key]={'base':base,'root':root,'p':p,'message':message,'record':record,'intents':intents,'returns':returns,'exceptions':exceptions}
        assert len(self.followups)==4;self.cache=Overlay(self.cache,{k:d['record'] for k,d in self.followups.items()});self.followup_stream=(self.path/'new_fixed_followup_receipt_uses.jsonl').open('xb')
        assert read(R/'outputs/source_bound_ack_bundle_fixture_20261019/Results.json')['status']=='PASS_REAL_IMMUTABLE_ZIP_ACK_TRANSPORT_UNCHANGED_IMPORT_AST_AND_UNKNOWN_MEMBER_REJECTION'
        proof=import_members(self);assert proof['imported']==697
        put(self.path/'Imported_Paid_Verification_Costs.json',proof)

    def lookup(self,node,row,key):
        if key not in self.followups:return super().lookup(node,row,key)
        begun=time.perf_counter();d=self.followups[key];assert key==point_key(node['net'],node['cursor'])+'|'+action_key(row) and row==d['message']['row']
        expected=build_verifier(self.runner.rescue,node['cursor'])[1](copy.deepcopy(node['net']),action(row));pid=d['record']['actual_measured_receipt']['PF_id']
        with (d['root']/'capsules.bin').open('rb') as pack:
            require_same(expected,decode_capsule(pack,d['intents'][pid]['before'])['net']);check_query(node,row,d['message'],cache={},intents=d['intents'],returns=d['returns'],exceptions=d['exceptions'],pack=pack,p=d['p'],runner=self.runner)
        record=copy.deepcopy(d['record']);seconds=time.perf_counter()-begun
        event={'key':key,'source_protocol_sha256':sha(d['base']/'Protocol.json'),'independent_audit_sha256':sha(d['base']/'audit/Independent_Audit.json'),'verification_workflow_seconds':seconds,'new_PF':0,'old_zero_native_storage_failure_preserved':True}
        raw=json.dumps(event,sort_keys=True,separators=(',',':')).encode()+b'\n';self.followup_stream.write(raw);self.followup_stream.flush();os.fsync(self.followup_stream.fileno())
        record['source_original_receipt_id']=record['receipt_id'];record['receipt_id']='ARCHIVED_FIXED_FOLLOWUP_'+hashlib.sha256(key.encode()).hexdigest()
        record['verified_use_reference']={'path':str((self.path/'new_fixed_followup_receipt_uses.jsonl').relative_to(R)),'prefix_bytes':self.followup_stream.tell(),'event_sha256':hashlib.sha256(raw[:-1]).hexdigest(),'actual_verification_CPU_seconds':seconds,'clock_semantics':'Measured perfcounter workflow, not process CPU or intrinsic solver latency'}
        return record

    def close(self):
        self.followup_stream.close()
        for lock in self.followup_locks:lock.close()
        super().close()

def main():
    assert read(REST/'Completion.json')['exit_codes']=={'warm':0,'cold_1':0,'cold_2':0,'audit':0}
    assert read(R/'outputs/fourth_required_numeric_context_v2_20261019/Completion.json')['exit_codes']=={'actual':0,'independent_audit':0}
    assert not B.exists() and not PREP.exists()
    text=Path(previous.__file__).read_text('utf-8');node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main');fn=copy.deepcopy(node)
    # Add current protocols/results to the prospective source snapshot. The old
    # fixed policy, cached numerical context, projection and UNKNOWN stop stay.
    target=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='versions' for t in n.targets))
    additions=ast.parse("""for root in [FIRST,REST]:
    files += [root/'Protocol.json',root/'Completion.json',root/'audit/Independent_Audit.json']
files += [R/'outputs/next_ordinary_query_zero_native_diagnosis_20261019/Independent_Diagnosis.json']
files += [ACKP/'All697_Closed_Receipt_ACKs.zip',ACKP/'All697_Closed_Receipt_ACKs.json',ACKP/'Results.json',R/'outputs/source_bound_ack_bundle_fixture_20261019/Results.json']
""").body
    fn.body[target:target]=additions
    env=previous.__dict__.copy();env.update(B=B,PREP=PREP,Registry=Registry,FIRST=FIRST,REST=REST,NUMBERS=NUMBERS,ACKP=ACKP,__file__=__file__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),__file__,'exec'),env);env['main']()

if __name__=='__main__':main()
