> Latest 2026-10-08T13:17:18.872540+00:00: VCSA has139 genuine no-LLM control replay PF calls and5 started/4 source-proven returned local pretrained CPU forwards; zero preserved real optimizer completions/checkpoints. CPU attempt terminal; no owned jobs. v3 decoder/checkpoint software20 checks passed (192 records/94 reloaded actions), not learned evidence. Exact34,831,836-byte Sheena T4 upload approval remains pending. Read outputs/vcsa_development/post_CPU_integration_readiness/Verified_Readiness_Checkpoint.md and Attribution_Gates_and_Execution_Order.md. Original baseline unchanged; superiority unachieved. Older zero-pretrained/CPU-running/oldCPU-upload headers below are historical.

> Latest 2026-10-08T11:29:08.762565+00:00: local module v1/v2 and data/control audits complete;155 state-only CPU steps, zero new VCSA pretrained calls. Exact34,831,836-byte HF/PEFT T4 smoke payload awaits direct specific upload approval after automatic review rejection. Old CPU-only upload/DLL blocks are obsolete. Read outputs/vcsa_development/Ready_Implementation_Checkpoint.md and latest_execution_status.json. Stage3 is partial74/80, six CPU records and original global costs unknown. Superiority unachieved.

> Execution update: T0 and bounded candidate labels completed/audited; source-only module-fixture approval pending; Stage3 incomplete74/80 after originalruntime loss. Read outputs/vcsa_development/latest_execution_status.json and T1_Labeling_Addendum.md. Older estimates/status/zero-historical-overlap text below are superseded. Training not started and no end-to-end completion ETA established.

# Complete execution and evidence plan for a genuine LLM contribution

**Method:** VCSA — Verifier-Conditioned State-Adaptive LoRA with a Physical Advantage Head  
**Decision:** use VCSA as the single core model intervention; keep DAgger/conservative-Q and adapter routing as gated extensions, not simultaneous knobs.  
**Status:** prospective; no VCSA weights or training labels have been created.  
**Current owner:** the existing Stage 3 matched study is still active on its original T4 assignment (37/80 records at the last audit). It must finish before any VCSA GPU work.

## What can and cannot be guaranteed

No literature or pre-training trick can justify a 90% claim that a new model will beat the exact D-SE controller before data are collected. A plan that promises that outcome would be outcome-chasing. We can be highly confident in the **integrity of the intervention** because it is modular, separately hashed, physically gated, and evaluated against an untouched baseline. Superiority remains an empirical hypothesis.

The practical confidence targets are therefore separated:

| Target | Confidence before VCSA training | Evidence required |
|---|---:|---|
| The modules can be integrated without changing the frozen baseline | high | import/shape/hash tests and a byte-level frozen-asset audit |
| The model can emit syntactically valid, in-scope bus/Q proposals | high | schema, masking, candidate-membership and serialization tests |
| The model can produce physically admissible novel proposals | unknown | training-split physical replay and a novel-action rate above zero |
| The model improves the literal D-SE endpoint at equal or lower full cost | unknown | matched confirmation experiment plus independent replay |

The plan is designed to find out quickly which of the last two statements is false. It does not manufacture a positive result.

## System facts that constrain the design

The current system uses a frozen Qwen 0.5B base with a recovered zonal LoRA adapter, structured JSON proposals, native candidate pools, an exact common-and-zone scope contract, and a physical power-flow verifier. The primary deterministic comparator is the unchanged D-SE portfolio: DFF + DFF-ALT + the original selector, including the full costs of both branches. The locked 62-case bank is sealed and cannot supply training labels.

The recovered grouped archive contains 109/13/15 physical scenarios and 16,000/2,000/2,000 records. Its audit found zero exact physical overlap with the locked bank and zero exact overlap with the recovered historical scenarios, but all 62 locked cases share an outage/DER pattern with the archive. The future claim is therefore same-network held-scenario development, not cross-grid or unseen-outage generalization.

The active Stage 3 owner is currently using the only active original-account T4. VCSA must not interrupt it, share its runtime, or reuse its files as training outcomes.

## Why VCSA is a justified model-level intervention

The reviewed work points to a specific failure in the current setup: a language adapter can emit plausible proposals, but it has no internal representation that says which physical state features matter, no direct action-scoring head, and no dense learning signal between a candidate and its replay outcome.

VCSA addresses these gaps:

1. **Structured physical state path.** Typed bus and topology tokens are fused into selected transformer layers using cross-attention. This follows graph–language fusion work but makes the state path specific and auditable.
2. **State-adaptive rank groups.** LoRA updates are partitioned into fixed rank groups and gated from the current state. AdaLoRA allocates rank statically from matrix importance; VCSA tests whether the useful update itself should depend on the operating state.
3. **Factorized action head.** A bus head and a conditional Q head match the actual parameterized action structure. This avoids asking the language head to learn a large flat JSON vocabulary.
4. **Physical process head.** The model predicts the replay-measured change in UV, normal-band margin, deficit, PF status, support, and full cost. These are dense labels for ranking and uncertainty, never a replacement for the exact verifier.
5. **Verifier-derived counterfactual loss.** Preferred/rejected pairs come from exact training-scenario replay, not human preference or model self-critique.
6. **Conservative abstention.** Unsupported or uncertain proposals fall back to unchanged D-SE. A fallback is counted as D-SE performance, never as LLM credit.

This combination is grounded in LoRA/AdaLoRA/DoRA, AdapterFusion and prefix tuning, Decision/Trajectory Transformer sequence modelling, GL-Fusion graph–language cross-attention, process supervision, DPO/ReST, conservative offline RL (CQL/IQL/PLAS), and safe power-system RL. The review found no directly matching power-system method that combines all six pieces; that is a candidate novelty statement requiring a final exact prior-art check.

## Model specification

### Inputs

For each decision state `s_t`, build a canonical and one semantically equivalent permuted serialization containing:

* active bus ID, zone ID, topology/outage flag, voltage magnitude/angle, generator/load/DER indicators;
* the current residual deficit and normal-band margin;
* the raw candidate bus/Q set and support statistics;
* the current decision index and remaining fixed budget;
* no hidden target metrics from validation, test, Stage 3, or the 62-case bank.

Numeric values are normalized using training-split statistics only. The exact tokenizer/context reserve used by the current system remains fixed unless a separate protocol declares a change.

### Trainable modules

* `StateEncoder`: typed bus/topology embedding plus a small message-passing layer over the saved network graph.
* `CrossAttentionInjectors`: two fixed transformer blocks, with a zero-initialized output gate so the initial function is close to the current adapter.
* `RankRouter`: `R` LoRA rank groups, with state-conditioned gates and a fixed maximum active rank.
* `ActionHead`: factorized `bus` and conditional `Q` logits masked by the exact candidate set.
* `ProgressHead`: six regression/classification outputs for replay-measured process quantities.
* `AbstentionHead`: calibrated support/uncertainty score; low support forces D-SE fallback.

The base model and current adapter are copied read-only. VCSA weights are stored under a new namespace and receive a new manifest, environment hash, and checkpoint hash.

### Loss

```text
L = L_language
  + λa L_factorized_action
  + λp L_pairwise_physical_preference
  + λr L_process_progress
  + λs L_support_conservative
  + λc L_serialization_consistency
```

`L_pairwise_physical_preference` uses a frozen lexicographic order: protected UV count, normal-upper violation, residual deficit, support, then full cost. `L_process_progress` uses the candidate-level replay outcomes. `L_support_conservative` penalizes confidence on unsupported/out-of-scope actions. `L_serialization_consistency` compares canonical and semantically equivalent state orderings while preserving bus IDs and candidate membership.

The coefficients, rank, active layers, optimizer, learning rate, epochs, negative-sampling rule, temperature, seeds, and stopping rule are written to the manifest before training. No confirmation result can alter them.

## Training-data construction

### Phase T0: input and split audit (CPU, read-only)

1. Verify `VAC_LoRA_Training_Manifest.json` against the recovered archive hashes.
2. Verify the 109/13/15 scenario split and 16,000/2,000/2,000 record counts.
3. Verify locked-bank and historical overlap remains zero.
4. Verify every record contains a parseable state, candidate scope, action field, and scenario ID.
5. Stop if any record maps to the locked 62 bank or if the split is ambiguous.

### Phase T1: physical counterfactual table (CPU, training scenarios only)

For each training state:

1. Reconstruct the exact native network state and raw candidate set.
2. Evaluate the recorded action and the unchanged DFF/DFF-ALT candidate actions with the original physical replay.
3. Add admissible hard negatives: PF failures, unsafe actions, unsupported bus/Q combinations, safe-but-worse actions, and higher-cost actions.
4. Record candidate-level physical progress, support, solver status, actual PF attempts, and full cost.
5. Form pairs only within the same state; never compare candidates across states.
6. Hash each table shard and then freeze a scientific pair manifest.

The table must preserve negative outcomes. Filtering to successful actions would train imitation, not improvement.

### Phase T2: action-head and process-head sanity checks (CPU)

Before any language-model training:

* bus/Q masking must make every emitted pair a member of the raw scope;
* support-negative examples must reduce confidence;
* process-head labels must reproduce stored replay metrics exactly;
* canonical/permuted serialization must preserve action probabilities within a predeclared tolerance;
* no model-generation function may import or call a solver;
* adapter enable/disable and restoration must pass the existing framework checks.

## Weight-training campaign

Only one authorized T4 allocation is used per training run. The active Stage 3 runtime must be released and its artifacts audited first.

### Fixed variants

1. **D-SE:** literal deterministic comparator.
2. **Base:** frozen base, no adapter.
3. **Current-LoRA:** existing frozen adapter.
4. **Static-SFT:** current architecture plus factorized action/process heads, no state-conditioned rank routing.
5. **State-Fusion:** state encoder and cross-attention, no physical preference loss.
6. **VCSA-Process:** state fusion plus process head and physical preference loss, static rank.
7. **VCSA-Full:** state fusion, adaptive rank groups, action/process heads, support penalty, and abstention.
8. **VCSA-Full+DAgger:** only if VCSA-Full produces admissible novel actions; training-only D-SE labels are collected on VCSA-induced training states.

No prompt, Q order, candidate budget, normal threshold, or random-seed sweep is allowed. These are architecture ablations, not outcome selection.

### Training gates

* Gate W1: checkpoint loads with exact base and tokenizer hashes.
* Gate W2: adapter-enabled and adapter-disabled hidden states differ only in the new namespace.
* Gate W3: training loss decreases without validation physical support collapse.
* Gate W4: no validation/test or Stage 3 identifiers appear in training logs or pair manifests.
* Gate W5: process-head calibration is measured on validation only.

If any gate fails, preserve the checkpoint and stop; do not fix it with an unregistered training change.

## Development evaluation before any superiority claim

Use validation/test development scenarios first. Every action is replayed independently.

Report:

* valid proposal rate;
* admissible novel-action rate relative to D-SE and current LoRA;
* action-selection agreement with D-SE;
* protected joint endpoint;
* residual deficit and normal-band margin;
* PF exceptions and failed-action denominators;
* support/abstention calibration;
* generation, repair, token, model-load, solver, wall-time, and full-cost ledgers;
* independent replay identity and source-network hashes.

**Novel-action gate:** if VCSA changes zero selected actions, or every changed action is rejected, do not run DAgger or a larger campaign. The model is not contributing yet.

## Confirmation experiment

Only after the novel-action gate passes:

1. Freeze an unused confirmation source and exact case manifest.
2. Lock all weights, preprocessing, candidate scope, budgets, and thresholds.
3. Run D-SE, base, current-LoRA, Static-SFT, VCSA-Process, and VCSA-Full on identical worlds.
4. Preserve partials and failures; do not rerun inference because a transfer fails.
5. Run a separate evaluator with no model/PF calls to verify identities, costs, masks, and replay agreements.
6. Repeat the evaluation from the same manifest with an independent process or reviewer.

The LLM earns credit only if a changed action improves the protected endpoint or a predeclared equal-cost secondary trade-off, with no safety regression and no higher full cost. Fallback rows are D-SE rows, not LLM wins.

## Statistical and decision rules

The locked 62 bank and current historical development cases cannot be used as confirmation. For the unused confirmation set:

* report paired per-case deltas and exact confidence intervals only when the number and independence of cases justify them;
* use the protected joint endpoint as the primary outcome;
* use residual deficit, support, cost, and latency as secondary outcomes;
* require an independent replay audit and a second evaluator;
* do not claim superiority from a single family or two operating points;
* retain adverse and neutral outcomes in the final package.

If the primary endpoint is tied, the model is not superior. If the endpoint improves but total cost increases, report the trade-off rather than calling it a win. If VCSA is safer but not better, report it as a safety/abstention contribution, not deterministic superiority.

## Risk register and mitigations

| Risk | Detection | Mitigation |
|---|---|---|
| No novel candidates | novel-action rate | Stop; do not tune prompts or budgets |
| Model imitates D-SE | action agreement near 1 | Treat as imitation baseline; test a new hypothesis only after evidence |
| Physically unsafe proposals | exact verifier | hard mask, abstention, D-SE fallback |
| Unsupported actions | support head/calibration | conservative penalty and rejection |
| State serialization shortcut | canonical/permuted test | state-encoder consistency loss |
| Data leakage | scenario/hash audit | freeze pair manifest and independent audit |
| DAgger feedback contamination | train-only IDs | keep it behind novel-action gate |
| Cost inflation | full ledger | equal-cost primary rule |
| Catastrophic language forgetting | language-retention loss and held-out language smoke tests | stop checkpoint if regression exceeds predeclared tolerance |
| GPU/runtime failure | owner and artifact manifests | preserve partials; never rerun inference silently |

## Evidence that this has a credible chance

The plan does not rely on one paper. It uses mutually reinforcing evidence:

* low-rank and modular adapters can change task behavior without rewriting a base model;
* graph/state fusion improves access to structured state information;
* structured/parameterized action heads reduce the difficulty of combinatorial actions;
* process supervision gives denser learning signals than terminal labels;
* conservative offline RL reduces unsupported-action overestimation;
* safe-control work shows that learned policies need an explicit safety boundary;
* the local system already provides an exact verifier, native candidate scope, replay audit, and provenance-preserving training split.

This makes VCSA technically plausible and auditable. It does not prove that the available training distribution contains a better action than D-SE. That is the decisive empirical uncertainty, so the novel-action gate is the first experiment after training.

## Execution checklist

1. Preserve the active Stage 3 owner until it finishes its 80-record matrix.
2. Run T0 audit and create the pair-manifest checker on CPU.
3. Run T1 training-scenario physical labeling and freeze hashes.
4. Implement VCSA under a new module namespace with no edits to frozen files.
5. Pass T2 module and no-solver tests.
6. Train Static-SFT and VCSA-Full on separate owned T4 runs.
7. Pass W1–W5 checkpoint and validation gates.
8. Run development replay and require the novel-action gate.
9. If the gate passes, freeze and run the unused confirmation campaign.
10. Run independent identity/physics/cost audit and report the result honestly.

The plan is strong enough to justify the experiment and to establish a genuine model contribution if the data support it. It is not scientifically possible to promise a 90% probability of beating D-SE before the novel-action and confirmation evidence exists.
