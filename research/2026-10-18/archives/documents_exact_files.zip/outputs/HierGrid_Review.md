# HierGrid package review

Reviewed 6 October 2026.

The supplied archives are intact research handovers, but they do not contain the frozen experiment assets needed to reproduce the reported results. The review found reproducible helper-code defects, protocol inconsistencies, and discrepancies between manuscript figures, tables, and prose. Original archives and research sources were preserved.

## What was reviewed

- Both ZIP archives, both separately supplied Markdown files, all unique handover and audit text, the three reference Python files, both paper text exports, and both plan text exports.
- Both PDFs: all 39 physical pages parsed and rendered successfully; every page was visually screened, with enlarged inspection of discrepant figures and tables.
- Both Word files: ZIP integrity and document XML checked, including all 11 tables. Their supplied text exports contain all words extracted from the document bodies. Word page layout was not verified because the bundled runtime has no LibreOffice executable.
- All 17 entries in the package manifest matched their recorded byte sizes and SHA-256 hashes. All 18 research-package files, including the manifest, are byte-identical between the two archives. The two standalone Markdown files also exactly match their archived counterparts.
- Isolated helper-function checks were run after reading the code. No scenario generation, controller campaign, real power-flow solve, model inference, or Colab session was executed.

The Desktop ZIP path supplied in chat did not exist. A single matching `HierGrid_Local_Transfer.zip` was found in Downloads and used. The local-transfer archive contains 26 files; the v2 archive contains 18 files. The local package adds eight transfer/audit records to the same research inputs.

This review runs on the user's Windows machine with bundled Python 3.12.14. The supplied Linux cloud environment reports describe a different, earlier workspace. Pandapower is absent from the inspected local Python runtime; current Google authentication and GPU availability were not tested. Embedded prompts were treated as research context, not authorization to implement or execute the research campaign.

## Findings requiring attention

### 1. Frozen execution assets are absent

Neither archive contains the latest `reflection.ipynb`, the exact `phase2g_ITER25_resume_pack_*`, adapter weights and tokenizer/base-model identity, frozen federation network/metadata, mature runner implementations, the locked 62-case bank and its lock/manifest/scenario files, or pilot/full-run logs. The PowerGridQA JSONL corpus is also absent.

The archived cloud manifest describes 180 repository files plus 18 handover files. Those 180 repository entries are inventory records, not the corresponding files. Its historical validation claims therefore cannot be independently reproduced from this transfer.

Consequences: the 62-case count, pilot results, exact controller ranking/selector, physical resource semantics, and historical performance remain unverified here. A replacement bank or reconstructed mature runner would not establish reproduction of the frozen experiment.

### 2. DFF-ALT and D-SE are specified but not implemented

`revision_config.py`, lines 114–122, defines method labels only. The package contains no runnable implementation of the second-ranked first-action rule or the common D-SE/HG-SE selector. This agrees with the handover's stated missing-work status.

Before implementation, obtain the actual mature DFF enumeration, deduplication, progress gates, tie ordering, and terminal selector. The manuscript's generic description of tie resolution is insufficient to reconstruct these exactly.

### 3. The older notebook export is unsuitable for a blind Run All

In `reflection_older_export.py`:

- Lines 10–18 install and upgrade unpinned packages and purge the package cache.
- Lines 26–49 locate a pack and load a model before the later restoration cells, temporarily using the pack root as the adapter directory.
- Lines 73–80, 141–145, and 176–180 remove and replace extraction/model/scenario directories.
- Lines 224–280 and 300–476 mutate restored scripts through string, regex, and AST-based replacement.
- Lines 565–575 execute several external historical/adaptive experiment scripts that are absent from this package.

The generator and configuration parse as ordinary Python. The notebook export does not, because it contains IPython `!` commands; that is an export-format limitation rather than proof of a malformed notebook. No wholesale execution was attempted.

### 4. The old normalizer permits Q values outside the declared list

The normalizer embedded at lines 371–471 rounds to multiples of 25 and clips to 25–300. Isolated checks confirmed that 175, 225, and 275 pass through, while `revision_config.py:85` excludes those values.

This establishes a source/config mismatch. It does not establish that the final frozen runner used this normalizer or that downstream gates accepted these values in historical experiments. Resolve actual behavior from the frozen source and logs before changing any method.

### 5. Numeric bus zero is discarded

At `reflection_older_export.py:422`, the alias lookup uses an `or` chain. The isolated normalizer rejects `{"bus": 0, "q_mvar": 100}` but accepts the same action with bus `"0"` as a string. Zero-based indexing is explicitly used by the supplied scenario generator.

A later corrected implementation should distinguish missing keys from valid falsy values. Whether bus 0 is an eligible control target in the frozen system still requires its metadata.

### 6. An iterator bypasses the missing-input check

`revision_config.py:140–149` accepts an `Iterable[str]`, consumes it in `set(names)`, then iterates it again. With `iter(["network"])`, the check returned successfully even though the configured network path was missing. A list containing the same key correctly raised `FileNotFoundError`.

Materialize the iterable once before both checks in a separately versioned correction.

### 7. Custom load factors can overwrite scenario identities

`generate_unseen_federation_scenarios.py:69–70` formats factors to two decimal places for filenames. Inputs 1.301 and 1.304 both produce `1p30`; the duplicate check at lines 312–317 compares the original floats. The later writes at lines 344–369 can therefore use the same filename for distinct inputs while retaining separate manifest rows.

The default factors 1.30 and 1.40 do not collide. For custom factors, validate uniqueness of generated IDs or use a lossless canonical representation before writing any files.

### 8. Convergence alone permits non-finite bus results

`generate_unseen_federation_scenarios.py:216–250` trusts `net.converged` and computes metrics without requiring finite voltages on every required energized bus. A mocked converged result with voltages `[1.0, NaN]` returned `converged: true`, zero UV/OV counts, and a NaN deficit. Pandas min/mean/max skipped the NaN; the scenario-inclusion rule only checks the convergence flag.

This was a reporting-helper test with a mocked solver, not a real pandapower case. Audit energized-bus coverage and finiteness when validating the actual locked bank. Do not silently alter an existing bank after seeing controller outcomes.

## Research protocol consistency

The overall sequence is coherent: establish frozen provenance, validate DFF-ALT on development cases, compare HG-SE with D-SE on the locked bank, complete centralized/zonal and optimization controls, then evaluate the security extension. Several decisions still need one authoritative prospective protocol:

1. **Primary uncertainty analysis conflicts.** The reviewer plan, text line 68, makes outage-family cluster bootstrap primary and ordinary paired bootstrap a sensitivity analysis. `START_HERE.md`, section 8, describes paired bootstrap with clustered sensitivity. Choose and document the primary method before final outcomes.
2. **Security scope contains an obsolete exclusion.** The computing plan, text line 49, excludes PowerGridQA poisoning from the one-cycle plan, but lines 50–64 and Table 6 add retrieval poisoning as core work. Retire or explicitly delimit the earlier passage.
3. **Pilot handling is conditional.** The 13 observed cases cannot automatically be called untouched. The plans correctly require a record of whether they informed tuning; that record is absent.
4. **Full restoration means zero UV in the existing manuscript.** It is not equivalent to every operational constraint being satisfied. Preserve the frozen endpoint and separately report nominal OV, hard OV, loading, convergence, and support.
5. **Matched action budgets do not prove matched computation.** Charge both simulated branches to each portfolio and record actual PF solves, inference calls/tokens, and runtime. The selected trajectory's support must remain distinct from discarded-branch planning cost.

The missing deterministic-diversity comparison is the main attribution gap. HG-SE's selection rule includes DFF, so non-regression under that ordering cannot by itself establish LLM-specific value. The manuscript already acknowledges this limitation.

## HierGrid manuscript

The headline arithmetic is internally consistent: 290 to 193 residual UV is a reduction of 97, or 33.45%; support rises from 89,050 to 102,250 MVAr, or 14.82%; accepted actions rise from 617 to 911, or 47.65%. Candidate-test counts sum to 174,969. These are arithmetic checks on reported totals, not revalidation of raw experiments.

- **Figure 2 does not depict its caption.** Physical PDF page 19 shows one zonal proposal/verification/action loop. Its caption says it shows DFF and HG-VF branches followed by terminal safety-envelope selection. Add the two independent trajectories and terminal selector, or relabel the current figure as the branch-level pipeline.
- **Page totals are wrong.** The PDF has 22 physical pages, including highlights. Appended figure pages display “Page 18 of 17” through “Page 21 of 17.” Rebuild the final pagination.
- **The exact terminal ordering is not fully specified.** Section 2.2 gives residual UV priority and refers to implemented tie ordering without enumerating it. Include the complete ordering, tolerances, and failed/missing-branch handling when the frozen code is recovered.
- **Operational settings need fuller reporting.** The reference configuration distinguishes 1.05 nominal OV from a 1.06 hard threshold and supplies the exact Q set/per-bus bound. The manuscript does not fully expose these details. Reconcile them with actual frozen behavior before revision.
- **Authorship/editorial fields remain unfinished.** The CRediT statement on physical page 17 lists two coauthors as `NIL`; contributions require factual author confirmation. The opening affiliation includes `Univeristy`, and reference [6] duplicates its journal/volume information.
- **Reference [5] needs a consistent source identity.** The manuscript uses a different title and incomplete author listing from the current primary record for [Grid-Agent](https://arxiv.org/abs/2508.05702). Use the intended version's verified metadata.

The reported 108 versus 110 full restorations and paired p=0.50 are already described cautiously. The shared training/replay scenario population and absent matched centralized/OPF controls are disclosed; the new revision experiments are still needed to strengthen these claims.

## Published PowerGridQA paper

These findings concern consistency and future reuse. The published PDF was preserved.

| Location | Confirmed discrepancy |
|---|---|
| Physical page 8, printed 8398, Figure 7 versus Table 4 | Theory “Other” is 66.1% in the figure and 46.2% in the table; theory causal is 15.0% versus 23.72%; theory definition/factual is 14.6% versus 23.52%. Several other categories also differ. |
| Physical page 12 prose versus page 15 Table 8 | Theory BERTScore is 82.74% in the prose and 83.99% in the table. |
| Page 3 dataset composition versus page 8 clustering description | The theory subset is described as 23,368 questions, but the clustering description uses 27,080 questions. No version/filter reconciliation is supplied. |
| Page 9 prose versus Table 5 and Figures 10–11 | The explanatory paragraphs interchange the protection/fault and load/control descriptions for clusters 3 and 4. |
| Figure 6 versus page 8 method text | The workflow names Louvain, while the text names NetworkX greedy modularity. Confirm which algorithm generated the published results. |

Page 6 also repeats the co-occurrence-method paragraph and parts of the dataset-composition explanation. Several figure/table cross-references are stale; for example, the experiment narrative points to Table 5 for baseline metrics while the metrics appear in Table 8.

The retrieval experiment describes indexing QA text and querying the original questions. It does not clearly establish exclusion of the query's own QA record. Consequently, the source-retrieval recall results should not be reused as proof of held-out answer generalization. The new thesis evaluation needs explicit query/index separation, source/version hashes, and denominators. The missing corpus and evaluation scripts prevent determining which conflicting counts or scores are correct.

## Prior cloud records and external references

The cloud audit contains useful historical context but merges different access states: one record reports a successful session listing, later records report HTTP 401, and earlier environment fields still say the CLI or credentials were absent. These should be timestamped events rather than a single current-state claim. Current local Colab authentication remains untested.

A targeted primary-source check confirmed the identities of [Grid-Agent](https://arxiv.org/abs/2508.05702), [Progent](https://arxiv.org/abs/2504.11703), [TwinGridShield](https://arxiv.org/abs/2608.15391), and [ProOPF](https://proceedings.mlr.press/v306/shen26h.html). This was a bibliography spot-check, not a full literature review or validation of every citation. TwinGridShield's abstract explicitly distinguishes surrogate proposal trials from real LLM prompt-injection measurements; that distinction in the handover is appropriate.

## Next inputs and recommended order

1. Recover the latest notebook and exact frozen resume pack, including model, network, runners, and original dependency records.
2. Recover the existing locked bank, manifest, scenario JSONs, pilot/full logs, and physical training/split provenance.
3. Reconcile source/config differences and replay a historical trajectory before implementing the comparator.
4. Freeze the selector, DFF-ALT rule, primary statistics, pilot treatment, central proposal protocol, and optimization-resource mapping.
5. Run the matched experiments and revise claims from their evidence. Preserve the published dataset and document any verified corrections separately.

Supporting outputs: `review_validation.json` records the isolated reproductions and manifest checks; `source_hash_manifest.json` inventories extracted copies. The `HierGrid_Local_Transfer` and `HierGrid_Codex_Handover_v2` folders contain the extracted packages. No research result has been manufactured or inferred from a successful file/hash check.
