"""Independent rational branch-flow separation checker, zero solver calls."""
import os,time,json,pickle
from fractions import Fraction as Q
from datetime import datetime,timezone
from unentered_public13_radial_outer_v2_20261022 import R,P,PRIMARY,READER,read,put,sha,source

def independent_check(root,result):
    edge,loads,reactive,base,controlled=source(root)
    n=52;upper=Q.from_float(1.05)**2;lower=Q.from_float(.95)**2
    import numpy as np
    qlimit=100*Q.from_float(float(np.float32(.3)))/(1-100*Q(1,2**53))
    boxes=[(-2*upper/max(t[2],t[3]),2*upper/max(t[2],t[3])) for t in edge]*2
    boxes += [(Q(0),4*upper/(t[2]**2+t[3]**2)) for t in edge]+[(lower,upper)]*13+[(-qlimit,qlimit)]*3
    equations=[];rhs=[]
    for k,(parent,node,resistance,reactance) in enumerate(edge):
        prow={};qrow={}
        for j,(a,b,_,_) in enumerate(edge):
            if b==node:prow[j]=Q(1);qrow[12+j]=Q(1)
            if a==node:prow[j]=Q(-1);qrow[12+j]=Q(-1)
        prow[24+k]=-resistance;qrow[24+k]=-reactance
        for i,bus in enumerate(controlled):
            if bus==node:qrow[49+i]=1/base
        equations.extend([prow,qrow,{36+node:Q(1),36+parent:Q(-1),k:2*resistance,12+k:2*reactance,24+k:-(resistance**2+reactance**2)}]);rhs.extend([loads[node],reactive[node],Q(0)])
    equations.append({36:Q(1)});rhs.append(Q(1))
    grid=list(map(Q,[-2,-1]))+[Q(-1,2),Q(-1,4),Q(0),Q(1,4),Q(1,2),Q(1),Q(2)]
    cuts=[];limits=[]
    for k in range(12):
        for a in grid:
            for b in grid:cuts.append({k:2*a,12+k:2*b,24+k:-upper});limits.append(a*a+b*b)
    if not result.get('solver_success'):return dict(status='UNKNOWN_NO_RETURNED_CERTIFICATE')
    y=list(map(Q,result['dual_equalities']));z=list(map(Q,result['dual_inequalities']))
    assert len(y)==37 and len(z)==972
    if any(t>0 for t in z):return dict(status='UNKNOWN_INVALID_INEQUALITY_DUAL_SIGN')
    # No reliance on the optimizer's success flag, objective or tolerances:
    # a positive exact separating gap alone rules out every point in the box.
    weights=[]
    for col in range(n):weights.append(sum((row.get(col,Q(0))*a for row,a in zip(equations,y)),Q(0))+sum((row.get(col,Q(0))*a for row,a in zip(cuts,z)),Q(0)))
    support=sum((max(lo*a,hi*a) for (lo,hi),a in zip(boxes,weights)),Q(0))
    right=sum((a*b for a,b in zip(rhs,y)),Q(0))+sum((a*b for a,b in zip(limits,z)),Q(0))
    margin=Q(1,10**7)*(sum(map(abs,y),Q(0))+sum(map(abs,z),Q(0)))
    gap=right-support-margin
    assert gap==Q(result['proof']['exact_gap'])
    return dict(status='CERTIFIED_NO_FULL13BAND_ENDPOINT_IN_SOURCE100STEP_ACTUATOR_OUTER_SET' if gap>0 else 'UNKNOWN_OUTER_RELAXATION_DOES_NOT_EXCLUDE_FEASIBILITY',exact_gap=str(gap),gap_float=float(gap),certified=gap>0)

def main():
    READER.mkdir(exist_ok=False);began=time.monotonic()
    put(READER/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__),at_utc=datetime.now(timezone.utc).isoformat()))
    while not (READER/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    p=read(P/'Protocol.json')
    for rel,h in p['hashes'].items():assert sha(R/rel)==h
    end=read(R/'outputs/public13_radial_outer_unentered_v2_coordination_20261022/End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
    lock=read(P/'Reader_Lock.json');assert lock['reader_sha256']==sha(__file__) and lock['protocol_sha256']==sha(P/'Protocol.json')
    for row in read(PRIMARY/'Closed_Manifest.json')['files']:assert sha(PRIMARY/row['path'])==row['sha256']
    rows=[]
    for root in p['all4_adverse_roots']:
        assert time.monotonic()-began<120
        old=read(PRIMARY/f"seed{root['seed']}_Result.json");answer=independent_check(root,old);rows.append(dict(seed=root['seed'],**answer))
        assert bool(answer.get('certified'))==bool(old.get('proof',{}).get('certified',False))
    put(READER/'Independent_Audit.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),status='PASS_INDEPENDENT_EXACT_RATIONAL_NECESSARY_CONDITION_CERTIFICATE_RECONSTRUCTION',rows=rows,certified_cases=sum(v.get('certified',False) for v in rows),unknown_cases=sum(not v.get('certified',False) for v in rows),new_LP_PF_model_derivative_training_calls=0,
        primary_costs=read(PRIMARY/'Result.json')['costs'],scope='All four adverse roots are retained in the original full500 benchmark. A certificate rules out only source-fixed dispatch/three-actuator/100-step reachable Q/full13band conditions, even ignoring normal-bus trajectory guards and thermal constraints. No certificate means UNKNOWN, not feasible/infeasible/model failure. Not a universal grid or LLM result.',workflow_seconds=time.monotonic()-began))
    put(READER/'Closed_Manifest.json',dict(files=[dict(path=f.name,bytes=f.stat().st_size,sha256=sha(f)) for f in READER.iterdir() if f.is_file()]));print('EXACT_OUTER_CERTIFICATE_READER_CLOSED')

if __name__=='__main__':main()
