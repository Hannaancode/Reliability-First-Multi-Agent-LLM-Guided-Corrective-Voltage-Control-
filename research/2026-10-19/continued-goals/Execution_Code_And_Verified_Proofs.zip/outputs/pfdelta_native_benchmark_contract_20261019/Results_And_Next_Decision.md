All36 fixed published PFDelta118 inputs pass native saved power-flow equation checks at5e-6, with independent complex-versus-polar agreement. None satisfy every checked operating limit. Source UV counts range0to28; these36 are development inputs, not all severe federation cases.

34/36 source slack references exceed the original1.05+1e-8 global safety ceiling. Keeping those references fixed makes that exact controller-acceptance role impossible irrespective of shunt action. This scoped bound does not establish physical infeasibility or authorize changing source voltages, guards or selecting only the remaining rows. All36 are retained.

A native PF predictor benchmark and our discrete corrective-control benchmark are different tasks. Before any model/solver calls, bind a faithful importer and explicit common causal input/action/protection task for all models. Preserve published licenses, source revisions, failed first schema reader and the successful additive schema repair.
