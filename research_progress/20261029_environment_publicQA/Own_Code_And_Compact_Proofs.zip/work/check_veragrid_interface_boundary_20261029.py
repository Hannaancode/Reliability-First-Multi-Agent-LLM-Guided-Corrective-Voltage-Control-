"""Synthetic source-contract checks, with zero real questions, model or OPF calls."""
from pathlib import Path
from dataclasses import asdict
from copy import deepcopy
from datetime import datetime,timezone
import ast,hashlib,json,re
from veragrid_label_hidden_interface_20261029 import make_view,make_all_views,strict_letter
R=Path(__file__).resolve().parents[1];O=R/'outputs/veragrid_source_admission_20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    out=O/'Synthetic_Boundary_And_Parser_Check.json';assert not out.exists()
    source=O/'source/evaluator.py';record=json.loads((O/'Intake_Record.json').read_text('utf-8'))
    assert sha(source)==next(x['sha256'] for x in record['files'] if x['path']=='evaluator.py')
    tree=ast.parse(source.read_text('utf-8'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='extract_letter')
    module=ast.Module(body=[node],type_ignores=[]);ast.fix_missing_locations(module);scope={'re':re}
    exec(compile(module,'pinned_author_extract_letter_only','exec'),scope)
    parse=scope['extract_letter'];checks=[]
    def ck(name,ok):assert ok,name;checks.append(name)
    base={'id':1,'question':'Synthetic question, not an actual benchmark item.','options':dict(zip('ABCD',['first','second','third','fourth'])),'correct_answer':'SECRET_LABEL_A','solution':'SECRET_SOLUTION','difficulty':'SECRET_DIFFICULTY','source':'SECRET_SOURCE'}
    view=make_view(base);txt=json.dumps(asdict(view))+'\n'+view.user_prompt()
    ck('answer_solution_category_metadata_absent',all(x not in txt for x in ['SECRET_','correct_answer','solution','difficulty','source']))
    poisoned=deepcopy(base);poisoned.update(correct_answer='SECRET_LABEL_D',solution='DIFFERENT_SOLUTION',difficulty='easy',source='different')
    ck('changing_hidden_labels_does_not_change_view',view==make_view(poisoned))
    base['options']['A']='changed';ck('input_mutation_cannot_change_existing_view',view.options[0][1]=='first')
    def rejects(fn):
        try:fn()
        except ValueError:return True
        return False
    ck('partial_denominator_rejected',rejects(lambda:make_all_views([poisoned],150)))
    ck('duplicate_ids_rejected',rejects(lambda:make_all_views([poisoned,poisoned],2)))
    bad=deepcopy(poisoned);bad['options'].pop('D');ck('missing_option_not_silently_dropped',rejects(lambda:make_view(bad)))
    bad=deepcopy(poisoned);bad['question']='';ck('empty_question_not_silently_dropped',rejects(lambda:make_view(bad)))
    ck('strict_format_accepts_letter_only',strict_letter(' B\n')=='B' and strict_letter('I cannot answer')=='?')
    samples=[]
    for s in ['A',' B\n','The correct answer is B.','I cannot answer','No computation was performed.','', 'refusal']:
        samples.append({'synthetic_response':s,'author_parser':parse(s),'strict_secondary':strict_letter(s)})
    ck('author_parser_can_assign_letter_from_refusal',parse('I cannot answer')=='C' and strict_letter('I cannot answer')=='?')
    ck('author_parser_exact_AST_only',ast.dump(module.body[0],include_attributes=False)==ast.dump(node,include_attributes=False))
    result={'status':'PASS_SYNTHETIC_BOUNDARY_AND_PINNED_PARSER_ONLY','at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'synthetic_parser_examples':samples,'author_source_sha256':sha(source),'interface_sha256':sha(R/'work/veragrid_label_hidden_interface_20261029.py'),'actual_question_records_read':0,'model_PF_OPF_training_calls':0,'limits':['Actual150record schema and label-hiding packaging not yet checked','No real model context/token/loader/latency check','Author parser remains primary for native replication; strict parser is a separately declared secondary format measure','A refusal mapping to a letter is source behaviour, not evidence that any published result is wrong','No benchmark success or GPU launch readiness']}
    out.write_text(json.dumps(result,indent=2)+'\n','utf-8');print(json.dumps({'status':result['status'],'checks':len(checks),'actual_questions_read':0,'new_science':0}))
if __name__=='__main__':main()
