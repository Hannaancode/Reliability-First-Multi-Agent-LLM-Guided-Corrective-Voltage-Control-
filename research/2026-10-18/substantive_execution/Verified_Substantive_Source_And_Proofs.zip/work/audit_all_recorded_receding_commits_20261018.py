"""Linear scoped audit of ALL actual recorded commitments, zero new physics.

Not a replacement for the failed full menu/policy/forecast/checkpoint reader.
Every recorded branch/commit is checked, including incomplete branches; the
all-four-world comparison always remains UNKNOWN for this partial study.
"""
import copy,hashlib,json,os,time
from pathlib import Path
import numpy as np,pandapower as pp
from full_receding_paid_campaign_20261015 import R,B as OLD,pin,read,put,sha
from audit_full_receding_paid_campaign_cached_state_v2_20261015 import check_query
from paid_receding_commit_and_history_v1 import initialize,fields,fingerprint,commit_paid,validate
from bounded_paid_lookahead_physics_20261014 import load_after
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from joint_reallocation_opportunity_core_v1 import load_endpoint,build_verifier,action
from shared_original_serving_action_domain_v1 import build_current_domain
from equal_operation_benchmark_v2 import decode_capsule
from frozen_physics_loader import load_stack
from candidate_process_evidence_utils import frozen_checks
import full_joint_suffix_benchmark_20261014 as prior
B=R/'outputs/all_recorded_receding_commits_audit_20261018'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def main():
    B.mkdir(exist_ok=False);begun=time.perf_counter()
    put(B/'Protocol.json',{'role':'SCOPED_LINEAR_ALL_RECORDED_COMMITMENT_AND_CLOSED_ENDPOINT_AUDIT_NOT_FULL_POLICY_READER',
        'source_scientific_study':str(OLD.relative_to(R)),'fixed_bound_seconds':600,
        'source_sha256':sha(Path(__file__)),
        'selection':'ALL branch initializations, ALL actual commits, ALL closed branch records in original sequential journal; no selected worlds or improvement filter.',
        'checks':'Full journal hash-chain/protocol/manifest SHA, all attempt/return/exception identity and arithmetic costs; descriptor-hashed source initial/paid/selected replay NETs, unchanged source actuator/verifier/score/scope/caps/stock/operation/continuous first-commit fields and terminal metrics.',
        'not_checked':'Full unchosen menus/ranking/forecast equations, every unselected PF capsule, full25 checkpoint state histories, missing26th full state, all-eight completion, fresh LLM/physical inference, attribution, deployment cost or unused confirmation.',
        'all_four_gate':'UNKNOWN regardless of descriptive closed endpoints; old complete-only/partial readers remain failed and preserved.',
        'new_model_PF_optimizer_derivative_forecast_factor_or_solve_calls':0,'no_old_owner_restart_or_budget_extension':True})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    def admit():assert time.perf_counter()-begun<600,'Fixed scoped analysis bound; retain partial output, no extension'
    forbidden=[]
    def no_science(*a,**k):forbidden.append(True);raise AssertionError('Audit cannot perform new scientific calls')
    for name in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,name,no_science)
    np.linalg.solve=no_science
    p=read(OLD/'Protocol.json');pin(p);p_hash=sha(OLD/'Protocol.json')
    result=read(OLD/'actual/Result.json');manifest=read(OLD/'actual/Closed_Manifest.json')
    assert result['scientific_status']=='TERMINAL_PARTIAL' and result['exit_code']==manifest['exit_code']
    _,runner,_=load_stack();metadata=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=metadata.get('zones',metadata)
    cache=read(R/'outputs/receding_warm_dependency_closure_20261015/Paid_Warm_Dependencies.json')['cache']
    protocol_inputs={e['world']:e for e in p['endpoints']}
    state=None;initials=[];commits=[];closed=[];pending={};intents={};returns={};exceptions={};previous='0'*64;file_digest=hashlib.sha256();query_pf=0;replay_pf=0
    solver_seconds=0.;bytes_read=0
    with (OLD/'actual/scientific.jsonl').open('rb') as stream,(OLD/'actual/capsules.bin').open('rb') as pack:
        while line:=stream.readline():
            admit();bytes_read+=len(line);file_digest.update(line);event=json.loads(line)
            assert event['previous_sha256']==previous and event['protocol_sha256']==p_hash
            previous=digest(line.rstrip(b'\n'));d=event['data'];name=event['event']
            if name=='PF_intent':
                pid=d['identity'];assert pid not in intents and d['kwargs']==p['solver_kwargs'];intents[pid]=d
                if d['context']['phase']=='NEW_PRIMARY_QUERY':query_pf+=1
                elif d['context']['phase']=='CONTINUOUS_SELECTED_COMMIT_REPLAY':replay_pf+=1
                else:raise AssertionError('Unexpected scientific phase')
            elif name in ('PF_return','PF_exception'):
                pid=d['PF_id'];assert pid in intents and pid not in returns and pid not in exceptions
                target=returns if name=='PF_return' else exceptions
                target[pid]={'data_sha256':digest(canon(d)),'seconds':d['seconds']};solver_seconds+=d['seconds']
            elif name=='receding_branch_initialized':
                assert not pending
                net=decode_capsule(pack,d['initial_net'])['net'];original,cursor,_=load_endpoint(protocol_inputs[d['world']])
                assert prior.signature(net)==prior.signature(original) and fields(net)==fields(original)
                domain=build_current_domain(original,cursor,runner=runner,zones=zones)
                cursor=initialize(original,domain['expanded_cursor_for_separately_fixed_future_protocol'])
                assert cursor==d['initial_cursor'] and point_key(net,cursor)==d['initial_point']
                assert runner.rescue.grid_metrics(net)==d['initial_metrics']
                state={'world':d['world'],'method':d['method'],'net':net,'cursor':cursor,'commits':[],'initial_metrics':d['initial_metrics']}
                initials.append({'world':d['world'],'method':d['method'],'initial_metrics':d['initial_metrics']})
            elif name=='every_query_receipt_closed_before_more_science':
                assert state and d['world']==state['world'] and d['method']==state['method']
                # Keep only the current decision. No quadratic full-history read.
                key=(d['parent'],d['aid']);assert key not in pending;pending[key]=d
            elif name=='actual_receding_first_commit':
                assert state and d['world']==state['world'] and d['method']==state['method']
                rec=d['record'];before=state['net'];cursor=state['cursor'];row=rec['candidate']
                root=f"{d['world']}|{d['method']}|{d['decision']}|ROOT"
                msg=pending[(root,rec['first_action_id'])];assert msg['row']==row and msg['successor']==rec['paid_successor_id']
                paid=msg['record'];assert paid['receipt_id']==rec['paid_receipt_id'] and paid['verdict']['accepted']
                if paid.get('actual_measured_receipt'):
                    m=paid['actual_measured_receipt'];assert digest(canon(m))==returns[m['PF_id']]['data_sha256']
                    selected_returns={m['PF_id']:m}
                else:selected_returns={}
                domain=build_current_domain(before,cursor,runner=runner,zones=zones)
                assert row in domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
                node={'net':before,'cursor':cursor}
                # This preserved independent function uses saved solver results;
                # its temporary backend cannot call actual native power flow.
                check_query(node,row,msg,cache=cache,intents=intents,returns=selected_returns,exceptions={},pack=pack,p=p,runner=runner)
                target=load_after(paid['after_reference'],pack)['net'];assert bool(target.converged)
                replay=rec['replay_receipt'];pid=replay['PF_id'];assert digest(canon(replay))==returns[pid]['data_sha256']
                intent=intents[pid];assert intent['context']['phase']=='CONTINUOUS_SELECTED_COMMIT_REPLAY' and intent['context']['candidate']==row
                assert intent['context']['world']==d['world'] and intent['context']['method']==d['method'] and intent['context']['decision']==d['decision']
                _,actuate,_=build_verifier(runner.rescue,cursor)
                expected=actuate(copy.deepcopy(before),action(row))
                replay_before=decode_capsule(pack,intent['before'])['net'];replay_after=decode_capsule(pack,replay['after'])['net']
                assert prior.signature(expected)==prior.signature(replay_before)==prior.signature(target)==prior.signature(replay_after)
                assert fields(replay_after)==replay['fields']
                f=fields(target);actual=fields(replay_after);delta=max(abs(f[b][k]-actual[b][k]) for b in f for k in f[b]);assert delta<=1e-10 and delta==rec['replay_field_delta']
                before_metrics=runner.rescue.grid_metrics(before);after_metrics=runner.rescue.grid_metrics(target)
                assert after_metrics['vmax']<=1.05+1e-8 and after_metrics['uv_count']<=before_metrics['uv_count']
                assert after_metrics['deficit_sum']<=before_metrics['deficit_sum']+1e-9
                assert after_metrics['uv_count']<before_metrics['uv_count'] or after_metrics['deficit_sum']<before_metrics['deficit_sum']-1e-9 or after_metrics['vmin']>before_metrics['vmin']+1e-9
                next_scope=build_current_domain(target,cursor,runner=runner,zones=zones)['shared_raw_receivers_for_BOTH_controls']
                following=commit_paid(before,target,cursor,row,{'receipt_id':paid['receipt_id'],'accepted':True,'converged':True,'fields':f,'before_fingerprint':fingerprint(before,cursor)},commit_id=rec['commit_id'],actuate=actuate,next_scope=next_scope)
                assert following==rec['following_cursor'];validate(target,following)
                debit=1 if row['kind']=='ordinary' else 2
                assert rec['device_operations_debited']==debit and following['remaining_original_device_operation_slots']==cursor['remaining_original_device_operation_slots']-debit
                bus=str(row['receiver']);assert following['positive_addition_lifetime_MVAr'][bus]==cursor['positive_addition_lifetime_MVAr'].get(bus,0)+row['q']<=450
                checked={'world':d['world'],'method':d['method'],'decision':d['decision'],'commit_id':rec['commit_id'],'before':before_metrics,'after':after_metrics,'debit':debit,'replay_PF_id':pid,'all118_replay_field_delta':delta,'remaining_original_operations':following['remaining_original_device_operation_slots']}
                commits.append(checked);state['commits'].append(rec);state['net']=target;state['cursor']=following;pending.clear()
            elif name=='receding_controller_closed':
                assert state and d['mode']==state['method'] and d['commits']==state['commits']
                assert d['initial_metrics']==state['initial_metrics'] and d['final_metrics']==runner.rescue.grid_metrics(state['net'])
                assert d['remaining_original_operations']==state['cursor']['remaining_original_device_operation_slots']
                assert d['stop_reason']=='full_UV_restoration' and d['final_metrics']['uv_count']==0
                closed.append({'world':state['world'],'method':state['method'],'initial_metrics':d['initial_metrics'],'final_metrics':d['final_metrics'],'new_device_operations':d['new_device_operations'],'remaining_original_operations':d['remaining_original_operations'],'commits':len(d['commits']),'scope':'Recorded closed branch, not full all-four comparison or fresh LLM attribution'})
    assert file_digest.hexdigest()==manifest['members']['scientific.jsonl']['sha256'] and bytes_read==manifest['members']['scientific.jsonl']['bytes']
    cost=result['actual_new_costs'];assert len(intents)==len(returns)+len(exceptions)==cost['PF_attempts']
    assert len(returns)==cost['PF_returns'] and len(exceptions)==cost['PF_exceptions'] and abs(solver_seconds-cost['PF_seconds'])<1e-8
    assert query_pf==cost['new_query_PF_attempts'] and replay_pf==cost['continuous_replay_PF_attempts']==len(commits)
    assert cost['new_model_calls']==cost['new_optimizer_steps']==0 and not forbidden
    assert len(closed)==len(result['branches'])
    for a,b in zip(closed,result['branches']):assert a['world']==b['world'] and a['method']==b['mode'] and a['final_metrics']==b['final_metrics']
    put(B/'Frozen_Checks.json',frozen_checks())
    report={'status':'PASS_ALL_RECORDED_COMMITTED_TRANSITIONS_AND_CLOSED_ENDPOINTS_SCOPED_ONLY','journal_SHA256':file_digest.hexdigest(),
        'initialized_branches':initials,'all_recorded_commits_checked':len(commits),'all_recorded_closed_branches':closed,
        'actual_full_study_costs_retained':cost,'numerical_costs_source_reported_not_reaudited':result['numerical_costs'],
        'all_four_or_full_policy_gate':'UNKNOWN','fresh_LLM_contribution_or_fullDSE_superiority':'NOT_ESTABLISHED',
        'workflow_seconds':time.perf_counter()-begun,'new_scientific_calls':0,
        'limits':read(B/'Protocol.json')['not_checked']}
    put(B/'All_Checked_Commits.json',commits);put(B/'Independent_Scoped_Audit.json',report)
    put(B/'Closed_Manifest.json',{'members':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()},'new_science':0})
    print(json.dumps({'scoped_commit_audit':'PASS','commits':len(commits),'closed_branches':len(closed),'all4_gate':'UNKNOWN','new_science':0}))
if __name__=='__main__':main()
