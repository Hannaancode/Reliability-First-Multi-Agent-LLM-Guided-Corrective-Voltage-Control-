"""Bound CURRENT + previously paid menus, no old root/trial/fit repeated.

Trusted measurement-administrator data only. NOT a learner forward interface.
Legacy nested records are used only under their original independent hashes.
"""
import ast,copy,hashlib,json,math,os,time
from pathlib import Path
from datetime import datetime,timezone
import numpy as np,pandas as pd
from types import SimpleNamespace
from train_trajectory_measurement_nullable_v2 import safe,digest
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'outputs/critical_research_reset_20261010/native_cached_contexts_20261011'
OUT=Path('\\\\?\\'+str(RAW)) if os.name=='nt' else RAW
PRE=ROOT/'outputs/critical_research_reset_20261010/fixed_storage_recipe_binding_20261011'
SUPPORT=ROOT/'outputs/critical_research_reset_20261010/later_fork_process_support_20261011/preparation/Protocol.json'
PHYS=ROOT/'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3/protocol.json'
SOURCE=ROOT/'work/e/audit/phase2g_rescue_runner.py'
Q=[25.,50.,75.,100.,125.,150.,200.,250.,300.]
def read(p):return json.loads(p.read_text('utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):return json.dumps(safe(v),sort_keys=True,separators=(',',':'),allow_nan=False)
def write(p,v):
 with p.open('x',encoding='utf8') as f:json.dump(safe(v),f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def extract_pure_native_functions():
 nodes=[n for n in ast.parse(SOURCE.read_text('utf8')).body if isinstance(n,ast.FunctionDef) and n.name in ['grid_metrics','score_candidate']];assert len(nodes)==2
 env={'np':np,'V_MIN':.95,'V_MAX':1.05};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SOURCE),'exec'),env)
 return env['grid_metrics'],env['score_candidate']
def main():
 OUT.mkdir(exist_ok=False);(OUT/'nodes').mkdir();start=time.perf_counter()
 previous=read(PRE/'Source_Bound_Current_Records.json');support=read(SUPPORT);physics=read(PHYS);worlds={w['sha256']:w for w in physics['worlds']}
 protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'native_pure_function_source_sha256':sha(SOURCE),'source_dependency_sha256':{'work/train_trajectory_measurement_nullable_v2.py':sha(ROOT/'work/train_trajectory_measurement_nullable_v2.py')},'input_sha256':{'source_bound_current_rows':sha(PRE/'Source_Bound_Current_Records.json'),'source_binding_checkpoint':sha(PRE/'Verified_Current_Recipe_Checkpoint.json'),'latched_branch_protocol':sha(SUPPORT),'physical_protocol':sha(PHYS)},'all31_worlds_retained':[{'scenario_id':w['scenario_id'],'sha256':w['sha256']} for w in physics['worlds']],'held8_branch_files_NOT_READ':support['declared_held_world_sha256_NOT_READ'],'OPT_branches':support['latched_OPT_branches'],'resource_seconds':180,'question':'Can every current descriptor be anchored to exact native source vectors, complete old paid candidate menus and real prefix without repeating physics?','gate':'Exact native current metric and old menu identity/order/score/before/scope; unknown or current terminal retained. Legacy nested records recovered by original hash, never replayed.','NoActorForwardReady':True,'new_PF_converter_model_optimizer_fit_forecast_derivative_cloud_calls':0,'future_rewards_or_full_candidate_successor_vectors_invented':False}
 write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'command':'build_native_cached_contexts_20261011.py','protocol_sha256':sha(OUT/'Protocol.json')})
 lookup={(r['world_sha256'],r['branch'],r['after_commit']):r for r in previous};assert len(lookup)==262
 metrics,score=extract_pure_native_functions();records=[];nodes={};recovered=[];counts={'branch_reads':0,'old_individual_record_reads':0,'native_metric_evaluations':0,'native_score_evaluations':0,'new_scientific_calls':0}
 for binding in support['latched_OPT_branches']:
  assert time.perf_counter()-start<180,'Resource bound; no extension/restart'
  path=ROOT/binding['path'];assert sha(path)==binding['sha256'];branch=read(path);counts['branch_reads']+=1
  states=branch.get('actual_partial_solved_states') or [];legacy=None
  if not states and branch.get('original_reference'):
   reference=branch['original_reference'];op=ROOT/reference['path'];assert sha(op)==reference['sha256']
   artifact=read(op);legacy=artifact['record'];counts['old_individual_record_reads']+=1;states=legacy['actual_solved_states']
   assert artifact['scenario_sha256']==binding['world_sha256'] and legacy['branch']==binding['branch'] and legacy['status']=='complete' and legacy['frozen_base_network_preserved']
   recovered.append({'world_sha256':binding['world_sha256'],'branch':binding['branch'],'path':reference['path'],'sha256':reference['sha256'],'actual_native_state_records':len(states),'prior_campaign_global_costs_remain_UNKNOWN':reference['prior_campaign_global_costs_unknown']})
  native={s['decision']:s for s in states};assert len(native)==len(states)
  decisions={d['decision']:d for d in branch.get('measured_decisions') or []}
  result=branch['result'];actions=result['executed_actions'];world=worlds[binding['world_sha256']]
  for occurrence in branch['observations']:
   assert time.perf_counter()-start<180,'Resource bound; no extension/restart'
   k=occurrence['decision'];old=lookup[(binding['world_sha256'],binding['branch'],k)];state=native.get(k);reasons=[]
   assert old['recipe_physical_inputs_exact'] and old['unobserved_nonempty_inputs']==['storage'] and digest(occurrence['input_observation'])==occurrence['observation_sha256']
   if state is None:reasons.append('MISSING_NATIVE_VECTOR')
   else:
    index=occurrence['input_observation']['physical_tables']['res_bus']['index'];vector=state['vm_pu']
    assert set(vector)=={str(int(b)) for b in index} and all(math.isfinite(v) for v in vector.values())
    frame=pd.DataFrame({'vm_pu':[vector[str(int(b))] for b in index]},index=index)
    current=metrics(SimpleNamespace(res_bus=frame));counts['native_metric_evaluations']+=1
    if canonical(current)!=canonical(state['metrics']):reasons.append('CURRENT_NATIVE_METRIC_NOT_EXACT')
   descriptor={'world_sha256':binding['world_sha256'],'scenario_id':world['scenario_id'],'branch':binding['branch'],'after_commit':k,'remaining_slots':25-k,'observation_sha256':occurrence['observation_sha256'],'branch_source':binding,'actual_native_vector_source':recovered[-1] if legacy else {'path':binding['path'],'sha256':binding['sha256'],'field':'actual_partial_solved_states'},'native_current':state,'cap_totals':old['named_shunt_cap_totals'],'source_storage_binding':'Pinned original fixed four zero-PQ storage rows, no-control native route','unknown_reasons':reasons,'audience':'TRUSTED_MEASUREMENT_ADMIN_NOT_ACTOR_FORWARD','no_new_physics_or_future_reward':True,'prior_campaign_global_costs_unknown':bool(legacy and branch['original_reference']['prior_campaign_global_costs_unknown'])}
   status='UNKNOWN';candidates=[];scores=[];reused_source='NONE'
   if state is not None and not reasons and (state['metrics']['uv_count']==0 or k>=25):status='HEALTHY_OR_BUDGET_TERMINAL_NO_NEW_SEARCH'
   elif state is not None and not reasons:
    decision=decisions.get(k+1)
    if decision is not None:
     assert decision['observation_sha256']==occurrence['observation_sha256'] and decision['failed_signatures_before']==[]
     candidates=copy.deepcopy(decision['candidates']);scores=decision['original_scores'];reused_source='fresh_native_v3_measured_decision'
    elif legacy is not None:
     rows=[c for c in legacy['actual_candidate_verifications'] if c['decision']==k+1]
     for row in rows:
      bus,q=next(iter(row['action']['add_shunts_q_mvar'].items()))
      candidates.append({'source':'safety_fallback_physics_refinement','zone':None,'action':copy.deepcopy(row['action']),'bus':str(bus),'q_abs':abs(float(q)),'verif':copy.deepcopy(row['verification']),'raw':None})
     scores=[safe(score(c)) for c in candidates];counts['native_score_evaluations']+=len(candidates);reused_source='exact_old_individual_candidate_verifications'
    if not candidates:descriptor['unknown_reasons'].append('NO_COMPLETE_CACHED_NATIVE_MENU')
    else:
     pool=occurrence['input_observation']['literal_fallback_bus_pool'];expected=[(str(b),q) for b in pool for q in Q]
     actual=[(str(c['bus']),float(c['q_abs'])) for c in candidates]
     if actual!=expected:descriptor['unknown_reasons'].append('MENU_SCOPE_ORDER_OR_COMPLETENESS_MISMATCH')
     assert len(candidates)==len(scores)
     for c,s in zip(candidates,scores):
      if canonical(c['verif']['before'])!=canonical(state['metrics']):descriptor['unknown_reasons'].append('CACHED_BEFORE_NATIVE_METRIC_MISMATCH');break
      if safe(score(c))!=s:descriptor['unknown_reasons'].append('EXACT_ORIGINAL_SCORE_MISMATCH');break
      counts['native_score_evaluations']+=1
      if c['verif']['accepted']:
       assert c['verif']['converged'] is True and c['verif']['normal_upper_mediation']['band_admissible'] and c['verif']['after']['vmax']<=1.05+1e-8
     if not descriptor['unknown_reasons']:status='BOUND_PAID_NATIVE_MENU'
   descriptor.update(status=status,cached_menu_source=reused_source,candidates=candidates,original_scores=scores)
   descriptor['native_prefix_result']={'method':result['method'],'scenario_id':result['scenario_id'],'base_converged':result['base_converged'],'base_metrics':result['base_metrics'],'final_metrics':None,'stop_reason':None,'logs':copy.deepcopy(result['logs'][:k]),'executed_actions':copy.deepcopy(actions[:k]),'counters':{'fallback_tests':sum(x.get('fallback_tests',0) for x in result['logs'][:k])}}
   parent=digest({'base_network_sha256':physics['network_sha256'],'metadata_sha256':physics['metadata_sha256'],'input_tables':{name:value for name,value in occurrence['input_observation']['physical_tables'].items() if not name.startswith('res_')},'native_vector':state['vm_pu'] if state else None,'cap':old['named_shunt_cap_totals'],'after_commit':k,'guard':physics['guard'],'failed_sigs':[]})
   descriptor['physical_process_parent_id']=parent
   descriptor['legal_zone_bus_intersections']=occurrence['input_observation']['raw_common_and_zone_pools']
   if parent in nodes:
    if canonical(nodes[parent]['candidates'])!=canonical(candidates) or nodes[parent]['status']!=status:descriptor['alias_cache_disposition']='DO_NOT_REUSE_ALIAS_MENU_CONFLICT'
    else:descriptor['alias_cache_disposition']='EXACT_PHYSICAL_PROCESS_ALIAS_NO_DUPLICATE_QUERY'
   else:nodes[parent]=descriptor;descriptor['alias_cache_disposition']='FIRST_PARENT_RECORD'
   name=digest({'world':binding['world_sha256'],'branch':binding['branch'],'k':k})[:32]+'.json';write(OUT/'nodes'/name,descriptor)
   records.append({'world_sha256':binding['world_sha256'],'branch':binding['branch'],'after_commit':k,'status':status,'unknown_reasons':descriptor['unknown_reasons'],'physical_process_parent_id':parent,'alias_cache_disposition':descriptor['alias_cache_disposition'],'path':'nodes/'+name,'sha256':sha(OUT/'nodes'/name),'cached_candidate_count':len(candidates)})
 summary={'all31_world_ids_retained':True,'held8_branch_files_unread':True,'OPT_occurrences_retained':len(records),'unique_physical_process_parent_ids':len(nodes),'status_counts':{status:sum(r['status']==status for r in records) for status in sorted({r['status'] for r in records})},'alias_cache_conflicts':sum(r['alias_cache_disposition']=='DO_NOT_REUSE_ALIAS_MENU_CONFLICT' for r in records),'recovered_original_native_vector_records':sum(r['actual_native_state_records'] for r in recovered),'recovered_individual_sources':recovered,'actual_pure_data_counts':counts,'workflow_seconds_before_report_manifest':time.perf_counter()-start,'no_new_PF_model_fit_converter_derivative_forecast_cloud_calls':True,'no_actor_or_physical_campaign_ready':True,'Stage3_joint_campaign_still_PARTIAL_74_of80':True,'prior_individual_costs_and_global_UNKNOWN_not_changed':True}
 assert len(records)==262 and counts['branch_reads']==46
 write(OUT/'Descriptor_Index.json',records);write(OUT/'Results.json',summary)
 write(OUT/'Closed_Manifest.json',{'complete':True,'members':{p.relative_to(OUT).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in OUT.rglob('*') if p.is_file()}})
 print(json.dumps({k:v for k,v in summary.items() if k not in ['recovered_individual_sources','actual_pure_data_counts']}))
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  if OUT.is_dir():write(OUT/'Failure.json',{'actual_pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'exception':type(exc).__name__,'message':str(exc),'state':'TERMINAL_BINDING_PARTIAL_NO_AUTOMATIC_RETRY','new_actual_scientific_calls':0})
  raise
