"""Pinned read-only paid-result metadata snapshot; no scientific call.

The 36 MB registry is verified once at construction/cold reconstruction. The
in-memory snapshot is the frozen declared index, not a live directory scanner.
Every selected NET, field bundle and independent certificate is hash-verified
at lookup. This never grants new-PF authority, including on a scoped miss.
"""
from pathlib import Path
import copy, hashlib, json

class PaidSnapshot:
    def __init__(self,root,expected_manifest_sha256):
        self.__root=Path(root).resolve()
        self.__directory=self.__root/'outputs/nonlinear500_paid_registry_20261029'
        self.__costs={'metadata_bytes_read':0,'selected_payload_bytes_read':0,'lookup_calls':0}
        self.__manifest_sha256=expected_manifest_sha256
        manifest=json.loads(self._read(self.__directory/'Frozen_Registry_Manifest.json',expected_manifest_sha256,False))
        self.__registry=json.loads(self._read(self.__directory/'Paid_Physical_Registry.json',manifest['Paid_Physical_Registry.json']['sha256'],False))
        self.__bindings=json.loads(self._read(self.__directory/'Source_Bindings.json',manifest['Source_Bindings.json']['sha256'],False))
        self.__identity={'manifest_sha256':expected_manifest_sha256,
            'registry_sha256':manifest['Paid_Physical_Registry.json']['sha256'],
            'bindings_sha256':manifest['Source_Bindings.json']['sha256'],
            'scope':'Immutable captured metadata; every cold construction re-verifies all metadata bytes; no automatic history refresh or PF permission.'}

    @property
    def root(self):
        return self.__root

    @property
    def manifest_sha256(self):
        return self.__manifest_sha256

    @property
    def identity(self):
        return copy.deepcopy(self.__identity)

    @property
    def costs(self):
        return self.__costs.copy()

    def _read(self,path,expected,payload):
        path=Path(path).resolve();path.relative_to(self.__root)
        raw=path.read_bytes()
        self.__costs['selected_payload_bytes_read' if payload else 'metadata_bytes_read']+=len(raw)
        if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Pinned paid evidence changed: '+str(path))
        return raw

    def lookup(self,physical_signature,kwargs):
        self.__costs['lookup_calls']+=1
        key=physical_signature+'|'+json.dumps(kwargs,sort_keys=True)
        entry=self.__registry['entries'].get(key)
        if entry and entry['reuse']:
            reuse=entry['reuse']
            for name in ['after','fields']:
                self._read(self.__root/reuse[name]['path'],reuse[name]['sha256'],True)
            cert=reuse['independent_certificate']
            self._read(self.__root/cert,self.__bindings[cert]['sha256'],True)
            return dict(status='VERIFIED_EXACT_PAID_REUSE',key=key,reuse=copy.deepcopy(reuse),
                source_manifest_sha256=self.__manifest_sha256,new_PF_permitted=False)
        if physical_signature in self.__registry['signature_deny_provenance']:
            return dict(status='BLOCKED_PREVIOUSLY_ATTEMPTED_NO_ELIGIBLE_EXACT_KEY',key=key,new_PF_permitted=False)
        return dict(status='MISS_IN_FINITE_SCOPED_REGISTRY',key=key,new_PF_permitted=False,universal_absence_claim=False)
