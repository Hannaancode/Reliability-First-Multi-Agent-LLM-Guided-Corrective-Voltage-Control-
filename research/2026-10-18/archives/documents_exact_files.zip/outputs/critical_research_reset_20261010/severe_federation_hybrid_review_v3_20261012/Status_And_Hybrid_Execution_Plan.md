# Verified status and a materially different hybrid route

12 October 2026. Main goal: actual incremental LLM advantage over original literal D-SE. This has not been established. No scientific, collector or reader job is currently owned. The new work in this checkpoint is a saved-result/source review and a prospectively specified saved support inventory, with zero new model, physics or optimizer calls.

## The severe cases exist

The federation has **118 buses in four microgrids**, and the original scenario directory has **141 recipe files**. The old rescue log preserves 68 completed rows, through scenario index 69; this is a partial record, not a complete 141-case result.

| Old scenario index | Recipe suffix | Initial UV buses | Final UV buses | Recorded stop |
|---|---|---:|---:|---|
| 65 | load 1.5 / line 101 / MG1 | 61 | 21 | iteration limit |
| 66 | load 1.5 / line 127 / MG3 | 55 | 41 | iteration limit |
| 67 | load 1.5 / line 128 / MG3 | 60 | 15 | iteration limit |
| 68 | load 1.5 / line 129 / MG3 | 57 | 3 | iteration limit |
| 69 | load 1.5 / line 135 / MG3 | 58 | 20 | iteration limit |

All five CSV entries were checked against their exact raw-log scenario blocks, starting UV values, ending UV values and stop reasons. These historical logs are not a matched D-SE comparison or a complete independent physical replay certificate.

The later independently audited Stage3 development evidence also contains difficult starts. Its four load-1.5 roots start with 56, 58, 57 and 55 UV buses. Their fresh trained-LoRA policy leaves 17, 33, 28 and 15 UV buses. The available protected full-DFF outcomes leave 6, UNKNOWN, 10 and 10 respectively. The available lowest-voltage control outcomes leave 2, UNKNOWN, 9 and 5. These are different decision procedures and costs. All 80 declared identities are retained in the accompanying CSV, including six UNKNOWN outcomes; the study remains 74/80 partial. Its original literal D-SE portfolios and both-branch costs are retained in the diagnostic JSON.

The sealed 62-case campaign is a different bank: the known initial UV maximum is 31, with two invalid/failure initial entries kept UNKNOWN. Among its 60 valid paired outcomes, deterministic D-SE ends with a total of zero UV buses; HG-SE ends with one. This bank cannot establish superiority on the 60+UV starts.

## Genuine improvements and their limits

- Matched adapted scaling increased exact teacher-action accuracy from 41.6667% at 0.5B to 53.125% at 1.5B: +11.4583 percentage points. Both produce legal schema outputs 100% of the time. The trained numerical control reaches 72.9167%; the fixed scale gate failed, and that intervention remains stopped. This test measured teacher-action accuracy, not physical restoration.
- In the sealed campaign's 60 valid pairs, HG-SE used 88,097 PF attempts versus D-SE's 99,029, about 11.0% fewer. Both portfolios charge both required branches. HG-SE's mean charged wall time was 220.10 seconds versus 150.25 seconds, so this is fewer physics calls with slower overall execution and one residual UV, not an overall efficiency or restoration win. The two invalid cases remain disclosed.
- Independent preservation, replay and source checks now expose these limitations rather than hide missing outcomes. Closed-controller evidence was compressed by 70.7% in an engineering read test. A live whole-policy speed improvement has not been measured; growing file counts and repeated inventories remain an overhead problem.

## Why change the decision mechanism

The original normalizer retains only the first positive shunt entry. The original actuator adds capacitive support; it cannot reduce previously added support. The source-bound contract also rejects a neutral preparatory move with no immediate UV, deficit or minimum-voltage gain. Therefore coordinated reallocation is absent from the current action space. This is a source fact, not a proof that a successful reallocation exists.

Later severe-case trajectories often stop at `no_accepted_action` or `no_accepted_action_within_declared_search`, before using 25 decisions. More iterations alone do not remove the action restriction. Earlier upper-pressure observations are consistent with a bottleneck, but do not prove universal infeasibility.

## One selected hypothesis: joint reallocation of already-added support

Use our unchanged trained LOCAL-role LLM as an optional recipient/proposal seed for a numerical planner. The planner may **withdraw a discrete block of its own previously added capacitive support at one bus and add support at another bus in the same proposed transition**. The nonlinear verifier checks the complete resulting state before any irreversible commit.

This is a new hybrid action contract. It does not teach the existing parser to output signed or multi-bus actions, alter the private adapter, edit the original controller, move base-network devices, add an undisclosed reactor, or treat a hypothetical intermediate network as an observed successor. The original command remains positive single-bus advice; the additive planner owns the separately specified joint transition. Coordinated volt-VAR control is established prior art, so this combination has no novelty claim without further evidence.

The saved inventory was frozen before this owner read its outcome bytes and includes all four declared load-1.5 Stage3 roots. Known committed additions and residual UV identify 152, 198, 83 and 120 nominal distinct donor/receiver bus pairs. Some previously supported buses are close to the upper band. These counts show that the route is not empty at the summary level. **They prove no safe physical improvement.** Exact shunt-row ownership, switchability and current full network states remain to be certified; voltages alone do not show the direction of an individual sensitivity.

## Ordered execution gates

1. **Current-state and actuator closure.** Recover source-bound initial networks and complete actual committed action lists for all four fixed roots. Rebuild each prefix only as explicitly charged independent replay in a new namespace. Keep the old studies closed and their costs. Check every available recorded voltage/current-state anchor; retain unobserved original angle/P/Q values as UNKNOWN. Any newly observed full fields must be labelled as replay measurements. Freeze the identity of each controllable added bank, its discrete blocks and remaining support. Require cold reconstruction, source/input/runtime binding, final fields, receipt/cursor/RNG preservation, and exact ended-owner proof. A missing field or mismatch stops that identity; no repeated science or claim of full completion.

2. **Cheap numerical admission, before GPU.** Bind a current-state Jacobian or comparably strong numerical approximation under a new source/protocol lock. Evaluate only genuinely new joint-action identities. Count every new derivative, factorization, solve, forecast and preparation call; prior preparations are reused with their costs retained. Include all native UV receivers, all eligible owned donors and the original discrete Q grid. No selected favorable donor, world, seed or threshold sweep. An approximation predicts admission only; it does not certify safety or establish that omitted nonlinear actions cannot work.

3. **Paid nonlinear opportunity screen.** Freeze the complete candidate ordering, finite query allowance, absolute resource/storage bounds, claim/owner/reader sources and stopped/UNKNOWN behavior before any opportunity outcome. Compare ordinary legal additions and joint reallocation from the same actual state, with unchanged raw common AND zone scopes, original score, native non-regression rules, nonlinear convergence requirement and common upper band 1.05+1e-8. Preserve every query/exception/rejection/unknown and independently replay accepted proposed transitions. No automatic application of a numerical forecast.

   Withdraw only source-owned added support, never base-network support. Maintain nonnegative installed support and the original 450-MVAr cumulative **positive-addition** cap at every bus. Withdrawal never refunds this cap. Record withdrawn amount, gross switching work and both device operations explicitly; joint moves must not obtain extra free device-operation or episode budget. Physical switchability of partially withdrawn banks is a research-model assumption that must be specified and checked, not inferred from their names.

   The provisional development opportunity gate is complete evidence on all four roots, a newly verified safe joint move reducing UV by at least one on at least two roots, and no loss of the already available ordinary-action incumbent on any root. Freeze this gate in the eventual execution protocol; it is a screen for this mechanism and fixed tested allowance, not statistical confidence or a universal impossibility test. An incomplete screen leaves the gate UNKNOWN. A measured failed screen stops this specified intervention; no outcome-driven changes to Q, roots, budget, thresholds or scoring.

4. **Only if opportunity survives, matched hybrid attribution.** Freeze a fresh causal serving binding for our unchanged private trained 0.5B LOCAL-role model. Use genuine fresh per-state inference; no saved answers or after-state labels in prompts. Compare (a) original literal D-SE with both original branches and FULL BOTH costs, (b) protected literal D-SE, (c) an equally capable strong numerical joint planner, and (d) the same joint planner seeded by the LLM. Give the numerical ablation the same causal information, actuator rights, legal candidate universe and physical-query allowance. Charge model, prompt, setup, training/reused data, numerical preparation, solver, preservation, replay and failure costs. No automatic re-training of the stopped 1.5B study.

5. **Full-policy and confirmation gate.** A safe one-move result is not a complete policy result. Require complete matched protected trajectories within a prospectively fixed operation bound, independent continuous replay, all four development roots retained, actual endpoint/unknown/failure/safety/effort/runtime results, then separately authorized genuinely unused confirmation. A win for the joint numerical planner is useful progress for the hybrid system; only a further improvement of the LLM-seeded version over that equally capable planner supports incremental LLM value. Architecture/pretraining attribution and full security remain separate requirements.

## Ready now versus unfinished

The case-count/UV review and saved stock inventory are complete. The new joint planner, source-bound physical actuator/current-state reconstruction, numerical admission implementation, full owner/reader protocol and actual opportunity screen are **not yet complete or launched**. No fresh physical/hybrid win, deployment-speed improvement or 90% success probability is claimed. Next work is these concrete gates, rather than another outcome-driven training run or routine monitoring.

Evidence: `Saved_Result_Diagnostic.json`, `Stage3_All_80_Identities.csv`, `../severe_joint_support_inventory_20261012/{Protocol.json,Saved_Support_Inventory.json}`, `../deployed_action_transition_contract_20261012/Source_Contract_Certificate.json`. Two failed diagnostic readers are preserved separately; their additive mechanical repair made zero scientific calls.

Primary references: [pandapower 3.4.0 shunt model and controls](https://pandapower.readthedocs.io/en/v3.4.0/elements/shunt.html) and [Jha et al., coordinated bi-level volt-VAR optimization](https://arxiv.org/abs/1912.03596). Their general coordinated-control mechanisms do not establish success on this IEEE118 federation, on our restricted devices, or for our LLM.
