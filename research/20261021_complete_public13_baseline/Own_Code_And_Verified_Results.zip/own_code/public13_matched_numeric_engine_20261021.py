"""Frozen existing numerical policy on the exact public500 roots, with paid reuse.

Primary proposes through the unchanged public sparse-derivative/two-LP method.
The first reader reconstructs dense equations and LP dual certificates, and
replays only NEW returned physical calls. No pretrained model is invoked.
"""
import os,json,copy,pickle,time,hashlib,random,traceback
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_matched_numeric_preparation_20261021'
PRIMARY=R/'outputs/public13_matched_numeric_execution_20261021';READER=R/'outputs/public13_matched_numeric_independent_20261021'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def metric(vm):return {'UV':int((vm<.95).sum()),'OV':int((vm>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'full13band':bool(((vm>=.95)&(vm<=1.05)).all())}
def original_guard(before,after):
    import numpy as np
    normal=(before>=.95)&(before<=1.05)
    return bool(np.isfinite(after).all() and np.all(after[normal]>=.95-1e-8) and np.all(after[normal]<=1.05+1e-8) and (after<.95).sum()<=(before<.95).sum() and (after>1.05).sum()<=(before>1.05).sum())
def run(mode):
    out=PRIMARY if mode=='primary' else READER;out.mkdir(exist_ok=False);began=time.monotonic();source=R/('work/run_public13_matched_numeric_20261021.py' if mode=='primary' else 'work/audit_public13_matched_numeric_20261021.py');put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(source),'at_utc':datetime.now(timezone.utc).isoformat()})
    while not (out/'Launcher_ACK.json').exists():assert time.monotonic()-began<60;time.sleep(.1)
    p=read(P/'Protocol.json');deadline=began+p['science_seconds' if mode=='primary' else 'reader_seconds'];ack=read(out/'Launcher_ACK.json');assert ack['actual_pid']==os.getpid() and ack['actual_parent_pid']==os.getppid() and ack['fresh_exact_source_PID_parent_command']
    for rel,h in p['source_and_input_hashes'].items():assert sha(R/rel)==h
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from run_public13_remaining_published_cohort_20261021 import regime
    from native_fit_teacher_math_20261020 import propose,verify
    from candidate_process_evidence_utils import frozen_checks
    from pandapower.pypower.makeSbus import makeSbus
    np=b.np;torch=b.torch;torch.set_num_threads(1);random.seed(20261021);np.random.seed(20261021);torch.manual_seed(20261021)
    roots=read(P/'All500_Audited_Exact_Roots.json')['roots'];old=read(P/'Historical_Paid_Physical_Index.json');oldindex_sha=sha(P/'Historical_Paid_Physical_Index.json');paid=dict(old['returned_exact_initializer_entries']);attempted=set(old['all_relevant_attempted_signatures']);mathcache={};mathreceipts=[];newreceipts=[];rows=[];previous='0'*64;binarybytes=0;current=None;scope={};maxdelta=0.;resource_partial=False;reader_replaying=False
    cost={n:0 for n in ['PF_attempts','PF_returns','PF_exceptions','old_paid_physics_reuses','current_campaign_physics_reuses','derivative_attempts','derivative_returns','LU_returns','RHS_returns','LP_attempts','LP_returns','paid_math_reuses','independent_dense_equation_checks','actual_control_decisions','accepted_commits','rejected_candidates']};cost['LLM_GPU_optimizer_training_converter_calls']=0
    stream=(out/'events.jsonl').open('x',encoding='utf-8');(out/'physics').mkdir();(out/'states').mkdir();(out/'decisions').mkdir()
    def bound():
        if time.monotonic()>deadline-20:raise TimeoutError('Fixed prospective resource bound; no renewal or retry')
    def event(kind,**data):
        nonlocal previous
        v={'kind':kind,'elapsed_seconds':time.monotonic()-began,'previous':previous,**data};h=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();stream.write(json.dumps({'event':v,'sha256':h})+'\n');stream.flush();os.fsync(stream.fileno());previous=h
    def binary(path,value):
        nonlocal binarybytes
        raw=pickle.dumps(value,protocol=5)
        if binarybytes+len(raw)>p['binary_preservation_cap_bytes']:raise TimeoutError('Fixed binary preservation capacity; no extension')
        with Path(path).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        binarybytes+=len(raw)
    def key(sig,kwargs):return sig+'|'+json.dumps(kwargs,sort_keys=True)
    graph=np.load(R/p['graph']);Y=graph['Y'];put(out/'Frozen_Before.json',frozen_checks())
    if mode=='independent':
        end=read(R/'outputs/public13_matched_numeric_coordination_20261021/End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
        locked=read(P/'Independent_Reader_Lock.json');assert sha(source)==locked['reader_sha256'] and sha(P/'Protocol.json')==locked['protocol_sha256']
        for v in read(PRIMARY/'Closed_Manifest.json')['files']:assert sha(PRIMARY/v['path'])==v['sha256']
        primary=read(PRIMARY/'Result.json');targets={key(v['physical_signature'],v['kwargs']):v for v in primary['receipts']};expected_worlds={v['seed']:v for v in primary['worlds']};expected_sources={}
        prior='0'*64
        for line in (PRIMARY/'events.jsonl').read_text().splitlines():
            row=json.loads(line);v=row['event'];assert v['previous']==prior and hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==row['sha256'];prior=row['sha256']
        assert prior==read(PRIMARY/'Closed_Manifest.json')['journal_last_sha256']
    def query(net):
        nonlocal current,maxdelta
        bound();sig=signature(net);kwargs={'algorithm':'bfsw','init':'dc'};k=key(sig,kwargs)
        assert regime(net)==roots[scope['seed']]['noncontrolled_regime'],'Changed native loads, P or unactuated inputs'
        if k in paid:
            receipt=paid[k];path=R/receipt['after'];assert sha(path)==receipt['after_sha256'];solved=pickle.loads(path.read_bytes());assert signature(solved)==sig;net.update(solved);current=receipt;cost['current_campaign_physics_reuses' if receipt.get('new_in_this_campaign') else 'old_paid_physics_reuses']+=1;event('exact_paid_physics_reuse',physical_signature=sig,after=receipt['after'],scope=scope.copy());return
        if sig in attempted:raise RuntimeError('Already attempted physical input without exact initializer-matched returned evidence; UNKNOWN, no new PF')
        if mode=='independent':
            assert reader_replaying and k in targets,'Reader would make an unentered scientific call';assert targets[k]['status']=='RETURNED','Never replay failed/unknown science'
        index=cost['PF_attempts'];before=out/'physics'/f'PF{index:05d}_before.pkl';binary(before,net);record={'index':index,'physical_signature':sig,'kwargs':kwargs,'scope':scope.copy(),'status':'ATTEMPTED','before_sha256':sha(before)};newreceipts.append(record);attempted.add(sig);cost['PF_attempts']+=1;event('PF_attempt',**record);start=time.perf_counter()
        try:b.pp.runpp(net,**kwargs)
        except BaseException as exc:
            cost['PF_exceptions']+=1;record.update(status='EXCEPTION',failure_type=type(exc).__name__,seconds=time.perf_counter()-start);event('PF_exception',**record);raise
        cost['PF_returns']+=1;assert net.converged and signature(net)==sig;pp=net._ppc;assert np.array_equal(pp['branch'][:,:13],graph['branch'][:,:13]) and np.array_equal(pp['bus'][:,[0,4,5]],graph['bus'][:,[0,4,5]])
        V=pp['bus'][:,7]*np.exp(1j*np.deg2rad(pp['bus'][:,8]));KCL=float(np.max(np.abs(V*np.conj(Y@V)-makeSbus(pp['baseMVA'],pp['bus'],pp['gen']))));assert KCL<=1e-7
        after=out/'physics'/f'PF{index:05d}_after.pkl';binary(after,net);fields=out/'physics'/f'PF{index:05d}_fields.npz';arrays={n:net[n].select_dtypes(include=[np.number]).to_numpy(float) for n in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};np.savez(fields,**arrays)
        if mode=='independent':
            expected=targets[k];z=np.load(PRIMARY/'physics'/f"PF{expected['index']:05d}_fields.npz");assert set(z.files)==set(arrays)
            for name,value in arrays.items():
                assert np.array_equal(np.isnan(value),np.isnan(z[name])) and np.allclose(value,z[name],atol=1e-10,rtol=0,equal_nan=True);mask=np.isfinite(value)&np.isfinite(z[name]);maxdelta=max(maxdelta,float(np.max(np.abs(value[mask]-z[name][mask]),initial=0.)))
        record.update(status='RETURNED',after=after.relative_to(R).as_posix(),after_sha256=sha(after),fields=fields.relative_to(R).as_posix(),fields_sha256=sha(fields),KCL_pu=KCL,seconds=time.perf_counter()-start,new_in_this_campaign=True);paid[k]=record;current=record;event('PF_return',**record)
    try:
        if mode=='independent':
            # Charge one first replay of every new RETURNED identity before
            # reading control decisions. Failed or unentered calls stay unknown.
            reader_replaying=True
            for receipt in primary['receipts']:
                if receipt['status']!='RETURNED':event('primary_failed_or_unreturned_not_replayed',index=receipt['index'],status=receipt['status']);continue
                scope.clear();scope.update(receipt['scope']);path=PRIMARY/'physics'/f"PF{receipt['index']:05d}_before.pkl";assert sha(path)==receipt['before_sha256'];net=pickle.loads(path.read_bytes());assert signature(net)==receipt['physical_signature'];query(net)
            reader_replaying=False
            # Every completed numerical call has an independently reconstructed
            # dense derivative and primal/dual proof, without another solver.
            for m in primary['math_receipts']:
                if m['status']!='RETURNED':event('incomplete_numeric_proof_retained_UNKNOWN',record=m);continue
                path=R/m['current_NET']['path'];assert sha(path)==m['current_NET']['sha256'];value=pickle.loads(path.read_bytes());net=value['network'] if m['current_NET']['kind']=='ENV' else value
                for name,h in m['proof_hashes'].items():assert sha(R/m['directory']/name)==h
                u,_=verify(R/m['directory'],net);assert u.tolist()==m['u'];cost['independent_dense_equation_checks']+=1;mathcache[m['context_key']]={'directory':m['directory'],'u':m['u']}
        for root in roots:
            if mode=='independent' and root['seed'] not in expected_worlds:break
            try:bound()
            except TimeoutError:resource_partial=True;break
            seed=root['seed'];raw=(R/root['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==root['sha256'];value=pickle.loads(raw);net=value['network'] if root['kind']=='ENV' else value;assert signature(net)==root['physical_signature'] and np.array_equal(net.res_bus.vm_pu.to_numpy(),root['all13_initial_vm']);netref={'path':root['path'],'sha256':root['sha256'],'kind':root['kind']};world={'seed':seed,'status':'UNKNOWN','initial':metric(net.res_bus.vm_pu.to_numpy()),'steps':[],'exact_root_physical_signature':signature(net)};rows.append(world);history=[]
            try:
                for step in range(1,101):
                    bound();scope.clear();scope.update(seed=seed,step=step);vm=net.res_bus.vm_pu.to_numpy(copy=True)
                    if metric(vm)['full13band']:world['status']='COMPLETE_FULL13_BAND_RESTORED';break
                    if mode=='independent' and len(world['steps'])>=len(expected_worlds[seed]['steps']):world['status']=expected_worlds[seed]['status'];break
                    identifier=f'seed{seed:03d}_step{step:03d}';directory=(out/'decisions'/identifier);directory.mkdir();checkpoint={'seed':seed,'next_step':step,'remaining_original_horizon':101-step,'current_NET':netref,'current_vm':vm.copy(),'current_Q':net.sgen.q_mvar.to_numpy()[:3].copy(),'history':copy.deepcopy(history),'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'absolute_deadline_monotonic':deadline,'costs':cost.copy(),'current_journal_prefix':previous,'current_journal_byte_offset':stream.tell(),'old_physical_index_sha256':oldindex_sha,'cache_restoration':'Reconstruct numerical_return/PF_return/attempt maps from exact fsynced journal prefix plus immutable old physical index; never re-execute science','source_protocol_sha256':sha(P/'Protocol.json')};binary(directory/'Full_Cursor.pkl',checkpoint);loaded=pickle.loads((directory/'Full_Cursor.pkl').read_bytes());assert loaded['remaining_original_horizon']==101-step and loaded['absolute_deadline_monotonic']==deadline and loaded['current_journal_prefix']==previous and loaded['current_journal_byte_offset']==stream.tell()
                    saved=(R/netref['path']).read_bytes();assert hashlib.sha256(saved).hexdigest()==netref['sha256'];restored=pickle.loads(saved);cold=restored['network'] if netref['kind']=='ENV' else restored;assert signature(cold)==signature(net) and np.array_equal(cold.res_bus.vm_pu.to_numpy(),vm) and np.array_equal(loaded['current_Q'],cold.sgen.q_mvar.to_numpy()[:3])
                    # State key includes exact solved voltages, not only physical inputs.
                    context_key=signature(net)+'|'+hashlib.sha256(net._ppc['bus'][:,7:9].tobytes()).hexdigest()
                    if context_key in mathcache:
                        proof=mathcache[context_key];u=np.asarray(proof['u'],dtype=np.float32);mathref=proof['directory'];cost['paid_math_reuses']+=1
                    else:
                        if mode=='primary':
                            record={'context_key':context_key,'directory':directory.relative_to(R).as_posix(),'current_NET':netref.copy(),'status':'ATTEMPTED','scope':scope.copy()};mathreceipts.append(record);event('numerical_attempt',**record);u,_=propose(net,Y,directory,cost);mathref=directory.relative_to(R).as_posix();record.update(status='RETURNED',u=u.tolist(),proof_hashes={n:sha(directory/n) for n in ['Current_Model.npz','LP1.npz','LP2.npz']});event('numerical_return',**record)
                        else:
                            expected=expected_worlds[seed]['steps'][step-1];mathref=expected['math_proof_directory'];u,_=verify(R/mathref,net);cost['independent_dense_equation_checks']+=1
                        mathcache[context_key]={'directory':mathref,'u':u.tolist()}
                    assert u.dtype==np.float32 and u.shape==(3,) and np.isfinite(u).all() and (np.abs(u)<=np.float32(.3)).all();q=net.sgen.q_mvar.to_numpy()[:3].copy();candidate=copy.deepcopy(net);candidate.sgen.loc[candidate.sgen.index[:3],'q_mvar']=q-u;query(candidate);after=candidate.res_bus.vm_pu.to_numpy(copy=True)
                    if mode=='primary':accepted=original_guard(vm,after)
                    else:
                        # Separate literal audit of the frozen guard boundaries.
                        normal_indices=np.flatnonzero((vm>=.95)&(vm<=1.05));accepted=bool(np.isfinite(after).all() and all(.95-1e-8<=after[i]<=1.05+1e-8 for i in normal_indices) and sum(after<.95)<=sum(vm<.95) and sum(after>1.05)<=sum(vm>1.05))
                    cost['actual_control_decisions']+=1;cost['accepted_commits' if accepted else 'rejected_candidates']+=1;decision={'step':step,'current_physical_signature':signature(net),'current_vm':vm.tolist(),'current_Q':q.tolist(),'native_u':u.tolist(),'candidate_Q':(q-u).tolist(),'candidate_vm':after.tolist(),'candidate_metrics':metric(after),'accepted':accepted,'math_context':context_key,'math_proof_directory':mathref,'candidate_receipt_after':current['after'],'candidate_receipt_after_sha256':current['after_sha256'],'new_physics_in_current_campaign':bool(current.get('new_in_this_campaign'))}
                    if mode=='independent':
                        expected=expected_worlds[seed]['steps'][step-1]
                        for name in ['current_physical_signature','current_vm','current_Q','native_u','candidate_Q','candidate_vm','candidate_metrics','accepted','math_context','math_proof_directory']:assert decision[name]==expected[name],name
                    put(directory/'Decision.json',decision);world['steps'].append(decision);history.append({'step':step,'accepted':accepted,'candidate_after':current['after'],'candidate_after_sha256':current['after_sha256'],'native_u':u.tolist()});event('decision',seed=seed,step=step,accepted=accepted,metrics=metric(after))
                    committed_ref={'path':current['after'],'sha256':current['after_sha256'],'kind':'NET'} if accepted else netref.copy();committed=candidate if accepted else net
                    post={'seed':seed,'next_step':step+1,'remaining_original_horizon':100-step,'current_NET':committed_ref,'current_vm':committed.res_bus.vm_pu.to_numpy(copy=True),'current_Q':committed.sgen.q_mvar.to_numpy()[:3].copy(),'history':copy.deepcopy(history),'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state().numpy(),'absolute_deadline_monotonic':deadline,'costs':cost.copy(),'current_journal_prefix':previous,'current_journal_byte_offset':stream.tell(),'old_physical_index_sha256':oldindex_sha,'source_protocol_sha256':sha(P/'Protocol.json')};binary(directory/'Post_Decision_Complete_Cursor.pkl',post)
                    if mode=='independent':
                        origin=PRIMARY/'decisions'/identifier;pre=pickle.loads((origin/'Full_Cursor.pkl').read_bytes());savedpost=pickle.loads((origin/'Post_Decision_Complete_Cursor.pkl').read_bytes());assert savedpost['next_step']==step+1 and savedpost['remaining_original_horizon']==100-step and savedpost['absolute_deadline_monotonic']==pre['absolute_deadline_monotonic'] and savedpost['old_physical_index_sha256']==oldindex_sha and np.array_equal(savedpost['current_vm'],post['current_vm']) and np.array_equal(savedpost['current_Q'],post['current_Q']);f=R/savedpost['current_NET']['path'];assert sha(f)==savedpost['current_NET']['sha256']
                    if not accepted:world['status']='COMPLETE_GUARD_REJECTED_HOLD_STOP';break
                    net=candidate;netref={'path':current['after'],'sha256':current['after_sha256'],'kind':'NET'}
                else:world['status']='COMPLETE_ORIGINAL100_HORIZON'
                final=net.res_bus.vm_pu.to_numpy(copy=True)
                if mode=='independent' and not expected_worlds[seed]['status'].startswith('COMPLETE_'):
                    world.update(status=expected_worlds[seed]['status'],last_verified_vm=final.tolist(),last_verified_NET=netref,source_unknown_preserved=True);continue
                world.update(final_vm=final.tolist(),final_Q=net.sgen.q_mvar.to_numpy()[:3].tolist(),final=metric(final),final_NET=netref)
                if world['final']['full13band']:world['status']='COMPLETE_FULL13_BAND_RESTORED'
                if mode=='independent':
                    expected=expected_worlds[seed];assert world['status']==expected['status'] and world['final']==expected['final'] and world['final_vm']==expected['final_vm'] and world['final_Q']==expected['final_Q']
                put(out/'states'/f'seed{seed:03d}_Terminal.json',world)
            except BaseException as exc:
                world.update(failure_type=type(exc).__name__,failure=str(exc),last_verified_vm=net.res_bus.vm_pu.to_numpy().tolist(),last_verified_NET=netref);event('world_unknown',seed=seed,type=type(exc).__name__)
                if mode=='independent':raise
                if isinstance(exc,TimeoutError):resource_partial=True;break
        complete=len(rows)==500 and all(v['status'].startswith('COMPLETE_') for v in rows)
        result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_ALL500_FROZEN_NUMERICAL_POLICY_EPISODES' if complete else 'TERMINAL_PARTIAL_FROZEN_NUMERICAL_POLICY','mode':mode,'worlds':rows,'unentered_seeds':list(range(len(rows),500)),'receipts':newreceipts,'math_receipts':mathreceipts,'costs':cost,'workflow_seconds':time.monotonic()-began,'new_reader_full_fields_max_delta':maxdelta,'root_PF_repeated':False,'strong_info_disclosure':'Our existing centralized full13VM/currentY sparse-Jacobian two-LP control versus published one-VM-per-agent policies. Same exact physical roots,3actuators/increment0.3/source100rounds, but different information and safety mechanisms. Not learning/LLM superiority or equal-information attribution.','same_existing_algorithm_not_retuned':True,'original_paper_model_result':'PENDING_NOT_THIS_NUMERICAL_ROW','old_costs':'All original failed science, prior primary/independent/preparation/model/training and current preparation costs retained separately, not free. Physical/model/root reuse never charged as a fresh new call.','full_AC_thermal_generator_security_feasibility':'NOT_CERTIFIED_VOLTAGE_BAND_ONLY','all6goals':'OPEN'};put(out/'Result.json',result)
        if mode=='independent':
            assert complete==primary['status'].startswith('COMPLETE_') and cost['PF_returns']==primary['costs']['PF_returns'] and cost['PF_attempts']==primary['costs']['PF_returns'];put(out/'Independent_Audit.json',{'status':'PASS_EXACT500_AVAILABLE_NUMERICAL_POLICY_DENSE_EQUATIONS_DUALS_COLD_STATE_CONTINUOUS_PHYSICS_COST_AUDIT','all500_complete':complete,'actual_independent_costs':cost,'new_primary_costs':primary['costs'],'full_fields_max_delta':maxdelta,'continuous_decisions_verified':cost['actual_control_decisions'],'old_paid_solver_outputs_reused_not_replayed':cost['old_paid_physics_reuses'],'new_derivative_LU_LP_solver_calls_in_reader':0,'workflow_seconds':time.monotonic()-began,'all6goals':'OPEN'})
        put(out/'Frozen_After.json',frozen_checks());event('closed',result_sha256=sha(out/'Result.json'));stream.close();put(out/'Closed_Manifest.json',{'files':[{'path':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)} for f in out.rglob('*') if f.is_file()],'journal_last_sha256':previous});print(result['status'])
    except BaseException as exc:
        put(out/'Failure.json',{'type':type(exc).__name__,'failure':str(exc),'traceback':traceback.format_exc(),'costs':cost,'worlds':rows,'receipts':newreceipts,'workflow_seconds':time.monotonic()-began});stream.close();raise
