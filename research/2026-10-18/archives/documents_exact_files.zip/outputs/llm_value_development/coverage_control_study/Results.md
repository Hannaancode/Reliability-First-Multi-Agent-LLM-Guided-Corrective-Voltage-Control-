# Coverage alone did not beat the primary deterministic control

Four new trajectories completed 8 October 2026 at 05:24 Qatar. The policy, identities, guard conditions, 25/32/512 limits, seed and primary comparator were declared before execution. Five software checks passed. Twelve earlier trajectories were preserved and reused, giving 16 descriptive rows from four policies, two guard conditions and two known historical operating points.

| Load factor | Guard | Bus-first final UV | Guarded lowest-voltage final UV | Bus-first PF | Guarded lowest-voltage PF |
|---|---|---:|---:|---:|---:|
| 1.25 | Original hard OV | 0 | 0 | 166 | 133 |
| 1.25 | Normal upper mediation | 0 | 0 | 166 | 133 |
| 1.50 | Original hard OV | 30 | 3 | 512 | 363 |
| 1.50 | Normal upper mediation | 30 | 3 | 512 | 363 |

The declared primary comparison uses the guarded rows. The new control cleared the mild point with 33 additional PF calls and no joint-success benefit. On the severe point it retained 27 additional undervoltage buses and used 149 additional calls. It improved on weak enumeration, but that secondary comparison does not establish an improvement over the primary state-dependent control.

All four new endpoints complied with the declared upper-band diagnostic tolerance. Applying the guard did not change their selected actions or final metrics. The severe trajectories actually exhausted the 512-call budget after 16 committed actions; they did not exhaust the 25-decision limit. Each evaluated 495 candidate actions, all at 25 MVAr, and committed 16 such actions, giving 400 MVAr nominal support. The mild trajectories committed 75/75/75/50/25 MVAr, giving 300 MVAr nominal support. These are nominal actuator quantities, not independently measured delivered reactive power. The recorded severe prefix demonstrates magnitude starvation under this bus-first ordering; it does not prove that any untested larger action would succeed.

New controller PF attempts: 1,356, zero exceptions. Independent physical replay: 46 solves, zero exceptions. Every committed state and reconstructed candidate set matched within 1e-10; source networks and prior results were preserved. A separate read-only audit verified all seven original manifest members, source/scenario/frozen hashes, all 16 exact identities, selected-action membership, recorded state chains and cost arithmetic. That audit performed zero new PF or model calls. See `independent_results_audit.json` and the complete `summary.json`; original manifests remain unchanged.

Decision: retain the adverse result. Do not reverse Q order, enlarge the budget, alter thresholds or rerun these cases to obtain a win. Candidate coverage, magnitude allocation and trajectory admissibility must be considered together. A genuine model comparator must compete with the declared lowest-voltage control under the same physics contract. The pending initial-state LoRA/base screen is unchanged; a future learned closed loop requires freshly generated proposals from each actual committed state, separately charged inference and independently replayed actions. Saved pilot or initial-state replies cannot stand in for that experiment.

These two inspected historical points belong to one family. This is descriptive development, not an independent holdout, statistical superiority, full operating feasibility, or security robustness.
