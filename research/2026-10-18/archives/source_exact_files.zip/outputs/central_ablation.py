"""New central-context ablation of the saved HG-VF controller.

Four proposal slots with shared global observation, max one repair per slot.
Call/output allowance matches four zonal agents; actual input tokens differ.
All verifier/refinement/fallback/selection/control-loop function ASTs unchanged.
"""
import copy,hashlib,json,math,types
CONTEXT=4096
GENERATION=384
def number(v):return round(float(v),6) if math.isfinite(float(v)) else str(float(v))
def global_observation(net,zones,runner):
    reports={z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
    candidates=sorted({b for z,s in reports.items() for b in runner.get_zone_candidate_buses(net,z,zones,s)})
    state={'bus_voltage_pu':[[int(b),number(v)] for b,v in net.res_bus.vm_pu.items()],
           'zones':{z:{'bus_ids':[int(b) for b in zones[z]],**{k:(number(v) if isinstance(v,float) else v) for k,v in s.items() if k not in ['undervoltage_buses','lowest_voltage_buses']}} for z,s in reports.items()},
           'candidates':candidates}
    return state,candidates
def build_prompt(net,zones,runner,ref,feedback_state,failed_actions,slot,memory_chars=1200,excluded_buses=()):
    state,candidates=global_observation(net,zones,runner)
    candidates=[b for b in candidates if str(b) not in {str(x) for x in excluded_buses}]
    uv=runner.rescue.global_uv_buses(net);stage,rule=ref.severity_stage(len(uv))
    failed=[]
    for fa in (failed_actions or [])[-5:]:
        b,q=ref._safe_bus_q(fa.get('action') if isinstance(fa,dict) else None)
        if b is not None:failed.append({'bus':b,'q':q,'reason':fa.get('reason','unknown')})
    memory=ref.build_compact_feedback_text(feedback_state,candidates,max_chars=memory_chars) if memory_chars else 'None (omitted to fit the declared context budget)'
    body=f'''You are a central grid agent inside a physics-verified grid controller.
The deterministic verifier will reject unsafe actions. Propose one valid candidate action.
CENTRAL_PROPOSAL_SLOT: {slot}
PREVIOUS_PROPOSAL_BUSES_THIS_ITERATION: {json.dumps(sorted(str(b) for b in excluded_buses))}
Later slots must propose a different bus from earlier structurally valid proposals.
GLOBAL_STATE: {json.dumps(state,separators=(',',':'))}
Bus voltage observations are rounded to six decimal places for prompt serialization only.
GLOBAL_UNDERVOLTAGE_COUNT: {len(uv)}
CANDIDATE_BUSES_YOU_MAY_USE: {json.dumps(candidates)}
ALLOWED_Q_MVAR_VALUES: {ref.ALLOWED_Q}
FAILED_ACTIONS_TO_AVOID_SHORT: {json.dumps(failed,separators=(',',':'))}
VERIFIER_FEEDBACK_MEMORY:
{memory}
COMPACT_VERIFIER_REFLECTION_INSTRUCTION:
Use verifier feedback to revise your next proposal. Avoid rejected_hard_overvoltage actions.
Avoid weak_or_stalled actions unless no better candidate exists. Prefer candidate buses related to strong_fallback_examples_current_run when available.
For high-severity cases, prioritize global UV-count reduction over tiny local deficit changes.
SEVERITY_STAGE: {stage}
STAGE_RULE: {rule}
TASK:
If GLOBAL_UNDERVOLTAGE_COUNT > 0, choose exactly one bus from the candidate list and one q_mvar from the allowed list.
Do not return null. Do not use a bus outside the candidate list.
Return ONLY this JSON schema: {{"bus":"BUS_ID","q_mvar":Q_MVAR}}
Example: {{"bus":"52","q_mvar":150}}'''
    return [{'role':'system','content':'Return only valid JSON. No markdown. No prose. Use exactly the requested compact JSON schema.'},{'role':'user','content':body}],candidates
def fit_prompt(tokenizer,net,zones,runner,ref,feedback_state,failed_actions,slot,excluded_buses=()):
    attempts=[]
    for chars in [1200,900,600,300,0]:
        msgs,candidates=build_prompt(net,zones,runner,ref,feedback_state,failed_actions,slot,chars,excluded_buses)
        ids=tokenizer.apply_chat_template(msgs,tokenize=True,add_generation_prompt=True)
        n=len(ids);attempts.append({'memory_char_allowance':chars,'input_tokens':n})
        if n+GENERATION<=CONTEXT:
            return msgs,candidates,{'input_tokens_before_memory_reduction':attempts[0]['input_tokens'],'input_tokens':n,'generation_reserved':GENERATION,'context_limit':CONTEXT,'memory_char_allowance':chars,'memory_reduced':chars<1200,'physical_observation_truncated':False,'fit_attempts':attempts,'prompt_sha256':hashlib.sha256(json.dumps(msgs).encode()).hexdigest()}
    raise ValueError('Full central physical observation exceeds frozen 4096 context even without feedback memory; no physical observation silently truncated')
def build_central_runner(ref,runner):
    proposed_buses=set()
    def query(model,tokenizer,net,zone,zones,zone_state,global_uv,failed_actions,feedback_state,mode):
        if zone==sorted(zones)[0]:proposed_buses.clear()
        excluded=sorted(proposed_buses)
        msgs,candidates,fit=fit_prompt(tokenizer,net,zones,runner,ref,feedback_state,failed_actions,zone,excluded)
        if not global_uv:return None,{'valid_action':False,'valid_reason':'global_uv_zero','candidate_buses':candidates,'central_prompt':fit}
        if not candidates:return None,{'valid_action':False,'valid_reason':'global_candidate_pool_exhausted_by_prior_proposals','candidate_buses':candidates,'central_prompt':fit,'previous_proposal_buses':excluded}
        raw=runner.base_runner.generate_response(model,tokenizer,msgs);parsed,pv,pe=runner.base_runner.extract_json(raw);action=ref.normalize_compact_or_nested_action(parsed);valid,reason=runner.validate_action_against_candidates(action,candidates)
        info={'mode':'central_reflection_v2','candidate_buses':candidates,'raw':raw,'parsed':parsed,'parse_valid':pv,'parse_error':pe,'valid_action':valid,'valid_reason':reason,'reprompted':False,'central_prompt':fit,'proposal_slot':zone,'previous_proposal_buses':excluded,'diversity_policy':'exclude earlier structurally valid proposal buses in this iteration; physical verifier unchanged'}
        if valid:
            proposed_buses.add(str(runner.action_bus(action)));return action,info
        repair=[{'role':'system','content':'Return only valid JSON. No prose.'},{'role':'user','content':f'''Your previous answer was invalid.
Failure reason: {reason}
You must choose exactly one bus from this list: {candidates}
You must choose one q_mvar from this list: {ref.ALLOWED_Q}
Return exactly this JSON schema only: {{"bus":"BUS_ID","q_mvar":Q_MVAR}}
Example: {{"bus":"{candidates[0]}","q_mvar":100}}'''}]
        n=len(tokenizer.apply_chat_template(repair,tokenize=True,add_generation_prompt=True));assert n+GENERATION<=CONTEXT
        raw2=runner.base_runner.generate_response(model,tokenizer,repair);parsed2,pv2,pe2=runner.base_runner.extract_json(raw2);action2=ref.normalize_compact_or_nested_action(parsed2);valid2,reason2=runner.validate_action_against_candidates(action2,candidates)
        info.update(raw=raw2,parsed=parsed2,parse_valid=pv2,parse_error=pe2,valid_action=valid2,valid_reason=reason2,reprompted=True,first_raw=raw,first_parsed=parsed,first_valid_reason=reason,repair_input_tokens=n)
        if valid2:proposed_buses.add(str(runner.action_bus(action2)))
        return action2 if valid2 else None,info
    source=ref.run_one_scenario_two_best_v2;namespace=dict(source.__globals__);namespace['get_llm_action_required_two_best_v2']=query
    cloned=types.FunctionType(source.__code__,namespace,'run_central_context',source.__defaults__,source.__closure__)
    def run(**kwargs):
        proposed_buses.clear()
        kwargs['mode']='reflection_v2';result=cloned(**kwargs);result['method']='central_reflection_v2'
        zones=kwargs['zones']
        for row in result.get('logs',[])+result.get('executed_actions',[]):
            action=row.get('action');bus=runner.action_bus(action) if action else None
            if bus is not None:row['physical_bus_owner']=next((z for z,bs in zones.items() if int(bus) in bs),None)
            if row.get('llm_info',{}).get('proposal_slot') is not None:row['central_proposal_slot']=row['llm_info']['proposal_slot']
        result['central_ablation']={'proposal_slots':4,'maximum_primary_calls_per_iteration':4,'maximum_repair_calls_per_iteration':4,'max_new_tokens_each_call':GENERATION,'context_limit':CONTEXT,'original_control_loop_code_unchanged':cloned.__code__ is source.__code__,'frozen_zonal_lora':'Same saved adapter; architecture/context ablation conditional on this adapter, not centrally retrained model','metadata_note':'Legacy zone field identifies the original query-loop slot for central direct proposals; actual bus ownership is separately recorded as physical_bus_owner.'};return result
    return run
