"""Length-safe local atomic preservation; no network, model or solver API."""
import hashlib,os,uuid
from pathlib import Path

def extended(path):
    path=Path(path)
    if str(path).startswith(chr(92)*2+'?'+chr(92)):return path
    path=path.resolve()
    return Path(chr(92)*2+'?'+chr(92)+str(path)) if os.name=='nt' else path

def preserve(path,raw,expected_sha256):
    assert hashlib.sha256(raw).hexdigest()==expected_sha256,'Incoming payload hash mismatch'
    path=extended(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        assert path.stat().st_size==len(raw) and hashlib.sha256(path.read_bytes()).hexdigest()==expected_sha256,'Existing immutable payload differs'
        return
    tmp=path.parent/('p_'+uuid.uuid4().hex[:8]+'.tmp')
    with tmp.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    assert tmp.stat().st_size==len(raw)
    tmp.replace(path)
