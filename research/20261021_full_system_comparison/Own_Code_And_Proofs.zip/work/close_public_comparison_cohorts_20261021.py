"""Bind every existing author schedule row/input recipe; no new reset, model or PF."""
import collections,csv,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/full_system_comparison_20261021'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False)
def main():
    author=ROOT/'outputs/published_method_roster_addendum_20261020';saved=json.loads((author/'TPA_Author_Evaluation_Schedule.json').read_text(encoding='utf-8'));file=author/'TPA_author_test_data.csv'
    assert sha(file)==saved['sha256'];rows=list(csv.DictReader(file.read_text(encoding='utf-8').splitlines()));assert rows==saved['rows'] and len(rows)==120
    multiplicity=collections.Counter(tuple(r[k] for k in ['year','month','day','day_id','idx']) for r in rows);seen={};schedule=[]
    for index,row in enumerate(rows):
        key=tuple(row[k] for k in ['year','month','day','day_id','idx']);seen.setdefault(key,index)
        schedule.append({'schedule_index':index,'author_identity':row,'first_same_calendar_identity_row':seen[key],
                         'calendar_identity_multiplicity':multiplicity[key],
                         'row_case_id':'TPA322_author_row_'+str(index).zfill(3),
                         'physical_initial_state_digest':'PENDING_exact_native_reset_RNG_stream_and_solved_root',
                         'calendar_identity_alone_is_not_a_complete_physical_case':True,
                         'data_role':'Published development schedule;2012conditioning overlap disclosed, not unused confirmation',
                         'new_comparison_outcome':'UNKNOWN'})
    put(OUT/'All120_TPA_Source_Ordered_Rows.json',schedule)
    native=ROOT/'outputs/stable_ddpg_native500_input_roster_20261020';identities=json.loads((native/'All500_Ordered_Identities.json').read_text(encoding='utf-8'));audit=json.loads((native/'Independent_Input_Audit.json').read_text(encoding='utf-8'))
    assert audit['status'].startswith('PASS_ALL500_SOURCE_NATIVE') and [r['author_rep_seed'] for r in identities]==list(range(500))
    assert len({r['physical_vectors_sha256'] for r in identities})==500 and sha(native/'All500_Native_Physical_Input_Recipes.npz')==audit['arrays_sha256']
    put(OUT/'All500_Public13_Source_Input_Identities.json',identities)
    summary={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL_PUBLIC_SOURCE_SCHEDULE_ROWS_AND_RECIPE_IDENTITIES_RETAINED_NO_SCIENCE',
             'TPA_source_commit':saved['commit'],'TPA_rows':120,'TPA_unique_calendar_identity_tuples':len(multiplicity),
             'TPA_rows_by_year':dict(collections.Counter(r['year'] for r in rows)),
             'TPA_repeated_calendar_identity_rows':120-len(multiplicity),
             'TPA_repeated_rows_kept':'Same date/index is not permission to deduplicate or repeat science. Exact initialQ/RNG/input identity required before reuse or new query.',
             'public13_author_cases':500,'public13_source_regime_counts':{'low':audit['source_low_branch_count'],'high':audit['source_high_branch_count']},
             'exact_shared_physical_roots_and_actuator_ports':'STILL_REQUIRED_BEFORE_PERFORMANCE',
             'schedule_source_files':{str(p.relative_to(ROOT)):sha(p) for p in [file,author/'TPA_Author_Evaluation_Schedule.json',native/'All500_Ordered_Identities.json',native/'Independent_Input_Audit.json']},
             'all_new_forward_PF_optimizer_forecast_reset_solve_calls':0}
    put(OUT/'Public_Cohort_Closure.json',summary)
    print(json.dumps({k:summary[k] for k in ['TPA_rows','TPA_unique_calendar_identity_tuples','TPA_repeated_calendar_identity_rows','public13_author_cases','all_new_forward_PF_optimizer_forecast_reset_solve_calls']}))
if __name__=='__main__':main()
