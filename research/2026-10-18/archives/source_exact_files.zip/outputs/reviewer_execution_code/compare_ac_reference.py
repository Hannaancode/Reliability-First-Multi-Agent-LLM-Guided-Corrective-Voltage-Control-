"""Full-bank reference ledger; available-reference differences are descriptive."""
from pathlib import Path
from collections import Counter
import json,csv,hashlib
root=Path('outputs');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads(Path('work/e/bank/BANK_LOCK.json').read_text());paths=sorted((root/'ac_reference_campaign/cases').glob('*.json'))
assert {p.name for p in paths}==set(lock['scenario_file_sha256']),'All 62 reference records, including declared failures, required'
protocol=sha(root/'ac_reference_campaign_protocol.json');rows=[];counts=Counter();attempts=Counter()
for p in paths:
    d=json.loads(p.read_text());assert d['campaign_protocol_sha256']==protocol and d['scenario_sha256']==lock['scenario_file_sha256'][p.name]
    source=root/'matched_campaign/cases'/p.name;assert d['matched_case_sha256']==sha(source);main=json.loads(source.read_text());audit=json.loads((root/'physical_replay_audit/cases'/p.name).read_text());assert audit['identity']['saved_case_sha256']==sha(source)
    selected=d.get('selected_local_voltage_reference');row={'scenario_id':p.stem,'reference_status':d['reference_status'],'voltage_only_reference_available':selected is not None,'solver_starts_recorded':len(d.get('runs',[])),'slack_limit_excludes_full_operational_feasibility':d['declared_slack_necessary_condition']['declared_slack_p_limit_impossible_under_fixed_dispatch_and_fully_served_load']};counts[d['reference_status']]+=1
    for k,v in d['costs']['local_case_actual'].items():attempts['local_'+k]+=v;row['reference_local_'+k]=v
    row['reference_charged_total_pf_attempts']=d['costs']['charged_total_pf_attempts'];row['reference_source_DFF_previous_GPU_wall_seconds']=d['costs']['charged_warm_start_source_DFF']['wall_seconds']
    if selected:
        assert selected['strict_uv_zero_and_upper_band_within_1e8'] and selected['power_flow_converged'];t=selected['audit'];assert t['all_active_bus_voltages_finite'] and not t['unserved_or_mismatched_loads'] and not t['incremental_shunt_cap_violations']
        row['reference_nominal_support_mvar']=selected['nominal_support_mvar'];row['reference_realized_injection_mvar']=t['incremental_shunt_realized_mvar_total'];row['reference_padding_factor']=selected['factor'];row['reference_uv_strict']=selected['original_metrics']['uv_count'];row['reference_ov_strict']=selected['original_metrics']['ov_count'];row['reference_upper_violations_beyond_1e8']=t['voltage']['ov_beyond_1e8_tolerance']
    for method in ['D-SE','HG-SE']:
        if not main['paired_terminal_metrics_valid']:row[method+'_status']='invalid_pair_retained';continue
        branch=main['portfolios'][method]['selected_branch'];t=audit['branches'][branch]['states'][-1];v=t['voltage'];band=bool(t['all_active_bus_voltages_finite'] and not t['unserved_or_mismatched_loads'] and v['uv_strict']==0 and v['ov_beyond_1e8_tolerance']==0 and not t['incremental_shunt_cap_violations'])
        row[method+'_same_voltage_band_diagnostic_passes']=band;row[method+'_nominal_support_mvar']=t['incremental_shunt_nominal_mvar_total'];row[method+'_realized_support_mvar']=t['incremental_shunt_realized_mvar_total']
        if selected and band:row[method+'_nominal_support_minus_local_reference_mvar']=t['incremental_shunt_nominal_mvar_total']-selected['nominal_support_mvar']
    rows.append(row)
columns=list(dict.fromkeys(k for r in rows for k in r))
with (root/'ac_reference_controller_comparison.csv').open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
summary={'case_count':62,'campaign_protocol_sha256':protocol,'status_counts':dict(counts),'local_actual_costs_including_failed_cases':dict(attempts),'all_declared_slack_necessary_exclusions':sum(r['slack_limit_excludes_full_operational_feasibility'] for r in rows),'references_found':sum(r['voltage_only_reference_available'] for r in rows),'available_reference_subset_comparisons':{},'interpretation':'Continuous same-actuator local voltage reference, with discrete/sequence/eligibility relaxations; not certified optimum or full feasible AC-OPF. Support differences are descriptive endpoint comparisons, not optimality gaps. Comparisons require both controller and reference to pass finite/load-service/strict-UV plus the disclosed 1e-8 upper-band diagnostic. Missing local references and invalid controller outcomes remain in the full denominator. Failed solver status is not inferred infeasibility. CPU and source-GPU timing stay separate.'}
for method in ['D-SE','HG-SE']:
    key=method+'_nominal_support_minus_local_reference_mvar';rs=[r for r in rows if key in r];values=[r[key] for r in rs]
    summary['available_reference_subset_comparisons'][method]={'available_same_band_pairs':len(rs),'mean_controller_minus_reference_nominal_support_mvar':sum(values)/len(values) if values else None,'controller_lower_support_cases':sum(v<0 for v in values),'reference_lower_support_cases':sum(v>0 for v in values),'equal_support_cases':sum(v==0 for v in values),'scenario_ids':[r['scenario_id'] for r in rs]}
(root/'ac_reference_controller_comparison_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False));print(json.dumps(summary,indent=2))
