"""Reject incomparable or incomplete head-to-head records before any superiority score."""
import math
MATCH_KEYS=('cohort','case_id','physical_initial_state_sha256','solver_initialization_sha256',
            'plant_source_sha256','legal_actuator_contract_sha256','available_causal_information_sha256',
            'common_safety_contract_sha256','commitment_horizon','online_resource_allowance_sha256')
HASH_KEYS=tuple(k for k in MATCH_KEYS if k.endswith('sha256'))
def require_record(record):
    for key in MATCH_KEYS:
        if key not in record or record[key] in (None,'','PENDING','UNKNOWN'):raise ValueError('Missing comparison identity: '+key)
    for key in HASH_KEYS:
        value=record[key]
        if not isinstance(value,str) or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):raise ValueError('Exact hashed identity required: '+key)
    if record.get('status')!='COMPLETE_INDEPENDENTLY_VERIFIED_TRAJECTORY':raise ValueError('Counts, engineering or partials do not complete a trajectory')
    if record.get('source_role') not in ('NATIVE_UNCHANGED','EXPLICIT_PORT','EXPLICIT_RETRAINED_ADAPTATION'):raise ValueError('Controller role must be named')
    if not record.get('case_in_frozen_manifest') or not record.get('actual_policy_inference_preserved'):raise ValueError('Actual case/inference evidence required')
    if not record.get('continuous_independent_physics_replay') or not record.get('all_actual_costs_and_unknowns_disclosed'):raise ValueError('Replay and honest costs required')
    if not record.get('all_case_failures_and_unknowns_retained'):raise ValueError('Do not drop failed cases')
    for key in ('final_UV','final_OV'):
        if type(record.get(key)) is not int or record[key]<0:raise ValueError('Measured all-bus counts required')
    for key in ('final_vmin','final_vmax'):
        if not isinstance(record.get(key),(int,float)) or not math.isfinite(record[key]):raise ValueError('Finite measured voltage required')
    actual_safe=record['final_UV']==record['final_OV']==0 and record['final_vmin']>=.95 and record['final_vmax']<=1.05
    if record.get('full_band_restored') is not actual_safe:raise ValueError('UV-only success cannot become full-band restoration')
    return record
def paired(left,right):
    require_record(left);require_record(right)
    if left.get('controller_id')==right.get('controller_id'):raise ValueError('Two distinct identified methods required')
    for key in MATCH_KEYS:
        if left[key]!=right[key]:raise ValueError('Unmatched comparison field: '+key)
    return {'case_id':left['case_id'],'left_minus_right_UV':left['final_UV']-right['final_UV'],
            'left_minus_right_OV':left['final_OV']-right['final_OV'],
            'left_minus_right_full_restoration':int(left['full_band_restored'])-int(right['full_band_restored']),
            'single_case_only_no_aggregate_superiority':True}
