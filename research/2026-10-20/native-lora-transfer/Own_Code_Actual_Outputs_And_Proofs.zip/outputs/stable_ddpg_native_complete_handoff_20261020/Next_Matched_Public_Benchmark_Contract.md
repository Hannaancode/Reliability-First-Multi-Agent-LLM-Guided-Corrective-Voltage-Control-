# Public benchmark contract and remaining work

The official Stable-DDPG 13-bus source supplies 500 ordered stress-test input recipes. All 500 are now independently source-checked. Only seed 0 has executed physics in this study. Seeds 1–499 remain UNKNOWN. Source labels “low” and “high” describe the recipe branch, not measured voltage violations.

| System | Ownership | Actual evidence | Remaining comparison limit |
|---|---|---|---|
| Stable-DDPG | Other authors, TCNS 2023 | First native 13-bus episode, all 13 buses: 12→0 UV in 5 actions; continuous independent replay passed | Other 499 recipes unexecuted; historical training overlap unknown |
| Ordinary DDPG | Other authors, same implementation | Same first case, 12→0 UV in 3 actions; replay passed | Same scope limits |
| Linear policy module | Other authors, same implementation | Same first case, 12→0 UV in 5 actions; replay passed | This is the source module, not every possible linear controller |
| TPA | Other authors, KDD 2024 | Second ordered native 322-bus engineering input: 108→77 UV; first input partial retained | Different plant, history and seasonal information; no cross-feeder ranking |
| Current-Jacobian LP | Our code using established numerical methods | Same paid 322-bus root: 108→0 UV, original inverter caps; replay/LP checks passed | Centralized Ybus/current-state information differs from TPA; contains no LLM |
| Original trained HierGrid LoRA | Our preserved trained 0.5B adapter | First native-PI integration stopped before inference; six outputs UNKNOWN. A separately source-locked loader-order repair precedes the unentered generations | Explicit new serving/action contract; not unchanged original shunt controller or matched native training |

Before any aggregate performance owner, bind one exact system definition and its real loader, native action semantics, complete input and output parser, training exposure, measured inference cost and whole-episode preservation. A returned malformed command is reported as a command failure; it is not filled with a deterministic action or silently repaired. Explicit abstention remains separate. A runtime failure or unexecuted identity is UNKNOWN. A format pass alone cannot authorize an expensive whole benchmark.

A source-faithful baseline campaign would retain seed order 0–499 and all three source algorithms, reuse already paid seed-0 results and execute only genuinely unentered identities. Keep the original 100-step maximum and float32 increment clipping followed by PI subtraction. Report source completion at the three controlled buses AND UV/OV over every bus. A three-bus completion does not imply full-grid restoration. Do not replace either endpoint with a favourable stopping rule. Every unsafe, failed, partial, timed-out or unexecuted identity remains in the declared denominator with its status, rather than averaging only successes as the source plotting code does.

Prespecify all-bus final UV/OV, fully restored cases, voltage extrema, native completion, action counts, proposed and applied Q, solver exceptions, every model attempt, training/setup/query/physics/replay costs and total workflow time. Do not infer deployment speed from separate engineering runs or omit cold/replay/failure costs. Any claim of “our model is better” requires a matched cohort and controls; one native numerical win, other authors' restoration, or a new output schema does not establish it.

The original federation DFF, DFF-ALT and unchanged DSE remain a separate mandatory comparator on their original plant, raw scopes and protections, with both branches and full combined costs. A published inverter action cannot be silently substituted for original shunt stock/cap semantics. Historical inspected development examples are not unused confirmation.

This contract is planning and scope control only. It starts no model, PF, solver, training, GPU allocation or 500-case campaign. The actual bounded native-role transfer has its own earlier frozen protocol; its outputs cannot be used to rewrite that protocol. All six final goals remain open.
