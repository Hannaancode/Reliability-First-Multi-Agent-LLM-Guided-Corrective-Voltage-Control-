"""New local nonconvex AC shunt reference; historical development only.

Same voltage-dependent shunt actuator, fixed loads/P dispatch/gen setpoints,
original NR PF/Q-limit switching and slack convention. Continuous endpoint
relaxation, not a certified optimum or a 25-step/discrete reachable controller.
Voltage-only objective mirrors frozen rescue metrics. Declared operating limits
are independently audited, never silently claimed satisfied.
"""
from pathlib import Path
import argparse,copy,hashlib,json,sys,time,warnings,importlib.metadata as md
import numpy as np
import pandapower as pp
from scipy.optimize import minimize
from frozen_physics_loader import ROOT,load_stack
from physical_replay_audit import save,state_audit
warnings.filterwarnings('ignore');sys.stdout.reconfigure(encoding='utf-8',line_buffering=True)
def fixed_p_balance_lower_bound(net):
    load=sum(float(r.p_mw)*float(r.scaling) for _,r in net.load.iterrows() if r.in_service)
    gen=sum(float(r.p_mw)*float(r.get('scaling',1)) for _,r in net.gen.iterrows() if r.in_service and not r.get('slack',False))
    sgen=sum(float(r.p_mw)*float(r.scaling) for _,r in net.sgen.iterrows() if r.in_service)
    return {'scheduled_load_mw':load,'fixed_non_slack_generation_mw':gen+sgen,'required_slack_before_nonnegative_losses_mw':load-gen-sgen,'declared_ext_grid_max_p_mw_total':float(net.ext_grid.loc[net.ext_grid.in_service,'max_p_mw'].sum()),'assumption':'All scheduled load served, fixed active generation, nonnegative passive network real losses. Necessary active-power condition only.'}
def solve(scenario,initials,output,maximum_iterations=60):
    v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));original=base.shunt.index.copy();_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
    v2.v0.apply_scenario_to_net(base,scenario,zones);conv,err=v2.v0.run_pf(base)
    protocol={'formulation':'voltage-only continuous AC shunt endpoint reference; local NLP; independent declared-resource audit','eligible_buses':'all in-service network buses including generator buses','variables':'nominal capacitive shunt support q_b/450','bounds_mvar':[0,450],'nominal_total_budget_mvar':7500,'discrete_and_sequence_relaxation':'Original Q set and 25 sequential verifier steps not enforced; total <=25*300 and per-bus cap are necessary endpoint constraints only. Not a proven performance bound.','fixed_controls':['load scaling and P/Q','generator P and voltage setpoints','sgen P/Q','slack voltage and angle','topology','transformer taps','original shunts'],'power_flow':'original NR init auto enforce_q_lims True max_iteration 50','solver':'SciPy SLSQP; deterministic zero and historical DFF endpoint starts; restoration phase then minimum nominal support if independently feasible','solver_maxiter':maximum_iterations,'finite_difference_scaled_step':.001,'solver_ftol':1e-9,'independent_voltage_feasibility_tolerance_pu':1e-6,'retry':'exactly the declared starts; solver failure is not infeasibility','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'versions':{n:md.version(n) for n in ['numpy','scipy','pandapower','pandas','numba','networkx']}}
    report={'scenario_id':scenario['scenario_id'],'development_only':True,'protocol':protocol,'base_pf_converged':conv,'base_pf_error':err,'fixed_p_balance':fixed_p_balance_lower_bound(base),'runs':[]}
    if not conv:save(output,report);return report
    report['base_audit']=state_audit(base,original)
    if not report['base_audit']['all_active_bus_voltages_finite']:report['status']='invalid_initial_state';save(output,report);return report
    buses=[int(b) for b in base.bus.index[base.bus.in_service.astype(bool)]];report['bus_variable_order']=buses
    for label,nominal in initials:
        start=time.perf_counter();counts={'attempts':0,'returns':0,'failures':0};last={};original_json=pp.to_json(base)
        def evaluate(x):
            key=np.asarray(x,dtype=float).tobytes()
            if last.get('key')==key:return last['vm'],last['net']
            net=copy.deepcopy(base)
            runner.rescue.apply_action(net,{'add_shunts_q_mvar':{str(b):float(q*450) for b,q in zip(buses,x) if q>1e-12}})
            counts['attempts']+=1;ok,error=v2.v0.run_pf(net)
            if ok and np.isfinite(net.res_bus.loc[buses,'vm_pu']).all():counts['returns']+=1;vm=net.res_bus.loc[buses,'vm_pu'].to_numpy(float)
            else:counts['failures']+=1;vm=np.zeros(len(buses))
            last.update(key=key,vm=vm,net=net);return vm,net
        def residual(x):
            vm,_=evaluate(x);return float(1e4*np.sum(np.maximum(.95-vm,0)**2+np.maximum(vm-1.05,0)**2)+1e-9*np.sum(x))
        def voltage_constraints(x):
            vm,_=evaluate(x);return np.concatenate([vm-.95,1.05-vm])
        total={'type':'ineq','fun':lambda x:7500/450-np.sum(x)}
        x0=np.array([nominal.get(str(b),0)/450 for b in buses]);assert np.all((x0>=0)&(x0<=1)) and sum(x0)<=7500/450+1e-8
        print('AC_DEVELOPMENT_START',scenario['scenario_id'],label,len(buses),'variables',flush=True)
        trace=[]
        def callback(x):
            if len(trace)%5==0:print('AC_NLP_ITER',label,len(trace)+1,'voltage_residual',residual(x),'nominal_mvar',float(450*sum(x)),flush=True)
            trace.append({'iteration':len(trace)+1,'nominal_support_mvar':float(450*sum(x)),'voltage_residual_objective':residual(x)})
        restoration=minimize(residual,x0,method='SLSQP',bounds=[(0,1)]*len(buses),constraints=[total],callback=callback,options={'maxiter':maximum_iterations,'eps':.001,'ftol':1e-9})
        x=np.asarray(restoration.x);vm,_=evaluate(x);feasible=bool(np.isfinite(vm).all() and min(voltage_constraints(x))>=-1e-6 and total['fun'](x)>=-1e-6)
        minimum=None
        if feasible:
            last.clear();minimum=minimize(lambda y:float(np.sum(y)),x,method='SLSQP',bounds=[(0,1)]*len(buses),constraints=[total,{'type':'ineq','fun':voltage_constraints}],callback=callback,options={'maxiter':maximum_iterations,'eps':.001,'ftol':1e-9});x=np.asarray(minimum.x)
        # Independent fresh PF, with no cached optimizer state.
        last.clear();vm,net=evaluate(x);audit=state_audit(net,original) if bool(net.converged) else None
        valid=bool(audit and audit['all_active_bus_voltages_finite'] and not audit['unserved_or_mismatched_loads'] and min(voltage_constraints(x))>=-1e-6 and total['fun'](x)>=-1e-6 and not audit['incremental_shunt_cap_violations'])
        def summary(result):return None if result is None else {'success':bool(result.success),'status':int(result.status),'message':str(result.message),'iterations':int(result.nit),'function_evaluations':int(result.nfev),'objective':float(result.fun)}
        row={'initialization':label,'initial_nominal_support_mvar':float(sum(nominal.values())),'restoration_solver':summary(restoration),'minimum_support_solver':summary(minimum),'independently_voltage_feasible':valid,'status':'feasible_local_reference' if valid else 'no_feasible_reference_found_not_proof_of_infeasibility','nominal_support_mvar_by_bus':{str(b):float(q*450) for b,q in zip(buses,x) if q>1e-12},'independent_audit':audit,'pf_evaluations':counts,'wall_seconds':time.perf_counter()-start,'iterate_trace':trace}
        assert pp.to_json(base)==original_json,'Reference changed original stressed network'
        report['runs'].append(row);save(output,report);print('AC_DEVELOPMENT_SAVED',label,row['status'],counts,flush=True)
    return report
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--case',default='fed_combined_load_1p25_line_101_MG1');parser.add_argument('--maxiter',type=int,default=60);args=parser.parse_args()
    sf=ROOT/'pack/scenarios/federation'/f'{args.case}.json';locked={p.stem for p in (ROOT/'bank/scenarios').glob('*.json')};assert args.case not in locked
    saved=Path('outputs/historical_replay_result.json') if '1p5_' in args.case else Path('outputs/development_'+args.case+'_dff.json');dff=json.loads(saved.read_text());nominal={}
    for row in dff['executed_actions']:
        for b,q in row['action']['add_shunts_q_mvar'].items():nominal[str(b)]=nominal.get(str(b),0)+abs(float(q))
    solve(json.loads(sf.read_text()),[('zero',{}),('historical_dff_endpoint',nominal)],Path('outputs/ac_reference_development')/(args.case+'.json'),args.maxiter)
if __name__=='__main__':main()
