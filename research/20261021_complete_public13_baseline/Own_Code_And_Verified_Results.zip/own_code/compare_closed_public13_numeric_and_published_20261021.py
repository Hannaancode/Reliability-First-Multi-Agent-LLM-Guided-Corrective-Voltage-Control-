"""Predeclared post-terminal same500case physical comparison; no new science."""
import json,hashlib,pickle
from pathlib import Path
from datetime import datetime,timezone
from coordinate_native_inverter_linear_reference_20261020 import process
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_matched_numeric_preparation_20261021';O=R/'outputs/public13_matched_numeric_comparison_20261021'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False)
def source_Q_histories():
    rows={}
    for rel in ['outputs/public13_remaining_published_cohort_20261021/Failure.json','outputs/public13_missing_only_execution_20261021/Result.json']:
        for w in read(R/rel)['worlds']:
            for a in w['algorithms']:
                if a['status']=='COMPLETE_NATIVE_EPISODE':assert (w['seed'],a['algorithm']) not in rows;rows[(w['seed'],a['algorithm'])]=[s['absolute_Q_Mvar'] for s in a['steps']]
    first=read(R/'outputs/stable_ddpg_native_remaining_engineering_v2_20261020/Result.json');suffix=read(R/'outputs/stable_ddpg_native_episode_20261020/Result.json')
    for a in ['safe-ddpg','linear','ddpg']:rows[(0,a)]=[[[v] for v in next(x for x in first['results'] if x['algorithm']==a)['absolute_Q_Mvar']]]+[s['absolute_Q_Mvar'] for s in suffix['steps'] if s['algorithm']==a]
    return rows
def main():
    assert (R/'outputs/public13_matched_numeric_handoff_20261021/Completion.json').exists(),'Do not read live result as final'
    for rel,source in [('outputs/public13_matched_numeric_execution_20261021','run_public13_matched_numeric_20261021.py'),('outputs/public13_matched_numeric_independent_20261021','audit_public13_matched_numeric_20261021.py'),('outputs/public13_matched_numeric_handoff_20261021','coordinate_public13_matched_numeric_20261021.py')]:
        c=read(R/rel/'owner.claim');live=process(c['actual_pid']);assert not live or source not in (live.get('CommandLine') or '')
    for rel in ['outputs/public13_matched_numeric_coordination_20261021','outputs/public13_matched_numeric_reader_coordination_20261021']:
        end=read(R/rel/'End_ACK.json');assert end['actual_owned_chain_ended'] and end['exit_code']==0
    import stable_ddpg_native_bridge_20261020 as b
    from scipy.stats import binomtest
    np=b.np;audit=read(R/'outputs/public13_matched_numeric_independent_20261021/Independent_Audit.json');assert audit['status']=='PASS_EXACT500_AVAILABLE_NUMERICAL_POLICY_DENSE_EQUATIONS_DUALS_COLD_STATE_CONTINUOUS_PHYSICS_COST_AUDIT' and audit['full_fields_max_delta']<=1e-10
    actual=read(R/'outputs/public13_matched_numeric_execution_20261021/Result.json');native=read(R/'outputs/public13_native_cohort_assembly_20261021/Native_Cohort_Results.json');guarded=read(R/'outputs/public13_common_guard_saved_prefix_20261021/Saved_Common_Guard_Results.json');roots=read(P/'All500_Audited_Exact_Roots.json')['roots'];complete=actual['status']=='COMPLETE_ALL500_FROZEN_NUMERICAL_POLICY_EPISODES' and audit['all500_complete'];worlds={w['seed']:w for w in actual['worlds']};O.mkdir(exist_ok=False)
    native_rows={(r['case'],r['method']):r for r in native['rows']};guard_rows={(r['seed'],r['algorithm']):r for r in guarded['rows']};paired=[];methods=['safe-ddpg','linear','ddpg'];summaries={};qh=source_Q_histories()
    def effort(qrows,initial):
        q=np.asarray(initial,dtype=float).reshape(3);variation=0.;absolute_squared=0.;nonzero=0
        for value in qrows:
            nxt=np.asarray(value,dtype=float).reshape(3);variation+=float(np.sum(np.abs(nxt-q)));absolute_squared+=float(np.sum(nxt*nxt));nonzero+=int(np.any(nxt!=q));q=nxt
        return {'sum_absolute_deltaQ_Mvar':variation,'sum_per_round_absoluteQ_squared_Mvar2':absolute_squared,'nonzero_vector_updates':nonzero}
    for seed in range(500):
        ours=worlds.get(seed);known=bool(ours and ours['status'].startswith('COMPLETE_'));root=roots[seed];assert root['seed']==seed
        if ours:assert ours['exact_root_physical_signature']==root['physical_signature']
        v=np.asarray(root['all13_initial_vm']);kind='mixed' if (v<.95).any() and (v>1.05).any() else 'UV_only' if (v<.95).any() else 'OV_only' if (v>1.05).any() else 'within_band'
        row={'seed':seed,'input_stratum':kind,'ours_status':ours['status'] if ours else 'UNENTERED_UNKNOWN','ours':ours.get('final') if known else None,'ours_rounds':len(ours['steps']) if ours else None,'ours_accepted_decisions':sum(s['accepted'] for s in ours['steps']) if ours else None,'native':{a:{k:native_rows[(seed,a)][k] for k in ['UV','OV','full13band','actions','vmin','vmax']} for a in methods},'common_guard_prefix':{a:guard_rows[(seed,a)]['final'] for a in methods}}
        if known:
            accepted=[s['candidate_Q'] for s in ours['steps'] if s['accepted']];row['ours_effort']=effort(accepted,root['initial_control_Q']);row['ours_effort']['queried_candidate_rounds']=len(ours['steps']);row['ours_effort']['zero_increment_accepted_rounds']=sum(s['accepted'] and all(x==0 for x in s['native_u']) for s in ours['steps']);after=np.asarray(ours['final_vm']);row['maximum_strict_band_violation_pu']=float(np.max(np.maximum(np.maximum(.95-after,after-1.05),0)));row['strict_failure_within_1e_minus8_descriptive_only']=not ours['final']['full13band'] and row['maximum_strict_band_violation_pu']<=1e-8
        row['native_effort']={a:effort(qh[(seed,a)],root['initial_control_Q']) for a in methods};row['guarded_effort']={a:effort(qh[(seed,a)][:guard_rows[(seed,a)]['accepted_steps']],root['initial_control_Q']) for a in methods};paired.append(row)
    if complete:
        assert len(worlds)==500 and all(r['ours'] is not None for r in paired);ours=np.asarray([r['ours']['full13band'] for r in paired],dtype=np.int8);rng=np.random.default_rng(20261021);indices=rng.integers(0,500,size=(10000,500));tests=[]
        summaries['our_numerical']={'cases':500,'full13band':int(ours.sum()),'rate':float(ours.mean()),'sum_residual_UV':sum(r['ours']['UV'] for r in paired),'sum_residual_OV':sum(r['ours']['OV'] for r in paired),'accepted_decisions':sum(r['ours_accepted_decisions'] for r in paired),'strict_failures_within1e_minus8_NOT_reclassified':sum(r['strict_failure_within_1e_minus8_descriptive_only'] for r in paired)}
        for a in methods:
            other=np.asarray([r['native'][a]['full13band'] for r in paired],dtype=np.int8);delta=ours-other;win=int(((ours==1)&(other==0)).sum());loss=int(((ours==0)&(other==1)).sum());pvalue=float(binomtest(win,win+loss,p=.5,alternative='two-sided').pvalue) if win+loss else 1.;ci=np.quantile(delta[indices].mean(axis=1),[.025,.975]);tests.append({'comparator':a,'ours_only_restored':win,'other_only_restored':loss,'both_same':500-win-loss,'restoration_rate_difference':float(delta.mean()),'case_root_bootstrap95_percentile_interval':ci.tolist(),'two_sided_exact_discordant_binomial_p':pvalue});summaries[a]=native['methods'][a]
        last=0.
        for pos,index in enumerate(sorted(range(3),key=lambda i:tests[i]['two_sided_exact_discordant_binomial_p'])):
            last=max(last,min(1.,(3-pos)*tests[index]['two_sided_exact_discordant_binomial_p']));tests[index]['Holm_adjusted_family3_p']=last
        gate=all(t['restoration_rate_difference']>0 and t['case_root_bootstrap95_percentile_interval'][0]>0 and t['Holm_adjusted_family3_p']<.05 for t in tests)
        decision='PASS_LIMITED_NUMERICAL_FULL13_BAND_COMPARISON_VS_EACH_NATIVE_POLICY' if gate else 'FAIL_FIXED_NUMERICAL_PRIMARY_SUPERIORITY_GATE_NO_RETUNING'
    else:tests=[];decision='UNKNOWN_FULL500_NUMERICAL_RESULT_PARTIAL';summaries['our_numerical']={'cases_complete':sum(r['ours'] is not None for r in paired),'full500_metric':'UNKNOWN_NO_SELECTED_PREFIX_SCORE'}
    strata={}
    for label in ['UV_only','OV_only','mixed','within_band']:
        group=[r for r in paired if r['input_stratum']==label];strata[label]={'all_registered_cases':len(group),'our_fullband':sum(r['ours']['full13band'] for r in group) if complete else None,'native_fullband':{a:sum(r['native'][a]['full13band'] for r in group) for a in methods}}
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_SAME500_PHYSICAL_NUMERICAL_VS_PUBLISHED_COMPARISON' if complete else 'PARTIAL_COMPARISON_FULL_METRICS_UNKNOWN','fixed_gate':decision,'summaries':summaries,'primary_paired_tests':tests,'input_defined_strata_descriptive':strata,'all500_paired_rows':paired,'numeric_actual_primary_costs':actual['costs'],'numeric_actual_independent_costs':audit['actual_independent_costs'],'numeric_workflow_seconds':actual['workflow_seconds'],'reader_workflow_seconds':audit['workflow_seconds'],'common_guard_sensitivity':'Saved native episode prefix adapters retained for ALL500; no native stronger comparator replaced and no new live deployment claimed. Per-case results/efforts alongside native rows.','scoring':'Original strict0.95/1.05 preserved. No rounding/clipping/epsilon repair of measured voltages; near-boundary failures remain failures.','claim_scope':'System voltage-band comparison on this complete public13test, with centralized13VM/Y versus native localVM actor information and policy guard/stop differences explicit. Not same-information learning superiority, original paper full framework performance, universal dataset/method superiority or unused confirmation.','original_paper_HG_VF_HG_SE':'PENDING_SEPARATE_SOURCE_COMPATIBLE_PORT_NOT_THIS_NUMERICAL_METHOD','cost_scope':'Original root/source/model training/preparation/failure/all independent ledgers remain separate and additive. Reused labels/roots are not free. Workflow includesIO and preservation; intrinsic solver latency is UNKNOWN. Do not compare different cost ledgers as deployment speed.','all6goals':'OPEN','new_model_PF_derivative_optimizer_calls_by_analysis':0};put(O/'Matched_Comparison_And_Fixed_Decision.json',result)
    lines=['# Same-case numerical and published-controller comparison','',f"Status: {result['status']}",f"Fixed gate: {decision}",'','All500registered physical starting states, native three actuators and100round maximum. Voltage-band primary score uses every13bus.','', '| Controller | Full13band cases | Residual UV | Residual OV |','|---|---:|---:|---:|']
    if complete:
        z=summaries['our_numerical'];lines.append(f"| Our fixed numerical controller | {z['full13band']}/500 | {z['sum_residual_UV']} | {z['sum_residual_OV']} |")
    else:lines.append('| Our fixed numerical controller | UNKNOWN | UNKNOWN | UNKNOWN |')
    for a in methods:
        z=native['methods'][a];lines.append(f"| Published {a} | {z['full13_band_restored_on_complete']}/500 | {z['sum_UV_on_complete']} | {z['sum_OV_on_complete']} |")
    lines+=['','Our numerical controller uses global13bus measurements/currentY; published actors consume local voltages. Their unmodified rows remain primary references, and separately named common-guard prefix adapters are sensitivity rows. This is not an LLM/original-paper full-system score or equal-information attribution.','', 'All strict near-boundary failures, adverse cases, source exceptions and unknowns are retained. The original numerical method, guard and score were fixed before its outcomes. No result-driven retuning is authorized.'];(O/'Results_And_Next_Decision.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'fixed_gate':decision,'summaries':summaries}))
if __name__=='__main__':main()
