"""Single prospective numerical primary followed by its sole first reader."""
import os,json,subprocess
from pathlib import Path
from datetime import datetime,timezone
from public13_matched_numeric_engine_20261021 import put,sha
R=Path(__file__).resolve().parents[1];P=R/'outputs/public13_matched_numeric_preparation_20261021';O=R/'outputs/public13_matched_numeric_handoff_20261021'
def main():
    O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'at_utc':datetime.now(timezone.utc).isoformat()});p=json.loads((P/'Protocol.json').read_text())
    for n,h in p['source_and_input_hashes'].items():assert sha(R/n)==h
    for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
        with (O/(name+'.log')).open('x',encoding='utf-8') as f:
            code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
        put(O/(name+'.End.json'),{'exit_code':code,'at_utc':datetime.now(timezone.utc).isoformat()});assert code==0,'No automatic science or reader retry'
    put(O/'Completion.json',{'status':'NUMERICAL_PRIMARY_AND_SOLE_FIRST_READER_TERMINAL','at_utc':datetime.now(timezone.utc).isoformat()})
if __name__=='__main__':main()
