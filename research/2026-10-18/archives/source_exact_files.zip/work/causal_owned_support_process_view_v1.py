"""Whitelisted current process features; no policy/solver/model/launch.

The original serving text is preserved as a reference. Appending these NEW
experimental fields is not a reproduction of the historical serving contract.
No assertion of sufficient long-horizon information or policy value is made.
"""
import math
from paid_joint_commit_v2 import validate
from owned_bank_joint_reallocation_v1 import Q_GRID

def finite_or_unknown(value):
    value = float(value)
    return value if math.isfinite(value) else None

def build_process_view(net, cursor, shared_domain):
    validate(net, cursor)
    banks = []
    for owned in sorted(cursor['owned_bank_rows'], key=lambda row: row['index']):
        actual = net.shunt.loc[owned['index']]
        banks.append({'owned_bank_id': owned['index'], 'physical_bus_id': int(actual.bus),
            'nominal_capacitive_support_remaining_MVAr_nonnegative': -float(actual.q_mvar),
            'current_observed_bus_voltage_pu': float(net.res_bus.at[int(actual.bus),'vm_pu'])})
    generators = []
    for index, actual in net.gen.iterrows():
        if not bool(actual.in_service): continue
        bus = int(actual.bus); case = int(net['_pd2ppc_lookups']['bus'][bus])
        generators.append({'physical_bus_id': bus, 'current_PV_PQ_REF_case_code': int(net['_ppc']['bus'][case,1]),
            'observed_generator_Q_MVAr_signed_not_an_action': finite_or_unknown(net.res_gen.at[index,'q_mvar']),
            'generator_min_Q_MVAr': finite_or_unknown(actual.min_q_mvar),
            'generator_max_Q_MVAr': finite_or_unknown(actual.max_q_mvar)})
    return {'schema': 'CURRENT_OWNED_SUPPORT_PROCESS_VIEW_V1',
        'original_device_operation_budget': 25,
        'remaining_original_device_operations': cursor['remaining_original_device_operation_slots'],
        'ordinary_debit': 1, 'equal_owned_reallocation_debit': 2,
        'positive_action_magnitude_MVAr_grid': list(Q_GRID), 'positive_lifetime_cap_per_bus_MVAr': 450,
        'withdrawal_refunds_positive_lifetime_cap': False,
        'current_positive_lifetime_additions_MVAr': dict(sorted(cursor['positive_addition_lifetime_MVAr'].items())),
        'current_withdrawn_lifetime_MVAr': dict(sorted(cursor['withdrawn_lifetime_MVAr'].items())),
        'owned_support_banks': banks, 'current_generator_limit_observations': generators,
        'same_source_defined_receiver_domain_for_model_and_numeric': shared_domain['shared_raw_receivers_for_BOTH_controls'],
        'unknown_nonfinite_limits_are_null_never_imputed': True}
