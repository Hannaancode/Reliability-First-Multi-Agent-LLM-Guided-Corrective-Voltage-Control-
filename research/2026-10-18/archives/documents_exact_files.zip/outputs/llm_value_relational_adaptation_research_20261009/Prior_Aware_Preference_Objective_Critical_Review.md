# Decision on a prior-aware language policy

This is a mathematical and prior-art review while the separately owned numerical measurement runs. It freezes no model objective, hyperparameter, decoder or training study. It changes no live sources or scientific settings. The next method decision still requires the final independently audited strong numerical evidence.

The useful question is whether a genuine language policy can correct errors of a strong physical numerical prior while preserving its good decisions. Replacing another numerical prediction head with an LLM name does not answer that question. Earlier failed structured-head/internal-residual studies stay stopped.

## Closest additional primary sources

| Primary work | Relevant result or design | Limit for HierGrid |
|---|---|---|
| [SimPO, Meng et al.](https://arxiv.org/html/2405.14734v3), sections 2 and appendix A | Optimizes length-normalized sequence likelihood with a target preference margin. Discusses mismatch between DPO implicit rewards and decoding, and notes reasoning-task degradation and safety limitations. | A change to a decoding-aligned objective is established prior art. Chat benchmarks do not prove protected grid recovery. Its margin tuning cannot be imported as an outcome-driven sweep here. |
| [ODPO, Amini et al.](https://arxiv.org/html/2402.10571v2), section 5 and limitations | Uses an offset derived from preference strength; studies how offset scaling depends on the task. | Adding a physics-derived margin is not automatically novel. Our lexicographic score supplies order, not a unique calibrated scalar strength. |
| [Cal-DPO, Xiao et al.](https://arxiv.org/html/2412.14516v1), section 4.1 | Adds reward-scale calibration to a contrastive policy/reference objective. Discusses why relative preference improvement alone need not increase chosen-response likelihood. | We cannot present numerical voltage/UV/deficit/Q units as commensurate rewards without a justified target definition. Pairwise labels do not become certified success probabilities. |
| [ORPO, Hong et al.](https://arxiv.org/html/2403.07691v2), section 4 | Combines supervised token likelihood and an odds-ratio preference term without an additional reference model. | Token-level domain adaptation and preferences already have joint objectives. Reported NLP results and resource settings do not establish feasibility or effectiveness on our full contexts and T4s. |

The earlier [DPO paper](https://arxiv.org/html/2305.18290v3), residual-policy/SPIBB review, and grid AC-feedback DPO precedent remain relevant. These papers motivate tests, not novelty, a90%success probability or superiority to literal D-SE. ODPO is especially important: a margin/offset addition by itself cannot be the proposed new scientific contribution.

## Our algebra: what a composite policy actually optimizes

For a finite, exactly scope-valid action set A(s), suppose a separately justified numerical distribution pN(a|s) is strictly positive. Let ellTheta and ellRef be log likelihoods of the same canonical action string under a copied trainable language policy and its frozen reference. Define the residual dTheta=ellTheta-ellRef and

    qTheta(a|s) = pN(a|s) exp(dTheta(a|s)) / ZTheta(s).

If the copied and reference models are genuinely identical, dTheta=0 and qTheta=pN. This is a mathematical initialization identity. It still requires real tokenizer/template/context/adapter/dropout/CUDA/reload gates; it says nothing about learned quality or safety. The numerical prior's actual definition, ties, failed or unavailable forecasts and normalization have not been chosen. Missing original outputs must not be reconstructed or silently assigned predicted truth.

For a preferred action w and another action l, write DeltaN=log pN(w)-log pN(l), DeltaD=dTheta(w)-dTheta(l). The composite policy margin is

    log qTheta(w)-log qTheta(l) = DeltaN + DeltaD.

Standard DPO relative to pN instead uses

    [log qTheta(w)-log pN(w)] - [log qTheta(l)-log pN(l)] = DeltaD.

The normalizer and numerical prior cancel. At identical initialization every pair has DPO margin0, irrespective of whether the strong numerical prior already ranks it correctly. Thus multiplying by a numerical prior only at decoding does not itself make DPO train preferentially on that prior's errors.

An alternative hypothesis is an absolute composite Bradley–Terry objective:

    Lpair = softplus(-beta (DeltaN + DeltaD))
    L = weighted mean(Lpair) + lambda KL(qTheta || pN).

Its derivative with respect to DeltaD is -beta sigmoid(-beta(DeltaN+DeltaD)). At initialization it depends on the numerical margin. In fabricated beta1 examples an incorrectly ordered9:1 pair has gradient-.9, whereas a correctly ordered9:1 pair has gradient-.1. All pairs remain in training; none must be selected afterward because it happens to be favorable.

This is a possible error-sensitive policy loss, not standard DPO's KL-regularized reward derivation. It is ordinary residual/logistic machinery; no novel theorem or improvement guarantee is asserted. It needs comparison with ODPO, SimPO, Cal-DPO, ORPO and a strong numerical residual preference learner. beta, lambda, rank-to-probability scaling, unknown-mass handling and token normalization remain unchosen. They must be justified and prospectively fixed before held evaluation, not searched until a win appears.

At initialization the KL value and its first derivative vanish when qTheta=pN. Later it can penalize departure from the finite numerical policy. Such a penalty does not enforce voltage limits, solver convergence, correct sparse labels, trajectory recovery or preservation of individual decisions. A favourable pair margin can coexist with a worse action ranking; an unmeasured third action can outrank the entire observed pair.

## What the new scalar proofs demonstrate

The accompanying script uses explicitly fabricated probabilities and elementary scalar math. It checks initialization, prior cancellation, the error-sensitive gradient with a finite-difference check, normalization invariance, zero-mass rejection, and two counterexamples. It performs zero model, optimizer, PF, controller, derivative, linear-solve, training or cloud calls. These are algebra/interpretation checks, not learned performance evidence.

In one counterexample the preferred action's policy/reference log-ratio improves relative to the other action, yet the preferred action still has the smaller policy probability. In another, the known-pair loss is below1e-5 while an unmeasured third action remains top ranked. These facts prevent using loss decrease or reward-margin accuracy as a surrogate for the actual K1/4/8/physical gates.

## Requirements if the final numerical evidence justifies further design

1. Define the strong numerical prior from complete available measurements without weakening either numerical comparator. Retain all missing/unexecuted/nonphysical cases and conservative uncertainty. Never use a favourable prefix as the evaluation set.
2. Use language-native, canonical action likelihoods if testing language adaptation. Measure suffix tokenization, legal membership, variable token length and finite-policy normalization. A new projection head is not evidence that original language abilities improved.
3. Keep current state/action inputs causal. World/branch IDs, AFTER, labels and numerical outcomes may enter the administrative training loss but never the language/current-state forward. Supply identical legitimate current information and priors to strong non-LLM preference controls.
4. Predeclare world/state weighting, one justified objective and budget, original copied-weight initialization, one seed, final checkpoint and all invalid/failure denominators. Include a frozen-reference/no-body-update comparison and meaningful architecture/pretraining attribution. Failed earlier arms cannot be relaunched under changed labels.
5. Charge actual reference and trainable language forward/backward/token/cache/recomputation/optimizer/checkpoint/reload/setup/transfer/failure costs. A reference-based composite policy is not reference-free merely because SimPO or ORPO is cheaper in its own setting. No T4 feasibility or training duration is claimed from this algebra.
6. Evaluate exact emitted actions and physical outcomes, not just logits, loss or scalar fit. A saved-label development gain permits only a separate fresh matched physical study with common verifier/normal guard/raw scopes, both-branch literal D-SE costs, independent continuous replay, and genuinely unused confirmation.

The research conclusion is to reject a bare offset/prior-product novelty claim and retain an absolute composite policy loss only as a hypothesis needing further derivation and controlled evidence. No new GPU/training/physical campaign is ready from this review. Validated incremental LLM value and D-SE superiority remain unachieved.
