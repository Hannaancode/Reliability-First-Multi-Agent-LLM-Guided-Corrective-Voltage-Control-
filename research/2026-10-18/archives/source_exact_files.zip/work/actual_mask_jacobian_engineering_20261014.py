"""Four newly specified final-solver-mask Jacobians from paid derivatives.

Original displayed-label guidance/MILP remain executed and stopped. No old
derivative, forecast, PF or model rerun; new4 LU factors/4 solves are charged.
No prediction ranking or physical/learning performance study is launched.
"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import inspect
import json
import os
import sys
import time
import numpy as np
import scipy
from scipy.linalg import lu_factor,lu_solve
import pandapower as pp
import pandapower.pf.run_newton_raphson_pf as native
from joint_reallocation_opportunity_core_v1 import load_endpoint

R=Path(__file__).resolve().parents[1]
B=R/'outputs/actual_mask_jacobian_engineering_20261014'
OLD=R/'outputs/critical_research_reset_20261010/equal_reallocation_opportunity_20261012'
MASK=R/'outputs/actual_solver_mask_namespace_metadata_v2_20261014'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def blocked(*a,**k):raise AssertionError('No new PF, public derivative or forecast in this engineering')
def block_physics():
    for n in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,n,blocked)

def root_data():
    old=read(OLD/'preparation/Protocol.json');out=[]
    for i,e in enumerate(old['current_endpoints'],1):
        net,_,_=load_endpoint(e);inner=net['_ppc']['internal'];file=OLD/'actual'/f'W{i}_Current_Jacobian.npz'
        with np.load(file,allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
        # The complete derivative mathematical inputs are exactly the prior paid
        # ones. Reuse m/a without calling their scientific derivative routine.
        assert np.array_equal(c['Y'],inner['Ybus'].toarray())
        assert np.array_equal(c['V'],inner['V'])
        assert np.array_equal(c['mapping'],net['_pd2ppc_lookups']['bus'])
        ref=np.array(inner['ref'],dtype=int);pv=np.array(inner['pv'],dtype=int);pq=np.array(inner['pq'],dtype=int)
        assert len(ref)==1 and len(ref)+len(pv)+len(pq)==118
        assert len(set(ref)|set(pv)|set(pq))==118
        assert inner['J'].shape==(len(pv)+2*len(pq),)*2
        nr=np.array(sorted(set(pv)|set(pq)),dtype=int)
        out.append({'world':e['world'],'index':i,'old':c,'ref':ref,'pv':pv,'pq':pq,'nr':nr,
                    'baseMVA':float(net['_ppc']['baseMVA']),'native_J_shape':list(inner['J'].shape)})
    return out

def matrices(d):
    c=d['old'];m=c['m'];a=c['a'];nr=d['nr'];pq=d['pq'];mapping=c['mapping'];V=c['V']
    J=np.block([[a.real[np.ix_(nr,nr)],m.real[np.ix_(nr,pq)]],
                [a.imag[np.ix_(pq,nr)],m.imag[np.ix_(pq,pq)]]])
    rhs=np.zeros((len(J),118));pos={int(i):j for j,i in enumerate(pq)}
    for bus,k in enumerate(mapping):
        if int(k) in pos:rhs[len(nr)+pos[int(k)],bus]=abs(V[k])**2/d['baseMVA']
    assert np.isfinite(J).all() and np.isfinite(rhs).all()
    assert list(J.shape)==d['native_J_shape']
    return J,rhs

def prepare():
    B.mkdir(exist_ok=False);block_physics()
    cert=read(MASK/'audit/Independent_Actual_Mask_Namespace_Audit.json')
    assert cert['status'].startswith('PASS_ALL34_') and cert['actual_input_namespace_contract'].startswith('FAIL_')
    roots=root_data();names=[Path(__file__),Path(inspect.getsourcefile(native)),R/'work/joint_reallocation_opportunity_core_v1.py',
        MASK/'Protocol.json',MASK/'audit/Independent_Actual_Mask_Namespace_Audit.json',OLD/'preparation/Protocol.json']
    old=read(OLD/'preparation/Protocol.json')
    for i,e in enumerate(old['current_endpoints'],1):
        ep=R/e['endpoint_record'];rec=read(ep)
        names += [ep,R/e['decoded_net_container_root']/rec['endpoint']['path'],OLD/'actual'/f'W{i}_Current_Jacobian.npz']
    dimensions=[]
    for d in roots:
        J,rhs=matrices(d)
        assert not np.array_equal(d['old']['PQ'],d['pq'])
        # Block assembly and identity preparation are not factor/solve calls.
        dimensions.append({'world':d['world'],'actual_J_shape':list(J.shape),'RHS_shape':list(rhs.shape),
            'actual_nr':d['nr'].tolist(),'actual_PQ':d['pq'].tolist(),
            'old_wrong_J_shape':list(d['old']['J'].shape),
            'new_J_sha256':hashlib.sha256(J.tobytes()).hexdigest(),
            'same_old_derivative_Y_V_exact':True,'new_numerical_input_is_not_old_J':J.shape!=d['old']['J'].shape})
    put(B/'Protocol.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'purpose':'Validate new source-bound actual-final-mask Jacobian assembly, basis and finite response for a future nonlinear receding control, preserving the previous wrong-mask scientific results.',
        'all_four_worlds':[d['world'] for d in roots],'declared_new_matrix_inputs':dimensions,
        'source_input_sha256':{str(p.relative_to(R)):sha(p) for p in names},
        'numpy':np.__version__,'scipy':scipy.__version__,
        'resource_bound_seconds':120.,'new_LU_factors':4,'new_LU_solves':4,'RHS_columns_total':472,
        'old_public_derivative_outputs_reused':4,'new_public_derivative_calls':0,
        'context':'Actual final inner.ref/pv/pq from solved native process; displayed restored case labels not accepted as that namespace.',
        'engineering_gate':'All4 exact input/Y/V/actual-set/axis/J-shape/source pins; finite solutions and maxabs(JX-B)<=1e-8; original reference/PV magnitude response rowszero. Reader independently checks all equations and bases with0solves.',
        'no_model_PF_forecast_optimizer_or_old_numerical_replay':True,
        'original_wrong_mask_guidance_primary_MILP_gate':'PRESERVED_FAILED_STOPPED_NOT_REPAIRED_OR_RERUN',
        'hypothesis_performance_or_novelty':'NOT_TESTED; a correct current mask still does not forecast future active regimes or certify nonlinear protected trajectories.',
        'no_automatic_model_or_physical_or_MILP_performance_launch':True})
    put(B/'Prepared_Input_Closure.json',{'all4_exact_new_J_input_identities':dimensions,
        'new_public_derivative_LU_factor_solve_PF_model_calls':0})
    print(json.dumps({'prepared':str(B),'new_factor_solve_calls':0,'old_derivatives_exactly_reused':4}))

def pins():
    p=read(B/'Protocol.json')
    assert p['numpy']==np.__version__ and p['scipy']==scipy.__version__
    for name,h in p['source_input_sha256'].items():assert sha(R/name)==h,name
    return p

def own(mode):
    out=B/mode;out.mkdir(exist_ok=False)
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),
        'protocol_sha256':sha(B/'Protocol.json'),'argv':sys.argv})
    return out

def log(out,event,data):
    with (out/'Attempt_Return_Journal.jsonl').open('a',encoding='utf-8') as f:
        f.write(json.dumps({'event':event,'data':data},allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())

def worker():
    p=pins();out=own('actual');block_physics();start=time.perf_counter();rows=[]
    cost={'LU_factor_attempts':0,'LU_factor_returns':0,'LU_solve_attempts':0,'LU_solve_returns':0,'RHS_columns':0,
          'public_derivative_calls':0,'model_PF_forecast_training_calls':0,'numerical_factor_and_solve_seconds':0.}
    try:
        for d in root_data():
            assert time.perf_counter()-start<p['resource_bound_seconds']
            J,rhs=matrices(d);index=d['index'];declared=p['declared_new_matrix_inputs'][index-1]
            assert declared['world']==d['world'] and hashlib.sha256(J.tobytes()).hexdigest()==declared['new_J_sha256']
            log(out,'factor_attempt',{'world':d['world'],'new_J_sha256':declared['new_J_sha256']});cost['LU_factor_attempts']+=1
            t=time.perf_counter();factor=lu_factor(J,check_finite=True);cost['LU_factor_returns']+=1
            log(out,'factor_return',{'world':d['world']})
            log(out,'solve_attempt',{'world':d['world'],'RHS_columns':118});cost['LU_solve_attempts']+=1
            X=lu_solve(factor,rhs,check_finite=True);cost['LU_solve_returns']+=1;cost['RHS_columns']+=118
            cost['numerical_factor_and_solve_seconds']+=time.perf_counter()-t
            log(out,'solve_return',{'world':d['world'],'RHS_columns':118})
            residual=float(np.max(np.abs(J@X-rhs)));assert np.isfinite(X).all() and residual<=1e-8
            S=np.zeros((118,118));S[d['pq'],:]=X[len(d['nr']):,:];S=S[d['old']['mapping'],:]
            mappedfixed=[i for i,k in enumerate(d['old']['mapping']) if k in set(d['ref'])|set(d['pv'])]
            assert not mappedfixed or np.array_equal(S[mappedfixed],np.zeros((len(mappedfixed),118)))
            np.savez_compressed(out/f'W{index}_Actual_Final_Mask_Context.npz',J=J,B=rhs,X=X,sensitivity=S,
                mapping=d['old']['mapping'],V=d['old']['V'],Y=d['old']['Y'],m=d['old']['m'],a=d['old']['a'],
                actual_ref=d['ref'],actual_PV=d['pv'],actual_PQ=d['pq'],nonref=d['nr'],
                current_vm=d['old']['current_vm'],baseMVA=d['baseMVA'])
            rows.append({'world':d['world'],'actual_PQ_count':len(d['pq']),'new_J_shape':list(J.shape),
                'residual':residual,'context_file':f'W{index}_Actual_Final_Mask_Context.npz',
                'same_paid_derivative_input_Y_V':True,'old_false_mask_source_and_costs_retained':True})
        put(out/'Result.json',{'exit_code':0,'all4_actual_mask_engineering':'PASS','worlds':rows,
            'actual_costs':cost,'workflow_seconds':time.perf_counter()-start,
            'performance_DSE_LLM_advantage_nonlinear_safety':'UNKNOWN_NOT_MEASURED'})
        put(out/'Closed_Manifest.json',{'files':{f.name:sha(f) for f in out.iterdir() if f.is_file()}})
        print(json.dumps({'actual_mask_engineering':'PASS','new_factor_returns':4,'new_solve_returns':4,'newPF_model_derivative_calls':0}))
    except BaseException as e:
        put(out/'Failure.json',{'type':type(e).__name__,'message':str(e),'costs':cost,'closed_worlds':rows,
                              'unexecuted_worlds_UNKNOWN':p['all_four_worlds'][len(rows):],'no_scientific_retry':True})
        raise

def audit():
    p=pins();out=own('audit');block_physics()
    result=read(B/'actual/Result.json');assert result['exit_code']==0
    for name,h in read(B/'actual/Closed_Manifest.json')['files'].items():assert sha(B/'actual'/name)==h
    rows=[]
    for d,r in zip(root_data(),result['worlds']):
        assert d['world']==r['world']
        with np.load(B/'actual'/r['context_file'],allow_pickle=False) as f:z={k:f[k] for k in f.files}
        assert np.array_equal(z['actual_PQ'],d['pq']) and np.array_equal(z['actual_PV'],d['pv']) and np.array_equal(z['actual_ref'],d['ref'])
        assert np.array_equal(z['m'],d['old']['m']) and np.array_equal(z['a'],d['old']['a'])
        # Independent element-by-element indexing and RHS definition; no solve.
        nr=z['nonref'];pq=z['actual_PQ'];m=z['m'];a=z['a'];J=z['J'];rhs=z['B'];n=len(nr)
        assert np.array_equal(J[:n,:n],a.real[np.ix_(nr,nr)])
        assert np.array_equal(J[:n,n:],m.real[np.ix_(nr,pq)])
        assert np.array_equal(J[n:,:n],a.imag[np.ix_(pq,nr)])
        assert np.array_equal(J[n:,n:],m.imag[np.ix_(pq,pq)])
        expected=np.zeros_like(rhs);where={int(i):j for j,i in enumerate(pq)}
        for b,k in enumerate(z['mapping']):
            if int(k) in where:expected[n+where[int(k)],b]=abs(z['V'][k])**2/float(z['baseMVA'])
        assert np.array_equal(rhs,expected) and np.max(np.abs(J@z['X']-rhs))<=1e-8
        original=np.zeros((118,118));original[pq,:]=z['X'][n:,:]
        assert np.array_equal(z['sensitivity'],original[z['mapping'],:])
        rows.append({'world':d['world'],'matrix_shape':list(J.shape),'residual':r['residual']})
    assert [x['world'] for x in rows]==p['all_four_worlds']
    calls=[json.loads(x) for x in (B/'actual/Attempt_Return_Journal.jsonl').read_text().splitlines()]
    for event in ['factor_attempt','factor_return','solve_attempt','solve_return']:
        assert [x['data']['world'] for x in calls if x['event']==event]==p['all_four_worlds']
    c=result['actual_costs'];assert all(c[k]==4 for k in ['LU_factor_attempts','LU_factor_returns','LU_solve_attempts','LU_solve_returns']) and c['RHS_columns']==472
    put(out/'Independent_Actual_Mask_Engineering_Audit.json',{'status':'PASS_ALL4_EXACT_PAID_DERIVATIVE_REUSE_FINAL_NATIVE_MASK_AXES_RESPONSE_AND_COSTS',
        'all_four_worlds':rows,'actual_new_costs':c,'worker_workflow_seconds':result['workflow_seconds'],
        'reader_new_PF_model_derivative_factor_solve_forecast_calls':0,
        'engineering_is_not_policy_performance_or_LLMvalue':True,'old_guidance_primary_MILP_failure_preserved':True,
        'no_automatic_rollout_training_or_repeated_primary_forecast':True})
    put(out/'Result.json',{'exit_code':0,'independent_engineering_audit':'PASS'})
    print(json.dumps({'independent_actual_mask_engineering_audit':'PASS','newreader_model_PF_numericalsolver_calls':0}))

if __name__=='__main__':
    cli=argparse.ArgumentParser()
    for n in ('prepare','worker','audit'):cli.add_argument('--'+n,action='store_true')
    args=cli.parse_args();assert sum(vars(args).values())==1
    if args.prepare:prepare()
    elif args.worker:worker()
    else:audit()
