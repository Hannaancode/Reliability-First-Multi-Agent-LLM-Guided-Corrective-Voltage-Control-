"""One new source/admission delta check. No worker, freeze, imports smoke or science."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import tokenize

R=Path(__file__).resolve().parents[1]
O=R/'outputs/nonlinear500_receding_acquisition_v2_source_preparation_20261030'
sys.path.insert(0,str(R/'work'))
import nonlinear500_isolated_owner_runtime_20261030 as gate

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return dict(path=p.relative_to(R).as_posix(),sha256=sha(p),bytes=p.stat().st_size)
def tree(p):
 with tokenize.open(p) as f:return ast.parse(f.read())
def dump(t):return ast.dump(t,include_attributes=False)
def put(name,value):
 with (O/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')

class NormalizeOwnerDelta(ast.NodeTransformer):
 def visit_Constant(self,node):
  if isinstance(node.value,str):
   for suffix in ('preparation','execution','coordination','independent','reader_coordination','handoff'):
    node.value=node.value.replace('nonlinear500_receding_acquisition_v2_'+suffix+'_20261030','nonlinear500_receding_acquisition_'+suffix+'_20261030')
   node.value=node.value.replace('nonlinear500_receding_acquisition_v2_20261030','nonlinear500_receding_acquisition_20261030')
  return node
 def visit_ImportFrom(self,node):
  if node.module=='nonlinear500_isolated_owner_runtime_20261030':return None
  return self.generic_visit(node)
 def visit_Assign(self,node):
  if len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='runtime_admission':return None
  return self.generic_visit(node)
 def visit_Dict(self,node):
  keep=[i for i,k in enumerate(node.keys) if not isinstance(k,ast.Constant) or k.value!='isolated_owner_runtime_admission']
  node.keys=[node.keys[i] for i in keep];node.values=[node.values[i] for i in keep]
  return self.generic_visit(node)
 def visit_Call(self,node):
  node.keywords=[k for k in node.keywords if k.arg!='isolated_owner_runtime_admission']
  return self.generic_visit(node)

def main():
 oldref=ref(R/gate.OLD_PROTOCOL)
 previous=dict(failed_protocol=oldref,
  independent_failure_diagnosis=ref(R/'outputs/nonlinear500_acquisition_setup_failure_20261030/Independent_Diagnosis.json'),
  fresh_terminal_absence=ref(R/'outputs/nonlinear500_acquisition_setup_failure_20261030/Fresh_Terminal_Source_Absence.json'),
  old_study_never_restarted=True,original_authenticated_chain_end='UNKNOWN_RETAINED_UNCHANGED')
 old=gate.validate_previous_setup(R,previous)
 certref=ref(R/'outputs/nonlinear500_actual_runtime_admission_20261030/Result.json')
 cert=json.loads((R/certref['path']).read_text(encoding='utf-8'))
 spec=dict(directory=gate.DEPENDENCY_DIRECTORY,package='psutil',version='7.2.2',official_wheel=ref(R/gate.WHEEL_FILE),
  actual_runtime_certificate=certref,actual_runtime_admission_source=ref(R/'work/check_acquisition_actual_runtime_20261030.py'),
  source_files=cert['isolated_dependency_sources'])
 sources=dict(old['sources']);sources.update(spec['source_files'])
 sources[spec['actual_runtime_admission_source']['path']]=spec['actual_runtime_admission_source']['sha256']
 for row in cert['imports'].values():sources[Path(row['file']).relative_to(R).as_posix()]=row['sha256']
 gate.validate_runtime_spec(R,spec,sources,expected_executable=R/'work/physics_env/Scripts/python.exe')
 checks=['real_saved_failure_absence_and_runtime_source_pins_accept_without_importing_runtime']
 bad=copy.deepcopy(spec);bad['version']='7.2.3'
 try:gate.validate_runtime_spec(R,bad,sources)
 except ValueError:checks.append('unreviewed_runtime_version_rejected')
 else:raise AssertionError('Wrong version admitted')
 bad_sources=dict(sources);bad_sources[next(iter(spec['source_files']))]='0'*64
 try:gate.validate_runtime_spec(R,spec,bad_sources)
 except ValueError:checks.append('changed_runtime_source_pin_rejected')
 else:raise AssertionError('Wrong bytes admitted')
 rows=[]
 for relative,digest in old['sources'].items():
  path=R/relative
  assert sha(path)==digest,relative
  if path.suffix=='.py':
   rows.append(dict(path=relative,old_frozen_sha256=digest,current_sha256=sha(path),
    ast_sha256=hashlib.sha256(dump(tree(path)).encode()).hexdigest(),
    invariant='AST unchanged because entire current source bytes equal original frozen SHA256'))
 checks.append('every_old_frozen_source_byte_exact_and_all_python_AST_hashes_recorded')
 deltas=[]
 for stem in ('run','audit','coordinate'):
  before=R/f'work/{stem}_nonlinear500_receding_acquisition_20261030.py'
  after=R/f'work/{stem}_nonlinear500_receding_acquisition_v2_20261030.py'
  assert dump(tree(before))==dump(NormalizeOwnerDelta().visit(tree(after))),stem
  deltas.append(dict(original=ref(before),additive=ref(after),
   AST_equal_after_only_declared_path_runtime_gate_and_runtime_evidence_changes=True))
 checks.append('three_owner_reader_coordinator_AST_deltas_limited_to_declared_changes')
 def settings(t):
  assignments=[n for n in ast.walk(t) if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='p' and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict']
  assert len(assignments)==1
  return {k.arg:dump(k.value) for k in assignments[0].value.keywords}
 before=settings(tree(R/'work/freeze_nonlinear500_receding_acquisition_20261030.py'))
 after=settings(NormalizeOwnerDelta().visit(tree(R/'work/freeze_nonlinear500_receding_acquisition_v2_20261030.py')))
 assert set(after)-set(before)=={'previous_failed_setup','isolated_owner_runtime','prospective_difference'}
 assert all(after[k]==v for k,v in before.items())
 checks.append('every_original_prospective_scientific_and_resource_protocol_setting_AST_identical')
 assert not (R/'outputs/nonlinear500_receding_acquisition_v2_preparation_20261030').exists()
 assert not (R/'outputs/nonlinear500_receding_acquisition_v2_execution_20261030').exists()
 checks.append('prospective_protocol_and_execution_not_created')
 newpaths=[f'work/{stem}_nonlinear500_receding_acquisition_v2_20261030.py' for stem in ('run','audit','coordinate','freeze')]+[gate.SOURCE_FILE]
 for p in newpaths:tree(R/p)
 report=dict(status='PASS_NEW_SOURCE_AND_PURE_ADMISSION_DELTA_CHECKS_NO_SCIENCE',checks=checks,
  previous_failed_setup=previous,isolated_runtime_certificate=certref,unchanged_old_python_sources=rows,owner_deltas=deltas,
  proposed_sources={p:sha(R/p) for p in newpaths},original_setting_count=len(before),
  actual_runtime_imports=0,owner_or_reader_launches=0,freeze_calls=0,optimizer_PF_model_equation_derivative_calls=0,
  old_NET_NPZ_calculation_journal_or_fixture_reads=0,
  remaining_gates=['Independent source delta review','Parent-controlled new readiness index and prospective freeze','Independent frozen-protocol review','Separate parent-controlled first entry'])
 put('Source_And_Admission_Check.json',report)
 print(json.dumps(dict(status=report['status'],checks=len(checks),old_python_sources=len(rows))))

if __name__=='__main__':main()
