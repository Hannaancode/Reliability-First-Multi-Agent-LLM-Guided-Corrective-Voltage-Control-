# Supported Colab access routes

Investigated 6 October 2026 from Google's official Colab CLI, Colab MCP, and VS Code repositories. The user has authorized account-connection preparation and confirmed willingness to authenticate. Passwords, codes, tokens, cookies, and credential files must not be sent through chat.

## Current evidence

- Official `google-colab-cli==0.7.4` is installed separately at `/workspace/.venvs/colab-cli`.
- Installed help/source and current official authentication documentation support explicit `--auth=oauth2` and `--auth=adc`. README default-provider text is stale; use the explicit flag.
- Google's ADC discovery rejects the existing credential configuration. A present environment variable does not establish usable Google authentication.
- After the environment restarted, `COLAB_ACCESS_TOKEN` was injected and the read-only checker succeeded with exit 0. Authenticated Colab session listing returned zero active sessions without exposing credential values.
- After the user reported saving settings, the Colab root returned HTTP 200 and the API root returned HTTP 404, establishing host reachability rather than authenticated API access. Earlier proxy denials are resolved for those probes.
- Configuration metadata still reported `has_saved_binding: false`, but this observation does not override successful runtime injection and authentication. The earlier missing-binding blocker is resolved in this instance.
- No browser-control, secure sign-in-handoff, or conversation-reading tool is available in this cloud task. Permission in chat cannot add those capabilities.
- Both supplied PDFs are retained and are byte-identical to the packaged papers. Research inputs are not Google account credentials or the missing runnable frozen experiment pack.

## Practical routes and limitations

| Route | What the user authorizes | What it enables | Status in this session |
| --- | --- | --- | --- |
| Short-lived bearer token in secure environment settings | Google OAuth on the user's computer; scoped token entered in the product secret editor | A candidate route for this cloud agent to authenticate read-only Colab API requests | Checker and secret requirement prepared; real token, network activation, and live validation still required |
| Official Colab CLI with OAuth | Browser consent and code entered into the same user-controlled terminal | Sustained local agent use of Colab sessions, execution, upload/download, and official SSH | Documented official route; requires Linux/macOS or Windows WSL and a local agent; does not authenticate this cloud task |
| Official Google Colab VS Code extension | Sign-in through VS Code, then select a Colab kernel | Notebook execution from the user's machine | Official Windows-friendly interface; local agent integration must be verified separately |
| Official Colab MCP bridge | Local MCP-capable agent linked to the browser's Colab session | Tools acting on the user's browser notebook | Requires a local client supporting dynamic tool-list notifications; this cloud task cannot use it. Codex compatibility has not been verified |
| Secure browser/account handoff | Supported product sign-in interface | Could authenticate a browser-backed workflow | No such interface is exposed here; passwords in chat cannot substitute for it |
| Notebook sharing or a Drive connector | Permission to read/edit files | Source/data access and notebook sharing | Does not establish authenticated runtime execution or GPU entitlement |
| Service-account/ambient ADC | A properly configured Google identity with relevant authorization | CLI supports ADC credential types | Not a demonstrated substitute for the user's personal Colab identity or entitlements |

Official `colab ssh` uses the authenticated Colab backend and a WebSocket SSH bridge; it is a feature after authentication, not a way around sign-in. A Colab local-runtime connection makes a browser notebook use the user's own machine, not the hosted Colab GPU this project seeks. Unsupported cookie extraction, password sharing, and ad-hoc tunnel workarounds are unnecessary for the official routes.

## Candidate route for the present cloud conversation

The environment secret proxy supports scoped HTTPS credentials. `COLAB_ACCESS_TOKEN` is a personal (`user_provided`) secret requirement, restricted to `colab.research.google.com` and `colab.pa.googleapis.com`. The checker sends it as an Authorization bearer header to the same session-list endpoint used by Google's client. This is an integration with the existing client library, not an official CLI token flag.

This route passed a live authenticated session-list check after the environment restarted. No sessions were active. An access token normally lasts about one hour and may need replacement. It gives no automatic long-term refresh. Session-list access, runtime assignment, notebook/kernel/WebSocket connectivity, and compute entitlement are separate checks; the latter remain untested. A HTTPS secret binding may not work on every subsequent WebSocket/runtime channel; verify those before promising remote execution. Additional runtime destinations should be derived from the actual authenticated response rather than guessed or broadly allowlisted.

### User-side steps (Windows supported by Google Cloud CLI)

1. Install Google Cloud CLI from [Google's Windows installation instructions](https://cloud.google.com/sdk/docs/install-sdk#windows). This does not require installing WSL for the token route. The user reported `gcloud` is not installed.
2. Open a private terminal and authorize the correct Google account using the scopes specified by Google's Colab documentation:

   ```powershell
   gcloud auth application-default login --scopes="openid,https://www.googleapis.com/auth/cloud-platform,https://www.googleapis.com/auth/userinfo.email,https://www.googleapis.com/auth/colaboratory"
   ```

   Complete Google's browser sign-in/consent. Enter any requested code only in that private terminal. These scopes match the documented ADC route; they are not a request for the Google account password.

3. Obtain a short-lived token in that terminal:

   ```powershell
   gcloud auth application-default print-access-token
   ```

4. Put that value directly into **COLAB_ACCESS_TOKEN** in the environment's secure personal-secret editor, never into chat or a repository. Review/save the existing Colab network/setup draft and publish when the product requires it. Saving a draft does not activate networking or inject a value by itself.
5. Tell the agent that settings were saved, without including the value. The agent will retry:

   ```bash
   /workspace/.venvs/colab-cli/bin/python /workspace/.cloud-setup/hiergrid/check_colab.py
   ```

   Exit 0 proves authenticated read-only session listing only; exit 2 means missing/unusable credentials; exit 3 means request/auth failure. The check allocates no runtime and reports no tokens.

If the UI cannot provide the personal-secret binding, this cloud route remains blocked. Use the local OAuth route rather than uploading credential files or sending a token through chat. If Google rejects a token, retain the status and diagnose scopes/expiry/identity/network before requesting another credential.

## Recommended sustained alternative

Run a local agent on Linux/macOS or WSL, install Google's CLI, and invoke:

```bash
uv tool install google-colab-cli==0.7.4
colab --auth=oauth2 sessions
```

Google displays a browser sign-in link; any authorization code goes directly back into that local terminal. The CLI manages its normal local token cache. No password or credential file needs to be shared with this conversation. For Windows without WSL, Google's VS Code extension provides browser sign-in and a Colab notebook kernel; the agent/runtime execution interface still needs local validation.

## Official sources and evidence limits

- [Google Colab CLI](https://github.com/googlecolab/google-colab-cli): official README/source fetched successfully; installed version 0.7.4 inspected.
- [Official CLI authentication documentation](https://github.com/googlecolab/google-colab-cli/blob/main/docs/04_automation_and_utility.md): remote OAuth code flow, scopes, ADC, and bearer-authenticated session backend.
- [Official Colab MCP](https://github.com/googlecolab/colab-mcp): requires local client and `notifications/tools/list_changed` support; names Gemini CLI, Claude Code, and Windsurf as examples.
- [Official Colab VS Code extension](https://github.com/googlecolab/colab-vscode): sign-in and Select Kernel > Colab > Auto Connect workflow.
- [Google Cloud CLI installation](https://cloud.google.com/sdk/docs/install-sdk#windows) and [ADC print-access-token reference](https://docs.cloud.google.com/sdk/gcloud/reference/auth/application-default/print-access-token): official user-facing reference links; cloud documentation retrieval was blocked by this workspace's proxy and is not claimed as a successfully retrieved page.

The Google FAQ/local-runtime pages were also blocked by the proxy; no claim of a complete current terms/quota review is made. Authenticated account access through session listing now succeeds. No GPU runtime or model experiment has been started.
