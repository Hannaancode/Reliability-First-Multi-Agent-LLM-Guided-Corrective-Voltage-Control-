"""One source-selected external graph query on EACH of four exact118roots.

Counterfactual integration only: no initial PF repeated, no actual controller
commit or full-policy score; source-native actuator differences stay explicit.
"""
import copy,json,os,sys,time,traceback
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'work'))
from reflection118_chronological_core_20261022 import read,put,sha,capsule,decode
P=R/'outputs/published_graph118_first_queries_preparation_20261022';O=R/'outputs/published_graph118_first_queries_execution_20261022'
def main():
    O.mkdir(exist_ok=False);start=time.monotonic();put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-start<180;time.sleep(.1)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp,numpy as np
    from public_size_u61_preservation import journal
    p=read(P/'Protocol.json');assert len(p['targets'])==4
    for name,h in p['source_hashes'].items():assert sha(R/name)==h
    costs={'new_PF_attempts':0,'new_PF_returns':0,'new_PF_exceptions':0,'new_PF_seconds':0.,'new_model_initialPF_training_calls':0,'actual_policy_commits':0};rows=[]
    try:
        for i,r in enumerate(p['targets']):
            assert time.monotonic()-start<p['bound_seconds']
            obj=decode(P,r['target']);net=obj['net'];before=capsule(O/f'{i:02d}_before.zlib',obj)
            # Every science input is actually loaded from its fsynced capsule.
            restored=decode(O,before);assert restored['action']==r['source_action'];net=restored['net']
            costs['new_PF_attempts']+=1;journal(O/'journal.jsonl',{'event':'PF_attempt_reserved','case_id':r['case_id'],'before':before,'solver_kwargs':p['solver_kwargs'],'source_history_gate_sha256':sha(P/'Protocol.json')})
            tick=time.perf_counter();error=None
            try:pp.runpp(net,**p['solver_kwargs']);assert net.converged;costs['new_PF_returns']+=1
            except Exception as e:error={'type':type(e).__name__,'failure':str(e)};costs['new_PF_exceptions']+=1
            seconds=time.perf_counter()-tick;costs['new_PF_seconds']+=seconds
            after=capsule(O/f'{i:02d}_after.zlib',{'net':net,'case_id':r['case_id'],'action':r['source_action']})
            row={'case_id':r['case_id'],'action':r['source_action'],'before':before,'after':after,'seconds':seconds,'exception':error,'status':'RETURNED_NEW_QUERY' if error is None else 'EXCEPTION_UNKNOWN_NO_RETRY','actual_policy_commit':False}
            if error is None:
                vm=net.res_bus.vm_pu.to_numpy(float);row['strict_all118_fields']={'UV':int((vm<.95).sum()),'OV':int((vm>1.05).sum()),'vmin':float(vm.min()),'vmax':float(vm.max()),'deficit':float(np.maximum(.95-vm,0).sum())}
            put(O/f'query_{i:02d}.json',row);rows.append(row);journal(O/'journal.jsonl',{'event':'PF_closed','record':f'query_{i:02d}.json','sha256':sha(O/f'query_{i:02d}.json'),'returned':error is None})
            assert sum(x.stat().st_size for x in O.iterdir() if x.is_file())<=p['binary_bytes']
        put(O/'Results.json',{'status':'COMPLETE_ALL4_FIRST_GRAPH_QUERY_ATTEMPTS_REQUIRE_OUTSIDE_REPLAY','rows':rows,'costs':costs,'no_full_policy_or_same_actuation_comparison':True,'workflow_seconds':time.monotonic()-start})
    except BaseException as e:
        put(O/'Failure.json',{'failure':str(e),'traceback':traceback.format_exc(),'costs':costs,'completed_records':len(rows)});raise
    finally:put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'all4_first_queries':'CLOSED_REQUIRE_READER','costs':costs}))
if __name__=='__main__':main()
