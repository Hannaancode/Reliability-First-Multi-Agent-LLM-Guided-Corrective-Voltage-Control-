"""Independent new-equation audit and full-denominator union; zero solves."""
import os, time
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'): os.environ[key] = '1'
import gzip, json, hashlib, zipfile
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import numpy as np
from native_affine_ranking_reader import context, verify_step, verify_prediction
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks

P = ROOT/'outputs/llm_value_relational_adaptation_research_20261009'; B = ROOT/'outputs/llm_value_candidate_development_20261009'
PRE = P/'unexecuted_measurement_preparation'; OLD = P/'nnrank2'; S = P/'native_unexecuted_measurement'; OUT = P/'native_unexecuted_measurement_audit'
ARMS = ('old_admittance_derivative', 'candidate_admittance_derivative'); GRID = (25.,50.,75.,100.,125.,150.,200.,250.,300.)
LABELS = {0:'interior',1:'near_min',2:'near_max'}

def rows(path):
    with gzip.open(path, 'rt', encoding='utf-8') as f: return [json.loads(line) for line in f]

def merge_predictions(prior, replacements):
    """Never substitute an executed, nonphysical, failed or lost old forecast."""
    lookup = {}
    for item in replacements:
        key = (item['action_index'], item['arm'])
        assert key not in lookup; lookup[key] = item
    result = {arm: [] for arm in ARMS}; used = set()
    for arm in ARMS:
        for ai, old in enumerate(prior['arms'][arm]):
            key = (ai, arm)
            if key in lookup:
                assert old['record_kind'] == 'unexecuted' and not old['steps'] and old['final_vm_key'] is None
                new = lookup[key]; assert new['native_action'] == old['native_action']; used.add(key)
                result[arm].append(new)
            else: result[arm].append(old)
    assert used == set(lookup)
    return result

def run():
    assert not OUT.exists(); OUT.mkdir(); start = time.perf_counter()
    write(OUT/'audit.claim', {'pid':os.getpid(), 'started_at_utc':datetime.now(timezone.utc).isoformat()})
    proto = read(PRE/'Protocol.json'); summary = read(S/'Summary.json')
    assert read(S/'status.json')['stage'] in {'complete_new_identity_measurement','terminal_partial_new_identity_measurement_no_retry'}
    for name, h in proto['source_hashes'].items(): assert sha(ROOT/name) == h, name
    for name, h in proto['data_hashes'].items(): assert sha(ROOT/name) == h, name
    for name, h in proto['prior_certificate_hashes'].items(): assert sha(ROOT/name) == h, name
    prior_certificate = read(P/'nnrank2_partial_audit_v3/Independent_Full_Native_Numerical_Audit.json')
    assert prior_certificate['all_available_identity_scope_equation_score_cost_manifest_checks_passed']
    assert prior_certificate['new_recorded_affine_step_checks'] == 145861
    manifest = read(S/'Supplement_Manifest.json')
    with zipfile.ZipFile(S/'Separate_Unexecuted_Native_Measurement.zip') as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(manifest)+1
        for n, d in manifest.items():
            data=z.read(n); assert len(data)==d['bytes'] and hashlib.sha256(data).hexdigest()==d['sha256']
    inputs = {r['observation_id']:r for r in rows(B/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz') if r['split']=='optimization'}
    targets = {r['observation_id']:r for r in rows(B/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz') if r['split']=='optimization'}
    support = {r['observation_id']:r for r in rows(B/'current_added_support_observables/Current_Control_State_Observables.jsonl.gz') if r['observation_id'] in inputs}
    scope = read(PRE/'Exact_Unexecuted_Identity_List.json'); expected_states={e['state_index']:e for e in scope}
    old_index = read(OLD/'Actual_State_File_Index.json'); new_index=read(S/'Actual_State_File_Index.json')
    assert len(new_index)==len(expected_states)==102 and {r['state_index'] for r in new_index}==set(expected_states)
    new_by_state={e['state_index']:e for e in new_index}; worlds={w['scenario_sha256']:w for w in proto['OPT_worlds']}
    full={a:{} for a in ARMS}; counts=Counter(); cachecost=Counter(); allsteps=set(); attempt_ids=set(); maxres=0.; disagreements=[]; contexts=0; new_cache_ledgers={}
    for ix in old_index:
        si=ix['state_index']; ident=ix['observation_id']; assert sha(OLD/ix['record_file'])==ix['sha256']
        prior=read(OLD/ix['record_file']); inp=inputs[ident]; obs=inp['model_input']['current_physical_observation']
        assert hashlib.sha256(json.dumps(obs,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()==ident
        buses={b for pool in obs['raw_common_and_zone_pools'].values() for b in pool}; added=support[ident]['current_added_support_MVAr_by_bus']
        allowed=[[b,j] for b in sorted(buses) for j,q in enumerate(GRID) if added[b]+q<=450.]
        assert prior['allowed_actions']==allowed and len(prior['arms'][ARMS[0]])==len(prior['arms'][ARMS[1]])==len(allowed)
        independent_pending=[(ai,arm) for ai in range(len(allowed)) for arm in ARMS if prior['arms'][arm][ai]['record_kind']=='unexecuted']
        replacements=[]
        if si in expected_states:
            entry=expected_states[si]; ni=new_by_state[si]; assert ni['observation_id']==ident and sha(S/ni['record_file'])==ni['sha256']
            rec=read(S/ni['record_file']); assert all(rec[k]==entry[k] for k in ('state_index','observation_id','world_sha256','model_input_sha256','prior_record_file','prior_record_sha256'))
            assert rec['prior_record_sha256']==ix['sha256'] and inp['model_input_sha256']==rec['model_input_sha256'] and inp['world_sha256']==rec['world_sha256']
            replacements=rec['records']; assert [(x['action_index'],x['arm']) for x in replacements]==independent_pending
            assert [(x['action_index'],x['arm'],x['native_action']) for x in replacements]==[(x['action_index'],x['arm'],x['native_action']) for x in entry['pending_slots']]
            c=None
            if rec['current_state_file']:
                assert sha(ROOT/rec['current_state_file'])==rec['current_state_sha256']
                assert sha(ROOT/rec['prepared_derivative_file'])==rec['prepared_derivative_sha256']
                with np.load(ROOT/rec['current_state_file']) as z: saved={k:z[k] for k in z.files}
                assert saved['Y'].shape==(118,118) and set(saved['mapping'])==set(range(118))
                f=obs['physical_tables']['res_bus']; vi=f['columns'].index('vm_pu'); ai=f['columns'].index('va_degree')
                observed={b:v[vi]*np.exp(1j*np.deg2rad(v[ai])) for b,v in zip(f['index'],f['values'])}
                assert max(abs(saved['V'][saved['mapping'][b]]-observed[b]) for b in range(118))<=1e-14
                c=context(saved,obs['physical_tables']); contexts+=1
            arrays={}; hashes={}
            for n in sorted({x['equation_block']['file'] for x in replacements}):
                hashes[n]=sha(S/n)
                with np.load(S/n) as z: arrays[n]={k:z[k] for k in z.files}
            for item in replacements:
                ai=item['action_index']; arm=item['arm']; pair=item['native_action']; assert pair==allowed[ai]
                original=prior['arms'][arm][ai]; assert original['record_kind']=='unexecuted' and original['prediction']['closure_status']=='UNKNOWN_unexecuted_resource_bound'
                block=arrays[item['equation_block']['file']]; assert hashes[item['equation_block']['file']]==item['equation_block']['sha256']
                vm=block[item['final_vm_key']] if item['final_vm_key'] else None; kind=item['record_kind']; counts[kind]+=1
                if kind=='unexecuted': assert not item['steps'] and vm is None
                else:
                    assert kind=='new_numerical_forecast' and c is not None
                    identity=(si,ai,arm); assert identity not in attempt_ids; attempt_ids.add(identity)
                    ids=sorted(c['gen']); assert ids==rec['native_generator_ids']; expected={i:'interior' for i in ids}; prev=-1
                    for sn, step in enumerate(item['steps']):
                        mask={i:LABELS[int(v)] for i,v in zip(ids,block['mask_catalog'][step['mask_id']])}; updates={i:LABELS[v] for i,v in step['updates']}
                        assert mask==expected and step['step']==sn and step['bound_count']==sum(v!='interior' for v in mask.values()) and step['bound_count']>prev
                        prev=step['bound_count']; skey=(*identity,sn); assert skey not in allsteps; allsteps.add(skey)
                        proof=verify_step(c,{'bus':pair[0],'q_abs_mvar':GRID[pair[1]]},arm==ARMS[1],mask,updates,block[step['x_key']],block[step['q_key']],vm if vm is not None and sn==len(item['steps'])-1 else None)
                        maxres=max(maxres,proof['residual'])
                        if not proof['independent_strict_update_agreement']: disagreements.append({'state_index':si,'action_index':ai,'arm':arm,'step':sn})
                        if vm is not None and sn==len(item['steps'])-1: assert not updates
                        else: assert updates or item['prediction']['closure_status'].startswith('unknown')
                        expected.update(updates)
                    assert len(item['steps'])<=54 and expected=={i:LABELS[int(v)] for i,v in zip(ids,block['mask_catalog'][item['final_mask_id']])}
                verify_prediction(pair,vm,obs['global_metrics'],item['prediction'])
            if rec['actual_cache_costs']:
                cachecost.update(rec['actual_cache_costs']); new_cache_ledgers[si]=rec['actual_cache_costs']
        else: assert not independent_pending
        merged=merge_predictions(prior,replacements)
        for arm in ARMS:
            assert [x['native_action'] for x in merged[arm]]==allowed
            full[arm][ident]=merged[arm]
    assert counts['new_numerical_forecast']+counts['unexecuted']==33736
    cost=summary['costs']; assert cost['forecast_attempts']==cost['forecast_returns']==counts['new_numerical_forecast']==len(attempt_ids)
    assert cost['unexecuted_records']==counts['unexecuted'] and cost['closed_affine_steps']==len(allsteps)
    assert cost['current_compile_returns']==contexts and cost['current_compile_attempts']>=contexts
    assert cost['new_PF_model_optimizer_controller_cloud_conversion_public_derivative_calls']==0
    journal=[json.loads(l) for l in (S/'Actual_Attempt_Return_Journal.jsonl').read_text(encoding='utf-8').splitlines()]; jc=Counter(x['event'] for x in journal)
    assert jc['forecast_attempt']==jc['forecast_return']==len(attempt_ids) and jc['affine_step_return']==len(allsteps) and jc['state_closed']==102
    assert {(e['state_index'],e['action_index'],e['arm']) for e in journal if e['event']=='forecast_attempt'}==attempt_ids
    assert {(e['state_index'],e['action_index'],e['arm'],e['step']) for e in journal if e['event']=='affine_step_return'}==allsteps
    last={e['state_index']:e for e in journal if e['event']=='forecast_return'}
    for si,e in last.items(): assert new_cache_ledgers[si]==e['actual_cache_costs_cumulative']
    assert cost['cache_solve_wrapper_attempts']>=cost['cache_solve_wrapper_returns']>=len(allsteps) and cost['cache_solve_wrapper_seconds']>=0
    table={}; metrics={}; label_count=0; total=Counter()
    for arm in ARMS:
        states=[]
        for ident, inp in inputs.items():
            items=full[arm][ident]; total.update(x['prediction']['status'] for x in items)
            truth={(x['target']['bus'],x['target']['Q_index']):x['target'] for x in targets.get(ident,{}).get('measured_candidates',[])}
            if arm==ARMS[0]: label_count+=len(truth)
            native={tuple(x['native_action']) for x in items}; admitted={a:t for a,t in truth.items() if a in native and t['recorded_verifier']['accepted']}
            best=max((tuple(t['recorded_original_score']) for t in admitted.values()),default=None); oracle={a for a,t in admitted.items() if tuple(t['recorded_original_score'])==best}
            finite=sorted((x['prediction'] for x in items if x['prediction']['status']=='finite_linear_forecast'),key=lambda v:(*v['estimated_original_score'],-v['bus']),reverse=True)
            complete=all(x['record_kind']!='unexecuted' and x['prediction']['status']!='unknown_affine_forecast' for x in items)
            state={'observation_id':ident,'world_sha256':inp['world_sha256'],'family':worlds[inp['world_sha256']]['family'],'oracle_exists':bool(oracle),'ranking_evidence_complete':complete,'K':{}}
            for k in (1,4,8):
                chosen=[(x['bus'],x['Q_index']) for x in finite[:k]]; hit=bool(set(chosen)&oracle) if oracle else None
                actual=hit if complete else None; bounds=[int(hit),int(hit)] if oracle and complete else [0,1] if oracle else None
                state['K'][str(k)]={'actual_recorded_best_inclusion':actual,'conservative_missing_evidence_bounds':bounds,'chosen_available_actions':[list(a) for a in chosen],
                                   'known_accepted':sum(a in truth and truth[a]['recorded_verifier']['accepted'] for a in chosen),
                                   'known_rejected':sum(a in truth and not truth[a]['recorded_verifier']['accepted'] for a in chosen),
                                   'unknown_unmeasured':sum(a not in truth for a in chosen),'unavailable_slots':max(0,k-len(chosen))}
            states.append(state)
        table[arm]=states; metrics[arm]={}
        for k in ('1','4','8'):
            byworld={}; misses=[]
            for w in worlds:
                ss=[s for s in states if s['world_sha256']==w]; oo=[s for s in ss if s['oracle_exists']]
                byworld[w]={'all_inputs':len(ss),'oracle_states':len(oo),'known_inclusions':sum(s['K'][k]['actual_recorded_best_inclusion'] is True for s in oo),
                            'unknown_inclusions':sum(s['K'][k]['actual_recorded_best_inclusion'] is None for s in oo),
                            'lower':sum(s['K'][k]['conservative_missing_evidence_bounds'][0] for s in oo)/len(oo) if oo else None,
                            'upper':sum(s['K'][k]['conservative_missing_evidence_bounds'][1] for s in oo)/len(oo) if oo else None}
            oo=[s for s in states if s['oracle_exists']]; measured=[v for v in byworld.values() if v['oracle_states']]
            misses=[s for s in oo if s['K'][k]['actual_recorded_best_inclusion'] is False]
            metrics[arm][k]={'oracle_states':len(oo),'known_inclusions':sum(s['K'][k]['actual_recorded_best_inclusion'] is True for s in oo),
                            'unknown_inclusions':sum(s['K'][k]['actual_recorded_best_inclusion'] is None for s in oo),
                            'equal_world_lower':sum(v['lower'] for v in measured)/len(measured),'equal_world_upper':sum(v['upper'] for v in measured)/len(measured),
                            'known_miss_states':len(misses),'known_miss_worlds':len({s['world_sha256'] for s in misses}),
                            'known_miss_families':sorted({s['family'] for s in misses}),'all23_world_denominators':byworld,
                            'available_shortlist_counts':{n:sum(s['K'][k][n] for s in states) for n in ('known_accepted','known_rejected','unknown_unmeasured','unavailable_slots')}}
    assert label_count==30510 and sum(total.values())==77002
    preferences=rows(P/'actual_representation_and_OPT_support/Measured_OPT_Native_Quality_Preference_Pairs.jsonl.gz')
    assert len(preferences)==11884
    relations={}
    for arm in ARMS:
        predictions={ident:{tuple(x['native_action']):x['prediction'] for x in items} for ident,items in full[arm].items()}
        pc=Counter(); reversed_states=set()
        for pair in preferences:
            ident=pair['observation_id']; a,b=(tuple(pair[k]) for k in ('preferred_action','other_action'))
            pa,pb=predictions[ident][a],predictions[ident][b]; relation='unknown'
            if pa['status']==pb['status']=='finite_linear_forecast':
                sa,sb=tuple(pa['estimated_original_score']),tuple(pb['estimated_original_score'])
                relation='aligned' if sa>sb else 'score_tied' if sa==sb else 'reversed'
            pc[relation]+=1
            if relation=='reversed':reversed_states.add(ident)
        relations[arm]={'counts':dict(pc),'reversed_states':len(reversed_states),
                        'reversed_worlds':len({inputs[i]['world_sha256'] for i in reversed_states}),
                        'reversed_families':sorted({worlds[inputs[i]['world_sha256']]['family'] for i in reversed_states})}
    proof={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'all77002_union_identities_retained':True,'new33736_scope_exactly_old_unexecuted':True,
           'no_old_forecast_replaced_or_repeated':True,'previous145861_equation_certificate_reused_with_bound_record_hashes':True,
           'new_equation_steps_independently_verified':len(allsteps),'new_dense_reader_contexts':contexts,'new_max_equation_residual':maxres,
           'independent_strict_update_disagreements':disagreements,'all_strict_updates_agreed':not disagreements,
           'new_model_PF_controller_optimizer_cloud_linear_solve_calls_by_reader':0,'reader_seconds_before_seal':time.perf_counter()-start,
           'original_lost_output_still_UNKNOWN':True,'old_terminal_partial_unchanged':True,'no_held_metric_or_confirmation':True}
    results={'K_all23_world_evidence':metrics,'all11884_previously_used_preference_relations':relations,'all_prediction_status_counts':dict(total),'new_stage_costs':cost,'new_stage_cache_costs':dict(cachecost),
             'prior_paid_stages':proto['prior_paid_stages'],'new_stage_workflow_seconds':summary['workflow_seconds_before_seal'],
             'missing_evidence_bounds_not_statistical_CI':True,'actual_nonlinear_convergence_UNKNOWN':True,'development_only':True,'no_automatic_learning_or_superiority':True}
    write(OUT/'Independent_New_Equations_and_Union_Audit.json',proof); write(OUT/'All_Arm_Union_Ranking_Results.json',results)
    write(OUT/'All239_State_and_World_Denominators.json',table); write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
    (OUT/'Results.md').write_text('Separate new-identity numerical measurement and existing audited outputs form a full declared union. Original lost output and any new partial/failure remain UNKNOWN. These are historical OPT saved-label rankings, not LLM value, nonlinear physical recovery, D-SE superiority, novelty or unused confirmation. No automatic learning follows.\n\n'+json.dumps({'K4':{a:{k:v for k,v in metrics[a]['4'].items() if k!='all23_world_denominators'} for a in ARMS},'new_audit':proof},indent=2)+'\n',encoding='utf-8')
    files={f.name:f for f in OUT.iterdir() if f.is_file() and f.name!='audit.claim'}
    files['sources/auditor.py']=Path(__file__); files['sources/equation_reader.py']=ROOT/'work/native_affine_ranking_reader.py'
    archive=seal(OUT,files,'Independent_Unexecuted_Measurement_and_Union_Audit.zip')
    write(OUT/'status.json',{'stage':'complete_new_equation_and_union_audit'})
    print(json.dumps({'audit':proof,'K4':{a:{k:v for k,v in metrics[a]['4'].items() if k!='all23_world_denominators'} for a in ARMS},'archive':archive}))

if __name__=='__main__':run()
