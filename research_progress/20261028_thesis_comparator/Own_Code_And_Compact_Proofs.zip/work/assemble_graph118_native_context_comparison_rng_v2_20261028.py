"""Closed all-four contextual comparison, explicitly unequal native actuators."""
import csv
from graph118_native_campaign_core_20261028 import *
A=R/'outputs/graph118_native_campaign_independent_rng_v2_20261028'
O=R/'outputs/graph118_native_context_comparison_rng_v2_20261028'
def main():
    lock=read(P/'Comparison_RNG_v2_Lock.json');assert sha(__file__)==lock['source_sha256']
    from coordinate_native_inverter_linear_reference_20261020 import process
    for folder,source in [(E,'run_graph118_native_campaign_20261028.py'),(A,'audit_graph118_native_campaign_rng_v2_20261028.py'),(R/'outputs/graph118_reader_rng_v2_handoff_20261028','coordinate_graph118_reader_rng_v2_20261028.py')]:
        claim=read(folder/'owner.claim')
        for pid in [claim['actual_pid'],claim['parent_pid']]:
            current=process(pid);assert current is None or source not in current.get('CommandLine','')
    complete=read(R/'outputs/graph118_reader_rng_v2_handoff_20261028/Completion.json')
    audit=read(A/'Independent_Audit.json');primary=read(E/'Result.json')
    assert complete['all4_complete'] and audit['all4_complete'] and primary['all4_complete']
    assert audit['status']=='PASS_ALL4_COMPLETE_NATIVE_GRAPH_EPISODES'
    for folder in [E,A]:
        m=read(folder/'Closed_Manifest.json')['members'];name='Result.json' if folder==E else 'Independent_Audit.json';assert sha(folder/name)==m[name]
        end=read(folder/'End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    original=read(R/lock['original_comparison']);assert sha(R/lock['original_comparison'])==lock['original_sha256']
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    first=read(R/'outputs/published_graph118_first_queries_preparation_20261022/Protocol.json')['targets']
    O.mkdir(exist_ok=False);rows=[];root_checks=[]
    for old,new,b,g in zip(original['rows'],audit['rows'],bindings,first):
        assert old['case_id']==new['case_id']==b['case_id']==g['case_id']
        assert sha(R/b['solved_payload'])==g['root_payload_sha256']
        root_checks.append(dict(case_id=b['case_id'],registered_solved_payload_sha256=g['root_payload_sha256'],same_initial_payload=True))
        row=dict(case_id=old['case_id'],initial_UV=old['initial_UV'],DFF_UV=old['DFF_UV'],DFF_OV=old['DFF_OV'],DFF_actions=old['DFF_actions'],
                 HGVF_UV=old['HGVF_UV'],HGVF_OV=old['HGVF_OV'],HGVF_actions=old['HGVF_actions'],
                 offline_HGSE_UV=old['HGSE_UV'],offline_HGSE_OV=old['HGSE_OV'],offline_HGSE_selected_actions=old['HGSE_selected_actions'],
                 GraphAgent_UV=new['endpoint']['UV'],GraphAgent_OV=new['endpoint']['OV'],GraphAgent_whole_band=new['endpoint']['whole_band'],GraphAgent_actions=new['action_count'],GraphAgent_termination=new['termination'])
        rows.append(row)
    result=dict(status='ALL4_IDENTICAL_INITIAL_ROOTS_NATIVE_ROLE_CONTEXT_COMPARISON',rows=rows,root_checks=root_checks,
      primary_endpoint='All118 strict0.95to1.05band; no epsilon rounding',
      unequal_contracts={'DFF_HGVF':'Original positive added shunts,450Mvar cap,25operations,native1.06guard;HGSEofflinefullBOTH selection',
                        'published_GraphAgent_port':'Unchanged author numerical GraphAgent policy AST; generator/slackVsetpoints+existingbinaryshunts,native136operations,fullgridfloat32observations/staticgraph. This is not the trainedDQN arm.'},
      no_equal_resource_or_causal_LLM_superiority=True,no_unused_confirmation=True,
      original_costs='outputs/original118_closed_comparison_20261028/Full_Cost_Source_Blocks.json',
      graph_costs=audit,old_graph_costs={n:read(R/n) for n in read(P/'Protocol.json')['old_cost_sources'][:2]},
      new_PF_model_calls=0)
    put(O/'Comparison.json',result)
    with (O/'Comparison.csv').open('x',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    table=['| Case | Initial UV | DFF UV/OV | Original HG-VF UV/OV | Offline HG-SE UV/OV | Published GraphAgent port UV/OV | Graph operations |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:table.append(f"| {r['case_id']} | {r['initial_UV']} | {r['DFF_UV']}/{r['DFF_OV']} | {r['HGVF_UV']}/{r['HGVF_OV']} | {r['offline_HGSE_UV']}/{r['offline_HGSE_OV']} | {r['GraphAgent_UV']}/{r['GraphAgent_OV']} | {r['GraphAgent_actions']} |")
    text='# Same initial cases, different native control resources\n\n'+'\n'.join(table)+'\n\nAll four registered starting payload hashes match. GraphAgent is the external published numerical policy, not its trained DQN arm. It changes generator/slack voltage setpoints and existing binary shunts, with up to136 native operations. Our original roles add positive shunts within450Mvar and25operations. These results describe native-method transfer on the same severe roots; they do not prove an equal-resource or causal LLM advantage. Offline HG-SE requires both complete branches and their full costs. These roots are inspected development. Strict upper-voltage failures are retained.\n'
    (O/'Results.md').write_text(text,encoding='utf-8');manifest(O)
    print(json.dumps(dict(status=result['status'],rows=rows)))
if __name__=='__main__':main()
