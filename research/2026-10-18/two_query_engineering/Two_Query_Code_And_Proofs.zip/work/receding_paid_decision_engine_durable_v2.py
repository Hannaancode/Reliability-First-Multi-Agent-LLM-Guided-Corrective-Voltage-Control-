"""Verified source-derived paid decision engine, separately prospective runtime.

This module supplies no launch or automatic permission to use a model. Original
bounded search callbacks retain all physical, menu, cache and cost equations.
Caller owns durable history/checkpoint/absolute bounds and actual first commits.
"""
import copy,os,time
import numpy as np
from bounded_paid_lookahead_physics_20261014 import (load_after,build_current_domain,point_key,compile_current,
    forecast,order_all_current_forecasts,resource_eligible,action_key,build_verifier,action,receipt,
    common_accept,sha)
from operation_aware_paid_lookahead_v1 import plan,MissingEvidence
from project_paid_joint_successor_v1 import project
import full_joint_suffix_benchmark_20261014 as prior

class PaidDecisionEngine:
    def __init__(self,*,out,evidence,runner,zones,cache,blocked,contexts,numeric_cost,history,paid_forecasts):
        self.out=out;self.evidence=evidence;self.runner=runner;self.zones=zones
        self.cache=cache;self.blocked=blocked;self.contexts=contexts;self.numeric_cost=numeric_cost
        self.history=history;self.saved_contexts=set();self.serial=0
        self.paid_forecasts=paid_forecasts
    def decision(self,original,original_cursor,world,mode,decision):
        evidence=self.evidence;runner=self.runner;zones=self.zones;out=self.out
        cache=self.cache;blocked=self.blocked;contexts=self.contexts;numeric_cost=self.numeric_cost
        saved_contexts=self.saved_contexts;serial=self.serial
        context={'world':world,'method':mode,'decision':decision};nodes={};log=[];menus=[]
        branch={'attributed_query_PF_calls':0,'attributed_query_solver_seconds':0.,'cached_query_receipts':0,
                'new_query_PF_calls':0,'root_query_count':0,'second_query_count':0}
        root=f'{world}|{mode}|{decision}|ROOT'
        domain=build_current_domain(original,original_cursor,runner=runner,zones=zones)
        nodes[root]={'net':copy.deepcopy(original),'cursor':domain['expanded_cursor_for_separately_fixed_future_protocol']}
        root_refs=[]
        def ensure(handle):
            node = nodes[handle]
            if 'net' not in node:
                parent = ensure(node['parent'])
                target = load_after(node['record']['after_reference'], evidence.pack)['net']
                projected = project(parent['net'], target, parent['cursor'], node['row'], node['record'], runner=runner, zones=zones)
                node.update(net=target, cursor=projected)
            if 'point' not in node:
                node['point'] = point_key(node['net'], node['cursor'])
            return node
        def make_menu(parent, slots, k=None):
            node = ensure(parent)
            d = build_current_domain(node['net'], node['cursor'], runner=runner, zones=zones)
            node['cursor'] = d['expanded_cursor_for_separately_fixed_future_protocol']
            rows = [r for r in d['all_declared_original9Q_ordinary_and_owned_joint_identities'] if (1 if r['kind'] == 'ordinary' else 2) <= slots]
            if k is not None:
                if root_refs:
                    evidence.event('complete_cached_root_menu_ACK', {**context, 'records': root_refs})
                    root_refs.clear()
                c, ident = compile_current(node['net'], contexts, numeric_cost, lambda n, data: evidence.event('numeric_' + n, {**context, **data}))
                if ident not in saved_contexts:
                    path = out / 'contexts' / (ident + '.npz')
                    with path.open('xb') as f:
                        np.savez_compressed(f, **c)
                        f.flush()
                        os.fsync(f.fileno())
                    saved_contexts.add(ident)
                    evidence.event('current_numeric_context_saved', {**context, 'parent': parent, 'identity': ident, 'sha256': sha(path)})
                before = runner.rescue.grid_metrics(node['net'])
                guided = []
                for r in rows:
                    prediction_key=ident+'|'+action_key(r)
                    if prediction_key in self.paid_forecasts:
                        prediction=copy.deepcopy(self.paid_forecasts[prediction_key])
                        numeric_cost['exact_paid_forecast_reuses']+=1
                    else:
                        prediction=forecast(r,c,before)
                        self.paid_forecasts[prediction_key]=copy.deepcopy(prediction)
                        numeric_cost['new_forecasts']+=1
                    guided.append({**r,'ordering_forecast':prediction})
                ordered = order_all_current_forecasts(guided, before, node['cursor'])
                rows = [{key: r[key] for key in ['kind', 'receiver', 'q', 'donor_index', 'donor_bus', 'universe_index']} for r in ordered if resource_eligible(r, node['cursor'])][:k]
                evidence.event('second_causal_context_and_forecasts', {**context, 'parent': parent, 'context_identity': ident, 'actual_mask_PV': c['actual_PV'].tolist(), 'actual_mask_PQ': c['actual_PQ'].tolist(), 'rows': guided, 'selected_ids': [action_key(r) for r in rows]})
            node.setdefault('rows', {}).update({action_key(r): r for r in rows})
            menu = {'parent': parent, 'slots': slots, 'k': k, 'ids': [action_key(r) for r in rows]}
            menus.append(menu)
            evidence.event('menu_declared', {**context, **menu})
            return menu['ids']
        def query(parent, aid):
            nonlocal serial
            evidence.admit()
            node = ensure(parent)
            row = node['rows'][aid]
            key = node['point'] + '|' + aid
            if key in blocked:
                raise MissingEvidence('Prior incomplete identity is forbidden to repeat')
            if parent != root and root_refs:
                evidence.event('complete_cached_root_menu_ACK', {**context, 'records': root_refs})
                root_refs.clear()
            if key in cache:
                record = copy.deepcopy(cache[key])
                record['candidate'] = dict(row)
                branch['cached_query_receipts'] += 1
            elif not resource_eligible(row, node['cursor']):
                record = {'candidate': row, 'verdict': {'accepted': False, 'reason': 'exact_resource_cap_or_stock_rejection_noPF', 'after': None}, 'original_score': [-1] * 5, 'after_reference': None, 'attributed_PF_calls': 0, 'attributed_solver_seconds': 0.0, 'receipt_id': 'RESOURCE_' + key}
                cache[key] = copy.deepcopy(record)
            else:
                verify, _, _ = build_verifier(runner.rescue, node['cursor'])
                evidence.last = None
                evidence.context = {**context, 'phase': 'NEW_PRIMARY_QUERY', 'parent': parent, 'point': node['point'], 'candidate': row, 'action_key': aid}
                raw = verify(node['net'], action(row))
                v = prior.verdict(raw)
                paid = copy.deepcopy(evidence.last)
                serial += 1
                record = {'candidate': row, 'verdict': v, 'original_score': list(runner.rescue.score_candidate({'action': action(row), 'verif': v})), 'after_reference': {'kind': 'new', 'descriptor': paid['after']} if paid and paid['outcome'] == 'RETURNED' else None, 'attributed_PF_calls': int(paid is not None), 'attributed_solver_seconds': paid['seconds'] if paid else 0.0, 'receipt_id': 'NEW_RECEDING_' + str(serial), 'actual_measured_receipt': paid}
                cache[key] = copy.deepcopy(record)
                branch['new_query_PF_calls'] += int(paid is not None)
            branch['attributed_query_PF_calls'] += record['attributed_PF_calls']
            branch['attributed_query_solver_seconds'] += record['attributed_solver_seconds']
            branch['root_query_count' if parent == root else 'second_query_count'] += 1
            successor = parent + '/' + aid
            if common_accept(record):
                nodes[successor] = {'parent': parent, 'row': row, 'record': record}
            message = {'parent': parent, 'aid': aid, 'row': row, 'record': record, 'successor': successor if common_accept(record) else None}
            evidence.event('every_query_receipt_closed_before_more_science',{**context,**message})
            log.append(message)
            if parent == root:
                root_refs.append(message)
            else:
                evidence.event('second_query_closed', {**context, **message})
            return receipt(parent, aid, row, record, successor)
        result=plan(root,runner.rescue.grid_metrics(original),original_cursor['remaining_original_device_operation_slots'],
            lambda parent,slots:make_menu(parent,slots),lambda parent,slots,k:make_menu(parent,slots,k),query,mode=mode)
        if root_refs:
            evidence.event('complete_cached_root_menu_ACK',{**context,'records':root_refs});root_refs.clear()
        self.serial=serial
        report={**context,'root':root,'plan':result,'menus':menus,'query_messages':log,'attributed_costs':branch}
        self.history.append('complete_paid_receding_decision',report)
        # Nodes remain local actual paid NET/receipt handles, not a simulated
        # second leaf that the controller could mistake for a first commit.
        return {**report,'nodes':nodes,'resolve_paid_state':ensure}
