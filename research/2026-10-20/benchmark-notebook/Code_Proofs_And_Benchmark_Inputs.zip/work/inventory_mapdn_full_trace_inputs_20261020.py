"""One full input-only trace inventory, before control/policy outcomes."""
import hashlib,json,os,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/mapdn_full_trace_inventory_20261020'
BASE=ROOT/'outputs/mapdn_native_contract_v2_20261020'
ARCH=ROOT/'outputs/mapdn_author_dataset_preservation_20261020'
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();bound=900
    anchor=json.loads((ARCH/'Result.json').read_text(encoding='utf-8'));assert anchor['status']=='COMPLETE_EXPECTED_FULL_SHA256_AND_ALL16_CRC_PASS'
    archive=ARCH/'voltage_control_data.zip';assert archive.stat().st_size==anchor['complete_bytes']
    entries=json.loads((ROOT/'outputs/benchmark_priority_20261020/MAPDN/All_Author_Archive_Entries.json').read_text(encoding='utf-8'))['entries'];targets=[r for r in entries if r['path'].endswith('.csv')];assert len(targets)==9
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixed_bound_seconds':bound,'all9targets':[r['path'] for r in targets],'scope':'Every source input timestamp/numeric field finite and aligned, exact device-column shapes, full coverage; pooled extrema are native input descriptors, not policy results. No train/test selection, fitting, model, PF or allocation.','archive_integrity_certificate':str(ARCH/'Result.json'),'no_complete_archive_rehash':True}
    put(OUT/'Protocol.json',protocol);put(OUT/'owner.claim',protocol);rows=[]
    try:
        with zipfile.ZipFile(archive) as z,(OUT/'Events.jsonl').open('x',encoding='utf-8') as journal:
            for e in targets:
                header=json.loads((BASE/'timeseries_headers'/(e['path'].split('/')[1]+'__'+Path(e['path']).stem+'.json')).read_text(encoding='utf-8'))
                columns=header['header'];dtype={c:np.float64 for c in columns[1:]};count=0;first=last=None;minima=maxima=None;negative=0;seconds=time.monotonic()
                with z.open(e['path']) as stream:
                    for chunk in pd.read_csv(stream,chunksize=16384,dtype=dtype):
                        assert time.monotonic()-start<bound,'Fixed inventory bound'
                        assert list(chunk.columns)==columns and len(chunk.columns)-1==header['native_device_count']
                        times=pd.to_datetime(chunk.iloc[:,0],format='%Y-%m-%d %H:%M:%S',errors='raise').to_numpy(dtype='datetime64[s]')
                        if first is None:first=times[0]
                        expected=first+np.arange(count,count+len(chunk))*np.timedelta64(180,'s');assert np.array_equal(times,expected)
                        vals=chunk.iloc[:,1:].to_numpy(dtype=np.float64);assert np.isfinite(vals).all()
                        mi=vals.min(axis=0);ma=vals.max(axis=0);minima=mi if minima is None else np.minimum(minima,mi);maxima=ma if maxima is None else np.maximum(maxima,ma)
                        negative+=int((vals<0).sum());count+=len(chunk);last=times[-1]
                        journal.write(json.dumps({'entry':e['path'],'rows_checked':count,'elapsed_seconds':time.monotonic()-start})+'\n');journal.flush()
                r={'entry':e['path'],'rows':count,'columns':len(columns)-1,'first_timestamp':str(first),'last_timestamp':str(last),'all_timestamps_regular_180_seconds':True,'all_numeric_fields_finite':True,'negative_input_values':negative,'native_column_min':minima.tolist(),'native_column_max':maxima.tolist(),'parse_seconds':time.monotonic()-seconds,'no_policy_or_physics_output':True}
                put(OUT/(e['path'].split('/')[1]+'__'+Path(e['path']).stem+'.json'),r);rows.append(r)
        assert len({(r['rows'],r['first_timestamp'],r['last_timestamp']) for r in rows})==1,'Native traces not aligned'
        put(OUT/'Results.json',{'status':'ALL9_FULL_INPUT_TRACES_FINITE_REGULAR_ALIGNED','at_utc':datetime.now(timezone.utc).isoformat(),'files':rows,'total_numeric_values_checked':sum(r['rows']*r['columns'] for r in rows),'workflow_seconds':time.monotonic()-start,'new_PF_model_optimizer_GPU_calls':0,'split_and_native_model_serving_performance_still_pending':True})
        print(json.dumps({'all9_input_traces':True,'rows_each':rows[0]['rows'],'first':rows[0]['first_timestamp'],'last':rows[0]['last_timestamp'],'workflow_seconds':time.monotonic()-start}))
    except BaseException as e:
        put(OUT/'Failure.json',{'status':'INPUT_INVENTORY_FAILED','failure_type':type(e).__name__,'failure':str(e)[:300],'closed_files':rows,'workflow_seconds':time.monotonic()-start,'new_science_calls':0});raise
if __name__=='__main__':main()
