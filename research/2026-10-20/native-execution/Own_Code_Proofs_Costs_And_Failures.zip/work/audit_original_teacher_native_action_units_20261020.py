"""Finite TRAIN-label support versus all native inverter action-capacity bounds."""
import hashlib,json,math,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/original_teacher_native_action_units_20261020'
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic()
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'All16000originalTRAIN proposed-action magnitudes only, all3publicnativePVcapacity envelopes. No heldlabels, teacherAFTERfields, modelinference orPF. Test unchanged label command units, NOT whether an LLM can extrapolate or a new adaptation can improve.','fixed_bound':'Every finite native action obeys |q|<=action_scale*sqrt((1.2Pmax)^2-P^2)<2Pmax. The conservative rational2Pmax bound avoids borderline floatingpoint ambiguity.','input_archive':r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2b_training_inputs.zip','no_source_modified':True}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    rows=nonnull=null=0;values=[];h=hashlib.sha256()
    with zipfile.ZipFile(protocol['input_archive']) as z:
        name=next(n for n in z.namelist() if n.endswith('zone_agent_train.jsonl'))
        with z.open(name) as f:
            for line in f:
                h.update(line);record=json.loads(line);a=json.loads(next(m['content'] for m in record['messages'] if m['role']=='assistant'));action=a.get('proposed_action');rows+=1
                if action is None:null+=1;continue
                assert set(action)=={'add_shunts_q_mvar'};q=action['add_shunts_q_mvar'];assert isinstance(q,dict) and q
                nonnull+=1
                for bus,value in q.items():value=float(value);assert math.isfinite(value) and value>0;values.append(value)
    assert rows==16000 and h.hexdigest()=='7b22162d0abd92ccb64473fcef5bb300ee12416ce22ea6ce03e60fefaa9154eb'
    native=[]
    for name,scale,path in [('33',.8,ROOT/'outputs/mapdn_full_trace_inventory_20261020/case33_3min_final__pv_active.json'),('141',.6,ROOT/'outputs/mapdn_full_trace_inventory_20261020/case141_3min_final__pv_active.json'),('322',.8,ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json')]:
        maxima=json.loads(path.read_text(encoding='utf-8'))['native_column_max'];cap=2*max(Fraction.from_float(x) for x in maxima);smallest=min(Fraction.from_float(q) for q in values)
        native.append({'network_buses':int(name),'PV_count':len(maxima),'native_action_scale':scale,'largest_source_Pmax_MW':max(maxima),'native_sharper_q_abs_bound_Mvar':scale*1.2*max(maxima),'conservative_q_abs_bound_2Pmax_Mvar':float(cap),'every_nonnull_teacher_magnitude_exceeds_conservative_cap':smallest>cap,'minimum_teacher_q_Mvar':float(smallest),'rational_positive_margin_Mvar':str(smallest-cap)})
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE_FINITE_TRAIN_COMMAND_UNIT_SUPPORT_AUDIT','original_TRAIN_sha256':h.hexdigest(),'TRAIN_rows':rows,'nonnull_actions':nonnull,'legal_null_actions':null,'q_values':len(values),'distinct_q_Mvar':sorted(set(values)),'native_envelopes':native,'all3_literal_nonnull_teacher_actions_outside_even_conservative_native_caps':all(r['every_nonnull_teacher_magnitude_exceeds_conservative_cap'] for r in native),'limitations':['This proves a finite existing-label/native-unit incompatibility, not a universal LLM inability or probability of scientific success.','A language model could generate unseen values. A separately fixed explicit inverter adaptation may be tested; no hidden Qrescaling/clipping or shunt-to-inverter reinterpretation.','Null means legal abstention/hold where specified, not a negative action label or physical infeasibility.'],'new_PF_model_optimizer_GPU_calls':0,'workflow_seconds':time.monotonic()-start}
    (OUT/'Results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({'rows':rows,'nonnull':nonnull,'min_q':min(values),'max_q':max(values),'native_q_upper':[r['native_sharper_q_abs_bound_Mvar'] for r in native],'all3_support_mismatch':result['all3_literal_nonnull_teacher_actions_outside_even_conservative_native_caps']}))
if __name__=='__main__':main()
