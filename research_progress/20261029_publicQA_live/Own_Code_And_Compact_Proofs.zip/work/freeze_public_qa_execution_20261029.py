"""Freeze the predetermined three-arm QA execution after actual software gates."""
from pathlib import Path
from datetime import datetime,timezone
import ast,hashlib,json,zipfile
R=Path(__file__).resolve().parents[1];BASE=R/'outputs/public_qa_execution_preparation_20261029';O=BASE/'final'
def read(p):return json.loads(Path(p).read_text('utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def data(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n','utf-8')
def main():
    assert not O.exists()
    design=read(BASE/'Prepared_Protocol.json')
    host=read(R/'outputs/public_qa_supervision_20261029/host_lifecycle_v2/Result.json')
    reader=read(R/'outputs/public_qa_supervision_20261029/reader_checks_v2/Result.json')
    capacity=read(R/'outputs/public_qa_supervision_20261029/Synthetic_Capacity.json')
    assert host['status']=='PASS_SIX_OFFLINE_FINAL_HOST_LIFECYCLES' and host['host_sha256']==sha(R/'work/run_public_qa_colab_20261029.py')
    assert reader['status']=='PASS_SIX_FINAL_SCIENTIFIC_READER_SOFTWARE_CHECKS'
    assert reader['source_sha256']==sha(R/'work/audit_public_qa_scientific_20261029.py') and reader['worker_sha256']==sha(R/'work/public_qa_inference_worker_v2_20261029.py')
    assert capacity['status']=='PASS_THREE_ACTUAL_SYNTHETIC_CONTEXT_BOUNDS'
    # Bind retained old transfer/mock tests only to unchanged functions. Native
    # loader hardening is separately exercised by the real pre-science gate.
    prior=R/'outputs/public_qa_supervision_20261029/pre_final_sources'
    def functions(path):
        return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text('utf-8')).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    old=functions(prior/'public_qa_inference_worker_v2_20261029.py');new=functions(R/'work/public_qa_inference_worker_v2_20261029.py')
    assert all(old[n]==new[n] for n in old if n!='TorchBackend')
    assert sha(prior/'public_qa_transfer_20261029.py')==sha(R/'work/public_qa_transfer_20261029.py')
    guardold=functions(prior/'public_qa_remote_supervisor_20261029.py');guardnew=functions(R/'work/public_qa_remote_supervisor_20261029.py')
    assert guardold['watchdog_reason']==guardnew['watchdog_reason']
    sources=list(design['source_hashes'])+['work/check_public_qa_linux_watchdog_20261029.py']
    hashes={p:sha(R/p) for p in sources}
    for p in sources:ast.parse((R/p).read_text('utf-8'))
    pins=['outputs/veragrid_native_prompt_contract_20261029/source/benchmark_runner.py',
        'outputs/veragrid_source_admission_20261029/source/evaluator.py',
        'outputs/veragrid_source_admission_20261029/administrator/mcq_questions.web.json',
        'outputs/veragrid_native_prompt_contract_20261029/participant/Native_NoTool_Prompts.json']
    hashes.update({p:sha(R/p) for p in pins})
    weights=read(R/'outputs/public_qa_supervision_20261029/weight_metadata/Result.json')['models']
    O.mkdir();arms=[]
    cloud_sources=['public_qa_inference_worker_v2_20261029.py','public_qa_transfer_20261029.py','public_qa_remote_supervisor_20261029.py',
        'public_qa_remote_setup_20261029.py','check_public_qa_linux_watchdog_20261029.py']
    for arm in design['arms']:
        folder=O/arm['id'];folder.mkdir();a=read(R/arm['assignment'])
        m=next(x for x in weights if x['model']==a['model']);assert m['revision']==a['revision'];a['expected_weights']=m['weights']
        put(folder/'Assignment.json',a);pack=read(R/arm['pack'])
        assert [x['question_id'] for x in pack['questions']]==a['question_ids'] and len(a['question_ids'])==150
        allowed={n:(R/'work'/n).read_bytes() for n in cloud_sources}
        allowed.update({'dependency_constraints.txt':(R/'work/frozen_dependency_closure.txt').read_bytes(),'assignment.json':data(a),'pack.json':data(pack)})
        manifest={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in allowed.items()}
        zpath=folder/'Participant_Payload_LOCAL_ONLY.zip'
        with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
            for n,b in allowed.items():z.writestr(n,b)
            z.writestr('Manifest.json',data(manifest))
        with zipfile.ZipFile(zpath) as z:
            assert z.testzip() is None and set(z.namelist())==set(manifest)|{'Manifest.json'}
            for n,m in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256']
        updated={**arm,'assignment':str((folder/'Assignment.json').relative_to(R)).replace('\\','/'),
            'payload':str(zpath.relative_to(R)).replace('\\','/'),'payload_sha256':sha(zpath)}
        arms.append(updated);hashes[updated['assignment']]=sha(folder/'Assignment.json');hashes[arm['pack']]=sha(R/arm['pack'])
        for name in ['config.json','tokenizer.json','tokenizer_config.json']:
            p=arm['tokenizer_directory']+'/'+name;hashes[p]=sha(R/p)
        put(folder/'Payload_Admission.json',{'allowed_members':manifest,'archive_sha256':sha(zpath),'contains_administrator_or_credentials_or_private_adapter':False})
    final={**design,'at_utc':datetime.now(timezone.utc).isoformat(),'status':'FROZEN_SOURCE_INPUT_OWNERSHIP_AND_PRE_SCIENCE_RUNTIME_GATES',
        'launch_ready':True,'arms':arms,'source_hashes':hashes,'worker_sha256':sha(R/'work/public_qa_inference_worker_v2_20261029.py'),
        'remaining_before_launch':[],
        'mandatory_actual_runtime_gates':['Linux actual owned-child setup/call watchdog exercise before model loading.',
            'Pinned weight bytes/hash and actualFP16 CUDA/eager loader; actual150inputIDs.',
            'Synthetic maxlength plus256output warm/cold exact match; no test question used.',
            'Local acknowledgement of complete engineering bytes before the first test inference.'],
        'runtime_gate_failure':'Preserve source/claim/returned bytes/costs; stop the assigned arm, no retry or profile fallback.'}
    put(O/'Final_Protocol.json',final)
    proof={'status':'PASS_FINAL_STATIC_AND_SOFTWARE_LAUNCH_GATES','protocol_sha256':sha(O/'Final_Protocol.json'),
        'fixed_profiles':[x['profile'] for x in arms],'models':[read(R/x['assignment'])['model'] for x in arms],
        'software_bound_transfer_checks':11,'final_host_lifecycle_checks':6,'final_reader_checks':6,'actual_synthetic_contexts':3,
        'source_and_input_hashes':hashes,'actual_GPU_allocation_model_calls':0,
        'limits':'Permission to enter one fixed bounded runtime integration and inference campaign; no result or guaranteed GPU availability follows.'}
    put(O/'Final_Readiness.json',proof);print(json.dumps({'status':proof['status'],'arms':3,'new_model_GPU_calls':0}))
if __name__=='__main__':main()
