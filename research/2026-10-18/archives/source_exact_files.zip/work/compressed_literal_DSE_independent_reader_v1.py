"""Independent closed evidence components; no science/old-reader run on import.

Complete whole-original source checks are retained by reversing just the
capsule byte-read substitution. Partial ledgers remain UNKNOWN and are never
sent through that complete-only function. A separate prospective coordinator,
source/input/ownership lock and charged physical replay are still required.
"""
import ast
import copy
import hashlib
import json
import math
import pickle
from pathlib import Path

import audit_spatial_DSE_reference_screen_20261012 as original_reader
from durable_opaque_evidence_store_v1 import EvidenceStop, inventory, local_root, process_alive
from literal_DSE_compressed_preservation_v2 import read_compressed_capsule
from native_continuation_preservation_v2 import canonical
from native_postcommit_preservation import measured_bus_fields, check_commit
from paid_spatial_controller_checkpoint_v1 import validate_chain
from trusted_causal_controller_snapshot import SOLVER_ROLES, cap_totals

ROOT=Path(__file__).resolve().parents[1]
OLD_READER=ROOT/'work/audit_spatial_DSE_reference_screen_20261012.py'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda p:json.loads(p.read_text('utf8'))


def finite_nonnegative(value):
    return type(value) in (int,float) and math.isfinite(value) and value>=0


def verify_closed_owner(folder, external, protocol_sha256, source_sha256):
    """External ended-owner ACK binds immutable manifest, identity and costs."""
    folder=local_root(folder)
    data=(folder/'Closed_Manifest.json').read_bytes()
    if sha(data)!=external['closed_manifest_sha256']:
        raise EvidenceStop('Externally captured closure changed')
    manifest=json.loads(data)
    if manifest['exit_code']!=external['exit_code']:
        raise EvidenceStop('Closed source exit identity changed')
    actual=inventory(folder,hashes=True)
    expected=dict(manifest['members'])
    expected['Closed_Manifest.json']={'bytes':len(data),'sha256':sha(data)}
    if actual!=expected:
        raise EvidenceStop('Closed owner has additional/missing/changed files')
    claim=read(folder/'owner.claim');completion=read(folder/'Completion.json');ack=read(folder/'Launcher_ACK.json')
    if (claim['actual_pid']!=external['actual_pid'] or claim['actual_parent_pid']!=external['actual_parent_pid'] or
        claim['protocol_sha256']!=protocol_sha256 or claim['source_sha256']!=source_sha256 or
        ack['actual_pid']!=claim['actual_pid'] or ack['actual_parent_pid']!=claim['actual_parent_pid'] or
        ack['protocol_sha256']!=protocol_sha256 or ack['source_sha256']!=source_sha256 or
        ack['exact_PID_parent_command_verified'] is not True or
        completion['actual_pid']!=claim['actual_pid'] or completion['exit_code']!=external['exit_code']):
        raise EvidenceStop('Actual claim/ACK/parent/source/exit changed')
    observed=ack['fresh_CIM_identity']
    if (observed['ProcessId']!=claim['actual_pid'] or observed['ParentProcessId']!=claim['actual_parent_pid'] or
        external['expected_command_suffix'] not in observed['CommandLine']):
        raise EvidenceStop('Exact captured source command changed')
    for pid in (claim['actual_pid'],claim['actual_parent_pid']):
        if process_alive(pid):
            raise EvidenceStop('Actual owner/launcher still live; no reader alongside owner')
    if not finite_nonnegative(external['owned_seconds']) or external['includes_final_manifest_and_process_exit'] is not True:
        raise EvidenceStop('Whole actual owned/final-write cost missing')
    return manifest


def reconcile_terminal_prefix(rows, terminal, *, science_exit_code):
    """Facts/lower bounds only on partials; never fabricate missing entries."""
    costs,codec=terminal['costs'],terminal['codec_costs']
    for group in (costs,codec):
        if not isinstance(group,dict) or not all(finite_nonnegative(v) for v in group.values()):
            raise EvidenceStop('Missing/nonfinite/negative terminal counter')
    integer_fields=('PF_attempts','PF_returns','PF_exceptions','initial_PF','trial_PF','commit_PF',
        'candidate_attempts','candidate_returns','full_menu_searches','capsule_bytes')
    for k in integer_fields:
        if type(costs[k]) is not int:raise EvidenceStop('Noninteger source counter: '+k)
    for k in ('raw_payload_bytes','encoded_payload_bytes','raw_fallbacks','post_journal_admissions','not_entered_intents'):
        if type(codec[k]) is not int:raise EvidenceStop('Noninteger codec counter: '+k)
    if costs['PF_attempts']!=sum(costs[k] for k in ('initial_PF','trial_PF','commit_PF')):
        raise EvidenceStop('Source physical-role arithmetic changed')
    if costs['PF_attempts']<costs['PF_returns']+costs['PF_exceptions']:
        raise EvidenceStop('Returns/exceptions exceed source attempts')
    events={key:[r['payload'] for r in rows if r['event']==key] for key in (
        'literal_PF_intent','literal_PF_return','literal_PF_exception','literal_PF_interrupted_unknown',
        'literal_PF_not_entered_operational_stop','literal_candidate_intent','literal_candidate_return',
        'literal_preselection_full_menu','literal_complete_search_return','literal_actual_commit_verified')}
    intents=events['literal_PF_intent'];ids=[x['identity'] for x in intents]
    if len(ids)!=len(set(ids)):raise EvidenceStop('Duplicate physical intent identity')
    by_id={x['identity']:x for x in intents};resolved={}
    for kind in ('literal_PF_return','literal_PF_exception','literal_PF_interrupted_unknown','literal_PF_not_entered_operational_stop'):
        for item in events[kind]:
            identity=item['identity']
            if identity not in by_id or identity in resolved or item['role']!=by_id[identity]['role']:
                raise EvidenceStop('Nonissued/duplicate/changed physical outcome identity')
            resolved[identity]=kind
            if kind=='literal_PF_not_entered_operational_stop':
                if item['PF_attempt_not_incremented'] is not True:
                    raise EvidenceStop('Non-entered intent mislabeled a solver attempt')
            elif not finite_nonnegative(item['seconds']):
                raise EvidenceStop('Invalid recorded backend interval')
    for item in intents:
        if item['role'] not in SOLVER_ROLES or item['kwargs']!=SOLVER_ROLES[item['role']]:
            raise EvidenceStop('Original solver role/options changed')
    lower_returns=len(events['literal_PF_return']);lower_exceptions=len(events['literal_PF_exception'])
    not_entered=len(events['literal_PF_not_entered_operational_stop'])
    interrupted=len(events['literal_PF_interrupted_unknown'])
    if (lower_returns>costs['PF_returns'] or lower_exceptions>costs['PF_exceptions'] or
        not_entered>codec['not_entered_intents'] or
        len(events['literal_candidate_intent'])>costs['candidate_attempts'] or
        len(events['literal_candidate_return'])>costs['candidate_returns'] or
        len(events['literal_preselection_full_menu'])>costs['full_menu_searches']):
        raise EvidenceStop('Journal lower bound exceeds terminal source counter')
    seconds=sum(x['seconds'] for kind in ('literal_PF_return','literal_PF_exception','literal_PF_interrupted_unknown') for x in events[kind])
    if seconds>costs['pure_solver_seconds']+1e-8:
        raise EvidenceStop('Recorded backend intervals exceed actual terminal counter')
    complete=science_exit_code==0
    if complete:
        if (terminal['stopped'] or interrupted or not_entered or codec['not_entered_intents'] or codec['raw_fallbacks'] or
            set(resolved)!=set(ids) or len(intents)!=costs['PF_attempts'] or
            lower_returns!=costs['PF_returns'] or lower_exceptions!=costs['PF_exceptions'] or
            lower_returns+lower_exceptions!=costs['PF_attempts'] or
            abs(seconds-costs['pure_solver_seconds'])>1e-8 or
            len(events['literal_candidate_intent'])!=costs['candidate_attempts'] or
            len(events['literal_candidate_return'])!=costs['candidate_returns'] or
            costs['candidate_attempts']!=costs['candidate_returns'] or
            len(events['literal_preselection_full_menu'])!=costs['full_menu_searches'] or
            codec['post_journal_admissions']!=len(intents)):
            raise EvidenceStop('Complete-only ledger has partial/missing/operational evidence')
    return {'scope':'TERMINAL_LEDGER_COMPONENT_NOT_COMPLETE_SCIENTIFIC_AUDIT',
        'scientific_outcome':'UNVERIFIED_COMPLETE_OWNER' if complete else 'TERMINAL_PARTIAL_UNKNOWN',
        'recorded_return_lower_bound':lower_returns,'recorded_exception_lower_bound':lower_exceptions,
        'recorded_not_entered_intents':not_entered,'recorded_interrupted_attempts_unknown':interrupted,
        'unresolved_intent_ids':[x for x in ids if x not in resolved],
        'source_reported_counters_not_substituted_for_receipt_proofs':costs,
        'source_reported_codec_counters':codec,'recorded_backend_seconds_lower_bound':seconds,
        'inference_or_policy_advantage':'UNPROVED','full_source_and_charged_physical_replay_still_required':True}


def read_terminal_prefix(folder, protocol, protocol_sha256, *, science_exit_code):
    folder=local_root(folder)
    rows,tip=validate_chain((folder/'scientific.jsonl').read_bytes(),protocol_sha256)
    raw=(folder/'Terminal_Costs.json').read_bytes();receipt=read(folder/'Terminal_Cost_Receipt.json')
    if sha(raw)!=receipt['terminal_cost_sha256'] or len(raw)!=receipt['terminal_cost_bytes'] or not finite_nonnegative(receipt['terminal_write_seconds']):
        raise EvidenceStop('Terminal cost external footer mismatch')
    terminal=json.loads(raw)
    if terminal['actual_pid']!=read(folder/'owner.claim')['actual_pid']:
        raise EvidenceStop('Terminal ledger issuer changed')
    report=reconcile_terminal_prefix(rows,terminal,science_exit_code=science_exit_code)
    for key in ('complete_storage_scans','complete_storage_scan_seconds'):
        if not finite_nonnegative(terminal[key]):raise EvidenceStop('Complete-tree inventory cost missing')
    if type(terminal['complete_storage_scans']) is not int:raise EvidenceStop('Noninteger inventory count')
    anchors=[]
    for row in rows:
        if row['event'] in ('literal_PF_return','literal_PF_exception','literal_PF_interrupted_unknown','literal_PF_not_entered_operational_stop'):
            anchors.append(row['payload']['anchors'])
        elif row['event']=='literal_preselection_full_menu':anchors.append(row['payload']['parent'])
    unique={a['relative']:a for a in anchors}
    if len(unique)!=len(anchors):raise EvidenceStop('Repeated issued capsule identity')
    verified_raw=verified_encoded=0
    for anchor in unique.values():
        raw=read_compressed_capsule(folder/anchor['relative'],anchor,
            max_raw_bytes=protocol['max_raw_capsule_bytes'],max_encoded_bytes=protocol['max_encoded_capsule_bytes'])
        metadata=read(folder/anchor['relative']/'Manifest.json')
        verified_raw+=len(raw);verified_encoded+=metadata['payload_storage_codec']['encoded_bytes']
    if science_exit_code==0 and (verified_raw!=terminal['codec_costs']['raw_payload_bytes'] or
        verified_raw!=terminal['costs']['capsule_bytes'] or verified_encoded!=terminal['codec_costs']['encoded_payload_bytes']):
        raise EvidenceStop('Complete encoded/raw capsule byte cost changed')
    if (folder/'Result.json').exists() and science_exit_code==0:
        result=read(folder/'Result.json')
        if (canonical(result['actual_original_observer_costs'])!=canonical(terminal['costs']) or
            canonical(result['actual_compression_costs'])!=canonical(terminal['codec_costs'])):
            raise EvidenceStop('Final source or codec cost snapshot changed')
    return dict(report,journal_tip=tip,verified_compressed_capsules=len(unique),
        verified_raw_bytes=verified_raw,verified_encoded_bytes=verified_encoded,
        final_terminal_write_seconds=receipt['terminal_write_seconds'],
        complete_storage_scans=terminal['complete_storage_scans'],
        complete_storage_scan_seconds=terminal['complete_storage_scan_seconds'])


def derive_complete_source_check(study, protocol, ownership):
    """Only opaque read changes; original complete-only assertions stay exact."""
    tree=ast.parse(OLD_READER.read_text('utf8'))
    original=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='saved_source_check')
    derived=copy.deepcopy(original)
    capsule=next(n for n in derived.body if isinstance(n,ast.FunctionDef) and n.name=='capsule')
    target=next(n for n in capsule.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='raw' for t in n.targets))
    old_value=copy.deepcopy(target.value)
    target.value=ast.parse("read_compressed_capsule(d,anchor,max_raw_bytes=p['max_raw_capsule_bytes'],max_encoded_bytes=p['max_encoded_capsule_bytes'])",mode='eval').body
    reverse=copy.deepcopy(derived)
    cap=next(n for n in reverse.body if isinstance(n,ast.FunctionDef) and n.name=='capsule')
    next(n for n in cap.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='raw' for t in n.targets)).value=old_value
    assert ast.dump(reverse,include_attributes=False)==ast.dump(original,include_attributes=False)
    study=Path(study).resolve()
    def closure(folder):
        relative=Path(str(folder).removeprefix('\\\\?\\')).relative_to(study).parts
        phase,job=relative[0],relative[1]
        record=next(x for x in ownership['entries'] if x['job_id']==job)
        key='branch' if phase=='branches' else 'replay'
        item=record[key]
        source=protocol['branch_worker_path'] if key=='branch' else protocol['replay_worker_path']
        m=verify_closed_owner(folder,item,protocol['_protocol_sha256'],protocol['source_sha256'][source])
        if m['exit_code']!=0:raise EvidenceStop('Complete-only source reader refuses partial owner')
        if key=='branch':read_terminal_prefix(folder,protocol,protocol['_protocol_sha256'],science_exit_code=0)
    env=original_reader.__dict__.copy()
    env.update(BASE=study,verify_manifest=closure,read_compressed_capsule=read_compressed_capsule)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[derived],type_ignores=[])),
        '<unchanged complete-source reader with anchored compressed byte read>','exec'),env)
    certificate={'original_complete_reader_sha256':sha(OLD_READER.read_bytes()),
        'complete_source_check_reverse_AST_exact':True,
        'every_original_complete_source_input_menu_mask_score_action_result_and_cost_assertion_retained':True,
        'only_function_AST_change':'externally anchored compressed capsule read',
        'external_owner_manifest_PID_parent_command_and_terminal_cost_checks_added_before_original_checks':True,
        'partial_owner_complete_reader_refused':True,'actual_source_replay_executed_by_derivation':False}
    return env['saved_source_check'],certificate


def compare_measured_fields(expected, actual):
    """Same field/UV/tolerance contract as the original charged replay."""
    fields={'vm_pu','va_degree','p_mw','q_mvar'}
    if not expected or set(expected)!=set(actual):raise EvidenceStop('Replay bus scope missing/changed')
    for bus in expected:
        if set(expected[bus])!=fields or set(actual[bus])!=fields:
            raise EvidenceStop('Replay equation fields missing/changed')
    values=[v for d in (expected,actual) for row in d.values() for v in row.values()]
    if not all(type(v) in (int,float) and math.isfinite(v) for v in values):
        raise EvidenceStop('Replay equation field nonfinite')
    delta=max(abs(expected[b][f]-actual[b][f]) for b in expected for f in fields)
    if delta>1e-10 or sorted(b for b in expected if expected[b]['vm_pu']<.95)!=sorted(b for b in actual if actual[b]['vm_pu']<.95):
        raise EvidenceStop('Replay field/UV agreement fails original tolerance')
    return delta


def verify_returned_replay_bytes(branch, replay, record, protocol, protocol_sha256, ownership):
    """Check actual paid raw replay packets; ZERO new PF or model calls."""
    branch,replay=local_root(branch),local_root(replay)
    for folder,key,source in ((branch,'branch',protocol['branch_worker_path']),
        (replay,'replay',protocol['replay_worker_path'])):
        m=verify_closed_owner(folder,ownership[key],protocol_sha256,protocol['source_sha256'][source])
        if m['exit_code']!=0:raise EvidenceStop('Complete replay field reader refuses a partial owner')
    rows,_=validate_chain((replay/'scientific.jsonl').read_bytes(),protocol_sha256)
    intents=[r['payload'] for r in rows if r['event']=='replay_PF_intent']
    returns=[r['payload'] for r in rows if r['event']=='replay_PF_return']
    expected=[('initial','initial')]
    for item in record['actual_commit_records']:
        expected.extend([('trial',f"trial_{item['decision']:02d}"),('commit',f"commit_{item['decision']:02d}")])
    if ([(x['role'],x['identity']) for x in returns]!=expected or
        [(x['role'],x['identity']) for x in intents]!=expected or
        any(r['event']=='replay_PF_exception' for r in rows)):
        raise EvidenceStop('Complete continuous replay order/identities/returns changed')
    paid_rows,_=validate_chain((branch/'scientific.jsonl').read_bytes(),protocol_sha256)
    initial=next(r['payload']['anchors'] for r in paid_rows if r['event']=='literal_PF_return' and r['payload']['role']=='initial')
    anchors=[initial]
    for c in record['actual_commit_records']:anchors.extend([c['selected_trial'],c['actual_commit']])
    deltas=[];nets=[]
    for intent,returned,anchor in zip(intents,returns,anchors,strict=True):
        if intent['kwargs']!=SOLVER_ROLES[intent['role']]:raise EvidenceStop('Continuous replay solver options changed')
        raw=(replay/(returned['identity']+'.pkl')).read_bytes()
        if len(raw)!=returned['bytes'] or sha(raw)!=returned['payload_sha256']:
            raise EvidenceStop('Continuous paid replay payload anchor changed')
        # Trusted local owner/closure verification must precede this function.
        net=pickle.loads(raw);actual=measured_bus_fields(net)
        if canonical(actual)!=canonical(returned['fields']):raise EvidenceStop('Replay journal fields do not match actual packet')
        original=pickle.loads(read_compressed_capsule(branch/anchor['relative'],anchor,
            max_raw_bytes=protocol['max_raw_capsule_bytes'],max_encoded_bytes=protocol['max_encoded_capsule_bytes']))['net']
        if original_reader.signature(original)!=original_reader.signature(net):
            raise EvidenceStop('Independent continuous replay native inputs/action state differ')
        deltas.append(compare_measured_fields(measured_bus_fields(original),actual));nets.append(net)
    result=read(replay/'Result.json')
    if max(deltas)!=result['maximum_field_delta']:raise EvidenceStop('Reported replay maximum differs from independently calculated fields')
    # Validate each selected trial/actual commit against the actual previous
    # replay current, with the original literal/protected upper contracts.
    _,runner,_=original_reader.load_stack()
    for i,c in enumerate(record['actual_commit_records']):
        proof=check_commit(measured_bus_fields(nets[1+2*i]),measured_bus_fields(nets[2+2*i]),
            runner.rescue.grid_metrics(nets[2*i]),
            cap_totals(nets[2+2*i]),upper=1.06 if record['guard'] is None else 1.05,
            guard_tolerance=0. if record['guard'] is None else 1e-8)
        if not proof['all_declared_continuous_fields_within_tolerance']:
            raise EvidenceStop('Replayed trial/commit contract failed')
    return {'actual_saved_replay_packets_checked':len(returns),'maximum_field_delta_independently_computed':max(deltas),
        'actual_new_solver_calls':0,'actual_new_model_calls':0,'full_replay_costs_not_free':result['charged_replay_costs']}


def verify_paid_partial_scope(folder, spec, protocol, protocol_sha256):
    """Masks/equations/caps on recorded receipts; no complete policy claim.

Caller first verifies the externally closed owner. Actual returned bytes are
the only solver replies. Missing half-calls or candidate results remain
explicit UNKNOWN; no partial endpoint, chosen-policy rank or success gate.
"""
    folder=local_root(folder)
    rows,_=validate_chain((folder/'scientific.jsonl').read_bytes(),protocol_sha256)
    def capsule(anchor):
        return pickle.loads(read_compressed_capsule(folder/anchor['relative'],anchor,
            max_raw_bytes=protocol['max_raw_capsule_bytes'],max_encoded_bytes=protocol['max_encoded_capsule_bytes']))['net']
    menus=[r['payload'] for r in rows if r['event']=='literal_preselection_full_menu']
    candidates=[r['payload'] for r in rows if r['event']=='literal_candidate_return']
    searched=[r['payload'] for r in rows if r['event']=='literal_complete_search_return']
    commits=[r['payload'] for r in rows if r['event']=='literal_actual_commit_verified']
    _,runner,_=original_reader.load_stack()
    zones=read(ROOT/protocol['metadata_path'])['zones']
    parents={}
    for menu in menus:
        decision=menu['decision']
        if decision in parents:raise EvidenceStop('Repeated native current/menu identity')
        net=capsule(menu['parent']);parents[decision]=net
        reports={z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
        buses=runner.rescue.candidate_buses_from_state(net,zones,reports,[])
        expected=[runner.rescue.make_action(b,q) for b in buses for q in runner.rescue.Q_SWEEP]
        if canonical(expected)!=canonical(menu['ordered_menu']):raise EvidenceStop('Raw native scope/Q/cap menu changed')
        taken=[c for c in candidates if c['decision']==decision]
        if canonical([c['action'] for c in taken])!=canonical(expected[:len(taken)]):
            raise EvidenceStop('Returned actions not exact declared-order prefix')
    import pandapower as pp
    blocked=[];active=None
    public={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph','rundcopp') if hasattr(pp,n)}
    def refuse(*args,**kwargs):
        blocked.append(True);raise EvidenceStop('Partial source reader must not invoke a backend')
    for n in public:setattr(pp,n,refuse)
    exceptions=[r['payload']['anchors'] for r in rows if r['event']=='literal_PF_exception']
    def reply(net,**kwargs):
        if active is None or kwargs!=SOLVER_ROLES['trial'] or len(active['solver_capsules'])!=1:
            raise EvidenceStop('Unissued/multiple/changed partial saved reply')
        anchor=active['solver_capsules'][0];saved=capsule(anchor)
        if original_reader.signature(net)!=original_reader.signature(saved):raise EvidenceStop('Paid partial reply input differs')
        net.clear();net.update(copy.deepcopy(saved))
        if anchor in exceptions:raise RuntimeError('Saved genuine exception only; no new PF')
    pp.runpp=reply
    guard=original_reader.NormalUpperMediation(runner.rescue,1.05,1e-8) if spec['guard'] is not None else None
    try:
        if guard:guard.__enter__()
        for c in candidates:
            if c['decision'] not in parents:raise EvidenceStop('Paid candidate has no measured current parent')
            active=c
            answer=runner.rescue.verify_action(copy.deepcopy(parents[c['decision']]),c['action'])
            if canonical(answer)!=canonical(c['verification']):raise EvidenceStop('Native partial mask/verification changed')
            active=None
    finally:
        if guard:guard.__exit__()
        for n,f in public.items():setattr(pp,n,f)
    if blocked:raise EvidenceStop('Unexpected public solver attempt blocked')
    for search in searched:
        decision=search['decision'];cs=search['candidates']
        menu=next(x for x in menus if x['decision']==decision)
        if (canonical([c['action'] for c in cs])!=canonical(menu['ordered_menu']) or
            canonical([runner.rescue.score_candidate(c) for c in cs])!=canonical(search['scores']) or
            canonical([c['verif'] for c in cs])!=canonical([c['verification'] for c in candidates if c['decision']==decision])):
            raise EvidenceStop('Completed partial-search menu/score/receipt join changed')
    for entry in commits:
        decision=entry['decision']
        selected=next(c for c in candidates if c['decision']==decision and c['action']==entry['action'])
        if not selected['verification']['accepted'] or entry['selected_trial'] not in selected['solver_capsules']:
            raise EvidenceStop('Partial commit lacks exact paid admitted receipt')
        trial,actual=capsule(entry['selected_trial']),capsule(entry['actual_commit'])
        proof=check_commit(measured_bus_fields(trial),measured_bus_fields(actual),selected['verification']['before'],cap_totals(actual),
            upper=1.06 if spec['guard'] is None else 1.05,guard_tolerance=0. if spec['guard'] is None else 1e-8)
        if canonical(proof)!=canonical(entry['proof']):raise EvidenceStop('Paid partial commit equation/protection proof differs')
        if decision+1 in parents and (original_reader.signature(parents[decision+1])!=original_reader.signature(actual) or
            canonical(measured_bus_fields(parents[decision+1]))!=canonical(measured_bus_fields(actual))):
            raise EvidenceStop('Next recorded current is not the actual committed state')
    return {'scope':'PAID_PREFIX_MENU_MASK_SCORE_COMMIT_FIELDS_ONLY',
        'measured_current_menus':len(menus),'returned_candidate_receipts':len(candidates),
        'complete_recorded_searches':len(searched),'recorded_protected_commit_proofs':len(commits),
        'original_root_ALT_and_whole_policy_selection':'NOT_VERIFIED_ON_PARTIAL',
        'endpoint_continuous_full_replay_economic_headroom_and_LLM_gate':'UNKNOWN',
        'actual_new_PF_model_optimizer_calls':0}


def audit_closed_job(study, spec, protocol, ownership, protocol_sha256):
    """Independent per-identity result; never promotes a partial to a gate."""
    study=Path(study).resolve()
    if not study.is_relative_to(ROOT/'outputs') or study==original_reader.BASE:
        raise EvidenceStop('Separate prospective new-study namespace required')
    for name,h in protocol['source_sha256'].items():
        if sha((ROOT/name).read_bytes())!=h:raise EvidenceStop('Pinned reader/scientific source changed: '+name)
    for key in ('network','metadata'):
        if sha((ROOT/protocol[key+'_path']).read_bytes())!=protocol[key+'_sha256']:
            raise EvidenceStop('Frozen physical input changed')
    if sha((ROOT/spec['scenario_path']).read_bytes())!=spec['scenario_sha256']:
        raise EvidenceStop('Declared root recipe changed')
    branch=local_root(study/'branches'/spec['job_id'])
    entry=next(x for x in ownership['entries'] if x['job_id']==spec['job_id'])
    external=entry['branch']
    closed=verify_closed_owner(branch,external,protocol_sha256,protocol['source_sha256'][protocol['branch_worker_path']])
    import pandapower as pp
    originals={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph','rundcopp') if hasattr(pp,n)}
    attempted=[]
    def refuse(*args,**kwargs):
        attempted.append(True);raise EvidenceStop('Independent reader refuses every genuine new solver call')
    for n in originals:setattr(pp,n,refuse)
    try:
        if closed['exit_code']!=0:
            # Before-observer setup failures may have no scientific journal or
            # terminal snapshot. Do not impute zero unobserved calls or costs.
            if not (branch/'scientific.jsonl').exists() or not (branch/'Terminal_Cost_Receipt.json').exists():
                return {'job_id':spec['job_id'],'status':'PRESERVED_FAILURE_UNKNOWN_SCIENTIFIC_LEDGER',
                    'recorded_endpoint_source_policy_and_gates':'UNKNOWN',
                    'whole_owned_seconds':external['owned_seconds'],
                    'unrecovered_scientific_counts_and_cost_subintervals':'UNKNOWN',
                    'actual_new_reader_PF_model_optimizer_calls':0,'no_scientific_retry':True}
            cost=read_terminal_prefix(branch,protocol,protocol_sha256,science_exit_code=closed['exit_code'])
            physical=verify_paid_partial_scope(branch,spec,protocol,protocol_sha256)
            return {'job_id':spec['job_id'],'status':'PASS_RECORDED_PREFIX_ONLY_SCIENCE_TERMINAL_PARTIAL',
                'ledger':cost,'physical_prefix':physical,'whole_owned_seconds':external['owned_seconds'],
                'complete_endpoint_source_policy_replay_economic_headroom_and_LLM_gates':'UNKNOWN',
                'actual_new_reader_PF_model_optimizer_calls':0,'no_scientific_retry':True}
        # The complete-only body keeps every original assertion and requires
        # the complete separately owned/charged physical replay and both costs.
        p=dict(protocol,_protocol_sha256=protocol_sha256)
        checker,certificate=derive_complete_source_check(study,p,ownership)
        source=checker(spec,p,protocol_sha256)
        fields=verify_returned_replay_bytes(branch,study/'replays'/spec['job_id'],read(branch/'Result.json'),p,protocol_sha256,entry)
        cost=read_terminal_prefix(branch,p,protocol_sha256,science_exit_code=0)
        if attempted:raise EvidenceStop('Unexpected actual solver attempt blocked')
        return {'job_id':spec['job_id'],'status':'PASS_COMPLETE_SOURCE_FIELDS_PAID_REPLAY_COST_AND_CLOSURE',
            'original_complete_source_check':source,'additional_independent_replay_fields':fields,
            'terminal_and_compression_costs':cost,'source_derivation':certificate,
            'whole_branch_owned_seconds':entry['branch']['owned_seconds'],
            'whole_replay_owned_seconds':entry['replay']['owned_seconds'],
            'actual_new_reader_PF_model_optimizer_calls':0,
            'single_branch_is_not_FULL_BOTH_portfolio_or_LLM_superiority':True}
    finally:
        for n,f in originals.items():setattr(pp,n,f)
