"""Positive-only exact native input comparison for possible paid PF reuse.

Unsupported fields, stale warm results, different native masks or any mismatch
remain UNKNOWN. No match authorizes reuse of old resource verdicts or scores.
The caller must re-evaluate the source verifier under its current resources.
"""
import datetime
import numpy as np,pandas as pd
from scipy import sparse
class InputNotExactlyMatched(RuntimeError):pass
def require_same(a,b,path='net'):
    if type(a) is not type(b):raise InputNotExactlyMatched(path+':type')
    if a is None or a is pd.NA or a is pd.NaT:
        if a is not b:raise InputNotExactlyMatched(path+':missing')
    elif isinstance(a,pd.DataFrame):
        try:pd.testing.assert_frame_equal(a,b,check_exact=True,check_dtype=True,check_frame_type=True,check_flags=True)
        except AssertionError as exc:raise InputNotExactlyMatched(path+':frame') from exc
        require_same(a.attrs,b.attrs,path+'.attrs')
        for col in a.columns:
            if a[col].dtype==object:
                for i,(x,y) in enumerate(zip(a[col].array,b[col].array)):require_same(x,y,path+f'.{col}[{i}]')
    elif isinstance(a,pd.Series):
        try:pd.testing.assert_series_equal(a,b,check_exact=True,check_dtype=True)
        except AssertionError as exc:raise InputNotExactlyMatched(path+':series') from exc
        require_same(a.attrs,b.attrs,path+'.attrs')
    elif isinstance(a,np.ndarray):
        if a.dtype!=b.dtype or a.shape!=b.shape:raise InputNotExactlyMatched(path+':array layout')
        if a.dtype.hasobject:
            for i,(x,y) in enumerate(zip(a.flat,b.flat)):require_same(x,y,path+f'[{i}]')
        elif a.tobytes()!=b.tobytes():raise InputNotExactlyMatched(path+':array bytes')
    elif sparse.issparse(a):
        if a.shape!=b.shape or a.format!=b.format:raise InputNotExactlyMatched(path+':sparse layout')
        # All actual source native matrices are compressed sparse; fail closed
        # for a new sparse representation rather than quietly converting it.
        if not all(hasattr(a,k) for k in ['data','indices','indptr']):raise InputNotExactlyMatched(path+':unsupported sparse')
        for k in ['data','indices','indptr']:require_same(getattr(a,k),getattr(b,k),path+'.'+k)
    elif isinstance(a,dict):
        if list(a)!=list(b):raise InputNotExactlyMatched(path+':mapping order/keys')
        if hasattr(a,'default_factory') and a.default_factory is not b.default_factory:raise InputNotExactlyMatched(path+':default factory')
        for k in a:require_same(a[k],b[k],path+'.'+str(k))
    elif isinstance(a,(list,tuple)):
        if len(a)!=len(b):raise InputNotExactlyMatched(path+':length')
        for i,(x,y) in enumerate(zip(a,b)):require_same(x,y,path+f'[{i}]')
    elif isinstance(a,np.generic):
        if a.dtype!=b.dtype or a.tobytes()!=b.tobytes():raise InputNotExactlyMatched(path+':numpy scalar')
    elif isinstance(a,float):
        if np.float64(a).tobytes()!=np.float64(b).tobytes():raise InputNotExactlyMatched(path+':float bytes')
    elif isinstance(a,(str,int,bool,complex,datetime.date,datetime.datetime)):
        if a!=b:raise InputNotExactlyMatched(path+':value')
    elif isinstance(a,np.dtype):
        if a!=b:raise InputNotExactlyMatched(path+':dtype')
    else:raise InputNotExactlyMatched(path+':unsupported '+type(a).__qualname__)
    return True
