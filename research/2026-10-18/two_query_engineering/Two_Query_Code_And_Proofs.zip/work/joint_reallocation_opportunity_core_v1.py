"""New one-move opportunity universe; no model, solver or science on import."""
import ast,copy,hashlib,json,math,pickle,zlib
from pathlib import Path
import numpy as np
from scipy.linalg import lu_factor,lu_solve
from pandapower.pypower.dSbus_dV import dSbus_dV
from owned_bank_joint_reallocation_v1 import prepare_equal_reallocation,Q_GRID

ROOT=Path(__file__).resolve().parents[1]

def load_endpoint(entry):
    p=ROOT/entry['endpoint_record'];r=json.loads(p.read_text('utf-8'));d=r['endpoint']
    packet=(ROOT/entry['decoded_net_container_root']/d['path']).read_bytes()
    assert len(packet)==d['encoded_bytes'] and hashlib.sha256(packet).hexdigest()==d['encoded_sha256']
    dec=zlib.decompressobj();b=dec.decompress(packet,d['raw_bytes']+1)
    assert dec.eof and not dec.unused_data and not dec.unconsumed_tail and len(b)==d['raw_bytes'] and hashlib.sha256(b).hexdigest()==d['raw_sha256']
    x=pickle.loads(b);net=x['net'];cursor=copy.deepcopy(r['cursor'])
    cursor['raw_current_receiver_scope']=r['native_common_AND_zone_buses']
    assert net.converged and len(net.res_bus)==118
    assert {str(int(i)):{k:float(net.res_bus.at[i,k]) for k in ('vm_pu','va_degree','p_mw','q_mvar')} for i in net.res_bus.index}==r['measured_fields']
    return net,cursor,x

def universe(cursor):
    rows=[]
    for bus in sorted(cursor['raw_current_receiver_scope']):
        for q in Q_GRID:
            rows.append({'kind':'ordinary','receiver':bus,'q':q,'donor_index':None,'donor_bus':None})
    for bank in sorted(cursor['owned_bank_rows'],key=lambda b:b['index']):
        for bus in sorted(cursor['raw_current_receiver_scope']):
            if bus==bank['bus']:continue
            for q in Q_GRID:
                if q<=abs(bank['q_mvar']):
                    rows.append({'kind':'equal_owned_reallocation','receiver':bus,'q':q,
                        'donor_index':bank['index'],'donor_bus':bank['bus']})
    for i,r in enumerate(rows):r['universe_index']=i
    return rows

def action(row):
    a={'add_shunts_q_mvar':{str(row['receiver']):row['q']}}
    if row['kind']=='equal_owned_reallocation':a['_owned_equal_reallocation']={'donor_index':row['donor_index'],'q_mvar':row['q']}
    return a

def build_verifier(rescue,cursor):
    path=ROOT/'work/e/audit/phase2g_rescue_runner.py';tree=ast.parse(path.read_text('utf-8'))
    old=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify_action');new=copy.deepcopy(old)
    targets=[i for i,n in enumerate(new.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='apply_action']
    assert len(targets)==1;i=targets[0]
    new.body[i]=ast.parse('test_net = actuate_candidate(test_net, action)').body[0]
    inverse=copy.deepcopy(new);inverse.body[i]=copy.deepcopy(old.body[i])
    assert ast.dump(inverse,include_attributes=False)==ast.dump(old,include_attributes=False)
    def actuate(net,a):
        bus,q=next(iter(a['add_shunts_q_mvar'].items()));bus=int(bus);q=float(q)
        assert cursor['positive_addition_lifetime_MVAr'].get(str(bus),0)+q<=450
        if '_owned_equal_reallocation' in a:
            h=a['_owned_equal_reallocation'];assert h['q_mvar']==q
            draft=prepare_equal_reallocation(net,cursor,donor_index=h['donor_index'],receiver_bus=bus,q_mvar=q,add_positive=rescue.apply_action)
            return draft['candidate_net']
        assert bus in cursor['raw_current_receiver_scope'] and q in Q_GRID
        rescue.apply_action(net,a);net.converged=False;return net
    g=dict(rescue.__dict__);g['actuate_candidate']=actuate
    exec(compile(ast.fix_missing_locations(ast.Module(body=[new],type_ignores=[])),str(path),'exec'),g)
    certificate={'original_source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'all_original_cap_solver_UV_deficit_minimum_improvement_HARD_OV_predicates_unchanged':True,
        'only_change':'Replace the old positive actuation call with declared source-owned joint/ordinary actuation.',
        'reverse_AST_exact':True}
    return g['verify_action'],actuate,certificate

def current_ordering(net,cost):
    """Current actual generator mask: ordering only; no nonlinear safety claim."""
    case=net['_ppc'];Y=case['internal']['Ybus'];V=case['internal']['V']
    mapping=np.asarray(net['_pd2ppc_lookups']['bus'],dtype=int)
    assert Y.shape==(118,118) and V.shape==(118,) and set(mapping)==set(range(118))
    actual=np.array([net.res_bus.at[b,'vm_pu']*np.exp(1j*np.deg2rad(net.res_bus.at[b,'va_degree'])) for b in range(118)])
    assert np.max(np.abs(V[mapping]-actual))<=1e-14
    types=case['bus'][:,1].astype(int);nr=np.flatnonzero(types!=3);pq=np.flatnonzero(types==1)
    assert len(nr)==117
    cost['public_derivative_attempts']+=1;m,a=dSbus_dV(Y,V);cost['public_derivative_returns']+=1
    m,a=m.toarray(),a.toarray()
    J=np.block([[a.real[np.ix_(nr,nr)],m.real[np.ix_(nr,pq)]],
                [a.imag[np.ix_(pq,nr)],m.imag[np.ix_(pq,pq)]]])
    B=np.zeros((len(J),118));positions={int(k):j for j,k in enumerate(pq)}
    for b,k in enumerate(mapping):
        if int(k) in positions:B[len(nr)+positions[int(k)],b]=abs(V[k])**2/float(case['baseMVA'])
    cost['LU_factor_attempts']+=1;factor=lu_factor(J,check_finite=True);cost['LU_factor_returns']+=1
    cost['LU_solve_attempts']+=1;X=lu_solve(factor,B,check_finite=True);cost['LU_solve_returns']+=1;cost['RHS_columns']+=118
    assert np.isfinite(X).all() and np.max(np.abs(J@X-B))<=1e-8
    S=np.zeros((118,118));S[pq,:]=X[len(nr):,:];S=S[mapping,:]
    return {'Y':Y.toarray(),'V':V,'mapping':mapping,'actual_bus_types':types,'nonref':nr,'PQ':pq,
        'm':m,'a':a,'J':J,'B':B,'X':X,'sensitivity':S,'current_vm':net.res_bus.loc[range(118),'vm_pu'].to_numpy()}

def forecast(row,context,before):
    change=context['sensitivity'][:,row['receiver']].copy()
    if row['donor_bus'] is not None:change-=context['sensitivity'][:,row['donor_bus']]
    vm=context['current_vm']+row['q']*change
    if not np.isfinite(vm).all() or (vm<=0).any():return {'status':'UNKNOWN_NONPHYSICAL_LINEAR_FORECAST','score':[-999]*5}
    after={'uv_count':int((vm<.95).sum()),'deficit_sum':float(np.maximum(.95-vm,0).sum()),'vmin':float(vm.min()),'vmax':float(vm.max())}
    return {'status':'FINITE_ORDERING_ONLY_FIXED_CURRENT_MASK_UNKNOWN_NONLINEAR_CONVERGENCE',
        'after':after,'score':[int(after['uv_count']==0),before['uv_count']-after['uv_count'],before['deficit_sum']-after['deficit_sum'],after['vmin']-before['vmin'],-row['q']]}
