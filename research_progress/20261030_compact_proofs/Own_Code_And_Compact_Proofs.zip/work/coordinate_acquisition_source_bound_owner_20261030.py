"""One exact-source owned chain, with terminal ACK even for partial/failure.

No retry, replacement owner, reader launch or experiment entry is implemented
here. The caller may separately read a closed partial result after End_ACK.
"""
import argparse
import json
import math
import os
import subprocess
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from coordinate_native_inverter_linear_reference_20261020 import process, sha, put

ROOT = Path(__file__).resolve().parents[1]


def require(value, message):
    if not value:
        raise ValueError(message)


def scoped(root, relative):
    path = (root/relative).resolve(); path.relative_to(root)
    return path


def contains_source(row, source):
    return bool(row and str(source).replace('/', '\\').lower() in
                (row.get('CommandLine') or '').replace('/', '\\').lower())


def terminate_owned_tree(pid):
    return subprocess.run(['taskkill.exe', '/PID', str(pid), '/T', '/F'], capture_output=True,
                          timeout=30, creationflags=subprocess.CREATE_NO_WINDOW).returncode


def coordinate(protocol_path, root=ROOT, *, popen=None, inspect_process=None, terminate_tree=None,
               monotonic=None, sleep=None):
    """Injectable process boundaries permit software tests without launching jobs."""
    root = Path(root).resolve()
    popen = subprocess.Popen if popen is None else popen
    inspect_process = process if inspect_process is None else inspect_process
    terminate_tree = terminate_owned_tree if terminate_tree is None else terminate_tree
    monotonic = time.monotonic if monotonic is None else monotonic
    sleep = time.sleep if sleep is None else sleep
    protocol_path = scoped(root, protocol_path)
    p = json.loads(protocol_path.read_text(encoding='utf-8')); spec = p['single_owner']
    protocol_digest = sha(protocol_path)
    bound = spec['bound_seconds']
    require(type(bound) in (int, float) and math.isfinite(bound) and bound > 0, 'Invalid original owner bound')
    for relative in p.get('require_ended_claims', []):
        old = json.loads(scoped(root, relative).read_text(encoding='utf-8'))
        current = inspect_process(old['actual_pid'])
        require(not current or p['old_scientific_source_name'] not in (current.get('CommandLine') or ''), 'Original scientific chain remains live')
    source = scoped(root, spec['source']); directory = scoped(root, spec['output']); out = scoped(root, spec['coordination'])
    require(not directory.exists() and not out.exists(), 'Existing owner/output claim: no restart or overwrite')
    require(sha(source) == spec['sha256'], 'Owner source changed')
    out.mkdir()
    put(out/'owner.claim', {'actual_pid': os.getpid(), 'parent_pid': os.getppid(),
        'source_sha256': sha(__file__), 'protocol_sha256': protocol_digest, 'at_utc': datetime.now(timezone.utc).isoformat()})
    child = None; claim = None; code = None; failure = None; timed_out = False
    authenticated = False; chain_ended = False; termination = []; start = monotonic()
    try:
        with (out/'Owner.log').open('x', encoding='utf-8') as log:
            child = popen([str(scoped(root, spec['python'])), '-X', 'utf8', str(source)], cwd=root,
                          stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
            while not (directory/'owner.claim').exists():
                require(child.poll() is None, 'Owner ended before an authenticated claim')
                require(monotonic()-start < min(60., bound), 'Owner claim deadline expired')
                sleep(.1)
            claim = json.loads((directory/'owner.claim').read_text(encoding='utf-8'))
            actual = inspect_process(claim['actual_pid']); parent = inspect_process(claim['parent_pid'])
            require(actual and parent and actual['ParentProcessId'] == claim['parent_pid'] == child.pid
                    and contains_source(actual, source) and claim['source_sha256'] == sha(source), 'Owner PID/parent/source custody mismatch')
            authenticated = True
            put(directory/'Launcher_ACK.json', {'actual_pid': claim['actual_pid'], 'actual_parent_pid': child.pid,
                'actual_command': actual['CommandLine'], 'parent_command': parent['CommandLine'],
                'fresh_exact_source_PID_parent_command': True, 'at_utc': datetime.now(timezone.utc).isoformat()})
            code = child.wait(timeout=max(0., bound-(monotonic()-start)))
            require(inspect_process(claim['actual_pid']) is None and inspect_process(child.pid) is None,
                    'Claimed actual chain still live after launcher exit')
            chain_ended = True
    except BaseException as exc:
        timed_out = isinstance(exc, subprocess.TimeoutExpired)
        failure = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
    finally:
        # Terminate only the source-bound actual owner or the still-live process
        # launched here whose exact command contains that source. Never retry.
        if child is not None:
            try:
                if authenticated:
                    actual = inspect_process(claim['actual_pid'])
                    if actual:
                        require(actual['ParentProcessId'] == child.pid and contains_source(actual, source), 'Refuse termination of substituted actual PID')
                        termination.append({'pid': claim['actual_pid'], 'returncode': terminate_tree(claim['actual_pid'])})
                if child.poll() is None:
                    launcher = inspect_process(child.pid)
                    require(contains_source(launcher, source), 'Refuse termination of substituted launcher PID')
                    termination.append({'pid': child.pid, 'returncode': terminate_tree(child.pid)})
                code = child.wait(timeout=30)
                chain_ended = bool(authenticated and inspect_process(claim['actual_pid']) is None
                                   and inspect_process(child.pid) is None)
            except BaseException as exc:
                chain_ended = False
                termination.append({'status': 'UNKNOWN_CHAIN_TERMINATION', 'error': repr(exc)})
        end = {'status': 'ACTUAL_OWNED_CHAIN_ENDED' if chain_ended else 'UNKNOWN_OWNED_CHAIN_END_NOT_VERIFIED',
               'actual_pid': None if claim is None else claim.get('actual_pid'),
               'launcher_pid': None if child is None else child.pid, 'exit_code': code,
               'actual_owned_chain_ended': chain_ended, 'source_and_parent_authenticated': authenticated,
               'original_bound_seconds': bound, 'elapsed_seconds': monotonic()-start,
               'timed_out': timed_out, 'failure': failure, 'termination': termination,
               'automatic_retry_or_replacement': False,
               'protocol_sha256': protocol_digest, 'source_sha256': spec['sha256']}
        put(out/'End_ACK.json', end)
        if failure is not None:
            put(out/'Failure.json', failure)
    successful = code == 0 and chain_ended and failure is None and not timed_out
    if successful:
        put(out/'Completion.json', {'status': 'SINGLE_SOURCE_BOUND_OWNER_COMPLETE',
            'all_owned_actors_ended': True, 'primary_exit_code': 0, 'at_utc': datetime.now(timezone.utc).isoformat()})
    # A closed partial result may be audited by a separate caller even with this
    # nonzero return. Nothing here converts a failure into successful science.
    return 0 if successful else (124 if timed_out else (code if isinstance(code, int) and code != 0 else 1))


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--protocol', required=True)
    args = parser.parse_args()
    raise SystemExit(coordinate(args.protocol))


if __name__ == '__main__':
    main()
