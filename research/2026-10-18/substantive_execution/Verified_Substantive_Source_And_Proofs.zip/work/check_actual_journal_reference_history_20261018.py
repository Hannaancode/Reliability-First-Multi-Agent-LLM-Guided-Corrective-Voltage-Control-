"""Fixed exact actual 35MB decision preservation check, zero new science."""
import argparse,copy,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
from bounded_chunk_evidence_store_v1_20261015 import restore
from paid_receding_journal_reference_history_v1_20261018 import ReceiptJournalIndex,ReferencedHistory,verify_reference_history,expand_reference_record,canon,digest,read_reference,context
R=Path(__file__).resolve().parents[1];B=R/'outputs/actual_journal_reference_history_20261018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def old_record():
    source=read(R/'outputs/bounded_chunk_actual_history_engineering_20261015/Results.json')
    raw=restore(source['source_and_input_anchor'])[0]['payload']
    assert len(raw)==35228332
    return raw,json.loads(raw)
def cold():
    request=read(B/'Cold_Request.json');check=verify_reference_history(request['anchor'])
    raw,old=old_record();expanded=expand_reference_record(check['records'][0]['payload'])
    assert expanded==old['payload'] and canon(expanded)==canon(old['payload'])
    assert digest(raw)==request['original_raw_record_sha256']
    assert check['all_referenced_queries_exact']==len(old['payload']['query_messages'])
    put(B/'Cold_Result.json',{'status':'PASS_EXACT_COMPLETE_REPORT_IN_COLD_PROCESS','all_original_query_verdicts_scores_inputs_costs_capsule_references_order_exact':True,
        'queries':check['all_referenced_queries_exact'],'new_scientific_calls':0})
def main():
    begun=time.perf_counter();B.mkdir(exist_ok=False)
    put(B/'Protocol.json',{'role':'SOFTWARE_ONLY_REFERENCE_PRESERVATION_OF_FIXED_ACTUAL_OVERSIZE_RECORD50',
        'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'record_bound_bytes':4*1024**2,'query_event_bound_bytes':1024**2,
        'parent_bound_seconds':300,'cold_bound_seconds':120,'no_original_artifact_changes_or_new_science':True,
        'selection':'Exact previously failed35,228,332-byte record, selected for transport stress not physical outcome.',
        'source_sha256':{str(p.relative_to(R)):sha(p) for p in [Path(__file__),R/'work/paid_receding_journal_reference_history_v1_20261018.py',R/'work/paid_receding_chunked_history_v2_20261018.py']},
        'live_integration':'NOT_READY; future owner must index only fsynced queries, bind exact full scientific dependency prefix, source/input/protocol and checkpoint cursor; complete/partial independent reader required before performance.'})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    raw,record=old_record();report=record['payload'];expected=context(report);journal=R/'outputs/full_receding_paid_campaign_20261015/actual/scientific.jsonl'
    proto=read(R/'outputs/full_receding_paid_campaign_20261015/actual_cold_request/Request.json')['source_anchors']['protocol']
    index=ReceiptJournalIndex(journal,protocol_sha256=proto);found=0;scanned=0
    with journal.open('rb') as stream:
        while found<len(report['query_messages']):
            assert time.perf_counter()-begun<180,'Fixed software preparation bound; no extension'
            offset=stream.tell();line=stream.readline();assert line,'Actual recorded query is missing'
            scanned+=len(line)
            # Exact event context and ordered message identity are checked again
            # by the independent history expansion, not inferred from a count.
            e=json.loads(line)
            if e['event']=='every_query_receipt_closed_before_more_science' and context(e['data'])==expected:
                index.observe_closed_durable_query(offset,line);found+=1
    history=ReferencedHistory(B/'history',source_anchor=sha(R/'work/paid_receding_journal_reference_history_v1_20261018.py'),input_anchor=digest(raw),max_bytes=16*1024**2,query_index=index)
    history.append('complete_paid_receding_decision',report);anchor=history.anchor();history.close()
    restored=verify_reference_history(anchor);payload=restored['records'][0]['payload']
    encoded=canon(restored['records'][0]);checks={
        'complete_report_exact':expand_reference_record(payload)==report,
        'all_ordered_query_verdict_score_cost_capsule_fields_exact':restored['all_referenced_queries_exact']==len(report['query_messages']),
        'bounded_logical_history_record_below4MiB':len(encoded)<4*1024**2,
        'no_query_payloads_copied_into_history':'query_messages' not in payload['report_without_query_messages']}
    def reject(name,mutator):
        bad=copy.deepcopy(payload);mutator(bad)
        try:expand_reference_record(bad)
        except (AssertionError,ValueError,KeyError,FileNotFoundError):checks[name]=True
        else:raise AssertionError('Malformed reference accepted: '+name)
    reject('foreign_protocol_rejected',lambda v:v.update(scientific_protocol_sha256='f'*64))
    reject('missing_receipt_rejected_without_filling',lambda v:v['query_references'].pop())
    reject('reordered_receipts_rejected',lambda v:v['query_references'].reverse())
    reject('changed_context_rejected',lambda v:v['query_references'][0].update(context=['FOREIGN','method',0]))
    reject('changed_receipt_hash_rejected',lambda v:v['query_references'][0].update(message_sha256='f'*64))
    reject('outside_workspace_reference_rejected',lambda v:v['query_references'][0].update(journal='../../../../outside.jsonl'))
    ref=payload['query_references'][0]
    with journal.open('rb') as stream:stream.seek(ref['offset']);line=stream.read(ref['bytes'])
    (B/'Changed_Journal_Line.bin').write_bytes(b'!'+line[1:])
    reject('changed_journal_bytes_rejected',lambda v:v['query_references'][0].update(journal=str((B/'Changed_Journal_Line.bin').relative_to(R)),offset=0))
    put(B/'Cold_Request.json',{'anchor':anchor,'original_raw_record_sha256':digest(raw)})
    with (B/'cold_console.log').open('x',encoding='utf-8') as log:
        child=subprocess.Popen([sys.executable,'-X','utf8',str(Path(__file__)),'--cold'],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        code=child.wait(timeout=120)
    put(B/'Child_Exit.json',{'child_pid':child.pid,'exit_code':code});assert code==0,'Retain failure; no automatic rerun'
    checks['cold_process_exact_full_report']=read(B/'Cold_Result.json')['status']=='PASS_EXACT_COMPLETE_REPORT_IN_COLD_PROCESS'
    assert all(checks.values())
    put(B/'Results.json',{'status':'PASS_EXACT_JOURNAL_REFERENCE_COMPONENT','checks':checks,
        'actual_original_record_bytes':len(raw),'new_logical_history_record_bytes':len(encoded),
        'new_storage_bytes':anchor['committed_physical_bytes'],'ordered_queries':found,
        'original_journal_bytes_read':scanned,'anchor':anchor,'workflow_seconds':time.perf_counter()-begun,
        'new_model_PF_optimizer_forecast_derivative_or_solve_calls':0,
        'limitations':'Engineering on one preserved actual decision. No live controller/source-owner/full scientific-chain integration or new trajectory result; costs and raw scientific journal remain mandatory, not free.'})
    put(B/'Closed_Manifest.json',{'members':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()},'scientific_calls':0})
    print(json.dumps({'actual_reference_history':'PASS','queries':found,'old_bytes':len(raw),'new_bytes':len(encoded),'checks':len(checks),'new_science':0}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cold',action='store_true');a=p.parse_args();cold() if a.cold else main()
