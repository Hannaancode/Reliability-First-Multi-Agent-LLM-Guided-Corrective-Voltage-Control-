"""Exact conditional finite-cohort ceiling; zero model/PF/optimizer calls.

This concerns a native-role adaptation that retains the original UV-only stop.
It does not assert an unchanged federation model is physically admitted here.
"""
import ast
import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/paper_uv_stop_public13_ceiling_20261021'
SOURCE = R / 'work/e/audit/run_reflection_v4_safety_envelope.py'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def exact_guard_function(function):
    loop = next(n for n in function.body if isinstance(n, ast.For))
    guard_index = next(i for i, n in enumerate(loop.body)
                       if isinstance(n, ast.If) and ast.unparse(n.test) == "current['uv_count'] == 0")
    assert guard_index == 2
    assert isinstance(loop.body[0], ast.Assign)
    assert ast.unparse(loop.body[0].value) == 'runner.rescue.grid_metrics(net)'
    assert isinstance(loop.body[1], ast.Expr) and ast.unparse(loop.body[1]).startswith('print(')
    guard = loop.body[guard_index]
    assert ast.unparse(guard) == "if current['uv_count'] == 0:\n    result['stop_reason'] = 'full_restoration'\n    break"
    # Exercise the exact guard AST without source root setup/model/physics.
    skeleton = ast.parse('def check_guard(current):\n result = {}\n passed_guard = False\n for step in range(1):\n  pass\n  passed_guard = True\n return result, passed_guard\n')
    target_loop = next(n for n in skeleton.body[0].body if isinstance(n, ast.For))
    target_loop.body[0] = copy.deepcopy(guard)
    namespace = {}
    exec(compile(ast.fix_missing_locations(skeleton), '<EXACT_SOURCE_GUARD_ONLY>', 'exec'), namespace)
    return namespace['check_guard'], {
        'function': function.name, 'line': function.lineno, 'loop_line': loop.lineno,
        'guard_line': guard.lineno,
        'function_AST_sha256': hashlib.sha256(ast.dump(function, include_attributes=False).encode()).hexdigest(),
        'guard_AST_sha256': hashlib.sha256(ast.dump(guard, include_attributes=False).encode()).hexdigest(),
        'pre_guard_loop_statements': [ast.unparse(n) for n in loop.body[:guard_index]],
        'source_model_query_commitment_and_fallback_are_after_guard': True,
    }


def main():
    O.mkdir(exist_ok=False)
    source_map = read(R / 'outputs/full_system_comparison_20261021/Original_Paper_System_Source_Map.json')
    anchor = next(x for x in source_map['traces'] if x['source'] == SOURCE.relative_to(R).as_posix())
    assert sha(SOURCE) == anchor['source_sha256']
    source_tree = ast.parse(SOURCE.read_text(encoding='utf-8'))
    functions = [next(n for n in source_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
                 for name in ['run_one_scenario_two_best_v2', 'run_one_scenario_no_llm_fallback_first']]
    guards = [exact_guard_function(n) for n in functions]
    root_name = 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json'
    protocol = read(R / 'outputs/public13_matched_numeric_preparation_20261021/Protocol.json')
    assert sha(R / root_name) == protocol['source_and_input_hashes'][root_name]
    roots = read(R / root_name)['roots']
    assert [r['seed'] for r in roots] == list(range(500))
    rows = []
    for root in roots:
        vm = root['all13_initial_vm']
        uv = sum(v < .95 for v in vm)
        ov = sum(v > 1.05 for v in vm)
        initial_fullband = uv == 0 and ov == 0
        stopped = []
        for check, proof in guards:
            result, entered = check({'uv_count': uv})
            assert entered == (uv > 0)
            if uv == 0:
                assert result['stop_reason'] == 'full_restoration'
            stopped.append(not entered)
        # Optimistically assume every UV-starting case can be solved. UV=0/OV>0
        # cannot be changed by either branch when the same stop is retained.
        rows.append({'seed': root['seed'], 'initial_UV': uv, 'initial_OV': ov,
                     'both_branches_stop_before_queries_when_UV0': all(stopped),
                     'fullband_success_upper_indicator': initial_fullband or uv > 0})
    no_uv_ov = sum(r['initial_UV'] == 0 and r['initial_OV'] > 0 for r in rows)
    already_safe = sum(r['initial_UV'] == 0 and r['initial_OV'] == 0 for r in rows)
    uv_inputs = sum(r['initial_UV'] > 0 for r in rows)
    upper = sum(r['fullband_success_upper_indicator'] for r in rows)
    assert (no_uv_ov, already_safe, uv_inputs, upper) == (251, 17, 232, 249)
    native = read(R / 'outputs/public13_native_cohort_assembly_20261021/Native_Cohort_Results.json')
    assert native['status'] == 'COMPLETE_SOURCE_NATIVE_ALL500_THREE_METHOD_INPUT_CASE_COHORT'
    contrasts = {name: {'verified_full13band': values['full13_band_restored_on_complete'],
                         'conditional_paper_stop_ceiling': upper,
                         'strict_primary_superiority_possible_with_this_stop': upper > values['full13_band_restored_on_complete']}
                 for name, values in native['methods'].items()}
    assert all(not v['strict_primary_superiority_possible_with_this_stop'] for v in contrasts.values())
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_CONDITIONAL_ALL500_UV_ONLY_STOP_FULLBAND_CEILING_PROOF_ZERO_SCIENCE',
              'root_count': 500, 'initial_UV_positive': uv_inputs, 'initial_noUV_but_OV': no_uv_ov,
              'initially_full13band': already_safe, 'conditional_full13band_upper': upper,
              'conditional_full13band_upper_fraction': upper / 500,
              'applies_to': 'Native-role single branch OR two-branch envelope when BOTH preserve this exact UV-only stop and begin at the same paid solved root.',
              'not_an_actual_model_performance_score': True,
              'source_sha256': sha(SOURCE), 'source_guards': [p for c, p in guards],
              'source_root_list_sha256': sha(R / root_name), 'published_contrasts': contrasts,
              'new_model_PF_conversion_derivative_optimizer_GPU_calls': 0,
              'decision': 'Do not launch a winning-fullband performance campaign for this UV-stop-preserving adaptation. A separately named OV-aware bidirectional hybrid and adequate controls require a prospective protocol.',
              'limits': ['Not a universal LLM ceiling, learned-output failure, original137paper rebuttal or physical infeasibility proof.',
                         'Original paper targeted UV restoration; all13band is a different published benchmark endpoint.',
                         'A hybrid with a branch that corrects OV and a suitable selector is outside this conditional bound.',
                         'No claim that the unchanged original25Mvar shunt parser is admitted to native0.3inverter actions.',
                         'No change to current frozen numerical campaign, source, LP, guard, score or resource limits.']}
    for name, value in [('Conditional_Source_And_Cohort_Ceiling.json', result), ('All500_Input_Indicators.json', rows)]:
        with (O / name).open('x', encoding='utf-8') as f:
            json.dump(value, f, indent=2, allow_nan=False)
    print(json.dumps({k: result[k] for k in ['status', 'conditional_full13band_upper', 'published_contrasts', 'new_model_PF_conversion_derivative_optimizer_GPU_calls']}))


if __name__ == '__main__':
    main()
