"""Preserve every existing exact current-mask forecast/context before new work.

No public derivative, factorization, solve, new voltage forecast or PF call.
Scores for30 already-recorded voltage vectors are assembled and separately
charged as CPU data derivations, not represented as old complete forecasts.
"""
import gzip,hashlib,json,os,time
from pathlib import Path
import numpy as np
from full_receding_paid_campaign_20261015 import R,B as OLD,DEP,read,put,sha,pin
from dynamic_actual_mask_guidance_v1 import identity
from compile_lookahead_paid_input_cache_20261014 import action_key
B=R/'outputs/full_paid_numeric_reuse_separate_roles_v2_20261018'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def main():
    B.mkdir(exist_ok=False);started=time.perf_counter();p=read(OLD/'Protocol.json');pin(p)
    put(B/'Protocol.json',{'role':'ALL_AVAILABLE_SOURCE_CURRENT_MASK_NUMERICAL_DEPENDENCIES_NOT_NEW_SCIENCE',
        'source_sha256':sha(Path(__file__)),'bound_seconds':300,'new_PF_derivative_factor_solve_voltage_forecast_calls':0,
        'selection':'All old warm forecasts, all terminal old receding forecast events, all30 saved dynamic voltage predictions and every pinned current-mask NPZ context. No performance/outcome selection.',
        'diagnostic_role':'All30 raw VM diagnostic records retained separately; not substituted for exact complete planner forecasts. Original failed derivation source/console retained.'})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    warm=read(DEP/'Paid_Warm_Dependencies.json');forecasts=warm['existing_numeric_forecasts'].copy();counts={'warm_complete_forecasts':len(forecasts),'old_receding_occurrences':0,'old_receding_new_keys':0,'raw_VM_score_assemblies':0,'raw_VM_exact_existing_keys':0}
    references={e['identity']:e for e in p['warm_numeric_contexts']}
    previous='0'*64;whole=hashlib.sha256();protocol=sha(OLD/'Protocol.json')
    with (OLD/'actual/scientific.jsonl').open('rb') as f:
        for line in f:
            assert time.perf_counter()-started<300
            e=json.loads(line);assert e['previous_sha256']==previous and e['protocol_sha256']==protocol
            if e['event']=='second_causal_context_and_forecasts':
                d=e['data'];ident=d['context_identity']
                for row in d['rows']:
                    key=ident+'|'+action_key(row);value=row['ordering_forecast'];counts['old_receding_occurrences']+=1
                    if key in forecasts:assert forecasts[key]==value
                    else:forecasts[key]=value;counts['old_receding_new_keys']+=1
            elif e['event']=='current_numeric_context_saved':
                d=e['data'];ident=d['identity'];path=OLD/'actual/contexts'/(ident+'.npz');assert sha(path)==d['sha256']
                references[ident]={'identity':ident,'path':str(path.relative_to(R)),'sha256':d['sha256']}
            previous=hashlib.sha256(line.rstrip(b'\n')).hexdigest();whole.update(line)
    assert whole.hexdigest()==read(OLD/'actual/Closed_Manifest.json')['members']['scientific.jsonl']['sha256']
    diagnostic=R/'outputs/all30_dynamic_actual_guidance_storage_v2_20261014/actual'
    for path in sorted(diagnostic.glob('*.npz')):
        with np.load(path,allow_pickle=False) as z:c={k:z[k].copy() for k in z.files}
        ident=identity(c);assert path.stem==ident
        references.setdefault(ident,{'identity':ident,'path':str(path.relative_to(R)),'sha256':sha(path)})
    derived=[]
    for i in range(1,31):
        d=read(diagnostic/f'T{i}.json');ident=d['before_context'];row=d['action'];key=ident+'|'+action_key(row)
        assert ident in references and len(d['dynamic_prediction'])==118
        derived.append({'key':key,'source_path':str((diagnostic/f'T{i}.json').relative_to(R)),'source_sha256':sha(diagnostic/f'T{i}.json'),
            'separate_role':'RAW_DIAGNOSTIC_VM_VECTOR_NOT_AN_EXACT_STORED_FULL_PLANNER_FORECAST_SCORE',
            'not_inserted_or_substituted_in_complete_forecast_index':True})
    contexts=[]
    for ident,ref in sorted(references.items()):
        assert time.perf_counter()-started<300 and sha(R/ref['path'])==ref['sha256']
        with np.load(R/ref['path'],allow_pickle=False) as z:c={k:z[k].copy() for k in z.files}
        assert identity(c)==ident and np.max(abs(c['J']@c['X']-c['B']))<=1e-8
        nr=c['nonref'];pq=c['actual_PQ'];V=c['V'];Y=c['Y'];dv=np.diag(V);di=np.diag(Y@V);norm=np.diag(V/abs(V))
        assert np.allclose(c['m'],dv@np.conj(Y@norm)+np.conj(di)@norm,atol=1e-8,rtol=1e-12)
        assert np.allclose(c['a'],1j*dv@np.conj(di-Y@dv),atol=1e-8,rtol=1e-12)
        J=np.block([[c['a'].real[np.ix_(nr,nr)],c['m'].real[np.ix_(nr,pq)]],[c['a'].imag[np.ix_(pq,nr)],c['m'].imag[np.ix_(pq,pq)]]]);assert np.array_equal(J,c['J'])
        contexts.append(ref)
    dest=B/'All_Existing_Complete_Forecasts.json.gz'
    with gzip.open(dest,'wb') as f:f.write(canon(forecasts))
    assert json.loads(gzip.decompress(dest.read_bytes()))==forecasts
    put(B/'All_Existing_Contexts.json',contexts);put(B/'Saved_VM_Score_Derivation_Sources.json',derived)
    put(B/'Results.json',{'status':'PASS_ALL_SAVED_CURRENT_MASK_FORECASTS_CONTEXT_SOURCE_AND_EQUATION_CLOSURE','complete_forecast_keys':len(forecasts),'contexts':len(contexts),'counts':counts,
        'forecast_index_sha256':sha(dest),'scientific_journal_sha256':whole.hexdigest(),'new_PF_derivative_factor_solve_voltage_forecast_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'Input/source/numerical software closure, not nonlinear convergence, deployment speed, new policy outcome or science launch permission. Every future reuse still requires exact causal current input identity and independent reader cost checks.'})
    put(B/'Closed_Manifest.json',{'members':{x.name:sha(x) for x in B.iterdir() if x.is_file()},'new_science':0})
    print(json.dumps({'full_numeric_reuse':'PASS','forecast_keys':len(forecasts),'contexts':len(contexts),'new_voltage_forecasts':0}))
if __name__=='__main__':main()
