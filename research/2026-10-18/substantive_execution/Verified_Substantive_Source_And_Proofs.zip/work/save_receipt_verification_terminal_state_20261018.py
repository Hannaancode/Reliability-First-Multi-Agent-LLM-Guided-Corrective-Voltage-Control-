"""Preserve terminal reader failure and genuine new per-use verification work."""
import gzip,hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
from prepare_github_research_snapshot_20261018 import SECRET
R=Path(__file__).resolve().parents[1];B=R/'outputs/receipt_verification_research_handoff_20261018'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def main():
    B.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat()
    old=R/'outputs/full_receding_paid_campaign_20261015/audit_linear_composed_v4_20261018'
    failure=R/'outputs/receding_linear_composed_reader_console_20261018.log';trace=failure.read_text('utf-8-sig')
    assert trace.rstrip().endswith('AssertionError: Fixed reader resource bound, no extension')
    progress=read(old/'Decision_Progress_11.json')
    index=read(R/'outputs/primary_input_reference_index_20261018/Results.json');assert index['status'].startswith('PASS_ALL37656_')
    receipt=read(R/'outputs/archived_receipt_on_use_20261018/Results.json');assert receipt['status'].startswith('PASS_ONE_ACTUAL_')
    archival=read(R/'outputs/archival_referenced_history_prefix_20261018/Results.json');assert archival['status'].startswith('PASS_REAL2580_')
    state={'at_utc':at,'status':'FULL_OLD_POLICY_READER_TERMINAL_RESOURCE_PARTIAL_PERUSE_RECEIPT_PATH_PASSES_ONE_ACTUAL_BOUNDARY',
        'old_reader':{'actual_pid':11300,'parent_pid':15812,'exec_session':80819,'actual_exit_code':1,'fixed_analysis_bound_seconds':7200,
            'terminal_reason':'Fixed reader resource bound; no extension or restart','progress_only':progress,'complete_report_produced':False,
            'all_four_full_policy_gate':'UNKNOWN','failure_sha256':sha(failure)},
        'independent_all25_complete_state_prefix_audit':'PASS; certificate outputs/receding_checkpoints_linear_audit_20261018/Independent_Checkpoint_Audit.json; no missing26th state inferred.',
        'all4_roots_both_method_input_admission':'8positive/12negative standalone;8actualengine preentries/8preentry rejections; scientific body stubbed, no performance.',
        'archival_history_prefix':'PASS actual2580 receipt references/9checks after append; live antirollback remains strict. This does not authorize historical controller rollback.',
        'primary_input_reference_index':index,
        'per_use_receipt_certificate':{'status':receipt['status'],'actual_receipts':1,'checks':len(receipt['checks']),
            'ACK':'outputs/archived_receipt_on_use_20261018/Actual_Receipt_ACK.json',
            'mechanism':'Exact current point/action, source input/closed-output byte references, actual actuation input and unchanged native saved-result verifier, original score/cost and fsynced keyed ACK BEFORE any receipt execution reuse.',
            'selection_clarification':'First saved checkpoint; first serialized canonical-index key at its point (lexicographic hashed-action order). Earlier test wording source-order is imprecise; no reward/outcome filter or performance inference.',
            'not_certified':'All old receipts, full old policy, future owner/policy/source-cost preservation or permission for any missing identity.'},
        'new_model_PF_optimizer_derivative_forecast_factor_solve_calls':0,
        'owned_science_GPU_collector_reader_jobs':[],'timers':[],
        'known_physics':'Earlier scoped26commit audit:one17-residualUV world reaches0 in both closed numerical suffixes,11vs14addedops; noUVwin over immediate/no freshLLM/fullDSE/all-severe claim.',
        'all_six_goals':'UNACHIEVED','old_partial_policy_gate':'UNKNOWN',
        'next_tasks_in_order':[
            'Bind independent per-use receipt verification and its durable ACK into lazy paid lookup BEFORE cache hits enter the actual decision engine. Warm receipts retain their prior independent source/physics certificate and all paid costs. Never gate science on an invented full-old-policy PASS.',
            'Persist complete verified-use registry/ACK/source/input/cursor/history/RNG/cost state and exact journal prefixes; prove full actual cold-process restoration at the largest admitted supported state. Historical-prefix reader remains separate from live antirollback.',
            'Establish all-attempt history coverage for proposed new identities, not merely absence from inspected60377-key lineage. Reserve exact genuinely unexecuted identities durably before any new PF; old attempts/missing outcomes block.',
            'Freeze new finite owner/protocol and independently locked complete-vs-partial reader for ALL declared unfinished roots/BOTH fixed policies/common raw scopes/16followups/remaining25ops/450cap/no-refund/9Q/protection/full costs/continuous replay. Preserve old closed outcomes and never restart/extend old budgets.',
            'Only after those gates launch genuinely unexecuted measurements. Then separately bind actual fresh LOCAL/family-broker inference and strong numerical/trained/architecture controls; all141case inventory,published benchmark,unused confirmation and security limitations remain.' ],
        'prospective_design':'outputs/linear_audit_and_admission_handoff_20261018/Prospective_Unexecuted_Measurement_Design.md',
        'no_one_time_timer_needed':'All owners are now terminal. The human waiting-timer condition is false; none created.'}
    put(B/'Exact_Next_Execution_State.json',state)
    note=f'''Continued and saved at {at}.

Verified:all25 complete saved-state prefixes PASS; input/encoding admission
is bound before the decision engine (all4roots/bothmethods, invalid/expired
inputs rejected); archival read-only history passes2580real receipt references
and9controls while live antirollback remains strict.

Full old-policy reader stopped at its fixed7200-second analysis bound, exit1.
It recorded11completed decisions/24,452query occurrences as progress, but did
not produce a complete PASS report. Fullfourworld gate remains UNKNOWN.
Original failure/source/progress preserved. No restart/budget extension.

To remove this audit bottleneck, all37,656old primary attempts now have exact
source input/output references. A new independent per-use receipt certificate
passed on1real current-state/source-action pair, including saved native
verifier/input/score/cost and durable ACK, with wrong-action/source rejection.
This supports a future per-use verification path, not a full receipt-cache,
policy-performance or launch certificate. Test selection is first serialized
hash-index key at the first saved point, not reward/outcome selection.

No new physics/model/optimizer/derivative/forecast/solve calls. No owned jobs,
GPU allocation or timers. Six goals remain unachieved. The earlier numerical
one-world17to0UV finding remains scoped; no new LLM/physical superiority claim.
Exact next work:per-use engine binding, complete durable/cold registry/reader,
global relevant-attempt closure and separately frozen unexecuted-only owner.
'''
    (B/'Results_And_Next_Execution.md').write_text(note,encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+note)
    header='18OCT OLD POLICY READER TERMINAL PARTIAL; PERUSE CAUSAL RECEIPT CERTIFICATE PASS '+at+'\n\n'+note+'\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_INDEX.md']:
        path=R/rel;path.write_text(header+path.read_text('utf-8'),encoding='utf-8')
    for rel in ['outputs/critical_research_reset_20261010/Research_Resume_20261012.json','outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json']:
        path=R/rel;d=read(path);d['latest_20261018_receipt_verification_resume']=state;put(path,d)
    path=R/'outputs/research_tasks_20261014/Tasks.json';tasks=read(path)
    tasks['tasks'][0]['status']=state['status'];tasks['tasks'][0]['done']+=' Fulloldpolicyreader ended7200sec/exit1:11decision24452query progress only, gateUNKNOWN. All37656primaryinputrefsPASS;1actualcausalperusereceipt saved-native-verifier/ACK+wrongaction/source checksPASS. Archival2580queryhistory9controlsPASS with liveantirollback unchanged.0newscience.'
    tasks['tasks'][0]['next']='Read outputs/receipt_verification_research_handoff_20261018/Exact_Next_Execution_State.json. No old owner restart or budget extension; per-use durable/cold/source/global-attempt/new-owner gates before genuine unexecuted physics.';tasks['at_utc']=at;put(path,tasks)
    files=[R/'work'/name for name in ['archival_referenced_history_prefix_v1_20261018.py','check_archival_referenced_history_prefix_20261018.py','index_primary_input_references_20261018.py',
        'certify_archived_receipt_on_use_v1_20261018.py','check_archived_receipt_on_use_20261018.py',Path(__file__).name]]
    for rel in ['archival_referenced_history_prefix_20261018','primary_input_reference_index_20261018','archived_receipt_on_use_20261018']:
        files+=list((R/'outputs'/rel).glob('*.json'))
    files+=list(old.glob('*.json'))+[old/'owner.claim',failure,B/'Exact_Next_Execution_State.json',B/'Results_And_Next_Execution.md',R/state['prospective_design']]
    files=sorted(set(files));members={};archive=B/'Receipt_Verification_And_Terminal_Audit_Evidence_20261018.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in files:
            raw=path.read_bytes();assert not any(p.search(raw.decode('utf-8-sig')) for p in SECRET),str(path)
            key=str(path.relative_to(R)).replace('\\','/');z.writestr(key,raw);members[key]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for key,item in members.items():assert hashlib.sha256(z.read(key)).hexdigest()==item['sha256']
    primary=R/'outputs/primary_input_reference_index_20261018/All_Primary_Input_References.json.gz'
    raw=gzip.decompress(primary.read_bytes());assert not any(p.search(raw.decode()) for p in SECRET)
    put(B/'Local_Incremental_Archive_Audit.json',{'status':'PASS_CRC_EVERY_MEMBER_SHA256_SECRET_SCREEN','archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':members,
        'separate_primary_reference_index':{'path':str(primary.relative_to(R)),'bytes':primary.stat().st_size,'sha256':sha(primary),'decoded_secret_screen':'PASS'},
        'raw_scientific_capsules_checkpoints_journals_stay_local':True})
    print(json.dumps({'save':'PASS','archive_members':len(files),'archive_bytes':archive.stat().st_size,'old_reader':'TERMINAL_RESOURCE_PARTIAL','per_use_actual_receipt':'PASS','new_science':0}))
if __name__=='__main__':main()
