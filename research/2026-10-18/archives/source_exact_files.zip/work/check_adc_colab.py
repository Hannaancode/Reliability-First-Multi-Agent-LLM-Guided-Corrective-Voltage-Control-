"""Read-only authentication/backend check; keep every credential in memory."""
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from google_account_profile import credential_path, expected_account

sys.stdout.reconfigure(encoding='utf-8')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

opener = urllib.request.build_opener(NoRedirect)
report = {'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'credentials_copied': False, 'runtime_allocated': False, 'kernel_execution_verified': False}

def request_json(req):
    try:
        with opener.open(req, timeout=25) as resp:
            body = resp.read().decode('utf-8')
            if body.startswith(")]}'\n"):
                body = body[5:]
            return resp.status, json.loads(body)
    except urllib.error.HTTPError as exc:
        safe = {'http_status': exc.code}
        try:
            body = json.loads(exc.read().decode('utf-8'))
            code = body.get('error')
            if isinstance(code, str) and code in ['invalid_grant','invalid_client','invalid_scope','access_denied']:
                safe['oauth_error'] = code
            elif isinstance(code, dict):
                safe['api_status'] = code.get('status')
        except (ValueError, UnicodeError):
            pass
        return exc.code, safe
    except (urllib.error.URLError, TimeoutError):
        return 0, {'transport_error': 'Network, TLS or timeout failure'}

adc_path = credential_path()
adc = json.loads(adc_path.read_text(encoding='utf-8'))
form = urllib.parse.urlencode({
    'grant_type': 'refresh_token',
    'client_id': adc['client_id'],
    'client_secret': adc['client_secret'],
    'refresh_token': adc['refresh_token'],
}).encode('ascii')
req = urllib.request.Request('https://oauth2.googleapis.com/token', data=form, headers={'Content-Type':'application/x-www-form-urlencoded'}, method='POST')
status, refreshed = request_json(req)
report['adc_refresh_http_status'] = status
print('ADC_REFRESH_HTTP_STATUS', status, flush=True)
token = refreshed.get('access_token') if status == 200 else None
if token:
    report['adc_refresh_succeeded'] = True
    report['expires_in_seconds'] = refreshed.get('expires_in')
    report['granted_scopes'] = refreshed.get('scope', '').split()
    print('ADC_REFRESH_SUCCEEDED True', flush=True)
    print('GRANTED_SCOPES', report['granted_scopes'], flush=True)
    headers = {'Authorization':'Bearer '+token, 'Accept':'application/json', 'X-Colab-Client-Agent':'colab-cli'}
    if expected_account():
        identity_status, identity = request_json(urllib.request.Request('https://www.googleapis.com/oauth2/v2/userinfo', headers=headers))
        assert identity_status == 200 and identity.get('email', '').casefold() == expected_account().casefold(), 'Separate CLI identity verification failed; no allocation permitted'
        report['verified_google_account'] = expected_account()
        report['isolated_credential_profile'] = True
    for name, endpoint in [('assignments','https://colab.research.google.com/tun/m/assignments?authuser=0'),('usage','https://colab.research.google.com/tun/m/ccu-info?authuser=0')]:
        status, body = request_json(urllib.request.Request(endpoint, headers=headers))
        report[name+'_http_status'] = status
        print('COLAB_'+name.upper()+'_HTTP_STATUS', status, flush=True)
        if name == 'assignments' and status == 200:
            assignments = body.get('assignments', [])
            report['active_assignment_count'] = len(assignments)
            report['active_hardware'] = [{'accelerator': x.get('accelerator'), 'variant':x.get('variant'), 'machineShape':x.get('machineShape')} for x in assignments]
            print('COLAB_ACTIVE_ASSIGNMENT_COUNT', len(assignments), flush=True)
            print('COLAB_ACTIVE_HARDWARE', report['active_hardware'], flush=True)
        elif status != 200:
            report[name+'_failure'] = body
        elif name == 'usage':
            report['usage_response_field_names'] = list(body) if isinstance(body,dict) else []
            print('COLAB_USAGE_RESPONSE_FIELDS', report['usage_response_field_names'], flush=True)
            report['compute_availability'] = {k:body.get(k) for k in ['currentBalance','consumptionRateHourly','assignmentsCount','eligibleGpus','ineligibleGpus']}
            print('COLAB_COMPUTE_AVAILABILITY', report['compute_availability'], flush=True)
else:
    report['adc_refresh_succeeded'] = False
    report['adc_refresh_failure'] = refreshed
    print('ADC_REFRESH_FAILURE', refreshed, flush=True)
output = Path(__file__).resolve().parents[1] / 'outputs/local_auth_status.json'
output.write_text(json.dumps(report, indent=2), encoding='utf-8')
if expected_account():
    isolated = output.parent / 'account_sessions/sheenahammed'
    isolated.mkdir(parents=True, exist_ok=True)
    (isolated/'local_auth_status.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    profile_status = output.parent/'separate_google_cli_status.json'
    if profile_status.exists():
        state = json.loads(profile_status.read_text())
        state.update(stage='isolated_cli_identity_verified', verified_google_account=report['verified_google_account'],
                     verified_at_utc=report['checked_at_utc'], assignments_http_status=report.get('assignments_http_status'),
                     usage_http_status=report.get('usage_http_status'))
        temporary = profile_status.with_suffix('.tmp')
        temporary.write_text(json.dumps(state, indent=2), encoding='utf-8')
        temporary.replace(profile_status)
print('SANITIZED_REPORT', output, flush=True)
