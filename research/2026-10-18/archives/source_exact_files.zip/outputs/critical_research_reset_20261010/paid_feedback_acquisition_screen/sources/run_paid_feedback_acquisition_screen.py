"""One prospective saved-only numerical acquisition screen; no GPU/PF."""
import json, os, time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended
from saved_query_receipt_anchored_dataset import open_anchored_OPT_administrator
from saved_query_receipt_dataset import digest
from paid_feedback_acquisition_inputs import load_priors
from paid_feedback_acquisition_control import choose_query, choose_commit, ARMS

PRE = extended(ROOT/'outputs/critical_research_reset_20261010/paid_feedback_acquisition_preparation')
OUT = extended(ROOT/'outputs/critical_research_reset_20261010/paid_feedback_acquisition_screen')


def run():
    assert not OUT.exists(), 'Never restart an existing owner/failed claim'
    protocol = read(PRE/'Protocol.json'); assert read(PRE/'Software_Readiness.json')['all_passed']
    for name, expected in {**protocol['source_sha256'], **protocol['prior_data_sha256']}.items():
        assert sha(ROOT/name) == expected, name
    OUT.mkdir(); started=time.perf_counter(); costs=Counter(); closed=[]
    write(OUT/'owner.claim', {'actual_pid':os.getpid(), 'started_at_utc':datetime.now(timezone.utc).isoformat(), 'source_sha256':sha(Path(__file__)), 'protocol_sha256':sha(PRE/'Protocol.json')})
    (OUT/'Protocol.json').write_bytes((PRE/'Protocol.json').read_bytes())
    for name in protocol['source_sha256']:
        destination=OUT/'sources'/Path(name).name; destination.parent.mkdir(exist_ok=True)
        destination.write_bytes((ROOT/name).read_bytes())
    journal=(OUT/'Actual_Saved_Replay_Journal.jsonl').open('x',encoding='utf8')

    def log(event):
        journal.write(json.dumps({'event_index':costs['journal_events']+1,'at_utc':datetime.now(timezone.utc).isoformat(),**event},allow_nan=False)+'\n')
        journal.flush(); os.fsync(journal.fileno()); costs['journal_events']+=1

    def status(stage):
        path=OUT/'status.tmp'; path.write_text(json.dumps({'stage':stage,'pid':os.getpid(),'closed_cases':len(closed),'costs':dict(costs),'wall_seconds':time.perf_counter()-started},indent=2),encoding='utf8')
        path.replace(OUT/'status.json')

    try:
        log({'event':'source_gates_passed'}); status('loading_original_saved_data')
        data=open_anchored_OPT_administrator(ROOT); priors=load_priors(ROOT,data.inputs,costs)
        write(OUT/'Actual_Input_Identities.json', [{'observation_id':oid,'world_sha256':data.inputs[oid]['world_sha256'],
              'model_input_sha256':data.inputs[oid]['model_input_sha256'],'actor_priors_sha256':digest(priors[oid])} for oid in sorted(data.inputs)])
        write(OUT/'Original_Invalid_and_World_Denominators.json',data.original_invalid_denominators)
        exhausted=False
        for oid in sorted(data.inputs):
            for arm in ARMS:
                record={'observation_id':oid,'world_sha256':data.inputs[oid]['world_sha256'],'arm':arm,'status':'UNKNOWN_unexecuted_resource_bound'}
                if time.perf_counter()-started >= protocol['resource_bound_seconds']: exhausted=True
                if not exhausted:
                    case_started=time.perf_counter(); session=data.session(oid,max_requests=protocol['API_request_bound_including_terminal_operation'])
                    view=session.actor_view(); trace=[]; command=None
                    for qi in range(min(protocol['queries_per_state'],len(view['legal_queries']))):
                        if time.perf_counter()-started >= protocol['resource_bound_seconds']:
                            exhausted=True; break
                        log({'event':'policy_attempt','observation_id':oid,'arm':arm,'query_index':qi,'actor_view_sha256':digest(view),'actor_priors_sha256':digest(priors[oid])})
                        costs['policy_attempts']+=1; command=choose_query(view,priors[oid],arm,costs); assert command is not None
                        costs['policy_returns']+=1; log({'event':'policy_return','observation_id':oid,'arm':arm,'query_index':qi,'command':command})
                        log({'event':'saved_query_attempt','observation_id':oid,'arm':arm,'query_index':qi,'command':command})
                        costs['saved_query_attempts']+=1; response=session.query(command); costs['saved_query_returns']+=1
                        trace.append({'request':command,'response':response}); log({'event':'saved_query_return','observation_id':oid,'arm':arm,'query_index':qi,'response':response})
                        view=session.actor_view()
                    if exhausted:
                        record.update(status='UNKNOWN_resource_partial', queries=trace, selection=None, terminal_operation=None)
                    else:
                        command=choose_commit(view); log({'event':'terminal_saved_operation_attempt','observation_id':oid,'arm':arm,'command':command})
                        result=session.commit(command) if command else session.abstain()
                        # Successor fields are intentionally not passed to the
                        # actor/next test: this is independent one-state replay.
                        record.update(status='complete_saved_one_state_replay',queries=trace,selection=command,
                            terminal_operation={k:v for k,v in result.items() if k!='next_current_state'})
                        log({'event':'terminal_saved_operation_return','observation_id':oid,'arm':arm,'result':record['terminal_operation']})
                    ledger=session.administrator_ledger(); record.update(software_seconds=time.perf_counter()-case_started,
                        actual_saved_API_events=len(ledger['events']), saved_receipt_lookups=ledger['saved_receipt_lookup_calls'],
                        saved_successor_lookups=ledger['saved_successor_lookup_calls'])
                    costs['saved_API_events']+=len(ledger['events']); costs['saved_receipt_lookups']+=ledger['saved_receipt_lookup_calls']
                    costs['saved_successor_lookups']+=ledger['saved_successor_lookup_calls']
                closed.append(record); log({'event':'case_closed','observation_id':oid,'arm':arm,'case':record}); status('saved_numerical_replay_running')
        assert len(closed)==239*4
        write(OUT/'All239_FourPolicy_Cases.json',closed)
        summary={'closed_at_utc':datetime.now(timezone.utc).isoformat(), 'scientific_status':'terminal_partial_saved_replay' if exhausted else 'complete_saved_replay',
            'all239_input_identities_four_policies_retained':True,'costs':dict(costs),'workflow_seconds_before_final_checks_seal':time.perf_counter()-started,
            'actual_new_pretrained_model_optimizer_nonlinear_PF_native_affine_forecast_linear_solve_controller_cloud_calls':0,
            'residual_metric_estimate_and_priority_arithmetic_charged':True,'deployment_query_cost_and_latency':None,
            'old_labels_forecasts_and_preparation_still_paid':True,'historical_OPT_development_not_confirmation':True,
            'no_held_performance_or_automatic_LLM_launch':True,'protocol_sha256':sha(PRE/'Protocol.json')}
        write(OUT/'Actual_Costs_And_Closure.json',summary); write(OUT/'Fresh_Frozen_Asset_Checks.json',frozen_checks())
        journal.close(); files={f.name:f for f in OUT.iterdir() if f.is_file() and f.name not in ('status.json','owner.claim')}
        for f in (OUT/'sources').iterdir(): files['sources/'+f.name]=f
        archive=seal(OUT,files,'Saved_Replay.zip'); status(summary['scientific_status'])
        print(json.dumps({'status':summary['scientific_status'],'costs':dict(costs),'wall_seconds':time.perf_counter()-started,'archive':archive}))
    except Exception as error:
        if not journal.closed:
            log({'event':'terminal_failure','exception_type':type(error).__name__,'message':str(error)}); journal.close()
        write(OUT/'Failed_Closure.json',{'exception_type':type(error).__name__,'message':str(error),'costs':dict(costs),'known_cases':len(closed),'wall_seconds':time.perf_counter()-started,'no_retry':True})
        status('terminal_failed_saved_replay_no_retry'); raise

if __name__=='__main__': run()
