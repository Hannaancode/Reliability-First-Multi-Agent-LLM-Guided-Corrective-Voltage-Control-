"""Saved-only worker journal and complete/partial identity audit; no answer labels."""
from pathlib import Path
import hashlib, json

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

def sha(b):
    return hashlib.sha256(b).hexdigest()

def audit(folder, expected_ids):
    manifest = json.loads((folder / 'Closed_Manifest.json').read_text())
    assert manifest['status'] == 'CLOSED'
    assert set(p.name for p in folder.iterdir() if p.is_file()) == set(manifest['files']) | {'Closed_Manifest.json'}
    for name, record in manifest['files'].items():
        assert '/' not in name and '\\' not in name
        b = (folder / name).read_bytes()
        assert len(b) == record['bytes'] and sha(b) == record['sha256']
    events = [json.loads(s) for s in (folder / 'journal.jsonl').read_text().splitlines()]
    previous = '0' * 64; attempts = []; returns = []
    for i, event in enumerate(events):
        assert event['index'] == i and event['previous'] == previous
        payload = {k: v for k, v in event.items() if k != 'sha256'}
        assert sha(canonical(payload)) == event['sha256']; previous = event['sha256']
        if event['kind'] == 'generation_attempt':
            ordinal = event['ordinal']; qid = event['question_id']
            assert ordinal == len(attempts) and expected_ids[ordinal] == qid
            assert sha((folder / f'pre_rng_{ordinal:03}.pt').read_bytes()) == event['rng_sha256']
            attempts.append(qid)
        elif event['kind'] == 'generation_return':
            ordinal = event['ordinal']; qid = event['question_id']
            assert ordinal == len(returns) and attempts[ordinal] == qid
            p = folder / f'output_{ordinal:03}.json'
            assert sha(p.read_bytes()) == event['output_sha256']
            value = json.loads(p.read_text()); assert value['ordinal'] == ordinal and value['question_id'] == qid
            assert isinstance(value['raw_text'], str) and isinstance(value['new_token_ids'], list)
            assert len(value['new_token_ids']) <= 256
            returns.append(qid)
    assert len(set(attempts)) == len(attempts) and len(set(returns)) == len(returns)
    result = json.loads((folder / 'Result.json').read_text())
    assert result['attempted'] == attempts and result['completed'] == returns
    assert result['journal_events'] == len(events) and result['journal_tail'] == previous
    assert result['unexecuted'] == [x for x in expected_ids if x not in attempts]
    assert result['attempted_without_return'] == [x for x in attempts if x not in returns]
    assert (result['status'] == 'COMPLETE') == (returns == expected_ids)
    assert result['accuracy'] == 'NOT_COMPUTED_LABELS_ABSENT'
    return {'status': 'PASS_SAVED_JOURNAL_IDENTITY_COMPLETE_PARTIAL_ACCOUNTING',
            'completed': len(returns), 'attempted': len(attempts), 'unexecuted': len(result['unexecuted']),
            'unknown_attempts': len(result['attempted_without_return']), 'new_model_PF_calls': 0}
