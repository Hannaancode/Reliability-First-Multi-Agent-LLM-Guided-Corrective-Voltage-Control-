"""Independent current normalization, scope/target identity and source audit.

No neural forward, optimizer, pretrained model, physics or cloud API.
"""
import candidate_process_runtime
import gzip,json,math,os,statistics,time,torch
from collections import defaultdict
from datetime import datetime,timezone
from candidate_process_evidence_utils import ROOT,read,sha,write,frozen_checks,seal
from relational_neural_input_v2 import cell_spec
from relational_current_state_codec import decode
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';C=P/'current_relational_tensor_cache_v2';S=P/'actual_representation_and_OPT_support';B=ROOT/'outputs/llm_value_candidate_development_20261009'
OUT=P/'independent_neural_preparation_evidence';assert not OUT.exists();OUT.mkdir()
write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()});start=time.perf_counter()
proto=read(P/'neural_software_preparation_v2/Prospective_Software_and_Cache_Protocol.json')
for n,h in proto['source_sha256'].items():assert sha(ROOT/n)==h
manifest=read(C/'Closed_Scientific_Manifest.json')
assert set(manifest)=={str(p.relative_to(C)).replace('\\','/') for p in C.rglob('*') if p.is_file() and p.name not in {'owner.claim','Closed_Scientific_Manifest.json','status.json'}}
for n,v in manifest.items():assert (C/n).stat().st_size==v['bytes'] and sha(C/n)==v['sha256']
def lines(p):
    with gzip.open(p,'rt',encoding='utf8') as f:
        for line in f:yield json.loads(line)
condition=read(C/'OPT_Input_Conditioning.json');schema={tuple(v):i for i,v in enumerate(condition['semantic_kinds'])}
index={r['observation_id']:r for r in read(C/'Input_Index.json')};values=defaultdict(list);OPT=0;fields=0;identities=[];allowed={}
for r in lines(S/'Actual_Relational_Current_Input_Records.jsonl.gz'):
    ident=r['audit_identity']['observation_id'];item=index[ident];x=torch.load(C/item['path'],weights_only=False)
    model=x['model_input'];names,cells,meta,queries=cell_spec(r['model_input_codec']);current=decode(r['model_input_codec'])
    assert set(model)=={'field_ids','kind_ids','numeric','value_bytes','cell_token_ids','token_table_ids','token_roles',
                        'token_bus_ends','token_coordinates','token_edge_active','query_token_ids','allowed_actions','original_Q_grid'}
    assert model['query_token_ids']==queries and names==condition['tables']
    assert item['source_current_input_sha256']==r['model_input_codec']['source_current_input_sha256']
    assert len(model['field_ids'])==len(cells)==len(model['numeric'])==len(model['value_bytes'])
    assert model['token_coordinates']==[m['coordinates'] for m in meta] and model['token_bus_ends']==[m['ends'] for m in meta]
    for j,(slot,key,actual) in enumerate(cells):
        assert model['field_ids'][j]==schema[(key,actual['kind'])] and model['cell_token_ids'][j]==slot
        assert model['kind_ids'][j]==('object','array','null','bool','int','float','str').index(actual['kind'])
        if actual['kind'] in ('int','float'):
            st=condition['numeric'][key];expected=(actual['value']-st['mean'])/st['scale']
            assert model['numeric'][j][0]==expected and math.isfinite(expected)
            if r['audit_identity']['split']=='optimization':values[key].append(float(actual['value']))
            expectmask=not st['near_constant']
        else:assert model['numeric'][j][0]==0.;expectmask=False
        assert x['current_input_reconstruction_mask'][j]==expectmask
        expect_text=list(actual['value'].encode('utf8')) if actual['kind']=='str' else []
        assert model['value_bytes'][j]==expect_text
        # Physical bus-map addresses are coordinates, not held-specific fields.
        parsed=json.loads(key)
        if len(parsed)>=6 and parsed[0:3]==['side','current_physical_observation','zone_reports'] and parsed[4] in ('lowest_voltage_buses','undervoltage_buses'):
            assert not (type(parsed[5]) is str and parsed[5].isdigit())
    obs=current['current_physical_observation'];control=current['current_control_state']
    pool={b for v in obs['raw_common_and_zone_pools'].values() for b in v};q=current['original_Q_grid'];support=control['added_abs_Q_MVAr_by_bus']
    expect_allowed=[[b in pool and support[b]+v<=450. for v in q] for b in range(118)]
    assert model['allowed_actions']==expect_allowed and model['original_Q_grid']==q
    assert item['soft_positions']==len(meta)+118 and item['soft_positions']+384<=4096
    if r['audit_identity']['split']=='optimization':OPT+=1
    fields+=len(cells);identities.append(ident);allowed[ident]=expect_allowed
assert len(identities)==311 and set(identities)==set(index) and OPT==239
assert set(values)==set(condition['numeric'])
for key,v in values.items():
    st=condition['numeric'][key];mean=statistics.mean(v);std=statistics.pstdev(v);floor=1e-6*max(1.,abs(mean))
    assert st=={'mean':mean,'std':std,'scale':std if std>=floor else 1.,'count':len(v),
                'near_constant_floor':floor,'near_constant':std<floor}
targets={r['observation_id']:r for r in read(C/'Target_Index.json')};pairs=defaultdict(list)
for p in lines(S/'Measured_OPT_Native_Quality_Preference_Pairs.jsonl.gz'):pairs[p['observation_id']].append(p['preferred_action']+p['other_action'])
label_checks=0;pair_checks=0
for r in lines(B/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz'):
    ident=r['observation_id'];t=torch.load(C/targets[ident]['path'],weights_only=True)
    mask=torch.zeros(118,9,2,dtype=torch.bool);labels=torch.zeros(118,9,2)
    for c in r['measured_candidates']:
        actual=c['target'];b,j=actual['bus'],actual['Q_index']
        if not allowed[ident][b][j]:continue
        mask[b,j,0]=True;labels[b,j,0]=float(actual['recorded_verifier']['accepted'])
        if type(actual['convergence_reported']) is bool:mask[b,j,1]=True;labels[b,j,1]=float(actual['convergence_reported'])
    assert torch.equal(t['classification_mask'],mask) and torch.equal(t['classification'],labels)
    expected=torch.tensor(pairs.get(ident,[]),dtype=torch.long).reshape(-1,4)
    assert torch.equal(t['preference_pairs'],expected)
    if r['split']!='optimization':assert len(expected)==0
    label_checks+=int(mask.sum());pair_checks+=len(expected)
assert len(targets)==238 and pair_checks==11884
software=read(P/'random_internal_software_readiness_v2/Software_Readiness.json')
extra=read(P/'additional_capacity_and_identity_software/Additional_Software_Readiness.json')
assert software['all_software_checks_passed'] and extra['all_checks_passed']
reference=811584;shared=software['shared_interface_parameters']
capacity={'internal_residual_LM':shared+reference,'frozen_LM_capacity_head':shared+extra['production_outside_head_parameters'],
          'edge_conditioned_graph':shared+software['graph_body_parameters'],'full_row_attention':shared+software['attention_body_parameters']}
assert all(abs(v-capacity['internal_residual_LM'])/capacity['internal_residual_LM']<.01 for v in capacity.values())
certificate={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,'exact_current_inputs':311,
 'OPT_only_normalization_states':239,'actual_current_field_encodings_checked':fields,'target_identities':238,
 'actual_known_classifier_entries_checked':label_checks,'OPT_native_quality_pairs_checked':pair_checks,
 'no_held_label_pairs_or_normalization_fit':True,'all_masks_scope_coordinates_source_checks_passed':True,
 'actual_new_software_checks':len(software['checks'])+len(extra['checks']),
 'actual_training_parameter_capacity_by_future_arm':capacity,'matching_is_not_FLOP_precision_or_architecture_equality':True,
 'genuine_pretrained_CUDA_cold_optimizer_resume_or_policy_value_unmeasured':True,
 'first_cache_failure18compiled_inputs_preserved_no_neural_calls':True,
 'new_neural_forward_optimizer_PF_linear_controller_cloud_calls_by_auditor':0,
 'actual_auditor_workflow_seconds':time.perf_counter()-start,
 'remaining_gates':['Prospective numerical/model pilot protocol and single-owner trainers/readers',
   'Genuine full-context CUDA/private/base preservation and cold optimizer-RNG continuation engineering',
   'Incremental native ranking/grounding over matched frozen body and strong same-information controls',
   'Fresh matched protected physical outcomes/full literal D-SE costs and unused independent confirmation']}
write(OUT/'Independent_Current_Cache_Source_and_Capacity_Audit.json',certificate)
write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
files={'Independent_Current_Cache_Source_and_Capacity_Audit.json':OUT/'Independent_Current_Cache_Source_and_Capacity_Audit.json',
       'Fresh_Frozen_Preservation.json':OUT/'Fresh_Frozen_Preservation.json','source/auditor.py':ROOT/'work/audit_relational_neural_preparation.py'}
for n in proto['source_sha256']:files['source/'+n.split('/')[-1]]=ROOT/n
for n in manifest:files['cache/'+n]=C/n
for folder in ('neural_software_preparation_v2','random_internal_software_readiness_v2','additional_capacity_and_identity_software'):
    for f in (P/folder).glob('*.json'):
        if f.name not in {'owner.claim','status.json'}:files[folder+'/'+f.name]=f
for n in ('relational_capacity_head_prototype.py','test_relational_capacity_and_identity_software.py'):files['source/'+n]=ROOT/'work'/n
files['first_compilation_failure_preserved.json']=P/'current_relational_tensor_cache/Terminal_Control_Preparation_Failure.json'
files['Closed_Current_Cache_Manifest.json']=C/'Closed_Scientific_Manifest.json'
archive=seal(OUT,files,'Verified_Relational_Internal_Decision_Preparation.zip')
write(OUT/'status.json',{'stage':'complete_independently_verified_neural_preparation','all_passed':True,'new_science_calls':0})
print(json.dumps({'audit':certificate,'archive':archive},indent=2))
