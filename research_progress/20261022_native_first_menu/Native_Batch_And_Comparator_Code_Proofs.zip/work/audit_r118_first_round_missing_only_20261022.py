"""First independent replay only of newly returned first-menu identities."""
import copy,json,os,pickle,sys,time
from pathlib import Path
from reflection118_chronological_core_20261022 import *
P=R/'outputs/r118_first_round_missing_only_preparation_20261022';E=R/'outputs/r118_first_round_missing_only_execution_20261022';O=R/'outputs/r118_first_round_missing_only_independent_20261022'
def main():
    O.mkdir(exist_ok=False);began=time.monotonic();put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    while not (O/'Launcher_ACK.json').exists():assert time.monotonic()-began<120;time.sleep(.1)
    import candidate_process_runtime
    sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
    import pandapower as pp,numpy as np
    from frozen_physics_loader import load_stack,AUDIT
    from pandapower.pypower.makeYbus import makeYbus
    from pandapower.pypower.makeSbus import makeSbus
    p=read(P/'Protocol.json');end=read(R/'outputs/r118_first_round_missing_only_coordination_20261022/End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    for n,h in p['source_hashes'].items():assert sha(R/n)==h
    for n,h in read(E/'Closed_Manifest.json')['members'].items():assert sha(E/n)==h
    result=read(E/'Result.json');declared=read(R/p['frontier'])['rows']
    _,runner,_=load_stack();assert all(x['all_function_asts_unchanged'] for x in AUDIT)
    bindings=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    roots={r['case_id']:pickle.loads((R/r['solved_payload']).read_bytes())['net'] for r in bindings}
    native=pp.runpp;replays=0;delta_max=0.;kcl_max=0.;checked=[]
    for i,row in enumerate(result['rows']):
        assert time.monotonic()-began<p['reader_seconds'] and row['identity']==i
        d=declared[i];assert row['case_id']==d['case_id'] and row['action']==d['action'] and row['solver_kwargs']==p['solver_kwargs']
        if row['status']=='PAID_NATIVE80_REUSE_NO_NEW_PF':assert d['status']=='EXACT_CURRENT_PAID80_RETURN_REUSABLE';continue
        if row['status']=='PRIOR_COLLISION_UNKNOWN_NO_CALL':assert d['status']!='NO_MATCH_IN_NAMED_TRACKED_SCOPE_NOT_GLOBAL_ABSENCE';continue
        assert d['status']=='NO_MATCH_IN_NAMED_TRACKED_SCOPE_NOT_GLOBAL_ABSENCE'
        root=roots[row['case_id']];expected=copy.deepcopy(root);runner.rescue.apply_action(expected,row['action'])
        before=decode(E,row['before']);after=decode(E,row['after']);frames_equal(expected,before)
        if row['exception'] is not None:assert row['status']=='EXCEPTION_UNKNOWN_NO_RETRY';continue
        net=copy.deepcopy(before);native(net,**p['solver_kwargs']);replays+=1;frames_equal(net,after);delta=0.
        for name in ['res_bus','res_line','res_trafo','res_gen','res_sgen','res_load','res_ext_grid','res_shunt']:
            a=net[name].select_dtypes(include=[np.number]).to_numpy(float);b=after[name].select_dtypes(include=[np.number]).to_numpy(float)
            assert a.shape==b.shape and np.allclose(a,b,atol=1e-10,rtol=0,equal_nan=True)
            mask=np.isfinite(a)&np.isfinite(b);delta=max(delta,float(np.max(abs(a[mask]-b[mask]),initial=0)))
        q=net._ppc;Y=makeYbus(q['baseMVA'],q['bus'],q['branch'])[0];V=q['bus'][:,7]*np.exp(1j*np.deg2rad(q['bus'][:,8]));kcl=float(np.max(abs(V*np.conj(Y@V)-makeSbus(q['baseMVA'],q['bus'],q['gen']))));assert kcl<=1e-7
        def cached(n,**kw):
            try:assert kw==p['solver_kwargs'];frames_equal(n,before);restore_exact(n,after)
            except Exception as e:raise BaseException('INDEPENDENT_SOURCE_CACHE_ERROR: '+repr(e)) from e
        pp.runpp=cached
        try:verif=runner.rescue.verify_action(copy.deepcopy(root),row['action'])
        finally:pp.runpp=native
        assert verif==row['verification'];delta_max=max(delta_max,delta);kcl_max=max(kcl_max,kcl)
        record=dict(identity=i,maximum_field_delta=delta,KCL_pu=kcl,original_verifier_exact=True,first_independent_PF_replay=True)
        put(O/f'first_replay_{i:04d}.json',record);checked.append(record)
    assert replays==result['costs']['new_PF_returns']
    put(O/'Independent_Audit.json',dict(status='PASS_PRESERVED_NEW_FIRST_MENU_RETURNS_SOURCE_INPUT_FIELDS_KCL_COST',
        primary_status=result['status'],all2034_identity_records_closed=len(result['rows'])==2034,first_independent_PF_replays=replays,
        maximum_field_delta=delta_max,maximum_KCL_pu=kcl_max,primary_costs=result['costs'],
        old_paid_replays=0,failed_call_retries=0,new_model_training_optimizer_calls=0,
        whole_trajectory_LLM_DSE_external_superiority='UNTESTED_UNKNOWN',known_contract_collisions_still_unknown=True,workflow_seconds=time.monotonic()-began))
    put(O/'Closed_Manifest.json',dict(members={p.name:sha(p) for p in O.iterdir() if p.is_file()}))
if __name__=='__main__':main()
