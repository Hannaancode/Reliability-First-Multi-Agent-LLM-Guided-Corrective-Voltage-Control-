"""Continue unchanged observed-paid policy at its verified16UV saved prefix.

Import the two completed decisions instead of recomputing their menus. Add only
the new independently checked numerical table. No new model/PF/solve/commit.
"""
import ast,copy,json
from pathlib import Path
from types import SimpleNamespace
import replay_unstarted_paid_suffix_numeric_v2_20261018 as original
import verified_paid_cache_engine_v2_20261018 as binding
from replay_all_thirteen_paid_receipts_20261019 import Registry
from fixed_three_query_core_20261019 import transform
from public118_slsqp_native_20261018 import R,read,put,sha
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
from prepare_exact_two_paid_query_engineering_20261018 import local_closure
B=R/'outputs/resumed16_paid_policy_support_20261019'
PREP=R/'outputs/resumed16_paid_policy_preparation_20261019'
PRIOR=R/'outputs/all_thirteen_paid_receipts_policy_screen_20261019'
NUMBERS=['next_required_numeric_context_20261019','second_required_numeric_context_20261019','third_required_numeric_context_20261019']

def main():
    assert read(R/'outputs/closed_thirteen_support_prefix_audit_v2_20261019/Independent_Selected_Prefix_Audit.json')['status']=='PASS_SAVED_SELECTED_METRICS_HASHES_BUDGET_AND_UNKNOWN_CONTEXT_IDENTITY'
    assert read(R/'outputs/third_required_numeric_context_20261019/Completion.json')['exit_codes']=={'actual':0,'independent_audit':0}
    assert not B.exists();PREP.mkdir(exist_ok=False)
    leg=read(PRIOR/'Leg_1.json');assert [v['metrics']['uv_count'] for v in leg['projection_trace']]==[23,16] and leg['remaining_original_operations']==15
    files=local_closure([Path(__file__)])+[PRIOR/'Results.json',PRIOR/'Leg_1.json',PRIOR/'Closed_Manifest.json',R/'outputs/closed_thirteen_support_prefix_audit_v2_20261019/Independent_Selected_Prefix_Audit.json']
    for name in NUMBERS:
        root=R/'outputs'/name
        files += [root/'Protocol.json',root/'Completion.json',root/'actual/Closed_Manifest.json',root/'actual/All_Current_Native_Forecasts.json',root/'independent_audit/Independent_Audit.json']
    versions=read(R/'outputs/third_required_numeric_context_20261019/Protocol.json')['runtime_versions']
    put(PREP/'Protocol.json',{'status':'FROZEN_BEFORE_NEW_READONLY_SUPPORT_CONTINUATION','source_input_sha256':{str(p.relative_to(R)):sha(p) for p in sorted(set(files))},'runtime_versions':versions,
       'fixed_bound_seconds':900,'imported_prefix':'Both original saved decisions33to23to16 retained; second source receipt and resource projection verified again, no prior menu decisions rerun.',
       'changed_data_only':'Add independently paid context480be..., all original receipts including rejects. All fixed methods/actions/scopes/protection/objective/budget/selection unchanged.',
       'new_model_PF_optimizer_derivative_forecast_factor_solve_actual_commit_calls':0,'limits':'Observed-supported graph analysis, not a new physical trajectory or LLM advantage. Stop UNKNOWN at any missing evidence; no automatic query or training.'})
    guard=LockedSourceSnapshot(PREP/'Protocol.json')
    try:
        text=Path(original.__file__).read_text('utf-8');n=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='main')
        function='\n'.join(text.splitlines()[n.lineno-1:n.end_lineno])
        before="contexts[proof['identity']]=c\n    for ref in read(reuse/'All_Existing_Contexts'):" # exact spelling checked below
        before=before.replace("All_Existing_Contexts'","All_Existing_Contexts.json'")
        after="""contexts[proof['identity']]=c
    for newname in NUMBERS:
        newroot=R/'outputs'/newname;newproof=read(newroot/'independent_audit/Independent_Audit.json')
        assert newproof['status']=='PASS_SINGLE_EXACT_CURRENT_MASK_CONTEXT_AND_ALL_MENU_FORECAST_EQUATIONS_COSTS_SOURCE_MANIFEST'
        for relative,expected in read(newroot/'actual/Closed_Manifest.json')['members'].items():assert sha(newroot/'actual'/relative)==expected
        menu=read(newroot/'actual/All_Current_Native_Forecasts.json')
        if newname=='next_required_numeric_context_20261019':ack=read(newroot/'additive_menu_join_v2/Full_Native_Menu_ACK.json')
        else:ack=read(newroot/'Full_Native_Menu_ACK.json')
        assert ack['all_forecast_keys']==len(menu)==newproof['forecasts']
        for key,value in menu.items():assert key not in forecasts;forecasts[key]=value['forecast']
        with np.load(newroot/'actual'/(newproof['identity']+'.npz'),allow_pickle=False) as z:newcontext={k:z[k].copy() for k in z.files}
        assert identity(newcontext)==newproof['identity'] and newproof['identity'] not in contexts
        contexts[newproof['identity']]=newcontext
    for ref in read(reuse/'All_Existing_Contexts.json'):"""
        function=transform(function,[(before,after)])
        old='        step=1\n        try:'
        new="""        supported=read(PRIOR/'Leg_1.json')['projection_trace'][1]
        row=supported['row'];key=point_key(net,cursor)+'|'+action_key(row)
        rec=registry.lookup({'net':net,'cursor':cursor},row,key)
        target=load_after(supported['after_reference'],evidence.pack)['net']
        cursor=project(net,target,cursor,row,rec,runner=runner,zones=zones);net=target
        assert runner.rescue.grid_metrics(net)==supported['metrics'] and cursor['remaining_original_device_operation_slots']==15
        item['projection_trace'].append({**supported,'role':'IMPORTED_VERIFIED_SECOND_OBSERVED_DECISION_NOT_MENU_RERUN'})
        item['imported_supported_prefix_reference']={'path':str((PRIOR/'Results.json').relative_to(R)),'sha256':sha(PRIOR/'Results.json'),'prior_workflow_seconds':read(PRIOR/'Results.json')['workflow_seconds'],'not_free_or_new_physics':True}
        step=2
        try:"""
        function=transform(function,[(old,new)])
        tree=ast.parse(function)
        for node in ast.walk(tree):
            if isinstance(node,ast.Constant) and type(node.value) is int and node.value==1800:node.value=900
        env=original.__dict__.copy();proxy=SimpleNamespace(**binding.__dict__);proxy.VerifiedPaidUseRegistry=Registry
        env.update(B=B,PRIOR=PRIOR,NUMBERS=NUMBERS,binding=proxy,__file__=__file__)
        put(PREP/'Source_Transformation.json',{'status':'EXACT_REVERSIBLE_TEXT_INSERTIONS_PLUS_FIXED_READONLY_BOUND','original_main_sha256':sha(original.__file__),'policy_decision_method_changed':False,'native_forecast_guard_score_method_changed':False,'imported_prefix_decisions':2,'new_scientific_calls':0})
        exec(compile(ast.fix_missing_locations(tree),str(original.__file__),'exec'),env);env['main']()
    finally:guard.close()

if __name__=='__main__':main()
