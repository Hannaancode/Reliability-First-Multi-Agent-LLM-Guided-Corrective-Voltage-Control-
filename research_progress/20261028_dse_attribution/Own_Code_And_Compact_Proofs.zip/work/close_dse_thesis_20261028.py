"""Close the visually reviewed stronger-control and public failure thesis insert."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,re,zipfile,hashlib,html,os
from docx import Document
from pypdf import PdfReader
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_dse_and_public_diagnosis_20261028'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n','utf-8')
def media(p):
    with zipfile.ZipFile(p) as z:return Counter(sh_bytes(z.read(n)) for n in z.namelist() if n.startswith('word/media/'))
def sh_bytes(b):return hashlib.sha256(b).hexdigest()
def main():
    assert not (O/'Final_Visual_And_Evidence_QA.json').exists()
    base=R/'outputs/thesis_attribution_and_comparators_20261028/Hannaan_Thesis_Attribution_And_Comparators.docx'
    path=O/'Hannaan_Thesis_DSE_And_Public_Diagnosis.docx';old=Document(base);d=Document(path)
    assert sh(base)==rd('outputs/thesis_attribution_and_comparators_20261028/Final_Visual_And_Evidence_QA.json')['docx_sha256']
    tables=lambda x:[[[c.text for c in row.cells] for row in t.rows] for t in x.tables]
    original,current=tables(old),tables(d)
    assert len(original)==15 and len(current)==17 and all(t in current for t in original)
    assert media(base)==media(path) and sum(media(path).values())==22
    refs=lambda x:[p.text for p in x.paragraphs if re.match(r'^\[\d+\]',p.text)]
    assert refs(d)==refs(old) and len(refs(d))==35
    norm=lambda s:re.sub(r'\t\d+$','',s)
    assert all(norm(p.text) in {norm(q.text) for q in d.paragraphs} for p in old.paragraphs)
    assert next(t for t in current if t[0][0]=='Root' and t[0][1]=='DFF UV/OV')[-1]==['Total','51/11','35/12','26/11','20/12']
    assert next(t for t in current if t[0][0]=='Initial condition')[-1]==['All cases','500','264','236']
    pagination=rd('outputs/thesis_dse_and_public_diagnosis_20261028/Pagination_Record.json')
    pdf=PdfReader(O/'Integrated_Thesis_QA.pdf');assert len(pdf.pages)==pagination['pages'] and pagination['list_entries']==52
    compact=lambda s:re.sub(r'\s+','',s).lower()
    for e in pagination['map']:assert compact(e['label']) in compact(pdf.pages[e['physical_page']-1].extract_text() or ''),e
    review=rd('outputs/thesis_dse_and_public_diagnosis_20261028/Visual_Review_Record.json')
    assert review['pdf_sha256']==sh(O/'Integrated_Thesis_QA.pdf') and review['status']=='PASS_CHANGED_PAGES_VISUALLY_REVIEWED'
    now=datetime.now(timezone.utc).isoformat()
    qa={'at_utc':now,'status':'PASS_WORKING_DRAFT_LAYOUT_AND_LISTED_EVIDENCE_CHECKS','pages':len(pdf.pages),'tables':17,'figures':22,'references':35,
      'page_bound_index_entries':52,'docx_sha256':sh(path),'pdf_sha256':sh(O/'Integrated_Thesis_QA.pdf'),
      'original113_unchanged':True,'all_prior15_table_values_unchanged':True,'all_prior_body_paragraphs_unchanged':True,
      'all22_media_bytes_unchanged':True,'visual_review':review,'new_scientific_calls':0,
      'limitations':['Working draft, not final university submission','D-SE older committed-state audit is narrower than new candidate/full-field/cold audit','No equal-cost or causal LLM advantage','All6 research goals remain OPEN']}
    put(O/'Final_Visual_And_Evidence_QA.json',qa)
    chunks=[]
    for e in d.element.body:
        if e.tag.endswith('}p'):
            from docx.text.paragraph import Paragraph
            q=Paragraph(e,d);chunks.append(('## ' if q.style.name.startswith('Heading') else '')+q.text)
        elif e.tag.endswith('}tbl'):
            from docx.table import Table
            t=Table(e,d);rows=[[c.text.replace('\n',' / ') for c in r.cells] for r in t.rows]
            chunks.append('\n'.join(['| '+' | '.join(rows[0])+' |','| '+' | '.join(['---']*len(rows[0]))+' |']+['| '+' | '.join(r)+' |' for r in rows[1:]]))
    (O/'Thesis_Text_And_Tables.md').write_text('\n\n'.join(chunks)+'\n','utf-8')
    index=rd('outputs/thesis_attribution_and_comparators_20261028/Thesis_Evidence_Navigation.json')
    index.update(at_utc=now,qa_record=(O/'Final_Visual_And_Evidence_QA.json').relative_to(R).as_posix(),current_docx=path.relative_to(R).as_posix(),pages=len(pdf.pages))
    for number,sources,limit in [('7.9',['outputs/original118_saved_dse_reconciliation_20261028/Verified_Completion.json','outputs/original118_saved_dse_reconciliation_20261028/independent/Independent_Audit.json','outputs/original118_saved_dse_reconciliation_20261028/Results_Corrected.md'],'Historical source/recipe and complete DFF output join; older ALT audit scope narrower, full costs retained, no causal/equal-cost proof.'),
      ('7.10',['outputs/public13_saved_numeric_stagnation_20261022/All500_Arithmetic_Diagnosis.json','outputs/public13_saved_numeric_stagnation_20261022/Separate_Arithmetic_Crosscheck.json'],'Saved all500 diagnosis; strict failures not reclassified, no new control success.')]:
        caption=next(p.text for p in d.paragraphs if p.style.name=='Caption' and p.text.startswith('Table '+number+' '))
        index['tables'].append({'table':number,'caption':caption,'status':'VERIFIED_SAVED_EVIDENCE','records':[{'path':s,'sha256':sh(R/s)} for s in sources],'limitation':limit})
    put(O/'Thesis_Evidence_Navigation.json',index)
    parts=['<!doctype html><meta charset="utf-8"><title>Thesis evidence index</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.5 system-ui}section{border-top:1px solid #ddd;padding:12px 0}</style><h1>Thesis evidence index</h1>',f'<p>{len(pdf.pages)} pages; 17 tables; 22 figures; 35 references. Working thesis, research goals remain open.</p>']
    def link(s,label):return '<a href="'+html.escape(os.path.relpath(R/s,O).replace('\\','/'),quote=True)+'">'+html.escape(label)+'</a>'
    parts.append('<p>'+link(path.relative_to(R).as_posix(),'Current Word draft')+'</p>')
    for t in sorted(index['tables'],key=lambda t:tuple(int(x) for x in t['table'].split('.'))):
        parts.append('<section><h2>'+html.escape(t['caption'])+'</h2><p>'+html.escape(t['limitation'])+'</p><ul>')
        for x in t['records']:parts.append('<li>'+link(x['path'],x['path'])+'</li>')
        parts.append('</ul></section>')
    parts.append(link('outputs/thesis_integrated_evidence_20261028/Evidence_Index.html','Original figure source navigation'))
    (O/'Evidence_Index.html').write_text('\n'.join(parts),'utf-8')
    tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json')
    for t in tasks['tasks']:
        if t['id'] in ['T06','T17']:
            t.update(status='COMPLETE_SCOPED_DOCUMENTATION_REQUIREMENT_IN_REVIEWED_WORKING_THESIS',completed_utc=now,
              limitation='Scoped comparison/diagnosis documented with unequal audit/cost limits and adverse outcomes; research superiority goals remain open.')
            t['evidence'] += [qa_path:=(O/'Final_Visual_And_Evidence_QA.json').relative_to(R).as_posix()]
    tasks['updated_utc']=now;tasks['completed_requirement_count']=sum(t['status'].startswith('COMPLETE') for t in tasks['tasks']);assert tasks['completed_requirement_count']==13
    put(R/'outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    resume=rd('outputs/research_resumption_20261028/Current_Resume.json');resume.update(at_utc=now,thesis_integration=qa_path,thesis_evidence_index=(O/'Evidence_Index.html').relative_to(R).as_posix(),thesis_closed_requirements=13)
    resume['next']=[x for x in resume['next'] if not x.startswith('Integrate the saved D-SE')]
    put(R/'outputs/research_resumption_20261028/Current_Resume.json',resume)
    msg=f'Reviewed thesis now {len(pdf.pages)} pages/17tables/22figures/35references. T06strongerDSEcomparison andT17public13adverse-diagnosis documentation complete;13/35requirements,all6researchgoalsOPEN. Existing strict500failure264vs363 retained;14,387zeroaction decisions and151nearboundary failures explained without score changes. SavedDSE35UV/12OV,HGVF26/11,offlineHGSE20/12 on4inspectedroots; OVlosses/olderaudit/fullcost limits explicit.0newscience/GPU/timer. Previous113-page copy unchanged.'
    head='## Stronger control and adverse benchmark thesis integration verified — '+now+'\n\n'+msg+'\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text(head+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+msg+'\n')
    main_tasks=rd('outputs/research_tasks_20261014/Tasks.json');main_tasks.update(updated_at_utc=now,thesis_documentation_requirements_complete=13,latest_verified_thesis=qa_path);put(R/'outputs/research_tasks_20261014/Tasks.json',main_tasks)
    integration=rd('outputs/thesis_dse_and_public_diagnosis_20261028/Integration_Record.json');integration.update(status='COMPLETE_WORKING_DRAFT_VISUALLY_VERIFIED',pages=len(pdf.pages),qa=qa_path);put(O/'Integration_Record.json',integration)
    print(json.dumps({'pages':len(pdf.pages),'requirements_complete':13,'new_science':0}))
if __name__=='__main__':main()
