"""One primary and one pinned, partial-aware first-return reader; no retries."""
import subprocess
from r118_dff_partition_core_20261023 import *
O=R/'outputs/r118_dff_partition_continuation_handoff_20261023'

def main():
    O.mkdir(exist_ok=False);began=time.monotonic()
    put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=sha(__file__)))
    p=read(P/'Protocol.json');validate_pins(p)
    assert read(P/'Readiness.json')['status'].startswith('PASS_')
    for phase,name in [('primary','Owner_Protocol.json'),('reader','Reader_Owner_Protocol.json')]:
        with (O/(phase+'.log')).open('x',encoding='utf-8') as log:
            child=subprocess.Popen([sys.executable,'-X','utf8',str(R/'work/coordinate_f118_encoder_owner_20261022.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
            put(O/(phase+'_Launcher.json'),dict(pid=child.pid,parent=os.getpid(),protocol_sha256=sha(P/name)))
            code=child.wait(timeout=7600)
        put(O/(phase+'_End.json'),dict(pid=child.pid,exit_code=code));assert code==0,'Preserve failure; never repeat owner/science/reader'
    audit=read(A/'Independent_Audit.json');assert audit['status'].startswith('PASS_')
    put(O/'Completion.json',dict(status='ACTUAL_PRIMARY_AND_PINNED_FIRST_RETURN_READER_ENDED',independent_audit_status=audit['status'],all4_complete=audit['all4_complete'],workflow_seconds=time.monotonic()-began,all6_final_goals='OPEN'))

if __name__=='__main__':main()
