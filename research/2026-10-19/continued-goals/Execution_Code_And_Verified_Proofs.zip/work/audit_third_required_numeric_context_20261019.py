"""Exact old independent equations/full-native-menu reader, new namespace."""
import argparse,ast
from pathlib import Path
import audit_first_missing_paid_numeric_context_20261018 as original
import audit_second_required_numeric_context_20261019 as menu
from third_required_numeric_context_20261019 import B,claim_writer
from public118_slsqp_native_20261018 import R,read,put,sha

def main():
    # menu.main embeds the exact original main AST before its complete-menu join.
    n=next(n for n in ast.parse(Path(menu.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main')
    env=menu.__dict__.copy();env.update(B=B,__file__=__file__,claim_writer=claim_writer)
    exec(compile(ast.Module(body=[n],type_ignores=[]),str(menu.__file__),'exec'),env);env['main']()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--reader',action='store_true');p.parse_args();main()
