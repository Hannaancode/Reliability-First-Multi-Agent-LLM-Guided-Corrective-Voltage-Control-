"""New prospective missing-only completion after a representation stop.

Keeps all old failures/bounds/results. Resolves only exact native argument
identity, never equal-aggregate approximation or a physical/control retune.
"""
import ast
from datetime import datetime,timezone
from r118_dff_partition_core_20261023 import *

def main():
    P.mkdir(exist_ok=False);began=time.monotonic()
    np,pp,v2,runner,reflection=setup()
    assert read(R/'outputs/r118_dff_missing_continuation_handoff_20261023/Completion.json')['independent_audit_status'].startswith('PASS_')
    assert read(R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023/Independent_Audit.json')['exact_solver_ppci_options_kwargs']
    from native_solver_input_identity_v3_20261023 import native_input_prefix
    import pandapower.powerflow as pf
    original=pp.runpp;original_algorithm=pf._run_pf_algorithm
    def forbidden(*a,**k):raise OperationalStop('PREPARATION_FORBIDS_NONLINEAR_SOLVER_MODEL')
    pp.runpp=forbidden;pf._run_pf_algorithm=forbidden
    try:
        fixed=read(R/'outputs/r118_exact_shunt_partition_receipt_v2_20261023/Result.json');packet=decode(R/'outputs/r118_exact_shunt_partition_receipt_v2_20261023',fixed['mapped_receipt'])
        d=R/'outputs/r118_dff_missing_continuation_execution_20261023/fed_combined_load_1p5_line_35_MG1';path=d/'call_000935.json';row=read(path)
        ref=dict(directory=d,source=path.relative_to(R).as_posix(),source_sha256=sha(path),before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=None)
        fixture=Registry([ref],proof_directory=P/'fixture_solver_input_identity')
        mapped,exc,prov=fixture.lookup(packet['new_input'],row['kwargs'])
        assert exc is None and prov['kind']=='EXACT_NATIVE_SOLVER_INPUT_IDENTITY_REUSE_NOT_NEW_PF'
        assert np.array_equal(mapped.res_bus.vm_pu.values,packet['mapped_after'].res_bus.vm_pu.values)
        from audit_solver_input_identity_receipts_20261023 import audit
        checked=audit(P/'fixture_solver_input_identity');assert checked['identity_receipts']==1 and checked['maximum_reconstructed_field_delta']==0.
    finally:pp.runpp=original;pf._run_pf_algorithm=original_algorithm
    # Source workers are additive copies. Their controller loader/function,
    # candidate generator, verifier, score and all physical settings are fixed.
    worker=(R/'work/run_r118_dff_missing_continuation_20261023.py').read_text('utf-8').replace('from r118_dff_missing_continuation_core_20261023 import *','from r118_dff_partition_core_20261023 import *')
    worker=worker.replace("costs['binary_bytes']+4*1024**2", "costs['binary_bytes']+registry.preparation_costs['proof_bytes']+4*1024**2")
    worker=worker.replace("tmp=E/'Status.pending';", "costs['exact_solver_input_preparation']=copy.deepcopy(registry.preparation_costs)\n        tmp=E/'Status.pending';")
    worker=worker.replace("checkpoint_equal(state,saved_first);first_gate=True", "checkpoint_equal(state,saved_first);first_gate=True")
    needle="                descriptor=capsule(directory/f'commit_{count:02d}.zlib'"
    add="""                old_dir=R/'outputs/r118_dff_missing_continuation_execution_20261023'/binding['case_id']
                old_commit=old_dir/f'commit_{count:02d}.json'
                if old_commit.exists():
                    old_desc=read(old_commit)['capsule'];old_state=decode(old_dir,old_desc)['source_frame'];checkpoint_equal(state,old_state)
"""
    assert needle in worker;worker=worker.replace(needle,add+needle)
    worker=worker.replace("put(E/'Result.json',dict(","costs['exact_solver_input_preparation']=copy.deepcopy(registry.preparation_costs)\n        put(E/'Result.json',dict(")
    reader=(R/'work/audit_r118_dff_missing_continuation_20261023.py').read_text('utf-8').replace('from r118_dff_missing_continuation_core_20261023 import *','from r118_dff_partition_core_20261023 import *').replace('outputs/r118_dff_missing_continuation_coordination_20261023','outputs/r118_dff_partition_continuation_coordination_20261023')
    reader=reader.replace("# All further policy checks use preserved physical receipts only.","from audit_solver_input_identity_receipts_20261023 import audit as identity_audit\n        identity_proof=identity_audit(E/'solver_input_identity');put(A/'Exact_Solver_Input_Receipt_Audit.json',identity_proof)\n        assert identity_proof['identity_receipts']==result['costs']['exact_solver_input_preparation']['identity_receipts']\n        # All further policy checks use preserved physical receipts only.")
    coordinator=(R/'work/coordinate_r118_dff_missing_continuation_20261023.py').read_text('utf-8').replace('from r118_dff_missing_continuation_core_20261023 import *','from r118_dff_partition_core_20261023 import *').replace('r118_dff_missing_continuation','r118_dff_partition_continuation')
    for name,text in [('run_r118_dff_partition_continuation_20261023.py',worker),('audit_r118_dff_partition_continuation_20261023.py',reader),('coordinate_r118_dff_partition_continuation_20261023.py',coordinator)]:
        ast.parse(text);path=R/'work'/name
        with path.open('x',encoding='utf-8') as f:f.write(text);f.flush();os.fsync(f.fileno())
    old=read(R/'outputs/r118_dff_missing_continuation_preparation_20261023/Protocol.json')
    sources=['r118_dff_partition_core_20261023.py','native_solver_input_identity_v3_20261023.py','native_solver_input_identity_20261023.py','audit_solver_input_identity_receipts_20261023.py','prepare_r118_dff_partition_continuation_20261023.py','run_r118_dff_partition_continuation_20261023.py','audit_r118_dff_partition_continuation_20261023.py','coordinate_r118_dff_partition_continuation_20261023.py','reflection118_remaining_cases_core_20261023.py']
    pins=old['source_hashes']|{'work/'+n:sha(R/'work'/n) for n in sources}
    extra=[R/'outputs/r118_dff_missing_continuation_execution_20261023/Result.json',R/'outputs/r118_dff_missing_continuation_independent_20261023/Independent_Audit.json',R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023/Independent_Audit.json',R/'outputs/r118_exact_shunt_partition_receipt_independent_v2_20261023/Mapped_Receipt.json']
    p=copy.deepcopy(old);p.update(at_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_NEW_MISSING_ONLY_DFF_COMPLETION_WITH_EXACT_ARGUMENT_IDENTITY',source_hashes=pins,input_hashes=old['input_hashes']|{f.relative_to(R).as_posix():sha(f) for f in extra},
        prior_owner_terminal_partial_preserved=True,prior_new_612_returns_and_first_replays_never_repeated=True,remaining_original_operations_after_reused_prefix=[22,24,24,24],
        change='Only the paid-input registry admits a different shunt-row layout IF all actual native ppci/options/kwargs are byte-identical and source result extraction preserves the target resource rows. Original controller/physical solver/settings/source/verifier/score/thresholds unchanged.',
        exact_identity_mechanism='Every new partition reuse reserves/preserves two actual native input preparations, arguments, reference and mapped result; ZERO new algorithm calls. No aggregate-only/epsilon equality, altered guard, chosen reference retry or failed physical retry. Exact argument mismatch stops UNKNOWN.',
        costs='Old612PF/612firstreplays and all earlier2034 source queries remain paid. Each new exact-argument reuse pays two input preparations and one native extraction; the independent reader checks stored argument bytes and first source result extraction with zero converter/PF/model calls. Only genuinely new returned PF inputs receive one first nonlinear replay.',
        independent_receipt_gate=checked,all4_fixed_original_case_order=True,no_automatic_model_rollout=True)
    put(P/'Protocol.json',p)
    for name,src,out,coord in [('Owner_Protocol.json','run','execution','coordination'),('Reader_Owner_Protocol.json','audit','independent','reader_coordination')]:
        path=R/f'work/{src}_r118_dff_partition_continuation_20261023.py'
        put(P/name,dict(single_owner=dict(source=path.relative_to(R).as_posix(),sha256=sha(path),python='work/vcsa_module_env/Scripts/python.exe',output=f'outputs/r118_dff_partition_continuation_{out}_20261023',coordination=f'outputs/r118_dff_partition_continuation_{coord}_20261023',bound_seconds=7500)))
    put(P/'Readiness.json',dict(status='PASS_PROSPECTIVE_EXACT_ARGUMENT_REGISTRY_INTEGRATION_UNDER_FORBIDDEN_SOLVER_AND_MODEL',source_original_controller_unchanged=True,old_all4_roots_and_25_operations_fixed=True,old_actual_prefixes_verified_before_further_actions=True,fixture_preparation_costs=fixture.preparation_costs,independent_fixture_receipt_proof=checked,actual_new_nonlinear_model_calls_in_preparation=0,protocol_sha256=sha(P/'Protocol.json'),workflow_seconds=time.monotonic()-began))
    print(json.dumps(dict(status='NEW_MISSING_ONLY_PARTITION_STUDY_FROZEN_READY',new_PF_model_calls_in_preparation=0,actual_pure_input_preparations=fixture.preparation_costs['native_input_returns'])))

if __name__=='__main__':main()
