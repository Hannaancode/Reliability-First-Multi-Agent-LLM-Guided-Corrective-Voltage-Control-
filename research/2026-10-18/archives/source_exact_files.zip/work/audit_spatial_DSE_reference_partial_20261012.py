"""One independently owned TERMINAL-PARTIAL reader, no science/retry.

Reuses unchanged complete-branch source checks for the four closed L1 jobs.
L2 checks every returned prefix receipt against its actual parent, but never
asserts an unobserved endpoint, full trajectory replay or all-eight gate.
"""
import copy
import hashlib
import importlib.metadata
import json
import math
import os
import pickle
import time
from datetime import datetime,timezone
from pathlib import Path
import pandapower as pp
import audit_spatial_DSE_reference_screen_20261012 as original_reader
from audit_spatial_allocation_inputs_v3_20261011 import signature
from candidate_process_evidence_utils import frozen_checks,seal
from frozen_physics_loader import load_stack
from native_continuation_preservation_v2 import canonical,extended_local_path
from native_postcommit_preservation import measured_bus_fields,check_commit
from paid_spatial_controller_checkpoint_v1 import validate_chain,process_alive
from trusted_causal_controller_snapshot import SOLVER_ROLES,cap_totals,write_bytes

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'outputs/critical_research_reset_20261010/spatial_DSE_reference_screen_20261012'
OUT=extended_local_path(BASE/'independent_partial_audit_v1')
read=lambda p:json.loads(p.read_text('utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    start=time.perf_counter();state=read(BASE/'owner_status.json')
    assert state['exit_code']==1 and state['stage']=='terminal_partial_or_reader_failure_no_retry'
    assert not process_alive(state['actual_pid']) and not process_alive(state['current']['actual_pid'])
    assert not (BASE/'Reader_Launch.json').exists() and not (BASE/'independent_audit/reader.claim').exists()
    assert not OUT.exists();OUT.mkdir()
    prep=read(BASE/'partial_analysis_preparation_v1/Protocol.json')
    def bound():
        assert time.perf_counter()-start<prep['reader_admission_seconds'],'Independent partial reader bound; no automatic retry'
    for n,d in prep['analysis_source_sha256'].items():assert sha(ROOT/n)==d,n
    write_bytes(OUT/'reader.claim',canonical({'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),
        'analysis_protocol_sha256':sha(BASE/'partial_analysis_preparation_v1/Protocol.json'),'new_science':0}))
    p=read(BASE/'preparation/Protocol.json');ph=sha(BASE/'preparation/Protocol.json')
    assert prep['original_science_protocol_sha256']==ph
    for n,d in p['source_sha256'].items():assert sha(ROOT/n)==d,n
    assert {n:importlib.metadata.version(n) for n in p['runtime_identity']}==p['runtime_identity']
    # Closed sources/owners before any new reader. No original reader ran.
    for f in (BASE/'branches').glob('*/owner.claim'):
        c=read(f);assert not process_alive(c['actual_pid']) and not process_alive(c['actual_parent_pid'])
    complete={}
    for job in state['finished_jobs']:
        bound()
        spec=next(x for x in p['jobs'] if x['job_id']==job)
        complete[job]=original_reader.saved_source_check(spec,p,ph)
    assert set(complete)=={'L1_literal_DFF','L1_literal_DFF_ALT','L1_protected_DFF','L1_protected_DFF_ALT'}
    job=state['current']['job_id'];assert job=='L2_literal_DFF'
    folder=extended_local_path(BASE/'branches'/job);spec=next(x for x in p['jobs'] if x['job_id']==job)
    manifest=read(folder/'Closed_Manifest.json');assert manifest['exit_code']==1
    actual={f.relative_to(folder).as_posix() for f in folder.rglob('*') if f.is_file()}
    assert actual==set(manifest['members'])|{'Closed_Manifest.json'}
    for n,d in manifest['members'].items():f=folder/n;assert f.stat().st_size==d['bytes'] and sha(f)==d['sha256']
    rows,tail=validate_chain((folder/'scientific.jsonl').read_bytes(),ph)
    intents=[r for r in rows if r['event']=='literal_PF_intent'];returns=[r for r in rows if r['event']=='literal_PF_return']
    exceptions=[r for r in rows if r['event']=='literal_PF_exception']
    assert not any(r['event']=='literal_PF_interrupted_unknown' for r in rows)
    observed={r['payload']['identity']:r for r in returns+exceptions}
    assert len(observed)==len(returns)+len(exceptions)
    assert set(observed)=={r['payload']['identity'] for r in intents} # actual clean tail; otherwise this assertion must fail, not guess.
    def capsule(a):
        d=folder/a['relative'];raw=(d/'trusted_local_net.pkl').read_bytes();meta=(d/'Manifest.json').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==a['payload_sha256'] and hashlib.sha256(meta).hexdigest()==a['manifest_sha256']
        return pickle.loads(raw)['net']
    for r in intents:assert r['payload']['kwargs']==SOLVER_ROLES[r['payload']['role']]
    for r in returns:
        bound()
        fields=measured_bus_fields(capsule(r['payload']['anchors']));assert fields and all(math.isfinite(x) for f in fields.values() for x in f.values())
    menus={r['payload']['decision']:r['payload'] for r in rows if r['event']=='literal_preselection_full_menu'}
    candidates=[r['payload'] for r in rows if r['event']=='literal_candidate_return']
    candidate_intents=[r for r in rows if r['event']=='literal_candidate_intent']
    assert len(candidates)==len(candidate_intents)
    commits=[r['payload'] for r in rows if r['event']=='literal_actual_commit_verified']
    searches=[r['payload'] for r in rows if r['event']=='literal_complete_search_return']
    v2,runner,_=load_stack();zones=read(ROOT/p['metadata_path'])['zones'];parents={k:capsule(x['parent']) for k,x in menus.items()}
    for decision,menu in menus.items():
        net=parents[decision];reports={z:runner.rescue.extract_zone_state_full(net,z,zones) for z in sorted(zones)}
        buses=runner.rescue.candidate_buses_from_state(net,zones,reports,[])
        expected=[runner.rescue.make_action(b,q) for b in buses for q in runner.rescue.Q_SWEEP]
        assert canonical(expected)==canonical(menu['ordered_menu'])
        taken=[x['action'] for x in candidates if x['decision']==decision]
        assert canonical(taken)==canonical(expected[:len(taken)])
    # Native masks recomputed using exactly the producer's paid whole returns.
    physical_attempts=[];original={n:getattr(pp,n) for n in ('runpp','runopp','rundcpp','runpp_3ph')};active=None;used=[]
    def refuse(*a,**k):physical_attempts.append(True);raise AssertionError('Partial reader cannot solve')
    for n in original:setattr(pp,n,refuse)
    def reply(net,**kwargs):
        assert active is not None and kwargs==SOLVER_ROLES['trial'] and len(active['solver_capsules'])==1
        a=active['solver_capsules'][0];saved=capsule(a);assert signature(net)==signature(saved)
        net.clear();net.update(copy.deepcopy(saved));used.append(a['relative'])
        failed=any(x['payload']['anchors']==a for x in exceptions)
        if failed:raise RuntimeError('Saved genuine exception; zero new solver calls')
    pp.runpp=reply
    try:
        for c in candidates:
            bound()
            active=c;answer=runner.rescue.verify_action(copy.deepcopy(parents[c['decision']]),c['action'])
            assert canonical(answer)==canonical(c['verification']);active=None
        assert not physical_attempts
    finally:
        for n,f in original.items():setattr(pp,n,f)
    for search in searches:
        bound()
        decision=search['decision'];cs=search['candidates']
        assert canonical([c['action'] for c in cs])==canonical(menus[decision]['ordered_menu'])
        assert canonical([runner.rescue.score_candidate(c) for c in cs])==canonical(search['scores'])
        taken=[x for x in candidates if x['decision']==decision]
        assert canonical([x['verification'] for x in taken])==canonical([x['verif'] for x in cs])
        best=max([c for c in cs if c['verif']['accepted']],key=runner.rescue.score_candidate)
        entry=next(x for x in commits if x['decision']==decision);assert canonical(entry['action'])==canonical(best['action'])
        a=capsule(entry['selected_trial']);b=capsule(entry['actual_commit'])
        proof=check_commit(measured_bus_fields(a),measured_bus_fields(b),best['verif']['before'],cap_totals(b),upper=1.06,guard_tolerance=0.)
        assert canonical(proof)==canonical(entry['proof'])
        if decision+1 in parents:
            assert signature(parents[decision+1])==signature(b) and canonical(measured_bus_fields(parents[decision+1]))==canonical(measured_bus_fields(b))
    last=max(menus);last_candidates=[c for c in candidates if c['decision']==last]
    pending=menus[last]['ordered_menu'][len(last_candidates):]
    assert pending and last>len(searches)
    deadline=datetime.fromisoformat(read(BASE/'Job_Launches'/(job+'.json'))['absolute_branch_deadline_utc'])
    late=[r['payload']['identity'] for r in intents if datetime.fromisoformat(r['at_utc'])>=deadline]
    crossed=[r['payload']['identity'] for r in returns if datetime.fromisoformat(r['at_utc'])>=deadline]
    summary={'actual_PF_attempts':len(intents),'actual_PF_returns':len(returns),'actual_PF_exceptions':len(exceptions),
        'actual_candidate_attempts_returns':len(candidates),'complete_native_decisions':len(searches),'actual_commits':len(commits),
        'actual_declared_current_decisions':len(menus),'last_complete_current_metrics':runner.rescue.grid_metrics(parents[last]),
        'initial_measured_metrics':menus[1]['current_metrics'],'last_incomplete_menu_returned':len(last_candidates),
        'last_incomplete_menu_declared':len(menus[last]['ordered_menu']),'last_menu_unexecuted_action_identities':pending,
        'pure_PF_seconds_from_all_return_exception_journals':sum(r['payload']['seconds'] for r in returns+exceptions),
        'whole_owned_failed_branch_cost':read(BASE/(job+'_branch_Owner_Ended.json')),
        'per_category_partial_preservation_storage_scan_time':'UNKNOWN; no final observer Result. Whole owned workflow measured, never impute subintervals.',
        'PF_intents_timestamped_at_or_after_deadline':late,'paid_return_records_at_or_after_deadline':crossed,
        'exact_UTC_backend_entry_for_straddling_call':'UNKNOWN; UTC intent is before durable-write/solver entry. No stronger exact deadline-entry claim.',
        'actual_failure':read(folder/'Failure.json'),'complete_journal_tail_sha256':tail,
        'all_returned_receipt_input_mask_scope_score_and_commit_checks_PASS':True,
        'full_L2_continuous_independent_physical_replay':'NOT_EXECUTED_UNKNOWN','L2_final_endpoint':'UNKNOWN',
        'all8_headroom_physical_economic_and_LLM_gates':'UNKNOWN_UNACHIEVED','new_reader_PF_model_optimizer_calls':0}
    unexecuted=[s['job_id'] for s in p['jobs'] if not s.get('reused_prior_science') and s['job_id'] not in complete and s['job_id']!=job]
    assert len(unexecuted)==26 and all(not (BASE/'branches'/j).exists() for j in unexecuted)
    results={'completed_new_branches':complete,'partial_attempted_branch':summary,'genuinely_unexecuted_new_branches':unexecuted,
        'certified_prior_paid_S1_reuse':{'certificate':p['S1_reuse_certificate'],'sha256':p['S1_reuse_certificate_sha256'],'new_science':0},
        'no_selected_L1_prefix_as_evaluation_subset':True,'original_complete_only_reader_not_run':True,'no_old_owner_restart_or_budget_extension':True}
    write_bytes(OUT/'Actual_Partial_Identity_Cost_And_Source_Audit.json',canonical(results))
    write_bytes(OUT/'Independent_Audit.json',canonical({'status':'PASS_PRESERVED_PREFIX_AND_FOUR_COMPLETED_BRANCHES',
        'science_status':'TERMINAL_PARTIAL','all8_headroom':'UNKNOWN','new_science':0,'actual_reader_pid':os.getpid(),
        'reader_seconds_before_archive':time.perf_counter()-start,'original_source_checks_preserved':True,
        'analysis_source_sha256':prep['analysis_source_sha256']}))
    write_bytes(OUT/'Fresh_Frozen_Checks.json',canonical(frozen_checks()))
    bound()
    files={f.relative_to(extended_local_path(BASE)).as_posix():f for f in extended_local_path(BASE).rglob('*') if f.is_file()
        and f.name not in ('partial_reader_stdout.log','partial_reader_stderr.log')}
    seal(OUT,files,'Verified_Terminal_Partial_Reference_Evidence.zip')
    write_bytes(OUT/'Completion.json',canonical({'exit_code':0,'full_reader_seconds':time.perf_counter()-start,'new_science':0}))
    print(json.dumps({'status':'PASS_PARTIAL_EVIDENCE_ONLY','actual_PF':len(intents),'actual_commits':len(commits),'all8_gate':'UNKNOWN'}))


if __name__=='__main__':main()
