"""Record the saved-only join, retain its reader correction and update resume."""
from pathlib import Path
import datetime,hashlib,json
R=Path(__file__).resolve().parents[1]
O=R/'outputs/original118_saved_dse_reconciliation_20261028'
def read(p):return json.loads(p.read_text('utf-8-sig'))
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8')
def main():
    assert not (O/'Verified_Completion.json').exists()
    at=datetime.datetime.now(datetime.timezone.utc).isoformat()
    audit=read(O/'independent/Independent_Audit.json');assert audit['status'].startswith('PASS_ALL4_')
    old=(O/'Results.md').read_text('utf-8')
    incorrect='Both language-containing systems have one case with more strict OV than numerical D-SE.'
    corrected='HG-VF has one case with more strict OV than numerical D-SE; offline HG-SE has two such cases.'
    assert incorrect in old
    (O/'Results_Corrected.md').write_text(old.replace(incorrect,corrected),'utf-8')
    write(O/'Documentation_Correction.json',{'at_utc':at,'original_closed_report_preserved':True,
      'original_text':incorrect,'corrected_text':corrected,'source':'independent/Independent_Audit.json',
      'scientific_values_or_comparison_changed':False,'new_science':0})
    write(O/'Process_Inspection_Failure.json',{'stage':'Optional read-only process inspection before saved-file assembly',
      'error':'Bundled document Python has no psutil. Native Get-CimInstance exact command inspection subsequently returned no matching actors.',
      'no_new_scientific_or_GPU_owner_launched':True,'saved_JSON_analysis_completed':True,'new_scientific_calls':0})
    record={'at_utc':at,'status':'COMPLETE_INDEPENDENT_SAVED_ONLY_JOIN_PASS',
      'comparison':'outputs/original118_saved_dse_reconciliation_20261028/Comparison.json',
      'report':'outputs/original118_saved_dse_reconciliation_20261028/Results_Corrected.md',
      'independent_audit':'outputs/original118_saved_dse_reconciliation_20261028/independent/Independent_Audit.json',
      'full_cost_source_blocks':'outputs/original118_saved_dse_reconciliation_20261028/Full_Cost_Source_Blocks.json',
      'all4_DFF_entire_results_exact':True,'numerical_DSE_UV_OV':[35,12],'HGVF_UV_OV':[26,11],'offline_HGSE_UV_OV':[20,12],
      'HGVF_vs_DSE':audit['descriptive_contrasts']['HGVF'],'HGSE_vs_DSE':audit['descriptive_contrasts']['HGSE'],
      'scope':'Same recipe/source and complete DFF outputs; historical ALT committed-metric audit only. No exact old ALT query ppci/full-field/cold identity claim. Four inspected development roots.',
      'new_scientific_calls':0,'GPU_active':0,'jobs_active':0,'all_six_final_goals':'OPEN'}
    write(O/'Verified_Completion.json',record)
    resume=R/'outputs/research_resumption_20261028/Current_Resume.json';d=read(resume)
    d.update(at_utc=at,scientific_jobs=[],gpu_assignments=[],waiting_check=None,
      saved_DSE_join='outputs/original118_saved_dse_reconciliation_20261028/Verified_Completion.json')
    d['next']=[
      'Publish compact latest raw-attribution, prompt inconsistency, 113-page thesis QA and saved D-SE join with fresh branch lease and downloaded-byte checks.',
      'Integrate the saved D-SE comparison into a later thesis revision with scope/cost/OV cautions; current 113-page reviewed copy is preserved.',
      'Complete remaining thesis evidence requirements where saved records support them; never invent missing historical RAG adjudication, later137 raw joins or coauthor roles.',
      'Further trained external118/common-information/publicQA studies require separately justified source-compatible protocols, actual loader/runtime/preservation/resource gates; no idle GPU.',
      'Candidate-example inconsistency is diagnosed. No prompt sweep or scientific rescue run is authorized solely by that observation.']
    write(resume,d)
    msg=('Saved D-SE comparison independently reconciled: all4 complete recent DFF result objects exactly equal old8Oct DFF, '
      'including29actions/alllogs; scenario/source hashes match. Reused historical ALT gives DSE35UV/12OV versus original '
      'HG-VF26UV/11OV and offlineHG-SE20UV/12OV. HG-VF3UVwins/1loss and1extraOVcase; offlineHG-SE3wins/1tie and2extraOVcases. '
      'Historical4root DSE15425PFattempts/15407returns/18exceptions remain paid;0newscience/GPU. ALT oldcommitted-metric audit '
      'does not establish allcandidate/fullfield/native-input/cold equivalence. Descriptive inspected development, no fullsuperiority. '
      'Independent reader corrected a report sentence (HG-SE has2extraOVcases); originalclosedreport and unchangednumericresults preserved. '
      'Current reviewedthesis113pages/11of35requirements; all6goalsOPEN; alljobsended/noGPU/timer.')
    for p in [R/'outputs/Unattended_Execution_Runbook.md',R/'outputs/llm_value_development/Next_Phase_Plan.md',R/'RESEARCH_TASKS.md']:
        p.write_text('## Saved stronger numerical comparison reconciled — '+at+'\n\n'+msg+'\n\n'+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+at+'\n'+msg+'\nEvidence: outputs/original118_saved_dse_reconciliation_20261028/Verified_Completion.json\n')
    taskfile=R/'outputs/research_tasks_20261014/Tasks.json';t=read(taskfile)
    t.update(updated_at_utc=at,latest_verified_resume='outputs/research_resumption_20261028/Current_Resume.json',
      latest_verified_update=record,current_owned_jobs=[],current_GPU_assignments=[],current_waiting_automations=[],
      thesis_documentation_requirements_complete=11,thesis_documentation_requirements_total=35)
    write(taskfile,t)
    print(json.dumps({'status':record['status'],'new_science':0,'research_goals_open':6}))
if __name__=='__main__':main()
