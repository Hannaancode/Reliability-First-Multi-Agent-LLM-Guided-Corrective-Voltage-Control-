"""Save exact terminal evidence and unfinished work; no scientific calls."""
import json, hashlib, os
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/native_readout_progress_handoff_20261020'

def read(rel):
    return json.loads((ROOT / rel).read_text(encoding='utf-8'))

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush(); os.fsync(f.fileno())
    temporary.replace(path)

def main():
    at = datetime.now(timezone.utc).isoformat()
    OUT.mkdir(exist_ok=True)
    probe = read('outputs/native_feature_exact_assignment_probe_20261020/All_Selected_Exact_Assignments.json')
    assert len(probe) == 3
    assert all(x['identity_verified'] and x['assignment_count'] == 0 and
               x['new_allocation_requests'] == 0 and not x['exact_runtime_proxy_present'] for x in probe.values())
    fit = read('outputs/native_fit_teacher_handoff_20261020/Completion.json')
    assert fit['audit_status'].startswith('PASS_INDEPENDENT_ALL_AVAILABLE_NATIVE64')
    failed = read('outputs/native_same_information_MLP_FIT_20261020/Failure.json')
    assert failed['actual_costs']['optimizer_returns'] == 5442
    numeric = read('outputs/native_stationary_readout_fit_20261020/numeric_v2/Results.json')
    assert numeric['status'].startswith('COMPLETE_ALL_FIXED_LINEAR_AND_RBF')
    next_tasks = [
        'Independently preserve/audit all 5442 MLP caller/backward/update returns and 55 complete saved states through update5400 with zero model/optimizer/PF calls. Last42 updates have no saved weights; fixed500epoch outcome UNKNOWN, never resume/choose a partial checkpoint.',
        'Independently verify both fixed numeric readout saved equations, weighted normalization/centering, predictions and manifest with zero factorization/solve/model/PF calls. FIT loss is descriptive, not a benchmark.',
        'Complete saved-field native1.5B command KCL supplement without a new PF; command was rejected for creating2OV, no commit.',
        'Keep all three timed-out allocation attempts terminal and unentered. Exact read-only probes verified zero current assignments. No replacement request, account rotation, scientific retry or old budget extension.',
        'Freeze a prospective full protected common-task comparison only for genuinely available complete policies. Frozen SLM features and all DEV16/confirmation32 inference/physics remain UNKNOWN/unentered; do not present CPU FIT loss as LLM advantage.',
        'Publish new own code, compact proofs and exact task/resume state to research-progress-20261018 with lease and downloaded-byte checks; raw scientific assets remain local.'
    ]
    state = {
        'at_utc': at, 'status': 'FIT64_COMPLETE_CPU_READOUTS_COMPLETE_MLP_RESOURCE_PARTIAL_THREE_GPU_ATTEMPTS_UNENTERED_NO_ASSIGNMENTS',
        'all6goals': 'OPEN', 'priority_order': ['G3','G2','G1','G4','G5','G6'],
        'owned_jobs': [], 'GPU_assignments': [], 'timers': [],
        'FIT64': {'status': fit['scientific_status'], 'independent': fit['audit_status'], 'decisions':1929,
                  'fully_restored':35,'worlds':64,'residual_UV':94,'residual_OV':0,
                  'new_PF_primary_and_independent':574,'new_derivative_LU_RHS_LP':[1929,1929,5787,3858],
                  'cached_paid_responses':1706,'all_cached_response_links_independently_passed':True,
                  'evidence':'outputs/native_fit_teacher_handoff_20261020/Completion.json'},
        'numeric_readouts': {'status':numeric['status'],'grouped_current_inputs':241,'all_weighted_rows':1929,
                             'all_fixed_kernels':['linear','rbf'],'new_Cholesky_threeRHS':[2,2],
                             'evidence':'outputs/native_stationary_readout_fit_20261020/numeric_v2/Results.json',
                             'held_physics_performance':'UNKNOWN_NOT_EXECUTED'},
        'MLP': {'status':'TERMINAL_RESOURCE_PARTIAL_FIXED500_EPOCHS_NOT_ACHIEVED','actual_forward_backward_updates':[5442,5442,5442],
                'last_full_state_update':5400,'last42_update_weights':'UNRECOVERED_UNKNOWN',
                'complete_saved_states':55,'no_partial_checkpoint_performance_selection':True,
                'evidence':'outputs/native_same_information_MLP_FIT_20261020/Failure.json'},
        'three_GPU_attempts': {'historical_allocation_requests':3,'science_started':False,'cloud_input_transfers':0,
                              'actual_new_model_forwards':0,'current_assignments':0,'exact_probe':
                              'outputs/native_feature_exact_assignment_probe_20261020/All_Selected_Exact_Assignments.json',
                              'reason':'Allocation responses timed out; exact subsequent GET-only probes confirm zero assignments. Not an OAuth or quota-denial conclusion.'},
        'saved_native15_command': {'new_model_calls':0,'primary_and_independent_PF':2,'old_UV_OV':[0,0],
                                  'candidate_UV_OV':[0,2],'guard':'REJECTED','commits':0,
                                  'evidence':'outputs/native15_saved_command_physics_independent_20261020/Result.json'},
        'DEV16_and_confirmation32':'UNEXECUTED_UNKNOWN_LOCK_RETAINED',
        'all_turn_new_PF_returns_before_supplements':852,
        'no_LLM_or_aggregate_published_benchmark_superiority':True,
        'next_ordered_tasks': next_tasks,
        'last_verified_GitHub':'e7fc00089296a54eb840be01ce91eb31e5cc0842'
    }
    audit=ROOT/'outputs/native_closed_CPU_evidence_audit_v3_20261020/Independent_Audit.json'
    if audit.exists():
        independent=json.loads(audit.read_text(encoding='utf-8'))
        assert independent['status'].startswith('PASS_ADDITIVE_CLOSED_CPU_EVIDENCE')
        state['closed_CPU_evidence_audit']={'status':independent['status'],'evidence':audit.relative_to(ROOT).as_posix(),
            'source_failures_preserved':['Original saved-prediction symmetric-dot arithmetic mismatch4.16e-16','BFSW internalYbus cache absent; existing independently certified sourceY used with exact branch/shunt/base matches'],
            'mechanical_repairs_only_zero_new_science':True,'all9_original_frozen_checks_passed':True,
            'KCL_all13_max_complex_pu_residual':independent['results']['saved_command_KCL']['max_complex_pu_KCL_residual']}
        state['next_ordered_tasks']=next_tasks[3:]
    serving=ROOT/'outputs/native_stationary_serving_boundary_20261020/Readiness.json'
    if serving.exists():state['serving_software_readiness']=json.loads(serving.read_text(encoding='utf-8'))
    diagnosis=OUT/'Saved_Only_Teacher_Learning_Bottleneck.json'
    if diagnosis.exists():state['teacher_target_bottleneck']=json.loads(diagnosis.read_text(encoding='utf-8'))
    for name in ['Independent_Audit.json','Saved_Field_KCL_Audit.json']:
        if (OUT/name).exists(): state[name[:-5]] = read((OUT/name).relative_to(ROOT).as_posix())
    write(OUT/'Current_Resume.json', state)
    checkpoint = OUT/'Verified_Progress_And_Limitations.json'
    write(checkpoint, state)
    tasks = read('outputs/research_tasks_20261014/Tasks.json')
    tasks['at_utc'] = at; tasks['goal_remains_active_unachieved'] = True
    for task in tasks['tasks']:
        task['completed'] = False
        if task['checklist_id'] in ['G3','G2','G4','G5']:
            task['current_result'] = 'Native1.5B integration passed; 64FIT teacher complete35/64restored,94residualUV. Two numeric convex readouts fitted. FixedMLP partial5442/30500updates, no performance result. Three frozen-feature allocations timed out before science; exact probes zero assignments. No LLM superiority.'
            task['next'] = next_tasks[0 if task['checklist_id']=='G3' else 4]
        if task['checklist_id']=='G3':
            additions = [('G3.2i','Complete64fixedFIT numerical teacher trajectories, independent replay and all1706paid cache links; retain35/64success and all94residualUV.', 'outputs/native_fit_teacher_handoff_20261020/Completion.json'),
                         ('G3.2j','Compile all1929full causal FIT observations/labels with exact paired tokenizer IDs and no cropping; keep DEV/confirmation locked.', 'outputs/native_fit_training_inputs_20261020/Readiness.json')]
            oldids = {x['id'] for x in task['subtasks']}
            for ident, desc, ev in additions:
                if ident not in oldids: task['subtasks'].append({'id':ident,'completed':True,'description':desc,'evidence':ev,'verified_at_save':at})
            if audit.exists() and 'G3.2k' not in oldids:
                task['subtasks'].append({'id':'G3.2k','completed':True,'description':'Independently preserve partialMLP5442cost/55fullstates and both complete fixed numeric readout equations; no partial checkpoint performance selection or new scientific calls.','evidence':audit.relative_to(ROOT).as_posix(),'verified_at_save':at})
        if task['checklist_id']=='G4' and serving.exists():
            sub=task.setdefault('subtasks',[])
            if not any(v['id']=='G4.3c' for v in sub):sub.append({'id':'G4.3c','completed':True,'description':'Verify all241same-current serving text/400feature identities,1929native transitions/guards and11negative boundaries; software only, frozen-body extraction unentered.','evidence':serving.relative_to(ROOT).as_posix(),'verified_at_save':at})
    write(ROOT/'outputs/research_tasks_20261014/Tasks.json', tasks)
    header = ('## Latest closed FIT/readout state — '+at+'\n\n'
              'All64fixed FIT teacher episodes independently complete:1929decisions,35/64fullyrestored,94residualUV/0OV;574newPF including independent replay. All1706paid-cache links verified. This is development, not learned-model benefit.\n\n'
              'Both fixed numeric convex readouts fitted; no held/physical score. Fixed500epoch MLP stopped at900sec after5442updates;55fullstates through5400,final42weights unrecovered,performanceUNKNOWN. Never resume/select a partial checkpoint. Three frozen-feature allocation responses timed out before science; subsequent exact account/UUID GET-only probes found ZEROassignments.0newfeatureforwards;no replacement/fallback.\n\n'
              'No owned job/GPU/timer. AllsixfinalgoalsOPEN. All16DEV/32confirmation remain unentered. Exact resume: outputs/native_readout_progress_handoff_20261020/Current_Resume.json. Continue independent saved-output audits and prospective scientifically justified work; preserve frozen original assets/all failures/full DSE BOTH costs.\n\n')
    if audit.exists():
        header=header.replace('Continue independent saved-output audits and prospective scientifically justified work;',
            'Saved-state/readout/KCL independent audit nowPASS, original analysis failures retained; serving241/1929/11boundary softwarePASS. Teacher18zero-action horizon loops+11guard stops; no benefit from imitating its failures alone. Next requires complete actual policies, fixed fair physical/economic protocol and available exact resource;')
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        path=ROOT/rel; text=path.read_text(encoding='utf-8')
        if not text.startswith(header): path.write_text(header+text,encoding='utf-8')
    with (ROOT/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write('\n'+header+'Method: stationary frozen-body readouts were prepared on241distinct current states preserving1929weights; no body features executed. Numeric linear/RBF controls fitted without a sweep. Limit: teacher35/64restoration, no DEV/confirmation score or LLM advantage. GPU allocation response failures retained; exact subsequent probes zero assignments, not zero historical requests. Next: saved-state/cost/readout equation audits and source-bound fair comparison gates.\n')
    latest = ROOT/'outputs/llm_value_relational_adaptation_research_20261009/latest_execution_status.json'
    if latest.exists():
        old=json.loads(latest.read_text(encoding='utf-8'));old['latest_verified_at_utc']=at;old['current_resume']='outputs/native_readout_progress_handoff_20261020/Current_Resume.json';old['current_owned_jobs']=[];old['current_GPU_assignments']=[];old['current_status']=state['status'];write(latest,old)
    print('SAVED_EXACT_TERMINAL_STATE_NO_JOBS_NO_GPU_ALL6GOALS_OPEN')

if __name__=='__main__': main()
