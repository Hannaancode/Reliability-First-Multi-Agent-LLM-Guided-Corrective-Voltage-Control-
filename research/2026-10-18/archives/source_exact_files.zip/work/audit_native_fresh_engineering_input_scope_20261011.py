"""Additive input/scope coverage after the first external reader ENDED."""
import copy,hashlib,json,os,pickle,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
import pandas as pd
import pandapower as pp
from frozen_physics_loader import load_stack,AUDIT
from candidate_process_evidence_utils import frozen_checks
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/'outputs/critical_research_reset_20261010/native_fresh_engineering_20261011'
PREP=BASE/'preparation_v2';DATA=BASE/'execution';OUT=BASE/'independent_input_scope_addendum'
read=lambda p:json.loads(p.read_text('utf8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not OUT.exists()
prior=read(BASE/'independent_audit/Independent_Engineering_Audit.json');assert prior['passed']
previous=read(BASE/'independent_audit/owner.claim')
ids=[previous['actual_pid'],previous['actual_parent_pid'],read(DATA/'owner.claim')['actual_pid'],read(BASE/'Actual_Launch.json')['launcher_pid']]
p=subprocess.run(['powershell','-NoProfile','-Command','Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -in '+','.join(map(str,ids))+' } | Select-Object -ExpandProperty ProcessId'],capture_output=True,text=True,timeout=30)
assert p.returncode==0 and not p.stdout.strip(),'Previous owner/reader still live'
OUT.mkdir();start=time.perf_counter()
def write(name,v):
 with (OUT/name).open('x',encoding='utf8') as f:json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
write('owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),'prior_owner_and_reader_ended':ids})
proto=read(PREP/'Protocol.json');netpath=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json';metapath=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json'
assert sha(netpath)==proto['network_sha256'] and sha(metapath)==proto['metadata_sha256'] and sha(PREP/'Scenario.json')==proto['scenario_sha256']
for name,h in proto['source_sha256'].items():assert sha(ROOT/name)==h
manifest=read(DATA/'Closed_Manifest.json')
path=DATA/'FRESH_ENGINEERING_ROOT_CAPTURE/trusted_local_snapshot.pkl';anchors=read(DATA/'Root_Anchors.json')
assert sha(path)==anchors['payload_sha256']==manifest['all_actual_members'][path.relative_to(DATA).as_posix()]['sha256']
actual=pickle.loads(path.read_bytes())['net']
old={k:getattr(pp,k) for k in ['runpp','runopp','rundcpp','runpp_3ph'] if hasattr(pp,k)}
attempted=[]
def forbid(*a,**kw):attempted.append('solver');raise BaseException('No new solver permitted during additive analysis')
for k in old:setattr(pp,k,forbid)
try:
 v2,runner,reflection=load_stack();assert all(a['all_function_asts_unchanged'] for a in AUDIT)
 zones={k:[int(b) for b in v] for k,v in read(metapath)['zones'].items()}
 expected=v2.v0.apply_scenario_to_net(pp.from_json(str(netpath)),read(PREP/'Scenario.json'),zones)
 tables=[]
 for name,table in expected.items():
  if isinstance(table,pd.DataFrame) and not name.startswith(('res_','_')):
   pd.testing.assert_frame_equal(table,actual[name],check_exact=True);tables.append(name)
 reports={z:runner.rescue.extract_zone_state_full(actual,z,zones) for z in sorted(zones)}
 buses=runner.rescue.candidate_buses_from_state(actual,zones,reports,[])
 candidates=[r['row']['payload']['ordered_candidates'] for r in map(json.loads,(DATA/'Native_Journal.jsonl').read_text('utf8').splitlines()) if r['row']['event']=='native_search_return']
 assert len(candidates)==1
 observed=[(int(next(iter(c['action']['add_shunts_q_mvar']))),float(next(iter(c['action']['add_shunts_q_mvar'].values())))) for c in candidates[0]]
 required=[(b,q) for b in buses for q in runner.rescue.Q_SWEEP]
 assert observed==required and len(required)==len(set(required)) and not attempted
 frozen=frozen_checks();assert frozen['all_passed'];write('Fresh_Original_Frozen_Checks.json',frozen)
 write('Independent_Input_And_Scope_Addendum.json',{
  'passed':True,'first_reader_scope_extension':'Original audit preserved. This adds explicit network/metadata/scenario and actual element-table/current native menu coverage.',
  'exact_input_element_tables':tables,'actual_global_candidate_buses':buses,'ordered_unique_native_actions':len(required),
  'global_native_Q_order_exact':True,'future_LOCAL_common_AND_zone_scope':'NOT CERTIFIED by this DFF engineering root',
  'original_frozen_checks':frozen,'actual_pure_network_decode':1,'actual_pure_scenario_application':1,
  'new_PF_model_optimizer_forecast_solver_calls':0,'previous_owner_and_reader_ended':ids,
  'seconds':time.perf_counter()-start,'full_policy_or_LLM_benefit':'UNTESTED'})
 print(json.dumps({'passed':True,'ordered_actions':len(required),'input_tables':len(tables),'nine_frozen_checks_passed':True,'new_scientific_calls':0}))
finally:
 for k,v in old.items():setattr(pp,k,v)
