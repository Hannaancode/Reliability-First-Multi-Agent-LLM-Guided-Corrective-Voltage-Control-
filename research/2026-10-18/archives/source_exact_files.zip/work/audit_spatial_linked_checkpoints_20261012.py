"""Separate read-only linked SOFTWARE evidence reader, no solver/model calls."""
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

from candidate_process_evidence_utils import frozen_checks, seal
from native_continuation_preservation_v2 import canonical, extended_local_path
from paid_spatial_controller_checkpoint_v3 import read_checkpoint, validate_linkages, validate_chain
from paid_spatial_controller_checkpoint_v1 import process_alive
from trusted_causal_controller_snapshot import write_bytes

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'outputs/critical_research_reset_20261010/spatial_linked_checkpoint_software_20261012'
OUT = BASE/'independent_audit'
read = lambda p: json.loads(p.read_text('utf8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    begun = time.perf_counter()
    write_bytes(OUT/'owner.claim', canonical({'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(),
        'source_sha256': sha(Path(__file__)), 'purpose': 'READ_ONLY_SOFTWARE_EVIDENCE'}))
    protocol = read(BASE/'Protocol.json')
    result = read(BASE/'Linked_Checkpoint_Software_Readiness.json')
    assert result['status'] == 'PASS' and result['check_count'] == 17 and len(set(result['checks'])) == 17
    assert len(set(result['software_pids'])) == 3 and all(not process_alive(pid) for pid in result['software_pids'])
    assert os.getpid() not in result['software_pids']
    for name, digest in protocol['source_sha256'].items():
        assert sha(ROOT/name) == digest, name
    assert protocol['source_sha256'] == result['source_sha256']
    warm = read(BASE/'Warm_Returned_Anchor.json')
    middle = read(BASE/'middle_Result.json')
    third = read(BASE/'third_Result.json')
    directory = extended_local_path(BASE/'fixture')
    anchors = [('warm', warm['anchor'], warm['controller']),
               ('middle', middle['anchor'], middle['controller']),
               ('third', third['anchor'], third['controller'])]
    summaries = []
    states = []
    for label, anchor, controller in anchors:
        state, manifest = read_checkpoint(anchor, expected_protocol=protocol,
            expected_protocol_sha256=sha(BASE/'Protocol.json'), expected_controller_identity=controller,
            expected_directory=directory)
        links = validate_linkages(state, directory)
        rows, tip = validate_chain(state['journal_bytes'], sha(BASE/'Protocol.json'))
        expected = {'warm': (2, 1, 1, 0, 1, 24), 'middle': (3, 2, 1, 1, 2, 23),
                    'third': (4, 3, 1, 2, 2, 23)}[label]
        c = state['counters_before_checkpoint']
        assert (c['pf_attempts'], c['pf_returns'], c['pf_exceptions'], len(links),
                controller['actual_commit_count'], controller['remaining_slots']) == expected
        assert c['new_queries'] == c['pf_attempts'] == len(state['attempted']) == len(state['receipts'])
        identities = [r['payload']['identity'] for r in rows if r['event'] == 'new_query_intent']
        assert identities == ['query_'+str(i).zfill(6) for i in range(1, c['new_queries']+1)]
        assert len(set(identities)) == len(identities)
        assert sum(r['event'] == 'PF_intent' for r in rows) == c['pf_attempts']
        assert sum(r['event'] == 'PF_return' for r in rows) == c['pf_returns']
        assert sum(r['event'] == 'PF_exception' for r in rows) == c['pf_exceptions']
        assert sum(r['event'] == 'paid_receipt_reuse' for r in rows) == c['reused_receipts']
        assert state['absolute_deadline_utc'] == protocol['absolute_deadline_utc']
        assert state['query_limit'] == 8 and state['storage_limit'] == 10000000
        summaries.append({'phase': label, 'attempts': c['pf_attempts'], 'returns': c['pf_returns'],
            'exceptions': c['pf_exceptions'], 'cache_reuses': c['reused_receipts'], 'planned_handoff_links': len(links),
            'commit_cursor': controller['actual_commit_count'], 'remaining_slots': controller['remaining_slots'],
            'known_costs': c, 'journal_rows': len(rows), 'journal_tip': tip,
            'payload_sha256': anchor['payload_sha256'], 'manifest_sha256': anchor['manifest_sha256']})
        states.append(state)
    # Middle also saved an earlier full checkpoint before its final boundary.
    earlier = directory/'controller_checkpoints/middle_after_simulated_second_commit'
    earlier_anchor = {'directory': str(earlier), 'payload_sha256': sha(earlier/'trusted_local_controller.pkl'),
                      'manifest_sha256': sha(earlier/'Manifest.json')}
    # This earlier anchor is independently joined to the later issuing journal;
    # no self-authored hash alone is accepted as provenance.
    middle_rows, _ = validate_chain(states[1]['journal_bytes'], sha(BASE/'Protocol.json'))
    certificate = next(r['payload'] for r in middle_rows if r['event'] == 'complete_controller_checkpoint_saved' and
                       r['payload']['payload_sha256'] == earlier_anchor['payload_sha256'])
    assert certificate['manifest_sha256'] == earlier_anchor['manifest_sha256']
    early_state, _ = read_checkpoint(earlier_anchor, expected_protocol=protocol,
        expected_protocol_sha256=sha(BASE/'Protocol.json'), expected_controller_identity=middle['controller'],
        expected_directory=directory)
    assert early_state['counters_before_checkpoint']['new_queries'] == 3
    assert states[1]['counters_before_checkpoint']['payload_bytes'] > early_state['counters_before_checkpoint']['payload_bytes']
    for prior, following in zip(states, states[1:]):
        assert following['counters_before_checkpoint']['payload_bytes'] > prior['counters_before_checkpoint']['payload_bytes']
        assert following['counters_before_checkpoint']['preservation_seconds'] >= prior['counters_before_checkpoint']['preservation_seconds']
        assert following['counters_before_checkpoint']['pf_seconds'] >= prior['counters_before_checkpoint']['pf_seconds']
    assert states[2]['counters_before_checkpoint']['reused_receipts'] == 5
    assert warm['warm_mock_solver_calls']+middle['mock_solver_calls_in_this_phase']+third['mock_solver_calls_in_this_phase'] == 4
    assert states[2]['controller']['direct_costs']['actual_initial_PF'] == 0
    assert states[2]['controller']['direct_costs']['actual_commit_PF'] == 0
    assert states[2]['controller']['direct_costs']['cursor_fixture_only'] is True
    frozen = frozen_checks()
    write_bytes(OUT/'Frozen_Original_Checks.json', canonical(frozen))
    audit = {'status': 'PASS', 'saved_at_utc': datetime.now(timezone.utc).isoformat(),
        'reader_pid': os.getpid(), 'ended_software_pids': result['software_pids'],
        'source_identity_pass': True, 'three_distinct_actual_software_processes': True,
        'two_closed_planned_handoffs_verified': True, 'four_complete_checkpoint_boundaries_verified': True,
        'inherited_scientific_event_rows_exact_bytes': True, 'receiver_admin_segments_separately_anchored': True,
        'every_paid_identity_unique_and_preserved': True, 'deadline_limits_and_cumulative_costs_never_reset': True,
        'history_cursor_1_then_2_remaining_24_then_23': True, 'all_five_cache_reuses_execute_zero_mock_solver_calls': True,
        'phases': summaries, 'software_checks': 17, 'actual_new_nonlinear_PF_model_optimizer_forecast_cloud_calls': 0,
        'labelled_mock_calls': {'attempts': 4, 'returns': 3, 'exceptions': 1},
        'nine_frozen_original_checks_pass': frozen['all_passed'],
        'reader_workflow_seconds_before_archive_report': time.perf_counter()-begun,
        'limitations': result['limitations']}
    write_bytes(OUT/'Independent_Linked_Checkpoint_Software_Audit.json', canonical(audit))
    files = {p.relative_to(BASE).as_posix(): p for p in BASE.rglob('*')
             if p.is_file() and 'independent_audit' not in p.parts}
    for p in OUT.iterdir():
        if p.is_file():
            files[p.relative_to(BASE).as_posix()] = p
    for name in protocol['source_sha256']:
        files['source/'+Path(name).name] = ROOT/name
    files['source/'+Path(__file__).name] = Path(__file__)
    archive = seal(OUT, files, 'Linked_Controller_Checkpoint_Software_Evidence.zip')
    print(json.dumps({'status': 'PASS', 'software_checks': 17, 'planned_handoffs': 2,
                      'checkpoint_boundaries': 4, 'archive': archive, 'actual_new_PF_model_calls': 0}))


if __name__ == '__main__':
    main()
