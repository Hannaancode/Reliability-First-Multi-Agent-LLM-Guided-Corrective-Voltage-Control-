"""One saved disposable engineering command, prospective native physics bridge and charged replay."""
import json,pickle,hashlib,os,time,copy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PREP=ROOT/'outputs/native15_saved_command_physics_preparation_20261020';PRIMARY=ROOT/'outputs/native15_saved_command_physics_20261020';READER=ROOT/'outputs/native15_saved_command_physics_independent_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
def run(mode):
    OUT=PRIMARY if mode=='primary' else READER;OUT.mkdir(exist_ok=False);source='work/run_native15_saved_command_physics_20261020.py' if mode=='primary' else 'work/audit_native15_saved_command_physics_20261020.py';put(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(ROOT/source)});start=time.monotonic()
    while not (OUT/'Launcher_ACK.json').exists():assert time.monotonic()-start<60;time.sleep(.1)
    import stable_ddpg_native_bridge_20261020 as b
    from native_upgrade_support_engine_20261020 import signature
    from candidate_process_evidence_utils import frozen_checks
    np=b.np;p=json.loads((PREP/'Protocol.json').read_text());assert mode in ['primary','independent']
    for rel,h in p['source_and_input_hashes'].items():assert sha(ROOT/rel)==h
    with (ROOT/p['current_NET']).open('rb') as f:net=pickle.load(f)
    initial=copy.deepcopy(net);r=json.loads((ROOT/p['saved_native_model_result']).read_text());u=np.asarray(r['warm_u'][0],dtype=np.float32);q0=net.sgen.q_mvar.to_numpy(copy=True)[:3];q=q0-u;assert u.shape==(3,) and np.isfinite(u).all() and (np.abs(u)<=np.float32(.3)).all() and np.array_equal(q,np.asarray(r['warm_Qnext'][0]));net.sgen.loc[net.sgen.index[:3],'q_mvar']=q;sig=signature(net);assert sig==p['new_candidate_signature'] and sig not in p['all_prior_physical_signatures'];before=OUT/'Actual_Native_Query_Before.pkl'
    with before.open('xb') as f:pickle.dump(net,f,protocol=5);f.flush();os.fsync(f.fileno())
    put(OUT/'Attempt.json',{'source':'Existingactualnative1.5Bengineeringwarm/coldexactu,notnewinference,notfinaltrainedpolicy','u':u.tolist(),'q0':q0.tolist(),'qnext':q.tolist(),'signature':sig,'actual_new_PF_attempts':1,'kwargs':{'algorithm':'bfsw','init':'dc'}});t=time.perf_counter();b.pp.runpp(net,algorithm='bfsw',init='dc');assert net.converged and signature(net)==sig;duration=time.perf_counter()-t
    for table in ['bus','line','load','gen','ext_grid','shunt','switch']:assert initial[table].equals(net[table])
    assert initial.sgen.drop(columns=['q_mvar']).equals(net.sgen.drop(columns=['q_mvar'])) and np.array_equal(initial.sgen.q_mvar.to_numpy()[3:],net.sgen.q_mvar.to_numpy()[3:]);vm0=initial.res_bus.vm_pu.to_numpy();vm=net.res_bus.vm_pu.to_numpy();normal=(vm0>=.95)&(vm0<=1.05);ok=bool(np.isfinite(vm).all() and (vm[normal]>=.95-1e-8).all() and (vm[normal]<=1.05+1e-8).all() and (vm<.95).sum()<=(vm0<.95).sum() and (vm>1.05).sum()<=(vm0>1.05).sum());fields={n:net[n].select_dtypes(include=[np.number]).to_numpy(dtype=float) for n in ['res_bus','res_line','res_trafo','res_sgen','res_load','res_ext_grid']};np.savez(OUT/'Actual_All_Fields.npz',**fields)
    if mode=='independent':
        saved=np.load(PRIMARY/'Actual_All_Fields.npz');assert all(np.allclose(saved[n],fields[n],atol=1e-10,rtol=0,equal_nan=True) for n in fields);prior=json.loads((PRIMARY/'Result.json').read_text());assert prior['guard_accepted']==ok and prior['candidate_UV']==int((vm<.95).sum()) and prior['candidate_OV']==int((vm>1.05).sum())
    result={'status':'COMPLETE_NATIVE15_SAVED_DISPOSABLE_COMMAND_PHYSICS_INTERFACE_ENGINEERING' if mode=='primary' else 'PASS_INDEPENDENT_NATIVE15_SAVED_COMMAND_NATIVE_PI_FULL_FIELDS_GUARD_PHYSICS_INTERFACE','mode':mode,'old_UV':int((vm0<.95).sum()),'old_OV':int((vm0>1.05).sum()),'candidate_UV':int((vm<.95).sum()),'candidate_OV':int((vm>1.05).sum()),'candidate_min_VM':float(vm.min()),'candidate_max_VM':float(vm.max()),'guard_accepted':ok,'actual_commits':0,'no_rejected_command_applied_to_current_state':True,'new_PF_attempts':1,'new_PF_returns':1,'new_model_GPU_optimizer_calls':0,'PF_seconds':duration,'engineering_weights_disposable_not_model_accuracy_or_superiority':True,'frozen_original_checks':frozen_checks()};put(OUT/'Result.json',result);put(OUT/'Closed_Manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}});print(result['status'],ok)
