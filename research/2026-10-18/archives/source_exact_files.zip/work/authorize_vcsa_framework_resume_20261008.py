"""Record the direct human upload approval and verify unchanged local inputs.

This performs no authentication, allocation, upload or scientific execution.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PREP = ROOT / 'outputs/vcsa_development/framework_preparation'
manifest = json.loads((PREP / 'HF_Cloud_Payload_Manifest.json').read_text())
archive = ROOT / manifest['archive']
expected_sha = 'bfe7d484dc571778df09f3a7a01fbe7449deefbe8f7174acd4ffe67475d127f8'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
assert archive.stat().st_size == manifest['bytes'] == 34831836
assert digest(archive.read_bytes()) == manifest['sha256'] == expected_sha
assert not (ROOT / 'outputs/vcsa_development/framework_execution').exists(), 'Existing owner/output must be inspected, not duplicated'
source_checks = {}
with zipfile.ZipFile(archive) as bundle:
    names = bundle.namelist()
    assert len(names) == len(set(names)) == 19
    assert bundle.testzip() is None
    declared = json.loads(bundle.read('VCSA_INPUT_MANIFEST.json'))
    assert declared == manifest['members'] and len(declared) == 18
    assert set(names) == set(declared) | {'VCSA_INPUT_MANIFEST.json'}
    for name, sha in declared.items():
        assert digest(bundle.read(name)) == sha
        if name != 'outputs/frozen_input_verification.json':
            assert digest((ROOT / name).read_bytes()) == sha, name
            source_checks[name] = sha
    for name in names:
        if name.endswith('.py'):
            ast.parse(bundle.read(name).decode(), filename=name)
owner = ROOT / 'work/run_vcsa_framework_colab.py'
ast.parse(owner.read_text(), filename=str(owner))
now = datetime.now(timezone.utc).isoformat()
authorization = {
    'recorded_at_utc': now,
    'authorization_source': 'Direct human message in this chat, not heartbeat or goal continuation',
    'human_message': 'I approve uploading the prepared 34,831,836-byte VCSA bundle to sheenahammed@gmail.com\u2019s Colab T4 and running the two-step integration test. Resume the experiments.',
    'archive': manifest['archive'],
    'bytes': 34831836,
    'sha256': expected_sha,
    'destination_account': 'sheenahammed@gmail.com',
    'hardware': 'one Colab T4 runtime',
    'purpose': 'unchanged two-step integration test; no model performance or superiority claim',
    'includes': manifest['includes'],
    'excludes': manifest['excludes'],
    'maximum_allocation_requests': 1,
    'automatic_account_fallback': False,
    'supersedes': 'Earlier pending exact upload approval condition only',
    'other_accounts': 'Read-only checks authorized; no additional GPU allocation from this approval',
}
path = PREP / 'HF_Cloud_Upload_Authorization_20261008.json'
assert not path.exists(), 'Preserve prior authorization record'
path.write_text(json.dumps(authorization, indent=2), encoding='utf-8')
audit = {'checked_at_utc': now, 'passed': True, 'archive_crc_passed': True,
         'archive_members': 19, 'declared_member_hashes_checked': 18,
         'local_member_hashes_checked': len(source_checks),
         'archive_sha256': expected_sha, 'owner_source_sha256': digest(owner.read_bytes()),
         'owner_and_scientific_python_AST_passed': True,
         'framework_execution_directory_absent': True,
         'authorization_record': str(path.relative_to(ROOT)),
         'no_cloud_or_scientific_execution': True}
(PREP / 'Human_Authorized_Resume_Preflight_20261008.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
status_path = ROOT / 'outputs/vcsa_development/latest_execution_status.json'
status = json.loads(status_path.read_text())
status.update(updated_at_utc=now, research_goal='human_authorized_continuation_unachieved',
              exact_upload_approval_pending=False,
              current_specific_block=None,
              exact_upload_authorization=str(path.relative_to(ROOT)),
              next_concrete_step='Fresh all-three read-only identity/resource check, then one unchanged selected Sheena T4 two-step integration owner',
              human_resume_preflight=str((PREP / 'Human_Authorized_Resume_Preflight_20261008.json').relative_to(ROOT)))
tmp = status_path.with_suffix('.tmp'); tmp.write_text(json.dumps(status, indent=2), encoding='utf-8'); tmp.replace(status_path)
print(json.dumps(audit, indent=2))
