"""All-packet independent current-data/units/context/source causal-boundary audit; no inference."""
import hashlib,json,pickle,sys,time,ast
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'outputs/native_inverter_serving_preparation_v3_20261020';OUT=SRC/'independent_audit'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'))
    import candidate_process_runtime
    import numpy as np
    from transformers import AutoTokenizer
    from candidate_process_evidence_utils import frozen_checks
    p=read(SRC/'Protocol.json');r=read(SRC/'Results.json');packets=read(SRC/'Packets.json');inputs=read(SRC/'Input_Hashes.json')
    assert sha(ROOT/'work/native_inverter_serving_contract_v1_20261020.py')==p['frozen_parser_and_prompt_sha256']
    for f,h in inputs.items():assert sha(ROOT/f)==h
    model=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for f,h in r['exact_original_tokenizer_files'].items():assert sha(model/f)==h
    tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True,trust_remote_code=False)
    maxima=np.array(read(ROOT/'outputs/mapdn_remaining_trace_diagnosis_20261020/pv_active.json')['native_column_max']);counts=[]
    sources=[ROOT/'outputs/tpa_native_one_step_engineering_v3_20261020',ROOT/'outputs/tpa_native_second_identity_engineering_20261020']
    expected_order=[];seen=[]
    for order,source in enumerate(sources):
        with (source/'PF0_before.pkl').open('rb') as f:net=pickle.load(f)
        fields=np.load(source/'PF0_fields.npz');caps=.8*np.sqrt((1.2*maxima)**2-net.sgen.p_mw.to_numpy()**2)
        zones=sorted(set(net.sgen['name']),key=lambda x:int(x.removeprefix('zone')))
        assert len(zones)==22
        for zone in zones:
            matching=[x for x in packets if x['root_author_ordinal']==order and x['current']['zone']==zone];assert len(matching)==1;packet=matching[0];current=packet['current'];expected_order.append((order,zone))
            assert current['voltage_limits_pu']==[.95,1.05] and set(current)=={'zone','voltage_limits_pu','buses','inverters'}
            ids=net.bus.index[net.bus.zone==zone].tolist();assert [b['bus'] for b in current['buses']]==ids
            for b in current['buses']:
                index=net.bus.index.get_loc(b['bus']);v=fields['res_bus'][index];ld=net.load[net.load.bus==b['bus']];pv=net.sgen[net.sgen.bus==b['bus']]
                assert b['vm_pu']==float(v[0]) and b['va_degree']==float(v[1])
                assert b['load_p_mw']==float(ld.p_mw.sum()) and b['load_q_mvar']==float(ld.q_mvar.sum())
                assert b['inverter_p_mw']==float(pv.p_mw.sum()) and b['inverter_q_mvar']==float(pv.q_mvar.sum())
            actual=net.sgen[net.sgen['name']==zone];assert [x['bus'] for x in current['inverters']]==[int(x) for x in actual.bus]
            for inv,index in zip(current['inverters'],actual.index):
                pos=net.sgen.index.get_loc(index);assert inv['q_min_mvar']==-float(caps[pos]) and inv['q_max_mvar']==float(caps[pos]);seen.append((order,int(index)))
            assert packet['messages'][1]=={'role':'user','content':'CURRENT_LOCAL_STATE_JSON\n'+json.dumps(current,separators=(',',':'),allow_nan=False)}
            encoded=tokenizer.apply_chat_template(packet['messages'],tokenize=True,add_generation_prompt=True);token_ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
            assert token_ids==packet['token_ids'] and len(token_ids)==packet['prefix_tokens'];assert packet['fits_fixed4096_plus384']==(len(token_ids)+384<=4096);counts.append(len(token_ids))
    assert len(set(seen))==len(seen)==76 and [(x['root_author_ordinal'],x['current']['zone']) for x in packets]==expected_order
    assert len(packets)==r['zonal_packets']==44 and [min(counts),max(counts)]==r['prefix_token_range']
    assert sum(x+384>4096 for x in counts)==r['fixed4096_384_overflows']
    tree=ast.parse((ROOT/'work/native_inverter_serving_contract_v1_20261020.py').read_text(encoding='utf-8'));function=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='messages');assert [a.arg for a in function.args.args]==['current']
    assert not any(isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id in ['open','eval','exec'] for x in ast.walk(function))
    assert read(SRC/'Frozen_Before.json')['all_passed'] and read(SRC/'Frozen_After.json')['all_passed']
    audit={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL44_CURRENT_SOURCE_UNITS_TOKEN_IDS_CAUSAL_BOUNDARY_AND_OVERFLOW_COUNTS','all44_packets_and76_inverter_entries_exact':True,'prefix_token_range':[min(counts),max(counts)],'fixed4096_plus384_overflows':sum(x+384>4096 for x in counts),'all_packets_fit_prospective4096_384_gate':all(x+384<=4096 for x in counts),'raw_inputs_not_truncated':True,'first_root_independent_PF_still_pending':True,'TPA_temporal_global_prototype_information_not_supplied':True,'our_model_inference_or_performance_ready':False,'actual_LLM_PF_GPU_optimizer_calls':0,'workflow_seconds':time.monotonic()-start,'limitations':'New current-only native inverter serving contract. All tested roots are development; model/base/cold/preservation/ownership gates remain. Not equivalent to original paper role or full TPA information contract.'}
    (OUT/'Independent_Audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8');(OUT/'Frozen_After.json').write_text(json.dumps(frozen_checks(),indent=2),encoding='utf-8');print(json.dumps(audit))
if __name__=='__main__':main()
