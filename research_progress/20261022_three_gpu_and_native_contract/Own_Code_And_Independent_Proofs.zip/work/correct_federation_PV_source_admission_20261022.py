"""Correct a device-intake error from saved roots; no physics or source import."""
import hashlib,json,pickle,sys
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'work'))
import candidate_process_runtime
sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
from reflection118_chronological_core_20261022 import read,put,sha
def main():
    O=R/'outputs/federation_PV_source_admission_correction_20261022';O.mkdir(exist_ok=False)
    old=R/'outputs/published_voltage_common118_design_20261022/Source_Contract_And_Execution_Decision.json'
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json');rows=[]
    import pandas as pd
    for r in roots:
        path=R/r['solved_payload'];assert sha(path)==r['payload_sha256']
        net=pickle.loads(path.read_bytes())['net'];pv=net.sgen.index[net.sgen.type.astype(str).str.lower()=='pv'].tolist();diesel=net.sgen.index[net.sgen.type.astype(str).str.lower()=='diesel'].tolist()
        assert len(pv)==len(diesel)==4
        rows.append({'case_id':r['case_id'],'root_sha256':r['payload_sha256'],'all_static_generators':len(net.sgen),'actual_PV_indices':[int(x) for x in pv],'diesel_indices':[int(x) for x in diesel],
            'PV_buses':[int(net.sgen.at[i,'bus']) for i in pv],
            'PV_present_sn_mva_ratings':[None if pd.isna(net.sgen.at[i,'sn_mva']) else float(net.sgen.at[i,'sn_mva']) for i in pv],
            'PV_explicit_pq_bound_columns_present':[k for k in ['min_p_mw','max_p_mw','min_q_mvar','max_q_mvar'] if k in net.sgen]})
    source=R/'outputs/published_voltage_source_intake_20261022/RWTH-IAEW__voltage-control-env/source/src/voltage_control_env/env_utils.py'
    text=source.read_text('utf-8');assert 'self.ctrl_sgen_indices = list(range(len(net.sgen)))' in text and 's_max = p_total_max * self.pv_converter_oversize' in text
    put(O/'Corrected_Source_Admission.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'status':'CORRECTION_OF_ERRONEOUS_NO_PV_STATEMENT_SAVED_ROOTS_ALL4_EXACT',
        'old_source_preserved':old.relative_to(R).as_posix(),'old_source_sha256':sha(old),'incorrect_old_claim':'The actual roots have no staticPVsgens. The field static_PV_sgens8 counted all sgens, not PV-only.',
        'corrected_finding':'Every registered severe root contains4PV and4diesel static generators. The source-native RRL environment may use existing PVs with explicit indices, but hardware/PQ ratings and scenario profiles are not yet specified; do not fabricate them.',
        'roots':rows,'author_source':source.relative_to(R).as_posix(),'author_source_sha256':sha(source),
        'source_behavior':'Defaultctrl_sgen_idx=None selects all8includingdiesels; explicitly pass the4PVindices to avoid changing diesel capability. Author initializer overwrites sn_mva using the supplied entire dataset max_p_mw times1.1. New hardware/data scope must be disclosed.',
        'remaining_comparison_gap':'PV P/Q actions differ from original positive25..300MVAr shunts; existing PVpresence does not make the old LoRA parser/weights or a foreignLVcheckpoint source-compatible. Preserve native/shared-actuation rows separately.',
        'new_PF_model_training_GPU_calls':0,'no_claim_of_trained_comparator_or_performance':True,'source_sha256':sha(__file__)})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'all4_roots':'4PV+4diesel each','false_PV_absence_claim':'CORRECTED_PRESERVED','new_science':0}))
if __name__=='__main__':main()
