# Experiment-backed revision sections

Working draft dated 7 October 2026. The original manuscript and published PowerGridQA paper are preserved. These sections address the four experimental concerns in the supplied reviewer-plan paraphrase. All planned reviewer experiments are complete; these are experiment-backed replacement sections, not a claim of reviewer acceptance or a rebuilt full manuscript.

## Methods: deterministic attribution control

HG-SE selects between independently simulated DFF and HG-VF terminal trajectories. To test whether the learned proposer adds value beyond one deterministic diversity mechanism, we define DFF-ALT before the final campaign. At iteration 1, DFF-ALT selects the second-ranked distinct physically accepted candidate under the original DFF candidate generation, gates, stable ranking, and tie order. If no distinct second candidate exists, it uses ordinary DFF and records the reason. Subsequent iterations use ordinary DFF from the altered state. D-SE applies the same frozen terminal selector to DFF and DFF-ALT. Both portfolios retain separate initial state copies and charge both simulated branches, including the discarded trajectory. Selected-path support and actions remain separate from planning cost.

The recovered terminal selector chooses fewer residual UV buses, then lower deficit with a 1e-12 comparison tolerance, then fewer accepted actions, retaining DFF on a final tie. The implementation uses a truthiness fallback of 1e99 for the deficit field, including an exact zero; this behavior is retained, rather than silently corrected. The new orchestration prevents missing/nonfinite terminal metrics from entering numerical pair selection and records invalid outcomes. Vmin and reactive-support magnitude are reported separately; they are not terminal-selector tiebreaks.

Original settings remain: 25 accepted-action iterations, nominal voltage range 0.95–1.05 p.u., hard upper threshold 1.06 p.u., incremental support cap 450 MVAr per bus, and one normalized shunt action per iteration. The deterministic sweep and prompt list contain nine Q values. The actual saved normalizer permits every 25-MVAr increment from 25 through 300, including 175, 225, and 275. This difference is disclosed as operative behavior, not fixed during the final evaluation. Strict UV/OV metrics remain unchanged; a separate 1e-8 diagnostic tolerance identifies floating-point boundary classifications.

## Methods: held-out bank and provenance

The locked bank contains 62 operating points: 31 outaged-line/DER patterns, each at load factors 1.30 and 1.40. All scenario, manifest, sanity-report, network, and metadata hashes match their original saved records. The bank is preserved, including two line-170 cases with an isolated bus and unserved load; it is not regenerated or filtered using final controller outcomes.

Saved grouped training inputs contain 16,000 training records covering 109 physical scenario IDs, with 2,000 validation records covering 13 IDs and 2,000 test records covering 15 IDs. The total 20,000 records are linguistic training/evaluation records derived from 137 physical scenarios, not 20,000 independent physical conditions. Canonical physical-modification comparisons found no identical locked case among the recovered 141 historical scenarios or saved train/validation/test splits. A second audit applied the original scenario code to separate copies of the frozen network and compared effective load P/Q, line status, and sgen P/Q; the 62 locked input states have zero exact overlap with the 141 distinct historical states or 137 split states, with no unknown modification silently skipped. Every locked case shares an outage/DER pattern with saved training. We therefore describe this as post-training held-out load operating points within a common network and contingency construction. The recovered files do not cryptographically establish the complete final adapter's training invocation; that lineage limitation remains explicit.

Thirteen completed pilot cases and an additional case-14 error record were observed previously. The new DFF-ALT rule was validated on historical cases and frozen before this campaign, but the full earlier prompt-edit history is unavailable. We report the pilot group, remaining 49 cases, and families without any recorded pilot exposure separately, without calling them automatically untouched or independent. The May execution dependency stack is restored; September pilot outputs are not reused as fresh matched results.

## Results: the completed matched campaign

All 62 cases and RNG checkpoints are preserved. Sixty pairs have finite terminal metrics; two line-170 cases are invalid because bus 116 is disconnected, leaving 26 or 28 MW of scheduled load unserved. All 60 valid initial states required UV correction. Invalid cases remain in the denominator and compute ledger.

| Method | Finite UV-clear cases / full 62-case bank | Total residual UV on 60 valid pairs |
|---|---:|---:|
| DFF | 59/62 | 1 |
| DFF-ALT | 59/62 | 2 |
| HG-VF | 38/62 | 61 |
| D-SE | 60/62 | 0 |
| HG-SE | 59/62 | 1 |

HG-SE and D-SE have equal residual UV in 59 valid pairs; D-SE has fewer residual UV buses in one, and HG-SE in none. HG-SE selects DFF in all 60 valid cases. D-SE selects DFF in 52 and DFF-ALT in eight. Under the full frozen selector, D-SE is preferred in eight pairs and the remaining 52 tie. All 60 valid DFF-ALT paths differ initially from DFF: 28 change only Q, 20 only bus, and 12 both.

For the primary HG-SE minus D-SE residual-UV difference, the mean is +0.0167 buses, with an outage-family percentile bootstrap 95% interval [0, 0.05] over 30 complete valid families. The family sign-flip Monte Carlo p-value is 1.0. These limited-bank analyses do not establish equivalence or a broad superiority claim. The statistical implementation was declared after 36 checkpoints were available; it is not described as a blinded preregistration. The independent paired-scenario bootstrap is a sensitivity analysis and gives the same interval. The observed pilot13 has 13 equal pairs; remaining49 contains 47 valid pairs, one D-SE advantage and 46 ties. After excluding families with completed or failed pilot exposure, 34 valid cases remain, with one D-SE advantage and 33 ties.

| Charged planning measure, all 62 cases | D-SE | HG-SE |
|---|---:|---:|
| Actual AC-PF attempts | 102,015 | 90,186 |
| AC-PF exceptions | 208 | 165 |
| Actual LLM calls | 0 | 5,023 |
| Input tokens | 0 | 4,376,962 |
| Output tokens | 0 | 99,200 |
| Sum of charged branch wall time, seconds | 9,294.42 | 13,523.87 |

HG-SE consumes fewer recorded PF calls but more wall time, and it provides no observed residual-UV gain over this specified deterministic portfolio. The support difference on valid pairs is -6.67 MVAr on average, with a family-bootstrap interval [-30.42, 22.92]; that does not establish a support advantage. The main campaign used fixed branch order and required a runtime restoration, so timing is an observed campaign result rather than a universal hardware-independent speed claim. Separate inference and PF durations were not recorded in that main run and cannot be reconstructed from total branch times.

## Methods and limits: central comparison

The prepared central extension retains the same zonally trained frozen adapter, numerical control loop, parser/normalizer, physical verifier, refinement, fallback, iteration limit, and generation allowance. It receives all 118 voltage observations, four zone summaries/membership lists, and the exact initial union of the zonal candidate pools. Four sequential global slots exclude buses proposed structurally validly in earlier slots of the same iteration; each slot permits at most one repair. Physical ownership is recorded separately from proposal-slot labels. Only feedback memory may be reduced to satisfy the 4096-token context plus 384-token generation reserve. Actual token cost, distinct proposal buses, parse failures, repair calls, inference time, PF time, and branch wall time are to be reported.

The four zones are balanced bus-index partitions of 30/30/30/28 buses in one IEEE-118 network. One shared model is queried sequentially with zone-specific contexts; accepted actions are serialized and verification uses the full network. This is not four separately trained models or decentralized numerical verification, and the partitions are not claimed electrically optimal.

Historical CPU checks pass at 2,524 and 2,790 input tokens before generation reservation. Historical GPU validation is required before protocol freezing and the locked campaign. Both standalone branches must be compared before their envelopes, because common DFF can mask proposer differences. Envelopes reuse and charge the same saved DFF; its previous-campaign time must remain separate from the current paired proposer times. The adapter's local-context training limits any inference about intrinsic centralized versus zonal superiority. **Central experimental evidence is complete; see the final evidence appendix below.**

## Methods and limits: AC reference and physical validity

The reference is a continuous local AC shunt endpoint optimization with the original voltage-dependent actuator. It fixes loads, active dispatch, generator/slack voltage settings, storage P/Q, topology, taps, and original shunts. It permits incremental nominal support between zero and 450 MVAr at every in-service bus and at most 7,500 MVAr total. These necessary endpoint restrictions relax dynamic candidate eligibility, the discrete action set, and the sequential 25-step progress gates. The formulation is a voltage-recovery reference, not an identical discrete controller or a certified AC-OPF optimum.

SLSQP uses two declared starts: zero support and the same-case frozen DFF endpoint. Its settings were validated on two historical cases before bank execution. All starts, failures, PF attempts, and timing remain recorded. Feasible raw endpoints undergo independent fresh AC-PF checks, including declared support-padding factors 1 and 1.0001, retaining original strict UV counts and a separately disclosed 1e-8 upper-bound diagnostic tolerance. A failed local search is not classified as physical infeasibility. Warm-start DFF work is charged once; its GPU time and the local optimizer's CPU time remain separate. **The full 62-case reference evidence is complete; see the final evidence appendix below.**

The first phase minimizes `10^4 × sum_b[max(0.95 - V_b, 0)^2 + max(V_b - 1.05, 0)^2] + 10^-9 × sum_b(q_b/450)`, subject to the support bounds and total budget. Voltages come from the original AC-PF solve with generator-Q-limit switching. If an independently feasible point is found, the second phase minimizes nominal support while imposing both voltage inequalities. Each phase is capped at 60 SLSQP iterations with scaled finite-difference step 0.001 and ftol 1e-9. This smooth voltage penalty is different from the controller's residual-count ordering; minimum support is a local search result, not a certified global optimum. Invalid PF evaluations receive a penalty and remain in the failure counters.

Independent replay covers all three branches in all 62 main cases and matches comparable continuous terminal metrics within 1e-10. Aggregation of all 1,794 initial and accepted-action replay states across 186 trajectories found zero strict violations of the 1.06-p.u. hard upper threshold, incremental-Q caps, declared thermal limits, or generator-Q limits. All 60 valid cases serve the scheduled load at every replay state; the two islanded cases retain their nonfinite/unserved flags. Every replay state violates a declared slack operating limit. Every case violates a declared slack operating limit. A necessary fixed-P balance proves why full declared-limit feasibility is impossible under the frozen resources: serving all scheduled load requires at least 1,601.1–2,030.3 MW of slack injection before nonnegative passive losses, while the declared ceiling is 805.2 MW. All four batteries remain at fixed zero P/Q. Capacitive shunts cannot close this active-power gap or reconnect bus 116. Thus zero residual UV is voltage recovery under the frozen slack convention, not fully operational restoration.

## Discussion and claim changes

The historical 137-case manuscript results remain a separate reported study and are not pooled with this locked-bank campaign. The new deterministic attribution control does not demonstrate a learned-proposer UV advantage in this scenario family. The architecture remains an auditable, physically checked proposal-and-selection workflow, with limited learned-proposer contribution in these observed outcomes. A future policy/security experiment may use that workflow as its fixed baseline, but no new cybersecurity result is asserted here. The completed secondary architecture and local optimization comparisons are reported in the evidence appendix below, with their conditional-model and relaxation limits.

Evidence: `matched_campaign_protocol.json`, `main_campaign_detailed_audit.json`, `matched_campaign_family_analysis.json`, `training_bank_physical_overlap.json`, `effective_operating_point_overlap.json`, `physical_replay_audit/overview.json`, `physical_trajectory_validity.json`, `physical_effort_ledger.csv`, and `fixed_p_feasibility_audit.json`. Design-source links and limits are recorded in `Experiment_Method_Justification.md`.

## Completed central and reference evidence appendix

The original saved full_restoration boolean denotes zero residual undervoltage. It does not establish the full 0.95–1.05 normal voltage band. The separate 1.06 hard ceiling and declared operating limits remain distinct checks.
Among 60 valid selected main endpoints, separately labelled 1e-8 diagnostics found both normal bands met in 1 D-SE and 0 HG-SE cases; soft upper-band exceedance occurred in 59 and 60 respectively. These diagnostics do not alter original strict success counts.

### Results: centralized versus zonal proposal contexts

Both standalone proposers were executed on the full locked bank with alternating order and the same frozen zonally trained adapter. The table includes all 62 cases and charges failed or invalid attempts. Finite UV-clear counts are voltage outcomes; the separate physical audit retains load-service and operating-limit flags.

| Measure | Zonal HG-VF | Central VF |
|---|---:|---:|
| Finite UV-clear cases / full bank | 38/62 | 58/62 |
| PF attempts | 38324 | 42611 |
| PF exceptions | 77 | 52 |
| LLM calls | 5023 | 4779 |
| LLM exceptions | 0 | 0 |
| Input tokens | 4376962 | 8694765 |
| Output tokens | 99200 | 113746 |
| Branch wall seconds | 8396.38 | 9742.41 |
| Measured PF seconds | 2659.51 | 2964.47 |
| CUDA-synchronized generation seconds | 5113.24 | 6045.96 |

Paired effect estimates use 30 complete valid outage families, with both load levels retained in each cluster. 2 invalid pairs remain in the full-bank ledger and are excluded only from numeric differences. Positive differences mean a larger central value. These are secondary architecture comparisons, not additional confirmatory superiority tests.

| Central minus zonal measure | Family mean | Family bootstrap 95% interval |
|---|---:|---|
| uv_count | -0.966667 | [-1.56667, -0.466667] |
| deficit_sum | -0.0180275 | [-0.0346899, -0.00465435] |
| accepted_actions | -3.03333 | [-4.36667, -1.68333] |
| nominal_support_mvar | -2.5 | [-109.167, 102.083] |
| wall_seconds | 19.5897 | [3.16191, 36.9284] |
| pf_attempts | 60.7333 | [-29.9025, 171.817] |
| llm_calls | -5.38333 | [-13.4004, 2.9] |
| input_tokens | 67642.6 | [56908.6, 79017.9] |
| output_tokens | 209.1 | [-22.8837, 435.422] |

The observed central proposer has fewer residual UV buses on average. The comparison is conditional on one adapter trained with local zone contexts, this network, and the locked bank. It does not establish intrinsic zoning superiority or performance of a separately trained central model.

Common-DFF envelopes are reported separately: zonal 59/62 and central 59/62 finite UV-clear outcomes. The same saved DFF computation is charged to each envelope; its prior-campaign time is kept separate from current proposer time. Standalone outcomes remain the architecture comparison because a common fallback can mask proposer differences.

Recorded context and proposal-diversity audits: `{"context_limit": 4096, "feedback_memory_reductions": 0, "generation_reserved": 384, "maximum_input_tokens": 3159, "physical_observation_truncations": 0, "recorded_primary_queries": 2948}`. Parsing, repair, distinct-bus counts, failures, and selected-envelope branches are available in the full summary and paired ledger.

### Results: conventional local AC shunt endpoint reference

All 62 original cases were processed. Independently checked voltage-only reference endpoints were found in 56/62 cases. Unsuccessful starts and invalid initial conditions remain recorded; absence of a local reference is not an infeasibility proof. The necessary fixed-P slack exclusion applies to 62/62 cases, so these are not fully operating-limit-feasible AC-OPF solutions.

| Controller | Available same-band reference pairs | Mean nominal controller minus reference support, MVAr | Controller lower / reference lower / equal |
|---|---:|---:|---|
| D-SE | 1 | 577.12 | 0 / 1 / 0 |
| HG-SE | 0 | not estimated | 0 / 0 / 0 |

These differences compare nominal support only where both endpoints satisfy the same finite-voltage, scheduled-load-service, strict-UV, and disclosed upper-band diagnostic checks. They are descriptive differences from a local continuous endpoint search, not optimality gaps. The relaxed continuous/all-bus endpoint may be unreachable under the discrete 25-action controller and its progress gates; a controller can also beat an unsuccessful local optimizer without proving global optimality. Realized voltage-dependent reactive injections remain separately reported.

All local reference computation, including failed cases and fresh endpoint probes: `{"local_pf_attempts": 426347, "local_pf_exceptions": 270, "local_pf_returns": 426077, "local_wall_seconds": 90389.4022861002}`. Warm-start DFF work is charged once in the case ledger. CPU solver times and the previous GPU DFF times are separate and do not establish a matched-hardware speedup.

The reference status ledger and paired availability list are retained in `ac_reference_controller_comparison_summary.json` and `ac_reference_controller_comparison.csv`; the complete architecture evidence is in `central_matched_summary.json`, `central_matched_paired_ledger.csv`, and the independent central physical replays. The primary main-bank HG-SE/D-SE conclusion remains unchanged by these secondary comparisons.
