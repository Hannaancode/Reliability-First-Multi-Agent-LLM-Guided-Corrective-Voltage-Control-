"""Additive packaging/control continuation, no scientific call repetition."""
import ast
from candidate_process_evidence_utils import ROOT,read
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
assert read(P/'cuda_zero_forward_failure_audit/Independent_Zero_Forward_Failure_Audit.json')['all_passed']
assert not (P/'cuda_integration_preparation_v3').exists() and not (P/'cuda_integration_execution_v3').exists()
remote=(ROOT/'work/relational_cuda_integration_remote.py').read_text()
remote=remote.replace("PREP=P/'cuda_integration_preparation_v2';OUT=P/'cuda_integration_science'", "PREP=P/'cuda_integration_preparation_v3';OUT=P/'cuda_integration_science_v3'")
(ROOT/'work/relational_cuda_integration_remote_v3.py').write_text(remote)
builder=(ROOT/'work/prepare_relational_cuda_integration.py').read_text()
builder=builder.replace("PREP=P/'cuda_integration_preparation_v2'", "PREP=P/'cuda_integration_preparation_v3'")
builder=builder.replace("(P/'cuda_integration_execution').exists()", "(P/'cuda_integration_execution_v3').exists()")
builder=builder.replace('relational_cuda_integration_remote.py','relational_cuda_integration_remote_v3.py')
builder=builder.replace('relational_cuda_environment_check.py','relational_cuda_environment_check_v3.py')
builder=builder.replace('relational_cuda_guardian.py','relational_cuda_guardian_v3.py')
builder=builder.replace('run_relational_cuda_integration_colab.py','run_relational_cuda_integration_colab_v3.py')
builder=builder.replace("/cuda_integration_preparation_v2'", "/cuda_integration_preparation_v3'")
builder=builder.replace("PREP=BASE/'cuda_integration_preparation_v2';OUT=BASE/'cuda_integration_execution'", "PREP=BASE/'cuda_integration_preparation_v3';OUT=BASE/'cuda_integration_execution_v3'")
builder=builder.replace('/cuda_integration_science', '/cuda_integration_science_v3')
point="for n in source_names+['run_relational_cuda_integration_colab_v3.py','verify_relational_cuda_package_cpu.py']:ast.parse((ROOT/'work'/n).read_text())"
assert point in builder
closure="""# Verify all direct and transitive local imports, including function-scope imports.
local={f.stem:f for f in (ROOT/'work').glob('*.py')};visited=set();queue=list(source_names)
while queue:
    n=queue.pop()
    if n in visited:continue
    visited.add(n);tree=ast.parse((ROOT/'work'/n).read_text())
    for node in ast.walk(tree):
        mods=([node.module.split('.')[0]] if isinstance(node,ast.ImportFrom) and node.module else
              [v.name.split('.')[0] for v in node.names] if isinstance(node,ast.Import) else [])
        for mod in mods:
            if mod in local and (mod+'.py') not in visited:queue.append(mod+'.py')
source_names=sorted(visited)
assert 'candidate_process_pretrained_loader.py' in source_names
write(PREP/'Verified_Local_Import_Closure.json',{'all_direct_function_scope_transitive_work_imports_bundled':True,'sources':source_names,'scientific_calls':0})
"""
builder=builder.replace(point,closure+'\n'+point)
builder=builder.replace("'study':'new relational internal residual versus matched frozen-head real CUDA engineering and cold-state restore'", "'study':'separate zero-forward packaging continuation: unchanged relational CUDA engineering and cold-state restore'")
for path,source in [('prepare_relational_cuda_integration_v3.py',builder),
 ('audit_relational_cuda_integration_v3.py',(ROOT/'work/audit_relational_cuda_integration.py').read_text()
  .replace("PREP=P/'cuda_integration_preparation_v2'", "PREP=P/'cuda_integration_preparation_v3'")
  .replace("E=P/'cuda_integration_execution'", "E=P/'cuda_integration_execution_v3'")
  .replace("OUT=P/'cuda_integration_external_audit'", "OUT=P/'cuda_integration_external_audit_v3'")
  .replace('run_relational_cuda_integration_colab.py','run_relational_cuda_integration_colab_v3.py')),
 ('continue_relational_cuda_audit_v3.py',(ROOT/'work/continue_relational_cuda_audit.py').read_text()
  .replace("E=P/'cuda_integration_execution'", "E=P/'cuda_integration_execution_v3'")
  .replace("OUT=P/'cuda_audit_continuation'", "OUT=P/'cuda_audit_continuation_v3'")
  .replace('run_relational_cuda_integration_colab.py','run_relational_cuda_integration_colab_v3.py')
  .replace("P/'cuda_integration_external_audit'", "P/'cuda_integration_external_audit_v3'")
  .replace('work/audit_relational_cuda_integration.py','work/audit_relational_cuda_integration_v3.py'))]:
    ast.parse(source);f=ROOT/'work'/path;assert not f.exists();f.write_text(source)
print('ADDITIVE_ZERO_FORWARD_IMPORT_CLOSURE_CONTINUATION_CREATED_NO_SCIENCE')
