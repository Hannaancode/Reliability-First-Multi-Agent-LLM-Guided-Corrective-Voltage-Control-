"""No labels/receipts: original positive LOCAL output only seeds full ordering."""
from joint_admissibility_order_v1 import KEYS,forecast_admissible,order_all_current_forecasts
Q=(25,50,75,100,125,150,200,250,300)
def order(rows,before,cursor,seed_actions,mode):
    assert mode in ('objective','admissibility')
    if any(set(r)!=KEYS for r in rows):raise ValueError('Never expose measured results to ordering')
    if any(set(a)!={'bus','q'} for a in seed_actions):raise ValueError('Seeds may contain only normalized current positive proposal')
    valid={int(a['bus']) for a in seed_actions if int(a['bus']) in cursor['raw_current_receiver_scope'] and float(a['q']) in Q and cursor['positive_addition_lifetime_MVAr'].get(str(int(a['bus'])),0)+float(a['q'])<=450}
    numeric=order_all_current_forecasts(rows,before,cursor) if mode=='admissibility' else sorted(rows,key=lambda r:(tuple(-x for x in r['ordering_forecast']['score']),r['universe_index']))
    rank={r['universe_index']:i for i,r in enumerate(numeric)}
    # The stronger control keeps its same admission class even under model seeds.
    result=sorted(numeric,key=lambda r:((not forecast_admissible(r,before,cursor)) if mode=='admissibility' else False,r['receiver'] not in valid,rank[r['universe_index']]))
    assert len(result)==len(rows) and {r['universe_index'] for r in result}=={r['universe_index'] for r in rows}
    return result,sorted(valid)
