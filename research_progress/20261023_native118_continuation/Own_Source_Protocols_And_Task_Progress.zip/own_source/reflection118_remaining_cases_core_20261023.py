"""Exact original language-policy execution with full commitment preservation."""
import argparse
from collections import defaultdict
from r118_dff_missing_continuation_core_20261023 import *

def case_paths():
    ap=argparse.ArgumentParser();ap.add_argument('--case-index',type=int,choices=[1,2,3],required=True)
    index=ap.parse_args().case_index;name=f'case_{index:02d}'
    return index,R/'outputs/reflection118_remaining_cases_preparation_20261023'/name,R/'outputs/reflection118_remaining_cases_execution_20261023'/name

def complete_dff_receipts():
    handoff=read(R/'outputs/r118_dff_missing_continuation_handoff_20261023/Completion.json')
    assert handoff['independent_audit_status'].startswith('PASS_')
    for directory in ['r118_dff_missing_continuation_coordination_20261023','r118_dff_missing_continuation_reader_coordination_20261023']:
        end=read(R/'outputs'/directory/'End_ACK.json');assert end['exit_code']==0 and end['actual_owned_chain_ended']
    value=read(E/'Result.json');rows=current_receipts()
    for name in value['call_records']:
        path=E/name;row=read(path)
        rows.append(dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),before=row['before'],after=row['after'],kwargs=row['kwargs'],exception=row['exception']))
    # Unclosed reservations also block entry, never disappear from history.
    covered={(x['directory']/x['before']['path']).resolve() for x in rows}
    for path in E.glob('*/call_*_before.zlib'):
        if path.resolve() in covered:continue
        raw=path.read_bytes();decoded=zlib.decompress(raw)
        desc=dict(path=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),decoded_bytes=len(decoded),decoded_sha256=hashlib.sha256(decoded).hexdigest())
        rows.append(dict(directory=path.parent,source=path.relative_to(R).as_posix(),source_sha256=sha(path),before=desc,after=None,kwargs=None,exception='UNCLOSED_OLD_RESERVATION_UNKNOWN'))
    return rows

class ClosedPaidRegistry(Registry):
    """Use a closed saved-input index; verify candidate capsules on lookup.

    The index is produced once after actual DFF closure, avoiding decoding
    every old NET separately on each allocated GPU's host startup. It contains
    no invented forecasts, scores, timing or scientific outcomes.
    """
    def __init__(self,index_path):
        from prior_physical_query_footprints_20261018 import component
        from run_reflection118_chronological_local_20261022 import necessary,History
        data=read(index_path);self.component,self.necessary=component,necessary
        self.items=defaultdict(list);self.decoded={};self.history=History();self.count=len(data['rows'])
        for item in data['rows']:
            row=dict(item);row['directory']=R/row['directory'];key=row.pop('resource_key');self.items[key].append(row)

def run_original(v2,runner,reflection,scenario,base,zones,model,physics,first_callback=None,commit_callback=None):
    import numpy as np,pandapower as pp
    target=reflection.run_one_scenario_two_best_v2
    oldpf,oldgen,oldtrace=pp.runpp,runner.base_runner.generate_response,sys.gettrace()
    first=None;seen=0
    def trace(frame,event,arg):
        nonlocal first,seen
        if frame.f_code is not target.__code__:return None
        if event=='line':
            loc=frame.f_locals;result=loc.get('result');n=len(result.get('executed_actions',[])) if result else 0
            if n>seen:
                assert n==seen+1;seen=n
                state=copy.deepcopy({k:loc[k] for k in ['net','result','failed_sigs','failed_actions','feedback_state','it'] if k in loc})
                state['python_rng']=random.getstate();state['numpy_rng']=np.random.get_state()
                if commit_callback:commit_callback(state)
                if n==1:
                    first=state
                    if first_callback:first_callback(state)
        return trace
    pp.runpp=physics;runner.base_runner.generate_response=lambda body,tokenizer,messages:model(messages)
    try:
        sys.settrace(trace)
        return target(scenario,base,zones,v2,object(),object(),'reflection_v2'),first
    finally:pp.runpp=oldpf;runner.base_runner.generate_response=oldgen;sys.settrace(oldtrace)
