"""Closed OPT receipt/timing inventory; no model, simulator or forecast calls."""
import ast
import gzip
import hashlib
import json
import math
import os
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks

R = ROOT / 'outputs/critical_research_reset_20261010'
D = ROOT / 'outputs/llm_value_next_method_research_20261008/guarded_train_trajectory_measurement_native_v3'
B = ROOT / 'outputs/llm_value_candidate_development_20261009'
T = ROOT / 'outputs/llm_value_relational_adaptation_research_20261009/measured_OPT_transition_inventory'
OUT = R / 'actual_query_and_continuation_receipt_inventory_v2'
assert not OUT.exists(), 'One bounded inventory; retain a failed claim rather than restart'
OUT.mkdir()
write(OUT / 'owner.claim', {'actual_pid': os.getpid(), 'source_sha256': sha(Path(__file__))})
start = time.perf_counter()
canonical = lambda x: json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False)
digest = lambda x: hashlib.sha256(canonical(x).encode()).hexdigest()
partition = read(B / 'input_and_target_contract_nullable_v2/protocol.json')
opt = set(partition['optimization_world_sha256']); held = set(partition['development_held_world_sha256'])
raw_protocol = read(D / 'protocol.json'); raw_manifest = read(D / 'manifest.json')
worlds = raw_protocol['worlds']
assert len(worlds) == 31 and {w['sha256'] for w in worlds} == opt | held
sources = [D / 'protocol.json', D / 'manifest.json', D / 'summary.json', T / 'Protocol.json',
           T / 'Actual_OPT_Transition_Rows.jsonl.gz', T / 'Closed_Manifest.json',
           ROOT / 'work/run_guarded_train_trajectory_measurement_native_v3.py',
           ROOT / 'work/train_trajectory_measurement_nullable_v2.py', ROOT / 'work/value_observe_original_DFF.py',
           Path(__file__)]
declaration = {
    'declared_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'All31 world/62 branch identities retained; new receipt/outcome coverage only in23 OPT worlds/46 branches. Held identities and previously paid collection costs retained without new held outcome metrics.',
    'questions': ['Which ordered candidate receipts and actual prior failed signatures exist?',
                  'Which action-linked committed successor snapshots exist?',
                  'Which timing levels were actually recorded?',
                  'Can existing evidence establish acquisition latency or unobserved continuation rewards?'],
    'missing_unexecuted_or_unmeasured_is_unknown': True,
    'no_adaptive_policy_simulation_or_budget_sweep': True,
    'analysis_bound_seconds': 300,
    'observer_source_depth': 'Collector and TrainingObserver match historical protocol hashes. FullBranchObserver current helper hash is recorded for inspection; this parent protocol has no separate historical hash for it. Timing coverage conclusions use the actual saved receipt schemas.',
    'source_sha256': {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in sources},
    'no_new_model_PF_optimizer_controller_forecast_derivative_solve_cloud_calls': True,
}
write(OUT / 'Prospective_Receipt_Inventory.json', declaration)
assert sha(D / 'manifest.json') == partition['parent_scientific_manifest_sha256']
for p in (sources[0], sources[2]):
    assert sha(p) == raw_manifest[p.name]['sha256'] and p.stat().st_size == raw_manifest[p.name]['bytes']
for p in sources[6:8]:
    name = str(p.relative_to(ROOT)).replace('\\', '/')
    expected = {k.replace('\\', '/'): v for k, v in raw_protocol['frozen_source_sha256'].items()}
    assert name in expected and sha(p) == expected[name]
transition_manifest = read(T / 'Closed_Manifest.json')
# The inventory already independently latched these raw branch hashes.
transition_protocol = read(T / 'Protocol.json')
source_branch_hashes = {k.replace('\\', '/'): v for k, v in transition_protocol['source_branch_hashes'].items()}
transition_rows_path = T / 'Actual_OPT_Transition_Rows.jsonl.gz'
assert sha(transition_rows_path) == transition_manifest['Actual_OPT_Transition_Rows.jsonl.gz']['sha256']

def stream(p):
    with gzip.open(p, 'rt', encoding='utf8') as f:
        for line in f:
            yield json.loads(line)

ts = list(stream(transition_rows_path))
assert len(ts) == 216 and len({r['transition_id'] for r in ts}) == 216
transition_by_action = defaultdict(list)
for r in ts:
    a = r['model_input']['candidate_action']
    pair = (a['bus'], a['q_abs_mvar'])
    transition_by_action[(r['before_observation_sha256'], pair)].append(r)
    frame = r['measured_target']['next_res_bus']
    assert len(frame['index']) == 118 and set(frame['index']) == set(range(118))
    assert 'vm_pu' in frame['columns'] and 'va_degree' in frame['columns']

branches, search_records, successor_records = [], [], []
counts = Counter(); counters_all = defaultdict(lambda: Counter())
cost_seconds_all = defaultdict(float)
candidate_schema, verif_schema, journal_schema = set(), set(), set()
query_keys = set(); observed_edges = set(); before_actions = defaultdict(set())
for w in worlds:
    for arm in ('DFF', 'DFF-ALT'):
        assert time.perf_counter() - start < declaration['analysis_bound_seconds']
        name = 'branches/' + w['scenario_id'] + '__' + arm + '.json'
        p = D / name
        assert sha(p) == raw_manifest[name]['sha256']
        r = read(p)
        assert r['scenario_sha256'] == w['sha256'] and r['branch'] == arm
        assert r['protocol_sha256'] == sha(D / 'protocol.json')
        # Cost inventory is NOT a newly chosen held outcome comparison.
        for phase, c in r['new_actual_costs'].items():
            for key in ('attempts', 'returns', 'exceptions'):
                counters_all[phase][key] += c[key]
            cost_seconds_all[phase] += c['solver_seconds']
        entry = {'world_sha256': w['sha256'], 'branch': arm, 'source_sha256': sha(p),
                 'source_role': r['source_role'], 'status': r['status'],
                 'split': 'optimization' if w['sha256'] in opt else 'development_held',
                 'new_actual_costs_already_paid': r['new_actual_costs'],
                 'prior_controller_costs_separately_paid': r.get('original_controller_costs'),
                 'new_held_receipt_outcome_metrics': False}
        if w['sha256'] in held:
            branches.append(entry)
            continue
        assert source_branch_hashes[str(p.relative_to(ROOT)).replace('\\', '/')] == sha(p)
        observations = r['observations']
        assert r['independent_all_field_replay_passed_1e10'] and r['base_network_preserved']
        for o in observations:
            assert digest(o['input_observation']) == o['observation_sha256']
        measured = r['measured_decisions']
        entry.update(OPT_recorded_prefix_observations=len(observations),
                     OPT_search_ledgers=None if measured is None else len(measured),
                     OPT_per_candidate_time_fields_present=False)
        counts['OPT_branches'] += 1
        counts['OPT_prefix_observation_occurrences'] += len(observations)
        if measured is None:
            counts['OPT_branches_original_search_ledger_missing'] += 1
        else:
            counts['OPT_branches_with_ordered_search_ledger'] += 1
            for decision in measured:
                assert set(decision) == {'decision', 'observation_sha256', 'failed_signatures_before', 'candidates', 'original_scores'}
                assert len(decision['original_scores']) == len(decision['candidates'])
                counts['OPT_search_context_occurrences'] += 1
                counts['OPT_contexts_with_nonempty_failed_signature_history'] += int(bool(decision['failed_signatures_before']))
                by_index = []
                for i, candidate in enumerate(decision['candidates']):
                    candidate_schema.update(candidate); verif_schema.update(candidate['verif'])
                    assert set(candidate) == {'source', 'zone', 'action', 'bus', 'q_abs', 'verif', 'raw'}
                    action = candidate['action']['add_shunts_q_mvar']; assert len(action) == 1
                    b, q = next(iter(action.items())); pair = (int(b), float(q))
                    identity = (decision['observation_sha256'], pair)
                    counts['OPT_candidate_receipt_occurrences'] += 1
                    query_keys.add(identity)
                    by_index.append({'ordinal': i, 'bus': pair[0], 'q_MVAr': pair[1],
                                     'saved_receipt_sha256': digest(candidate['verif']),
                                     'actual_per_query_attempts_seconds_timestamps': None,
                                     'actual_committed_successor_transition_ids': [t['transition_id'] for t in transition_by_action.get(identity, [])]})
                search_records.append({'world_sha256': w['sha256'], 'branch': arm,
                    'decision': decision['decision'], 'observation_id': decision['observation_sha256'],
                    'failed_signatures_before': decision['failed_signatures_before'],
                    'ordered_actual_candidate_receipts': by_index,
                    'past_receipt_prefix_can_be_reconstructed_in_source_order_not_timed': True,
                    'unseen_receipt_not_an_online_input_or_free_query': True})
        # Verify actual action-linked successors, without matching global metrics to invent an edge.
        for before, after in zip(observations, observations[1:]):
            action = after['committed_action']; assert action is not None
            b, q = next(iter(action['add_shunts_q_mvar'].items())); pair = (int(b), float(q))
            key = (before['observation_sha256'], pair)
            observed_edges.add(key); before_actions[before['observation_sha256']].add(pair)
            matches = transition_by_action.get(key, [])
            assert len(matches) == 1
            t = matches[0]
            assert t['after_observation_sha256'] == after['observation_sha256']
            assert canonical(t['measured_target']['next_res_bus']) == canonical(after['input_observation']['physical_tables']['res_bus'])
            successor_records.append({'world_sha256': w['sha256'], 'branch': arm,
                'before_observation_id': key[0], 'action': list(pair),
                'after_observation_id': after['observation_sha256'], 'transition_id': t['transition_id'],
                'full_saved_successor_observation_present': True,
                'past_teacher_committed_edge_only': True,
                'uncommitted_candidate_successor_or_terminal_return_inferred': False})
        journal = D / ('journals/' + w['scenario_id'] + '__' + arm + '.jsonl')
        assert sha(journal) == raw_manifest[str(journal.relative_to(D)).replace('\\', '/')]['sha256']
        events = [json.loads(line) for line in journal.read_text(encoding='utf8').splitlines()]
        assert len(events) == r['journal_events']
        for n, event in enumerate(events, 1):
            assert event['event_index'] == n and event['scenario_sha256'] == w['sha256'] and event['branch'] == arm
            journal_schema.update(event)
        branches.append(entry)

assert len(branches) == 62 and counts['OPT_branches'] == 46
assert len(successor_records) == len(observed_edges) == len(ts) == 216
assert journal_schema == {'event_index', 'event', 'scenario_sha256', 'branch', 'protocol_sha256', 'payload'}
summary_raw = read(D / 'summary.json')
for phase, c in summary_raw['actual_new_PF_costs_by_phase'].items():
    assert dict(counters_all[phase]) == {k: c[k] for k in ('attempts', 'returns', 'exceptions')}
    assert abs(cost_seconds_all[phase] - c['solver_seconds']) < 1e-8
known_receipts_with_successor = len(query_keys & observed_edges)
controller_cost = summary_raw['actual_new_PF_costs_by_phase']['new_common_guard_controller']
schema = {'candidate_record_keys': sorted(candidate_schema), 'verifier_record_keys': sorted(verif_schema),
          'journal_record_keys': sorted(journal_schema),
          'recorded_time_levels': ['controller/PF aggregate by branch and phase', 'branch measurement wall', 'observation capture wall'],
          'not_recorded': ['per-candidate verify_action latency', 'per-candidate runpp count or timestamp',
                           'timestamped search prefix history', 'full successors for never-committed alternatives',
                           'terminal episode outcomes following never-committed alternatives'],
          'cannot_allocate_aggregate_seconds_uniformly_and_call_it_measurement': True}
write(OUT / 'Actual_Receipt_And_Timing_Schemas.json', schema)
write(OUT / 'All62_Branch_Identity_And_Paid_Cost_Records.json', branches)
write(OUT / 'All_OPT_Ordered_Query_Receipt_Contexts.json', search_records)
write(OUT / 'All216_Actual_Action_Linked_Successor_Records.json', successor_records)
summary = {'completed_at_utc': datetime.now(timezone.utc).isoformat(), 'all_source_identity_prefix_action_next_vector_cost_checks_passed': True,
    'counts': dict(counts), 'unique_OPT_measured_state_action_receipts': len(query_keys),
    'unique_actual_committed_successor_edges': len(observed_edges),
    'recorded_query_receipts_with_exact_committed_successor': known_receipts_with_successor,
    'recorded_query_receipts_without_measured_successor': len(query_keys - observed_edges),
    'before_states_with_multiple_actual_committed_actions': sum(len(v) > 1 for v in before_actions.values()),
    'actual_per_candidate_timing_receipts': 0,
    'all_prior_guarded_controller_PF_cost': controller_cost,
    'aggregate_recorded_runpp_seconds_per_attempt': controller_cost['solver_seconds'] / controller_cost['attempts'],
    'aggregate_average_NOT_per_query_latency_or_deployed_acquisition_break_even': True,
    'raw_held_outcomes_not_newly_analysed': True, 'all31_worlds_original_invalid_and_missing_ledger_denominators_retained': True,
    'new_model_optimizer_PF_controller_forecast_derivative_solve_cloud_calls': 0,
    'elapsed_inventory_seconds': time.perf_counter() - start,
    'decision': 'Ordered receipt-count offline diagnostics are possible on recorded OPT support. Accurate per-query latency and arbitrary-action horizon rewards are not established. Freeze any different query mechanism and prospective timing/physical protocol before new science; no automatic model training.'}
write(OUT / 'summary.json', summary)
write(OUT / 'Fresh_Local_Frozen_Asset_Checks.json', frozen_checks())
files = {p.name: p for p in OUT.iterdir() if p.is_file()}; files['source/Inventory.py'] = Path(__file__)
print(json.dumps({'summary': summary, 'archive': seal(OUT, files, 'Actual_Query_And_Continuation_Receipt_Inventory.zip')}, indent=2))
