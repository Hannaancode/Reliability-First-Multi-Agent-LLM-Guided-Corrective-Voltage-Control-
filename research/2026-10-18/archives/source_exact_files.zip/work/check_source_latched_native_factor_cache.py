"""Labelled fabricated numerical fixtures, not experimental performance."""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import json,time
from datetime import datetime,timezone
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandapower as pp
from scipy.sparse import csr_matrix
from pandapower.pypower.dSbus_dV import dSbus_dV
import source_latched_affine_control as literal
from source_latched_native_factor_cache import CurrentFactorCache,action_context
from candidate_process_evidence_utils import ROOT,read,sha,write,seal
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';OUT=P/'native_factor_cache_software_readiness'
assert not OUT.exists();OUT.mkdir();start=time.perf_counter()
protocol={'declared_at_utc':datetime.now(timezone.utc).isoformat(),'fixture_only':True,
 'cases':'Fabricated connected118-node ring with53 generator constraints; fixed bus/Q/mask cases, both derivative variants',
 'not_measured_grid_or_model_performance':True,'new_actual_PF_model_optimizer_cloud_calls':0,
 'module_sha256':sha(ROOT/'work/source_latched_native_factor_cache.py'),'checker_sha256':sha(Path(__file__)),
 'literal_source_sha256':sha(Path(literal.__file__)),
 'criteria':'Exact current-only input/mask scope, derivative rank-one equations, LU reference agreement1e-10, residual1e-8, simultaneous strict bound checks, singular update rejection/no fallback',
 'fixed_actions':[[0,25.],[1,25.],[54,25.],[54,300.],[117,50.],[54,0.]],'fixed_masks':['all_interior','two_fixed_bounds']}
write(OUT/'Protocol.json',protocol);write(OUT/'owner.claim',{'pid':os.getpid()})
Y=np.zeros((118,118),complex)
for k in range(118):
 j=(k+1)%118;y=.1-10j;Y[k,k]+=y;Y[j,j]+=y;Y[k,j]-=y;Y[j,k]-=y
V=np.ones(118,complex);mapping=np.arange(118);refs=np.array([0]);base=100.
m,a=dSbus_dV(csr_matrix(Y),V)
features={i:{'bus':i+1,'position':i+1,'q0':0.,'lo':-500.,'hi':500.,'command':1.} for i in range(53)}
current={'Y':Y,'newY':Y.copy(),'V':V,'mapping':mapping,'refs':refs,'base':base,'gen':features,
         'm':m.toarray(),'a':a.toarray(),'Sdelta':np.zeros(118,complex)}
cache=CurrentFactorCache(current);proof=[];direct_solves=0;derivatives=1;maxdiff=0.;maxres=0.
with patch.object(pp,'runpp',side_effect=AssertionError('No genuine PF')),patch('pandapower.powerflow._powerflow',side_effect=AssertionError('No genuine PF')):
 for mode in protocol['fixed_masks']:
  mask={i:'interior' for i in features}
  if mode=='two_fixed_bounds':mask[0]='near_max';mask[52]='near_min'
  for bus,q in protocol['fixed_actions']:
   for candidate in (False,True):
    s=action_context(current,{'bus':bus,'q_abs_mvar':q},candidate)
    am,aa=dSbus_dV(csr_matrix(s['newY'] if candidate else Y),V);derivatives+=1
    assert np.max(np.abs(s['m']-am.toarray()))<=1e-10 and np.max(np.abs(s['a']-aa.toarray()))<=1e-10
    f=cache.solve(s,mask);reference=np.linalg.solve(f['J'],f['rhs']);direct_solves+=1
    diff=float(np.max(np.abs(f['x']-reference)));assert diff<=1e-10
    maxdiff=max(maxdiff,diff);maxres=max(maxres,f['equation_residual'])
    updates=literal.new_limits(mask,f['qgen'],features)
    expected={i:('near_max' if f['qgen'][i]>g['hi'] else 'near_min') for i,g in features.items() if mask[i]=='interior' and (f['qgen'][i]>g['hi'] or f['qgen'][i]<g['lo'])}
    assert updates==expected
    proof.append({'mask':mode,'bus':bus,'q_MVAr':q,'candidate_derivative':candidate,'reference_difference':diff,'residual':f['equation_residual'],'updates':updates})
 # A mathematically singular updated system must remain UNKNOWN. Select its
 # pole analytically on the fabricated current system, never from outcomes.
 mask={i:'interior' for i in features};key,e=cache._factor(mask);position=len(e['nonref'])+int(np.flatnonzero(e['free']==54)[0])
 unit=np.zeros(len(e['J0']));unit[position]=1.;z=cache._solve(e['factor'],unit)
 pole_q=base/(2*z[position]);assert pole_q>0
 try:cache.solve(action_context(current,{'bus':54,'q_abs_mvar':float(pole_q)},True),mask)
 except ArithmeticError:singular_rejected=True
 else:raise AssertionError('Singular fixture was not rejected')
 # Invalid action and injected non-current field cannot bypass the schema.
 try:action_context(current,{'bus':54,'q_abs_mvar':25.,'AFTER':{}},True)
 except AssertionError:leaked_label_rejected=True
 else:raise AssertionError('Label-bearing action accepted')
report={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'all_software_checks_passed':True,
 'fabricated_equation_fixture_cases':len(proof),'fixture_reference_dense_solves':direct_solves,'fixture_derivative_evaluations':derivatives,
 'actual_fixture_cache_costs':cache.costs,'singular_no_fallback_passed':singular_rejected,'label_field_rejection_passed':leaked_label_rejected,
 'max_reference_solution_difference':maxdiff,'max_equation_residual':maxres,'actual_fixture_workflow_seconds':time.perf_counter()-start,
 'real_pretrained_physical_or_action_ranking_performance_calls':0,'no_ready_full_native_performance_runner_or_reader_inferred':True}
write(OUT/'Actual_Fabricated_Equation_Checks.json',proof);write(OUT/'Software_Readiness.json',report)
files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='owner.claim'}
files['source/module.py']=ROOT/'work/source_latched_native_factor_cache.py';files['source/checker.py']=Path(__file__)
archive=seal(OUT,files,'Native_Affine_Factor_Cache_Software_Readiness.zip')
write(OUT/'status.json',{'stage':'complete_labelled_software_readiness','all_passed':True})
print(json.dumps({'readiness':report,'archive':archive}))
