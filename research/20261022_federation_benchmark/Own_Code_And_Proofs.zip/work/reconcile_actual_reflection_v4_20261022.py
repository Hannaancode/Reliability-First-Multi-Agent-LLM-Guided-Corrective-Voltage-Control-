"""Read-only source/record reconciliation. Never imports the original controller.

Historical summaries are not a new physical audit or a reconstructed 137-case run.
"""
import ast
import csv
import hashlib
import io
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/reflection_v4_federation_reconciliation_20261022'


def digest(b):
    return hashlib.sha256(b).hexdigest()


def put(name, value):
    with (O / name).open('x', encoding='utf-8', newline='') as f:
        if name.endswith('.json'):
            json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        else:
            f.write(value)
        f.flush()
        os.fsync(f.fileno())


def readcsv(p):
    return list(csv.DictReader(io.StringIO(p.read_text(encoding='utf-8-sig'))))


def num(row, key):
    return float(row[key])


def main():
    O.mkdir(exist_ok=False)
    script = R / 'work/e/audit/run_reflection_v4_safety_envelope.py'
    raw = script.read_bytes()
    assert raw == (R / 'work/e/v4/run_reflection_v4_safety_envelope.py').read_bytes()
    tree = ast.parse(raw.decode('utf-8'))
    selector = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'choose_safety_envelope')
    # Only this scalar selector is executed. No imports or main/runner statements.
    ns = {}
    exec(compile(ast.Module(body=[selector], type_ignores=[]), str(script), 'exec'), ns)
    choose = ns['choose_safety_envelope']
    master = R / 'work/e/handoff/reflection_v4_master_completed_cases.csv'
    selected = readcsv(master)
    assert len(selected) == len({r['scenario_id'] for r in selected}) == 67
    protocol = json.loads((R / 'outputs/matched_campaign_protocol.json').read_text(encoding='utf-8'))
    for p, h in protocol['source_sha256'].items():
        assert digest((R / p).read_bytes()) == h
    cases = []
    files = []
    branch_totals = {k: {'final_uv': 0, 'zero_uv_cases': 0, 'accepted_actions': 0,
                        'guided_tests': 0, 'fallback_tests': 0, 'llm_direct_tests': 0}
                     for k in ['no_llm_fallback_first', 'reflection_v2', 'selected_v4']}
    for row in selected:
        sid = row['scenario_id']
        path = R / 'work/e/handoff/branch_results' / (sid + '__branches.csv')
        rows = readcsv(path)
        assert len(rows) == 2 and {r['method'] for r in rows} == {'no_llm_fallback_first', 'reflection_v2'}
        d = {r['method']: r for r in rows}
        assert all(r['scenario_id'] == sid for r in rows)
        assert len({num(r, 'base_uv') for r in rows + [row]}) == 1
        # Preserve the literal selector's zero/missing semantics by converting
        # the CSV numeric fields before calling the unchanged function AST.
        scalar = {k: {**v, **{f: num(v, f) for f in ['final_uv', 'final_deficit', 'accepted_actions']}}
                  for k, v in d.items()}
        pick = choose(scalar['no_llm_fallback_first'], scalar['reflection_v2'])
        assert pick == row['selected_branch']
        chosen = d[pick]
        for field in ['final_uv', 'final_vmin', 'final_deficit', 'accepted_actions',
                      'llm_direct', 'llm_guided', 'fallback', 'guided_tests', 'fallback_tests', 'llm_direct_tests']:
            assert num(row, field) == num(chosen, field), (sid, field)
        assert num(row, 'fresh_no_llm_branch_final_uv') == num(d['no_llm_fallback_first'], 'final_uv')
        assert num(row, 'reflection_v2_branch_final_uv') == num(d['reflection_v2'], 'final_uv')
        for key, rec in [*d.items(), ('selected_v4', row)]:
            for f in branch_totals[key]:
                branch_totals[key][f] += int(num(rec, 'final_uv') == 0) if f == 'zero_uv_cases' else int(num(rec, f))
        cases.append({'scenario_id': sid, 'initial_UV': int(num(row, 'base_uv')),
                      'DFF_UV': int(num(d['no_llm_fallback_first'], 'final_uv')),
                      'HG_VF_UV': int(num(d['reflection_v2'], 'final_uv')),
                      'actual_v4_selected_UV': int(num(row, 'final_uv')),
                      'selected_branch': pick,
                      'two_branch_candidate_tests': sum(int(num(r, f)) for r in rows
                                                       for f in ['guided_tests', 'fallback_tests', 'llm_direct_tests']),
                      'summaries_only_not_new_independent_physical_replay': True})
        files.append({'path': str(path.relative_to(R)), 'bytes': path.stat().st_size,
                      'sha256': digest(path.read_bytes())})
    assert branch_totals['no_llm_fallback_first']['final_uv'] == 32
    assert branch_totals['reflection_v2']['final_uv'] == 29
    assert branch_totals['selected_v4']['final_uv'] == 19
    state = json.loads((R / 'work/e/handoff/reflection_v4_run_state.json').read_text())
    assert state['completed_cases'] == 67 and state['expected_total_cases'] == 137 and state['remaining_cases'] == 70
    # Read only the three small historical v4 CSV members, not the archive's
    # whole member CRC/hash inventory or any executable/model payload.
    bundle = R / 'work/e/v4/today_experiment_bundle_20260603_182357.zip'
    severe, severe_branches, member_receipts = [], [], []
    with zipfile.ZipFile(bundle) as z:
        for suffix in ['reflection_v4_safety_envelope_per_scenario_results.csv', 'reflection_v4_candidate_branches.csv']:
            names = [n for n in z.namelist() if '/reflection_v4_safety_envelope/' in n and n.endswith('/' + suffix)]
            assert len(names) == 1
            b = z.read(names[0])
            records = list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
            if 'per_scenario' in suffix:
                severe = records
            else:
                severe_branches = records
            member_receipts.append({'archive': str(bundle.relative_to(R)), 'member': names[0],
                                    'bytes': len(b), 'sha256': digest(b), 'CRC': z.getinfo(names[0]).CRC})
    assert len(severe) == 5 and len(severe_branches) == 10
    assert sum(num(r, 'final_uv') for r in severe) == 27
    assert sum(num(r, 'fresh_no_llm_branch_final_uv') for r in severe) == 40
    # Distinguish the full manuscript population from these smaller artifacts.
    paper = json.loads((R / 'outputs/full_system_comparison_20261021/Provided_Paper_Primary_Cohort_Correction.json').read_text())
    assert paper['primary_reported_cohort'] == 137
    assert [paper['reported_table9'][k]['final_UV'] for k in ['DFF', 'HG_VF', 'HG_SE']] == [290, 291, 193]
    cohorts = [
        {'cohort': 'Supplied primary manuscript, all137', 'initial_UV': 2715,
         'DFF_UV': 290, 'HG_VF_UV': 291, 'HG_SE_UV': 193, 'zero_UV': [108, 103, 110],
         'evidence_level': 'REPORTED_TABLE9_VISUALLY_VERIFIED; complete new raw137 join UNKNOWN'},
        {'cohort': 'Saved v4 checkpoint prefix, all67 completed', 'initial_UV': sum(r['initial_UV'] for r in cases),
         'DFF_UV': 32, 'HG_VF_UV': 29, 'HG_SE_UV': 19, 'zero_UV': [branch_totals[k]['zero_uv_cases'] for k in branch_totals],
         'evidence_level': 'SOURCE_SELECTOR_AND_BOTH_BRANCH_SUMMARIES_CHECKED; remaining70 UNKNOWN'},
        {'cohort': 'Earlier predefined five severe failures', 'initial_UV': sum(int(num(r, 'base_uv')) for r in severe),
         'DFF_UV': 40, 'HG_VF_UV': 36, 'HG_SE_UV': 27, 'zero_UV': [0, 1, 1],
         'evidence_level': 'SAVED_HISTORICAL_CSV; not a new representative sample'},
        {'cohort': 'Older paper complete-metric61', 'initial_UV': 945, 'Phase2G_UV': 28,
         'v2b_UV': 267, 'v2R_UV': 107, 'router_UV': 99,
         'evidence_level': 'OLDER_MANUSCRIPT_DISTINCT_COHORT_AND_CONTROLLER_LABELS; not a smaller full137 result'}]
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_SAVED67_LITERAL_V4_SELECTION_AND_BRANCH_SUMMARY_RECONCILIATION',
              'source': str(script.relative_to(R)), 'source_sha256': digest(raw),
              'both_source_copies_byte_identical': True,
              'selector_AST_sha256': digest(ast.dump(selector, include_attributes=False).encode()),
              'original_model': 'shared trained Qwen2.5-0.5B ultra-v1 LoRA; no new model called',
              'actual_v4_definition': 'Complete DFF plus reflection_v2 LLM-guided branch; unchanged end-trajectory selector',
              'all67_both_branch_and_selected_summaries_match': True,
              'all67_initial_UV': sum(r['initial_UV'] for r in cases), 'branch_totals': branch_totals,
              'wins_ties_losses_vs_DFF': [sum(r['actual_v4_selected_UV'] < r['DFF_UV'] for r in cases),
                                          sum(r['actual_v4_selected_UV'] == r['DFF_UV'] for r in cases),
                                          sum(r['actual_v4_selected_UV'] > r['DFF_UV'] for r in cases)],
              'known67_total_both_branch_candidate_tests': sum(r['two_branch_candidate_tests'] for r in cases),
              'selected_test_count_is_not_full_compute_cost': True,
              'remaining70_of137': 'UNKNOWN_NOT_FILLED_OR_RERUN',
              'full137_raw_controller_trajectory_weight_root_cost_join': 'NOT_RECOVERED_IN_INSPECTED_LOCAL_SOURCES',
              '193_is_best_in_supplied_final137_table': True,
              '193_is_global_best_of_all_historical_experiments': 'NOT_ESTABLISHED',
              'no_cross_cohort_best_selection': True, 'cohort_table': cohorts,
              'native_verifier': 'hardOV1.06, softOV1.05 metrics; zeroUV alone is not normal-band compliance',
              'source_files_and_receipts': files, 'historical_severe_member_receipts': member_receipts,
              'original_sources_and_frozen_gates_unchanged': True,
              'new_model_PF_training_optimizer_derivative_forecast_solve_or_GPU_calls': 0,
              'all6goals': 'OPEN'}
    put('Reconciliation.json', result)
    put('All67_Joined_Branch_Summary_Results.json', cases)
    put('Distinct_Cohorts_Not_Rankable_Across_Denominators.json', cohorts)
    put('Results_And_Exact_Next_Step.md', '''# Actual Reflection-v4 and paper result recheck

The supplied final paper reports DFF290, HG-VF291 and HG-SE193 residual UV on137 cases, with108/103/110 zero-UV cases.193 is the best of those three rows. It is not evidence that no later method ever did better. Earlier28/61,19/67 and27/5 results concern different populations and cannot replace193/137.

The actual Reflection-v4 source was recovered and the two local copies are byte-identical. Its unchanged selector was checked against all67 saved completed case records and both134 branch summaries. The checkpoint prefix has1,034 initial UV, DFF32, HG-VF29 and selected19; three strict UV wins,64 ties, no UV losses. It is partial:70 of the intended137 cases are absent. These are historical summary checks, not fresh physical replay or new LLM inference.

Reflection-v4 is the trained shared0.5B local-proposal system plus physics verification/refinement/fallback/memory and complete two-branch selection. It is not the new public13 numerical router. Native hard-overvoltage protection1.06 is distinct from full0.95–1.05 normal-band safety. Both branch costs are retained; selected-row test counts are not total computation.

Next: bind federation methods to identical solved physical roots, native shunt units/stock/bus masks, information and25-operation budgets. Reuse exact paid historical evidence. Missing raw137 trajectories stayUNKNOWN; do not regenerate them to replace missing provenance. Published13-bus actor weights and radial118 feeder policies cannot be called unchanged pretrained controllers on this transmission federation. A named common-role adaptation with authentic source/training and independent physical validation is needed before benchmarking.
''')
    put('Closed_Manifest.json', {'source_sha256': digest(Path(__file__).read_bytes()),
                               'files': [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
                                         for p in sorted(O.iterdir())],
                               'new_scientific_calls': 0})
    print(json.dumps({k: result[k] for k in ['status', 'all67_initial_UV', 'branch_totals', 'wins_ties_losses_vs_DFF', 'known67_total_both_branch_candidate_tests', 'remaining70_of137']}))


if __name__ == '__main__':
    main()
