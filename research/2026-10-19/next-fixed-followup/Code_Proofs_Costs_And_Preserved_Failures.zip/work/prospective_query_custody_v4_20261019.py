"""Future-only same-ACK sharing-transient reader; old launch/service retained.

The read loop is the actual exclusively locked-ACK-tested function body. No ACL
changes, source/PID relaxation, scientific retry, parent restart or new allowance.
"""
import ast,json,time
from pathlib import Path
import prospective_query_custody_v3_20261019 as prior
from public118_slsqp_native_20261018 import read,put,sha

def read_exact_launcher_ack(path,maximum_seconds=60):
    begun=time.perf_counter();errors={}
    while True:
        try:return read(path),errors
        except (PermissionError,json.JSONDecodeError,UnicodeDecodeError) as error:
            errors[type(error).__name__]=errors.get(type(error).__name__,0)+1
            if time.perf_counter()-begun>=maximum_seconds:raise
            time.sleep(.025)

def bind(env,entrypoint):
    out=prior.bind(env,entrypoint);text=Path(prior.__file__).read_text('utf-8');tree=ast.parse(text)
    outer=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='bind');fn=next(n for n in outer.body if isinstance(n,ast.FunctionDef) and n.name=='claim')
    original=ast.unparse(fn);before="a = read(out / 'Launcher_ACK.json')"
    after="a, ack_read_errors = read_exact_launcher_ack(out / 'Launcher_ACK.json')\n    if ack_read_errors:\n        put(out / 'ACK_Read_Transient_Recovery.json', {'errors': ack_read_errors, 'same_owned_ACK': True, 'new_scientific_calls': 0, 'no_ACL_change': True})"
    assert original.count(before)==1;changed=original.replace(before,after);assert changed.replace(after,before)==original
    namespace=prior.__dict__.copy();namespace.update(base=env['B'],entrypoint=entrypoint,now=env['now'],admit=env['admit'],read_exact_launcher_ack=read_exact_launcher_ack)
    exec(compile(changed,str(__file__),'exec'),namespace);out['claim']=namespace['claim'];return out

def certificate():
    import fourth_required_numeric_context_v2_20261019 as tested
    a=next(n for n in ast.parse(Path(__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='read_exact_launcher_ack')
    b=next(n for n in ast.parse(Path(tested.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='read_exact_launcher_ack')
    assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
    return {'tested_ACK_reader_body_AST_exact':True,'tested_source_sha256':sha(tested.__file__),'parent_launcher_unchanged_v3':True,'PID_parent_source_ACK_predicates_unchanged':True,'new_scientific_calls':0}
