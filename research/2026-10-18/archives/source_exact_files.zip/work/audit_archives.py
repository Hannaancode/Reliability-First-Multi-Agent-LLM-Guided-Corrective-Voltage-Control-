import hashlib, json, zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
archives = [
    Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\HierGrid_Local_Transfer.zip'),
    Path(r'C:\Users\HOME\Downloads\HierGrid_Codex_Handover_v2.zip'),
]
for archive in archives:
    print('\nARCHIVE', archive)
    if not archive.exists():
        print('MISSING_AT_SUPPLIED_PATH')
        matches = list(Path(r'C:\Users\HOME\Desktop').glob('*/HierGrid_Local_Transfer.zip')) + list(Path(r'C:\Users\HOME\Downloads').glob('HierGrid_Local_Transfer*.zip'))
        print('POSSIBLE_MATCHES', [str(p) for p in matches])
        if len(matches) == 1:
            archive = matches[0]
        else:
            continue
    print('SHA256', hashlib.sha256(archive.read_bytes()).hexdigest())
    dest = root / 'work' / archive.stem
    with zipfile.ZipFile(archive) as z:
        print('ENTRIES', len(z.infolist()), 'UNCOMPRESSED_BYTES', sum(x.file_size for x in z.infolist()))
        for info in z.infolist():
            target = (dest / info.filename).resolve()
            if not target.is_relative_to(dest.resolve()):
                raise ValueError('Unsafe archive path: ' + info.filename)
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Archive symlink: ' + info.filename)
            print(info.file_size, info.filename)
        if sum(x.file_size for x in z.infolist()) > 1000000000:
            raise ValueError('Archive too large for routine extraction')
        dest.mkdir(parents=True, exist_ok=True)
        z.extractall(dest)
        print('EXTRACTED', dest)
