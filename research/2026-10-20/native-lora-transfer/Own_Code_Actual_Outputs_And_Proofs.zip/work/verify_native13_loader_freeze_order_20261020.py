"""Actual pinned PEFT CPU state-transition test only; no forward/backward/PF/GPU."""
import ast,inspect,json,hashlib,sys,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/original_lora_native13_loader_order_repair_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);import candidate_process_runtime
    import torch,peft
    from transformers import Qwen2Config,Qwen2ForCausalLM
    from peft import LoraConfig,get_peft_model
    import candidate_process_pretrained_loader as old
    assert peft.__version__=='0.19.1'
    original=ROOT/'work/candidate_process_pretrained_loader.py';source=original.read_text(encoding='utf-8')
    source=source.replace('copied=verify_copy_state(model,expected);trainable=set_body_trainability(model,train_body)\n    restoration=enabled_restored_gate(model);torch.cuda.synchronize()', 'copied=verify_copy_state(model,expected)\n    restoration=enabled_restored_gate(model);trainable=set_body_trainability(model,train_body)\n    assert all(not p.requires_grad for p in model.parameters()) if not train_body else True\n    torch.cuda.synchronize()')
    target=ROOT/'work/candidate_process_pretrained_loader_native13_v2_20261020.py'
    with target.open('x',encoding='utf-8') as f:f.write(source)
    before={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(original.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)};after={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)};assert set(before)==set(after) and all(before[n]==after[n] for n in before if n!='load_isolated_body')
    config=Qwen2Config(hidden_size=32,intermediate_size=64,num_hidden_layers=24,num_attention_heads=2,num_key_value_heads=2,vocab_size=64,max_position_embeddings=64)
    model=get_peft_model(Qwen2ForCausalLM(config),LoraConfig(r=16,lora_alpha=16,lora_dropout=0,bias='none',target_modules=sorted(old.EXPECTED_MODULES)),adapter_name=old.ADAPTER_NAME)
    # Explicit random CPU software fixture: same168 adapter modules/336 tensors,
    # small width; only the fixture's expected-parameter scalar is rebound.
    fixture_count=sum(p.numel() for n,p in model.named_parameters() if '.lora_A.' in n or '.lora_B.' in n);old.EXPECTED_BODY_PARAMETERS=fixture_count
    old.set_body_trainability(model,False);old_frozen=sum(p.requires_grad for p in model.parameters());old.enabled_restored_gate(model);after_restore=sum(p.requires_grad for p in model.parameters());assert old_frozen==0 and after_restore==336
    old.set_body_trainability(model,False);assert not any(p.requires_grad for p in model.parameters())
    old.enabled_restored_gate(model);fixed=old.set_body_trainability(model,False);assert len(fixed)==0 and not any(p.requires_grad for p in model.parameters())
    old.enabled_restored_gate(model);train=old.set_body_trainability(model,True);assert len(train)==336 and sum(p.numel() for p in train.values())==fixture_count
    from peft.tuners.tuners_utils import BaseTunerLayer
    installed=inspect.getsource(BaseTunerLayer.set_adapter);assert 'requires_grad_' in installed
    (OUT/'Actual_PEFT_BaseTunerLayer_set_adapter.py.txt').write_text(installed,encoding='utf-8')
    remote=json.loads((ROOT/'outputs/original_lora_native13_transfer_execution_20261020/staged/public_size_environment.json').read_text(encoding='utf-8'));assert remote['versions']['peft']==peft.__version__
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ACTUAL_PINNED_PEFT_TRAINABILITY_RESTORE_ORDER_CAUSE_AND_ADDITIVE_PREINFERENCE_FIX','peft_version':peft.__version__,'same_actual_remote_PEFT_version':True,'old_false_gate_before_restore_trainable_tensors':old_frozen,'old_false_gate_after_restore_trainable_tensors':after_restore,'fixed_false_gate_final_trainable_tensors':0,'fixed_true_gate_final_trainable_tensors':len(train),'fixture_adapter_modules':168,'fixture_tensor_count':336,'fixture_parameters':fixture_count,'fixture_is_random_small_width_CPU_not_actual_quantized_model':True,'all_other_loader_function_ASTs_identical':True,'old_loader_sha256':sha(original),'new_loader_sha256':sha(target),'actual_library_source_sha256':sha(OUT/'Actual_PEFT_BaseTunerLayer_set_adapter.py.txt'),'actual_pretrained_generation_forward_backward_optimizer_PF_GPU_calls':0,'old_partial_model_loads_paid':1,'old_actual_model_outputs':'ALL6_UNEXECUTED_UNKNOWN','no_retry_of_any_actual_forward_or_physical_call':True,'conditional_next':'Distinct fixed source/claim/output;prospectively same3input/token/decoder/strictparser/privateweights/publicbase/nativeaction. Final freeze must pass on actual T4 before any unentered generation. One original-profile allocation,nofallback;oldowner/runtimeended/released. Anyactualscientificattemptmustnotberepeated.'}
    (OUT/'Independent_Causal_Software_Proof.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
