"""Check exact source bytes and prevent an older case snapshot becoming an env pin."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'outputs/published_graph118_environment_source_20261022'
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def main():
    p=O/'voltage_control_env.py';b=p.read_bytes();expected='4f57f118fc65c8234676c55b1c29bd686bd832fd'
    if blob(b)!=expected:
        assert blob(b[:-1])==expected and b.endswith(b'\n')
        (O/'Transport_Extra_Newline_Copy.txt').write_bytes(b);b=b[:-1];p.write_bytes(b)
    assert len(b)==85133 and blob(b)==expected
    text=b.decode('utf-8');assert 'num_gen_reg_buses' not in text
    proof=dict(status='CASE_FILE_COMMIT_IS_NOT_A_COMPATIBLE_GRAPH_ENVIRONMENT_PIN',
        repository='blthayer/gym-powerworld',commit='5540b2704450acb87fee7f57f6766a8bea419f06',git_blob=expected,source_bytes=len(b),source_sha256=hashlib.sha256(b).hexdigest(),
        origin='The drl-powerworld IEEE14 case README cites this snapshot for case files. Its installer does not pin the gym environment revision.',
        incompatibility='The pinned GraphAgent expects num_gen_reg_buses and gen_action_array. This older environment source lacks num_gen_reg_buses. Its episode semantics may not be silently treated as the publication runtime.',
        admission='Read-only source review; do not execute or install this old package as the comparator environment. Obtain a compatible explicitly pinned dependency or disclose a named backend adaptation.',
        already_completed_first_query_port='Original GraphAgent AST preserved with an explicitly named pandapower backend. Four first-query outcomes are integration results, not full native PowerWorld reproduction.',
        new_model_PF_training_install_calls=0,transport_copy_repair='One newline inserted by text patch removed only after exact Git blob proof; original transport copy retained.')
    with (O/'Source_Version_Gap.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
    print(json.dumps(dict(exact_source_blob=expected,compatible_historical_environment='UNRECOVERED',scientific_calls=0)))
if __name__=='__main__':main()
