"""Additive compact ZIP path-key repair after the saved handoff completed.

The failed ZIP and source remain unchanged. No science/reader is restarted.
"""
import hashlib, json, zipfile
from datetime import datetime, timezone
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_native_role_scope_handoff_20261022'; P = O / 'publication'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p, x): p.write_text(json.dumps(x, indent=2, ensure_ascii=False), 'utf-8')

old = P / 'Own_Code_And_Proofs.zip'; retained = O / 'First_Publication_Pack_Path_Key_Failure.zip'
assert old.resolve().is_relative_to(O.resolve()) and retained.resolve().is_relative_to(O.resolve())
assert not retained.exists(); old.rename(retained)
failure = {'at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'PRESERVED_PUBLICATION_ONLY_PATH_KEY_FAILURE',
    'source': 'work/save_original_native_role_scope_checkpoint_20261022.py',
    'source_sha256': sha(R / 'work/save_original_native_role_scope_checkpoint_20261022.py'),
    'exception': 'KeyError at line116: Windows backslash member lookup differs from zipfile normalized forward-slash names',
    'retained_zip': str(retained.relative_to(R)), 'retained_zip_sha256': sha(retained),
    'scientific_and_closed_reader_results_unchanged': True, 'new_science': 0}
put(O / 'Publication_Path_Key_Failure.json', failure)
# Reuse the already written source/code pack membership, normalize only keys.
with zipfile.ZipFile(retained) as z: members = z.namelist()
files = [R / n for n in members]
files += [Path(__file__), O / 'Publication_Path_Key_Failure.json']
manifest = {'members': {p.relative_to(R).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in files},
            'old_failure_retained': str(retained.relative_to(R)), 'path_keys': 'Forward slash ZIP names, no source/science change'}
with zipfile.ZipFile(old, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files: z.write(p, p.relative_to(R).as_posix())
with zipfile.ZipFile(old) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(manifest['members'])
    assert all(hashlib.sha256(z.read(n)).hexdigest() == d['sha256'] for n, d in manifest['members'].items())
manifest.update(zip_bytes=old.stat().st_size, zip_sha256=sha(old), zip_members=len(files), CRC_and_every_member_hash='PASS')
put(P / 'Evidence_Manifest.json', manifest)
expected = [{'local': p.relative_to(R).as_posix(), 'path': 'research/20261022_original_role_history/' + p.name,
             'bytes': p.stat().st_size, 'sha256': sha(p),
             'blob': hashlib.sha1(b'blob ' + str(p.stat().st_size).encode() + b'\0' + p.read_bytes()).hexdigest()}
            for p in sorted(P.iterdir()) if p.is_file()]
assert len(expected) == 7
put(O / 'Expected_Remote_Files.json', {'head': None, 'tree': None, 'previous_head': None, 'files': expected})
print(json.dumps({'new_pack_CRC_and_every_hash': 'PASS', 'files': 7, 'zip_members': len(files), 'zip_bytes': old.stat().st_size}))
