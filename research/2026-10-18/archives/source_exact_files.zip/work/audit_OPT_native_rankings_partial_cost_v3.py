"""Independent all-record current-equation/ranking/cost reader; no solves."""
import os,time
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='1'
import gzip,json,hashlib,zipfile
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter,defaultdict
import numpy as np
from native_affine_ranking_reader import context,verify_step,verify_prediction
from candidate_process_evidence_utils import ROOT,read,sha,write,seal,frozen_checks
P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009';B=ROOT/'outputs/llm_value_candidate_development_20261009'
S=P/'nnrank2';PRE=P/'native_ranking_preparation_v2';OUT=P/'nnrank2_partial_audit_v3'
ARMS=('old_admittance_derivative','candidate_admittance_derivative');LABELS={0:'interior',1:'near_min',2:'near_max'}
GRID=(25.,50.,75.,100.,125.,150.,200.,250.,300.)
def rows(p):
    with gzip.open(p,'rt',encoding='utf8') as f:return [json.loads(l) for l in f]

def run():
    assert not OUT.exists();OUT.mkdir();start=time.perf_counter();write(OUT/'audit.claim',{'pid':os.getpid(),'started_at_utc':datetime.now(timezone.utc).isoformat()})
    proto=read(PRE/'Protocol.json');summary=read(S/'Summary.json');status=read(S/'status.json')
    assert status['stage'] in {'complete_closed_native_numerical_study','terminal_partial_preserved_no_retry'}
    for n,h in proto['source_hashes'].items():assert sha(ROOT/n)==h,n
    # Immutable science manifest, including all actual partial/unexecuted rows.
    manifest=read(S/'Supplement_Manifest.json')
    with zipfile.ZipFile(S/'Full_OPT_Native_Affine_Ranking_Evidence.zip') as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
        for n,d in manifest.items():assert len(z.read(n))==d['bytes'] and hashlib.sha256(z.read(n)).hexdigest()==d['sha256']
    inputs={r['observation_id']:r for r in rows(B/'input_and_target_contract_nullable_v2/Current_Input_Rows.jsonl.gz') if r['split']=='optimization'}
    targets={r['observation_id']:r for r in rows(B/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz') if r['split']=='optimization'}
    support={r['observation_id']:r for r in rows(B/'current_added_support_observables/Current_Control_State_Observables.jsonl.gz') if r['observation_id'] in inputs}
    prefs=rows(P/'actual_representation_and_OPT_support/Measured_OPT_Native_Quality_Preference_Pairs.jsonl.gz')
    worlds={w['scenario_sha256']:w for w in proto['OPT_worlds']};old={}
    for r in read(P/'sla_remaining/Actual_All_Transition_Records.json'):
        j=GRID.index(r['action']['q_abs_mvar'])
        for arm,item in r['arms'].items():old[(r['before_sha256'],r['action']['bus'],j,arm)]=(r['transition_id'],item)
    index=read(S/'Actual_State_File_Index.json');assert len(index)==len({r['observation_id'] for r in index})==239 and {r['observation_id'] for r in index}==set(inputs)
    count=Counter();cachecosts=Counter();records={a:{} for a in ARMS};step_count=0;boundary_disagreements=[];maxres=0.;dense_derivatives=0
    input_arrays=Counter();case_status=Counter();allstepidentities=set();actual_state_ledgers={}
    for ix,entry in zip(proto['all239_current_inputs'],index):
        ident=entry['observation_id'];assert ix['observation_id']==ident
        path=S/entry['record_file'];assert sha(path)==entry['sha256'];r=read(path);inp=inputs[ident];obs=inp['model_input']['current_physical_observation']
        assert r['observation_id']==ident and r['world_sha256']==inp['world_sha256'] and r['model_input_sha256']==inp['model_input_sha256']
        h=hashlib.sha256(json.dumps(obs,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest();assert h==r['current_observation_sha256']==ident
        buses={b for pool in obs['raw_common_and_zone_pools'].values() for b in pool};add=support[ident]['current_added_support_MVAr_by_bus']
        allowed=[(b,j) for b in sorted(buses) for j,q in enumerate(GRID) if add[b]+q<=450.]
        assert r['allowed_actions']==ix['allowed_actions']==[list(a) for a in allowed]
        c=None
        if r['current_state_file']:
            assert sha(ROOT/r['current_state_file'])==r['current_state_sha256']
            with np.load(ROOT/r['current_state_file']) as z:saved={k:z[k] for k in z.files}
            assert saved['Y'].shape==(118,118) and saved['V'].shape==saved['mapping'].shape==(118,) and set(saved['mapping'])==set(range(118))
            vf=obs['physical_tables']['res_bus'];cols=vf['columns'];vv={b:values[cols.index('vm_pu')]*np.exp(1j*np.deg2rad(values[cols.index('va_degree')])) for b,values in zip(vf['index'],vf['values'])}
            assert max(abs(saved['V'][saved['mapping'][b]]-vv[b]) for b in range(118))<=1e-14
            c=context(saved,obs['physical_tables']);dense_derivatives+=1;input_arrays[r['current_state_origin']]+=1
        block_files={item['equation_block']['file'] for arm in ARMS for item in r['arms'][arm]}
        # Read each small closed block once. Per-step masks/x/q and final vm
        # carry enough proof without repeating a factorization or solve.
        block_arrays={};block_hashes={}
        for name in sorted(block_files):
            p=S/name
            block_hashes[name]=sha(p)
            with np.load(p) as z:block_arrays[name]={k:z[k] for k in z.files}
        for arm in ARMS:
            rr=r['arms'][arm];assert [tuple(i['native_action']) for i in rr]==allowed
            recs={}
            for ai,item in enumerate(rr):
                pair=tuple(item['native_action']);assert item['arm']==arm and pair in allowed
                arrays=block_arrays[item['equation_block']['file']];assert block_hashes[item['equation_block']['file']]==item['equation_block']['sha256']
                vm=arrays[item['final_vm_key']] if item['final_vm_key'] else None;key=(ident,*pair,arm);kind=item['record_kind'];count[kind]+=1
                if key in old:
                    tid,prior=old[key];assert kind=='reused_prior' and item['prior_transition_id']==tid and item['prior_scientific_status']==prior['status'] and not item['steps']
                    if prior['status']=='UNKNOWN_original_arrays_lost_no_repeat':
                        assert vm is None;count['original_unknown']+=1
                    else:
                        pf=P/'sla_remaining'/prior['equation_file'];assert sha(pf)==prior['array_sha256']==item['prior_equation_sha256']
                        with np.load(pf) as z:original=z[f"s{len(prior['steps'])-1:02d}_vm"]
                        assert np.array_equal(vm,original);count['reused_finite']+=1
                elif kind=='unexecuted':assert not item['steps'] and vm is None
                else:
                    assert kind=='new_numerical_forecast' and c is not None
                    ids=sorted(c['gen']);assert ids==r['native_generator_ids'];expected={i:'interior' for i in ids};prev=-1
                    for si,step in enumerate(item['steps']):
                        mask={i:LABELS[int(v)] for i,v in zip(ids,arrays['mask_catalog'][step['mask_id']])}
                        updates={i:LABELS[v] for i,v in step['updates']}
                        assert mask==expected and step['step']==si and step['bound_count']==sum(v!='interior' for v in mask.values()) and step['bound_count']>prev
                        prev=step['bound_count'];allstepidentities.add((r['state_index'],ai,arm,si))
                        proof=verify_step(c,{'bus':pair[0],'q_abs_mvar':GRID[pair[1]]},arm==ARMS[1],mask,updates,arrays[step['x_key']],arrays[step['q_key']],vm if vm is not None and si==len(item['steps'])-1 else None)
                        maxres=max(maxres,proof['residual']);step_count+=1
                        if not proof['independent_strict_update_agreement']:boundary_disagreements.append({'observation_id':ident,'native_action':list(pair),'arm':arm,'step':si})
                        if vm is not None and si==len(item['steps'])-1:assert not updates
                        else:assert updates or item['prediction']['closure_status'].startswith('unknown')
                        expected.update(updates)
                    final={i:LABELS[int(v)] for i,v in zip(ids,arrays['mask_catalog'][item['final_mask_id']])};assert final==expected
                    assert len(item['steps'])<=54
                verify_prediction(pair,vm,obs['global_metrics'],item['prediction']);recs[pair]=item['prediction'];case_status[item['prediction']['status']]+=1
            records[arm][ident]=recs
        if r['actual_cache_costs']:
            cachecosts.update(r['actual_cache_costs']);count['cache_evictions']+=r['actual_cache_evictions']
            actual_state_ledgers[r['state_index']]=r['actual_cache_costs']
    assert count['reused_prior']==432 and count['reused_finite']==431 and count['original_unknown']==1
    assert sum(case_status.values())==77002 and count['new_numerical_forecast']+count['unexecuted']==76570
    cost=summary['costs'];assert cost['forecast_attempts']==cost['forecast_returns']==count['new_numerical_forecast']
    assert cost['closed_affine_steps']==step_count==len(allstepidentities) and cost['unexecuted_records']==count['unexecuted']
    assert cost['reused_finite_forecasts']==431 and cost['retained_original_unknown']==1
    assert cost['new_saved_current_states']==input_arrays['new_current_only_derivation'] and cost['reused_current_states']==input_arrays['reused_original']
    assert cost['conversion_attempts']>=cost['conversion_returns']==2*input_arrays['new_current_only_derivation']
    assert cost['admittance_returns']==cost['conversion_returns']==cost['derivative_returns']==0
    assert cost['current_compile_returns']==cost['reused_current_states']==dense_derivatives
    assert 0<=dense_derivatives<=239 and cost['new_saved_current_states']==0
    if summary['all_new_actions_executed']:assert dense_derivatives==239
    assert proto['actual_new_preparation_dense_derivative_assemblies']==239
    journal=[json.loads(l) for l in (S/'Actual_Attempt_Return_Journal.jsonl').read_text().splitlines()];jc=Counter(e['event'] for e in journal)
    assert jc['forecast_attempt']==jc['forecast_return']==count['new_numerical_forecast'] and jc['affine_step_return']==step_count and jc['state_closed']==239
    actual_step_ids={(e['state_index'],e['action_index'],e['arm'],e['step']) for e in journal if e['event']=='affine_step_return'};assert actual_step_ids==allstepidentities
    final_state_events={e['state_index']:e for e in journal if e['event']=='forecast_return'}
    for k in ('LU_factor_attempts','LU_factor_returns','LU_factor_failures','LU_solve_attempts','LU_solve_returns','LU_solve_failures'):
        # Every exact per-state ledger must equal its last immutable action
        # return. No cache/factorization/solve is treated as free.
        for state_index,event in final_state_events.items():
            assert actual_state_ledgers[state_index][k]==event['actual_cache_costs_cumulative'][k]
    measured=0;stats={};pair_relations={};world_tables={};index_by_identity={e['observation_id']:e for e in index}
    for arm in ARMS:
        byk={str(k):[] for k in (1,4,8)};state_results=[];pair_counts=Counter();pair_states=defaultdict(Counter)
        for ident,inp in inputs.items():
            truth={}
            for entry in targets.get(ident,{}).get('measured_candidates',[]):
                t=entry['target'];a=(t['bus'],t['Q_index']);assert a not in truth;truth[a]=t
            if arm==ARMS[0]:measured+=len(truth)
            valid={a:t for a,t in truth.items() if a in records[arm][ident] and t['recorded_verifier']['accepted']}
            best=max((tuple(t['recorded_original_score']) for t in valid.values()),default=None);oracle={a for a,t in valid.items() if tuple(t['recorded_original_score'])==best}
            finite=[p for p in records[arm][ident].values() if p['status']=='finite_linear_forecast']
            ranked=sorted(finite,key=lambda p:(*p['estimated_original_score'],-p['bus']),reverse=True)
            source_record=read(S/index_by_identity[ident]['record_file'])
            arm_items=source_record['arms'][arm]
            execution_complete=all(i['record_kind']!='unexecuted' for i in arm_items)
            lost_original=any(i.get('prior_scientific_status')=='UNKNOWN_original_arrays_lost_no_repeat' for i in arm_items)
            ranking_evidence_complete=execution_complete and not lost_original
            sr={'observation_id':ident,'world_sha256':inp['world_sha256'],'family':worlds[inp['world_sha256']]['family'],'oracle_exists':bool(oracle),'K':{},
                'all_native_calls_executed':execution_complete,'lost_original_output_retained':lost_original,
                'policy_ranking_evidence_complete':ranking_evidence_complete,'ranking_scope':'complete_execution' if ranking_evidence_complete else 'available_outputs_ONLY_not_method_performance'}
            for k in (1,4,8):
                chosen=[(p['bus'],p['Q_index']) for p in ranked[:k]]
                d={'oracle_included':bool(set(chosen)&oracle) if oracle else None,'chosen_actions':[list(a) for a in chosen],
                   'known_accepted':sum(a in truth and truth[a]['recorded_verifier']['accepted'] for a in chosen),
                   'known_rejected':sum(a in truth and not truth[a]['recorded_verifier']['accepted'] for a in chosen),
                   'unknown_unmeasured':sum(a not in truth for a in chosen),'unavailable_slots':max(0,k-len(chosen))}
                d['actual_method_inclusion']=d['oracle_included'] if ranking_evidence_complete else None
                d['conservative_inclusion_bounds']=[int(d['oracle_included']),int(d['oracle_included'])] if oracle and ranking_evidence_complete else [0,1] if oracle else None
                sr['K'][str(k)]=d;byk[str(k)].append(sr)
            state_results.append(sr)
        assert len(state_results)==239
        for p in prefs:
            ident=p['observation_id'];a,b=(tuple(p[n]) for n in ('preferred_action','other_action'));pa,pb=records[arm][ident][a],records[arm][ident][b]
            relation='unknown'
            if pa['status']==pb['status']=='finite_linear_forecast':
                sa,sb=tuple(pa['estimated_original_score']),tuple(pb['estimated_original_score']);relation='aligned' if sa>sb else 'score_tied' if sa==sb else 'reversed'
            pair_counts[relation]+=1;pair_states[ident][relation]+=1
        totals={}
        for k in ('1','4','8'):
            ors=[r for r in state_results if r['oracle_exists']];wtable={}
            for w in worlds:
                wr=[r for r in state_results if r['world_sha256']==w];oo=[r for r in wr if r['oracle_exists']];wins=sum(r['K'][k]['oracle_included'] for r in oo)
                wtable[w]={'all_inputs':len(wr),'oracle_states':len(oo),'included':wins,'rate':wins/len(oo) if oo else None}
            rates=[r['rate'] for r in wtable.values() if r['rate'] is not None]
            totals[k]={'recorded_best_included':sum(r['K'][k]['oracle_included'] for r in ors),'oracle_states':len(ors),'equal_world_inclusion':sum(rates)/len(rates),
                       'all23_worlds':wtable,'shortlist_totals':{n:sum(r['K'][k][n] for r in state_results) for n in ('known_accepted','known_rejected','unknown_unmeasured','unavailable_slots')}}
        stats[arm]=totals;world_tables[arm]=state_results
        pair_relations[arm]={'counts':dict(pair_counts),'reversed_coverage':{'states':sum(v['reversed']>0 for v in pair_states.values()),
            'worlds':len({inputs[i]['world_sha256'] for i,v in pair_states.items() if v['reversed']}),
            'families':sorted({worlds[inputs[i]['world_sha256']]['family'] for i,v in pair_states.items() if v['reversed']})}}
    assert measured==30510
    uncertainty={}
    for arm in ARMS:
        uncertainty[arm]={}
        for k in ('1','4','8'):
            world_intervals={};complete_count=exact_wins=unknown_count=0
            for w in worlds:
                oo=[r for r in world_tables[arm] if r['world_sha256']==w and r['oracle_exists']]
                if not oo:world_intervals[w]={'oracle_states':0,'lower':None,'upper':None};continue
                lo=sum(r['K'][k]['conservative_inclusion_bounds'][0] for r in oo)/len(oo)
                hi=sum(r['K'][k]['conservative_inclusion_bounds'][1] for r in oo)/len(oo)
                world_intervals[w]={'oracle_states':len(oo),'lower':lo,'upper':hi}
                complete_count+=sum(r['policy_ranking_evidence_complete'] for r in oo)
                exact_wins+=sum(r['K'][k]['actual_method_inclusion'] is True for r in oo)
                unknown_count+=sum(r['K'][k]['actual_method_inclusion'] is None for r in oo)
            intervals=[v for v in world_intervals.values() if v['lower'] is not None]
            uncertainty[arm][k]={'complete_execution_oracle_states':complete_count,'exact_inclusion_wins':exact_wins,'unexecuted_or_unrecovered_inclusion_UNKNOWN_states':unknown_count,
                'equal_world_conservative_lower':sum(v['lower'] for v in intervals)/len(intervals),'equal_world_conservative_upper':sum(v['upper'] for v in intervals)/len(intervals),
                'all23_world_intervals':world_intervals}
    allresults={'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'K_available_outputs_ONLY':stats,'actual_method_inclusion_evidence':uncertainty,'existing_preference_relations_available_outputs_ONLY':pair_relations,
                'all239_OPT_inputs_23worlds_187targetstates_30510labels_retained':True,'all77002_records_retained':True,
                'unknown_and_nonphysical_status_counts':dict(case_status),'new_actual_costs':cost,'cache_numerical_costs':dict(cachecosts),
                'original_paid_data_reused_separately':proto['prior_costs'],'invalid_and_missing_denominators':proto['invalid_and_missing_denominators'],
                'overall_DSE_or_LLM_superiority':False,'development_only':True,'no_automatic_training':True}
    certificate={'audited_at_utc':datetime.now(timezone.utc).isoformat(),'all_available_identity_scope_equation_score_cost_manifest_checks_passed':True,
                 'declared_arm_records':77002,'new_recorded_affine_step_checks':step_count,'exact_original_forecasts_reused':431,'original_unavailable_forecast_retained':1,
                 'independent_dense_current_derivative_evaluations':dense_derivatives,'max_equation_residual':maxres,
                 'independent_strict_update_disagreements':boundary_disagreements,'every_strict_update_agreed':not boundary_disagreements,
                 'new_model_PF_optimizer_controller_cloud_or_linear_solve_calls':0,'actual_reader_seconds':time.perf_counter()-start,
                 'all_planned_new_numerical_calls_executed':summary['all_new_actions_executed'],'new_unknown_or_nonphysical_outcomes_retained':True,
                 'production_control_not_hidden_nonlinear_PF_mode_certificate':True,'held_metrics_or_unused_confirmation_computed':0,'partial_output_rankings_are_not_failed_or_passed_full_method_results':True}
    write(OUT/'Independent_Full_Native_Numerical_Audit.json',certificate);write(OUT/'Actual_All_Arm_Native_Ranking_Results.json',allresults)
    write(OUT/'Actual_All239_World_State_Denominators.json',world_tables);write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())
    text='Unexecuted native forecasts and unrecovered original outputs leave full method rankings UNKNOWN. Available-output K values are descriptive only; conservative full-ranking intervals are reported. No partial result is a negative learning or numerical-method finding. Both derivative variants and every declared action/unknown/failure remain retained. This is current-only affine development ranking, not physical rollout, learned contribution or D-SE superiority. No automatic training follows.\n\n'+json.dumps({'K4_actual_method_evidence':{a:uncertainty[a]['4'] for a in ARMS},'available_output_preferences_ONLY':pair_relations,'unknown_counts':dict(case_status)},indent=2)+'\n'
    (OUT/'Results.md').write_text(text,encoding='utf8')
    files={p.name:p for p in OUT.iterdir() if p.is_file() and p.name!='audit.claim'};files['source/auditor.py']=Path(__file__);files['source/reader.py']=ROOT/'work/native_affine_ranking_reader.py'
    archive=seal(OUT,files,'Independent_Full_Native_Numerical_Ranking_Audit.zip');write(OUT/'status.json',{'stage':'complete_external_native_numerical_audit'})
    print(json.dumps({'audit':certificate,'K4':{a:{k:stats[a]['4'][k] for k in ('recorded_best_included','oracle_states','equal_world_inclusion','shortlist_totals')} for a in ARMS},'preference_relations':pair_relations,'archive':archive}))

if __name__=='__main__':run()
