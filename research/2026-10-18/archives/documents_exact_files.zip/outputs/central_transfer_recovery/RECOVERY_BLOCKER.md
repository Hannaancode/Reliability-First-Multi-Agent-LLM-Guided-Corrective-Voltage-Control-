# Missing final central outputs

Observed 7 October 2026, 14:07 Qatar time. Original remote campaign returned exit 0. The staging downloader stopped at 60 pairs with PermissionError, then the original collector released its runtime. A GET-only check of the exact assignment returns no runtime proxy, so original remaining files are no longer accessible through that assignment. No new runtime was allocated.

The preserved prefix contains 60 original case/RNG pairs. Every case matches its locked scenario identity and frozen protocol; every RNG archive passes CRC; overlap with existing live files matches SHA256. Manifest: `VERIFIED_PRESERVED_PREFIX_MANIFEST.json`.

Missing: index 61, `rev_unseen_combined_load_1p4_line_97_MG2` and RNG `061.pt`; index 62, `rev_unseen_combined_load_1p4_line_99_MG1` and RNG `062.pt`. The last preserved original RNG is `060.pt`.

Proposed recovery, pending user authorization: preserve all 60 original pairs, use the unchanged frozen `run_central_experiment.py --locked --resume` on the validated frozen environment, restore the genuine case-60 RNG, and execute only the two missing cases. Record those two results as recovery executions, not recovered original outputs. Recheck configuration compatibility and actual hardware/environment before execution; do not alter frozen sources to force a resume. Then audit all 62 identities before integration and complete physical/statistical/package gates.

The current follow-up explicitly says never rerun experiments due to transfer failure. Accordingly, no recovery executions or security GPU runtime have started. AC remains active at 37/62, and its supervisor can continue independently. This is not all-ten completion.
