"""Actual pinned tokenizer synthetic engineering capacity; no model import/load."""
from pathlib import Path
import json,hashlib
from transformers import AutoTokenizer
from public_qa_inference_worker_v2_20261029 import TorchBackend
R=Path(__file__).resolve().parents[1]
def main():
    o=R/'outputs/public_qa_supervision_20261029/Synthetic_Capacity.json';assert not o.exists();rows=[]
    for m in json.loads((R/'outputs/public_qa_scale_design_20261029/token_bounds_v2/Result.json').read_text())['models']:
        d=R/'outputs/public_qa_scale_design_20261029'/m['model'].split('/')[-1]/'tokenizer_only'
        b=TorchBackend.__new__(TorchBackend);b.tokenizer=AutoTokenizer.from_pretrained(d,local_files_only=True,trust_remote_code=False)
        ids=b.synthetic_ids(m['max_prefix_tokens']);assert len(ids)+256<=4096
        rows.append({'model':m['model'],'actual_synthetic_input_tokens':len(ids),'forced_engineering_output':256,
            'full_tokens':len(ids)+256,'limit':4096,'input_ids_sha256':hashlib.sha256(json.dumps(ids).encode()).hexdigest()})
    result={'status':'PASS_THREE_ACTUAL_SYNTHETIC_CONTEXT_BOUNDS','models':rows,'new_model_GPU_calls':0,
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    o.write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps({'status':result['status'],'counts':[x['full_tokens'] for x in rows]}))
if __name__=='__main__':main()
