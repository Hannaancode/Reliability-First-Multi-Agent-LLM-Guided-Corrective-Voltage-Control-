"""Causal current-state/history encoder for a NEW native numeric actor; no outcome/label inputs."""
import json,math
FORBIDDEN={'seed','world','algorithm','teacher','target','after','accepted','proposed_action','reward','final_score','oracle'}
def check_keys(value):
    if isinstance(value,dict):
        for k,v in value.items():
            if k.lower() in FORBIDDEN:raise ValueError('Outcome/identity field forbidden in causal forward')
            check_keys(v)
    elif isinstance(value,list):
        for v in value:check_keys(v)
    elif isinstance(value,float) and not math.isfinite(value):raise ValueError('Nonfinite causal state')
def make_text(net,ybus,actor_bus,past_receipts,current_step,remaining):
    if actor_bus not in [2,7,9] or len(net.bus)!=13 or not 0<=remaining<=100:raise ValueError('Native actor/budget mismatch')
    if any(r['step']>=current_step for r in past_receipts):raise ValueError('Future receipt is unavailable')
    history=[{'relative_step':int(r['step']-current_step),'voltage_magnitudes_pu':r['all13_vm'],'controlled_Q_mvar':r['absolute_Q_Mvar']} for r in past_receipts[-2:]]
    entries=[]
    for i in range(13):
        for j in range(13):
            z=complex(ybus[i,j])
            if z!=0:entries.append([i,j,z.real,z.imag])
    state={'network':{'base_mva':float(net._ppc['baseMVA']),'bus_ids':[int(i) for i in net.bus.index],'Ybus_pu_sparse_ij_real_imag':entries},'current_measurements':{'Vm_pu':net.res_bus.vm_pu.to_list(),'Va_degree':net.res_bus.va_degree.to_list(),'net_P_injection_mw':(-net.res_bus.p_mw).to_list(),'net_Q_injection_mvar':(-net.res_bus.q_mvar).to_list()},'control':{'actuator_bus_ids':[2,7,9],'own_actor_bus_id':int(actor_bus),'current_Q_mvar':net.sgen.q_mvar.to_list()[:3],'maximum_absolute_increment_mvar':0.30000001192092896,'absolute_Q_hardware_cap':None,'transition':'Q_next=Q_current-u;u is signed float32 Mvar','remaining_operations':int(remaining)},'operating_rule':{'whole_grid_voltage_band_pu':[.95,1.05],'protect_currently_normal_buses':True,'no_increase_UV_or_OV_counts':True},'past_receipts':history}
    check_keys(state);payload=json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False)
    return '<|im_start|>system\nNative whole-grid inverter actor. Use only the current causal measurements, public circuit, native controls and past receipts below. A separate bounded numeric head supplies the action; do not generate language.\n<|im_end|>\n<|im_start|>user\n'+payload+'\n<|im_end|>\n<|im_start|>assistant\n'
