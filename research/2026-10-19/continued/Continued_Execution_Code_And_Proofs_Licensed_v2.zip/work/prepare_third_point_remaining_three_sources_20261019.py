"""Three never-entered physical identities; old warm call and stopped owners stay closed."""
import ast,pickle,zlib
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha
def sub(t,a,b):assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
def main():
    out=R/'outputs/third_point_remaining_three_source_preparation_20261019';out.mkdir(exist_ok=False)
    prior=R/'outputs/third_point_four_query_acquisition_20261019';proof=read(prior/'Preserved_Prefix_State_Proof.json');assert proof['status']=='PASS_ACTUAL_WARM_PREFIX_NATIVE_PHYSICS_STATE_COSTS_ONLY' and proof['remaining_original_menu_identities']=='THREE_UNEXECUTED_UNKNOWN'
    cell=read(R/'outputs/third_point_four_source_preparation_20261019/Exact_Current_Cell.json');paid=proof['paid_key'];assert cell['all4_pre_physics_menu'][0]['point_action_key']==paid
    pending=[v for v in cell['all4_pre_physics_menu'] if v['point_action_key']!=paid];assert len(pending)==3
    cell['all_unexecuted_original_menu_queries']=pending;cell['all4_pre_physics_menu'][0]['already_paid']=True;put(out/'Exact_Current_Cell.json',cell)
    inp=R/'outputs/third_point_remaining_three_input_20261019';inp.mkdir(exist_ok=False);base=R/'outputs/third_point_four_input_20261019/Exact_Current_Input.zlib';state=pickle.loads(zlib.decompress(base.read_bytes()));state['source_edge']['new_paid_warm_prefix']=str((prior/'Preserved_Prefix_State_Proof.json').relative_to(R));(inp/'Exact_Current_Input.zlib').write_bytes(zlib.compress(pickle.dumps(state,5),6));put(inp/'Exact_Candidate_Inputs.json',{'point':cell['point'],'parent':cell['parent'],'exact_new_query_rows':pending})
    mapping={'fixed_three_query_core_20261019':'third_point_remaining_three_core_20261019','run_remaining_three_fixed_queries_20261019':'run_third_point_remaining_three_20261019','audit_remaining_three_fixed_queries_20261019':'audit_third_point_remaining_three_20261019','certify_remaining_three_coverage_20261019':'certify_third_point_remaining_three_20261019','prepare_remaining_three_fixed_queries_20261019':'prepare_third_point_remaining_three_20261019'}
    for old,new in mapping.items():
        if old.startswith('certify_'):t=(R/'work/certify_third_point_four_coverage_20261019.py').read_text('utf-8')
        else:t=(R/'work'/f'{old}.py').read_text('utf-8')
        for a,b in mapping.items():t=t.replace(a,b)
        t=t.replace("B=R/'outputs/remaining_three_fixed_queries_20261019'","B=R/'outputs/third_point_remaining_three_query_acquisition_20261019'")
        if old.startswith('fixed_'):
            t=sub(t,"I=old.I;PYTHON=old.PYTHON;PHASES=", "I=R/'outputs/third_point_remaining_three_input_20261019';PYTHON=old.PYTHON;PHASES=")
            t=sub(t,'from pathlib import Path','from pathlib import Path\nfrom prospective_query_custody_v3_20261019 import bind')
            a="    keys=old.known_keys();past=read(I/'Exact_Candidate_Inputs.json')\n    return set(keys)|{v['point_action_key'] for v in past['exact_new_query_rows']}"
            b="    from third_point_four_query_core_20261019 import known_keys as prior_keys\n    key=read(R/'outputs/third_point_four_query_acquisition_20261019/Preserved_Prefix_State_Proof.json')['paid_key']\n    return set(prior_keys())|{key}"
            t=sub(t,a,b);t=sub(t,'    return env\n','    return bind(env,entrypoint)\n');t=t.replace("f'exact_three_fixed_query_{index + 1}'","f'exact_third_remaining_query_{index + 1}'")
        if old.startswith('audit_'):t=sub(t,'EDITS=[','EDITS=[\n    ("assert runner.rescue.grid_metrics(source[\'net\'])[\'uv_count\']==17", "assert runner.rescue.grid_metrics(source[\'net\'])[\'uv_count\']==18"),')
        if old.startswith('certify_'):
            t=t.replace('from third_point_four_query_core_20261019 import B,I,helpers,known_keys','from third_point_remaining_three_core_20261019 import B,I,helpers,known_keys').replace('outputs/third_point_four_source_preparation_20261019/Exact_Current_Cell.json','outputs/third_point_remaining_three_source_preparation_20261019/Exact_Current_Cell.json')
            t=sub(t,"'PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE')]:","'PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE'),('third_point_four_query_acquisition_20261019',('warm',),'Preserved_Prefix_State_Proof.json','PASS_ACTUAL_WARM_PREFIX_NATIVE_PHYSICS_STATE_COSTS_ONLY')]:")
            t=t.replace('assert len(recent)==18','assert len(recent)==20').replace('recent18','recent20').replace("assert rows==cell['all4_pre_physics_menu']==cell['all_unexecuted_original_menu_queries']","assert rows==cell['all_unexecuted_original_menu_queries'] and [r['fixed_rank'] for r in rows]==[2,3,4]").replace('assert len(targets)==4','assert len(targets)==3')
        if old.startswith('prepare_'):
            t=t.replace('current17UV','current18UV').replace('Preserve prior rejected rank1 and separate cold engineering action.','Prior rank1 was already measured18to15 and remains paid. The stopped cold owner never passedACK or entered a scientific body; these3 exact identities were never reserved or attempted. No old owner is restarted.')
        target=R/'work'/f'{new}.py';ast.parse(t);assert not target.exists();target.write_text(t,'utf-8')
    put(out/'Preparation_Justification.json',{'status':'EXACT_THREE_UNENTERED_IDENTITIES_NOT_SCIENTIFIC_RETRY','prior_prefix_proof_sha256':sha(prior/'Preserved_Prefix_State_Proof.json'),'old_four_study':'TERMINAL_PARTIAL_ALL_OTHER_IDENTITIES_UNKNOWN','new_scientific_calls':0,'no_old_owner_restart_budget_extension_or_new_settings':True,'all3_remaining_original_menu_rows_retained':True,'already_measured_rank1_excluded_for_identity_reuse_not_outcome_selection':paid,'future_custody_source':'work/prospective_query_custody_v3_20261019.py'})
    print('Prepared new exact3unentered identities; no science/no oldownerrestart')
if __name__=='__main__':main()
