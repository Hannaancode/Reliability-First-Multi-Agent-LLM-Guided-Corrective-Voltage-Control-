"""Saved trajectory/label diagnostic only. No learned or physical policy evaluation."""
import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    import numpy as np
    source=ROOT/'outputs/native_fit_teacher_execution_20261020/Result.json'
    teacher=json.loads(source.read_text(encoding='utf-8'))
    rows=json.loads((ROOT/'outputs/native_fit_training_inputs_20261020/All_FIT_Complete_Causal_Inputs_And_Separated_Labels.json').read_text(encoding='utf-8'))
    assert teacher['status']=='COMPLETE_DECLARED64_NATIVE_FIT_TEACHER_EPISODES' and len(rows)==1929
    weights=np.array([r['world_weight'] for r in rows]);targets=np.array([r['label_not_forwarded'] for r in rows],dtype=np.float32)
    zero=np.all(targets==0,axis=1);failures=[];deficits=[];stops={}
    for w in teacher['all_worlds']:
        stops[w['status']]=stops.get(w['status'],0)+1
        vm=np.asarray(w['final_vm']);deficits.extend((.95-vm[vm<.95]).tolist())
        if w['final_UV'] or w['final_OV']:
            last=w['steps'][-1];tail=0
            for s in reversed(w['steps']):
                if s['accepted'] and np.array_equal(np.array(s['raw_teacher_u'],dtype=np.float32),np.zeros(3,dtype=np.float32)):tail+=1
                else:break
            failures.append({'world':w['seed'],'status':w['status'],'final_UV':w['final_UV'],'final_OV':w['final_OV'],
                             'last_target_exact_zero':bool(np.all(np.array(last['committed_teacher_u'])==0)),
                             'consecutive_accepted_exact_zero_tail':tail,'last_measured_proposal_accepted':last['accepted'],
                             'last_proposal_UV_OV':[last['candidate_UV'],last['candidate_OV']]})
    assert len(failures)==29 and len(deficits)==94 and all(x['consecutive_accepted_exact_zero_tail']>0 for x in failures if x['status']=='COMPLETE_NATIVE100_HORIZON')
    report={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'SAVED_ONLY_CAUSAL_TEACHER_TARGET_LIMITATION_DIAGNOSTIC',
            'source_sha256':sha(source),'all_declared_worlds':64,'fully_restored':35,'failed_all_bus_restoration':29,
            'terminal_statuses':stops,'all_original_decision_rows':1929,'exact_zero_target_rows':int(zero.sum()),
            'world_weighted_exact_zero_target_fraction':float(weights[zero].sum()/weights.sum()),
            'remaining_UV':94,'deficits_gt0_at_most_1e_8':int(sum(0<x<=1e-8 for x in deficits)),
            'deficits_gt1e_8':int(sum(x>1e-8 for x in deficits)),'maximum_deficit_pu':max(deficits),
            'all_failed_worlds':failures,'threshold_and_success_definition_unchanged':True,
            'meaning':'Exact reproduction of this saved teacher under the same host rules reproduces its saved limitations. Lower imitation loss or a bigger body alone is not evidence of an improvement mechanism. This is not an upper bound on other controllers, an infeasibility certificate or a reason to drop difficult states.',
            'next_hypothesis_gate':'Before expensive learning require a target/representation/decision mechanism that can address teacher failures, with prospectively fixed controls, safe full-system outcomes and unused confirmation. No observed-case Q/margin/objective retune is authorized by this diagnosis.',
            'new_PF_model_forward_backward_optimizer_derivative_factor_solve_calls':0}
    out=ROOT/'outputs/native_readout_progress_handoff_20261020/Saved_Only_Teacher_Learning_Bottleneck.json'
    with out.open('x',encoding='utf-8') as f:json.dump(report,f,indent=2,allow_nan=False)
    print(json.dumps({k:report[k] for k in ['fully_restored','failed_all_bus_restoration','terminal_statuses','exact_zero_target_rows','world_weighted_exact_zero_target_fraction','remaining_UV','deficits_gt0_at_most_1e_8','deficits_gt1e_8','new_PF_model_forward_backward_optimizer_derivative_factor_solve_calls']}))
if __name__=='__main__':main()
