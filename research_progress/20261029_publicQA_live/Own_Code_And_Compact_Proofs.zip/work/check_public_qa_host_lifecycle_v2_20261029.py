"""Offline integration of the actual host main, with an explicitly fake Colab API."""
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import unquote
import ast, base64, hashlib, json, os, sys
from unittest.mock import patch
import run_public_qa_colab_20261029 as owner
from public_qa_transfer_20261029 import publish_packet, read, sha
R=Path(__file__).resolve().parents[1];O=R/'outputs/public_qa_supervision_20261029/host_lifecycle_v2'

class Response:
    def __init__(self,value,status=200):self.value=value;self.status_code=status;self.content=json.dumps(value).encode();self.text=self.content.decode()
    def json(self):return self.value
    def raise_for_status(self):
        if self.status_code>=400:raise owner.requests.exceptions.HTTPError(response=self)

def scenario(label,mode):
    root=O/label;root.mkdir();execution=root/'execution';remote={};calls=[];runtime_exec=[]
    source=R/'outputs/public_qa_supervision_20261029/software_v2/complete'
    transfer=root/'fixture_transfer';descriptor=publish_packet(source,transfer,0,True,0)
    remote_root='content/hiergrid_public_qa_mock'
    for p in (transfer/'packet_000').iterdir():remote[remote_root+'/transfer/packet_000/'+p.name]=p.read_bytes()
    for n,v in {'Setup_Reaped.json':{'actual_setup_child_ended':True,'exit_code':0},
        'Setup_End.json':{'exit_code':0},'Linux_Watchdog_Gate.json':{'status':'PASS_TWO_ACTUAL_LINUX_CHILD_STOPS'},'environment.json':{'mock':True},
        'Remote_End.json':{'actual_child_ended':True},'Supervisor_Reaped.json':{'actual_supervisor_ended':True},
        'supervisor.claim':{'mock':True},'child_launch.json':{'mock':True}}.items():remote[remote_root+'/'+n]=json.dumps(v).encode()
    if mode=='setup_failure':remote[remote_root+'/Setup_Reaped.json']=json.dumps({'actual_setup_child_ended':True,'exit_code':1}).encode()
    for n in ['setup.log','worker.log']:remote[remote_root+'/'+n]=b'MOCK_ONLY'
    payload=root/'payload.zip';payload.write_bytes(b'MOCK_UPLOAD_NOT_EXECUTABLE')
    protocol={'launch_ready':True,'source_hashes':{},'arms':[{'id':'mock','execution':'execution','payload':'payload.zip',
        'payload_sha256':sha(payload.read_bytes()),'credential_directory':'MOCK_NEVER_READ','account_sha256':sha(b'mock@example.invalid')}]}
    protocol_path=root/'Protocol.json';protocol_path.write_text(json.dumps(protocol),'utf-8')
    assignment=SimpleNamespace(endpoint='MOCK_ENDPOINT',accelerator=owner.Accelerator.T4,
        runtime_proxy_info=SimpleNamespace(url='https://fake.invalid',token='MOCK_NEVER_NETWORKED'))
    class Credentials:
        @staticmethod
        def from_authorized_user_file(p):return Credentials()
        def refresh(self,*a,**k):pass
    class Session:
        def __init__(self,*a,**k):pass
        def get(self,url,**k):return Response({'email':'mock@example.invalid'} if 'userinfo' in url else {'eligibleGpus':['T4']})
        def close(self):pass
    class Client:
        def __init__(self,*a):self.assigned=False
        def list_assignments(self):return [assignment] if self.assigned else []
        def assign(self,*a,**k):
            calls.append('assign')
            if mode=='denied':raise owner.requests.exceptions.HTTPError(response=Response({},403))
            self.assigned=True
            if mode=='ambiguous':raise owner.requests.exceptions.Timeout('MOCK uncertain assign')
            return assignment
        def _get_assignment(self,*a,**k):calls.append('same_assignment_GET');return assignment
        def unassign(self,endpoint):assert endpoint=='MOCK_ENDPOINT';calls.append('release');self.assigned=False
    class Runtime:
        def __init__(self,**k):pass
        def execute_code(self,code,**k):
            ast.parse(code);runtime_exec.append(code)
            if mode=='uncertain_science' and 'public_qa_remote_supervisor' in code:
                raise owner.requests.exceptions.Timeout('MOCK code receipt ambiguous; no replay')
            return []
        def stop(self):calls.append('disconnect_kernel_client')
    transient_used=False
    def request(method,url,**kwargs):
        nonlocal transient_used
        assert url.startswith('https://fake.invalid/api/contents/')
        path=unquote(url.split('/api/contents/',1)[1])
        if mode=='one_transfer_timeout' and method=='GET' and not transient_used:
            transient_used=True;raise owner.requests.exceptions.Timeout('MOCK data transfer timeout')
        if method=='PUT':
            p=kwargs['json'];remote[path]=base64.b64decode(p['content']) if p['format']=='base64' else p['content'].encode();return Response({})
        return Response({'format':'base64','content':base64.b64encode(remote[path]).decode()}) if path in remote else Response({},404)
    def sleep(seconds):
        if (execution/'owner.claim').exists() and not (execution/'Launcher_ACK.json').exists():
            (execution/'Launcher_ACK.json').write_text(json.dumps({'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'fresh_exact_source_PID_parent_command':True}))
    exit_code=0
    with patch.object(owner,'R',root),patch.object(owner,'Credentials',Credentials),patch.object(owner,'BoundedSession',Session),\
        patch.object(owner,'Client',Client),patch.object(owner,'ColabRuntime',Runtime),patch.object(owner.requests,'request',request),\
        patch.object(owner.time,'sleep',sleep),patch.object(sys,'argv',['mock','--protocol',str(protocol_path),'--arm','mock']):
        try:owner.main()
        except SystemExit as e:exit_code=e.code
    result=read(execution/'status.json');assert calls.count('assign')==1
    if mode in ('complete','one_transfer_timeout'):
        assert exit_code==0 and result['all_artifacts_preserved'] and result['runtime_released']
        assert calls.count('release')==1 and len(runtime_exec)==3
    elif mode=='setup_failure':
        assert exit_code==0 and result['no_scientific_entry'] and result['runtime_released'] and result['all_artifacts_preserved'] and len(runtime_exec)==2
    elif mode=='ambiguous':
        assert exit_code==1 and calls.count('same_assignment_GET')==1 and calls.count('release')==1 and not runtime_exec
    elif mode=='denied':
        assert exit_code==1 and calls==['assign'] and not runtime_exec
    elif mode=='uncertain_science':
        assert exit_code==1 and 'release' not in calls and len(runtime_exec)==3 and not result['runtime_released']
    return {'case':mode,'status':'PASS_OFFLINE_HOST_BOUNDARY','allocation_API_calls':'MOCK_ONLY',
        'mock_calls':calls,'runtime_execute_requests':len(runtime_exec),'host_exit':exit_code}

def main():
    O.mkdir(exist_ok=False)
    checks=[scenario(mode,mode) for mode in ['complete','one_transfer_timeout','ambiguous','denied','uncertain_science','setup_failure']]
    result={'status':'PASS_SIX_OFFLINE_FINAL_HOST_LIFECYCLES','checks':checks,'host_sha256':sha((R/'work/run_public_qa_colab_20261029.py').read_bytes()),
        'test_sha256':sha(Path(__file__).read_bytes()),'real_network_allocation_model_GPU_PF_calls':0,
        'limits':'Mock API tests do not establish real Colab availability or process execution. Uncertain live science preserves its assignment for same-owner GET-only recovery; no automatic replacement or repeated execution.'}
    (O/'Result.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps({'status':result['status'],'cases':len(checks)}))
if __name__=='__main__':main()
