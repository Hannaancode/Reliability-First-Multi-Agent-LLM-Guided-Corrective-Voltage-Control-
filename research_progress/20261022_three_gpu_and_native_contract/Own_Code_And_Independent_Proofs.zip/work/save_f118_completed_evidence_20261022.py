"""Close verified results and save an exact, conservative continuation index."""
import hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'outputs/f118_actual_completion_handoff_20261022'
def read(p):return json.loads((R/p).read_text('utf-8'))
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2,ensure_ascii=False)
def main():
    O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
    completion=read('outputs/f118_encoder_readout_handoff_20261022/Completion.json')
    assert completion['all3_features_complete']
    fa=read('outputs/f118_encoder_readout_independent_20261022/Independent_Audit.json');assert fa['all3_complete']
    ma=read('outputs/f118_fixed_encoder_readout_audit_20261022/Independent_Audit.json');assert ma['status'].startswith('PASS_ALL_FIXED')
    nr=read('outputs/f118_fixed_numeric_readouts_20261022/Results.json')
    rr=read('outputs/f118_fixed_encoder_readouts_20261022/Results.json')
    assert rr['private_primary_gate']=='FAIL_STOP_FIXED_ENCODER_READOUT_INTERVENTION'
    models={}
    for arm in fa['models']:
        st=read(f'outputs/f118_encoder_readout_execution_20261022/{arm}/status.json')
        assert st['runtime_released'] and st['scientific_process_ended'] and st['all_actual_closed_artifacts_preserved'] and st['remote_exit_code']==0
        models[arm]=dict(actual_costs=fa['models'][arm]['actual_costs'],peak_allocated_bytes=fa['models'][arm]['peak_allocated_bytes'],
            workflow_seconds=fa['models'][arm]['workflow_seconds'],runtime_released=True,preserved_archive=st['preserved_archive'])
    bridge=read('outputs/r118_solver_contract_bridge_independent_20261022/Independent_Audit.json');assert bridge['status'].startswith('PASS_FIRST_NEW80')
    for path in ['outputs/r118_solver_contract_bridge_coordination_v2_20261022/End_ACK.json','outputs/r118_solver_contract_bridge_reader_coordination_20261022/End_ACK.json']:
        e=read(path);assert e['exit_code']==0 and e['actual_owned_chain_ended']
    graph=read('outputs/published_graph118_first_queries_independent_20261022/Independent_Audit.json');assert graph['status'].startswith('PASS_PRESERVED_ALL4')
    gate=read('outputs/r118_dff_paid_prefix_continuation_v2_20261022/Continuation_Readiness.json')
    assert gate['cached_native_PF_calls_per_pass']==7 and gate['complete_source_result'] is None and gate['new_PF_model_derivative_optimizer_calls']==0
    ps=subprocess.run(['powershell.exe','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -match '(f118_encoder|r118_solver_contract|check_r118_dff)' } | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Depth 3"],capture_output=True,text=True,check=True,timeout=30)
    active=json.loads(ps.stdout) if ps.stdout.strip() else []
    assert not active,'Do not close while a relevant owner remains live'
    put(O/'Fresh_Process_Closure.json',dict(at_utc=now,matching_actual_python_owners=active,scope='Current three encoder arms/root and solver bridge/cache gates; fresh full command inspection.'))
    results=dict(at_utc=now,status='COMPLETE_INDEPENDENT_FEATURE_AND_READOUT_AUDITS_FIXED_GATE_FAIL',models=models,
        teacher_exact_action={k:v['equal_world_exact_action'] for k,v in rr['results'].items()},
        numeric_teacher_exact_action={k:v['equal_world_exact_action'] for k,v in nr['results'].items()},
        primary_gate=rr['private_primary_gate'],predeclared_threshold=rr['threshold_from_strongest_numeric_and_same_base'],
        historical_private_training_overlap='Readout HELD excludes readout FIT only; original private adapter may have trained on these worlds. Historical development, not unused confirmation.',
        new_graph_first_query_UV=[dict(case_id=r['case_id'],after_UV=r['strict_all118_fields']['UV'],after_OV=r['strict_all118_fields']['OV']) for r in graph['rows']],
        graph_scope='Four author-native FIRST generator-voltage queries, not full policy or same-actuator comparison.',
        solver_bridge=bridge,paid_DFF_prefix=dict(cached_native_calls=7,next_missing=gate['next_missing'],full_result='UNKNOWN'),
        actual_original_LLM_episode=dict(initial_UV=56,final_UV=7,strict_OV=2,commits=17,full_DFF_contrast='UNKNOWN'),
        total_current_body_forward_returns=sum(m['actual_costs']['body_forward_returns'] for m in models.values()),
        current_model_load_returns=sum(m['actual_costs']['model_load_returns'] for m in models.values()),
        graph_PF_primary_and_first_replay_calls='4 + 4',bridge_PF_primary_and_first_replay_calls='1 + 1',
        no_old50_or_completed_physics_repeated=True,new_optimizer_training_generation_calls=0,
        costs_note='GPU workflow times overlap across arms; remote generation contains forward time; old preparation/data/training/failure costs remain separately paid and are not zero.',
        all6_final_goals='OPEN',current_GPU_assignments=0)
    put(O/'Verified_Results_And_Costs.json',results)
    resume=dict(at_utc=now,status='ALL_CURRENT_OWNERS_TERMINAL_NO_GPU_NO_TIMER',all6_final_goals='OPEN',
        verified_results=(O/'Verified_Results_And_Costs.json').relative_to(R).as_posix(),
        stopped='Fixed frozen-encoder readout fails the predeclared 80% gate. Preserve all six outputs; no pooling/kernel/seed/checkpoint/regularization rescue or automatic rollout.',
        next_tasks=[
          dict(id='G3.native118.missing_only',task='Freeze one exact missing-only DFF/source-contract frontier list with all relevant prior attempts and costs before further physics. Saved original DFF warm/cold uses seven paid returns then stops at logical call7; no accepted commit or complete DFF score yet.',evidence='outputs/r118_dff_paid_prefix_continuation_v2_20261022/Continuation_Readiness.json'),
          dict(id='G3.graph118.full_policy',task='Finish a source-faithful full GraphAgent transition/cursor/stopping port and cold/ownership/first-new-replay protocol. Reuse all four paid first calls. Native generator/capacitor role differs from our shunts; disclose it and do not count the first-action probe as a beaten full method.'),
          dict(id='G3.external.common118',task='Specify matched training/information/actuator/resources for trainable published controls. Existing PVs are four PV plus four diesel, but source PQ ratings/profiles are missing. Do not fabricate them or call a foreign trained checkpoint comparable.'),
          dict(id='G1.original_prefix.repair',task='Any materially new repair of the actual seven-UV/two-OV trained-controller endpoint must preserve 17 committed operations, eight remaining slots, original stock/no-refund/full costs, correct internal Q-limit mask and strict normal-band outcome. No old budget reset or automatic physical launch.')],
        preservation=['Original no-op bridge launcher and typed cache-gate error preserved; additive repairs made no repeated science.',
          'Original model/parser/controller/network/locked bank and both DSE branch obligations remain unchanged.',
          'No current live sole-result dependency: do not create a waiting timer or recurring monitor.'],
        latest_verified_GitHub='be9d621813d248e1d414c351cb4cb7c06082baea',publication='This closure/new code/proofs pending compact screened publication.')
    put(O/'Current_Resume.json',resume)
    text='''# Verified 118-bus progress — 22 October 2026

All three T4 studies finished, their data were preserved, and their runtimes were released. Independent feature and fixed-readout equation audits passed.

| Fixed linear action readout | Exact teacher action on 96 development observations |
| --- | ---: |
| Same-current numerical control | 75.00% (72/96) |
| Original trained 0.5B adapter features | 71.875% (69/96) |
| Public 1.5B features | 64.583% (62/96) |
| Public 0.5B features | 59.375% (57/96) |

The trained adapter improves over its same-base representation by 12.5 percentage points, but is below the numerical control. The predeclared primary threshold was 80%; this fixed intervention failed and stops. Both linear and RBF outputs are retained, with no kernel or checkpoint selection. Historical private-adapter training may include these evaluation worlds, so this is development evidence, not unseen generalization. These are action-label results, not UV reduction results.

Actual cost: 2,594 body forward returns, six model loads, zero generation/backward/optimizer/PF calls in this encoder experiment. Every primary feature had an exact fresh-load counterpart. Prior training, preparation and failures remain separately paid. GPU workflow times overlap and must not be added as intrinsic inference latency.

The authorized DFF solver-contract bridge completed one new 80-iteration-contract call and one first independent replay. All returned numerical fields matched exactly; KCL residual was 8.52e-14. The old 50-iteration record was preserved. This certifies this one input only. An initial launcher omitted --execute and entered no science; its log and the additive argument repair are retained.

The unchanged DFF can now reconstruct seven paid calls in identical warm/cold source execution, then stops at the next missing exact query. Its final result remains unknown. A saved-cache wrapper error initially turned an AttributeError into apparent PF failures; that zero-physics software result is explicitly invalidated and preserved. The corrected reader unwraps the bridge NET container and makes unexpected cache errors fatal. No physics was repeated by either cache check.

Four new first actions from the published graph policy were independently checked on the four severe 118-bus roots. UV stayed 56, 58, 57 and 55. The requested generator was at its reactive-power ceiling, explaining this particular ineffective voltage-reference change. This is not a full graph-policy score or proof that all generator controls fail. Its native generator/capacitor actions differ from our positive-shunt actions.

The real original Reflection-v4 episode remains 56 to 7 UV, with two strict overvoltage buses, after 17 committed operations. Its exact paid terminal NET was recovered without a new solve. Eight original operation slots remain for any separately justified repair. Full DFF/external comparison and zero-UV, LLM superiority and security remain open.

Measured old workflow bottleneck: approximately 47 of 53 local minutes were spent awaiting model responses and transport/preservation, while remote generation sections totalled about 4.7 minutes. Those times overlap. This identifies experimental orchestration overhead; it is not a deployment-speed claim.

Next: close a complete exact missing-query/source-contract list for the original DFF comparison, and complete published full-policy transition/cursor integration before another bounded performance campaign. No current GPU or waiting timer remains. Private raw NETs and weights stay local; compact public proofs are not a complete raw backup.
'''
    (O/'Results_And_Next_Decision.md').write_text(text,encoding='utf-8')
    summary='## Three-GPU test and authorized solver bridge complete — '+now+'\n\nAll three actual T4 arms ended/released/preserved. Feature and readout audits PASS; private 0.5B linear action accuracy 71.875%, public same-base 59.375%, public1.5B64.583%, numeric75%; fixed80% gate FAIL/STOP. Historical private training overlap retained; not UV or unused-confirmation results. New native80 solver bridge1primary+1first replay PASS, allfielddelta0; old50record kept. Exact DFF cached source now advances7paid calls, then nextquery UNKNOWN; no complete DFF/head-to-head score. Four native published-graph first queries independently PASS but no UV change; full external policy still pending. All6goals OPEN; no owned job/GPU/timer. Resume outputs/f118_actual_completion_handoff_20261022/Current_Resume.json.\n\n'
    for path in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        target=R/path;old=target.read_text('utf-8');target.write_text(summary+old,encoding='utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n\n'+text+'\nSaved at '+now+'\n')
    registry=read('outputs/research_tasks_20261014/Tasks.json')
    registry.update(latest_verified_update=now,latest_resume=(O/'Current_Resume.json').relative_to(R).as_posix(),current_GPU_assignments=0,current_owned_jobs=[],all6_final_goals='OPEN')
    additions=[('G4','G4.f118_encoder_readout_20261022','Complete three actual frozen-encoder arms, cold feature audit and six fixed readout math checks; failed 80% primary gate retained.','outputs/f118_actual_completion_handoff_20261022/Verified_Results_And_Costs.json'),('G3','G3.native80_contract_bridge_20261022','Complete the specifically authorized one-input native80 bridge and first independent replay; no blanket other-contract equivalence.','outputs/r118_solver_contract_bridge_independent_20261022/Independent_Audit.json')]
    for goal,tid,description,evidence in additions:
        t=next(t for t in registry['tasks'] if t['checklist_id']==goal);subs=t.setdefault('subtasks',[])
        assert not any(s['id']==tid for s in subs);subs.append(dict(id=tid,completed=True,description=description,evidence=evidence,verified_at_save=now));t['completed']=False
    (R/'outputs/research_tasks_20261014/Tasks.json').write_text(json.dumps(registry,indent=2,ensure_ascii=False),encoding='utf-8')
    for path in ['outputs/f118_encoder_readout_handoff_20261022/Current_Resume.json','outputs/reflection118_chronological_handoff_20261022/Current_Resume.json','outputs/full_system_comparison_20261021/Current_Resume.json']:
        obj=read(path);obj['newest_active_continuation']=(O/'Current_Resume.json').relative_to(R).as_posix();obj['superseded_operational_status_at_utc']=now
        (R/path).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
    put(O/'Closed_Receipt_Manifest.json',dict(members={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()}))
    print(json.dumps(dict(status='SAVED_VERIFIED_CLOSURE',body_forwards=results['total_current_body_forward_returns'],GPU_assignments=0,all6_goals='OPEN')))
if __name__=='__main__':main()
