"""Control-only file-routing continuation; all scientific sources/settings unchanged."""
import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'work'
def emit(name,source):
    ast.parse(source);p=W/name;assert not p.exists();p.write_text(source,encoding='utf-8')
owner=(W/'run_public_size_u61_colab.py').read_text()
assert "ROOT/'work/public_size_setup_remote.py'" in owner
owner=owner.replace("ROOT/'work/public_size_setup_remote.py'","ROOT/'work/public_size_u61_setup_remote.py'")
owner=owner.replace("PREP=R/'public_size_u61_preparation'","PREP=R/'public_size_u61_v2_preparation'")
owner=owner.replace("R/'public_size_u61_execution'","R/'public_size_u61_v2_execution'")
emit('run_public_size_u61_colab_v2.py',owner)
reader=(W/'audit_public_size_u61_outputs.py').read_text().replace("R/'public_size_u61_preparation'","R/'public_size_u61_v2_preparation'").replace("R/'public_size_u61_execution'","R/'public_size_u61_v2_execution'").replace("R/'public_size_u61_external_audit'","R/'public_size_u61_v2_external_audit'")
emit('audit_public_size_u61_outputs_v2.py',reader)
handoff=(W/'continue_public_size_u61_joint_audit.py').read_text().replace('run_public_size_u61_colab.py','run_public_size_u61_colab_v2.py').replace("R/'public_size_u61_execution'","R/'public_size_u61_v2_execution'").replace("R/'public_size_u61_handoff'","R/'public_size_u61_v2_handoff'").replace('public_size_u61_external_audit','public_size_u61_v2_external_audit').replace('audit_public_size_u61_outputs.py','audit_public_size_u61_outputs_v2.py')
emit('continue_public_size_u61_joint_audit_v2.py',handoff)
