"""Read ALL saved checkpoint dependencies/history once, never resume an owner.

Coalesces append-only prefix checks without weakening byte/source/hash/receipt/
cursor/RNG boundaries. Does NOT certify all unselected physical outcomes or
policy decisions. Old missing26th full state and the all-four gate stay UNKNOWN.
"""
import copy,hashlib,json,os,pickle,random,struct,time
from pathlib import Path
import numpy as np,pandapower as pp
from full_receding_paid_campaign_20261015 import R,B as OLD,DEP,pin,read,put,sha
import paid_receding_commit_and_history_v1 as saved
from receding_paid_runtime_v2 import DEPENDENCY_KEY,restore_dependency_prefix
from dynamic_actual_mask_guidance_v1 import current_inputs,identity
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from bounded_paid_lookahead_physics_20261014 import load_after
from exact_input_pair_equality_v1_20261018 import same_inputs
from candidate_process_evidence_utils import frozen_checks
B=R/'outputs/receding_checkpoints_linear_audit_20261018'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(b):return hashlib.sha256(b).hexdigest()
CHECK_FIELDS=('verdict','original_score','after_reference','attributed_PF_calls','attributed_solver_seconds','actual_measured_receipt')
def projection(record):return digest(canon({k:record.get(k) for k in CHECK_FIELDS}))

class HistoryPrefixes:
    def __init__(self,p):
        self.p=p;self.path=OLD/'actual/Complete_Runtime_History.bin';self.stream=self.path.open('rb')
        self.hash=hashlib.sha256();self.previous='0'*64;self.records=0;self.last=None;self.selected=None
    def advance(self,anchor):
        assert R/anchor['path']==self.path and anchor['source_anchor']==self.p['runtime_source_sha256'] and anchor['input_anchor']==self.p['warm_dependency_sha256']
        assert self.stream.tell()<=anchor['bytes']<=self.path.stat().st_size<=self.p['maximum_history_bytes']
        while self.stream.tell()<anchor['bytes']:
            header=self.stream.read(8);assert len(header)==8;size=struct.unpack('<Q',header)[0]
            assert 0<size<=64*1024**2 and self.stream.tell()+size<=anchor['bytes']
            raw=self.stream.read(size);record=json.loads(raw)
            assert record['previous']==self.previous and record['source_anchor']==anchor['source_anchor'] and record['input_anchor']==anchor['input_anchor']
            self.hash.update(header+raw);self.previous=digest(raw);self.records+=1;self.last=record
            if record['event']=='complete_paid_receding_decision':
                branch=record['payload'];chosen=branch['plan']['selected'];assert chosen is not None
                self.selected=next(m for m in branch['query_messages'] if m['parent']==branch['root'] and m['aid']==chosen['first'])
        assert self.hash.hexdigest()==anchor['sha256'] and self.previous==anchor['last_record_sha256'] and self.records==anchor['records']
        assert self.last['event']=='actual_receding_first_commit'
        return self.last['payload'],self.selected

def main():
    B.mkdir(exist_ok=False);started=time.perf_counter()
    put(B/'Protocol.json',{'role':'LINEAR_READONLY_ALL25_SAVED_COMPLETE_CHECKPOINT_PREFIX_AUDIT','bound_seconds':600,
        'source_sha256':sha(Path(__file__)),'equality_source_sha256':sha(R/'work/exact_input_pair_equality_v1_20261018.py'),
        'scope':'ALL actual saved checkpoint requests in original order, complete raw state/receipt/RNG/cursor/history/scientific prefix/cost/context boundaries. No future suffix leakage or checkpoint26 inference.',
        'preservation_equivalence':'Original prefix byte/hash/source/closed-return checks retained; coalesce one monotone scientific/history pass. Cross-check reconstructed maps against original restore_dependency_prefix at first, first-new-query and first-exception saved prefixes.',
        'not_checked':'All unchosen physical outputs, all policy/ranking/forecast equations or full trajectories; all-four gate remains UNKNOWN.',
        'science_calls_allowed':0,'original_science_and_reader_budgets_not_extended':True})
    put(B/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__))})
    p=read(OLD/'Protocol.json');pin(p);protocol=sha(OLD/'Protocol.json');result=read(OLD/'actual/Result.json');manifest=read(OLD/'actual/Closed_Manifest.json')
    requests=result['checkpoint_requests'];assert len(requests)==25 and result['scientific_status']=='TERMINAL_PARTIAL'
    assert not (OLD/'actual/checkpoints/26').exists()
    warm=read(DEP/'Paid_Warm_Dependencies.json');assert sha(DEP/'Paid_Warm_Dependencies.json')==p['warm_dependency_sha256']
    cache_hash={k:digest(canon(v)) for k,v in warm['cache'].items()};cache_projection={k:projection(v) for k,v in warm['cache'].items()}
    forecast_hash={k:digest(canon(v)) for k,v in warm['existing_numeric_forecasts'].items()}
    cumulative_cache=hashlib.sha256();cumulative_forecast=hashlib.sha256()
    contexts={};seen_contexts={};intents={};returns={};exceptions={};closed_occurrences=0;prefix='0'*64;filehash=hashlib.sha256();offset=0;capsules_bytes=0
    counters={};solver_seconds=0.;new_queries=replays=0;new_forecasts=reused_forecasts=0;commits=[];checkpoint_proofs=[];baseline_roles=set();last_preservation=last_compile=-1.
    history=HistoryPrefixes(p)
    for entry in p['warm_numeric_contexts']:
        path=R/entry['path'];assert sha(path)==entry['sha256']
        with np.load(path,allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
        assert identity(c)==entry['identity'];contexts[entry['identity']]=c
    forbidden=[]
    def no_science(*a,**k):forbidden.append(True);raise AssertionError('Read-only checkpoint audit cannot perform science')
    for name in ('runpp','runopp','rundcpp','rundcopp'):setattr(pp,name,no_science)
    np.linalg.solve=no_science
    with (OLD/'actual/scientific.jsonl').open('rb') as stream,(OLD/'actual/capsules.bin').open('rb') as pack:
        for line in stream:
            assert time.perf_counter()-started<600,'Fixed new analysis bound, no extension'
            e=json.loads(line);assert e['previous_sha256']==prefix and e['protocol_sha256']==protocol
            d=e['data'];name=e['event']
            if name=='PF_intent':
                pid=d['identity'];assert pid not in intents;intents[pid]=d
                capsules_bytes=max(capsules_bytes,d['before']['encoded_offset']+d['before']['encoded_bytes'])
                if d['context']['phase']=='NEW_PRIMARY_QUERY':new_queries+=1
                elif d['context']['phase']=='CONTINUOUS_SELECTED_COMMIT_REPLAY':replays+=1
                else:raise AssertionError('Unknown scientific role')
            elif name in ('PF_return','PF_exception'):
                pid=d['PF_id'];assert pid in intents and pid not in returns and pid not in exceptions
                (returns if name=='PF_return' else exceptions)[pid]=digest(canon(d));solver_seconds+=d['seconds']
                capsules_bytes=max(capsules_bytes,d['after']['encoded_offset']+d['after']['encoded_bytes'])
            elif name=='receding_branch_initialized':capsules_bytes=max(capsules_bytes,d['initial_net']['encoded_offset']+d['initial_net']['encoded_bytes'])
            elif name=='every_query_receipt_closed_before_more_science':
                record=d['record'];m=record.get('actual_measured_receipt')
                if m:
                    pid=m['PF_id'];assert digest(canon(m))==(returns if m['outcome']=='RETURNED' else exceptions)[pid]
                    c=intents[pid]['context'];assert c['phase']=='NEW_PRIMARY_QUERY' and c['action_key']==d['aid']
                    key=c['point']+'|'+d['aid'];proj=projection(record)
                    if key in cache_hash:assert cache_projection[key]==proj
                    else:
                        cache_projection[key]=proj;cache_hash[key]=digest(canon(record));cumulative_cache.update(canon([key,cache_hash[key]]))
                    closed_occurrences+=1
            elif name=='second_causal_context_and_forecasts':
                for row in d['rows']:
                    key=d['context_identity']+'|'+action_key(row);h=digest(canon(row['ordering_forecast']))
                    if key in forecast_hash:assert forecast_hash[key]==h;reused_forecasts+=1
                    else:forecast_hash[key]=h;new_forecasts+=1;cumulative_forecast.update(canon([key,h]))
            elif name=='current_numeric_context_saved':
                path=OLD/'actual/contexts'/(d['identity']+'.npz');assert sha(path)==d['sha256']
                with np.load(path,allow_pickle=False) as f:c={k:f[k].copy() for k in f.files}
                assert identity(c)==d['identity'];contexts[d['identity']]=c
                seen_contexts[d['identity']]={'identity':d['identity'],'path':str(path.relative_to(R)),'sha256':d['sha256']}
            elif name.startswith('numeric_'):counters[name]=counters.get(name,0)+1
            elif name=='actual_receding_first_commit':commits.append(d)
            elif name=='complete_receding_checkpoint_ACK':
                idx=len(checkpoint_proofs);assert d==requests[idx]
                state=saved.restore(R/d['checkpoint'],d['receipt']);dep=state['paid_query_registry'][DEPENDENCY_KEY]
                assert state['protocol_sha256']==protocol and state['absolute_deadline_utc']==d['original_deadline_utc']
                assert point_key(state['net'],state['cursor'])==d['expected_point_key']
                assert dep['scientific_journal_path']==str((OLD/'actual/scientific.jsonl').relative_to(R)) and dep['scientific_journal_bytes']==offset and dep['last_scientific_event_sha256']==prefix
                assert dep['capsules_bytes']==capsules_bytes and dep['closed_new_receipt_occurrences']==closed_occurrences
                assert dep['source_anchors']==d['source_anchors'] and d['source_anchors']=={'runtime':p['runtime_source_sha256'],'worker':sha(R/'work/full_receding_paid_campaign_20261015.py'),'protocol':protocol}
                assert dep['warm_dependency_path']==str((DEP/'Paid_Warm_Dependencies.json').relative_to(R)) and dep['warm_dependency_sha256']==p['warm_dependency_sha256']
                assert dep['warm_numeric_contexts']==p['warm_numeric_contexts'] and dep['current_numeric_contexts']==[seen_contexts[k] for k in sorted(seen_contexts)]
                assert set(intents)==set(returns)|set(exceptions) and not set(returns)&set(exceptions)
                cost=state['costs']['actual_scientific'];nc=state['costs']['numeric']
                for field,value in [('PF_attempts',len(intents)),('PF_returns',len(returns)),('PF_exceptions',len(exceptions)),('new_query_PF_attempts',new_queries),('continuous_replay_PF_attempts',replays)]:assert cost[field]==value
                assert abs(cost['PF_seconds']-solver_seconds)<1e-8 and cost['new_model_calls']==cost['new_optimizer_steps']==0
                assert last_preservation<=cost['preservation_seconds']<=result['actual_new_costs']['preservation_seconds'];last_preservation=cost['preservation_seconds']
                assert last_compile<=nc['compile_seconds']<=result['numerical_costs']['compile_seconds'];last_compile=nc['compile_seconds']
                for field,event in [('public_derivative_attempts','public_derivative_attempt'),('public_derivative_returns','public_derivative_return'),('LU_factor_attempts','LU_factor_attempt'),('LU_factor_returns','LU_factor_return'),('LU_solve_attempts','LU_solve_attempt'),('LU_solve_returns','LU_solve_return'),('exact_context_reuses','exact_context_reused')]:assert nc[field]==counters.get('numeric_'+event,0)
                assert nc['RHS_columns']==118*nc['LU_solve_returns'] and nc['new_forecasts']==new_forecasts and nc['exact_paid_forecast_reuses']==reused_forecasts
                record,selected=history.advance(state['paid_query_registry'][saved.HISTORY_KEY])
                assert record==commits[idx]['record'] and state['cursor']==record['following_cursor']
                target=load_after(selected['record']['after_reference'],pack)['net']
                assert same_inputs(state['net'],target) and saved.fields(state['net'])==saved.fields(target)
                a=current_inputs(state['net']);b=current_inputs(target)
                assert set(a)==set(b) and all(np.array_equal(a[k],b[k]) for k in a)
                # Test valid preserved RNG representations, without claiming an
                # unsaved later state or executing any later decision.
                random.setstate(state['python_rng']);np.random.set_state(state['numpy_rng'])
                assert pickle.dumps(random.getstate())==pickle.dumps(state['python_rng']) and pickle.dumps(np.random.get_state())==pickle.dumps(state['numpy_rng'])
                role='first' if idx==0 else 'first_new_query' if new_queries and 'first_new_query' not in baseline_roles else 'first_exception' if exceptions and 'first_exception' not in baseline_roles else None
                if role:
                    baseline=restore_dependency_prefix(state,warm_dependencies=warm,source_anchors=d['source_anchors'])
                    assert {k:digest(canon(v)) for k,v in baseline['cache'].items()}==cache_hash
                    assert {k:digest(canon(v)) for k,v in baseline['paid_forecasts'].items()}==forecast_hash
                    assert set(baseline['contexts'])==set(contexts) and baseline['new_scientific_calls']==0
                    baseline_roles.add(role)
                checkpoint_proofs.append({'request':d,'manifest_sha256':d['receipt']['manifest_sha256'],'raw_sha256':d['receipt']['raw_sha256'],
                    'scientific_prefix_bytes':offset,'scientific_prefix_sha256':prefix,'history_bytes':state['paid_query_registry'][saved.HISTORY_KEY]['bytes'],
                    'cache_keys':len(cache_hash),'forecast_keys':len(forecast_hash),'incremental_cache_delta_sha256':cumulative_cache.hexdigest(),'incremental_forecast_delta_sha256':cumulative_forecast.hexdigest(),
                    'all_contexts':len(contexts),'PF_attempts':len(intents),'all_cursor_caps_stock_NET_mask_RNG_cost_prefixes_verified':True})
                put(B/f'Progress_{len(checkpoint_proofs)}.json',{'verified_saved_checkpoints':len(checkpoint_proofs),'workflow_seconds':time.perf_counter()-started,'new_scientific_calls':0})
            prefix=digest(line.rstrip(b'\n'));filehash.update(line);offset+=len(line)
    history.stream.close()
    assert filehash.hexdigest()==manifest['members']['scientific.jsonl']['sha256'] and offset==manifest['members']['scientific.jsonl']['bytes']
    assert len(checkpoint_proofs)==len(requests)==25 and not forbidden
    put(B/'Fresh_Frozen_Checks.json',frozen_checks())
    report={'status':'PASS_ALL25_SAVED_COMPLETE_STATE_AND_DEPENDENCY_PREFIXES_LINEAR','checkpoints':checkpoint_proofs,
        'original_restore_function_crosschecks':sorted(baseline_roles),'scientific_journal_sha256':filehash.hexdigest(),
        'scientific_bytes_read_once':offset,'history_prefix_bytes_read_once':history.path.stat().st_size if False else checkpoint_proofs[-1]['history_bytes'],
        'missing26th_complete_state':'UNKNOWN_NOT_RECONSTRUCTED','all_four_or_full_policy_gate':'UNKNOWN',
        'new_model_PF_derivative_forecast_factor_solve_calls':0,'workflow_seconds':time.perf_counter()-started,
        'limits':'All25 saved historical states/prefixes, not live resume authorization, every unchosen physical result, all policy/ranking equations or a fresh LLM result. Source timing counters retained; no kernel latency claim.'}
    put(B/'Independent_Checkpoint_Audit.json',report)
    put(B/'Closed_Manifest.json',{'members':{str(p.relative_to(B)):sha(p) for p in B.iterdir() if p.is_file()},'new_science':0})
    print(json.dumps({'linear_checkpoint_audit':'PASS','checkpoints':25,'all4gate':'UNKNOWN','science':0}))
if __name__=='__main__':main()
