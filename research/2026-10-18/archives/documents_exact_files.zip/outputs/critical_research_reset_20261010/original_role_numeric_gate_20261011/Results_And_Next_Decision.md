# Original-role numerical gate: verified result

This new CPU diagnostic completed once and its independent audit passed. It keeps the failed same-bus receipt-acquisition route stopped. No pretrained model, GPU, PF, controller episode or old scientific call was run.

The original16,000 TRAIN identities were retained. Exact-input-connected worlds stayed in the same partition:85 FIT worlds/340 distinct world-input pairs and24 HELD worlds/96 pairs (92 unique inputs). Four HELD action tuples were absent from the FIT action vocabulary and remain counted as errors. The held partition is inspected historical development, not unused confirmation. No exact input or float32 model-input overlap crosses the partition; unknown feature symbols, contradictory labels and encoding collisions were zero.

| Fixed control | Equal-world exact teacher-action match | HELD hits/pairs |
|---|---:|---:|
| 512-tree numerical classifier |72.92%|70/96|
| One nearest current-state neighbor |65.63%|63/96|
| World-weighted action prior |25.00%|24/96|

For teacher non-null cases, the tree's equal-world bus match was90.97%, while exact bus/Q match was70.49%. Null match was82.50%. Across all96 pairs,26 tree errors comprise14 correct-bus/wrong-Q,4 wrong-bus,3 missed proposals and5 unnecessary proposals. Twelve HELD worlds contain an error;11 contain a non-null error. Four unsupported joint classes account for four errors; the remaining22 errors also occur among supported classes. No favorable subset replaces the primary denominator.

The fixed support/residual criterion is RESIDUAL_IMITATION_SUPPORT_ONLY_NO_AUTOMATIC_SCALE_LAUNCH. The95% numerical priority-stop level was not reached. This retains a narrowly justified adapted-scale question; it does not show that1.5B will learn better, that a bigger model is required, or that physical improvement is possible. These are strong declared numerical controls, not a universally strongest learner. The flat joint-class output cannot compose unseen bus/Q combinations, so a future scale study needs an equally informed factorized/candidate-conditioned numerical control as well.

One tree fit took3.645 seconds; original held scoring0.097 seconds and fresh saved-tree scoring0.092 seconds. All cold-reloaded score arrays and classes were exact. Whole execution before manifest took33.339 seconds, independent reader/frozen/archive checks13.487 seconds. Source/data preparation, isolated dependency installation and earlier data costs are separate, not free. Numerical-estimator fits1, declared arm evaluations3, fresh estimator reload prediction1; new pretrained/optimizer/PF/controller/forecast/cloud calls0.

The independently verified local archive has33 members/4,540,612 bytes, SHA256 4a29f3d194595f8693eab797a58a288ba3f9715426d808d3ec7a7774d63779b1. CRC/every-member and nine frozen original asset checks passed. The reader reconstructs inputs/partition/conditioning/weights/masks and recomputes saved-score decoding/metrics/costs; it does not refit the tree, repeat nearest-neighbor distances or independently replay estimator equations. This precise certificate is reused rather than rehashed at follow-ups.

## Deployment binding matters

The original Phase2G guided-refinement function sweeps the complete Q grid around proposed buses independently of nominal seed Q. However, the caller gives accepted DIRECT proposals higher routing priority than guided candidates, and direct failures affect failed signatures. Therefore correct-bus/wrong-Q errors cannot simply be declared harmless or erased by refinement. The same-bus menu invariance is a source property, not a measured end-to-end physical equivalence. Source: work/e/audit/phase2g_llm_guided_rescue_runner.py, llm_guided_refinement_candidates and score_with_source_priority.

This learned subrole is only original local proposed_action/null. Coordinator decisions and the later mandatory-global-proposal role are not learned here. Locally normal old labels cannot be silently repurposed as globally required proposals. Missing independent teacher PF certificates, actual deployment binding and model integration remain unresolved.

## Next decision

Preserve all fixed controls and do not tune their seed/partition/hyperparameters to improve this result. Keep the residual acquisition route stopped. Next prepare one separately prospective matched original-role adaptation protocol, including a factorized numerical command control and explicit deployed-role binding; new matched0.5B/1.5B adapters must use identical new inputs/objective. The old trained adapter is a reference, not an unbiased comparator on worlds it already saw. Actual context/mask/gradient/memory/complete optimizer-RNG-cursor preservation must pass before genuine model learning. No GPU or physical campaign is launch-ready from this diagnostic.

LLM superiority over original literal D-SE remains unachieved. Both DFF branches and unchanged selector/FULL BOTH costs, matched protected trajectories, real per-state inference, replay, full training/preparation/failure costs, attribution and unused confirmation remain required. No calibrated90% chance of discovering a winner is supported.
