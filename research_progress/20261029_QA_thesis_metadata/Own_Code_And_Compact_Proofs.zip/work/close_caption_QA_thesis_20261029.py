"""Close source-bound caption/checklist edits after actual render inspection."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,html,json,os,re,zipfile
from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from docx.table import Table
from pypdf import PdfReader
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_caption_QA_v2_20261029';B=R/'outputs/thesis_cohorts_references_20261029'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    p=R/p;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8');t.replace(p)
def media(p):
    with zipfile.ZipFile(p) as z:return Counter(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/'))
def drawings(d):
    a=[]
    for s in d.inline_shapes:
        blips=s._inline.xpath('.//a:blip');assert len(blips)==1
        rid=blips[0].get(qn('r:embed'));part=d.part.related_parts[rid]
        a.append((hashlib.sha256(part.blob).hexdigest(),s.width,s.height))
    return a
def main():
    assert not (O/'Final_Visual_And_Evidence_QA.json').exists()
    path=O/'Hannaan_Thesis_Caption_And_QA_Update.docx';base=B/'Hannaan_Thesis_Cohorts_And_References.docx';pdfpath=O/'Integrated_Thesis_QA.pdf'
    old,new=Document(base),Document(path);record=rd((O/'Integration_Record.json').relative_to(R));prior=rd((B/'Final_Visual_And_Evidence_QA.json').relative_to(R))
    assert sha(base)==prior['docx_sha256']==record['base_sha256']
    assert len(new.inline_shapes)==22 and drawings(old)==drawings(new)
    assert media(base)==media(path) and sum(media(path).values())==22
    tables=lambda d:[[[c.text for c in row.cells] for row in t.rows] for t in d.tables]
    ot,nt=tables(old),tables(new);assert len(ot)==18 and len(nt)==19
    qa_table=[['Public model','Native correct','Strict correct','Strict valid','At token cap'],['0.5B-Instruct','37/150','12/150','65/150','73/150'],['1.5B-Instruct','0/150','0/150','0/150','150/150'],['3B-Instruct','37/150','37/150','150/150','0/150']]
    assert nt.count(qa_table)==1;nt.remove(qa_table);assert nt==ot
    refs=rd('outputs/thesis_bibliography_review_20261029/Verified_Reference_Register.json')
    assert [p.text for p in new.paragraphs if re.match(r'^\[\d+\]',p.text)]==[r['normalized'] for r in refs['references']] and len(refs['references'])==35
    norm=lambda s:re.sub(r'\s+',' ',re.sub(r'\t\d+$','',s)).strip()
    before=Counter(norm(p.text) for p in old.paragraphs);after=Counter(norm(p.text) for p in new.paragraphs)
    allowed=Counter(norm(c['original']) for c in record['caption_changes']);assert len(record['caption_changes'])==29
    for c in record['caption_changes']:assert after[norm(c['integrated'])]>=1
    allowed[norm(record['old_cohort_sentence'])]+=1
    internal=(O/'Internal_Submission_Checklist.txt').read_text('utf-8').strip().split('\n\n')
    for p in internal:allowed[norm(p)]+=1
    allowed[norm(internal[0])]+=1 # removed list-of-contents entry
    allowed['Figure 7.2 Reported source of accepted actions in the 61-scenario development cohort']+=1
    lost=before-after;assert not (lost-allowed),list((lost-allowed).items())
    assert sum(lost.values())==37 and not any('Appendix C Finalisation' in p.text for p in new.paragraphs)
    for s in record['source_bindings']:assert sha(R/s['path'])==s['sha256']
    completion=rd('outputs/public_qa_completion_20261029/Verified_Completion.json')
    pdf=PdfReader(pdfpath);pg=rd((O/'Pagination_Record.json').relative_to(R));assert len(pdf.pages)==pg['pages']==130
    assert len(pg['map'])==pg['list_entries']==53
    compact=lambda s:re.sub(r'\s+','',s).lower()
    for x in pg['map']:assert compact(x['label']) in compact(pdf.pages[x['physical_page']-1].extract_text() or ''),x
    assert len(list((O/'render').glob('final-*.png')))==130
    embedded=sum(len(p.images) for p in pdf.pages);assert embedded>=22,embedded
    now=datetime.now(timezone.utc).isoformat();qarel=(O/'Final_Visual_And_Evidence_QA.json').relative_to(R).as_posix()
    detail=[5,7,41,43,45,46,47,48,49,52,54,57,58,59,60,63,78,80,82,83,84,85,86,87,88,91,92,104,105,124,125]
    visual={'status':'PASS_OVERVIEW_ALL130_AND_CHANGED_DETAIL_PAGES','all_page_contact_ranges':[[1,24],[25,48],[49,72],[73,96],[97,120],[121,130]],'detailed_pages':detail,'pdf_sha256':sha(pdfpath),
        'observations':'All22 original figures render as real images, captions legible and attached to their figures; new QA table and failure explanation fit on page105 without a trailing orphan. AppendixC is absent and contents/references remain navigable. Existing source figures retain original quality.',
        'limits':'Working thesis; title/admin/final research decisions remain open. All-page overview plus changed full-page detail, not fresh full-size review of every unchanged page.'}
    qa={'at_utc':now,'status':'PASS_REVIEWED_WORKING_THESIS_CAPTIONS_AND_QA','pages':130,'tables':19,'figures':22,'references':35,'page_bound_index_entries':53,
        'docx_sha256':sha(path),'pdf_sha256':sha(pdfpath),'all22_original_media_bytes_order_relationships_and_extents_preserved':True,'all18_prior_tables_unchanged':True,
        'permitted_changed_old_paragraph_instances':37,'all_other_old_paragraphs_preserved':True,'new_QA_table_exact_fixed_results':True,'PDF_embedded_image_occurrences':embedded,
        'visual_review':visual,'new_science':0,'source_bindings':record['source_bindings'],
        'preserved_failed_layouts':['outputs/thesis_caption_QA_20261029/Failed_Caption_Clear_Draft.docx','outputs/thesis_caption_QA_20261029/Drawing_Preservation_Repair.json'],
        'layout_failure_resolution':'Oldp.clear removed drawings; later raw drawingXML repair lacked media relationships. Both failed layouts retained. Thisv2 rebuilt from pristine approved128page base, preserved original drawing relationships and exact media; final rendering independently inspected.',
        'limitations':['No final university submission approval.','No new model advantage established by documentation.','T21 lineage and T33 comprehensive terminology review remain open.']}
    put((O/'Visual_Review_Record.json').relative_to(R),visual);put(qarel,qa)
    chunks=[]
    for e in new.element.body:
        if e.tag.endswith('}p'):
            p=Paragraph(e,new);chunks.append(('## ' if p.style.name.startswith('Heading') else '')+p.text)
        elif e.tag.endswith('}tbl'):
            v=[[c.text.replace('\n',' / ') for c in row.cells] for row in Table(e,new).rows]
            chunks.append('\n'.join(['| '+' | '.join(v[0])+' |','| '+' | '.join(['---']*len(v[0]))+' |']+['| '+' | '.join(a)+' |' for a in v[1:]]))
    (O/'Thesis_Text_And_Tables.md').write_text('\n\n'.join(chunks)+'\n','utf-8')
    index=rd((B/'Thesis_Evidence_Navigation.json').relative_to(R));index.update(at_utc=now,qa_record=qarel,current_docx=path.relative_to(R).as_posix(),pages=130)
    index['tables'].append({'caption':record['new_section_paragraphs'][2],'limitation':'One public circuit; no RAG/private adapter.1.5Bdegenerate output preserved; no size or control superiority.','records':[{'path':'outputs/public_qa_completion_20261029/Verified_Completion.json'},{'path':'outputs/public_qa_completion_20261029/Saved_Output_Diagnosis.json'}]})
    put((O/'Thesis_Evidence_Navigation.json').relative_to(R),index)
    def link(p,label):return '<a href="'+html.escape(os.path.relpath(R/p,O).replace('\\','/'),quote=True)+'">'+html.escape(label)+'</a>'
    parts=['<!doctype html><meta charset="utf-8"><title>Thesis evidence</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.5 system-ui}section{border-top:1px solid #ddd;padding:12px 0}</style><h1>Thesis evidence</h1><p>130pages,19tables,22figures,35references. Working draft; all6research goals remain open.</p>',link(path.relative_to(R),'Current Word draft')]
    for t in index['tables']:
        parts.append('<section><h2>'+html.escape(t['caption'])+'</h2><p>'+html.escape(t['limitation'])+'</p>')
        parts.extend('<p>'+link(v['path'],v['path'])+'</p>' for v in t['records']);parts.append('</section>')
    parts.append(link('outputs/thesis_integrated_evidence_20261028/Evidence_Index.html','Original figure source index'))
    (O/'Evidence_Index.html').write_text('\n'.join(parts),'utf-8')
    tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json')
    for tid,ev,msg in [('T32',qarel,'All22figure and7specifiedtable captions integrated and visually checked; source denominators, roles and limitations explicit.'),('T34',(O/'Internal_Checklist_Extraction.json').relative_to(R).as_posix(),'InternalAppendixC removed from examinable working body and contents; preserved separately. Final submission/admin approvals are not implied.')]:
        t=next(t for t in tasks['tasks'] if t['id']==tid);assert not t['status'].startswith('COMPLETE');t.update(status='COMPLETE_SCOPED_REQUIREMENT_IN_REVIEWED_WORKING_THESIS',completed_utc=now,evidence=[ev,qarel],new_scoped_progress=msg)
    tasks['completed_requirement_count']=sum(t['status'].startswith('COMPLETE') for t in tasks['tasks']);assert tasks['completed_requirement_count']==19
    tasks['updated_utc']=now;put('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    additional=['outputs/inference_numerical_admission_20261029/Software_And_Saved_Evidence_Check.json','outputs/inference_numerical_admission_20261029/tensor_hook/Result.json','outputs/common118_DER_admission_correction_20261029/Corrected_Source_Admission.json']
    for rel in ['outputs/research_resumption_20261028/Current_Resume.json','outputs/public_qa_scale_design_20261029/Exact_Resume.json']:
        x=rd(rel);x.update(at_utc=now,thesis_closed_requirements=19,thesis_requirements_complete=19,thesis_integration=qarel,thesis_evidence_index=(O/'Evidence_Index.html').relative_to(R).as_posix(),latest_engineering_and_source_evidence=additional,owned_scientific_jobs=[],GPU_assignments=[],waiting_timer=None)
        x['next_ready_work']=['Publish new own code and compact results with fresh lease/exact-byte checks.','Develop next common118 action/source/control contract using corrected4PV+4diesel roles; no invented inverter ratings.','Complete future actual-model raw-logit/behavior admission and durable stop integration under separate protocol; oldQA remains stopped.','Advance open thesis lineage/cost/RAG claims from exact sources; do not infer missing historical identities.']
        put(rel,x)
    x=rd('outputs/research_tasks_20261014/Tasks.json');x.update(updated_at_utc=now,thesis_documentation_requirements_complete=19,latest_verified_thesis=qarel,latest_engineering_and_source_evidence=additional);put('outputs/research_tasks_20261014/Tasks.json',x)
    record.update(status='COMPLETE_REVIEWED_WORKING_DRAFT',pages=130,qa=qarel,T32='COMPLETE_SCOPED',T34='COMPLETE_SCOPED');put((O/'Integration_Record.json').relative_to(R),record)
    msg='19/35 thesis requirements complete: T32 captions and T34 removal of internalAppendixC independently preserved/rendered/reviewed in130pages/19tables/22figures/35refs. Fixed publicQA complete/auditPASS: native37/0/37 of150;1.5B repeated-token operationalfailure,3Bformatvalid150but no accuracygain. All3T4sreleased/allownersended. New inferenceadmission10software+5realCPUhook checksPASS, no actualpretrained integration; oldfailurecauseUNKNOWN. Corrected all4federationroots:4PV+4diesel, missingratings; prior falsePVabsence report retained/superseded. Zero newmodel/PF/training from these followups. All6goalsOPEN; no timer or ready GPU campaign.'
    header='## Reviewed thesis and completed QA/source findings — '+now+'\n\n'+msg+'\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text(header+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+msg+'\n')
    print(json.dumps({'status':qa['status'],'pages':130,'thesis_requirements_complete':19,'new_science':0}))
if __name__=='__main__':main()
