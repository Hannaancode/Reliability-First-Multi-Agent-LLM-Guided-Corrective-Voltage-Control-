"""Durable local-ACK barrier and immutable, bounded transfer packets."""
from pathlib import Path
import hashlib, io, json, os, time, zipfile

def sha(b): return hashlib.sha256(b).hexdigest()
def encoded(v): return json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def write_once(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
def json_once(path, value): write_once(path, encoded(value))
def read(p): return json.loads(Path(p).read_text('utf-8'))

def wait_for_checkpoint_ack(transfer, stage, seconds):
    transfer.mkdir(parents=True, exist_ok=True)
    ordinal = len(list(transfer.glob('request_*.json')))
    request = transfer / f'request_{ordinal:03d}.json'
    json_once(request, {'number': ordinal, 'stage': stage})
    began = time.monotonic()
    while True:
        ack = transfer / f'ack_{ordinal:03d}.json'
        if ack.exists():
            value = read(ack); descriptor = read(transfer / f'packet_{ordinal:03d}' / 'descriptor.json')
            assert value['number'] == ordinal and value['sha256'] == descriptor['sha256']
            assert value['all_bytes_preserved_locally'] is True
            return
        if time.monotonic() - began >= seconds: raise TimeoutError('Local evidence acknowledgement did not arrive; no next question')
        time.sleep(.1)

def publish_packet(study, transfer, number, terminal=False, exit_code=None, cause=None):
    """Caller proves the worker is paused at its barrier or has exited."""
    destination = transfer / f'packet_{number:03d}'
    destination.mkdir(parents=True, exist_ok=False)
    members = {}
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(study.iterdir()):
            if p.is_file() and not p.name.endswith('.tmp'):
                b = p.read_bytes(); members[p.name] = {'bytes': len(b), 'sha256': sha(b)}; z.writestr(p.name, b)
    raw = stream.getvalue(); parts = []
    for i, offset in enumerate(range(0, len(raw), 2 * 1024 * 1024)):
        block = raw[offset:offset + 2 * 1024 * 1024]; name = f'part_{i:03d}.bin'
        write_once(destination / name, block); parts.append({'name': name, 'bytes': len(block), 'sha256': sha(block)})
    descriptor = {'number': number, 'bytes': len(raw), 'sha256': sha(raw), 'parts': parts, 'members': members,
        'terminal': terminal, 'actual_child_exit_code': exit_code, 'stop_cause': cause}
    json_once(destination / 'descriptor.json', descriptor)
    return descriptor

def accept_packet(descriptor, blocks, local):
    """Reject path traversal, changed artifacts and changed journal prefixes before ACK."""
    raw = b''.join(blocks)
    assert len(blocks) == len(descriptor['parts'])
    for b, part in zip(blocks, descriptor['parts']): assert len(b) == part['bytes'] and sha(b) == part['sha256']
    assert len(raw) == descriptor['bytes'] and sha(raw) == descriptor['sha256']
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert z.testzip() is None and len(set(z.namelist())) == len(z.namelist())
        assert set(z.namelist()) == set(descriptor['members'])
        checked = {}
        for name, m in descriptor['members'].items():
            assert name not in ('', '.', '..') and '/' not in name and '\\' not in name and ':' not in name
            b = z.read(name); assert len(b) == m['bytes'] and sha(b) == m['sha256']; checked[name] = b
            p = local / 'study' / name
            if p.exists():
                previous = p.read_bytes()
                assert b.startswith(previous) if name == 'journal.jsonl' else b == previous
        folder = local / 'packets' / f"packet_{descriptor['number']:03d}"
        folder.mkdir(parents=True, exist_ok=False)
        write_once(folder / 'packet.zip', raw); json_once(folder / 'descriptor.json', descriptor)
        for name, b in checked.items():
            p = local / 'study' / name
            if not p.exists(): write_once(p, b)
            elif name == 'journal.jsonl' and p.read_bytes() != b:
                tmp = p.with_suffix('.tmp'); write_once(tmp, b); tmp.replace(p)
    return {'number': descriptor['number'], 'sha256': descriptor['sha256'], 'all_bytes_preserved_locally': True}
