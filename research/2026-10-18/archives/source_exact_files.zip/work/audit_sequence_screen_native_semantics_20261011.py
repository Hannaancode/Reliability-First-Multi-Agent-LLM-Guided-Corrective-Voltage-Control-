"""Static gate for proposed cheap sequence screens; never execute a solver."""
import ast
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/sequence_screen_native_semantics_20261011'
assert not OUT.exists(), 'Preserve any prior review; no duplicate'
OUT.mkdir()
started=time.perf_counter()
paths={
 'initial':'work/e/pack/scripts/phase2d_iterative_blackboard_v0.py',
 'trial_commit':'work/e/audit/phase2g_multiagent_llm_runner.py',
 'action_verifier':'work/e/audit/phase2g_rescue_runner.py',
 'refinement':'work/e/audit/phase2g_llm_guided_rescue_runner.py',
 'portfolio':'work/e/audit/run_reflection_v4_safety_envelope.py',
}
texts={k:(ROOT/p).read_text('utf8') for k,p in paths.items()}
trees={k:ast.parse(s) for k,s in texts.items()}
pins={paths[k]:hashlib.sha256((ROOT/paths[k]).read_bytes()).hexdigest() for k in paths}
def write(name,v):
 with (OUT/name).open('x',encoding='utf8') as f:
  json.dump(v,f,indent=2);f.flush();os.fsync(f.fileno())
write('Protocol.json',{
 'declared_at_utc':datetime.now(timezone.utc).isoformat(),
 'fixed_questions':['Exact native initial/trial/commit solver keywords and action/cap conventions.',
                    'Do native solver/verifier functions explicitly enforce declared slack active-power ceiling?',
                    'Which proposed cheap negative tests can legitimately exclude an improving protected native sequence?'],
 'source_sha256':pins,'analysis_only':True,'new_model_PF_optimizer_controller_forecast_solver_converter_calls':0,
 'no_running_model_sources_or_settings_changed':True,
})
def function(group,name):
 return next(n for n in trees[group].body if isinstance(n,ast.FunctionDef) and n.name==name)
def scalar(group,name):
 n=next(n for n in trees[group].body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
 return ast.literal_eval(n.value)
def pf_keywords(group):
 f=function(group,'run_pf')
 calls=[n for n in ast.walk(f) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='runpp']
 assert len(calls)==1
 return {k.arg:ast.literal_eval(k.value) for k in calls[0].keywords}
initial=pf_keywords('initial');trial=pf_keywords('trial_commit')
assert initial=={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':50}
assert trial=={'algorithm':'nr','init':'auto','enforce_q_lims':True,'max_iteration':80,'calculate_voltage_angles':True}
q=scalar('refinement','Q_SWEEP');cap=scalar('action_verifier','MAX_ABS_Q_PER_BUS')
assert q==[25.,50.,75.,100.,125.,150.,200.,250.,300.] and cap==450.
apply=function('action_verifier','apply_action');verify=function('action_verifier','verify_action')
create=[n for n in ast.walk(apply) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='create_shunt']
assert len(create)==1
action_fields={k.arg:ast.unparse(k.value) for k in create[0].keywords}
assert action_fields['q_mvar']=='-q_abs' and action_fields['p_mw']=='0.0'
native_names={n.value for f in [function('initial','run_pf'),function('trial_commit','run_pf'),verify]
              for n in ast.walk(f) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
assert 'max_p_mw' not in native_names and 'min_p_mw' not in native_names
selector=function('portfolio','choose_safety_envelope')
functions={'initial_run_pf':function('initial','run_pf'),'trial_commit_run_pf':function('trial_commit','run_pf'),
           'apply_action':apply,'verify_action':verify,'choose_safety_envelope':selector}
function_pins={k:hashlib.sha256(ast.dump(n).encode()).hexdigest() for k,n in functions.items()}
result={
 'completed_at_utc':datetime.now(timezone.utc).isoformat(), 'source_contract_checks_passed':True,
 'source_sha256':pins,'function_AST_sha256':function_pins,
 'initial_solver':initial,'trial_and_commit_solver':trial,
 'native_positive_schema_Q_grid':q,'native_added_named_shunt_per_bus_cap':cap,
 'action_create_shunt_keywords':action_fields,
 'original_source_HARD_OV':scalar('action_verifier','HARD_OV'),
 'prospective_common_upper_remains':1.05+1e-8,
 'original_source_and_common_guard_must_be_reported_separately':True,
 'explicit_declared_slack_P_bounds_in_inspected_native_solver_verifier_functions':False,
 'scope_of_P_bound_finding':'Static exact function coverage only; no new PF run or blanket claim about every library convention. A certificate adding a declared P ceiling needs proof it is part of the target feasibility set.',
 'rejected_negative_tests':[
  'A local Jacobian/Taylor model is infeasible: not an AC outer-set certificate.',
  'A sufficient convex restriction is infeasible: cannot exclude feasible points outside that inner set.',
  'A local optimizer fails or times out: not a certificate of no better allocation.',
  'A stricter OPF imposes generator/slack/thermal/angle restrictions not present in native target semantics: cannot exclude the native voltage-recovery task.',
  'One total-restoration formulation is infeasible: cannot exclude a smaller incremental UV improvement.',
  'A continuous terminal allocation is feasible: does not certify discrete Q-grid, irreversible guarded intermediate steps or actual NR convergence.',
 ],
 'only_valid_global_negative_route':'Independently prove a superset of all target-admissible native allocations/sequences, then verify a numerical/interval dual lower bound on unavoidable terminal UV that reaches the corresponding full D-SE UV count. Anything weaker leaves improvement UNKNOWN.',
 'next_action':'Define a source-consistent outer relaxation OR a bounded paid numerical sequence opportunity study; neither is currently implemented/certified or launched by this analysis.',
 'new_model_PF_optimizer_controller_forecast_solver_converter_calls':0,
 'HELD_model_outputs_inspected':0,'seconds':time.perf_counter()-started,
}
write('Results.json',result)
write('Progress_Entry.json',{
 'event_id':'sequence_screen_native_semantics_review_20261011',
 'method':'Static exact frozen solver/action/verifier/selector binding for proposed cheap opportunity and impossibility screens; no original source edits or calls.',
 'result':'Source checks PASS: Q-limits enabled, initial50/trial-commit80 NR iterations, original nine Q values, added named-shunt cap450, zero-P negative-Q insertion. Inspected native functions do not explicitly impose declared slack P bounds. Six invalid negative-test routes rejected.',
 'improvements':'Before: a generic optimizer or linear-model failure could be mistaken for a conclusive no-improvement result. After: exact inclusion and incremental-UV requirements are explicit, preventing that false early stop.',
 'limitations':'No relaxation, dual certificate, native continuation equivalence, new counterfactual physical outcome or LLM benefit is established. Source coverage is static and explicitly bounded.',
 'decision':result['next_action'],
 'sources':['outputs/critical_research_reset_20261010/sequence_screen_native_semantics_20261011/Protocol.json','outputs/critical_research_reset_20261010/sequence_screen_native_semantics_20261011/Results.json'],
})
print(json.dumps(result))
