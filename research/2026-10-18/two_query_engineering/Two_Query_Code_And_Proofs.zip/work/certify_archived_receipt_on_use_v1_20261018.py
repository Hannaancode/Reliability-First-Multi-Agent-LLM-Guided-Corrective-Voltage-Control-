"""Independently check one exact causal old receipt BEFORE any execution reuse.

Uses the unchanged saved-result verifier from the full reader, not a nonlinear
PF call. This is receipt validity, never old full-policy performance or a new
owner's permission to execute a missing identity.
"""
import copy,hashlib,json,os,time
from pathlib import Path
import pandapower as pp
import audit_full_receding_linear_composed_v4_20261018 as source_reader
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from shared_original_serving_action_domain_v1 import build_current_domain
from bounded_paid_lookahead_physics_20261014 import canon
R=Path(__file__).resolve().parents[1]
def digest(b):return hashlib.sha256(b).hexdigest()
def read_line(path,reference):
    with path.open('rb') as f:f.seek(reference['offset']);raw=f.read(reference['bytes'])
    assert len(raw)==reference['bytes'] and digest(raw)==reference['sha256']
    return json.loads(raw)
def certify(net,cursor,row,entry,*,runner,zones,ack_path):
    started=time.perf_counter();key=point_key(net,cursor)+'|'+action_key(row)
    assert key==entry['key']
    old=R/'outputs/full_receding_paid_campaign_20261015';journal=old/'actual/scientific.jsonl'
    protocol=digest((old/'Protocol.json').read_bytes());p=source_reader.read(old/'Protocol.json');source_reader.pin(p)
    assert protocol==entry['source_protocol_sha256']
    assert source_reader.read(old/'actual/Closed_Manifest.json')['members']['scientific.jsonl']['sha256']==entry['source_journal_sha256']
    source=read_line(journal,entry['intent_reference']);assert source['event']=='PF_intent' and source['protocol_sha256']==protocol
    intent=source['data'];assert intent==entry['intent'] and intent['kwargs']==p['solver_kwargs']
    ref=entry['record_reference'];event=read_line(journal,{'offset':ref['journal_offset'],'bytes':ref['journal_bytes'],'sha256':ref['journal_line_sha256']})
    assert event['event']=='every_query_receipt_closed_before_more_science' and event['protocol_sha256']==protocol
    message=event['data'];record=message['record'];m=record['actual_measured_receipt']
    assert m['PF_id']==intent['identity']==ref['PF_id'] and digest(canon(m))==ref['PF_close_data_sha256']
    assert intent['context']['phase']=='NEW_PRIMARY_QUERY' and intent['context']['point']==key.rsplit('|',1)[0]
    # Membership/stock/Q/cap/protection use the actual current state. An old
    # source namespace or old control decision is never supplied as a label.
    domain=build_current_domain(net,cursor,runner=runner,zones=zones)
    assert row in domain['all_declared_original9Q_ordinary_and_owned_joint_identities']
    current=domain['expanded_cursor_for_separately_fixed_future_protocol']
    node={'net':net,'cursor':current,'immutable_point_key':point_key(net,current)}
    assert node['immutable_point_key']==intent['context']['point']
    calls=[]
    def no_new_pf(*a,**k):calls.append(True);raise AssertionError('Per-use certificate cannot run nonlinear physics')
    previous={n:getattr(pp,n) for n in ['runpp','runopp','rundcpp','rundcopp']}
    try:
        for name in previous:setattr(pp,name,no_new_pf)
        with (old/'actual/capsules.bin').open('rb') as pack:
            checked=source_reader.check_query(node,row,message,cache={},intents={m['PF_id']:intent},
                returns={m['PF_id']:m} if m['outcome']=='RETURNED' else {},exceptions={m['PF_id']:m} if m['outcome']!='RETURNED' else {},pack=pack,p=p,runner=runner)
        assert checked==record and not calls
    finally:
        for name,value in previous.items():setattr(pp,name,value)
    ack={'status':'PASS_EXACT_CAUSAL_ARCHIVED_RECEIPT_SAVED_NATIVE_VERIFIER','point_action_key':key,
        'source_protocol_sha256':protocol,'source_journal_sha256':entry['source_journal_sha256'],
        'source_intent_line_sha256':entry['intent_reference']['sha256'],'source_record_line_sha256':ref['journal_line_sha256'],
        'checked_record_sha256':digest(canon(record)),
        'native_source_bound_reader_sha256':digest(Path(source_reader.__file__).read_bytes()),
        'verdict':record['verdict'],'original_score':record['original_score'],
        'old_attributed_PF_calls':record['attributed_PF_calls'],'old_attributed_solver_seconds':record['attributed_solver_seconds'],
        'new_model_PF_derivative_forecast_factor_solve_calls':0,'paid_certificate_CPU_seconds':time.perf_counter()-started,
        'old_full_policy_gate':'UNKNOWN_UNCHANGED','new_missing_identity_execution_authorized':False}
    with Path(ack_path).open('x',encoding='utf-8') as f:json.dump(ack,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    return ack
