from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,zipfile
R=Path(__file__).resolve().parents[1];O=R/'outputs/receding_preparation_checkpoint_20261029'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def put(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 O.mkdir(exist_ok=False);now=datetime.now(timezone.utc).isoformat()
 old=R/'outputs/research_resumption_20261028/Current_Resume.json';shutil.copy2(old,O/'Previous_Current_Resume.json')
 resume=read(old);resume.update(at_utc=now,status='VERIFIED_FIRST_NUMERICAL_PROPOSAL_AND_NEW_RECEDING_PREPARATION_SAVED_FULL_CAMPAIGN_NOT_READY',
  latest_exact_execution_state=(O/'Exact_Resume.json').relative_to(R).as_posix(),latest_verified_GitHub='c7f36567d111b11fb24a4f76a76b8caca9782873',
  last_verified_GitHub='c7f36567d111b11fb24a4f76a76b8caca9782873',
  verified_GitHub_receipt='outputs/nonlinear_readiness_publication_20261029/Verified_GitHub_Receipt.json',
  new_work_publication='First nonlinear results/source published with six exact downloaded-byte checks. Later receding preparation pending current compact publication.',
  owned_scientific_jobs=[],GPU_assignments=[],waiting_timer=None,
  usage_observation='Latest actual account usage94percent consumed,6percent remaining; ordinaryUsageAllowed true. No reset/time promise.',
  thesis_requirements_complete=27,thesis_requirements_total=35,all_six_final_goals='OPEN',
  today_new_verified_evidence={
   'all500_initial_bindings':'outputs/nonlinear500_input_binding_independent_20261029/Independent_Audit.json',
   'first_actual_two_stage_solver':'outputs/nonlinear13_first_proposal_independent_20261029/Independent_Audit.json',
   'exact_paid_reuse':'outputs/nonlinear500_paid_registry_independent_20261029/Repair_And_First_Reuse_Review.json',
   'real_saved_current_state_qualified_review':'outputs/nonlinear13_actual_saved_cursor_20261029/Independent_Review.json',
   'snapshot_v2_changed_path_review':'outputs/nonlinear500_paid_snapshot_preparation_20261029/v2_changed_paths/Independent_Review.json',
   'receding_engine_software_only':'outputs/nonlinear13_receding_policy_preparation_20261029/Results.json',
   'future_independent_audit_contract':'outputs/nonlinear13_receding_independent_design_20261029/Audit_Contract.json',
   'remaining_thesis_literal_criteria':'outputs/remaining_thesis_closure_triage_20261029/Triage.json'},
  actual_saved_cursor_limits=['before_vm null in preserved old fixture; current engine uses current_vm.',
   'Old shape_hash scalar type claim overstated; new synthetic engine checks distinguish bool/int/float.',
   'PF3 historical primary timer0.0470000000204891seconds and independent timer0.0 recovered; zero reading is not free. Full runtime/clock/RNG restore not certified.'],
  next_ordered_actions=[
   'Independently review new receding engine against Audit_Contract; do not rerun old completed checks or firstproposal.',
   'Implement fixed new-math execution/attempt ownership around unchanged v3 solver and exact source context cache; seed0 firstproposal MUST reuse its paid receipt.',
   'Bind full historical physical/replay/cost lineage, complete semantic journals, source-frozen owner clock and actual RNG restore. Snapshotv2 is current; v1 mutation defect retained.',
   'Prepare complete partial-aware physical reader and prospective exact source/owner/resource/history protocol before any new PF or full500 study. Both newoptimizer/PF entries currently disabled.',
   'Keep all500 source order,100rounds,3nativeactuators/float32cap/originalguard. No outcome retuning or claim of a new benchmark/LLM win.',
   'Eight thesis items remain evidence-dependent; do not change security scope or invent approvals/memberships to reach30.'])
 put(O/'Exact_Resume.json',resume);put(old,resume)
 nxt=R/'outputs/research_resumption_20261028/Next_Exact_Work_20261029.json';shutil.copy2(nxt,O/'Previous_Next_Exact_Work.json')
 put(nxt,dict(at_utc=now,exact_resume=resume['latest_exact_execution_state'],next_ordered_actions=resume['next_ordered_actions'],scientific_owner=None,GPU_assignments=[],timer=None))
 tasks=R/'outputs/research_tasks_20261014/Tasks.json';shutil.copy2(tasks,O/'Previous_Tasks.json');t=read(tasks)
 t.update(updated_at_utc=now,latest_exact_execution_state=resume['latest_exact_execution_state'],latest_verified_GitHub=resume['latest_verified_GitHub'],verified_GitHub_receipt=resume['verified_GitHub_receipt'],current_owned_jobs=[],current_GPU_assignments=[],thesis_documentation_requirements_complete=27)
 for x in t['tasks']:
  if x.get('checklist_id')=='G2':x['current_result']='Saved public13 analysis: strict NUM264/500 versus DDPG363/500; same user-requested1e-8 allowance for all gives NUM415 versus SafeDDPG262/linear258/DDPG363. This is retrospective engineering sensitivity, not new500science or an LLM result. Original-paper faithful public role remains open.'
  if x.get('checklist_id')=='G1':x['next']='Implement and independently review fixed receding nonlinear worker from new exact resume; first solver proposal paid and must be reused. No new performance campaign ready.'
 put(tasks,t)
 text=('Parallel preparation checkpoint — '+now+'\n27/35 thesis requirements complete; all6finalgoalsOPEN. Three agents completed bounded source/review work. All500 initialbindings and one real fixed two-stage numerical proposal independentlyPASS; exact old firstphysics remains12UVto12UV/0OV. New real saved-NET warm/cold integration reviewed with preserved metadata/type/cost qualifications. Fixed receding-engine code and new synthetic state-machine checks saved; new optimizer/PF entries HARD-DISABLED pending complete worker/owner/reader/semantic-cost integration. Snapshotv2 fixes metadata mutation and avoids repeated36MBregistry parsing; no scientific outcome change. No new benchmark score, LLM superiority or fresh physics/model/GPU/actualcommit. No live scientificjob or timer. Exactresume:'+resume['latest_exact_execution_state']+'\n')
 (O/'Progress.txt').write_text(text,encoding='utf-8')
 with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+text)
 for p in [R/'outputs/Unattended_Execution_Runbook.md',R/'outputs/llm_value_development/Next_Phase_Plan.md',R/'RESEARCH_TASKS.md']:
  prior=p.read_text(encoding='utf-8');p.write_text('## '+text.splitlines()[0]+'\n\n'+'\n'.join(text.splitlines()[1:])+'\n\n'+prior,encoding='utf-8')
 scripts=['check_nonlinear13_actual_saved_cursor_20261029.py','nonlinear500_paid_snapshot_20261029.py','nonlinear500_paid_snapshot_v2_20261029.py','check_nonlinear500_paid_snapshot_20261029.py','nonlinear13_receding_policy_engine_20261029.py',Path(__file__).name]
 files=[R/'work'/s for s in scripts]
 for folder in ['nonlinear13_actual_saved_cursor_20261029','nonlinear500_paid_snapshot_preparation_20261029','nonlinear13_receding_policy_preparation_20261029','nonlinear13_receding_independent_design_20261029','remaining_thesis_closure_triage_20261029']:
  files.extend(p for p in sorted((R/'outputs'/folder).rglob('*.json')) if p.name not in ['Warm_Snapshot.json','Closed_Manifest.json'])
 pack=O/'Own_Engineering_And_Reviews.zip';members=[]
 with zipfile.ZipFile(pack,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in files:
   raw=p.read_bytes();name=p.relative_to(R).as_posix();z.writestr(name,raw);members.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
 with zipfile.ZipFile(pack) as z:
  assert z.testzip() is None
  for v in members:assert sha(z.read(v['path']))==v['sha256']
 put(O/'Artifact_Index.json',dict(members=members,archive_sha256=sha(pack.read_bytes()),scope='Own code and compact generated proofs only; no rawNETs/weights/fullthesis/thirdparty library source. Not full rawbackup.'))
 prepared=[]
 for name in ['Artifact_Index.json','Own_Engineering_And_Reviews.zip','Exact_Resume.json','Progress.txt']:
  p=O/name;b=p.read_bytes();prepared.append(dict(local=p.relative_to(R).as_posix(),path='research_progress/20261029_receding_preparation/'+name,bytes=len(b),sha256=sha(b),blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
 put(O/'Prepared_Files.json',dict(files=prepared));print(json.dumps(dict(saved=True,files=len(prepared),members=len(members),thesis_closed=27,main_final_closed=0)))
if __name__=='__main__':main()
