import json
from native_upgrade_support_engine_20261020 import run,PRIMARY,READER,put
if __name__=='__main__':
    r=run('independent');p=json.loads((PRIMARY/'Result.json').read_text(encoding='utf-8'))
    def observed(cases):
        return [{'seed':c['seed'],'root':c['root'],'root_UV':c.get('root_UV'),'root_OV':c.get('root_OV'),'algorithms':[{k:a[k] for k in ['algorithm','status','endpoint','cumulative_Q_squared','all_bus_restored','completed_steps'] if k in a} for a in c['algorithms']]} for c in cases]
    assert observed(r['cases'])==observed(p['cases']) and r['all_steps']==p['all_steps'] and r['fixed_UV_opportunity_screen']==p['fixed_UV_opportunity_screen']
    put(READER/'Independent_Audit.json',{'status':'PASS_ALL_DECLARED_RETURNED_SOURCE_POLICY_COLD_CONTINUOUS_PHYSICS_INPUT_FIELDS_COST_FROZEN_CHECKS','science_status':p['status'],'fixed_screen':p['fixed_UV_opportunity_screen'],'primary_costs':p['costs'],'actual_reader_costs':r['costs'],'new_learning_GPU_calls':0,'all8_case_outcomes_preserved':True,'trained_upgrade_authorized':False})
    print('INDEPENDENT_UPGRADE_SUPPORT_AUDIT_PASS',r['fixed_UV_opportunity_screen'])
