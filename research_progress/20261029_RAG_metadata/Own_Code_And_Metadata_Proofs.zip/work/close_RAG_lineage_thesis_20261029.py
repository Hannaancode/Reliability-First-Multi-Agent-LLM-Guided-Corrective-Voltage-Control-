"""Close reviewed additive thesis work, never infer a completed causal study."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,zipfile,html,os
from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from docx.table import Table
from pypdf import PdfReader
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_RAG_lineage_20261029';B=R/'outputs/thesis_caption_QA_v2_20261029'
def rd(p):return json.loads((R/p).read_text('utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    p=R/p;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n','utf-8');t.replace(p)
def shapes(d):
    out=[]
    for s in d.inline_shapes:
        rid=s._inline.xpath('.//a:blip')[0].get(qn('r:embed'))
        out.append((hashlib.sha256(d.part.related_parts[rid].blob).hexdigest(),s.width,s.height))
    return out
def main():
    assert not (O/'Final_Visual_And_Evidence_QA.json').exists()
    rec=rd((O/'Integration_Record.json').relative_to(R));base=R/rec['base'];path=R/rec['output']
    assert sha(base)==rec['base_sha256']==rd((B/'Final_Visual_And_Evidence_QA.json').relative_to(R))['docx_sha256']
    before,after=Document(base),Document(path)
    assert len(after.inline_shapes)==22 and shapes(before)==shapes(after)
    tabletexts=lambda d:[[[c.text for c in row.cells] for row in t.rows] for t in d.tables]
    assert tabletexts(before)==tabletexts(after) and len(after.tables)==19
    norm=lambda s:re.sub(r'\s+',' ',re.sub(r'\t\d+$','',s)).strip()
    old=Counter(norm(p.text) for p in before.paragraphs);new=Counter(norm(p.text) for p in after.paragraphs)
    assert old-new==Counter(norm(x['old']) for x in rec['changed'])
    for x in rec['changed']:assert new[norm(x['new'])]>=1
    for x in rec['added']:assert new[norm(x['text'])]>=1
    refs=[p.text for p in after.paragraphs if re.match(r'^\[\d+\]',p.text)]
    priorrefs=[p.text for p in before.paragraphs if re.match(r'^\[\d+\]',p.text)]
    assert refs==priorrefs+rec['references_added'] and len(refs)==37
    assert [int(re.match(r'^\[(\d+)\]',s)[1]) for s in refs]==list(range(1,38))
    for x in rec['source_bindings']:assert sha(R/x['path'])==x['sha256']
    pdfpath=O/'Integrated_Thesis_QA.pdf';pdf=PdfReader(pdfpath)
    pagination=rd((O/'Pagination_Record.json').relative_to(R));render=rd((O/'Final_Rendered_Pages.json').relative_to(R))
    assert len(pdf.pages)==pagination['pages']==render['pages']==133
    assert len(pagination['map'])==53
    compact=lambda s:re.sub(r'\s+','',s).lower()
    for x in pagination['map']:assert compact(x['label']) in compact(pdf.pages[x['physical_page']-1].extract_text() or ''),x
    assert len(list((O/'render_final').glob('page-*.png')))==133
    assert sum(len(p.images) for p in pdf.pages)>=22
    now=datetime.now(timezone.utc).isoformat();qarel=(O/'Final_Visual_And_Evidence_QA.json').relative_to(R).as_posix()
    visual={'status':'PASS_ALL_PAGE_OVERVIEW_AND_CHANGED_DETAIL_REVIEW','pages':133,'overview':'Final133page contacts, original unchanged pages also covered by prior130page review.','detail_pages':[5,7,64,83,84,133],'unchanged_new_section_details_reviewed_in_prior_preview':[32,52,53,63],
      'observations':'New source analysis, claim-scope paragraph and bibliography are legible. New references36/37 follow35. Two-line orphan eliminated by concise scope paragraph. All22original figures and19tables retained.','limitation':'Final university administrative approval and broadT33terminology review remain open.'}
    qa={'at_utc':now,'status':'PASS_REVIEWED_RAG_SCOPE_LINEAGE_AND_METADATA_WORKING_THESIS','pages':133,'tables':19,'figures':22,'references':37,'page_bound_index_entries':53,
      'docx_sha256':sha(path),'pdf_sha256':sha(pdfpath),'all_prior_tables_unchanged':True,'all_original_image_bytes_order_and_dimensions_preserved':True,
      'all_prior_paragraphs_preserved_except_one_declared_scope_correction':True,'new_model_PF_training_calls':0,'source_bindings':rec['source_bindings'],'visual_review':visual,
      'T14':'COMPLETE_DOCUMENTATION_ALTERNATIVE_ONLY_CAUSAL_RETRIEVAL_UNPROVEN','T12':'PARTIAL','T13':'PARTIAL','all_six_final_goals':'OPEN'}
    put(qarel,qa);put((O/'Visual_Review_Record.json').relative_to(R),visual)
    chunks=[]
    for e in after.element.body:
        if e.tag.endswith('}p'):
            p=Paragraph(e,after);chunks.append(('## ' if p.style.name.startswith('Heading') else '')+p.text)
        elif e.tag.endswith('}tbl'):
            rows=[[c.text.replace('\n',' / ') for c in row.cells] for row in Table(e,after).rows]
            chunks.append('\n'.join(['| '+' | '.join(rows[0])+' |','| '+' | '.join(['---']*len(rows[0]))+' |']+['| '+' | '.join(r)+' |' for r in rows[1:]]))
    (O/'Thesis_Text_And_Tables.md').write_text('\n\n'.join(chunks)+'\n','utf-8')
    index=rd((B/'Thesis_Evidence_Navigation.json').relative_to(R));index.update(at_utc=now,current_docx=path.relative_to(R).as_posix(),pages=133,qa_record=qarel)
    index['new_source_sections']={'2.21':'Primary ALCE and RAGTruth records, references36/37','4.8':rec['source_bindings'][:2],'5.10':rec['source_bindings'][2:],'7.3':'Claimscope only; no matched causal ablation completed'}
    put((O/'Thesis_Evidence_Navigation.json').relative_to(R),index)
    def link(p):return '<a href="'+html.escape(os.path.relpath(R/p,O).replace('\\','/'),quote=True)+'">'+html.escape(p)+'</a>'
    content=['<!doctype html><meta charset="utf-8"><title>Thesis evidence</title><style>body{max-width:1000px;margin:40px auto;font:17px/1.5 system-ui}</style><h1>Thesis evidence</h1><p>133pages,19tables,22figures,37references. Current working draft; causal retrieval and all six research goals remain open.</p>',link(path.relative_to(R).as_posix())]
    for x in rec['source_bindings']:content.append('<p>'+link(x['path'])+'</p>')
    for t in index['tables']:
        content.append('<h2>'+html.escape(t['caption'])+'</h2><p>'+html.escape(t['limitation'])+'</p>')
        content.extend('<p>'+link(v['path'])+'</p>' for v in t['records'])
    content.append(link('outputs/thesis_integrated_evidence_20261028/Evidence_Index.html'))
    (O/'Evidence_Index.html').write_text('\n'.join(content),'utf-8')
    tasks=rd('outputs/thesis_research_closure_20261028/Tasks.json')
    t=next(t for t in tasks['tasks'] if t['id']=='T14');assert t['status']=='OPEN'
    t.update(status='COMPLETE_DOCUMENTATION_ALTERNATIVE_IN_REVIEWED_WORKING_THESIS',completed_utc=now,evidence=t['evidence']+[qarel],
      limitation='Only the explicitly permitted whole-system claim restriction is complete. No matched ablation or causal retrieval improvement is claimed.')
    t=next(t for t in tasks['tasks'] if t['id']=='T12');t['evidence']+=['outputs/nerc_reference_metadata_broker_20261029/Independent_Saved_Output_Audit.json',qarel]
    t['new_scoped_progress']='All98actual registered reference entries tested:392exact-value checks,392missing-field checks,108rejections plus4loaderrejections. Independent saved-output auditPASS. Metadata-only software; answer truth/refusal and runtime integration remain untested.'
    next(t for t in tasks['tasks'] if t['id']=='T13')['evidence'].append(qarel)
    tasks['completed_requirement_count']=sum(t['status'].startswith('COMPLETE') for t in tasks['tasks']);assert tasks['completed_requirement_count']==20
    tasks['updated_utc']=now;put('outputs/thesis_research_closure_20261028/Tasks.json',tasks)
    msg='20/35 thesis requirements complete: T14 closed through the explicitly allowed whole-system claim restriction, not a causal RAG experiment. Reviewed133page thesis retains19tables/22figures and adds2primary references (37total), source-level citation failures, all98reference metadata broker checks and independent NERC format/lineage findings. T12/T13remainPARTIAL; all6research goalsOPEN. Zero new model/PF/training; no ownedscientificjob/GPU/timer.'
    for rel in ['outputs/research_resumption_20261028/Current_Resume.json','outputs/public_qa_scale_design_20261029/Exact_Resume.json','outputs/research_resumption_20261028/Next_Exact_Work_20261029.json']:
        x=rd(rel);x.update(at_utc=now,thesis_complete=20,thesis_requirements_complete=20,thesis_closed_requirements=20,thesis_current=path.relative_to(R).as_posix(),thesis_qa=qarel,thesis_integration=qarel,thesis_evidence_index=(O/'Evidence_Index.html').relative_to(R).as_posix(),reference_metadata_broker='outputs/nerc_reference_metadata_broker_20261029/Independent_Saved_Output_Audit.json',owned_scientific_jobs=[],GPU_assignments=[],waiting_timer=None)
        put(rel,x)
    main=rd('outputs/research_tasks_20261014/Tasks.json');main.update(updated_at_utc=now,thesis_documentation_requirements_complete=20,latest_verified_thesis=qarel);put('outputs/research_tasks_20261014/Tasks.json',main)
    header='## Reviewed RAG claim scope and all-entry metadata checks — '+now+'\n\n'+msg+'\n\n'
    for rel in ['outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md','RESEARCH_TASKS.md']:
        p=R/rel;p.write_text(header+p.read_text('utf-8-sig'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:f.write('\n'+now+'\n'+msg+'\n')
    rec.update(status='COMPLETE_REVIEWED_WORKING_DRAFT',pages=133,qa=qarel,T14='COMPLETE_SCOPED_DOCUMENTATION_ONLY');put((O/'Integration_Record.json').relative_to(R),rec)
    print(json.dumps({'status':qa['status'],'pages':133,'thesis_requirements_complete':20,'research_goals_complete':0}))
if __name__=='__main__':main()
