"""Exact elementary witnesses; no learned/physical performance experiment."""
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/critical_research_reset_20261010/literature_transfer_assumption_checks'

def write(name, value):
    path = OUT / name
    with path.open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=False)
    write('owner.claim', {'pid': os.getpid(), 'source': str(Path(__file__).resolve()),
          'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Fresh exact arithmetic witnesses only; no scientific rerun'})
    write('Prospective_Scope.json', {
        'fixed_checks': ['singleton_support', 'compact_continuity', 'additive_margin_scale', 'shared_intercept_cancellation'],
        'no_grid_data_or_outcome_access': True,
        'no_model_PF_optimizer_controller_linear_solver_or_cloud_calls': True,
        'meaning': 'Certificates concern specified mathematical implications, not general LLM failure or superiority',
        'source_sha256': sha(Path(__file__))})

    # A probability distribution with singleton support is uniquely determined.
    # Enumerate a rational two-action simplex to verify the concrete witness.
    distributions = [(F(i, 100), F(100-i, 100)) for i in range(101)]
    same_support = [p for p in distributions if {i for i,v in enumerate(p) if v>0} == {0}]
    assert same_support == [(F(1), F(0))]
    support = {
        'baseline': ['1', '0'], 'simplex_witnesses_checked': 101,
        'same_support_witnesses': [[str(v) for v in p] for p in same_support],
        'general_argument': 'A nonnegative normalized distribution supported on one action must assign that action probability one.',
        'scope': 'A support-preserving update of a deterministic point-mass cannot select another action. A stochastic reference is a different assumption, not a changed deterministic comparator.'}

    # f(x)=sqrt(x) on [0,1]. At x=1/n^2 the exact difference quotient is n.
    continuity = []
    for n in [2, 10, 100, 10000]:
        x, fx = F(1,n*n), F(1,n)
        assert fx*fx == x and fx/x == n
        continuity.append({'n': n, 'x': str(x), 'f_x': str(fx), 'difference_quotient': str(fx/x)})
    lipschitz = {
        'family': 'f(x)=sqrt(x), x in [0,1]; x_n=1/n^2 for arbitrary positive integer n',
        'exact_witnesses': continuity,
        'general_argument': 'For any finite proposed Lipschitz constant K, choose integer n>K; |f(x_n)-f(0)|/|x_n-0|=n>K.',
        'scope': 'Continuity on a compact set is insufficient to establish Lipschitz continuity. This does not refute a theorem that separately assumes or enforces Lipschitz constants.'}

    # Generic margin-residual model t=(D r-c)/q with c=D h.
    # r'=a r+(1-a)h and q'=a q leave all t exactly unchanged.
    r = [F(7,3), F(-2,5), F(11,4)]
    h = [F(1,7), F(3,2), F(-5,3)]
    edges = [(0,1),(1,2),(0,2)]
    q = F(5,4)
    c = [h[i]-h[j] for i,j in edges]
    original = [(r[i]-r[j]-ce)/q for (i,j),ce in zip(edges,c)]
    margin_witnesses = []
    for a in [F(1,2), F(3,2), F(2)]:
        rp = [a*rv+(1-a)*hv for rv,hv in zip(r,h)]
        qp = a*q
        transformed = [(rp[i]-rp[j]-ce)/qp for (i,j),ce in zip(edges,c)]
        assert transformed == original and qp != q
        margin_witnesses.append({'a': str(a), 'q_prime': str(qp), 'all_comparison_scores_identical': True})
    assert c[0]+c[1]-c[2] == 0
    margin = {
        'original_q': str(q), 'exact_comparison_scores': [str(v) for v in original],
        'alternative_parameters': margin_witnesses, 'triangle_margin_cycle_sum': '0',
        'general_argument': 'When c=D h, D[a r+(1-a)h]-c=a(D r-c); dividing by a q gives the original score.',
        'scope': 'An unrestricted prompt-local scale is not identified by additive utility-gap margins. Additional architectural, cross-prompt or normalization restrictions can select a scale; selection is not recovery of physical uncertainty.'}

    # A nuisance term shared across the compared models cancels from the difference.
    intercept_witnesses = []
    for world in [F(-100), F(0), F(100)]:
        model_a = F(1,3)+world+F(2,7)
        model_b = F(3,5)+world+F(-1,4)
        d = model_a-model_b
        assert d == F(1,3)-F(3,5)+F(2,7)+F(1,4)
        intercept_witnesses.append({'shared_world_intercept': str(world), 'paired_difference': str(d)})
    intercept = {
        'exact_witnesses': intercept_witnesses,
        'general_argument': '(alpha_A+u+e_A)-(alpha_B+u+e_B)=alpha_A-alpha_B+e_A-e_B.',
        'scope': 'A shared world intercept alone does not model correlated model-effect differences within worlds; assess the paired-difference dependence or aggregate by world.'}

    write('Exact_Assumption_Witnesses.json', {
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'singleton_support': support, 'compact_continuity': lipschitz,
        'additive_margin_scale': margin, 'shared_intercept_cancellation': intercept,
        'all_exact_arithmetic_checks_passed': True,
        'arbitrary_n_and_a_arguments_are_algebraic_not_inferred_from_finite_witness_counts': True,
        'new_model_forwards': 0, 'new_generation': 0, 'new_training': 0,
        'new_PF': 0, 'new_controller': 0, 'new_linear_solves': 0,
        'new_GPU_allocations': 0, 'grid_outcomes_read': False,
        'no_claim_of_universal_learning_failure_or_grid_superiority': True,
        'seconds': time.perf_counter()-started})
    files = [p for p in OUT.iterdir() if p.is_file()]
    write('Immutable_Evidence_Manifest.json', {
        'source': {'path': 'work/'+Path(__file__).name, 'sha256': sha(Path(__file__))},
        'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files}})
    print(json.dumps({'status': 'COMPLETE', 'four_scoped_checks_passed': True, 'science_calls': 0, 'output': str(OUT)}))

if __name__ == '__main__':
    main()
