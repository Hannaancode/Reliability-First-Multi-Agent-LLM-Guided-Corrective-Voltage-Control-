"""Read-only evidence audit; no solver, inference, export, or campaign rerun."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, zipfile
from value_baseline_gate import require_sealed_baseline

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
OUT = ROOT / 'outputs'
DEV = OUT / 'llm_value_development'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    baseline = require_sealed_baseline(ROOT)
    lock = read(ROOT / 'work/e/bank/BANK_LOCK.json')
    frozen = ROOT / 'work/e'
    protocol = read(OUT / 'matched_campaign_protocol.json')
    proof = read(OUT / 'frozen_input_verification.json')
    assets = read(frozen / 'bank/scenario_manifest.json')['frozen_asset_hashes']
    checks = {
        'protocol': sha(OUT / 'matched_campaign_protocol.json') == 'a2d18b90656d541b29ca35062503b2bc6156aee28e1f5a794b392e91b35a3aa7',
        'controller_sources': all(sha(ROOT / p) == h for p, h in protocol['source_sha256'].items()),
        'locked_scenarios': len(lock['scenario_file_sha256']) == 62 and all(sha(frozen / 'bank/scenarios' / n) == h for n, h in lock['scenario_file_sha256'].items()),
        'locked_file_set': set(lock['scenario_file_sha256']) == {p.name for p in (frozen / 'bank/scenarios').glob('*.json')},
        'bank_manifest': sha(frozen / 'bank/scenario_manifest.json') == lock['manifest_sha256'],
        'bank_sanity': sha(frozen / 'bank/sanity_report.json') == lock['sanity_report_sha256'],
        'network': sha(frozen / 'pack/testbeds/federation_4mg_ieee118.json') == assets['federation_network_sha256'],
        'metadata': sha(frozen / 'pack/testbeds/federation_4mg_ieee118_metadata.json') == assets['federation_metadata_sha256'],
        'model_files': all(sha(frozen / 'pack/models/zone_agent_shared_lora_qwen05b_ultra_v1' / n) == h for n, h in proof['model_files'].items()),
    }
    assert all(checks.values()), checks
    expected_ids = {Path(n).stem for n in lock['scenario_file_sha256']}
    package = read(OUT / 'reviewer_reproducibility_package_manifest.json')
    with zipfile.ZipFile(OUT / package['package_file']) as z:
        for folder in ['matched_campaign', 'central_matched_campaign', 'ac_reference_campaign']:
            paths = list((OUT / folder / 'cases').glob('*.json'))
            assert {p.stem for p in paths} == expected_ids
            for p in paths:
                assert hashlib.sha256(z.read('outputs/' + folder + '/cases/' + p.name)).hexdigest() == sha(p)
        rng_counts = {}
        for folder in ['matched_campaign', 'central_matched_campaign']:
            paths = list((OUT / folder / 'rng').glob('*.pt'))
            assert len(paths) == 62
            for p in paths:
                assert hashlib.sha256(z.read('outputs/' + folder + '/rng/' + p.name)).hexdigest() == sha(p)
            rng_counts[folder] = len(paths)
    execution = package['execution_inputs']
    archive = OUT / execution['file']
    assert sha(archive) == execution['archive_sha256'] and archive.stat().st_size == execution['bytes']
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == execution['member_count']
        assert z.testzip() is None
        members = json.loads(z.read('RESEARCH_FILE_MANIFEST.json'))
        assert set(z.namelist()) == set(members) | {'RESEARCH_FILE_MANIFEST.json'}
        for n, info in members.items():
            raw = z.read(n)
            assert len(raw) == info['bytes'] and hashlib.sha256(raw).hexdigest() == info['sha256']
    controls_manifest = read(DEV / 'CPU_Control_Manifest.json')
    assert len(controls_manifest) == 20
    assert set(controls_manifest) == {p.name for p in (DEV / 'cpu_controls').glob('*.json')}
    for n, info in controls_manifest.items():
        p = DEV / 'cpu_controls' / n
        assert p.stat().st_size == info['bytes'] and sha(p) == info['sha256']
    dev_protocol = read(DEV / 'clean_value_development_protocol.json')
    expected_controls = {(c['scenario_id'], p, b) for c in dev_protocol['initial_screen_scenarios'] for p in dev_protocol['first_screen_policies'] if not p.startswith('zonal_') for b in dev_protocol['candidate_evaluation_budget_grid']}
    rows = [read(DEV / 'cpu_controls' / n) for n in controls_manifest if n not in {'summary.json', 'config.json'}]
    assert len(rows) == 18 and {(r['scenario_id'], r['policy'], r['budget']) for r in rows} == expected_controls
    expected_cases = {c['scenario_id']: c['sha256'] for c in dev_protocol['initial_screen_scenarios']}
    total_attempts = 0
    for r in rows:
        assert r['scenario_sha256'] == expected_cases[r['scenario_id']]
        assert r['true_state_preserved'] and r['model_costs']['llm_calls'] == 0
        assert r['candidate_PF_counts']['attempts'] == r['tested_candidate_count'] <= r['budget']
        assert r['execution_PF_counts']['attempts'] == int(r['selected_action'] is not None)
        for k in ['candidate_PF_counts', 'execution_PF_counts']:
            assert r[k]['attempts'] == r[k]['returns'] + r[k]['exceptions']
            total_attempts += r[k]['attempts']
        if r['selected_action'] is not None:
            selected = [t for t in r['tested'] if t['action'] == r['selected_action'] and t['verification']['accepted']]
            assert selected and all(abs(float(r['executed_after_metrics'][k]) - float(selected[0]['verification']['after'][k])) <= 1e-10 for k in r['executed_after_metrics'])
    summary = read(DEV / 'cpu_controls/summary.json')
    config = summary['config']
    assert summary['actual_CPU_trials'] == 18 and summary['actual_model_calls'] == 0 and not summary['learned_arms_complete']
    assert config['baseline_gate']['package_sha256'] == baseline['package_sha256']
    for field, p in [('protocol_sha256', DEV / 'clean_value_development_protocol.json'), ('evaluator_sha256', ROOT / 'work/run_clean_value_cpu_controls.py'), ('ordering_source_sha256', ROOT / 'work/value_candidate_ordering.py'), ('PF_budget_source_sha256', ROOT / 'work/value_pf_budget.py')]:
        assert config[field] == sha(p)
    total_attempts += sum(c['initial_PF_counts']['attempts'] for c in summary['shared_initial_PF_costs'])
    assert total_attempts == summary['PF_budget']['attempts'] == len(summary['PF_budget']['events']) == 968
    report = {'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'original_ten_steps_verified_complete': True, 'baseline': baseline, 'reproducibility_archive_members': package['member_count'], 'execution_input_archive_members': execution['member_count'], 'exact_62_case_id_sets_verified': True, 'archived_live_case_and_RNG_hashes_match': True, 'RNG_counts': rng_counts, 'fresh_frozen_preservation_checks': checks, 'actual_CPU_control_trials_verified': len(rows), 'actual_CPU_control_PF_attempts': total_attempts, 'actual_CPU_control_PF_exceptions': summary['PF_budget']['exceptions'], 'actual_new_clean_model_calls': 0, 'learned_trials_complete': False, 'full_security_evaluation_complete': False, 'experimental_reruns': False}
    destination = DEV / 'baseline_and_CPU_controls_completion_audit.json'
    assert not destination.exists(), 'Preserve completed audit; do not overwrite'
    destination.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
