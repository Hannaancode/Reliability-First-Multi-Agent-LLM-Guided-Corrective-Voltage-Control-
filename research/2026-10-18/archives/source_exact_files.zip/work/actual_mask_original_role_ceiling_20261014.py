"""Exact finite-support ceiling for one-shot original LOCAL paid acquisition.

PREPARE before physical outcomes. Run only after the shared-domain scientist,
coordinator and independent physics reader ended with complete source auditPASS.
New actual-mask forecasts are charged; original wrong-mask outputs stay frozen.
An idealized label-aware ceiling is NOT a learned policy or online method.
"""
import argparse,copy,hashlib,json,os,sys,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from shared_current_domain_physics_guarded_v2_20261014 import inputs,key,read,sha,canon
from joint_reallocation_opportunity_core_v1 import forecast
from joint_admissibility_order_v1 import order_all_current_forecasts
from original_local_paid_branch_broker_v1 import resource_eligible,numerical_only_branches

R=Path(__file__).resolve().parents[1]
B=R/'outputs/actual_mask_original_role_ceiling_20261014'
PHYS=R/'outputs/shared_current_domain_physics_guarded_v2_20261014'
MASK=R/'outputs/actual_mask_jacobian_engineering_20261014'
def put(p,d):
    with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())

def prepare():
    B.mkdir(exist_ok=False)
    names=['work/actual_mask_original_role_ceiling_20261014.py','work/original_local_paid_branch_broker_v1.py',
        'work/joint_reallocation_opportunity_core_v1.py','work/joint_admissibility_order_v1.py',
        'work/shared_current_domain_physics_guarded_v2_20261014.py',
        'outputs/shared_current_domain_physics_guarded_v2_20261014/Protocol.json',
        'outputs/original_local_paid_branch_broker_20261014/Verified_Original_LOCAL_Broker_Software_Checkpoint.json',
        'outputs/actual_mask_jacobian_engineering_20261014/audit/Independent_Actual_Mask_Engineering_Audit.json']
    names += [str((MASK/'actual'/f'W{i}_Actual_Final_Mask_Context.npz').relative_to(R)) for i in range(1,5)]
    put(B/'Protocol.json',{'frozen_at_utc':datetime.now(timezone.utc).isoformat(),
        'purpose':'Before spending GPU/inference, compute the exact most-optimistic finite candidate ceiling for the implemented originalLOCALrecipient/Q prior and commonnumericaldonorbroker versus strongestactualmasknumericalK4 acquisition.',
        'source_input_sha256':{n:sha(R/n) for n in names},'new_correct_actual_mask_forecasts_planned':6372,
        'old4001plus2371restored_label_forecasts':'Never overwritten/recomputed/repaired; newcorrectS mathematicalinputs differ and newcalls charged.',
        'activation':'ONLY after true sharedphysicscoordinator+scientist+readerended, scienceexit0/readerexit0 and complete independent2371physics/source/cost auditPASS; no partial inputs.',
        'query_budget_each_control':4,'model_role':'One originalmandatoryLOCALrecipient/Qproposal per4zones; common numericalbroker selects firstresourceeligible ordinary/owneddonorvariant at each requested(bus,q) in the samecausalordering. No numericfill for null/malformed/duplicate.',
        'primary_cheap_role_gate':'AcrossALL4roots, a perfect label-aware recipient/Q choice under that FIXEDbroker can attain strictlylower UV than numericK4 in>=2worlds and no UVloss. PASS only means limitedroleheadroom, not modelbenefit. FAIL stops this one-shotrole/data/K4 intervention, no alternateK/threshold/proposal-count/donor-rule/decoder/domain/outcome sweeps.',
        'secondary_report_only':'AllK1/4/8/16/32/64 numericbestscore, UV/deficit/min/max/knownreject/unknown counts and everyoraclegroup. Never choose favourableK or secondary instead of primary.',
        'mathematical_ceiling_scope':'Exact givencompletefinite measured support/ordering/legalfilters/one-action objective; NOT a100percent statement about anymodel, anyfuturegrid, horizons or policy.',
        'economic_gate':'Actual original-model coldcontext/latency/memory/cost measurement still needed; no uniformquerytime, imputedepisode reward, freecache/tool/model costs or deploymentspeed guarantee.',
        'new_model_PF_derivative_factor_solve_optimizer_calls':0,'resource_bound_seconds':600.,
        'no_automatic_GPU_or_policy_or_training':True})
    print(json.dumps({'prepared_only':str(B),'physics_or_model_started':False,'primary_budget':4}))

def pins():
    p=read(B/'Protocol.json')
    for n,h in p['source_input_sha256'].items():assert sha(R/n)==h,n
    return p

def best(rows,initial):
    accepted=[x for x in rows if x['verdict']['accepted']]
    if not accepted:return {'best':None,'UV':initial['uv_count'],'unknown_or_exception_candidates':sum(x.get('unknown',False) for x in rows)}
    b=max(accepted,key=lambda x:tuple(x['original_score']))
    return {'best':b,'UV':b['verdict']['after']['uv_count'],
            'unknown_or_exception_candidates':sum(x.get('unknown',False) for x in rows)}

def worker():
    p=pins();assert read(PHYS/'Completion.json')['science_exit']==read(PHYS/'Completion.json')['reader_exit']==0
    audit=read(PHYS/'audit/Independent_Shared_Domain_Physics_Audit.json')
    assert audit['status'].startswith('PASS_ALL2371_')
    out=B/'actual';out.mkdir(exist_ok=False);start=time.perf_counter()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'actual_parent_pid':os.getppid(),'source_sha256':sha(Path(__file__)),
                           'protocol_sha256':sha(B/'Protocol.json'),'argv':sys.argv})
    # Bind actual complete physical evidence at activation without pretending
    # its not-yet-produced hashes existed at preparation.
    put(out/'Actual_Complete_Physics_Input_Binding.json',{'Completion':sha(PHYS/'Completion.json'),
        'Independent_Physics_Audit':sha(PHYS/'audit/Independent_Shared_Domain_Physics_Audit.json'),
        'New_Action_Records':sha(PHYS/'actual/Actual_New_Action_Records.json')})
    worlds,runner,zones,times=inputs()
    new={(x['world'],key(x['candidate'])):x for x in read(PHYS/'actual/Actual_New_Action_Records.json')['records']}
    summaries=[];forecasts=0;elapsed=0.;wins=0;losses=0;anyunknown=False
    from shared_original_serving_action_domain_v1 import build_current_domain
    for w in worlds:
        assert time.perf_counter()-start<p['resource_bound_seconds']
        current=runner.rescue.grid_metrics(w['net']);domain=build_current_domain(w['net'],w['source_cursor'],runner=runner,zones=zones)
        with np.load(MASK/'actual'/f'W{w["index"]}_Actual_Final_Mask_Context.npz',allow_pickle=False) as f:ctx={k:f[k] for k in f.files}
        old={key(x):x for x in w['paid']};measured={};causal=[]
        for row in w['rows']:
            t=time.perf_counter();f=forecast(row,ctx,current);elapsed+=time.perf_counter()-t;forecasts+=1
            causal.append({**row,'ordering_forecast':f})
            if key(row) in old:
                r=old[key(row)];receipt=r.get('measured_receipt');verdict=r['verif'];score=r['original_score']
                unknown=bool(receipt and receipt.get('outcome')=='EXCEPTION')
            else:
                r=new[(w['world'],key(row))];receipt=r['measured_receipt'];verdict=r['verdict'];score=r['original_score']
                unknown=bool(receipt and receipt.get('outcome')=='EXCEPTION')
            measured[row['universe_index']]={'candidate':row,'verdict':verdict,'original_score':score,'unknown':unknown}
        ordered=order_all_current_forecasts(causal,current,w['cursor']);order=[x['universe_index'] for x in ordered]
        assert set(order)==set(measured) and len(order)==len(measured)==len(w['rows'])
        numeric=numerical_only_branches(domain=domain,ordering=order)
        numericbest=best([measured[x['universe_index']] for x in numeric],current)
        # For each original zone and every legally requestable(recipient,Q), the
        # broker's first numerical variant is fixed BEFORE outcome lookup.
        possible={};zone_groups={}
        for zone,pool in domain['original_LOCAL_allowed_per_zone'].items():
            groups={}
            for uid in order:
                row=measured[uid]['candidate'];g=(row['receiver'],row['q'])
                if row['receiver'] in pool and g not in groups and resource_eligible(row,w['cursor']):groups[g]=uid
            zone_groups[zone]=[{'recipient':b,'q':q,'broker_candidate':uid} for (b,q),uid in groups.items()]
            for uid in groups.values():possible[uid]=measured[uid]
        ceiling=best(list(possible.values()),current)
        wins+=int(ceiling['UV']<numericbest['UV']);losses+=int(ceiling['UV']>numericbest['UV'])
        unknown=any(x['unknown'] for x in measured.values());anyunknown|=unknown
        ks={}
        eligible=[uid for uid in order if resource_eligible(measured[uid]['candidate'],w['cursor'])]
        for k in [1,4,8,16,32,64]:
            selected=[measured[i] for i in eligible[:k]];ks[str(k)]={'best':best(selected,current),
                'known_rejected':sum(not x['verdict']['accepted'] and not x['unknown'] for x in selected),
                'unknown':sum(x['unknown'] for x in selected),'actual_selected':len(selected)}
        record={'world':w['world'],'initial':current,'new_causal_forecasts':causal,'full_order':order,
            'all_measured_rows':list(measured.values()),'all_original_LOCAL_groups':zone_groups,
            'numericK4':numericbest,'ideal_originalLOCAL_role_ceiling':ceiling,'numeric_allK':ks,
            'ideal_role_is_after_label_upper_bound_NOT_method':True,'any_unknown':unknown}
        put(out/f'W{w["index"]}_Role_Ceiling.json',record)
        summaries.append({'world':w['world'],'numericK4_UV':numericbest['UV'],'ideal_role_ceiling_UV':ceiling['UV'],
                          'any_unknown':unknown,'role_groups':sum(map(len,zone_groups.values()))})
    assert forecasts==6372
    gate='UNKNOWN' if anyunknown else ('PASS' if wins>=2 and losses==0 else 'FAIL')
    put(out/'Result.json',{'exit_code':0,'role_support_gate':gate,'strict_UV_oracle_ceiling_wins':wins,'UV_losses':losses,
        'all_four_worlds':summaries,'new_actual_mask_forecast_attempts':forecasts,'new_actual_mask_forecast_returns':forecasts,
        'forecast_function_seconds':elapsed,'workflow_seconds':time.perf_counter()-start,'new_model_PF_derivative_factor_solve_calls':0,
        'no_automatic_phase_or_parameter_donor_rule_budget_world_sweep':True})
    print(json.dumps({'role_gate':gate,'newforecasts':forecasts,'model_PF_calls':0}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--worker',action='store_true');a=p.parse_args()
    assert a.prepare!=a.worker
    if a.prepare:prepare()
    else:worker()
