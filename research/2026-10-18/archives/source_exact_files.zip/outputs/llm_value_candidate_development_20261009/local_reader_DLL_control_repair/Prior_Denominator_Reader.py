"""Static input/label coverage clarification; no predictions or scientific calls."""
from pathlib import Path
from datetime import datetime, timezone
import collections, gzip, json
import torch
from candidate_process_evidence_utils import ROOT, read, write, sha, seal

BASE = ROOT / 'outputs/llm_value_candidate_development_20261009'
PREP = BASE / 'reliable_replication_preparation_v2'
DATA = BASE / 'input_and_target_contract_nullable_v2'
OUT = BASE / 'independent_learning_denominator_scope'
assert not OUT.exists()
OUT.mkdir()
torch.set_num_threads(2)
protocol = read(PREP / 'protocol.json')
inputs = read(PREP / 'Input_Index.json')
targets = read(PREP / 'Target_Index.json')
by_id = {r['observation_id']: r for r in inputs}
target_ids = {r['observation_id'] for r in targets}
assert len(by_id) == len(inputs) == 311 and len(target_ids) == len(targets) == 238
assert target_ids <= set(by_id)
assert len(set(by_id) - target_ids) == protocol['unlabelled_states'] == 73
denominators = read(DATA / 'World_and_Invalid_Denominators.json')
worlds = {w['scenario_sha256']: w for w in denominators['worlds']}
assert len(worlds) == 31
with gzip.open(DATA / 'Measured_Target_Rows.jsonl.gz', 'rt', encoding='utf-8') as f:
    labels = {r['observation_id']: r for r in map(json.loads, f)}
assert set(labels) == target_ids
rows = []
for world in sorted(worlds):
    current = [r for r in inputs if r['world_sha256'] == world]
    measured = [r for r in current if r['observation_id'] in target_ids]
    oracle_ids = []
    for r in measured:
        x = torch.load(PREP / r['tensor_path'], weights_only=True, map_location='cpu')
        allowed = x['allowed_actions']
        known = labels[r['observation_id']]['measured_candidates']
        if any(bool(allowed[c['target']['bus'], c['target']['Q_index']]) and
               c['target']['recorded_verifier']['accepted'] for c in known):
            oracle_ids.append(r['observation_id'])
    rows.append({'world_sha256': world, 'split': worlds[world]['split'],
        'finite_current_inputs': len(current), 'measured_target_states': len(measured),
        'unlabelled_current_inputs': len(current) - len(measured),
        'recorded_admissible_oracle_supported_states': len(oracle_ids),
        'measured_states_without_recorded_admissible_oracle': len(measured) - len(oracle_ids),
        'unlabelled_ids': sorted(r['observation_id'] for r in current if r['observation_id'] not in target_ids),
        'oracle_supported_ids': sorted(oracle_ids)})
split_rows = {}
for split in ['optimization', 'development_held']:
    selected = [r for r in rows if r['split'] == split]
    split_rows[split] = {'declared_worlds': len(selected),
        'worlds_with_finite_input': sum(r['finite_current_inputs'] > 0 for r in selected),
        'worlds_with_measured_targets': sum(r['measured_target_states'] > 0 for r in selected),
        'worlds_with_admissible_oracle_supported_states': sum(r['recorded_admissible_oracle_supported_states'] > 0 for r in selected)}
    for key in ['finite_current_inputs', 'measured_target_states', 'unlabelled_current_inputs',
                'recorded_admissible_oracle_supported_states', 'measured_states_without_recorded_admissible_oracle']:
        split_rows[split][key] = sum(r[key] for r in selected)
assert split_rows['optimization']['finite_current_inputs'] == 239
assert split_rows['optimization']['measured_target_states'] == 187
assert split_rows['development_held']['finite_current_inputs'] == 72
assert split_rows['development_held']['measured_target_states'] == 51
assert split_rows['development_held']['recorded_admissible_oracle_supported_states'] == 49
write(OUT / 'All_Exact_World_Coverage.json', rows)
write(OUT / 'Independent_Denominator_Scope_Audit.json', {
    'audited_at_utc': datetime.now(timezone.utc).isoformat(), 'all_passed': True,
    'actual_finite_forward_input_states': 311, 'actual_measured_target_states': 238,
    'split_coverage': split_rows, 'retained_original_invalid_root_view': protocol['retained_invalid_view'],
    'missing_candidate_ledgers': protocol['missing_ledgers'],
    'unknown_AFTER_records': protocol['masked_unknown_after'],
    'precap_unknown_native_convergence_records': protocol['precap_unknown_convergence'],
    'fixed_learning_gate_metrics_not_changed': True,
    'interpretation': 'Gain MSE is conditional on measured targets; topK inclusion is conditional on recorded admissible-oracle support. Unlabelled/invalid/unknown views are explicit coverage limits, not fabricated outcomes or measured failures.',
    'no_new_model_optimizer_PF_calls_or_outcome_inspection': True,
    'physical_or_full_DSE_performance_not_inferred': True,
    'source_sha256': sha(Path(__file__))})
(OUT / 'Scope.md').write_text('''# Actual metric denominators

The model forwards cover311 finite current inputs. Only238 have measured targets;73 remain unlabelled. The held development split contains72 inputs across8 declared worlds,51 target states across7 worlds, and49 states with a recorded admissible oracle. Gain MSE averages the7 labelled held worlds; topK inclusion uses the49 supported states with equal-world averaging. These frozen metric definitions are unchanged. The eighth declared world and21 unlabelled held inputs remain coverage limits, not measured negative or positive predictions. The original invalid root has no model forward and stays separately visible. Unknown AFTER/native-convergence fields remain unknown. These are saved-label learning diagnostics, not full physical trajectory performance or unused confirmation.
''', encoding='utf-8')
files = {'audit/' + p.name: p for p in OUT.iterdir() if p.is_file()}
files['source/' + Path(__file__).name] = Path(__file__)
archive = seal(OUT, files, 'Learning_Denominator_Scope_Evidence.zip')
print(json.dumps({'coverage': split_rows, 'archive': archive}, indent=2))
