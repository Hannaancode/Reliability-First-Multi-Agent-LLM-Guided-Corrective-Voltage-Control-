"""Fixed user-requested actual-model transfer question, input/token/parser prep only."""
import hashlib,json,pickle,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/original_lora_native13_transfer_preparation_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parse(text):
    import numpy as np
    def pairs(xs):
        d={}
        for k,v in xs:
            if k in d:raise ValueError('Duplicate key')
            d[k]=v
        return d
    def bad_constant(x):raise ValueError('Nonfinite constant')
    v=json.loads(text,object_pairs_hook=pairs,parse_constant=bad_constant)
    if type(v)!=dict:raise ValueError('Exact object required')
    if set(v)=={'abstain'} and type(v['abstain']) is bool and v['abstain']:return {'kind':'explicit_abstain','u_mvar':0.}
    if set(v)!={'u_mvar'} or type(v['u_mvar']) not in (int,float):raise ValueError('Exact native raw-policy-increment schema required')
    with np.errstate(over='ignore'):u=np.float32(v['u_mvar'])
    if not np.isfinite(u):raise ValueError('Finite sourcefloat32 policy proposal required')
    return {'kind':'native_PI_proposal','u_mvar':float(u),'native_clipped_u_mvar':float(np.clip(np.asarray([u],dtype=np.float32),-.3,.3)[0])}
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic();sys.path.append(str(ROOT/'work/physics_env/Lib/site-packages'));import candidate_process_runtime
    import numpy as np
    from transformers import AutoTokenizer
    from candidate_process_evidence_utils import frozen_checks
    source=ROOT/'outputs/stable_ddpg_native_engineering_20261020';proof=json.loads((source/'preserved_root_independent_audit/Independent_Partial_Audit.json').read_text(encoding='utf-8'));assert proof['status'].startswith('PASS_')
    with (source/'PF0_after.pkl').open('rb') as f:net=pickle.load(f)
    model=ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1';tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True,trust_remote_code=False)
    system='You are a microgrid zone agent. Return only valid JSON. No prose.';messages=[]
    for agent,bus in enumerate([2,7,9]):
        vm=float(net.res_bus.loc[bus,'vm_pu']);q=float(net.sgen.iloc[agent].q_mvar)
        user=('NEW NATIVE INVERTER CONTRACT: this task sets a reactive-power control increment, not a shunt addition.\n'
              'CURRENT_LOCAL_STATE:\n'+f'bus: {bus}\nvoltage_pu: {vm!r}\ncurrent_q_mvar: {q!r}\n'
              'voltage_limits_pu: [0.95,1.05]\n'
              'CONTROL: output u_mvar. The native plant uses next_q=current_q-clip(u_mvar,-0.3,0.3). '
              'Negative u therefore raises reactive injection. Use only this current voltage. '
              'Return exactly {"u_mvar":NUMBER} or {"abstain":true}. No extra fields.')
        chat=[{'role':'system','content':system},{'role':'user','content':user}];encoded=tokenizer.apply_chat_template(chat,tokenize=True,add_generation_prompt=True);ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded;assert type(ids)==list and all(type(i)==int for i in ids)
        messages.append({'agent':agent,'physical_bus':bus,'messages':chat,'token_ids':ids,'prefix_tokens':len(ids),'full_context_with128reserve':len(ids)+128,'source_root_fields_sha256':sha(source/'PF0_fields.npz')})
    assert len(messages)==3 and all(m['full_context_with128reserve']<=512 for m in messages)
    negative=['null','{"u_mvar":true}','{"u_mvar":NaN}','{"u_mvar":1,"u_mvar":2}','{"add_shunts_q_mvar":{"2":25}}','text {"u_mvar":0}','{"abstain":false}','{"u_mvar":1e300}']
    for x in negative:
        try:parse(x)
        except (ValueError,TypeError,OverflowError):pass
        else:raise AssertionError('Invalid schema/dtype accepted')
    assert parse('{"u_mvar":-1}')['native_clipped_u_mvar']==float(np.float32(-.3)) and parse('{"abstain":true}')['kind']=='explicit_abstain'
    inputs={'root_NET_sha256':sha(source/'PF0_after.pkl'),'root_fields_sha256':sha(source/'PF0_fields.npz'),'private_model_files':json.loads((ROOT/'outputs/frozen_input_verification.json').read_text(encoding='utf-8'))['model_files']}
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scientific_question':'Requested finite zero-shot transfer screen:can originaltrained0.5BLoRA emit usable current-voltage nativePI commands on firstpublished13busroot? This is an explicitly NEWservingrole,not unchangedpapercontroller or a claim of potentialnovelty. Measurebeforeany nativefine-tuning or expensivefullbenchmark.','same_native_first_seed':0,'all3_source_agent_indices':[0,1,2],'all3_physical_buses':[2,7,9],'information':'Exactly own currentvoltage/currentQ+staticnativePIrule/limits/busidentity;no afterstate/teacher/retrieval/seasonal/other-agentstate. Publisherlocal1voltage policies know their learned agent identity and commonrule.','new_role_not_silent_rescaling':'u_mvar is a NEWexplicitpolicyincrement field;originaladd_shunts_q_mvar schema is rejected. Same publisherPI subtraction andfloat32±.3clipping for ALLpolicies. No clippingorJSONrepair beyond declared shared nativeoperation.','decoder_fixed_before_outputs':{'do_sample':False,'num_beams':1,'max_new_tokens':128,'seed':20261020,'no_output_repair_retry_or_prompt_sweep':True},'planned_model_generation_attempts':{'primary':3,'fresh_model_cold_replays':3},'primary_metrics':'All3strictschema/finitefloat32validity,explicitabstainseparate,rawcliprate,all6fresh-modeltoken-sequencesexact,fulltokens/attempts/time/load/memory/quantizedsource/costs;not a guaranteedphysicswin.','conditional_physics':'Onlyafter genuine modeloutputs existand arepreserved/coldverified,independentCPUreaderconstructsnativewhole3proposal vector. Ifanyinvalid,STOPnamedtransferintervention/noactuation/noinvalidfill. Forvalidall3,oneprospectiveactualaction+independentreplayONLYifexactphysicalidentitynotalreadymeasured;otherwisereuse paidfields/costs. No originalrootrepeat. This preparationauthorizesnoPFcall.','input_context':'All3completeprefixes+128outputreservefit512,notruncation. This is distinctfrom prior44MAPDNnativezone4096overflowcontract,which remainsstopped.','base_for_new_experiment':{'repo':'unsloth/qwen2.5-0.5b-instruct-unsloth-bnb-4bit','revision':'10413c288cb9629acdf60b3e0229f3ba75efe413','public_weight_sha256':'81aaf58f48650c8e1480ad451f870f6f1e9d69a2e824fb46ee340c890f466f32','historical_original_SFT_base_revision':'UNRECOVERED;newpinnedbaseidentitymustbedisclosed'},'private_adapter_tokenizer_unchanged':inputs['private_model_files'],'hardware_scope':'Atmostoneprospectivelyselectedoriginal-profileT4afteractualintegration/source/loader/mask/memory/ownership/persistenthashpreservation/readinessprotocolpasses. NoGPUallocationfromthisinputonlygate,noaccountfallback/purchases/quotaevasion.','currently_ready_for_actual_model_owner':False,'missing_before_model_launch':['Actualremote111dependency/publicbase/privateadapterstrictloaderandlongestmask/memory/coldsourcecheck','Frozenremotechild/guardian/collectorandoneindependentreader;oneallocation/noinference retry;allpartialcosts;hashedlocalpreservationACKbeforeexactrelease','Freshactualprofile/assignment/process/claim/sourceclosurechecks'],'source_no_hindsight':'Firstoriginalauthorroot/all3agentsretained;all3outputsrunoncebeforegate,coldreplicascharged. Malformed isoperationalfailure;tool/runtime/unrecoveredoutput isUNKNOWN. NouniversalLLMinability/winconfidenceclaim.','actual_model_PF_GPU_calls_by_this_preparation':0}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8');(OUT/'All3_Messages_And_Token_IDs.json').write_text(json.dumps(messages,indent=2),encoding='utf-8');(OUT/'Input_Anchors.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL3_COMPLETE_NATIVE_SOURCE_CURRENT_ONLY_512_CONTEXT_AND_STRICT_PI_SCHEMA_SOFTWARE_GATE','prefix_token_counts':[m['prefix_tokens'] for m in messages],'negative_schema_checks':len(negative),'shared_native_clip_and_explicit_abstain_checks':2,'actual_LLM_PF_GPU_calls':0,'model_launch_ready':False,'workflow_seconds':time.monotonic()-start};(OUT/'Readiness.json').write_text(json.dumps(result,indent=2),encoding='utf-8');(OUT/'Frozen_After.json').write_text(json.dumps(frozen_checks(),indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
