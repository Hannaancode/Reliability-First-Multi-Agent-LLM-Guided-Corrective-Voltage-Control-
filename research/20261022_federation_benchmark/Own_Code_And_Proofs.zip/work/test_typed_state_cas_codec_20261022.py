"""Actual saved typed-state preservation fixtures, zero scientific call replay."""
import copy,json,pickle
from pathlib import Path
import stable_ddpg_native_bridge_20261020
import numpy as np
import pandas as pd
from typed_state_cas_codec_20261022 import Store,atomic_json,digest
R=Path(__file__).resolve().parents[1];O=R/'outputs/typed_state_cas_engineering_20261022'

def equal(a,b):
    assert type(a)==type(b),(type(a),type(b))
    if isinstance(a,np.ndarray):assert a.dtype==b.dtype and a.shape==b.shape and np.array_equal(a,b,equal_nan=a.dtype.kind in 'fc')
    elif isinstance(a,pd.DataFrame):pd.testing.assert_frame_equal(a,b,check_exact=True)
    elif isinstance(a,pd.Series):pd.testing.assert_series_equal(a,b,check_exact=True)
    elif isinstance(a,pd.Index):pd.testing.assert_index_equal(a,b,exact=True)
    elif isinstance(a,dict):
        assert list(a)==list(b)
        for k in a:equal(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b):equal(x,y)
    elif isinstance(a,float) and np.isnan(a):assert np.isnan(b)
    elif hasattr(a,'toarray'):assert np.array_equal(a.toarray(),b.toarray())
    else:assert a==b,(type(a),str(a)[:80],str(b)[:80])

def main():
    O.mkdir(exist_ok=False);store=Store(O/'state_store',512*1024**2);rows=[]
    prior=R/'outputs/public13_fresh_router_execution_20261022'
    paths=[prior/'Initial_All_Bank_State.pkl',prior/'Final_All_Bank_State.pkl',prior/'cases/seed1054/numerical_044/Full_Cursor.pkl',prior/'cases/seed1054/numerical_043/Completed_Full_State.pkl',prior/'forwards/F003749_before.pkl']
    for i,path in enumerate(paths):
        original=pickle.loads(path.read_bytes());standard=pickle.loads(pickle.dumps(original,protocol=5));target=store.directory/f'fixture{i}.state'
        info=store.dump(target,original);restored=store.load(target);equal(standard,restored)
        first=store.bytes_written;store.dump(store.directory/f'fixture{i}_again.state',original)
        rows.append(dict(path=path.relative_to(R).as_posix(),original_bytes=path.stat().st_size,packet_bytes=info['bytes'],second_write_added_only_packet_bytes=store.bytes_written-first,exact_typed_values=True))
        assert store.bytes_written-first==info['bytes']
    a=np.asarray([1.,np.nan,-0.,np.inf]);payload=dict(a=a,b=a,c=a.copy(),fortran=np.asfortranarray(np.arange(12).reshape(3,4)),object_array=np.asarray(['x',None],dtype=object))
    store.dump(store.directory/'aliases.state',payload);restored=store.load(store.directory/'aliases.state')
    assert restored['a'] is restored['b'] and restored['a'] is not restored['c'] and restored['fortran'].flags.f_contiguous
    assert restored['object_array'].dtype.hasobject and restored['object_array'].tolist()==['x',None]
    good=(store.directory/'aliases.state').read_bytes();bad=store.directory/'corrupt.state';bad.write_bytes(good[:-2]+b'xx')
    rejected=False
    try:store.load(bad)
    except Exception:rejected=True
    assert rejected
    # Test a missing immutable blob with a separate fresh descriptor/store.
    tiny=Store(O/'tiny',64);bounded=False
    try:tiny.dump(tiny.directory/'large.state',np.arange(1000))
    except TimeoutError:bounded=True
    assert bounded
    report=dict(status='PASS_ACTUAL_SAVED_STATE_VALUE_TYPE_ALIAS_ARRAY_ORDER_CORRUPTION_BOUND_AND_DEDUP_FIXTURES',codec_source_sha256=digest((R/'work/typed_state_cas_codec_20261022.py').read_bytes()),fixtures=rows,actual_saved_cursor1054_step44_preserved=True,alias_order_object_array_corruption_and_capacity_checks=True,stored_bytes=store.bytes_written,new_PF_model_derivative_LP_training_calls=0,
        limits='Lossless storage engineering only. Not a source/controller/performance or fullprocess integration certificate. New missing-only owner/reader/scope/persistence/source/ownership gates remainrequired.')
    atomic_json(O/'Engineering_Readiness.json',report);print(json.dumps(report))

if __name__=='__main__':main()
