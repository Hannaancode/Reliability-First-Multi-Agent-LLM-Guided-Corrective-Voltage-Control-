"""GET-only recovery of closed science; no allocation, notebook execution or model call."""
import hashlib,json,logging,os,time,uuid,zipfile
from pathlib import Path
from urllib.parse import quote
import requests
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession,Request
from colab_cli.client import Client,Prod,Variant,Accelerator
from google_account_profile import verify_account
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'outputs/critical_research_reset_20261010'
EX=R/'public_size_execution';OUT=R/'public_size_same_assignment_preservation'
assert not OUT.exists();OUT.mkdir();logging.disable(logging.CRITICAL)
original=json.loads((EX/'status.json').read_text());assert original['finished_at_utc'] and not original['runtime_released']
(OUT/'owner.claim').write_text(json.dumps({'pid':os.getpid(),'started_at_unix':time.time(),'source':'GET-only preservation; no scientific calls'}))
def h(b):return hashlib.sha256(b).hexdigest()
def expanded(path):
    path=Path(path).resolve()
    return Path('\\\\?\\'+str(path)) if os.name=='nt' else path
def preserve(path,b):
    path=expanded(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==b;return
    # A short sibling name avoids the original 287-character temporary path.
    tmp=path.parent/('recover_'+uuid.uuid4().hex[:8]+'.tmp')
    with tmp.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
    tmp.replace(path)
def write(p,v):preserve(p,json.dumps(v,indent=2,allow_nan=False).encode())
costs=[];started=time.perf_counter();released=False
os.environ['HIERGRID_EXPECTED_GOOGLE_ACCOUNT']=original['expected_account']
credentials=Credentials.from_authorized_user_file(r'C:\Users\HOME\AppData\Roaming\gcloud\application_default_credentials.json')
credentials.refresh(Request());session=AuthorizedSession(credentials)
assert verify_account(session)==original['expected_account'];client=Client(Prod(),session)
nbh=uuid.UUID(original['notebook_hash'])
assignment=client._get_assignment(nbh,variant=Variant.GPU,accelerator=Accelerator.T4)
assert assignment.endpoint==original['endpoint'] and assignment.runtime_proxy_info is not None
write(OUT/'Same_Exact_Assignment_Identity.json',{'notebook_hash':str(nbh),'endpoint':assignment.endpoint,'actual_account':original['expected_account'],'new_allocations':0})
refreshed=time.monotonic()
def get(path):
    global assignment,refreshed
    if time.monotonic()-refreshed>90:
        assignment=client._get_assignment(nbh,variant=Variant.GPU,accelerator=Accelerator.T4)
        assert assignment.endpoint==original['endpoint'] and assignment.runtime_proxy_info is not None;refreshed=time.monotonic()
    began=time.perf_counter()
    response=requests.get(assignment.runtime_proxy_info.url.rstrip('/')+'/api/contents/'+quote(path,safe='/'),
        params={'authuser':'0','colab-runtime-proxy-token':assignment.runtime_proxy_info.token,'content':'1','format':'base64'},timeout=(10,30))
    costs.append({'method':'GET','path':path,'seconds':time.perf_counter()-began,'http_status':response.status_code,'response_bytes':len(response.content)})
    response.raise_for_status();v=response.json()
    return __import__('base64').b64decode(v['content']) if v.get('format')=='base64' else v['content'].encode()
try:
    exit_raw=get('content/hiergrid_execution/outputs/public_size_exit.json');exit_info=json.loads(exit_raw)
    assert exit_info['scientific_process_ended'];write(OUT/'Actual_Ended_Process_Proof.json',exit_info)
    raw=get('content/hiergrid_execution/outputs/public_size_closed_descriptor.json');desc=json.loads(raw);assert desc['scientific_process_ended']
    preserve(EX/'remote_closed_descriptor.json',json.dumps(desc,indent=2).encode())
    for name,m in desc['members'].items():
        p=Path(name);assert not p.is_absolute() and '..' not in p.parts and ':' not in name and '\\' not in name
        target=expanded(EX/'staged/study'/p)
        if target.is_file():assert target.stat().st_size==m['bytes'] and h(target.read_bytes())==m['sha256'];continue
        recovered=None
        for archive in (EX/'packages').glob('*/package.zip'):
            with zipfile.ZipFile(archive) as z:
                if name in z.namelist():recovered=z.read(name);break
        if recovered is None:
            blocks=[]
            for part in m['parts']:
                b=get('content/hiergrid_execution/outputs/public_size_closed_parts/'+part['name'])
                assert len(b)==part['bytes'] and h(b)==part['sha256'];blocks.append(b)
            recovered=b''.join(blocks)
        assert len(recovered)==m['bytes'] and h(recovered)==m['sha256'];preserve(target,recovered)
    for name in ['public_size_science.log','public_size_exit.json']:
        preserve(EX/'staged'/name,get('content/hiergrid_execution/outputs/'+name))
    archive=EX/'preserved_remote_science.zip';assert not archive.exists()
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for name in desc['members']:z.write(expanded(EX/'staged/study'/name),name)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and set(z.namelist())==set(desc['members'])
        for name,m in desc['members'].items():b=z.read(name);assert len(b)==m['bytes'] and h(b)==m['sha256']
    # Release the already-owned exact runtime only after actual closure and preservation.
    client.unassign(original['endpoint']);released=not any(a.endpoint==original['endpoint'] for a in client.list_assignments());assert released
    write(OUT/'Repair_Outcome.json',{'all_actual_closed_artifacts_preserved':True,'runtime_released':released,'scientific_process_ended':True,
       'notebook_hash':original['notebook_hash'],'endpoint':original['endpoint'],'remote_exit_code':desc['exit_code'],
       'original_failed_status_and_source_unchanged':True,'all_closed_member_hashes_and_CRC_passed':True,
       'local_failure_cause':'Original temporary response path287 characters exceeded Windows standard path limit; final245-character response recovered with short sibling temporary path',
       'new_model_PF_optimizer_generation_allocation_calls':0,'seconds':time.perf_counter()-started})
finally:
    write(OUT/'GET_Only_Transfer_Costs.json',costs);session.close()
print(json.dumps({'actual_closed_members':len(desc['members']),'exact_owned_runtime_released':released,'science_not_rerun':True}))
