# Critical precedent for language-native preference adaptation

This review is a research gate, not a new frozen learning plan. The original model, query interface, network, D-SE controller/settings and locked62bank remain preserved. All prior stopped branches stay stopped.

## Closest grid precedent

[Chehade and Zhu, Fine-Tuning LLMs to Generate Economical and Reliable Actions for the Power Grid](https://arxiv.org/html/2602.15350v1), February2026, already combines supervised instruction adaptation, AC-evaluated DPO preferences and verified candidate selection for IEEE118-bus switching. The study uses200scenarios and440preference pairs, with an API-hosted GPT-4.1-mini model. Its comparison includes an MLP. The numerical baseline has the lowest PF-failure rate; reported voltage-quality comparisons use scenarios where the compared adapted policies and MLP all converge. These are useful results, but neither superiority to HierGrid D-SE nor our local0.5Badapter performance follows. Switching, its objective and its verification task differ from shunt control. Applying AC-preference DPO to our actions would reproduce an established pattern, not establish novelty. Our23historical OPTworlds also are not200independent scenarios. A proposed adaptation must keep failures in the overall denominator, match information/training data/budgets, charge preparation and selection, and demonstrate benefit over our strong numerical action prior.

## Cross-domain physical feedback

[Ghosh et al., Preference Learning from Physics-Based Feedback](https://arxiv.org/html/2511.12036v1) uses thermodynamic feedback to tune language models for alloy design. It supports investigating physically derived preference supervision; it is not evidence about our controller, data sufficiency, training time or safety. Physics-derived DPO feedback is therefore also established outside power systems.

## What could justify a different intervention

Our own evidence shows that predicting nominal generator regimes has very little remaining headroom over a numerical control. A language model should not be trained to replace that successful calculation. A different question is whether it can correct the **ranking of scope-valid actions** where an exact measured physical preference disagrees with an available numerical prior. Such errors must first be inventoried on all fixed OPTstates, without outcome-selected worlds or fabricated counterfactual vectors/rewards.

A possible initialization-preserving design would combine a fixed numerical action prior with a trainable language-policy likelihood ratio against its frozen reference. At initialization, the ratio contributes zero and the policy reproduces the prior. Actual preference supervision would have to produce improved action choices, not merely reduced language loss or a different tensor. This design sketch is our hypothesis, not a novelty claim: residual policy learning, preference optimization and physics priors all have prior literature and need an additional focused overlap review. Its exact probability model, decoder, tensor paths, input scope, objective, budgets, costs and controls must be frozen and implemented before a scientific call.

Canonical action strings alone give no new physical information. The existing failed soft-input interventions do not establish whether language-native adapter training will succeed, and this uncertainty does not authorize automatic retraining. Require a strong same-information numerical preference learner and a no-internal-update/reference control. Existing original literal D-SE portfolios with complete both-branch costs remain primary; the numerical prior is an additional control. Positive development ranking would still require fresh matched physical trajectories and genuinely unused confirmation.

No ready preference corpus, novel method, mature trainer or90%success expectation is inferred from these papers. The next safe deliverable is a prospectively fixed OPT-only numerical ranking and measured-preference feasibility design, with raw scope/score/cost/source identities and unknown/failure coverage, before any GPU proposal.
