"""Recorded-label diagnostics, never a physical controller or new oracle."""
import math
import torch
from candidate_predictor_input_contract import Q_GRID
def priority(prediction,allowed,normal):
    assert prediction.shape==(118,9,7) and bool(torch.isfinite(prediction).all())
    p=prediction.detach().cpu();prob=torch.sigmoid(p[...,:3]);gain=p[...,3:]*torch.tensor(normal['scale'])+torch.tensor(normal['mean'])
    pairs=[(b,j) for b in range(118) for j in range(9) if bool(allowed[b,j])]
    # Prospective approximate tuple. Every selected action still needs real verification.
    def key(pair):
        b,j=pair;feasible=bool(prob[b,j,0]>=.5 and prob[b,j,1]>=.5 and gain[b,j,3]>=0.)
        return (int(feasible),int(prob[b,j,2]>=.5),float(gain[b,j,0]),float(gain[b,j,1]),float(gain[b,j,2]),-Q_GRID[j],-b)
    return sorted(pairs,key=key,reverse=True)
def recorded_priority_diagnostic(prediction,allowed,normal,raw_labels,current_vm):
    ordering=priority(prediction,allowed,normal)
    actual={(c['target']['bus'],c['target']['Q_index']):c['target'] for c in raw_labels['measured_candidates']}
    admissible={k:t for k,t in actual.items() if bool(allowed[k]) and t['recorded_verifier']['accepted']}
    best=max((tuple(t['recorded_original_score']) for t in admissible.values()),default=None)
    oracle={k for k,t in admissible.items() if tuple(t['recorded_original_score'])==best}
    lowest=sorted(ordering,key=lambda k:(current_vm[k[0]],Q_GRID[k[1]],k[0]))
    def describe(order):
        result={}
        for k in (1,4,8):
            top=order[:k];known=[p for p in top if p in actual]
            result[str(k)]={'actual_available_predictions':len(top),'known_measured':len(known),
                'unmeasured_unknown':len(top)-len(known),'known_accepted':sum(actual[p]['recorded_verifier']['accepted'] for p in known),
                'recorded_best_score_included':bool(oracle.intersection(top)) if oracle else None}
        return result
    return {'known_measured_candidate_denominator':len(actual),'known_allowed_measured':sum(bool(allowed[k]) for k in actual),
        'known_admissible_oracle_exists':bool(oracle),'recorded_oracle_best_tuple':list(best) if best else None,
        'full_native_scope_plus_cap_candidate_denominator':len(ordering),'model_priority':describe(ordering),
        'current_lowestVm_then_Q_secondary':describe(lowest),
        'model_first':list(ordering[0]) if ordering else None,'known_first_outcome':actual.get(ordering[0]) if ordering else None,
        'not_a_new_physical_recovery_or_DSE_superiority_measurement':True}
