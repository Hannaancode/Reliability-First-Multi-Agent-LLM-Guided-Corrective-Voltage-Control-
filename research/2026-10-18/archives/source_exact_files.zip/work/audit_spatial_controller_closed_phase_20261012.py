"""Independent read-only SOFTWARE evidence audit; zero solver/model calls."""
import hashlib
import json
import os
import pickle
import time
from datetime import datetime, timezone
from pathlib import Path

from candidate_process_evidence_utils import frozen_checks, seal
from native_continuation_preservation_v2 import canonical, extended_local_path
from paid_spatial_controller_checkpoint_v1 import read_checkpoint, validate_chain, process_alive
from trusted_causal_controller_snapshot import write_bytes

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'outputs/critical_research_reset_20261010/spatial_controller_closed_phase_software_20261012'
OUT = BASE/'independent_audit'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text('utf8'))


def main():
    OUT.mkdir(exist_ok=False)
    started = time.perf_counter()
    write_bytes(OUT/'owner.claim', canonical({'actual_pid': os.getpid(), 'actual_parent_pid': os.getppid(),
        'source_sha256': sha(Path(__file__)), 'purpose': 'SOFTWARE_READ_ONLY_NO_SCIENCE'}))
    suite = read(BASE/'Closed_Phase_Software_Readiness.json')
    evidence = read(BASE/'Warm_Returned_Anchor.json')
    protocol = read(BASE/'Protocol.json')
    assert suite['status'] == 'PASS' and suite['check_count'] == 26 and len(set(suite['checks'])) == 26
    assert not process_alive(suite['warm_pid']) and not process_alive(suite['cold_pid'])
    assert suite['warm_pid'] != suite['cold_pid'] != os.getpid()
    for name, digest in protocol['source_sha256'].items():
        assert sha(ROOT/name) == digest, name
    assert suite['source_sha256'] == protocol['source_sha256']
    for script in ['work/check_spatial_controller_checkpoint_20261012.py',
                   'work/check_spatial_controller_closed_phase_20261012.py']:
        source = (ROOT/script).read_text('utf8')
        assert 'LABELLED_MOCK_FAILURE_NOT_PHYSICS' in source and 'pp.runpp = ' in source
    directory = extended_local_path(BASE/'fixture')
    state, manifest = read_checkpoint(evidence['anchor'], expected_protocol=protocol,
        expected_protocol_sha256=sha(BASE/'Protocol.json'), expected_controller_identity=evidence['controller'],
        expected_directory=directory)
    phase_anchor = evidence['closed_phase_anchor']
    assert sha(Path(phase_anchor['path'])) == phase_anchor['sha256']
    closed = read(Path(phase_anchor['path']))
    warm = (directory/closed['closed_journal_relative_path']).read_bytes()
    assert len(warm) == closed['closed_journal_bytes'] and hashlib.sha256(warm).hexdigest() == closed['closed_journal_sha256']
    warm_rows, warm_tip = validate_chain(warm, sha(BASE/'Protocol.json'))
    assert warm_tip == closed['closed_journal_tip'] and len(warm_rows) == state['journal_sequence']+1
    assert warm.startswith(state['journal_bytes']) and warm_rows[-1]['event'] == 'complete_controller_checkpoint_saved'
    cold_rows, cold_tip = validate_chain((directory/'cold_events.jsonl').read_bytes(), sha(BASE/'Protocol.json'))
    events = [x['event'] for x in cold_rows]
    assert events[:2] == ['planned_controller_handoff_bound', 'closed_phase_costs_inherited']
    assert events.count('paid_receipt_reuse') == 2 and events.count('new_query_intent') == 1
    assert events.count('PF_intent') == events.count('PF_return') == 1 and events.count('PF_exception') == 0
    new_id = next(x for x in cold_rows if x['event'] == 'new_query_intent')['payload']['action']
    assert canonical(new_id) == canonical(state['menus'][evidence['parent']][evidence['new_unexecuted_action']])
    old_action_ids = {r.action for r in state['receipts'].values()}
    assert evidence['new_unexecuted_action'] not in old_action_ids
    assert state['controller']['actual_commit_count'] == 1 and state['controller']['remaining_slots'] == 24
    inherited = cold_rows[0]['payload']
    assert inherited['inherited_journal_tip'] == state['journal_tip']
    assert inherited['inherited_journal_sequence'] == state['journal_sequence']
    assert inherited['original_deadline_utc'] == protocol['absolute_deadline_utc']
    assert cold_rows[1]['payload']['known_costs'] == closed['final_query_costs_before_closed_phase_receipt_write']
    partial, _ = read_checkpoint(evidence['partial_anchor'], expected_protocol=protocol,
        expected_protocol_sha256=sha(BASE/'Protocol.json'), expected_controller_identity=evidence['controller'],
        expected_directory=directory)
    assert not partial['resumable'] and len(partial['attempted']) == 3 and len(partial['receipts']) == 2
    assert partial['counters_before_checkpoint']['pf_attempts'] == 2
    assert evidence['unknown_fixture_is_constructed_not_actual_failure'] is True
    checks = {'source_pins_unchanged': True, 'two_actual_distinct_software_processes_ended': True,
        'externally_anchored_complete_state_and_registry': True, 'closed_issuing_prefix_no_subsequent_activity': True,
        'exact_native_ordered_menu_receipt_and_cursor_checks': True, 'warm_two_cold_one_labelled_mock_calls': True,
        'success_and_failure_reused_without_mock_retry': True, 'distinct_new_query_identity_only': True,
        'original_deadline_costs_and_hash_prefix_inherited': True, 'constructed_unknowns_remain_unknown': True}
    frozen = frozen_checks()
    write_bytes(OUT/'Frozen_Original_Checks.json', canonical(frozen))
    result = {'status': 'PASS', 'saved_at_utc': datetime.now(timezone.utc).isoformat(), 'checks': checks,
        'software_checks_passed': 26, 'actual_new_nonlinear_PF_model_optimizer_forecast_cloud_calls': 0,
        'labelled_mock_solver_calls': {'warm': 2, 'cold_new_identity': 1, 'cached_reuse': 0},
        'warm_software_pid': suite['warm_pid'], 'cold_software_pid': suite['cold_pid'],
        'reader_pid': os.getpid(), 'closed_warm_journal_tip': warm_tip, 'closed_cold_journal_tip': cold_tip,
        'original_nine_frozen_checks_pass': frozen['all_passed'],
        'reader_workflow_seconds_before_report_and_archive_write': time.perf_counter()-started,
        'limitations': suite['limitations']+[
            'v1 handoff gate alone is superseded: an anchored closed-phase receipt and unchanged final issuing journal are mandatory.',
            'Runtime/source/context/physical field identity must additionally be fixed and audited for a real new engineering protocol.',
            'Fresh launcher must bind exact actual PID/parent/command/exit and no duplicate owners before any real handoff.',
            'No new physical commitment, full trajectory, superiority result or performance launch has occurred.']}
    write_bytes(OUT/'Independent_Software_Audit.json', canonical(result))
    files = {p.relative_to(BASE).as_posix(): p for p in BASE.rglob('*') if p.is_file() and 'independent_audit' not in p.parts}
    for p in OUT.iterdir():
        if p.is_file():
            files[p.relative_to(BASE).as_posix()] = p
    for name in protocol['source_sha256']:
        files['source/'+Path(name).name] = ROOT/name
    files['source/'+Path(__file__).name] = Path(__file__)
    archive = seal(OUT, files, 'Controller_Checkpoint_Software_Evidence.zip')
    print(json.dumps({'status': 'PASS', 'software_checks': 26, 'archive': archive,
                      'actual_new_PF_model_calls': 0}))


if __name__ == '__main__':
    main()
