## 7.8 Four severe roots with independent physics checks

All four predeclared severe development roots now have complete, independently checked DFF and original Reflection-v4 HG-VF endpoints. The two earlier interrupted language branches were completed through separately frozen missing-only continuations from their saved pending requests. The original failures and paid prefixes remain in the evidence record; their already returned physics and model responses were not regenerated.

| Root | Initial UV | DFF UV / OV | HG-VF UV / OV | Offline HG-SE UV / OV |
| --- | ---: | ---: | ---: | ---: |
| Line 35_MG1 | 56 | 11 / 3 | 7 / 2 | 7 / 2 |
| Line 36_MG1 | 58 | 15 / 2 | 1 / 3 | 1 / 3 |
| Line 84_MG2 | 57 | 18 / 2 | 5 / 3 | 5 / 3 |
| Line 127_MG3 | 55 | 7 / 4 | 13 / 3 | 7 / 4 |


DFF leaves 51 undervoltage buses across the four cases and HG-VF leaves 26, a descriptive reduction of 25 residual violations, or 49.0%. HG-VF improves the UV count in three cases and worsens it in one. Line36MG1 improves from 58 initial UV to one with HG-VF, compared with 15 remaining under DFF. Line127MG3 instead leaves 13 under HG-VF and seven under DFF, so the positive total does not imply improvement on every case.

Strict overvoltage uses Vm > 1.05 p.u., while the unchanged original acceptance guard allows values up to 1.06 p.u. HG-VF adds one strict overvoltage relative to DFF on both Line36MG1 and Line84MG2. Its total of 11 strict overvoltages equals DFF's total only because the other two cases each remove one. The predefined test required at least two UV wins, no UV loss and no additional strict OV in any case. It fails. Neither branch restores the whole 0.95–1.05 p.u. band in any of these four cases.

The unchanged offline HG-SE selector retains the HG-VF trajectory in the first three cases and the DFF trajectory in the fourth. Its selected endpoints contain 20 UV and 12 strict OV. The 60.8% reduction in total residual UV relative to DFF is a descriptive result of evaluating and then selecting between both complete branches. The selector does not include an explicit OV tie criterion. It is not a fresh online language decision, and its cost includes both searches.

DFF uses 29 accepted actions across the four cases, while HG-VF uses 73. The latter comprise 51 direct language actions, 13 guided actions and nine fallback actions. These are accepted-action origins, not raw output validity rates or a causal allocation of the voltage improvement. Guided refinement, fallback and numerical verification all contribute to the combined controller. A numerical D-SE comparison and matched information, intervention and query costs remain necessary for an incremental LLM claim.

The two new suffixes record 1,933 primary PF attempts, 1,927 returned solutions and six preserved exceptions. The independent readers replay each new successful input once, with zero maximum difference over the checked fields; the largest KCL residual is approximately 1.14 × 10⁻⁸ p.u. They verify 140 new controller model responses; the remote records also include two separately charged cold-check generations. Old prefixes, training, shared queries, setup and failed work remain separately paid. Overlapping workflow times are not added as a deployment latency estimate.

For the four matched roots, HG-VF minus DFF residual-UV differences are −4, −14, −13 and +6, giving a mean difference of −6.25 and a median of −8.5. These are descriptive development effects. The four roots were already inspected, so no IID confidence interval, repeated-run variance or unused-confirmation claim is attached to this table. The four-case study does not reconstruct the final 137-scenario manuscript cohort or establish an external-method benchmark.