"""Disposable native1.5B full-context engineering. No policy performance or PF."""
import os,json,time,hashlib,traceback,functools,gc,random
from pathlib import Path
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',CUBLAS_WORKSPACE_CONFIG=':4096:8',HF_HUB_DISABLE_IMPLICIT_TOKEN='1')
ROOT=Path(__file__).resolve().parents[1]
from public_size_u61_preservation import atomic_json,journal,Publisher,file_hash
OUT=ROOT/'outputs/public_size_science';OUT.mkdir(exist_ok=False);began=time.monotonic();p=json.loads((ROOT/'prep/protocol.json').read_text());item=json.loads((ROOT/'prep/Selected_Longest_Engineering_Context.json').read_text());environment=json.loads((ROOT/'outputs/public_size_environment.json').read_text())
costs={'model_load_attempts':0,'model_load_returns':0,'body_forward_attempts':0,'body_forward_returns':0,'backward_attempts':0,'backward_returns':0,'optimizer_attempts':0,'optimizer_returns':0,'PF_generation_controller_calls':0};events=OUT/'events.jsonl';previous='0'*64
atomic_json(OUT/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':file_hash(__file__),'protocol_sha256':file_hash(ROOT/'prep/protocol.json'),'started_at_unix':time.time()})
def event(kind,**data):
    global previous
    assert time.monotonic()-began<p['science_process_seconds'];row={'kind':kind,'elapsed_seconds':time.monotonic()-began,'previous':previous,**data};h=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest();journal(events,{'event':row,'sha256':h});previous=h
def progress(stage):atomic_json(OUT/'progress.json',{'stage':stage,'actual_costs':costs,'updated_unix':time.time()})
publisher=Publisher(OUT,ROOT/'outputs/public_size_transfer',wait_seconds=600)
try:
    import numpy as np,torch
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.use_deterministic_algorithms(True)
    from transformers import AutoModelForCausalLM,BitsAndBytesConfig
    from peft import LoraConfig,get_peft_model,prepare_model_for_kbit_training
    from candidate_process_pretrained_loader import preservation_inventory
    from native_slm_joint_head_v2_20261020 import NativeJointHead
    from native_joint_checkpoint_contract_20261020 import selected,save,restore
    assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
    assert len(item['input_ids'])==3229 and len(item['input_ids'])<=4096 and item['context_index']==8
    assert file_hash(ROOT/'prep/Selected_Longest_Engineering_Context.json')==p['selected_input_sha256']
    for rel,h in p['source_hashes'].items():assert file_hash(ROOT/rel)==h
    assert environment['exact_dependency_count']==111 and environment['base_revision']==p['base_for_new_experiment']['revision']
    contract={'source_hashes':p['source_hashes'],'selected_input_sha256':p['selected_input_sha256'],'protocol_sha256':file_hash(ROOT/'prep/protocol.json'),'base_revision':environment['base_revision'],'engineering_only':True}
    seed=20261020;random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);torch.cuda.reset_peak_memory_stats()
    def load():
        costs['model_load_attempts']+=1;event('model_load_attempt',number=costs['model_load_attempts']);t=time.perf_counter()
        model=AutoModelForCausalLM.from_pretrained(environment['base_snapshot'],local_files_only=True,quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.float16),device_map={'':'cuda:0'},dtype=torch.float16,attn_implementation='sdpa')
        assert model.is_loaded_in_4bit and model.config.model_type=='qwen2' and model.config.hidden_size==1536 and model.config.num_hidden_layers==28
        model=prepare_model_for_kbit_training(model,use_gradient_checkpointing=True,gradient_checkpointing_kwargs={'use_reentrant':False})
        model=get_peft_model(model,LoraConfig(r=16,lora_alpha=16,lora_dropout=0,bias='none',target_modules=['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj'],task_type='CAUSAL_LM'),adapter_name='candidate_process_copy')
        for n,v in model.named_parameters():
            if v.requires_grad:v.data=v.data.float()
        head=NativeJointHead(1536).cuda();active=selected(model,head);assert all('.lora_' in n or n.startswith('head.') for n in active)
        opt=torch.optim.AdamW(list(active.values()),lr=.0002,weight_decay=.01,betas=(.9,.999),eps=1e-8);scaler=torch.amp.GradScaler('cuda',init_scale=1024,growth_interval=2000)
        costs['model_load_returns']+=1;event('model_load_return',number=costs['model_load_returns'],seconds=time.perf_counter()-t);return model,head,opt,scaler
    ids=torch.tensor([item['input_ids']],device='cuda',dtype=torch.long);mask=torch.ones_like(ids);assert ids.shape==(1,3229) and torch.equal(ids.cpu(),torch.tensor([item['input_ids']]))
    fields=item['loss_current_fields_not_forwarded'];q=torch.tensor([fields['current_Q']],device='cuda',dtype=torch.float64);vm=torch.tensor(fields['vm'],device='cuda',dtype=torch.float32);S=torch.tensor(fields['dVm_dQ'],device='cuda',dtype=torch.float32);assert S.shape==(13,3) and q.shape==(1,3) and vm.shape==(13,)
    def application(model,head,phase):
        body=model.get_base_model().model;costs['body_forward_attempts']+=1;event('body_forward_attempt',phase=phase,number=costs['body_forward_attempts'],full_tokens=3229,attention_mask_ones=3229);t=time.perf_counter()
        with torch.autocast('cuda',dtype=torch.float16):hidden=body(input_ids=ids,attention_mask=mask,use_cache=False,return_dict=True).last_hidden_state
        assert hidden.shape==(1,3229,1536) and torch.isfinite(hidden).all();output=head(hidden[:,-1,:],q);u=output['u_mvar'];assert u.dtype==torch.float32 and output['next_q_mvar'].dtype==torch.float64 and torch.equal(output['next_q_mvar'],q-u) and (u.abs()<=torch.tensor(.3,device='cuda')).all()
        pred=vm-S@u[0];loss=torch.relu(.95-pred).square().sum()+torch.relu(pred-1.05).square().sum()+.01*output['next_q_mvar'].float().square().sum();assert loss.isfinite()
        costs['body_forward_returns']+=1;atomic_json(OUT/f'Application_{costs["body_forward_returns"]:02d}.json',{'phase':phase,'loss':float(loss.detach()),'u':u.detach().cpu().tolist(),'Qnext':output['next_q_mvar'].detach().cpu().tolist(),'u_dtype':str(u.dtype),'Qnext_dtype':str(output['next_q_mvar'].dtype),'body_tokens':3229});event('body_forward_return',phase=phase,number=costs['body_forward_returns'],seconds=time.perf_counter()-t,loss=float(loss.detach()));return loss,u,output['next_q_mvar']
    model,head,opt,scaler=load();before=preservation_inventory(model);atomic_json(OUT/'Immutable_Base_Before.json',before);atomic_json(OUT/'Input_And_Trainability.json',{'input_ids_sha256':hashlib.sha256(ids.cpu().numpy().tobytes()).hexdigest(),'full_tokens':3229,'trainable_names':list(selected(model,head)),'LoRA_parameters':18464768,'head_parameters':4611,'same_native_float32_u_float64_Q_transition':True,'current_affine_loss_only_not_physics_or_learning_result':True})
    save(OUT/'initial0_complete.pt',model,head,opt,scaler,0,contract);event('initial_complete_state_saved');progress('initial_complete_cpu_ACK_required');publisher.publish('initial_complete_state_before_any_forward')
    gradient_records=[];model.train();head.train()
    for step in [1,2]:
        opt.zero_grad(set_to_none=True);loss,u,qn=application(model,head,'engineering_train');costs['backward_attempts']+=1;event('backward_attempt',step=step);scaler.scale(loss).backward();costs['backward_returns']+=1;scaler.unscale_(opt)
        gradients={}
        for name,param in selected(model,head).items():
            assert param.grad is not None and torch.isfinite(param.grad).all(),name;gradients[name]={'elements':param.numel(),'nonzero':int(torch.count_nonzero(param.grad).item()),'l2':float(param.grad.norm().item()),'finite':True,'present':True}
        assert all(g['nonzero']>0 for n,g in gradients.items() if '.lora_B.' in n or n.startswith('head.'))
        if step==2:assert all(g['nonzero']>0 for g in gradients.values())
        norm=float(torch.nn.utils.clip_grad_norm_(list(selected(model,head).values()),1.0));assert np.isfinite(norm);event('backward_return',step=step,gradient_norm_before_clip=norm)
        scale=scaler.get_scale();costs['optimizer_attempts']+=1;event('optimizer_attempt',step=step);scaler.step(opt);scaler.update();assert scaler.get_scale()>=scale,'No overflow retry';torch.cuda.synchronize();costs['optimizer_returns']+=1;event('optimizer_return',step=step,scale=scaler.get_scale());gradient_records.append({'step':step,'gradients':gradients,'unclipped_norm':norm});opt.zero_grad(set_to_none=True)
    atomic_json(OUT/'Actual_Gradient_Participation.json',gradient_records);checkpoint=save(OUT/'step2_complete.pt',model,head,opt,scaler,2,contract);assert preservation_inventory(model)==before
    event('two_update_full_state_saved');progress('complete_AdamW_RNG_cursor_CPU_ACK_required');publisher.publish('two_updates_complete_state_before_more_model_calls')
    model.eval();head.eval()
    with torch.no_grad():loss,u,qn=application(model,head,'warm_final_eval');reference={'loss':loss.detach().cpu(),'u':u.detach().cpu(),'Qnext':qn.detach().cpu()}
    assert preservation_inventory(model)==before;del model,head,opt,scaler;gc.collect();torch.cuda.empty_cache()
    model,head,opt,scaler=load();assert preservation_inventory(model)==before;restore_proof=restore(checkpoint,model,head,opt,scaler,contract);model.eval();head.eval()
    with torch.no_grad():loss,u,qn=application(model,head,'cold_complete_restored_eval')
    assert torch.equal(reference['loss'],loss.detach().cpu()) and torch.equal(reference['u'],u.detach().cpu()) and torch.equal(reference['Qnext'],qn.detach().cpu());assert preservation_inventory(model)==before
    peak=torch.cuda.max_memory_allocated();assert peak<=12*1024**3
    result={'status':'COMPLETE_DISPOSABLE_NATIVE15_FULL_CONTEXT_GRADIENT_MEMORY_COMPLETE_COLD_RESTORE_ENGINEERING','actual_costs':costs,'full_tokens':3229,'all394_gradient_tensors_finite_present':True,'all394_nonzero_by_second_update':True,'all392_body_LoRA_and2_head_moment_steps':2,'warm_cold_native_action_and_loss_bit_exact':True,'native_u_float32_Qcursor_float64_exact':True,'frozen_base_quantized_parameters_buffers_and_metadata_unchanged':True,'full_restore':restore_proof,'warm_loss':float(reference['loss']),'warm_u':reference['u'].tolist(),'warm_Qnext':reference['Qnext'].tolist(),'peak_allocated_bytes':peak,'peak_reserved_bytes':torch.cuda.max_memory_reserved(),'workflow_seconds':time.monotonic()-began,'engineering_weights_disposable_not_final_policy_or_performance':True,'no_PF_generation_security_superiority_or_automatic_training_permission':True}
    atomic_json(OUT/'Results.json',result);event('closed_complete_engineering',results_sha256=file_hash(OUT/'Results.json'));progress('complete_preserving_results');publisher.publish('complete_cold_restore_engineering_results')
except BaseException as exc:
    atomic_json(OUT/'Failure.json',{'failure_type':type(exc).__name__,'failure':str(exc),'traceback':traceback.format_exc(),'actual_costs':costs,'workflow_seconds':time.monotonic()-began});progress('failed_partial_preserved');raise
