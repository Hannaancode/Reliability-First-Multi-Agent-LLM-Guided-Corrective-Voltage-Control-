"""Mode-isolated original paid commits plus complete durable query-prefix anchors.

All original commit/checkpoint function ASTs remain byte-structure identical.
Query history lives in an anchored append-only journal, preventing arbitrary
growth from silently truncating a controller checkpoint. Cold restore verifies
the complete saved prefix and exposes precisely that prefix for cache recovery.
"""
import ast,hashlib,json,os,struct
from pathlib import Path
import paid_joint_commit_v1 as original

SOURCE=Path(original.__file__);TREE=ast.parse(SOURCE.read_text('utf-8'))
FUNCTIONS=[node for node in TREE.body if isinstance(node,ast.FunctionDef)]
MODE='ACTUAL_PAID_PROTECTED_OPERATION_AWARE_RECEDING_LOOKAHEAD'
environment=original.__dict__.copy();environment['MODE']=MODE
exec(compile(ast.Module(body=FUNCTIONS,type_ignores=[]),str(SOURCE),'exec'),environment)
for definition in FUNCTIONS:globals()[definition.name]=environment[definition.name]
SOURCE_CERTIFICATE={'original_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'all_original_commit_checkpoint_function_ASTs_unchanged':True,'only_change':'Separate prospective receding mode',
    'no_science_or_launch_on_import':True}
HISTORY_KEY='__COMPLETE_DURABLE_PAID_QUERY_HISTORY_PREFIX__'
ROOT=Path(__file__).resolve().parents[1]
def canonical_record(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

class History:
    """Hashed, length-framed durable records with a prospectively bounded size."""
    def __init__(self,path,*,source_anchor,input_anchor,max_bytes):
        self.path=Path(path).resolve()
        if not self.path.is_relative_to(ROOT):raise ValueError('History outside authorized workspace')
        if type(max_bytes) is not int or max_bytes<=0:raise ValueError('Declared history byte bound required')
        self.source_anchor=source_anchor;self.input_anchor=input_anchor;self.max_bytes=max_bytes
        self.file=self.path.open('xb');self.prefix=hashlib.sha256();self.previous='0'*64;self.count=0
    def append(self,event,payload):
        body={'event':event,'payload':payload,'previous':self.previous,'source_anchor':self.source_anchor,'input_anchor':self.input_anchor}
        encoded=canonical_record(body);frame=struct.pack('<Q',len(encoded))+encoded
        if self.file.tell()+len(frame)>self.max_bytes:raise ValueError('Declared history bound exhausted; no extension')
        self.file.write(frame);self.file.flush();os.fsync(self.file.fileno());self.prefix.update(frame)
        self.previous=hashlib.sha256(encoded).hexdigest();self.count+=1
    def anchor(self):
        return {'path':str(self.path.relative_to(ROOT)),'bytes':self.file.tell(),'sha256':self.prefix.hexdigest(),
            'last_record_sha256':self.previous,'records':self.count,'source_anchor':self.source_anchor,
            'input_anchor':self.input_anchor,'maximum_declared_bytes':self.max_bytes}
    def close(self):self.file.close()

def verify_history(anchor):
    path=(ROOT/anchor['path']).resolve()
    if not path.is_relative_to(ROOT):raise ValueError('History anchor escapes workspace')
    if path.stat().st_size<anchor['bytes']:raise ValueError('Saved query prefix missing/truncated')
    digest=hashlib.sha256();previous='0'*64;records=[];read_bytes=0
    with path.open('rb') as stream:
        while read_bytes<anchor['bytes']:
            header=stream.read(8)
            if len(header)!=8:raise ValueError('Missing record header')
            size=struct.unpack('<Q',header)[0]
            if not 0<size<=32*1024**2 or read_bytes+8+size>anchor['bytes']:raise ValueError('Invalid prefix record bound')
            data=stream.read(size)
            if len(data)!=size:raise ValueError('Missing record bytes')
            record=json.loads(data)
            if record['previous']!=previous or record['source_anchor']!=anchor['source_anchor'] or record['input_anchor']!=anchor['input_anchor']:
                raise ValueError('History source/input/chain mismatch')
            digest.update(header+data);previous=hashlib.sha256(data).hexdigest();read_bytes+=8+size;records.append(record)
    if digest.hexdigest()!=anchor['sha256'] or previous!=anchor['last_record_sha256'] or len(records)!=anchor['records']:
        raise ValueError('History prefix identity mismatch')
    return records

def save_complete(path,state,anchors):
    registry=state['paid_query_registry']
    if HISTORY_KEY not in registry:raise ValueError('Complete query-history anchor is mandatory')
    verify_history(registry[HISTORY_KEY])
    return save(path,state,anchors)

def restore_complete(path,receipt):
    state=restore(path,receipt)
    if HISTORY_KEY not in state['paid_query_registry']:raise ValueError('Missing complete history anchor')
    history=verify_history(state['paid_query_registry'][HISTORY_KEY])
    return state,history
