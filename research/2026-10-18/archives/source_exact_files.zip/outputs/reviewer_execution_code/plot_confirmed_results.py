"""Standalone scientific plots from complete saved main-campaign evidence."""
from pathlib import Path
import json,csv,os
os.environ['MPLCONFIGDIR']=str(Path('work/reporting_matplotlib_cache').resolve())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('outputs');d=json.loads((root/'main_campaign_detailed_audit.json').read_text());assert d['checkpoint_checks']['cases']==62
out=root/'reviewer_figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'figure.dpi':160,'savefig.dpi':220,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
    fig.tight_layout();fig.savefig(out/(name+'.png'),bbox_inches='tight');fig.savefig(out/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
valid=[r for r in d['rows'] if r['valid_pair']]
counts=[sum(r['HG-SE_uv']<r['D-SE_uv'] for r in valid),sum(r['HG-SE_uv']==r['D-SE_uv'] for r in valid),sum(r['D-SE_uv']<r['HG-SE_uv'] for r in valid),62-len(valid)]
fig,ax=plt.subplots(figsize=(6.6,3.8));bars=ax.bar(['HG-SE lower UV','Equal UV','D-SE lower UV','Invalid pair'],counts,color=['#218c74','#426b9e','#c57924','#777777']);ax.bar_label(bars,padding=4);ax.set(ylim=(0,65),ylabel='Locked cases',title='Paired terminal residual undervoltage: all 62 cases');ax.text(.01,-.20,'60 numerical pairs; 2 invalid cases retained',transform=ax.transAxes,fontsize=9);save(fig,'main_paired_uv_counts')
fig,axs=plt.subplots(1,3,figsize=(10.8,3.7));methods=['D-SE','HG-SE'];totals=d['full_bank_costs_including_invalid_case_attempts']
for ax,key,title,scale,label in zip(axs,['pf_attempts','wall_seconds','llm_calls'],['Charged AC power flows','Charged branch wall time','Actual LLM calls'],[1,60,1],['Attempts','Minutes','Calls']):
    vals=[totals[m][key]/scale for m in methods];bars=ax.bar(methods,vals,color=['#426b9e','#218c74']);ax.bar_label(bars,labels=[f'{v:,.0f}' for v in vals],padding=3);ax.set(ylabel=label,title=title,ylim=(0,max(vals)*1.18 or 1))
fig.suptitle('Planning cost over all 62 cases, including invalid cases',fontsize=12);save(fig,'main_charged_compute')
fig,ax=plt.subplots(figsize=(6.6,3.8));names=['DFF','DFF-ALT','HG-VF','D-SE','HG-SE'];values=[d['branch_costs_and_valid_case_uv'][n]['uv_clear_cases'] for n in names[:3]]+[sum(r[n+'_uv']==0 for r in valid) for n in names[3:]];bars=ax.bar(names,values,color=['#777777','#426b9e','#218c74','#426b9e','#218c74']);ax.bar_label(bars,labels=[f'{n}/62' for n in values],padding=4);ax.set(ylim=(0,68),ylabel='Cases with finite terminal UV = 0',title='Branch and portfolio outcomes on the locked bank');ax.text(.01,-.18,'UV clearance does not imply full operating-limit feasibility.',transform=ax.transAxes,fontsize=9);save(fig,'main_branches_and_portfolios')
captions='''# Confirmed-result figure captions

1. **Paired residual UV.** Comparison uses 60 finite paired outcomes from the frozen 62-case bank. Two disconnected-load cases remain invalid in the denominator and failure ledger. Counts reflect the original strict 0.95 threshold, not a new tolerance.
2. **Charged planning cost.** Each portfolio is charged for DFF plus its own second branch, including discarded trajectories and failed/invalid-case attempts. Storage reuse does not make DFF free. Wall times are the observed branch times on the campaign hardware; fixed branch order and runtime restoration limit general timing claims. Individual PF and generation durations were not separately recorded in this main run.
3. **Branches and portfolios.** Successful UV clearance means finite terminal metrics with zero original residual UV; it does not establish every operating constraint is satisfied. Independent audit found declared slack-limit violations in every locked case. Original raw OV counts and diagnostic boundary tolerance remain separately recorded.

Source: `main_campaign_detailed_audit.json`, the frozen matched protocol, per-case records, and the independent physical audit. These figures contain no central or full AC-reference conclusions.
'''
(out/'Captions.md').write_text(captions,encoding='utf-8')
print('CONFIRMED_MAIN_FIGURES_SAVED',3,flush=True)
