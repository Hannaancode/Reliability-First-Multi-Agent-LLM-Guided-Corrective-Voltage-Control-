"""One exact native study owner followed by its sole independent reader."""
import json,os,subprocess
from pathlib import Path
from reflection118_chronological_core_20261022 import R,put,sha
P=R/'outputs/reflection118_chronological_preparation_20261022'
O=R/'outputs/r118chrono_handoff_20261022'
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__)})
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf-8') as f:
   code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_atomic_source_owner_20261022.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),{'exit_code':code});assert code==0,'Preserve all failed/partial evidence; no retry'
 put(O/'Completion.json',{'status':'ACTUAL_STUDY_AND_SOLE_READER_TERMINAL'})
if __name__=='__main__':main()
