"""Complete source-native inference state; no altered policy definition or calls."""
import copy,random
import candidate_process_runtime
import numpy as np
import torch

def snapshot(models):
    return {f'{a}::{i}::{n}':v.detach().cpu().numpy().copy() for a,g in models.items() for i,m in enumerate(g) for n,v in m.state_dict().items()}

def restore(models,values):
    expected=set(snapshot(models));assert set(values)==expected,'Incomplete or extraneous model state'
    for a,g in models.items():
        for i,m in enumerate(g):
            state=m.state_dict()
            for n,old in state.items():
                v=values[f'{a}::{i}::{n}'];assert v.shape==tuple(old.shape) and v.dtype==old.detach().numpy().dtype
                state[n]=torch.from_numpy(v.copy())
            m.load_state_dict(state,strict=True);m.eval()
    after=snapshot(models);assert all(np.array_equal(v,after[n]) for n,v in values.items())

def source_transition(model,algorithm,before):
    expected={n:v.clone() for n,v in before.items()}
    if algorithm=='safe-ddpg':
        for name in ['b','c']:
            v=expected[name].clamp(min=0);expected[name]=model.scale*v/torch.norm(v,1)
    actual=model.state_dict();assert set(actual)==set(expected)
    assert all(torch.equal(v.detach().cpu(),expected[n]) for n,v in actual.items()),'Non-native inference-state mutation'

def check_cursor(packet,models,deadline):
    required={'complete_model_state','paid_receipts','attempted_inputs','historical_attempts','python_rng','numpy_rng','torch_rng','absolute_deadline_monotonic','environment','last_Q','state','history','protocol_sha256'}
    assert required<=set(packet),'Incomplete causal checkpoint'
    assert packet['absolute_deadline_monotonic']==deadline,'No renewal of absolute resource bound'
    current=snapshot(models);assert set(current)==set(packet['complete_model_state'])
    assert all(np.array_equal(v,packet['complete_model_state'][n]) for n,v in current.items())
    # Construct cold policy objects without constructors, new random initialization,
    # load of a base/checkpoint, or a forward call. This verifies actual bytes.
    cold=copy.deepcopy(models);restore(cold,packet['complete_model_state']);cold_values=snapshot(cold)
    assert all(np.array_equal(v,cold_values[n]) for n,v in current.items())
    assert packet['torch_rng'].dtype==np.uint8 and len(packet['python_rng'])==3 and len(packet['numpy_rng'])==5
    assert packet['python_rng']==random.getstate() and np.array_equal(packet['torch_rng'],torch.get_rng_state().numpy())
    now=np.random.get_state();saved=packet['numpy_rng']
    assert now[0]==saved[0] and np.array_equal(now[1],saved[1]) and now[2:]==saved[2:]
