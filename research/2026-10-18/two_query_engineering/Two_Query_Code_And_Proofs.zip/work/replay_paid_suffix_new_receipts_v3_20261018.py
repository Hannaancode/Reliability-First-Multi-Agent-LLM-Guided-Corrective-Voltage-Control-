"""Add ONLY the two newly audited receipts to the unchanged causal screen.

Zero new model/PF/derivative/forecast/solve calls. The first previously fixed
unstarted leg is replayed with a changed evidence set; old screen owners and
scientific workers are never restarted. Unsupported successors remain UNKNOWN.
"""
import ast,copy,hashlib,json,os,time
from collections.abc import Mapping
from pathlib import Path
from types import SimpleNamespace
import replay_unstarted_paid_suffix_numeric_v2_20261018 as old
import verified_paid_cache_engine_v2_20261018 as binding
from public118_slsqp_native_20261018 import R,read,put,sha
from exact_two_paid_query_engineering_20261018 import B as TWO
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from equal_operation_benchmark_v2 import decode_capsule
from strict_saved_native_input_match_v2_20261018 import require_same
from audit_full_receding_linear_composed_v4_20261018 import check_query
from locked_source_receipt_verifier_v1_20261018 import LockedSourceSnapshot
B=R/'outputs/unstarted_paid_suffix_new_receipts_v3_20261018'
PREP=R/'outputs/unstarted_paid_suffix_new_receipts_v3_preparation_20261018'

class Overlay(Mapping):
    def __init__(self,prior,extra):self.prior=prior;self.extra=extra
    def __contains__(self,key):return key in self.extra or key in self.prior
    def __getitem__(self,key):return copy.deepcopy(self.extra[key]) if key in self.extra else self.prior[key]
    def __iter__(self):return iter(list(self.prior)+list(self.extra))
    def __len__(self):return len(self.prior)+len(self.extra)

class Registry(binding.VerifiedPaidUseRegistry):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.new_lock=LockedSourceSnapshot(TWO/'Protocol.json');self.new_data={};self.new_uses=0
        assert read(TWO/'audit_source_claim_v2/Independent_Audit.json')['status']=='PASS_COMPLETE_FIXED_TWO_QUERY_WARM_COLD_AND_CHARGED_REPLAY_ENGINEERING'
        assert read(TWO/'reader_source_claim_repair_v2/Completion.json')['reader_exit_code']==0
        self.new_p=read(TWO/'Protocol.json')
        for mode in ('warm','cold'):
            root=TWO/mode;closed=read(root/'Closed_Manifest.json')
            for rel,h in closed['members'].items():assert sha(root/rel)==h
            item=read(root/'Result.json')['receipt'];msg=item['message'];key=self.new_p['point']+'|'+msg['aid'];r=copy.deepcopy(msg['record'])
            r['after_reference']={'kind':'external_capsule','base':str(TWO.relative_to(R)),'descriptor':{**r['after_reference']['descriptor'],'path':mode+'/capsules.bin'}}
            intents={};returns={};exceptions={}
            for raw in (root/'scientific.jsonl').read_bytes().splitlines():
                e=json.loads(raw);v=e['data']
                if e['event']=='PF_intent':intents[v['identity']]=v
                elif e['event']=='PF_return':returns[v['PF_id']]=v
                elif e['event']=='PF_exception':exceptions[v['PF_id']]=v
            self.new_data[key]={'record':r,'message':msg,'intents':intents,'returns':returns,'exceptions':exceptions,'root':root}
        self.cache=Overlay(self.cache,{k:v['record'] for k,v in self.new_data.items()});self.new_stream=(self.path/'new_two_receipt_uses.jsonl').open('xb')
    def lookup(self,node,row,key):
        if key not in self.new_data:return super().lookup(node,row,key)
        t=time.perf_counter();assert key==point_key(node['net'],node['cursor'])+'|'+action_key(row)
        d=self.new_data[key];assert row==d['message']['row'];native=build_verifier(self.runner.rescue,node['cursor'])[1](copy.deepcopy(node['net']),action(row))
        pid=d['message']['record']['actual_measured_receipt']['PF_id']
        with (d['root']/'capsules.bin').open('rb') as pack:
            require_same(native,decode_capsule(pack,d['intents'][pid]['before'])['net'])
            check_query(node,row,d['message'],cache={},intents=d['intents'],returns=d['returns'],exceptions=d['exceptions'],pack=pack,p=self.new_p,runner=self.runner)
        r=copy.deepcopy(d['record']);seconds=time.perf_counter()-t;r['source_original_receipt_id']=r['receipt_id'];r['receipt_id']='ARCHIVED_NEW_TWO_'+hashlib.sha256(key.encode()).hexdigest()
        use={'key':key,'source_protocol_sha256':sha(TWO/'Protocol.json'),'independent_audit_sha256':sha(TWO/'audit_source_claim_v2/Independent_Audit.json'),
            'record_sha256':hashlib.sha256(json.dumps(d['record'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),'actual_verification_CPU_seconds':seconds,'new_PF':0}
        raw=json.dumps(use,sort_keys=True,separators=(',',':')).encode()+b'\n';self.new_stream.write(raw);self.new_stream.flush();os.fsync(self.new_stream.fileno());self.new_uses+=1
        r['verified_use_reference']={'path':str((self.path/'new_two_receipt_uses.jsonl').relative_to(R)),'prefix_bytes':self.new_stream.tell(),
            'event_sha256':hashlib.sha256(raw[:-1]).hexdigest(),'actual_verification_CPU_seconds':seconds};return r
    def close(self):
        self.new_stream.close();self.new_lock.close();super().close()

def main():
    PREP.mkdir(exist_ok=False)
    files=[Path(__file__),Path(old.__file__),R/'work/verified_paid_cache_engine_v2_20261018.py',TWO/'Protocol.json',TWO/'audit_source_claim_v2/Independent_Audit.json',TWO/'reader_source_claim_repair_v2/Completion.json']
    p=read(TWO/'Protocol.json')
    put(PREP/'Protocol.json',{'status':'FROZEN_READONLY_CHANGED_EVIDENCESET_SCREEN','source_input_sha256':{str(x.relative_to(R)):sha(x) for x in files},'runtime_versions':p['runtime_versions'],
        'selection':'Same previously fixed first unstarted leg and unchanged policies; add BOTH new fixed receipts, including both rejections. No favorable receipt selection.',
        'bound_seconds':900,'no_model_PF_optimizer_derivative_forecast_solve':True,'not_a_new_actual_trajectory':True})
    guard=LockedSourceSnapshot(PREP/'Protocol.json')
    try:
        node=copy.deepcopy(next(n for n in ast.parse(Path(old.__file__).read_text('utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='main'))
        # Only the independent CPU analysis resource bound changes; the query,
        # menu, action, score, stop/projection and scientific blockers are exact.
        for n in ast.walk(node):
            if isinstance(n,ast.Constant) and type(n.value) is int and n.value==1800:n.value=900
        proxy=SimpleNamespace(**binding.__dict__);proxy.VerifiedPaidUseRegistry=Registry
        env=old.__dict__.copy();env.update(B=B,binding=proxy,__file__=__file__)
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(old.__file__),'exec'),env);env['main']()
    finally:guard.close()
if __name__=='__main__':main()
