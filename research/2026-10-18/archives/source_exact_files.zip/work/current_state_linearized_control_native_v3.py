"""Current AC-equation sensitivity prototype; no power-flow solves/LLM.

Local Jacobian derivatives are analytic, while finite-Q successor forecasts are
approximations. Observed Q-bound active-set inference is explicitly imperfect.
This is a strong additional numerical control, not a new learned controller.
"""
import copy,math
import numpy as np
import pandas as pd
import pandapower as pp
from pandapower.converter.pypower.to_ppc import to_ppc
from pandapower.pypower.makeYbus import makeYbus
from pandapower.pd2ppc import _pd2ppc
from pandapower.pypower.dSbus_dV import dSbus_dV
from pandapower.pypower.idx_bus import BUS_TYPE,REF,PV,PQ
from candidate_predictor_input_contract import validate_observation,Q_GRID
def decode(v):
    if isinstance(v,dict) and set(v)=={'missing'}:
        assert v['missing']=='pandas.NA';return pd.NA
    if isinstance(v,dict) and set(v)=={'nonfinite'}:return float(v['nonfinite'])
    if isinstance(v,list):return [decode(x) for x in v]
    return v
def materialize_observed_network(base,observation):
    validate_observation(observation);net=copy.deepcopy(base)
    for table,frame in observation['physical_tables'].items():
        prior=net[table];current=prior.reindex(frame['index']).copy()
        for j,col in enumerate(frame['columns']):
            values=[decode(row[j]) for row in frame['values']]
            current[col]=pd.Series(values,index=frame['index'])
            if col in prior and not current[col].isna().any():current[col]=current[col].astype(prior[col].dtype)
        net[table]=current
    assert net.switch.empty and net.impedance.empty and net.trafo3w.empty
    assert all(np.isfinite(net.res_bus.vm_pu)) and all(np.isfinite(net.res_bus.va_degree))
    return net
def sensitivity_at_observed_state(base,observation):
    net=materialize_observed_network(base,observation)
    # Conversion evaluates no nonlinear power-flow solver.
    to_ppc(net,calculate_voltage_angles=True,trafo_model='t',check_connectivity=True,
           voltage_depend_loads=False,init='results',mode='pf')
    _,case=_pd2ppc(net)
    assert len(case['bus'])==118
    lookup=net._pd2ppc_lookups['bus'];mapping=np.array([lookup[b] for b in range(118)],dtype=int)
    assert set(mapping)==set(range(118))
    Y,_,_=makeYbus(case['baseMVA'],case['bus'],case['branch'])
    voltage=np.empty(118,dtype=complex)
    voltage[mapping]=net.res_bus.loc[range(118),'vm_pu'].to_numpy()*np.exp(1j*np.deg2rad(net.res_bus.loc[range(118),'va_degree'].to_numpy()))
    types=case['bus'][:,BUS_TYPE].astype(int).copy();inferred=[]
    # All current in-service generators at a specified PV bus must be at a
    # measured Q bound before treating its magnitude as free in this estimate.
    for bus in range(118):
        position=mapping[bus]
        if types[position]!=PV:continue
        gens=net.gen[(net.gen.bus==bus)&net.gen.in_service]
        bounded=[]
        for index,row in gens.iterrows():
            q=float(net.res_gen.at[index,'q_mvar']);lo=float(row['min_q_mvar']);hi=float(row['max_q_mvar'])
            bounded.append(math.isfinite(lo) and math.isfinite(hi) and (abs(q-lo)<=1e-8 or abs(q-hi)<=1e-8))
        if bounded and all(bounded):types[position]=PQ;inferred.append(bus)
    nonref=np.flatnonzero(types!=REF);pq=np.flatnonzero(types==PQ)
    assert len(nonref)==117 and len(pq)>0
    dVm,dVa=dSbus_dV(Y,voltage)
    J=np.block([[dVa.real.toarray()[np.ix_(nonref,nonref)],dVm.real.toarray()[np.ix_(nonref,pq)]],
                [dVa.imag.toarray()[np.ix_(pq,nonref)],dVm.imag.toarray()[np.ix_(pq,pq)]]])
    rhs=np.zeros((len(nonref)+len(pq),118))
    for bus in range(118):
        where=np.flatnonzero(pq==mapping[bus])
        if len(where):rhs[len(nonref)+where[0],bus]=abs(voltage[mapping[bus]])**2/case['baseMVA']
    response=np.linalg.solve(J,rhs);assert np.isfinite(response).all()
    residual=float(np.max(np.abs(J@response-rhs)));assert residual<=1e-8
    dvoltage=np.zeros((118,118));dvoltage[pq,:]=response[len(nonref):,:]
    # Rows are original bus order; columns already are original action bus order.
    return {'voltage_pu':np.abs(voltage)[mapping],'dVm_per_MVAr':dvoltage[mapping,:],
        'jacobian':J,'Ybus':Y,'complex_voltage':voltage,'dS_dVm':dVm,'dS_dVa':dVa,
        'observed_Q_bound_inferred_PQ_buses':inferred,'specified_PV_bus_count':int(sum(case['bus'][:,BUS_TYPE]==PV)),
        'inferred_PQ_bus_count':len(pq),'linear_system_residual':residual,
        'linear_algebra_condition_number':float(np.linalg.cond(J)),
        'not_original_solver_active_set_certificate':True,'new_PF_calls':0}
def algebra_derivative_check(sensitivity,epsilon=1e-6):
    Y=sensitivity['Ybus'];V=sensitivity['complex_voltage'];vm=np.abs(V);va=np.angle(V);a=sensitivity['dS_dVa'].toarray();m=sensitivity['dS_dVm'].toarray()
    f=lambda vector:vector*np.conj(Y@vector)
    errors=[]
    for bus in range(118):
        angle=np.zeros(118);angle[bus]=epsilon
        fd=(f(vm*np.exp(1j*(va+angle)))-f(vm*np.exp(1j*(va-angle))))/(2*epsilon)
        errors.append(float(np.max(np.abs(fd-a[:,bus]))/max(1.,np.max(np.abs(a[:,bus])))))
        change=np.zeros(118);change[bus]=epsilon
        fd=(f((vm+change)*np.exp(1j*va))-f((vm-change)*np.exp(1j*va)))/(2*epsilon)
        errors.append(float(np.max(np.abs(fd-m[:,bus]))/max(1.,np.max(np.abs(m[:,bus])))))
    assert max(errors)<=1e-6
    return {'actual_analytic_derivative_columns':236,'actual_AC_equation_function_evaluations':472,
        'maximum_relative_derivative_error':max(errors),'new_PF_calls':0}
