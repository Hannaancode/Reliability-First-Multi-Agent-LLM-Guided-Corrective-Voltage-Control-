"""One new primary and one pinned first reader. No retry or budget extension."""
from pathlib import Path
from datetime import datetime,timezone
import os,json,subprocess,hashlib
R=Path(__file__).resolve().parents[1];P=R/'outputs/nonlinear500_receding_acquisition_preparation_20261030';O=R/'outputs/nonlinear500_receding_acquisition_handoff_20261030'
def put(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2);f.flush();os.fsync(f.fileno())
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',dict(actual_pid=os.getpid(),parent_pid=os.getppid(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
 outcomes={}
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf-8') as log:
   code=subprocess.call([str(R/'work/physics_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_acquisition_source_bound_owner_20261030.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),dict(exit_code=code,at_utc=datetime.now(timezone.utc).isoformat()))
  spec=json.loads((P/name).read_text(encoding='utf-8'))['single_owner'];endpath=R/spec['coordination']/'End_ACK.json'
  end=None if not endpath.exists() else json.loads(endpath.read_text(encoding='utf-8'))
  outcomes[name]=dict(launcher_exit=code,end_ack=end)
  if end is None or end.get('actual_owned_chain_ended') is not True:
   put(O/'Completion.json',dict(status='UNKNOWN_OWNED_CHAIN_NOT_CERTIFIED_TERMINAL',outcomes=outcomes,no_retry=True))
   raise RuntimeError('No terminal ownership certificate; reader not permitted')
  claimpath=R/spec['output']/'owner.claim'
  assert claimpath.exists(),'Terminal owner claim absent'
  claim=json.loads(claimpath.read_text(encoding='utf-8'))
  assert end['protocol_sha256']==hashlib.sha256((P/name).read_bytes()).hexdigest(),'Wrong owner protocol End_ACK'
  assert end['source_sha256']==spec['sha256']==claim['source_sha256'],'Wrong actual source End_ACK'
  assert end['source_and_parent_authenticated'] is True and end['actual_pid']==claim['actual_pid'],'End_ACK does not bind exact source owner'
  assert end['launcher_pid']==claim['parent_pid'],'End_ACK parent chain changed'
  boundpath=R/spec['output']/'Bound_Owner_ACK.json'
  if boundpath.exists():
   bound=json.loads(boundpath.read_text(encoding='utf-8'))
   assert bound['actual_pid']==claim['actual_pid'] and bound['actual_parent_pid']==claim['parent_pid'],'Bound ACK owner changed'
  if name=='Primary_Owner_Protocol.json':
   primary=R/spec['output'];closed=primary/'Closed_Manifest.json';result=primary/'Result.json'
   if not closed.exists() or not result.exists():
    put(O/'Completion.json',dict(status='TERMINAL_PRIMARY_UNCLOSED_AUDIT_NOT_STARTED',outcomes=outcomes,
     limitation='Preserve raw failure/claims and all unclosed science; only safe additive mechanical closure may follow, never a retry.',no_retry=True))
    return
   files={x['path']:x for x in json.loads(closed.read_text(encoding='utf-8'))['files']}
   assert files['Result.json']['sha256']==hashlib.sha256(result.read_bytes()).hexdigest(),'Primary result is not the closed file'
   # The pinned reader is explicitly partial-aware; nonzero primary exit does
   # not erase a genuinely closed partial. It is never treated as success here.
  elif code!=0:
   put(O/'Completion.json',dict(status='TERMINAL_FIRST_READER_FAILURE_RETAINED',outcomes=outcomes,no_retry=True))
   raise RuntimeError('First reader failed; no repeated independent phase')
 put(O/'Completion.json',dict(status='ACQUISITION_AND_FIRST_READER_TERMINAL',outcomes=outcomes,at_utc=datetime.now(timezone.utc).isoformat()))
 print('ACQUISITION_AND_FIRST_READER_CLOSED')
if __name__=='__main__':main()
