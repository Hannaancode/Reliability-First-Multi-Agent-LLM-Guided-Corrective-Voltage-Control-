"""Read-only failed-launch audit; no model, solver, allocation or restart."""
from pathlib import Path
from datetime import datetime
import ast, hashlib, json, subprocess, zipfile
from candidate_process_evidence_utils import ROOT, read, write, sha, seal, frozen_checks
BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
EX=BASE/'pretrained_learning_execution'; PREP=BASE/'pretrained_learning_preparation'
OUT=BASE/'pretrained_learning_zero_forward_failure_audit'
assert not OUT.exists()
state=read(EX/'status.json')
assert state['runtime_released'] and state['all_actual_artifacts_preserved'] and state['remote_exit_code']==1
for claim in [EX/'owner.claim', BASE/'pretrained_learning_audit_continuation/owner.claim']:
    raw=claim.read_text(); pid=int(raw) if raw.strip().isdigit() else json.loads(raw)['actual_pid']
    p=subprocess.run(['powershell','-NoProfile','-Command',f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if ($p) {{$p.CommandLine}}"],capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    assert not p.stdout.strip(), 'Prior owner must have actually ended'
descriptor=read(EX/'remote_output_descriptor.json'); archive=EX/'preserved_remote_outputs.zip'
assert archive.stat().st_size==descriptor['bytes'] and sha(archive)==descriptor['sha256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist())) and z.testzip() is None
    assert set(z.namelist())==set(descriptor['members'])
    for n,m in descriptor['members'].items():
        b=z.read(n); assert len(b)==m['bytes'] and hashlib.sha256(b).hexdigest()==m['sha256']
        assert (EX/'staged/study'/n).read_bytes()==b
SCI=EX/'staged/study'
for n,m in read(SCI/'Closed_Actual_Manifest.json').items():
    assert (SCI/n).stat().st_size==m['bytes'] and sha(SCI/n)==m['sha256']
for n,h in read(PREP/'Program_Input_Manifest.json').items(): assert sha(ROOT/n)==h
assert read(EX/'staged/exact_dependency_check.json')=={'checked_count':111,'differences':{}}
assert read(EX/'staged/remote_frozen_environment.json')==read(PREP/'Expected_Environment.json')
assert read(SCI/'protocol.json')==read(PREP/'protocol.json')
events=[json.loads(x) for x in (SCI/'events.jsonl').read_text().splitlines()]
assert len(events)==1 and events[0]['event']=='terminal_failure'
failure=read(SCI/'Terminal_Failure.json')
counts=failure['actual_counts']; assert set(counts)=={'frozen_original_body_heads'}
assert all(v==0 for v in counts['frozen_original_body_heads'].values())
assert failure['forbidden_counts']=={'PF_attempts':0,'generation_attempts':0}
assert 'sum(p.numel() for p in actual.values())==expected' in failure['traceback']
source=ROOT/'work/candidate_process_pretrained_learning_remote.py'
tree=ast.parse(source.read_text()); lines=source.read_text().splitlines()
assert lines[76].strip()=='assert sum(p.numel() for p in actual.values())==expected'
assert next(i for i,l in enumerate(lines) if "evaluate(wrapper,rows,'untrained'" in l)>76
assert not list(SCI.rglob('*.pt')) and not list(SCI.rglob('*scores*'))
OUT.mkdir()
report={'all_partial_integrity_and_identity_gates_passed':True,
 'failed_notebook':state['notebook_hash'],'exact_owned_runtime_released':True,
 'one_allocation_request':state['allocation_requests']==1,'all_actual_artifacts_preserved':True,
 'exact_111_environment_and_original_program_inputs_verified':True,
 'actual_pretrained_model_forward_backward_optimizer_PF_generation_counts':counts,
 'failure_location':'actual trainable parameter count assertion BEFORE first scientific forward',
 'scientific_workflow_before_failure_seconds':events[0]['elapsed_seconds'],
 'owned_runtime_wall_seconds':(datetime.fromisoformat(state['finished_at_utc'])-datetime.fromisoformat(state['started_at_utc'])).total_seconds(),
 'genuine_loader_return_inferred_from_source_control_flow':True,
 'loader_time_gradient_memory_preservation_gates_not_persisted_remain_unknown':True,
 'learning_metrics_unmeasured_not_negative':True,'no_old_owner_restart_or_scientific_rerun':True,
 'cause_hypothesis_requires_separate_PEFT_reproduction':'adapter disable/restore reactivates LoRA gradients after requested freezing',
 'reader_new_model_PF_calls':0,'source_sha256':sha(Path(__file__))}
write(OUT/'Independent_Zero_Forward_Failure_Audit.json',report)
write(OUT/'Fresh_Frozen_Asset_Audit.json',frozen_checks())
files={p.relative_to(ROOT).as_posix():p for p in EX.rglob('*') if p.is_file()}
for p in [source,ROOT/'work/candidate_process_pretrained_loader.py',Path(__file__),PREP/'protocol.json',PREP/'Program_Input_Manifest.json',PREP/'Cloud_Payload_Manifest.json',BASE/'pretrained_learning_audit_continuation/status.json',BASE/'pretrained_learning_audit_continuation/owner.claim']:
    files[p.relative_to(ROOT).as_posix()]=p
for p in OUT.iterdir():files[p.name]=p
print(json.dumps({'audit':report,'archive':seal(OUT,files,'Preserved_Zero_Forward_Failure_Evidence.zip')},indent=2))
