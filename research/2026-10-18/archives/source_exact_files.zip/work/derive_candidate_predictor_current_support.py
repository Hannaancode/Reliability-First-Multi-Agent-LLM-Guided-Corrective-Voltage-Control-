"""Current-observable proof from actual committed history; zero solver/model."""
from pathlib import Path
from datetime import datetime,timezone
from types import SimpleNamespace
import ast,gzip,hashlib,json
from candidate_predictor_operational_state import support_from_verified_snapshot,augmented_model_input
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT/'outputs/llm_value_next_method_research_20261008'
DATA=PARENT/'guarded_train_trajectory_measurement_native_v3'
BASE=ROOT/'outputs/llm_value_candidate_development_20261009'
CONTRACT=BASE/'input_and_target_contract_nullable_v2';OUT=BASE/'current_added_support_observables'
read=lambda p:json.loads(p.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
digest=lambda v:hashlib.sha256(canonical(v).encode()).hexdigest()
assert not OUT.exists()
for folder in (DATA,CONTRACT):
    for name,m in read(folder/'manifest.json').items():assert sha(folder/name)==m['sha256'] and (folder/name).stat().st_size==m['bytes']
asset=ROOT/'work/e/pack/testbeds/federation_4mg_ieee118.json'
network=read(asset)['_object'];frame=network['shunt'];raw=json.loads(frame['_object'])
baseline={i:dict(zip(raw['columns'],v)) for i,v in zip(raw['index'],raw['data'])}
assert len(baseline)==14 and all(not str(r.get('name','')).startswith('llm_shunt') for r in baseline.values())
source=ROOT/'work/e/audit/phase2g_rescue_runner.py';tree=ast.parse(source.read_text(encoding='utf-8'))
getter=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='llm_q_abs_at_bus')
scope={};exec(compile(ast.Module(body=[getter],type_ignores=[]),str(source),'exec'),scope)
cap_node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MAX_ABS_Q_PER_BUS' for t in n.targets))
cap=ast.literal_eval(cap_node.value);assert cap==450.
class ProvenNamesFrame:
    def __init__(self,rows):self.rows=rows
    def __len__(self):return len(self.rows)
    def iterrows(self):return iter(self.rows)
proofs={};prefix_checks=0
for world in read(DATA/'protocol.json')['worlds']:
    for branch in ('DFF','DFF-ALT'):
        path=DATA/'branches'/(world['scenario_id']+'__'+branch+'.json');r=read(path)
        actions=r['result']['executed_actions'];assert len(r['observations'])==len(actions)+1
        for prefix,o in enumerate(r['observations']):
            assert o['decision']==prefix
            assert o['committed_action']==(None if prefix==0 else actions[prefix-1]['action'])
            obs=o['input_observation'];identity=o['observation_sha256'];assert digest(obs)==identity
            f=obs['physical_tables']['shunt'];current=[(i,dict(zip(f['columns'],v))) for i,v in zip(f['index'],f['values'])]
            added_rows=[(i,v) for i,v in current if i not in baseline]
            assert len(added_rows)==prefix
            named=[];expected=[0.]*118
            for pos,((i,row),committed) in enumerate(zip(added_rows,actions[:prefix])):
                mapping=committed['action']['add_shunts_q_mvar'];assert len(mapping)==1
                bus,q=next(iter(mapping.items()));bus=int(bus);q=abs(float(q))
                assert row['bus']==bus and row['q_mvar']==-q and row['p_mw']==0.
                # Name is a proved deterministic consequence of the original apply_action
                # and an actually committed prefix, not a newly observed saved name.
                named.append((i,{**row,'name':f'llm_shunt_b{bus}_q{q}'}));expected[bus]+=q
            named=[(i,baseline[i]) for i,_ in current if i in baseline]+named
            net=SimpleNamespace(shunt=ProvenNamesFrame(named))
            original_getter=[scope['llm_q_abs_at_bus'](net,bus) for bus in range(118)]
            derived=support_from_verified_snapshot(obs,baseline)
            assert expected==original_getter==derived
            compiled=augmented_model_input(obs,derived,cap)
            proof={'observation_id':identity,'current_added_support_MVAr_by_bus':derived,
                   'original_cap_MVAr':cap,'augmented_model_input_sha256':digest(compiled),
                   'committed_prefix_checks':[],'no_future_outcome_or_branch_ID_in_forward':True}
            if identity in proofs:
                assert proofs[identity]['current_added_support_MVAr_by_bus']==derived
                proof=proofs[identity]
            else:proofs[identity]=proof
            proof['committed_prefix_checks'].append({'record_sha256':sha(path),'prefix_length':prefix,
                    'actual_recorded_prefix_action_sha256':digest([a['action'] for a in actions[:prefix]]),
                    'baseline_and_added_row_correspondence_passed':True})
            prefix_checks+=1
with gzip.open(CONTRACT/'Current_Input_Rows.jsonl.gz','rt',encoding='utf-8') as f:
    ids={json.loads(line)['observation_id'] for line in f}
assert set(proofs)==ids and len(proofs)==311 and prefix_checks==342
OUT.mkdir()
with (OUT/'Current_Control_State_Observables.jsonl.gz').open('xb') as raw_file,gzip.GzipFile(fileobj=raw_file,mode='wb',mtime=0) as f:
    for identity,proof in sorted(proofs.items()):f.write((canonical(proof)+'\n').encode())
summary={'completed_at_utc':datetime.now(timezone.utc).isoformat(),'unique_current_observables':len(proofs),
 'actual_committed_prefix_and_saved_shunt_row_correspondences':prefix_checks,'frozen_baseline_shunt_rows':len(baseline),
 'original_unmodified_450MVAr_getter_algebra_matches_all118buses':True,
 'omitted_shunt_names_not_claimed_saved_or_observed':True,'old_observations_input_targets_manifests_unchanged':True,
 'current_added_support_determined_by_current_snapshot_plus_frozen_baseline_after_actual_history_proof':True,
 'past_committed_history_used_for_audit_only_no_future_labels_in_augmented_forward':True,
 'future_live_collection_must_use_actual_original_getter_not_unproved_role_inference':True,
 'known_prechecks_shared_with_all_future_model_and_numerical_arms':True,
 'model_optimizer_PF_controller_cloud_calls':0,'no_LLM_contribution_or_performance_claim':True,
 'network_sha256':sha(asset),'original_getter_source_sha256':sha(source),
 'operational_state_source_sha256':sha(ROOT/'work/candidate_predictor_operational_state.py'),'source_sha256':sha(Path(__file__)),
 'parent_input_manifest_sha256':sha(CONTRACT/'manifest.json')}
with (OUT/'summary.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2)
members={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}
with (OUT/'manifest.json').open('x',encoding='utf-8') as f:json.dump(members,f,indent=2)
print(json.dumps(summary,indent=2))
