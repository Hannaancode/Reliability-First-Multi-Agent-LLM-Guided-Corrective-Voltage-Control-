"""Join actual charged costs, saved branch choice and independent PF replay."""
import csv,hashlib,json,math
from pathlib import Path
rows=[]
for p in sorted(Path('outputs/matched_campaign/cases').glob('*.json')):
 audit=Path('outputs/physical_replay_audit/cases')/p.name
 if not audit.exists():continue
 d=json.loads(p.read_text());a=json.loads(audit.read_text());assert a['identity']['saved_case_sha256']==hashlib.sha256(p.read_bytes()).hexdigest()
 for name in ['D-SE','HG-SE']:
  row={'scenario_id':p.stem,'portfolio':name,'valid_numerical_pair':d['paired_terminal_metrics_valid']}
  secondary='DFF-ALT' if name=='D-SE' else 'HG-VF'
  # Failed/invalid cases still consumed real planning compute; never drop it.
  for key in ['pf_attempts','pf_returns','pf_exceptions','llm_calls','llm_exceptions','input_tokens','output_tokens','wall_seconds']:
   row[key]=d['costs']['DFF'][key]+d['costs'][secondary][key]
  if d['paired_terminal_metrics_valid']:
   portfolio=d['portfolios'][name];branch=portfolio['selected_branch'];b=a['branches'][branch];t=b['states'][-1];v=t['voltage'];row.update(selected_branch=branch,accepted_actions=b['executed_action_count'],within_25_action_budget=b['within_25_action_budget'],original_strict_uv=v['uv_strict'],original_strict_ov=v['ov_strict'],ov_beyond_1e8_tolerance=v['ov_beyond_1e8_tolerance'],all_active_bus_voltages_finite=t['all_active_bus_voltages_finite'],unserved_scheduled_p_mw=t['unserved_scheduled_p_mw'],nominal_support_mvar=t['incremental_shunt_nominal_mvar_total'],realized_support_mvar=t['incremental_shunt_realized_mvar_total'],shunt_admittance_formula_max_error_mvar=t.get('incremental_shunt_realized_vs_admittance_formula_max_abs_error_mvar'),declared_slack_limit_violation_count=len(t['ext_grid_declared_limit_violations']),gen_q_limit_violation_count=len(t['gen_q_limit_violations']),thermal_overload_count=sum(len(x['above_100_percent']) for x in t['thermal'].values()),**portfolio['charged_cost'])
  else:row['status']='invalid pair retained; no portfolio selected; do not zero-impute physical effort or outcome'
  rows.append(row)
path=Path('outputs/physical_effort_ledger.csv');cols=list(dict.fromkeys(k for r in rows for k in r))
with path.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
print('PHYSICAL_EFFORT_LEDGER_SAVED',len(rows),'portfolio rows')
