"""Freeze the exact bounded public-model diagnostic before any pretrained call."""
import ast,collections,gzip,json,os,shutil,subprocess,sys,tempfile,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'work'))
from candidate_process_evidence_utils import read,sha,write,frozen_checks,seal
R=ROOT/'outputs/critical_research_reset_20261010';OUT=R/'public_size_production_preparation_v2'
assert not OUT.exists();OUT.mkdir()
input_dir=R/'requested_public_size_screen_input_preflight'
old=read(input_dir/'Prospective_Public_Size_Screen_Input_Protocol.json');cases=read(input_dir/'All31_Outcome_Independent_Paired_Inputs.json')
software=read(R/'public_size_production_software_readiness/Software_Readiness.json')
assert software['actual_random_CPU_forward_attempts']==software['actual_random_CPU_forward_returns']==6
assert software['v2_report_presence_flag_cases_passed']==3 and software['hash_bound_ACK_transfer_verified']
assert read(R/'requested_public_size_screen_input_preflight_completion_v2/Actual_Paired_Input_Readiness.json')['all31_public_model_token_ids_identical']
models=read(R/'public_size_model_file_metadata/Pinned_Public_Model_Files.json')['models']
records=read(R/'requested_public_size_screen_input_preflight_completion_v2/All62_Actual_Public_Tokenizer_Context_Records.json')
versions=dict(line.strip().split('==') for line in (ROOT/'work/frozen_dependency_closure.txt').read_text().splitlines() if line.strip())
assert len(versions)==111
largest=sorted([r for r in records if r['model']=='public_0_5B'],key=lambda r:(-r['tokens'],r['observation_id']))[0]
sources=['run_public_size_screen_remote_20261010.py','public_size_screen_guardian.py','public_size_screen_environment_check.py',
         'public_size_preservation.py','public_size_forward_observer.py','public_size_screen_reader_contract_v2_20261010.py']
remote=set(sources);pending=list(sources)
while pending:
    name=pending.pop();tree=ast.parse((ROOT/'work'/name).read_text(encoding='utf-8'))
    for node in ast.walk(tree):
        names=[a.name for a in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        for imported in names:
            candidate=imported.split('.')[0]+'.py'
            if (ROOT/'work'/candidate).is_file() and candidate not in remote:remote.add(candidate);pending.append(candidate)
remote_hashes={'work/'+n:sha(ROOT/'work'/n) for n in sorted(remote)}
local_names=['run_public_size_screen_colab_20261010.py','public_size_setup_remote.py','audit_public_size_screen_20261010.py',
 'continue_public_size_screen_audit_20261010.py',Path(__file__).name,'google_account_profile.py','candidate_process_runtime.py']
source_hashes={**remote_hashes,**{'work/'+n:sha(ROOT/'work'/n) for n in local_names}}
for name in source_hashes:ast.parse((ROOT/name).read_text(encoding='utf-8'))

B=ROOT/'outputs/llm_value_candidate_development_20261009';P=ROOT/'outputs/llm_value_relational_adaptation_research_20261009'
target_path=B/'input_and_target_contract_nullable_v2/Measured_Target_Rows.jsonl.gz'
with gzip.open(target_path,'rt',encoding='utf-8') as f:targets={r['observation_id']:r for r in map(json.loads,f)}
control_paths={
 'numerical_full_information':B/'numerical_process_pilot/final_epoch5_records.json',
 'attention_full_information':B/'global_attention_process_pilot/final_epoch5_records.json',
 'current_AC_linearization':B/'current_state_sensitivity_diagnostic/Actual_Current_Sensitivity_Records.json',
 'native_union':P/'native_unexecuted_measurement_audit/All239_State_and_World_Denominators.json'}
methods={};binding={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in control_paths.values()}
paid={}
for name,folder in [('numerical_full_information','numerical_process_pilot'),('attention_full_information','global_attention_process_pilot'),
                    ('current_AC_linearization','current_state_sensitivity_diagnostic')]:
    path=B/folder/'summary.json';paid[name]=read(path);binding[str(path.relative_to(ROOT)).replace('\\','/')]=sha(path)
for name in ['numerical_full_information','attention_full_information']:
    full=read(control_paths[name]);invalid_controls=[r for r in full if 'observation_id' not in r]
    assert len(invalid_controls)==1 and invalid_controls[0]['status']=='original_invalid_TRAIN_view_no_forward'
    source={r['observation_id']:r for r in full if 'observation_id' in r};selected=[]
    assert len(source)==311
    for c in cases:
        r=source[c['observation_id']];assert r['world_sha256']==c['world_sha256'] and r['split']==c['split']
        pair=r['recorded_label_priority_diagnostic']['model_first']
        selected.append({'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],'action_pair':pair,
          'status':'preserved_final_epoch5_native_K1','ranking_complete':True,'full_table_information_exceeds_public_partial_view':True})
    methods[name]=selected
    paid[name+'_original_invalid_row']=invalid_controls
source={r['observation_id']:r for r in read(control_paths['current_AC_linearization'])};selected=[]
assert len(source)==311
for c in cases:
    r=source[c['observation_id']];assert r['world_sha256']==c['world_sha256']
    candidates=r.get('candidate_predictions',[])
    ranked=sorted((p for p in candidates if p['status']=='finite_linear_forecast'),key=lambda p:(*p['estimated_original_score'],-p['bus']),reverse=True)
    pair=[ranked[0]['bus'],ranked[0]['Q_index']] if ranked else None
    selected.append({'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],'action_pair':pair,
      'status':r['status'],'ranking_complete':r['status']=='finite_current_linear_system',
      'original_finite_forecast_filter_preserved':True,'native_nonlinear_convergence_UNKNOWN':True,
      'full_table_information_exceeds_public_partial_view':True})
methods['current_AC_linearization']=selected
native=read(control_paths['native_union'])
for name,items in native.items():
    source={r['observation_id']:r for r in items};selected=[]
    for c in cases:
        r=source.get(c['observation_id']);pair=None
        if r:
            assert r['world_sha256']==c['world_sha256'];available=r['K']['1']['chosen_available_actions'];pair=available[0] if available else None
        selected.append({'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],'action_pair':pair,
          'status':'historical_OPT_native_affine' if r else 'not_measured_for_held_world',
          'ranking_complete':bool(r and r['ranking_evidence_complete']),'native_nonlinear_convergence_UNKNOWN':True,
          'full_table_information_exceeds_public_partial_view':True})
    methods[name]=selected
    paid[name+'_original_invalid_row']=invalid_controls
paid['native_affine_all_stages']=read(P/'native_unexecuted_measurement_audit/All_Arm_Union_Ranking_Results.json')
methods['lowest_voltage_secondary']=[]
for c in cases:
    s=c['selected_same_information_input'];allowed=[(b,j) for buses in s['raw_common_and_zone_pools'].values() for b in buses for j,q in enumerate(s['original_Q_grid']) if s['current_added_support_MVAr_by_bus'][b]+q<=450]
    pair=min(set(allowed),key=lambda x:(s['current_bus_voltage_pu'][x[0]],x[0],x[1])) if allowed else None
    methods['lowest_voltage_secondary'].append({'observation_id':c['observation_id'],'world_sha256':c['world_sha256'],
      'action_pair':list(pair) if pair else None,'status':'implemented_immediate_secondary_only_not_DSE','ranking_complete':True})
controls={'methods':methods,'prior_paid_costs':paid,'no_new_model_PF_forecast_or_solver_calls':True,
 'native_full_DSE_portfolio_not_equated_with_one_step_controls':True,'all_refs_selected_before_public_outputs':True}
write(OUT/'Local_Numerical_Control_References.json',controls)
write(OUT/'cases.json',cases)
write(OUT/'denominators.json',read(input_dir/'Original_Invalid_and_All_World_Denominators.json'))
coverage={'fixed_selected_finite_worlds':31,'selected_worlds_with_any_measured_targets':sum(c['observation_id'] in targets for c in cases),
 'selected_already_healthy_states':sum(c['selected_same_information_input']['current_global_metrics']['uv_count']==0 for c in cases),
 'cases_remain_unchanged_after_coverage':True,'partition':dict(collections.Counter(c['split'] for c in cases))}
write(OUT/'Fixed_Label_Coverage.json',coverage)
protocol={
 'declared_at_utc':datetime.now(timezone.utc).isoformat(),'purpose':'Human-requested bounded paired public-model size development diagnostic, not full DSE superiority',
 'selected_account':'abdulhannaan2002@gmail.com','one_allocation_no_profile_fallback_or_scientific_retry':True,
 'models':models,'framework_versions':versions,'context_tokens':8192,'max_new_tokens':384,'seed':20261010,
 'quantization':{'load_in_4bit':True,'bnb_4bit_compute_dtype':'float16','bnb_4bit_quant_type':'nf4','bnb_4bit_use_double_quant':True},
 'generation':{'max_new_tokens':384,'do_sample':False,'num_beams':1,'use_cache':True,'cache_implementation':'dynamic',
     'bos_token_id':151643,'pad_token_id':151643,'eos_token_id':[151645,151643],'repetition_penalty':1.0,
     'return_dict_in_generate':True,'output_scores':False,'output_logits':False,'disable_compile':True},
 'published_sampling_defaults_replaced_by_common_prospective_greedy_contract':True,
 'tokenizer_context_records':records,'engineering_context_observation_id':largest['observation_id'],
 'engineering_context_selection':'Longest already-frozen tokenized context, then smallest observationSHA; no label/output selection',
 'planned_generation_attempts':62,'planned_additional_full_context_engineering_forwards':4,
 'prefill_decode_native_forward_counts_recorded_not_equal_to62':True,
 'raw_last_token_logits_for_every_return_preserved':True,'ordered_arms':['public_0_5B','public_1_5B'],
 'setup_seconds':1800,'science_seconds':1800,'science_process_seconds':2100,'collector_seconds':2700,
 'targets':{'path':str(target_path.relative_to(ROOT)).replace('\\','/'),'sha256':sha(target_path),'excluded_from_cloud':True},
 'local_analysis_source_hashes':binding,'remote_source_hashes':remote_hashes,
 'input_protocol_sha256':sha(input_dir/'Prospective_Public_Size_Screen_Input_Protocol.json'),
 'current_cases_sha256':sha(OUT/'cases.json'),'original_selection_prompt_and_invalid_denominators_preserved':True,
 'fixed_label_coverage':coverage,'no_repairs_prompt_sweeps_or_original_private_adapter_transfer':True,
 'analysis':'All31 paired categorical/known original-score decisions and fixed numerical K1 references, plus original invalid32nd world. Unknowns/abstentions/malformed/failed/unexecuted remain distinct; raw numerical ranking incompleteness retained. Descriptive historical development only, no selection on favorable subgroup or inferential99percent claim.',
 'no_automatic_learning_or_physical_campaign':'A result can inform separate hypothesis design; strong attribution/full physical DSE both-branch costs and unused confirmation still required',
 'original_private_model_network_controller_settings_and_locked_bank_unchanged':True}
write(OUT/'protocol.json',protocol)
for arm in ['public_0_5B','public_1_5B']:
    shutil.copytree(input_dir/'public_tokenizers'/arm,OUT/'tokenizers'/arm)
write(OUT/'Fresh_Frozen_Preservation.json',frozen_checks())

with tempfile.TemporaryDirectory(prefix='public_size_import_',dir=ROOT/'work') as directory:
    isolated=Path(directory);(isolated/'work').mkdir()
    for name in remote:shutil.copy2(ROOT/'work'/name,isolated/'work'/name)
    code=f"import sys;sys.path.insert(0,{str(ROOT/'work')!r});import candidate_process_runtime;sys.path.pop(0);sys.path.insert(0,{str(isolated/'work')!r});import public_size_forward_observer,public_size_preservation,public_size_screen_reader_contract_v2_20261010;print('ISOLATED_HELPERS_IMPORTED')"
    result=subprocess.run([str(ROOT/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8','-c',code],cwd=isolated,capture_output=True,text=True,timeout=60)
    assert result.returncode==0,result.stderr
    write(OUT/'Actual_Isolated_Import_Check.json',{'passed':True,'stdout':result.stdout,'whole_function_scope_local_import_closure':sorted(remote)})
ready={'passed':True,'source_hashes':source_hashes,'remote_import_closure':sorted(remote),
 'public_weights_CUDA_memory_and_real_forward_gates_pending':True,
 'no_source_or_setting_change_after_scientific_launch':True,'software_scope':software}
write(OUT/'Launch_Readiness_Audit.json',ready)
manifest_files={}
for name in ['protocol.json','cases.json','denominators.json']:
    manifest_files['prep/'+name]=OUT/name
for path in (OUT/'tokenizers').rglob('*'):
    if path.is_file():manifest_files['prep/'+path.relative_to(OUT).as_posix()]=path
for name in remote:manifest_files['work/'+name]=ROOT/'work'/name
for name in ['frozen_gpu_requirements.txt','frozen_dependency_closure.txt','uv_bootstrap_version.txt']:
    manifest_files['work/'+name]=ROOT/'work'/name
manifest={name:{'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in manifest_files.items()}
write(OUT/'PUBLIC_SIZE_INPUT_MANIFEST.json',manifest)
archive=OUT/'Public_Size_Paired_Inference_Inputs.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name,path in manifest_files.items():z.write(path,name)
    z.write(OUT/'PUBLIC_SIZE_INPUT_MANIFEST.json','PUBLIC_SIZE_INPUT_MANIFEST.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
    for name,m in manifest.items():b=z.read(name);assert len(b)==m['bytes'] and __import__('hashlib').sha256(b).hexdigest()==m['sha256']
authority=ROOT/'outputs/overnight_research_authorization_20261009.json'
payload={'archive':str(archive.relative_to(ROOT)).replace('\\','/'),'bytes':archive.stat().st_size,'sha256':sha(archive),
 'unique_members':len(manifest)+1,'CRC_and_every_member_hash_passed':True,
 'destination':protocol['selected_account'],'action':'One T4; paired public inference and four charged engineering prefills, no optimizer or PF',
 'human_authority_source':str(authority.relative_to(ROOT)).replace('\\','/'),'human_authority_sha256':sha(authority),
 'direct_human_model_size_request':'Use1.5B or intermediate to see if it makes a difference; do that',
 'excludes_credentials_private_adapter_raw_network_full_tables_locked_bank_labels_old_results':True}
write(OUT/'Cloud_Payload_Manifest.json',payload)
print(json.dumps({'readiness_passed':True,'payload':payload,'coverage':coverage,'remote_source_modules':sorted(remote)}))
