"""Current CPU reference series, gated by completed historical development.

Does not call OPF with hidden controllable generator/storage/load freedoms.
All frozen declared-slack exclusions and unsuccessful local solves remain in
the 62-case ledger. Solver timings are local CPU, never substituted for GPU.
"""
from pathlib import Path
import hashlib,json,sys,time
import pandapower as pp
from ac_shunt_reference import solve
from frozen_physics_loader import ROOT,load_stack
from reference_endpoint_check import check_endpoint
from physical_replay_audit import save
from checkpoint_io import read_json_ready
sys.stdout.reconfigure(encoding='utf-8',line_buffering=True)
root=Path('outputs');state={'status':'waiting_for_historical_development','completed_count':0,'planned_count':62};status=root/'ac_reference_campaign_status.json';save(status,state)
def record_unhandled_failure(kind,error,tb):
    state.update(status='interrupted',failure_type=kind.__name__,blocker='AC reference prerequisite, validation, or execution failed; inspect the saved development reports and process output. Complete case checkpoints remain preserved.');save(status,state);sys.__excepthook__(kind,error,tb)
sys.excepthook=record_unhandled_failure
print('AC_REFERENCE_BANK_QUEUED_AFTER_HISTORICAL_DEVELOPMENT_WITH_PER_CASE_DFF_CHECKPOINT_GATES',flush=True);started=time.monotonic()
development_ids=['fed_combined_load_1p25_line_101_MG1','fed_combined_load_1p5_line_101_MG1']
while time.monotonic()-started<43200:
    supervisor=read_json_ready(root/'campaign_supervisor_status.json')
    if supervisor['status'] in ['interrupted','time_limit_reached']:
        state.update(status='waiting_on_campaign_recovery',blocker='Main matched ledger incomplete; no AC locked-bank optimization started.');save(status,state);sys.exit(0)
    dev_paths=[root/'ac_reference_development'/(sid+'.json') for sid in development_ids]
    if all(p.exists() and len(read_json_ready(p).get('runs',[]))==2 for p in dev_paths):break
    time.sleep(20)
else:
    state.update(status='dependency_wait_limit',blocker='Historical development did not complete within bounded wait.');save(status,state);sys.exit(0)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads((ROOT/'bank/BANK_LOCK.json').read_text());main_protocol=json.loads((root/'matched_campaign_protocol.json').read_text());assert lock['bank_digest_sha256']==main_protocol['bank_digest']
for p,h in main_protocol['source_sha256'].items():assert sha(p)==h,'Frozen source changed'
manifest=json.loads((ROOT/'bank/scenario_manifest.json').read_text());assert sha(ROOT/'bank/scenario_manifest.json')==lock['manifest_sha256']
for n,h in lock['scenario_file_sha256'].items():assert sha(ROOT/'bank/scenarios'/n)==h
for n,k in [('federation_4mg_ieee118.json','federation_network_sha256'),('federation_4mg_ieee118_metadata.json','federation_metadata_sha256')]:assert sha(ROOT/'pack/testbeds'/n)==manifest['frozen_asset_hashes'][k]
balance=json.loads((root/'fixed_p_feasibility_audit.json').read_text());assert balance['locked_case_count']==62 and all(balance['assumptions_verified'].values())
v2,runner,ref=load_stack();base=pp.from_json(str(ROOT/'pack/testbeds/federation_4mg_ieee118.json'));_,zones=v2.v0.load_metadata(ROOT/'pack/testbeds/federation_4mg_ieee118_metadata.json')
# Independent historical fresh-PF checks precede freezing and any bank solve.
development=[]
for p in dev_paths:
    d=json.loads(p.read_text());assert d['protocol']['source_sha256']==sha('work/ac_shunt_reference.py')
    scenario=json.loads((ROOT/'pack/scenarios/federation'/p.name).read_text())
    checks=[check_endpoint(scenario,r['nominal_support_mvar_by_bus'],1.0001,base,zones,v2,runner) if r['independently_voltage_feasible'] else {'strict_uv_zero_and_upper_band_within_1e8':False,'raw_reference_status':r['status'],'projection_not_attempted':'Raw optimizer endpoint did not pass its own independent feasibility check; invalid/nonfinite variables cannot be converted into a valid reference.'} for r in d['runs']]
    development.append({'scenario_id':d['scenario_id'],'two_solver_starts_recorded':True,'raw_report_sha256':sha(p),'endpoint_checks':checks})
assert all(c['strict_uv_zero_and_upper_band_within_1e8'] for c in development[0]['endpoint_checks']),'Mild historical reference must reproduce strict UV clearance before bank execution'
assert any(c['strict_uv_zero_and_upper_band_within_1e8'] for c in development[1]['endpoint_checks']),'Severe historical reference must independently reproduce strict UV clearance for at least one declared start'
validation={'passed':True,'development':development,'interpretation':'Mild strict-UV fresh-PF validation passed for both starts; severe warm-start strict-UV clearance independently reproduced. The failed severe zero start remains explicit; no infeasibility claim inferred from failure.'};save(root/'ac_reference_development_validation.json',validation)
protocol={'status':'frozen_after_historical_development_before_ac_bank_solve','bank_digest':lock['bank_digest_sha256'],'main_protocol_sha256':sha(root/'matched_campaign_protocol.json'),'sources':{n:sha('work/'+n) for n in ['ac_shunt_reference.py','reference_endpoint_check.py','physical_replay_audit.py','run_ac_reference_campaign.py']},'solver_parameters':json.loads(dev_paths[0].read_text())['protocol'],'initializations':['zero','actual_frozen_DFF_endpoint_from_same_case_main_run'],'padding':'For each independently feasible raw optimizer endpoint evaluate factors 1 and 1.0001, clipping each bus at 450 Mvar; retain raw/padded outcomes. Choose smallest nominal support among physically checked strict-UV-zero endpoints with upper band tolerance explicitly 1e-8. If none, report no valid local reference found; do not infer infeasibility.','scope':'continuous endpoint relaxation of discrete sequential action space; all in-service bus shunts; fixed frozen active dispatch, storage P/Q, voltage setpoints, topology and taps; not certified optimum or proven bound','declared_operating_limits':'Report necessary fixed-P slack infeasibility for every case and independent endpoint slack/thermal/gen-Q limits. Voltage-only reference is not full operational restoration.','cost_accounting':'Instrument every actual pp.runpp attempt/return/exception for the whole local case including initial and fresh endpoint PFlows. Charge the source DFF PF work once for the two-start method; report GPU DFF and local solver wall times separately, never as matched-hardware timing. Shared storage does not make warm-start DFF free.','input_dependency':'Each bank case waits for its own complete same-protocol DFF checkpoint, permitting local reference and remote GPU campaign execution concurrently; statistical analysis remains gated on the full 62-case ledger.','hardware':'local Windows CPU; original numerical core versions verified; wall times cannot be compared directly with Colab GPU branch wall times','historical_validation_sha256':sha(root/'ac_reference_development_validation.json')}
path=root/'ac_reference_campaign_protocol.json'
if path.exists():assert json.loads(path.read_text())==protocol
else:save(path,protocol)
out=root/'ac_reference_campaign';out.mkdir(exist_ok=True);done=[];balance_rows={r['scenario_id']:r for r in balance['cases']};started=time.monotonic()
for p in sorted((ROOT/'bank/scenarios').glob('*.json')):
    case=out/'cases'/p.name
    if case.exists():
        existing=json.loads(case.read_text());assert existing['campaign_protocol_sha256']==sha(path) and existing['scenario_sha256']==sha(p);done.append(p.stem);continue
    if time.monotonic()-started>43200:state.update(status='time_limit_reached',completed_count=len(done));save(status,state);break
    scenario=json.loads(p.read_text());dff_path=root/'matched_campaign/cases'/p.name
    while not dff_path.exists():
        if time.monotonic()-started>43200:state.update(status='time_limit_reached',completed_count=len(done));save(status,state);sys.exit(0)
        dependency=read_json_ready(root/'campaign_supervisor_status.json')
        if dependency['status'] in ['interrupted','time_limit_reached']:
            state.update(status='waiting_on_campaign_recovery',completed_count=len(done),blocker='The next required same-case DFF checkpoint is unavailable because the main campaign stopped. Complete AC checkpoints preserved.');save(status,state);sys.exit(0)
        state.update(status='waiting_for_matched_case_checkpoint',waiting_scenario_id=p.stem,completed_count=len(done));save(status,state);time.sleep(20)
    matched=read_json_ready(dff_path);assert matched['scenario_sha256']==sha(p) and matched['protocol_sha256']==sha(root/'matched_campaign_protocol.json')
    state.update(status='running',current_scenario_id=p.stem,completed_count=len(done));save(status,state)
    nominal={}
    for action in matched['branches']['DFF'].get('executed_actions',[]):
        for b,q in action['action']['add_shunts_q_mvar'].items():nominal[str(b)]=nominal.get(str(b),0)+abs(float(q))
    print('AC_BANK_CASE_STARTED',p.stem,flush=True)
    counters={'pf_attempts':0,'pf_returns':0,'pf_exceptions':0};pf_original=pp.runpp;case_started=time.perf_counter()
    def counted(*a,**kw):
        counters['pf_attempts']+=1
        try:r=pf_original(*a,**kw);counters['pf_returns']+=1;return r
        except Exception:counters['pf_exceptions']+=1;raise
    pp.runpp=counted
    try:
        # A solver's first completed initialization is an intermediate report,
        # never a complete case checkpoint eligible for resume.
        intermediate=out/'solver_intermediate'/p.name
        report=solve(scenario,[('zero',{}),('same_case_frozen_dff_endpoint',nominal)],intermediate,60);report['development_only']=False;report['initialization_note']='Second start uses actual same-case frozen DFF output; solver parameters developed and frozen on historical cases only.'
        probes=[]
        for run in report.get('runs',[]):
            if not run['independently_voltage_feasible']:continue
            for factor in [1.,1.0001]:probes.append({'initialization':run['initialization'],**check_endpoint(scenario,run['nominal_support_mvar_by_bus'],factor,base,zones,v2,runner)})
        valid=[r for r in probes if r['strict_uv_zero_and_upper_band_within_1e8']]
        report['fresh_endpoint_probes']=probes;report['selected_local_voltage_reference']=min(valid,key=lambda r:r['nominal_support_mvar']) if valid else None
        report['reference_status']='local_voltage_reference_found' if valid else 'invalid_initial_state_or_no_feasible_local_reference_found_not_infeasibility_proof'
    except Exception as exc:report={'scenario_id':p.stem,'development_only':False,'reference_status':'exception_retained','exception_type':type(exc).__name__}
    finally:pp.runpp=pf_original
    dff_cost=matched['costs']['DFF'];report['costs']={'local_case_actual':{**counters,'wall_seconds':time.perf_counter()-case_started},'charged_warm_start_source_DFF':dff_cost,'charged_total_pf_attempts':counters['pf_attempts']+dff_cost['pf_attempts'],'timing_note':'DFF ran on Colab hardware and reference on local Windows CPU; retain separate wall times, no matched-timing efficiency claim.'}
    report.update(campaign_protocol_sha256=sha(path),scenario_sha256=sha(p),matched_case_sha256=sha(dff_path),declared_slack_necessary_condition=balance_rows[p.stem]);save(case,report);done.append(p.stem);state.update(status='running',completed_count=len(done),completed_ids=done);save(status,state);print('AC_BANK_CASE_SAVED',p.stem,report['reference_status'],flush=True)
else:state.update(status='complete',completed_count=len(done),completed_ids=done);save(status,state);print('AC_REFERENCE_BANK_COMPLETE',len(done),flush=True)
