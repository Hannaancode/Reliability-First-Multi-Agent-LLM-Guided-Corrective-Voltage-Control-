# Critical literature review and VAC-LoRA plan

**Prepared:** 2026-10-08  
**Purpose:** define a scientific model-improvement route toward incremental LLM value while preserving the frozen HierGrid baseline and the active Stage 3 campaign.

## What the literature actually supports

| Method | Evidence in its original domain | Transferable idea | Limitation for HierGrid |
|---|---|---|---|
| [Self-Refine](https://arxiv.org/abs/2303.17651) | One model generates, critiques, and revises; the paper reports roughly 20 percentage points average improvement over one-shot outputs across seven language tasks. | Use a feedback loop after a first proposal. | A language critic can miss electrical infeasibility. In HierGrid the physical replay must be the authority, and every extra generation/solver call is a measured cost. |
| [Tool-integrated self-verification (T1)](https://arxiv.org/abs/2504.04718) | A small model delegates arithmetic/fact verification to external tools and improves test-time scaling on MATH/MMLU-Pro. | Put exact verification outside the language model. | Our verifier is stronger than a text checker but domain-specific; it must score the actual action/state, not a rationale. |
| [Knockout/league test-time scaling](https://arxiv.org/abs/2411.19477) | Generate multiple candidates and compare them; the paper gives scaling guarantees under assumptions about candidate generation and comparison. | Allocate a bounded candidate budget and compare candidates explicitly. | The guarantee does not hold if the LLM proposer has no useful probability of finding a better action. Physical comparison cost must be included. |
| [Compute-optimal test-time scaling](https://arxiv.org/abs/2408.03314) | Adaptive allocation of inference-time compute can be more efficient than fixed best-of-N. | Spend extra proposals only on uncertain states. | Uncertainty must be calibrated against physical replay, and the policy cannot use adaptive compute as an unreported advantage. |
| [LoRA](https://arxiv.org/abs/2106.09685) | Low-rank adapters keep base weights frozen while adding a small trainable update. | Train a separately identified domain adapter without changing the frozen model. | A new adapter is a new model variant; it cannot be treated as the frozen baseline or evaluated on its training cases. |
| [DPO](https://arxiv.org/abs/2305.18290) | Pairwise preferences can be used without a separately trained reward model. | Learn from physically verified preferred/rejected action pairs. | Human preference is replaced by a domain verifier; pair construction must be leakage-safe and must retain hard negatives. |
| [LaMo/offline LM control](https://arxiv.org/abs/2310.20587) | LoRA, sequential decision modeling, and an auxiliary language loss help use pretrained LMs for offline control. | Preserve language ability while adapting to sequential state/action data. | Motion-control benchmarks are not power-system evidence; all claims need physical replay and a held-out scenario split. |
| [Safe-RL power-system review](https://arxiv.org/abs/2407.00681) and [stability-constrained voltage RL](https://arxiv.org/abs/2109.14854) | Safety constraints and stability certificates are required before learned policies are trusted in a grid. | Make safety filtering, abstention, and fallback first-class parts of the learned controller. | These are RL methods, not evidence that an LLM will beat D-SE; they justify the protected-action gate. |

The consistent lesson is that an LLM should propose or rank candidate actions while an exact external verifier measures the physical consequence. Self-critique without a verifier is not enough. Preference training is useful only when preferences come from a trusted physical objective and the data split prevents scenario leakage. More inference by itself is not a contribution unless the LLM changes the selected action and improves the predeclared primary endpoint at a fair total cost.

## Proposed method: VAC-LoRA

We propose **Verifier-Anchored Counterfactual LoRA with protected-action abstention (VAC-LoRA)**. This is a hypothesis and a candidate implementation, not a claim of established superiority.

1. **Frozen reference.** Keep the current base model, current LoRA, DFF/DFF-ALT, selector, network, controller settings, and locked 62-case bank byte-identical. VAC-LoRA is stored as a new adapter and has its own manifest.
2. **State-conditioned proposer.** Given the fresh per-state observation and the exact raw common-and-zone candidate scope, the adapter emits a bounded structured set of bus/Q proposals. It never emits an unconstrained command and never calls the solver during generation.
3. **Counterfactual physical preferences.** On training scenarios only, evaluate the original DFF/DFF-ALT candidates and additional admissible proposals with the exact physical replay. Build pairs `(preferred, rejected)` using a predeclared lexicographic objective: protected UV count, normal-upper violation, residual deficit, support, then full cost. Keep hard negatives (PF failure, unsafe voltage, unsupported bus, and safe-but-worse proposals), not only successful traces.
4. **Two adapter variants.** Train `VAC-SFT` on verified structured traces and `VAC-CPO` with the same SFT objective plus a DPO-style pairwise loss whose labels come only from the physical verifier. The pairwise term is called counterfactual preference optimization because the rejected action is a physically evaluated alternative from the same state. The naming is a hypothesis of novelty; a final novelty claim requires a broader search before publication.
5. **Protected abstention.** At inference, a small critic/uncertainty score is used only to decide whether to submit a proposal. If no proposal passes the physical gate or confidence is below a frozen threshold, the controller falls back to the unchanged D-SE action. Report the abstention/fallback rate. A safe fallback is a safety mechanism, not LLM credit.
6. **Bounded test-time search.** For each state, use the predeclared budget of four primary proposals and up to four repairs, then physical replay and deterministic ranking. All generation, repair, token, model-load, solver, and fallback costs are charged. No post-hoc budget or threshold tuning is allowed.

The intended contribution is the combination of (i) verifier-derived counterfactual training, (ii) state-conditioned candidate proposals, and (iii) an explicit protected abstention boundary. It is stronger than simply prompting the current model to “reflect,” but it can still fail: if VAC-LoRA does not produce admissible candidates that D-SE misses, there is no LLM value to claim.

## Data and leakage controls

Use only the recovered training archive recorded in `outputs/recovered_training_provenance_assets.json` and its grouped split map. It contains 109 training, 13 validation, and 15 test physical scenario IDs with 16,000/2,000/2,000 records. The archived audit reports 0/62 exact physical overlap with the locked bank and 0/62 overlap with the 141 recovered historical scenarios, while warning that all 62 share an outage/DER pattern. Therefore the result may claim same-network, held-out-scenario development; it may not claim cross-grid or unseen-outage generalization.

Generate verifier labels only from training scenarios. Freeze all preprocessing, adapter rank/alpha, optimizer, learning rate, epoch budget, negative-sampling rule, and random seeds before training. Validation selects no hyperparameters; it is a diagnostic gate. The 15-scenario test split is used once for development selection, and a separately held-out confirmation set is required for a superiority claim. The locked 62-case bank remains untouched.

## Falsifiable evaluation

The primary comparator is the literal original D-SE portfolio (DFF + DFF-ALT + unchanged selector, including both branch costs). Lowest-voltage remains an attribution control only. The primary endpoint is the proportion of scenarios satisfying `UV_zero AND normal_upper <= 1.05 + 1e-8`; secondary endpoints are residual deficit, support, PF exceptions, total wall time, model tokens, generation/repair count, fallback rate, and full cost.

Run the following predeclared variants on the same unused confirmation cases:

* frozen base, no adapter;
* current frozen LoRA;
* VAC-SFT;
* VAC-CPO;
* VAC-CPO with abstention/fallback;
* literal D-SE and an LLM-off control using the same physical candidate budget.

The LLM earns credit only when it changes the selected action and improves the primary endpoint or a predeclared secondary trade-off at equal or lower full cost. A result is a meaningful superiority signal only if the direction is consistent on the confirmation cases, the physical replay audit passes, no safety regression occurs, and the independent re-run confirms it. Eight historical development points and the current Stage 3 cases cannot serve as the final confirmation set.

## Execution order and stop rules

1. Let the active Stage 3 owner finish; do not touch its T4, files, or source.
2. Prepare and audit the VAC training manifest and verifier-pair generator on CPU, without training or changing frozen assets.
3. Train the two separately hashed adapters when an authorized GPU is genuinely available; preserve checkpoints, logs, token/cost accounting, and exact environment before release.
4. Run CPU physical replay and leakage/identity audits on the validation/test development splits.
5. Only if the adapter produces admissible novel candidates, freeze a confirmation manifest and run the matched D-SE/base/current-LoRA/VAC screen.
6. Stop if VAC has zero novel selected actions, worse protected endpoint, higher cost without a compensating endpoint gain, or any safety regression. Do not make small prompt/Q/threshold changes and rerun.

This plan makes a scientifically meaningful model change possible without rewriting the thesis baseline or manufacturing a positive result. The first success criterion is not “the LLM wins”; it is evidence that the learned adapter contributes a physically valid candidate that the deterministic portfolio would not select. Superiority is a later, stricter gate.
