"""Freeze one new, bounded original-adapter functional experiment and reader."""
import ast
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def put(p, v):
    with Path(p).open('x', encoding='utf-8') as f:
        json.dump(v, f, indent=2, allow_nan=False)


def script(name, text):
    ast.parse(text)
    with (R / 'work' / name).open('x', encoding='utf-8') as f:
        f.write(text)


def main():
    p = read(P / 'Production_Protocol.json')
    ready = read(P / 'Software_And_Method_Readiness.json')
    assert ready['status'].startswith('PASS_') and len(ready['boundary_checks']) == 20
    assert sha(R / 'work/native13_fullband_hybrid_contract_20261021.py') == ready['source_sha256']
    p['currently_ready_for_actual_model_owner'] = True
    p['missing_before_model_launch'] = []
    # Preserve the pre-freeze document, and use a distinct immutable final protocol.
    put(P / 'Frozen_Engineering_Protocol.json', p)
    worker_old = (R / 'work/run_native13_lora_transfer_remote_v2_20261020.py').read_text(encoding='utf-8')
    worker = worker_old.replace('All3_Messages_And_Token_IDs.json', 'All6_Messages_And_Token_IDs.json')
    worker = worker.replace('len(ids)+384<=1024', 'len(ids)+384<=4096')
    worker = worker.replace('torch.manual_seed(20261020)', 'torch.manual_seed(20261021)').replace('torch.cuda.manual_seed_all(20261020)', 'torch.cuda.manual_seed_all(20261021)').replace('np.random.seed(20261020)', 'np.random.seed(20261021)')
    worker = worker.replace('==6', '==12')
    worker = worker.replace('COMPLETE_ALL3_ORIGINAL_TRAINED_LORA_PRIMARY_AND_FRESH_MODEL_COLD_NATIVE_TRANSFER_OUTPUTS',
                            'COMPLETE_ALL6_ORIGINAL_TRAINED_LORA_PRIMARY_AND_FRESH_MODEL_COLD_FULLBAND_ENGINEERING_OUTPUTS')
    worker = worker.replace("'cold_all3_token_sequences_exact'", "'cold_all6_token_sequences_exact'")
    worker = worker.replace("'all3_complete_token_sequences_exact'", "'all6_complete_token_sequences_exact'")
    worker = worker.replace('Explicitnewrawpolicyincrementu_mvar/abstain,notoriginalshuntcontroller;strictlocalreaderdecidesvalidity,no outputrepair',
                            'New named bidirectional full-band bus/q_mvar literal increment role; no physical calls or performance claim; strict local reader admits raw outputs without repair')
    worker = worker.replace('"""Original private0.5B,onefixednativecontract,all3primary+3cold outputs,no training or PF."""',
                            '"""Original frozen private0.5B, six new full-band contexts and six cold outputs; no PF/training."""')
    assert '==12' in worker and 'len(ids)+384<=4096' in worker and 'max_new_tokens=384' in worker
    script('run_native13_fullband_lora_remote_20261021.py', worker)
    guardian = (R / 'work/native13_lora_guardian_v2_20261020.py').read_text(encoding='utf-8').replace('run_native13_lora_transfer_remote_v2_20261020.py', 'run_native13_fullband_lora_remote_20261021.py')
    script('native13_fullband_lora_guardian_20261021.py', guardian)
    host = (R / 'work/run_original_lora_native13_colab_v2_20261020.py').read_text(encoding='utf-8')
    host = host.replace('original_lora_native13_transfer_preparation_v2_20261020', 'native13_fullband_original_adapter_engineering_preparation_20261021')
    host = host.replace('original_lora_native13_transfer_execution_v2_20261020', 'native13_fullband_original_adapter_engineering_execution_20261021')
    host = host.replace("PREP/'Production_Protocol.json'", "PREP/'Frozen_Engineering_Protocol.json'")
    host = host.replace('native13_lora_guardian_v2_20261020.py', 'native13_fullband_lora_guardian_20261021.py')
    # Setup/environment/loader modules are byte-identical previously integrated
    # dependencies, not a new installation or hidden scientific retry strategy.
    assert host.count('client.assign(') == 1 and "arm='public_0_5B'" in host
    script('run_native13_fullband_original_adapter_colab_20261021.py', host)
    reader = 'audit_native13_fullband_original_adapter_engineering_20261021.py'
    coordinator = '''"""One bounded model interface owner followed by its sole zero-model reader."""
import os,json,subprocess,hashlib
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
P=R/'outputs/native13_fullband_original_adapter_engineering_preparation_20261021'
O=R/'outputs/native13_fullband_original_adapter_engineering_handoff_20261021'
def put(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def main():
 O.mkdir(exist_ok=False);put(O/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'at_utc':datetime.now(timezone.utc).isoformat()})
 ready=json.loads((P/'Launch_Readiness_Audit.json').read_text(encoding='utf-8'))
 assert ready['passed']
 for n,h in ready['source_hashes'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
 for name in ['Primary_Owner_Protocol.json','Reader_Owner_Protocol.json']:
  with (O/(name+'.log')).open('x',encoding='utf-8') as f:
   code=subprocess.call([str(R/'work/vcsa_module_env/Scripts/python.exe'),'-X','utf8',str(R/'work/coordinate_single_source_bound_owner_20261020.py'),'--protocol',str((P/name).relative_to(R))],cwd=R,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  put(O/(name+'.End.json'),{'exit_code':code,'at_utc':datetime.now(timezone.utc).isoformat()});assert code==0,'Preserve failed/partial/denied attempt; no model or allocation retry'
 put(O/'Completion.json',{'status':'MODEL_INTERFACE_ENGINEERING_AND_SOLE_READER_TERMINAL','at_utc':datetime.now(timezone.utc).isoformat()})
if __name__=='__main__':main()
'''
    script('coordinate_native13_fullband_original_adapter_engineering_20261021.py', coordinator)
    authority = {'latest_direct_human_instruction': 'ok test numerical and our llm also and if we achieved better then move to next task if not improve until we beat all of them work until tokens run out',
                 'interpretation': 'One prospective finite original-adapter interface test for a materially different bidirectional/full-band native role, with complete preservation/independent audit, before any physics/training campaign. No promised winner or permission to outcome-retune.',
                 'existing_full_necessary_authority': True,
                 'private_adapter_tokenizer_export': 'Same unchanged adapter/tokenizer, necessary for explicitly authorized model test; no credentials/private network/locked bank/private TRAIN labels uploaded.'}
    put(P / 'Direct_Human_Authority.json', authority)
    payload_files = {}
    remote_names = ['run_native13_fullband_lora_remote_20261021.py', 'native13_fullband_lora_guardian_20261021.py',
                    'native13_lora_setup_remote_v2_20261020.py', 'native13_lora_environment_check_v2_20261020.py',
                    'candidate_process_pretrained_loader_native13_v2_20261020.py', 'public_size_u61_preservation.py',
                    'frozen_gpu_requirements.txt', 'frozen_dependency_closure.txt', 'uv_bootstrap_version.txt']
    for n in remote_names:
        payload_files['work/' + n] = R / 'work' / n
    adapter = R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    for n, digest in p['private_adapter_tokenizer_unchanged'].items():
        assert sha(adapter / n) == digest
        payload_files['work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/' + n] = adapter / n
    payload_files['prep/protocol.json'] = P / 'Frozen_Engineering_Protocol.json'
    payload_files['prep/All6_Messages_And_Token_IDs.json'] = P / 'All6_Messages_And_Token_IDs.json'
    manifest = {n: {'bytes': f.stat().st_size, 'sha256': sha(f)} for n, f in payload_files.items()}
    archive = P / 'Private_Adapter_And_New6_Inputs_Only.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for n, f in payload_files.items():
            z.write(f, n)
        z.writestr('PUBLIC_SIZE_INPUT_MANIFEST.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(manifest) + 1
        for n, record in manifest.items():
            data = z.read(n)
            assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
    put(P / 'Cloud_Payload_Manifest.json', {'archive': archive.relative_to(R).as_posix(),
        'bytes': archive.stat().st_size, 'sha256': sha(archive), 'members': len(manifest) + 1,
        'human_authority_source': (P / 'Direct_Human_Authority.json').relative_to(R).as_posix(),
        'human_authority_sha256': sha(P / 'Direct_Human_Authority.json'),
        'private_adapter_tokenizer_authorized': True, 'credentials_network_bank_privateTRAINlabels_uploaded': False,
        'public_base_fetched_by_exact_revision': p['base_for_new_experiment']})
    source_names = remote_names + ['run_native13_fullband_original_adapter_colab_20261021.py',
        'coordinate_native13_fullband_original_adapter_engineering_20261021.py', reader,
        'native13_fullband_hybrid_contract_20261021.py', 'paper_native13_causal_contract_v2_20261021.py',
        'check_native_parser_contract_v3_20261021.py', 'public_size_local_preservation_v2.py',
        'google_account_profile.py', 'coordinate_single_source_bound_owner_20261020.py']
    source_hashes = {(R / 'work' / n).relative_to(R).as_posix(): sha(R / 'work' / n) for n in source_names}
    for n in source_names:
        if n.endswith('.py'):
            ast.parse((R / 'work' / n).read_text(encoding='utf-8'))
    for n in ['Frozen_Engineering_Protocol.json', 'All6_Messages_And_Token_IDs.json',
              'All2_Exact_Engineering_Cases.json', 'Software_And_Method_Readiness.json',
              'Cloud_Payload_Manifest.json', 'Direct_Human_Authority.json']:
        source_hashes[(P / n).relative_to(R).as_posix()] = sha(P / n)
    from candidate_process_evidence_utils import frozen_checks
    put(P / 'Launch_Readiness_Audit.json', {'passed': True, 'at_utc': datetime.now(timezone.utc).isoformat(),
        'source_hashes': source_hashes, 'fixed_model_outputs_primary6_cold6': True,
        'actual_loader_reused_pinned_and_previously_integrated_not_assumed_new_model_success': True,
        'all6_current_causal_prefixes_and_actual_token_IDs_pinned': True,
        'single_original_profile_one_T4_request_no_account_fallback': True,
        'fresh_account_assignment_and_claim_PID_parent_command_before_allocation': True,
        'full_private_adapter_public_base_identity_and_context_bindings': True,
        'post_each_output_hashed_local_ACK_before_further_generation': True,
        'same_assignment_GET_only_preservation_no_scientific_retry': True,
        'release_only_after_actual_remote_child_ended_and_all_artifacts_preserved': True,
        'no_PF_optimizer_training_or_physical_performance_campaign': True,
        'independent_reader_zero_new_model_calls': True,
        'frozen_original_checks': frozen_checks()})
    for kind, source, output, coordination, bound in [
        ('Primary', 'run_native13_fullband_original_adapter_colab_20261021.py',
         'native13_fullband_original_adapter_engineering_execution_20261021',
         'native13_fullband_original_adapter_engineering_coordination_20261021', 3900),
        ('Reader', reader, 'native13_fullband_original_adapter_engineering_independent_20261021',
         'native13_fullband_original_adapter_engineering_reader_coordination_20261021', 600)]:
        put(P / (kind + '_Owner_Protocol.json'), {'single_owner': {
            'source': 'work/' + source, 'sha256': sha(R / 'work' / source),
            'python': 'work/vcsa_module_env/Scripts/python.exe', 'output': 'outputs/' + output,
            'coordination': 'outputs/' + coordination, 'bound_seconds': bound},
            'require_ended_claims': []})
    put(P / 'Independent_Reader_Lock.json', {'source': 'work/' + reader,
        'sha256': sha(R / 'work' / reader), 'new_model_PF_optimizer_calls': 0,
        'only_after_primary_chain_ended_released_all_closed_artifacts': True})
    print(json.dumps({'status': 'FROZEN_BOUNDED_NEW6_PLUS6_ORIGINAL_ADAPTER_ENGINEERING',
                      'private_payload_bytes': archive.stat().st_size, 'members': len(manifest) + 1,
                      'primary_owner_source': 'work/run_native13_fullband_original_adapter_colab_20261021.py',
                      'no_actual_model_PF_GPU_calls_by_preparation': True}))


if __name__ == '__main__':
    main()
