"""All original500 native test recipes, no solved voltages/learned policy or PF calls."""
import hashlib,json,pickle,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs/stable_ddpg_native500_input_roster_20261020'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False);start=time.monotonic()
    protocol={'at_utc':datetime.now(timezone.utc).isoformat(),'scope':'ALLoriginalpublishedtest_suc_rate rep0..499 inputrecipes in originalorder;pureauthorresetcontrolflow with explicitlyMOCK solvercallback. No voltageoutcomes/NNinference/training/physics. Not a selectedsubset or unusedconfirmation.','fixed_control_buses':[2,7,9],'source_all_bus_flag':False,'source_recipe_count':500,'mock_solved_voltage':'Constant1 solelytoalloworiginalresetreturn;not storedas an observation or claimedphysicalresult.','zero_PF_model_GPU_calls':True,'every_recipe_retained':True,'remaining_physical_roots':'Seed0alreadymeasured,neverrepeat. Seeds1..499remainUNKNOWN/unexecuted andrequireseparatefixedowner/source/cost/preservation/readerprotocol.'}
    (OUT/'Protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    import stable_ddpg_native_bridge_20261020 as b
    env,proxy,proof=b.environment();np=b.np;captured=[]
    def mock(net,*args,**kwargs):
        assert not args and kwargs=={'algorithm':'bfsw'}
        captured.append({k:net[table][column].to_numpy(copy=True) for k,table,column in [('sgen_p','sgen','p_mw'),('sgen_q','sgen','q_mvar'),('load_p','load','p_mw'),('load_q','load','q_mvar')]})
        net['res_bus']=b.pd.DataFrame({'vm_pu':np.ones(13)},index=net.bus.index)
    proxy.runpp=mock
    for seed in range(500):env.reset(seed)
    assert len(captured)==500
    arrays={k:np.stack([r[k] for r in captured]) for k in captured[0]};np.savez(OUT/'All500_Native_Physical_Input_Recipes.npz',**arrays)
    # Independent literal native RNG equations,not another execution of author reset.
    mismatches=[];kinds=[]
    for seed in range(500):
        rng=np.random.RandomState(seed);kind=int(rng.choice([0,1]));kinds.append(kind);p=np.zeros(12);q=np.zeros(12)
        if kind==0:p[0]=-.5*rng.uniform(1,7);p[1]=-.8*rng.uniform(1,4);p[2]=-.3*rng.uniform(1,5)
        else:
            p[0]=rng.uniform(.5,4);p[1]=rng.uniform(0,4.51);p[2]=rng.uniform(0,5);q[3]=.3*rng.uniform(0,.2);p[4]=.5*rng.uniform(2,3);q[5]=.4*rng.uniform(0,10);p[10]=rng.uniform(.2,3);p[11]=rng.uniform(0,1.5)
        if not (np.array_equal(p,arrays['sgen_p'][seed]) and np.array_equal(q,arrays['sgen_q'][seed]) and np.all(arrays['load_p'][seed]==0) and np.all(arrays['load_q'][seed]==0)):mismatches.append(seed)
    assert not mismatches
    with (ROOT/'outputs/stable_ddpg_native_engineering_20261020/PF0_before.pkl').open('rb') as f:paid=pickle.load(f)
    assert np.array_equal(arrays['sgen_p'][0],paid.sgen.p_mw.to_numpy()) and np.array_equal(arrays['sgen_q'][0],paid.sgen.q_mvar.to_numpy()) and np.array_equal(arrays['load_p'][0],paid.load.p_mw.to_numpy()) and np.array_equal(arrays['load_q'][0],paid.load.q_mvar.to_numpy())
    rows=[]
    for seed in range(500):
        h=hashlib.sha256()
        for k in sorted(arrays):h.update(k.encode());h.update(arrays[k][seed].tobytes())
        rows.append({'author_rep_seed':seed,'source_scenario_branch':kinds[seed],'physical_vectors_sha256':h.hexdigest(),'physical_voltage_results':'seed0previouslyverified;remainingUNKNOWN' if seed==0 else 'UNKNOWN_UNEXECUTED'})
    (OUT/'All500_Ordered_Identities.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL500_SOURCE_NATIVE_INPUT_RECIPES_INDEPENDENT_LITERAL_RNG_AND_PAID_SEED0_JOIN','all500retained':True,'unique_physical_input_vectors':len({r['physical_vectors_sha256'] for r in rows}),'source_low_branch_count':kinds.count(0),'source_high_branch_count':kinds.count(1),'actual_UV_OV_for_seeds1to499':'UNKNOWN;sourcebranchlabelsarenotmeasuredvoltages','source_AST_proof':proof,'native_network_conversion_calls':1,'mock_reset_callbacks':500,'new_model_PF_GPU_calls':0,'arrays_sha256':sha(OUT/'All500_Native_Physical_Input_Recipes.npz'),'workflow_seconds':time.monotonic()-start,'limitations':'Authorrandomstressrecipeszeroallnative loads andusecontrollednegativegenerators aslow-voltageloads;highbranchhasuncontrolleddisturbances. Not a claim of realisticoperationaltraces or unusedconfirmation. Originalrealdata isseparate.'}
    (OUT/'Independent_Input_Audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps({k:result[k] for k in ['status','unique_physical_input_vectors','source_low_branch_count','source_high_branch_count','new_model_PF_GPU_calls']}))
if __name__=='__main__':main()
