"""Mechanical ended-owner custody/reader only. No scientific retries or forged exit0."""
import json,os
from pathlib import Path
from fixed_four_query_core_20261019 import B,PHASES,helpers
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from equal_operation_benchmark_v2 import process

def main():
    out=B/'custody_repair';out.mkdir(exist_ok=False);p=read(B/'Protocol.json');h=helpers(__file__)
    c=read(B/'Coordinator_Claim.json');assert process(c['actual_pid']) is None and process(c['parent_pid']) is None
    for ph in PHASES:
        claim=read(B/ph/'owner.claim');assert process(claim['actual_pid']) is None and process(claim['actual_parent_pid']) is None
    assert not (B/'audit').exists()
    # Last original child was ACKed while freshly live, never restarted; its
    # OS handle was already gone before custody acquired it. Preserve UNKNOWN.
    last=B/'cold_3';proof=read(last/'Custody_Actual_End_Proof.json')
    assert all(v['actual_exit_code']=='UNKNOWN_ALREADY_ENDED' for v in proof['owners'])
    assert read(last/'Result.json')['status']=='COMPLETE_FIXED_PHASE_WITH_QUERY_ONLY_STATE'
    for rel,digest in read(last/'Closed_Manifest.json')['members'].items():assert sha(last/rel)==digest
    put(out/'Original_Coordinator_Failure.json',{'original_source':p['source_input_sha256'],'original_completion':read(B/'Completion.json'),
        'failure':'JSONDecodeError reading freshly created cold_3/owner.claim before original put finished writing. Original coordinator ENDED before Launcher_ACK. Same waiting live child was freshly PID/parent/command/source verified then ACKed without restart.',
        'exact_original_failure_location':'exact_two_paid_query_engineering_20261018.py launch, read(out/owner.claim)',
        'actual_last_exit_code':'UNKNOWN_ALREADY_ENDED','last_result_and_closed_source_bound_evidence_retained':True,'no_science_repeated':True,'bound_unchanged':p['absolute_deadline_utc'],
        'secondary_readonly_prelaunch_observation':'Separate additional prelaunch observer overlapped coordinator and saw newly created warm directory; authoritative coordinator had already required all phases absent before launch. Preserve this observation as a race, not a completed additional prelaunch gate.'})
    claim=read(last/'owner.claim')
    put(B/'cold_3_End_ACK.json',{'actual_pid':claim['actual_pid'],'launcher_pid':claim['actual_parent_pid'],'exit_code':'UNKNOWN_ALREADY_ENDED','closed_manifest_sha256':sha(last/'Closed_Manifest.json'),'actual_owned_chain_ended':True,'not_exit0_claim':True})
    code=h['launch'](R/p['independent_reader_source'],'reader',B/'audit',p)
    result=read(B/'audit/Independent_Audit.json');assert code==0 and result['status']=='PARTIAL_PRESERVED_OUTPUTS_NO_POLICY_GATE' and result['failure_or_unstarted_phases']==['cold_3_EXIT_NONZERO']
    # Original assertion uses !=0: UNKNOWN is retained under its original
    # label, with this explicit clarification. All physics/source checks run.
    put(out/'Completion.json',{'reader_exit_code':code,'original_physical_evidence_checks_completed':True,'original_overall_complete_gate':'UNKNOWN_LAST_PROCESS_EXIT','literal_original_failure_label':'cold_3_EXIT_NONZERO','actual_last_exit':'UNKNOWN_NOT_MEASURED_NONZERO','new_model_PF_derivative_forecast_solve_calls':0,'all_owners_ended':True})
    manifest(out);print(json.dumps({'reader_exit':code,'PF':result['counts'],'source_physics_checks':'PASS','overall_complete_gate':'UNKNOWN_LAST_PROCESS_EXIT','new_scientific_calls':0}))
if __name__=='__main__':main()
