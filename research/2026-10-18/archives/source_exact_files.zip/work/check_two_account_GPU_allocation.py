"""Human-requested bounded hardware checks, separate from scientific experiments.

One allocation request per explicitly named existing account, no automatic
fallback, retries, dataset/model upload or inference. Release only runtimes
created with this check's freshly preserved UUID. Never change old claims.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import logging
import os
import uuid
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import AuthorizedSession, Request
from colab_cli.client import Client, Prod, Variant, Accelerator
from colab_cli.runtime import ColabRuntime
from colab_allocation_diagnostics import failure_details

logging.disable(logging.CRITICAL)
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/resource_checks'/('human_GPU_probe_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S'))
OUT.mkdir(exist_ok=False)
(OUT/'owner.claim').write_text(str(os.getpid()))
profiles = {
    'original': (r'C:\Users\HOME\AppData\Roaming\gcloud\application_default_credentials.json', 'abdulhannaan2002@gmail.com'),
    'isolated': (r'C:\Users\HOME\AppData\Roaming\gcloud-hiergrid-sheenah\application_default_credentials.json', 'sheenahammed@gmail.com')}
report = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'owner_pid': os.getpid(),
          'authorization': 'Direct human request: check two accounts to see if any has GPU access now',
          'maximum_allocation_requests_per_account': 1, 'automatic_account_fallback': False,
          'model_or_dataset_uploads': 0, 'model_inference_calls': 0,
          'free_remaining_hours_or_reset_time_known': False, 'profiles': {}}

def save():
    temporary = OUT/'status.tmp'
    temporary.write_text(json.dumps(report, indent=2), encoding='utf-8')
    temporary.replace(OUT/'status.json')

class BoundedSession(AuthorizedSession):
    def request(self, *args, **kwargs):
        kwargs.setdefault('timeout', (10, 30))
        return super().request(*args, **kwargs)

transport = Request()
def refresh(*args, **kwargs):
    kwargs.setdefault('timeout', 30)
    return transport(*args, **kwargs)

save()
for profile, (credential_path, expected_email) in profiles.items():
    row = {'expected_account': expected_email, 'stage': 'authenticating', 'runtime_allocated': False,
           'runtime_released': False, 'allocation_request_count': 0, 'CUDA_tensor_execution_verified': False}
    report['profiles'][profile] = row
    save()
    client = session = runtime = endpoint = None
    try:
        credentials = Credentials.from_authorized_user_file(credential_path)
        credentials.refresh(refresh)
        session = BoundedSession(credentials, refresh_timeout=30)
        identity = session.get('https://www.googleapis.com/oauth2/v2/userinfo')
        identity.raise_for_status()
        assert identity.json().get('email') == expected_email
        row['authenticated_account'] = expected_email
        client = Client(Prod(), session)
        assert not client.list_assignments(), 'Account has an existing runtime; do not allocate or alter it'
        usage = session.get('https://colab.research.google.com/tun/m/ccu-info', params={'authuser': '0'},
                            headers={'Accept': 'application/json', 'X-Colab-Client-Agent': 'colab-cli'})
        usage.raise_for_status()
        info = json.loads(usage.text.removeprefix(")]}'\n"))
        row['reported_eligible_GPUs'] = info.get('eligibleGpus')
        if 'T4' not in (info.get('eligibleGpus') or []):
            row['stage'] = 'T4_reported_ineligible_no_request'
            save()
            continue
        notebook_hash = uuid.uuid4()
        row.update(stage='requesting_one_T4', notebook_hash=str(notebook_hash), allocation_request_count=1,
                   requested_variant='GPU', requested_accelerator='T4', requested_shape='standard')
        save()
        assignment = client.assign(notebook_hash, variant=Variant.GPU, accelerator=Accelerator.T4)
        endpoint = assignment.endpoint
        row.update(runtime_allocated=True, stage='checking_actual_CUDA_hardware')
        save()
        assert assignment.accelerator == Accelerator.T4
        runtime = ColabRuntime(url=assignment.runtime_proxy_info.url, token=assignment.runtime_proxy_info.token,
                               session_name='hiergrid-human-requested-hardware-check')
        outputs = runtime.execute_code("import json, torch\nassert torch.cuda.is_available()\nname=torch.cuda.get_device_name(0)\nassert 'T4' in name\nvalue=float(torch.tensor([1.,2.,3.], device='cuda').sum().item())\nassert value==6.\nprint('HIERGRID_HARDWARE_CHECK '+json.dumps({'device':name,'CUDA_available':True,'tensor_sum':value}))", allow_stdin=False, timeout=120)
        assert not any(x.get('output_type') == 'error' for x in outputs), 'CUDA hardware check returned an error'
        text = ''.join(str(x.get('text', '')) for x in outputs)
        marker = next(line for line in text.splitlines() if line.startswith('HIERGRID_HARDWARE_CHECK '))
        proof = json.loads(marker.split(' ', 1)[1])
        assert proof['CUDA_available'] and proof['tensor_sum'] == 6.0 and 'T4' in proof['device']
        row.update(CUDA_tensor_execution_verified=True, hardware_proof=proof, stage='actual_T4_verified')
    except Exception as exc:
        row.update(stage='hardware_check_blocked_or_failed', failure=failure_details(exc))
    finally:
        if runtime is not None:
            try:
                runtime.stop()
            except Exception as exc:
                row['kernel_stop_failure'] = failure_details(exc)
        if endpoint is not None:
            try:
                client.unassign(endpoint)
                row['runtime_released'] = True
            except Exception as exc:
                row['owned_runtime_release_failure'] = failure_details(exc)
                # Preserve UUID for exact same-assignment cleanup; no replacement.
        if client is not None:
            try:
                row['post_check_active_assignment_count'] = len(client.list_assignments())
            except Exception as exc:
                row['post_check_assignment_failure'] = failure_details(exc)
        if session is not None:
            session.close()
        row['checked_at_utc'] = datetime.now(timezone.utc).isoformat()
        save()
        print('ACCOUNT_GPU_CHECK', profile, json.dumps(row), flush=True)
report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
report['stage'] = 'both_requested_account_checks_finished'
save()
print('GPU_CHECK_REPORT_PATH', str(OUT/'status.json'), flush=True)
