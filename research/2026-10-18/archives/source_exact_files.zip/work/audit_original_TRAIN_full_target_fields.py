"""New TRAIN-only field consistency question; reuse old physical input classes."""
import gzip
import hashlib
import json
import math
import os
import sys
import time
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended

OUT = extended(ROOT / 'outputs/critical_research_reset_20261010/original_TRAIN_full_target_field_support')
TRAIN = Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2b_training_inputs.zip')
MEMBER = 'hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'
EXPECTED_TRAIN = '7b22162d0abd92ccb64473fcef5bb300ee12416ce22ea6ce03e60fefaa9154eb'
OLD_ROWS = ROOT / 'outputs/critical_research_reset_20261010/original_TRAIN_causal_label_support/All16000_TRAIN_Identity_and_Projection_Records.json'
EXPECTED_OLD_ROWS = '2182df652584132704aab8c3b055a01b5779fdefa98223f10402e5998cb22eac'

def canonical(value):
    if value is None: return ['null']
    if isinstance(value, bool): return ['boolean', value]
    if isinstance(value, (int, float)):
        assert math.isfinite(value)
        n, d = value.as_integer_ratio()
        return ['number', str(n), str(d)]
    if isinstance(value, str): return ['string', value]
    if isinstance(value, list): return ['list', [canonical(x) for x in value]]
    assert isinstance(value, dict)
    return ['object', [[k, canonical(value[k])] for k in sorted(value)]]

def digest(value):
    return hashlib.sha256(json.dumps(canonical(value), ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()

def run():
    assert not OUT.exists(), 'Never duplicate or overwrite an existing claim'
    OUT.mkdir()
    started = time.perf_counter()
    write(OUT / 'audit.claim', {'actual_pid': os.getpid(), 'command': sys.argv, 'source_sha256': sha(Path(__file__)), 'at_utc': datetime.now(timezone.utc).isoformat()})
    protocol = {
        'declared_at_utc': datetime.now(timezone.utc).isoformat(),
        'question': 'Are exact complete/field output targets consistent under reused current-local physical input classes, and under exact original message prefixes?',
        'all16000_TRAIN_rows_only': True,
        'TRAIN_member_sha256': EXPECTED_TRAIN,
        'prior_all_row_projection_record_sha256': EXPECTED_OLD_ROWS,
        'physical_projection': 'REUSE prior exact zone + ALL local_measurements projection; excludes scenario ID/type/severity and linguistic instructions',
        'original_prefix_projection': 'Exact role/content strings of all messages before the final assistant; includes actual administrative fields/instructions. Prefix bytes, not a new tokenizer test.',
        'all_target_fields': 'Union of all top-level assistant JSON keys, explicit missing value distinct from null; complete parsed target also compared',
        'target_canonicalization': 'Exact parsed numeric ratios; strings and arrays retained; no rounding, dropping, zero imputation or response repair',
        'conflict_rule': 'More than one exact target hash for an identical declared input class',
        'bound': 'Sum largest target frequency in each class / 16000; empirical teacher-match bound under THAT information projection only',
        'interpretation': 'Physical projection conflicts do not prove conflicts in actual original prompts, which may include IDs/type/severity/instructions. Free text differences do not prove semantic contradictions.',
        'canonical_field_UTF8_bytes_are_not_tokens_loss_weights_or_FLOPs': True,
        'all_worlds_failures_and_missing_fields_retained': True,
        'no_new_VAL_test_label_metrics': True,
        'no_new_neural_PF_optimizer_controller_native_forecast_solve_or_cloud_calls': True,
        'no_automatic_training_or_change_to_existing_stopped_methods': True,
        'resource_bound_seconds_before_seal': 120,
    }
    write(OUT / 'Prospective_Field_Support_Protocol.json', protocol)
    assert sha(OLD_ROWS) == EXPECTED_OLD_ROWS
    old_rows = read(OLD_ROWS)
    assert len(old_rows) == 16000
    with zipfile.ZipFile(TRAIN) as archive: raw = archive.read(MEMBER)
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_TRAIN
    items = [json.loads(line) for line in raw.decode('utf8').splitlines()]
    fields = sorted({key for item in items for key in json.loads(item['messages'][-1]['content'])})
    assert '__complete_parsed_target__' not in fields
    targets = fields + ['__complete_parsed_target__']
    groups = {projection: {field: defaultdict(Counter) for field in targets} for projection in ('current_physical_input', 'original_message_prefix')}
    field_presence = Counter()
    field_bytes = Counter()
    source_worlds = set()
    identities = []
    for index, item in enumerate(items):
        assert time.perf_counter() - started < 120
        messages = item['messages']
        assert messages[-1]['role'] == 'assistant' and old_rows[index]['TRAIN_row_index'] == index
        user = json.loads(next(m['content'] for m in messages if m['role'] == 'user'))
        world_hash = hashlib.sha256(str(user['scenario_id']).encode()).hexdigest()
        assert world_hash == old_rows[index]['world_sha256']
        source_worlds.add(world_hash)
        target = json.loads(messages[-1]['content'])
        projections = {'current_physical_input': old_rows[index]['projections']['full_current_local_information'], 'original_message_prefix': digest(messages[:-1])}
        hashes = {}
        for field in targets:
            present = field == '__complete_parsed_target__' or field in target
            value = target if field == '__complete_parsed_target__' else target.get(field)
            hashes[field] = digest(['present', value]) if present else digest(['missing'])
            if field in target:
                field_presence[field] += 1
                field_bytes[field] += len(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode())
            for projection, key in projections.items(): groups[projection][field][key][hashes[field]] += 1
        identities.append({'TRAIN_row_index': index, 'world_sha256': world_hash, 'projection_sha256': projections, 'target_field_sha256': hashes})
    assert len(items) == 16000 and len(source_worlds) == 109
    classes = {}
    summaries = {}
    for projection, fields_groups in groups.items():
        classes[projection] = {}
        summaries[projection] = {}
        for field, field_groups in fields_groups.items():
            records = [{'input_sha256': key, 'rows': sum(c.values()), 'target_counts': dict(c), 'exact_label_ambiguous': len(c) > 1} for key, c in sorted(field_groups.items())]
            classes[projection][field] = records
            matched = sum(max(c.values()) for c in field_groups.values())
            summaries[projection][field] = {'distinct_inputs': len(records), 'ambiguous_input_classes': sum(len(c) > 1 for c in field_groups.values()), 'rows_in_ambiguous_classes': sum(sum(c.values()) for c in field_groups.values() if len(c) > 1), 'minimum_exact_teacher_mismatches': len(items) - matched, 'empirical_row_weighted_exact_teacher_match_upper_fraction': matched / len(items)}
    with gzip.open(OUT / 'All_TRAIN_Field_Identities.jsonl.gz', 'xt', encoding='utf8') as stream:
        for item in identities: stream.write(json.dumps(item, separators=(',', ':')) + '\n')
    write(OUT / 'All_Field_Equivalence_Classes.json', classes)
    summary = {'at_utc': datetime.now(timezone.utc).isoformat(), 'all16000_TRAIN_rows_retained': True, 'original_TRAIN_world_groups': len(source_worlds), 'all_top_level_target_fields': fields, 'source_member_sha256': EXPECTED_TRAIN, 'prior_projection_records_sha256': EXPECTED_OLD_ROWS, 'field_presence_counts': dict(field_presence), 'canonical_field_value_UTF8_bytes': dict(field_bytes), 'not_actual_token_loss_or_timing_weights': True, 'projections_and_exact_field_support': summaries, 'interpretation': protocol['interpretation'], 'actual_new_model_PF_optimizer_controller_forecast_solve_cloud_calls': 0, 'workflow_seconds_before_frozen_checks_and_seal': time.perf_counter() - started, 'automatic_learning_or_GPU_launch': False}
    write(OUT / 'Original_TRAIN_Full_Target_Field_Support.json', summary)
    write(OUT / 'Fresh_Frozen_Asset_Checks.json', frozen_checks())
    files = {p.name: p for p in OUT.iterdir() if p.is_file() and p.name != 'audit.claim'}
    files['sources/reader.py'] = Path(__file__)
    archive = seal(OUT, files, 'TRAIN_Full_Target_Field_Support.zip')
    print(json.dumps({'summary': summary, 'archive': archive}))

if __name__ == '__main__': run()
