"""All500 saved numerical diagnosis; no rerun, new model or solver call."""
import json,hashlib
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parents[1]
O=R/'outputs/public13_saved_numeric_stagnation_20261022'

def main():
    O.mkdir(exist_ok=False);path=R/'outputs/public13_matched_numeric_execution_20261021/Result.json';raw=path.read_bytes();data=json.loads(raw)
    audit=json.loads((R/'outputs/public13_matched_numeric_independent_20261021/Independent_Audit.json').read_text());assert audit['all500_complete']
    groups={};rows=[];global_counts=Counter()
    for world in data['worlds']:
        initial=world['initial'];kind='UV_only' if initial['UV'] and not initial['OV'] else 'OV_only' if initial['OV'] and not initial['UV'] else 'within_band' if not initial['UV'] and not initial['OV'] else 'mixed'
        counts=Counter();max_run=run=0
        for step in world['steps']:
            same_Q=step['candidate_Q']==step['current_Q'];same_VM=step['candidate_vm']==step['current_vm'];zero_u=all(v==0 for v in step['native_u'])
            counts['decisions']+=1;counts['accepted']+=step['accepted'];counts['unchanged_Q']+=same_Q;counts['unchanged_all13VM']+=same_VM
            counts['nonzero_u_lost_in_float64_Q_accumulation']+=same_Q and not zero_u
            counts['all_zero_float32_u']+=zero_u;counts['accepted_unchanged_Q']+=same_Q and step['accepted']
            run=run+1 if same_Q and step['accepted'] else 0;max_run=max(max_run,run)
        final=world['final'];vm=world['final_vm'];failed=not final['full13band'];distance=max([max(.95-v,0,v-1.05) for v in vm])
        row=dict(seed=world['seed'],input_stratum=kind,terminal_status=world['status'],initial=initial,final=final,steps=len(world['steps']),strict_failure=failed,max_band_distance=distance,
            failed_but_inside_1e_minus8_NOT_reclassified=bool(failed and distance<=1e-8),max_consecutive_accepted_unchanged_Q=max_run,counts=dict(counts));rows.append(row)
        g=groups.setdefault(kind,Counter());g['cases']+=1;g['fullband']+=not failed;g['strict_failures']+=failed;g['near_boundary_failures_NOT_passes']+=row['failed_but_inside_1e_minus8_NOT_reclassified'];g['100round_terminal']+='100' in world['status'];g['cases_with_accepted_unchanged_Q']+=counts['accepted_unchanged_Q']>0;g.update(counts);global_counts.update(counts)
    result=dict(at_utc=datetime.now(timezone.utc).isoformat(),status='COMPLETE_ALL500_SAVED_ACTION_ARITHMETIC_AND_STAGNATION_DIAGNOSIS_ZERO_NEW_SCIENCE',source_sha256=hashlib.sha256(raw).hexdigest(),groups={k:dict(v) for k,v in groups.items()},all_counts=dict(global_counts),all500_rows=rows,
        causal_limit='Exact saved equality diagnoses repeated physical-input/VM calls and float64 accumulation cancellation. It does not prove that changing stopping, margin, LP objective, thresholds or model would restore voltage or beat a control. All strict failures and costs remain failures; old fixed intervention remains stopped.',
        next_method_gate='A future numerical algorithm must state representable-action and strict-feasibility semantics prospectively and face all controls; no minor outcome-driven tolerance/Q/horizon rescue. This diagnosis gives no incremental LLM value.',new_PF_model_derivative_LP_calls=0)
    (O/'All500_Arithmetic_Diagnosis.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps(dict(groups=result['groups'],all_counts=result['all_counts'],new_science=0)))

if __name__=='__main__':main()
