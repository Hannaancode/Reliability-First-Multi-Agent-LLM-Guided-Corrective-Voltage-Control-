"""Immutable container for prior paid ACKs; original import method AST exact.

Only source read transport is rebound to hash-checked ZIP members. The original
source/point/record/native-reader validator and durable target writer are intact.
"""
import ast,hashlib,json,time,zipfile
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
import verified_paid_cache_engine_v1_20261018 as original
P=R/'outputs/exact_receipt_ack_import_preparation_20261019'
OLD=R/'outputs/resumed16_with_fixed_followup_receipts_v2_20261019'

def method_node():
    cls=next(n for n in ast.parse(Path(original.__file__).read_text('utf-8')).body if isinstance(n,ast.ClassDef) and n.name=='VerifiedPaidUseRegistry')
    return next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='import_existing_ack')

def build():
    assert read(P/'Results.json')['status']=='PASS_ACTUAL_EXISTING_ACK_IMPORT_AND_FOUR_SOURCE_IDENTITY_MUTATIONS'
    paths=sorted((OLD/'verified_uses/acks').glob('*.json'));assert len(paths)==697
    closed=read(OLD/'Closed_Manifest.json')['members'];rows=[];old_seconds=0.
    zpath=P/'All697_Closed_Receipt_ACKs.zip'
    with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
        for path in paths:
            raw=path.read_bytes();h=hashlib.sha256(raw).hexdigest();assert h==closed[str(path.relative_to(OLD))]
            value=json.loads(raw);assert value['status']=='PASS_EXACT_CAUSAL_ARCHIVED_RECEIPT_SAVED_NATIVE_VERIFIER'
            name=path.name;z.writestr(name,raw);rows.append({'member':name,'source_path':str(path.relative_to(R)),'bytes':len(raw),'sha256':h,'point_action_key':value['point_action_key']});old_seconds+=value['paid_certificate_CPU_seconds']
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        for v in rows:assert hashlib.sha256(z.read(v['member'])).hexdigest()==v['sha256']
    put(P/'All697_Closed_Receipt_ACKs.json',{'status':'PASS_ALL697_EXACT_CLOSED_SOURCE_ACK_BYTES_CRC_AND_HASH','rows':rows,'zip_sha256':sha(zpath),'source_closed_manifest_sha256':sha(OLD/'Closed_Manifest.json'),
        'source_result_sha256':sha(OLD/'Results.json'),'source_prior_workflow_seconds':read(OLD/'Results.json')['workflow_seconds'],'prior_actual_certificate_workflow_seconds':old_seconds,
        'existing_import_method_AST_sha256':hashlib.sha256(ast.dump(method_node(),include_attributes=False).encode()).hexdigest(),'original_registry_source_sha256':sha(original.__file__),
        'cost_policy':'All old source/PF/preparation/verification costs stay separately attributed. Only immutable paid proof computation is reused; no new physical or LLM result.','new_scientific_calls':0})
    print(json.dumps({'ACK_bundle':697,'bytes':zpath.stat().st_size,'newPF':0}))

def import_members(registry,selected=None):
    started=time.perf_counter();metadata=read(P/'All697_Closed_Receipt_ACKs.json');zpath=P/'All697_Closed_Receipt_ACKs.zip';assert sha(zpath)==metadata['zip_sha256'] and sha(original.__file__)==metadata['original_registry_source_sha256']
    node=method_node();assert hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==metadata['existing_import_method_AST_sha256']
    members={r['member']:r for r in metadata['rows']};names=list(members) if selected is None else list(selected);assert set(names)<=set(members)
    with zipfile.ZipFile(zpath) as z:
        def exact_read(name):
            row=members[name];raw=z.read(name);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];value=json.loads(raw);assert value['point_action_key']==row['point_action_key'];return value
        env=registry.import_existing_ack.__func__.__globals__.copy();env['read']=exact_read
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(original.__file__),'exec'),env)
        for name in names:env['import_existing_ack'](registry,name)
    return {'status':'PASS_IMPORTED_EXACT_SOURCE_BOUND_PRIOR_ACKS_WITH_UNCHANGED_VALIDATOR_AST','imported':len(names),'bundle_sha256':metadata['zip_sha256'],
        'source_closed_manifest_sha256':metadata['source_closed_manifest_sha256'],'prior_workflow_seconds_retained':metadata['source_prior_workflow_seconds'],
        'prior_certificate_workflow_seconds_retained':metadata['prior_actual_certificate_workflow_seconds'],'this_import_workflow_seconds':time.perf_counter()-started,'new_scientific_calls':0,
        'limitations':'Analytical preservation efficiency, not a controller/LLM deployment-speed or superiority claim. Future job must source-lock ZIP/metadata/code before importing.'}

if __name__=='__main__':build()
