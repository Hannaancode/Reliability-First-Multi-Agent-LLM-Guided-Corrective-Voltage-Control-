# HierGrid environment and asset audit

Audit date: 6 October 2026. This session runs in a Linux cloud workspace at `/workspace`, not on the user's Windows computer.

## Verified capabilities

- Python 3.12.14 with a separate CPU virtual environment at `/workspace/.venvs/hiergrid`.
- All seven repository requirements installed; dependency compatibility check passes. Exact resolved versions are in `constraints.txt` and `environment_report.json`.
- GitHub read access succeeds through the existing Git configuration.
- Standard pandapower IEEE-118 AC power flow and a copied-network shunt candidate both converge. This is a dependency smoke check, not a replay of the missing frozen federation or a controller result.
- All 151 included scenario/result JSON files and 11 result CSVs load. The 137-case historical router CSV agrees with its summary; the five saved residual-envelope cases do not worsen residual UV relative to their recorded fresh deterministic branch.
- Headless plotting succeeds. Writable Matplotlib/font caches are configured outside the checkout.
- Saved install instructions were rerun successfully. Tracked repository files remain unchanged.

## Available inputs

- Requested Git checkout, scripts, raw historical scenarios, saved results, and its artifact ZIP.
- Handover extracted to `/workspace/hiergrid-revision-inputs/hiergrid_codex_handover`.
- All 17 files listed in the handover manifest match the supplied byte sizes and SHA-256 hashes. This verifies transfer consistency, not the truth of historical performance claims.
- Two manuscripts, two revision/thesis plans, checklist, source bibliography, revision configuration, scenario generator, and older notebook export.
- The separately uploaded manuscripts are byte-identical to the two packaged PDFs.
- Current source/input hashes are recorded in `asset_manifest.json`.

## Required assets absent from supplied files

1. Latest `reflection.ipynb` and exact `phase2g_ITER25_resume_pack_*`, including original dependency/version records.
2. Mature runner dependencies including `phase2d_iterative_blackboard_v0.py`, `phase2g_multiagent_llm_runner.py`, and `phase2g_rescue_runner.py`.
3. Frozen federation network and zone metadata, adapter weights, tokenizer/base-model identity, and original physical training/split provenance.
4. Existing locked 62-case bank: scenario JSONs, `LOCKED_BANK.json`, and `reports/scenario_manifest.json`.
5. First-13 pilot logs, subsequent evaluation logs, full historical terminal trajectories/action logs, and a record of whether pilot outcomes informed tuning.

The handover ZIP explicitly says it is not a frozen runnable experiment pack. Its scenario generator was not run and no replacement bank was generated.

## Discrepancies to resolve before frozen replay

- Repository v2 script specifies eight iterations; guided-rescue script specifies ten. The supplied reviewer protocol and manuscript specify 25. Repository scripts are historical artifacts, not verified copies of the final frozen runners.
- `selected_phase2g_per_scenario.csv` has 68 unique rows; 66 have final UV, Vmin, and deficit present. The manuscript reports a 61-case complete matched population. Its exact identity/filter cannot be inferred from the folder name.
- Repository Q candidate lists vary from the revision configuration. The older notebook normalizer rounds by 25 and clips to 25–300, permitting intermediate values absent from the declared list. This is a possible source mismatch, not evidence those values were executed.
- `revision_config.py` labels DFF-ALT but contains no implementation of the second-ranked first-candidate rule.
- Existing repository router results are from the earlier development controller and cannot stand in for the final 137-case DFF/HG-VF/HG-SE campaign.
- The new CPU environment uses repository-declared, unpinned dependencies resolved during onboarding. It is not a verified reproduction of the frozen Colab software stack; do not use it for final numerical claims until the original stack is audited.
- The detailed reviewer plan specifies family-cluster bootstrap as primary with paired-scenario bootstrap as sensitivity; the shorter handover describes paired bootstrap with clustered sensitivity. Fix the primary analysis in a prospective protocol before final outcomes.
- One thesis-plan passage excludes poisoning from a narrow assurance cycle, whereas its later security-extension section and START_HERE include a four-arm retrieval/poisoning study. Treat the later consolidated handover as planning context and make the final scope explicit before that later campaign.

## Runtime and access limitations

No NVIDIA device files or `nvidia-smi` were available. Following the user's Colab connection request, Google's official `google-colab-cli==0.7.4` was installed in the separate environment `/workspace/.venvs/colab-cli`. Top-level help works. The CLI callback attempts to log under the read-only home directory, so a read-only connection checker uses the installed official client library with bounded requests and credential-bearing debug output suppressed, without editing the package or changing HOME.

`GOOGLE_APPLICATION_CREDENTIALS` is now present, but Google's ADC discovery rejects its configuration as unsupported. Only metadata/presence was inspected; no credential values were printed. There is no exposed secure browser or terminal sign-in handoff. The official OAuth flow requires the user to sign in and paste its authorization code into the same user-controlled terminal, not chat. Authentication in the user's local terminal does not authenticate this cloud workspace. No Google session or GPU was allocated and entitlement is unverified.

Unauthenticated HTTPS probes to `colab.research.google.com` and `colab.pa.googleapis.com` failed at the proxy. Diagnosis confirmed HTTP 403 with a denial marker. Installation/start instructions and connection-specific domain additions were saved successfully to the environment draft: `colab.research.google.com`, `colab.pa.googleapis.com`, `accounts.google.com`, `oauth2.googleapis.com`, `sdk.cloud.google.com`, and `www.googleapis.com`. Existing presets were preserved. Saving does not apply the policy to this running instance. Review/save and publication remain pending; authentication will still be required afterward.

No conversation-reading tool is exposed in this session. Neither linked conversation, **Thesis Improvement Plan** nor **LLM Value Assessment**, was retrieved; the uploaded structured handover and manuscript text provide the available context. PDF figures were not all visually inspected. The user explicitly confirmed the cybersecurity component in the current conversation.

After the user requested all supported connection options, official CLI authentication documentation and official Colab MCP/VS Code READMEs were retrieved. A personal `COLAB_ACCESS_TOKEN` requirement and updated connection checker/install/start instructions were saved successfully to the draft. The scoped bearer route is a candidate integration awaiting real authentication and live network activation, not a verified kernel connection. Its token must be entered only in secure settings and expires; user-side Google Cloud CLI installation is needed for the documented token-issuance route. See `colab_access_options.md` and `colab_connection_report.json`. No credential values were recorded.

## Current readiness

CPU analysis, dependency development, artifact inspection, and standard pandapower simulation are validated. Full frozen controller replay, development-case DFF-ALT validation, and locked-bank campaigns remain blocked by missing physical/model/source assets. The original scripts were attempted and fail on the missing v0 module and `/content/phase2g_rescue_runner.py`; these are missing-input failures rather than unexplained solver failures.

Reusable `install_script` and `start_skill` for the CPU workflow were saved successfully to the environment configuration draft. The save returned `requires_publish: true`; it does not apply or publish the configuration. The product user must review/save settings and publish to activate the reusable snapshot. A fresh-task restoration has not been tested.
