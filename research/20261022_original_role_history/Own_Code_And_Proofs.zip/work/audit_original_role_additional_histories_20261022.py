"""Independent saved-only query/reference coverage audit, no PF/model replay."""
import gzip, hashlib, json, os, time
from pathlib import Path
R = Path(__file__).resolve().parents[1]
O = R / 'outputs/original_role_additional_history_scope_20261022'
def read(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    started = time.perf_counter(); A = O / 'independent_audit'; A.mkdir(exist_ok=False)
    p = read(O / 'Protocol.json'); res = read(O / 'Result.json')
    assert sha(Path(__file__)) == p['reader_source_sha256']
    assert sha(R / 'work/close_original_role_additional_histories_20261022.py') == p['source_sha256']
    assert all(sha(O / rel) == h for rel, h in read(O / 'Closed_Manifest.json')['members'].items())
    assert res['status'] == 'COMPLETE_NAMED_ADDITIONAL_INPUT_SCOPE_ONLY' and not res['unclosed_or_missing']
    refs = json.loads(gzip.decompress((O / 'All_Named_Prior_Attempt_Component_References.json.gz').read_bytes()))
    from collections import Counter
    c = Counter(x['journal'] for x in refs)
    assert len(refs) == res['actual_named_attempts_checked']
    assert c == {x['journal']: x['closed_attempts'] for x in res['source_counts']}
    assert len(c) == 7 and sum(c.values()) == 9297
    # Independent source-ledger intent/closure identity multiset, including
    # the three failed reference calls. No failed call is replayed or dropped.
    for rel, h in p['sources'].items():
        path = R / rel; assert sha(path) == h
        attempts = []; ends = []
        for raw in path.open('rb'):
            row = json.loads(raw); row = row.get('row', row); e = row['event']; d = row.get('payload', row)
            if e in ['literal_PF_intent', 'direct_PF_intent', 'PF_intent', 'solver_attempt']: attempts.append(json.dumps(d['identity'], sort_keys=True))
            elif e in ['literal_PF_return', 'literal_PF_exception', 'direct_PF_return', 'direct_PF_exception', 'PF_return', 'PF_exception', 'solver_closed']:
                ends.append(json.dumps(d['identity'], sort_keys=True))
        assert Counter(attempts) == Counter(ends) == Counter(json.dumps(x['identity'], sort_keys=True) for x in refs if x['journal'] == rel)
    targets = read(R / 'outputs/original_role_prior_input_scope_20261022/All45_Indexed_Scope_Query.json')
    assert len(targets) == 45
    for t in targets:
        hits = [r for r in refs if r['component_sha256'] == t['physical_component_sha256']]
        assert hits == res['matching_refs'][t['physical_component_sha256']]
        assert len(hits) == res['target_match_counts'][f"{t['root']}|{t['bus']}|{t['q_mvar']}"]
    value = {'status': 'PASS_ALL_NAMED9297_ATTEMPT_ID_CLOSURES_AND_ALL45_COMPONENT_QUERIES',
        'all_checked_attempts': 9297, 'targets': 45, 'failed_reference_attempts_preserved': 3,
        'matching_components_remain_UNKNOWN': sum(v != 0 for v in res['target_match_counts'].values()),
        'new_PF_model_calls': 0, 'not_full_universal_history_closure_or_new_PF_authority': True,
        'independent_arithmetic_scope': 'Target arithmetic separately certified; original60426component arithmetic certificate reused. New source component production is saved-only, with source/intent/closure binding checked here; not a new physics replay.',
        'workflow_seconds': time.perf_counter() - started}
    with (A / 'Independent_Audit.json').open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2); f.flush(); os.fsync(f.fileno())
    with (A / 'Closed_Manifest.json').open('x', encoding='utf-8') as f:
        json.dump({'members': {'Independent_Audit.json': sha(A / 'Independent_Audit.json')}}, f, indent=2); f.flush(); os.fsync(f.fileno())
    print(json.dumps(value))

if __name__ == '__main__': main()
