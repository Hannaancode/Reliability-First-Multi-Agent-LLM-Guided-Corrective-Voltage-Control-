"""All four saved118roots; actual unchanged author policy, zero new PF."""
import copy,json,pickle,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'work'))
import candidate_process_runtime
sys.path.append(str(R/'work/physics_env/Lib/site-packages'))
from reflection118_chronological_core_20261022 import read,put,sha
from published_graph118_backend_20261022 import Graph118Env,author_policy,AUTHOR,AUTHOR_SHA
def main():
    import pandapower as pp
    def forbidden(*a,**kw):raise AssertionError('Source/backend admission only; no physics')
    pp.runpp=forbidden
    O=R/'outputs/published_graph118_backend_20261022';O.mkdir(exist_ok=False);start=time.monotonic();rows=[]
    Policy,astsha=author_policy(O)
    roots=read(R/'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json')
    for i,r in enumerate(roots):
        net=pickle.loads((R/r['solved_payload']).read_bytes())['net'];env=Graph118Env(net,O)
        agent=Policy(env=env,file_str=str(i),random=False);agent.init_episode();action=agent.get_action([]);after,decoded=env.apply_only(action)
        assert after.res_bus.equals(net.res_bus),'Apply-only must not invent new solved voltages'
        assert len(after.bus)==118 and len(after.shunt)==len(net.shunt)
        original=env.net.res_bus.vm_pu.copy();env.net.res_bus.loc[:,'vm_pu']=1.0;assert agent.get_action([])==0
        env.net.res_bus.loc[:,'vm_pu']=original
        # The original unique-action convention must skip a repeated proposal.
        second=agent.get_action([int(action)]) if action else 0
        if action:assert second!=action
        rows.append({'case_id':r['case_id'],'root_payload_sha256':r['payload_sha256'],'unchanged_author_class_AST_sha256':astsha,
            'nodes':agent.graph.number_of_nodes(),'edges':agent.graph.number_of_edges(),
            'regulated_gen_and_slack_buses':env.num_gen_reg_buses,'existing_binary_shunts':env.num_shunts,
            'positive_q_reactor_banks_retained_in_author_native_menu':sum(float(net.shunt.at[j,'q_mvar'])>0 for j in env.shunts),
            'first_source_action_id':int(action),'first_decoded_source_action':decoded,'source_next_unused_action_id_on_same_saved_observation':int(second),
            'all_band_noop_check':True,'unchanged_source_policy_and_apply_only_checks':True,
            'physical_outcome':'UNEXECUTED_UNKNOWN_NO_NEW_PF_OR_COMMIT'})
    put(O/'Author_Policy_Backend_Admission.json',{'status':'PASS_UNMODIFIED_AUTHOR_GRAPH_POLICY_ON_ALL4_EXACT118SAVED_ROOTS_BACKEND_SOFTWARE_ONLY',
        'source':str(AUTHOR.relative_to(R)),'source_sha256':AUTHOR_SHA,'policy_class_AST_sha256':astsha,
        'rows':rows,'source_experiment_gen_bins':[.95,.975,1.,1.025,1.05],'source_observation_dtype':'float32','source_all_v_range':'strict0.95..1.05 from float64 table; V_TOL.0001 preserved within graph choice',
        'backend_port':'PowerWorldSAW Ybus export replaced by exact stored pandapowerYbus rendered into the original author parser format; bus0based->1based mapping explicitly asserted. Not byte-identical PowerWorld physics.',
        'actuator_fairness':'Native published graph controls generator/slackV and installed binary banks. HierGrid adds positive shunts; do not report a same-resource win from these different action roles. A separately named common-action adaptation or shared actuator-capability benchmark is still required.',
        'no_trained_DQN_native_physics_or_benchmark_score_claim':True,'new_PF_model_gradient_training_converter_calls':0,'workflow_seconds':time.monotonic()-start,
        'own_sources':{p.relative_to(R).as_posix():sha(p) for p in [Path(__file__),R/'work/published_graph118_backend_20261022.py']}})
    put(O/'Closed_Manifest.json',{'members':{p.name:sha(p) for p in O.iterdir() if p.is_file()}})
    print(json.dumps({'author_policy':'UNCHANGED_AST','all4_backend_inputs':'PASS','first_actions':[r['first_decoded_source_action'] for r in rows],'new_PF_model_calls':0}))
if __name__=='__main__':main()
