"""Create additive implementations for fixed, never-attempted identities only."""
import ast
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'work'
def emit(name,source):
    ast.parse(source);p=W/name;assert not p.exists();p.write_text(source,encoding='utf-8')
def replace(source,old,new):
    assert old in source,old;return source.replace(old,new)

publisher=(W/'public_size_preservation.py').read_text()
publisher=replace(publisher,'def __init__(self,study,transfer):','def __init__(self,study,transfer,wait_seconds=600):')
publisher=replace(publisher,'self.known=set();self.offset=0;self.previous=digest(b\'\');self.number=0','self.known=set();self.offset=0;self.previous=digest(b\'\');self.number=0;self.wait_seconds=wait_seconds')
publisher=replace(publisher,'def publish(self,label,wait_seconds=120):','def publish(self,label,wait_seconds=None):\n        wait_seconds=self.wait_seconds if wait_seconds is None else wait_seconds')
emit('public_size_u61_preservation.py',publisher)

remote=(W/'run_public_size_screen_remote_20261010.py').read_text()
remote=replace(remote,'from public_size_preservation import','from public_size_u61_preservation import')
remote=replace(remote,"cases=json.loads((PREP/'cases.json').read_text());environment=", "selected_arm=json.loads((PREP/'selected_arm.json').read_text())['arm']\ncases=json.loads((PREP/'cases.json').read_text());environment=")
remote=replace(remote,"publisher=Publisher(STUDY,ROOT/'outputs/public_size_transfer')","publisher=Publisher(STUDY,ROOT/'outputs/public_size_transfer',protocol['ACK_seconds'])")
remote=replace(remote,"for declaration in protocol['models']:","for declaration in [m for m in protocol['models'] if m['arm']==selected_arm]:")
remote=replace(remote,"        initial=gate(model,observer,tokenizer,gate_case,'engineering_initial_prefill')", """        if arm=='public_0_5B':
            reference=json.loads((PREP/'old_public_0_5B_initial_gates.json').read_text())
            assert before==reference['before_state'],'New0.5B initialization differs from preserved public initial weights'
            with np.load(PREP/'old_public_0_5B_initial_logits.npz',allow_pickle=False) as old:initial=old['logits'].copy()
        else:initial=gate(model,observer,tokenizer,gate_case,'engineering_initial_prefill')""")
remote=replace(remote,"'actual_4bit_cuda_model':True,'before_state':before,'full_context_prefill_passed':True", "'actual_4bit_cuda_model':True,'before_state':before,'full_context_prefill_passed':arm!='public_0_5B','old_full_context_prefill_reused':arm=='public_0_5B'")
remote=replace(remote,"        for c in cases:\n            observer.set_phase", "        for c in [c for c in cases if c['observation_id'] in protocol['remaining_observation_ids_by_arm'][arm]]:\n            observer.set_phase")
remote=replace(remote,"assert status['actual_generation_returns']==62 and status['engineering_prefill_returns']==4", "assert status['actual_generation_returns']==len(protocol['remaining_observation_ids_by_arm'][selected_arm])\n    assert status['engineering_prefill_returns']==(1 if selected_arm=='public_0_5B' else 2)")
remote=replace(remote,"journal(STUDY/'events.jsonl',{'kind':'generation_attempt','arm':arm,'observation_id':c['observation_id']})", "journal(STUDY/'events.jsonl',{'kind':'generation_attempt','arm':arm,'observation_id':c['observation_id']})\n            atomic_json(STUDY/'progress.json',status)")
emit('run_public_size_u61_remote.py',remote)

guardian=(W/'public_size_screen_guardian.py').read_text().replace('from public_size_preservation import','from public_size_u61_preservation import').replace('run_public_size_screen_remote_20261010.py','run_public_size_u61_remote.py')
emit('public_size_u61_guardian.py',guardian)
environment=(W/'public_size_screen_environment_check.py').read_text().replace('from public_size_preservation import','from public_size_u61_preservation import')
environment=replace(environment,"for model in protocol['models']:","arm=json.loads((PREP/'selected_arm.json').read_text())['arm']\nfor model in [m for m in protocol['models'] if m['arm']==arm]:")
emit('public_size_u61_environment_check.py',environment)
setup=(W/'public_size_setup_remote.py').read_text().replace('public_size_screen_environment_check.py','public_size_u61_environment_check.py')
setup=replace(setup,"from_path=ROOT/'outputs'", "(ROOT/'prep/selected_arm.json').write_text(json.dumps({'arm':sys.argv[1]}))\nfrom_path=ROOT/'outputs'")
emit('public_size_u61_setup_remote.py',setup)

owner=(W/'run_public_size_screen_colab_20261010.py').read_text()
owner=replace(owner,'import ast,base64,hashlib,json,logging,os,time,uuid,zipfile','import argparse,ast,base64,hashlib,json,logging,os,time,uuid,zipfile')
owner=replace(owner,'from google_account_profile import verify_account','from google_account_profile import verify_account\nfrom public_size_local_preservation_v2 import preserve as safe_preserve,extended')
owner=replace(owner,"PREP=R/'public_size_production_preparation_v4';OUT=R/'public_size_execution'", "PREP=R/'public_size_u61_preparation'\nparser=argparse.ArgumentParser();parser.add_argument('--arm',required=True,choices=['public_0_5B','public_1_5B']);arm=parser.parse_args().arm\nOUT=extended(R/'public_size_u61_execution'/arm)")
start=owner.index('def preserve(path,raw):');end=owner.index('class BoundedSession',start)
owner=owner[:start]+"def preserve(path,raw):safe_preserve(path,raw,digest(raw))\n"+owner[end:]
owner=replace(owner,"protocol=read(PREP/'protocol.json');payload=read(PREP/'Cloud_Payload_Manifest.json');ready=read(PREP/'Launch_Readiness_Audit.json')", """protocol=read(PREP/'protocol.json');payload=read(PREP/'Cloud_Payload_Manifest.json');ready=read(PREP/'Launch_Readiness_Audit.json')
    profile=dict(protocol['profiles'][arm])
    profile['credential_path']={'public_0_5B':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud\\application_default_credentials.json',
      'public_1_5B':r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud-hiergrid-sheenah\\application_default_credentials.json'}[arm]""")
owner=owner.replace("protocol['selected_account']","profile['account']")
owner=replace(owner,"Credentials.from_authorized_user_file(r'C:\\Users\\HOME\\AppData\\Roaming\\gcloud\\application_default_credentials.json')","Credentials.from_authorized_user_file(profile['credential_path'])")
owner=owner.replace("'public_size_setup_remote.py'","'public_size_u61_setup_remote.py'")
owner=replace(owner,'''repr(setup)+"])\\n''', '''repr(setup)+","+repr(arm)+"])\\n''')
owner=owner.replace('work/public_size_screen_guardian.py','work/public_size_u61_guardian.py')
emit('run_public_size_u61_colab.py',owner)
print('ADDITIVE_U61_IMPLEMENTATIONS_CREATED')
