"""Additive control-only preparation; retains prior schema failures and all cases."""
from pathlib import Path
import json, hashlib

ROOT = Path(__file__).resolve().parents[1]
old = ROOT / 'work/prepare_public_size_production_v2_20261010.py'
source = old.read_text(encoding='utf-8')
source = source.replace("OUT=R/'public_size_production_preparation_v2'", "OUT=R/'public_size_production_preparation_v3'")
source = source.replace('import ast,collections,gzip,json,os,shutil,subprocess,sys,tempfile,zipfile',
    'import ast,collections,gzip,json,os,shutil,subprocess,sys,tempfile,zipfile\nimport candidate_process_runtime\nimport torch\nfrom candidate_process_diagnostics import priority')
source = source.replace("'continue_public_size_screen_audit_20261010.py',Path(__file__).name,'google_account_profile.py','candidate_process_runtime.py'",
    "'continue_public_size_screen_audit_20261010.py',Path(__file__).name,'google_account_profile.py','candidate_process_runtime.py','candidate_process_diagnostics.py','candidate_predictor_input_contract.py'")
source = source.replace('paid={}\n', '''paid={}
cache=B/'tensor_readiness_v2'
index={r['observation_id']:r for r in read(cache/'Input_Index.json')}
normal=read(cache/'Target_Normalization.json')
for p in [cache/'Input_Index.json',cache/'Target_Normalization.json']:
    binding[str(p.relative_to(ROOT)).replace('\\\\','/')]=sha(p)
allowed={}
for c in cases:
    row=index[c['observation_id']];p=cache/row['tensor_path'];assert sha(p)==row['tensor_sha256']
    binding[str(p.relative_to(ROOT)).replace('\\\\','/')]=sha(p)
    allowed[c['observation_id']]=torch.load(p,weights_only=True)['allowed_actions']
    actor=c['selected_same_information_input'];native=torch.zeros((118,9),dtype=torch.bool)
    for pool in actor['raw_common_and_zone_pools'].values():
        for bus in pool:
            for j,q in enumerate(actor['original_Q_grid']):native[bus,j]=actor['current_added_support_MVAr_by_bus'][bus]+q<=450
    assert torch.equal(allowed[c['observation_id']],native),'Native scope/cap mismatch'
''')
source = source.replace("    assert len(source)==311\n    for c in cases:", """    assert len(source)==311
    p=control_paths[name].parent/'final_epoch5_scores.pt';binding[str(p.relative_to(ROOT)).replace('\\\\','/')]=sha(p)
    scores=torch.load(p,weights_only=True);assert len(scores)==311 and set(scores)==set(source)
    for c in cases:""")
source = source.replace("        pair=r['recorded_label_priority_diagnostic']['model_first']", """        ordering=priority(scores[c['observation_id']],allowed[c['observation_id']],normal)
        pair=list(ordering[0]) if ordering else None
        diagnostic=r.get('recorded_label_priority_diagnostic')
        if diagnostic:assert pair==diagnostic['model_first']
        # The old labels are not required to decode already-preserved predictions.
""")
source = source.replace("'status':'preserved_final_epoch5_native_K1','ranking_complete':True", "'status':'preserved_final_epoch5_native_K1','original_label_status':r.get('status'),'decoded_from_saved_scores_without_new_model_call':True,'ranking_complete':True")
source = source.replace("    paid[name+'_original_invalid_row']=invalid_controls\npaid['native_affine", "paid['native_affine")
source = source.replace("write(OUT/'Local_Numerical_Control_References.json',controls)", """write(OUT/'Local_Numerical_Control_References.json',controls)
local_control_hash=sha(OUT/'Local_Numerical_Control_References.json')""")
source = source.replace("'local_analysis_source_hashes':binding,'remote_source_hashes':remote_hashes,", "'local_analysis_source_hashes':binding,'local_control_references_sha256':local_control_hash,'remote_source_hashes':remote_hashes,")
source = source.replace("for name,h in", "for name,h in")
# Preserve exact wrapper and original recipe as separately hashed implementation sources.
source = source.replace("for name in source_hashes:ast.parse", "source_hashes['work/prepare_public_size_production_v2_20261010.py']=sha(old)\nfor name in source_hashes:ast.parse")
exec(compile(source, str(Path(__file__)), 'exec'), {'__file__':str(Path(__file__).resolve()),'old':old})
