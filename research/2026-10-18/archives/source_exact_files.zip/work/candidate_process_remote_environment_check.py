"""Pinned public-base cache/versions; no model inference or private export API."""
from pathlib import Path
import hashlib,json,os,importlib.metadata as md
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
os.environ.update(HF_HOME=str(ROOT/'cache/huggingface'),HF_HUB_DISABLE_IMPLICIT_TOKEN='1',HF_HUB_DISABLE_TELEMETRY='1')
import torch
from huggingface_hub import snapshot_download
PREP=ROOT/'outputs/llm_value_candidate_development_20261009/copied_body_integration_preparation'
expected=json.loads((PREP/'Expected_Environment.json').read_text())
config=json.loads((ROOT/'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1/adapter_config.json').read_text())
assert torch.cuda.is_available() and torch.cuda.get_device_name(0)=='Tesla T4'
snapshot=Path(snapshot_download(config['base_model_name_or_path'],revision=expected['base_revision_verified']))
assert hashlib.sha256((snapshot/'model.safetensors').read_bytes()).hexdigest()==expected['base_weight_sha256']
versions={n:md.version(n) for n in expected['versions']};assert versions==expected['versions']
report={**expected,'versions':versions}
(ROOT/'outputs/remote_frozen_environment.json').write_text(json.dumps(report,indent=2))
print('PINNED_PUBLIC_BASE_CACHED_AND_ENVIRONMENT_VERIFIED_NO_MODEL_FORWARD')
