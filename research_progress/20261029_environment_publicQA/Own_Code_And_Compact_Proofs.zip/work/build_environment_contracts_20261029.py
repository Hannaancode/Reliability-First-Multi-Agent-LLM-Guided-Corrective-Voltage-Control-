"""Saved-source-only environment inventory. Never import an experimental worker."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import ast, hashlib, json

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/environment_contracts_20261029'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert not O.exists()
    sources = {
        'rag_paper': 'outputs/thesis_expanded_20261028/rag_manuscript.txt',
        'rag_solver': 'C:/Users/HOME/Downloads/pf_assist.py',
        'original_controller': 'work/e/audit/run_reflection_v4_safety_envelope.py',
        'original_initial_solver': 'work/e/pack/scripts/phase2d_iterative_blackboard_v0.py',
        'original_action_solver': 'work/e/audit/phase2g_multiagent_llm_runner.py',
        'original_guard': 'work/e/audit/phase2g_rescue_runner.py',
        'original_roots': 'outputs/registered_severe_federation_root_binding_20261022/All4_Registered_Solved_Root_Bindings.json',
        'original_results': 'outputs/original118_closed_comparison_20261028/Comparison.json',
        'saved_dse': 'outputs/original118_saved_dse_reconciliation_20261028/Comparison.json',
        'graph_protocol': 'outputs/graph118_native_campaign_preparation_20261028/Protocol.json',
        'graph_engine': 'work/published_graph118_episode_engine_v2_20261026.py',
        'graph_result': 'outputs/graph118_native_context_comparison_rng_v2_20261028/Comparison.json',
        'public13_env': 'outputs/stable_ddpg_author_intake_20261020/author_reference/env_single_phase_13bus.py',
        'public13_policy_loop': 'work/run_public13_remaining_published_cohort_20261021.py',
        'public13_protocol': 'outputs/public13_matched_numeric_preparation_20261021/Protocol.json',
        'public13_numeric': 'work/public13_matched_numeric_engine_20261021.py',
        'tpa_protocol': 'outputs/tpa_native_second_identity_preparation_20261020/Execution_Protocol.json',
        'tpa_result': 'outputs/tpa_native_second_identity_engineering_20261020/Result.json',
        'numeric322': 'work/run_native_inverter_linear_reference_20261020.py',
        'numeric322_math': 'work/native_inverter_linear_reference_core_20261020.py',
        'numeric322_result': 'outputs/native_inverter_linear_reference_20261020/Result.json',
    }
    records = {}
    for name, rel in sources.items():
        p = Path(rel) if Path(rel).is_absolute() else R / rel
        data = p.read_text('utf-8-sig')
        record = {'path': rel, 'sha256': sha(p), 'bytes': p.stat().st_size}
        if p.suffix == '.py':
            tree = ast.parse(data)
            record['functions'] = [{'name': n.name, 'line': n.lineno, 'end_line': n.end_lineno}
                                   for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
        records[name] = record
    rows = []
    def row(id, **kwargs):
        rows.append({'id': id, **kwargs})
    rag_common = dict(
        actions='Manuscript figures describe multiplying demand by 0.9. Supplied solver also supports line/gen outages, taps, shunts and dispatch edits; these are capabilities, not established figure settings.',
        solver='Manuscript describes balanced Newton–Raphson. Supplied pf_assist.py defaults to dc_ac with DC initialization and a sequential NR/fast-decoupled fallback stack, varying iteration limits and a final 1e-5 tolerance. Exact historical figure branch is UNKNOWN.',
        guard='Supplied LimitConfig defaults .95/1.061, GuardConfig.enable=True, max_loops=12, Qstep=15 Mvar, Qcap=150 Mvar, slack target1.03 and generator-Q widening500. solve_pf passes request limits to the guard. Actual historical figure overrides are UNKNOWN.',
        stopping='One requested tool workflow with bounded internal guard loops; not the original four-zone25-operation controller.',
        information='RAG question/context and a structured tool request. Exact figure prompt, retrieval index revision, complete request and solved NET chain are UNKNOWN.',
        evidence_level='MANUSCRIPT_REPORTED_DEMONSTRATION_AND_SEPARATELY_INSPECTED_SOURCE_NOT_EXECUTION_BOUND',
        partition='Historical demonstration, inspected; no unused confirmation claim.',
        source_ids=['rag_paper', 'rag_solver'])
    row('RAG14', plant='IEEE14 balanced demonstration', disturbance='Baseline operating point; caption reports 10% uniform load derating, not a severe line-outage cohort.',
        observed='Figure5 minimum0.982→0.986 p.u.; stated minima already exceed .95. Body says approximately.04 p.u. margin, whereas displayed minimum change is .004. The inconsistency remains unresolved.', **rag_common)
    row('RAG118', plant='IEEE118 balanced demonstration', disturbance='Baseline operating point and10% demand derating described in Figure4; no identity with federation roots established.',
        observed='Minimum0.966→0.971 p.u. reported. This is margin improvement from a minimum already above .95, not evidence of removing55–58 strict UV buses.', **rag_common)
    row('FED118', plant='Frozen IEEE118 four-microgrid federation; all four registered load1.5 roots with lines35/36/84/127 out',
        disturbance='Initial strict UV56/58/57/55 on the exact four saved roots; inspected development.',
        actions='Positive capacitive added-shunt recipient/Q commands; exact menu25,50,75,100,125,150,200,250,300 Mvar. Rescue cap450 Mvar applies to named llm_shunt additions per bus, not all pre-existing shunts or a global budget. DFF, original HG-VF and offline HG-SE retain original policies.',
        solver='Initial native function uses NR/auto/enforceQ/max50; action native function uses NR/auto/enforceQ/max80/calculate_voltage_angles=True. Paid reuse requires the exact solver-input contract, not merely equal aggregate shunt Q.',
        guard='Original hard upper1.06 and source acceptance rules; endpoint counts separately use strict UV<.95 and OV>1.05. Admission by the native guard does not certify the stricter reporting band or all network limits.',
        stopping='Original chronological four-zone control with maximum25 total operations and native early stops. HG-SE selects offline between completed DFF/HG-VF; numerical D-SE selects DFF/DFF-ALT separately.',
        information='Original trained0.5B LoRA receives source-local current context, candidates and feedback. Numerical fallback/guidance/search and verifier information are preserved and charged.',
        observed='DFF51UV/11OV; HG-VF26/11; offlineHG-SE20/12. Saved stronger numericalD-SE35/12 has older committed-state audit depth. UV gains have adverse cases and remaining OV.',
        partition='Four inspected development roots; neither a new holdout nor complete later137-case paper reconstruction.',
        evidence_level='CLOSED_INDEPENDENT_FOUR_ROOT_COMPARISON_WITH_EXPLICIT_OLDER_DSE_AUDIT_LIMITS',
        source_ids=['original_controller','original_initial_solver','original_action_solver','original_guard','original_roots','original_results','saved_dse'])
    row('GRAPH118', plant='Same four exact federation118 root NETs, native external GraphAgent role',
        disturbance='Identical four root disturbances to FED118.',
        actions='Source-native generator/slack voltage setpoints and existing binary shunt controls, not HierGrid positive added-shunt commands. GraphAgent is an author numerical comparison agent, not the trained DQN.',
        solver='Pinned pandapower port: NR/auto/enforce_q_lims=True/max_iteration80/calculate_voltage_angles=True.',
        guard='Source-native policy/control and terminal solver behaviour; the source external role is not silently wrapped in the original HierGrid action restrictions. Strict all118 .95–1.05 outcomes retained separately.',
        stopping='Source-native maximum136 operations; terminal nonconvergence retained. This differs from25 operations in FED118.',
        information='Source GraphAgent graph/device state through the documented PowerWorld-to-pandapower backend port. No learned external DQN or LLM inference.',
        observed='All four native episodes terminate in nonconvergence after19/21/21/21 operations; final UV/OV UNKNOWN. This is not a certified infeasibility result or an equal-resource win.',
        partition='Same inspected development roots; no unused confirmation.',
        evidence_level='CLOSED_NATIVE_ROLE_COMPARISON_DIFFERENT_ACTUATORS_HORIZON_AND_BACKEND',
        source_ids=['graph_protocol','graph_engine','graph_result'])
    row('PUBLIC13', plant='Author public13 distribution system; all500 exact common solved roots seeds0..499',
        disturbance='Author randomized voltage-control initial states:232UV-only,251OV-only,17already within reporting band. No federation line-outage equivalence.',
        actions='Three native sgen Q assignments at buses2/7/9, source policy updates last minus float32-clipped output at magnitude.3 per decision; bidirectional reactive action. Not a25Mvar minimum added-shunt role.',
        solver='Author step_Preward uses pandapower BFSW with init=dc; our numerical branch uses the same native plant transition.',
        guard='Published source actors retain native protection. NUM protects currently normal buses within .95−1e-8..1.05+1e-8 and rejects global count regressions; first rejection hold-stops. Saved common-guard adapters are secondary, not replacements for primary native methods.',
        stopping='Native actors stop when ONLY3controlled buses strictly satisfy .95<VM<1.05 or at100 rounds. Common endpoint checks all13 buses with .95<=VM<=1.05. NUM retains100round bound and its fixed guard.',
        information='Published safeDDPG/linear/DDPG actors use one local VM each. NUM uses full13VM/currentY and two LP stages. Identical cases, actuators and horizon do not imply identical information or costs.',
        observed='Whole13-band endpoints:NUM264/500;safeDDPG262;linear258;DDPG363. NUM fixed gateFAIL. No original-paper LLM comparison is established by these numerical scores.',
        partition='Source replication/development; all500 inspected. Source-training identity overlap remains unestablished, not presumed absent. Any later router evaluation has a separate prospective protocol/cohort and cannot erase this result.',
        evidence_level='COMPLETE_ALL500_SAME_ROOT_NATIVE_COMPARISON_INFORMATION_AND_GUARD_DIFFERENCES_DISCLOSED',
        source_ids=['public13_env','public13_policy_loop','public13_protocol','public13_numeric'])
    row('MAPDN322', plant='Author case322_3min_final; second ordered identity20Jan2013 day385 index185262,38PV inverters',
        disturbance='Native time-series/initialization identity, initial108UV/0OV; first ordered identity remains partial after a runtime failure. No arbitrary selection of a winning timestamp.',
        actions='Absolute signed inverterQ = fraction×sqrt(Smax²−P²), fraction[-.8,.8], Smax=1.2×native all-pool columnPmax. Both compared one-step actions share these capabilities.',
        solver='Native action calls pp.runpp(net) with default arguments on the recorded modern compatibility runtime; not silently equated with an explicit federation or13bus solver contract.',
        guard='Native .95/1.05 reporting. Numerical LP includes upper1.05 and native inverter capability bounds; physical post-action state checked. Voltage-band evidence is not all-limit feasibility.',
        stopping='ONE measured action per method. A configured480-step episode and120author identities were not executed as a full benchmark. Earlier first-identity failure retained.',
        information='TPA has distributed current/history/seasonal inputs. Our numerical method has full currentY and solved operating point. Historical all-pool maxima and seasonal preprocessing prevent assuming a strictly causal fresh holdout.',
        observed='Same108UV root→TPA77UV/0OV and current-Jacobian numerical0UV/0OV. Independently checked one-step engineering, not LLM benefit or full-cohort superiority.',
        partition='Single engineering identity with inspected inputs; full120 includes conditioning-year overlap and is not unused confirmation.',
        evidence_level='ONE_STEP_ENGINEERING_TWO_METHODS_DIFFERENT_INFORMATION_FIRST_IDENTITY_PARTIAL_RETAINED',
        source_ids=['tpa_protocol','tpa_result','numeric322','numeric322_math','numeric322_result'])
    record = {'status':'SAVED_SOURCE_INVENTORY_AWAITING_SEPARATE_CHECK','at_utc':datetime.now(timezone.utc).isoformat(),
              'sources':records,'environments':rows,'new_model_PF_training_optimizer_GPU_calls':0,
              'rag14_exact_minimum_difference':str(Decimal('.986')-Decimal('.982')),
              'rag_figure_runtime_binding':'UNKNOWN','source_presence_is_not_execution_proof':True,
              'all_six_research_goals':'OPEN'}
    O.mkdir()
    (O/'Environment_Contracts.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n','utf-8')
    lines=['# Experimental environment and comparison contracts','',
           'Saved records and source inspection only. No scientific call was repeated. Source availability is distinguished from a demonstrated historical execution.','']
    for row in rows:
        lines.extend(['## '+row['id']+' '+row['plant'],''])
        for k,v in row.items():
            if k not in ('id','plant','source_ids'):lines.extend([k.replace('_',' ').capitalize()+': '+v,''])
        lines.extend(['Source records: '+', '.join(row['source_ids']), ''])
    (O/'Environment_Contracts.md').write_text('\n'.join(lines),'utf-8')
    print(json.dumps({'output':str(O),'environments':len(rows),'sources':len(records),'new_science':0}))

if __name__=='__main__':main()
