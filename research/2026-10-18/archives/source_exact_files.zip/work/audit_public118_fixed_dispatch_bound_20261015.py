"""Independent exact-decimal parser checks all three scoped dispatch bounds."""
import hashlib,json,os,re,time
from decimal import Decimal
from pathlib import Path
R=Path(__file__).resolve().parents[1];B=R/'outputs/public118_raw_fixed_dispatch_bound_20261015';O=B/'independent_audit'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    O.mkdir(exist_ok=False);started=time.perf_counter()
    evidence=json.loads((B/'Necessary_Condition_Certificate.json').read_text());rows=[]
    for recorded in evidence['all3']:
        path=R/recorded['case'];assert sha(path)==recorded['raw_sha256'];raw=path.read_text('utf-8-sig')
        clean='\n'.join(line.partition('%')[0] for line in raw.splitlines());tables={}
        for name in ('bus','gen','branch'):
            body=re.search(r'\bmpc\.'+name+r'\s*=\s*\[(.*?)\]\s*;',clean,re.S).group(1)
            tables[name]=[[Decimal(token) for token in row.split()] for row in body.split(';') if row.strip()]
        bus=tables['bus'];gen=[g for g in tables['gen'] if g[7]>0];branch=[b for b in tables['branch'] if b[10]>0]
        ref={int(b[0]) for b in bus if b[1]==3};demand=sum(b[2] for b in bus)
        fixed=sum(g[1] for g in gen if int(g[0]) not in ref);maximum=sum(g[8] for g in gen if int(g[0]) in ref)
        assert len(ref)==1 and any(int(g[0]) in ref for g in gen) and all(b[4]>=0 for b in bus) and all(b[2]>=0 for b in branch)
        exact=demand-fixed-maximum
        for field,value in [('raw_net_demand_MW',demand),('fixed_online_nonslack_Pg_MW',fixed),('maximum_online_reference_Pg_MW',maximum),('shortfall_even_before_nonnegative_losses_MW',exact)]:
            assert abs(Decimal(recorded[field])-value)<=Decimal(recorded['numeric_margin_allowance_MW'])
        assert exact>Decimal('0.000001') and recorded['fixed_raw_PF_all_gen_Pmax_compliance']=='ANALYTICALLY_EXCLUDED_UNDER_STATED_ROLE'
        rows.append({'case':recorded['case'],'exact_decimal_necessary_generation_shortfall_MW':str(exact),'scoped_bound':'PASS_EXACT_SOURCE_ARITHMETIC'})
    result={'status':'PASS_ALL3_INDEPENDENT_EXACT_DECIMAL_SOURCE_POWER_BOUNDS','all3':rows,
        'scope':'RAW specified nonslack dispatch and native generatorPmax only; general OPF/grid/model/voltage/thermal feasibility UNKNOWN.',
        'new_PF_OPF_model_converter_forecast_solve_calls':0,'workflow_seconds':time.perf_counter()-started,'source_sha256':sha(Path(__file__))}
    with (O/'Independent_Source_Bound_Audit.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'all3_independent_source_power_bound':'PASS','new_PF_model_calls':0}))
if __name__=='__main__':main()
