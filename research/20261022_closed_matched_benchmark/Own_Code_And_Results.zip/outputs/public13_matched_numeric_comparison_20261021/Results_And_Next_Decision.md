# Same-case numerical and published-controller comparison

Status: COMPLETE_SAME500_PHYSICAL_NUMERICAL_VS_PUBLISHED_COMPARISON
Fixed gate: FAIL_FIXED_NUMERICAL_PRIMARY_SUPERIORITY_GATE_NO_RETUNING

All500registered physical starting states, native three actuators and100round maximum. Voltage-band primary score uses every13bus.

| Controller | Full13band cases | Residual UV | Residual OV |
|---|---:|---:|---:|
| Our fixed numerical controller | 264/500 | 765 | 5 |
| Published safe-ddpg | 262/500 | 0 | 324 |
| Published linear | 258/500 | 0 | 345 |
| Published ddpg | 363/500 | 59 | 121 |

Our numerical controller uses global13bus measurements/currentY; published actors consume local voltages. Their unmodified rows remain primary references, and separately named common-guard prefix adapters are sensitivity rows. This is not an LLM/original-paper full-system score or equal-information attribution.

All strict near-boundary failures, adverse cases, source exceptions and unknowns are retained. The original numerical method, guard and score were fixed before its outcomes. No result-driven retuning is authorized.
