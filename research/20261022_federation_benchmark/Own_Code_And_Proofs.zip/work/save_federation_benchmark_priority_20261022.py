"""Save the human's federation-first benchmark decision and actual evidence.

No model/simulator imports or automatic job launch.
"""
import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/federation_matched_benchmark_20261022'
P = O / 'publication'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(p, value):
    with p.open('w', encoding='utf-8', newline='') as f:
        if isinstance(value, str):
            f.write(value)
        else:
            json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())


def main():
    at = datetime.now(timezone.utc).isoformat()
    P.mkdir(exist_ok=False)
    result = json.loads((R / 'outputs/reflection_v4_federation_reconciliation_v3_20261022/Reconciliation.json').read_text('utf-8'))
    audit = json.loads((R / 'outputs/reflection_v4_federation_reconciliation_v3_20261022/Independent_Saved_Summary_Audit.json').read_text('utf-8'))
    assert audit['status'].startswith('PASS')
    ready = json.loads((O / 'Software_Admission_Readiness.json').read_text('utf-8'))
    assert ready['pending_raw_roots_rejected_before_execution'] == 203
    resources = sorted((R / 'outputs/resource_checks').glob('20261022_*.json'))
    resource_path = resources[-1]
    access = json.loads(resource_path.read_text('utf-8'))
    assert all(v['check_succeeded'] and v['active_assignment_count'] == 0 for v in access['profiles'].values())
    literature = {
        'at_utc': at, 'status': 'PRIMARY_SOURCE_118_CONTROLLER_DISCOVERY_NOT_EXECUTED_BENCHMARK',
        'same_bus_count_does_not_establish_same_network_or_task': True,
        'original_plant': {'source': 'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json',
                           'description': 'pandapower case118 transmission network, four index-based zones; capacitive shunt-addition corrective UV task'},
        'methods': [
            {'id': 'B6', 'method': 'SPARQ', 'publication': 'IEEE Access13,43830–43842,2025',
             'DOI': '10.1109/ACCESS.2025.3548517',
             'author_primary_fulltext': 'https://katedavis.engr.tamu.edu/wp-content/uploads/sites/180/2025/04/SPARQ_A_Cyber-Resilient_Voltage_Regulation_Using_Soft_Q-Learning_Approach_for_Autonomous_Grid_Operations.pdf',
             'reported_networks': ['14', 'reduced118', '118'],
             'source_review': 'Author-hosted full paper read; Algorithm1 soft-Q/replay/target-network procedure and Grid2Op six-feature observation specification recovered. Exact action catalog/environment IDs, executed checkpoint and authentic complete code are not certified.',
             'federation_comparison': 'UNKNOWN_NOT_BEATEN; needs source-compatible plant/action adaptation and real trained artifact',
             'publisher_verification_challenge': 'IEEE page requested browser challenge; author-hosted open copy read, no challenge bypass'},
            {'id': 'B7', 'method': 'AE-HMATD3', 'publication': 'IET Smart Grid,2026,e70107',
             'DOI': '10.1049/stg2.70107',
             'primary_source': 'https://ietresearch.onlinelibrary.wiley.com/doi/10.1049/stg2.70107',
             'reported_networks': ['33bus distribution', '118bus distribution at11kV'],
             'source_review': 'Two-timescale inverter/SVC/switched-capacitor coordination. The118 network is a distribution system, not automatically the original case118 transmission federation. Author data availability is upon reasonable request; no certified public checkpoint/code intake yet.',
             'federation_comparison': 'UNKNOWN_NOT_BEATEN; native mixed-device/time-scale action domain differs'},
            {'id': 'B8', 'method': 'MG-ASTGCN plus DDPG', 'publication': 'Author arXiv manuscript2401.15848v1,2024; peer-review status not newly certified',
             'primary_source': 'https://arxiv.org/html/2401.15848v1',
             'reported_networks': ['modified33radial', 'modified69radial', 'modified118radial'],
             'source_review': 'Spatial-temporal generation/voltage control with renewable-accommodation objective and hourly trajectories. Actual released code/checkpoint availability not established by the inspected manuscript.',
             'federation_comparison': 'UNKNOWN_NOT_BEATEN; not identical static corrective-shunt task'}],
        'existing_source_families_retained': ['MAPDN/TPA', 'PowerGym', 'Stable-DDPG/linear/DDPG', 'online-topology', 'OptDisPro', 'other named LLM candidates'],
        'no_unavailable_method_scored_as_defeated': True,
        'new_model_PF_training_optimizer_solver_GPU_calls': 0}
    save(O / 'Published118_Method_Registry_Addendum.json', literature)
    next_steps = [
        {'id': 'F118.1', 'status': 'COMPLETE_SAVED_SUMMARY_ONLY', 'task': 'Recover actual Reflection-v4 source and independently reconcile67 saved cases and134 candidate branch summaries; preserve missing deficits and70 missing cases.'},
        {'id': 'F118.2', 'status': 'COMPLETE_REPORTED_TABLE_RECHECK', 'task': 'Verify final manuscript Table9:137cases,2715initialUV,DFF290/HGVF291/HGSE193. Keep61/67/5case tables distinct; do not assert193 is the best ever.'},
        {'id': 'F118.3', 'status': 'COMPLETE_SOURCE_DISCOVERY_ONLY', 'task': 'Register relevant published118 studies and authentic data/code/weights/action gaps; unavailable methods remainUNKNOWN.'},
        {'id': 'F118.4', 'status': 'SOFTWARE_COMPLETE_EVIDENCE_BINDING_PENDING', 'task': 'Common-case gate passes25 labelled boundaries and rejects all203 unresolved solved-root registrations before execution. Bind exact paid physical roots/cursors rather than repeating initialization.'},
        {'id': 'F118.5', 'status': 'PENDING', 'task': 'Select source-compatible external adaptation(s), pin source/code/checkpoint/training split/objective/budget before outcomes. Unchanged foreign-grid weights cannot substitute for trained118 adaptation.'},
        {'id': 'F118.6', 'status': 'PENDING', 'task': 'Complete original full Reflection-v4 and adapted-baseline actual loader/context/parser/cold preservation, persistent receipt/cost/RNG cursor, ownership and independent partial-aware continuous reader.'},
        {'id': 'F118.7', 'status': 'PENDING_NOT_READY_TO_ALLOCATE', 'task': 'Once gates pass, execute prospective common118 campaign. Separate GPU workers for independent real model arms; CPU workers for independent cases, never split one stateful policy bank across uncontrolled workers. Same roots/order/information/legal actions/protection/horizon, all failures and full costs.'},
        {'id': 'F118.8', 'status': 'PENDING', 'task': 'Full registered denominators, paired per-root uncertainty, all wins/ties/losses and independent unused confirmation before a superiority claim.'}]
    protocol = {
        'at_utc': at, 'status': 'PROSPECTIVE_COMMON118_DESIGN_NOT_A_LAUNCH_LOCK',
        'human_priority': 'Original-paper/full Reflection-v4/new-controller/external published methods on identical federation cases first; assess superiority honestly.',
        'case_scope': 'All141 existing federation recipes plus a separately reported sealed62 cohort; no outcome-selected hard-case subset. Original137 historical membership scaffold is separately retained.',
        'registration_source': 'outputs/full_system_comparison_20261021/All203_Existing_Federation_Input_Cases.json',
        'case_binding': 'Require full solved physical-root/input/solver digest, not recipe name/seed/UV/bus-count alone. Reuse existing paid exact returns; unresolved/lost historical bytes stayUNKNOWN.',
        'native_fidelity_track': 'Original unmodified Reflection-v4/DFF/DFFALT/unchanged selector and original native1.06hard protection, all118UV/OV and effort reported. Preserve frozen source/weights; no new result claimed from old summaries.',
        'common_protection_track': 'Any normal-upper1.05+1e-8 guard adaptation is named and identical for all methods; never modify original native source or relabel a wrapper as exact historical replication.',
        'common_actuation': 'Native positive shunt additions25/50/75/100/125/150/200/250/300Mvar, original bus/zone/candidate masks,450Mvar cumulative perbus, original25-operation horizon. No granting a competitor taps/load-shedding/redispatch while limiting ours to shunts, or the reverse.',
        'information': 'Same causally available measurements/history/query returns; no teacher/successor/unqueried labels. Report local/global consumption and strong same-information trained numerical controls explicitly.',
        'required_own_arms': ['DFF', 'DFF-ALT', 'D-SE literal selector', 'HG-VF actual trained original role', 'HG-SE actual Reflection-v4', 'new hybrid/numerical component under separately frozen complete policy'],
        'external_models': 'Authentic runnable published native model only when compatible; otherwise explicitly named reimplementation/retraining on common task with source fidelity/training costs and validation before test. No random or malformed model as a straw comparator.',
        'primary_outcome': 'All-bus normal-band restoration; UV-only restoration separately, plus all118UV/OV/deficit/extremeVm/whole-trajectory safety/effort/cost. Do not round strict boundary failures into success.',
        'costs': 'Full BOTH branches per portfolio, actual model/token/load/training/preparation/numerical/query/PF/replay/failure/storage time/memory; no free teacher/oracle or unmeasured solver-speed claim.',
        'prospective_controls': 'Source/input/assignment/PID/parent/claim exact; closed manifests and fsynced checkpoints; no duplicates/restarts/scientific retries/old bound extension/outcome sweeps.',
        'GPU_plan': 'Three authenticated profiles eligibleT4, current allocations0. Allocate only actual admitted model workloads; availability/hours/reset unknown. Independent jobs do not pool VRAM. No fallback after denial.',
        'tasks': next_steps, 'full_benchmark_or_superiority_ready': False,
        'no_new_science_this_preparation': True,
        'secondary_pending_public13': '441unfinished method-cases remain preserved; no previous worker/reader/budget restarted.'}
    save(O / 'Federation_First_Execution_Design.json', protocol)
    save(O / 'Current_Resume.json', {'at_utc': at, 'status': 'FEDERATION_PRIORITY_RECHECK_AND_ADMISSION_COMPLETE_PERFORMANCE_PENDING',
        'all6goals': 'OPEN', 'current_owner': None, 'GPU_assignments': 0, 'timers': [], 'tasks': next_steps,
        'latest_actual_v4_saved_summary_audit': 'outputs/reflection_v4_federation_reconciliation_v3_20261022/Independent_Saved_Summary_Audit.json',
        'latest_GPU_read_only_snapshot': str(resource_path.relative_to(R)), 'new_scientific_calls': 0,
        'original_full137_raw_join': 'UNKNOWN', 'matched_external_118_results': 'NOT_EXECUTED',
        'no_false_promise_to_beat_every_published_method': True})
    save(O / 'Three_Profile_Current_Read_Only_Access.json', access)
    note = f'''## Federation benchmark priority and actual Reflection-v4 recheck — {at}

Latest human request prioritizes a same-case federation comparison of the original paper system, actual Reflection-v4, new hybrid and relevant external methods. A larger118-bus system does not alone prove greater control difficulty or superiority to13-bus methods. Published118 studies were found: SPARQ(transmission/Grid2Op role), AE-HMATD3(11kV distribution) and MG-ASTGCN/DDPG(modified radial feeder). Exact source/weights/actuator compatibility remains a gate; none is counted beaten.

Rechecked supplied final paper Table9: all137cases begin at2,715UV; DFF290residual/108zeroUV, HG-VF291/103, HG-SE193/110.193 is best within this final table, not certified best across all historical experiments. Older28/61 and27/5 totals are different cohorts. Actual source d4b329413c91a64828ced63a0554d67e4f70d46726fc8c3ba3556d8714d9e81e was recovered: complete DFF plus trained-LLM reflection_v2 trajectory and unchanged selector.

New saved-summary reconciliation plus separate Decimal reader PASS on67cases/134branches:1,034initialUV; DFF32,HG-VF29,HG-SE19;3strictUVwins/64ties/0losses versusDFF;63/59/64zeroUVcases. All72,313recorded candidate tests across both branches remain charged; selected-only tests are not full cost. Four candidate deficit fields(two selected records) are missing and stayUNKNOWN. Exact CSV float assertion and missing-field analysis failures are preserved; additive analysis changed only storage-field handling, max raw delta2e-16, no physics or source/selector threshold changed.70remaining cases and full137rawtrajectory join remainUNKNOWN. No PF/model/scientific replay was repeated.

Implemented same-case admission boundary:25labelled synthetic boundary checks passed; all203actual registered recipe hashes verified, and all203PENDING root bindings rejected before performance. This is software readiness, not evidence that all roots are absent elsewhere or physical superiority. Exact paid solved-root/cursor reuse and compatible external controller/actual loader/persistent reader are next. New design and stable F118task sequence saved.

Three authorized Colab profiles authenticate and reportT4eligible/0activeassignments; no GPU allocated and no model/PF/training launched by this recheck. Fixed native13/scale failures and partial128results remain preserved; no old experiment restarted. All six final goals OPEN. No current job or waiting timer. Source/code/result publication is compact proof backup, not private rawweights/NET backup.
'''
    save(O / 'Research_Progress_Entry.md', note)
    with (R / 'reseacrh progress.txt').open('a', encoding='utf-8') as f:
        f.write('\n' + note + '\n')
        f.flush(); os.fsync(f.fileno())
    header = f'''## Federation comparison priority; actual Reflection-v4 reconciled — {at}

Latest direct human priority: compare original full paper/actualReflection-v4/newhybrid/external methods on identical118federation cases. Latest saved67/134branch summary audit PASS: DFF32/HGVF29/HGSE19 residualUV,3wins/64ties/0losses. Native primary paper137reported290/291/193 preserved; full137rawjoin and70missingv4records UNKNOWN, no lower cross-cohort totals relabelled. Four missing branch deficits retainedUNKNOWN. No new model/PF/training/GPU. Allthreeprofiles freshlyauthenticated/T4eligible/zeroassignments; no currentowner/timer.

Read outputs/federation_matched_benchmark_20261022/Current_Resume.json and Federation_First_Execution_Design.json next. Software25boundarychecks/all203recipehashesPASS; unresolved exact roots rejected, not permission to rerun old physics. Next substantive work: bind existing paid exact solvedroots/cursors and source-compatible external adaptations/actual original-role loader/persistent continuous reader before one prospective physical campaign. FullBOTH/native-vs-common safety/source/ownership/fullcost/unknown/unusedconfirmation gates unchanged. Previous441unfinishedpublic13identities remain preserved as secondary work, no old restart or bound extension. AllsixgoalsOPEN. No automatic GPU allocation or winning promise.

'''
    for rel in ['outputs/Unattended_Execution_Runbook.md', 'outputs/llm_value_development/Next_Phase_Plan.md', 'RESEARCH_TASKS.md']:
        p = R / rel
        save(p, header + p.read_text(encoding='utf-8'))
    rp = R / 'outputs/full_system_comparison_20261021/Current_Resume.json'
    resume = json.loads(rp.read_text('utf-8'))
    resume.update(at_utc=at, status='FEDERATION_PRIORITY_RECHECK_AND_ADMISSION_COMPLETE_PERFORMANCE_PENDING',
                  human_scope=protocol['human_priority'], next_dependency='Bind existing exact paid federation roots/cursors and source-compatible external adaptation/actual original-role model/persistent-reader gates.',
                  next_ordered_tasks=[v['task'] for v in next_steps if v['status'].startswith('PENDING') or v['id'] == 'F118.4'],
                  federation_priority_resume='outputs/federation_matched_benchmark_20261022/Current_Resume.json',
                  current_single_scientific_owner=None, current_GPU='All3profiles authenticated/T4eligible; zero assignments; no ready allocation', timers=[])
    save(rp, resume)
    tp = R / 'outputs/research_tasks_20261014/Tasks.json'
    tasks = json.loads(tp.read_text('utf-8'))
    goal = next(t for t in tasks['tasks'] if t['checklist_id'] == 'G3')
    goal.update(status=resume['status'], current_result='Actual historicalv4 saved67summary independentlychecked32/29/19; complete new118externalcomparison pending. All203unresolvedphysicalrootregistrations correctlyblocked.',
                next=resume['next_dependency'])
    for id_, desc, evidence in [
        ('G3.F118.1', 'Recover actualReflection-v4 and separately reconcile67saved/134branch summaries and unchanged selector.', 'outputs/reflection_v4_federation_reconciliation_v3_20261022/Independent_Saved_Summary_Audit.json'),
        ('G3.F118.2', 'Implement common-case admission gates and check all203registered recipe hashes; performance remains blocked on exact roots/compatible methods.', 'outputs/federation_matched_benchmark_20261022/Software_Admission_Readiness.json')]:
        assert id_ not in [t['id'] for t in goal['subtasks']]
        goal['subtasks'].append({'id': id_, 'completed': True, 'description': desc, 'evidence': evidence, 'verified_at_save': at})
    tasks.update(updated_at_utc=at, latest_exact_execution_state='outputs/federation_matched_benchmark_20261022/Current_Resume.json',
                 latest_human_instruction=protocol['human_priority'])
    save(tp, tasks)
    # Compact own sources/generated proofs only. Do not package notebooks,
    # original private weights, physical NETs or third-party source archives.
    own = [R / 'work' / name for name in [
        'reconcile_actual_reflection_v4_20261022.py', 'reconcile_actual_reflection_v4_v2_20261022.py',
        'reconcile_actual_reflection_v4_v3_20261022.py', 'audit_reflection_v4_saved_summary_20261022.py',
        'federation_benchmark_admission_20261022.py', 'prepare_federation_benchmark_admission_20261022.py',
        'save_federation_benchmark_priority_20261022.py', 'typed_state_cas_codec_20261022.py', 'test_typed_state_cas_codec_20261022.py']]
    for folder in ['reflection_v4_federation_reconciliation_20261022', 'reflection_v4_federation_reconciliation_v2_20261022', 'reflection_v4_federation_reconciliation_v3_20261022', 'fresh128_terminal_partial_handoff_20261022', 'typed_state_cas_engineering_v2_20261022']:
        own += [p for p in (R / 'outputs' / folder).glob('*') if p.is_file() and p.suffix in ['.json', '.md']]
    own += [p for p in O.glob('*') if p.is_file() and p.suffix in ['.json', '.md']]
    own = sorted(set(own))
    with zipfile.ZipFile(P / 'Own_Code_And_Proofs.zip', 'x', zipfile.ZIP_DEFLATED) as z:
        for p in own:
            z.write(p, str(p.relative_to(R)).replace('\\', '/'))
    with zipfile.ZipFile(P / 'Own_Code_And_Proofs.zip') as z:
        assert z.testzip() is None
        cert = [{'path': n, 'bytes': len(z.read(n)), 'sha256': hashlib.sha256(z.read(n)).hexdigest()} for n in z.namelist()]
    save(P / 'Evidence_Manifest.json', {'archive': 'Own_Code_And_Proofs.zip', 'bytes': (P / 'Own_Code_And_Proofs.zip').stat().st_size,
         'sha256': sha(P / 'Own_Code_And_Proofs.zip'), 'CRC_and_every_member': 'PASS', 'members': cert,
         'not_full_private_raw_backup': True})
    save(P / 'Actual_v4_Reconciliation.json', result)
    save(P / 'Current_Resume.json', json.loads((O / 'Current_Resume.json').read_text('utf-8')))
    save(P / 'Task_Checklist.md', '# Federation comparison execution tasks\n\n' + '\n'.join(f"- [{'x' if t['status'].startswith('COMPLETE') else ' '}] {t['id']}: {t['task']} ({t['status']})" for t in next_steps) + '\n')
    save(P / 'Research_Progress_Entry.md', note)
    save(P / 'README.md', '''# Federation comparison priority and actual Reflection-v4

The final manuscript137-case table reports DFF290/HG-VF291/HG-SE193 residual UV. Independent saved-summary analysis on the available67-case v4 prefix gives32/29/19; these populations are distinct. Full137raw trajectory/source/weight/cost reconstruction is not certified. No new physical/model/training benchmark ran in this recheck.

The package includes own analysis, software admission checks, source-linked118method registry, preserved mechanical-analysis failures, prior fresh128terminalpartial checkpoint and exact unfinished tasks. It excludes private weights/NETs and full third-party/notebook source. It is not a complete raw backup or a claim to beat unavailable methods.
''')
    entries = []
    for p in sorted(P.iterdir()):
        entries.append({'local': str(p.relative_to(R)).replace('\\', '/'),
                        'path': 'research/20261022_federation_benchmark/' + p.name,
                        'bytes': p.stat().st_size, 'sha256': sha(p),
                        'blob': hashlib.sha1(b'blob ' + str(p.stat().st_size).encode() + b'\0' + p.read_bytes()).hexdigest()})
    assert len(entries) == 7
    save(O / 'Publication_Files_Prepared.json', entries)
    print(json.dumps({'saved': str(O.relative_to(R)), 'files': len(entries), 'zip_members': len(own),
                      'archive_bytes': (P / 'Own_Code_And_Proofs.zip').stat().st_size,
                      'all6goals': 'OPEN', 'currentGPU': 0, 'newscience': 0}))


if __name__ == '__main__':
    main()
