The fixed pretrained one-state pilot completed with independently audited training, checkpoint reloads and selected physical states.

Actual training: 310 optimizer steps and 654 model forwards across both arms.
New selected-physics PF attempts: 21; exact prior reports and their separate costs retained.

Descriptive validation VCSA versus each preserved comparator:
- state_only_pilot: 0 UV wins, 13 ties, 3 losses, 0 unavailable pairs; 5 admissible changed actions.
- common_information_control_pilot: 0 UV wins, 16 ties, 0 losses, 0 unavailable pairs; 3 admissible changed actions.
- frozen_LM_heads: 0 UV wins, 16 ties, 0 losses, 0 unavailable pairs; 0 admissible changed actions.

These are correlated historical one-state development results. They do not establish full D-SE trajectory superiority, clean component attribution, deployment efficiency or unused independent confirmation. Preserve final epoch5 and both controls; no outcome-chasing retraining.
