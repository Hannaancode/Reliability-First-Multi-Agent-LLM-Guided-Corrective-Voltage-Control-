# Historical paper cohort reconciliation

An archived raw comparison table contains137 distinct scenario IDs, all present in the existing141 federation recipes. Its two recorded initial UV columns agree case by case and each sum to2,715, matching the supplied paper’s stated primary population.

This recovers a concrete historical cohort identity scaffold. The earlier method columns are explicitly v2b, v2r and a reconstructed router; their835,656 and545 residualUV totals must not be relabeled as the later DFF/HG-VF/HG-SE paper rows290/291/193. The accompanying early Phase2G table has68 rows. The complete later137-case HG-SE action/trajectory data remain unjoined.

Matching case IDs and counts does not certify the exact solved physical roots, initializer, source/weights, all physical trajectories, costs, or the later paper’s result. Four generated recipe IDs are absent from this archive; their individual convergence/exclusion reasons remain unverified. No sources were changed, no original study was rerun, and no new model, PF or optimizer was called.
