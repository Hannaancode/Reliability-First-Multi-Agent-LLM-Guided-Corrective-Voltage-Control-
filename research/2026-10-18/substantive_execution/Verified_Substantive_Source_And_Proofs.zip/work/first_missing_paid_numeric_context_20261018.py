"""One source-fixed first missing context; no PF, policy rollout or model call."""
import argparse,hashlib,json,os,pickle,subprocess,sys,time,zlib
from pathlib import Path
import numpy as np
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
B=R/'outputs/first_missing_paid_numeric_context_20261018'
OLD=R/'outputs/unstarted_paid_suffix_support_screen_20261018'
REUSE=R/'outputs/full_paid_numeric_reuse_separate_roles_v2_20261018'
def prepare():
    from dynamic_actual_mask_guidance_v1 import current_inputs,identity
    B.mkdir(exist_ok=False);started=time.perf_counter();leg=read(OLD/'Leg_1.json')
    assert leg['status']=='UNKNOWN_MissingPaidNumericalContext'
    ref=leg['frontier_input'];raw=(OLD/ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['encoded_sha256']
    payload=zlib.decompress(raw);assert hashlib.sha256(payload).hexdigest()==ref['raw_sha256'];d=pickle.loads(payload)
    ident=identity(current_inputs(d['net']));assert ident==leg['missing_identity']
    refs=read(REUSE/'All_Existing_Contexts.json');assert ident not in {x['identity'] for x in refs}
    catalog=read(R/'outputs/prior_attempt_journal_scope_catalog_20261018/Journal_Schema_Catalog.json')
    relevant=[x for x in catalog if any('derivative_attempt' in k for k in x['events'])];assert len(relevant)==3
    coverage=[]
    for row in relevant:
        h=hashlib.sha256();tail=b'';hits=0;needle=ident.encode()
        with (R/row['path']).open('rb') as f:
            while data:=f.read(1024*1024):
                h.update(data);joined=tail+data;hits+=joined.count(needle);tail=joined[-(len(needle)-1):]
        assert h.hexdigest()==row['sha256'] and hits==0
        coverage.append({'path':row['path'],'sha256':row['sha256'],'target_identity_mentions':hits,'role':'All three catalogued journals with actual current-mask public derivative attempt events, exact snapshot closure. No universal claim about every historical mathematical operation.'})
    source=[Path(__file__),R/'work/audit_first_missing_paid_numeric_context_20261018.py',R/'work/dynamic_actual_mask_guidance_v1.py',
        R/'work/bounded_paid_lookahead_physics_20261014.py',R/'work/shared_original_serving_action_domain_v1.py',OLD/'Results.json',OLD/'Leg_1.json',OLD/ref['path'],
        REUSE/'Results.json',REUSE/'All_Existing_Contexts.json']
    put(B/'Attempt_Coverage.json',{'status':'PASS_EXACT_CURRENT_MASK_SOURCE_ROLE_NOT_PREVIOUSLY_MEASURED_IN_CLOSED_DEPENDENCY_SET','identity':ident,
        'existing_complete_contexts':len(refs),'relevant_journals':coverage,'bounds':'Not a global never-computed theorem; exact causal current-mask compile role and source snapshots only','workflow_seconds':time.perf_counter()-started})
    source.append(B/'Attempt_Coverage.json')
    put(B/'Protocol.json',{'status':'FROZEN_BEFORE_NEW_NUMERICAL_CONTEXT_OR_FORECAST','identity':ident,'selection':'First required missing numerical context of first declared originally unstarted suffix, imported first decision fixed before screen; no outcome selection',
        'input_frontier':str((OLD/ref['path']).relative_to(R)),'raw_sha256':ref['raw_sha256'],
        'allowed':'ONE original compile_current application:1dSbus_dV,1LU factor,1LU solve118RHS; then original forecast ONCE for ALL current full native ordinary+owned donor9Q rows within remaining original operation allowance',
        'new_PF_model_optimizer_controller_commit_calls':0,'bound_seconds':120,'reader_bound_seconds':120,
        'reuse_rule':'All70 complete known contexts and three source-bound derivative journals exclude this exact identity. All prior106917 complete forecast keys retained, no score replacement.',
        'limits':'Numerical current-mask ordering data only, not nonlinear feasibility/new physical trajectory/LLM value. No extra contexts/queries/retunes/retries/old budget extension.',
        'pins':{str(x.relative_to(R)):sha(x) for x in source},'reader_sha256':sha(R/'work/audit_first_missing_paid_numeric_context_20261018.py')})
    print(json.dumps({'prepared_exact_missing_numeric_identity':ident,'new_science':0}))
def worker():
    import pandapower as pp
    from dynamic_actual_mask_guidance_v1 import compile_current,identity
    from bounded_paid_lookahead_physics_20261014 import forecast,action_key,build_current_domain
    from frozen_physics_loader import load_stack
    p=read(B/'Protocol.json')
    for rel,h in p['pins'].items():assert sha(R/rel)==h,rel
    out=B/'actual';out.mkdir(exist_ok=False);started=time.perf_counter();cpu=time.process_time()
    put(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(__file__),'protocol_sha256':sha(B/'Protocol.json')})
    def block(*a,**k):raise AssertionError('No nonlinear/model/controller science authorized here')
    for n in ['runpp','runopp','rundcpp','rundcopp']:setattr(pp,n,block)
    d=pickle.loads(zlib.decompress((R/p['input_frontier']).read_bytes()));net=d['net'];cursor=d['cursor']
    _,runner,_=load_stack();meta=read(R/'work/e/pack/testbeds/federation_4mg_ieee118_metadata.json');zones=meta.get('zones',meta)
    cost={k:0 for k in ['public_derivative_attempts','public_derivative_returns','LU_factor_attempts','LU_factor_returns','LU_solve_attempts','LU_solve_returns','RHS_columns','exact_context_reuses']};cost['compile_seconds']=0.
    previous='0'*64;stream=(out/'Journal.jsonl').open('xb')
    def event(name,data):
        nonlocal previous
        assert time.perf_counter()-started<p['bound_seconds']
        raw=json.dumps({'event':name,'data':data,'previous_sha256':previous},sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        stream.write(raw+b'\n');stream.flush();os.fsync(stream.fileno());previous=hashlib.sha256(raw).hexdigest()
    context,ident=compile_current(net,{},cost,event);assert ident==p['identity'] and all(cost[k]==1 for k in ['public_derivative_returns','LU_factor_returns','LU_solve_returns'])
    with (out/(ident+'.npz')).open('xb') as f:np.savez_compressed(f,**context);f.flush();os.fsync(f.fileno())
    domain=build_current_domain(net,cursor,runner=runner,zones=zones);rows=[r for r in domain['all_declared_original9Q_ordinary_and_owned_joint_identities'] if (1 if r['kind']=='ordinary' else 2)<=cursor['remaining_original_device_operation_slots']]
    before=runner.rescue.grid_metrics(net);forecasts={}
    for row in rows:
        event('forecast_attempt',{'action_key':action_key(row)});prediction=forecast(row,context,before);forecasts[ident+'|'+action_key(row)]={'row':row,'forecast':prediction};event('forecast_return',{'action_key':action_key(row)})
    stream.close();put(out/'All_Current_Native_Forecasts.json',forecasts)
    put(out/'Result.json',{'status':'COMPLETE_SINGLE_CURRENT_MASK_CONTEXT_ALL_DECLARED_MENU_FORECASTS','identity':ident,'numeric_costs':cost,'forecast_attempts':len(rows),'forecast_returns':len(forecasts),
        'before':before,'new_nonlinear_PF_LLM_optimizer_controller_commit_calls':0,'journal_last_sha256':previous,'workflow_seconds':time.perf_counter()-started,'CPU_seconds':time.process_time()-cpu})
    manifest(out)
def run():
    # Actual worker ends before the sole locked independent reader starts.
    worker();p=read(B/'Protocol.json');reader=R/'work/audit_first_missing_paid_numeric_context_20261018.py';assert sha(reader)==p['reader_sha256']
    code=subprocess.run([sys.executable,'-X','utf8',str(reader)],cwd=R,timeout=p['reader_bound_seconds']).returncode
    put(B/'Completion.json',{'reader_exit_code':code})
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');args=parser.parse_args();prepare() if args.prepare else run()
