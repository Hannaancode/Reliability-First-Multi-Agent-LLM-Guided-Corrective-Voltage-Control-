"""New source-derived TRAIN input-support question; no original asset regeneration."""
import ast
import gzip
import hashlib
import json
import math
import os
import sys
import time
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from candidate_process_evidence_utils import ROOT, read, sha, write, seal, frozen_checks
from public_size_local_preservation_v2 import extended

R = ROOT / 'outputs/critical_research_reset_20261010'
OUT = extended(R / 'original_compact_TRAIN_current_input_support')
NOTEBOOK = extended(R / 'original_training_notebook_source_snapshot/Original_Account_Phase2A_Download.ipynb')
NOTEBOOK_SHA = '338bdb60b86efab822a0027a2ca57765deb8841470969cab084945c5ec009dfc'
ARCHIVE = Path(r'C:\Users\HOME\Desktop\multi agentic llm  power systesm\phase2b_training_inputs.zip')
MEMBER = 'hiergrid_phase2/zone_training_data/augmented/grouped_splits/zone_agent_train.jsonl'
TRAIN_SHA = '7b22162d0abd92ccb64473fcef5bb300ee12416ce22ea6ce03e60fefaa9154eb'
OLD_ROWS = extended(R / 'original_TRAIN_causal_label_support/All16000_TRAIN_Identity_and_Projection_Records.json')
OLD_ROWS_SHA = '2182df652584132704aab8c3b055a01b5779fdefa98223f10402e5998cb22eac'
SYSTEM = 'You are a microgrid zone agent. Return only valid JSON. No prose.'
SCALARS = ('zone', 'min_voltage_pu', 'max_voltage_pu', 'n_undervoltage', 'n_overvoltage')
TARGET_FIELDS = ['state_summary', 'fault_detected', 'zone', 'min_voltage_pu', 'max_voltage_pu',
                 'n_undervoltage', 'n_overvoltage', 'proposed_action', 'requires_coordinator_review',
                 'autonomous_local_action_allowed', 'verification', 'confidence']


def canonical(value):
    if value is None: return ['null']
    if isinstance(value, bool): return ['bool', value]
    if isinstance(value, (int, float)):
        assert math.isfinite(value)
        n, d = value.as_integer_ratio()
        return ['number', str(n), str(d)]
    if isinstance(value, str): return ['string', value]
    if isinstance(value, list): return ['list', [canonical(v) for v in value]]
    assert isinstance(value, dict)
    return ['object', [[k, canonical(value[k])] for k in sorted(value)]]


def digest(value):
    return hashlib.sha256(json.dumps(canonical(value), ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def compact_teacher(target):
    # Independent transcription of the recovered compact_assistant; never eval/exec a notebook.
    result = {name: target.get(name) for name in TARGET_FIELDS[:8]}
    result['requires_coordinator_review'] = target.get('requires_coordinator_review', False)
    result['autonomous_local_action_allowed'] = target.get('autonomous_local_action_allowed', target.get('proposed_action') is not None)
    verification = target.get('verification', {})
    result['verification'] = {'verdict': verification.get('verdict'), 'reason': verification.get('reason', '')}
    result['confidence'] = target.get('confidence', 'moderate')
    candidate = target.get('candidate_action_for_coordinator')
    if candidate is not None: result['candidate_action_for_coordinator'] = candidate
    return result


def user(values):
    return (
        'You are a microgrid zone agent for physics-verified grid operation.\n'
        'Read the local zone state and output ONLY valid JSON using the required schema.\n'
        'Do not copy the input. Do not explain in prose.\n\n'
        'LOCAL_ZONE_STATE:\n'
        f"zone: {values.get('zone')}\n"
        f"min_voltage_pu: {values.get('min_voltage_pu')}\n"
        f"max_voltage_pu: {values.get('max_voltage_pu')}\n"
        f"n_undervoltage: {values.get('n_undervoltage')}\n"
        f"n_overvoltage: {values.get('n_overvoltage')}\n"
        f"state_summary: {values.get('state_summary')}\n\n"
        'TASK:\n'
        'Decide whether this zone needs no action, a local voltage-support action, '
        'or coordinator review. Return compact JSON only.'
    )


def current_values(observation):
    local = observation.get('local_measurements')
    if not isinstance(local, dict): return None, 'missing_local_measurements'
    raw_vm = local.get('bus_voltages')
    if not isinstance(raw_vm, dict) or not raw_vm: return None, 'missing_or_empty_voltages'
    if any(not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v) for v in raw_vm.values()):
        return None, 'invalid_archived_voltage'
    load = local.get('total_load_mw')
    if not isinstance(load, (int, float)) or isinstance(load, bool) or not math.isfinite(load):
        return None, 'missing_or_invalid_archived_load'
    zone = observation.get('zone')
    if not isinstance(zone, str): return None, 'missing_zone'
    vm = {int(b): float(v) for b, v in raw_vm.items()}
    minimum, maximum = min(vm.values()), max(vm.values())
    uv = sum(v < 0.95 for v in vm.values())
    ov = sum(v > 1.05 for v in vm.values())
    worst = min(vm, key=vm.get)
    if uv:
        summary = (f'Zone {zone} has {uv} undervoltage buses below 0.95 p.u.; '
                   f'the worst bus is {worst} at {minimum:.4f} p.u.; '
                   f'total solved load is {float(load):.3f} MW.')
    elif ov:
        summary = (f'Zone {zone} has {ov} overvoltage buses above 1.05 p.u.; '
                   f'the maximum local voltage is {maximum:.4f} p.u.')
    else:
        summary = (f'Zone {zone} is locally within voltage limits; voltage range is '
                   f'{minimum:.4f} to {maximum:.4f} p.u.; '
                   f'total solved load is {float(load):.3f} MW.')
    return {'zone': zone, 'min_voltage_pu': minimum, 'max_voltage_pu': maximum,
            'n_undervoltage': uv, 'n_overvoltage': ov, 'state_summary': summary}, None


def run():
    assert not OUT.exists(), 'Never duplicate or overwrite a prior reader'
    OUT.mkdir(); started = time.perf_counter(); now = datetime.now(timezone.utc).isoformat()
    write(OUT / 'audit.claim', {'actual_pid': os.getpid(), 'command': sys.argv,
        'source_sha256': sha(Path(__file__)), 'at_utc': now})
    write(OUT / 'Prospective_Source_Derived_TRAIN_Protocol.json', {
        'declared_at_utc': now, 'scope': 'All16000 original TRAIN rows/109 worlds only; no VAL/test outcomes',
        'previous_goal_turn_classification': 'NO_EMPIRICAL_PROGRESS: answered review-status question and wrote an unexecuted candidate plan; this turn performs a new measured information-contract check',
        'question': 'Can the recovered compact teacher-input fields be derived from archived current observations, and are proposed-action targets consistent under a measurement-derived compact serving representation?',
        'notebook_sha256': NOTEBOOK_SHA, 'TRAIN_member_sha256': TRAIN_SHA, 'reused_physical_identity_rows_sha256': OLD_ROWS_SHA,
        'projection_A': 'Independent transcription of recovered compact teacher six-field prompt; hashes only, not an original historical compact file',
        'projection_B': 'Source Phase2C current compact prompt rendered from raw archived voltage/load fields; strict0.95/1.05, raw bus iteration, no IDs/AFTER/targets in inputs',
        'B_load_identity_limit': 'Raw total_load_mw is used conditionally; equality to original serving net.res_load sum and bus iteration has not been physically remeasured. This is archived-information support, not actual deployment replay.',
        'target': 'Exact proposed_action including null; compact complete-target matching is secondary exact-string/field support, not physical quality',
        'canonicalization': 'Exact parsed finite numeric ratios, no rounding except the original source summary4/3decimal formats; no missing-to-zero imputation',
        'missing_rule': 'Retain every identity; unavailable measurement-derived prompt is UNKNOWN, not a negative action outcome',
        'matching_bound': 'Empirical deterministic exact-teacher match only on declared TRAIN projections; UNKNOWN rows yield conservative missing-evidence range, not a statistical CI',
        'no_original_missing_compact_asset_regeneration_or_new_training_dataset': True,
        'no_new_model_PF_optimizer_controller_forecast_solve_cloud_or_allocation_calls': True,
        'no_automatic_learning_or_gpu_gate': True, 'resource_bound_seconds_before_seal': 120,
    })
    assert sha(NOTEBOOK) == NOTEBOOK_SHA and sha(OLD_ROWS) == OLD_ROWS_SHA
    old = read(OLD_ROWS); assert len(old) == 16000
    notebook = read(NOTEBOOK)
    prep = ''.join(notebook['cells'][36]['source'])
    tree = ast.parse(prep)
    compact_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'compact_assistant')
    dictionary = next(n.value for n in compact_fn.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'compact' for t in n.targets))
    assert [ast.literal_eval(k) for k in dictionary.keys] == TARGET_FIELDS
    make_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'make_ultra_compact_user')
    local_tree = ast.parse(Path(__file__).read_text(encoding='utf8'))
    our_fn = next(n for n in local_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'user')
    # Compare the actual f-string AST; function/argument name is outside this return expression.
    original_expression = make_fn.body[0].value
    our_expression = our_fn.body[0].value
    # Same literal structure; local 'values' is an intentionally renamed 'compact' variable.
    class Rename(ast.NodeTransformer):
        def visit_Name(self, node):
            return ast.copy_location(ast.Name(id='compact' if node.id == 'values' else node.id, ctx=node.ctx), node)
    assert ast.dump(original_expression, include_attributes=False) == ast.dump(Rename().visit(our_expression), include_attributes=False)
    with zipfile.ZipFile(ARCHIVE) as archive: raw = archive.read(MEMBER)
    assert hashlib.sha256(raw).hexdigest() == TRAIN_SHA
    rows = [json.loads(line) for line in raw.decode('utf8').splitlines()]
    assert len(rows) == 16000
    groups = {name: defaultdict(Counter) for name in ('teacher_derived_compact', 'measurement_derived_compact')}
    full_groups = defaultdict(Counter)
    worlds = Counter(); counts = Counter(); scalar_matches = Counter(); unknown = Counter(); witnesses = []
    identities = []
    for index, row in enumerate(rows):
        assert time.perf_counter() - started < 120
        messages = row['messages']; assert len(messages) == 3 and messages[2]['role'] == 'assistant'
        observation = json.loads(messages[1]['content']); target = json.loads(messages[2]['content'])
        world = hashlib.sha256(str(observation['scenario_id']).encode()).hexdigest()
        assert old[index]['TRAIN_row_index'] == index and old[index]['world_sha256'] == world
        worlds[world] += 1
        compact = compact_teacher(target)
        prefix_a = digest([SYSTEM, user(compact)])
        action = digest(target['proposed_action'])
        assert action == old[index]['target_proposed_action_sha256']
        groups['teacher_derived_compact'][prefix_a][action] += 1
        full_groups[prefix_a][digest(compact)] += 1
        current, error = current_values(observation)
        record = {'TRAIN_row_index': index, 'world_sha256': world,
            'reused_full_physical_observation_sha256': old[index]['projections']['full_current_local_information'],
            'source_derived_teacher_compact_prefix_sha256': prefix_a,
            'measurement_derived_compact_prefix_sha256': None,
            'exact_proposed_action_sha256': action, 'source_derived_compact_target_sha256': digest(compact),
            'measurement_input_status': 'UNKNOWN' if error else 'KNOWN', 'unknown_reason': error}
        if error:
            unknown[error] += 1
        else:
            prefix_b = digest([SYSTEM, user(current)])
            record['measurement_derived_compact_prefix_sha256'] = prefix_b
            groups['measurement_derived_compact'][prefix_b][action] += 1
            matches = {name: canonical(compact.get(name)) == canonical(current[name]) for name in SCALARS}
            record['scalar_fields_exactly_match_archived_measurements'] = matches
            scalar_matches.update(name for name, ok in matches.items() if ok)
            same_summary = compact['state_summary'] == current['state_summary']
            record['summary_exactly_matches_source_canonical_wording'] = same_summary
            counts['summary_exact_match' if same_summary else 'summary_wording_different'] += 1
            counts['all_five_scalar_fields_match' if all(matches.values()) else 'some_scalar_field_different'] += 1
            counts['prefix_exact_match' if prefix_a == prefix_b else 'prefix_different'] += 1
            counts['fault_flag_matches_current_counts' if compact['fault_detected'] == (current['n_undervoltage'] > 0 or current['n_overvoltage'] > 0) else 'fault_flag_different'] += 1
            if (not all(matches.values()) or not same_summary) and len(witnesses) < 5:
                witnesses.append({'TRAIN_row_index': index, 'scalar_matches': matches,
                    'teacher_summary': compact['state_summary'], 'measurement_derived_summary': current['state_summary'],
                    'not_a_causal_model_failure_or_independent_physics_replay': True})
        identities.append(record)
    assert len(worlds) == 109
    summaries = {}; classes = {}
    for name, grouped in groups.items():
        classes[name] = [{'prefix_sha256': key, 'rows': sum(f.values()), 'target_action_counts': dict(f)}
                         for key, f in sorted(grouped.items())]
        known = sum(sum(f.values()) for f in grouped.values())
        exact_max = sum(max(f.values()) for f in grouped.values())
        missing = 16000 - known
        summaries[name] = {'distinct_source_derived_prefixes': len(grouped), 'known_rows': known, 'unknown_rows': missing,
            'ambiguous_proposed_action_classes': sum(len(f) > 1 for f in grouped.values()),
            'rows_in_ambiguous_classes': sum(sum(f.values()) for f in grouped.values() if len(f) > 1),
            'minimum_exact_action_teacher_errors_on_known_rows': known - exact_max,
            'all_row_empirical_exact_teacher_match_conservative_range': [exact_max / 16000, (exact_max + missing) / 16000],
            'not_generalization_or_physical_success_probability': True}
    write(OUT / 'Exact_Source_Derived_Compact_Action_Classes.json', classes)
    with gzip.open(OUT / 'All16000_Source_Derived_Compact_Identities.jsonl.gz', 'xt', encoding='utf8') as stream:
        for identity in identities: stream.write(json.dumps(identity, separators=(',', ':')) + '\n')
    facts = {'at_utc': now, 'all16000_TRAIN_rows_109_worlds_retained': True,
        'original_raw_member_sha256': TRAIN_SHA, 'notebook_sha256': NOTEBOOK_SHA,
        'reused_physical_row_sha256': OLD_ROWS_SHA, 'scalar_field_matches': dict(scalar_matches),
        'comparison_counts': dict(counts), 'unknown_measurement_input_reasons': dict(unknown),
        'exact_teacher_action_support': summaries,
        'teacher_derived_compact_full_target_exact_match': {
            'distinct_prefixes': len(full_groups), 'ambiguous_complete_target_classes': sum(len(v) > 1 for v in full_groups.values()),
            'empirical_deterministic_exact_teacher_match_upper_fraction': sum(max(v.values()) for v in full_groups.values()) / 16000,
            'secondary_exact_matching_not_policy_quality': True},
        'summary_witnesses': witnesses,
        'derived_hashes_are_forensic_recipe_measurement_not_recovered_original_compact_bytes': True,
        'raw_load_vs_original_solved_load_and_bus_iteration_identity_not_certified': True,
        'teacher_wording_difference_is_not_proof_future_leakage_or_causal_failure': True,
        'teacher_embedded_targets_not_independent_physical_certification': True,
        'all_new_model_PF_optimizer_controller_forecast_solve_cloud_allocation_calls': 0,
        'automatic_training_or_gpu_launch': False,
        'analysis_seconds_before_frozen_checks_and_seal': time.perf_counter() - started}
    write(OUT / 'Original_Compact_TRAIN_Current_Input_Support.json', facts)
    write(OUT / 'Fresh_Frozen_Asset_Checks.json', frozen_checks())
    files = {p.name: p for p in OUT.iterdir() if p.is_file() and p.name != 'audit.claim'}
    files['sources/reader.py'] = Path(__file__)
    archive = seal(OUT, files, 'Source_Derived_Compact_TRAIN_Support.zip')
    write(OUT / 'Actual_Read_Only_Workflow_Cost.json', {
        'workflow_seconds_including_frozen_checks_and_seal': time.perf_counter() - started,
        'new_scientific_calls': 0, 'prior_raw_dataset_physical_training_and_reader_costs_separate_not_free': True})
    print(json.dumps({'support': summaries, 'scalar_matches': dict(scalar_matches), 'comparison_counts': dict(counts),
                      'unknowns': dict(unknown), 'compact_full_target': facts['teacher_derived_compact_full_target_exact_match'],
                      'archive': archive, 'workflow_seconds': time.perf_counter() - started}))


if __name__ == '__main__':
    run()
