Fixed public0.5B/1.5B development diagnostic.

{
  "complete_engineering_and_paired_response_study": false,
  "development_only": true,
  "paired_counts": {
    "unknown": 31
  },
  "missing_unmeasured_malformed_abstention_failures_retained": true,
  "this_is_not_a_training_or_superiority_gate": true,
  "no_automatic_training_or_full_physical_campaign": true,
  "full_DSE_both_branches_matched_trajectories_and_unused_confirmation_still_required": true,
  "goal_achieved": false
}

All31 finite worlds plus the original invalid world remain. Existing measured one-step targets are reused, with no new physics. Unknown outcomes are not ties or losses. Numerical controls have stronger full-table information; public sizes share identical partial prompts. Recipe, architecture, precision/FLOP and original-private-adapter differences remain. This does not establish learning value, full protected trajectories or original D-SE superiority.
