"""Exact certified-initial representation adapter; no scientific entry point.

Every call first runs the unchanged v1 current-state binder. Only an empty
history at the exact original certified root may return the original certified
input representation. No tolerance, rounded state, changed reference, or copied
physical snapshot can acquire the historical first-proposal identity.

Noninitial/copy-reference states return the untouched v1 kernel. Cursor schema,
history, deadlines, RNG custody, receipts, and all v1 checks remain unchanged.
"""
from pathlib import Path
import copy
import io
import os
import pickle

import numpy as np
import nonlinear13_current_state_20261029 as legacy
from remaining85_certified_loader_20261029 import load_certified_case
from remaining85_source_binder_v2_20261029 import DataUnpickler

SCHEMA = legacy.SCHEMA
SOURCE_FILE = 'work/nonlinear13_current_state_v2_20261030.py'
LEGACY_SOURCE_FILE = legacy.SOURCE_FILE
CERTIFIED_LOADER_SOURCE = 'work/remaining85_certified_loader_20261029.py'
AUXILIARY_SOURCE = legacy.AUXILIARY_SOURCE
PQ_SOURCE = legacy.PQ_SOURCE
ADAPTER_SCHEMA = 'EXACT_CERTIFIED_INITIAL_REPRESENTATION_V1'
MAX_CURSOR_BYTES = 1024 * 1024  # Fixed prospective bound; never raised per state.
EXACT_ARRAY_FIELDS = (
    'Y', 'ppc_bus', 'ppc_gen', 'lookup', 'control', 'current_vm', 'current_q',
    'control_scaling', 'control_in_service', 'pq', 'ref', 'normal', 'injection0',
)
SCALAR_REPRESENTATION_FIELDS = ('baseMVA', 'enforce_q_lims', 'distributed_slack')


def _typed_same(a, b):
    """Explicit scalar/container types; arrays require dtype, shape, and bytes."""
    if type(a) is not type(b):
        return False
    if isinstance(a, np.ndarray):
        return (not a.dtype.hasobject and not b.dtype.hasobject and
                a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes())
    if isinstance(a, np.generic):
        return a.dtype == b.dtype and a.tobytes() == b.tobytes()
    if isinstance(a, dict):
        return list(a) == list(b) and all(_typed_same(a[k], b[k]) for k in a)
    if isinstance(a, (tuple, list)):
        return len(a) == len(b) and all(_typed_same(x, y) for x, y in zip(a, b))
    return a == b


def _array_anchor(a, b, name):
    legacy._need(isinstance(a, np.ndarray) and isinstance(b, np.ndarray) and
                 a.dtype == b.dtype and a.shape == b.shape and a.tobytes() == b.tobytes(),
                 'Certified initial/current exact array differs: ' + name)


def _require_cursor_byte_cap(raw):
    if len(raw) > MAX_CURSOR_BYTES:
        raise RuntimeError('UNKNOWN_CURSOR_CAP_EXCEEDED_NO_WRITE_NO_LIMIT_INCREASE: ' +
                           str(len(raw)) + ' > ' + str(MAX_CURSOR_BYTES))


def _bind_current(root, seed, current_ref, cursor):
    # This must remain the first gate: no v2 branch bypasses any v1 source,
    # complete cursor/RNG, receipt, NET, physical table, option, or PPC check.
    rebuilt, original_binding = legacy._bind_current(root, seed, current_ref, cursor)
    required = {SOURCE_FILE, LEGACY_SOURCE_FILE, CERTIFIED_LOADER_SOURCE}
    legacy._need(required <= cursor['source_lock'].keys(), 'V2 adapter/dependency missing from source lock')
    # The old binder already checked every source_lock hash, including v2.
    metadata = {'schema': ADAPTER_SCHEMA, 'source_file': SOURCE_FILE,
                'source_sha256': cursor['source_lock'][SOURCE_FILE],
                'route': 'UNCHANGED_LEGACY_CURRENT_RECONSTRUCTION',
                'all_original_checks_completed_first': True, 'scientific_evaluations': 0}
    binding = dict(original_binding, exact_initial_representation_adapter=metadata)
    if cursor['history'] or cursor['next_step'] != 1:
        return rebuilt, binding

    initial, certified = load_certified_case(root, seed)
    # Compare the entire reference, not only a physical signature or equal data.
    # A copied/aliased file (even identical bytes) is not the original context.
    exact_root = (_typed_same(current_ref, certified['root']) and
                  _typed_same(cursor['current_NET'], certified['root']) and
                  _typed_same(cursor['root_NET'], certified['root']) and
                  type(seed) is int and seed == certified['seed'] == cursor['seed'])
    if not exact_root:
        return rebuilt, binding
    legacy._need(type(initial) is type(rebuilt), 'Certified/current kernel class differs')
    legacy._need(not initial.costs and not rebuilt.costs, 'Evaluated input cannot acquire initial identity')
    for name in EXACT_ARRAY_FIELDS:
        a, b = getattr(initial, name), getattr(rebuilt, name)
        _array_anchor(a, b, name)
        legacy._need(not np.shares_memory(a, b), 'Initial/current model arrays unexpectedly alias: ' + name)
    for name, cvalue in [('current_q', cursor['current_Q']), ('current_vm', cursor['current_vm'])]:
        a = getattr(initial, name)
        legacy._need(np.array_equal(a, np.asarray(cvalue)), 'Initial/cursor numerical state differs: ' + name)
        legacy._need(not np.shares_memory(a, np.asarray(cvalue)), 'Returned initial model aliases caller cursor: ' + name)
    differences = []
    for name in SCALAR_REPRESENTATION_FIELDS:
        a, b = getattr(initial, name), getattr(rebuilt, name)
        aa, bb = np.asarray(a), np.asarray(b)
        legacy._need(aa.shape == bb.shape == () and aa.dtype == bb.dtype and
                     np.array_equal(aa, bb), 'Certified initial scalar value differs: ' + name)
        if not _typed_same(a, b):
            differences.append(name)
    a, b = initial.V_current, rebuilt.V_current
    legacy._need(a.dtype == b.dtype == np.dtype('complex128') and a.shape == b.shape == (13,) and
                 np.isfinite(a).all() and np.isfinite(b).all(), 'Invalid certified/reconstructed voltage representation')
    # V may have different reconstruction bits. Its authority is the unchanged
    # certified pack joined to the exact original root, never a tolerance test.
    # Do not rebuild, cast, modify, or substitute any certified kernel field.
    metadata.update(route='EXACT_ORIGINAL_ROOT_CERTIFIED_INITIAL_OBJECT',
                    certified_root=copy.deepcopy(certified['root']),
                    certified_input_pack=copy.deepcopy(certified['pack']),
                    certified_directory=certified['certificate'],
                    exact_array_anchor_fields=list(EXACT_ARRAY_FIELDS),
                    scalar_container_differences=differences,
                    certified_V_bytes_equal_reconstructed=(a.tobytes() == b.tobytes()),
                    voltage_difference_admission_rule='NONE: exact root and certified pack only',
                    original_root_initializer_authority='Exact saved root bytes and unchanged original checks; no inferred kwargs normalization')
    return initial, binding


def pack_current_state(root, seed, current_NET_ref, cursor, output_path):
    """Same public signature and return API as v1; preserve full cursor."""
    kernel, binding = _bind_current(root, seed, current_NET_ref, cursor)
    value = {'schema': SCHEMA, 'cursor': copy.deepcopy(cursor), 'binding': binding}
    raw = pickle.dumps(value, protocol=5)
    _require_cursor_byte_cap(raw)  # Check actual serialized bytes before opening output.
    p = (Path(root) / output_path).resolve()
    p.relative_to(Path(root).resolve())
    with p.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return kernel, {'path': p.relative_to(Path(root).resolve()).as_posix(),
                    'sha256': legacy._sha(raw), 'bytes': len(raw)}


def load_current_state(root, checkpoint_ref):
    """Re-run original checks and the same exact representation branch cold."""
    raw = legacy._verify_reference(root, checkpoint_ref)
    _require_cursor_byte_cap(raw)
    value = DataUnpickler(io.BytesIO(raw)).load()
    legacy._need(value['schema'] == SCHEMA, 'Unknown packed cursor schema')
    cursor = value['cursor']
    kernel, binding = _bind_current(root, cursor['seed'], cursor['current_NET'], cursor)
    legacy._need(_typed_same(binding, value['binding']), 'Cold v2 current binding changed')
    return kernel, cursor


if __name__ == '__main__':
    raise SystemExit('Library only: no solver, PF, model, scientific replay, or controller CLI.')
