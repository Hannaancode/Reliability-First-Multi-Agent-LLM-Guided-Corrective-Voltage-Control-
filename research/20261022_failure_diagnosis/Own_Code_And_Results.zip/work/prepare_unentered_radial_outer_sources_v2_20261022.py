"""Additive metadata-only launch repair; four LP identities were never entered."""
import ast,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]

def main():
    old=R/'outputs/public13_radial_outer_execution_20261022'
    assert sorted(p.name for p in old.iterdir())==['owner.claim']
    pairs={
        'public13_radial_outer_certificate_20261022':'unentered_public13_radial_outer_v2_20261022',
        'run_public13_radial_outer_20261022':'run_unentered_public13_radial_outer_v2_20261022',
        'audit_public13_radial_outer_20261022':'audit_unentered_public13_radial_outer_v2_20261022',
        'coordinate_public13_radial_outer_20261022':'coordinate_unentered_public13_radial_outer_v2_20261022',
        'prepare_public13_radial_outer_20261022':'prepare_unentered_public13_radial_outer_v2_20261022',
        'public13_radial_outer_preparation_v2_20261022':'public13_radial_outer_preparation_v3_20261022',
        'public13_radial_outer_execution_20261022':'public13_radial_outer_unentered_v2_execution_20261022',
        'public13_radial_outer_independent_20261022':'public13_radial_outer_unentered_v2_independent_20261022',
        'public13_radial_outer_coordination_20261022':'public13_radial_outer_unentered_v2_coordination_20261022',
        'public13_radial_outer_handoff_20261022':'public13_radial_outer_unentered_v2_handoff_20261022',
        'public13_radial_outer_reader_coordination_20261022':'public13_radial_outer_unentered_v2_reader_coordination_20261022',
        'coordinate_single_source_bound_owner_20261020':'coordinate_atomic_source_owner_20261022'}
    stems=list(pairs)[:5]
    for stem in stems:
        raw=(R/'work'/(stem+'.py')).read_text(encoding='utf-8');changed=raw
        for a,b in pairs.items():changed=changed.replace(a,b)
        if stem==stems[0]:
            start=changed.index('def put(p,v):');end=changed.index('def f(v):',start)
            changed=changed[:start]+'''def put(p,v):
    assert not Path(p).exists();temporary=Path(p).with_name(Path(p).name+'.pending')
    with temporary.open('x',encoding='utf-8') as stream:json.dump(v,stream,indent=2,allow_nan=False);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,p)
'''+changed[end:]
            before=ast.parse(raw);after=ast.parse(changed)
            for name in ['source','build','certificate']:
                a=next(n for n in before.body if isinstance(n,ast.FunctionDef) and n.name==name);b=next(n for n in after.body if isinstance(n,ast.FunctionDef) and n.name==name)
                assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
        dest=R/'work'/(pairs[stem]+'.py');assert not dest.exists();dest.write_text(changed,encoding='utf-8');compile(changed,str(dest),'exec')
    print('ALL4_UNENTERED_METADATA_ONLY_SOURCES_ADDITIVE_EXACT_MATH_AST_PASS')

if __name__=='__main__':main()
