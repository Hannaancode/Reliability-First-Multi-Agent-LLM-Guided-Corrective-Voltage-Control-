"""Append a genuinely new reviewed event to the human's plain-text progress log."""
import argparse
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--entry-json',required=True)
args=parser.parse_args()
entry_path=Path(args.entry_json).resolve()
entry=json.loads(entry_path.read_text(encoding='utf-8'))
assert set(entry)=={'event_id','method','result','improvements','limitations','decision','sources'}
assert re.fullmatch(r'[a-zA-Z0-9_-]{1,100}',entry['event_id'])
for source in entry['sources']:
    path=(ROOT/source).resolve()
    assert path.is_relative_to(ROOT) and path.is_file(),source
log=ROOT/'reseacrh progress.txt'
marker='[EVENT '+entry['event_id']+']'
if marker in log.read_text(encoding='utf-8'):
    print(json.dumps({'already_recorded':entry['event_id'],'duplicate_append':False}))
else:
    lines=['',marker,datetime.now(timezone.utc).isoformat()]
    for field in ['method','result','improvements','limitations','decision']:
        value=entry[field]
        assert isinstance(value,str) and value.strip()
        lines.extend([field.upper()+':',value])
    lines.extend(['SOURCES:']+entry['sources']+['[END EVENT]',''])
    with log.open('a',encoding='utf-8') as f:
        f.write('\n'.join(lines));f.flush();os.fsync(f.fileno())
    print(json.dumps({'appended_event':entry['event_id'],'progress_file':str(log)}))
