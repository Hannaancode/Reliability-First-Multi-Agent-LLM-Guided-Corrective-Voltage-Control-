"""Isolated chunked runtime binding; no owner, launcher or old-study resume.

All physical/controller/dependency logic comes from the preserved v2 AST.
Only the history module binding and its exact index SHA anchor change.
"""
import ast, copy, hashlib
from pathlib import Path
import receding_paid_runtime_v2 as original
import paid_receding_chunked_history_v2_20261018 as transport
DEPENDENCY_KEY=original.DEPENDENCY_KEY

SOURCE=Path(original.__file__)
source=SOURCE.read_text(encoding='utf-8')
before="self.registry[HISTORY_KEY]['sha256']"
after="self.registry[HISTORY_KEY]['index_sha256']"
assert source.count(before)==1
changed=source.replace(before,after)
assert changed.replace(after,before)==source
tree=ast.parse(changed)
definitions=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))]
environment=original.__dict__.copy()
for name in ['HISTORY_KEY','fields','fingerprint','commit_paid','save_complete','restore_complete']:
    environment[name]=getattr(transport,name)
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(SOURCE),'exec'),environment)
for node in definitions:globals()[node.name]=environment[node.name]

SOURCE_CERTIFICATE={
    'original_source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'changed_runtime_AST_sha256':hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest(),
    'inverse_exact_source_replacement':True,
    'replacement_before':before,'replacement_after':after,
    'transport_source_sha256':hashlib.sha256(Path(transport.__file__).read_bytes()).hexdigest(),
    'unchanged_physical_control_query_score_cost_dependency_logic':True,
    'new_history_MODE':transport.MODE,
    'no_science_on_import_or_automatic_old_resume':True}

def reconstruct_saved_readonly_factory(state,*,warm_dependencies,source_anchors):
    """Reconstruct paid evidence and bindings, explicitly NOT a live owner."""
    dependencies=restore_dependency_prefix(state,warm_dependencies=warm_dependencies,source_anchors=source_anchors)
    return {'dependencies':dependencies,'cursor':copy.deepcopy(state['cursor']),
            'original_absolute_deadline_utc':state['absolute_deadline_utc'],
            'execution_authorized_by_this_factory':False,
            'next_phase':'READONLY_SAVED_PREFIX_FACTORY_NO_SCIENCE',
            'new_scientific_calls':0}
