"""One fixed host per preassigned profile, then one saved-only reader."""
from pathlib import Path
from datetime import datetime,timezone
import argparse, hashlib, json, os, subprocess, time, traceback
from coordinate_native_inverter_linear_reference_20261020 import process
from public_qa_transfer_20261029 import read,json_once,sha
R=Path(__file__).resolve().parents[1]

def verify_child(child,claim,source):
    actual=process(claim['actual_pid']);assert actual and source.name in actual['CommandLine']
    assert actual['ParentProcessId']==claim['parent_pid'] and claim['source_sha256']==sha(source.read_bytes())
    assert (claim['actual_pid']==child.pid and claim['parent_pid']==os.getpid()) or claim['parent_pid']==child.pid
    return actual

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--protocol',required=True);args=ap.parse_args()
    p=read(args.protocol);assert p['launch_ready'] is True
    for path,h in p['source_hashes'].items():assert sha((R/path).read_bytes())==h
    out=R/p['coordination'];out.mkdir(parents=True,exist_ok=False)
    json_once(out/'owner.claim',{'actual_pid':os.getpid(),'parent_pid':os.getppid(),'source_sha256':sha(Path(__file__).read_bytes()),
        'started_at_utc':datetime.now(timezone.utc).isoformat()})
    children=[];host_source=R/'work/run_public_qa_colab_20261029.py';python=R/'work/colab_access_env/Scripts/python.exe'
    try:
        assert len(p['arms'])==3 and len({a['credential_directory'] for a in p['arms']})==3
        for arm in p['arms']:
            destination=R/arm['execution'];assert not destination.exists()
            log=(out/(arm['id']+'.log')).open('xb')
            child=subprocess.Popen([str(python),'-X','utf8',str(host_source),'--protocol',str(Path(args.protocol).resolve()),'--arm',arm['id']],
                cwd=R,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            began=time.monotonic()
            while not (destination/'owner.claim').exists():assert child.poll() is None and time.monotonic()-began<60;time.sleep(.1)
            claim=read(destination/'owner.claim');actual=verify_child(child,claim,host_source)
            assert arm['id'] in actual['CommandLine']
            json_once(destination/'Launcher_ACK.json',{'actual_pid':claim['actual_pid'],'actual_parent_pid':claim['parent_pid'],
                'actual_command':actual['CommandLine'],'fresh_exact_source_PID_parent_command':True})
            children.append({'arm':arm,'child':child,'claim':claim,'began':began,'log':log,'closed':False})
        while any(not item['closed'] for item in children):
            for item in children:
                if item['closed']:continue
                child=item['child']
                if child.poll() is None and time.monotonic()-item['began']>p['host_process_seconds']:
                    verify_child(child,item['claim'],host_source)
                    subprocess.run(['taskkill.exe','/PID',str(item['claim']['actual_pid']),'/T','/F'],capture_output=True,timeout=30)
                    child.wait(timeout=30)
                    json_once(out/(item['arm']['id']+'_Host_Bound.json'),{'host_bound_exhausted':True,'remote_state':'Must inspect same assignment; no replacement or repeated science'})
                if child.poll() is not None:
                    assert process(item['claim']['actual_pid']) is None and process(child.pid) is None
                    json_once(out/(item['arm']['id']+'_End_ACK.json'),{'actual_owned_chain_ended':True,'actual_pid':item['claim']['actual_pid'],
                        'launcher_pid':child.pid,'exit_code':child.returncode,'seconds':time.monotonic()-item['began']})
                    item['closed']=True;item['log'].close()
            time.sleep(5)
        # No analysis of still-running or lost primaries. A failure does not trigger
        # a second scientific attempt or a substitute profile.
        for item in children:
            state=read(R/item['arm']['execution']/'status.json')
            assert (R/item['arm']['execution']/'Host_End.json').exists()
            if state['runtime_allocated']:
                assert state['actual_remote_child_ended'] and state['all_artifacts_preserved'] and state['runtime_released']
            else: assert state.get('failure_http_status') in (401,403,429) or state['allocation_requests']==0
        reader=R/'work/audit_public_qa_scientific_20261029.py';audit=R/p['independent_audit'];assert not audit.exists()
        with (out/'reader.log').open('xb') as log:
            child=subprocess.Popen([str(python),'-X','utf8',str(reader),'--protocol',str(Path(args.protocol).resolve()),'--output',str(audit)],
                cwd=R,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            began=time.monotonic()
            while not (audit/'owner.claim').exists():
                assert child.poll() is None and time.monotonic()-began<60;time.sleep(.1)
            claim=read(audit/'owner.claim');mapped={**claim,'actual_pid':claim['pid']}
            actual=verify_child(child,mapped,reader)
            json_once(out/'Reader_Ownership_ACK.json',{'actual_pid':claim['pid'],'parent_pid':claim['parent_pid'],
                'actual_command':actual['CommandLine'],'fresh_exact_source_PID_parent_command':True})
            try:code=child.wait(timeout=max(1,p['reader_seconds']-(time.monotonic()-began)))
            except subprocess.TimeoutExpired:
                verify_child(child,mapped,reader)
                subprocess.run(['taskkill.exe','/PID',str(claim['pid']),'/T','/F'],capture_output=True,timeout=30)
                child.wait(timeout=30);raise
            assert process(claim['pid']) is None and process(child.pid) is None
            json_once(out/'Reader_End_ACK.json',{'actual_pid':claim['pid'],'launcher_pid':child.pid,
                'exit_code':code,'actual_owned_chain_ended':True,'seconds':time.monotonic()-began})
        assert code==0 and (audit/'Independent_Audit.json').exists()
        json_once(out/'Completion.json',{'status':'ALL_FIXED_PRIMARY_HOSTS_ENDED_AND_SAVED_READER_ENDED',
            'audit_sha256':sha((audit/'Independent_Audit.json').read_bytes()),'all_six_goals':'OPEN'})
    except BaseException as error:
        json_once(out/'Failure.json',{'failure_type':type(error).__name__,'traceback':traceback.format_exc(),
            'do_not_restart':True,'live_children_require_same_owner_observation':[x['claim'] for x in children if x['child'].poll() is None]})
        raise
if __name__=='__main__':main()
