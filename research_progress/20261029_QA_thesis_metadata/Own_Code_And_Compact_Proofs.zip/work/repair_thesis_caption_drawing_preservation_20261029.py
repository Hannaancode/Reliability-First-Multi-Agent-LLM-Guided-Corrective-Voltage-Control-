"""Restore inline drawings removed by paragraph.clear in the unapproved edit.

Original128-page thesis is unchanged. Preserve failed layout and restore exact
drawing XML from that original before replacing caption text only.
"""
from pathlib import Path
import copy,hashlib,json,shutil
from docx import Document
from docx.shared import Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.text.paragraph import Paragraph
R=Path(__file__).resolve().parents[1];O=R/'outputs/thesis_caption_QA_20261029'
def main():
    record=json.loads((O/'Integration_Record.json').read_text('utf-8'))
    base=R/record['base'];p=O/'Hannaan_Thesis_Caption_And_QA_Update.docx'
    assert hashlib.sha256(base.read_bytes()).hexdigest()==record['base_sha256']
    old=Document(base);new=Document(p)
    assert len(old.inline_shapes)==22 and len(new.inline_shapes)==0
    assert not (O/'Failed_Caption_Clear_Draft.docx').exists()
    shutil.copy2(p,O/'Failed_Caption_Clear_Draft.docx');shutil.copy2(O/'Integrated_Thesis_QA.pdf',O/'Failed_Caption_Clear_Draft.pdf')
    n=0
    for x in record['caption_changes']:
        if x['kind']!='Figure':continue
        a=next(p for p in old.paragraphs if p.text==x['original']);b=next(p for p in new.paragraphs if p.text==x['integrated'])
        replacement=copy.deepcopy(a._p);b._p.addprevious(replacement);b._p.getparent().remove(b._p)
        q=Paragraph(replacement,new)
        for run in list(q.runs):
            if run._r.xpath('.//w:drawing'):
                # The current source has separate picture/text runs. This guard
                # also preserves a combined picture run without retaining old text.
                for node in list(run._r.xpath('.//w:t')):node.getparent().remove(node)
            else:run._r.getparent().remove(run._r)
        rr=q.add_run('\n'+x['integrated'].lstrip('\n'));rr.font.name='Times New Roman';rr.font.size=Pt(11);rr.font.color.rgb=RGBColor(0,0,0)
        q.alignment=WD_ALIGN_PARAGRAPH.CENTER;q.paragraph_format.keep_together=True;q.paragraph_format.keep_with_next=False;q.paragraph_format.line_spacing=1;q.paragraph_format.space_after=Pt(6)
        n+=1
    assert n==22 and len(new.inline_shapes)==22
    oldxml=[s._inline.xml for s in old.inline_shapes];newxml=[s._inline.xml for s in new.inline_shapes];assert oldxml==newxml
    new.save(p)
    (O/'Drawing_Preservation_Repair.json').write_text(json.dumps({'status':'RESTORED_ALL22_EXACT_INLINE_DRAWING_XML','cause':'paragraph.clear removed drawing runs colocated with captions; visual contact review detected missing figures. Replaced from unchanged prior source and changed only text runs.','failed122page_draft_retained':True,'old_drawing_count':22,'faulty_draft_drawing_count':0,'restored_drawing_count':22,'drawing_XML_equal':True,'new_science':0},indent=2)+'\n','utf-8')
    print(json.dumps({'restored_exact_drawing_xml':22}))
if __name__=='__main__':main()
