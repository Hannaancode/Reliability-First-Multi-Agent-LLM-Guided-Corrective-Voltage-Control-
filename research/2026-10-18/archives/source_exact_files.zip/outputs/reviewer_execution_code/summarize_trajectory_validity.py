"""Aggregate existing independent physical replays; do not execute or select actions."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json

out = Path('outputs')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
bank = Path('work/e/bank/scenarios')
expected = {p.stem for p in bank.glob('*.json')}
paths = sorted((out / 'physical_replay_audit/cases').glob('*.json'))
assert len(expected) == 62 and {p.stem for p in paths} == expected
rows = []
aggregate = defaultdict(Counter)
for path in paths:
    record = json.loads(path.read_text())
    identity = record['identity']
    assert identity['saved_case_sha256'] == sha(out / 'matched_campaign/cases' / path.name)
    assert identity['scenario_sha256'] == sha(bank / path.name)
    assert identity['audit_source_sha256'] == sha('work/physical_replay_audit.py')
    assert identity['network_sha256'] == sha('work/e/pack/testbeds/federation_4mg_ieee118.json')
    assert set(record['branches']) == {'DFF', 'DFF-ALT', 'HG-VF'}
    for name, branch in record['branches'].items():
        assert branch['status'] == 'replayed', (path.name, name, branch['status'])
        states = branch['states']
        assert len(states) == branch['executed_action_count'] + 1
        assert [s['step'] for s in states] == list(range(len(states)))
        flags = {
            'nonfinite_active_bus_voltage': lambda s: bool(s['nonfinite_active_bus_ids']),
            'unserved_or_mismatched_load': lambda s: bool(s['unserved_or_mismatched_loads']),
            'hard_upper_voltage_strict': lambda s: s['voltage']['maximum'] > 1.06,
            'hard_upper_voltage_beyond_1e8': lambda s: s['voltage']['hard_ov_beyond_1e8_tolerance'] > 0,
            'thermal_above_100_percent': lambda s: any(v['above_100_percent'] for v in s['thermal'].values()),
            'thermal_above_declared_limit': lambda s: any(v['above_declared_loading_limit'] for v in s['thermal'].values()),
            'nonfinite_active_thermal_result': lambda s: any(v['nonfinite_active_indices'] for v in s['thermal'].values()),
            'generator_q_limit_violation': lambda s: bool(s['gen_q_limit_violations']),
            'slack_declared_limit_violation': lambda s: bool(s['ext_grid_declared_limit_violations']),
            'incremental_bus_q_cap_violation': lambda s: bool(s['incremental_shunt_cap_violations']),
            'incremental_total_q_budget_violation': lambda s: s['incremental_shunt_nominal_mvar_total'] > 7500 + 1e-8,
        }
        flagged = {key: [s['step'] for s in states if fn(s)] for key, fn in flags.items()}
        action_valid = branch['within_25_action_budget'] and all(
            a['single_shunt_action'] and a['within_actual_normalizer_25_mvar_grid_25_to_300']
            for a in branch['action_space_audit'])
        initial_valid = not flagged['nonfinite_active_bus_voltage'] and not flagged['unserved_or_mismatched_load']
        row = {'scenario_id': path.stem, 'branch': name, 'saved_replay_sha256': sha(path),
               'state_count_including_initial': len(states), 'action_count': branch['executed_action_count'],
               'all_states_have_finite_voltages_and_serve_scheduled_load': initial_valid,
               'action_count_and_actual_normalizer_grid_valid': action_valid,
               'continuous_terminal_metrics_match_1e10': branch['continuous_metrics_match_1e10'],
               'flagged_steps': flagged}
        rows.append(row)
        totals = aggregate[name]
        totals['trajectories'] += 1
        totals['states_including_initial'] += len(states)
        totals['finite_load_serving_trajectories'] += int(initial_valid)
        totals['action_grid_or_budget_invalid_trajectories'] += int(not action_valid)
        for key, steps in flagged.items():
            totals[key + '_trajectories'] += int(bool(steps))
            totals[key + '_states'] += len(steps)
        if initial_valid:
            totals['valid_trajectories_with_any_hard_upper_strict_violation'] += int(bool(flagged['hard_upper_voltage_strict']))
            totals['valid_trajectories_with_any_thermal_or_gen_q_violation'] += int(bool(flagged['thermal_above_declared_limit'] or flagged['generator_q_limit_violation']))
report = {'audited_case_count': len(paths), 'trajectory_count': len(rows),
          'all_replay_input_and_source_hashes_match': True,
          'aggregation_source_sha256': sha(__file__),
          'scope': 'All saved initial and accepted-action states from independent replay. Original hard threshold 1.06 is counted strictly and with separately declared 1e-8 diagnostic tolerance. No extra control actions or outcomes generated; no trajectory states omitted.',
          'branch_counts': {name: dict(counts) for name, counts in aggregate.items()}, 'rows': rows}
target = out / 'physical_trajectory_validity.json'
temporary = target.with_suffix('.tmp')
temporary.write_text(json.dumps(report, indent=2), encoding='utf-8')
temporary.replace(target)
print(json.dumps({k: v for k, v in report.items() if k != 'rows'}, indent=2))
