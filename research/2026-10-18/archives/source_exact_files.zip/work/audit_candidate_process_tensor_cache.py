"""Independent stored-mask/conditioning audit; zero model, optimizer or PF."""
import candidate_process_runtime
import gzip,json,math,statistics
from pathlib import Path
import torch
from candidate_process_evidence_utils import ROOT,read,sha,write
from candidate_predictor_input_contract import Q_GRID,group_for,validate_observation
from candidate_process_tensor_inputs import KINDS,NODE_FIELDS
BASE=ROOT/'outputs/llm_value_candidate_development_20261009';DATA=BASE/'input_and_target_contract_nullable_v2'
CACHE=BASE/'tensor_readiness_v2';SUPPORT=BASE/'current_added_support_observables';OUT=BASE/'tensor_external_audit'
assert not OUT.exists();OUT.mkdir();torch.set_num_threads(2)
for folder in (DATA,CACHE,SUPPORT):
    for n,m in read(folder/'manifest.json').items():assert sha(folder/n)==m['sha256'] and (folder/n).stat().st_size==m['bytes']
def rows(p):
    with gzip.open(p,'rt',encoding='utf-8') as f:return [json.loads(s) for s in f]
normal=read(DATA/'Input_Normalization.json');tn=read(CACHE/'Target_Normalization.json');nn=read(CACHE/'Node_Normalization.json')
inputs=rows(DATA/'Current_Input_Rows.jsonl.gz');labels=rows(DATA/'Measured_Target_Rows.jsonl.gz')
support={r['observation_id']:r['current_added_support_MVAr_by_bus'] for r in rows(SUPPORT/'Current_Control_State_Observables.jsonl.gz')}
keys={tuple(s):i for i,s in enumerate(normal['typed_semantic_schema'])}
current=mask=unknown=known_cap=regression=pairs=0
for row in inputs:
    ident=row['observation_id'];x=torch.load(CACHE/'inputs'/f'{ident}.pt',weights_only=True)
    assert set(x)=={'field_ids','kind','numeric','coordinates','value_bytes','node_features','adjacency','zone_ids','allowed_actions'}
    obs=row['model_input']['current_physical_observation'];records=validate_observation(obs)
    assert len(records)==len(x['field_ids'])
    for i,r in enumerate(records):
        key=group_for(obs,r['path']);assert int(x['field_ids'][i])==keys[(key,r['kind'])]
        assert int(x['kind'][i].argmax())==KINDS.index(r['kind']) and float(x['kind'][i].sum())==1.
        number=(r['value']-normal['numeric'][key]['mean'])/normal['numeric'][key]['scale'] if r['kind'] in ('int','float') else 0.
        assert float(x['numeric'][i,0])==float(torch.tensor(number,dtype=torch.float32))
        assert x['value_bytes'][i]==(list(r['value'].encode('utf-8')) if r['kind']=='str' else [])
    pools=set(b for p in obs['raw_common_and_zone_pools'].values() for b in p)
    expected=torch.tensor([[b in pools and support[ident][b]+q<=450. for q in Q_GRID] for b in range(118)])
    assert torch.equal(expected,x['allowed_actions']);current+=1
train_gains=[]
for row in labels:
    ident=row['observation_id'];x=torch.load(CACHE/'inputs'/f'{ident}.pt',weights_only=True)
    t=torch.load(CACHE/'targets'/f'{ident}.pt',weights_only=True)
    seen=torch.zeros(118,9,dtype=torch.bool)
    for c in row['measured_candidates']:
        raw=c['target'];b,j=raw['bus'],raw['Q_index'];assert not seen[b,j];seen[b,j]=True
        if not bool(x['allowed_actions'][b,j]):
            assert raw['recorded_verifier']['converged'] is None and not raw['recorded_verifier']['accepted']
            assert not bool(t['classification_mask'][b,j].any()) and not bool(t['regression_mask'][b,j].any());known_cap+=1;continue
        truth=[raw['recorded_verifier']['accepted'],raw['recorded_verifier']['converged'],raw['one_step_UV_zero']]
        for k,value in enumerate(truth):
            assert bool(t['classification_mask'][b,j,k])==(type(value)is bool)
            if type(value)is bool:assert float(t['classification'][b,j,k])==float(value);mask+=1
        assert bool(t['regression_mask'][b,j].all())==raw['has_finite_after_global_metrics']
        if raw['has_finite_after_global_metrics']:
            gains=[raw['measured_global_gains'][k] for k in tn['channels']]
            expected=torch.tensor([(v-tn['mean'][k])/tn['scale'][k] for k,v in enumerate(gains)])
            assert torch.equal(expected,t['regression'][b,j]);regression+=1
            if row['split']=='optimization':train_gains.append(gains)
        else:
            assert raw['one_step_UV_zero'] is None and not bool(t['classification_mask'][b,j,2]);unknown+=1
    assert not bool(t['classification_mask'][~seen].any()) and not bool(t['regression_mask'][~seen].any())
    pairs+=int((t['regression_mask'][:,:-1]&t['regression_mask'][:,1:]).sum())//4
for j in range(4):
    values=[s[j] for s in train_gains];mean=statistics.mean(values);std=statistics.pstdev(values)
    assert mean==tn['mean'][j] and std==tn['std'][j]
assert current==311 and known_cap==219 and unknown==60 and regression==38448 and pairs==34112
certificate={'all_passed':True,'exact_current_tensor_identities':current,'unique_candidate_labels_verified':38727,
 'masked_known_cap_rows':known_cap,'remaining_missing_after_unknown':unknown,'finite_gain_rows':regression,
 'actual_adjacent_Q_pairs':pairs,'optimization_only_target_normalization_verified':True,
 'typed_fields_all_reloaded_against_raw_values':True,'strict_no_label_or_identity_metadata_in_forward':True,
 'missing_UVzero_mask_verified_from_actual_unknown_rows':True,
 'cache_manifest_sha256':sha(CACHE/'manifest.json'),'source_sha256':sha(Path(__file__)),
 'new_model_optimizer_PF_controller_cloud_calls':0,'no_physical_policy_or_LLM_attribution_claim':True}
write(OUT/'Independent_Tensor_and_Target_Audit.json',certificate)
write(OUT/'manifest.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()})
print(json.dumps(certificate,indent=2))
