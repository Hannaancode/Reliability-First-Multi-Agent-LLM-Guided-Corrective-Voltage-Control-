"""Read-only all500 native-role packet preparation, no model/physics launch."""
import hashlib
import json
import pickle
import time
from datetime import datetime, timezone
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'outputs/paper_native13_causal_contract_v3_20261021'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def put(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)


def main():
    O.mkdir(exist_ok=False)
    started = time.monotonic()
    import stable_ddpg_native_bridge_20261020 as bridge
    import paper_native13_causal_contract_v2_20261021 as port
    from transformers import AutoTokenizer

    attempts = []

    def forbidden(*args, **kwargs):
        attempts.append('FORBIDDEN_NEW_SCIENTIFIC_CALL')
        raise AssertionError('This preparation cannot run physical/model science')

    bridge.pp.runpp = forbidden
    bridge.from_mpc = forbidden
    adapter = R / 'work/e/pack/models/zone_agent_shared_lora_qwen05b_ultra_v1'
    tokenizer = AutoTokenizer.from_pretrained(str(adapter), local_files_only=True, trust_remote_code=False)
    roots_path = R / 'outputs/public13_matched_numeric_preparation_20261021/All500_Audited_Exact_Roots.json'
    roots = json.loads(roots_path.read_text(encoding='utf-8'))['roots']
    assert [r['seed'] for r in roots] == list(range(500))
    numeric_protocol = json.loads((roots_path.parent / 'Protocol.json').read_text(encoding='utf-8'))
    graph_path = R / numeric_protocol['graph']
    assert sha(graph_path) == numeric_protocol['source_and_input_hashes'][numeric_protocol['graph']]
    graph = bridge.np.load(graph_path)
    saved_Y = graph['Y']
    rows = []
    graph_contracts = []
    counts = {'MODEL_INPUT_AVAILABLE': 0, 'EMPTY_ACTUATOR_ZONE_NO_MODEL_CALL': 0,
              'PAPER_UV_STOP_NO_MODEL_CALL': 0}
    max_tokens = 0
    all_contracts = set()
    for root in roots:
        path = R / root['path']
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == root['sha256']
        value = pickle.loads(raw)
        net = value['network'] if root['kind'] == 'ENV' else value
        pp = net._ppc
        assert bridge.np.array_equal(pp['branch'][:, :13], graph['branch'][:, :13])
        assert bridge.np.array_equal(pp['bus'][:, [0, 4, 5]], graph['bus'][:, [0, 4, 5]])
        assert float(pp['baseMVA']) == float(graph['baseMVA'])
        assert bridge.np.array_equal(net.bus.index.to_numpy(), bridge.np.arange(13))
        Y = saved_Y
        assert net.converged and len(net.bus) == 13
        contract = port.physical_contract(net.bus.index.to_numpy(), net.sgen.bus.to_numpy()[:3],
                                          int(net.ext_grid.bus.iloc[0]), Y)
        assert set(contract['actuator_buses']) == {2, 7, 9}
        frame = port.observation_frame(contract, net.res_bus.vm_pu.to_numpy(),
                                       net.sgen.q_mvar.to_numpy()[:3], 0)
        assert frame['current_VM'] == root['all13_initial_vm']
        assert frame['current_Q_Mvar'] == root['initial_control_Q']
        packets = []
        for zone in contract['zones']:
            packet = port.agent_packet(contract, frame, zone)
            counts[packet['disposition']] += 1
            if packet['messages'] is not None:
                encoded = tokenizer.apply_chat_template(packet['messages'], tokenize=True,
                                                         add_generation_prompt=True)
                ids = encoded['input_ids'] if hasattr(encoded, 'keys') else encoded
                assert isinstance(ids, list) and all(type(v) is int for v in ids)
                assert len(ids) + 384 <= 8192, 'No truncation or selective dropping allowed'
                packet.update(actual_input_ids=ids, input_tokens=len(ids))
                max_tokens = max(max_tokens, len(ids))
            packets.append(packet)
        digest = hashlib.sha256(json.dumps(contract, sort_keys=True).encode()).hexdigest()
        all_contracts.add(digest)
        graph_contracts.append({'seed': root['seed'], 'source_NET_sha256': root['sha256'],
                                'contract_sha256': digest, 'contract': contract})
        rows.append({'administrative_seed_NOT_in_prompt': root['seed'],
                     'source_NET': root['path'], 'source_NET_sha256': root['sha256'],
                     'frame': frame, 'packets': packets})
    assert len(all_contracts) == 1, 'Plant topology/namespace cannot change by outcomes'
    put(O / 'All500_Initial_Causal_Frames.json', rows)
    put(O / 'All500_Physical_Role_Contracts.json', graph_contracts)
    contract = graph_contracts[0]['contract']
    zone = next(z for z, buses in contract['allowed'].items() if 2 in buses)
    frame = port.observation_frame(contract, roots[0]['all13_initial_vm'], [2., 0., 0.], 1)
    checks = []

    def check(label, condition):
        assert condition, label
        checks.append(label)

    for amount in [.0001, .1, port.STEP_CAP]:
        admitted = port.admit_request({'bus': '2', 'q_mvar': amount}, contract, frame, zone)
        check(f'literal_increment_{amount}_above_nonzero_currentQ',
              admitted['valid'] and admitted['candidate_absolute_Q_Mvar'][0] > 2.
              and admitted['physical_verification_pending'])
    for label, parsed in [
        ('null', None), ('empty', {}), ('bare_list', []),
        ('malformed_bus', {'bus': 'not_an_int', 'q_mvar': .1}),
        ('negative_absorption_not_silently_enabled', {'bus': '2', 'q_mvar': -.1}),
        ('old25Mvar_not_scaled', {'bus': '2', 'q_mvar': 25.}),
        ('above_native_increment_not_clipped', {'bus': '2', 'q_mvar': port.STEP_CAP + 1e-9}),
        ('nan', {'bus': '2', 'q_mvar': float('nan')}),
        ('infinity', {'bus': '2', 'q_mvar': float('inf')}),
        ('uncontrolled_recipient', {'bus': '12', 'q_mvar': .1}),
        ('foreign_zone_recipient', {'bus': '7', 'q_mvar': .1}),
        ('float32_underflow', {'bus': '2', 'q_mvar': 1e-100}),
]:
        check(label, not port.admit_request(parsed, contract, frame, zone)['valid'])
    first_only = port.admit_request({'add_shunts_q_mvar': {'2': .1, '7': .1}}, contract, frame, zone)
    check('original_first_valid_recipient_semantics_preserved_and_disclosed', first_only['valid'] and first_only['bus'] == 2 and sum(v != 0 for v in first_only['native_u']) == 1)
    history = {'round': 0, 'zone': zone, 'bus': 2, 'increment_Mvar': .1,
               'accepted': False, 'reason': 'normal_band_protection'}
    with_history = port.observation_frame(contract, roots[0]['all13_initial_vm'], [2., 0., 0.], 1, [history])
    check('past_feedback_preserved', with_history['causal_request_history'] == [history])
    for label, record in [('future_feedback_rejected', dict(history, round=1)),
                          ('teacher_coverage_key_rejected', dict(history, teacher_success=True))]:
        try:
            port.observation_frame(contract, roots[0]['all13_initial_vm'], [2., 0., 0.], 1, [record])
        except ValueError:
            check(label, True)
        else:
            raise AssertionError(label)
    check('packet_JSON_cold_roundtrip', json.loads(json.dumps(rows[0])) == rows[0])
    check('zero_new_forbidden_science_calls', not attempts)
    normalizer, proof = port.native_unit_normalizer()
    sources = {p: sha(R / p) for p in [
        'work/paper_native13_causal_contract_v2_20261021.py',
        'work/prepare_paper_native13_causal_contract_v3_20261021.py',
        'work/check_native_parser_contract_v3_20261021.py',
        'work/e/audit/phase2g_rescue_runner.py']}
    tokenizer_files = {p.name: sha(p) for p in adapter.iterdir()
                       if p.is_file() and p.name in {'tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json'}}
    result = {'at_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PASS_ALL500_CAUSAL_INITIAL_INPUT_AND_POSITIVE_LITERAL_NATIVE_ROLE_SOFTWARE_ONLY',
              'port': port.PORT_NAME, 'source_roots_sha256': sha(roots_path),
              'saved_Y_anchor': {'path': numeric_protocol['graph'], 'sha256': sha(graph_path), 'all500_branch_bus_baseMVA_binding': True},
              'original_empty_Y_software_failure_preserved': 'outputs/paper_native13_causal_contract_20261021/Failure.json',
              'all_registered_cases': 500, 'all_zone_frames': len(rows) * 4,
              'input_dispositions': counts, 'one_outcome_independent_topology_partition': True,
              'maximum_actual_input_tokens': max_tokens, 'input_plus384_within8192': True,
              'original_training_context512_not_silently_replicated': True,
              'boundary_checks': checks, 'parser_AST_adaptation': proof,
              'source_hashes': sources, 'actual_tokenizer_file_hashes': tokenizer_files,
              'new_model_PF_conversion_derivative_LP_training_optimizer_GPU_calls': 0,
              'preparation_seconds': time.monotonic() - started,
              'NOT_READY': ['Complete router/refinement/fallback/reflection/two-branch native policy',
                            'Prospective inference/physics and equally informed trained noLLM controls',
                            'Actual original adapter/base/context/cold integration and full persistent runtime',
                            'Scientific independent owner/reader/cost/unused-confirmation gates'],
              'lost_earlier_software_encoding_calls_separately_paid': 696,
              'v2_expectation_failure_preserved': 'outputs/paper_native13_causal_contract_v2_20261021/Failure.json',
              'original_normalizer_multi_recipient_semantics': 'First valid recipient only, preserving source break. Raw and normalized model outputs must both be retained by eventual runtime.',
              'limitations': ['Named positive-only unit/hardware/partition/prompt port, not unchanged paper.',
                              'Original UV-only stop leaves OV-only inputs with no original-branch model call; they remain in full-grid denominators.',
                              'Negative absorption remains unsupported, never repaired using a numerical action labelled as LLM.',
                              'Packet JSON cold roundtrip is not controller/process recovery or physical trajectory validation.',
                              'Past verdict values still require real receipt anchoring by the eventual runtime.',
                              'All500 roots are inspected development; this is not performance or learning evidence.']}
    put(O / 'Software_Input_Admission.json', result)
    print(json.dumps({k: result[k] for k in ['status', 'all_registered_cases', 'all_zone_frames',
                                            'input_dispositions', 'maximum_actual_input_tokens',
                                            'new_model_PF_conversion_derivative_LP_training_optimizer_GPU_calls']}))


if __name__ == '__main__':
    main()
