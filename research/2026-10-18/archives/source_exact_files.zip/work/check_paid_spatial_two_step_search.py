"""Labelled synthetic causal/search checks; zero physics/model calls."""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from paid_spatial_two_step_search import Receipt, IncompleteEvidence, two_step

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/critical_research_reset_20261010/spatial_two_step_software_20261011'

def metrics(uv, deficit=None):
    return dict(uv_count=uv, deficit_sum=uv*.01 if deficit is None else deficit,
                vmin=.93 if uv else .96, vmax=1.04)

def fixture():
    # Immediate greedy gets 5UV; alternative gets 6UV but permits 1UV later.
    menus={'r':('a','b'),'sa':('x',),'sb':('y',)}
    rows={('r','a'):Receipt('r','a',True,True,'sa',metrics(5),(5,)),
          ('r','b'):Receipt('r','b',True,True,'sb',metrics(6),(4,)),
          ('sa','x'):Receipt('sa','x',True,False,None,None,None),
          ('sb','y'):Receipt('sb','y',True,True,'sy',metrics(1),(5,))}
    calls=[]
    def query(p,a):calls.append((p,a));return rows[(p,a)]
    return menus,rows,calls,query

def main():
    OUT.mkdir(exist_ok=False); checks=[]
    def check(name, condition):
        assert condition,name
        checks.append(name)
    m,r,c,q=fixture()
    full=two_step('r',metrics(10),25,m.__getitem__,q)
    check('non_greedy_spatial_successor_can_win_in_labelled_fixture',full['first']=='b' and full['measured_leaf']['uv_count']==1)
    check('all_paid_identities_called_once',c==[('r','a'),('r','b'),('sa','x'),('sb','y')] and full['queries']==4)
    m,r,c,q=fixture();g=two_step('r',metrics(10),25,m.__getitem__,q,mode='greedy')
    check('greedy_does_not_receive_unqueried_alternative_successor',g['first']=='a' and ('sb','y') not in c)
    m,r,c,q=fixture();b=two_step('r',metrics(10),25,m.__getitem__,q,mode='fixed_beam',width=1)
    check('fixed_width_is_not_expanded_after_bad_outcome',b['first']=='a' and b['queries']==3)
    m,r,c,q=fixture();one=two_step('r',metrics(10),1,m.__getitem__,q)
    check('one_remaining_slot_never_queries_second_horizon',len(c)==2 and one['second'] is None)
    m,r,c,q=fixture();stop=two_step('r',metrics(0),25,m.__getitem__,q)
    check('healthy_root_has_no_queries',not c and stop['first'] is None)
    m,r,c,q=fixture();r[('sb','y')]=Receipt('sb','y',False,None,None,None,None)
    try:two_step('r',metrics(10),25,m.__getitem__,q)
    except IncompleteEvidence:checks.append('missing_later_receipt_aborts_not_negative')
    else:raise AssertionError('Missing receipt accepted')
    m,r,c,q=fixture();r[('r','b')]=Receipt('other','b',True,True,'sb',metrics(6),(4,))
    try:two_step('r',metrics(10),25,m.__getitem__,q)
    except IncompleteEvidence:checks.append('wrong_parent_receipt_rejected')
    else:raise AssertionError('Wrong parent accepted')
    m,r,c,q=fixture();bad=metrics(6);bad['vmax']=1.05000002;r[('r','b')]=Receipt('r','b',True,True,'sb',bad,(4,))
    try:two_step('r',metrics(10),25,m.__getitem__,q)
    except IncompleteEvidence:checks.append('upper_band_violation_rejected')
    else:raise AssertionError('Unsafe accepted')
    m,r,c,q=fixture();r[('r','b')]=Receipt('r','b',True,True,None,metrics(6),(4,))
    try:two_step('r',metrics(10),25,m.__getitem__,q)
    except IncompleteEvidence:checks.append('missing_successor_not_replaced_by_metrics')
    else:raise AssertionError('Missing successor accepted')
    m,r,c,q=fixture();r[('r','b')]=Receipt('r','b',True,True,'sb',metrics(5),(5,))
    tie=two_step('r',metrics(10),1,m.__getitem__,q)
    check('exact_tie_retains_native_order',tie['first']=='a')
    result={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'all_passed':True,
            'labelled_synthetic_checks':checks,'check_count':len(checks),
            'actual_PF_model_optimizer_controller_forecast_calls':0,
            'source_sha256':hashlib.sha256((ROOT/'work/paid_spatial_two_step_search.py').read_bytes()).hexdigest(),
            'limitations':['Callbacks NOT yet bound to real native menu/solver/caps/process/full-field storage.',
                          'Fixtures show orchestration only, not physical opportunity or LLM value.',
                          'Full depth2 numerical control is a ceiling for any same-information depth2 scorer after all leaves are paid.',
                          'Two-step leaf UV is not 25-step terminal improvement; no automatic learning launch.']}
    with (OUT/'Software_Readiness.json').open('x',encoding='utf8') as f:
        json.dump(result,f,indent=2);f.flush();os.fsync(f.fileno())
    print(json.dumps({'passed':len(checks),'new_scientific_calls':0,'actual_physics_integration':False}))
if __name__=='__main__':main()
