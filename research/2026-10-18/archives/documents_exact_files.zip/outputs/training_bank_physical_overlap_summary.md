# Saved training inputs and locked-bank overlap

Physical modifications compared against the same frozen system, not scenario names or timestamps. Grouped split inputs recovered from an actual Desktop experiment ZIP. The exact training invocation/data hash of the final ultra_v1 adapter is not encoded in the recovered model card/trainer state; these files establish archived-input provenance, not a cryptographically proven complete adapter training lineage.

Saved splits contain 109 training, 13 validation, and 15 test physical scenario IDs. JSONL record counts are train: 16000, val: 2000, test: 2000. Exact physical modification overlap is 0/62 with saved training and 0/62 with all 141 recovered historical scenarios. 62/62 share an outage/DER pattern with saved training.

Post-training held-out load operating points in the same network and contingency construction; do not claim unseen outage families, cross-grid transfer, or broad OOD generalization. Linguistic record count is not number of independent physical scenarios.
