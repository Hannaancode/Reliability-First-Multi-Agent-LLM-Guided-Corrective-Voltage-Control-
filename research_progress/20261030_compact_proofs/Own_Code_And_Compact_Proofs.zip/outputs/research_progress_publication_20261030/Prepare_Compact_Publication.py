"""Prepare an explicit compact publication; never edits master state or contacts GitHub.

Default inspection creates only a bounded planning report. Final freeze requires
parent-issued authorization binding this source, the allowlist and every selected
file's current SHA256. No directory walking or dependency traversal is used.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, ast, hashlib, io, json, re, zipfile
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
ALLOW=O/'Publication_Allowlist.json'
FINAL_NAMES=['Own_Code_And_Compact_Proofs.zip','Artifact_Index.json','Exact_Resume.json','Progress.txt','Prepared_Files.json']
TEXT_EXTENSIONS={'.py','.json','.md','.txt','.claim','.log'}
DENY_PARTS={'physics_env','site-packages','node_modules','.git','.venv','venv','__pycache__','isolated_owner_dependencies_20261030','owner_runtime_dependencies_20261030'}
RAW_KEYS={'question','answer','prompt','response','messages','conversation','retrieved_context','question_text','gold_answer','reference_answer','raw_answer','raw_prompt','full_prompt','raw_response','raw_transcript','qa_transcript','checkpoint_payload','net_pickle','ndarray_data','v_current','y_bus'}
SECRET_KEYS={'api_key','access_token','refresh_token','password','client_secret','private_key','secret_key','authorization'}
SECRET_PATTERNS={
 'github_token':re.compile(r'\bgh[pousr]_[A-Za-z0-9]{20,}\b|\bgithub_pat_[A-Za-z0-9_]{30,}\b'),
 'aws_access_key':re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
 'private_key':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
 'credential_in_url':re.compile(r'https?://[^\s/@:]+:[^\s/@]+@'),
 'literal_bearer':re.compile(r'(?i)bearer\s+[A-Za-z0-9_.-]{24,}')}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def put(name,obj):
 with (O/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
def safe_source(relative):
 if not isinstance(relative,str) or '\\' in relative or any(x in relative for x in '*?[]'):
  raise ValueError('Source must be an explicit POSIX relative path')
 q=PurePosixPath(relative)
 if q.is_absolute() or '..' in q.parts:raise ValueError('Invalid source path')
 p=R.joinpath(*q.parts);resolved=p.resolve();resolved.relative_to(R.resolve())
 if p.is_symlink() or any(x.lower() in DENY_PARTS for x in q.parts+PurePosixPath(resolved.relative_to(R).as_posix()).parts):
  raise ValueError('Dependency/alias path prohibited')
 if 'local_only' in p.name.lower() or p.suffix.lower() not in TEXT_EXTENSIONS:
  raise ValueError('Raw/binary/unapproved source prohibited')
 if re.search(r'(?:^|/)(?:nonlinear500_receding_acquisition(?:_v[0-9]+)?_execution_20261030)(?:/|$)',relative):
  raise ValueError('Live scientific output directories are prohibited')
 return p

def sensitive_literal(value):
 return isinstance(value,str) and len(value)>=12 and not any(x.isspace() for x in value) and value.upper() not in {'UNKNOWN','NOT_RECORDED','NOT_APPLICABLE','REDACTED','PLACEHOLDER'}

def scan_content(path,raw):
 text=raw.decode('utf-8-sig');hits=[]
 for rule,pattern in SECRET_PATTERNS.items():
  for match in pattern.finditer(text):hits.append({'rule':rule,'line':text.count('\n',0,match.start())+1})
 def check_json(value,where='$'):
  if isinstance(value,dict):
   for key,child in value.items():
    key=str(key);lower=key.lower();loc=where+'.'+key
    if lower in RAW_KEYS and child not in (None,'',[],{}):hits.append({'rule':'embedded_raw_or_state_field','location':loc})
    if lower in SECRET_KEYS and sensitive_literal(child):hits.append({'rule':'sensitive_literal_value','location':loc})
    check_json(child,loc)
  elif isinstance(value,list):
   for i,child in enumerate(value):check_json(child,f'{where}[{i}]')
 if path.suffix.lower()=='.json':check_json(json.loads(text))
 if path.suffix.lower()=='.py':
  tree=ast.parse(text)
  for node in ast.walk(tree):
   if isinstance(node,ast.Assign) and isinstance(node.value,ast.Constant):
    for target in node.targets:
     if isinstance(target,ast.Name) and target.id.lower() in SECRET_KEYS and sensitive_literal(node.value.value):
      hits.append({'rule':'code_sensitive_literal','line':node.lineno})
   if isinstance(node,ast.Dict):
    for key,value in zip(node.keys,node.values):
     if isinstance(key,ast.Constant) and isinstance(key.value,str) and key.value.lower() in RAW_KEYS and isinstance(value,ast.Constant) and isinstance(value.value,str) and len(value.value)>80:
      hits.append({'rule':'code_embedded_raw_example','line':value.lineno})
 return hits

def inspect_sources(allow):
 seen=set();members=[];payloads={};issues=[];total=0
 for entry in allow['entries']:
  relative=entry['path']
  if relative in seen:raise ValueError('Duplicate allowlist source: '+relative)
  seen.add(relative);p=safe_source(relative)
  if not p.is_file():
   issues.append({'path':relative,'rule':'missing_required_source'});continue
  size=p.stat().st_size
  if size>entry['max_bytes']:
   issues.append({'path':relative,'rule':'individual_size_cap','bytes':size,'cap':entry['max_bytes']});continue
  raw=p.read_bytes();total+=len(raw)
  for hit in scan_content(p,raw):issues.append({'path':relative,**hit})
  members.append({'path':relative,'bytes':len(raw),'sha256':digest(raw),'category':entry['category']})
  payloads[relative]=raw
 if total>allow['total_uncompressed_source_byte_cap']:issues.append({'rule':'fixed_total_source_byte_cap','bytes':total,'cap':allow['total_uncompressed_source_byte_cap']})
 return members,payloads,issues,total

def archive_bytes(payloads):
 stream=io.BytesIO()
 with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name in sorted(payloads):
   info=zipfile.ZipInfo(name,date_time=(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(info,payloads[name])
 result=stream.getvalue()
 with zipfile.ZipFile(io.BytesIO(result)) as z:
  assert z.testzip() is None and set(z.namelist())==set(payloads)
  assert all(z.read(k)==v for k,v in payloads.items())
 return result

def freeze(allow,members,payloads,issues,authorization_path):
 if authorization_path is None:raise ValueError('Parent readiness authorization is required; preparation is not authorization')
 authpath=(O/authorization_path).resolve();authpath.relative_to(O.resolve())
 auth=json.loads(authpath.read_text(encoding='utf-8'))
 assert auth['status']=='PARENT_CONFIRMED_CURRENT_RESUME_AND_V2_SOURCES_READY'
 assert auth['allowlist_sha256']==digest(ALLOW.read_bytes())
 assert auth['snapshot_builder_sha256']==digest(Path(__file__).read_bytes())
 assert auth['source_sha256_by_path']=={x['path']:x['sha256'] for x in members},'Every selected source must match the parent-confirmed bytes'
 assert auth['exact_resume_source']==allow['exact_resume_source']
 assert isinstance(auth['confirmed_at_utc'],str) and auth['confirmed_at_utc']
 if issues:raise ValueError('Inspection issues prevent freezing; inspect issue metadata without publishing contents')
 for name in FINAL_NAMES:
  if (O/name).exists():raise FileExistsError('Existing frozen artifact is retained: '+name)
 for member in members:
  assert digest(safe_source(member['path']).read_bytes())==member['sha256'],'Source changed since inspection'
 archive=archive_bytes(payloads)
 resume=payloads[allow['exact_resume_source']];resume_object=json.loads(resume.decode('utf-8-sig'))
 progress=('Compact proof publication for30October2026\n'
  'Own code, bounded generated proofs, retained pre-entry failure evidence, and exact task/resume copies.\n'
  'This is not a raw backup, full scientific release, new experiment or claim of completed final goals.\n'
  'Excluded: rawQA/transcripts,NET/NPZ/checkpoints/fullDOCX,dependencies/credentials and live scientific outputs.\n'
  'Exact resume source: '+allow['exact_resume_source']+'\n'
  'Exact resume status: '+str(resume_object.get('status','FIELD_ABSENT_NO_INFERENCE'))+'\n'
  'Historical raw evidence referenced by proofs remains local; publication references do not imply its inclusion.\n').encode('utf-8')
 index={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'FROZEN_LOCAL_COMPACT_PROOF_SNAPSHOT_NOT_PUBLISHED',
  'scope':allow['publication_scope'],'members':members,'archive_sha256':digest(archive),
  'archive_member_bytes':sum(x['bytes'] for x in members),'allowlist_sha256':digest(ALLOW.read_bytes()),
  'builder_sha256':digest(Path(__file__).read_bytes()),'parent_readiness_authorization_sha256':digest(authpath.read_bytes()),
  'exact_resume_source':allow['exact_resume_source'],'exact_resume_sha256':digest(resume),
  'no_complete_raw_backup_claim':True,'published_to_GitHub':False}
 indexraw=(json.dumps(index,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
 outputs={'Own_Code_And_Compact_Proofs.zip':archive,'Artifact_Index.json':indexraw,'Exact_Resume.json':resume,'Progress.txt':progress}
 for name,raw in outputs.items():
  with (O/name).open('xb') as f:f.write(raw)
 prepared=[]
 for name,raw in outputs.items():
  assert (O/name).read_bytes()==raw
  prepared.append({'local':(O/name).relative_to(R).as_posix(),'path':allow['remote_prefix']+'/'+name,'bytes':len(raw),'sha256':digest(raw),'blob':blob(raw)})
 put('Prepared_Files.json',{'files':prepared})
 return {'status':'FROZEN_LOCAL_ONLY_PARENT_MUST_PUBLISH_AND_VERIFY','files':len(prepared),'members':len(members),'network_calls':0,'master_files_modified':False}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--freeze',action='store_true');ap.add_argument('--authorization');ap.add_argument('--label',default='prepared')
 args=ap.parse_args();allow=json.loads(ALLOW.read_text(encoding='utf-8'))
 if args.freeze and args.authorization is None:raise ValueError('No final pack permitted without parent readiness authorization')
 if not re.fullmatch(r'[A-Za-z0-9_-]+',args.label):raise ValueError('Invalid inspection label')
 members,payloads,issues,total=inspect_sources(allow)
 if args.freeze:result=freeze(allow,members,payloads,issues,args.authorization)
 else:
  result={'status':'PREPARED_INSPECTION_PASS_NOT_FROZEN' if not issues else 'PREPARED_INSPECTION_HAS_BLOCKERS_NOT_FROZEN',
   'allowlist_sha256':digest(ALLOW.read_bytes()),'builder_sha256':digest(Path(__file__).read_bytes()),
   'source_members_observed':members,'total_observed_bytes':total,'issues':issues,
   'final_archive_or_Artifact_Index_or_Prepared_Files_created':False,'scope':allow['publication_scope'],
   'parent_confirmation_of_final_resume_and_v2_sources_received':False,
   'master_files_modified':False,'network_calls':0,
   'scan_limit':'Known-pattern and structured-field checks plus human review of selected content; not a proof that arbitrary secrets cannot exist.'}
  put('Inspection_'+args.label+'.json',result)
 print(json.dumps({k:v for k,v in result.items() if k not in {'source_members_observed'}}))
if __name__=='__main__':main()
