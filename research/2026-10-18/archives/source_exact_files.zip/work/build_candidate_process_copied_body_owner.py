"""Additive, AST-checked adaptation of the proved single-assignment collector."""
from pathlib import Path
import ast
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'work/run_vcsa_pretrained_pilot_colab_20261008.py').read_text()
def swap(old,new,count=1):
    global source
    assert source.count(old)==count,(old,source.count(old),count)
    source=source.replace(old,new)
swap("PREP=ROOT/'outputs/vcsa_development/pretrained_pilot_preparation'","PREP=ROOT/'outputs/llm_value_candidate_development_20261009/copied_body_integration_preparation'")
swap("OUT=ROOT/'outputs/vcsa_development/pretrained_pilot_execution'","OUT=ROOT/'outputs/llm_value_candidate_development_20261009/copied_body_integration_execution'")
swap("Pretrained_Pilot_Cloud_Payload_Manifest_20261008.json","Cloud_Payload_Manifest.json")
swap("assert read(ROOT/'outputs/vcsa_development/framework_execution_memory_20261008/Memory_Integration_Independent_Audit_20261008.json')['passed']\n assert read(ROOT/'outputs/vcsa_development/trainer_v4_journal_software_fixtures/summary.json')['passed']\n assert read(ROOT/'outputs/vcsa_development/checkpoint_replay_v2_journal_software_fixtures/summary.json')['passed']",
 "assert read(PREP/'Launch_Readiness_Audit.json')['passed']\n assert sha((ROOT/'outputs/overnight_research_authorization_20261009.json').read_bytes())==payload['direct_human_overnight_authority_record_sha256']\n for name,digest in read(PREP/'Launch_Readiness_Audit.json')['source_hashes'].items():assert sha((ROOT/name).read_bytes())==digest")
swap("if not name.endswith('_events.jsonl'):continue","if name!='events.jsonl':continue")
swap("if event['event']!='epoch_checkpoint_preserved':continue\n   relative=event['variant']+'/'+event['checkpoint'];target=OUT/'early_epoch_preservation'/relative",
 "if event['event']!='optimizer_step_and_checkpoint_preserved':continue\n   relative=event['checkpoint'];target=OUT/'early_epoch_preservation'/relative")
swap("VCSA_PILOT_INPUT_MANIFEST.json","CANDIDATE_PROCESS_INPUT_MANIFEST.json")
swap("setup=setup.replace('uv==0.8.22','uv=='+(ROOT/'work/uv_bootstrap_version.txt').read_text().strip())",
 "setup=setup.replace('uv==0.8.22','uv=='+(ROOT/'work/uv_bootstrap_version.txt').read_text().strip())\n setup=setup.replace('work/remote_environment_check.py','work/candidate_process_remote_environment_check.py')\n ast.parse(setup)")
swap("assert read(OUT/'staged/remote_frozen_environment.json')==read(ROOT/'outputs/remote_frozen_environment.json')",
 "assert read(OUT/'staged/remote_frozen_environment.json')==read(PREP/'Expected_Environment.json')")
swap("work/vcsa_pretrained_pilot_remote_20261008.py","work/candidate_process_copied_body_integration_remote.py")
swap(" result=p.wait()", " try:result=p.wait(timeout=1200)\n except subprocess.TimeoutExpired:\n  p.terminate()\n  try:result=p.wait(timeout=30)\n  except subprocess.TimeoutExpired:p.kill();result=p.wait()\n  Path('outputs/pilot_timeout_preserved.json').write_text(json.dumps({'actual_pid':p.pid,'bound_seconds':1200,'scientific_restart':False}))")
swap("outputs/vcsa_development/pretrained_pilot_model_study","outputs/llm_value_candidate_development_20261009/copied_body_integration_science",2)
swap("members={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in root.rglob('*') if p.is_file()}",
 "members={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in root.rglob('*') if p.is_file()} if root.exists() else {}")
swap("pool.submit(execute,launch,3600)","pool.submit(execute,launch,1350)")
swap("while time.monotonic()-began<3600:","while time.monotonic()-began<1350:")
swap("assert read(OUT/'staged/study/summary.json')['completed']","assert read(OUT/'staged/study/summary.json')['all_genuine_integration_gates_passed']")
swap("session_name='hiergrid-fixed-vcsa-pilot'","session_name='hiergrid-copied-body-integration'")
swap("stage='fixed_two_arm_real_model_pilot'","stage='genuine_two_step_copied_body_integration'")
swap('"""One owned selected-profile T4: fixed two-arm pilot, incremental preservation.',
 '"""One owned selected-profile T4: two-step copied-body integration, preservation.')
ast.parse(source)
tree=ast.parse(source)
launch=next(n.value.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='launch' for x in n.targets))
ast.parse(launch)
target=ROOT/'work/run_candidate_process_copied_body_colab.py'
with target.open('x') as file:file.write(source)
print('OWNER_AND_LITERAL_REMOTE_LAUNCH_AST_PARSED_NO_CLOUD_CALLS')
