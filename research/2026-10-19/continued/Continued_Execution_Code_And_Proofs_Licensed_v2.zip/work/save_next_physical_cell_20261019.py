"""Preserve next fixed-policy physical gap and scope checks; ZERO new science.

All last-menu identities are retained. This does not launch a scientific owner
or silently feed a new arity into the completed three-query executor.
"""
import copy,gzip,hashlib,json,os,pickle,zlib
from datetime import datetime,timezone
from pathlib import Path
from public118_slsqp_native_20261018 import R,read,put,sha,manifest
from equal_operation_benchmark_v2 import process,decode_capsule
from prior_physical_query_footprints_20261018 import component
from audit_prior_physical_query_footprints_20261018 import independent_component
from compile_lookahead_paid_input_cache_20261014 import point_key,action_key
from fixed_three_query_core_20261019 import known_keys,B as THREE
from frozen_physics_loader import load_stack
from joint_reallocation_opportunity_core_v1 import build_verifier,action
from candidate_process_evidence_utils import seal
from prepare_github_research_snapshot_20261018 import SECRET,SECRET_NAME
SCREEN=R/'outputs/fixed_receipt_next_context_screen_20261019'
B=R/'outputs/next_fixed_physical_cell_20261019'
def atomic(path,value):
    t=path.with_name(path.name+'.new')
    with t.open('w',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(t,path)
def main():
    B.mkdir(exist_ok=False);at=datetime.now(timezone.utc).isoformat();owner=read(SCREEN/'owner.claim');assert process(owner['actual_pid']) is None and process(owner['parent_pid']) is None
    result=read(SCREEN/'Results.json');assert result['new_model_PF_optimizer_derivative_forecast_solve_calls']==0 and result['old_full_four_world_physical_gate']=='UNKNOWN'
    for n in ('public_derivative_attempts','LU_factor_attempts','LU_solve_attempts','new_forecasts'):assert result['numeric_costs'][n]==0
    for rel,h in read(SCREEN/'Closed_Manifest.json')['members'].items():assert sha(SCREEN/rel)==h
    leg=read(SCREEN/'Leg_1.json');assert leg['status']=='UNKNOWN_UnknownLineageIdentity';ref=leg['frontier_input'];enc=(SCREEN/ref['path']).read_bytes();raw=zlib.decompress(enc)
    assert hashlib.sha256(enc).hexdigest()==ref['encoded_sha256'] and hashlib.sha256(raw).hexdigest()==ref['raw_sha256'];state=pickle.loads(raw)
    point=point_key(state['net'],state['cursor']);assert point+'|'+action_key(state['row'])==state['key']
    menus=[];previous='0'*64;queries=0;protocol=sha(SCREEN/'Protocol.json')
    with (SCREEN/'scientific.jsonl').open('rb') as f:
        for line in f:
            e=json.loads(line);assert e['previous_sha256']==previous and e['protocol_sha256']==protocol;previous=hashlib.sha256(line[:-1]).hexdigest()
            assert e['event'] not in ('PF_intent','PF_return','PF_exception')
            if e['event']=='every_query_receipt_closed_before_more_science':queries+=1
            if e['event']=='second_causal_context_and_forecasts' and e['data']['parent']==state['parent']:menus.append(e['data'])
    assert len(menus)==1;menu=menus[0];keys=known_keys()|{v['point_action_key'] for v in read(THREE/'Protocol.json')['exact_new_query_rows']}
    rows={action_key(v):{k:v[k] for k in ('kind','receiver','q','donor_index','donor_bus','universe_index')} for v in menu['rows']}
    oldbase=R/'outputs/prior_physical_query_footprints_20261018/actual';path=oldbase/'Physical_Component_Input_References.json.gz';expected=read(oldbase/'Closed_Manifest.json')['members'][path.name];expected=expected['sha256'] if isinstance(expected,dict) else expected
    assert sha(path)==expected;old=json.loads(gzip.decompress(path.read_bytes()))
    static=R/'outputs/fresh_static_component_index_20261018';assert sha(static/'All_Static_Component_References.json.gz')==read(static/'Results.json')['index_sha256'];observed=json.loads(gzip.decompress((static/'All_Static_Component_References.json.gz').read_bytes()))
    recent=[]
    two=R/'outputs/exact_two_paid_query_engineering_20261018'
    for root,phases in ((two,('warm','cold')),(THREE,('warm','cold_1','cold_2'))):
        for phase in phases:
            with (root/phase/'capsules.bin').open('rb') as pack:
                for line in (root/phase/'scientific.jsonl').read_bytes().splitlines():
                    e=json.loads(line)
                    if e['event']=='PF_intent':
                        native=decode_capsule(pack,e['data']['before'])['net'];h,_=component(native);assert independent_component(native)==h;recent.append(h)
    assert len(recent)==10;_,runner,_=load_stack();_,actuate,cert=build_verifier(runner.rescue,state['cursor']);declared=[];pending=[]
    for rank,aid in enumerate(menu['selected_ids'],1):
        row=rows[aid];key=point+'|'+aid;item={'fixed_rank':rank,'row':row,'point_action_key':key,'already_paid':key in keys}
        if key not in keys:
            native=actuate(copy.deepcopy(state['net']),action(row));h,values=component(native);assert independent_component(native)==h
            item.update(component_sha256=h,perbus_rational_component=values,tracked_BEFORE_matches=len(old.get(h,[])),static_observed_matches=len(observed.get(h,[])),recent10_BEFORE_matches=recent.count(h),prior_matching_references=old.get(h,[]))
            pending.append(item)
        declared.append(item)
    assert pending and pending[0]['point_action_key']==state['key']
    data={'status':'EXACT_NEXT_POLICY_MENU_PREPARED_NOT_NEW_SCIENCE_PERMISSION','at_utc':at,'point':point,'parent':state['parent'],'current_metrics':runner.rescue.grid_metrics(state['net']),
        'remaining_original_operations':state['cursor']['remaining_original_device_operation_slots'],'context_identity':menu['context_identity'],'all4_pre_physics_menu':declared,'all_unexecuted_original_menu_queries':pending,
        'current_input':{'path':str((SCREEN/ref['path']).relative_to(R)),'encoded_sha256':ref['encoded_sha256'],'raw_sha256':ref['raw_sha256']},'native_verifier_certificate':cert,
        'source_menu_journal_sha256':sha(SCREEN/'scientific.jsonl'),'closed_readonly_query_messages':queries,'full_four_world_gate':'UNKNOWN','new_model_PF_derivative_forecast_solve_calls':0,
        'required_next_gate':'New prospective owner/reader/source/persistent cold/ownership/full-cost protocol at this exact arity, preserving prior scopes/actions/9Q/cap450/no-refund/stock/normalupper1.05+1e-8/score/operationbudget. Existing executor is THREE-only; no silent arity change.',
        'scope_limits':'60426trackedBEFORE,3418staticAFTER observations and10recentquery/replayBEFOREs. Not universal unlogged history or automatic PF authority. Any positive component hit needs exact full-native-input/kwargs classification; never repeat to resolve uncertainty.',
        'selection':'ALL remaining originalK4 menu members in numerical order from the just-completed causal context; no outcome-selected action/Q/width/seed/threshold.'}
    put(B/'Exact_Next_Cell.json',data)
    next_steps=['All actors ended. Waiting timerhiergrid-next-context-result-check was deleted after terminal; noGPU or active timers.',
        'Read this exact next-cell file and Current_Resume. Continue the SAME frozen policy; no restarts/repeated science or already-solved zeroUVterminal queries.',
        'Prepare additive reservation/worker/reader phase-count gates for exactly '+str(len(pending))+'new identities, not a silent use of THREE-only APIs. Freeze before outcomes; all selected rows/known paid rows retained. Scope component-zero checks are prerequisites, not launch authority.',
        'If any target component matches an old input, classify exact nativeNET/kwargs and current resources before any rawPF reuse; unsupported staysUNKNOWN. No newPF to settle old-attempt ambiguity.',
        'Only launch genuinely unexecuted exact identities after actual source/native-verifier/persistent state/complete cold/source-claim/independent-reader/full-cost gates. Each converged query gets its explicitly charged independent replay; all failures/unknowns preserved. No automatic GPU or scientific retries.',
        'All6finalgoalsOPEN. Safe17to14 today is conditional query evidence, not a new actual commit/complete protected trajectory/DSE/LLM superiority. Preserve all141roster,70unknowninitials, original62bank/frozenassets and FULL BOTH DSEcosts/strongcontrols/unusedconfirmation.']
    (B/'Next_Execution.md').write_text('# Exact next fixed-policy cell\n\n'+'\n\n'.join(f'{i}. {v}' for i,v in enumerate(next_steps,1))+'\n','utf-8')
    current=THREE/'verified_completion/Current_Resume_20261019.json';resume=read(current);resume.update(at_utc=at,status='ALL_WORK_TERMINAL_NEW_PHYSICAL_GAP_PREPARED_PENDING_EXACT_ARITY_PROTOCOL',
        active_analysis={'actual_live':False,'actual_pid':owner['actual_pid'],'shim_pid':owner['parent_pid'],'source':'work/replay_fixed_receipts_with_next_context_20261019.py','closed_result':str((SCREEN/'Results.json').relative_to(R))},
        waiting_check={'automation_id':'hiergrid-next-context-result-check','status':'DELETED_TERMINAL','deleted_on_observed_completion':True},next_steps_in_order=next_steps,exact_next_cell=str((B/'Exact_Next_Cell.json').relative_to(R)),latest_verified_published_head='0f13070af2f157df54f9c2d35b6095eb5fccb042')
    atomic(current,resume)
    canonical=R/'outputs/substantive_research_progress_20261018/Exact_Next_Execution_State.json';v=read(canonical);v.update(at_utc=at,active_owned_jobs=[],timers=[],latest_closed_continuation=str(current.relative_to(R)),next_tasks=next_steps,
        current_task={'status':resume['status'],'next_cell':str((B/'Exact_Next_Cell.json').relative_to(R))},latest_verified_GitHub_head=resume['latest_verified_published_head']);atomic(canonical,v)
    tasks=R/'outputs/research_tasks_20261014/Tasks.json';v=read(tasks);v['at_utc']=at;v['tasks'][0]['next']='Follow outputs/next_fixed_physical_cell_20261019/Next_Execution.md. Exactly'+str(len(pending))+'remaining preselected menu queries need a new arity-bound protocol; no silent reuse of completed THREE-query owner.';v['latest_exact_execution_state']=str(current.relative_to(R));atomic(tasks,v)
    header=f'LATEST TERMINAL CONTINUATION {at}\n\nToday3safequeries17to14UV/6chargedPF independentPASS; requirednewcontext1430forecasts+equations/fullmenuPASS, importfailure/additive0science repairpreserved. LastreadonlyscreenCLOSED389.536sec,3contexts4290paidforecasts,0newscience, nextphysicalgap. Allactorsended/noGPU/timers; waitingautomationdeleted. Read outputs/next_fixed_physical_cell_20261019/Next_Execution.md and Current_Resume_20261019.json. Next exactly{len(pending)}preselected originalK4queries require NEWarity-bound source/worker/persistentcold/reader/ownership/fullcost protocol before execution. Scopeabsencealone is not PFpermission. All6goalsopen, noactualcommit/wholeDSE/LLMsuperiority. Frozenassets/adverse/UNKNOWN/fullbothDSEcosts retained.\n\n'
    for rel in ('outputs/Unattended_Execution_Runbook.md','outputs/llm_value_development/Next_Phase_Plan.md'):
        p=R/rel;p.write_text(header+p.read_text('utf-8'),'utf-8')
    with (R/'reseacrh progress.txt').open('a',encoding='utf-8') as f:
        f.write('\n\n'+at+' —Lastchanged-evidence screenCLOSED389.5360964sec/3exactcontextreuses/4290paidforecastsreused,0newscience. Policy remainsUNKNOWN atnextphysicalreceipt; alloriginalselectedmenu retained. Prepared'+str(len(pending))+'unexecuted originalK4queries, componentmatches '+json.dumps([{k:x[k] for k in ('tracked_BEFORE_matches','static_observed_matches','recent10_BEFORE_matches')} for x in pending])+'. Allactorsended/noGPU/timers; one-timecheckdeleted immediatelyatterminal. No new actualcommit/fullpolicy/LLMclaim. Exactnext '+str((B/'Next_Execution.md').relative_to(R))+'.\n');f.flush();os.fsync(f.fileno())
    manifest(B)
    files={p.relative_to(R).as_posix():p for p in B.iterdir() if p.is_file()}
    for p in [Path(__file__),SCREEN/'Results.json',SCREEN/'Leg_1.json',SCREEN/'Closed_Manifest.json',current,tasks,canonical,R/'RESEARCH_TASKS.md']:files[p.relative_to(R).as_posix()]=p
    for n,p in files.items():assert not SECRET_NAME.search(p.name) and not any(s.search(p.read_text('utf-8')) for s in SECRET),n
    desc={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()};put(B/'Public_Manifest.json',{'files':desc,'all6goalsopen':True,'no_rawNET_or_model_export':True})
    dest=B/'Closed_Cell_Code_And_Proofs.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,p in files.items():z.write(p,n)
        z.write(B/'Public_Manifest.json','Public_Manifest.json')
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for n,d in desc.items():raw=z.read(n);assert len(raw)==d['bytes'] and hashlib.sha256(raw).hexdigest()==d['sha256']
    put(B/'Archive_Audit.json',{'status':'PASS_UNIQUE_CRC_ALL_HASH_SECRET_SCREEN','bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(files)+1})
    print(json.dumps({'all_jobs_ended':True,'next_unexecuted_queries':len(pending),'scope_hits':[{k:x[k] for k in ('tracked_BEFORE_matches','static_observed_matches','recent10_BEFORE_matches')} for x in pending],'timer':'DELETED','new_science':0,'public_pack_bytes':dest.stat().st_size}))
if __name__=='__main__':main()
