# Verified result and next decision

The new physical opportunity test is complete. Its independent evidence audit passed, but the prospectively fixed feedback gate failed. Stop this same-bus residual feedback route and its conditional model training on this dataset.

All eight new cases were valid, initially undervoltage-stressed and protected at the normal upper limit. No case was selected after seeing the outcome. Each policy requested exactly eight distinct actions from the full native universe, then nominated its best actually accepted, protected returned action or abstained. These are isolated one-step measurements and masked saved-receipt policy diagnostics; no action was committed and no controller episode was run.

| Policy | Found the full-table best accepted action | Percentage |
|---|---:|---:|
| Simple current-voltage/Q ordering | 1 of 8 | 12.5% |
| Current-Jacobian numerical ordering | 6 of 8 | 75.0% |
| Same-bus correction using requested feedback | 5 of 8 | 62.5% |

Feedback gained 50 percentage points over simple ordering but lost 12.5 points to the current-Jacobian control. It strictly improved in four cases against simple ordering and only one against the Jacobian; the fixed requirement was at least three against each, plus at least five percentage points mean improvement against each. All eight cases remain in the result. Unsafe/unqueried nominations were zero. This is a measured failed gate, not an UNKNOWN dataset result.

## What was actually executed

There were 1,134 new physical action receipts. Measurement used 1,142 actual PF returns; independent replay used 2,276 more, with zero exceptions. The replay count includes a root solve and an action solve for each query, plus eight root-only checks. All 1,142 saved observation states were independently checked, with full physical fields agreeing within 1e-10 and exact UV/protection memberships. Source identities, original verifier/score/Q/cap/scopes and all nine frozen-asset gates passed. The original model/network/controller/settings/bank were preserved. New model, optimizer, controller and cloud calls were zero.

The measurement/replay/data workflow before final hashing was 1,107.560 seconds; terminal collector status was recorded at 1,128.266 seconds. The external reader and archive validation took 235.823 seconds. Preparation, prior data/control costs and input-token readiness costs are separate and not free. The collector's exact cleanup termination time was not continuously observed; its full owned interval remains unknown rather than being inferred from the later check.

The verified local archive has 22 members, 523,695,061 bytes, SHA256 `ab99d4a4a880bcd7f6e1d601f52f9517b73996d95856a859ecf3f4828eef3319`. CRC and every member hash passed. Reuse this certificate; do not rehash it at every follow-up.

## Economics and limits

This fixed eight-query screen had a mean additional-model allowance of -0.032360 seconds per decision against the per-case cheapest static cost. That is a descriptive conditional allowance, not measured LLM latency or a proof that all feedback/stopping policies are uneconomic. Feedback's total tool/numerical cost was slightly lower than the Jacobian's, but its decision quality was lower. The simple policy was cheaper and much less accurate. Actual model, training and supported deployment-workload costs remain UNKNOWN. Full trajectory/deployment efficiency is not established.

Saved Jacobian matrices/RHS/sensitivity vectors are absent. The original numerical source and stored residual are bound, but an independent equation certificate is UNKNOWN; no forecast or solve was repeated to manufacture it. The eight cases are now development data, not unused confirmation. No LLM ran, so this test does not demonstrate or refute every possible LLM contribution.

## Execution plan state

Stage 0 completed: all 16,000 TRAIN examples have additive input/token/span evidence, no conflicting current-input action classes or size-token mismatches, and no 4096/384 limit violation in the proposed interface. This is input readiness, not learned policy value.

Stage 1 completed and failed the fixed opportunity gate. Conditional Stages 2–6 for this route remain unexecuted; do not launch its trained numerical or 1.5B study, alter its residual rule, select favorable cases, lower thresholds or restart owners. The original detailed priority plan and its independent language/economic challenge are preserved.

A future continuation needs a materially different, evidence-backed mechanism or a separately justified matched adapted-scale question, a prospectively fixed protocol and strong equally informed numerical controls. No such launch-ready campaign is established by this result. Future LLM superiority still needs real fresh inference, matched complete protected trajectories against both literal D-SE branches and unchanged selector, full BOTH-branch and model/preparation/failure costs, attribution controls and genuinely unused confirmation. The overall objective remains unachieved. A calibrated 90% probability of discovering a winner cannot be claimed.

